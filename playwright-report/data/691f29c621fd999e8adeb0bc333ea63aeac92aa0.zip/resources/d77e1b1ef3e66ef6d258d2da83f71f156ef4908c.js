import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Payment.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { FaMoneyBillWave, FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Modal as AntModal, Drawer, Tooltip, Tag, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { FaReceipt } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import Modal from "/src/components/modals/Modal.jsx";
import { FiChevronDown, FiSearch } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import ReConfirmModal from "/src/components/modals/ReConfirmModal.jsx";
const Payment = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [actualGroups, setActualGroups] = useState([]);
  const [TablePayments, setTablePayments] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [viewLoader, setViewLoader] = useState(false);
  const [filteredEnrollments, setFilteredEnrollments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [enrollmentLoading, setEnrollmentLoading] = useState(false);
  const [showModalView, setShowModalView] = useState(false);
  const [currentViewGroup, setCurrentViewGroup] = useState(null);
  const [whatsappEnable, setWhatsappEnable] = useState(true);
  const [paymentMode, setPaymentMode] = useState("cash");
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [borrowers, setBorrowers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [paymentGroupTickets, setPaymentGroupTickets] = useState([]);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [currentGroupId, setCurrentGroupId] = useState(null);
  const [openAntDDrawer, setOpenAntDDrawer] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [lastThreePayments, setLastThreePayments] = useState([]);
  const [showGroupPayment, setShowGroupPayment] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [thirdPartyEnable, setThirdPartyEnable] = useState({
    whatsapp: true
  });
  const [open, setOpen] = useState(false);
  const [printAfterConfirm, setPrintAfterConfirm] = useState(false);
  const dropDownItems = (paymentObject) => {
    const dropDownItemList = [
      {
        key: "1",
        label: /* @__PURE__ */ jsxDEV(Link, { to: `/print/${paymentObject?._id}`, className: "text-violet-600 ", children: "Print" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
          lineNumber: 62,
          columnNumber: 7
        }, this)
      },
      {
        key: "3",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-green-600 ",
            onClick: () => handleViewModalOpen(paymentObject?._id),
            children: "View"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
            lineNumber: 71,
            columnNumber: 7
          },
          this
        )
      }
    ];
    return dropDownItemList;
  };
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    remarks: "",
    user_id: "",
    receipt_no: "",
    pay_date: today,
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    payment_group_tickets: [],
    account_type: "",
    cheque_number: "",
    cheque_date: "",
    cheque_bank_name: "",
    cheque_bank_branch: "",
    collection_time: ""
  });
  const [modifyPayment, setModifyPayment] = useState(false);
  const [modifyMinMaxPaymentDate, setModifyMinMaxPaymentDate] = useState(false);
  const yesterday = new Date((/* @__PURE__ */ new Date()).setDate((/* @__PURE__ */ new Date()).getDate() - 2)).toISOString().split("T")[0];
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj) {
      const adminAccessPermissions = userObj.admin_access_right_id?.access_permissions;
      if (adminAccessPermissions?.edit_payment === "true") {
        setModifyPayment(true);
      }
      if (adminAccessPermissions?.edit_limited_payment === "true") {
        setModifyPayment(true);
        setModifyMinMaxPaymentDate(true);
      }
    }
  }, []);
  const fetchLastThreeTransactions = async (event) => {
    event.preventDefault();
    setOpenAntDDrawer(true);
    if (formData.user_id && formData.payment_group_tickets) {
      try {
        setShowLoader(true);
        const response = await api.get("payment/get-last-n-transaction", {
          params: {
            user_id: formData.user_id,
            payment_group_tickets: paymentGroupTickets,
            limit: 3
          }
        });
        if (response?.data) {
          setLastThreePayments(response.data);
        } else {
          setLastThreePayments([]);
        }
      } catch (error) {
        setLastThreePayments([]);
      } finally {
        setShowLoader(false);
      }
    }
  };
  useEffect(() => {
    setBorrowers([]);
    const fetchCustomerLoanDetails = async () => {
      if (!selectedUserId) return;
      try {
        const response = await api.get(`/v1/admin/loans/get-borrower-details/${selectedUserId}`);
        if (response.data?.data) {
          setBorrowers(response.data.data);
        } else {
          setBorrowers([]);
        }
      } catch (err) {
        setBorrowers([]);
        console.log("Error fetching loan details:", err);
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedUserId]);
  useEffect(() => {
    setPigmeCustomers([]);
    const fetchCustomerPigmeDetails = async () => {
      if (!selectedUserId) return;
      try {
        const response = await api.get(`/v1/admin/pigmes/get-pigme-customer-details/${selectedUserId}`);
        if (response.data?.data) {
          setPigmeCustomers(response.data.data);
        } else {
          setPigmeCustomers([]);
        }
      } catch (err) {
        setPigmeCustomers([]);
        console.log("Error fetching pigme details:", err);
      }
    };
    fetchCustomerPigmeDetails();
  }, [selectedUserId]);
  useEffect(() => {
    const fetchAllCustomers = async () => {
      try {
        const response = await api.get("user/verified");
        setUsers(response?.data?.data);
      } catch (error) {
        setUsers([]);
        console.error("Error fetching group data:", error);
      }
    };
    fetchAllCustomers();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setActualGroups(response.data);
      } catch (error) {
        setActualGroups([]);
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  const validateForm = () => {
    const newErrors = {};
    if (!selectedUserId) {
      newErrors.customer = "Please select a customer";
    }
    if (!formData.payment_group_tickets) {
      newErrors.payment_group_tickets = "Please select a group and ticket";
    }
    if (!formData.pay_date) {
      newErrors.pay_date = "Payment date is required";
    }
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    }
    if (paymentMode === "online" && !formData.transaction_id?.trim()) {
      newErrors.transaction_id = "Transaction ID is required for online payments";
    }
    if (paymentMode === "cheque" && !formData.cheque_date?.trim()) {
      newErrors.cheque_date = "Cheque Date is required for cheque payments";
    }
    if (paymentMode === "cheque" && !formData.cheque_number?.trim()) {
      newErrors.cheque_number = "Cheque Number is required for cheque payments";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "amount") {
      let cleaned = value.replace(/[^0-9.]/g, "");
      const dotCount = (cleaned.match(/\./g) || []).length;
      if (dotCount > 1) return;
      setFormData((prev) => ({
        ...prev,
        [name]: cleaned
      }));
      return;
    }
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };
  const handlePaymentAntSelect = (values) => {
    setPaymentGroupTickets(values);
  };
  const formatIndianNumber = (value) => {
    if (!value) return "";
    value = value.toString().replace(/[^0-9.]/g, "");
    const parts = value.split(".");
    const integerPart = parts[0];
    const decimalPart = parts[1] ? parts[1].slice(0, 2) : "";
    let lastThree = integerPart.slice(-3);
    let otherNumbers = integerPart.slice(0, -3);
    let formattedInt = otherNumbers ? otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + lastThree : lastThree;
    return decimalPart ? `${formattedInt}.${decimalPart}` : formattedInt;
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "ticket", header: "Ticket Number" },
    { key: "old_receipt", header: "Old Receipt" },
    { key: "receipt", header: "Receipt" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Payment Type" },
    { key: "collection_time", header: "Collection Time" },
    { key: "collected_by", header: "Collected By" },
    { key: "action", header: "Action" }
  ];
  const handleCustomer = async (userId) => {
    setFilteredUsers([]);
    setFilteredEnrollments([]);
    setSelectedUserId(userId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      user_id: userId
    }));
    setErrors((prevData) => ({ ...prevData, customer: "" }));
    setPaymentGroupTickets([]);
    handleGroupAuctionChange(userId);
  };
  const handleGroupPayment = async (groupId) => {
    if (groupId) {
      let url = `/payment/get-payments-by-dates?from_date=${today}&to_date=${today}`;
      try {
        setIsLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id?.group_name) return {};
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              ticket: group.ticket,
              receipt: group.receipt_no,
              old_receipt: group.old_receipt_no,
              amount: group.amount,
              pay_type: group?.pay_type,
              date: group?.pay_date.split("T")[0],
              transaction_date: group?.createdAt?.split("T")[0],
              collected_by: group?.collected_by?.name || group?.admin_type?.admin_name || "Super Admin",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: dropDownItems(group)
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 381,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 374,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 373,
                columnNumber: 15
              }, this)
            };
          });
          setShowGroupPayment(true);
          setTablePayments(formattedData);
        }
      } catch (error) {
        setTablePayments([]);
        console.error("Error fetching payment data:", error);
      } finally {
        setIsLoading(false);
      }
    }
  };
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" || selectedMode === "online/upi" ? prevData.transaction_id : ""
    }));
  };
  const handleAccountTypeChange = (e) => {
    const selectedMode = e.target.value;
    setFormData((prevData) => ({
      ...prevData,
      account_type: selectedMode
    }));
  };
  const resetForm = () => {
    setSelectedUserId("");
    setPaymentGroupTickets([]);
    setPaymentMode("cash");
    setFormData({
      remarks: "",
      user_id: "",
      receipt_no: "",
      pay_date: today,
      amount: "",
      pay_type: "cash",
      transaction_id: "",
      payment_group_tickets: [],
      account_type: "",
      cheque_number: "",
      cheque_date: "",
      cheque_bank_name: "",
      cheque_bank_branch: "",
      collection_time: ""
    });
    setErrors({});
  };
  const handleSubmit = async (printFlag) => {
    try {
      setOpenBackdropLoader(true);
      formData.payment_group_tickets = paymentGroupTickets;
      formData.admin_type = JSON.parse(localStorage.getItem("user"))?._id;
      const payload = {
        ...formData,
        whatsapp: thirdPartyEnable.whatsapp
      };
      const response = await api.post("/payment/add-payments", payload);
      if (printFlag) {
        const paymentIds = response.data.data.map((item) => item._id);
        if (paymentIds.length > 0) {
          window.open(`/print/${paymentIds[0]}`, "_blank");
        }
      }
      resetForm();
      setAlertConfig({
        visibility: true,
        noReload: true,
        message: "Payment Added Successfully",
        type: "success"
      });
    } catch (error) {
      setAlertConfig({
        visibility: true,
        noReload: true,
        message: `Error submitting payment: ${error.message}`,
        type: "error"
      });
    } finally {
      setOpenBackdropLoader(false);
      setShowConfirm(false);
    }
  };
  const handleViewModalOpen = async (paymentId) => {
    try {
      setLoading(true);
      setShowModalView(true);
      setCurrentGroupId(paymentId);
      setViewLoader(true);
      const response = await api.get(`/payment/get-payment-by-id/${paymentId}`);
      setCurrentViewGroup(response.data);
    } catch (error) {
      console.error("Error viewing Payment:", error);
    } finally {
      setLoading(false);
      setViewLoader(false);
    }
  };
  const handleGroupAuctionChange = async (userId) => {
    if (!userId) return;
    try {
      const response = await api.get(`/v1/admin/enrolls/users/${userId}`);
      if (response.data?.data?.length > 0) {
        const transformed = response.data.data.map((item) => ({
          enrollment: {
            group: item.group_id,
            tickets: item.tickets
          },
          payments: {
            totalPaidAmount: item.total_investment
          },
          payable: {
            totalPayable: item.total_payable
          },
          profit: {
            totalProfit: item.total_profit
          },
          auction: {
            auctionCount: item.total_count
          },
          firstAuction: {
            firstDividentHead: item.first_divident_head
          },
          // Additional fields
          group_install: item.group_install,
          total_penalty: item.total_penalty,
          total_late_fee: item.total_late_fee,
          total_balance: item.total_balance
        }));
        setFilteredEnrollments(transformed);
      } else {
        setFilteredEnrollments([]);
      }
    } catch (error) {
      console.error("Error fetching enrollment data:", error);
      setFilteredEnrollments([]);
    }
  };
  const selectedCustomer = users.find(
    (user) => user._id === formData.user_id || user._id === selectedUserId
  );
  const selectedGroupTickets = paymentGroupTickets.map((item) => {
    const enrollment = filteredEnrollments.find((entry) => {
      const groupId = entry?.enrollment?.group?._id;
      const ticket = entry?.enrollment?.tickets;
      return `chit-${groupId}|${ticket}` === item;
    });
    if (enrollment) {
      return `${enrollment?.enrollment?.group?.group_name} | ${enrollment?.enrollment?.tickets}`;
    }
    const pigme = pigmeCustomers?.find(
      (p) => `pigme-${p._id}` === item
    );
    if (pigme) {
      return `${pigme.pigme_id} | ₹ ${pigme.payable_amount}`;
    }
    const borrower = borrowers?.find(
      (b) => `loan-${b._id}` === item
    );
    if (borrower) {
      return `${borrower.loan_id} | ₹ ${borrower.loan_amount}`;
    }
    return item;
  });
  const confirmData = {
    customer_name: selectedCustomer?.full_name || "",
    group_tickets: selectedGroupTickets.join(", "),
    ...formData
  };
  const sanitizedConfirmData = Object.fromEntries(
    Object.entries(confirmData).filter(([key, value]) => {
      return key !== "user_id" && //  remove user_id field
      value !== null && value !== void 0 && value !== "" && !(Array.isArray(value) && value.length === 0);
    })
  );
  const handleReconfirmation = (e, printFlag) => {
    e.preventDefault();
    const isValid = validateForm("addGroup");
    if (!isValid) {
      console.warn("Please fill all the required fields");
      return;
    }
    setPrintAfterConfirm(printFlag);
    setShowConfirm(true);
  };
  const getTicketDetails = (item) => {
    if (item.startsWith("chit-")) {
      const enrollment = filteredEnrollments.find((entry) => {
        const groupId = entry?.enrollment?.group?._id;
        const ticket = entry?.enrollment?.tickets;
        return `chit-${groupId}|${ticket}` === item;
      });
      if (enrollment) {
        return {
          type: "chit",
          name: enrollment.enrollment?.group?.group_name || "",
          ticket: enrollment.enrollment?.tickets || 0,
          payable: enrollment.payable?.totalPayable || 0,
          profit: enrollment.profit?.totalProfit || 0,
          totalPaid: enrollment.payments?.totalPaidAmount || 0,
          group_value: enrollment.enrollment?.group?.group_value || 0,
          group_install: enrollment.enrollment?.group?.group_install || 0,
          auctionCount: enrollment.auction?.auctionCount || 0,
          dividentHead: enrollment.firstAuction?.firstDividentHead || 0,
          // These fields don't exist in the logged response
          totalPenalty: 0,
          totalLateFee: 0,
          balance: (enrollment.payable?.totalPayable || 0) - (enrollment.payments?.totalPaidAmount || 0)
        };
      }
    } else if (item.startsWith("pigme-")) {
      const pigme = pigmeCustomers?.find((p) => `pigme-${p._id}` === item);
      if (pigme) {
        const maturity_period = pigme.maturity_period;
        const payable_amount = Number(pigme.payable_amount || 0);
        const start_date = pigme.start_date;
        const duration = Number(pigme.duration || 0);
        const total_paid_amount = Number(pigme.total_paid_amount || 0);
        return {
          type: "pigmy",
          name: pigme.pigme_id,
          ticket: "-",
          maturityPeriod: maturity_period,
          payableAmount: payable_amount,
          startDate: start_date,
          duration,
          totalPaid: total_paid_amount,
          profit: 0,
          auctionCount: 0
        };
      }
    } else if (item.startsWith("loan-")) {
      const borrower = borrowers?.find((b) => `loan-${b._id}` === item);
      if (borrower) {
        const dailyPayment = borrower.daily_payment_amount || 0;
        const loanAmount = borrower?.loan_amount || 0;
        const totalPaid = borrower?.total_payments || 0;
        const startDate = borrower?.start_date;
        const endDate = borrower?.end_date;
        const balance = borrower?.remaining_loan || 0;
        const totalLoan = borrower.loan_amount || 0;
        return {
          type: "loan",
          name: borrower.loan_id,
          ticket: "-",
          loanAmount,
          dailyPayment,
          startDate,
          endDate,
          totalPaid,
          balance,
          profit: 0,
          auctionCount: 0
        };
      }
    }
    return null;
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: openBackdropLoader ? /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "payment Data processing...." }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
    lineNumber: 706,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 mt-12", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
      lineNumber: 710,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
          lineNumber: 712,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          noReload: alertConfig.noReload
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
          lineNumber: 716,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          isVisible: showGroupPayment,
          onClose: () => setShowGroupPayment(false),
          children: /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-4", children: "Group Payment Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 728,
              columnNumber: 19
            }, this),
            TablePayments && TablePayments.length > 0 ? /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: TablePayments.filter(
                  (item) => Object.values(item).some(
                    (value) => String(value).toLowerCase().includes(searchText.toLowerCase())
                  )
                ),
                columns,
                exportedPdfName: "Payments",
                printHeaderKeys: ["Group Name"],
                printHeaderValues: ["Today's"],
                exportedFileName: `Payments.csv`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 730,
                columnNumber: 17
              },
              this
            ) : /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-8", children: /* @__PURE__ */ jsxDEV(
              CircularLoader,
              {
                isLoading,
                data: "Payments Data",
                failure: TablePayments.length <= 0
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 746,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 745,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
            lineNumber: 727,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
          lineNumber: 723,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto ", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border-b-2 border-blue-900 p-2 mb-2 flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-blue-900 uppercase tracking-wider", children: "Add New Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 759,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: fetchLastThreeTransactions,
                className: "flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-all",
                children: [
                  /* @__PURE__ */ jsxDEV(FaReceipt, { className: "text-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 767,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Last 3 Transactions" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 768,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 762,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
            lineNumber: 758,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end", marginBottom: "1.5rem" }, children: /* @__PURE__ */ jsxDEV("div", { style: { position: "relative" }, children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                style: {
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  background: "#1e3a8a",
                  color: "#fff",
                  fontWeight: 600,
                  padding: "0.625rem 1.25rem",
                  borderRadius: "1rem",
                  boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
                  border: "1px solid rgba(147, 51, 234, 0.2)",
                  minWidth: "250px",
                  cursor: "pointer",
                  transition: "all 0.3s ease"
                },
                onClick: (e) => e.currentTarget.nextSibling.classList.toggle("hidden"),
                children: [
                  /* @__PURE__ */ jsxDEV("span", { style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", paddingRight: "0.5rem" }, children: selectedGroupId ? actualGroups.find((g) => g._id === selectedGroupId)?.group_name : "Search or Select Group" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 793,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(FiChevronDown, { style: { transition: "transform 0.3s" } }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 798,
                    columnNumber: 25
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 774,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "hidden",
                style: {
                  position: "absolute",
                  top: "85%",
                  right: 0,
                  bottom: 10,
                  marginTop: "0.5rem",
                  minWidth: "250px",
                  background: "#fff",
                  borderRadius: "0.75rem",
                  boxShadow: "0 10px 25px rgba(0,0,0,0.15)",
                  border: "1px solid #e5e7eb",
                  padding: "0.25rem 0",
                  zIndex: 10
                },
                children: /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    placeholder: "Search Group",
                    showSearch: true,
                    value: selectedGroupId || void 0,
                    onChange: (value) => {
                      setSelectedGroupId(value);
                      handleGroupPayment(value);
                    },
                    suffixIcon: /* @__PURE__ */ jsxDEV(FiSearch, { style: { color: "#9333ea" } }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 827,
                      columnNumber: 37
                    }, this),
                    style: { width: "100%", border: "none", boxShadow: "none" },
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    children: actualGroups.map(
                      (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 834,
                        columnNumber: 25
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 819,
                    columnNumber: 25
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 802,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
            lineNumber: 773,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
            lineNumber: 772,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("form", { onSubmit: handleReconfirmation, className: "space-y-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                "Customer ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 846,
                  columnNumber: 34
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 845,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  placeholder: "Select Or Search Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  className: "w-full h-12",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: selectedUserId || void 0,
                  onChange: handleCustomer,
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: `${user.full_name} | ${user.phone_number}` }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 863,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 848,
                  columnNumber: 23
                },
                this
              ),
              errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 869,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 844,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `${enrollmentLoading ? "opacity-70" : ""}`, children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                "Group & Ticket ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 875,
                  columnNumber: 40
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 874,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  disabled: enrollmentLoading,
                  mode: "multiple",
                  name: "group_id",
                  open,
                  onDropdownVisibleChange: setOpen,
                  placeholder: "Select Group | Ticket",
                  onChange: (value) => {
                    handlePaymentAntSelect(value);
                    setOpen(false);
                  },
                  loading: enrollmentLoading,
                  value: paymentGroupTickets,
                  className: "w-full",
                  children: [
                    filteredEnrollments.map((entry, index) => {
                      const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                      const groupId = entry?.enrollment?.group?._id || `missing-${index}`;
                      const ticket = entry?.enrollment?.tickets || "Unknown";
                      return /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: `chit-${groupId}|${ticket}`,
                          children: [
                            groupName,
                            " | ",
                            ticket
                          ]
                        },
                        `chit-${groupId}|${ticket}`,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 898,
                          columnNumber: 27
                        },
                        this
                      );
                    }),
                    pigmeCustomers?.map(
                      (pigme) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `pigme-${pigme._id}`, children: `${pigme.pigme_id} | ₹ ${pigme.payable_amount}` }, `pigme-${pigme._id}`, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 907,
                        columnNumber: 23
                      }, this)
                    ),
                    borrowers?.map(
                      (borrower) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `loan-${borrower._id}`, children: `${borrower.loan_id} | ₹ ${borrower.loan_amount}` }, `loan-${borrower._id}`, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 912,
                        columnNumber: 23
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 877,
                  columnNumber: 23
                },
                this
              ),
              errors.payment_group_tickets && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.payment_group_tickets }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 918,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 873,
              columnNumber: 21
            }, this),
            paymentGroupTickets.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 animate-fade-in-up", children: paymentGroupTickets.map((item) => {
              const details = getTicketDetails(item);
              if (!details) return null;
              const balanceColor = details.balance > 0 ? "text-red-600" : "text-green-600";
              const balanceBg = details.balance > 0 ? "bg-red-50" : "bg-emerald-50";
              const tagStyles = {
                chit: "bg-blue-100 text-blue-700",
                loan: "bg-purple-100 text-purple-700",
                pigmy: "bg-amber-100 text-amber-700"
              };
              let fields = [];
              if (details.type === "chit") {
                fields = [
                  { label: "Total Payable", value: `₹${details.payable?.toLocaleString("en-IN")}` },
                  { label: "Total Paid", value: `₹${details.totalPaid?.toLocaleString("en-IN")}` },
                  { label: "Penalty", value: `₹${details.totalPenalty?.toLocaleString("en-IN")}` },
                  { label: "Late Fee", value: `₹${details.totalLateFee?.toLocaleString("en-IN")}` },
                  { label: "Balance Due", value: `₹${details.balance?.toLocaleString("en-IN")}`, highlight: true }
                ];
              } else if (details.type === "loan") {
                fields = [
                  { label: "Loan Amount", value: `₹${details.loanAmount?.toLocaleString("en-IN")}` },
                  { label: "Start Date", value: details.startDate?.split("T")[0].split("-").reverse().join("-") },
                  { label: "End Date", value: details.endDate?.split("T")[0].split("-").reverse().join("-") },
                  { label: "Daily Payment", value: `₹${details.dailyPayment?.toLocaleString("en-IN")}` },
                  { label: "Total Paid", value: `₹${details.totalPaid?.toLocaleString("en-IN")}` },
                  { label: "Balance", value: `₹${details.balance?.toLocaleString("en-IN")}`, highlight: true }
                ];
              } else if (details.type === "pigmy") {
                fields = [
                  { label: "Daily Amount", value: `₹${details.payableAmount?.toLocaleString("en-IN")}` },
                  { label: "Start Date", value: details.startDate?.split("T")[0].split("-").reverse().join("-") },
                  { label: "Duration", value: `${details.duration} months` },
                  { label: "Total Paid", value: `₹${details.totalPaid?.toLocaleString("en-IN")}`, color: "text-green-600" }
                ];
              }
              return /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `bg-white rounded-xl shadow-sm border border-gray-100 border-l-4 hover:shadow-md transition-all duration-200 overflow-hidden ${details.balance > 0 ? "border-l-red-500" : "border-l-emerald-500"}`,
                  children: /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3 mb-3", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider ${tagStyles[details.type] || "bg-gray-100 text-gray-700"}`, children: details.type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 977,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-900 truncate max-w-[250px]", children: details.name }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 980,
                        columnNumber: 35
                      }, this),
                      details.type === "chit" && details.ticket && details.ticket !== "-" && /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md", children: [
                        "Ticket: ",
                        details.ticket
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 984,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 976,
                      columnNumber: 33
                    }, this),
                    details.type === "chit" && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5 mb-1 pb-1 border-b border-dashed border-gray-200 text-xs text-gray-500 font-medium", children: [
                      /* @__PURE__ */ jsxDEV("span", { children: [
                        "Group Value: ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800 font-semibold", children: details.group_value }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 994,
                          columnNumber: 52
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 993,
                        columnNumber: 37
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: [
                        "Installment: ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800 font-semibold", children: details.group_install }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 997,
                          columnNumber: 52
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 996,
                        columnNumber: 37
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 992,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: `grid grid-cols-2 sm:grid-cols-3 gap-4 ${details.type === "loan" ? "lg:grid-cols-6" : "lg:grid-cols-5"}`, children: fields.map(
                      (field, idx) => /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `flex flex-col rounded-lg px-1 py-1 -mx-1 transition-colors ${field.highlight ? balanceBg : "hover:bg-gray-50"}`,
                          children: [
                            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-medium text-gray-400 uppercase tracking-wide mb-1", children: field.label }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                              lineNumber: 1011,
                              columnNumber: 39
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              "span",
                              {
                                className: `text-base font-semibold tracking-tight ${field.color ? field.color : field.highlight ? balanceColor : "text-gray-800"}`,
                                children: field.value
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                                lineNumber: 1014,
                                columnNumber: 39
                              },
                              this
                            )
                          ]
                        },
                        idx,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1006,
                          columnNumber: 31
                        },
                        this
                      )
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1003,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 973,
                    columnNumber: 31
                  }, this)
                },
                item,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 968,
                  columnNumber: 25
                },
                this
              );
            }) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 924,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-6 border border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-900 mb-4", children: "Payment Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1047,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Payment Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1051,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      disabled: !modifyPayment,
                      type: "date",
                      name: "pay_date",
                      min: modifyMinMaxPaymentDate ? yesterday : void 0,
                      max: modifyMinMaxPaymentDate ? today : void 0,
                      value: formData.pay_date,
                      id: "pay_date",
                      onChange: handleChange,
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1054,
                      columnNumber: 27
                    },
                    this
                  ),
                  errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1066,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1050,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                    "Amount ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1072,
                      columnNumber: 36
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1071,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "amount",
                      value: formatIndianNumber(formData.amount),
                      id: "amount",
                      onChange: handleChange,
                      placeholder: "Enter Amount",
                      required: true,
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1074,
                      columnNumber: 27
                    },
                    this
                  ),
                  errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1085,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[#1e3a8a] text-sm mt-1 italic", children: numberToIndianWords(formData.amount) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1087,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1070,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Payment Mode" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1093,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      name: "pay_mode",
                      id: "pay_mode",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all",
                      onChange: handlePaymentModeChange,
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1102,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1103,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "online/upi", children: "Online/UPI" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1104,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1105,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "Credit Note", children: "Credit Note" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1106,
                          columnNumber: 29
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1096,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1092,
                  columnNumber: 25
                }, this),
                modifyPayment && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Account Type" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1112,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      name: "account_type",
                      id: "account_type",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-gray-50 focus:bg-white transition-all",
                      onChange: handleAccountTypeChange,
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Account Type" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1121,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "suspense", children: "Suspense" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1122,
                          columnNumber: 31
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1115,
                      columnNumber: 29
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1111,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1049,
                columnNumber: 23
              }, this),
              formData.amount && paymentGroupTickets.length > 1 && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-dashed border-gray-300", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Individual Ticket Amount" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1131,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed opacity-70",
                      placeholder: "Individual Amount",
                      value: formatIndianNumber(
                        Number(formData.amount) / paymentGroupTickets.length
                      ),
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1134,
                      columnNumber: 29
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1130,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[#1e3a8a] text-sm mt-1 italic", children: numberToIndianWords(
                  Number(formData.amount) / paymentGroupTickets.length
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1144,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1129,
                columnNumber: 21
              }, this),
              (paymentMode === "online" || paymentMode === "online/upi") && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                  "Transaction ID ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1156,
                    columnNumber: 46
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1155,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "transaction_id",
                    id: "transaction_id",
                    value: formData.transaction_id,
                    onChange: handleChange,
                    placeholder: "Enter Transaction ID",
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1158,
                    columnNumber: 29
                  },
                  this
                ),
                errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1168,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1154,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1153,
                columnNumber: 21
              }, this),
              paymentMode === "cheque" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("h5", { className: "text-base font-semibold text-gray-900 mb-3", children: "Cheque Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1176,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                      "Cheque Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1180,
                        columnNumber: 47
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1179,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "cheque_number",
                        id: "cheque_number",
                        value: formData.cheque_number,
                        onChange: handleChange,
                        placeholder: "Enter Cheque Number",
                        className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1182,
                        columnNumber: 31
                      },
                      this
                    ),
                    errors.cheque_number && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1192,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1178,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                      "Cheque Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1198,
                        columnNumber: 45
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1197,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        name: "cheque_date",
                        id: "cheque_date",
                        value: formData.cheque_date.split("T")[0],
                        onChange: handleChange,
                        placeholder: "Enter Cheque Date",
                        className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1200,
                        columnNumber: 31
                      },
                      this
                    ),
                    errors.cheque_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_date }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1210,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1196,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1215,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "cheque_bank_name",
                        id: "cheque_bank_name",
                        value: formData.cheque_bank_name,
                        onChange: handleChange,
                        placeholder: "Enter Bank Name",
                        className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1218,
                        columnNumber: 31
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1214,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Branch" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1230,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "cheque_bank_branch",
                        id: "cheque_bank_branch",
                        value: formData.cheque_bank_branch,
                        onChange: handleChange,
                        placeholder: "Enter Bank Branch",
                        className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1233,
                        columnNumber: 31
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1229,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1177,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1175,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Remarks" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1248,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    name: "remarks",
                    id: "remarks",
                    value: formData?.remarks,
                    onChange: handleChange,
                    placeholder: "Remarks if any...",
                    rows: 2,
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]   focus:border-transparent bg-gray-50 focus:bg-white transition-all resize-vertical"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1251,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1247,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1046,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4 border border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { className: "text-green-500 text-2xl" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1266,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-semibold text-gray-900", children: "WhatsApp Notification" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1267,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1265,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: thirdPartyEnable.whatsapp,
                    className: "w-5 h-5 text-green-500 rounded focus:ring-green-500",
                    onChange: () => setThirdPartyEnable((prev) => ({
                      ...prev,
                      whatsapp: !prev.whatsapp
                    }))
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1270,
                    columnNumber: 27
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: "Send Via WhatsApp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1281,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1269,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1264,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1263,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-4 mt-6", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: (e) => handleReconfirmation(e, true),
                  className: "px-7 py-2.5 rounded-xl bg-gradient-to-r from-[#2563EB] to-[#1E40AF] text-white font-semibold shadow-md hover:from-[#1D4ED8] hover:to-[#1E3A8A] hover:shadow-xl hover:-translate-y-0.5 active:scale-95 transition-all duration-300",
                  children: "Save & Print"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1287,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  onClick: (e) => handleReconfirmation(e, false),
                  className: "px-7 py-2.5 rounded-xl bg-[#0F4C81] text-white font-semibold shadow-md hover:bg-[#0B3B63] hover:shadow-xl hover:-translate-y-0.5 active:scale-95 transition-all duration-300",
                  children: "Save Payment"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1295,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1286,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
            lineNumber: 843,
            columnNumber: 19
          }, this),
          showConfirm && /* @__PURE__ */ jsxDEV(
            ReConfirmModal,
            {
              isOpen: showConfirm,
              title: "Confirm Payment Details",
              data: sanitizedConfirmData,
              onCancel: () => setShowConfirm(false),
              onConfirm: () => handleSubmit(printAfterConfirm)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1305,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
          lineNumber: 757,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          Drawer,
          {
            closable: true,
            destroyOnHidden: true,
            title: /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-gray-900", children: "Last Three Transactions" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1318,
              columnNumber: 24
            }, this),
            placement: "right",
            open: openAntDDrawer,
            loading: showLoader,
            onClose: () => setOpenAntDDrawer(false),
            width: 400,
            children: lastThreePayments?.length <= 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center font-semibold text-gray-500 text-lg py-8", children: "No Transaction Found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1326,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
              (() => {
                const chitPayments = lastThreePayments.filter((p) => !p.pay_for || p.pay_for?.toLowerCase() !== "loan" && p.pay_for?.toLowerCase() !== "pigme").slice(-3);
                if (chitPayments.length === 0) return null;
                return /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-md font-bold text-purple-700 mb-2", children: "Last 3 Chit Transactions" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1340,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: chitPayments.map(
                    (payment, index) => /* @__PURE__ */ jsxDEV("section", { className: "bg-white rounded-lg p-4 shadow-sm border border-gray-200 border-l-4 border-l-purple-500 relative", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-1", children: /* @__PURE__ */ jsxDEV("span", { className: "bg-purple-100 text-purple-800 text-xs font-bold px-2.5 py-0.5 rounded uppercase tracking-wide", children: "Chit" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1345,
                        columnNumber: 37
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1344,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Payment Date:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1350,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment?.pay_date }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1351,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1349,
                        columnNumber: 35
                      }, this),
                      payment.group_id && /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Group:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1355,
                          columnNumber: 39
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment.group_id?.group_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1356,
                          columnNumber: 39
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1354,
                        columnNumber: 29
                      }, this),
                      payment.ticket && /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Ticket:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1361,
                          columnNumber: 39
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment?.ticket }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1362,
                          columnNumber: 39
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1360,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Amount:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1366,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: [
                          "₹",
                          payment?.amount
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1367,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1365,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Payment Type:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1370,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment?.pay_type }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1371,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1369,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Name:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1374,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment.user_id?.full_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1375,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1373,
                        columnNumber: 35
                      }, this)
                    ] }, index, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1343,
                      columnNumber: 27
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1341,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1339,
                  columnNumber: 23
                }, this);
              })(),
              (() => {
                const loanPayments = lastThreePayments.filter((p) => p.pay_for?.toLowerCase() === "loan").slice(-3);
                if (loanPayments.length === 0) return null;
                return /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-md font-bold text-blue-700 mb-2", children: "Last 3 Loan Transactions" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1392,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: loanPayments.map(
                    (payment, index) => /* @__PURE__ */ jsxDEV("section", { className: "bg-white rounded-lg p-4 shadow-sm border border-gray-200 border-l-4 border-l-blue-500 relative", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-1", children: /* @__PURE__ */ jsxDEV("span", { className: "bg-blue-100 text-blue-800 text-xs font-bold px-2.5 py-0.5 rounded uppercase tracking-wide", children: "Loan" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1397,
                        columnNumber: 37
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1396,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Payment Date:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1402,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment?.pay_date }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1403,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1401,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Amount:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1407,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: [
                          "₹",
                          payment?.amount
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1408,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1406,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Payment Type:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1411,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment?.pay_type }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1412,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1410,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Name:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1415,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment.user_id?.full_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1416,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1414,
                        columnNumber: 35
                      }, this)
                    ] }, index, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1395,
                      columnNumber: 27
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1393,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1391,
                  columnNumber: 23
                }, this);
              })(),
              (() => {
                const pigmePayments = lastThreePayments.filter((p) => p.pay_for?.toLowerCase() === "pigme").slice(-3);
                if (pigmePayments.length === 0) return null;
                return /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-md font-bold text-green-700 mb-2", children: "Last 3 Pigmy Transactions" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1433,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: pigmePayments.map(
                    (payment, index) => /* @__PURE__ */ jsxDEV("section", { className: "bg-white rounded-lg p-4 shadow-sm border border-gray-200 border-l-4 border-l-green-500 relative", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-1", children: /* @__PURE__ */ jsxDEV("span", { className: "bg-green-100 text-green-800 text-xs font-bold px-2.5 py-0.5 rounded uppercase tracking-wide", children: "Pigmy" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1438,
                        columnNumber: 37
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1437,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Payment Date:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1443,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment?.pay_date }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1444,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1442,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Amount:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1448,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: [
                          "₹",
                          payment?.amount
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1449,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1447,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Payment Type:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1452,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment?.pay_type }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1453,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1451,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[120px]", children: "Name:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1456,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: payment.user_id?.full_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                          lineNumber: 1457,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                        lineNumber: 1455,
                        columnNumber: 35
                      }, this)
                    ] }, index, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                      lineNumber: 1436,
                      columnNumber: 27
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                    lineNumber: 1434,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1432,
                  columnNumber: 23
                }, this);
              })()
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1330,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
            lineNumber: 1315,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
        lineNumber: 756,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(
        AntModal,
        {
          open: showModalView,
          onCancel: () => setShowModalView(false),
          onClose: () => setShowModalView(false),
          onOk: () => setShowModalView(false),
          onReload: () => handleViewModalOpen(currentGroupId),
          footer: /* @__PURE__ */ jsxDEV("div", {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
            lineNumber: 1479,
            columnNumber: 23
          }, this),
          loading: viewLoader,
          children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-4", children: "Payment Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1482,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-4 border border-gray-300", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Group:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1485,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.group_id?.group_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1486,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1484,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Group Value:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1489,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.group_id?.group_value }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1490,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1488,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Group Installment:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1493,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.group_id?.group_install }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1494,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1492,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "User:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1497,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: [
                  currentViewGroup?.user_id?.full_name,
                  " | Ticket: ",
                  currentViewGroup?.ticket
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1498,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1496,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Bid Amount:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1503,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount ? currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount : "" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1504,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1502,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Commission:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1511,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.commission }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1512,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1510,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Winning Amount:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1515,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.win_amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1516,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1514,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Divident:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1519,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.divident }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1520,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1518,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Divident per Head:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1523,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.divident_head }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1524,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1522,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Next Payable:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1527,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.payable }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1528,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1526,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Auction Date:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1531,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.auction_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1532,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1530,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Next Date:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1535,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.next_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1536,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1534,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Created At:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1539,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.createdAt?.split("T")[0] }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1540,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1538,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Updated At:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1543,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.updatedAt?.split("T")[0] }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1544,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1542,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Cheque Number:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1547,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.cheque_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1548,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1546,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Cheque Date:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1551,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.cheque_date?.split("T")[0] }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1552,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1550,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex mb-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Cheque Bank Name:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1555,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.cheque_bank_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1556,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1554,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600 min-w-[180px]", children: "Cheque Bank Branch Name:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1559,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-medium", children: currentViewGroup?.cheque_bank_branch }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                  lineNumber: 1560,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
                lineNumber: 1558,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
              lineNumber: 1483,
              columnNumber: 17
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
          lineNumber: 1473,
          columnNumber: 15
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
      lineNumber: 711,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
    lineNumber: 709,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
    lineNumber: 708,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx",
    lineNumber: 704,
    columnNumber: 5
  }, this);
};
_s(Payment, "MVmL3TnA9jIh63cURt/WK2JHQUI=");
_c = Payment;
export default Payment;
var _c;
$RefreshReg$(_c, "Payment");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payment.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRVLFNBa29CTixVQWxvQk07MkJBN0RWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsaUJBQWlCQyx3QkFBd0I7QUFDbEQsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxRQUFRQyxVQUFVQyxTQUFTQyxVQUFVQyxRQUFRQyxTQUFTQyxLQUFLQyxlQUFlO0FBQ25GLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxZQUFZO0FBQ3JCLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsMkJBQTJCO0FBQ3BDLE9BQU9WLFdBQVc7QUFDbEIsU0FBU1csZUFBZUMsZ0JBQWdCO0FBQ3hDLE9BQU9DLG9CQUFvQjtBQUczQixNQUFNQyxVQUFVQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEIsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUk1QixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDNkIsY0FBY0MsZUFBZSxJQUFJOUIsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQytCLGVBQWVDLGdCQUFnQixJQUFJaEMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ2lDLGdCQUFnQkMsaUJBQWlCLElBQUlsQyxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDbUMsaUJBQWlCQyxrQkFBa0IsSUFBSXBDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNxQyxlQUFlQyxnQkFBZ0IsSUFBSXRDLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUN1QyxZQUFZQyxhQUFhLElBQUl4QyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDeUMscUJBQXFCQyxzQkFBc0IsSUFBSTFDLFNBQVMsRUFBRTtBQUVqRSxRQUFNLENBQUMyQyxXQUFXQyxZQUFZLElBQUk1QyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDNkMsbUJBQW1CQyxvQkFBb0IsSUFBSTlDLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUMrQyxlQUFlQyxnQkFBZ0IsSUFBSWhELFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNpRCxrQkFBa0JDLG1CQUFtQixJQUFJbEQsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQ21ELGdCQUFnQkMsaUJBQWlCLElBQUlwRCxTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDcUQsYUFBYUMsY0FBYyxJQUFJdEQsU0FBUyxNQUFNO0FBQ3JELFFBQU11RCxTQUFRLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNuRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSTVELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM2RCxTQUFTQyxVQUFVLElBQUk5RCxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDK0QsWUFBWUMsYUFBYSxJQUFJaEUsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2lFLFdBQVdDLFlBQVksSUFBSWxFLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNtRSxnQkFBZ0JDLGlCQUFpQixJQUFJcEUsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3FFLHFCQUFxQkMsc0JBQXNCLElBQUl0RSxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDdUUsb0JBQW9CQyxxQkFBcUIsSUFBSXhFLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUN5RSxnQkFBZ0JDLGlCQUFpQixJQUFJMUUsU0FBUyxJQUFJO0FBQ3pELFFBQU0sQ0FBQzJFLGdCQUFnQkMsaUJBQWlCLElBQUk1RSxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDNkUsWUFBWUMsYUFBYSxJQUFJOUUsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQytFLG1CQUFtQkMsb0JBQW9CLElBQUloRixTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDaUYsa0JBQWtCQyxtQkFBbUIsSUFBSWxGLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUNtRixhQUFhQyxjQUFjLElBQUlwRixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDcUYsa0JBQWtCQyxtQkFBbUIsSUFBSXRGLFNBQVM7QUFBQSxJQUN2RHVGLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCxRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSXpGLFNBQVMsS0FBSztBQUN0QyxRQUFNLENBQUMwRixtQkFBbUJDLG9CQUFvQixJQUFJM0YsU0FBUyxLQUFLO0FBRWhFLFFBQU00RixnQkFBZ0JBLENBQUNDLGtCQUFrQjtBQUN2QyxVQUFNQyxtQkFBbUI7QUFBQSxNQUN2QjtBQUFBLFFBQ0VDLEtBQUs7QUFBQSxRQUNMQyxPQUNFLHVCQUFDLFFBQUssSUFBSSxVQUFVSCxlQUFlSSxHQUFHLElBQUksV0FBVSxvQkFBbUIscUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRUo7QUFBQSxNQUVBO0FBQUEsUUFDRUYsS0FBSztBQUFBLFFBQ0xDLE9BQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTUUsb0JBQW9CTCxlQUFlSSxHQUFHO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxNQUVKO0FBQUEsSUFBQztBQUdILFdBQU9IO0FBQUFBLEVBQ1Q7QUFDQSxRQUFNSyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCdEMsa0JBQWNxQyxLQUFLO0FBQUEsRUFDckI7QUFDQSxRQUFNLENBQUNFLGFBQWFDLGNBQWMsSUFBSXhHLFNBQVM7QUFBQSxJQUM3Q3lHLFlBQVk7QUFBQSxJQUNaekYsU0FBUztBQUFBLElBQ1QwRixVQUFVO0FBQUEsSUFDVkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJN0csU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDOEcsVUFBVUMsV0FBVyxJQUFJL0csU0FBUztBQUFBLElBQ3ZDZ0gsU0FBUztBQUFBLElBQ1RDLFNBQVM7QUFBQSxJQUNUQyxZQUFZO0FBQUEsSUFDWkMsVUFBVTVEO0FBQUFBLElBQ1Y2RCxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLGdCQUFnQjtBQUFBLElBQ2hCQyx1QkFBdUI7QUFBQSxJQUN2QkMsY0FBYztBQUFBLElBQ2RDLGVBQWU7QUFBQSxJQUNmQyxhQUFhO0FBQUEsSUFDYkMsa0JBQWtCO0FBQUEsSUFDbEJDLG9CQUFvQjtBQUFBLElBQ3BCQyxpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSS9ILFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNnSSx5QkFBeUJDLDBCQUEwQixJQUFJakksU0FBUyxLQUFLO0FBQzVFLFFBQU1rSSxZQUFZLElBQUkxRSxNQUFLLG9CQUFJQSxLQUFLLEdBQUUyRSxTQUFRLG9CQUFJM0UsS0FBSyxHQUFFNEUsUUFBUSxJQUFJLENBQUMsQ0FBQyxFQUNwRTNFLFlBQVksRUFDWkMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUVmM0QsWUFBVSxNQUFNO0FBQ2QsVUFBTXNJLE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBRS9CLFFBQUlHLFNBQVM7QUFDWCxZQUFNRyx5QkFDSkgsUUFBUUksdUJBQXVCQztBQUVqQyxVQUFJRix3QkFBd0JHLGlCQUFpQixRQUFRO0FBQ25EZix5QkFBaUIsSUFBSTtBQUFBLE1BQ3ZCO0FBRUEsVUFBSVksd0JBQXdCSSx5QkFBeUIsUUFBUTtBQUMzRGhCLHlCQUFpQixJQUFJO0FBQ3JCRSxtQ0FBMkIsSUFBSTtBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTWUsNkJBQTZCLE9BQU9DLFVBQVU7QUFDbERBLFVBQU1DLGVBQWU7QUFDckJ0RSxzQkFBa0IsSUFBSTtBQUN0QixRQUFJa0MsU0FBU0csV0FBV0gsU0FBU1MsdUJBQXVCO0FBQ3RELFVBQUk7QUFDRnpDLHNCQUFjLElBQUk7QUFDbEIsY0FBTXFFLFdBQVcsTUFBTWpKLElBQUlrSixJQUFJLGtDQUFrQztBQUFBLFVBQy9EQyxRQUFRO0FBQUEsWUFDTnBDLFNBQVNILFNBQVNHO0FBQUFBLFlBQ2xCTSx1QkFBdUJsRDtBQUFBQSxZQUN2QmlGLE9BQU87QUFBQSxVQUNUO0FBQUEsUUFDRixDQUFDO0FBQ0QsWUFBSUgsVUFBVUksTUFBTTtBQUNsQnZFLCtCQUFxQm1FLFNBQVNJLElBQUk7QUFBQSxRQUNwQyxPQUFPO0FBQ0x2RSwrQkFBcUIsRUFBRTtBQUFBLFFBQ3pCO0FBQUEsTUFDRixTQUFTd0UsT0FBTztBQUNkeEUsNkJBQXFCLEVBQUU7QUFBQSxNQUN6QixVQUFDO0FBQ0NGLHNCQUFjLEtBQUs7QUFBQSxNQUNyQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEvRSxZQUFVLE1BQU07QUFDZG1FLGlCQUFhLEVBQUU7QUFDZixVQUFNdUYsMkJBQTJCLFlBQVk7QUFDM0MsVUFBSSxDQUFDeEgsZUFBZ0I7QUFDckIsVUFBSTtBQUNGLGNBQU1rSCxXQUFXLE1BQU1qSixJQUFJa0osSUFBSSx3Q0FBd0NuSCxjQUFjLEVBQUU7QUFDdkYsWUFBSWtILFNBQVNJLE1BQU1BLE1BQU07QUFDdkJyRix1QkFBYWlGLFNBQVNJLEtBQUtBLElBQUk7QUFBQSxRQUNqQyxPQUFPO0FBQ0xyRix1QkFBYSxFQUFFO0FBQUEsUUFDakI7QUFBQSxNQUNGLFNBQVN3RixLQUFLO0FBQ1p4RixxQkFBYSxFQUFFO0FBQ2Z5RixnQkFBUUMsSUFBSSxnQ0FBZ0NGLEdBQUc7QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFDQUQsNkJBQXlCO0FBQUEsRUFDM0IsR0FBRyxDQUFDeEgsY0FBYyxDQUFDO0FBRW5CbEMsWUFBVSxNQUFNO0FBQ2RxRSxzQkFBa0IsRUFBRTtBQUNwQixVQUFNeUYsNEJBQTRCLFlBQVk7QUFDNUMsVUFBSSxDQUFDNUgsZUFBZ0I7QUFDckIsVUFBSTtBQUNGLGNBQU1rSCxXQUFXLE1BQU1qSixJQUFJa0osSUFBSSwrQ0FBK0NuSCxjQUFjLEVBQUU7QUFDOUYsWUFBSWtILFNBQVNJLE1BQU1BLE1BQU07QUFDdkJuRiw0QkFBa0IrRSxTQUFTSSxLQUFLQSxJQUFJO0FBQUEsUUFDdEMsT0FBTztBQUNMbkYsNEJBQWtCLEVBQUU7QUFBQSxRQUN0QjtBQUFBLE1BQ0YsU0FBU3NGLEtBQUs7QUFDWnRGLDBCQUFrQixFQUFFO0FBQ3BCdUYsZ0JBQVFDLElBQUksaUNBQWlDRixHQUFHO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBQ0FHLDhCQUEwQjtBQUFBLEVBQzVCLEdBQUcsQ0FBQzVILGNBQWMsQ0FBQztBQUVuQmxDLFlBQVUsTUFBTTtBQUNkLFVBQU0rSixvQkFBb0IsWUFBWTtBQUNwQyxVQUFJO0FBQ0YsY0FBTVgsV0FBVyxNQUFNakosSUFBSWtKLElBQUksZUFBZTtBQUM5Q3hILGlCQUFTdUgsVUFBVUksTUFBTUEsSUFBSTtBQUFBLE1BQy9CLFNBQVNDLE9BQU87QUFDZDVILGlCQUFTLEVBQUU7QUFDWCtILGdCQUFRSCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBTSxzQkFBa0I7QUFBQSxFQUNwQixHQUFHLEVBQUU7QUFFTC9KLFlBQVUsTUFBTTtBQUNkLFVBQU1nSyxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU1aLFdBQVcsTUFBTWpKLElBQUlrSixJQUFJLHdCQUF3QjtBQUN2RHRILHdCQUFnQnFILFNBQVNJLElBQUk7QUFBQSxNQUMvQixTQUFTQyxPQUFPO0FBQ2QxSCx3QkFBZ0IsRUFBRTtBQUNsQjZILGdCQUFRSCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBTyxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUwsUUFBTUMsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxZQUFZLENBQUM7QUFFbkIsUUFBSSxDQUFDaEksZ0JBQWdCO0FBQ25CZ0ksZ0JBQVVDLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFFBQUksQ0FBQ3BELFNBQVNTLHVCQUF1QjtBQUNuQzBDLGdCQUFVMUMsd0JBQXdCO0FBQUEsSUFDcEM7QUFFQSxRQUFJLENBQUNULFNBQVNLLFVBQVU7QUFDdEI4QyxnQkFBVTlDLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFVBQU1DLFNBQVMrQyxXQUFXckQsU0FBU00sTUFBTTtBQUN6QyxRQUFJZ0QsTUFBTWhELE1BQU0sS0FBS0EsVUFBVSxHQUFHO0FBQ2hDNkMsZ0JBQVU3QyxTQUFTO0FBQUEsSUFDckI7QUFFQSxRQUFJL0QsZ0JBQWdCLFlBQVksQ0FBQ3lELFNBQVNRLGdCQUFnQitDLEtBQUssR0FBRztBQUNoRUosZ0JBQVUzQyxpQkFDUjtBQUFBLElBQ0o7QUFFQSxRQUFJakUsZ0JBQWdCLFlBQVksQ0FBQ3lELFNBQVNZLGFBQWEyQyxLQUFLLEdBQUc7QUFDN0RKLGdCQUFVdkMsY0FBYztBQUFBLElBQzFCO0FBQ0EsUUFBSXJFLGdCQUFnQixZQUFZLENBQUN5RCxTQUFTVyxlQUFlNEMsS0FBSyxHQUFHO0FBQy9ESixnQkFBVXhDLGdCQUFnQjtBQUFBLElBQzVCO0FBRUFaLGNBQVVvRCxTQUFTO0FBQ25CLFdBQU9LLE9BQU9DLEtBQUtOLFNBQVMsRUFBRU8sV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTUMsZUFBZUEsQ0FBQ3JFLE1BQU07QUFDMUIsVUFBTSxFQUFFc0UsTUFBTXJFLE1BQU0sSUFBSUQsRUFBRUU7QUFFMUIsUUFBSW9FLFNBQVMsVUFBVTtBQUVyQixVQUFJQyxVQUFVdEUsTUFBTXVFLFFBQVEsWUFBWSxFQUFFO0FBRTFDLFlBQU1DLFlBQVlGLFFBQVFHLE1BQU0sS0FBSyxLQUFLLElBQUlOO0FBQzlDLFVBQUlLLFdBQVcsRUFBRztBQUVsQjlELGtCQUFZLENBQUNnRSxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSCxDQUFDTCxJQUFJLEdBQUdDO0FBQUFBLE1BQ1YsRUFBRTtBQUVGO0FBQUEsSUFDRjtBQUdBNUQsZ0JBQVksQ0FBQ2dFLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNILENBQUNMLElBQUksR0FBR3JFO0FBQUFBLElBQ1YsRUFBRTtBQUFBLEVBQ0o7QUFHQSxRQUFNMkUseUJBQXlCQSxDQUFDQyxXQUFXO0FBQ3pDM0csMkJBQXVCMkcsTUFBTTtBQUFBLEVBQy9CO0FBS0EsUUFBTUMscUJBQXFCQSxDQUFDN0UsVUFBVTtBQUNwQyxRQUFJLENBQUNBLE1BQU8sUUFBTztBQUVuQkEsWUFBUUEsTUFBTThFLFNBQVMsRUFBRVAsUUFBUSxZQUFZLEVBQUU7QUFFL0MsVUFBTVEsUUFBUS9FLE1BQU0zQyxNQUFNLEdBQUc7QUFDN0IsVUFBTTJILGNBQWNELE1BQU0sQ0FBQztBQUMzQixVQUFNRSxjQUFjRixNQUFNLENBQUMsSUFBSUEsTUFBTSxDQUFDLEVBQUVHLE1BQU0sR0FBRyxDQUFDLElBQUk7QUFFdEQsUUFBSUMsWUFBWUgsWUFBWUUsTUFBTSxFQUFFO0FBQ3BDLFFBQUlFLGVBQWVKLFlBQVlFLE1BQU0sR0FBRyxFQUFFO0FBRTFDLFFBQUlHLGVBQWVELGVBQ2ZBLGFBQWFiLFFBQVEseUJBQXlCLEdBQUcsSUFBSSxNQUFNWSxZQUMzREE7QUFFSixXQUFPRixjQUFjLEdBQUdJLFlBQVksSUFBSUosV0FBVyxLQUFLSTtBQUFBQSxFQUMxRDtBQUVBLFFBQU1DLFVBQVU7QUFBQSxJQUNkLEVBQUU1RixLQUFLLE1BQU02RixRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFN0YsS0FBSyxRQUFRNkYsUUFBUSxZQUFZO0FBQUEsSUFDbkMsRUFBRTdGLEtBQUssb0JBQW9CNkYsUUFBUSxtQkFBbUI7QUFBQSxJQUN0RCxFQUFFN0YsS0FBSyxRQUFRNkYsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFN0YsS0FBSyxnQkFBZ0I2RixRQUFRLHdCQUF3QjtBQUFBLElBQ3ZELEVBQUU3RixLQUFLLGNBQWM2RixRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFN0YsS0FBSyxVQUFVNkYsUUFBUSxnQkFBZ0I7QUFBQSxJQUN6QyxFQUFFN0YsS0FBSyxlQUFlNkYsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRTdGLEtBQUssV0FBVzZGLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUU3RixLQUFLLFVBQVU2RixRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFN0YsS0FBSyxZQUFZNkYsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRTdGLEtBQUssbUJBQW1CNkYsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFN0YsS0FBSyxnQkFBZ0I2RixRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFN0YsS0FBSyxVQUFVNkYsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyxpQkFBaUIsT0FBT0MsV0FBVztBQUN2Q3hKLHFCQUFpQixFQUFFO0FBQ25CSSwyQkFBdUIsRUFBRTtBQUN6QlIsc0JBQWtCNEosTUFBTTtBQUN4Qi9FLGdCQUFZLENBQUNnRixrQkFBa0I7QUFBQSxNQUM3QixHQUFHQTtBQUFBQSxNQUNIOUUsU0FBUzZFO0FBQUFBLElBQ1gsRUFBRTtBQUNGakYsY0FBVSxDQUFDbUYsY0FBYyxFQUFFLEdBQUdBLFVBQVU5QixVQUFVLEdBQUcsRUFBRTtBQUN2RDVGLDJCQUF1QixFQUFFO0FBQ3pCMkgsNkJBQXlCSCxNQUFNO0FBQUEsRUFDakM7QUFFQSxRQUFNSSxxQkFBcUIsT0FBT0MsWUFBWTtBQUM1QyxRQUFJQSxTQUFTO0FBQ1gsVUFBSUMsTUFBTSw0Q0FBNEM3SSxLQUFLLFlBQVlBLEtBQUs7QUFDNUUsVUFBSTtBQUNGSyxxQkFBYSxJQUFJO0FBQ2pCLGNBQU11RixXQUFXLE1BQU1qSixJQUFJa0osSUFBSWdELEdBQUc7QUFFbEMsWUFBSWpELFNBQVNJLFFBQVFKLFNBQVNJLEtBQUtpQixTQUFTLEdBQUc7QUFDN0MsZ0JBQU02QixnQkFBZ0JsRCxTQUFTSSxLQUFLK0MsSUFBSSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3hELGdCQUFJLENBQUNELE9BQU9FLFVBQVVDLFdBQVksUUFBTyxDQUFDO0FBQzFDLG1CQUFPO0FBQUEsY0FDTHpHLEtBQUtzRyxNQUFNdEc7QUFBQUEsY0FDWDBHLElBQUlILFFBQVE7QUFBQSxjQUNaOUIsTUFBTTZCLE9BQU90RixTQUFTMkY7QUFBQUEsY0FDdEJDLGNBQWNOLE9BQU90RixTQUFTNEY7QUFBQUEsY0FDOUJILFlBQVlILE9BQU9FLFVBQVVDO0FBQUFBLGNBQzdCSSxRQUFRUCxNQUFNTztBQUFBQSxjQUNkQyxTQUFTUixNQUFNckY7QUFBQUEsY0FDZjhGLGFBQWFULE1BQU1VO0FBQUFBLGNBQ25CN0YsUUFBUW1GLE1BQU1uRjtBQUFBQSxjQUNkQyxVQUFVa0YsT0FBT2xGO0FBQUFBLGNBQ2pCNkYsTUFBTVgsT0FBT3BGLFNBQVN6RCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsY0FDbEN5SixrQkFBa0JaLE9BQU9hLFdBQVcxSixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsY0FDaEQySixjQUNFZCxPQUFPYyxjQUFjM0MsUUFDckI2QixPQUFPZSxZQUFZQyxjQUNuQjtBQUFBLGNBQ0ZDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsa0JBQ2pCLE1BQU07QUFBQSxvQkFDSkMsT0FBTzdILGNBQWMyRyxLQUFLO0FBQUEsa0JBQzVCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLFlBRUo7QUFBQSxVQUNGLENBQUM7QUFDRHJILDhCQUFvQixJQUFJO0FBQ3hCbEQsMkJBQWlCcUssYUFBYTtBQUFBLFFBQ2hDO0FBQUEsTUFDRixTQUFTN0MsT0FBTztBQUNkeEgseUJBQWlCLEVBQUU7QUFDbkIySCxnQkFBUUgsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFBQSxNQUNyRCxVQUFDO0FBQ0M1RixxQkFBYSxLQUFLO0FBQUEsTUFFcEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU04SiwwQkFBMEJBLENBQUN0SCxNQUFNO0FBQ3JDLFVBQU11SCxlQUFldkgsRUFBRUUsT0FBT0Q7QUFDOUIvQyxtQkFBZXFLLFlBQVk7QUFDM0I1RyxnQkFBWSxDQUFDaUYsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gzRSxVQUFVc0c7QUFBQUEsTUFFVnJHLGdCQUNFcUcsaUJBQWlCLFlBQVlBLGlCQUFpQixlQUMxQzNCLFNBQVMxRSxpQkFDVDtBQUFBLElBQ1IsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNc0csMEJBQTBCQSxDQUFDeEgsTUFBTTtBQUNyQyxVQUFNdUgsZUFBZXZILEVBQUVFLE9BQU9EO0FBQzlCVSxnQkFBWSxDQUFDaUYsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0h4RSxjQUFjbUc7QUFBQUEsSUFDaEIsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNRSxZQUFZQSxNQUFNO0FBQ3RCM0wsc0JBQWtCLEVBQUU7QUFDcEJvQywyQkFBdUIsRUFBRTtBQUN6QmhCLG1CQUFlLE1BQU07QUFHckJ5RCxnQkFBWTtBQUFBLE1BQ1ZDLFNBQVM7QUFBQSxNQUNUQyxTQUFTO0FBQUEsTUFDVEMsWUFBWTtBQUFBLE1BQ1pDLFVBQVU1RDtBQUFBQSxNQUNWNkQsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxNQUNWQyxnQkFBZ0I7QUFBQSxNQUNoQkMsdUJBQXVCO0FBQUEsTUFDdkJDLGNBQWM7QUFBQSxNQUNkQyxlQUFlO0FBQUEsTUFDZkMsYUFBYTtBQUFBLE1BQ2JDLGtCQUFrQjtBQUFBLE1BQ2xCQyxvQkFBb0I7QUFBQSxNQUNwQkMsaUJBQWlCO0FBQUEsSUFDbkIsQ0FBQztBQUdEaEIsY0FBVSxDQUFDLENBQUM7QUFBQSxFQUNkO0FBRUEsUUFBTWlILGVBQWUsT0FBT0MsY0FBYztBQUN4QyxRQUFJO0FBQ0Z2Siw0QkFBc0IsSUFBSTtBQUMxQnNDLGVBQVNTLHdCQUF3QmxEO0FBQ2pDeUMsZUFBU3dHLGFBQWE3RSxLQUFLQyxNQUFNSixhQUFhQyxRQUFRLE1BQU0sQ0FBQyxHQUFHdEM7QUFFaEUsWUFBTStILFVBQVU7QUFBQSxRQUNkLEdBQUdsSDtBQUFBQSxRQUNIdkIsVUFBVUYsaUJBQWlCRTtBQUFBQSxNQUM3QjtBQUVBLFlBQU00RCxXQUFXLE1BQU1qSixJQUFJK04sS0FBSyx5QkFBeUJELE9BQU87QUFHaEUsVUFBSUQsV0FBVztBQUNiLGNBQU1HLGFBQWEvRSxTQUFTSSxLQUFLQSxLQUFLK0MsSUFBSSxDQUFBNkIsU0FBUUEsS0FBS2xJLEdBQUc7QUFDMUQsWUFBSWlJLFdBQVcxRCxTQUFTLEdBQUc7QUFDekI0RCxpQkFBTzVJLEtBQUssVUFBVTBJLFdBQVcsQ0FBQyxDQUFDLElBQUksUUFBUTtBQUFBLFFBQ2pEO0FBQUEsTUFDRjtBQUdBTCxnQkFBVTtBQUVWckgscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsVUFBVTtBQUFBLFFBQ1YxRixTQUFTO0FBQUEsUUFDVDJGLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUVILFNBQVM2QyxPQUFPO0FBQ2RoRCxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxVQUFVO0FBQUEsUUFDVjFGLFNBQVMsNkJBQTZCd0ksTUFBTXhJLE9BQU87QUFBQSxRQUNuRDJGLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ25DLDRCQUFzQixLQUFLO0FBQzNCWSxxQkFBZSxLQUFLO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBRUEsUUFBTWMsc0JBQXNCLE9BQU9tSSxjQUFjO0FBQy9DLFFBQUk7QUFDRnZLLGlCQUFXLElBQUk7QUFDZmQsdUJBQWlCLElBQUk7QUFDckIwQix3QkFBa0IySixTQUFTO0FBQzNCN0wsb0JBQWMsSUFBSTtBQUNsQixZQUFNMkcsV0FBVyxNQUFNakosSUFBSWtKLElBQUksOEJBQThCaUYsU0FBUyxFQUFFO0FBQ3hFbkwsMEJBQW9CaUcsU0FBU0ksSUFBSTtBQUFBLElBQ25DLFNBQVNDLE9BQU87QUFDZEcsY0FBUUgsTUFBTSwwQkFBMEJBLEtBQUs7QUFBQSxJQUMvQyxVQUFDO0FBQ0MxRixpQkFBVyxLQUFLO0FBQ2hCdEIsb0JBQWMsS0FBSztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU15SiwyQkFBMkIsT0FBT0gsV0FBVztBQUNqRCxRQUFJLENBQUNBLE9BQVE7QUFFYixRQUFJO0FBQ0YsWUFBTTNDLFdBQVcsTUFBTWpKLElBQUlrSixJQUFJLDJCQUEyQjBDLE1BQU0sRUFBRTtBQUVsRSxVQUFJM0MsU0FBU0ksTUFBTUEsTUFBTWlCLFNBQVMsR0FBRztBQUNuQyxjQUFNOEQsY0FBY25GLFNBQVNJLEtBQUtBLEtBQUsrQyxJQUFJLENBQUM2QixVQUFVO0FBQUEsVUFDcERJLFlBQVk7QUFBQSxZQUNWaEMsT0FBTzRCLEtBQUsxQjtBQUFBQSxZQUNaK0IsU0FBU0wsS0FBS0s7QUFBQUEsVUFDaEI7QUFBQSxVQUNBQyxVQUFVO0FBQUEsWUFDUkMsaUJBQWlCUCxLQUFLUTtBQUFBQSxVQUN4QjtBQUFBLFVBQ0FDLFNBQVM7QUFBQSxZQUNQQyxjQUFjVixLQUFLVztBQUFBQSxVQUNyQjtBQUFBLFVBQ0FDLFFBQVE7QUFBQSxZQUNOQyxhQUFhYixLQUFLYztBQUFBQSxVQUNwQjtBQUFBLFVBQ0FDLFNBQVM7QUFBQSxZQUNQQyxjQUFjaEIsS0FBS2lCO0FBQUFBLFVBQ3JCO0FBQUEsVUFDQUMsY0FBYztBQUFBLFlBQ1pDLG1CQUFtQm5CLEtBQUtvQjtBQUFBQSxVQUMxQjtBQUFBO0FBQUEsVUFHQUMsZUFBZXJCLEtBQUtxQjtBQUFBQSxVQUNwQkMsZUFBZXRCLEtBQUtzQjtBQUFBQSxVQUNwQkMsZ0JBQWdCdkIsS0FBS3VCO0FBQUFBLFVBQ3JCQyxlQUFleEIsS0FBS3dCO0FBQUFBLFFBQ3RCLEVBQUU7QUFFRmpOLCtCQUF1QjRMLFdBQVc7QUFBQSxNQUNwQyxPQUFPO0FBQ0w1TCwrQkFBdUIsRUFBRTtBQUFBLE1BQzNCO0FBQUEsSUFDRixTQUFTOEcsT0FBTztBQUNkRyxjQUFRSCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RDlHLDZCQUF1QixFQUFFO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsUUFBTWtOLG1CQUFtQmpPLE1BQU1rTztBQUFBQSxJQUM3QixDQUFDeEgsU0FBU0EsS0FBS3BDLFFBQVFhLFNBQVNHLFdBQVdvQixLQUFLcEMsUUFBUWhFO0FBQUFBLEVBQzFEO0FBRUEsUUFBTTZOLHVCQUF1QnpMLG9CQUFvQmlJLElBQUksQ0FBQzZCLFNBQVM7QUFDN0QsVUFBTUksYUFBYTlMLG9CQUFvQm9OLEtBQUssQ0FBQ0UsVUFBVTtBQUNyRCxZQUFNNUQsVUFBVTRELE9BQU94QixZQUFZaEMsT0FBT3RHO0FBQzFDLFlBQU02RyxTQUFTaUQsT0FBT3hCLFlBQVlDO0FBQ2xDLGFBQU8sUUFBUXJDLE9BQU8sSUFBSVcsTUFBTSxPQUFPcUI7QUFBQUEsSUFDekMsQ0FBQztBQUVELFFBQUlJLFlBQVk7QUFDZCxhQUFPLEdBQUdBLFlBQVlBLFlBQVloQyxPQUFPRyxVQUFVLE1BQU02QixZQUFZQSxZQUFZQyxPQUFPO0FBQUEsSUFDMUY7QUFFQSxVQUFNd0IsUUFBUTdMLGdCQUFnQjBMO0FBQUFBLE1BQzVCLENBQUNJLE1BQU0sU0FBU0EsRUFBRWhLLEdBQUcsT0FBT2tJO0FBQUFBLElBQzlCO0FBRUEsUUFBSTZCLE9BQU87QUFDVCxhQUFPLEdBQUdBLE1BQU1FLFFBQVEsUUFBUUYsTUFBTUcsY0FBYztBQUFBLElBQ3REO0FBRUEsVUFBTUMsV0FBV25NLFdBQVc0TDtBQUFBQSxNQUMxQixDQUFDUSxNQUFNLFFBQVFBLEVBQUVwSyxHQUFHLE9BQU9rSTtBQUFBQSxJQUM3QjtBQUVBLFFBQUlpQyxVQUFVO0FBQ1osYUFBTyxHQUFHQSxTQUFTRSxPQUFPLFFBQVFGLFNBQVNHLFdBQVc7QUFBQSxJQUN4RDtBQUVBLFdBQU9wQztBQUFBQSxFQUNULENBQUM7QUFHRCxRQUFNcUMsY0FBYztBQUFBLElBQ2xCQyxlQUFlYixrQkFBa0JoRCxhQUFhO0FBQUEsSUFDOUM4RCxlQUFlWixxQkFBcUJhLEtBQUssSUFBSTtBQUFBLElBQzdDLEdBQUc3SjtBQUFBQSxFQUNMO0FBRUEsUUFBTThKLHVCQUF1QnRHLE9BQU91RztBQUFBQSxJQUNsQ3ZHLE9BQU93RyxRQUFRTixXQUFXLEVBQUVPLE9BQU8sQ0FBQyxDQUFDaEwsS0FBS00sS0FBSyxNQUFNO0FBQ25ELGFBQ0VOLFFBQVE7QUFBQSxNQUNSTSxVQUFVLFFBQ1ZBLFVBQVUySyxVQUNWM0ssVUFBVSxNQUNWLEVBQUU0SyxNQUFNQyxRQUFRN0ssS0FBSyxLQUFLQSxNQUFNbUUsV0FBVztBQUFBLElBRS9DLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTTJHLHVCQUF1QkEsQ0FBQy9LLEdBQUcySCxjQUFjO0FBQzdDM0gsTUFBRThDLGVBQWU7QUFDakIsVUFBTWtJLFVBQVVwSCxhQUFhLFVBQVU7QUFDdkMsUUFBSSxDQUFDb0gsU0FBUztBQUVaekgsY0FBUTBILEtBQUsscUNBQXFDO0FBQ2xEO0FBQUEsSUFDRjtBQUNBMUwseUJBQXFCb0ksU0FBUztBQUM5QjNJLG1CQUFlLElBQUk7QUFBQSxFQUNyQjtBQUdBLFFBQU1rTSxtQkFBbUJBLENBQUNuRCxTQUFTO0FBRWpDLFFBQUlBLEtBQUtvRCxXQUFXLE9BQU8sR0FBRztBQUM1QixZQUFNaEQsYUFBYTlMLG9CQUFvQm9OLEtBQUssQ0FBQ0UsVUFBVTtBQUNyRCxjQUFNNUQsVUFBVTRELE9BQU94QixZQUFZaEMsT0FBT3RHO0FBQzFDLGNBQU02RyxTQUFTaUQsT0FBT3hCLFlBQVlDO0FBQ2xDLGVBQU8sUUFBUXJDLE9BQU8sSUFBSVcsTUFBTSxPQUFPcUI7QUFBQUEsTUFDekMsQ0FBQztBQUVELFVBQUlJLFlBQVk7QUFDZCxlQUFPO0FBQUEsVUFDTDVILE1BQU07QUFBQSxVQUNOK0QsTUFBTTZELFdBQVdBLFlBQVloQyxPQUFPRyxjQUFjO0FBQUEsVUFDbERJLFFBQVF5QixXQUFXQSxZQUFZQyxXQUFXO0FBQUEsVUFDMUNJLFNBQVNMLFdBQVdLLFNBQVNDLGdCQUFnQjtBQUFBLFVBQzdDRSxRQUFRUixXQUFXUSxRQUFRQyxlQUFlO0FBQUEsVUFDMUN3QyxXQUFXakQsV0FBV0UsVUFBVUMsbUJBQW1CO0FBQUEsVUFDbkQrQyxhQUFhbEQsV0FBV0EsWUFBWWhDLE9BQU9rRixlQUFlO0FBQUEsVUFDMURqQyxlQUFlakIsV0FBV0EsWUFBWWhDLE9BQU9pRCxpQkFBaUI7QUFBQSxVQUM5REwsY0FBY1osV0FBV1csU0FBU0MsZ0JBQWdCO0FBQUEsVUFDbER1QyxjQUFjbkQsV0FBV2MsY0FBY0MscUJBQXFCO0FBQUE7QUFBQSxVQUc1RHFDLGNBQWM7QUFBQSxVQUNkQyxjQUFjO0FBQUEsVUFDZEMsVUFDR3RELFdBQVdLLFNBQVNDLGdCQUFnQixNQUNwQ04sV0FBV0UsVUFBVUMsbUJBQW1CO0FBQUEsUUFDN0M7QUFBQSxNQUNGO0FBQUEsSUFDRixXQUVTUCxLQUFLb0QsV0FBVyxRQUFRLEdBQUc7QUFDbEMsWUFBTXZCLFFBQVE3TCxnQkFBZ0IwTCxLQUFLLENBQUNJLE1BQU0sU0FBU0EsRUFBRWhLLEdBQUcsT0FBT2tJLElBQUk7QUFDbkUsVUFBSTZCLE9BQU87QUFFVCxjQUFNOEIsa0JBQWtCOUIsTUFBTThCO0FBQzlCLGNBQU0zQixpQkFBaUI0QixPQUFPL0IsTUFBTUcsa0JBQWtCLENBQUM7QUFDdkQsY0FBTTZCLGFBQWFoQyxNQUFNZ0M7QUFDekIsY0FBTUMsV0FBV0YsT0FBTy9CLE1BQU1pQyxZQUFZLENBQUM7QUFDM0MsY0FBTUMsb0JBQW9CSCxPQUFPL0IsTUFBTWtDLHFCQUFxQixDQUFDO0FBQzdELGVBQU87QUFBQSxVQUNMdkwsTUFBTTtBQUFBLFVBQ04rRCxNQUFNc0YsTUFBTUU7QUFBQUEsVUFDWnBELFFBQVE7QUFBQSxVQUNScUYsZ0JBQWdCTDtBQUFBQSxVQUNoQk0sZUFBZWpDO0FBQUFBLFVBQ2ZrQyxXQUFXTDtBQUFBQSxVQUNYQztBQUFBQSxVQUNBVCxXQUFXVTtBQUFBQSxVQUNYbkQsUUFBUTtBQUFBLFVBQ1JJLGNBQWM7QUFBQSxRQUNoQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLFdBRVNoQixLQUFLb0QsV0FBVyxPQUFPLEdBQUc7QUFDakMsWUFBTW5CLFdBQVduTSxXQUFXNEwsS0FBSyxDQUFDUSxNQUFNLFFBQVFBLEVBQUVwSyxHQUFHLE9BQU9rSSxJQUFJO0FBQ2hFLFVBQUlpQyxVQUFVO0FBR1osY0FBTWtDLGVBQWVsQyxTQUFTbUMsd0JBQXdCO0FBQ3RELGNBQU1DLGFBQWFwQyxVQUFVRyxlQUFlO0FBQzVDLGNBQU1pQixZQUFZcEIsVUFBVXFDLGtCQUFrQjtBQUM5QyxjQUFNSixZQUFZakMsVUFBVTRCO0FBQzVCLGNBQU1VLFVBQVV0QyxVQUFVdUM7QUFDMUIsY0FBTWQsVUFBVXpCLFVBQVV3QyxrQkFBa0I7QUFDNUMsY0FBTUMsWUFBWXpDLFNBQVNHLGVBQWU7QUFDMUMsZUFBTztBQUFBLFVBQ0w1SixNQUFNO0FBQUEsVUFDTitELE1BQU0wRixTQUFTRTtBQUFBQSxVQUNmeEQsUUFBUTtBQUFBLFVBQ1IwRjtBQUFBQSxVQUNBRjtBQUFBQSxVQUNBRDtBQUFBQSxVQUNBSztBQUFBQSxVQUNBbEI7QUFBQUEsVUFDQUs7QUFBQUEsVUFDQTlDLFFBQVE7QUFBQSxVQUNSSSxjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FDRSxtQ0FDRzVLLCtCQUNDLHVCQUFDLHNCQUFtQixPQUFPLGlDQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlELElBRXpELHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFDUix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTWdDLFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVl2RjtBQUFBQSxVQUNyQixVQUFVdUYsWUFBWUc7QUFBQUE7QUFBQUEsUUFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWlDO0FBQUEsTUFHakM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVd6QjtBQUFBQSxVQUNYLFNBQVMsTUFBTUMsb0JBQW9CLEtBQUs7QUFBQSxVQUV4QyxpQ0FBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSx3Q0FBdUMscUNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsWUFDekVuRCxpQkFBaUJBLGNBQWN5SSxTQUFTLElBQ3ZDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTXpJLGNBQWNnUDtBQUFBQSxrQkFBTyxDQUFDNUMsU0FDMUI3RCxPQUFPVyxPQUFPa0QsSUFBSSxFQUFFMkU7QUFBQUEsb0JBQUssQ0FBQ3pNLFVBQ3hCME0sT0FBTzFNLEtBQUssRUFDVDJNLFlBQVksRUFDWkMsU0FBU2xQLFdBQVdpUCxZQUFZLENBQUM7QUFBQSxrQkFDdEM7QUFBQSxnQkFDRjtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0EsaUJBQWdCO0FBQUEsZ0JBQ2hCLGlCQUFpQixDQUFDLFlBQVk7QUFBQSxnQkFDOUIsbUJBQW1CLENBQUMsU0FBUztBQUFBLGdCQUM3QixrQkFBa0I7QUFBQTtBQUFBLGNBWnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVltQyxJQUduQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLE1BQUs7QUFBQSxnQkFDTCxTQUFTalIsY0FBY3lJLFVBQVU7QUFBQTtBQUFBLGNBSG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUdxQyxLQUp2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQTtBQUFBLFFBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQStCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNkRBQTRELCtCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTeEI7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEsa0JBQzlCLHVCQUFDLFVBQUssbUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUI7QUFBQTtBQUFBO0FBQUEsY0FOM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFa0ssU0FBUyxRQUFRQyxnQkFBZ0IsWUFBWUMsY0FBYyxTQUFTLEdBQ2hGLGlDQUFDLFNBQUksT0FBTyxFQUFFQyxVQUFVLFdBQVcsR0FDakM7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPO0FBQUEsa0JBQ0xILFNBQVM7QUFBQSxrQkFDVEksWUFBWTtBQUFBLGtCQUNaSCxnQkFBZ0I7QUFBQSxrQkFDaEJJLFlBQVk7QUFBQSxrQkFDWkMsT0FBTztBQUFBLGtCQUNQQyxZQUFZO0FBQUEsa0JBQ1pDLFNBQVM7QUFBQSxrQkFDVEMsY0FBYztBQUFBLGtCQUNkQyxXQUFXO0FBQUEsa0JBQ1hDLFFBQVE7QUFBQSxrQkFDUkMsVUFBVTtBQUFBLGtCQUNWQyxRQUFRO0FBQUEsa0JBQ1JDLFlBQVk7QUFBQSxnQkFDZDtBQUFBLGdCQUNBLFNBQVMsQ0FBQzVOLE1BQU1BLEVBQUU2TixjQUFjQyxZQUFZQyxVQUFVQyxPQUFPLFFBQVE7QUFBQSxnQkFFckU7QUFBQSx5Q0FBQyxVQUFLLE9BQU8sRUFBRUMsVUFBVSxVQUFVQyxjQUFjLFlBQVlDLFlBQVksVUFBVUMsY0FBYyxTQUFTLEdBQ3ZHclMsNEJBQ0dOLGFBQWFnTyxLQUFLLENBQUM0RSxNQUFNQSxFQUFFeE8sUUFBUTlELGVBQWUsR0FBR3VLLGFBQ3JELDRCQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxpQkFBYyxPQUFPLEVBQUVzSCxZQUFZLGlCQUFpQixLQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RDtBQUFBO0FBQUE7QUFBQSxjQXhCekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBeUJBO0FBQUEsWUFHQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPO0FBQUEsa0JBQ0xYLFVBQVU7QUFBQSxrQkFDVnFCLEtBQUs7QUFBQSxrQkFDTEMsT0FBTztBQUFBLGtCQUNQQyxRQUFRO0FBQUEsa0JBQ1JDLFdBQVc7QUFBQSxrQkFDWGYsVUFBVTtBQUFBLGtCQUNWUCxZQUFZO0FBQUEsa0JBQ1pJLGNBQWM7QUFBQSxrQkFDZEMsV0FBVztBQUFBLGtCQUNYQyxRQUFRO0FBQUEsa0JBQ1JILFNBQVM7QUFBQSxrQkFDVG9CLFFBQVE7QUFBQSxnQkFDVjtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLE9BQU8zUyxtQkFBbUI2TztBQUFBQSxvQkFDMUIsVUFBVSxDQUFDM0ssVUFBVTtBQUNuQmpFLHlDQUFtQmlFLEtBQUs7QUFDeEI2Rix5Q0FBbUI3RixLQUFLO0FBQUEsb0JBQzFCO0FBQUEsb0JBQ0EsWUFBWSx1QkFBQyxZQUFTLE9BQU8sRUFBRW1OLE9BQU8sVUFBVSxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzQztBQUFBLG9CQUNsRCxPQUFPLEVBQUV1QixPQUFPLFFBQVFsQixRQUFRLFFBQVFELFdBQVcsT0FBTztBQUFBLG9CQUMxRCxjQUFjLENBQUNvQixPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU2xDLFlBQVksRUFBRUMsU0FBUytCLE1BQU1oQyxZQUFZLENBQUM7QUFBQSxvQkFHM0RuUix1QkFBYXlLO0FBQUFBLHNCQUFJLENBQUNDLFVBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNdEcsS0FDekNzRyxnQkFBTUcsY0FEV0gsTUFBTXRHLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUEsa0JBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFtQkE7QUFBQTtBQUFBLGNBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXFDQTtBQUFBLGVBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUVBLEtBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUVBO0FBQUEsVUFFQSx1QkFBQyxVQUFLLFVBQVVrTCxzQkFBc0IsV0FBVSxhQUM5QztBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxnQkFDdkQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUNWLGNBQWMsQ0FBQzZELE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKL0osU0FBUyxFQUNUNkgsWUFBWSxFQUNaQyxTQUFTK0IsTUFBTWhDLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPL1Esa0JBQWtCK087QUFBQUEsa0JBQ3pCLFVBQVVuRjtBQUFBQSxrQkFFVGxLLGdCQUFNMks7QUFBQUEsb0JBQUksQ0FBQ2pFLFNBQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLEtBQUtwQyxLQUN2QyxhQUFHb0MsS0FBS3VFLFNBQVMsTUFBTXZFLEtBQUt3RSxZQUFZLE1BRHZCeEUsS0FBS3BDLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW1CQTtBQUFBLGNBQ0NXLE9BQU9zRCxZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ0RCxpQkFBT3NELFlBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBEO0FBQUEsaUJBekI5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFXLEdBQUdySCxvQkFBb0IsZUFBZSxFQUFFLElBQ3REO0FBQUEscUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsZ0JBQ2pELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsVUFBVUE7QUFBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTDtBQUFBLGtCQUNBLHlCQUF5QjRDO0FBQUFBLGtCQUN6QixhQUFZO0FBQUEsa0JBQ1osVUFBVSxDQUFDWSxVQUFVO0FBQ25CMkUsMkNBQXVCM0UsS0FBSztBQUM1QlosNEJBQVEsS0FBSztBQUFBLGtCQUNmO0FBQUEsa0JBQ0EsU0FBUzVDO0FBQUFBLGtCQUNULE9BQU93QjtBQUFBQSxrQkFDUCxXQUFVO0FBQUEsa0JBRVQ1QjtBQUFBQSx3Q0FBb0I2SixJQUFJLENBQUN5RCxPQUFPdkQsVUFBVTtBQUN6Qyw0QkFBTTJJLFlBQVlwRixPQUFPeEIsWUFBWWhDLE9BQU9HLGNBQWM7QUFDMUQsNEJBQU1QLFVBQVU0RCxPQUFPeEIsWUFBWWhDLE9BQU90RyxPQUFPLFdBQVd1RyxLQUFLO0FBQ2pFLDRCQUFNTSxTQUFTaUQsT0FBT3hCLFlBQVlDLFdBQVc7QUFFN0MsNkJBQ0U7QUFBQSx3QkFBQyxPQUFPO0FBQUEsd0JBQVA7QUFBQSwwQkFFQyxPQUFPLFFBQVFyQyxPQUFPLElBQUlXLE1BQU07QUFBQSwwQkFFL0JxSTtBQUFBQTtBQUFBQSw0QkFBVTtBQUFBLDRCQUFJckk7QUFBQUE7QUFBQUE7QUFBQUEsd0JBSFYsUUFBUVgsT0FBTyxJQUFJVyxNQUFNO0FBQUEsd0JBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFFSixDQUFDO0FBQUEsb0JBQ0EzSSxnQkFBZ0JtSTtBQUFBQSxzQkFBSSxDQUFDMEQsVUFDcEIsdUJBQUMsT0FBTyxRQUFQLEVBQXlDLE9BQU8sU0FBU0EsTUFBTS9KLEdBQUcsSUFDaEUsYUFBRytKLE1BQU1FLFFBQVEsUUFBUUYsTUFBTUcsY0FBYyxNQUQ1QixTQUFTSCxNQUFNL0osR0FBRyxJQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQSxvQkFDQWhDLFdBQVdxSTtBQUFBQSxzQkFBSSxDQUFDOEQsYUFDZix1QkFBQyxPQUFPLFFBQVAsRUFBMkMsT0FBTyxRQUFRQSxTQUFTbkssR0FBRyxJQUNwRSxhQUFHbUssU0FBU0UsT0FBTyxRQUFRRixTQUFTRyxXQUFXLE1BRDlCLFFBQVFILFNBQVNuSyxHQUFHLElBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUE7QUFBQSxnQkF0Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdUNBO0FBQUEsY0FDQ1csT0FBT1cseUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QlgsaUJBQU9XLHlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RTtBQUFBLGlCQTdDM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQ0E7QUFBQSxZQUdDbEQsb0JBQW9CbUcsU0FBUyxLQUM1Qix1QkFBQyxTQUFJLFdBQVUsMENBQ1puRyw4QkFBb0JpSSxJQUFJLENBQUM2QixTQUFTO0FBQ2pDLG9CQUFNaUgsVUFBVTlELGlCQUFpQm5ELElBQUk7QUFDckMsa0JBQUksQ0FBQ2lILFFBQVMsUUFBTztBQUVyQixvQkFBTUMsZUFBZUQsUUFBUXZELFVBQVUsSUFBSSxpQkFBaUI7QUFDNUQsb0JBQU15RCxZQUFZRixRQUFRdkQsVUFBVSxJQUFJLGNBQWM7QUFHdEQsb0JBQU0wRCxZQUFZO0FBQUEsZ0JBQ2hCQyxNQUFNO0FBQUEsZ0JBQ05DLE1BQU07QUFBQSxnQkFDTkMsT0FBTztBQUFBLGNBQ1Q7QUFFQSxrQkFBSUMsU0FBUztBQUViLGtCQUFJUCxRQUFRek8sU0FBUyxRQUFRO0FBQzNCZ1AseUJBQVM7QUFBQSxrQkFDUCxFQUFFM1AsT0FBTyxpQkFBaUJLLE9BQU8sSUFBSStPLFFBQVF4RyxTQUFTZ0gsZUFBZSxPQUFPLENBQUMsR0FBRztBQUFBLGtCQUNoRixFQUFFNVAsT0FBTyxjQUFjSyxPQUFPLElBQUkrTyxRQUFRNUQsV0FBV29FLGVBQWUsT0FBTyxDQUFDLEdBQUc7QUFBQSxrQkFDL0UsRUFBRTVQLE9BQU8sV0FBV0ssT0FBTyxJQUFJK08sUUFBUXpELGNBQWNpRSxlQUFlLE9BQU8sQ0FBQyxHQUFHO0FBQUEsa0JBQy9FLEVBQUU1UCxPQUFPLFlBQVlLLE9BQU8sSUFBSStPLFFBQVF4RCxjQUFjZ0UsZUFBZSxPQUFPLENBQUMsR0FBRztBQUFBLGtCQUNoRixFQUFFNVAsT0FBTyxlQUFlSyxPQUFPLElBQUkrTyxRQUFRdkQsU0FBUytELGVBQWUsT0FBTyxDQUFDLElBQUlDLFdBQVcsS0FBSztBQUFBLGdCQUFDO0FBQUEsY0FFcEcsV0FBV1QsUUFBUXpPLFNBQVMsUUFBUTtBQUNsQ2dQLHlCQUFTO0FBQUEsa0JBQ1AsRUFBRTNQLE9BQU8sZUFBZUssT0FBTyxJQUFJK08sUUFBUTVDLFlBQVlvRCxlQUFlLE9BQU8sQ0FBQyxHQUFHO0FBQUEsa0JBQ2pGLEVBQUU1UCxPQUFPLGNBQWNLLE9BQU8rTyxRQUFRL0MsV0FBVzNPLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRUEsTUFBTSxHQUFHLEVBQUVvUyxRQUFRLEVBQUVuRixLQUFLLEdBQUcsRUFBRTtBQUFBLGtCQUM5RixFQUFFM0ssT0FBTyxZQUFZSyxPQUFPK08sUUFBUTFDLFNBQVNoUCxNQUFNLEdBQUcsRUFBRSxDQUFDLEVBQUVBLE1BQU0sR0FBRyxFQUFFb1MsUUFBUSxFQUFFbkYsS0FBSyxHQUFHLEVBQUU7QUFBQSxrQkFDMUYsRUFBRTNLLE9BQU8saUJBQWlCSyxPQUFPLElBQUkrTyxRQUFROUMsY0FBY3NELGVBQWUsT0FBTyxDQUFDLEdBQUc7QUFBQSxrQkFDckYsRUFBRTVQLE9BQU8sY0FBY0ssT0FBTyxJQUFJK08sUUFBUTVELFdBQVdvRSxlQUFlLE9BQU8sQ0FBQyxHQUFHO0FBQUEsa0JBQy9FLEVBQUU1UCxPQUFPLFdBQVdLLE9BQU8sSUFBSStPLFFBQVF2RCxTQUFTK0QsZUFBZSxPQUFPLENBQUMsSUFBSUMsV0FBVyxLQUFLO0FBQUEsZ0JBQUM7QUFBQSxjQUVoRyxXQUFXVCxRQUFRek8sU0FBUyxTQUFTO0FBQ25DZ1AseUJBQVM7QUFBQSxrQkFDUCxFQUFFM1AsT0FBTyxnQkFBZ0JLLE9BQU8sSUFBSStPLFFBQVFoRCxlQUFld0QsZUFBZSxPQUFPLENBQUMsR0FBRztBQUFBLGtCQUNyRixFQUFFNVAsT0FBTyxjQUFjSyxPQUFPK08sUUFBUS9DLFdBQVczTyxNQUFNLEdBQUcsRUFBRSxDQUFDLEVBQUVBLE1BQU0sR0FBRyxFQUFFb1MsUUFBUSxFQUFFbkYsS0FBSyxHQUFHLEVBQUU7QUFBQSxrQkFDOUYsRUFBRTNLLE9BQU8sWUFBWUssT0FBTyxHQUFHK08sUUFBUW5ELFFBQVEsVUFBVTtBQUFBLGtCQUN6RCxFQUFFak0sT0FBTyxjQUFjSyxPQUFPLElBQUkrTyxRQUFRNUQsV0FBV29FLGVBQWUsT0FBTyxDQUFDLElBQUlwQyxPQUFPLGlCQUFpQjtBQUFBLGdCQUFDO0FBQUEsY0FFN0c7QUFFQSxxQkFDRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxXQUFXLCtIQUErSDRCLFFBQVF2RCxVQUFVLElBQUkscUJBQXFCLHNCQUFzQjtBQUFBLGtCQUczTSxpQ0FBQyxTQUFJLFdBQVUsT0FHYjtBQUFBLDJDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDZDQUFDLFVBQUssV0FBVyxrR0FBa0cwRCxVQUFVSCxRQUFRek8sSUFBSSxLQUFLLDJCQUEyQixJQUN0S3lPLGtCQUFRek8sUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLDBEQUNYeU8sa0JBQVExSyxRQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQzBLLFFBQVF6TyxTQUFTLFVBQVV5TyxRQUFRdEksVUFBVXNJLFFBQVF0SSxXQUFXLE9BQy9ELHVCQUFDLFVBQUssV0FBVSx3R0FBdUc7QUFBQTtBQUFBLHdCQUM1R3NJLFFBQVF0STtBQUFBQSwyQkFEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBWUE7QUFBQSxvQkFHQ3NJLFFBQVF6TyxTQUFTLFVBQ2hCLHVCQUFDLFNBQUksV0FBVSw4R0FDYjtBQUFBLDZDQUFDLFVBQUs7QUFBQTtBQUFBLHdCQUNTLHVCQUFDLFVBQUssV0FBVSwrQkFBK0J5TyxrQkFBUTNELGVBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW1FO0FBQUEsMkJBRGxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFLO0FBQUE7QUFBQSx3QkFDUyx1QkFBQyxVQUFLLFdBQVUsK0JBQStCMkQsa0JBQVE1RixpQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBcUU7QUFBQSwyQkFEcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSxvQkFJRix1QkFBQyxTQUFJLFdBQVcseUNBQXlDNEYsUUFBUXpPLFNBQVMsU0FDdEUsbUJBQW1CLGdCQUFnQixJQUNwQ2dQLGlCQUFPcko7QUFBQUEsc0JBQUksQ0FBQ3lKLE9BQU9DLFFBQ2xCO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUVDLFdBQVcsOERBQThERCxNQUFNRixZQUFZUCxZQUFZLGtCQUFrQjtBQUFBLDBCQUd6SDtBQUFBLG1EQUFDLFVBQUssV0FBVSxzRUFDYlMsZ0JBQU0vUCxTQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFDQTtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxXQUFXLDBDQUEwQytQLE1BQU12QyxRQUN2RHVDLE1BQU12QyxRQUNOdUMsTUFBTUYsWUFDSlIsZUFDQSxlQUFlO0FBQUEsZ0NBR3BCVSxnQkFBTTFQO0FBQUFBO0FBQUFBLDhCQVJUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFTQTtBQUFBO0FBQUE7QUFBQSx3QkFoQksyUDtBQUFBQSx3QkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWtCQTtBQUFBLG9CQUNELEtBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBdUJBO0FBQUEsdUJBckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdURBO0FBQUE7QUFBQSxnQkEzREs3SDtBQUFBQSxnQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBNkRBO0FBQUEsWUFFSixDQUFDLEtBM0dIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEdBO0FBQUEsWUFjRix1QkFBQyxTQUFJLFdBQVUsb0RBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsNENBQTJDLCtCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RTtBQUFBLGNBRXhFLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsa0RBQWlELDRCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsVUFBVSxDQUFDckc7QUFBQUEsc0JBQ1gsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxLQUFLRSwwQkFBMEJFLFlBQVk4STtBQUFBQSxzQkFDM0MsS0FBS2hKLDBCQUEwQnpFLFFBQVF5TjtBQUFBQSxzQkFDdkMsT0FBT2xLLFNBQVNLO0FBQUFBLHNCQUNoQixJQUFHO0FBQUEsc0JBQ0gsVUFBVXNEO0FBQUFBLHNCQUNWLFdBQVU7QUFBQTtBQUFBLG9CQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTdUw7QUFBQSxrQkFFdEw3RCxPQUFPTyxZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJQLGlCQUFPTyxZQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRDtBQUFBLHFCQWhCOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQkE7QUFBQSxnQkFFQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsb0JBQ3pELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsT0FBTytELG1CQUFtQnBFLFNBQVNNLE1BQU07QUFBQSxzQkFDekMsSUFBRztBQUFBLHNCQUNILFVBQVVxRDtBQUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1o7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUXVMO0FBQUEsa0JBRXRMN0QsT0FBT1EsVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCUixpQkFBT1EsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0Q7QUFBQSxrQkFFMUQsdUJBQUMsU0FBSSxXQUFVLHNDQUNaL0YsOEJBQW9CeUYsU0FBU00sTUFBTSxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0JBO0FBQUEsZ0JBRUEsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQsNEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILFdBQVU7QUFBQSxzQkFDVixVQUFVc0c7QUFBQUEsc0JBRVY7QUFBQSwrQ0FBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUI7QUFBQSx3QkFDekIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZCO0FBQUEsd0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxjQUFhLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxQztBQUFBLHdCQUNyQyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkI7QUFBQSx3QkFDN0IsdUJBQUMsWUFBTyxPQUFNLGVBQWMsMkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXVDO0FBQUE7QUFBQTtBQUFBLG9CQVZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV0E7QUFBQSxxQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdCQTtBQUFBLGdCQUVDNUYsaUJBQ0MsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQsNEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILFdBQVU7QUFBQSxzQkFDVixVQUFVOEY7QUFBQUEsc0JBRVY7QUFBQSwrQ0FBQyxZQUFPLE9BQU0sSUFBRyxtQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBb0M7QUFBQSx3QkFDcEMsdUJBQUMsWUFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVBuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUE7QUFBQSxxQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBO0FBQUEsbUJBM0VKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNkVBO0FBQUEsY0FFQzlHLFNBQVNNLFVBQVUvQyxvQkFBb0JtRyxTQUFTLEtBQy9DLHVCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsa0RBQWlELHdDQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osT0FBT1U7QUFBQUEsd0JBQ0w2RyxPQUFPakwsU0FBU00sTUFBTSxJQUFJL0Msb0JBQW9CbUc7QUFBQUEsc0JBQ2hEO0FBQUEsc0JBQ0EsVUFBUTtBQUFBO0FBQUEsb0JBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9VO0FBQUEscUJBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxzQ0FDWm5KO0FBQUFBLGtCQUNDMFEsT0FBT2pMLFNBQVNNLE1BQU0sSUFBSS9DLG9CQUFvQm1HO0FBQUFBLGdCQUNoRCxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQkE7QUFBQSxlQUdBbkgsZ0JBQWdCLFlBQVlBLGdCQUFnQixpQkFDNUMsdUJBQUMsU0FBSSxXQUFVLHNDQUNiLGlDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxrQkFDakQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxJQUFHO0FBQUEsb0JBQ0gsT0FBT3lELFNBQVNRO0FBQUFBLG9CQUNoQixVQUFVbUQ7QUFBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPdUw7QUFBQSxnQkFFdEw3RCxPQUFPVSxrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCVixpQkFBT1Usa0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdFO0FBQUEsbUJBZHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsY0FHRGpFLGdCQUFnQixZQUNmLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw4Q0FBNkMsOEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlFO0FBQUEsZ0JBQ3pFLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHlDQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxzQkFDbEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxJQUFHO0FBQUEsd0JBQ0gsT0FBT3lELFNBQVNXO0FBQUFBLHdCQUNoQixVQUFVZ0Q7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPdUw7QUFBQSxvQkFFdEw3RCxPQUFPYSxpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCYixpQkFBT2EsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStEO0FBQUEsdUJBZG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZ0JBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLHNCQUNwRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLElBQUc7QUFBQSx3QkFDSCxPQUFPWCxTQUFTWSxZQUFZaEUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLHdCQUN4QyxVQUFVK0c7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPdUw7QUFBQSxvQkFFdEw3RCxPQUFPYyxlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJkLGlCQUFPYyxlQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RDtBQUFBLHVCQWRqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWdCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsa0RBQWlELHlCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxJQUFHO0FBQUEsd0JBQ0gsT0FBT1osU0FBU2E7QUFBQUEsd0JBQ2hCLFVBQVU4QztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU91TDtBQUFBLHVCQVh6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxrREFBaUQsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLElBQUc7QUFBQSx3QkFDSCxPQUFPM0QsU0FBU2M7QUFBQUEsd0JBQ2hCLFVBQVU2QztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU91TDtBQUFBLHVCQVh6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEscUJBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0VBO0FBQUEsbUJBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUVBO0FBQUEsY0FHRix1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQsdUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsSUFBRztBQUFBLG9CQUNILE9BQU8zRCxVQUFVRTtBQUFBQSxvQkFDakIsVUFBVXlEO0FBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixNQUFNO0FBQUEsb0JBQ04sV0FBVTtBQUFBO0FBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFDO0FBQUEsbUJBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGlCQXRORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVOQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGtEQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLG9CQUFpQixXQUFVLDZCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRDtBQUFBLGdCQUNyRCx1QkFBQyxRQUFHLFdBQVUseUNBQXdDLHFDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRTtBQUFBLG1CQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3BGLGlCQUFpQkU7QUFBQUEsb0JBQzFCLFdBQVU7QUFBQSxvQkFDVixVQUFVLE1BQ1JELG9CQUFvQixDQUFDeUYsVUFBVTtBQUFBLHNCQUM3QixHQUFHQTtBQUFBQSxzQkFDSHhGLFVBQVUsQ0FBQ3dGLEtBQUt4RjtBQUFBQSxvQkFDbEIsRUFBRTtBQUFBO0FBQUEsa0JBUk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNHO0FBQUEsZ0JBRUgsdUJBQUMsVUFBSyxXQUFVLHlCQUF3QixpQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxtQkFaM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGlCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsQ0FBQ2EsTUFBTStLLHFCQUFxQi9LLEdBQUcsSUFBSTtBQUFBLGtCQUM1QyxXQUFVO0FBQUEsa0JBQW1PO0FBQUE7QUFBQSxnQkFIL087QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLENBQUNBLE1BQU0rSyxxQkFBcUIvSyxHQUFHLEtBQUs7QUFBQSxrQkFDN0MsV0FBVTtBQUFBLGtCQUE4SztBQUFBO0FBQUEsZ0JBSDFMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxlQTNjRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRjQTtBQUFBLFVBQ0NqQixlQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxRQUFRQTtBQUFBQSxjQUNSLE9BQU07QUFBQSxjQUNOLE1BQU15TDtBQUFBQSxjQUNOLFVBQVUsTUFBTXhMLGVBQWUsS0FBSztBQUFBLGNBQ3BDLFdBQVcsTUFBTTBJLGFBQWFwSSxpQkFBaUI7QUFBQTtBQUFBLFlBTGpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUttRDtBQUFBLGFBemlCdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRpQkE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0E7QUFBQSxZQUNBLE9BQU8sdUJBQUMsT0FBRSxXQUFVLHVDQUFzQyx1Q0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxZQUNqRixXQUFVO0FBQUEsWUFDVixNQUFNZjtBQUFBQSxZQUNOLFNBQVNFO0FBQUFBLFlBQ1QsU0FBUyxNQUFNRCxrQkFBa0IsS0FBSztBQUFBLFlBQ3RDLE9BQU87QUFBQSxZQUVORyw2QkFBbUJ5RixVQUFVLElBQzVCLHVCQUFDLFNBQUksV0FBVSx3REFBdUQsb0NBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFHWDtBQUFBLHFCQUFNO0FBQ04sc0JBQU15TCxlQUFlbFIsa0JBQ2xCZ00sT0FBTyxDQUFBZCxNQUFLLENBQUNBLEVBQUVpRyxXQUFZakcsRUFBRWlHLFNBQVNsRCxZQUFZLE1BQU0sVUFBVS9DLEVBQUVpRyxTQUFTbEQsWUFBWSxNQUFNLE9BQVEsRUFDdkd6SCxNQUFNLEVBQUU7QUFDWCxvQkFBSTBLLGFBQWF6TCxXQUFXLEVBQUcsUUFBTztBQUN0Qyx1QkFDRSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsUUFBRyxXQUFVLDBDQUF5Qyx3Q0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0U7QUFBQSxrQkFDL0UsdUJBQUMsU0FBSSxXQUFVLGFBQ1p5TCx1QkFBYTNKO0FBQUFBLG9CQUFJLENBQUM2SixTQUFTM0osVUFDMUIsdUJBQUMsYUFBb0IsV0FBVSxvR0FDN0I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUseUJBQ2IsaUNBQUMsVUFBSyxXQUFVLGlHQUFnRyxvQkFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSUE7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSw2Q0FBNEMsNkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXlFO0FBQUEsd0JBQ3pFLHVCQUFDLFVBQUssV0FBVSw2QkFBNkIySixtQkFBU2hQLFlBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStEO0FBQUEsMkJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQ2dQLFFBQVExSixZQUNQLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDZDQUE0QyxzQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBa0U7QUFBQSx3QkFDbEUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QjBKLGtCQUFRMUosVUFBVUMsY0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMEU7QUFBQSwyQkFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUVEeUosUUFBUXJKLFVBQ1AsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQ0FBQyxVQUFLLFdBQVUsNkNBQTRDLHVCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtRTtBQUFBLHdCQUNuRSx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCcUosbUJBQVNySixVQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2RDtBQUFBLDJCQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBRUYsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQ0FBQyxVQUFLLFdBQVUsNkNBQTRDLHVCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtRTtBQUFBLHdCQUNuRSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCO0FBQUE7QUFBQSwwQkFBRXFKLFNBQVMvTztBQUFBQSw2QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBOEQ7QUFBQSwyQkFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDZDQUE0Qyw2QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUU7QUFBQSx3QkFDekUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QitPLG1CQUFTOU8sWUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0Q7QUFBQSwyQkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDZDQUE0QyxxQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUU7QUFBQSx3QkFDakUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QjhPLGtCQUFRbFAsU0FBUzJGLGFBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXdFO0FBQUEsMkJBRjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSx5QkFqQ1lKLE9BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFrQ0E7QUFBQSxrQkFDRCxLQXJDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXNDQTtBQUFBLHFCQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlDQTtBQUFBLGNBRUosR0FBRztBQUFBLGVBR0QsTUFBTTtBQUNOLHNCQUFNNEosZUFBZXJSLGtCQUNsQmdNLE9BQU8sQ0FBQWQsTUFBS0EsRUFBRWlHLFNBQVNsRCxZQUFZLE1BQU0sTUFBTSxFQUMvQ3pILE1BQU0sRUFBRTtBQUNYLG9CQUFJNkssYUFBYTVMLFdBQVcsRUFBRyxRQUFPO0FBQ3RDLHVCQUNFLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsd0NBQXVDLHdDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RTtBQUFBLGtCQUM3RSx1QkFBQyxTQUFJLFdBQVUsYUFDWjRMLHVCQUFhOUo7QUFBQUEsb0JBQUksQ0FBQzZKLFNBQVMzSixVQUMxQix1QkFBQyxhQUFvQixXQUFVLGtHQUM3QjtBQUFBLDZDQUFDLFNBQUksV0FBVSx5QkFDYixpQ0FBQyxVQUFLLFdBQVUsNkZBQTRGLG9CQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDZDQUE0Qyw2QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUU7QUFBQSx3QkFDekUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QjJKLG1CQUFTaFAsWUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0Q7QUFBQSwyQkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDZDQUE0Qyx1QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBbUU7QUFBQSx3QkFDbkUsdUJBQUMsVUFBSyxXQUFVLDZCQUE0QjtBQUFBO0FBQUEsMEJBQUVnUCxTQUFTL087QUFBQUEsNkJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQThEO0FBQUEsMkJBRmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSw2Q0FBNEMsNkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXlFO0FBQUEsd0JBQ3pFLHVCQUFDLFVBQUssV0FBVSw2QkFBNkIrTyxtQkFBUzlPLFlBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStEO0FBQUEsMkJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSw2Q0FBNEMscUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlFO0FBQUEsd0JBQ2pFLHVCQUFDLFVBQUssV0FBVSw2QkFBNkI4TyxrQkFBUWxQLFNBQVMyRixhQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF3RTtBQUFBLDJCQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEseUJBdEJZSixPQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBdUJBO0FBQUEsa0JBQ0QsS0ExQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEyQkE7QUFBQSxxQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4QkE7QUFBQSxjQUVKLEdBQUc7QUFBQSxlQUdELE1BQU07QUFDTixzQkFBTTZKLGdCQUFnQnRSLGtCQUNuQmdNLE9BQU8sQ0FBQWQsTUFBS0EsRUFBRWlHLFNBQVNsRCxZQUFZLE1BQU0sT0FBTyxFQUNoRHpILE1BQU0sRUFBRTtBQUNYLG9CQUFJOEssY0FBYzdMLFdBQVcsRUFBRyxRQUFPO0FBQ3ZDLHVCQUNFLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxRQUFHLFdBQVUseUNBQXdDLHlDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErRTtBQUFBLGtCQUMvRSx1QkFBQyxTQUFJLFdBQVUsYUFDWjZMLHdCQUFjL0o7QUFBQUEsb0JBQUksQ0FBQzZKLFNBQVMzSixVQUMzQix1QkFBQyxhQUFvQixXQUFVLG1HQUM3QjtBQUFBLDZDQUFDLFNBQUksV0FBVSx5QkFDYixpQ0FBQyxVQUFLLFdBQVUsK0ZBQThGLHFCQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDZDQUE0Qyw2QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUU7QUFBQSx3QkFDekUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QjJKLG1CQUFTaFAsWUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0Q7QUFBQSwyQkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDZDQUE0Qyx1QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBbUU7QUFBQSx3QkFDbkUsdUJBQUMsVUFBSyxXQUFVLDZCQUE0QjtBQUFBO0FBQUEsMEJBQUVnUCxTQUFTL087QUFBQUEsNkJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQThEO0FBQUEsMkJBRmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSw2Q0FBNEMsNkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXlFO0FBQUEsd0JBQ3pFLHVCQUFDLFVBQUssV0FBVSw2QkFBNkIrTyxtQkFBUzlPLFlBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStEO0FBQUEsMkJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSw2Q0FBNEMscUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlFO0FBQUEsd0JBQ2pFLHVCQUFDLFVBQUssV0FBVSw2QkFBNkI4TyxrQkFBUWxQLFNBQVMyRixhQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF3RTtBQUFBLDJCQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEseUJBdEJZSixPQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBdUJBO0FBQUEsa0JBQ0QsS0ExQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEyQkE7QUFBQSxxQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4QkE7QUFBQSxjQUVKLEdBQUc7QUFBQSxpQkF0SUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwSUE7QUFBQTtBQUFBLFVBekpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQTJKQTtBQUFBLFdBMXNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMnNCQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU16SjtBQUFBQSxVQUNOLFVBQVUsTUFBTUMsaUJBQWlCLEtBQUs7QUFBQSxVQUN0QyxTQUFTLE1BQU1BLGlCQUFpQixLQUFLO0FBQUEsVUFDckMsTUFBTSxNQUFNQSxpQkFBaUIsS0FBSztBQUFBLFVBQ2xDLFVBQVUsTUFBTWtELG9CQUFvQnpCLGNBQWM7QUFBQSxVQUNsRCxRQUFRLHVCQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBSztBQUFBLFVBQ2IsU0FBU2xDO0FBQUFBLFVBRVQ7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFLHVCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDZDQUE0QyxzQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0U7QUFBQSxnQkFDbEUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QlUsNEJBQWtCd0osVUFBVUMsY0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Y7QUFBQSxtQkFGdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTRDLDRCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLGdCQUN4RSx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCekosNEJBQWtCd0osVUFBVWdGLGVBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFGO0FBQUEsbUJBRnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDZDQUE0QyxrQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEU7QUFBQSxnQkFDOUUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QnhPLDRCQUFrQndKLFVBQVUrQyxpQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUY7QUFBQSxtQkFGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTRDLHFCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRTtBQUFBLGdCQUNqRSx1QkFBQyxVQUFLLFdBQVUsNkJBQ2J2TTtBQUFBQSxvQ0FBa0JnRSxTQUFTMkY7QUFBQUEsa0JBQVU7QUFBQSxrQkFBWTNKLGtCQUFrQjZKO0FBQUFBLHFCQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTRDLDJCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RTtBQUFBLGdCQUN2RSx1QkFBQyxVQUFLLFdBQVUsNkJBQ2I3Siw0QkFBa0J3SixVQUFVZ0YsY0FBY3hPLGtCQUFrQnFULGFBQ3pEclQsa0JBQWtCd0osVUFBVWdGLGNBQWN4TyxrQkFBa0JxVCxhQUM1RCxNQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw2Q0FBNEMsMkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFO0FBQUEsZ0JBQ3ZFLHVCQUFDLFVBQUssV0FBVSw2QkFBNkJyVCw0QkFBa0JzVCxjQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRTtBQUFBLG1CQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw2Q0FBNEMsK0JBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJFO0FBQUEsZ0JBQzNFLHVCQUFDLFVBQUssV0FBVSw2QkFBNkJ0VCw0QkFBa0JxVCxjQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRTtBQUFBLG1CQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw2Q0FBNEMseUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFO0FBQUEsZ0JBQ3JFLHVCQUFDLFVBQUssV0FBVSw2QkFBNkJyVCw0QkFBa0J1VCxZQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLG1CQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw2Q0FBNEMsa0NBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThFO0FBQUEsZ0JBQzlFLHVCQUFDLFVBQUssV0FBVSw2QkFBNkJ2VCw0QkFBa0J3VCxpQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkU7QUFBQSxtQkFGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTRDLDZCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RTtBQUFBLGdCQUN6RSx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCeFQsNEJBQWtCMkwsV0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUU7QUFBQSxtQkFGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTRDLDZCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RTtBQUFBLGdCQUN6RSx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCM0wsNEJBQWtCeVQsZ0JBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRFO0FBQUEsbUJBRjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDZDQUE0QywwQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQSxnQkFDdEUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QnpULDRCQUFrQjBULGFBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlFO0FBQUEsbUJBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDZDQUE0QywyQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUU7QUFBQSxnQkFDdkUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QjFULDRCQUFrQm1LLFdBQVcxSixNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdGO0FBQUEsbUJBRjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDZDQUE0QywyQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUU7QUFBQSxnQkFDdkUsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QlQsNEJBQWtCMlQsV0FBV2xULE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Y7QUFBQSxtQkFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTRDLDhCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRTtBQUFBLGdCQUMxRSx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCVCw0QkFBa0J3RSxpQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkU7QUFBQSxtQkFGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTRDLDRCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLGdCQUN4RSx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCeEUsNEJBQWtCeUUsYUFBYWhFLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEY7QUFBQSxtQkFGNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTRDLGlDQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2RTtBQUFBLGdCQUM3RSx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCVCw0QkFBa0IwRSxvQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Y7QUFBQSxtQkFGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTRDLHdDQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRjtBQUFBLGdCQUNwRix1QkFBQyxVQUFLLFdBQVUsNkJBQTZCMUUsNEJBQWtCMkUsc0JBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtGO0FBQUEsbUJBRnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkE5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErRUE7QUFBQTtBQUFBO0FBQUEsUUF6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BMEZBO0FBQUEsU0FwMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxMUJBO0FBQUEsT0F2MUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3MUJBLEtBejFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMDFCQSxLQTkxQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWcyQkE7QUFFSjtBQUFFbEcsR0E3Z0RJRCxTQUFPO0FBQUFvVixLQUFQcFY7QUErZ0ROLGVBQWVBO0FBQVEsSUFBQW9WO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkNpcmN1bGFyTG9hZGVyIiwiRmFNb25leUJpbGxXYXZlIiwiRmFXaGF0c2FwcFNxdWFyZSIsIk5hdmJhciIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiTW9kYWwiLCJBbnRNb2RhbCIsIkRyYXdlciIsIlRvb2x0aXAiLCJUYWciLCJtZXNzYWdlIiwiSW9NZE1vcmUiLCJMaW5rIiwiQmFja2Ryb3BCbHVyTG9hZGVyIiwiRmFSZWNlaXB0IiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIkZpQ2hldnJvbkRvd24iLCJGaVNlYXJjaCIsIlJlQ29uZmlybU1vZGFsIiwiUGF5bWVudCIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsImFjdHVhbEdyb3VwcyIsInNldEFjdHVhbEdyb3VwcyIsIlRhYmxlUGF5bWVudHMiLCJzZXRUYWJsZVBheW1lbnRzIiwic2VsZWN0ZWRVc2VySWQiLCJzZXRTZWxlY3RlZFVzZXJJZCIsInNlbGVjdGVkR3JvdXBJZCIsInNldFNlbGVjdGVkR3JvdXBJZCIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwidmlld0xvYWRlciIsInNldFZpZXdMb2FkZXIiLCJmaWx0ZXJlZEVucm9sbG1lbnRzIiwic2V0RmlsdGVyZWRFbnJvbGxtZW50cyIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsImVucm9sbG1lbnRMb2FkaW5nIiwic2V0RW5yb2xsbWVudExvYWRpbmciLCJzaG93TW9kYWxWaWV3Iiwic2V0U2hvd01vZGFsVmlldyIsImN1cnJlbnRWaWV3R3JvdXAiLCJzZXRDdXJyZW50Vmlld0dyb3VwIiwid2hhdHNhcHBFbmFibGUiLCJzZXRXaGF0c2FwcEVuYWJsZSIsInBheW1lbnRNb2RlIiwic2V0UGF5bWVudE1vZGUiLCJ0b2RheSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImJvcnJvd2VycyIsInNldEJvcnJvd2VycyIsInBpZ21lQ3VzdG9tZXJzIiwic2V0UGlnbWVDdXN0b21lcnMiLCJwYXltZW50R3JvdXBUaWNrZXRzIiwic2V0UGF5bWVudEdyb3VwVGlja2V0cyIsIm9wZW5CYWNrZHJvcExvYWRlciIsInNldE9wZW5CYWNrZHJvcExvYWRlciIsImN1cnJlbnRHcm91cElkIiwic2V0Q3VycmVudEdyb3VwSWQiLCJvcGVuQW50RERyYXdlciIsInNldE9wZW5BbnRERHJhd2VyIiwic2hvd0xvYWRlciIsInNldFNob3dMb2FkZXIiLCJsYXN0VGhyZWVQYXltZW50cyIsInNldExhc3RUaHJlZVBheW1lbnRzIiwic2hvd0dyb3VwUGF5bWVudCIsInNldFNob3dHcm91cFBheW1lbnQiLCJzaG93Q29uZmlybSIsInNldFNob3dDb25maXJtIiwidGhpcmRQYXJ0eUVuYWJsZSIsInNldFRoaXJkUGFydHlFbmFibGUiLCJ3aGF0c2FwcCIsIm9wZW4iLCJzZXRPcGVuIiwicHJpbnRBZnRlckNvbmZpcm0iLCJzZXRQcmludEFmdGVyQ29uZmlybSIsImRyb3BEb3duSXRlbXMiLCJwYXltZW50T2JqZWN0IiwiZHJvcERvd25JdGVtTGlzdCIsImtleSIsImxhYmVsIiwiX2lkIiwiaGFuZGxlVmlld01vZGFsT3BlbiIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5Iiwibm9SZWxvYWQiLCJ0eXBlIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInJlbWFya3MiLCJ1c2VyX2lkIiwicmVjZWlwdF9ubyIsInBheV9kYXRlIiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsInBheW1lbnRfZ3JvdXBfdGlja2V0cyIsImFjY291bnRfdHlwZSIsImNoZXF1ZV9udW1iZXIiLCJjaGVxdWVfZGF0ZSIsImNoZXF1ZV9iYW5rX25hbWUiLCJjaGVxdWVfYmFua19icmFuY2giLCJjb2xsZWN0aW9uX3RpbWUiLCJtb2RpZnlQYXltZW50Iiwic2V0TW9kaWZ5UGF5bWVudCIsIm1vZGlmeU1pbk1heFBheW1lbnREYXRlIiwic2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGUiLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsImFkbWluQWNjZXNzUGVybWlzc2lvbnMiLCJhZG1pbl9hY2Nlc3NfcmlnaHRfaWQiLCJhY2Nlc3NfcGVybWlzc2lvbnMiLCJlZGl0X3BheW1lbnQiLCJlZGl0X2xpbWl0ZWRfcGF5bWVudCIsImZldGNoTGFzdFRocmVlVHJhbnNhY3Rpb25zIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInJlc3BvbnNlIiwiZ2V0IiwicGFyYW1zIiwibGltaXQiLCJkYXRhIiwiZXJyb3IiLCJmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMiLCJlcnIiLCJjb25zb2xlIiwibG9nIiwiZmV0Y2hDdXN0b21lclBpZ21lRGV0YWlscyIsImZldGNoQWxsQ3VzdG9tZXJzIiwiZmV0Y2hHcm91cHMiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJjdXN0b21lciIsInBhcnNlRmxvYXQiLCJpc05hTiIsInRyaW0iLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiaGFuZGxlQ2hhbmdlIiwibmFtZSIsImNsZWFuZWQiLCJyZXBsYWNlIiwiZG90Q291bnQiLCJtYXRjaCIsInByZXYiLCJoYW5kbGVQYXltZW50QW50U2VsZWN0IiwidmFsdWVzIiwiZm9ybWF0SW5kaWFuTnVtYmVyIiwidG9TdHJpbmciLCJwYXJ0cyIsImludGVnZXJQYXJ0IiwiZGVjaW1hbFBhcnQiLCJzbGljZSIsImxhc3RUaHJlZSIsIm90aGVyTnVtYmVycyIsImZvcm1hdHRlZEludCIsImNvbHVtbnMiLCJoZWFkZXIiLCJoYW5kbGVDdXN0b21lciIsInVzZXJJZCIsInByZXZGb3JtRGF0YSIsInByZXZEYXRhIiwiaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlIiwiaGFuZGxlR3JvdXBQYXltZW50IiwiZ3JvdXBJZCIsInVybCIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJncm91cCIsImluZGV4IiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwiaWQiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJ0aWNrZXQiLCJyZWNlaXB0Iiwib2xkX3JlY2VpcHQiLCJvbGRfcmVjZWlwdF9ubyIsImRhdGUiLCJ0cmFuc2FjdGlvbl9kYXRlIiwiY3JlYXRlZEF0IiwiY29sbGVjdGVkX2J5IiwiYWRtaW5fdHlwZSIsImFkbWluX25hbWUiLCJhY3Rpb24iLCJpdGVtcyIsImhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlIiwic2VsZWN0ZWRNb2RlIiwiaGFuZGxlQWNjb3VudFR5cGVDaGFuZ2UiLCJyZXNldEZvcm0iLCJoYW5kbGVTdWJtaXQiLCJwcmludEZsYWciLCJwYXlsb2FkIiwicG9zdCIsInBheW1lbnRJZHMiLCJpdGVtIiwid2luZG93IiwicGF5bWVudElkIiwidHJhbnNmb3JtZWQiLCJlbnJvbGxtZW50IiwidGlja2V0cyIsInBheW1lbnRzIiwidG90YWxQYWlkQW1vdW50IiwidG90YWxfaW52ZXN0bWVudCIsInBheWFibGUiLCJ0b3RhbFBheWFibGUiLCJ0b3RhbF9wYXlhYmxlIiwicHJvZml0IiwidG90YWxQcm9maXQiLCJ0b3RhbF9wcm9maXQiLCJhdWN0aW9uIiwiYXVjdGlvbkNvdW50IiwidG90YWxfY291bnQiLCJmaXJzdEF1Y3Rpb24iLCJmaXJzdERpdmlkZW50SGVhZCIsImZpcnN0X2RpdmlkZW50X2hlYWQiLCJncm91cF9pbnN0YWxsIiwidG90YWxfcGVuYWx0eSIsInRvdGFsX2xhdGVfZmVlIiwidG90YWxfYmFsYW5jZSIsInNlbGVjdGVkQ3VzdG9tZXIiLCJmaW5kIiwic2VsZWN0ZWRHcm91cFRpY2tldHMiLCJlbnRyeSIsInBpZ21lIiwicCIsInBpZ21lX2lkIiwicGF5YWJsZV9hbW91bnQiLCJib3Jyb3dlciIsImIiLCJsb2FuX2lkIiwibG9hbl9hbW91bnQiLCJjb25maXJtRGF0YSIsImN1c3RvbWVyX25hbWUiLCJncm91cF90aWNrZXRzIiwiam9pbiIsInNhbml0aXplZENvbmZpcm1EYXRhIiwiZnJvbUVudHJpZXMiLCJlbnRyaWVzIiwiZmlsdGVyIiwidW5kZWZpbmVkIiwiQXJyYXkiLCJpc0FycmF5IiwiaGFuZGxlUmVjb25maXJtYXRpb24iLCJpc1ZhbGlkIiwid2FybiIsImdldFRpY2tldERldGFpbHMiLCJzdGFydHNXaXRoIiwidG90YWxQYWlkIiwiZ3JvdXBfdmFsdWUiLCJkaXZpZGVudEhlYWQiLCJ0b3RhbFBlbmFsdHkiLCJ0b3RhbExhdGVGZWUiLCJiYWxhbmNlIiwibWF0dXJpdHlfcGVyaW9kIiwiTnVtYmVyIiwic3RhcnRfZGF0ZSIsImR1cmF0aW9uIiwidG90YWxfcGFpZF9hbW91bnQiLCJtYXR1cml0eVBlcmlvZCIsInBheWFibGVBbW91bnQiLCJzdGFydERhdGUiLCJkYWlseVBheW1lbnQiLCJkYWlseV9wYXltZW50X2Ftb3VudCIsImxvYW5BbW91bnQiLCJ0b3RhbF9wYXltZW50cyIsImVuZERhdGUiLCJlbmRfZGF0ZSIsInJlbWFpbmluZ19sb2FuIiwidG90YWxMb2FuIiwic29tZSIsIlN0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJkaXNwbGF5IiwianVzdGlmeUNvbnRlbnQiLCJtYXJnaW5Cb3R0b20iLCJwb3NpdGlvbiIsImFsaWduSXRlbXMiLCJiYWNrZ3JvdW5kIiwiY29sb3IiLCJmb250V2VpZ2h0IiwicGFkZGluZyIsImJvcmRlclJhZGl1cyIsImJveFNoYWRvdyIsImJvcmRlciIsIm1pbldpZHRoIiwiY3Vyc29yIiwidHJhbnNpdGlvbiIsImN1cnJlbnRUYXJnZXQiLCJuZXh0U2libGluZyIsImNsYXNzTGlzdCIsInRvZ2dsZSIsIm92ZXJmbG93IiwidGV4dE92ZXJmbG93Iiwid2hpdGVTcGFjZSIsInBhZGRpbmdSaWdodCIsImciLCJ0b3AiLCJyaWdodCIsImJvdHRvbSIsIm1hcmdpblRvcCIsInpJbmRleCIsIndpZHRoIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsImdyb3VwTmFtZSIsImRldGFpbHMiLCJiYWxhbmNlQ29sb3IiLCJiYWxhbmNlQmciLCJ0YWdTdHlsZXMiLCJjaGl0IiwibG9hbiIsInBpZ215IiwiZmllbGRzIiwidG9Mb2NhbGVTdHJpbmciLCJoaWdobGlnaHQiLCJyZXZlcnNlIiwiZmllbGQiLCJpZHgiLCJjaGl0UGF5bWVudHMiLCJwYXlfZm9yIiwicGF5bWVudCIsImxvYW5QYXltZW50cyIsInBpZ21lUGF5bWVudHMiLCJ3aW5fYW1vdW50IiwiY29tbWlzc2lvbiIsImRpdmlkZW50IiwiZGl2aWRlbnRfaGVhZCIsImF1Y3Rpb25fZGF0ZSIsIm5leHRfZGF0ZSIsInVwZGF0ZWRBdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBheW1lbnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhTW9uZXlCaWxsV2F2ZSwgRmFXaGF0c2FwcFNxdWFyZSB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgRHJvcGRvd24sIE1vZGFsIGFzIEFudE1vZGFsLCBEcmF3ZXIsIFRvb2x0aXAsIFRhZywgbWVzc2FnZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgQmFja2Ryb3BCbHVyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQmFja2Ryb3BCbHVyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhUmVjZWlwdCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCB7IEZpQ2hldnJvbkRvd24sIEZpU2VhcmNoIH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbmltcG9ydCBSZUNvbmZpcm1Nb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvUmVDb25maXJtTW9kYWxcIjtcclxuXHJcblxyXG5jb25zdCBQYXltZW50ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthY3R1YWxHcm91cHMsIHNldEFjdHVhbEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlUGF5bWVudHMsIHNldFRhYmxlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFVzZXJJZCwgc2V0U2VsZWN0ZWRVc2VySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFVzZXJzLCBzZXRGaWx0ZXJlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdmlld0xvYWRlciwgc2V0Vmlld0xvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkRW5yb2xsbWVudHMsIHNldEZpbHRlcmVkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlbnJvbGxtZW50TG9hZGluZywgc2V0RW5yb2xsbWVudExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxWaWV3LCBzZXRTaG93TW9kYWxWaWV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFZpZXdHcm91cCwgc2V0Q3VycmVudFZpZXdHcm91cF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbd2hhdHNhcHBFbmFibGUsIHNldFdoYXRzYXBwRW5hYmxlXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtwYXltZW50TW9kZSwgc2V0UGF5bWVudE1vZGVdID0gdXNlU3RhdGUoXCJjYXNoXCIpO1xyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYm9ycm93ZXJzLCBzZXRCb3Jyb3dlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaWdtZUN1c3RvbWVycywgc2V0UGlnbWVDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwYXltZW50R3JvdXBUaWNrZXRzLCBzZXRQYXltZW50R3JvdXBUaWNrZXRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbb3BlbkJhY2tkcm9wTG9hZGVyLCBzZXRPcGVuQmFja2Ryb3BMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50R3JvdXBJZCwgc2V0Q3VycmVudEdyb3VwSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW29wZW5BbnRERHJhd2VyLCBzZXRPcGVuQW50RERyYXdlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dMb2FkZXIsIHNldFNob3dMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsYXN0VGhyZWVQYXltZW50cywgc2V0TGFzdFRocmVlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93R3JvdXBQYXltZW50LCBzZXRTaG93R3JvdXBQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd0NvbmZpcm0sIHNldFNob3dDb25maXJtXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdGhpcmRQYXJ0eUVuYWJsZSwgc2V0VGhpcmRQYXJ0eUVuYWJsZV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB3aGF0c2FwcDogdHJ1ZSxcclxuICB9KTtcclxuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3ByaW50QWZ0ZXJDb25maXJtLCBzZXRQcmludEFmdGVyQ29uZmlybV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGRyb3BEb3duSXRlbXMgPSAocGF5bWVudE9iamVjdCkgPT4ge1xyXG4gICAgY29uc3QgZHJvcERvd25JdGVtTGlzdCA9IFtcclxuICAgICAge1xyXG4gICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgIDxMaW5rIHRvPXtgL3ByaW50LyR7cGF5bWVudE9iamVjdD8uX2lkfWB9IGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBcIj5cclxuICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICApLFxyXG4gICAgICB9LFxyXG5cclxuICAgICAge1xyXG4gICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVmlld01vZGFsT3BlbihwYXltZW50T2JqZWN0Py5faWQpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBWaWV3XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICB9LFxyXG4gICAgXTtcclxuXHJcbiAgICByZXR1cm4gZHJvcERvd25JdGVtTGlzdDtcclxuICB9O1xyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICBub1JlbG9hZDogZmFsc2UsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHJlbWFya3M6IFwiXCIsXHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgcmVjZWlwdF9ubzogXCJcIixcclxuICAgIHBheV9kYXRlOiB0b2RheSxcclxuICAgIGFtb3VudDogXCJcIixcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgIGFjY291bnRfdHlwZTogXCJcIixcclxuICAgIGNoZXF1ZV9udW1iZXI6IFwiXCIsXHJcbiAgICBjaGVxdWVfZGF0ZTogXCJcIixcclxuICAgIGNoZXF1ZV9iYW5rX25hbWU6IFwiXCIsXHJcbiAgICBjaGVxdWVfYmFua19icmFuY2g6IFwiXCIsXHJcbiAgICBjb2xsZWN0aW9uX3RpbWU6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9kaWZ5TWluTWF4UGF5bWVudERhdGUsIHNldE1vZGlmeU1pbk1heFBheW1lbnREYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZShuZXcgRGF0ZSgpLnNldERhdGUobmV3IERhdGUoKS5nZXREYXRlKCkgLSAyKSlcclxuICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAuc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG5cclxuICAgIGlmICh1c2VyT2JqKSB7XHJcbiAgICAgIGNvbnN0IGFkbWluQWNjZXNzUGVybWlzc2lvbnMgPVxyXG4gICAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM7XHJcblxyXG4gICAgICBpZiAoYWRtaW5BY2Nlc3NQZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50ID09PSBcInRydWVcIikge1xyXG4gICAgICAgIHNldE1vZGlmeVBheW1lbnQodHJ1ZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChhZG1pbkFjY2Vzc1Blcm1pc3Npb25zPy5lZGl0X2xpbWl0ZWRfcGF5bWVudCA9PT0gXCJ0cnVlXCIpIHtcclxuICAgICAgICBzZXRNb2RpZnlQYXltZW50KHRydWUpO1xyXG4gICAgICAgIHNldE1vZGlmeU1pbk1heFBheW1lbnREYXRlKHRydWUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaExhc3RUaHJlZVRyYW5zYWN0aW9ucyA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNldE9wZW5BbnRERHJhd2VyKHRydWUpO1xyXG4gICAgaWYgKGZvcm1EYXRhLnVzZXJfaWQgJiYgZm9ybURhdGEucGF5bWVudF9ncm91cF90aWNrZXRzKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0U2hvd0xvYWRlcih0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCJwYXltZW50L2dldC1sYXN0LW4tdHJhbnNhY3Rpb25cIiwge1xyXG4gICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgIHVzZXJfaWQ6IGZvcm1EYXRhLnVzZXJfaWQsXHJcbiAgICAgICAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogcGF5bWVudEdyb3VwVGlja2V0cyxcclxuICAgICAgICAgICAgbGltaXQ6IDMsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChyZXNwb25zZT8uZGF0YSkge1xyXG4gICAgICAgICAgc2V0TGFzdFRocmVlUGF5bWVudHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldExhc3RUaHJlZVBheW1lbnRzKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgc2V0TGFzdFRocmVlUGF5bWVudHMoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldFNob3dMb2FkZXIoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldEJvcnJvd2VycyhbXSk7XHJcbiAgICBjb25zdCBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGlmICghc2VsZWN0ZWRVc2VySWQpIHJldHVybjtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9sb2Fucy9nZXQtYm9ycm93ZXItZGV0YWlscy8ke3NlbGVjdGVkVXNlcklkfWApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5kYXRhKSB7XHJcbiAgICAgICAgICBzZXRCb3Jyb3dlcnMocmVzcG9uc2UuZGF0YS5kYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0Qm9ycm93ZXJzKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIHNldEJvcnJvd2VycyhbXSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJFcnJvciBmZXRjaGluZyBsb2FuIGRldGFpbHM6XCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMoKTtcclxuICB9LCBbc2VsZWN0ZWRVc2VySWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFBpZ21lQ3VzdG9tZXJzKFtdKTtcclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJQaWdtZURldGFpbHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGlmICghc2VsZWN0ZWRVc2VySWQpIHJldHVybjtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9waWdtZXMvZ2V0LXBpZ21lLWN1c3RvbWVyLWRldGFpbHMvJHtzZWxlY3RlZFVzZXJJZH1gKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8uZGF0YSkge1xyXG4gICAgICAgICAgc2V0UGlnbWVDdXN0b21lcnMocmVzcG9uc2UuZGF0YS5kYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0UGlnbWVDdXN0b21lcnMoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgc2V0UGlnbWVDdXN0b21lcnMoW10pO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgZmV0Y2hpbmcgcGlnbWUgZGV0YWlsczpcIiwgZXJyKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQ3VzdG9tZXJQaWdtZURldGFpbHMoKTtcclxuICB9LCBbc2VsZWN0ZWRVc2VySWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWxsQ3VzdG9tZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcInVzZXIvdmVyaWZpZWRcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2U/LmRhdGE/LmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHNldFVzZXJzKFtdKTtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBbGxDdXN0b21lcnMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICAgIHNldEFjdHVhbEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRBY3R1YWxHcm91cHMoW10pO1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcblxyXG4gICAgaWYgKCFzZWxlY3RlZFVzZXJJZCkge1xyXG4gICAgICBuZXdFcnJvcnMuY3VzdG9tZXIgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZm9ybURhdGEucGF5bWVudF9ncm91cF90aWNrZXRzKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHMgPSBcIlBsZWFzZSBzZWxlY3QgYSBncm91cCBhbmQgdGlja2V0XCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5wYXlfZGF0ZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGF5X2RhdGUgPSBcIlBheW1lbnQgZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlRmxvYXQoZm9ybURhdGEuYW1vdW50KTtcclxuICAgIGlmIChpc05hTihhbW91bnQpIHx8IGFtb3VudCA8PSAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIHBvc2l0aXZlIGFtb3VudFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJvbmxpbmVcIiAmJiAhZm9ybURhdGEudHJhbnNhY3Rpb25faWQ/LnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPVxyXG4gICAgICAgIFwiVHJhbnNhY3Rpb24gSUQgaXMgcmVxdWlyZWQgZm9yIG9ubGluZSBwYXltZW50c1wiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJjaGVxdWVcIiAmJiAhZm9ybURhdGEuY2hlcXVlX2RhdGU/LnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMuY2hlcXVlX2RhdGUgPSBcIkNoZXF1ZSBEYXRlIGlzIHJlcXVpcmVkIGZvciBjaGVxdWUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJjaGVxdWVcIiAmJiAhZm9ybURhdGEuY2hlcXVlX251bWJlcj8udHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5jaGVxdWVfbnVtYmVyID0gXCJDaGVxdWUgTnVtYmVyIGlzIHJlcXVpcmVkIGZvciBjaGVxdWUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcblxyXG4gICAgaWYgKG5hbWUgPT09IFwiYW1vdW50XCIpIHtcclxuICAgICAgLy8gQWxsb3cgZGlnaXRzICYgT05MWSBvbmUgZG90XHJcbiAgICAgIGxldCBjbGVhbmVkID0gdmFsdWUucmVwbGFjZSgvW14wLTkuXS9nLCBcIlwiKTtcclxuXHJcbiAgICAgIGNvbnN0IGRvdENvdW50ID0gKGNsZWFuZWQubWF0Y2goL1xcLi9nKSB8fCBbXSkubGVuZ3RoO1xyXG4gICAgICBpZiAoZG90Q291bnQgPiAxKSByZXR1cm47XHJcblxyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIFtuYW1lXTogY2xlYW5lZCxcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIE90aGVyIGZpZWxkc1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcblxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRBbnRTZWxlY3QgPSAodmFsdWVzKSA9PiB7XHJcbiAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKHZhbHVlcyk7XHJcbiAgfTtcclxuXHJcblxyXG5cclxuXHJcbiAgY29uc3QgZm9ybWF0SW5kaWFuTnVtYmVyID0gKHZhbHVlKSA9PiB7XHJcbiAgICBpZiAoIXZhbHVlKSByZXR1cm4gXCJcIjtcclxuXHJcbiAgICB2YWx1ZSA9IHZhbHVlLnRvU3RyaW5nKCkucmVwbGFjZSgvW14wLTkuXS9nLCBcIlwiKTtcclxuXHJcbiAgICBjb25zdCBwYXJ0cyA9IHZhbHVlLnNwbGl0KFwiLlwiKTtcclxuICAgIGNvbnN0IGludGVnZXJQYXJ0ID0gcGFydHNbMF07XHJcbiAgICBjb25zdCBkZWNpbWFsUGFydCA9IHBhcnRzWzFdID8gcGFydHNbMV0uc2xpY2UoMCwgMikgOiBcIlwiO1xyXG5cclxuICAgIGxldCBsYXN0VGhyZWUgPSBpbnRlZ2VyUGFydC5zbGljZSgtMyk7XHJcbiAgICBsZXQgb3RoZXJOdW1iZXJzID0gaW50ZWdlclBhcnQuc2xpY2UoMCwgLTMpO1xyXG5cclxuICAgIGxldCBmb3JtYXR0ZWRJbnQgPSBvdGhlck51bWJlcnNcclxuICAgICAgPyBvdGhlck51bWJlcnMucmVwbGFjZSgvXFxCKD89KFxcZHsyfSkrKD8hXFxkKSkvZywgXCIsXCIpICsgXCIsXCIgKyBsYXN0VGhyZWVcclxuICAgICAgOiBsYXN0VGhyZWU7XHJcblxyXG4gICAgcmV0dXJuIGRlY2ltYWxQYXJ0ID8gYCR7Zm9ybWF0dGVkSW50fS4ke2RlY2ltYWxQYXJ0fWAgOiBmb3JtYXR0ZWRJbnQ7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiUGFpZCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zYWN0aW9uX2RhdGVcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0IE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJvbGRfcmVjZWlwdFwiLCBoZWFkZXI6IFwiT2xkIFJlY2VpcHRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVjZWlwdFwiLCBoZWFkZXI6IFwiUmVjZWlwdFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25fdGltZVwiLCBoZWFkZXI6IFwiQ29sbGVjdGlvbiBUaW1lXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3RlZF9ieVwiLCBoZWFkZXI6IFwiQ29sbGVjdGVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBoYW5kbGVDdXN0b21lciA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgc2V0RmlsdGVyZWRFbnJvbGxtZW50cyhbXSk7XHJcbiAgICBzZXRTZWxlY3RlZFVzZXJJZCh1c2VySWQpO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZGb3JtRGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkZvcm1EYXRhLFxyXG4gICAgICB1c2VyX2lkOiB1c2VySWQsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoeyAuLi5wcmV2RGF0YSwgY3VzdG9tZXI6IFwiXCIgfSkpO1xyXG4gICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyhbXSk7XHJcbiAgICBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UodXNlcklkKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cFBheW1lbnQgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgbGV0IHVybCA9IGAvcGF5bWVudC9nZXQtcGF5bWVudHMtYnktZGF0ZXM/ZnJvbV9kYXRlPSR7dG9kYXl9JnRvX2RhdGU9JHt0b2RheX1gO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQodXJsKTtcclxuXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIWdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSkgcmV0dXJuIHt9O1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgbmFtZTogZ3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICAgIHRpY2tldDogZ3JvdXAudGlja2V0LFxyXG4gICAgICAgICAgICAgIHJlY2VpcHQ6IGdyb3VwLnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgb2xkX3JlY2VpcHQ6IGdyb3VwLm9sZF9yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIGFtb3VudDogZ3JvdXAuYW1vdW50LFxyXG4gICAgICAgICAgICAgIHBheV90eXBlOiBncm91cD8ucGF5X3R5cGUsXHJcbiAgICAgICAgICAgICAgZGF0ZTogZ3JvdXA/LnBheV9kYXRlLnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBncm91cD8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgICAgICAgY29sbGVjdGVkX2J5OlxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmNvbGxlY3RlZF9ieT8ubmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHxcclxuICAgICAgICAgICAgICAgIFwiU3VwZXIgQWRtaW5cIixcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogZHJvcERvd25JdGVtcyhncm91cCksXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0U2hvd0dyb3VwUGF5bWVudCh0cnVlKTtcclxuICAgICAgICAgIHNldFRhYmxlUGF5bWVudHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHNldFRhYmxlUGF5bWVudHMoW10pO1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIC8vIHNldFNob3dHcm91cFBheW1lbnQoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGF5bWVudE1vZGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRNb2RlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRQYXltZW50TW9kZShzZWxlY3RlZE1vZGUpO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgcGF5X3R5cGU6IHNlbGVjdGVkTW9kZSxcclxuXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOlxyXG4gICAgICAgIHNlbGVjdGVkTW9kZSA9PT0gXCJvbmxpbmVcIiB8fCBzZWxlY3RlZE1vZGUgPT09IFwib25saW5lL3VwaVwiXHJcbiAgICAgICAgICA/IHByZXZEYXRhLnRyYW5zYWN0aW9uX2lkXHJcbiAgICAgICAgICA6IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQWNjb3VudFR5cGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRNb2RlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBhY2NvdW50X3R5cGU6IHNlbGVjdGVkTW9kZSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCByZXNldEZvcm0gPSAoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFVzZXJJZChcIlwiKTtcclxuICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgc2V0UGF5bWVudE1vZGUoXCJjYXNoXCIpO1xyXG5cclxuICAgIC8vIFJlc2V0IGZvcm0gZGF0YSB0byBkZWZhdWx0ICh3aXRoIHRvZGF5J3MgZGF0ZSlcclxuICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgcmVtYXJrczogXCJcIixcclxuICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgcmVjZWlwdF9ubzogXCJcIixcclxuICAgICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogW10sXHJcbiAgICAgIGFjY291bnRfdHlwZTogXCJcIixcclxuICAgICAgY2hlcXVlX251bWJlcjogXCJcIixcclxuICAgICAgY2hlcXVlX2RhdGU6IFwiXCIsXHJcbiAgICAgIGNoZXF1ZV9iYW5rX25hbWU6IFwiXCIsXHJcbiAgICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogXCJcIixcclxuICAgICAgY29sbGVjdGlvbl90aW1lOiBcIlwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gQ2xlYXIgdmFsaWRhdGlvbiBlcnJvcnNcclxuICAgIHNldEVycm9ycyh7fSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKHByaW50RmxhZykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG4gICAgICBmb3JtRGF0YS5wYXltZW50X2dyb3VwX3RpY2tldHMgPSBwYXltZW50R3JvdXBUaWNrZXRzO1xyXG4gICAgICBmb3JtRGF0YS5hZG1pbl90eXBlID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIikpPy5faWQ7XHJcblxyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgIHdoYXRzYXBwOiB0aGlyZFBhcnR5RW5hYmxlLndoYXRzYXBwLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi9wYXltZW50L2FkZC1wYXltZW50c1wiLCBwYXlsb2FkKTtcclxuXHJcbiAgICAgIC8vIElmIHByaW50RmxhZyBpcyB0cnVlLCBvcGVuIHJlY2VpcHQgaW4gbmV3IHRhYlxyXG4gICAgICBpZiAocHJpbnRGbGFnKSB7XHJcbiAgICAgICAgY29uc3QgcGF5bWVudElkcyA9IHJlc3BvbnNlLmRhdGEuZGF0YS5tYXAoaXRlbSA9PiBpdGVtLl9pZCk7XHJcbiAgICAgICAgaWYgKHBheW1lbnRJZHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgd2luZG93Lm9wZW4oYC9wcmludC8ke3BheW1lbnRJZHNbMF19YCwgJ19ibGFuaycpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gUmVzZXQgZm9ybSBhZnRlciBzdWNjZXNzXHJcbiAgICAgIHJlc2V0Rm9ybSgpO1xyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQYXltZW50IEFkZGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBgRXJyb3Igc3VibWl0dGluZyBwYXltZW50OiAke2Vycm9yLm1lc3NhZ2V9YCxcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKGZhbHNlKTtcclxuICAgICAgc2V0U2hvd0NvbmZpcm0oZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVZpZXdNb2RhbE9wZW4gPSBhc3luYyAocGF5bWVudElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICBzZXRTaG93TW9kYWxWaWV3KHRydWUpO1xyXG4gICAgICBzZXRDdXJyZW50R3JvdXBJZChwYXltZW50SWQpO1xyXG4gICAgICBzZXRWaWV3TG9hZGVyKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9wYXltZW50L2dldC1wYXltZW50LWJ5LWlkLyR7cGF5bWVudElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50Vmlld0dyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHZpZXdpbmcgUGF5bWVudDpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldFZpZXdMb2FkZXIoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgaWYgKCF1c2VySWQpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9lbnJvbGxzL3VzZXJzLyR7dXNlcklkfWApO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LmRhdGE/Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjb25zdCB0cmFuc2Zvcm1lZCA9IHJlc3BvbnNlLmRhdGEuZGF0YS5tYXAoKGl0ZW0pID0+ICh7XHJcbiAgICAgICAgICBlbnJvbGxtZW50OiB7XHJcbiAgICAgICAgICAgIGdyb3VwOiBpdGVtLmdyb3VwX2lkLFxyXG4gICAgICAgICAgICB0aWNrZXRzOiBpdGVtLnRpY2tldHMsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgcGF5bWVudHM6IHtcclxuICAgICAgICAgICAgdG90YWxQYWlkQW1vdW50OiBpdGVtLnRvdGFsX2ludmVzdG1lbnQsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgcGF5YWJsZToge1xyXG4gICAgICAgICAgICB0b3RhbFBheWFibGU6IGl0ZW0udG90YWxfcGF5YWJsZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBwcm9maXQ6IHtcclxuICAgICAgICAgICAgdG90YWxQcm9maXQ6IGl0ZW0udG90YWxfcHJvZml0LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGF1Y3Rpb246IHtcclxuICAgICAgICAgICAgYXVjdGlvbkNvdW50OiBpdGVtLnRvdGFsX2NvdW50LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGZpcnN0QXVjdGlvbjoge1xyXG4gICAgICAgICAgICBmaXJzdERpdmlkZW50SGVhZDogaXRlbS5maXJzdF9kaXZpZGVudF9oZWFkLFxyXG4gICAgICAgICAgfSxcclxuXHJcbiAgICAgICAgICAvLyBBZGRpdGlvbmFsIGZpZWxkc1xyXG4gICAgICAgICAgZ3JvdXBfaW5zdGFsbDogaXRlbS5ncm91cF9pbnN0YWxsLFxyXG4gICAgICAgICAgdG90YWxfcGVuYWx0eTogaXRlbS50b3RhbF9wZW5hbHR5LFxyXG4gICAgICAgICAgdG90YWxfbGF0ZV9mZWU6IGl0ZW0udG90YWxfbGF0ZV9mZWUsXHJcbiAgICAgICAgICB0b3RhbF9iYWxhbmNlOiBpdGVtLnRvdGFsX2JhbGFuY2UsXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKHRyYW5zZm9ybWVkKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IHNlbGVjdGVkQ3VzdG9tZXIgPSB1c2Vycy5maW5kKFxyXG4gICAgKHVzZXIpID0+IHVzZXIuX2lkID09PSBmb3JtRGF0YS51c2VyX2lkIHx8IHVzZXIuX2lkID09PSBzZWxlY3RlZFVzZXJJZFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHNlbGVjdGVkR3JvdXBUaWNrZXRzID0gcGF5bWVudEdyb3VwVGlja2V0cy5tYXAoKGl0ZW0pID0+IHtcclxuICAgIGNvbnN0IGVucm9sbG1lbnQgPSBmaWx0ZXJlZEVucm9sbG1lbnRzLmZpbmQoKGVudHJ5KSA9PiB7XHJcbiAgICAgIGNvbnN0IGdyb3VwSWQgPSBlbnRyeT8uZW5yb2xsbWVudD8uZ3JvdXA/Ll9pZDtcclxuICAgICAgY29uc3QgdGlja2V0ID0gZW50cnk/LmVucm9sbG1lbnQ/LnRpY2tldHM7XHJcbiAgICAgIHJldHVybiBgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWAgPT09IGl0ZW07XHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoZW5yb2xsbWVudCkge1xyXG4gICAgICByZXR1cm4gYCR7ZW5yb2xsbWVudD8uZW5yb2xsbWVudD8uZ3JvdXA/Lmdyb3VwX25hbWV9IHwgJHtlbnJvbGxtZW50Py5lbnJvbGxtZW50Py50aWNrZXRzfWA7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcGlnbWUgPSBwaWdtZUN1c3RvbWVycz8uZmluZChcclxuICAgICAgKHApID0+IGBwaWdtZS0ke3AuX2lkfWAgPT09IGl0ZW1cclxuICAgICk7XHJcblxyXG4gICAgaWYgKHBpZ21lKSB7XHJcbiAgICAgIHJldHVybiBgJHtwaWdtZS5waWdtZV9pZH0gfCDigrkgJHtwaWdtZS5wYXlhYmxlX2Ftb3VudH1gO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGJvcnJvd2VyID0gYm9ycm93ZXJzPy5maW5kKFxyXG4gICAgICAoYikgPT4gYGxvYW4tJHtiLl9pZH1gID09PSBpdGVtXHJcbiAgICApO1xyXG5cclxuICAgIGlmIChib3Jyb3dlcikge1xyXG4gICAgICByZXR1cm4gYCR7Ym9ycm93ZXIubG9hbl9pZH0gfCDigrkgJHtib3Jyb3dlci5sb2FuX2Ftb3VudH1gO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBpdGVtO1xyXG4gIH0pO1xyXG5cclxuXHJcbiAgY29uc3QgY29uZmlybURhdGEgPSB7XHJcbiAgICBjdXN0b21lcl9uYW1lOiBzZWxlY3RlZEN1c3RvbWVyPy5mdWxsX25hbWUgfHwgXCJcIixcclxuICAgIGdyb3VwX3RpY2tldHM6IHNlbGVjdGVkR3JvdXBUaWNrZXRzLmpvaW4oXCIsIFwiKSxcclxuICAgIC4uLmZvcm1EYXRhLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNhbml0aXplZENvbmZpcm1EYXRhID0gT2JqZWN0LmZyb21FbnRyaWVzKFxyXG4gICAgT2JqZWN0LmVudHJpZXMoY29uZmlybURhdGEpLmZpbHRlcigoW2tleSwgdmFsdWVdKSA9PiB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAga2V5ICE9PSBcInVzZXJfaWRcIiAmJiAvLyAgcmVtb3ZlIHVzZXJfaWQgZmllbGRcclxuICAgICAgICB2YWx1ZSAhPT0gbnVsbCAmJlxyXG4gICAgICAgIHZhbHVlICE9PSB1bmRlZmluZWQgJiZcclxuICAgICAgICB2YWx1ZSAhPT0gXCJcIiAmJlxyXG4gICAgICAgICEoQXJyYXkuaXNBcnJheSh2YWx1ZSkgJiYgdmFsdWUubGVuZ3RoID09PSAwKVxyXG4gICAgICApO1xyXG4gICAgfSlcclxuICApO1xyXG4gIGNvbnN0IGhhbmRsZVJlY29uZmlybWF0aW9uID0gKGUsIHByaW50RmxhZykgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybShcImFkZEdyb3VwXCIpO1xyXG4gICAgaWYgKCFpc1ZhbGlkKSB7XHJcbiAgICAgIC8vIEFzc3VtaW5nIHlvdSBoYXZlIGFjY2VzcyB0byAnbWVzc2FnZScgZnJvbSBhbnRkIG9yIGEgY3VzdG9tIHRvYXN0XHJcbiAgICAgIGNvbnNvbGUud2FybihcIlBsZWFzZSBmaWxsIGFsbCB0aGUgcmVxdWlyZWQgZmllbGRzXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBzZXRQcmludEFmdGVyQ29uZmlybShwcmludEZsYWcpO1xyXG4gICAgc2V0U2hvd0NvbmZpcm0odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gLS0tIEhFTFBFUiBUTyBHRVQgVElDS0VUIERFVEFJTFMgRk9SIFVJIC0tLVxyXG4gIGNvbnN0IGdldFRpY2tldERldGFpbHMgPSAoaXRlbSkgPT4ge1xyXG4gICAgLy8gQ0hJVFxyXG4gICAgaWYgKGl0ZW0uc3RhcnRzV2l0aChcImNoaXQtXCIpKSB7XHJcbiAgICAgIGNvbnN0IGVucm9sbG1lbnQgPSBmaWx0ZXJlZEVucm9sbG1lbnRzLmZpbmQoKGVudHJ5KSA9PiB7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBJZCA9IGVudHJ5Py5lbnJvbGxtZW50Py5ncm91cD8uX2lkO1xyXG4gICAgICAgIGNvbnN0IHRpY2tldCA9IGVudHJ5Py5lbnJvbGxtZW50Py50aWNrZXRzO1xyXG4gICAgICAgIHJldHVybiBgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWAgPT09IGl0ZW07XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgaWYgKGVucm9sbG1lbnQpIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgdHlwZTogXCJjaGl0XCIsXHJcbiAgICAgICAgICBuYW1lOiBlbnJvbGxtZW50LmVucm9sbG1lbnQ/Lmdyb3VwPy5ncm91cF9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgICB0aWNrZXQ6IGVucm9sbG1lbnQuZW5yb2xsbWVudD8udGlja2V0cyB8fCAwLFxyXG4gICAgICAgICAgcGF5YWJsZTogZW5yb2xsbWVudC5wYXlhYmxlPy50b3RhbFBheWFibGUgfHwgMCxcclxuICAgICAgICAgIHByb2ZpdDogZW5yb2xsbWVudC5wcm9maXQ/LnRvdGFsUHJvZml0IHx8IDAsXHJcbiAgICAgICAgICB0b3RhbFBhaWQ6IGVucm9sbG1lbnQucGF5bWVudHM/LnRvdGFsUGFpZEFtb3VudCB8fCAwLFxyXG4gICAgICAgICAgZ3JvdXBfdmFsdWU6IGVucm9sbG1lbnQuZW5yb2xsbWVudD8uZ3JvdXA/Lmdyb3VwX3ZhbHVlIHx8IDAsXHJcbiAgICAgICAgICBncm91cF9pbnN0YWxsOiBlbnJvbGxtZW50LmVucm9sbG1lbnQ/Lmdyb3VwPy5ncm91cF9pbnN0YWxsIHx8IDAsXHJcbiAgICAgICAgICBhdWN0aW9uQ291bnQ6IGVucm9sbG1lbnQuYXVjdGlvbj8uYXVjdGlvbkNvdW50IHx8IDAsXHJcbiAgICAgICAgICBkaXZpZGVudEhlYWQ6IGVucm9sbG1lbnQuZmlyc3RBdWN0aW9uPy5maXJzdERpdmlkZW50SGVhZCB8fCAwLFxyXG5cclxuICAgICAgICAgIC8vIFRoZXNlIGZpZWxkcyBkb24ndCBleGlzdCBpbiB0aGUgbG9nZ2VkIHJlc3BvbnNlXHJcbiAgICAgICAgICB0b3RhbFBlbmFsdHk6IDAsXHJcbiAgICAgICAgICB0b3RhbExhdGVGZWU6IDAsXHJcbiAgICAgICAgICBiYWxhbmNlOlxyXG4gICAgICAgICAgICAoZW5yb2xsbWVudC5wYXlhYmxlPy50b3RhbFBheWFibGUgfHwgMCkgLVxyXG4gICAgICAgICAgICAoZW5yb2xsbWVudC5wYXltZW50cz8udG90YWxQYWlkQW1vdW50IHx8IDApLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC8vIFBJR01FXHJcbiAgICBlbHNlIGlmIChpdGVtLnN0YXJ0c1dpdGgoXCJwaWdtZS1cIikpIHtcclxuICAgICAgY29uc3QgcGlnbWUgPSBwaWdtZUN1c3RvbWVycz8uZmluZCgocCkgPT4gYHBpZ21lLSR7cC5faWR9YCA9PT0gaXRlbSk7XHJcbiAgICAgIGlmIChwaWdtZSkge1xyXG4gICAgICAgIC8vIEFzc3VtaW5nIHBpZ21lIGRhdGEgc3RydWN0dXJlIGhhcyBwYWlkX2Ftb3VudCBhbmQgcGF5YWJsZV9hbW91bnRcclxuICAgICAgICBjb25zdCBtYXR1cml0eV9wZXJpb2QgPSBwaWdtZS5tYXR1cml0eV9wZXJpb2Q7XHJcbiAgICAgICAgY29uc3QgcGF5YWJsZV9hbW91bnQgPSBOdW1iZXIocGlnbWUucGF5YWJsZV9hbW91bnQgfHwgMCk7XHJcbiAgICAgICAgY29uc3Qgc3RhcnRfZGF0ZSA9IHBpZ21lLnN0YXJ0X2RhdGU7XHJcbiAgICAgICAgY29uc3QgZHVyYXRpb24gPSBOdW1iZXIocGlnbWUuZHVyYXRpb24gfHwgMCk7XHJcbiAgICAgICAgY29uc3QgdG90YWxfcGFpZF9hbW91bnQgPSBOdW1iZXIocGlnbWUudG90YWxfcGFpZF9hbW91bnQgfHwgMCk7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIHR5cGU6IFwicGlnbXlcIixcclxuICAgICAgICAgIG5hbWU6IHBpZ21lLnBpZ21lX2lkLFxyXG4gICAgICAgICAgdGlja2V0OiBcIi1cIixcclxuICAgICAgICAgIG1hdHVyaXR5UGVyaW9kOiBtYXR1cml0eV9wZXJpb2QsXHJcbiAgICAgICAgICBwYXlhYmxlQW1vdW50OiBwYXlhYmxlX2Ftb3VudCxcclxuICAgICAgICAgIHN0YXJ0RGF0ZTogc3RhcnRfZGF0ZSxcclxuICAgICAgICAgIGR1cmF0aW9uOiBkdXJhdGlvbixcclxuICAgICAgICAgIHRvdGFsUGFpZDogdG90YWxfcGFpZF9hbW91bnQsXHJcbiAgICAgICAgICBwcm9maXQ6IDAsXHJcbiAgICAgICAgICBhdWN0aW9uQ291bnQ6IDAsXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLy8gTE9BTlxyXG4gICAgZWxzZSBpZiAoaXRlbS5zdGFydHNXaXRoKFwibG9hbi1cIikpIHtcclxuICAgICAgY29uc3QgYm9ycm93ZXIgPSBib3Jyb3dlcnM/LmZpbmQoKGIpID0+IGBsb2FuLSR7Yi5faWR9YCA9PT0gaXRlbSk7XHJcbiAgICAgIGlmIChib3Jyb3dlcikge1xyXG5cclxuICAgICAgICAvLyBBc3N1bWluZyBsb2FuIGRhdGEgc3RydWN0dXJlIGhhcyBwYWlkX2Ftb3VudCBhbmQgbG9hbl9hbW91bnRcclxuICAgICAgICBjb25zdCBkYWlseVBheW1lbnQgPSBib3Jyb3dlci5kYWlseV9wYXltZW50X2Ftb3VudCB8fCAwO1xyXG4gICAgICAgIGNvbnN0IGxvYW5BbW91bnQgPSBib3Jyb3dlcj8ubG9hbl9hbW91bnQgfHwgMDtcclxuICAgICAgICBjb25zdCB0b3RhbFBhaWQgPSBib3Jyb3dlcj8udG90YWxfcGF5bWVudHMgfHwgMDtcclxuICAgICAgICBjb25zdCBzdGFydERhdGUgPSBib3Jyb3dlcj8uc3RhcnRfZGF0ZVxyXG4gICAgICAgIGNvbnN0IGVuZERhdGUgPSBib3Jyb3dlcj8uZW5kX2RhdGVcclxuICAgICAgICBjb25zdCBiYWxhbmNlID0gYm9ycm93ZXI/LnJlbWFpbmluZ19sb2FuIHx8IDA7XHJcbiAgICAgICAgY29uc3QgdG90YWxMb2FuID0gYm9ycm93ZXIubG9hbl9hbW91bnQgfHwgMDtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgdHlwZTogXCJsb2FuXCIsXHJcbiAgICAgICAgICBuYW1lOiBib3Jyb3dlci5sb2FuX2lkLFxyXG4gICAgICAgICAgdGlja2V0OiBcIi1cIixcclxuICAgICAgICAgIGxvYW5BbW91bnQ6IGxvYW5BbW91bnQsXHJcbiAgICAgICAgICBkYWlseVBheW1lbnQ6IGRhaWx5UGF5bWVudCxcclxuICAgICAgICAgIHN0YXJ0RGF0ZTogc3RhcnREYXRlLFxyXG4gICAgICAgICAgZW5kRGF0ZTogZW5kRGF0ZSxcclxuICAgICAgICAgIHRvdGFsUGFpZDogdG90YWxQYWlkLFxyXG4gICAgICAgICAgYmFsYW5jZTogYmFsYW5jZSxcclxuICAgICAgICAgIHByb2ZpdDogMCxcclxuICAgICAgICAgIGF1Y3Rpb25Db3VudDogMCxcclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAge29wZW5CYWNrZHJvcExvYWRlciA/IChcclxuICAgICAgICA8QmFja2Ryb3BCbHVyTG9hZGVyIHRpdGxlPXtcInBheW1lbnQgRGF0YSBwcm9jZXNzaW5nLi4uLlwifSAvPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBtdC0xMlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPEN1c3RvbUFsZXJ0XHJcbiAgICAgICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgIG5vUmVsb2FkPXthbGVydENvbmZpZy5ub1JlbG9hZH1cclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgICAgIGlzVmlzaWJsZT17c2hvd0dyb3VwUGF5bWVudH1cclxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dHcm91cFBheW1lbnQoZmFsc2UpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTRcIj5Hcm91cCBQYXltZW50IERldGFpbHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgICB7VGFibGVQYXltZW50cyAmJiBUYWJsZVBheW1lbnRzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YT17VGFibGVQYXltZW50cy5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC52YWx1ZXMoaXRlbSkuc29tZSgodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nKHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhzZWFyY2hUZXh0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiUGF5bWVudHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXCJHcm91cCBOYW1lXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcIlRvZGF5J3NcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgUGF5bWVudHMuY3N2YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHktOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhPVwiUGF5bWVudHMgRGF0YVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e1RhYmxlUGF5bWVudHMubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbGcgcC04IG1heC13LTR4bCBteC1hdXRvIFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iLTIgYm9yZGVyLWJsdWUtOTAwIHAtMiBtYi0yIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ibHVlLTkwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEFkZCBOZXcgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtmZXRjaExhc3RUaHJlZVRyYW5zYWN0aW9uc31cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZhUmVjZWlwdCBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkxhc3QgMyBUcmFuc2FjdGlvbnM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiwgbWFyZ2luQm90dG9tOiBcIjEuNXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246IFwicmVsYXRpdmVcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCIjMWUzYThhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDYwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjAuNjI1cmVtIDEuMjVyZW1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiMXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogXCIwIDRweCA2cHggcmdiYSgwLDAsMCwwLjEpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCByZ2JhKDE0NywgNTEsIDIzNCwgMC4yKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1pbldpZHRoOiBcIjI1MHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBcImFsbCAwLjNzIGVhc2VcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuY3VycmVudFRhcmdldC5uZXh0U2libGluZy5jbGFzc0xpc3QudG9nZ2xlKFwiaGlkZGVuXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBvdmVyZmxvdzogXCJoaWRkZW5cIiwgdGV4dE92ZXJmbG93OiBcImVsbGlwc2lzXCIsIHdoaXRlU3BhY2U6IFwibm93cmFwXCIsIHBhZGRpbmdSaWdodDogXCIwLjVyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRHcm91cElkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGFjdHVhbEdyb3Vwcy5maW5kKChnKSA9PiBnLl9pZCA9PT0gc2VsZWN0ZWRHcm91cElkKT8uZ3JvdXBfbmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlNlYXJjaCBvciBTZWxlY3QgR3JvdXBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RmlDaGV2cm9uRG93biBzdHlsZT17eyB0cmFuc2l0aW9uOiBcInRyYW5zZm9ybSAwLjNzXCIgfX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBEcm9wZG93biAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvcDogXCI4NSVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b206IDEwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpblRvcDogXCIwLjVyZW1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5XaWR0aDogXCIyNTBweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiI2ZmZlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCIwLjc1cmVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiBcIjAgMTBweCAyNXB4IHJnYmEoMCwwLDAsMC4xNSlcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICNlNWU3ZWJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjAuMjVyZW0gMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleDogMTAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZCh2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVHcm91cFBheW1lbnQodmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3VmZml4SWNvbj17PEZpU2VhcmNoIHN0eWxlPXt7IGNvbG9yOiBcIiM5MzMzZWFcIiB9fSAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIGJvcmRlcjogXCJub25lXCIsIGJveFNoYWRvdzogXCJub25lXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWN0dWFsR3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVJlY29uZmlybWF0aW9ufSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRVc2VySWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake3VzZXIuZnVsbF9uYW1lfSB8ICR7dXNlci5waG9uZV9udW1iZXJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmN1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuY3VzdG9tZXJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake2Vucm9sbG1lbnRMb2FkaW5nID8gXCJvcGFjaXR5LTcwXCIgOiBcIlwifWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgJiBUaWNrZXQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlbnJvbGxtZW50TG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgbW9kZT1cIm11bHRpcGxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3Blbj17b3Blbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25Ecm9wZG93blZpc2libGVDaGFuZ2U9e3NldE9wZW59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwIHwgVGlja2V0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVBheW1lbnRBbnRTZWxlY3QodmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldE9wZW4oZmFsc2UpOyAvLyBjbG9zZSBkcm9wZG93biBhZnRlciBzZWxlY3Rpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17ZW5yb2xsbWVudExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50R3JvdXBUaWNrZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRFbnJvbGxtZW50cy5tYXAoKGVudHJ5LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9IGVudHJ5Py5lbnJvbGxtZW50Py5ncm91cD8uZ3JvdXBfbmFtZSB8fCBcIlVubmFtZWQgR3JvdXBcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBncm91cElkID0gZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5faWQgfHwgYG1pc3NpbmctJHtpbmRleH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpY2tldCA9IGVudHJ5Py5lbnJvbGxtZW50Py50aWNrZXRzIHx8IFwiVW5rbm93blwiO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cE5hbWV9IHwge3RpY2tldH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BpZ21lQ3VzdG9tZXJzPy5tYXAoKHBpZ21lKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtgcGlnbWUtJHtwaWdtZS5faWR9YH0gdmFsdWU9e2BwaWdtZS0ke3BpZ21lLl9pZH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHtwaWdtZS5waWdtZV9pZH0gfCDigrkgJHtwaWdtZS5wYXlhYmxlX2Ftb3VudH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtib3Jyb3dlcnM/Lm1hcCgoYm9ycm93ZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2Bsb2FuLSR7Ym9ycm93ZXIuX2lkfWB9IHZhbHVlPXtgbG9hbi0ke2JvcnJvd2VyLl9pZH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHtib3Jyb3dlci5sb2FuX2lkfSB8IOKCuSAke2JvcnJvd2VyLmxvYW5fYW1vdW50fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHN9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIC0tLSBORVc6IFNFTEVDVEVEIFRJQ0tFVFMgREVUQUlMUyBTRUNUSU9OIC0tLSAqL31cclxuICAgICAgICAgICAgICAgICAgICB7cGF5bWVudEdyb3VwVGlja2V0cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCBhbmltYXRlLWZhZGUtaW4tdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnRHcm91cFRpY2tldHMubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGV0YWlscyA9IGdldFRpY2tldERldGFpbHMoaXRlbSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFkZXRhaWxzKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFsYW5jZUNvbG9yID0gZGV0YWlscy5iYWxhbmNlID4gMCA/IFwidGV4dC1yZWQtNjAwXCIgOiBcInRleHQtZ3JlZW4tNjAwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFsYW5jZUJnID0gZGV0YWlscy5iYWxhbmNlID4gMCA/IFwiYmctcmVkLTUwXCIgOiBcImJnLWVtZXJhbGQtNTBcIjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRHluYW1pYyBjb2xvcnMgZm9yIHRoZSBtYWluIFR5cGUgVGFnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGFnU3R5bGVzID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hpdDogXCJiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNzAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FuOiBcImJnLXB1cnBsZS0xMDAgdGV4dC1wdXJwbGUtNzAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWdteTogXCJiZy1hbWJlci0xMDAgdGV4dC1hbWJlci03MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZmllbGRzID0gW107XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkZXRhaWxzLnR5cGUgPT09IFwiY2hpdFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZHMgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiVG90YWwgUGF5YWJsZVwiLCB2YWx1ZTogYOKCuSR7ZGV0YWlscy5wYXlhYmxlPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJUb3RhbCBQYWlkXCIsIHZhbHVlOiBg4oK5JHtkZXRhaWxzLnRvdGFsUGFpZD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiUGVuYWx0eVwiLCB2YWx1ZTogYOKCuSR7ZGV0YWlscy50b3RhbFBlbmFsdHk/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkxhdGUgRmVlXCIsIHZhbHVlOiBg4oK5JHtkZXRhaWxzLnRvdGFsTGF0ZUZlZT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiQmFsYW5jZSBEdWVcIiwgdmFsdWU6IGDigrkke2RldGFpbHMuYmFsYW5jZT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLCBoaWdobGlnaHQ6IHRydWUgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChkZXRhaWxzLnR5cGUgPT09IFwibG9hblwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZHMgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiTG9hbiBBbW91bnRcIiwgdmFsdWU6IGDigrkke2RldGFpbHMubG9hbkFtb3VudD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiU3RhcnQgRGF0ZVwiLCB2YWx1ZTogZGV0YWlscy5zdGFydERhdGU/LnNwbGl0KFwiVFwiKVswXS5zcGxpdChcIi1cIikucmV2ZXJzZSgpLmpvaW4oXCItXCIpIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiRW5kIERhdGVcIiwgdmFsdWU6IGRldGFpbHMuZW5kRGF0ZT8uc3BsaXQoXCJUXCIpWzBdLnNwbGl0KFwiLVwiKS5yZXZlcnNlKCkuam9pbihcIi1cIikgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJEYWlseSBQYXltZW50XCIsIHZhbHVlOiBg4oK5JHtkZXRhaWxzLmRhaWx5UGF5bWVudD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiVG90YWwgUGFpZFwiLCB2YWx1ZTogYOKCuSR7ZGV0YWlscy50b3RhbFBhaWQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkJhbGFuY2VcIiwgdmFsdWU6IGDigrkke2RldGFpbHMuYmFsYW5jZT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLCBoaWdobGlnaHQ6IHRydWUgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChkZXRhaWxzLnR5cGUgPT09IFwicGlnbXlcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRzID0gW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkRhaWx5IEFtb3VudFwiLCB2YWx1ZTogYOKCuSR7ZGV0YWlscy5wYXlhYmxlQW1vdW50Py50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJTdGFydCBEYXRlXCIsIHZhbHVlOiBkZXRhaWxzLnN0YXJ0RGF0ZT8uc3BsaXQoXCJUXCIpWzBdLnNwbGl0KFwiLVwiKS5yZXZlcnNlKCkuam9pbihcIi1cIikgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJEdXJhdGlvblwiLCB2YWx1ZTogYCR7ZGV0YWlscy5kdXJhdGlvbn0gbW9udGhzYCB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIlRvdGFsIFBhaWRcIiwgdmFsdWU6IGDigrkke2RldGFpbHMudG90YWxQYWlkPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsIGNvbG9yOiBcInRleHQtZ3JlZW4tNjAwXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0xMDAgYm9yZGVyLWwtNCBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIG92ZXJmbG93LWhpZGRlbiAke2RldGFpbHMuYmFsYW5jZSA+IDAgPyBcImJvcmRlci1sLXJlZC01MDBcIiA6IFwiYm9yZGVyLWwtZW1lcmFsZC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU2VjdGlvbiAxOiBQcmltYXJ5IElkZW50aXR5ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0zIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMSByb3VuZGVkLW1kIHRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgJHt0YWdTdHlsZXNbZGV0YWlscy50eXBlXSB8fCAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCd9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkZXRhaWxzLnR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCB0cnVuY2F0ZSBtYXgtdy1bMjUwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkZXRhaWxzLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2RldGFpbHMudHlwZSA9PT0gXCJjaGl0XCIgJiYgZGV0YWlscy50aWNrZXQgJiYgZGV0YWlscy50aWNrZXQgIT09IFwiLVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNjAwIGJnLWJsdWUtNTAgcHgtMiBweS0wLjUgcm91bmRlZC1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpY2tldDoge2RldGFpbHMudGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU2VjdGlvbiAyOiBTZWNvbmRhcnkgTWV0YSAoT25seSBmb3IgQ2hpdHMpICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkZXRhaWxzLnR5cGUgPT09IFwiY2hpdFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTUgbWItMSBwYi0xIGJvcmRlci1iIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMjAwIHRleHQteHMgdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cCBWYWx1ZTogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBmb250LXNlbWlib2xkXCI+e2RldGFpbHMuZ3JvdXBfdmFsdWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluc3RhbGxtZW50OiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj57ZGV0YWlscy5ncm91cF9pbnN0YWxsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNlY3Rpb24gMzogRmluYW5jaWFsIERhdGEgR3JpZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTMgZ2FwLTQgJHtkZXRhaWxzLnR5cGUgPT09IFwibG9hblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwibGc6Z3JpZC1jb2xzLTZcIiA6IFwibGc6Z3JpZC1jb2xzLTVcIn1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHMubWFwKChmaWVsZCwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGZsZXgtY29sIHJvdW5kZWQtbGcgcHgtMSBweS0xIC1teC0xIHRyYW5zaXRpb24tY29sb3JzICR7ZmllbGQuaGlnaGxpZ2h0ID8gYmFsYW5jZUJnIDogXCJob3ZlcjpiZy1ncmF5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGQubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCAke2ZpZWxkLmNvbG9yXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZmllbGQuY29sb3JcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmaWVsZC5oaWdobGlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGJhbGFuY2VDb2xvclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktODAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkLnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPFRvb2x0aXAgdGl0bGU9XCJMYXN0IDMgVHJhbnNhY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtmZXRjaExhc3RUaHJlZVRyYW5zYWN0aW9uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbGcgaG92ZXI6YmctZ3JlZW4tNzAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGYVJlY2VpcHQgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkxhc3QgMyBUcmFuc2FjdGlvbnM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+ICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC14bCBwLTYgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTRcIj5QYXltZW50IERldGFpbHM8L2g0PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFtb2RpZnlQYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17bW9kaWZ5TWluTWF4UGF5bWVudERhdGUgPyB5ZXN0ZXJkYXkgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9e21vZGlmeU1pbk1heFBheW1lbnREYXRlID8gdG9kYXkgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMxZTNhOGFdIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCBiZy1ncmF5LTUwIGZvY3VzOmJnLXdoaXRlIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMucGF5X2RhdGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1hdEluZGlhbk51bWJlcihmb3JtRGF0YS5hbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMxZTNhOGFdIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCBiZy1ncmF5LTUwIGZvY3VzOmJnLXdoaXRlIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmFtb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWyMxZTNhOGFdIHRleHQtc20gbXQtMSBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhLmFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwYXlfbW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMxZTNhOGFdIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCBiZy1ncmF5LTUwIGZvY3VzOmJnLXdoaXRlIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50TW9kZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvbmxpbmVcIj5PbmxpbmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvbmxpbmUvdXBpXCI+T25saW5lL1VQSTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNoZXF1ZVwiPkNoZXF1ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNyZWRpdCBOb3RlXCI+Q3JlZGl0IE5vdGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bW9kaWZ5UGF5bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjY291bnQgVHlwZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFjY291bnRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYWNjb3VudF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXB1cnBsZS01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IGJnLWdyYXktNTAgZm9jdXM6Ymctd2hpdGUgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQWNjb3VudFR5cGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgQWNjb3VudCBUeXBlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJzdXNwZW5zZVwiPlN1c3BlbnNlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hbW91bnQgJiYgcGF5bWVudEdyb3VwVGlja2V0cy5sZW5ndGggPiAxICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW5kaXZpZHVhbCBUaWNrZXQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgYmctZ3JheS0xMDAgY3Vyc29yLW5vdC1hbGxvd2VkIG9wYWNpdHktNzBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkluZGl2aWR1YWwgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1hdEluZGlhbk51bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoZm9ybURhdGEuYW1vdW50KSAvIHBheW1lbnRHcm91cFRpY2tldHMubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bIzFlM2E4YV0gdGV4dC1zbSBtdC0xIGl0YWxpY1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE51bWJlcihmb3JtRGF0YS5hbW91bnQpIC8gcGF5bWVudEdyb3VwVGlja2V0cy5sZW5ndGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7KHBheW1lbnRNb2RlID09PSBcIm9ubGluZVwiIHx8IHBheW1lbnRNb2RlID09PSBcIm9ubGluZS91cGlcIikgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSUQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRyYW5zYWN0aW9uIElEXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLnRyYW5zYWN0aW9uX2lkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudE1vZGUgPT09IFwiY2hlcXVlXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBtYi0zXCI+Q2hlcXVlIERldGFpbHM8L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDaGVxdWUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY2hlcXVlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQ2hlcXVlIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY2hlcXVlX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuY2hlcXVlX251bWJlcn08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY2hlcXVlX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jaGVxdWVfZGF0ZS5zcGxpdChcIlRcIilbMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIENoZXF1ZSBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMxZTNhOGFdIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCBiZy1ncmF5LTUwIGZvY3VzOmJnLXdoaXRlIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaGVxdWVfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuY2hlcXVlX2RhdGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNoZXF1ZV9iYW5rX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jaGVxdWVfYmFua19uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBCYW5rIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzFlM2E4YV0gZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IGJnLWdyYXktNTAgZm9jdXM6Ymctd2hpdGUgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9iYW5rX2JyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfYmFua19icmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jaGVxdWVfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEJhbmsgQnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMxZTNhOGFdIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCBiZy1ncmF5LTUwIGZvY3VzOmJnLXdoaXRlIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUmVtYXJrc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVtYXJrc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJyZW1hcmtzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnJlbWFya3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJlbWFya3MgaWYgYW55Li4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzFlM2E4YV0gICBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbCByZXNpemUtdmVydGljYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC90ZXh0YXJlYT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC00IGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcFNxdWFyZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCB0ZXh0LTJ4bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5XaGF0c0FwcCBOb3RpZmljYXRpb248L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXJkUGFydHlFbmFibGUud2hhdHNhcHB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JlZW4tNTAwIHJvdW5kZWQgZm9jdXM6cmluZy1ncmVlbi01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRoaXJkUGFydHlFbmFibGUoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aGF0c2FwcDogIXByZXYud2hhdHNhcHAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+U2VuZCBWaWEgV2hhdHNBcHA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtNCBtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlUmVjb25maXJtYXRpb24oZSwgdHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTcgcHktMi41IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLVsjMjU2M0VCXSB0by1bIzFFNDBBRl0gdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHNoYWRvdy1tZCBob3Zlcjpmcm9tLVsjMUQ0RUQ4XSBob3Zlcjp0by1bIzFFM0E4QV0gaG92ZXI6c2hhZG93LXhsIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNhdmUgJiBQcmludFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZVJlY29uZmlybWF0aW9uKGUsIGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNyBweS0yLjUgcm91bmRlZC14bCBiZy1bIzBGNEM4MV0gdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHNoYWRvdy1tZCBob3ZlcjpiZy1bIzBCM0I2M10gaG92ZXI6c2hhZG93LXhsIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNhdmUgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICAgICAge3Nob3dDb25maXJtICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8UmVDb25maXJtTW9kYWxcclxuICAgICAgICAgICAgICAgICAgICAgIGlzT3Blbj17c2hvd0NvbmZpcm19XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkNvbmZpcm0gUGF5bWVudCBEZXRhaWxzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e3Nhbml0aXplZENvbmZpcm1EYXRhfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DYW5jZWw9eygpID0+IHNldFNob3dDb25maXJtKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17KCkgPT4gaGFuZGxlU3VibWl0KHByaW50QWZ0ZXJDb25maXJtKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPERyYXdlclxyXG4gICAgICAgICAgICAgICAgICBjbG9zYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkZXN0cm95T25IaWRkZW5cclxuICAgICAgICAgICAgICAgICAgdGl0bGU9ezxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+TGFzdCBUaHJlZSBUcmFuc2FjdGlvbnM8L3A+fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJyaWdodFwiXHJcbiAgICAgICAgICAgICAgICAgIG9wZW49e29wZW5BbnRERHJhd2VyfVxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtzaG93TG9hZGVyfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuQW50RERyYXdlcihmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgIHdpZHRoPXs0MDB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtsYXN0VGhyZWVQYXltZW50cz8ubGVuZ3RoIDw9IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdGV4dC1sZyBweS04XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBObyBUcmFuc2FjdGlvbiBGb3VuZFxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIC0tLS0tLS0tLS0gQ0hJVCAoR1JPVVApIFRSQU5TQUNUSU9OUyAtLS0tLS0tLS0tICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgeygoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoaXRQYXltZW50cyA9IGxhc3RUaHJlZVBheW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcihwID0+ICFwLnBheV9mb3IgfHwgKHAucGF5X2Zvcj8udG9Mb3dlckNhc2UoKSAhPT0gXCJsb2FuXCIgJiYgcC5wYXlfZm9yPy50b0xvd2VyQ2FzZSgpICE9PSBcInBpZ21lXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5zbGljZSgtMyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjaGl0UGF5bWVudHMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbWQgZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMCBtYi0yXCI+TGFzdCAzIENoaXQgVHJhbnNhY3Rpb25zPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjaGl0UGF5bWVudHMubWFwKChwYXltZW50LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWN0aW9uIGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC00IHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJvcmRlci1sLTQgYm9yZGVyLWwtcHVycGxlLTUwMCByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS04MDAgdGV4dC14cyBmb250LWJvbGQgcHgtMi41IHB5LTAuNSByb3VuZGVkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2hpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtaW4tdy1bMTIwcHhdXCI+UGF5bWVudCBEYXRlOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bVwiPntwYXltZW50Py5wYXlfZGF0ZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50Lmdyb3VwX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzEyMHB4XVwiPkdyb3VwOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e3BheW1lbnQuZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC50aWNrZXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtaW4tdy1bMTIwcHhdXCI+VGlja2V0Ojwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e3BheW1lbnQ/LnRpY2tldH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtaW4tdy1bMTIwcHhdXCI+QW1vdW50Ojwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bVwiPuKCuXtwYXltZW50Py5hbW91bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzEyMHB4XVwiPlBheW1lbnQgVHlwZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57cGF5bWVudD8ucGF5X3R5cGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxMjBweF1cIj5OYW1lOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bVwiPntwYXltZW50LnVzZXJfaWQ/LmZ1bGxfbmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KSgpfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiAtLS0tLS0tLS0tIExPQU4gVFJBTlNBQ1RJT05TIC0tLS0tLS0tLS0gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICB7KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbG9hblBheW1lbnRzID0gbGFzdFRocmVlUGF5bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKHAgPT4gcC5wYXlfZm9yPy50b0xvd2VyQ2FzZSgpID09PSBcImxvYW5cIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuc2xpY2UoLTMpOyAgLy8gbGFzdCAzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsb2FuUGF5bWVudHMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbWQgZm9udC1ib2xkIHRleHQtYmx1ZS03MDAgbWItMlwiPkxhc3QgMyBMb2FuIFRyYW5zYWN0aW9uczwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9hblBheW1lbnRzLm1hcCgocGF5bWVudCwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VjdGlvbiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHAtNCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBib3JkZXItbC00IGJvcmRlci1sLWJsdWUtNTAwIHJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtODAwIHRleHQteHMgZm9udC1ib2xkIHB4LTIuNSBweS0wLjUgcm91bmRlZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExvYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzEyMHB4XVwiPlBheW1lbnQgRGF0ZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57cGF5bWVudD8ucGF5X2RhdGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTG9hbiBoYXMgbm8gZ3JvdXBfaWQvdGlja2V0IOKAkyB0aG9zZSBsaW5lcyB3b24ndCBhcHBlYXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzEyMHB4XVwiPkFtb3VudDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj7igrl7cGF5bWVudD8uYW1vdW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxMjBweF1cIj5QYXltZW50IFR5cGU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e3BheW1lbnQ/LnBheV90eXBlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtaW4tdy1bMTIwcHhdXCI+TmFtZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57cGF5bWVudC51c2VyX2lkPy5mdWxsX25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSkoKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogLS0tLS0tLS0tLSBQSUdNWSBUUkFOU0FDVElPTlMgLS0tLS0tLS0tLSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIHsoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwaWdtZVBheW1lbnRzID0gbGFzdFRocmVlUGF5bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKHAgPT4gcC5wYXlfZm9yPy50b0xvd2VyQ2FzZSgpID09PSBcInBpZ21lXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnNsaWNlKC0zKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBpZ21lUGF5bWVudHMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbWQgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwIG1iLTJcIj5MYXN0IDMgUGlnbXkgVHJhbnNhY3Rpb25zPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZVBheW1lbnRzLm1hcCgocGF5bWVudCwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VjdGlvbiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHAtNCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBib3JkZXItbC00IGJvcmRlci1sLWdyZWVuLTUwMCByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwIHRleHQteHMgZm9udC1ib2xkIHB4LTIuNSBweS0wLjUgcm91bmRlZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBpZ215XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxMjBweF1cIj5QYXltZW50IERhdGU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e3BheW1lbnQ/LnBheV9kYXRlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBpZ21lIGFsc28gaGFzIG5vIGdyb3VwL3RpY2tldCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtaW4tdy1bMTIwcHhdXCI+QW1vdW50Ojwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bVwiPuKCuXtwYXltZW50Py5hbW91bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzEyMHB4XVwiPlBheW1lbnQgVHlwZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57cGF5bWVudD8ucGF5X3R5cGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxMjBweF1cIj5OYW1lOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bVwiPntwYXltZW50LnVzZXJfaWQ/LmZ1bGxfbmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KSgpfVxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9EcmF3ZXI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxBbnRNb2RhbFxyXG4gICAgICAgICAgICAgICAgb3Blbj17c2hvd01vZGFsVmlld31cclxuICAgICAgICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRTaG93TW9kYWxWaWV3KGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFZpZXcoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgb25Paz17KCkgPT4gc2V0U2hvd01vZGFsVmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBvblJlbG9hZD17KCkgPT4gaGFuZGxlVmlld01vZGFsT3BlbihjdXJyZW50R3JvdXBJZCl9XHJcbiAgICAgICAgICAgICAgICBmb290ZXI9ezxkaXY+PC9kaXY+fVxyXG4gICAgICAgICAgICAgICAgbG9hZGluZz17dmlld0xvYWRlcn1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi00XCI+UGF5bWVudCBEZXRhaWxzPC9oMz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWdyYXktMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxODBweF1cIj5Hcm91cDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bVwiPntjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtaW4tdy1bMTgwcHhdXCI+R3JvdXAgVmFsdWU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57Y3VycmVudFZpZXdHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxODBweF1cIj5Hcm91cCBJbnN0YWxsbWVudDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bVwiPntjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfaW5zdGFsbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtaW4tdy1bMTgwcHhdXCI+VXNlcjo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZX0gfCBUaWNrZXQ6IHtjdXJyZW50Vmlld0dyb3VwPy50aWNrZXR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzE4MHB4XVwiPkJpZCBBbW91bnQ6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgLSBjdXJyZW50Vmlld0dyb3VwPy53aW5fYW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gY3VycmVudFZpZXdHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlIC0gY3VycmVudFZpZXdHcm91cD8ud2luX2Ftb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzE4MHB4XVwiPkNvbW1pc3Npb246PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57Y3VycmVudFZpZXdHcm91cD8uY29tbWlzc2lvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtaW4tdy1bMTgwcHhdXCI+V2lubmluZyBBbW91bnQ6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57Y3VycmVudFZpZXdHcm91cD8ud2luX2Ftb3VudH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtaW4tdy1bMTgwcHhdXCI+RGl2aWRlbnQ6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57Y3VycmVudFZpZXdHcm91cD8uZGl2aWRlbnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzE4MHB4XVwiPkRpdmlkZW50IHBlciBIZWFkOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e2N1cnJlbnRWaWV3R3JvdXA/LmRpdmlkZW50X2hlYWR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzE4MHB4XVwiPk5leHQgUGF5YWJsZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bVwiPntjdXJyZW50Vmlld0dyb3VwPy5wYXlhYmxlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxODBweF1cIj5BdWN0aW9uIERhdGU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57Y3VycmVudFZpZXdHcm91cD8uYXVjdGlvbl9kYXRlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxODBweF1cIj5OZXh0IERhdGU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57Y3VycmVudFZpZXdHcm91cD8ubmV4dF9kYXRlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxODBweF1cIj5DcmVhdGVkIEF0Ojwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e2N1cnJlbnRWaWV3R3JvdXA/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxODBweF1cIj5VcGRhdGVkIEF0Ojwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e2N1cnJlbnRWaWV3R3JvdXA/LnVwZGF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1pbi13LVsxODBweF1cIj5DaGVxdWUgTnVtYmVyOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e2N1cnJlbnRWaWV3R3JvdXA/LmNoZXF1ZV9udW1iZXJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzE4MHB4XVwiPkNoZXF1ZSBEYXRlOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e2N1cnJlbnRWaWV3R3JvdXA/LmNoZXF1ZV9kYXRlPy5zcGxpdChcIlRcIilbMF19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzE4MHB4XVwiPkNoZXF1ZSBCYW5rIE5hbWU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj57Y3VycmVudFZpZXdHcm91cD8uY2hlcXVlX2JhbmtfbmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWluLXctWzE4MHB4XVwiPkNoZXF1ZSBCYW5rIEJyYW5jaCBOYW1lOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtXCI+e2N1cnJlbnRWaWV3R3JvdXA/LmNoZXF1ZV9iYW5rX2JyYW5jaH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9BbnRNb2RhbD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYXltZW50OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9QYXltZW50LmpzeCJ9