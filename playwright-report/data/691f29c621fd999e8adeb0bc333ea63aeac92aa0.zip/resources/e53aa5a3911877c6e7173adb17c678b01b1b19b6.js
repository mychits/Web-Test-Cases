import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UnApprovedCustomerReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Input, Select, Dropdown, DatePicker } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import handleEnrollmentRequestPrint from "/src/components/printFormats/enrollmentRequestPrint.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const { RangePicker } = DatePicker;
const UnApprovedCustomerReport = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [TableUsers, setTableUsers] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const now = /* @__PURE__ */ new Date();
  const todayString = now.toISOString().split("T")[0];
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedDate, setSelectedDate] = useState(todayString);
  const [showFilterField, setShowFilterField] = useState(false);
  const groupOptions = [
    { label: "All", value: "All" },
    // ✅ NEW OPTION
    { label: "Today", value: "Today" },
    { label: "Yesterday", value: "Yesterday" },
    { label: "This Month", value: "ThisMonth" },
    { label: "Last Month", value: "LastMonth" },
    { label: "This Year", value: "ThisYear" },
    { label: "Custom", value: "Custom" }
  ];
  const formatDate = (date) => date.toLocaleDateString("en-CA");
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    if (value === "All") {
      setSelectedFromDate(null);
      setSelectedDate(null);
      return;
    }
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/user/approval-status/false");
        setUsers(response.data);
        const formattedData = response.data.map((group, index) => ({
          _id: group._id,
          id: index + 1,
          name: group.full_name,
          phone_number: group.phone_number,
          createdAt: group.createdAt?.split("T")[0],
          address: group.address?.replaceAll(",", " "),
          pincode: group.pincode,
          customer_id: group.customer_id,
          collection_area: group.collection_area?.route_name,
          approval_status: group.approval_status === "true" ? /* @__PURE__ */ jsxDEV("div", { className: "inline-block px-3 py-1 text-sm font-medium text-green-800 bg-green-100 rounded-full shadow-sm", children: "Approved" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 566,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "inline-block px-3 py-1 text-sm font-medium text-red-800 bg-red-100 rounded-full shadow-sm", children: "Pending" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 570,
            columnNumber: 11
          }, this),
          approval_status_raw: group?.approval_status,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        onClick: () => handleEnrollmentRequestPrint(group?._id),
                        className: "text-violet-600",
                        children: "Print"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                        lineNumber: 584,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 596,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 577,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 576,
            columnNumber: 11
          }, this)
        }));
        setTableUsers(formattedData);
      } catch (error) {
        console.error("Error fetching user data:", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUsers();
  }, [reloadTrigger]);
  const filteredByDate = selectedLabel === "All" ? TableUsers : TableUsers.filter((user) => {
    const joinDate = new Date(user.createdAt);
    const from = new Date(selectedFromDate);
    const to = new Date(selectedDate);
    return joinDate >= from && joinDate <= to;
  });
  const totalUnapprovedCustomers = filteredByDate.length;
  const collectionAreaCount = {};
  filteredByDate.forEach((item) => {
    const key = item.collection_area || "Unassigned";
    collectionAreaCount[key] = (collectionAreaCount[key] || 0) + 1;
  });
  const calculateDaysBetween = () => {
    if (selectedLabel === "All") return 365;
    const fromDate = new Date(selectedFromDate);
    const toDate = new Date(selectedDate);
    const diffTime = Math.abs(toDate - fromDate);
    const diffDays = Math.ceil(diffTime / (1e3 * 60 * 60 * 24)) + 1;
    return diffDays;
  };
  const avgCustomersPerDay = calculateDaysBetween() > 0 ? (totalUnapprovedCustomers / calculateDaysBetween()).toFixed(1) : 0;
  const todayUnapproved = TableUsers.filter((user) => {
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    return user.createdAt === today;
  }).length;
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "approval_status", header: "Approval Status" },
    { key: "customer_id", header: "Customer Id" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "createdAt", header: "Joined On" },
    { key: "action", header: "Action" }
  ];
  const unapprovedcolumns = [
    { key: "id", header: "SL. NO" },
    { key: "approval_status_raw", header: "Approval Status" },
    { key: "customer_id", header: "Customer Id" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "createdAt", header: "Joined On" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
        lineNumber: 676,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
        lineNumber: 680,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-6", children: "Report - Unverified Customers" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
        lineNumber: 689,
        columnNumber: 11
      }, this),
      filteredByDate.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4 text-gray-800", children: "Summary" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
          lineNumber: 696,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-violet-600 to-violet-600 text-white p-6 rounded-xl shadow-lg mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-red-100 text-sm uppercase tracking-wide", children: "Total Unapproved Customers" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 702,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold mt-1", children: totalUnapprovedCustomers }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 705,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-red-100 text-sm mt-1", children: selectedLabel === "All" ? "All Time" : selectedLabel }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 706,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 701,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white bg-opacity-20 p-3 rounded-full", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-8 w-8", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 712,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 711,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 710,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
          lineNumber: 700,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
          lineNumber: 699,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800", children: "Collection Areas" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 724,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "bg-violet-100 text-violet-800 text-xs font-medium px-2.5 py-0.5 rounded", children: [
                Object.keys(collectionAreaCount).length,
                " Areas"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 725,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 723,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
              Object.entries(collectionAreaCount).sort((a, b) => b[1] - a[1]).slice(0, 5).map(
                ([area, count]) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-2 h-2 bg-violet-500 rounded-full mr-3" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                      lineNumber: 736,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm truncate max-w-xs", children: area }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                      lineNumber: 737,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                    lineNumber: 735,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-24 bg-gray-200 rounded-full h-2 mr-3", children: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "bg-violet-500 h-2 rounded-full",
                        style: { width: `${count / totalUnapprovedCustomers * 100}%` }
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                        lineNumber: 741,
                        columnNumber: 31
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                      lineNumber: 740,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 w-8 text-right", children: count }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                      lineNumber: 746,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                    lineNumber: 739,
                    columnNumber: 27
                  }, this)
                ] }, area, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                  lineNumber: 734,
                  columnNumber: 19
                }, this)
              ),
              Object.keys(collectionAreaCount).length > 5 && /* @__PURE__ */ jsxDEV("div", { className: "text-center pt-2", children: /* @__PURE__ */ jsxDEV("button", { className: "text-violet-600 text-sm font-medium", children: "View All Areas" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 752,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 751,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 729,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 722,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800", children: "Today's Unapproved" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 761,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded", children: [
                todayUnapproved,
                " New"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 762,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 760,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-4", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-5xl font-bold text-red-600", children: todayUnapproved }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 768,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm mt-2", children: "Customers awaiting approval today" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 769,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 767,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 766,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 759,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
          lineNumber: 719,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-full bg-purple-100 text-purple-600 mr-4", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-6 w-6", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 781,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 780,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 779,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Selected Period" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 785,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: selectedLabel === "All" ? "All Time" : selectedLabel }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 786,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 784,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 778,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 777,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-full bg-amber-100 text-amber-600 mr-4", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-6 w-6", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 795,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 794,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 793,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Avg. Unapproved/Day" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 799,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: avgCustomersPerDay }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 800,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 798,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 792,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 791,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-full bg-red-100 text-red-600 mr-4", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-6 w-6", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 809,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 808,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 807,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Pending Approval Rate" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 813,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: users.length > 0 ? `${(totalUnapprovedCustomers / users.length * 100).toFixed(1)}%` : "0%" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 814,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 812,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 806,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 805,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
          lineNumber: 776,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
        lineNumber: 695,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-6 flex flex-wrap gap-6 items-end", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Filter" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 829,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              popupMatchSelectWidth: false,
              onChange: handleSelectFilter,
              value: selectedLabel,
              placeholder: "Search Or Select Filter",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              className: "w-full max-w-xs h-11",
              children: groupOptions.map(
                (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                  lineNumber: 845,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 830,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
          lineNumber: 828,
          columnNumber: 13
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { children: "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 855,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: selectedFromDate,
                onChange: (e) => setSelectedFromDate(e.target.value),
                className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full max-w-xs"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 856,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 854,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { children: "To Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
              lineNumber: 864,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: selectedDate,
                onChange: (e) => setSelectedDate(e.target.value),
                className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full max-w-xs"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
                lineNumber: 865,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
            lineNumber: 863,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
          lineNumber: 853,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
        lineNumber: 827,
        columnNumber: 11
      }, this),
      filteredByDate?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          catcher: "_id",
          data: filterOption(filteredByDate, searchText),
          columns,
          exportCols: unapprovedcolumns,
          exportedPdfName: "UnApproved Customers",
          exportedFileName: `UnApproved Customers.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
          lineNumber: 877,
          columnNumber: 11
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          failure: filteredByDate.length <= 0,
          data: "Customer Data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
          lineNumber: 886,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
      lineNumber: 688,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
    lineNumber: 675,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx",
    lineNumber: 674,
    columnNumber: 5
  }, this);
};
_s(UnApprovedCustomerReport, "cMVhtZ3rPMSIBORXjoCQwWYb5gQ=");
_c = UnApprovedCustomerReport;
export default UnApprovedCustomerReport;
var _c;
$RefreshReg$(_c, "UnApprovedCustomerReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomerReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcWpCYyxTQTRHVixVQTVHVTsyQkFyakJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsT0FBT0MsUUFBUUMsVUFBVUMsa0JBQWtCO0FBQ3BELFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0Msa0NBQWtDO0FBQ3pDLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxpQkFBaUI7QUFDMUIsTUFBTSxFQUFFQyxZQUFZLElBQUlSO0FBa2N4QixNQUFNUywyQkFBMkJBLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXBCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQixZQUFZQyxhQUFhLElBQUl0QixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDdUIsWUFBWUMsYUFBYSxJQUFJeEIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3lCLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyQixlQUFlQyxnQkFBZ0IsSUFBSTVCLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUM2QixhQUFhQyxjQUFjLElBQUk5QixTQUFTO0FBQUEsSUFDN0MrQixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFHRCxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJbkMsU0FBUyxPQUFPO0FBQzFELFFBQU1vQyxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFFBQU1DLGNBQWNGLElBQUlHLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNsRCxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUkxQyxTQUFTc0MsV0FBVztBQUNwRSxRQUFNLENBQUNLLGNBQWNDLGVBQWUsSUFBSTVDLFNBQVNzQyxXQUFXO0FBQzVELFFBQU0sQ0FBQ08saUJBQWlCQyxrQkFBa0IsSUFBSTlDLFNBQVMsS0FBSztBQUc1RCxRQUFNK0MsZUFBZTtBQUFBLElBQ25CLEVBQUVDLE9BQU8sT0FBT0MsT0FBTyxNQUFNO0FBQUE7QUFBQSxJQUM3QixFQUFFRCxPQUFPLFNBQVNDLE9BQU8sUUFBUTtBQUFBLElBQ2pDLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxZQUFZO0FBQUEsSUFDekMsRUFBRUQsT0FBTyxjQUFjQyxPQUFPLFlBQVk7QUFBQSxJQUMxQyxFQUFFRCxPQUFPLGNBQWNDLE9BQU8sWUFBWTtBQUFBLElBQzFDLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxXQUFXO0FBQUEsSUFDeEMsRUFBRUQsT0FBTyxVQUFVQyxPQUFPLFNBQVM7QUFBQSxFQUFDO0FBR3RDLFFBQU1DLGFBQWFBLENBQUNDLFNBQVNBLEtBQUtDLG1CQUFtQixPQUFPO0FBRTVELFFBQU1DLHFCQUFxQkEsQ0FBQ0osVUFBVTtBQUNwQ2QscUJBQWlCYyxLQUFLO0FBQ3RCSCx1QkFBbUIsS0FBSztBQUV4QixVQUFNUSxRQUFRLG9CQUFJakIsS0FBSztBQUV2QixRQUFJWSxVQUFVLE9BQU87QUFFbkJQLDBCQUFvQixJQUFJO0FBQ3hCRSxzQkFBZ0IsSUFBSTtBQUNwQjtBQUFBLElBQ0Y7QUFFQSxRQUFJSyxVQUFVLFNBQVM7QUFDckIsWUFBTU0sWUFBWUwsV0FBV0ksS0FBSztBQUNsQ1osMEJBQW9CYSxTQUFTO0FBQzdCWCxzQkFBZ0JXLFNBQVM7QUFBQSxJQUMzQixXQUFXTixVQUFVLGFBQWE7QUFDaEMsWUFBTU8sWUFBWSxJQUFJbkIsS0FBS2lCLEtBQUs7QUFDaENFLGdCQUFVQyxRQUFRRCxVQUFVRSxRQUFRLElBQUksQ0FBQztBQUN6QyxZQUFNSCxZQUFZTCxXQUFXTSxTQUFTO0FBQ3RDZCwwQkFBb0JhLFNBQVM7QUFDN0JYLHNCQUFnQlcsU0FBUztBQUFBLElBQzNCLFdBQVdOLFVBQVUsYUFBYTtBQUNoQyxZQUFNVSxRQUFRLElBQUl0QixLQUFLaUIsTUFBTU0sWUFBWSxHQUFHTixNQUFNTyxTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUl6QixLQUFLaUIsTUFBTU0sWUFBWSxHQUFHTixNQUFNTyxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFbkIsMEJBQW9CUSxXQUFXUyxLQUFLLENBQUM7QUFDckNmLHNCQUFnQk0sV0FBV1ksR0FBRyxDQUFDO0FBQUEsSUFDakMsV0FBV2IsVUFBVSxhQUFhO0FBQ2hDLFlBQU1VLFFBQVEsSUFBSXRCLEtBQUtpQixNQUFNTSxZQUFZLEdBQUdOLE1BQU1PLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbkUsWUFBTUMsTUFBTSxJQUFJekIsS0FBS2lCLE1BQU1NLFlBQVksR0FBR04sTUFBTU8sU0FBUyxHQUFHLENBQUM7QUFDN0RuQiwwQkFBb0JRLFdBQVdTLEtBQUssQ0FBQztBQUNyQ2Ysc0JBQWdCTSxXQUFXWSxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXYixVQUFVLFlBQVk7QUFDL0IsWUFBTVUsUUFBUSxJQUFJdEIsS0FBS2lCLE1BQU1NLFlBQVksR0FBRyxHQUFHLENBQUM7QUFDaEQsWUFBTUUsTUFBTSxJQUFJekIsS0FBS2lCLE1BQU1NLFlBQVksR0FBRyxJQUFJLEVBQUU7QUFDaERsQiwwQkFBb0JRLFdBQVdTLEtBQUssQ0FBQztBQUNyQ2Ysc0JBQWdCTSxXQUFXWSxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXYixVQUFVLFVBQVU7QUFDN0JILHlCQUFtQixJQUFJO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBRUEsUUFBTWlCLDRCQUE0QkEsQ0FBQ0MsTUFBTTtBQUN2QyxVQUFNLEVBQUVmLE1BQU0sSUFBSWUsRUFBRUM7QUFDcEJ6QyxrQkFBY3lCLEtBQUs7QUFBQSxFQUNyQjtBQUdBbEQsWUFBVSxNQUFNO0FBQ2QsVUFBTW1FLGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0Z4QyxxQkFBYSxJQUFJO0FBQ2pCLGNBQU15QyxXQUFXLE1BQU1oRSxJQUFJaUUsSUFBSSw2QkFBNkI7QUFDNURoRCxpQkFBUytDLFNBQVNFLElBQUk7QUFFdEIsY0FBTUMsZ0JBQWdCSCxTQUFTRSxLQUFLRSxJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxVQUN6REMsS0FBS0YsTUFBTUU7QUFBQUEsVUFDWEMsSUFBSUYsUUFBUTtBQUFBLFVBQ1pHLE1BQU1KLE1BQU1LO0FBQUFBLFVBQ1pDLGNBQWNOLE1BQU1NO0FBQUFBLFVBQ3BCQyxXQUFXUCxNQUFNTyxXQUFXdkMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFVBQ3hDd0MsU0FBU1IsTUFBTVEsU0FBU0MsV0FBVyxLQUFLLEdBQUc7QUFBQSxVQUMzQ0MsU0FBU1YsTUFBTVU7QUFBQUEsVUFDZkMsYUFBYVgsTUFBTVc7QUFBQUEsVUFDbkJDLGlCQUFpQlosTUFBTVksaUJBQWlCQztBQUFBQSxVQUN4Q0MsaUJBQ0VkLE1BQU1jLG9CQUFvQixTQUN4Qix1QkFBQyxTQUFJLFdBQVUsaUdBQWdHLHdCQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDZGQUE0Rix1QkFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUVDLHFCQUFxQmYsT0FBT2M7QUFBQUEsVUFDbENFLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLENBQUMsT0FBTztBQUFBLGNBQ2pCLE1BQU07QUFBQSxnQkFDSkMsT0FBTztBQUFBLGtCQUNMO0FBQUEsb0JBQ0VDLEtBQUs7QUFBQSxvQkFDTDFDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsU0FBUyxNQUFNbkMsNkJBQTZCMkQsT0FBT0UsR0FBRztBQUFBLHdCQUN0RCxXQUFVO0FBQUEsd0JBQWlCO0FBQUE7QUFBQSxzQkFGN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxnQkFBQztBQUFBLGNBRUw7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBO0FBQUEsWUFuQmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW9CQSxLQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFFBRUosRUFBRTtBQUNGcEQsc0JBQWNnRCxhQUFhO0FBQUEsTUFDN0IsU0FBU3FCLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sNkJBQTZCQSxNQUFNM0QsT0FBTztBQUFBLE1BQzFELFVBQUM7QUFDQ04scUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBd0MsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDdkMsYUFBYSxDQUFDO0FBR2xCLFFBQU1rRSxpQkFDSjNELGtCQUFrQixRQUNkYixhQUNBQSxXQUFXeUUsT0FBTyxDQUFDQyxTQUFTO0FBQzFCLFVBQU1DLFdBQVcsSUFBSTNELEtBQUswRCxLQUFLaEIsU0FBUztBQUN4QyxVQUFNa0IsT0FBTyxJQUFJNUQsS0FBS0ksZ0JBQWdCO0FBQ3RDLFVBQU15RCxLQUFLLElBQUk3RCxLQUFLTSxZQUFZO0FBQ2hDLFdBQU9xRCxZQUFZQyxRQUFRRCxZQUFZRTtBQUFBQSxFQUN6QyxDQUFDO0FBR1AsUUFBTUMsMkJBQTJCTixlQUFlTztBQUdoRCxRQUFNQyxzQkFBc0IsQ0FBQztBQUM3QlIsaUJBQWVTLFFBQVEsQ0FBQ0MsU0FBUztBQUMvQixVQUFNYixNQUFNYSxLQUFLbkIsbUJBQW1CO0FBQ3BDaUIsd0JBQW9CWCxHQUFHLEtBQUtXLG9CQUFvQlgsR0FBRyxLQUFLLEtBQUs7QUFBQSxFQUMvRCxDQUFDO0FBR0QsUUFBTWMsdUJBQXVCQSxNQUFNO0FBQ2pDLFFBQUl0RSxrQkFBa0IsTUFBTyxRQUFPO0FBRXBDLFVBQU11RSxXQUFXLElBQUlwRSxLQUFLSSxnQkFBZ0I7QUFDMUMsVUFBTWlFLFNBQVMsSUFBSXJFLEtBQUtNLFlBQVk7QUFDcEMsVUFBTWdFLFdBQVdDLEtBQUtDLElBQUlILFNBQVNELFFBQVE7QUFDM0MsVUFBTUssV0FBV0YsS0FBS0csS0FBS0osWUFBWSxNQUFPLEtBQUssS0FBSyxHQUFHLElBQUk7QUFDL0QsV0FBT0c7QUFBQUEsRUFDVDtBQUdBLFFBQU1FLHFCQUFxQlIscUJBQXFCLElBQUksS0FDL0NMLDJCQUEyQksscUJBQXFCLEdBQUdTLFFBQVEsQ0FBQyxJQUM3RDtBQUdKLFFBQU1DLGtCQUFrQjdGLFdBQVd5RSxPQUFPLENBQUFDLFNBQVE7QUFDaEQsVUFBTXpDLFNBQVEsb0JBQUlqQixLQUFLLEdBQUVFLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNuRCxXQUFPdUQsS0FBS2hCLGNBQWN6QjtBQUFBQSxFQUM1QixDQUFDLEVBQUU4QztBQUVILFFBQU1lLFVBQVU7QUFBQSxJQUNkLEVBQUV6QixLQUFLLE1BQU0wQixRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFMUIsS0FBSyxtQkFBbUIwQixRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUUxQixLQUFLLGVBQWUwQixRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFMUIsS0FBSyxRQUFRMEIsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFMUIsS0FBSyxnQkFBZ0IwQixRQUFRLHdCQUF3QjtBQUFBLElBQ3ZELEVBQUUxQixLQUFLLGFBQWEwQixRQUFRLFlBQVk7QUFBQSxJQUN4QyxFQUFFMUIsS0FBSyxVQUFVMEIsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUVuQyxRQUFNQyxvQkFBb0I7QUFBQSxJQUMxQixFQUFFM0IsS0FBSyxNQUFNMEIsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRTFCLEtBQUssdUJBQXVCMEIsUUFBUSxrQkFBa0I7QUFBQSxJQUN4RCxFQUFFMUIsS0FBSyxlQUFlMEIsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRTFCLEtBQUssUUFBUTBCLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRTFCLEtBQUssZ0JBQWdCMEIsUUFBUSx3QkFBd0I7QUFBQSxJQUN2RCxFQUFFMUIsS0FBSyxhQUFhMEIsUUFBUSxZQUFZO0FBQUEsSUFDeEMsRUFBRTFCLEtBQUssVUFBVTBCLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsU0FDRSxtQ0FDRSxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyw2QkFBNkJyRDtBQUFBQSxRQUM3QixZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNbEMsWUFBWUk7QUFBQUEsUUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsUUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUN3RixVQUFVLEVBQUUsR0FBR0EsTUFBTXZGLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBRUgsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtCQUE4Qiw2Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFHQzhELGVBQWVPLFNBQVMsS0FDdkIsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNENBQTJDLHVCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFHaEUsdUJBQUMsU0FBSSxXQUFVLDJGQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsZ0RBQStDLDBDQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsMkJBQTJCRCxzQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQSxZQUNqRSx1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZqRSw0QkFBa0IsUUFBUSxhQUFhQSxpQkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiLGlDQUFDLFNBQUksT0FBTSw4QkFBNkIsV0FBVSxXQUFVLE1BQUssUUFBTyxTQUFRLGFBQVksUUFBTyxnQkFDakcsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFhLEdBQUcsR0FBRSwwSUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMk0sS0FEN007QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsOENBR2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLGdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRTtBQUFBLGNBQ3BFLHVCQUFDLFVBQUssV0FBVSwyRUFDYnFGO0FBQUFBLHVCQUFPQyxLQUFLbkIsbUJBQW1CLEVBQUVEO0FBQUFBLGdCQUFPO0FBQUEsbUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDWm1CO0FBQUFBLHFCQUFPRSxRQUFRcEIsbUJBQW1CLEVBQ2hDcUIsS0FBSyxDQUFDQyxHQUFHQyxNQUFNQSxFQUFFLENBQUMsSUFBSUQsRUFBRSxDQUFDLENBQUMsRUFDMUJFLE1BQU0sR0FBRyxDQUFDLEVBQ1Z0RDtBQUFBQSxnQkFBSSxDQUFDLENBQUN1RCxNQUFNQyxLQUFLLE1BQ2hCLHVCQUFDLFNBQWUsV0FBVSxxQ0FDeEI7QUFBQSx5Q0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsNkNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUQ7QUFBQSxvQkFDekQsdUJBQUMsVUFBSyxXQUFVLDJDQUEyQ0Qsa0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdFO0FBQUEsdUJBRmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLE9BQU8sRUFBRUUsT0FBTyxHQUFJRCxRQUFRNUIsMkJBQTRCLEdBQUcsSUFBSTtBQUFBO0FBQUEsc0JBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxVQUFLLFdBQVUsOENBQThDNEIsbUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9FO0FBQUEsdUJBUHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxxQkFiUUQsTUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsY0FDRDtBQUFBLGNBQ0ZQLE9BQU9DLEtBQUtuQixtQkFBbUIsRUFBRUQsU0FBUyxLQUN6Qyx1QkFBQyxTQUFJLFdBQVUsb0JBQ2IsaUNBQUMsWUFBTyxXQUFVLHVDQUFzQyw4QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0UsS0FEeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLGVBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0NBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLGtDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGNBQ3RFLHVCQUFDLFVBQUssV0FBVSxxRUFDYmM7QUFBQUE7QUFBQUEsZ0JBQWdCO0FBQUEsbUJBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsbUNBQW1DQSw2QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxjQUNoRSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLGlEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRTtBQUFBLGlCQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLGFBckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzREE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSw0REFDYixpQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsdURBQ2IsaUNBQUMsU0FBSSxPQUFNLDhCQUE2QixXQUFVLFdBQVUsTUFBSyxRQUFPLFNBQVEsYUFBWSxRQUFPLGdCQUNqRyxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLDRGQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2SixLQUQvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSx5QkFBd0IsK0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9EO0FBQUEsY0FDcEQsdUJBQUMsT0FBRSxXQUFVLCtCQUErQmhGLDRCQUFrQixRQUFRLGFBQWFBLGlCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRztBQUFBLGlCQUZuRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNiLGlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxxREFDYixpQ0FBQyxTQUFJLE9BQU0sOEJBQTZCLFdBQVUsV0FBVSxNQUFLLFFBQU8sU0FBUSxhQUFZLFFBQU8sZ0JBQ2pHLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBYSxHQUFHLEdBQUUsaURBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtILEtBRHBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLHlCQUF3QixtQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0Q7QUFBQSxjQUN4RCx1QkFBQyxPQUFFLFdBQVUsK0JBQStCOEUsZ0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsaUJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2IsaUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlEQUNiLGlDQUFDLFNBQUksT0FBTSw4QkFBNkIsV0FBVSxXQUFVLE1BQUssUUFBTyxTQUFRLGFBQVksUUFBTyxnQkFDakcsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFhLEdBQUcsR0FBRSxvQ0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUcsS0FEdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUseUJBQXdCLHFDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGNBQzFELHVCQUFDLE9BQUUsV0FBVSwrQkFDVjdGLGdCQUFNaUYsU0FBUyxJQUNaLElBQUtELDJCQUEyQmhGLE1BQU1pRixTQUFVLEtBQUthLFFBQVEsQ0FBQyxDQUFDLE1BQy9ELFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLGFBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4Q0E7QUFBQSxXQS9IRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0lBO0FBQUEsTUFJRix1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxzQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFhO0FBQUEsVUFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLHVCQUF1QjtBQUFBLGNBQ3ZCLFVBQVU1RDtBQUFBQSxjQUNWLE9BQU9uQjtBQUFBQSxjQUNQLGFBQVk7QUFBQSxjQUNaLGNBQWMsQ0FBQytGLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsY0FFakMsV0FBVTtBQUFBLGNBRVR0Rix1QkFBYXdCO0FBQUFBLGdCQUFJLENBQUNnRSxTQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBK0IsT0FBT0EsS0FBS3RGLE9BQ3pDc0YsZUFBS3ZGLFNBRFl1RixLQUFLdEYsT0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBLFlBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CQTtBQUFBLGFBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxRQUVDSixtQkFDQyx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLHlCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdCO0FBQUEsWUFDaEI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0o7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDdUIsTUFBTXRCLG9CQUFvQnNCLEVBQUVDLE9BQU9oQixLQUFLO0FBQUEsZ0JBQ25ELFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTZGO0FBQUEsZUFOL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sdUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYztBQUFBLFlBQ2Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT047QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDcUIsTUFBTXBCLGdCQUFnQm9CLEVBQUVDLE9BQU9oQixLQUFLO0FBQUEsZ0JBQy9DLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTZGO0FBQUEsZUFOL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxXQTdDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0NBO0FBQUEsTUFFQzRDLGdCQUFnQk8sU0FBUyxLQUFLLENBQUMzRSxZQUM5QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsTUFBTWQsYUFBYWtGLGdCQUFnQnRFLFVBQVU7QUFBQSxVQUM3QztBQUFBLFVBQ0EsWUFBWThGO0FBQUFBLFVBQ1osaUJBQWdCO0FBQUEsVUFDaEIsa0JBQWtCO0FBQUE7QUFBQSxRQU5wQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNK0MsSUFHL0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxTQUFTeEIsZUFBZU8sVUFBVTtBQUFBLFVBQ2xDLE1BQUs7QUFBQTtBQUFBLFFBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3NCO0FBQUEsU0F6TTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0TUE7QUFBQSxPQXpORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBME5BLEtBM05GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0TkE7QUFFSjtBQUFFbEYsR0EvYUlELDBCQUF3QjtBQUFBdUgsS0FBeEJ2SDtBQWtiTixlQUFlQTtBQUF5QixJQUFBdUg7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsIk1vZGFsIiwiYXBpIiwiRGF0YVRhYmxlIiwiSW5wdXQiLCJTZWxlY3QiLCJEcm9wZG93biIsIkRhdGVQaWNrZXIiLCJJb01kTW9yZSIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwiaGFuZGxlRW5yb2xsbWVudFJlcXVlc3RQcmludCIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiZmllbGRTaXplIiwiUmFuZ2VQaWNrZXIiLCJVbkFwcHJvdmVkQ3VzdG9tZXJSZXBvcnQiLCJfcyIsInVzZXJzIiwic2V0VXNlcnMiLCJUYWJsZVVzZXJzIiwic2V0VGFibGVVc2VycyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwic2VsZWN0ZWRMYWJlbCIsInNldFNlbGVjdGVkTGFiZWwiLCJub3ciLCJEYXRlIiwidG9kYXlTdHJpbmciLCJ0b0lTT1N0cmluZyIsInNwbGl0Iiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJzaG93RmlsdGVyRmllbGQiLCJzZXRTaG93RmlsdGVyRmllbGQiLCJncm91cE9wdGlvbnMiLCJsYWJlbCIsInZhbHVlIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJoYW5kbGVTZWxlY3RGaWx0ZXIiLCJ0b2RheSIsImZvcm1hdHRlZCIsInllc3RlcmRheSIsInNldERhdGUiLCJnZXREYXRlIiwic3RhcnQiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZW5kIiwiR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ0YXJnZXQiLCJmZXRjaFVzZXJzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJfaWQiLCJpZCIsIm5hbWUiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJjcmVhdGVkQXQiLCJhZGRyZXNzIiwicmVwbGFjZUFsbCIsInBpbmNvZGUiLCJjdXN0b21lcl9pZCIsImNvbGxlY3Rpb25fYXJlYSIsInJvdXRlX25hbWUiLCJhcHByb3ZhbF9zdGF0dXMiLCJhcHByb3ZhbF9zdGF0dXNfcmF3IiwiYWN0aW9uIiwiaXRlbXMiLCJrZXkiLCJlcnJvciIsImNvbnNvbGUiLCJmaWx0ZXJlZEJ5RGF0ZSIsImZpbHRlciIsInVzZXIiLCJqb2luRGF0ZSIsImZyb20iLCJ0byIsInRvdGFsVW5hcHByb3ZlZEN1c3RvbWVycyIsImxlbmd0aCIsImNvbGxlY3Rpb25BcmVhQ291bnQiLCJmb3JFYWNoIiwiaXRlbSIsImNhbGN1bGF0ZURheXNCZXR3ZWVuIiwiZnJvbURhdGUiLCJ0b0RhdGUiLCJkaWZmVGltZSIsIk1hdGgiLCJhYnMiLCJkaWZmRGF5cyIsImNlaWwiLCJhdmdDdXN0b21lcnNQZXJEYXkiLCJ0b0ZpeGVkIiwidG9kYXlVbmFwcHJvdmVkIiwiY29sdW1ucyIsImhlYWRlciIsInVuYXBwcm92ZWRjb2x1bW5zIiwicHJldiIsIk9iamVjdCIsImtleXMiLCJlbnRyaWVzIiwic29ydCIsImEiLCJiIiwic2xpY2UiLCJhcmVhIiwiY291bnQiLCJ3aWR0aCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ0aW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVW5BcHByb3ZlZEN1c3RvbWVyUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBJbnB1dCwgU2VsZWN0LCBEcm9wZG93biwgRGF0ZVBpY2tlciB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IGhhbmRsZUVucm9sbG1lbnRSZXF1ZXN0UHJpbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvcHJpbnRGb3JtYXRzL2Vucm9sbG1lbnRSZXF1ZXN0UHJpbnRcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuY29uc3QgeyBSYW5nZVBpY2tlciB9ID0gRGF0ZVBpY2tlcjtcclxuXHJcblxyXG4vLyBjb25zdCBVbkFwcHJvdmVkQ3VzdG9tZXJSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW1RhYmxlVXNlcnMsIHNldFRhYmxlVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbY3VycmVudFVwZGF0ZVVzZXIsIHNldEN1cnJlbnRVcGRhdGVVc2VyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKHt9KTtcclxuLy8gICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFthcmVhcywgc2V0QXJlYXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtmaWxlcywgc2V0RmlsZXNdID0gdXNlU3RhdGUoe30pO1xyXG4vLyAgIGNvbnN0IFtkaXN0cmljdHMsIHNldERpc3RyaWN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbi8vICAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuLy8gICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbi8vICAgICB0eXBlOiBcImluZm9cIixcclxuLy8gICB9KTtcclxuLy8gICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuXHJcblxyXG5cclxuLy8gICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuLy8gICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4vLyAgICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoQ29sbGVjdGlvbkFyZWEgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4vLyAgICAgICAgICAgXCIvY29sbGVjdGlvbi1hcmVhLXJlcXVlc3QvZ2V0LWNvbGxlY3Rpb24tYXJlYS1kYXRhXCJcclxuLy8gICAgICAgICApO1xyXG5cclxuLy8gICAgICAgICBzZXRBcmVhcyhyZXNwb25zZS5kYXRhKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaENvbGxlY3Rpb25BcmVhKCk7XHJcbi8vICAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcblxyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvYXBwcm92YWwtc3RhdHVzL2ZhbHNlXCIpO1xyXG4vLyAgICAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4vLyAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbi8vICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4vLyAgICAgICAgICAgbmFtZTogZ3JvdXAuZnVsbF9uYW1lLFxyXG4vLyAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cC5waG9uZV9udW1iZXIsXHJcbi8vICAgICAgICAgICBjcmVhdGVkQXQ6IGdyb3VwLmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdLFxyXG4vLyAgICAgICAgICAgYWRkcmVzczogZ3JvdXAuYWRkcmVzcyxcclxuLy8gICAgICAgICAgIHBpbmNvZGU6IGdyb3VwLnBpbmNvZGUsXHJcbi8vICAgICAgICAgICBjdXN0b21lcl9pZDogZ3JvdXAuY3VzdG9tZXJfaWQsXHJcbi8vICAgICAgICAgICBjb2xsZWN0aW9uX2FyZWE6IGdyb3VwLmNvbGxlY3Rpb25fYXJlYT8ucm91dGVfbmFtZSxcclxuLy8gICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czpcclxuLy8gICAgICAgICAgICAgZ3JvdXAuYXBwcm92YWxfc3RhdHVzID09PSBcInRydWVcIiA/IChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0zIHB5LTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTgwMCBiZy1yZWQtMTAwIHJvdW5kZWQtZnVsbCBzaGFkb3ctc21cIj5BcHByb3ZlZDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApIDogZ3JvdXAuYXBwcm92YWxfc3RhdHVzID09PSBcImZhbHNlXCIgPyAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcHgtMyBweS0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1yZWQtODAwIGJnLXJlZC0xMDAgcm91bmRlZC1mdWxsIHNoYWRvdy1zbVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgUGVuZGluZ1xyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTMgcHktMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JlZW4tODAwIGJnLXJlZC0xMDAgcm91bmRlZC1mdWxsIHNoYWRvdy1zbVwiID5BcHByb3ZlZDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgYWN0aW9uOiAoXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4vLyAgICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbi8vICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbi8vICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiM1wiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVFbnJvbGxtZW50UmVxdWVzdFByaW50KGdyb3VwPy5faWQpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiB0ZXh0LXZpb2xldC02MDAgXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaW50XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICAgICAgXSxcclxuLy8gICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuLy8gICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICksXHJcbi8vICAgICAgICAgfSkpO1xyXG4vLyAgICAgICAgIGxldCBmRGF0YSA9IGZvcm1hdHRlZERhdGEubWFwKChlbGUpID0+IHtcclxuLy8gICAgICAgICAgIGlmIChcclxuLy8gICAgICAgICAgICAgZWxlPy5hZGRyZXNzICYmXHJcbi8vICAgICAgICAgICAgIHR5cGVvZiBlbGUuYWRkcmVzcyA9PT0gXCJzdHJpbmdcIiAmJlxyXG4vLyAgICAgICAgICAgICBlbGU/LmFkZHJlc3M/LmluY2x1ZGVzKFwiLFwiKVxyXG4vLyAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICBlbGUuYWRkcmVzcyA9IGVsZS5hZGRyZXNzLnJlcGxhY2VBbGwoXCIsXCIsIFwiIFwiKTtcclxuLy8gICAgICAgICAgIHJldHVybiBlbGU7XHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgICAgaWYgKCFmRGF0YSkgc2V0VGFibGVVc2Vycyhmb3JtYXR0ZWREYXRhKTtcclxuLy8gICAgICAgICBpZiAoIWZEYXRhKSBzZXRUYWJsZVVzZXJzKGZvcm1hdHRlZERhdGEpO1xyXG4vLyAgICAgICAgIHNldFRhYmxlVXNlcnMoZkRhdGEpO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRhdGE6XCIsIGVycm9yLm1lc3NhZ2UpO1xyXG4vLyAgICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaFVzZXJzKCk7XHJcbi8vICAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuLy8gICBjb25zdCBjb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJhcHByb3ZhbF9zdGF0dXNcIiwgaGVhZGVyOiBcIkFwcHJvdmFsIFN0YXR1c1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJjdXN0b21lcl9pZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbi8vICAgICB7a2V5OiBcImNyZWF0ZWRBdFwiLCBoZWFkZXI6IFwiSm9pbmVkIE9uXCJ9LFxyXG4vLyAgICAgeyBrZXk6IFwiYWRkcmVzc1wiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgQWRkcmVzc1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJwaW5jb2RlXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaW5jb2RlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImNvbGxlY3Rpb25fYXJlYVwiLCBoZWFkZXI6IFwiQXJlYVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZXJzLmZpbHRlcigodXNlcikgPT5cclxuLy8gICAgIHVzZXIuZnVsbF9uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICk7XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8PlxyXG4vLyAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgXHJcbi8vICAgICAgICAgICA8TmF2YmFyXHJcbi8vICAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17R2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuLy8gICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuLy8gICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuLy8gICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuLy8gICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4vLyAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4vLyAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4vLyAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuLy8gICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuLy8gICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlJlcG9ydCAtIFVudmVyaWZpZWQgQ3VzdG9tZXJzPC9oMT5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIHtUYWJsZVVzZXJzPy5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZVVzZXJzLCBzZWFyY2hUZXh0KX1cclxuLy8gICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJVbkFwcHJvdmVkIEN1c3RvbWVyc1wiXHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgVW5BcHByb3ZlZCBDdXN0b21lcnMuY3N2YH1cclxuLy8gICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4vLyAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbi8vICAgICAgICAgICAgICAgICBmYWlsdXJlPXtUYWJsZVVzZXJzLmxlbmd0aCA8PSAwfVxyXG4vLyAgICAgICAgICAgICAgICAgZGF0YT1cIkN1c3RvbWVyIERhdGFcIlxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICBcclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8Lz5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuXHJcbi8vIGNvbnN0IFVuQXBwcm92ZWRDdXN0b21lclJlcG9ydCA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbVGFibGVVc2Vycywgc2V0VGFibGVVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuLy8gICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4vLyAgICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuLy8gICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICAvLyDwn5S5IERhdGUgRmlsdGVyIFN0YXRlc1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiVG9kYXlcIik7XHJcbi8vICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuLy8gICBjb25zdCB0b2RheVN0cmluZyA9IG5vdy50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyaW5nKTtcclxuLy8gICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICAvLyDwn5S5IERhdGUgRmlsdGVyIE9wdGlvbnMg4oCUIOKchSBBZGRlZCBcIkFsbFwiXHJcbi8vICAgY29uc3QgZ3JvdXBPcHRpb25zID0gW1xyXG4vLyAgICAgeyBsYWJlbDogXCJBbGxcIiwgdmFsdWU6IFwiQWxsXCIgfSwgLy8g4pyFIE5FVyBPUFRJT05cclxuLy8gICAgIHsgbGFiZWw6IFwiVG9kYXlcIiwgdmFsdWU6IFwiVG9kYXlcIiB9LFxyXG4vLyAgICAgeyBsYWJlbDogXCJZZXN0ZXJkYXlcIiwgdmFsdWU6IFwiWWVzdGVyZGF5XCIgfSxcclxuLy8gICAgIHsgbGFiZWw6IFwiVGhpcyBNb250aFwiLCB2YWx1ZTogXCJUaGlzTW9udGhcIiB9LFxyXG4vLyAgICAgeyBsYWJlbDogXCJMYXN0IE1vbnRoXCIsIHZhbHVlOiBcIkxhc3RNb250aFwiIH0sXHJcbi8vICAgICB7IGxhYmVsOiBcIlRoaXMgWWVhclwiLCB2YWx1ZTogXCJUaGlzWWVhclwiIH0sXHJcbi8vICAgICB7IGxhYmVsOiBcIkN1c3RvbVwiLCB2YWx1ZTogXCJDdXN0b21cIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbi8vICAgICBzZXRTZWxlY3RlZExhYmVsKHZhbHVlKTtcclxuLy8gICAgIHNldFNob3dGaWx0ZXJGaWVsZChmYWxzZSk7XHJcblxyXG4vLyAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG5cclxuLy8gICAgIGlmICh2YWx1ZSA9PT0gXCJBbGxcIikge1xyXG4vLyAgICAgICAvLyDinIUgU2VsZWN0aW5nIOKAnEFsbOKAnSBkaXNhYmxlcyBkYXRlIGZpbHRlcmluZ1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKG51bGwpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUobnVsbCk7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4vLyAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4vLyAgICAgICB5ZXN0ZXJkYXkuc2V0RGF0ZSh5ZXN0ZXJkYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcbi8vICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUoeWVzdGVyZGF5KTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuLy8gICAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKHRydWUpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IEdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4vLyAgICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbi8vICAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyDwn5S5IEZldGNoIHVuYXBwcm92ZWQgdXNlcnNcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvYXBwcm92YWwtc3RhdHVzL2ZhbHNlXCIpO1xyXG4vLyAgICAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG5cclxuLy8gICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuLy8gICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4vLyAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIG5hbWU6IGdyb3VwLmZ1bGxfbmFtZSxcclxuLy8gICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXAucGhvbmVfbnVtYmVyLFxyXG4vLyAgICAgICAgICAgY3JlYXRlZEF0OiBncm91cC5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSxcclxuLy8gICAgICAgICAgIGFkZHJlc3M6IGdyb3VwLmFkZHJlc3M/LnJlcGxhY2VBbGwoXCIsXCIsIFwiIFwiKSxcclxuLy8gICAgICAgICAgIHBpbmNvZGU6IGdyb3VwLnBpbmNvZGUsXHJcbi8vICAgICAgICAgICBjdXN0b21lcl9pZDogZ3JvdXAuY3VzdG9tZXJfaWQsXHJcbi8vICAgICAgICAgICBjb2xsZWN0aW9uX2FyZWE6IGdyb3VwLmNvbGxlY3Rpb25fYXJlYT8ucm91dGVfbmFtZSxcclxuLy8gICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czpcclxuLy8gICAgICAgICAgICAgZ3JvdXAuYXBwcm92YWxfc3RhdHVzID09PSBcInRydWVcIiA/IChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0zIHB5LTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTgwMCBiZy1ncmVlbi0xMDAgcm91bmRlZC1mdWxsIHNoYWRvdy1zbVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgQXBwcm92ZWRcclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0zIHB5LTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXJlZC04MDAgYmctcmVkLTEwMCByb3VuZGVkLWZ1bGwgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgICAgICBQZW5kaW5nXHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICksXHJcbi8vICAgICAgICAgICBhY3Rpb246IChcclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbi8vICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuLy8gICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuLy8gICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuLy8gICAgICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiM1wiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUVucm9sbG1lbnRSZXF1ZXN0UHJpbnQoZ3JvdXA/Ll9pZCl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaW50XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICBdLFxyXG4vLyAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgKSxcclxuLy8gICAgICAgICB9KSk7XHJcbi8vICAgICAgICAgc2V0VGFibGVVc2Vycyhmb3JtYXR0ZWREYXRhKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvci5tZXNzYWdlKTtcclxuLy8gICAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG4vLyAgICAgZmV0Y2hVc2VycygpO1xyXG4vLyAgIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4vLyAgIC8vIPCflLkgQXBwbHkgZGF0ZSBmaWx0ZXIgb24gY3JlYXRlZEF0XHJcbi8vICAgY29uc3QgZmlsdGVyZWRCeURhdGUgPVxyXG4vLyAgICAgc2VsZWN0ZWRMYWJlbCA9PT0gXCJBbGxcIlxyXG4vLyAgICAgICA/IFRhYmxlVXNlcnMgLy8g4pyFIOKAnEFsbOKAnSBzaG93cyBhbGwgdXNlcnNcclxuLy8gICAgICAgOiBUYWJsZVVzZXJzLmZpbHRlcigodXNlcikgPT4ge1xyXG4vLyAgICAgICAgICAgY29uc3Qgam9pbkRhdGUgPSBuZXcgRGF0ZSh1c2VyLmNyZWF0ZWRBdCk7XHJcbi8vICAgICAgICAgICBjb25zdCBmcm9tID0gbmV3IERhdGUoc2VsZWN0ZWRGcm9tRGF0ZSk7XHJcbi8vICAgICAgICAgICBjb25zdCB0byA9IG5ldyBEYXRlKHNlbGVjdGVkRGF0ZSk7XHJcbi8vICAgICAgICAgICByZXR1cm4gam9pbkRhdGUgPj0gZnJvbSAmJiBqb2luRGF0ZSA8PSB0bztcclxuLy8gICAgICAgICB9KTtcclxuXHJcbi8vICAgY29uc3QgY29sdW1ucyA9IFtcclxuLy8gICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYXBwcm92YWxfc3RhdHVzXCIsIGhlYWRlcjogXCJBcHByb3ZhbCBTdGF0dXNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiY3VzdG9tZXJfaWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuLy8gICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaG9uZSBOdW1iZXJcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiY3JlYXRlZEF0XCIsIGhlYWRlcjogXCJKb2luZWQgT25cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8PlxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuLy8gICAgICAgICA8TmF2YmFyXHJcbi8vICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e0dsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbi8vICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4vLyAgICAgICAgIC8+XHJcbi8vICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbi8vICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4vLyAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4vLyAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuLy8gICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbi8vICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuLy8gICAgICAgICAgIH1cclxuLy8gICAgICAgICAvPlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4vLyAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICBSZXBvcnQgLSBVbnZlcmlmaWVkIEN1c3RvbWVyc1xyXG4vLyAgICAgICAgICAgPC9oMT5cclxuXHJcbi8vICAgICAgICAgICB7Lyog8J+UuSBGaWx0ZXIgU2VjdGlvbiAqL31cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi02IGZsZXggZmxleC13cmFwIGdhcC02IGl0ZW1zLWVuZFwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxsYWJlbD5GaWx0ZXI8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbi8vICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0RmlsdGVyfVxyXG4vLyAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGFiZWx9XHJcbi8vICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBPciBTZWxlY3QgRmlsdGVyXCJcclxuLy8gICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14cyBoLTExXCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgodGltZSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3RpbWUudmFsdWV9IHZhbHVlPXt0aW1lLnZhbHVlfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7dGltZS5sYWJlbH1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAge3Nob3dGaWx0ZXJGaWVsZCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWw+RnJvbSBEYXRlPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEZyb21EYXRlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbCBtYXgtdy14c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbD5UbyBEYXRlPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGwgbWF4LXcteHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICB7ZmlsdGVyZWRCeURhdGU/Lmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuLy8gICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4vLyAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihmaWx0ZXJlZEJ5RGF0ZSwgc2VhcmNoVGV4dCl9XHJcbi8vICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuLy8gICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJVbkFwcHJvdmVkIEN1c3RvbWVyc1wiXHJcbi8vICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YFVuQXBwcm92ZWRfQ3VzdG9tZXJzLmNzdmB9XHJcbi8vICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuLy8gICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuLy8gICAgICAgICAgICAgICBmYWlsdXJlPXtmaWx0ZXJlZEJ5RGF0ZS5sZW5ndGggPD0gMH1cclxuLy8gICAgICAgICAgICAgICBkYXRhPVwiQ3VzdG9tZXIgRGF0YVwiXHJcbi8vICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICApfVxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvPlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG5jb25zdCBVbkFwcHJvdmVkQ3VzdG9tZXJSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlVXNlcnMsIHNldFRhYmxlVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgLy8g8J+UuSBEYXRlIEZpbHRlciBTdGF0ZXNcclxuICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIlRvZGF5XCIpO1xyXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgdG9kYXlTdHJpbmcgPSBub3cudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUodG9kYXlTdHJpbmcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbiAgY29uc3QgW3Nob3dGaWx0ZXJGaWVsZCwgc2V0U2hvd0ZpbHRlckZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgLy8g8J+UuSBEYXRlIEZpbHRlciBPcHRpb25zIOKAlCDinIUgQWRkZWQgXCJBbGxcIlxyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIHsgbGFiZWw6IFwiQWxsXCIsIHZhbHVlOiBcIkFsbFwiIH0sIC8vIOKchSBORVcgT1BUSU9OXHJcbiAgICB7IGxhYmVsOiBcIlRvZGF5XCIsIHZhbHVlOiBcIlRvZGF5XCIgfSxcclxuICAgIHsgbGFiZWw6IFwiWWVzdGVyZGF5XCIsIHZhbHVlOiBcIlllc3RlcmRheVwiIH0sXHJcbiAgICB7IGxhYmVsOiBcIlRoaXMgTW9udGhcIiwgdmFsdWU6IFwiVGhpc01vbnRoXCIgfSxcclxuICAgIHsgbGFiZWw6IFwiTGFzdCBNb250aFwiLCB2YWx1ZTogXCJMYXN0TW9udGhcIiB9LFxyXG4gICAgeyBsYWJlbDogXCJUaGlzIFllYXJcIiwgdmFsdWU6IFwiVGhpc1llYXJcIiB9LFxyXG4gICAgeyBsYWJlbDogXCJDdXN0b21cIiwgdmFsdWU6IFwiQ3VzdG9tXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcbiAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiQWxsXCIpIHtcclxuICAgICAgLy8g4pyFIFNlbGVjdGluZyBcIkFsbFwiIGRpc2FibGVzIGRhdGUgZmlsdGVyaW5nXHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUobnVsbCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShudWxsKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHllc3RlcmRheS5zZXREYXRlKHllc3RlcmRheS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdE1vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpIC0gMSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAwLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMTEsIDMxKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4gICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIC8vIPCflLkgRmV0Y2ggdW5hcHByb3ZlZCB1c2Vyc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9hcHByb3ZhbC1zdGF0dXMvZmFsc2VcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgbmFtZTogZ3JvdXAuZnVsbF9uYW1lLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cC5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6IGdyb3VwLmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgYWRkcmVzczogZ3JvdXAuYWRkcmVzcz8ucmVwbGFjZUFsbChcIixcIiwgXCIgXCIpLFxyXG4gICAgICAgICAgcGluY29kZTogZ3JvdXAucGluY29kZSxcclxuICAgICAgICAgIGN1c3RvbWVyX2lkOiBncm91cC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgIGNvbGxlY3Rpb25fYXJlYTogZ3JvdXAuY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9uYW1lLFxyXG4gICAgICAgICAgYXBwcm92YWxfc3RhdHVzOlxyXG4gICAgICAgICAgICBncm91cC5hcHByb3ZhbF9zdGF0dXMgPT09IFwidHJ1ZVwiID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTMgcHktMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JlZW4tODAwIGJnLWdyZWVuLTEwMCByb3VuZGVkLWZ1bGwgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICBBcHByb3ZlZFxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTMgcHktMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcmVkLTgwMCBiZy1yZWQtMTAwIHJvdW5kZWQtZnVsbCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIFBlbmRpbmdcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgIGFwcHJvdmFsX3N0YXR1c19yYXc6IGdyb3VwPy5hcHByb3ZhbF9zdGF0dXMsXHJcbiAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUVucm9sbG1lbnRSZXF1ZXN0UHJpbnQoZ3JvdXA/Ll9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFByaW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVVc2Vycyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvci5tZXNzYWdlKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hVc2VycygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIC8vIPCflLkgQXBwbHkgZGF0ZSBmaWx0ZXIgb24gY3JlYXRlZEF0XHJcbiAgY29uc3QgZmlsdGVyZWRCeURhdGUgPVxyXG4gICAgc2VsZWN0ZWRMYWJlbCA9PT0gXCJBbGxcIlxyXG4gICAgICA/IFRhYmxlVXNlcnMgLy8g4pyFIFwiQWxsXCIgc2hvd3MgYWxsIHVzZXJzXHJcbiAgICAgIDogVGFibGVVc2Vycy5maWx0ZXIoKHVzZXIpID0+IHtcclxuICAgICAgICAgIGNvbnN0IGpvaW5EYXRlID0gbmV3IERhdGUodXNlci5jcmVhdGVkQXQpO1xyXG4gICAgICAgICAgY29uc3QgZnJvbSA9IG5ldyBEYXRlKHNlbGVjdGVkRnJvbURhdGUpO1xyXG4gICAgICAgICAgY29uc3QgdG8gPSBuZXcgRGF0ZShzZWxlY3RlZERhdGUpO1xyXG4gICAgICAgICAgcmV0dXJuIGpvaW5EYXRlID49IGZyb20gJiYgam9pbkRhdGUgPD0gdG87XHJcbiAgICAgICAgfSk7XHJcblxyXG4gIC8vIENhbGN1bGF0ZSBzdW1tYXJ5IGRhdGFcclxuICBjb25zdCB0b3RhbFVuYXBwcm92ZWRDdXN0b21lcnMgPSBmaWx0ZXJlZEJ5RGF0ZS5sZW5ndGg7XHJcbiAgXHJcbiAgLy8gQ291bnQgYnkgQ29sbGVjdGlvbiBBcmVhXHJcbiAgY29uc3QgY29sbGVjdGlvbkFyZWFDb3VudCA9IHt9O1xyXG4gIGZpbHRlcmVkQnlEYXRlLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgIGNvbnN0IGtleSA9IGl0ZW0uY29sbGVjdGlvbl9hcmVhIHx8IFwiVW5hc3NpZ25lZFwiO1xyXG4gICAgY29sbGVjdGlvbkFyZWFDb3VudFtrZXldID0gKGNvbGxlY3Rpb25BcmVhQ291bnRba2V5XSB8fCAwKSArIDE7XHJcbiAgfSk7XHJcblxyXG4gIC8vIENhbGN1bGF0ZSBkYXlzIGJldHdlZW4gc2VsZWN0ZWQgZGF0ZXNcclxuICBjb25zdCBjYWxjdWxhdGVEYXlzQmV0d2VlbiA9ICgpID0+IHtcclxuICAgIGlmIChzZWxlY3RlZExhYmVsID09PSBcIkFsbFwiKSByZXR1cm4gMzY1OyAvLyBEZWZhdWx0IHRvIDM2NSBkYXlzIGZvciBcIkFsbFwiXHJcbiAgICBcclxuICAgIGNvbnN0IGZyb21EYXRlID0gbmV3IERhdGUoc2VsZWN0ZWRGcm9tRGF0ZSk7XHJcbiAgICBjb25zdCB0b0RhdGUgPSBuZXcgRGF0ZShzZWxlY3RlZERhdGUpO1xyXG4gICAgY29uc3QgZGlmZlRpbWUgPSBNYXRoLmFicyh0b0RhdGUgLSBmcm9tRGF0ZSk7XHJcbiAgICBjb25zdCBkaWZmRGF5cyA9IE1hdGguY2VpbChkaWZmVGltZSAvICgxMDAwICogNjAgKiA2MCAqIDI0KSkgKyAxOyAvLyArMSB0byBpbmNsdWRlIGJvdGggc3RhcnQgYW5kIGVuZCBkYXRlXHJcbiAgICByZXR1cm4gZGlmZkRheXM7XHJcbiAgfTtcclxuXHJcbiAgLy8gQ2FsY3VsYXRlIGF2ZXJhZ2UgY3VzdG9tZXJzIHBlciBkYXlcclxuICBjb25zdCBhdmdDdXN0b21lcnNQZXJEYXkgPSBjYWxjdWxhdGVEYXlzQmV0d2VlbigpID4gMCBcclxuICAgID8gKHRvdGFsVW5hcHByb3ZlZEN1c3RvbWVycyAvIGNhbGN1bGF0ZURheXNCZXR3ZWVuKCkpLnRvRml4ZWQoMSkgXHJcbiAgICA6IDA7XHJcblxyXG4gIC8vIENhbGN1bGF0ZSB0b2RheSdzIHVuYXBwcm92ZWQgY3VzdG9tZXJzXHJcbiAgY29uc3QgdG9kYXlVbmFwcHJvdmVkID0gVGFibGVVc2Vycy5maWx0ZXIodXNlciA9PiB7XHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgICByZXR1cm4gdXNlci5jcmVhdGVkQXQgPT09IHRvZGF5O1xyXG4gIH0pLmxlbmd0aDtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYXBwcm92YWxfc3RhdHVzXCIsIGhlYWRlcjogXCJBcHByb3ZhbCBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfaWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3JlYXRlZEF0XCIsIGhlYWRlcjogXCJKb2luZWQgT25cIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcbiAgICBjb25zdCB1bmFwcHJvdmVkY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYXBwcm92YWxfc3RhdHVzX3Jhd1wiLCBoZWFkZXI6IFwiQXBwcm92YWwgU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyX2lkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImNyZWF0ZWRBdFwiLCBoZWFkZXI6IFwiSm9pbmVkIE9uXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTZcIj5cclxuICAgICAgICAgICAgUmVwb3J0IC0gVW52ZXJpZmllZCBDdXN0b21lcnNcclxuICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgey8qIEVOSEFOQ0VEIFNVTU1BUlkgQ0FSRFMgKi99XHJcbiAgICAgICAgICB7ZmlsdGVyZWRCeURhdGUubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgbWItNCB0ZXh0LWdyYXktODAwXCI+U3VtbWFyeTwvaDI+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgey8qIFRPVEFMIFVOQVBQUk9WRUQgQ1VTVE9NRVJTIENBUkQgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNjAwIHRleHQtd2hpdGUgcC02IHJvdW5kZWQteGwgc2hhZG93LWxnIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtMTAwIHRleHQtc20gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFVuYXBwcm92ZWQgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCBtdC0xXCI+e3RvdGFsVW5hcHByb3ZlZEN1c3RvbWVyc308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtMTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkTGFiZWwgPT09IFwiQWxsXCIgPyBcIkFsbCBUaW1lXCIgOiBzZWxlY3RlZExhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYmctb3BhY2l0eS0yMCBwLTMgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgY2xhc3NOYW1lPVwiaC04IHctOFwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTEyIDl2Mm0wIDRoLjAxbS02LjkzOCA0aDEzLjg1NmMxLjU0IDAgMi41MDItMS42NjcgMS43MzItM0wxMy43MzIgNGMtLjc3LTEuMzMzLTIuNjk0LTEuMzMzLTMuNDY0IDBMMy4zNCAxNmMtLjc3IDEuMzMzLjE5MiAzIDEuNzMyIDN6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFNVTU1BUlkgR1JJRCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTIgZ2FwLTYgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB7LyogQ09MTEVDVElPTiBBUkVBIENPVU5UICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+Q29sbGVjdGlvbiBBcmVhczwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctdmlvbGV0LTEwMCB0ZXh0LXZpb2xldC04MDAgdGV4dC14cyBmb250LW1lZGl1bSBweC0yLjUgcHktMC41IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtPYmplY3Qua2V5cyhjb2xsZWN0aW9uQXJlYUNvdW50KS5sZW5ndGh9IEFyZWFzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoY29sbGVjdGlvbkFyZWFDb3VudClcclxuICAgICAgICAgICAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiWzFdIC0gYVsxXSlcclxuICAgICAgICAgICAgICAgICAgICAgIC5zbGljZSgwLCA1KVxyXG4gICAgICAgICAgICAgICAgICAgICAgLm1hcCgoW2FyZWEsIGNvdW50XSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17YXJlYX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIgaC0yIGJnLXZpb2xldC01MDAgcm91bmRlZC1mdWxsIG1yLTNcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDAgdGV4dC1zbSB0cnVuY2F0ZSBtYXgtdy14c1wiPnthcmVhfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjQgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIGgtMiBtci0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTUwMCBoLTIgcm91bmRlZC1mdWxsXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAkeyhjb3VudCAvIHRvdGFsVW5hcHByb3ZlZEN1c3RvbWVycykgKiAxMDB9JWAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdy04IHRleHQtcmlnaHRcIj57Y291bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIHtPYmplY3Qua2V5cyhjb2xsZWN0aW9uQXJlYUNvdW50KS5sZW5ndGggPiA1ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+VmlldyBBbGwgQXJlYXM8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFRPREFZJ1MgVU5BUFBST1ZFRCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQteGwgc2hhZG93LWxnIGJvcmRlciBib3JkZXItZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlRvZGF5J3MgVW5hcHByb3ZlZDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAgdGV4dC14cyBmb250LW1lZGl1bSBweC0yLjUgcHktMC41IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt0b2RheVVuYXBwcm92ZWR9IE5ld1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNXhsIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj57dG9kYXlVbmFwcHJvdmVkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbSBtdC0yXCI+Q3VzdG9tZXJzIGF3YWl0aW5nIGFwcHJvdmFsIHRvZGF5PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHsvKiBBRERJVElPTkFMIE1FVFJJQ1MgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLWZ1bGwgYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS02MDAgbXItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgY2xhc3NOYW1lPVwiaC02IHctNlwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9ezJ9IGQ9XCJNOCA3VjNtOCA0VjNtLTkgOGgxME01IDIxaDE0YTIgMiAwIDAwMi0yVjdhMiAyIDAgMDAtMi0ySDVhMiAyIDAgMDAtMiAydjEyYTIgMiAwIDAwMiAyelwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtXCI+U2VsZWN0ZWQgUGVyaW9kPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+e3NlbGVjdGVkTGFiZWwgPT09IFwiQWxsXCIgPyBcIkFsbCBUaW1lXCIgOiBzZWxlY3RlZExhYmVsfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTEwMCB0ZXh0LWFtYmVyLTYwMCBtci00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBjbGFzc05hbWU9XCJoLTYgdy02XCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk0xMiA4djRsMyAzbTYtM2E5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPkF2Zy4gVW5hcHByb3ZlZC9EYXk8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj57YXZnQ3VzdG9tZXJzUGVyRGF5fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC1mdWxsIGJnLXJlZC0xMDAgdGV4dC1yZWQtNjAwIG1yLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIGNsYXNzTmFtZT1cImgtNiB3LTZcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTEzIDdoOG0wIDB2OG0wLThsLTggOC00LTQtNiA2XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj5QZW5kaW5nIEFwcHJvdmFsIFJhdGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VzZXJzLmxlbmd0aCA+IDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgJHsoKHRvdGFsVW5hcHByb3ZlZEN1c3RvbWVycyAvIHVzZXJzLmxlbmd0aCkgKiAxMDApLnRvRml4ZWQoMSl9JWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiMCVcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiDwn5S5IEZpbHRlciBTZWN0aW9uICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLTYgZmxleCBmbGV4LXdyYXAgZ2FwLTYgaXRlbXMtZW5kXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPkZpbHRlcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTZWxlY3RGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIE9yIFNlbGVjdCBGaWx0ZXJcIlxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGgtMTFcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKCh0aW1lKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dGltZS52YWx1ZX0gdmFsdWU9e3RpbWUudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHt0aW1lLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbD5Gcm9tIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LXhzXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsPlRvIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbCBtYXgtdy14c1wiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHtmaWx0ZXJlZEJ5RGF0ZT8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGZpbHRlcmVkQnlEYXRlLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgIGV4cG9ydENvbHM9e3VuYXBwcm92ZWRjb2x1bW5zfVxyXG4gICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlVuQXBwcm92ZWQgQ3VzdG9tZXJzXCJcclxuICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgVW5BcHByb3ZlZCBDdXN0b21lcnMuY3N2YH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgIGZhaWx1cmU9e2ZpbHRlcmVkQnlEYXRlLmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgIGRhdGE9XCJDdXN0b21lciBEYXRhXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBVbkFwcHJvdmVkQ3VzdG9tZXJSZXBvcnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9VbkFwcHJvdmVkQ3VzdG9tZXJSZXBvcnQuanN4In0=