import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChitCancelPaymentIn.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Modal as AntModal, Drawer, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { FaReceipt } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import Modal from "/src/components/modals/Modal.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const ChitCancelPaymentIn = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [actualGroups, setActualGroups] = useState([]);
  const [TablePayments, setTablePayments] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [filteredEnrollments, setFilteredEnrollments] = useState([]);
  const [enrollmentLoading, setEnrollmentLoading] = useState(false);
  const [showModalView, setShowModalView] = useState(false);
  const [currentViewGroup, setCurrentViewGroup] = useState(null);
  const [whatsappEnable, setWhatsappEnable] = useState(true);
  const [paymentMode, setPaymentMode] = useState("cash");
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [borrowers, setBorrowers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [currentGroupId, setCurrentGroupId] = useState(null);
  const [openAntDDrawer, setOpenAntDDrawer] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [lastThreePayments, setLastThreePayments] = useState([]);
  const [showGroupPayment, setShowGroupPayment] = useState(false);
  const [viewLoader, setViewLoader] = useState(false);
  const [selectedGroupTickets, setSelectedGroupTickets] = useState([]);
  const location = useLocation();
  const [userAccountInfo, setUserAccountInfo] = useState(null);
  const [fetchingBalance, setFetchingBalance] = useState(false);
  const dropDownItems = (paymentObject) => [
    {
      key: "1",
      label: /* @__PURE__ */ jsxDEV(Link, { to: `/print/${paymentObject?._id}`, className: "text-violet-600", children: "Print" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
        lineNumber: 55,
        columnNumber: 12
      }, this)
    },
    {
      key: "3",
      label: /* @__PURE__ */ jsxDEV("div", { className: "text-green-600", onClick: () => handleViewModalOpen(paymentObject?._id), children: "View" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
        lineNumber: 59,
        columnNumber: 12
      }, this)
    }
  ];
  const onGlobalSearchChangeHandler = (e) => setSearchText(e.target.value);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    user_id: "",
    payment_group_tickets: null,
    // { group_id, ticket }
    pay_date: today,
    amount: "",
    pay_type: "Transfer",
    transaction_id: "",
    admin_type: "",
    remarks: "",
    account_type: "",
    cheque_number: "",
    cheque_date: "",
    cheque_bank_name: "",
    cheque_bank_branch: ""
  });
  const [modifyPayment, setModifyPayment] = useState(false);
  const [modifyMinMaxPaymentDate, setModifyMinMaxPaymentDate] = useState(false);
  const yesterday = new Date((/* @__PURE__ */ new Date()).setDate((/* @__PURE__ */ new Date()).getDate() - 1)).toISOString().split("T")[0];
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj) {
      const permissions = userObj.admin_access_right_id?.access_permissions;
      if (permissions?.edit_payment === "true") setModifyPayment(true);
      if (permissions?.edit_limited_payment === "true") {
        setModifyPayment(true);
        setModifyMinMaxPaymentDate(true);
      }
    }
  }, []);
  useEffect(() => {
    if (!selectedUserId) return;
    const allOptions = [
      ...filteredEnrollments.map((entry) => `chit-${entry.enrollment.group._id}|${entry.enrollment.tickets}`),
      ...pigmeCustomers.map((pigme) => `pigme-${pigme._id}`),
      ...borrowers.map((borrower) => `loan-${borrower._id}`)
    ];
    if (allOptions.length > 0) {
      setSelectedGroupTickets(allOptions);
      setErrors((prev) => ({ ...prev, group_ticket: void 0 }));
    }
  }, [filteredEnrollments, pigmeCustomers, borrowers, selectedUserId]);
  const fetchUserAccountInfo = async (userId) => {
    if (!userId) return;
    setFetchingBalance(true);
    try {
      const response = await api.get(`/v1/admin/user-accounts/${userId}`);
      if (response.data?.status) {
        setUserAccountInfo(response.data.data);
      } else {
        setUserAccountInfo(null);
      }
    } catch (error) {
      console.error("Error fetching user account:", error);
      setUserAccountInfo(null);
    } finally {
      setFetchingBalance(false);
    }
  };
  const fetchUserEnrollments = async (userId) => {
    if (!userId) return;
    setEnrollmentLoading(true);
    try {
      const response = await api.post(`/enroll/get-user-tickets-report/${userId}`);
      const valid = response.data.filter((item) => item.enrollment && item.enrollment.group);
      setFilteredEnrollments(valid);
    } catch (error) {
      setFilteredEnrollments([]);
    } finally {
      setEnrollmentLoading(false);
    }
  };
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const userId = params.get("userId");
    const amount = params.get("amount");
    if (userId) {
      setFormData((prev) => ({ ...prev, user_id: userId }));
      setSelectedUserId(userId);
      fetchUserAccountInfo(userId);
      fetchUserEnrollments(userId);
    }
    if (amount) {
      setFormData((prev) => ({ ...prev, amount }));
    }
  }, [location.search]);
  useEffect(() => {
    if (selectedUserId) {
      fetchUserAccountInfo(selectedUserId);
      fetchUserEnrollments(selectedUserId);
    }
  }, [selectedUserId]);
  const fetchLastThreeTransactions = async (event) => {
    event.preventDefault();
    if (!formData.user_id || !formData.payment_group_tickets) {
      alert("Please select customer and group/ticket first");
      return;
    }
    const { group_id, ticket } = formData.payment_group_tickets;
    setOpenAntDDrawer(true);
    setShowLoader(true);
    try {
      const response = await api.get("payment/get-last-n-transaction", {
        params: {
          user_id: formData.user_id,
          group_id,
          ticket,
          limit: 3
        }
      });
      setLastThreePayments(response.data || []);
    } catch (error) {
      setLastThreePayments([]);
    } finally {
      setShowLoader(false);
    }
  };
  useEffect(() => {
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(`/loans/get-borrower-by-user-id/${selectedUserId}`);
        setBorrowers(response.data);
      } catch (err) {
        setBorrowers([]);
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedUserId]);
  useEffect(() => {
    const fetchPigmeDetails = async () => {
      try {
        const response = await api.get(`/pigme/get-pigme-customer-by-user-id/${selectedUserId}`);
        setPigmeCustomers(response.data);
      } catch (err) {
        setPigmeCustomers([]);
      }
    };
    fetchPigmeDetails();
  }, [selectedUserId]);
  useEffect(() => {
    const fetchAllCustomers = async () => {
      try {
        const response = await api.get("user/verified");
        setUsers(response?.data?.data || []);
      } catch (error) {
        setUsers([]);
      }
    };
    fetchAllCustomers();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setActualGroups(response.data);
      } catch (error) {
        setActualGroups([]);
      }
    };
    fetchGroups();
  }, []);
  const validateForm = () => {
    const newErrors = {};
    if (!formData.user_id) newErrors.customer = "Please select a customer";
    if (!selectedGroupTickets || selectedGroupTickets.length === 0) {
      newErrors.group_ticket = "Please select at least one group/ticket";
    }
    if (!formData.pay_date) newErrors.pay_date = "Payment date is required";
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    } else if (!userAccountInfo) {
      newErrors.amount = "Unable to verify balance. Please refresh or select customer again.";
    } else if (amount > userAccountInfo.balance) {
      newErrors.amount = `Amount cannot exceed available balance of ₹${userAccountInfo.balance.toLocaleString()}`;
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "amount") {
      let cleaned = value.replace(/[^0-9.]/g, "");
      if ((cleaned.match(/\./g) || []).length > 1) return;
      setFormData((prev) => ({ ...prev, [name]: cleaned }));
      setErrors({});
      return;
    }
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors({});
  };
  const handleCustomer = async (userId) => {
    setSelectedUserId(userId);
    setFormData((prev) => ({ ...prev, user_id: userId, payment_group_tickets: null }));
    setErrors((prev) => ({ ...prev, customer: "" }));
    setSelectedGroupTickets([]);
  };
  const handlePaymentModeChange = (e) => {
    const mode = e.target.value;
    setPaymentMode(mode);
    setFormData((prev) => ({
      ...prev,
      pay_type: mode,
      transaction_id: mode === "cash" ? "" : prev.transaction_id,
      ...mode !== "cheque" && { cheque_number: "", cheque_date: "", cheque_bank_name: "", cheque_bank_branch: "" }
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    const admin = JSON.parse(localStorage.getItem("user") || "{}");
    const payload = {
      user_id: formData.user_id,
      payment_group_tickets: selectedGroupTickets,
      pay_date: formData.pay_date,
      amount: parseFloat(formData.amount),
      pay_type: formData.pay_type,
      admin_type: admin._id,
      transaction_id: formData.transaction_id || null,
      remarks: formData.remarks || null,
      account_type: formData.account_type || "savings",
      ...formData.pay_type === "cheque" && {
        cheque_number: formData.cheque_number,
        cheque_date: formData.cheque_date,
        cheque_bank_name: formData.cheque_bank_name,
        cheque_bank_branch: formData.cheque_bank_branch
      }
    };
    setOpenBackdropLoader(true);
    try {
      await api.post("v1/admin/user-accounts/payin", payload);
      setAlertConfig({ visibility: true, message: "Cancellation payment successful", type: "success", noReload: true });
      setFormData({
        user_id: "",
        payment_group_tickets: null,
        pay_date: today,
        amount: "",
        pay_type: "cash",
        transaction_id: "",
        admin_type: "",
        remarks: "",
        account_type: "",
        cheque_number: "",
        cheque_date: "",
        cheque_bank_name: "",
        cheque_bank_branch: ""
      });
      setSelectedUserId("");
      setFilteredEnrollments([]);
      setUserAccountInfo(null);
    } catch (error) {
      setAlertConfig({ visibility: true, message: error.message || "Submission failed", type: "error", noReload: true });
    } finally {
      setOpenBackdropLoader(false);
      setSelectedGroupTickets([]);
    }
  };
  const handleViewModalOpen = async (paymentId) => {
    setLoading(true);
    setShowModalView(true);
    setCurrentGroupId(paymentId);
    setViewLoader(true);
    try {
      const res = await api.get(`/payment/get-payment-by-id/${paymentId}`);
      setCurrentViewGroup(res.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
      setViewLoader(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: openBackdropLoader ? /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "Payment Data Processing...." }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
    lineNumber: 394,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 min-h-screen mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
      lineNumber: 398,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { onGlobalSearchChangeHandler, visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
        lineNumber: 400,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          noReload: alertConfig.noReload
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
          lineNumber: 401,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
          lineNumber: 409,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "max-w-5xl mx-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-xl overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-900 to-blue-800 px-8 py-5", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-white tracking-wide", children: "Chit Transfer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 414,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-blue-200 text-sm mt-1", children: "Process transfer amounts to different chit accounts, pigmy, or loans." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 415,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 413,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "p-8 space-y-8", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                  "Select Customer ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 424,
                    columnNumber: 109
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 424,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    placeholder: "Select or search customer",
                    showSearch: true,
                    size: "large",
                    className: "w-full",
                    filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                    value: formData.user_id || void 0,
                    onChange: handleCustomer,
                    options: users.map((user) => ({
                      value: user._id,
                      label: `${user.full_name} | ${user.phone_number}`
                    }))
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 425,
                    columnNumber: 27
                  },
                  this
                ),
                errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.customer }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 440,
                  columnNumber: 47
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 423,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                  "Select Group & Ticket ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 472,
                    columnNumber: 51
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 471,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    mode: "multiple",
                    placeholder: "Select one or more groups, pigmy, or loans",
                    disabled: enrollmentLoading || (userAccountInfo?.balance || 0) <= 0,
                    loading: enrollmentLoading,
                    size: "large",
                    className: "w-full",
                    value: selectedGroupTickets,
                    onChange: (values) => {
                      setSelectedGroupTickets(values);
                      setErrors((prev) => ({ ...prev, group_ticket: void 0 }));
                    },
                    children: [
                      filteredEnrollments.map((entry) => {
                        const groupId = entry.enrollment.group._id;
                        const ticket = entry.enrollment.tickets;
                        const value = `chit-${groupId}|${ticket}`;
                        const label = `${entry.enrollment.group.group_name} | ${ticket}`;
                        return /* @__PURE__ */ jsxDEV(Select.Option, { value, children: label }, value, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                          lineNumber: 493,
                          columnNumber: 36
                        }, this);
                      }),
                      pigmeCustomers?.map((pigme) => {
                        const value = `pigme-${pigme._id}`;
                        const label = `${pigme.pigme_id} | ₹ ${pigme.payable_amount}`;
                        return /* @__PURE__ */ jsxDEV(Select.Option, { value, children: label }, value, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                          lineNumber: 499,
                          columnNumber: 36
                        }, this);
                      }),
                      borrowers?.map((borrower) => {
                        const value = `loan-${borrower._id}`;
                        const label = `loan-${borrower.loan_id} | ₹ ${borrower.loan_amount}`;
                        return /* @__PURE__ */ jsxDEV(Select.Option, { value, children: label }, value, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                          lineNumber: 505,
                          columnNumber: 36
                        }, this);
                      })
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 474,
                    columnNumber: 27
                  },
                  this
                ),
                errors.group_ticket && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.group_ticket }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 508,
                  columnNumber: 51
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 470,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 422,
              columnNumber: 23
            }, this),
            userAccountInfo && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-4 flex justify-between items-center shadow-sm", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase tracking-wide", children: "Customer Balance" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 516,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-gray-800", children: userAccountInfo.full_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 517,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 515,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Available Balance" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 520,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-extrabold text-green-700", children: [
                  "₹ ",
                  Number(userAccountInfo.balance).toLocaleString()
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 521,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 519,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 514,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-6 border border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-800 mb-5 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-blue-600 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 540,
                  columnNumber: 27
                }, this),
                " Payment Details"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 539,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                    "Payment Date ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 544,
                      columnNumber: 108
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 544,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      name: "pay_date",
                      value: formData.pay_date,
                      onChange: handleChange,
                      disabled: !modifyPayment,
                      min: modifyMinMaxPaymentDate ? yesterday : void 0,
                      max: modifyMinMaxPaymentDate ? today : void 0,
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 545,
                      columnNumber: 29
                    },
                    this
                  ),
                  errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 550,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 543,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                    "Transfer Amount ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 554,
                      columnNumber: 111
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 554,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("input", { type: "number", name: "amount", value: formData.amount, onChange: handleChange, placeholder: "Enter amount", className: "w-full px-4 py-2 border border-gray-300 rounded-lg bg-blue-50 font-medium text-blue-800" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 555,
                    columnNumber: 29
                  }, this),
                  errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 556,
                    columnNumber: 47
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 mt-1", children: numberToIndianWords(formData.amount) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 557,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 553,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Remarks (optional)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 561,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("textarea", { name: "remarks", value: formData.remarks, onChange: handleChange, rows: 2, placeholder: "Additional remarks (e.g., reason for cancellation)", className: "w-full px-4 py-2 border border-gray-300 rounded-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 562,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 560,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 542,
                columnNumber: 25
              }, this),
              (formData.pay_type === "online" || formData.pay_type === "online/upi") && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                  "Transaction ID ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 575,
                    columnNumber: 110
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 575,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "transaction_id",
                    value: formData.transaction_id,
                    onChange: handleChange,
                    placeholder: "Enter Transaction ID",
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 576,
                    columnNumber: 29
                  },
                  this
                ),
                errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 578,
                  columnNumber: 55
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 574,
                columnNumber: 23
              }, this),
              formData.pay_type === "cheque" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("h5", { className: "text-base font-semibold text-gray-900 mb-3", children: "Cheque Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 585,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                      "Cheque Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                        lineNumber: 588,
                        columnNumber: 113
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 588,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("input", { type: "text", name: "cheque_number", value: formData.cheque_number, onChange: handleChange, className: "w-full px-4 py-2 border border-gray-300 rounded-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 589,
                      columnNumber: 33
                    }, this),
                    errors.cheque_number && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 590,
                      columnNumber: 58
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 587,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                      "Cheque Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                        lineNumber: 593,
                        columnNumber: 111
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 593,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("input", { type: "date", name: "cheque_date", value: formData.cheque_date, onChange: handleChange, className: "w-full px-4 py-2 border border-gray-300 rounded-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 594,
                      columnNumber: 33
                    }, this),
                    errors.cheque_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_date }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 595,
                      columnNumber: 56
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 592,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 598,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("input", { type: "text", name: "cheque_bank_name", value: formData.cheque_bank_name, onChange: handleChange, className: "w-full px-4 py-2 border border-gray-300 rounded-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 599,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 597,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Branch" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 602,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("input", { type: "text", name: "cheque_bank_branch", value: formData.cheque_bank_branch, onChange: handleChange, className: "w-full px-4 py-2 border border-gray-300 rounded-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                      lineNumber: 603,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                    lineNumber: 601,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 586,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 584,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 538,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4 border border-gray-200 flex justify-between items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { className: "text-green-500 text-2xl" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 633,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: "WhatsApp Notification" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 634,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 632,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: whatsappEnable, onChange: (e) => setWhatsappEnable(e.target.checked), className: "w-5 h-5 text-green-500 rounded" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 637,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Send via WhatsApp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                  lineNumber: 638,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 636,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 631,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "bg-blue-900 hover:bg-blue-800 text-white font-semibold px-8 py-2.5 rounded-lg shadow-md transition-all",
                disabled: (userAccountInfo?.balance || 0) <= 0,
                title: (userAccountInfo?.balance || 0) <= 0 ? "Customer has no available balance" : "Save Payment",
                children: "Save Payment"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
                lineNumber: 643,
                columnNumber: 25
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 642,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 420,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
          lineNumber: 411,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
          lineNumber: 410,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
        lineNumber: 408,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Drawer, { title: "Last Three Transactions", placement: "right", open: openAntDDrawer, onClose: () => setOpenAntDDrawer(false), width: 400, loading: showLoader, children: lastThreePayments.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500 py-8", children: "No Transaction Found" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
        lineNumber: 659,
        columnNumber: 15
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: lastThreePayments.map(
        (p, i) => /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg p-4 shadow-sm border", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold w-28", children: "Payment Date:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 664,
              columnNumber: 52
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: p.pay_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 664,
              columnNumber: 109
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 664,
            columnNumber: 25
          }, this),
          p.group_id && /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold w-28", children: "Group:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 665,
              columnNumber: 67
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: p.group_id?.group_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 665,
              columnNumber: 117
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 665,
            columnNumber: 40
          }, this),
          p.ticket && /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold w-28", children: "Ticket:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 666,
              columnNumber: 65
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: p.ticket }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 666,
              columnNumber: 116
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 666,
            columnNumber: 38
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold w-28", children: "Amount:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 667,
              columnNumber: 52
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: [
              "₹",
              p.amount
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 667,
              columnNumber: 103
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 667,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex mb-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold w-28", children: "Payment Type:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 668,
              columnNumber: 52
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: p.pay_type }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 668,
              columnNumber: 109
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 668,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold w-28", children: "Name:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 669,
              columnNumber: 47
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: p.user_id?.full_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 669,
              columnNumber: 96
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 669,
            columnNumber: 25
          }, this)
        ] }, i, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
          lineNumber: 663,
          columnNumber: 17
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
        lineNumber: 661,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
        lineNumber: 657,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(AntModal, { open: showModalView, onCancel: () => setShowModalView(false), footer: null, width: 800, children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold mb-4", children: "Payment Details" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
          lineNumber: 677,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-4 border", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Group:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 680,
              columnNumber: 26
            }, this),
            " ",
            currentViewGroup?.group_id?.group_name
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 680,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Group Value:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 681,
              columnNumber: 26
            }, this),
            " ",
            currentViewGroup?.group_id?.group_value
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 681,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "User:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 682,
              columnNumber: 26
            }, this),
            " ",
            currentViewGroup?.user_id?.full_name,
            " | Ticket: ",
            currentViewGroup?.ticket
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 682,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Amount:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 683,
              columnNumber: 26
            }, this),
            " ",
            currentViewGroup?.amount
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 683,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Pay Type:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 684,
              columnNumber: 26
            }, this),
            " ",
            currentViewGroup?.pay_type
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 684,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Pay Date:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 685,
              columnNumber: 26
            }, this),
            " ",
            currentViewGroup?.pay_date?.split("T")[0]
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 685,
            columnNumber: 21
          }, this),
          currentViewGroup?.cheque_number && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Cheque No:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 686,
              columnNumber: 62
            }, this),
            " ",
            currentViewGroup.cheque_number
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 686,
            columnNumber: 57
          }, this),
          currentViewGroup?.transaction_id && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Transaction ID:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
              lineNumber: 687,
              columnNumber: 63
            }, this),
            " ",
            currentViewGroup.transaction_id
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
            lineNumber: 687,
            columnNumber: 58
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
          lineNumber: 679,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
          lineNumber: 678,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
        lineNumber: 676,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
      lineNumber: 399,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
    lineNumber: 397,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
    lineNumber: 396,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx",
    lineNumber: 392,
    columnNumber: 5
  }, this);
};
_s(ChitCancelPaymentIn, "HpB7TJS3xSTM5tMEt6ZBMdq0rFw=", false, function() {
  return [useLocation];
});
_c = ChitCancelPaymentIn;
export default ChitCancelPaymentIn;
var _c;
$RefreshReg$(_c, "ChitCancelPaymentIn");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentIn.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RhLFNBaVZULFVBalZTOzJCQXREYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLHdCQUF3QjtBQUNqQyxPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFVBQVVDLFNBQVNDLFVBQVVDLFFBQVFDLGVBQWU7QUFDckUsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxPQUFPQyx3QkFBd0I7QUFDL0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLDJCQUEyQjtBQUNwQyxPQUFPVCxXQUFXO0FBQ2xCLE9BQU9VLGdCQUFnQjtBQUV2QixNQUFNQyxzQkFBc0JBLE1BQU07QUFBQUMsS0FBQTtBQUNoQyxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXhCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUN5QixjQUFjQyxlQUFlLElBQUkxQixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDMkIsZUFBZUMsZ0JBQWdCLElBQUk1QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDNkIsZ0JBQWdCQyxpQkFBaUIsSUFBSTlCLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUMrQixxQkFBcUJDLHNCQUFzQixJQUFJaEMsU0FBUyxFQUFFO0FBQ2pFLFFBQU0sQ0FBQ2lDLG1CQUFtQkMsb0JBQW9CLElBQUlsQyxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDbUMsZUFBZUMsZ0JBQWdCLElBQUlwQyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDcUMsa0JBQWtCQyxtQkFBbUIsSUFBSXRDLFNBQVMsSUFBSTtBQUM3RCxRQUFNLENBQUN1QyxnQkFBZ0JDLGlCQUFpQixJQUFJeEMsU0FBUyxJQUFJO0FBQ3pELFFBQU0sQ0FBQ3lDLGFBQWFDLGNBQWMsSUFBSTFDLFNBQVMsTUFBTTtBQUNyRCxRQUFNMkMsU0FBUSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbkQsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUloRCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDaUQsU0FBU0MsVUFBVSxJQUFJbEQsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ21ELFlBQVlDLGFBQWEsSUFBSXBELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNxRCxXQUFXQyxZQUFZLElBQUl0RCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDdUQsZ0JBQWdCQyxpQkFBaUIsSUFBSXhELFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUN5RCxvQkFBb0JDLHFCQUFxQixJQUFJMUQsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQzJELGdCQUFnQkMsaUJBQWlCLElBQUk1RCxTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDNkQsZ0JBQWdCQyxpQkFBaUIsSUFBSTlELFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUMrRCxZQUFZQyxhQUFhLElBQUloRSxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDaUUsbUJBQW1CQyxvQkFBb0IsSUFBSWxFLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNtRSxrQkFBa0JDLG1CQUFtQixJQUFJcEUsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ3FFLFlBQVlDLGFBQWEsSUFBSXRFLFNBQVMsS0FBSztBQUVsRCxRQUFNLENBQUN1RSxzQkFBc0JDLHVCQUF1QixJQUFJeEUsU0FBUyxFQUFFO0FBQ25FLFFBQU15RSxXQUFXekQsWUFBWTtBQUc3QixRQUFNLENBQUMwRCxpQkFBaUJDLGtCQUFrQixJQUFJM0UsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQzRFLGlCQUFpQkMsa0JBQWtCLElBQUk3RSxTQUFTLEtBQUs7QUFHNUQsUUFBTThFLGdCQUFnQkEsQ0FBQ0Msa0JBQWtCO0FBQUEsSUFDdkM7QUFBQSxNQUNFQyxLQUFLO0FBQUEsTUFDTEMsT0FBTyx1QkFBQyxRQUFLLElBQUksVUFBVUYsZUFBZUcsR0FBRyxJQUFJLFdBQVUsbUJBQWtCLHFCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsSUFDcEY7QUFBQSxJQUNBO0FBQUEsTUFDRUYsS0FBSztBQUFBLE1BQ0xDLE9BQU8sdUJBQUMsU0FBSSxXQUFVLGtCQUFpQixTQUFTLE1BQU1FLG9CQUFvQkosZUFBZUcsR0FBRyxHQUFHLG9CQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRGO0FBQUEsSUFDckc7QUFBQSxFQUFDO0FBR0gsUUFBTUUsOEJBQThCQSxDQUFDQyxNQUFNakMsY0FBY2lDLEVBQUVDLE9BQU9DLEtBQUs7QUFFdkUsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUl6RixTQUFTO0FBQUEsSUFDN0MwRixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUkvRixTQUFTLENBQUMsQ0FBQztBQUd2QyxRQUFNLENBQUNnRyxVQUFVQyxXQUFXLElBQUlqRyxTQUFTO0FBQUEsSUFDdkNrRyxTQUFTO0FBQUEsSUFDVEMsdUJBQXVCO0FBQUE7QUFBQSxJQUN2QkMsVUFBVXpEO0FBQUFBLElBQ1YwRCxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLGNBQWM7QUFBQSxJQUNkQyxlQUFlO0FBQUEsSUFDZkMsYUFBYTtBQUFBLElBQ2JDLGtCQUFrQjtBQUFBLElBQ2xCQyxvQkFBb0I7QUFBQSxFQUN0QixDQUFDO0FBRUQsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSWhILFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNpSCx5QkFBeUJDLDBCQUEwQixJQUFJbEgsU0FBUyxLQUFLO0FBQzVFLFFBQU1tSCxZQUFZLElBQUl2RSxNQUFLLG9CQUFJQSxLQUFLLEdBQUV3RSxTQUFRLG9CQUFJeEUsS0FBSyxHQUFFeUUsUUFBUSxJQUFJLENBQUMsQ0FBQyxFQUFFeEUsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBR25HL0MsWUFBVSxNQUFNO0FBQ2QsVUFBTXVILE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBQy9CLFFBQUlHLFNBQVM7QUFDWCxZQUFNRyxjQUFjSCxRQUFRSSx1QkFBdUJDO0FBQ25ELFVBQUlGLGFBQWFHLGlCQUFpQixPQUFRZixrQkFBaUIsSUFBSTtBQUMvRCxVQUFJWSxhQUFhSSx5QkFBeUIsUUFBUTtBQUNoRGhCLHlCQUFpQixJQUFJO0FBQ3JCRSxtQ0FBMkIsSUFBSTtBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUxuSCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUM4QixlQUFnQjtBQUVyQixVQUFNb0csYUFBYTtBQUFBLE1BQ2pCLEdBQUdsRyxvQkFBb0JtRyxJQUFJLENBQUFDLFVBQVMsUUFBUUEsTUFBTUMsV0FBV0MsTUFBTW5ELEdBQUcsSUFBSWlELE1BQU1DLFdBQVdFLE9BQU8sRUFBRTtBQUFBLE1BQ3BHLEdBQUcvRSxlQUFlMkUsSUFBSSxDQUFBSyxVQUFTLFNBQVNBLE1BQU1yRCxHQUFHLEVBQUU7QUFBQSxNQUNuRCxHQUFHN0IsVUFBVTZFLElBQUksQ0FBQU0sYUFBWSxRQUFRQSxTQUFTdEQsR0FBRyxFQUFFO0FBQUEsSUFBQztBQUd0RCxRQUFJK0MsV0FBV1EsU0FBUyxHQUFHO0FBQ3pCakUsOEJBQXdCeUQsVUFBVTtBQUVsQ2xDLGdCQUFVLENBQUEyQyxVQUFTLEVBQUUsR0FBR0EsTUFBTUMsY0FBY0MsT0FBVSxFQUFFO0FBQUEsSUFDMUQ7QUFBQSxFQUNGLEdBQUcsQ0FBQzdHLHFCQUFxQndCLGdCQUFnQkYsV0FBV3hCLGNBQWMsQ0FBQztBQUduRSxRQUFNZ0gsdUJBQXVCLE9BQU9DLFdBQVc7QUFDN0MsUUFBSSxDQUFDQSxPQUFRO0FBQ2JqRSx1QkFBbUIsSUFBSTtBQUN2QixRQUFJO0FBQ0YsWUFBTWtFLFdBQVcsTUFBTTdJLElBQUk4SSxJQUFJLDJCQUEyQkYsTUFBTSxFQUFFO0FBQ2xFLFVBQUlDLFNBQVNFLE1BQU1DLFFBQVE7QUFDekJ2RSwyQkFBbUJvRSxTQUFTRSxLQUFLQSxJQUFJO0FBQUEsTUFDdkMsT0FBTztBQUNMdEUsMkJBQW1CLElBQUk7QUFBQSxNQUN6QjtBQUFBLElBQ0YsU0FBU3dFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkR4RSx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFVBQUM7QUFDQ0UseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNd0UsdUJBQXVCLE9BQU9QLFdBQVc7QUFDN0MsUUFBSSxDQUFDQSxPQUFRO0FBQ2I1Ryx5QkFBcUIsSUFBSTtBQUN6QixRQUFJO0FBQ0YsWUFBTTZHLFdBQVcsTUFBTTdJLElBQUlvSixLQUFLLG1DQUFtQ1IsTUFBTSxFQUFFO0FBQzNFLFlBQU1TLFFBQVFSLFNBQVNFLEtBQUtPLE9BQU8sQ0FBQUMsU0FBUUEsS0FBS3JCLGNBQWNxQixLQUFLckIsV0FBV0MsS0FBSztBQUNuRnJHLDZCQUF1QnVILEtBQUs7QUFBQSxJQUM5QixTQUFTSixPQUFPO0FBQ2RuSCw2QkFBdUIsRUFBRTtBQUFBLElBQzNCLFVBQUM7QUFDQ0UsMkJBQXFCLEtBQUs7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFHQW5DLFlBQVUsTUFBTTtBQUNkLFVBQU0ySixTQUFTLElBQUlDLGdCQUFnQmxGLFNBQVNtRixNQUFNO0FBQ2xELFVBQU1kLFNBQVNZLE9BQU9WLElBQUksUUFBUTtBQUNsQyxVQUFNM0MsU0FBU3FELE9BQU9WLElBQUksUUFBUTtBQUNsQyxRQUFJRixRQUFRO0FBQ1Y3QyxrQkFBWSxDQUFBeUMsVUFBUyxFQUFFLEdBQUdBLE1BQU14QyxTQUFTNEMsT0FBTyxFQUFFO0FBQ2xEaEgsd0JBQWtCZ0gsTUFBTTtBQUN4QkQsMkJBQXFCQyxNQUFNO0FBQzNCTywyQkFBcUJQLE1BQU07QUFBQSxJQUM3QjtBQUNBLFFBQUl6QyxRQUFRO0FBQ1ZKLGtCQUFZLENBQUF5QyxVQUFTLEVBQUUsR0FBR0EsTUFBTXJDLE9BQWUsRUFBRTtBQUFBLElBQ25EO0FBQUEsRUFDRixHQUFHLENBQUM1QixTQUFTbUYsTUFBTSxDQUFDO0FBR3BCN0osWUFBVSxNQUFNO0FBQ2QsUUFBSThCLGdCQUFnQjtBQUNsQmdILDJCQUFxQmhILGNBQWM7QUFDbkN3SCwyQkFBcUJ4SCxjQUFjO0FBQUEsSUFDckM7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsY0FBYyxDQUFDO0FBR25CLFFBQU1nSSw2QkFBNkIsT0FBT0MsVUFBVTtBQUNsREEsVUFBTUMsZUFBZTtBQUNyQixRQUFJLENBQUMvRCxTQUFTRSxXQUFXLENBQUNGLFNBQVNHLHVCQUF1QjtBQUN4RDZELFlBQU0sK0NBQStDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBLFVBQU0sRUFBRUMsVUFBVUMsT0FBTyxJQUFJbEUsU0FBU0c7QUFDdENyQyxzQkFBa0IsSUFBSTtBQUN0QkUsa0JBQWMsSUFBSTtBQUNsQixRQUFJO0FBQ0YsWUFBTStFLFdBQVcsTUFBTTdJLElBQUk4SSxJQUFJLGtDQUFrQztBQUFBLFFBQy9EVSxRQUFRO0FBQUEsVUFDTnhELFNBQVNGLFNBQVNFO0FBQUFBLFVBQ2xCK0Q7QUFBQUEsVUFDQUM7QUFBQUEsVUFDQUMsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGLENBQUM7QUFDRGpHLDJCQUFxQjZFLFNBQVNFLFFBQVEsRUFBRTtBQUFBLElBQzFDLFNBQVNFLE9BQU87QUFDZGpGLDJCQUFxQixFQUFFO0FBQUEsSUFDekIsVUFBQztBQUNDRixvQkFBYyxLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBR0FqRSxZQUFVLE1BQU07QUFDZCxVQUFNcUssMkJBQTJCLFlBQVk7QUFDM0MsVUFBSTtBQUNGLGNBQU1yQixXQUFXLE1BQU03SSxJQUFJOEksSUFBSSxrQ0FBa0NuSCxjQUFjLEVBQUU7QUFDakZ5QixxQkFBYXlGLFNBQVNFLElBQUk7QUFBQSxNQUM1QixTQUFTb0IsS0FBSztBQUNaL0cscUJBQWEsRUFBRTtBQUFBLE1BQ2pCO0FBQUEsSUFDRjtBQUNBOEcsNkJBQXlCO0FBQUEsRUFDM0IsR0FBRyxDQUFDdkksY0FBYyxDQUFDO0FBRW5COUIsWUFBVSxNQUFNO0FBQ2QsVUFBTXVLLG9CQUFvQixZQUFZO0FBQ3BDLFVBQUk7QUFDRixjQUFNdkIsV0FBVyxNQUFNN0ksSUFBSThJLElBQUksd0NBQXdDbkgsY0FBYyxFQUFFO0FBQ3ZGMkIsMEJBQWtCdUYsU0FBU0UsSUFBSTtBQUFBLE1BQ2pDLFNBQVNvQixLQUFLO0FBQ1o3RywwQkFBa0IsRUFBRTtBQUFBLE1BQ3RCO0FBQUEsSUFDRjtBQUNBOEcsc0JBQWtCO0FBQUEsRUFDcEIsR0FBRyxDQUFDekksY0FBYyxDQUFDO0FBRW5COUIsWUFBVSxNQUFNO0FBQ2QsVUFBTXdLLG9CQUFvQixZQUFZO0FBQ3BDLFVBQUk7QUFDRixjQUFNeEIsV0FBVyxNQUFNN0ksSUFBSThJLElBQUksZUFBZTtBQUM5Q3hILGlCQUFTdUgsVUFBVUUsTUFBTUEsUUFBUSxFQUFFO0FBQUEsTUFDckMsU0FBU0UsT0FBTztBQUNkM0gsaUJBQVMsRUFBRTtBQUFBLE1BQ2I7QUFBQSxJQUNGO0FBQ0ErSSxzQkFBa0I7QUFBQSxFQUNwQixHQUFHLEVBQUU7QUFFTHhLLFlBQVUsTUFBTTtBQUNkLFVBQU15SyxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU16QixXQUFXLE1BQU03SSxJQUFJOEksSUFBSSx3QkFBd0I7QUFDdkR0SCx3QkFBZ0JxSCxTQUFTRSxJQUFJO0FBQUEsTUFDL0IsU0FBU0UsT0FBTztBQUNkekgsd0JBQWdCLEVBQUU7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQThJLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFHTCxRQUFNQyxlQUFlQSxNQUFNO0FBQ3pCLFVBQU1DLFlBQVksQ0FBQztBQUNuQixRQUFJLENBQUMxRSxTQUFTRSxRQUFTd0UsV0FBVUMsV0FBVztBQUM1QyxRQUFJLENBQUNwRyx3QkFBd0JBLHFCQUFxQmtFLFdBQVcsR0FBRztBQUM5RGlDLGdCQUFVL0IsZUFBZTtBQUFBLElBQzNCO0FBQ0EsUUFBSSxDQUFDM0MsU0FBU0ksU0FBVXNFLFdBQVV0RSxXQUFXO0FBRTdDLFVBQU1DLFNBQVN1RSxXQUFXNUUsU0FBU0ssTUFBTTtBQUN6QyxRQUFJd0UsTUFBTXhFLE1BQU0sS0FBS0EsVUFBVSxHQUFHO0FBQ2hDcUUsZ0JBQVVyRSxTQUFTO0FBQUEsSUFDckIsV0FBVyxDQUFDM0IsaUJBQWlCO0FBRTNCZ0csZ0JBQVVyRSxTQUFTO0FBQUEsSUFDckIsV0FBV0EsU0FBUzNCLGdCQUFnQm9HLFNBQVM7QUFDM0NKLGdCQUFVckUsU0FBUyw4Q0FBOEMzQixnQkFBZ0JvRyxRQUFRQyxlQUFlLENBQUM7QUFBQSxJQUMzRztBQUdBaEYsY0FBVTJFLFNBQVM7QUFDbkIsV0FBT00sT0FBT0MsS0FBS1AsU0FBUyxFQUFFakMsV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTXlDLGVBQWVBLENBQUM3RixNQUFNO0FBQzFCLFVBQU0sRUFBRThGLE1BQU01RixNQUFNLElBQUlGLEVBQUVDO0FBQzFCLFFBQUk2RixTQUFTLFVBQVU7QUFDckIsVUFBSUMsVUFBVTdGLE1BQU04RixRQUFRLFlBQVksRUFBRTtBQUMxQyxXQUFLRCxRQUFRRSxNQUFNLEtBQUssS0FBSyxJQUFJN0MsU0FBUyxFQUFHO0FBQzdDeEMsa0JBQVksQ0FBQXlDLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUN5QyxJQUFJLEdBQUdDLFFBQVEsRUFBRTtBQUNsRHJGLGdCQUFVLENBQUMsQ0FBQztBQUNaO0FBQUEsSUFDRjtBQUNBRSxnQkFBWSxDQUFBeUMsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ3lDLElBQUksR0FBRzVGLE1BQU0sRUFBRTtBQUNoRFEsY0FBVSxDQUFDLENBQUM7QUFBQSxFQUNkO0FBRUEsUUFBTXdGLGlCQUFpQixPQUFPekMsV0FBVztBQUN2Q2hILHNCQUFrQmdILE1BQU07QUFDeEI3QyxnQkFBWSxDQUFBeUMsVUFBUyxFQUFFLEdBQUdBLE1BQU14QyxTQUFTNEMsUUFBUTNDLHVCQUF1QixLQUFLLEVBQUU7QUFDL0VKLGNBQVUsQ0FBQTJDLFVBQVMsRUFBRSxHQUFHQSxNQUFNaUMsVUFBVSxHQUFHLEVBQUU7QUFDN0NuRyw0QkFBd0IsRUFBRTtBQUFBLEVBQzVCO0FBRUEsUUFBTWdILDBCQUEwQkEsQ0FBQ25HLE1BQU07QUFDckMsVUFBTW9HLE9BQU9wRyxFQUFFQyxPQUFPQztBQUN0QjdDLG1CQUFlK0ksSUFBSTtBQUNuQnhGLGdCQUFZLENBQUF5QyxVQUFTO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSHBDLFVBQVVtRjtBQUFBQSxNQUNWbEYsZ0JBQWdCa0YsU0FBUyxTQUFTLEtBQUsvQyxLQUFLbkM7QUFBQUEsTUFDNUMsR0FBSWtGLFNBQVMsWUFBWSxFQUFFOUUsZUFBZSxJQUFJQyxhQUFhLElBQUlDLGtCQUFrQixJQUFJQyxvQkFBb0IsR0FBRztBQUFBLElBQzlHLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTTRFLGVBQWUsT0FBT3JHLE1BQU07QUFDaENBLE1BQUUwRSxlQUFlO0FBQ2pCLFFBQUksQ0FBQ1UsYUFBYSxFQUFHO0FBRXJCLFVBQU1rQixRQUFRakUsS0FBS0MsTUFBTUosYUFBYUMsUUFBUSxNQUFNLEtBQUssSUFBSTtBQVE3RCxVQUFNb0UsVUFBVTtBQUFBLE1BQ2QxRixTQUFTRixTQUFTRTtBQUFBQSxNQUNsQkMsdUJBQXVCNUI7QUFBQUEsTUFDdkI2QixVQUFVSixTQUFTSTtBQUFBQSxNQUNuQkMsUUFBUXVFLFdBQVc1RSxTQUFTSyxNQUFNO0FBQUEsTUFDbENDLFVBQVVOLFNBQVNNO0FBQUFBLE1BQ25CRSxZQUFZbUYsTUFBTXpHO0FBQUFBLE1BQ2xCcUIsZ0JBQWdCUCxTQUFTTyxrQkFBa0I7QUFBQSxNQUMzQ0UsU0FBU1QsU0FBU1MsV0FBVztBQUFBLE1BQzdCQyxjQUFjVixTQUFTVSxnQkFBZ0I7QUFBQSxNQUN2QyxHQUFJVixTQUFTTSxhQUFhLFlBQVk7QUFBQSxRQUNwQ0ssZUFBZVgsU0FBU1c7QUFBQUEsUUFDeEJDLGFBQWFaLFNBQVNZO0FBQUFBLFFBQ3RCQyxrQkFBa0JiLFNBQVNhO0FBQUFBLFFBQzNCQyxvQkFBb0JkLFNBQVNjO0FBQUFBLE1BQy9CO0FBQUEsSUFDRjtBQUNBcEQsMEJBQXNCLElBQUk7QUFDMUIsUUFBSTtBQUNGLFlBQU14RCxJQUFJb0osS0FBSyxnQ0FBZ0NzQyxPQUFPO0FBQ3REbkcscUJBQWUsRUFBRUMsWUFBWSxNQUFNQyxTQUFTLG1DQUFtQ0UsTUFBTSxXQUFXRCxVQUFVLEtBQUssQ0FBQztBQUVoSEssa0JBQVk7QUFBQSxRQUNWQyxTQUFTO0FBQUEsUUFDVEMsdUJBQXVCO0FBQUEsUUFDdkJDLFVBQVV6RDtBQUFBQSxRQUNWMEQsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxnQkFBZ0I7QUFBQSxRQUNoQkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxjQUFjO0FBQUEsUUFDZEMsZUFBZTtBQUFBLFFBQ2ZDLGFBQWE7QUFBQSxRQUNiQyxrQkFBa0I7QUFBQSxRQUNsQkMsb0JBQW9CO0FBQUEsTUFDdEIsQ0FBQztBQUNEaEYsd0JBQWtCLEVBQUU7QUFFcEJFLDZCQUF1QixFQUFFO0FBQ3pCMkMseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTd0UsT0FBTztBQUNkMUQscUJBQWUsRUFBRUMsWUFBWSxNQUFNQyxTQUFTd0QsTUFBTXhELFdBQVcscUJBQXFCRSxNQUFNLFNBQVNELFVBQVUsS0FBSyxDQUFDO0FBQUEsSUFDbkgsVUFBQztBQUNDbEMsNEJBQXNCLEtBQUs7QUFDM0JjLDhCQUF3QixFQUFFO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBRUEsUUFBTVcsc0JBQXNCLE9BQU8wRyxjQUFjO0FBQy9DM0ksZUFBVyxJQUFJO0FBQ2ZkLHFCQUFpQixJQUFJO0FBQ3JCd0Isc0JBQWtCaUksU0FBUztBQUMzQnZILGtCQUFjLElBQUk7QUFDbEIsUUFBSTtBQUNGLFlBQU13SCxNQUFNLE1BQU01TCxJQUFJOEksSUFBSSw4QkFBOEI2QyxTQUFTLEVBQUU7QUFDbkV2SiwwQkFBb0J3SixJQUFJN0MsSUFBSTtBQUFBLElBQzlCLFNBQVNFLE9BQU87QUFDZEMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBQ3JCLFVBQUM7QUFDQ2pHLGlCQUFXLEtBQUs7QUFDaEJvQixvQkFBYyxLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDR2IsK0JBQ0MsdUJBQUMsc0JBQW1CLE9BQU0saUNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUQsSUFFdkQsdUJBQUMsU0FBSSxXQUFVLGlDQUNiLGlDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkJBQUMsVUFBTyw2QkFBMEQsWUFBWSxRQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1GO0FBQUEsTUFDbkY7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU0rQixZQUFZSztBQUFBQSxVQUNsQixXQUFXTCxZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQSxVQUNyQixVQUFVSCxZQUFZSTtBQUFBQTtBQUFBQSxRQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJaUM7QUFBQSxNQUdqQyx1QkFBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1gsdUJBQUMsU0FBSSxXQUFVLHFCQUNiLGlDQUFDLFNBQUksV0FBVSxrREFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSwrQ0FBOEMsNkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUEsWUFDekUsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixxRkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBRUEsdUJBQUMsVUFBSyxVQUFVOEYsY0FBYyxXQUFVLGlCQUV0QztBQUFBLG1DQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxrQkFBZ0IsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5SDtBQUFBLGdCQUN6SDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLGNBQWMsQ0FBQ0ssT0FBT0MsV0FDcEJBLFFBQVEvRyxPQUFPZ0gsWUFBWSxFQUFFQyxTQUFTSCxNQUFNRSxZQUFZLENBQUM7QUFBQSxvQkFFM0QsT0FBT2pHLFNBQVNFLFdBQVcwQztBQUFBQSxvQkFDM0IsVUFBVTJDO0FBQUFBLG9CQUNWLFNBQVNoSyxNQUFNMkcsSUFBSSxDQUFBWixVQUFTO0FBQUEsc0JBQzFCL0IsT0FBTytCLEtBQUtwQztBQUFBQSxzQkFDWkQsT0FBTyxHQUFHcUMsS0FBSzZFLFNBQVMsTUFBTTdFLEtBQUs4RSxZQUFZO0FBQUEsb0JBQ2pELEVBQUU7QUFBQTtBQUFBLGtCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFhTTtBQUFBLGdCQUVMdEcsT0FBTzZFLFlBQVksdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjdFLGlCQUFPNkUsWUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEQ7QUFBQSxtQkFqQmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsY0E2QkEsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGtCQUMxQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLFVBQVUxSSxzQkFBc0J5QyxpQkFBaUJvRyxXQUFXLE1BQU07QUFBQSxvQkFDbEUsU0FBUzdJO0FBQUFBLG9CQUNULE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsT0FBT3NDO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQzhILFdBQVc7QUFDcEI3SCw4Q0FBd0I2SCxNQUFNO0FBQzlCdEcsZ0NBQVUsQ0FBQTJDLFVBQVMsRUFBRSxHQUFHQSxNQUFNQyxjQUFjQyxPQUFVLEVBQUU7QUFBQSxvQkFDMUQ7QUFBQSxvQkFHQzdHO0FBQUFBLDBDQUFvQm1HLElBQUksQ0FBQUMsVUFBUztBQUNoQyw4QkFBTW1FLFVBQVVuRSxNQUFNQyxXQUFXQyxNQUFNbkQ7QUFDdkMsOEJBQU1nRixTQUFTL0IsTUFBTUMsV0FBV0U7QUFDaEMsOEJBQU0vQyxRQUFRLFFBQVErRyxPQUFPLElBQUlwQyxNQUFNO0FBQ3ZDLDhCQUFNakYsUUFBUSxHQUFHa0QsTUFBTUMsV0FBV0MsTUFBTWtFLFVBQVUsTUFBTXJDLE1BQU07QUFDOUQsK0JBQU8sdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQWVqRixtQkFBdEJNLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdEO0FBQUEsc0JBQ3pELENBQUM7QUFBQSxzQkFFQWhDLGdCQUFnQjJFLElBQUksQ0FBQUssVUFBUztBQUM1Qiw4QkFBTWhELFFBQVEsU0FBU2dELE1BQU1yRCxHQUFHO0FBQ2hDLDhCQUFNRCxRQUFRLEdBQUdzRCxNQUFNaUUsUUFBUSxRQUFRakUsTUFBTWtFLGNBQWM7QUFDM0QsK0JBQU8sdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQWV4SCxtQkFBdEJNLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdEO0FBQUEsc0JBQ3pELENBQUM7QUFBQSxzQkFFQWxDLFdBQVc2RSxJQUFJLENBQUFNLGFBQVk7QUFDMUIsOEJBQU1qRCxRQUFRLFFBQVFpRCxTQUFTdEQsR0FBRztBQUNsQyw4QkFBTUQsUUFBUSxRQUFRdUQsU0FBU2tFLE9BQU8sUUFBUWxFLFNBQVNtRSxXQUFXO0FBQ2xFLCtCQUFPLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFlMUgsbUJBQXRCTSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnRDtBQUFBLHNCQUN6RCxDQUFDO0FBQUE7QUFBQTtBQUFBLGtCQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBaUNBO0FBQUEsZ0JBQ0NPLE9BQU82QyxnQkFBZ0IsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjdDLGlCQUFPNkMsZ0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThEO0FBQUEsbUJBdEN4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVDQTtBQUFBLGlCQXZGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdGQTtBQUFBLFlBR0NqRSxtQkFDQyx1QkFBQyxTQUFJLFdBQVUsbUlBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLGlEQUFnRCxnQ0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkU7QUFBQSxnQkFDN0UsdUJBQUMsT0FBRSxXQUFVLG1DQUFtQ0EsMEJBQWdCeUgsYUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEU7QUFBQSxtQkFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLGlDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLGdCQUN0RCx1QkFBQyxPQUFFLFdBQVUsMENBQXlDO0FBQUE7QUFBQSxrQkFDakRTLE9BQU9sSSxnQkFBZ0JvRyxPQUFPLEVBQUVDLGVBQWU7QUFBQSxxQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFhRix1QkFBQyxTQUFJLFdBQVUsb0RBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsZ0VBQ1o7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsc0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1EO0FBQUEsZ0JBQU87QUFBQSxtQkFENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLG9CQUFhLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0g7QUFBQSxrQkFDdEg7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQU0sTUFBSztBQUFBLHNCQUFPLE1BQUs7QUFBQSxzQkFBVyxPQUFPL0UsU0FBU0k7QUFBQUEsc0JBQVUsVUFBVThFO0FBQUFBLHNCQUNyRSxVQUFVLENBQUNuRTtBQUFBQSxzQkFDWCxLQUFLRSwwQkFBMEJFLFlBQVl5QjtBQUFBQSxzQkFDM0MsS0FBSzNCLDBCQUEwQnRFLFFBQVFpRztBQUFBQSxzQkFDdkMsV0FBVTtBQUFBO0FBQUEsb0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlpRztBQUFBLGtCQUNoRzlDLE9BQU9NLFlBQVksdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qk4saUJBQU9NLFlBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBEO0FBQUEscUJBUGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsSUFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLG9CQUFnQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsdUJBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlIO0FBQUEsa0JBQ3pILHVCQUFDLFdBQU0sTUFBSyxVQUFTLE1BQUssVUFBUyxPQUFPSixTQUFTSyxRQUFRLFVBQVU2RSxjQUFjLGFBQVksZ0JBQWUsV0FBVSw2RkFBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaU47QUFBQSxrQkFDaE5wRixPQUFPTyxVQUFVLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJQLGlCQUFPTyxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLGtCQUMxRSx1QkFBQyxTQUFJLFdBQVUsOEJBQThCbEYsOEJBQW9CNkUsU0FBU0ssTUFBTSxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrRjtBQUFBLHFCQUpwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGtEQUFpRCxrQ0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0Y7QUFBQSxrQkFDcEYsdUJBQUMsY0FBUyxNQUFLLFdBQVUsT0FBT0wsU0FBU1MsU0FBUyxVQUFVeUUsY0FBYyxNQUFNLEdBQUcsYUFBWSxzREFBcUQsV0FBVSx3REFBOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbU47QUFBQSxxQkFGck47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRCQTtBQUFBLGVBR0VsRixTQUFTTSxhQUFhLFlBQVlOLFNBQVNNLGFBQWEsaUJBQ3hELHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGtCQUFlLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0g7QUFBQSxnQkFDeEg7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQU0sTUFBSztBQUFBLG9CQUFPLE1BQUs7QUFBQSxvQkFBaUIsT0FBT04sU0FBU087QUFBQUEsb0JBQWdCLFVBQVUyRTtBQUFBQSxvQkFDakYsYUFBWTtBQUFBLG9CQUF1QixXQUFVO0FBQUE7QUFBQSxrQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNtRztBQUFBLGdCQUNsR3BGLE9BQU9TLGtCQUFrQix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCVCxpQkFBT1Msa0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdFO0FBQUEsbUJBSjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUlEUCxTQUFTTSxhQUFhLFlBQ3JCLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw4Q0FBNkMsOEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlFO0FBQUEsZ0JBQ3pFLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHlDQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxzQkFBYyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVIO0FBQUEsb0JBQ3ZILHVCQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUssaUJBQWdCLE9BQU9OLFNBQVNXLGVBQWUsVUFBVXVFLGNBQWMsV0FBVSx3REFBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNko7QUFBQSxvQkFDNUpwRixPQUFPYSxpQkFBaUIsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QmIsaUJBQU9hLGlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErRDtBQUFBLHVCQUgxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLHNCQUFZLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUg7QUFBQSxvQkFDckgsdUJBQUMsV0FBTSxNQUFLLFFBQU8sTUFBSyxlQUFjLE9BQU9YLFNBQVNZLGFBQWEsVUFBVXNFLGNBQWMsV0FBVSx3REFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUo7QUFBQSxvQkFDeEpwRixPQUFPYyxlQUFlLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJkLGlCQUFPYyxlQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RDtBQUFBLHVCQUh0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxrREFBaUQseUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJFO0FBQUEsb0JBQzNFLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUssb0JBQW1CLE9BQU9aLFNBQVNhLGtCQUFrQixVQUFVcUUsY0FBYyxXQUFVLHdEQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtSztBQUFBLHVCQUZySztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxrREFBaUQsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZFO0FBQUEsb0JBQzdFLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUssc0JBQXFCLE9BQU9sRixTQUFTYyxvQkFBb0IsVUFBVW9FLGNBQWMsV0FBVSx3REFBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUs7QUFBQSx1QkFGeks7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLG1CQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGlCQXBFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNFQTtBQUFBLFlBdUJBLHVCQUFDLFNBQUksV0FBVSxvRkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLG9CQUFpQixXQUFVLDZCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRDtBQUFBLGdCQUNyRCx1QkFBQyxVQUFLLFdBQVUsK0JBQThCLHFDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRTtBQUFBLG1CQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsMENBQ2Y7QUFBQSx1Q0FBQyxXQUFNLE1BQUssWUFBVyxTQUFTM0ksZ0JBQWdCLFVBQVUsQ0FBQzhDLE1BQU03QyxrQkFBa0I2QyxFQUFFQyxPQUFPdUgsT0FBTyxHQUFHLFdBQVUsb0NBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdKO0FBQUEsZ0JBQ2hKLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsaUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlEO0FBQUEsbUJBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTyxNQUFLO0FBQUEsZ0JBQ1gsV0FBVTtBQUFBLGdCQUNWLFdBQVduSSxpQkFBaUJvRyxXQUFXLE1BQU07QUFBQSxnQkFBRyxRQUM3Q3BHLGlCQUFpQm9HLFdBQVcsTUFBTSxJQUMvQixzQ0FDQTtBQUFBLGdCQUNKO0FBQUE7QUFBQSxjQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1nQixLQVBsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUF0T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1T0E7QUFBQSxhQWhQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaVBBLEtBbFBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtUEE7QUFBQSxXQXJQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc1BBO0FBQUEsTUFHQSx1QkFBQyxVQUFPLE9BQU0sMkJBQTBCLFdBQVUsU0FBUSxNQUFNakgsZ0JBQWdCLFNBQVMsTUFBTUMsa0JBQWtCLEtBQUssR0FBRyxPQUFPLEtBQUssU0FBU0MsWUFDM0lFLDRCQUFrQndFLFdBQVcsSUFDNUIsdUJBQUMsU0FBSSxXQUFVLGtDQUFpQyxvQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRSxJQUVwRSx1QkFBQyxTQUFJLFdBQVUsYUFDWnhFLDRCQUFrQmlFO0FBQUFBLFFBQUksQ0FBQzRFLEdBQUdDLE1BQ3pCLHVCQUFDLFNBQVksV0FBVSw0Q0FDckI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsYUFBWTtBQUFBLG1DQUFDLFVBQUssV0FBVSxzQkFBcUIsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUEsWUFBTyx1QkFBQyxVQUFNRCxZQUFFMUcsWUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQjtBQUFBLGVBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZHO0FBQUEsVUFDNUcwRyxFQUFFN0MsWUFBWSx1QkFBQyxTQUFJLFdBQVUsYUFBWTtBQUFBLG1DQUFDLFVBQUssV0FBVSxzQkFBcUIsc0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDO0FBQUEsWUFBTyx1QkFBQyxVQUFNNkMsWUFBRTdDLFVBQVVzQyxjQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBLGVBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtIO0FBQUEsVUFDaElPLEVBQUU1QyxVQUFVLHVCQUFDLFNBQUksV0FBVSxhQUFZO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHNCQUFxQix1QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQSxZQUFPLHVCQUFDLFVBQU00QyxZQUFFNUMsVUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBLGVBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFHO0FBQUEsVUFDbEgsdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsc0JBQXFCLHVCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBLFlBQU8sdUJBQUMsVUFBSztBQUFBO0FBQUEsY0FBRTRDLEVBQUV6RztBQUFBQSxpQkFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLGVBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNHO0FBQUEsVUFDdEcsdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsc0JBQXFCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLFlBQU8sdUJBQUMsVUFBTXlHLFlBQUV4RyxZQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtCO0FBQUEsZUFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkc7QUFBQSxVQUM3Ryx1QkFBQyxTQUFJLFdBQVUsUUFBTztBQUFBLG1DQUFDLFVBQUssV0FBVSxzQkFBcUIscUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsWUFBTyx1QkFBQyxVQUFNd0csWUFBRTVHLFNBQVNpRyxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QjtBQUFBLGVBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBHO0FBQUEsYUFObEdZLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsTUFDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQSxLQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUVBLHVCQUFDLFlBQVMsTUFBTTVLLGVBQWUsVUFBVSxNQUFNQyxpQkFBaUIsS0FBSyxHQUFHLFFBQVEsTUFBTSxPQUFPLEtBQzNGO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBCQUF5QiwrQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQ3RELHVCQUFDLFNBQUksV0FBVSxvQ0FDYixpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpQ0FBQyxTQUFJO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFnQixzQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUFPO0FBQUEsWUFBRUMsa0JBQWtCNEgsVUFBVXNDO0FBQUFBLGVBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsVUFDM0YsdUJBQUMsU0FBSTtBQUFBLG1DQUFDLFVBQUssV0FBVSxpQkFBZ0IsNEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDO0FBQUEsWUFBTztBQUFBLFlBQUVsSyxrQkFBa0I0SCxVQUFVK0M7QUFBQUEsZUFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0c7QUFBQSxVQUNsRyx1QkFBQyxTQUFJO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFnQixxQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxZQUFPO0FBQUEsWUFBRTNLLGtCQUFrQjZELFNBQVNpRztBQUFBQSxZQUFVO0FBQUEsWUFBWTlKLGtCQUFrQjZIO0FBQUFBLGVBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZIO0FBQUEsVUFDN0gsdUJBQUMsU0FBSTtBQUFBLG1DQUFDLFVBQUssV0FBVSxpQkFBZ0IsdUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUEsWUFBTztBQUFBLFlBQUU3SCxrQkFBa0JnRTtBQUFBQSxlQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLFVBQzlFLHVCQUFDLFNBQUk7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLHlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBLFlBQU87QUFBQSxZQUFFaEUsa0JBQWtCaUU7QUFBQUEsZUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Y7QUFBQSxVQUNsRix1QkFBQyxTQUFJO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFnQix5QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUFPO0FBQUEsWUFBRWpFLGtCQUFrQitELFVBQVV0RCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsZUFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUc7QUFBQSxVQUNoR1Qsa0JBQWtCc0UsaUJBQWlCLHVCQUFDLFNBQUk7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQztBQUFBLFlBQU87QUFBQSxZQUFFdEUsaUJBQWlCc0U7QUFBQUEsZUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUY7QUFBQSxVQUMxSHRFLGtCQUFrQmtFLGtCQUFrQix1QkFBQyxTQUFJO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFnQiwrQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0M7QUFBQSxZQUFPO0FBQUEsWUFBRWxFLGlCQUFpQmtFO0FBQUFBLGVBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZGO0FBQUEsYUFScEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQW5TRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb1NBO0FBQUEsT0F0U0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVTQSxLQXhTRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeVNBLEtBN1NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErU0E7QUFFSjtBQUFFakYsR0F0cUJJRCxxQkFBbUI7QUFBQSxVQTBCTkwsV0FBVztBQUFBO0FBQUFpTSxLQTFCeEI1TDtBQXdxQk4sZUFBZUE7QUFBb0IsSUFBQTRMO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkNpcmN1bGFyTG9hZGVyIiwiRmFXaGF0c2FwcFNxdWFyZSIsIk5hdmJhciIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiTW9kYWwiLCJBbnRNb2RhbCIsIkRyYXdlciIsIlRvb2x0aXAiLCJJb01kTW9yZSIsIkxpbmsiLCJ1c2VMb2NhdGlvbiIsIkJhY2tkcm9wQmx1ckxvYWRlciIsIkZhUmVjZWlwdCIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJCcmVhZGNydW1iIiwiQ2hpdENhbmNlbFBheW1lbnRJbiIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsImFjdHVhbEdyb3VwcyIsInNldEFjdHVhbEdyb3VwcyIsIlRhYmxlUGF5bWVudHMiLCJzZXRUYWJsZVBheW1lbnRzIiwic2VsZWN0ZWRVc2VySWQiLCJzZXRTZWxlY3RlZFVzZXJJZCIsImZpbHRlcmVkRW5yb2xsbWVudHMiLCJzZXRGaWx0ZXJlZEVucm9sbG1lbnRzIiwiZW5yb2xsbWVudExvYWRpbmciLCJzZXRFbnJvbGxtZW50TG9hZGluZyIsInNob3dNb2RhbFZpZXciLCJzZXRTaG93TW9kYWxWaWV3IiwiY3VycmVudFZpZXdHcm91cCIsInNldEN1cnJlbnRWaWV3R3JvdXAiLCJ3aGF0c2FwcEVuYWJsZSIsInNldFdoYXRzYXBwRW5hYmxlIiwicGF5bWVudE1vZGUiLCJzZXRQYXltZW50TW9kZSIsInRvZGF5IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiYm9ycm93ZXJzIiwic2V0Qm9ycm93ZXJzIiwicGlnbWVDdXN0b21lcnMiLCJzZXRQaWdtZUN1c3RvbWVycyIsIm9wZW5CYWNrZHJvcExvYWRlciIsInNldE9wZW5CYWNrZHJvcExvYWRlciIsImN1cnJlbnRHcm91cElkIiwic2V0Q3VycmVudEdyb3VwSWQiLCJvcGVuQW50RERyYXdlciIsInNldE9wZW5BbnRERHJhd2VyIiwic2hvd0xvYWRlciIsInNldFNob3dMb2FkZXIiLCJsYXN0VGhyZWVQYXltZW50cyIsInNldExhc3RUaHJlZVBheW1lbnRzIiwic2hvd0dyb3VwUGF5bWVudCIsInNldFNob3dHcm91cFBheW1lbnQiLCJ2aWV3TG9hZGVyIiwic2V0Vmlld0xvYWRlciIsInNlbGVjdGVkR3JvdXBUaWNrZXRzIiwic2V0U2VsZWN0ZWRHcm91cFRpY2tldHMiLCJsb2NhdGlvbiIsInVzZXJBY2NvdW50SW5mbyIsInNldFVzZXJBY2NvdW50SW5mbyIsImZldGNoaW5nQmFsYW5jZSIsInNldEZldGNoaW5nQmFsYW5jZSIsImRyb3BEb3duSXRlbXMiLCJwYXltZW50T2JqZWN0Iiwia2V5IiwibGFiZWwiLCJfaWQiLCJoYW5kbGVWaWV3TW9kYWxPcGVuIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsInZhbHVlIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwibm9SZWxvYWQiLCJ0eXBlIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInVzZXJfaWQiLCJwYXltZW50X2dyb3VwX3RpY2tldHMiLCJwYXlfZGF0ZSIsImFtb3VudCIsInBheV90eXBlIiwidHJhbnNhY3Rpb25faWQiLCJhZG1pbl90eXBlIiwicmVtYXJrcyIsImFjY291bnRfdHlwZSIsImNoZXF1ZV9udW1iZXIiLCJjaGVxdWVfZGF0ZSIsImNoZXF1ZV9iYW5rX25hbWUiLCJjaGVxdWVfYmFua19icmFuY2giLCJtb2RpZnlQYXltZW50Iiwic2V0TW9kaWZ5UGF5bWVudCIsIm1vZGlmeU1pbk1heFBheW1lbnREYXRlIiwic2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGUiLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsInBlcm1pc3Npb25zIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiZWRpdF9saW1pdGVkX3BheW1lbnQiLCJhbGxPcHRpb25zIiwibWFwIiwiZW50cnkiLCJlbnJvbGxtZW50IiwiZ3JvdXAiLCJ0aWNrZXRzIiwicGlnbWUiLCJib3Jyb3dlciIsImxlbmd0aCIsInByZXYiLCJncm91cF90aWNrZXQiLCJ1bmRlZmluZWQiLCJmZXRjaFVzZXJBY2NvdW50SW5mbyIsInVzZXJJZCIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsInN0YXR1cyIsImVycm9yIiwiY29uc29sZSIsImZldGNoVXNlckVucm9sbG1lbnRzIiwicG9zdCIsInZhbGlkIiwiZmlsdGVyIiwiaXRlbSIsInBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsInNlYXJjaCIsImZldGNoTGFzdFRocmVlVHJhbnNhY3Rpb25zIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImFsZXJ0IiwiZ3JvdXBfaWQiLCJ0aWNrZXQiLCJsaW1pdCIsImZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscyIsImVyciIsImZldGNoUGlnbWVEZXRhaWxzIiwiZmV0Y2hBbGxDdXN0b21lcnMiLCJmZXRjaEdyb3VwcyIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsImN1c3RvbWVyIiwicGFyc2VGbG9hdCIsImlzTmFOIiwiYmFsYW5jZSIsInRvTG9jYWxlU3RyaW5nIiwiT2JqZWN0Iiwia2V5cyIsImhhbmRsZUNoYW5nZSIsIm5hbWUiLCJjbGVhbmVkIiwicmVwbGFjZSIsIm1hdGNoIiwiaGFuZGxlQ3VzdG9tZXIiLCJoYW5kbGVQYXltZW50TW9kZUNoYW5nZSIsIm1vZGUiLCJoYW5kbGVTdWJtaXQiLCJhZG1pbiIsInBheWxvYWQiLCJwYXltZW50SWQiLCJyZXMiLCJpbnB1dCIsIm9wdGlvbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJ2YWx1ZXMiLCJncm91cElkIiwiZ3JvdXBfbmFtZSIsInBpZ21lX2lkIiwicGF5YWJsZV9hbW91bnQiLCJsb2FuX2lkIiwibG9hbl9hbW91bnQiLCJOdW1iZXIiLCJjaGVja2VkIiwicCIsImkiLCJncm91cF92YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNoaXRDYW5jZWxQYXltZW50SW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHBTcXVhcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIERyb3Bkb3duLCBNb2RhbCBhcyBBbnRNb2RhbCwgRHJhd2VyLCBUb29sdGlwIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgTGluaywgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgQmFja2Ryb3BCbHVyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQmFja2Ryb3BCbHVyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhUmVjZWlwdCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcbmNvbnN0IENoaXRDYW5jZWxQYXltZW50SW4gPSAoKSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FjdHVhbEdyb3Vwcywgc2V0QWN0dWFsR3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVQYXltZW50cywgc2V0VGFibGVQYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVXNlcklkLCBzZXRTZWxlY3RlZFVzZXJJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZmlsdGVyZWRFbnJvbGxtZW50cywgc2V0RmlsdGVyZWRFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2Vucm9sbG1lbnRMb2FkaW5nLCBzZXRFbnJvbGxtZW50TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFZpZXcsIHNldFNob3dNb2RhbFZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Vmlld0dyb3VwLCBzZXRDdXJyZW50Vmlld0dyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt3aGF0c2FwcEVuYWJsZSwgc2V0V2hhdHNhcHBFbmFibGVdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW3BheW1lbnRNb2RlLCBzZXRQYXltZW50TW9kZV0gPSB1c2VTdGF0ZShcImNhc2hcIik7XHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtib3Jyb3dlcnMsIHNldEJvcnJvd2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3BpZ21lQ3VzdG9tZXJzLCBzZXRQaWdtZUN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW29wZW5CYWNrZHJvcExvYWRlciwgc2V0T3BlbkJhY2tkcm9wTG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwSWQsIHNldEN1cnJlbnRHcm91cElkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtvcGVuQW50RERyYXdlciwgc2V0T3BlbkFudEREcmF3ZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TG9hZGVyLCBzZXRTaG93TG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbGFzdFRocmVlUGF5bWVudHMsIHNldExhc3RUaHJlZVBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd0dyb3VwUGF5bWVudCwgc2V0U2hvd0dyb3VwUGF5bWVudF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3ZpZXdMb2FkZXIsIHNldFZpZXdMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIC8vIFJlbW92ZSBwYXltZW50X2dyb3VwX3RpY2tldHMgZnJvbSBmb3JtRGF0YSDigJMgd2Ugd2lsbCB1c2UgYSBzZXBhcmF0ZSBzdGF0ZVxyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwVGlja2V0cywgc2V0U2VsZWN0ZWRHcm91cFRpY2tldHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuXHJcbiAgLy8gU3RhdGUgZm9yIHVzZXIgYWNjb3VudCBpbmZvXHJcbiAgY29uc3QgW3VzZXJBY2NvdW50SW5mbywgc2V0VXNlckFjY291bnRJbmZvXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtmZXRjaGluZ0JhbGFuY2UsIHNldEZldGNoaW5nQmFsYW5jZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIERyb3Bkb3duIGl0ZW1zIGZvciB0aGUgRGF0YVRhYmxlICh1bmNoYW5nZWQpXHJcbiAgY29uc3QgZHJvcERvd25JdGVtcyA9IChwYXltZW50T2JqZWN0KSA9PiBbXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgIGxhYmVsOiA8TGluayB0bz17YC9wcmludC8ke3BheW1lbnRPYmplY3Q/Ll9pZH1gfSBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDBcIj5QcmludDwvTGluaz4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICBsYWJlbDogPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdNb2RhbE9wZW4ocGF5bWVudE9iamVjdD8uX2lkKX0+VmlldzwvZGl2PixcclxuICAgIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG5cclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIG5vUmVsb2FkOiBmYWxzZSxcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICAvLyBVcGRhdGVkIGZvcm1EYXRhIChrZXB0IGFzIGJlZm9yZSwgYnV0IHdlJ2xsIG1vZGlmeSBwYXlsb2FkKVxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogbnVsbCwgICAgICAvLyB7IGdyb3VwX2lkLCB0aWNrZXQgfVxyXG4gICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X3R5cGU6IFwiVHJhbnNmZXJcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgYWRtaW5fdHlwZTogXCJcIixcclxuICAgIHJlbWFya3M6IFwiXCIsXHJcbiAgICBhY2NvdW50X3R5cGU6IFwiXCIsXHJcbiAgICBjaGVxdWVfbnVtYmVyOiBcIlwiLFxyXG4gICAgY2hlcXVlX2RhdGU6IFwiXCIsXHJcbiAgICBjaGVxdWVfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgY2hlcXVlX2JhbmtfYnJhbmNoOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbbW9kaWZ5UGF5bWVudCwgc2V0TW9kaWZ5UGF5bWVudF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW21vZGlmeU1pbk1heFBheW1lbnREYXRlLCBzZXRNb2RpZnlNaW5NYXhQYXltZW50RGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUobmV3IERhdGUoKS5zZXREYXRlKG5ldyBEYXRlKCkuZ2V0RGF0ZSgpIC0gMSkpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuICAvLyBQZXJtaXNzaW9uIGNoZWNrXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBjb25zdCB1c2VyT2JqID0gSlNPTi5wYXJzZSh1c2VyKTtcclxuICAgIGlmICh1c2VyT2JqKSB7XHJcbiAgICAgIGNvbnN0IHBlcm1pc3Npb25zID0gdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucztcclxuICAgICAgaWYgKHBlcm1pc3Npb25zPy5lZGl0X3BheW1lbnQgPT09IFwidHJ1ZVwiKSBzZXRNb2RpZnlQYXltZW50KHRydWUpO1xyXG4gICAgICBpZiAocGVybWlzc2lvbnM/LmVkaXRfbGltaXRlZF9wYXltZW50ID09PSBcInRydWVcIikge1xyXG4gICAgICAgIHNldE1vZGlmeVBheW1lbnQodHJ1ZSk7XHJcbiAgICAgICAgc2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGUodHJ1ZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9LCBbXSk7XHJcbiAgLy8gQXV0by1zZWxlY3QgYWxsIGF2YWlsYWJsZSBvcHRpb25zIHdoZW4gZGF0YSBjaGFuZ2VzIGZvciB0aGUgc2VsZWN0ZWQgY3VzdG9tZXJcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZFVzZXJJZCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGFsbE9wdGlvbnMgPSBbXHJcbiAgICAgIC4uLmZpbHRlcmVkRW5yb2xsbWVudHMubWFwKGVudHJ5ID0+IGBjaGl0LSR7ZW50cnkuZW5yb2xsbWVudC5ncm91cC5faWR9fCR7ZW50cnkuZW5yb2xsbWVudC50aWNrZXRzfWApLFxyXG4gICAgICAuLi5waWdtZUN1c3RvbWVycy5tYXAocGlnbWUgPT4gYHBpZ21lLSR7cGlnbWUuX2lkfWApLFxyXG4gICAgICAuLi5ib3Jyb3dlcnMubWFwKGJvcnJvd2VyID0+IGBsb2FuLSR7Ym9ycm93ZXIuX2lkfWApXHJcbiAgICBdO1xyXG5cclxuICAgIGlmIChhbGxPcHRpb25zLmxlbmd0aCA+IDApIHtcclxuICAgICAgc2V0U2VsZWN0ZWRHcm91cFRpY2tldHMoYWxsT3B0aW9ucyk7XHJcbiAgICAgIC8vIENsZWFyIGFueSBwcmV2aW91cyBlcnJvciBhYm91dCBncm91cF90aWNrZXRcclxuICAgICAgc2V0RXJyb3JzKHByZXYgPT4gKHsgLi4ucHJldiwgZ3JvdXBfdGlja2V0OiB1bmRlZmluZWQgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtmaWx0ZXJlZEVucm9sbG1lbnRzLCBwaWdtZUN1c3RvbWVycywgYm9ycm93ZXJzLCBzZWxlY3RlZFVzZXJJZF0pO1xyXG5cclxuICAvLyBGZXRjaCB1c2VyIGFjY291bnQgYmFsYW5jZVxyXG4gIGNvbnN0IGZldGNoVXNlckFjY291bnRJbmZvID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgaWYgKCF1c2VySWQpIHJldHVybjtcclxuICAgIHNldEZldGNoaW5nQmFsYW5jZSh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL3VzZXItYWNjb3VudHMvJHt1c2VySWR9YCk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5zdGF0dXMpIHtcclxuICAgICAgICBzZXRVc2VyQWNjb3VudEluZm8ocmVzcG9uc2UuZGF0YS5kYXRhKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRVc2VyQWNjb3VudEluZm8obnVsbCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGFjY291bnQ6XCIsIGVycm9yKTtcclxuICAgICAgc2V0VXNlckFjY291bnRJbmZvKG51bGwpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RmV0Y2hpbmdCYWxhbmNlKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBGZXRjaCBlbnJvbGxtZW50cyBmb3IgYSBnaXZlbiB1c2VyXHJcbiAgY29uc3QgZmV0Y2hVc2VyRW5yb2xsbWVudHMgPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICBpZiAoIXVzZXJJZCkgcmV0dXJuO1xyXG4gICAgc2V0RW5yb2xsbWVudExvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KGAvZW5yb2xsL2dldC11c2VyLXRpY2tldHMtcmVwb3J0LyR7dXNlcklkfWApO1xyXG4gICAgICBjb25zdCB2YWxpZCA9IHJlc3BvbnNlLmRhdGEuZmlsdGVyKGl0ZW0gPT4gaXRlbS5lbnJvbGxtZW50ICYmIGl0ZW0uZW5yb2xsbWVudC5ncm91cCk7XHJcbiAgICAgIHNldEZpbHRlcmVkRW5yb2xsbWVudHModmFsaWQpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0RmlsdGVyZWRFbnJvbGxtZW50cyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRFbnJvbGxtZW50TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIFVSTCBwYXJhbWV0ZXJzICh1c2VySWQgJiBhbW91bnQpXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKTtcclxuICAgIGNvbnN0IHVzZXJJZCA9IHBhcmFtcy5nZXQoXCJ1c2VySWRcIik7XHJcbiAgICBjb25zdCBhbW91bnQgPSBwYXJhbXMuZ2V0KFwiYW1vdW50XCIpO1xyXG4gICAgaWYgKHVzZXJJZCkge1xyXG4gICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHVzZXJfaWQ6IHVzZXJJZCB9KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVXNlcklkKHVzZXJJZCk7XHJcbiAgICAgIGZldGNoVXNlckFjY291bnRJbmZvKHVzZXJJZCk7XHJcbiAgICAgIGZldGNoVXNlckVucm9sbG1lbnRzKHVzZXJJZCk7XHJcbiAgICB9XHJcbiAgICBpZiAoYW1vdW50KSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgYW1vdW50OiBhbW91bnQgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtsb2NhdGlvbi5zZWFyY2hdKTtcclxuXHJcbiAgLy8gV2hlbiBzZWxlY3RlZFVzZXJJZCBjaGFuZ2VzIChmcm9tIGRyb3Bkb3duKSwgZmV0Y2ggYWNjb3VudCBpbmZvIGFuZCBlbnJvbGxtZW50c1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRVc2VySWQpIHtcclxuICAgICAgZmV0Y2hVc2VyQWNjb3VudEluZm8oc2VsZWN0ZWRVc2VySWQpO1xyXG4gICAgICBmZXRjaFVzZXJFbnJvbGxtZW50cyhzZWxlY3RlZFVzZXJJZCk7XHJcbiAgICB9XHJcbiAgfSwgW3NlbGVjdGVkVXNlcklkXSk7XHJcblxyXG4gIC8vIGZldGNoTGFzdFRocmVlVHJhbnNhY3Rpb25zICh1bmNoYW5nZWQpXHJcbiAgY29uc3QgZmV0Y2hMYXN0VGhyZWVUcmFuc2FjdGlvbnMgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAoIWZvcm1EYXRhLnVzZXJfaWQgfHwgIWZvcm1EYXRhLnBheW1lbnRfZ3JvdXBfdGlja2V0cykge1xyXG4gICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgY3VzdG9tZXIgYW5kIGdyb3VwL3RpY2tldCBmaXJzdFwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgY29uc3QgeyBncm91cF9pZCwgdGlja2V0IH0gPSBmb3JtRGF0YS5wYXltZW50X2dyb3VwX3RpY2tldHM7XHJcbiAgICBzZXRPcGVuQW50RERyYXdlcih0cnVlKTtcclxuICAgIHNldFNob3dMb2FkZXIodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCJwYXltZW50L2dldC1sYXN0LW4tdHJhbnNhY3Rpb25cIiwge1xyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgdXNlcl9pZDogZm9ybURhdGEudXNlcl9pZCxcclxuICAgICAgICAgIGdyb3VwX2lkOiBncm91cF9pZCxcclxuICAgICAgICAgIHRpY2tldDogdGlja2V0LFxyXG4gICAgICAgICAgbGltaXQ6IDMsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldExhc3RUaHJlZVBheW1lbnRzKHJlc3BvbnNlLmRhdGEgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0TGFzdFRocmVlUGF5bWVudHMoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0U2hvd0xvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gRmV0Y2ggbG9hbnMgJiBwaWdtZSAodW5jaGFuZ2VkKVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvbG9hbnMvZ2V0LWJvcnJvd2VyLWJ5LXVzZXItaWQvJHtzZWxlY3RlZFVzZXJJZH1gKTtcclxuICAgICAgICBzZXRCb3Jyb3dlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIHNldEJvcnJvd2VycyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMoKTtcclxuICB9LCBbc2VsZWN0ZWRVc2VySWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUGlnbWVEZXRhaWxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BpZ21lL2dldC1waWdtZS1jdXN0b21lci1ieS11c2VyLWlkLyR7c2VsZWN0ZWRVc2VySWR9YCk7XHJcbiAgICAgICAgc2V0UGlnbWVDdXN0b21lcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoUGlnbWVEZXRhaWxzKCk7XHJcbiAgfSwgW3NlbGVjdGVkVXNlcklkXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEFsbEN1c3RvbWVycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCJ1c2VyL3ZlcmlmaWVkXCIpO1xyXG4gICAgICAgIHNldFVzZXJzKHJlc3BvbnNlPy5kYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRVc2VycyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEFsbEN1c3RvbWVycygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0QWN0dWFsR3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHNldEFjdHVhbEdyb3VwcyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gVXBkYXRlZCB2YWxpZGF0aW9uIHdpdGggYmFsYW5jZSBjaGVja1xyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICgpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgaWYgKCFmb3JtRGF0YS51c2VyX2lkKSBuZXdFcnJvcnMuY3VzdG9tZXIgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4gICAgaWYgKCFzZWxlY3RlZEdyb3VwVGlja2V0cyB8fCBzZWxlY3RlZEdyb3VwVGlja2V0cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgbmV3RXJyb3JzLmdyb3VwX3RpY2tldCA9IFwiUGxlYXNlIHNlbGVjdCBhdCBsZWFzdCBvbmUgZ3JvdXAvdGlja2V0XCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWZvcm1EYXRhLnBheV9kYXRlKSBuZXdFcnJvcnMucGF5X2RhdGUgPSBcIlBheW1lbnQgZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG5cclxuICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlRmxvYXQoZm9ybURhdGEuYW1vdW50KTtcclxuICAgIGlmIChpc05hTihhbW91bnQpIHx8IGFtb3VudCA8PSAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIHBvc2l0aXZlIGFtb3VudFwiO1xyXG4gICAgfSBlbHNlIGlmICghdXNlckFjY291bnRJbmZvKSB7XHJcbiAgICAgIC8vIEJhbGFuY2UgZGF0YSBub3QgbG9hZGVkIOKAkyBBUEkgbWlnaHQgaGF2ZSBmYWlsZWRcclxuICAgICAgbmV3RXJyb3JzLmFtb3VudCA9IFwiVW5hYmxlIHRvIHZlcmlmeSBiYWxhbmNlLiBQbGVhc2UgcmVmcmVzaCBvciBzZWxlY3QgY3VzdG9tZXIgYWdhaW4uXCI7XHJcbiAgICB9IGVsc2UgaWYgKGFtb3VudCA+IHVzZXJBY2NvdW50SW5mby5iYWxhbmNlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBgQW1vdW50IGNhbm5vdCBleGNlZWQgYXZhaWxhYmxlIGJhbGFuY2Ugb2Yg4oK5JHt1c2VyQWNjb3VudEluZm8uYmFsYW5jZS50b0xvY2FsZVN0cmluZygpfWA7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gLi4uIHJlc3Qgb2YgcGF5bWVudCBtb2RlIHZhbGlkYXRpb25zXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBpZiAobmFtZSA9PT0gXCJhbW91bnRcIikge1xyXG4gICAgICBsZXQgY2xlYW5lZCA9IHZhbHVlLnJlcGxhY2UoL1teMC05Ll0vZywgXCJcIik7XHJcbiAgICAgIGlmICgoY2xlYW5lZC5tYXRjaCgvXFwuL2cpIHx8IFtdKS5sZW5ndGggPiAxKSByZXR1cm47XHJcbiAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgW25hbWVdOiBjbGVhbmVkIH0pKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTsgICAvLyBjbGVhcnMgYWxsIGVycm9yc1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdmFsdWUgfSkpO1xyXG4gICAgc2V0RXJyb3JzKHt9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDdXN0b21lciA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkVXNlcklkKHVzZXJJZCk7XHJcbiAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHVzZXJfaWQ6IHVzZXJJZCwgcGF5bWVudF9ncm91cF90aWNrZXRzOiBudWxsIH0pKTtcclxuICAgIHNldEVycm9ycyhwcmV2ID0+ICh7IC4uLnByZXYsIGN1c3RvbWVyOiBcIlwiIH0pKTtcclxuICAgIHNldFNlbGVjdGVkR3JvdXBUaWNrZXRzKFtdKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TW9kZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBtb2RlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRQYXltZW50TW9kZShtb2RlKTtcclxuICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgcGF5X3R5cGU6IG1vZGUsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBtb2RlID09PSBcImNhc2hcIiA/IFwiXCIgOiBwcmV2LnRyYW5zYWN0aW9uX2lkLFxyXG4gICAgICAuLi4obW9kZSAhPT0gXCJjaGVxdWVcIiAmJiB7IGNoZXF1ZV9udW1iZXI6IFwiXCIsIGNoZXF1ZV9kYXRlOiBcIlwiLCBjaGVxdWVfYmFua19uYW1lOiBcIlwiLCBjaGVxdWVfYmFua19icmFuY2g6IFwiXCIgfSksXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGVGb3JtKCkpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBhZG1pbiA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpIHx8IFwie31cIik7XHJcblxyXG4gICAgLy8gQ29udmVydCB0byBhcnJheSBmb3JtYXRcclxuICAgIC8vIGNvbnN0IGdyb3VwVGlja2V0c0FycmF5ID0gW3tcclxuICAgIC8vICAgZ3JvdXBfaWQ6IGZvcm1EYXRhLnBheW1lbnRfZ3JvdXBfdGlja2V0cy5ncm91cF9pZCxcclxuICAgIC8vICAgdGlja2V0OiBmb3JtRGF0YS5wYXltZW50X2dyb3VwX3RpY2tldHMudGlja2V0XHJcbiAgICAvLyB9XTtcclxuXHJcbiAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICB1c2VyX2lkOiBmb3JtRGF0YS51c2VyX2lkLFxyXG4gICAgICBwYXltZW50X2dyb3VwX3RpY2tldHM6IHNlbGVjdGVkR3JvdXBUaWNrZXRzLFxyXG4gICAgICBwYXlfZGF0ZTogZm9ybURhdGEucGF5X2RhdGUsXHJcbiAgICAgIGFtb3VudDogcGFyc2VGbG9hdChmb3JtRGF0YS5hbW91bnQpLFxyXG4gICAgICBwYXlfdHlwZTogZm9ybURhdGEucGF5X3R5cGUsXHJcbiAgICAgIGFkbWluX3R5cGU6IGFkbWluLl9pZCxcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IGZvcm1EYXRhLnRyYW5zYWN0aW9uX2lkIHx8IG51bGwsXHJcbiAgICAgIHJlbWFya3M6IGZvcm1EYXRhLnJlbWFya3MgfHwgbnVsbCxcclxuICAgICAgYWNjb3VudF90eXBlOiBmb3JtRGF0YS5hY2NvdW50X3R5cGUgfHwgXCJzYXZpbmdzXCIsXHJcbiAgICAgIC4uLihmb3JtRGF0YS5wYXlfdHlwZSA9PT0gXCJjaGVxdWVcIiAmJiB7XHJcbiAgICAgICAgY2hlcXVlX251bWJlcjogZm9ybURhdGEuY2hlcXVlX251bWJlcixcclxuICAgICAgICBjaGVxdWVfZGF0ZTogZm9ybURhdGEuY2hlcXVlX2RhdGUsXHJcbiAgICAgICAgY2hlcXVlX2JhbmtfbmFtZTogZm9ybURhdGEuY2hlcXVlX2JhbmtfbmFtZSxcclxuICAgICAgICBjaGVxdWVfYmFua19icmFuY2g6IGZvcm1EYXRhLmNoZXF1ZV9iYW5rX2JyYW5jaCxcclxuICAgICAgfSksXHJcbiAgICB9O1xyXG4gICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnBvc3QoXCJ2MS9hZG1pbi91c2VyLWFjY291bnRzL3BheWluXCIsIHBheWxvYWQpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7IHZpc2liaWxpdHk6IHRydWUsIG1lc3NhZ2U6IFwiQ2FuY2VsbGF0aW9uIHBheW1lbnQgc3VjY2Vzc2Z1bFwiLCB0eXBlOiBcInN1Y2Nlc3NcIiwgbm9SZWxvYWQ6IHRydWUgfSk7XHJcbiAgICAgIC8vIFJlc2V0IGZvcm1cclxuICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBudWxsLFxyXG4gICAgICAgIHBheV9kYXRlOiB0b2RheSxcclxuICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgICAgIGFkbWluX3R5cGU6IFwiXCIsXHJcbiAgICAgICAgcmVtYXJrczogXCJcIixcclxuICAgICAgICBhY2NvdW50X3R5cGU6IFwiXCIsXHJcbiAgICAgICAgY2hlcXVlX251bWJlcjogXCJcIixcclxuICAgICAgICBjaGVxdWVfZGF0ZTogXCJcIixcclxuICAgICAgICBjaGVxdWVfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogXCJcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVXNlcklkKFwiXCIpO1xyXG5cclxuICAgICAgc2V0RmlsdGVyZWRFbnJvbGxtZW50cyhbXSk7XHJcbiAgICAgIHNldFVzZXJBY2NvdW50SW5mbyhudWxsKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHsgdmlzaWJpbGl0eTogdHJ1ZSwgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB8fCBcIlN1Ym1pc3Npb24gZmFpbGVkXCIsIHR5cGU6IFwiZXJyb3JcIiwgbm9SZWxvYWQ6IHRydWUgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIoZmFsc2UpO1xyXG4gICAgICBzZXRTZWxlY3RlZEdyb3VwVGlja2V0cyhbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVmlld01vZGFsT3BlbiA9IGFzeW5jIChwYXltZW50SWQpID0+IHtcclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRTaG93TW9kYWxWaWV3KHRydWUpO1xyXG4gICAgc2V0Q3VycmVudEdyb3VwSWQocGF5bWVudElkKTtcclxuICAgIHNldFZpZXdMb2FkZXIodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9nZXQtcGF5bWVudC1ieS1pZC8ke3BheW1lbnRJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudFZpZXdHcm91cChyZXMuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICBzZXRWaWV3TG9hZGVyKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAge29wZW5CYWNrZHJvcExvYWRlciA/IChcclxuICAgICAgICA8QmFja2Ryb3BCbHVyTG9hZGVyIHRpdGxlPVwiUGF5bWVudCBEYXRhIFByb2Nlc3NpbmcuLi4uXCIgLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgbWluLWgtc2NyZWVuIG10LTIwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cclxuICAgICAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICA8TmF2YmFyIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfSB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgIDxDdXN0b21BbGVydFxyXG4gICAgICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICBub1JlbG9hZD17YWxlcnRDb25maWcubm9SZWxvYWR9XHJcbiAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTZcIj5cclxuICAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTV4bCBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXhsIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS05MDAgdG8tYmx1ZS04MDAgcHgtOCBweS01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctd2lkZVwiPkNoaXQgVHJhbnNmZXI8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTIwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUHJvY2VzcyB0cmFuc2ZlciBhbW91bnRzIHRvIGRpZmZlcmVudCBjaGl0IGFjY291bnRzLCBwaWdteSwgb3IgbG9hbnMuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInAtOCBzcGFjZS15LThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciAmIEdyb3VwL1RpY2tldCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+U2VsZWN0IEN1c3RvbWVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBzZWFyY2ggY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudXNlcl9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXt1c2Vycy5tYXAodXNlciA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdXNlci5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgJHt1c2VyLmZ1bGxfbmFtZX0gfCAke3VzZXIucGhvbmVfbnVtYmVyfWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmN1c3RvbWVyICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmN1c3RvbWVyfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwICYgVGlja2V0IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb25lIG9yIG1vcmUgZ3JvdXAgJiB0aWNrZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Vucm9sbG1lbnRMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17ZW5yb2xsbWVudExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF90aWNrZXRzPy5tYXAoZ3QgPT4gYCR7Z3QuZ3JvdXBfaWR9fCR7Z3QudGlja2V0fWApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2VsZWN0ZWQgPSB2YWx1ZXMubWFwKHZhbCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgW2dyb3VwX2lkLCB0aWNrZXRdID0gdmFsLnNwbGl0KFwifFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyBncm91cF9pZCwgdGlja2V0IH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGdyb3VwX3RpY2tldHM6IHNlbGVjdGVkIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHByZXYgPT4gKHsgLi4ucHJldiwgZ3JvdXBfdGlja2V0OiB1bmRlZmluZWQgfSkpOyAgLy8gY2xlYXIgZXJyb3JcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtmaWx0ZXJlZEVucm9sbG1lbnRzLm1hcChlbnRyeSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogYCR7ZW50cnkuZW5yb2xsbWVudC5ncm91cC5faWR9fCR7ZW50cnkuZW5yb2xsbWVudC50aWNrZXRzfWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgJHtlbnRyeS5lbnJvbGxtZW50Lmdyb3VwLmdyb3VwX25hbWV9IHwgJHtlbnRyeS5lbnJvbGxtZW50LnRpY2tldHN9YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfdGlja2V0ICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmdyb3VwX3RpY2tldH08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBHcm91cCAmIFRpY2tldCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kZT1cIm11bHRpcGxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9uZSBvciBtb3JlIGdyb3VwcywgcGlnbXksIG9yIGxvYW5zXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlbnJvbGxtZW50TG9hZGluZyB8fCAodXNlckFjY291bnRJbmZvPy5iYWxhbmNlIHx8IDApIDw9IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtlbnJvbGxtZW50TG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXBUaWNrZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cFRpY2tldHModmFsdWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHByZXYgPT4gKHsgLi4ucHJldiwgZ3JvdXBfdGlja2V0OiB1bmRlZmluZWQgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQ2hpdCBvcHRpb25zIChlbnJvbGxtZW50cykgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRFbnJvbGxtZW50cy5tYXAoZW50cnkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBncm91cElkID0gZW50cnkuZW5yb2xsbWVudC5ncm91cC5faWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpY2tldCA9IGVudHJ5LmVucm9sbG1lbnQudGlja2V0cztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxhYmVsID0gYCR7ZW50cnkuZW5yb2xsbWVudC5ncm91cC5ncm91cF9uYW1lfSB8ICR7dGlja2V0fWA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiA8U2VsZWN0Lk9wdGlvbiBrZXk9e3ZhbHVlfSB2YWx1ZT17dmFsdWV9PntsYWJlbH08L1NlbGVjdC5PcHRpb24+O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUGlnbXkgb3B0aW9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZUN1c3RvbWVycz8ubWFwKHBpZ21lID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBgcGlnbWUtJHtwaWdtZS5faWR9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbGFiZWwgPSBgJHtwaWdtZS5waWdtZV9pZH0gfCDigrkgJHtwaWdtZS5wYXlhYmxlX2Ftb3VudH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gPFNlbGVjdC5PcHRpb24ga2V5PXt2YWx1ZX0gdmFsdWU9e3ZhbHVlfT57bGFiZWx9PC9TZWxlY3QuT3B0aW9uPjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIExvYW4gb3B0aW9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtib3Jyb3dlcnM/Lm1hcChib3Jyb3dlciA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYGxvYW4tJHtib3Jyb3dlci5faWR9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbGFiZWwgPSBgbG9hbi0ke2JvcnJvd2VyLmxvYW5faWR9IHwg4oK5ICR7Ym9ycm93ZXIubG9hbl9hbW91bnR9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxTZWxlY3QuT3B0aW9uIGtleT17dmFsdWV9IHZhbHVlPXt2YWx1ZX0+e2xhYmVsfTwvU2VsZWN0Lk9wdGlvbj47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX3RpY2tldCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5ncm91cF90aWNrZXR9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogRGlzcGxheSBVc2VyIEJhbGFuY2UgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2VyQWNjb3VudEluZm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi01MCB0by1lbWVyYWxkLTUwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHJvdW5kZWQteGwgcC00IGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+Q3VzdG9tZXIgQmFsYW5jZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57dXNlckFjY291bnRJbmZvLmZ1bGxfbmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5BdmFpbGFibGUgQmFsYW5jZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtZXh0cmFib2xkIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7TnVtYmVyKHVzZXJBY2NvdW50SW5mby5iYWxhbmNlKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIExhc3QgMyBUcmFuc2FjdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiVmlldyBsYXN0IDMgcGF5bWVudHMgZm9yIHRoaXMgY3VzdG9tZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtmZXRjaExhc3RUaHJlZVRyYW5zYWN0aW9uc30gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNSBweS0yIHJvdW5kZWQtbGcgaG92ZXI6YmctZ3JlZW4tNzAwIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUmVjZWlwdCBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz4gPHNwYW4+TGFzdCAzIFRyYW5zYWN0aW9uczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBQYXltZW50IERldGFpbHMgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLXhsIHAtNiBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIG1iLTUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLWJsdWUtNjAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj4gUGF5bWVudCBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlBheW1lbnQgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImRhdGVcIiBuYW1lPVwicGF5X2RhdGVcIiB2YWx1ZT17Zm9ybURhdGEucGF5X2RhdGV9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshbW9kaWZ5UGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXttb2RpZnlNaW5NYXhQYXltZW50RGF0ZSA/IHllc3RlcmRheSA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4PXttb2RpZnlNaW5NYXhQYXltZW50RGF0ZSA/IHRvZGF5IDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBheV9kYXRlICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLnBheV9kYXRlfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlRyYW5zZmVyIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJhbW91bnRcIiB2YWx1ZT17Zm9ybURhdGEuYW1vdW50fSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBwbGFjZWhvbGRlcj1cIkVudGVyIGFtb3VudFwiIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGJnLWJsdWUtNTAgZm9udC1tZWRpdW0gdGV4dC1ibHVlLTgwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5hbW91bnR9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj57bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5hbW91bnQpfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+UmVtYXJrcyAob3B0aW9uYWwpPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYSBuYW1lPVwicmVtYXJrc1wiIHZhbHVlPXtmb3JtRGF0YS5yZW1hcmtzfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSByb3dzPXsyfSBwbGFjZWhvbGRlcj1cIkFkZGl0aW9uYWwgcmVtYXJrcyAoZS5nLiwgcmVhc29uIGZvciBjYW5jZWxsYXRpb24pXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIj48L3RleHRhcmVhPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5QYXltZW50IE1vZGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17Zm9ybURhdGEucGF5X3R5cGV9IG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50TW9kZUNoYW5nZX0gY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRyYW5zZmVyXCI+VHJhbnNmZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogVHJhbnNhY3Rpb24gSUQgZm9yIG9ubGluZS9VUEkgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsoZm9ybURhdGEucGF5X3R5cGUgPT09IFwib25saW5lXCIgfHwgZm9ybURhdGEucGF5X3R5cGUgPT09IFwib25saW5lL3VwaVwiKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlRyYW5zYWN0aW9uIElEIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJ0cmFuc2FjdGlvbl9pZFwiIHZhbHVlPXtmb3JtRGF0YS50cmFuc2FjdGlvbl9pZH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBUcmFuc2FjdGlvbiBJRFwiIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudHJhbnNhY3Rpb25faWQgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMudHJhbnNhY3Rpb25faWR9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDaGVxdWUgZGV0YWlscyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBheV90eXBlID09PSBcImNoZXF1ZVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTNcIj5DaGVxdWUgRGV0YWlsczwvaDU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPkNoZXF1ZSBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJjaGVxdWVfbnVtYmVyXCIgdmFsdWU9e2Zvcm1EYXRhLmNoZXF1ZV9udW1iZXJ9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNoZXF1ZV9udW1iZXIgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuY2hlcXVlX251bWJlcn08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPkNoZXF1ZSBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImRhdGVcIiBuYW1lPVwiY2hlcXVlX2RhdGVcIiB2YWx1ZT17Zm9ybURhdGEuY2hlcXVlX2RhdGV9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNoZXF1ZV9kYXRlICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmNoZXF1ZV9kYXRlfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+QmFuayBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPVwiY2hlcXVlX2JhbmtfbmFtZVwiIHZhbHVlPXtmb3JtRGF0YS5jaGVxdWVfYmFua19uYW1lfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+QmFuayBCcmFuY2g8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJjaGVxdWVfYmFua19icmFuY2hcIiB2YWx1ZT17Zm9ybURhdGEuY2hlcXVlX2JhbmtfYnJhbmNofSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogUGF5b3V0IEFtb3VudCBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTYgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBzaGFkb3ctc21cIj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTYgYmctcmVkLTUwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+IFBheW91dCBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJncmlkIGxnOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy0yIGdhcC01XCI+ICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5BY2NvdW50IFR5cGUgKG9wdGlvbmFsKTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IG5hbWU9XCJhY2NvdW50X3R5cGVcIiB2YWx1ZT17Zm9ybURhdGEuYWNjb3VudF90eXBlIHx8IFwic2F2aW5nc1wifSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJzYXZpbmdzXCI+U2F2aW5nczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY3VycmVudFwiPkN1cnJlbnQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhc2hcIj5DYXNoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFdoYXRzQXBwIE5vdGlmaWNhdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwU3F1YXJlIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwIHRleHQtMnhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5XaGF0c0FwcCBOb3RpZmljYXRpb248L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17d2hhdHNhcHBFbmFibGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0V2hhdHNhcHBFbmFibGUoZS50YXJnZXQuY2hlY2tlZCl9IGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmVlbi01MDAgcm91bmRlZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+U2VuZCB2aWEgV2hhdHNBcHA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtOTAwIGhvdmVyOmJnLWJsdWUtODAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCBweC04IHB5LTIuNSByb3VuZGVkLWxnIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyh1c2VyQWNjb3VudEluZm8/LmJhbGFuY2UgfHwgMCkgPD0gMH0gdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHVzZXJBY2NvdW50SW5mbz8uYmFsYW5jZSB8fCAwKSA8PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJDdXN0b21lciBoYXMgbm8gYXZhaWxhYmxlIGJhbGFuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiU2F2ZSBQYXltZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9PlNhdmUgUGF5bWVudDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRHJhd2VyIGFuZCBNb2RhbCAqL31cclxuICAgICAgICAgICAgICA8RHJhd2VyIHRpdGxlPVwiTGFzdCBUaHJlZSBUcmFuc2FjdGlvbnNcIiBwbGFjZW1lbnQ9XCJyaWdodFwiIG9wZW49e29wZW5BbnRERHJhd2VyfSBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuQW50RERyYXdlcihmYWxzZSl9IHdpZHRoPXs0MDB9IGxvYWRpbmc9e3Nob3dMb2FkZXJ9PlxyXG4gICAgICAgICAgICAgICAge2xhc3RUaHJlZVBheW1lbnRzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwIHB5LThcIj5ObyBUcmFuc2FjdGlvbiBGb3VuZDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bGFzdFRocmVlUGF5bWVudHMubWFwKChwLCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBwLTQgc2hhZG93LXNtIGJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItMlwiPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdy0yOFwiPlBheW1lbnQgRGF0ZTo8L3NwYW4+PHNwYW4+e3AucGF5X2RhdGV9PC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cC5ncm91cF9pZCAmJiA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItMlwiPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdy0yOFwiPkdyb3VwOjwvc3Bhbj48c3Bhbj57cC5ncm91cF9pZD8uZ3JvdXBfbmFtZX08L3NwYW4+PC9kaXY+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cC50aWNrZXQgJiYgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTJcIj48c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHctMjhcIj5UaWNrZXQ6PC9zcGFuPjxzcGFuPntwLnRpY2tldH08L3NwYW4+PC9kaXY+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItMlwiPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdy0yOFwiPkFtb3VudDo8L3NwYW4+PHNwYW4+4oK5e3AuYW1vdW50fTwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1iLTJcIj48c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHctMjhcIj5QYXltZW50IFR5cGU6PC9zcGFuPjxzcGFuPntwLnBheV90eXBlfTwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB3LTI4XCI+TmFtZTo8L3NwYW4+PHNwYW4+e3AudXNlcl9pZD8uZnVsbF9uYW1lfTwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9EcmF3ZXI+XHJcblxyXG4gICAgICAgICAgICAgIDxBbnRNb2RhbCBvcGVuPXtzaG93TW9kYWxWaWV3fSBvbkNhbmNlbD17KCkgPT4gc2V0U2hvd01vZGFsVmlldyhmYWxzZSl9IGZvb3Rlcj17bnVsbH0gd2lkdGg9ezgwMH0+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgbWItNFwiPlBheW1lbnQgRGV0YWlsczwvaDM+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBwLTQgYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPkdyb3VwOjwvc3Bhbj4ge2N1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPkdyb3VwIFZhbHVlOjwvc3Bhbj4ge2N1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5Vc2VyOjwvc3Bhbj4ge2N1cnJlbnRWaWV3R3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZX0gfCBUaWNrZXQ6IHtjdXJyZW50Vmlld0dyb3VwPy50aWNrZXR9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj48c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+QW1vdW50Ojwvc3Bhbj4ge2N1cnJlbnRWaWV3R3JvdXA/LmFtb3VudH08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5QYXkgVHlwZTo8L3NwYW4+IHtjdXJyZW50Vmlld0dyb3VwPy5wYXlfdHlwZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5QYXkgRGF0ZTo8L3NwYW4+IHtjdXJyZW50Vmlld0dyb3VwPy5wYXlfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5jaGVxdWVfbnVtYmVyICYmIDxkaXY+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPkNoZXF1ZSBObzo8L3NwYW4+IHtjdXJyZW50Vmlld0dyb3VwLmNoZXF1ZV9udW1iZXJ9PC9kaXY+fVxyXG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy50cmFuc2FjdGlvbl9pZCAmJiA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5UcmFuc2FjdGlvbiBJRDo8L3NwYW4+IHtjdXJyZW50Vmlld0dyb3VwLnRyYW5zYWN0aW9uX2lkfTwvZGl2Pn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L0FudE1vZGFsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENoaXRDYW5jZWxQYXltZW50SW47Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0NoaXRDYW5jZWxQYXltZW50SW4uanN4In0=