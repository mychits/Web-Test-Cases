import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RedemptionPointsReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const RedemptionPointsReport = () => {
  _s();
  const [reportType, setReportType] = useState("EMPLOYEE");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [summary, setSummary] = useState({
    totalRecords: 0,
    totalPoints: 0,
    totalAmount: 0
  });
  const [employees, setEmployees] = useState([]);
  const [employeeId, setEmployeeId] = useState("");
  const [customers, setCustomers] = useState([]);
  const [customerId, setCustomerId] = useState("");
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const res = await api.get("/agent/get-employee");
        setEmployees(res.data?.employee || []);
      } catch (err) {
        console.error("Employee fetch error", err);
      }
    };
    fetchEmployees();
  }, []);
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const res = await api.get("/user/get-user");
        setCustomers(res.data || []);
      } catch (err) {
        console.error("Customer fetch error", err);
      }
    };
    fetchCustomers();
  }, []);
  const handleSearch = async () => {
    if (!fromDate || !toDate) {
      alert("Please select From Date and To Date");
      return;
    }
    if (reportType === "EMPLOYEE" && !employeeId) {
      alert("Please select Employee");
      return;
    }
    if (reportType === "CUSTOMER" && !customerId) {
      alert("Please select Customer");
      return;
    }
    try {
      setLoading(true);
      setTableData([]);
      setSummary({ totalRecords: 0, totalPoints: 0, totalAmount: 0 });
      let res;
      if (reportType === "EMPLOYEE") {
        res = await api.post("/reward-points/redemption", {
          employee_id: employeeId,
          from_date: fromDate,
          to_date: toDate
        });
        const formatted = res.data?.data?.map((row, index) => ({
          id: row._id,
          slNo: index + 1,
          redemptionType: row.redemption_type,
          usedPoints: row.points_used,
          amount: row.amount,
          description: row.description || "-"
        })) || [];
        setTableData(formatted);
        setSummary({
          totalRecords: formatted.length,
          totalPoints: formatted.reduce(
            (sum, r) => sum + (r.usedPoints || 0),
            0
          ),
          totalAmount: formatted.reduce((sum, r) => sum + (r.amount || 0), 0)
        });
      }
      if (reportType === "CUSTOMER") {
        res = await api.post("/customer-rewards/redemption", {
          customer_id: customerId,
          from_date: fromDate,
          to_date: toDate
        });
        const formatted = res.data?.data?.map((row, index) => ({
          id: row._id,
          slNo: index + 1,
          redemptionType: row.redemption_type || "-",
          redeemedPoints: row.redeemed_points || "-",
          redeemedAmount: row.redeemed_amount,
          remarks: row.remarks
        })) || [];
        setTableData(formatted);
        setSummary({
          totalRecords: formatted.length,
          totalPoints: formatted.reduce(
            (sum, r) => sum + (r.redeemedPoints || 0),
            0
          ),
          totalAmount: formatted.reduce(
            (sum, r) => sum + (r.redeemedAmount || 0),
            0
          )
        });
      }
    } catch (err) {
      console.error("Search error:", err.response?.data || err);
    } finally {
      setLoading(false);
    }
  };
  const employeeColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "redemptionType", header: "Redemption Type" },
    { key: "usedPoints", header: "Redeemed Points" },
    { key: "amount", header: "Redeemed Amount" },
    { key: "description", header: "Description" }
  ];
  const customerColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "redemptionType", header: "Redemption Type" },
    { key: "redeemedPoints", header: "Redeemed Points" },
    { key: "redeemedAmount", header: "Redeemed Amount" },
    { key: "remarks", header: "Remarks" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
      lineNumber: 514,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-6", children: "Redemption Points Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
        lineNumber: 518,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-6 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            className: "border p-2 rounded",
            value: reportType,
            onChange: (e) => {
              setReportType(e.target.value);
              setTableData([]);
              setSummary({ totalRecords: 0, totalPoints: 0, totalAmount: 0 });
            },
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "EMPLOYEE", children: "Employee " }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
                lineNumber: 532,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "CUSTOMER", children: "Customer " }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
                lineNumber: 533,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 523,
            columnNumber: 13
          },
          this
        ),
        reportType === "EMPLOYEE" && // <select
        //   className="border p-2 rounded"
        //   value={employeeId}
        //   onChange={(e) => setEmployeeId(e.target.value)}
        // >
        //   <option value="">Select Employee</option>
        //   {employees.map((emp) => (
        //     <option key={emp._id} value={emp._id}>
        //       {emp.name}
        //     </option>
        //   ))}
        // </select>
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-64",
            popupMatchSelectWidth: false,
            showSearch: true,
            placeholder: "Select Employee",
            value: employeeId || void 0,
            onChange: (value) => setEmployeeId(value),
            optionFilterProp: "children",
            filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
            children: employees.map(
              (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                emp.name,
                " - ",
                emp.phone_number
              ] }, emp._id, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
                lineNumber: 565,
                columnNumber: 15
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 549,
            columnNumber: 13
          },
          this
        ),
        reportType === "CUSTOMER" && // <select
        //   className="border p-2 rounded"
        //   value={customerId}
        //   onChange={(e) => setCustomerId(e.target.value)}
        // >
        //   <option value="">Select Customer</option>
        //   {customers.map((cust) => (
        //     <option key={cust._id} value={cust._id}>
        //       {cust.full_name}
        //     </option>
        //   ))}
        // </select>
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-64 ",
            popupMatchSelectWidth: false,
            showSearch: true,
            placeholder: "Select Customer",
            value: customerId || void 0,
            onChange: (value) => setCustomerId(value),
            optionFilterProp: "children",
            filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
            children: customers.map(
              (cust) => /* @__PURE__ */ jsxDEV(Select.Option, { value: cust._id, children: [
                cust.full_name,
                " - ",
                cust.phone_number
              ] }, cust._id, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
                lineNumber: 601,
                columnNumber: 15
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 585,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            className: "border p-2 rounded ml-16",
            value: fromDate,
            onChange: (e) => setFromDate(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 608,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            className: "border p-2 rounded ",
            value: toDate,
            onChange: (e) => setToDate(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 615,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleSearch,
            className: "bg-violet-600 text-white px-4 py-2 rounded hover:bg-violet-700",
            children: loading ? "Loading..." : "Search"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 622,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
        lineNumber: 522,
        columnNumber: 11
      }, this),
      tableData.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow rounded p-4 border-l-4 border-violet-600", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Total Records" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 633,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold", children: summary.totalRecords }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 634,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
          lineNumber: 632,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow rounded p-4 border-l-4 border-green-600", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Total Redeemed Points" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 638,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold", children: summary.totalPoints }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 639,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
          lineNumber: 637,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow rounded p-4 border-l-4 border-purple-600", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Total Redeemed Amount" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 643,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold", children: [
            "₹ ",
            summary.totalAmount
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
            lineNumber: 644,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
          lineNumber: 642,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
        lineNumber: 631,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: tableData,
          columns: reportType === "EMPLOYEE" ? employeeColumns : customerColumns,
          exportedFileName: "Redemption Points Report.csv",
          exportedPdfName: "Redemption Points Report"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
          lineNumber: 649,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
      lineNumber: 517,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
      lineNumber: 516,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx",
    lineNumber: 513,
    columnNumber: 5
  }, this);
};
_s(RedemptionPointsReport, "Q5GODt7ZZTJ/G52I37Ft1fG1oQU=");
_c = RedemptionPointsReport;
export default RedemptionPointsReport;
var _c;
$RefreshReg$(_c, "RedemptionPointsReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RedemptionPointsReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaWdCTTsyQkFqZ0JOO0FBQW1CQSxvQkFBaUIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsWUFBWTtBQUNuQixTQUFRQyxjQUFhO0FBc1dyQixNQUFNQyx5QkFBeUJBLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSUMsU0FBUyxVQUFVO0FBQ3ZELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJRixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDRyxRQUFRQyxTQUFTLElBQUlKLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNLLFNBQVNDLFVBQVUsSUFBSU4sU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ08sV0FBV0MsWUFBWSxJQUFJUixTQUFTLEVBQUU7QUFFN0MsUUFBTSxDQUFDUyxTQUFTQyxVQUFVLElBQUlWLFNBQVM7QUFBQSxJQUNyQ1csY0FBYztBQUFBLElBQ2RDLGFBQWE7QUFBQSxJQUNiQyxhQUFhO0FBQUEsRUFDZixDQUFDO0FBRUQsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlmLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNnQixZQUFZQyxhQUFhLElBQUlqQixTQUFTLEVBQUU7QUFFL0MsUUFBTSxDQUFDa0IsV0FBV0MsWUFBWSxJQUFJbkIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ29CLFlBQVlDLGFBQWEsSUFBSXJCLFNBQVMsRUFBRTtBQUUvQ1QsWUFBVSxNQUFNO0FBQ2QsVUFBTStCLGlCQUFpQixZQUFZO0FBQ2pDLFVBQUk7QUFDRixjQUFNQyxNQUFNLE1BQU0vQixJQUFJZ0MsSUFBSSxxQkFBcUI7QUFDL0NULHFCQUFhUSxJQUFJRSxNQUFNQyxZQUFZLEVBQUU7QUFBQSxNQUN2QyxTQUFTQyxLQUFLO0FBQ1pDLGdCQUFRQyxNQUFNLHdCQUF3QkYsR0FBRztBQUFBLE1BQzNDO0FBQUEsSUFDRjtBQUNBTCxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVML0IsWUFBVSxNQUFNO0FBQ2QsVUFBTXVDLGlCQUFpQixZQUFZO0FBQ2pDLFVBQUk7QUFDRixjQUFNUCxNQUFNLE1BQU0vQixJQUFJZ0MsSUFBSSxnQkFBZ0I7QUFDMUNMLHFCQUFhSSxJQUFJRSxRQUFRLEVBQUU7QUFBQSxNQUM3QixTQUFTRSxLQUFLO0FBQ1pDLGdCQUFRQyxNQUFNLHdCQUF3QkYsR0FBRztBQUFBLE1BQzNDO0FBQUEsSUFDRjtBQUNBRyxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMLFFBQU1DLGVBQWUsWUFBWTtBQUMvQixRQUFJLENBQUM5QixZQUFZLENBQUNFLFFBQVE7QUFDeEI2QixZQUFNLHFDQUFxQztBQUMzQztBQUFBLElBQ0Y7QUFFQSxRQUFJbEMsZUFBZSxjQUFjLENBQUNrQixZQUFZO0FBQzVDZ0IsWUFBTSx3QkFBd0I7QUFDOUI7QUFBQSxJQUNGO0FBRUEsUUFBSWxDLGVBQWUsY0FBYyxDQUFDc0IsWUFBWTtBQUM1Q1ksWUFBTSx3QkFBd0I7QUFDOUI7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGMUIsaUJBQVcsSUFBSTtBQUNmRSxtQkFBYSxFQUFFO0FBQ2ZFLGlCQUFXLEVBQUVDLGNBQWMsR0FBR0MsYUFBYSxHQUFHQyxhQUFhLEVBQUUsQ0FBQztBQUU5RCxVQUFJVTtBQUVKLFVBQUl6QixlQUFlLFlBQVk7QUFDN0J5QixjQUFNLE1BQU0vQixJQUFJeUMsS0FBSyw2QkFBNkI7QUFBQSxVQUNoREMsYUFBYWxCO0FBQUFBLFVBQ2JtQixXQUFXbEM7QUFBQUEsVUFDWG1DLFNBQVNqQztBQUFBQSxRQUNYLENBQUM7QUFFRCxjQUFNa0MsWUFDSmQsSUFBSUUsTUFBTUEsTUFBTWEsSUFBSSxDQUFDQyxLQUFLQyxXQUFXO0FBQUEsVUFDbkNDLElBQUlGLElBQUlHO0FBQUFBLFVBQ1JDLE1BQU1ILFFBQVE7QUFBQSxVQUNkSSxnQkFBZ0JMLElBQUlNO0FBQUFBLFVBQ3BCQyxZQUFZUCxJQUFJUTtBQUFBQSxVQUNoQkMsUUFBUVQsSUFBSVM7QUFBQUEsVUFDWkMsYUFBYVYsSUFBSVUsZUFBZTtBQUFBLFFBQ2xDLEVBQUUsS0FBSztBQUVUekMscUJBQWE2QixTQUFTO0FBRXRCM0IsbUJBQVc7QUFBQSxVQUNUQyxjQUFjMEIsVUFBVWE7QUFBQUEsVUFDeEJ0QyxhQUFheUIsVUFBVWM7QUFBQUEsWUFDckIsQ0FBQ0MsS0FBS0MsTUFBTUQsT0FBT0MsRUFBRVAsY0FBYztBQUFBLFlBQ25DO0FBQUEsVUFDRjtBQUFBLFVBQ0FqQyxhQUFhd0IsVUFBVWMsT0FBTyxDQUFDQyxLQUFLQyxNQUFNRCxPQUFPQyxFQUFFTCxVQUFVLElBQUksQ0FBQztBQUFBLFFBQ3BFLENBQUM7QUFBQSxNQUNIO0FBRUEsVUFBSWxELGVBQWUsWUFBWTtBQUM3QnlCLGNBQU0sTUFBTS9CLElBQUl5QyxLQUFLLGdDQUFnQztBQUFBLFVBQ25EcUIsYUFBYWxDO0FBQUFBLFVBQ2JlLFdBQVdsQztBQUFBQSxVQUNYbUMsU0FBU2pDO0FBQUFBLFFBQ1gsQ0FBQztBQUVELGNBQU1rQyxZQUNKZCxJQUFJRSxNQUFNQSxNQUFNYSxJQUFJLENBQUNDLEtBQUtDLFdBQVc7QUFBQSxVQUNuQ0MsSUFBSUYsSUFBSUc7QUFBQUEsVUFDUkMsTUFBTUgsUUFBUTtBQUFBLFVBQ2RJLGdCQUFnQkwsSUFBSU0sbUJBQW1CO0FBQUEsVUFDdkNVLGdCQUFnQmhCLElBQUlpQixtQkFBbUI7QUFBQSxVQUN2Q0MsZ0JBQWdCbEIsSUFBSW1CO0FBQUFBLFVBQ3BCQyxTQUFTcEIsSUFBSW9CO0FBQUFBLFFBQ2YsRUFBRSxLQUFLO0FBRVRuRCxxQkFBYTZCLFNBQVM7QUFFdEIzQixtQkFBVztBQUFBLFVBQ1RDLGNBQWMwQixVQUFVYTtBQUFBQSxVQUN4QnRDLGFBQWF5QixVQUFVYztBQUFBQSxZQUNyQixDQUFDQyxLQUFLQyxNQUFNRCxPQUFPQyxFQUFFRSxrQkFBa0I7QUFBQSxZQUN2QztBQUFBLFVBQ0Y7QUFBQSxVQUNBMUMsYUFBYXdCLFVBQVVjO0FBQUFBLFlBQ3JCLENBQUNDLEtBQUtDLE1BQU1ELE9BQU9DLEVBQUVJLGtCQUFrQjtBQUFBLFlBQ3ZDO0FBQUEsVUFDRjtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVM5QixLQUFLO0FBQ1pDLGNBQVFDLE1BQU0saUJBQWlCRixJQUFJaUMsVUFBVW5DLFFBQVFFLEdBQUc7QUFBQSxJQUMxRCxVQUFDO0FBQ0NyQixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTXVELGtCQUFrQjtBQUFBLElBQ3RCLEVBQUVDLEtBQUssUUFBUUMsUUFBUSxRQUFRO0FBQUEsSUFDL0IsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEsa0JBQWtCO0FBQUEsSUFDbkQsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGtCQUFrQjtBQUFBLElBQy9DLEVBQUVELEtBQUssVUFBVUMsUUFBUSxrQkFBa0I7QUFBQSxJQUMzQyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsY0FBYztBQUFBLEVBQUM7QUFHL0MsUUFBTUMsa0JBQWtCO0FBQUEsSUFDdEIsRUFBRUYsS0FBSyxRQUFRQyxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLEVBQUM7QUFHdkMsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUVQLHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwrQkFBOEIsd0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE9BQU9qRTtBQUFBQSxZQUNQLFVBQVUsQ0FBQ21FLE1BQU07QUFDZmxFLDRCQUFja0UsRUFBRUMsT0FBT0MsS0FBSztBQUM1QjNELDJCQUFhLEVBQUU7QUFDZkUseUJBQVcsRUFBRUMsY0FBYyxHQUFHQyxhQUFhLEdBQUdDLGFBQWEsRUFBRSxDQUFDO0FBQUEsWUFDaEU7QUFBQSxZQUVBO0FBQUEscUNBQUMsWUFBTyxPQUFNLFlBQVcseUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FDbEMsdUJBQUMsWUFBTyxPQUFNLFlBQVcseUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUE7QUFBQTtBQUFBLFVBVnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdBO0FBQUEsUUFFQ2YsZUFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWFkO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVix1QkFBdUI7QUFBQSxZQUN2QjtBQUFBLFlBQ0EsYUFBWTtBQUFBLFlBQ1osT0FBT2tCLGNBQWNvRDtBQUFBQSxZQUNyQixVQUFVLENBQUNELFVBQVVsRCxjQUFja0QsS0FBSztBQUFBLFlBQ3hDLGtCQUFpQjtBQUFBLFlBQ2pCLGNBQWMsQ0FBQ0UsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxZQUdoQzNELG9CQUFVd0I7QUFBQUEsY0FBSSxDQUFDcUMsUUFDZCx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsSUFBSWpDLEtBQ3JDaUM7QUFBQUEsb0JBQUlDO0FBQUFBLGdCQUFLO0FBQUEsZ0JBQUlELElBQUlFO0FBQUFBLG1CQURBRixJQUFJakMsS0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0Q7QUFBQTtBQUFBLFVBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW9CQTtBQUFBLFFBR0Q1QyxlQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBYWQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLHVCQUF1QjtBQUFBLFlBQ3ZCO0FBQUEsWUFDQSxhQUFZO0FBQUEsWUFDWixPQUFPc0IsY0FBY2dEO0FBQUFBLFlBQ3JCLFVBQVUsQ0FBQ0QsVUFBVTlDLGNBQWM4QyxLQUFLO0FBQUEsWUFDeEMsa0JBQWlCO0FBQUEsWUFDakIsY0FBYyxDQUFDRSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLFlBR2hDdkQsb0JBQVVvQjtBQUFBQSxjQUFJLENBQUN3QyxTQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLcEMsS0FDdkNvQztBQUFBQSxxQkFBS0M7QUFBQUEsZ0JBQVU7QUFBQSxnQkFBSUQsS0FBS0Q7QUFBQUEsbUJBRFBDLEtBQUtwQyxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFDRDtBQUFBO0FBQUEsVUFuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0JBO0FBQUEsUUFHRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ1YsT0FBT3pDO0FBQUFBLFlBQ1AsVUFBVSxDQUFDZ0UsTUFBTS9ELFlBQVkrRCxFQUFFQyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxVQUo3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJK0M7QUFBQSxRQUcvQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ1YsT0FBT2hFO0FBQUFBLFlBQ1AsVUFBVSxDQUFDOEQsTUFBTTdELFVBQVU2RCxFQUFFQyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxVQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJNkM7QUFBQSxRQUc3QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU3BDO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBRVQxQixvQkFBVSxlQUFlO0FBQUE7QUFBQSxVQUo1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBekdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwR0E7QUFBQSxNQUVDRSxVQUFVMkMsU0FBUyxLQUNsQix1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUseUJBQXdCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBQ2xELHVCQUFDLE9BQUUsV0FBVSxzQkFBc0J6QyxrQkFBUUUsZ0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsYUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUseUJBQXdCLHFDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLFVBQzFELHVCQUFDLE9BQUUsV0FBVSxzQkFBc0JGLGtCQUFRRyxlQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLGFBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHlCQUF3QixxQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUMxRCx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCO0FBQUE7QUFBQSxZQUFHSCxRQUFRSTtBQUFBQSxlQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLGFBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFHRjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTU47QUFBQUEsVUFDTixTQUNFVCxlQUFlLGFBQWErRCxrQkFBa0JHO0FBQUFBLFVBRWhELGtCQUFpQjtBQUFBLFVBQ2pCLGlCQUFnQjtBQUFBO0FBQUEsUUFObEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTTRDO0FBQUEsU0ExSTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0SUEsS0E3SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThJQTtBQUFBLE9BakpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrSkE7QUFFSjtBQUFFbkUsR0ExU0lELHdCQUFzQjtBQUFBb0YsS0FBdEJwRjtBQTRTTixlQUFlQTtBQUF1QixJQUFBb0Y7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsImFwaSIsIkRhdGFUYWJsZSIsIk5hdmJhciIsIlNlbGVjdCIsIlJlZGVtcHRpb25Qb2ludHNSZXBvcnQiLCJfcyIsInJlcG9ydFR5cGUiLCJzZXRSZXBvcnRUeXBlIiwidXNlU3RhdGUiLCJmcm9tRGF0ZSIsInNldEZyb21EYXRlIiwidG9EYXRlIiwic2V0VG9EYXRlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJ0YWJsZURhdGEiLCJzZXRUYWJsZURhdGEiLCJzdW1tYXJ5Iiwic2V0U3VtbWFyeSIsInRvdGFsUmVjb3JkcyIsInRvdGFsUG9pbnRzIiwidG90YWxBbW91bnQiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJlbXBsb3llZUlkIiwic2V0RW1wbG95ZWVJZCIsImN1c3RvbWVycyIsInNldEN1c3RvbWVycyIsImN1c3RvbWVySWQiLCJzZXRDdXN0b21lcklkIiwiZmV0Y2hFbXBsb3llZXMiLCJyZXMiLCJnZXQiLCJkYXRhIiwiZW1wbG95ZWUiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJmZXRjaEN1c3RvbWVycyIsImhhbmRsZVNlYXJjaCIsImFsZXJ0IiwicG9zdCIsImVtcGxveWVlX2lkIiwiZnJvbV9kYXRlIiwidG9fZGF0ZSIsImZvcm1hdHRlZCIsIm1hcCIsInJvdyIsImluZGV4IiwiaWQiLCJfaWQiLCJzbE5vIiwicmVkZW1wdGlvblR5cGUiLCJyZWRlbXB0aW9uX3R5cGUiLCJ1c2VkUG9pbnRzIiwicG9pbnRzX3VzZWQiLCJhbW91bnQiLCJkZXNjcmlwdGlvbiIsImxlbmd0aCIsInJlZHVjZSIsInN1bSIsInIiLCJjdXN0b21lcl9pZCIsInJlZGVlbWVkUG9pbnRzIiwicmVkZWVtZWRfcG9pbnRzIiwicmVkZWVtZWRBbW91bnQiLCJyZWRlZW1lZF9hbW91bnQiLCJyZW1hcmtzIiwicmVzcG9uc2UiLCJlbXBsb3llZUNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJjdXN0b21lckNvbHVtbnMiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZW1wIiwibmFtZSIsInBob25lX251bWJlciIsImN1c3QiLCJmdWxsX25hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZWRlbXB0aW9uUG9pbnRzUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7U2VsZWN0fSBmcm9tIFwiYW50ZFwiXHJcblxyXG4vLyBjb25zdCBSZWRlbXB0aW9uUG9pbnRzUmVwb3J0ID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2VtcGxveWVlSWQsIHNldEVtcGxveWVlSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW3Jld2FyZERhdGFUYWJsZSwgc2V0UmV3YXJkRGF0YVRhYmxlXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IEZFVENIIEVNUExPWUVFUyA9PT09PT09PT09PT09PT09PSAqL1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1lbXBsb3llZVwiKTtcclxuLy8gICAgICAgICBjb25zb2xlLmluZm8ocmVzKTtcclxuLy8gICAgICAgICBzZXRFbXBsb3llZXMocmVzLmRhdGE/LmVtcGxveWVlIHx8IFtdKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcIlVuYWJsZSB0byBmZXRjaCBlbXBsb3llZXNcIiwgZXJyKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuLy8gICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICAvKiA9PT09PT09PT09PT09PT09PSBGRVRDSCBSRVdBUkQgUE9JTlRTID09PT09PT09PT09PT09PT09ICovXHJcbi8vICAgY29uc3QgZmV0Y2hSZXdhcmRQb2ludHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICBpZiAoIWVtcGxveWVlSWQgfHwgIWZyb21EYXRlIHx8ICF0b0RhdGUpIHtcclxuLy8gICAgICAgYWxlcnQoXCJQbGVhc2Ugc2VsZWN0IEVtcGxveWVlLCBGcm9tIERhdGUgYW5kIFRvIERhdGVcIik7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG5cclxuLy8gICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLnBvc3QoXCIvcmV3YXJkLXBvaW50cy9yZWRlbXB0aW9uXCIsIHtcclxuLy8gICAgICAgICBlbXBsb3llZV9pZDogZW1wbG95ZWVJZCxcclxuLy8gICAgICAgICBmcm9tX2RhdGU6IGZyb21EYXRlLFxyXG4vLyAgICAgICAgIHRvX2RhdGU6IHRvRGF0ZSxcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIGNvbnNvbGUuaW5mbyhyZXMsIFwicmVkZW1wdGlvblwiKTtcclxuXHJcbi8vICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXMuZGF0YT8uZGF0YT8ubWFwKChyZXdhcmQsIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAgIGlkOiByZXdhcmQuX2lkLFxyXG4vLyAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICB1c2VkUG9pbnRzOiByZXdhcmQucG9pbnRzX3VzZWQgPz8gXCItXCIsXHJcbi8vICAgICAgICAgcmVkZW1wdGlvblR5cGU6IHJld2FyZC5yZWRlbXB0aW9uX3R5cGUgPz8gXCItXCIsXHJcbi8vICAgICAgICAgYW1vdW50OiByZXdhcmQuYW1vdW50ID8/IFwiLVwiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiByZXdhcmQuZGVzY3JpcHRpb24gfHwgXCItXCIsXHJcbi8vICAgICAgIH0pKTtcclxuXHJcbi8vICAgICAgIHNldFJld2FyZERhdGFUYWJsZShmb3JtYXR0ZWREYXRhIHx8IFtdKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiVW5hYmxlIHRvIGZldGNoIHJld2FyZCBwb2ludHNcIiwgZXJyKTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IFRBQkxFIENPTFVNTlMgPT09PT09PT09PT09PT09PT0gKi9cclxuLy8gICBjb25zdCByZXdhcmRDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidXNlZFBvaW50c1wiLCBoZWFkZXI6IFwiVXNlZCBQb2ludHNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVkZW1wdGlvblR5cGVcIiwgaGVhZGVyOiBcIlJlZGVtcHRpb24gVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJkZXNjcmlwdGlvblwiLCBoZWFkZXI6IFwiRGVzY3JpcHRpb25cIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2PlxyXG4vLyAgICAgICA8TmF2YmFyIC8+XHJcblxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuLy8gICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTVcIj5cclxuLy8gICAgICAgICAgICAgUmVwb3J0cyAtIFJld2FyZCBQb2ludHNcclxuLy8gICAgICAgICAgIDwvaDE+XHJcblxyXG4vLyAgICAgICAgICAgey8qID09PT09PT09PT09PT09PT09IEZJTFRFUlMgPT09PT09PT09PT09PT09PT0gKi99XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICB7LyogRW1wbG95ZWUgKi99XHJcbi8vICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtlbXBsb3llZUlkfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1wbG95ZWVJZChlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEVtcGxveWVlPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAge2VtcC5uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIEZyb20gRGF0ZSAqL31cclxuLy8gICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiXHJcbi8vICAgICAgICAgICAgICAgdmFsdWU9e2Zyb21EYXRlfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIFRvIERhdGUgKi99XHJcbi8vICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXt0b0RhdGV9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIFNlYXJjaCBCdXR0b24gKi99XHJcbi8vICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXtmZXRjaFJld2FyZFBvaW50c31cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcm91bmRlZCBweC00IHB5LTIgaG92ZXI6YmctdmlvbGV0LTcwMFwiXHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICB7bG9hZGluZyA/IFwiTG9hZGluZy4uLlwiIDogXCJTZWFyY2hcIn1cclxuLy8gICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gVEFCTEUgPT09PT09PT09PT09PT09PT0gKi99XHJcbi8vICAgICAgICAgICA8RGF0YVRhYmxlIGRhdGE9e3Jld2FyZERhdGFUYWJsZX0gY29sdW1ucz17cmV3YXJkQ29sdW1uc30gLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuLy8gY29uc3QgUmVkZW1wdGlvblBvaW50c1JlcG9ydCA9ICgpID0+IHtcclxuLy8gICAvKiA9PT09PT09PT09PT09PT09PSBDT01NT04gU1RBVEVTID09PT09PT09PT09PT09PT09ICovXHJcbi8vICAgY29uc3QgW3JlcG9ydFR5cGUsIHNldFJlcG9ydFR5cGVdID0gdXNlU3RhdGUoXCJcIik7IC8vIEVNUExPWUVFIHwgQ1VTVE9NRVJcclxuLy8gICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFt0b0RhdGUsIHNldFRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3RhYmxlRGF0YSwgc2V0VGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbi8vICAgLyogPT09PT09PT09PT09PT09PT0gRU1QTE9ZRUUgPT09PT09PT09PT09PT09PT0gKi9cclxuLy8gICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtlbXBsb3llZUlkLCBzZXRFbXBsb3llZUlkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuLy8gICAvKiA9PT09PT09PT09PT09PT09PSBDVVNUT01FUiA9PT09PT09PT09PT09PT09PSAqL1xyXG4vLyAgIGNvbnN0IFtjdXN0b21lcnMsIHNldEN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2N1c3RvbWVySWQsIHNldEN1c3RvbWVySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IEZFVENIIEVNUExPWUVFUyA9PT09PT09PT09PT09PT09PSAqL1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1lbXBsb3llZVwiKTtcclxuLy8gICAgICAgICBzZXRFbXBsb3llZXMocmVzLmRhdGE/LmVtcGxveWVlIHx8IFtdKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcIkVtcGxveWVlIGZldGNoIGVycm9yXCIsIGVycik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgLyogPT09PT09PT09PT09PT09PT0gRkVUQ0ggQ1VTVE9NRVJTID09PT09PT09PT09PT09PT09ICovXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTsgLy8gYWRqdXN0IGlmIGVuZHBvaW50IGRpZmZlcnNcclxuLy8gICAgICAgICBzZXRDdXN0b21lcnMocmVzLmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiQ3VzdG9tZXIgZmV0Y2ggZXJyb3JcIiwgZXJyKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuLy8gICAgIGZldGNoQ3VzdG9tZXJzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICAvKiA9PT09PT09PT09PT09PT09PSBTRUFSQ0ggSEFORExFUiA9PT09PT09PT09PT09PT09PSAqL1xyXG4vLyAgIGNvbnN0IGhhbmRsZVNlYXJjaCA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIGlmICghZnJvbURhdGUgfHwgIXRvRGF0ZSkge1xyXG4vLyAgICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgRnJvbSBEYXRlIGFuZCBUbyBEYXRlXCIpO1xyXG4vLyAgICAgICByZXR1cm47XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgaWYgKHJlcG9ydFR5cGUgPT09IFwiRU1QTE9ZRUVcIiAmJiAhZW1wbG95ZWVJZCkge1xyXG4vLyAgICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgRW1wbG95ZWVcIik7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBpZiAocmVwb3J0VHlwZSA9PT0gXCJDVVNUT01FUlwiICYmICFjdXN0b21lcklkKSB7XHJcbi8vICAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBDdXN0b21lclwiKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4vLyAgICAgICBsZXQgcmVzO1xyXG5cclxuLy8gICAgICAgLyogPT09PT09PT09PSBFTVBMT1lFRSBBUEkgPT09PT09PT09PSAqL1xyXG4vLyAgICAgICBpZiAocmVwb3J0VHlwZSA9PT0gXCJFTVBMT1lFRVwiKSB7XHJcbi8vICAgICAgICAgcmVzID0gYXdhaXQgYXBpLnBvc3QoXCIvcmV3YXJkLXBvaW50cy9yZWRlbXB0aW9uXCIsIHtcclxuLy8gICAgICAgICAgIGVtcGxveWVlX2lkOiBlbXBsb3llZUlkLFxyXG4vLyAgICAgICAgICAgZnJvbV9kYXRlOiBmcm9tRGF0ZSxcclxuLy8gICAgICAgICAgIHRvX2RhdGU6IHRvRGF0ZSxcclxuLy8gICAgICAgICB9KTtcclxuXHJcbi8vICAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gcmVzLmRhdGE/LmRhdGE/Lm1hcCgocm93LCBpbmRleCkgPT4gKHtcclxuLy8gICAgICAgICAgIGlkOiByb3cuX2lkLFxyXG4vLyAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4vLyAgICAgICAgICAgcmVkZW1wdGlvblR5cGU6IHJvdy5yZWRlbXB0aW9uX3R5cGUsXHJcbi8vICAgICAgICAgICB1c2VkUG9pbnRzOiByb3cucG9pbnRzX3VzZWQsXHJcbi8vICAgICAgICAgICBhbW91bnQ6IHJvdy5hbW91bnQsXHJcbi8vICAgICAgICAgICBkZXNjcmlwdGlvbjogcm93LmRlc2NyaXB0aW9uIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgIH0pKTtcclxuXHJcbi8vICAgICAgICAgc2V0VGFibGVEYXRhKGZvcm1hdHRlZCB8fCBbXSk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIC8qID09PT09PT09PT0gQ1VTVE9NRVIgQVBJID09PT09PT09PT0gKi9cclxuLy8gICAgICAgaWYgKHJlcG9ydFR5cGUgPT09IFwiQ1VTVE9NRVJcIikge1xyXG4vLyAgICAgICAgIHJlcyA9IGF3YWl0IGFwaS5wb3N0KFwiL2N1c3RvbWVyLXJld2FyZHMvcmVkZW1wdGlvblwiLCB7XHJcbi8vICAgICAgICAgICBjdXN0b21lcl9pZDogY3VzdG9tZXJJZCxcclxuLy8gICAgICAgICAgIGZyb21fZGF0ZTogZnJvbURhdGUsXHJcbi8vICAgICAgICAgICB0b19kYXRlOiB0b0RhdGUsXHJcbi8vICAgICAgICAgfSk7XHJcblxyXG4vLyAgICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJlcy5kYXRhPy5kYXRhPy5tYXAoKHJvdywgaW5kZXgpID0+ICh7XHJcbi8vICAgICAgICAgICBpZDogcm93Ll9pZCxcclxuLy8gICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIHJlZGVtcHRpb25UeXBlOiByb3cucmVkZW1wdGlvbl90eXBlLFxyXG4vLyAgICAgICAgICAgcmVkZWVtZWRQb2ludHM6IHJvdy5yZWRlZW1lZF9wb2ludHMsXHJcbi8vICAgICAgICAgICByZWRlZW1lZEFtb3VudDogcm93LnJlZGVlbWVkX2Ftb3VudCxcclxuLy8gICAgICAgICAgIHRvdGFsRWFybmVkUG9pbnRzOiByb3cudG90YWxfZWFybmVkX3BvaW50cyxcclxuLy8gICAgICAgICAgIHRvdGFsRWFybmVkQW1vdW50OiByb3cudG90YWxfZWFybmVkX2Ftb3VudCxcclxuLy8gICAgICAgICAgIGJhbGFuY2VQb2ludHM6IHJvdy5iYWxhbmNlX3BvaW50c19hZnRlcixcclxuLy8gICAgICAgICAgIGJhbGFuY2VBbW91bnQ6IHJvdy5iYWxhbmNlX3ZhbHVlX2FmdGVyLFxyXG4vLyAgICAgICAgICAgc3RhdHVzOiByb3cuc3RhdHVzLFxyXG4vLyAgICAgICAgIH0pKTtcclxuXHJcbi8vICAgICAgICAgc2V0VGFibGVEYXRhKGZvcm1hdHRlZCB8fCBbXSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiU2VhcmNoIGVycm9yOlwiLCBlcnIucmVzcG9uc2U/LmRhdGEgfHwgZXJyKTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IFRBQkxFIENPTFVNTlMgPT09PT09PT09PT09PT09PT0gKi9cclxuXHJcbi8vICAgY29uc3QgZW1wbG95ZWVDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVkZW1wdGlvblR5cGVcIiwgaGVhZGVyOiBcIlJlZGVtcHRpb24gVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ1c2VkUG9pbnRzXCIsIGhlYWRlcjogXCJSZWRlZW1lZCAgUG9pbnRzXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiUmVkZWVtZWQgQW1vdW50XCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlc2NyaXB0aW9uXCIsIGhlYWRlcjogXCJEZXNjcmlwdGlvblwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3QgY3VzdG9tZXJDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVkZW1wdGlvblR5cGVcIiwgaGVhZGVyOiBcIlJlZGVtcHRpb24gVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJyZWRlZW1lZFBvaW50c1wiLCBoZWFkZXI6IFwiUmVkZWVtZWQgUG9pbnRzXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInJlZGVlbWVkQW1vdW50XCIsIGhlYWRlcjogXCJSZWRlZW1lZCBBbW91bnRcIiB9LFxyXG4vLyAgICAgLy97IGtleTogXCJ0b3RhbEVhcm5lZFBvaW50c1wiLCBoZWFkZXI6IFwiVG90YWwgRWFybmVkIFBvaW50c1wiIH0sXHJcbi8vICAgICAvL3sga2V5OiBcInRvdGFsRWFybmVkQW1vdW50XCIsIGhlYWRlcjogXCJUb3RhbCBFYXJuZWQgQW1vdW50XCIgfSxcclxuLy8gICAgIC8veyBrZXk6IFwiYmFsYW5jZVBvaW50c1wiLCBoZWFkZXI6IFwiQmFsYW5jZSBQb2ludHNcIiB9LFxyXG4vLyAgICAvLyB7IGtleTogXCJiYWxhbmNlQW1vdW50XCIsIGhlYWRlcjogXCJCYWxhbmNlIEFtb3VudFwiIH0sXHJcbi8vICAgIC8vIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdj5cclxuLy8gICAgICAgPE5hdmJhciAvPlxyXG5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbi8vICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgIFJlZGVtcHRpb24gUG9pbnRzIFJlcG9ydFxyXG4vLyAgICAgICAgICAgPC9oMT5cclxuXHJcbi8vICAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gRklMVEVSIFNFQ1RJT04gPT09PT09PT09PT09PT09PT0gKi99XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTUgZ2FwLTQgbWItNlwiPlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIFJlcG9ydCBUeXBlICovfVxyXG4vLyAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17cmVwb3J0VHlwZX1cclxuLy8gICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgIHNldFJlcG9ydFR5cGUoZS50YXJnZXQudmFsdWUpO1xyXG4vLyAgICAgICAgICAgICAgICAgc2V0VGFibGVEYXRhKFtdKTtcclxuLy8gICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkVNUExPWUVFXCI+RW1wbG95ZWUgUmVkZW1wdGlvbjwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDVVNUT01FUlwiPkN1c3RvbWVyIFJlZGVtcHRpb248L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogRW1wbG95ZWUgKi99XHJcbi8vICAgICAgICAgICAgIHtyZXBvcnRUeXBlID09PSBcIkVNUExPWUVFXCIgJiYgKFxyXG4vLyAgICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiXHJcbi8vICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1wbG95ZWVJZH1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1wbG95ZWVJZChlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBFbXBsb3llZTwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBDdXN0b21lciAqL31cclxuLy8gICAgICAgICAgICAge3JlcG9ydFR5cGUgPT09IFwiQ1VTVE9NRVJcIiAmJiAoXHJcbi8vICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuLy8gICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21lcklkfVxyXG4vLyAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21lcklkKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEN1c3RvbWVyPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJzLm1hcCgoY3VzdCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Y3VzdC5faWR9IHZhbHVlPXtjdXN0Ll9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2N1c3QuZnVsbF9uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4vLyAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAgey8qIEZyb20gRGF0ZSAqL31cclxuLy8gICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiXHJcbi8vICAgICAgICAgICAgICAgdmFsdWU9e2Zyb21EYXRlfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIFRvIERhdGUgKi99XHJcbi8vICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXt0b0RhdGV9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIFNlYXJjaCAqL31cclxuLy8gICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNlYXJjaH1cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgaG92ZXI6YmctdmlvbGV0LTcwMFwiXHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICB7bG9hZGluZyA/IFwiTG9hZGluZy4uLlwiIDogXCJTZWFyY2hcIn1cclxuLy8gICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gVEFCTEUgPT09PT09PT09PT09PT09PT0gKi99XHJcbi8vICAgICAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgICAgIGRhdGE9e3RhYmxlRGF0YX1cclxuLy8gICAgICAgICAgICAgY29sdW1ucz17XHJcbi8vICAgICAgICAgICAgICAgcmVwb3J0VHlwZSA9PT0gXCJFTVBMT1lFRVwiID8gZW1wbG95ZWVDb2x1bW5zIDogY3VzdG9tZXJDb2x1bW5zXHJcbi8vICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbmNvbnN0IFJlZGVtcHRpb25Qb2ludHNSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3JlcG9ydFR5cGUsIHNldFJlcG9ydFR5cGVdID0gdXNlU3RhdGUoXCJFTVBMT1lFRVwiKTsgLy8gRU1QTE9ZRUUgfCBDVVNUT01FUlxyXG4gIGNvbnN0IFtmcm9tRGF0ZSwgc2V0RnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3RvRGF0ZSwgc2V0VG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdGFibGVEYXRhLCBzZXRUYWJsZURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0b3RhbFJlY29yZHM6IDAsXHJcbiAgICB0b3RhbFBvaW50czogMCxcclxuICAgIHRvdGFsQW1vdW50OiAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbXBsb3llZUlkLCBzZXRFbXBsb3llZUlkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBbY3VzdG9tZXJzLCBzZXRDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjdXN0b21lcklkLCBzZXRDdXN0b21lcklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXQtZW1wbG95ZWVcIik7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKHJlcy5kYXRhPy5lbXBsb3llZSB8fCBbXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFbXBsb3llZSBmZXRjaCBlcnJvclwiLCBlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEN1c3RvbWVycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0Q3VzdG9tZXJzKHJlcy5kYXRhIHx8IFtdKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkN1c3RvbWVyIGZldGNoIGVycm9yXCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEN1c3RvbWVycygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VhcmNoID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFmcm9tRGF0ZSB8fCAhdG9EYXRlKSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBGcm9tIERhdGUgYW5kIFRvIERhdGVcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAocmVwb3J0VHlwZSA9PT0gXCJFTVBMT1lFRVwiICYmICFlbXBsb3llZUlkKSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBFbXBsb3llZVwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChyZXBvcnRUeXBlID09PSBcIkNVU1RPTUVSXCIgJiYgIWN1c3RvbWVySWQpIHtcclxuICAgICAgYWxlcnQoXCJQbGVhc2Ugc2VsZWN0IEN1c3RvbWVyXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0VGFibGVEYXRhKFtdKTtcclxuICAgICAgc2V0U3VtbWFyeSh7IHRvdGFsUmVjb3JkczogMCwgdG90YWxQb2ludHM6IDAsIHRvdGFsQW1vdW50OiAwIH0pO1xyXG5cclxuICAgICAgbGV0IHJlcztcclxuXHJcbiAgICAgIGlmIChyZXBvcnRUeXBlID09PSBcIkVNUExPWUVFXCIpIHtcclxuICAgICAgICByZXMgPSBhd2FpdCBhcGkucG9zdChcIi9yZXdhcmQtcG9pbnRzL3JlZGVtcHRpb25cIiwge1xyXG4gICAgICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXHJcbiAgICAgICAgICBmcm9tX2RhdGU6IGZyb21EYXRlLFxyXG4gICAgICAgICAgdG9fZGF0ZTogdG9EYXRlLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPVxyXG4gICAgICAgICAgcmVzLmRhdGE/LmRhdGE/Lm1hcCgocm93LCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgaWQ6IHJvdy5faWQsXHJcbiAgICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgcmVkZW1wdGlvblR5cGU6IHJvdy5yZWRlbXB0aW9uX3R5cGUsXHJcbiAgICAgICAgICAgIHVzZWRQb2ludHM6IHJvdy5wb2ludHNfdXNlZCxcclxuICAgICAgICAgICAgYW1vdW50OiByb3cuYW1vdW50LFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogcm93LmRlc2NyaXB0aW9uIHx8IFwiLVwiLFxyXG4gICAgICAgICAgfSkpIHx8IFtdO1xyXG5cclxuICAgICAgICBzZXRUYWJsZURhdGEoZm9ybWF0dGVkKTtcclxuXHJcbiAgICAgICAgc2V0U3VtbWFyeSh7XHJcbiAgICAgICAgICB0b3RhbFJlY29yZHM6IGZvcm1hdHRlZC5sZW5ndGgsXHJcbiAgICAgICAgICB0b3RhbFBvaW50czogZm9ybWF0dGVkLnJlZHVjZShcclxuICAgICAgICAgICAgKHN1bSwgcikgPT4gc3VtICsgKHIudXNlZFBvaW50cyB8fCAwKSxcclxuICAgICAgICAgICAgMCxcclxuICAgICAgICAgICksXHJcbiAgICAgICAgICB0b3RhbEFtb3VudDogZm9ybWF0dGVkLnJlZHVjZSgoc3VtLCByKSA9PiBzdW0gKyAoci5hbW91bnQgfHwgMCksIDApLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAocmVwb3J0VHlwZSA9PT0gXCJDVVNUT01FUlwiKSB7XHJcbiAgICAgICAgcmVzID0gYXdhaXQgYXBpLnBvc3QoXCIvY3VzdG9tZXItcmV3YXJkcy9yZWRlbXB0aW9uXCIsIHtcclxuICAgICAgICAgIGN1c3RvbWVyX2lkOiBjdXN0b21lcklkLFxyXG4gICAgICAgICAgZnJvbV9kYXRlOiBmcm9tRGF0ZSxcclxuICAgICAgICAgIHRvX2RhdGU6IHRvRGF0ZSxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID1cclxuICAgICAgICAgIHJlcy5kYXRhPy5kYXRhPy5tYXAoKHJvdywgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgIGlkOiByb3cuX2lkLFxyXG4gICAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIHJlZGVtcHRpb25UeXBlOiByb3cucmVkZW1wdGlvbl90eXBlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICByZWRlZW1lZFBvaW50czogcm93LnJlZGVlbWVkX3BvaW50cyB8fCBcIi1cIixcclxuICAgICAgICAgICAgcmVkZWVtZWRBbW91bnQ6IHJvdy5yZWRlZW1lZF9hbW91bnQsXHJcbiAgICAgICAgICAgIHJlbWFya3M6IHJvdy5yZW1hcmtzLFxyXG4gICAgICAgICAgfSkpIHx8IFtdO1xyXG5cclxuICAgICAgICBzZXRUYWJsZURhdGEoZm9ybWF0dGVkKTtcclxuXHJcbiAgICAgICAgc2V0U3VtbWFyeSh7XHJcbiAgICAgICAgICB0b3RhbFJlY29yZHM6IGZvcm1hdHRlZC5sZW5ndGgsXHJcbiAgICAgICAgICB0b3RhbFBvaW50czogZm9ybWF0dGVkLnJlZHVjZShcclxuICAgICAgICAgICAgKHN1bSwgcikgPT4gc3VtICsgKHIucmVkZWVtZWRQb2ludHMgfHwgMCksXHJcbiAgICAgICAgICAgIDAsXHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICAgdG90YWxBbW91bnQ6IGZvcm1hdHRlZC5yZWR1Y2UoXHJcbiAgICAgICAgICAgIChzdW0sIHIpID0+IHN1bSArIChyLnJlZGVlbWVkQW1vdW50IHx8IDApLFxyXG4gICAgICAgICAgICAwLFxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJTZWFyY2ggZXJyb3I6XCIsIGVyci5yZXNwb25zZT8uZGF0YSB8fCBlcnIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZW1wbG95ZWVDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwicmVkZW1wdGlvblR5cGVcIiwgaGVhZGVyOiBcIlJlZGVtcHRpb24gVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VkUG9pbnRzXCIsIGhlYWRlcjogXCJSZWRlZW1lZCBQb2ludHNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJSZWRlZW1lZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGVzY3JpcHRpb25cIiwgaGVhZGVyOiBcIkRlc2NyaXB0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBjdXN0b21lckNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbE5vXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJyZWRlbXB0aW9uVHlwZVwiLCBoZWFkZXI6IFwiUmVkZW1wdGlvbiBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInJlZGVlbWVkUG9pbnRzXCIsIGhlYWRlcjogXCJSZWRlZW1lZCBQb2ludHNcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVkZWVtZWRBbW91bnRcIiwgaGVhZGVyOiBcIlJlZGVlbWVkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJyZW1hcmtzXCIsIGhlYWRlcjogXCJSZW1hcmtzXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPE5hdmJhciAvPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi02XCI+XHJcbiAgICAgICAgICAgIFJlZGVtcHRpb24gUG9pbnRzIFJlcG9ydFxyXG4gICAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTYgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17cmVwb3J0VHlwZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldFJlcG9ydFR5cGUoZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgc2V0VGFibGVEYXRhKFtdKTtcclxuICAgICAgICAgICAgICAgIHNldFN1bW1hcnkoeyB0b3RhbFJlY29yZHM6IDAsIHRvdGFsUG9pbnRzOiAwLCB0b3RhbEFtb3VudDogMCB9KTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkVNUExPWUVFXCI+RW1wbG95ZWUgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNVU1RPTUVSXCI+Q3VzdG9tZXIgPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDwvc2VsZWN0PlxyXG5cclxuICAgICAgICAgICAge3JlcG9ydFR5cGUgPT09IFwiRU1QTE9ZRUVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgLy8gPHNlbGVjdFxyXG4gICAgICAgICAgICAgIC8vICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAvLyAgIHZhbHVlPXtlbXBsb3llZUlkfVxyXG4gICAgICAgICAgICAgIC8vICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbXBsb3llZUlkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAvLyA+XHJcbiAgICAgICAgICAgICAgLy8gICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEVtcGxveWVlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgLy8gICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgLy8gICAgIDxvcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgLy8gICAgICAge2VtcC5uYW1lfVxyXG4gICAgICAgICAgICAgIC8vICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAvLyAgICkpfVxyXG4gICAgICAgICAgICAgIC8vIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctNjRcIlxyXG4gICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtlbXBsb3llZUlkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEVtcGxveWVlSWQodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX0gLSB7ZW1wLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7cmVwb3J0VHlwZSA9PT0gXCJDVVNUT01FUlwiICYmIChcclxuICAgICAgICAgICAgICAvLyA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgLy8gICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgIC8vICAgdmFsdWU9e2N1c3RvbWVySWR9XHJcbiAgICAgICAgICAgICAgLy8gICBvbkNoYW5nZT17KGUpID0+IHNldEN1c3RvbWVySWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIC8vID5cclxuICAgICAgICAgICAgICAvLyAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgQ3VzdG9tZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAvLyAgIHtjdXN0b21lcnMubWFwKChjdXN0KSA9PiAoXHJcbiAgICAgICAgICAgICAgLy8gICAgIDxvcHRpb24ga2V5PXtjdXN0Ll9pZH0gdmFsdWU9e2N1c3QuX2lkfT5cclxuICAgICAgICAgICAgICAvLyAgICAgICB7Y3VzdC5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgLy8gICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIC8vICAgKSl9XHJcbiAgICAgICAgICAgICAgLy8gPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy02NCBcIlxyXG4gICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21lcklkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEN1c3RvbWVySWQodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7Y3VzdG9tZXJzLm1hcCgoY3VzdCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2N1c3QuX2lkfSB2YWx1ZT17Y3VzdC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtjdXN0LmZ1bGxfbmFtZX0gLSB7Y3VzdC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZCBtbC0xNlwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zyb21EYXRlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZCBcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXt0b0RhdGV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNlYXJjaH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgaG92ZXI6YmctdmlvbGV0LTcwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7bG9hZGluZyA/IFwiTG9hZGluZy4uLlwiIDogXCJTZWFyY2hcIn1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7dGFibGVEYXRhLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgc2hhZG93IHJvdW5kZWQgcC00IGJvcmRlci1sLTQgYm9yZGVyLXZpb2xldC02MDBcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlRvdGFsIFJlY29yZHM8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGRcIj57c3VtbWFyeS50b3RhbFJlY29yZHN9PC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHNoYWRvdyByb3VuZGVkIHAtNCBib3JkZXItbC00IGJvcmRlci1ncmVlbi02MDBcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlRvdGFsIFJlZGVlbWVkIFBvaW50czwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZFwiPntzdW1tYXJ5LnRvdGFsUG9pbnRzfTwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBzaGFkb3cgcm91bmRlZCBwLTQgYm9yZGVyLWwtNCBib3JkZXItcHVycGxlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+VG90YWwgUmVkZWVtZWQgQW1vdW50PC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkXCI+4oK5IHtzdW1tYXJ5LnRvdGFsQW1vdW50fTwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgZGF0YT17dGFibGVEYXRhfVxyXG4gICAgICAgICAgICBjb2x1bW5zPXtcclxuICAgICAgICAgICAgICByZXBvcnRUeXBlID09PSBcIkVNUExPWUVFXCIgPyBlbXBsb3llZUNvbHVtbnMgOiBjdXN0b21lckNvbHVtbnNcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiUmVkZW1wdGlvbiBQb2ludHMgUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlJlZGVtcHRpb24gUG9pbnRzIFJlcG9ydFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSZWRlbXB0aW9uUG9pbnRzUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUmVkZW1wdGlvblBvaW50c1JlcG9ydC5qc3gifQ==