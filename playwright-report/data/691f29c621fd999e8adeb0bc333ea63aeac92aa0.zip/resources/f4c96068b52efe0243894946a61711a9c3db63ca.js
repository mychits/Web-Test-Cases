import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LeadWhatsappWelcomeMessage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, Input } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const LeadWhatsappWelcomeMessage = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const [selectAll, setSelectAll] = useState(false);
  const [auctionData, setAuctionData] = useState([]);
  const today = /* @__PURE__ */ new Date();
  const todayString = today.toISOString().split("T")[0];
  const [selectedDate, setSelectedDate] = useState(todayString);
  const [selectedLabel, setSelectedLabel] = useState("All");
  const groupOptions = [
    ...new Set(
      usersData.filter(
        (u) => u.groupName !== void 0 && u.groupName !== "" && u.groupName !== "   "
      ).map((u) => u.groupName)
    )
  ];
  const filteredUsers = useMemo(() => {
    const filtered = usersData.filter((u) => {
      const matchGroup = groupFilter ? u.groupName === groupFilter : true;
      const matchSingleDate = selectedDate ? new Date(u.enrollDate).toISOString().split("T")[0] === selectedDate : true;
      const matchFromDate = fromDate ? new Date(u.enrollDate) >= new Date(fromDate) : true;
      const matchToDate = toDate ? new Date(u.enrollDate) <= new Date(toDate) : true;
      return matchGroup && matchFromDate && matchToDate && matchSingleDate;
    });
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    leadPhone: user.leadPhone,
                    groupName: user.groupName,
                    leadName: user.leadName
                    // referredBy: user.referredBy,
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
            lineNumber: 121,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, selectedDate, activeUserData]);
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    const today2 = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      setSelectedDate(formatDate(today2));
      setFromDate("");
      setToDate("");
    } else if (value === "Yesterday") {
      const yesterday = new Date(today2);
      yesterday.setDate(yesterday.getDate() - 1);
      setSelectedDate(formatDate(yesterday));
      setFromDate("");
      setToDate("");
    } else if (value === "TwoDaysAgo") {
      const twoDaysAgo = new Date(today2);
      twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
      setSelectedDate(formatDate(twoDaysAgo));
      setFromDate("");
      setToDate("");
    } else if (value === "ThisWeek") {
      const day = today2.getDay();
      const diffToMonday = day === 0 ? 6 : day - 1;
      const monday = new Date(today2);
      monday.setDate(today2.getDate() - diffToMonday);
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      setFromDate(formatDate(monday));
      setToDate(formatDate(sunday));
      setSelectedDate("");
    } else if (value === "LastWeek") {
      const day = today2.getDay();
      const diffToMonday = day === 0 ? 6 : day - 1;
      const thisMonday = new Date(today2);
      thisMonday.setDate(today2.getDate() - diffToMonday);
      const lastMonday = new Date(thisMonday);
      lastMonday.setDate(thisMonday.getDate() - 7);
      const lastSunday = new Date(lastMonday);
      lastSunday.setDate(lastMonday.getDate() + 6);
      setFromDate(formatDate(lastMonday));
      setToDate(formatDate(lastSunday));
      setSelectedDate("");
    } else if (value === "ThisMonth") {
      const start = new Date(today2.getFullYear(), today2.getMonth(), 1);
      const end = new Date(today2.getFullYear(), today2.getMonth() + 1, 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "LastMonth") {
      const start = new Date(today2.getFullYear(), today2.getMonth() - 1, 1);
      const end = new Date(today2.getFullYear(), today2.getMonth(), 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "ThisYear") {
      const start = new Date(today2.getFullYear(), 0, 1);
      const end = new Date(today2.getFullYear(), 11, 31);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "All") {
      const start = new Date(2e3, 0, 1);
      const end = today2;
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "Custom") {
    }
  };
  useEffect(() => {
    handleSelectFilter("All");
  }, []);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp..",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      const test = await api.post("/whatsapp/lead-welcome-message", {
        receivers: visibleActiveUsers
      });
      console.info(test, "hghgfghgff");
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete newActiveUserData[user._id];
        }
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Has Been Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  useEffect(() => {
    const allChecked = filteredUsers.length > 0 && filteredUsers.every((user) => activeUserData[user._id]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredUsers, activeUserData]);
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/lead/get-lead");
      const usersList = [];
      const tempActive = {};
      const data = reportResponse.data?.map((lead, index) => {
        const id = lead._id;
        const leadName = lead?.lead_name;
        const leadPhone = lead?.lead_phone;
        const groupName = lead?.group_id?.group_name;
        const enrollDate = lead?.createdAt.split("T")[0];
        tempActive[id] = {
          info: {
            status: false
          }
        };
        const tempUsr = {
          _id: id,
          leadName,
          leadPhone,
          groupName,
          // groupId,
          enrollmentDate: lead?.group_id?.createdAt,
          enrollDate
          // leadenrollDate,
        };
        usersList.push(tempUsr);
        return {
          slNo: index + 1,
          groupName,
          leadName,
          leadPhone,
          //  groupId,
          referredBy: lead?.lead_agent?.name,
          enrollDate
        };
      });
      console.info(data, "jkgnsdkgjsbng");
      setAuctionData(data);
      setUsersData(usersList);
      setActiveUserData(tempActive);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "checkBoxs", header: "Select User" },
    { key: "leadName", header: "Lead Name" },
    { key: "leadPhone", header: "Phone Number" },
    { key: "enrollDate", header: "Joined on" },
    // { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" }
    //  {key: "paymentsTicket", header: "Ticket"},
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
        lineNumber: 355,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
      lineNumber: 359,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
        lineNumber: 362,
        columnNumber: 14
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Lead Welcome Message" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
        lineNumber: 363,
        columnNumber: 11
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
          lineNumber: 369,
          columnNumber: 13
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
          lineNumber: 372,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
          lineNumber: 371,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                  lineNumber: 379,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                  lineNumber: 380,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                lineNumber: 378,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                lineNumber: 384,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
              lineNumber: 377,
              columnNumber: 3
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                  lineNumber: 389,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                  lineNumber: 390,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                lineNumber: 388,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                lineNumber: 394,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
              lineNumber: 387,
              columnNumber: 3
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
            lineNumber: 376,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Select Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                lineNumber: 399,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  style: { width: 200 },
                  allowClear: true,
                  placeholder: "--All groups--",
                  onChange: (value) => setGroupFilter(value),
                  value: groupFilter || void 0,
                  className: "w-full max-w-xs h-11 ",
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 411,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                  lineNumber: 402,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
              lineNumber: 398,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mb-5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "font-medium", children: "Select Date Filter" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                lineNumber: 419,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  className: "border p-2 rounded text-sm",
                  value: selectedLabel,
                  onChange: (e) => handleSelectFilter(e.target.value),
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "Today", children: "Today" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 425,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 426,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "TwoDaysAgo", children: "Two Days Ago" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 427,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "ThisWeek", children: "This Week" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 428,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "LastWeek", children: "Last Week" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 429,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "ThisMonth", children: "This Month" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 430,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "LastMonth", children: "Last Month" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 431,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "ThisYear", children: "This Year" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 432,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "All", children: "All" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 433,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Custom", children: "Custom" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 434,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                  lineNumber: 420,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
              lineNumber: 418,
              columnNumber: 19
            }, this),
            selectedLabel && /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                lineNumber: 440,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "date",
                  value: selectedDate,
                  onChange: (e) => {
                    setSelectedDate(e.target?.value?.split("T")[0]);
                  },
                  className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full max-w-xs"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                  lineNumber: 441,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
              lineNumber: 439,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-5", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                lineNumber: 453,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  className: "ml-4 w-4 h-4 mb-3",
                  checked: selectAll,
                  onChange: (e) => {
                    const checked = e.target.checked;
                    setSelectAll(checked);
                    const updatedData = { ...activeUserData };
                    filteredUsers.forEach((user) => {
                      updatedData[user._id] = {
                        info: {
                          status: checked,
                          leadPhone: user.leadPhone,
                          groupName: user.groupName,
                          leadName: user.leadName
                          // groupId: user.groupId?._id || user.groupId,
                          //  userId: user.userId,
                        }
                      };
                    });
                    setActiveUserData(updatedData);
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                  lineNumber: 456,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
              lineNumber: 452,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
            lineNumber: 397,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                      lineNumber: 495,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                    lineNumber: 491,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
                  lineNumber: 498,
                  columnNumber: 21
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
              lineNumber: 486,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
            lineNumber: 485,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Lead Welcome Message",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Lead Welcome Message.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
              lineNumber: 502,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
          lineNumber: 375,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
        lineNumber: 368,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
      lineNumber: 361,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
    lineNumber: 354,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx",
    lineNumber: 353,
    columnNumber: 5
  }, this);
};
_s(LeadWhatsappWelcomeMessage, "hBQX0jBIJoGq/9LdF3OTbTN9l6A=", false, function() {
  return [notification.useNotification];
});
_c = LeadWhatsappWelcomeMessage;
export default LeadWhatsappWelcomeMessage;
var _c;
$RefreshReg$(_c, "LeadWhatsappWelcomeMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappWelcomeMessage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0hVOzJCQXhIVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLFFBQVFDLGFBQWE7QUFDOUIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFHdkIsTUFBTUMsNkJBQTZCQSxNQUFNO0FBQUFDLEtBQUE7QUFDdkMsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlsQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUIsV0FBV0MsWUFBWSxJQUFJcEIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3FCLGFBQWFDLGNBQWMsSUFBSXRCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUN1QixVQUFVQyxXQUFXLElBQUl4QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDeUIsUUFBUUMsU0FBUyxJQUFJMUIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzJCLGdCQUFnQkMsaUJBQWlCLElBQUk1QixTQUFTLENBQUMsQ0FBQztBQUN2RCxRQUFNLENBQUM2QixXQUFXQyxZQUFZLElBQUk5QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDK0IsWUFBWUMsYUFBYSxJQUFJaEMsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ2lDLFVBQVVDLGFBQWEsSUFBSXhCLGFBQWF5QixnQkFBZ0I7QUFDL0QsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlyQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDc0MsYUFBYUMsY0FBYyxJQUFJdkMsU0FBUyxFQUFFO0FBQ2pELFFBQU13QyxRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFFBQU1DLGNBQWNGLE1BQU1HLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNwRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSTlDLFNBQVMwQyxXQUFXO0FBQzVELFFBQU0sQ0FBQ0ssZUFBZUMsZ0JBQWdCLElBQUloRCxTQUFTLEtBQUs7QUFFeEQsUUFBTWlELGVBQWU7QUFBQSxJQUNuQixHQUFHLElBQUlDO0FBQUFBLE1BQ0wvQixVQUNHZ0M7QUFBQUEsUUFDQyxDQUFDQyxNQUNDQSxFQUFFQyxjQUFjQyxVQUNoQkYsRUFBRUMsY0FBYyxNQUNoQkQsRUFBRUMsY0FBYztBQUFBLE1BQ3BCLEVBQ0NFLElBQUksQ0FBQ0gsTUFBTUEsRUFBRUMsU0FBUztBQUFBLElBQzNCO0FBQUEsRUFBQztBQXFESCxRQUFNRyxnQkFBZ0J2RCxRQUFRLE1BQU07QUFDbEMsVUFBTXdELFdBQVd0QyxVQUFVZ0MsT0FBTyxDQUFDQyxNQUFNO0FBQ3ZDLFlBQU1NLGFBQWFyQyxjQUFjK0IsRUFBRUMsY0FBY2hDLGNBQWM7QUFFL0QsWUFBTXNDLGtCQUFrQmQsZUFDcEIsSUFBSUosS0FBS1csRUFBRVEsVUFBVSxFQUFFakIsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDLE1BQU1DLGVBQ3ZEO0FBRUosWUFBTWdCLGdCQUFnQnRDLFdBQ2xCLElBQUlrQixLQUFLVyxFQUFFUSxVQUFVLEtBQUssSUFBSW5CLEtBQUtsQixRQUFRLElBQzNDO0FBRUosWUFBTXVDLGNBQWNyQyxTQUNoQixJQUFJZ0IsS0FBS1csRUFBRVEsVUFBVSxLQUFLLElBQUluQixLQUFLaEIsTUFBTSxJQUN6QztBQUVKLGFBQU9pQyxjQUFjRyxpQkFBaUJDLGVBQWVIO0FBQUFBLElBQ3ZELENBQUM7QUFFRCxXQUFPRixTQUFTRixJQUFJLENBQUNRLE1BQU1DLFVBQVU7QUFDbkMsWUFBTUMsYUFBYSxDQUFDLENBQUN0QyxlQUFlb0MsS0FBS0csR0FBRyxHQUFHQyxNQUFNQztBQUVyRCxhQUFPO0FBQUEsUUFDTCxHQUFHTDtBQUFBQSxRQUNITSxPQUFPTCxRQUFRO0FBQUEsUUFDZk0sV0FDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU0w7QUFBQUEsWUFDVCxVQUFVLENBQUNNLE1BQU07QUFDZjNDLGdDQUFrQixDQUFDNEMsVUFBVTtBQUFBLGdCQUMzQixHQUFHQTtBQUFBQSxnQkFDSCxDQUFDVCxLQUFLRyxHQUFHLEdBQUc7QUFBQSxrQkFDVkMsTUFBTTtBQUFBLG9CQUNKQyxRQUFRRyxFQUFFRSxPQUFPQztBQUFBQSxvQkFDakJDLFdBQVdaLEtBQUtZO0FBQUFBLG9CQUNoQnRCLFdBQVdVLEtBQUtWO0FBQUFBLG9CQUNoQnVCLFVBQVViLEtBQUthO0FBQUFBO0FBQUFBLGtCQUVqQjtBQUFBLGdCQUNGO0FBQUEsY0FDRixFQUFFO0FBQUEsWUFDSjtBQUFBO0FBQUEsVUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBZ0JJO0FBQUEsUUFHTlg7QUFBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDOUMsV0FBV0UsYUFBYUUsVUFBVUUsUUFBUW9CLGNBQWNsQixjQUFjLENBQUM7QUFFM0UsUUFBTWtELHFCQUFxQkEsQ0FBQ0MsVUFBVTtBQUNwQzlCLHFCQUFpQjhCLEtBQUs7QUFFdEIsVUFBTXRDLFNBQVEsb0JBQUlDLEtBQUs7QUFDdkIsVUFBTXNDLGFBQWFBLENBQUNDLFNBQVNBLEtBQUtDLG1CQUFtQixPQUFPO0FBRTVELFFBQUlILFVBQVUsU0FBUztBQUNyQmhDLHNCQUFnQmlDLFdBQVd2QyxNQUFLLENBQUM7QUFDakNoQixrQkFBWSxFQUFFO0FBQ2RFLGdCQUFVLEVBQUU7QUFBQSxJQUNkLFdBQVdvRCxVQUFVLGFBQWE7QUFDaEMsWUFBTUksWUFBWSxJQUFJekMsS0FBS0QsTUFBSztBQUNoQzBDLGdCQUFVQyxRQUFRRCxVQUFVRSxRQUFRLElBQUksQ0FBQztBQUN6Q3RDLHNCQUFnQmlDLFdBQVdHLFNBQVMsQ0FBQztBQUNyQzFELGtCQUFZLEVBQUU7QUFDZEUsZ0JBQVUsRUFBRTtBQUFBLElBQ2QsV0FBV29ELFVBQVUsY0FBYztBQUNqQyxZQUFNTyxhQUFhLElBQUk1QyxLQUFLRCxNQUFLO0FBQ2pDNkMsaUJBQVdGLFFBQVFFLFdBQVdELFFBQVEsSUFBSSxDQUFDO0FBQzNDdEMsc0JBQWdCaUMsV0FBV00sVUFBVSxDQUFDO0FBQ3RDN0Qsa0JBQVksRUFBRTtBQUNkRSxnQkFBVSxFQUFFO0FBQUEsSUFDZCxXQUFXb0QsVUFBVSxZQUFZO0FBQy9CLFlBQU1RLE1BQU05QyxPQUFNK0MsT0FBTztBQUN6QixZQUFNQyxlQUFlRixRQUFRLElBQUksSUFBSUEsTUFBTTtBQUMzQyxZQUFNRyxTQUFTLElBQUloRCxLQUFLRCxNQUFLO0FBQzdCaUQsYUFBT04sUUFBUTNDLE9BQU00QyxRQUFRLElBQUlJLFlBQVk7QUFDN0MsWUFBTUUsU0FBUyxJQUFJakQsS0FBS2dELE1BQU07QUFDOUJDLGFBQU9QLFFBQVFNLE9BQU9MLFFBQVEsSUFBSSxDQUFDO0FBQ25DNUQsa0JBQVl1RCxXQUFXVSxNQUFNLENBQUM7QUFDOUIvRCxnQkFBVXFELFdBQVdXLE1BQU0sQ0FBQztBQUM1QjVDLHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsV0FBV2dDLFVBQVUsWUFBWTtBQUMvQixZQUFNUSxNQUFNOUMsT0FBTStDLE9BQU87QUFDekIsWUFBTUMsZUFBZUYsUUFBUSxJQUFJLElBQUlBLE1BQU07QUFDM0MsWUFBTUssYUFBYSxJQUFJbEQsS0FBS0QsTUFBSztBQUNqQ21ELGlCQUFXUixRQUFRM0MsT0FBTTRDLFFBQVEsSUFBSUksWUFBWTtBQUNqRCxZQUFNSSxhQUFhLElBQUluRCxLQUFLa0QsVUFBVTtBQUN0Q0MsaUJBQVdULFFBQVFRLFdBQVdQLFFBQVEsSUFBSSxDQUFDO0FBQzNDLFlBQU1TLGFBQWEsSUFBSXBELEtBQUttRCxVQUFVO0FBQ3RDQyxpQkFBV1YsUUFBUVMsV0FBV1IsUUFBUSxJQUFJLENBQUM7QUFDM0M1RCxrQkFBWXVELFdBQVdhLFVBQVUsQ0FBQztBQUNsQ2xFLGdCQUFVcUQsV0FBV2MsVUFBVSxDQUFDO0FBQ2hDL0Msc0JBQWdCLEVBQUU7QUFBQSxJQUNwQixXQUFXZ0MsVUFBVSxhQUFhO0FBQ2hDLFlBQU1nQixRQUFRLElBQUlyRCxLQUFLRCxPQUFNdUQsWUFBWSxHQUFHdkQsT0FBTXdELFNBQVMsR0FBRyxDQUFDO0FBQy9ELFlBQU1DLE1BQU0sSUFBSXhELEtBQUtELE9BQU11RCxZQUFZLEdBQUd2RCxPQUFNd0QsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNqRXhFLGtCQUFZdUQsV0FBV2UsS0FBSyxDQUFDO0FBQzdCcEUsZ0JBQVVxRCxXQUFXa0IsR0FBRyxDQUFDO0FBQ3pCbkQsc0JBQWdCLEVBQUU7QUFBQSxJQUNwQixXQUFXZ0MsVUFBVSxhQUFhO0FBQ2hDLFlBQU1nQixRQUFRLElBQUlyRCxLQUFLRCxPQUFNdUQsWUFBWSxHQUFHdkQsT0FBTXdELFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbkUsWUFBTUMsTUFBTSxJQUFJeEQsS0FBS0QsT0FBTXVELFlBQVksR0FBR3ZELE9BQU13RCxTQUFTLEdBQUcsQ0FBQztBQUM3RHhFLGtCQUFZdUQsV0FBV2UsS0FBSyxDQUFDO0FBQzdCcEUsZ0JBQVVxRCxXQUFXa0IsR0FBRyxDQUFDO0FBQ3pCbkQsc0JBQWdCLEVBQUU7QUFBQSxJQUNwQixXQUFXZ0MsVUFBVSxZQUFZO0FBQy9CLFlBQU1nQixRQUFRLElBQUlyRCxLQUFLRCxPQUFNdUQsWUFBWSxHQUFHLEdBQUcsQ0FBQztBQUNoRCxZQUFNRSxNQUFNLElBQUl4RCxLQUFLRCxPQUFNdUQsWUFBWSxHQUFHLElBQUksRUFBRTtBQUNoRHZFLGtCQUFZdUQsV0FBV2UsS0FBSyxDQUFDO0FBQzdCcEUsZ0JBQVVxRCxXQUFXa0IsR0FBRyxDQUFDO0FBQ3pCbkQsc0JBQWdCLEVBQUU7QUFBQSxJQUNwQixXQUFXZ0MsVUFBVSxPQUFPO0FBQzFCLFlBQU1nQixRQUFRLElBQUlyRCxLQUFLLEtBQU0sR0FBRyxDQUFDO0FBQ2pDLFlBQU13RCxNQUFNekQ7QUFDWmhCLGtCQUFZdUQsV0FBV2UsS0FBSyxDQUFDO0FBQzdCcEUsZ0JBQVVxRCxXQUFXa0IsR0FBRyxDQUFDO0FBQ3pCbkQsc0JBQWdCLEVBQUU7QUFBQSxJQUNwQixXQUFXZ0MsVUFBVSxVQUFVO0FBQUEsSUFDN0I7QUFBQSxFQUVKO0FBRUEvRSxZQUFVLE1BQU07QUFDZDhFLHVCQUFtQixLQUFLO0FBQUEsRUFDMUIsR0FBRyxFQUFFO0FBRUwsUUFBTXFCLHVCQUF1QmpHLFFBQVEsTUFBTTtBQUN6QyxXQUFPdUQsY0FBY0wsT0FBTyxDQUFDWSxTQUFTQSxLQUFLRSxVQUFVLEVBQUVrQztBQUFBQSxFQUN6RCxHQUFHLENBQUMzQyxhQUFhLENBQUM7QUFFbEIsUUFBTTRDLGVBQWUsWUFBWTtBQUMvQixVQUFNQyxNQUFNO0FBQ1osUUFBSTtBQUNGcEUsZUFBU3FFLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBRUQsWUFBTUMscUJBQXFCLENBQUM7QUFDNUJuRCxvQkFBY29ELFFBQVEsQ0FBQzdDLFNBQVM7QUFDOUIsWUFBSUEsS0FBS0UsY0FBY3RDLGVBQWVvQyxLQUFLRyxHQUFHLEdBQUc7QUFDL0N5Qyw2QkFBbUI1QyxLQUFLRyxHQUFHLElBQUl2QyxlQUFlb0MsS0FBS0csR0FBRztBQUFBLFFBQ3hEO0FBQUEsTUFDRixDQUFDO0FBRUQsWUFBTTJDLE9BQU8sTUFBTTNHLElBQUk0RyxLQUFLLGtDQUFrQztBQUFBLFFBQzVEQyxXQUFXSjtBQUFBQSxNQUNiLENBQUM7QUFDREssY0FBUTdDLEtBQUswQyxNQUFNLFlBQVk7QUFFL0IsWUFBTUksb0JBQW9CLEVBQUUsR0FBR3RGLGVBQWU7QUFDOUM2QixvQkFBY29ELFFBQVEsQ0FBQzdDLFNBQVM7QUFDOUIsWUFBSUEsS0FBS0UsWUFBWTtBQUNuQixpQkFBT2dELGtCQUFrQmxELEtBQUtHLEdBQUc7QUFBQSxRQUNuQztBQUFBLE1BQ0YsQ0FBQztBQUNEdEMsd0JBQWtCcUYsaUJBQWlCO0FBRW5DaEYsZUFBU3FFLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxTQUFTUSxLQUFLO0FBQ1pqRixlQUFTcUUsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhVSxJQUFJWCxXQUFXO0FBQUEsUUFDNUJFLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFDQTNHLFlBQVUsTUFBTTtBQUVkLFVBQU1vSCxhQUNKM0QsY0FBYzJDLFNBQVMsS0FDdkIzQyxjQUFjNEQsTUFBTSxDQUFDckQsU0FBU3BDLGVBQWVvQyxLQUFLRyxHQUFHLEdBQUdDLE1BQU1DLE1BQU07QUFDdEUvQixpQkFBYThFLFVBQVU7QUFBQSxFQUN6QixHQUFHLENBQUMzRCxlQUFlN0IsY0FBYyxDQUFDO0FBRWxDLFFBQU0wRixZQUFZLFlBQVk7QUFDNUIsUUFBSTtBQUNGdkYsbUJBQWEsSUFBSTtBQUNqQixZQUFNd0YsaUJBQWlCLE1BQU1wSCxJQUFJcUgsSUFBSSxnQkFBZ0I7QUFFckQsWUFBTUMsWUFBWTtBQUNsQixZQUFNQyxhQUFhLENBQUM7QUFDcEIsWUFBTUMsT0FBT0osZUFBZUksTUFBTW5FLElBQUksQ0FBQ29FLE1BQU0zRCxVQUFVO0FBQ3JELGNBQU00RCxLQUFLRCxLQUFLekQ7QUFFaEIsY0FBTVUsV0FBVytDLE1BQU1FO0FBQ3ZCLGNBQU1sRCxZQUFZZ0QsTUFBTUc7QUFDeEIsY0FBTXpFLFlBQVlzRSxNQUFNSSxVQUFVQztBQUNsQyxjQUFNcEUsYUFBYStELE1BQU1NLFVBQVVyRixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBRS9DNkUsbUJBQVdHLEVBQUUsSUFBSTtBQUFBLFVBQ2Z6RCxNQUFNO0FBQUEsWUFDSkMsUUFBUTtBQUFBLFVBQ1Y7QUFBQSxRQUNGO0FBRUEsY0FBTThELFVBQVU7QUFBQSxVQUNkaEUsS0FBSzBEO0FBQUFBLFVBQ0xoRDtBQUFBQSxVQUNBRDtBQUFBQSxVQUNBdEI7QUFBQUE7QUFBQUEsVUFFQThFLGdCQUFnQlIsTUFBTUksVUFBVUU7QUFBQUEsVUFDaENyRTtBQUFBQTtBQUFBQSxRQUVGO0FBQ0E0RCxrQkFBVVksS0FBS0YsT0FBTztBQUV0QixlQUFPO0FBQUEsVUFDTEcsTUFBTXJFLFFBQVE7QUFBQSxVQUNkWDtBQUFBQSxVQUNBdUI7QUFBQUEsVUFDQUQ7QUFBQUE7QUFBQUEsVUFFQTJELFlBQVlYLE1BQU1ZLFlBQVlDO0FBQUFBLFVBQzlCNUU7QUFBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUNEb0QsY0FBUTdDLEtBQUt1RCxNQUFNLGVBQWU7QUFFbENuRixxQkFBZW1GLElBQUk7QUFDbkJ0RyxtQkFBYW9HLFNBQVM7QUFDdEI1Rix3QkFBa0I2RixVQUFVO0FBQUEsSUFDOUIsU0FBU2dCLE9BQU87QUFDZHpCLGNBQVF5QixNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDLFVBQUM7QUFDQzNHLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQS9CLFlBQVUsTUFBTTtBQUNkc0gsY0FBVTtBQUFBLEVBQ1osR0FBRyxFQUFFO0FBRUwsUUFBTXFCLGlCQUFpQjtBQUFBLElBQ3JCLEVBQUVyQyxLQUFLLFNBQVNzQyxRQUFRLFNBQVM7QUFBQSxJQUNqQyxFQUFFdEMsS0FBSyxhQUFhc0MsUUFBUSxjQUFjO0FBQUEsSUFDMUMsRUFBRXRDLEtBQUssWUFBWXNDLFFBQVEsWUFBWTtBQUFBLElBQ3ZDLEVBQUV0QyxLQUFLLGFBQWFzQyxRQUFRLGVBQWU7QUFBQSxJQUMzQyxFQUFFdEMsS0FBSyxjQUFjc0MsUUFBUSxZQUFZO0FBQUE7QUFBQSxJQUV6QyxFQUFFdEMsS0FBSyxhQUFhc0MsUUFBUSxhQUFhO0FBQUE7QUFBQSxFQUN6QztBQUdGLFNBQ0csdUJBQUMsU0FBSSxXQUFVLFVBQ2QsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsNkJBQTZCLENBQUNwRSxNQUFNckQsY0FBY3FELEVBQUVFLE9BQU9LLEtBQUs7QUFBQSxRQUNoRSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFFUix1QkFBQyxTQUFJLFdBQVUsaUJBQ1Y7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUNkLHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0Msb0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0M1QztBQUFBQSxNQUVELHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNqRUwsWUFDQyx1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxrQkFBZSxPQUFNLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1EQUM3QjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLCtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxPQUFFLFdBQVUsc0NBQ1YyQix3QkFBYzJDLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxXQUFRLFdBQVUsOEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDO0FBQUEsaUJBUC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLGtDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLGdCQUN2RCx1QkFBQyxPQUFFLFdBQVUscUNBQ1ZELGtDQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxpQkFBYyxXQUFVLDZCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGlCQVBwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFuQmM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQmhCO0FBQUEsVUFDZ0IsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU8sRUFBRTBDLE9BQU8sSUFBSTtBQUFBLGtCQUNwQjtBQUFBLGtCQUNBLGFBQVk7QUFBQSxrQkFDWixVQUFVLENBQUM5RCxVQUFVeEQsZUFBZXdELEtBQUs7QUFBQSxrQkFDekMsT0FBT3pELGVBQWVpQztBQUFBQSxrQkFDdEIsV0FBVTtBQUFBLGtCQUVUTCx1QkFBYU07QUFBQUEsb0JBQUksQ0FBQ3NGLFVBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZUFBYyxrQ0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUQ7QUFBQSxjQUNqRDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTzlGO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3dCLE1BQU1NLG1CQUFtQk4sRUFBRUUsT0FBT0ssS0FBSztBQUFBLGtCQUVsRDtBQUFBLDJDQUFDLFlBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQjtBQUFBLG9CQUMzQix1QkFBQyxZQUFPLE9BQU0sYUFBWSx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUM7QUFBQSxvQkFDbkMsdUJBQUMsWUFBTyxPQUFNLGNBQWEsNEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVDO0FBQUEsb0JBQ3ZDLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrQztBQUFBLG9CQUNsQyx1QkFBQyxZQUFPLE9BQU0sWUFBVyx5QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0M7QUFBQSxvQkFDbEMsdUJBQUMsWUFBTyxPQUFNLGFBQVksMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUEsb0JBQ3BDLHVCQUFDLFlBQU8sT0FBTSxhQUFZLDBCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvQztBQUFBLG9CQUNwQyx1QkFBQyxZQUFPLE9BQU0sWUFBVyx5QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0M7QUFBQSxvQkFDbEMsdUJBQUMsWUFBTyxPQUFNLE9BQU0sbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVCO0FBQUEsb0JBQ3ZCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QjtBQUFBO0FBQUE7QUFBQSxnQkFkL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxZQUVDL0IsaUJBQ0MsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxXQUFNLG9CQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVc7QUFBQSxjQUNYO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPRjtBQUFBQSxrQkFDUCxVQUFVLENBQUMwQixNQUFNO0FBQ2Z6QixvQ0FBZ0J5QixFQUFFRSxRQUFRSyxPQUFPbEMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQUEsa0JBQ2hEO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTTZGO0FBQUEsaUJBUi9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUdGLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDBCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFNBQVNSO0FBQUFBLGtCQUNULFVBQVUsQ0FBQ21DLE1BQU07QUFDZiwwQkFBTUcsVUFBVUgsRUFBRUUsT0FBT0M7QUFDekJyQyxpQ0FBYXFDLE9BQU87QUFFcEIsMEJBQU1vRSxjQUFjLEVBQUUsR0FBR25ILGVBQWU7QUFHeEM2QixrQ0FBY29ELFFBQVEsQ0FBQzdDLFNBQVM7QUFDOUIrRSxrQ0FBWS9FLEtBQUtHLEdBQUcsSUFBSTtBQUFBLHdCQUN0QkMsTUFBTTtBQUFBLDBCQUNKQyxRQUFRTTtBQUFBQSwwQkFDUkMsV0FBV1osS0FBS1k7QUFBQUEsMEJBQ2hCdEIsV0FBV1UsS0FBS1Y7QUFBQUEsMEJBQ2hCdUIsVUFBVWIsS0FBS2E7QUFBQUE7QUFBQUE7QUFBQUEsd0JBR2pCO0FBQUEsc0JBQ0Y7QUFBQSxvQkFDRixDQUFDO0FBRURoRCxzQ0FBa0JrSCxXQUFXO0FBQUEsa0JBQy9CO0FBQUE7QUFBQSxnQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBeUJJO0FBQUEsaUJBN0JOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBO0FBQUEsZUF0RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1RkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUzFDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVRGO0FBQUFBLHVDQUF1QixLQUN0QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxpQ0FBaUNBLG9CQUFvQjtBQUFBLG9CQUU1RCxpQ0FBQyxVQUFNQSxrQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0QjtBQUFBO0FBQUEsa0JBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUVGLHVCQUFDLGNBQVcsV0FBVSxRQUFPLE1BQU0sTUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxnQkFBRztBQUFBO0FBQUE7QUFBQSxZQVozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTFDO0FBQUFBLGNBQ04sU0FBU2tGO0FBQUFBLGNBQ1QsU0FBUTtBQUFBLGNBQ1QsaUJBQWdCO0FBQUEsY0FDZixpQkFBaUIsQ0FBQyxZQUFZO0FBQUEsY0FDOUIsbUJBQW1CLENBQUNySCxXQUFXO0FBQUEsY0FDL0Isa0JBQWtCO0FBQUE7QUFBQSxZQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPK0M7QUFBQSxhQXRJakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdJQTtBQUFBLFdBL0lKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpSkE7QUFBQSxTQXhKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUpBO0FBQUEsT0FoS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlLQSxLQWxLRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUtEO0FBRUo7QUFBRUwsR0F2ZklELDRCQUEwQjtBQUFBLFVBU0lMLGFBQWF5QixlQUFlO0FBQUE7QUFBQTRHLEtBVDFEaEk7QUF5Zk4sZUFBZUE7QUFBMkIsSUFBQWdJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIlNlbGVjdCIsIklucHV0IiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiRmFXaGF0c2FwcCIsIm5vdGlmaWNhdGlvbiIsIlNpZGViYXIiLCJGYVVzZXJzIiwiRmFDaGVja0NpcmNsZSIsIkJyZWFkY3J1bWIiLCJMZWFkV2hhdHNhcHBXZWxjb21lTWVzc2FnZSIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ0b3RhbFVzZXJzIiwic2V0VG90YWxVc2VycyIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsImF1Y3Rpb25EYXRhIiwic2V0QXVjdGlvbkRhdGEiLCJ0b2RheSIsIkRhdGUiLCJ0b2RheVN0cmluZyIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJzZWxlY3RlZExhYmVsIiwic2V0U2VsZWN0ZWRMYWJlbCIsImdyb3VwT3B0aW9ucyIsIlNldCIsImZpbHRlciIsInUiLCJncm91cE5hbWUiLCJ1bmRlZmluZWQiLCJtYXAiLCJmaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWQiLCJtYXRjaEdyb3VwIiwibWF0Y2hTaW5nbGVEYXRlIiwiZW5yb2xsRGF0ZSIsIm1hdGNoRnJvbURhdGUiLCJtYXRjaFRvRGF0ZSIsInVzZXIiLCJpbmRleCIsImlzU2VsZWN0ZWQiLCJfaWQiLCJpbmZvIiwic3RhdHVzIiwic2xfbm8iLCJjaGVja0JveHMiLCJlIiwicHJldiIsInRhcmdldCIsImNoZWNrZWQiLCJsZWFkUGhvbmUiLCJsZWFkTmFtZSIsImhhbmRsZVNlbGVjdEZpbHRlciIsInZhbHVlIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInR3b0RheXNBZ28iLCJkYXkiLCJnZXREYXkiLCJkaWZmVG9Nb25kYXkiLCJtb25kYXkiLCJzdW5kYXkiLCJ0aGlzTW9uZGF5IiwibGFzdE1vbmRheSIsImxhc3RTdW5kYXkiLCJzdGFydCIsImdldEZ1bGxZZWFyIiwiZ2V0TW9udGgiLCJlbmQiLCJ2aXNpYmxlU2VsZWN0ZWRDb3VudCIsImxlbmd0aCIsInNlbmRXaGF0c2FwcCIsImtleSIsIm9wZW4iLCJtZXNzYWdlIiwiZGVzY3JpcHRpb24iLCJjbGFzc05hbWUiLCJkdXJhdGlvbiIsInZpc2libGVBY3RpdmVVc2VycyIsImZvckVhY2giLCJ0ZXN0IiwicG9zdCIsInJlY2VpdmVycyIsImNvbnNvbGUiLCJuZXdBY3RpdmVVc2VyRGF0YSIsImVyciIsImFsbENoZWNrZWQiLCJldmVyeSIsImZldGNoRGF0YSIsInJlcG9ydFJlc3BvbnNlIiwiZ2V0IiwidXNlcnNMaXN0IiwidGVtcEFjdGl2ZSIsImRhdGEiLCJsZWFkIiwiaWQiLCJsZWFkX25hbWUiLCJsZWFkX3Bob25lIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwiY3JlYXRlZEF0IiwidGVtcFVzciIsImVucm9sbG1lbnREYXRlIiwicHVzaCIsInNsTm8iLCJyZWZlcnJlZEJ5IiwibGVhZF9hZ2VudCIsIm5hbWUiLCJlcnJvciIsIkF1Y3Rpb25jb2x1bW5zIiwiaGVhZGVyIiwid2lkdGgiLCJncm91cCIsInVwZGF0ZWREYXRhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGVhZFdoYXRzYXBwV2VsY29tZU1lc3NhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIElucHV0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBGYVVzZXJzLCBGYUNoZWNrQ2lyY2xlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcblxyXG5jb25zdCBMZWFkV2hhdHNhcHBXZWxjb21lTWVzc2FnZSA9ICgpID0+IHtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG90YWxVc2Vycywgc2V0VG90YWxVc2Vyc10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2F1Y3Rpb25EYXRhLCBzZXRBdWN0aW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IHRvZGF5U3RyaW5nID0gdG9kYXkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyaW5nKTtcclxuICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuICAvL2NvbnN0IGdyb3VwT3B0aW9ucyA9IFsuLi5uZXcgU2V0KHVzZXJzRGF0YS5tYXAoKHUpID0+IHUuZ3JvdXBOYW1lKSldO1xyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIC4uLm5ldyBTZXQoXHJcbiAgICAgIHVzZXJzRGF0YVxyXG4gICAgICAgIC5maWx0ZXIoXHJcbiAgICAgICAgICAodSkgPT5cclxuICAgICAgICAgICAgdS5ncm91cE5hbWUgIT09IHVuZGVmaW5lZCAmJlxyXG4gICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gXCJcIiAmJlxyXG4gICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gXCIgICBcIlxyXG4gICAgICAgIClcclxuICAgICAgICAubWFwKCh1KSA9PiB1Lmdyb3VwTmFtZSlcclxuICAgICksXHJcbiAgXTtcclxuICAvLyBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgLy8gICBjb25zdCBmaWx0ZXJlZCA9IHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuICAvLyAgICAgY29uc3QgbWF0Y2hHcm91cCA9IGdyb3VwRmlsdGVyID8gdS5ncm91cE5hbWUgPT09IGdyb3VwRmlsdGVyIDogdHJ1ZTtcclxuICAvLyAgICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSBuZXcgRGF0ZSh1LmVucm9sbG1lbnREYXRlKTtcclxuICAvLyAgICAgY29uc3QgZmlsdGVyRW5yb2xsRGF0ZSA9IHNlbGVjdGVkRGF0ZSA9PT0gdS5lbnJvbGxEYXRlXHJcbiAgLy8gICAgIGNvbnN0IG1hdGNoRnJvbURhdGUgPSBmcm9tRGF0ZVxyXG4gIC8vICAgICAgID8gZW5yb2xsbWVudERhdGUgPj0gbmV3IERhdGUoZnJvbURhdGUpXHJcbiAgLy8gICAgICAgOiB0cnVlO1xyXG4gIC8vICAgICBjb25zdCBtYXRjaFRvRGF0ZSA9IHRvRGF0ZSA/IGVucm9sbG1lbnREYXRlIDw9IG5ldyBEYXRlKHRvRGF0ZSkgOiB0cnVlO1xyXG4gIC8vICAgICByZXR1cm4gbWF0Y2hHcm91cCAmJiBtYXRjaEZyb21EYXRlICYmIG1hdGNoVG9EYXRlICYmIGZpbHRlckVucm9sbERhdGU7XHJcbiAgLy8gICB9KTtcclxuXHJcbiAgLy8gICByZXR1cm4gZmlsdGVyZWQubWFwKCh1c2VyLCBpbmRleCkgPT4ge1xyXG4gIC8vICAgICBjb25zdCBpc1NlbGVjdGVkID0gISFhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cztcclxuXHJcbiAgLy8gICAgIHJldHVybiB7XHJcbiAgLy8gICAgICAgLi4udXNlcixcclxuICAvLyAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4gIC8vICAgICAgIGNoZWNrQm94czogKFxyXG4gIC8vICAgICAgICAgPGlucHV0XHJcbiAgLy8gICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgLy8gICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgLy8gICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gIC8vICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gIC8vICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAvLyAgICAgICAgICAgICAgIFt1c2VyLl9pZF06IHtcclxuICAvLyAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gIC8vICAgICAgICAgICAgICAgICAgIHN0YXR1czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAvLyAgICAgICAgICAgICAgICAgICBsZWFkUGhvbmU6IHVzZXIubGVhZFBob25lLFxyXG4gIC8vICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbiAgLy8gICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgLy8gICAgICAgICAgICAgICAgIH0sXHJcbiAgLy8gICAgICAgICAgICAgICB9LFxyXG4gIC8vICAgICAgICAgICAgIH0pKTtcclxuICAvLyAgICAgICAgICAgfX1cclxuICAvLyAgICAgICAgIC8+XHJcbiAgLy8gICAgICAgKSxcclxuICAvLyAgICAgICBpc1NlbGVjdGVkLFxyXG4gIC8vICAgICB9O1xyXG4gIC8vICAgfSk7XHJcbiAgLy8gfSwgW1xyXG4gIC8vICAgdXNlcnNEYXRhLFxyXG4gIC8vICAgZ3JvdXBGaWx0ZXIsXHJcbiAgLy8gICBmcm9tRGF0ZSxcclxuICAvLyAgIHRvRGF0ZSxcclxuICAvLyAgIHNlYXJjaFRleHQsXHJcbiAgLy8gICBhY3RpdmVVc2VyRGF0YSxcclxuICAvLyAgIHNlYXJjaFRleHQsXHJcbiAgLy8gICBzZWxlY3RlZERhdGVcclxuICAvLyBdKTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSB1c2Vyc0RhdGEuZmlsdGVyKCh1KSA9PiB7XHJcbiAgICAgIGNvbnN0IG1hdGNoR3JvdXAgPSBncm91cEZpbHRlciA/IHUuZ3JvdXBOYW1lID09PSBncm91cEZpbHRlciA6IHRydWU7XHJcblxyXG4gICAgICBjb25zdCBtYXRjaFNpbmdsZURhdGUgPSBzZWxlY3RlZERhdGVcclxuICAgICAgICA/IG5ldyBEYXRlKHUuZW5yb2xsRGF0ZSkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0gPT09IHNlbGVjdGVkRGF0ZVxyXG4gICAgICAgIDogdHJ1ZTtcclxuXHJcbiAgICAgIGNvbnN0IG1hdGNoRnJvbURhdGUgPSBmcm9tRGF0ZVxyXG4gICAgICAgID8gbmV3IERhdGUodS5lbnJvbGxEYXRlKSA+PSBuZXcgRGF0ZShmcm9tRGF0ZSlcclxuICAgICAgICA6IHRydWU7XHJcblxyXG4gICAgICBjb25zdCBtYXRjaFRvRGF0ZSA9IHRvRGF0ZVxyXG4gICAgICAgID8gbmV3IERhdGUodS5lbnJvbGxEYXRlKSA8PSBuZXcgRGF0ZSh0b0RhdGUpXHJcbiAgICAgICAgOiB0cnVlO1xyXG5cclxuICAgICAgcmV0dXJuIG1hdGNoR3JvdXAgJiYgbWF0Y2hGcm9tRGF0ZSAmJiBtYXRjaFRvRGF0ZSAmJiBtYXRjaFNpbmdsZURhdGU7XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gZmlsdGVyZWQubWFwKCh1c2VyLCBpbmRleCkgPT4ge1xyXG4gICAgICBjb25zdCBpc1NlbGVjdGVkID0gISFhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cztcclxuXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4udXNlcixcclxuICAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4gICAgICAgIGNoZWNrQm94czogKFxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgIFt1c2VyLl9pZF06IHtcclxuICAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICBsZWFkUGhvbmU6IHVzZXIubGVhZFBob25lLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgbGVhZE5hbWU6IHVzZXIubGVhZE5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gcmVmZXJyZWRCeTogdXNlci5yZWZlcnJlZEJ5LFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICksXHJcbiAgICAgICAgaXNTZWxlY3RlZCxcclxuICAgICAgfTtcclxuICAgIH0pO1xyXG4gIH0sIFt1c2Vyc0RhdGEsIGdyb3VwRmlsdGVyLCBmcm9tRGF0ZSwgdG9EYXRlLCBzZWxlY3RlZERhdGUsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcblxyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKHRvZGF5KSk7XHJcbiAgICAgIHNldEZyb21EYXRlKFwiXCIpO1xyXG4gICAgICBzZXRUb0RhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbiAgICAgIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgeWVzdGVyZGF5LnNldERhdGUoeWVzdGVyZGF5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpKTtcclxuICAgICAgc2V0RnJvbURhdGUoXCJcIik7XHJcbiAgICAgIHNldFRvRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVHdvRGF5c0Fnb1wiKSB7XHJcbiAgICAgIGNvbnN0IHR3b0RheXNBZ28gPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHR3b0RheXNBZ28uc2V0RGF0ZSh0d29EYXlzQWdvLmdldERhdGUoKSAtIDIpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZSh0d29EYXlzQWdvKSk7XHJcbiAgICAgIHNldEZyb21EYXRlKFwiXCIpO1xyXG4gICAgICBzZXRUb0RhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNXZWVrXCIpIHtcclxuICAgICAgY29uc3QgZGF5ID0gdG9kYXkuZ2V0RGF5KCk7IC8vIFN1bmRheT0wLCBNb25kYXk9MSwgLi4uXHJcbiAgICAgIGNvbnN0IGRpZmZUb01vbmRheSA9IGRheSA9PT0gMCA/IDYgOiBkYXkgLSAxOyAvLyBhZGp1c3QgaWYgdG9kYXkgaXMgU3VuZGF5XHJcbiAgICAgIGNvbnN0IG1vbmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgbW9uZGF5LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gZGlmZlRvTW9uZGF5KTtcclxuICAgICAgY29uc3Qgc3VuZGF5ID0gbmV3IERhdGUobW9uZGF5KTtcclxuICAgICAgc3VuZGF5LnNldERhdGUobW9uZGF5LmdldERhdGUoKSArIDYpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKG1vbmRheSkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShzdW5kYXkpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0V2Vla1wiKSB7XHJcbiAgICAgIGNvbnN0IGRheSA9IHRvZGF5LmdldERheSgpO1xyXG4gICAgICBjb25zdCBkaWZmVG9Nb25kYXkgPSBkYXkgPT09IDAgPyA2IDogZGF5IC0gMTtcclxuICAgICAgY29uc3QgdGhpc01vbmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgdGhpc01vbmRheS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIGRpZmZUb01vbmRheSk7XHJcbiAgICAgIGNvbnN0IGxhc3RNb25kYXkgPSBuZXcgRGF0ZSh0aGlzTW9uZGF5KTtcclxuICAgICAgbGFzdE1vbmRheS5zZXREYXRlKHRoaXNNb25kYXkuZ2V0RGF0ZSgpIC0gNyk7XHJcbiAgICAgIGNvbnN0IGxhc3RTdW5kYXkgPSBuZXcgRGF0ZShsYXN0TW9uZGF5KTtcclxuICAgICAgbGFzdFN1bmRheS5zZXREYXRlKGxhc3RNb25kYXkuZ2V0RGF0ZSgpICsgNik7XHJcbiAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUobGFzdE1vbmRheSkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShsYXN0U3VuZGF5KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbiAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQWxsXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSgyMDAwLCAwLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gdG9kYXk7XHJcbiAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuICAgICAgLy8gdXNlciBzZWxlY3RzIG1hbnVhbGx5IOKGkiBkb27igJl0IG92ZXJyaWRlXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGhhbmRsZVNlbGVjdEZpbHRlcihcIkFsbFwiKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IHZpc2libGVTZWxlY3RlZENvdW50ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHVzZXIpID0+IHVzZXIuaXNTZWxlY3RlZCkubGVuZ3RoO1xyXG4gIH0sIFtmaWx0ZXJlZFVzZXJzXSk7XHJcblxyXG4gIGNvbnN0IHNlbmRXaGF0c2FwcCA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGtleSA9IFwidXBkYXRhYmxlXCI7XHJcbiAgICB0cnkge1xyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJTZW5kaW5nIE1lc3NhZ2VzIFZpYSBXaGF0c2FwcC4uXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiUHJvY2Vzc2luZy4uLlwiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCB2aXNpYmxlQWN0aXZlVXNlcnMgPSB7fTtcclxuICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCAmJiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0pIHtcclxuICAgICAgICAgIHZpc2libGVBY3RpdmVVc2Vyc1t1c2VyLl9pZF0gPSBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF07XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHRlc3QgPSBhd2FpdCBhcGkucG9zdChcIi93aGF0c2FwcC9sZWFkLXdlbGNvbWUtbWVzc2FnZVwiLCB7XHJcbiAgICAgICAgcmVjZWl2ZXJzOiB2aXNpYmxlQWN0aXZlVXNlcnMsXHJcbiAgICAgIH0pO1xyXG4gICAgICBjb25zb2xlLmluZm8odGVzdCwgXCJoZ2hnZmdoZ2ZmXCIpO1xyXG5cclxuICAgICAgY29uc3QgbmV3QWN0aXZlVXNlckRhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQpIHtcclxuICAgICAgICAgIGRlbGV0ZSBuZXdBY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF07XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgICAgc2V0QWN0aXZlVXNlckRhdGEobmV3QWN0aXZlVXNlckRhdGEpO1xyXG5cclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiV2hhdHNhcHAgTWVzc2FnZXMgSGFzIEJlZW4gU2VudCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogXCJTdWNjZXNzXCIsXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gU2VuZCBXaGF0c2FwcFwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBlcnIubWVzc2FnZSB8fCBcIlNvbWV0aGluZyB3ZW50IHdyb25nXCIsXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJnLXJlZC0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgLy8gQXV0b21hdGljYWxseSB1cGRhdGUgc2VsZWN0QWxsIGJhc2VkIG9uIGZpbHRlcmVkVXNlcnNcclxuICAgIGNvbnN0IGFsbENoZWNrZWQgPVxyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmxlbmd0aCA+IDAgJiZcclxuICAgICAgZmlsdGVyZWRVc2Vycy5ldmVyeSgodXNlcikgPT4gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXMpO1xyXG4gICAgc2V0U2VsZWN0QWxsKGFsbENoZWNrZWQpO1xyXG4gIH0sIFtmaWx0ZXJlZFVzZXJzLCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlcG9ydFJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9sZWFkL2dldC1sZWFkXCIpO1xyXG5cclxuICAgICAgY29uc3QgdXNlcnNMaXN0ID0gW107XHJcbiAgICAgIGNvbnN0IHRlbXBBY3RpdmUgPSB7fTtcclxuICAgICAgY29uc3QgZGF0YSA9IHJlcG9ydFJlc3BvbnNlLmRhdGE/Lm1hcCgobGVhZCwgaW5kZXgpID0+IHtcclxuICAgICAgICBjb25zdCBpZCA9IGxlYWQuX2lkO1xyXG4gICAgICAgIC8vICBjb25zdCBncm91cElkID0gbGVhZD8uZ3JvdXBfaWQ7XHJcbiAgICAgICAgY29uc3QgbGVhZE5hbWUgPSBsZWFkPy5sZWFkX25hbWU7XHJcbiAgICAgICAgY29uc3QgbGVhZFBob25lID0gbGVhZD8ubGVhZF9waG9uZTtcclxuICAgICAgICBjb25zdCBncm91cE5hbWUgPSBsZWFkPy5ncm91cF9pZD8uZ3JvdXBfbmFtZTtcclxuICAgICAgICBjb25zdCBlbnJvbGxEYXRlID0gbGVhZD8uY3JlYXRlZEF0LnNwbGl0KFwiVFwiKVswXTtcclxuXHJcbiAgICAgICAgdGVtcEFjdGl2ZVtpZF0gPSB7XHJcbiAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGNvbnN0IHRlbXBVc3IgPSB7XHJcbiAgICAgICAgICBfaWQ6IGlkLFxyXG4gICAgICAgICAgbGVhZE5hbWUsXHJcbiAgICAgICAgICBsZWFkUGhvbmUsXHJcbiAgICAgICAgICBncm91cE5hbWUsXHJcbiAgICAgICAgICAvLyBncm91cElkLFxyXG4gICAgICAgICAgZW5yb2xsbWVudERhdGU6IGxlYWQ/Lmdyb3VwX2lkPy5jcmVhdGVkQXQsXHJcbiAgICAgICAgICBlbnJvbGxEYXRlLFxyXG4gICAgICAgICAgLy8gbGVhZGVucm9sbERhdGUsXHJcbiAgICAgICAgfTtcclxuICAgICAgICB1c2Vyc0xpc3QucHVzaCh0ZW1wVXNyKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgIGxlYWROYW1lLFxyXG4gICAgICAgICAgbGVhZFBob25lLFxyXG4gICAgICAgICAgLy8gIGdyb3VwSWQsXHJcbiAgICAgICAgICByZWZlcnJlZEJ5OiBsZWFkPy5sZWFkX2FnZW50Py5uYW1lLFxyXG4gICAgICAgICAgZW5yb2xsRGF0ZSxcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuICAgICAgY29uc29sZS5pbmZvKGRhdGEsIFwiamtnbnNka2dqc2JuZ1wiKTtcclxuXHJcbiAgICAgIHNldEF1Y3Rpb25EYXRhKGRhdGEpO1xyXG4gICAgICBzZXRVc2Vyc0RhdGEodXNlcnNMaXN0KTsgLy8g4pyFIHVwZGF0ZSB1c2Vyc0RhdGEgZm9yIGZpbHRlcmluZyArIGNoZWNrYm94ZXNcclxuICAgICAgc2V0QWN0aXZlVXNlckRhdGEodGVtcEFjdGl2ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBBdWN0aW9uY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY2hlY2tCb3hzXCIsIGhlYWRlcjogXCJTZWxlY3QgVXNlclwiIH0sXHJcbiAgICB7IGtleTogXCJsZWFkTmFtZVwiLCBoZWFkZXI6IFwiTGVhZCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImxlYWRQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbERhdGVcIiwgaGVhZGVyOiBcIkpvaW5lZCBvblwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJjdXN0b21lcklkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgLy8gIHtrZXk6IFwicGF5bWVudHNUaWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwifSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1jZW50ZXIgbXQtMlwiPlxyXG4gICAgICAgICAgICBMZWFkIFdlbGNvbWUgTWVzc2FnZVxyXG4gICAgICAgICAgPC9oMT5cclxuICAgICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LXN0YXJ0IGJvcmRlci1iIGJvcmRlci1ncmF5LTMwMCBtYi00XCI+PC9kaXY+XHJcbiAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTYgbXQtOCBtYi02XCI+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtMTAwIHJvdW5kZWQteGwgcC02IHNoYWRvdyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlRvdGFsIEN1c3RvbWVyczwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4gICAgICAgIHtmaWx0ZXJlZFVzZXJzLmxlbmd0aH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFVc2VycyBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgdGV4dC00eGxcIiAvPlxyXG4gIDwvZGl2PlxyXG5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5TZWxlY3RlZCBDdXN0b21lcnM8L3A+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgIHt2aXNpYmxlU2VsZWN0ZWRDb3VudH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB0ZXh0LTR4bFwiIC8+XHJcbiAgPC9kaXY+XHJcbjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tQWxsIGdyb3Vwcy0tXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEdyb3VwRmlsdGVyKHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cEZpbHRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMSBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktMiBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+U2VsZWN0IERhdGUgRmlsdGVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWQgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VsZWN0RmlsdGVyKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVG9kYXlcIj5Ub2RheTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlllc3RlcmRheVwiPlllc3RlcmRheTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlR3b0RheXNBZ29cIj5Ud28gRGF5cyBBZ288L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUaGlzV2Vla1wiPlRoaXMgV2Vlazwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhc3RXZWVrXCI+TGFzdCBXZWVrPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVGhpc01vbnRoXCI+VGhpcyBNb250aDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhc3RNb250aFwiPkxhc3QgTW9udGg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUaGlzWWVhclwiPlRoaXMgWWVhcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFsbFwiPkFsbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkN1c3RvbVwiPkN1c3RvbTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZExhYmVsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5EYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRGF0ZShlLnRhcmdldD8udmFsdWU/LnNwbGl0KFwiVFwiKVswXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGwgbWF4LXcteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IHctNCBoLTQgbWItM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTsgLy8gU2V0IGdsb2JhbCBjaGVja2JveCBzdGF0ZVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZERhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBMb29wIHRocm91Z2ggYWxsIGZpbHRlcmVkIHVzZXJzIGFuZCBhcHBseSB0aGUgc2VsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhW3VzZXIuX2lkXSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWFkUGhvbmU6IHVzZXIubGVhZFBob25lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWFkTmFtZTogdXNlci5sZWFkTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZ3JvdXBJZDogdXNlci5ncm91cElkPy5faWQgfHwgdXNlci5ncm91cElkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgdXNlcklkOiB1c2VyLnVzZXJJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSh1cGRhdGVkRGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17c2VuZFdoYXRzYXBwfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ncmVlbi03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi13LTYgaC02IGFic29sdXRlIC1yaWdodC0zIC10b3AtMiBzaGFkb3ctbGcgaG92ZXI6YmctcmVkLTYwMCBiZy1yZWQtNDAwIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YE1lc3NhZ2Ugd2lsbCBiZSBzZW50IHRvIHRvdGFsICR7dmlzaWJsZVNlbGVjdGVkQ291bnR9IGN1c3RvbWVyc2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt2aXNpYmxlU2VsZWN0ZWRDb3VudH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cIm1yLTJcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjb2x1bW5zPXtBdWN0aW9uY29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiTGVhZCBXZWxjb21lIE1lc3NhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcIkdyb3VwIE5hbWVcIl19XHJcbiAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbZ3JvdXBGaWx0ZXJdfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgTGVhZCBXZWxjb21lIE1lc3NhZ2UuY3N2YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTGVhZFdoYXRzYXBwV2VsY29tZU1lc3NhZ2U7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9MZWFkV2hhdHNhcHBXZWxjb21lTWVzc2FnZS5qc3gifQ==