import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Branches.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Dropdown, Select, Input, DatePicker } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Modal as antModal } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import __vite__cjsImport14_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport14_dayjs.__esModule ? __vite__cjsImport14_dayjs.default : __vite__cjsImport14_dayjs;
import { FaBuilding } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { MdCalendarToday, MdEmail, MdLocationOn, MdPerson2, MdPhone } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
const { confirm } = antModal;
const { TextArea } = Input;
const Branches = () => {
  _s();
  const [branches, setBranches] = useState([]);
  const [tableBranches, setTableBranches] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [currentBranch, setCurrentBranch] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [formData, setFormData] = useState({
    branch_name: "",
    // branch_code: "",
    branch_type: "",
    is_head_office: false,
    phone_number: "",
    email: "",
    street_address: "",
    street_address2: "",
    city: "",
    district: "",
    state: "",
    country: "",
    pincode: "",
    manager_name: "",
    manager_phone: "",
    status: "active",
    opening_date: null,
    gst_number: "",
    pan_number: ""
    // permissions: [],
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const branchTypeOptions = [
    { value: "HEAD_OFFICE", label: "Head Office" },
    { value: "BRANCH", label: "Branch" },
    { value: "REGIONAL_OFFICE", label: "Regional Office" },
    { value: "CORPORATE_OFFICE", label: "Corporate Office" }
  ];
  const statusOptions = [
    { value: "active", label: "Active" },
    { value: "inactive", label: "Inactive" },
    { value: "suspended", label: "Suspended" }
  ];
  const fetchBranches = async () => {
    try {
      setLoading(true);
      const response = await api.get("/v1/admin/branches");
      const branchesData = Array.isArray(response.data) ? response.data : response.data?.data || [];
      const formatted = branchesData.map((branch, index) => ({
        _id: branch._id,
        id: index + 1,
        branchCode: branch.branch_code || "N/A",
        branchName: branch.branch_name || "N/A",
        branchType: branch.branch_type ? branch.branch_type.replace(/_/g, " ") : "N/A",
        phoneNumber: branch.phone_number || "N/A",
        email: branch.email || "N/A",
        address: branch.address.street_address || "N/A",
        city: branch.address?.city || "N/A",
        state: branch.address?.state || "N/A",
        managerName: branch.manager_name || "N/A",
        status: branch.status || "Inactive",
        openingDate: branch.opening_date ? new Date(branch.opening_date).toLocaleDateString("en-GB") : "N/A",
        action: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            menu: {
              items: [
                {
                  key: "1",
                  label: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-green-600",
                      onClick: () => openEdit(branch),
                      children: "Edit"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 109,
                      columnNumber: 15
                    },
                    this
                  )
                },
                {
                  key: "2",
                  label: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-red-600",
                      onClick: () => handleDelete(branch._id),
                      children: "Delete"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 120,
                      columnNumber: 15
                    },
                    this
                  )
                }
              ]
            },
            placement: "bottomLeft",
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 132,
              columnNumber: 25
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 103,
            columnNumber: 9
          },
          this
        ),
        // Keep raw data for future use
        raw: branch
      }));
      setTableBranches(formatted);
      setBranches(branchesData);
    } catch (error) {
      console.error("Error fetching branches:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to load branches",
        type: "error"
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchBranches();
  }, [reloadTrigger]);
  const handleInputChange = (name, value) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };
  const handleSelectChange = (name, value) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };
  const handleDateChange = (date, dateString) => {
    setFormData((prev) => ({
      ...prev,
      opening_date: date ? date.toISOString() : null
    }));
  };
  const resetForm = () => {
    setFormData({
      branch_name: "",
      // branch_code: "",
      branch_type: "",
      is_head_office: false,
      phone_number: "",
      email: "",
      street_address: "",
      street_address2: "",
      city: "",
      district: "",
      state: "",
      country: "",
      pincode: "",
      manager_name: "",
      manager_phone: "",
      status: "active",
      opening_date: null,
      gst_number: "",
      pan_number: ""
      // permissions: [],
    });
    setCurrentBranch(null);
  };
  const openEdit = (branch) => {
    if (branch) {
      const addressData = branch.address || {};
      setFormData({
        branch_name: branch.branch_name || "",
        // branch_code: branch.branch_code || "",
        branch_type: branch.branch_type || "",
        is_head_office: branch.is_head_office || false,
        phone_number: branch.phone_number || "",
        email: branch.email || "",
        street_address: addressData.street_address || "",
        street_address2: addressData.street_address2 || "",
        city: addressData.city || "",
        district: addressData.district || "",
        state: addressData.state || "",
        country: addressData.country || "",
        pincode: addressData.pincode || "",
        manager_name: branch.manager_name || "",
        manager_phone: branch.manager_phone || "",
        status: branch.status || "active",
        opening_date: branch.opening_date || null,
        gst_number: branch.gst_number || "",
        pan_number: branch.pan_number || ""
        // permissions: branch.permissions || [],
      });
      setCurrentBranch(branch._id);
    } else {
      resetForm();
    }
    setModalVisible(true);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.branch_name || !formData.branch_type) {
      setAlertConfig({
        visibility: true,
        message: "Branch Name, Code, and Type are required",
        type: "error"
      });
      return;
    }
    try {
      setLoading(true);
      const payload = {
        branch_name: formData.branch_name,
        // branch_code: formData.branch_code,
        branch_type: formData.branch_type,
        is_head_office: formData.is_head_office,
        phone_number: formData.phone_number,
        email: formData.email,
        manager_name: formData.manager_name,
        manager_phone: formData.manager_phone,
        status: formData.status,
        opening_date: formData.opening_date || null,
        gst_number: formData.gst_number,
        pan_number: formData.pan_number,
        // permissions: formData.permissions,
        address: {
          street_address: formData.street_address,
          street_address2: formData.street_address2,
          city: formData.city,
          district: formData.district,
          state: formData.state,
          country: formData.country || "India",
          pincode: formData.pincode
        }
      };
      if (currentBranch) {
        await api.put(`/v1/admin/branches/${currentBranch}`, payload);
        setAlertConfig({
          visibility: true,
          message: "Branch updated successfully",
          type: "success"
        });
      } else {
        await api.post("/v1/admin/branches", payload);
        setAlertConfig({
          visibility: true,
          message: "Branch created successfully",
          type: "success"
        });
      }
      setModalVisible(false);
      resetForm();
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      console.error("Error saving branch:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to save branch",
        type: "error"
      });
    } finally {
      setLoading(false);
    }
  };
  const handleDelete = async (id) => {
    confirm({
      title: "Delete Branch",
      content: "Are you sure you want to delete this branch? This action cannot be undone.",
      okText: "Yes, Delete",
      cancelText: "Cancel",
      centered: true,
      okType: "danger",
      onOk: async () => {
        try {
          await api.delete(`/v1/admin/branches/${id}`);
          setReloadTrigger((prev) => prev + 1);
          setAlertConfig({
            visibility: true,
            message: "Branch deleted successfully",
            type: "success"
          });
        } catch (error) {
          console.error("Error deleting branch:", error);
          setAlertConfig({
            visibility: true,
            message: "Failed to delete branch",
            type: "error"
          });
        }
      }
    });
  };
  const columns = [
    { key: "id", header: "SL No" },
    { key: "branchCode", header: "Branch Code" },
    { key: "branchName", header: "Branch Name" },
    { key: "branchType", header: "Branch Type" },
    { key: "managerName", header: "Manager" },
    { key: "phoneNumber", header: "Phone" },
    { key: "email", header: "Email" },
    { key: "address", header: "address" },
    { key: "city", header: "City" },
    { key: "state", header: "State" },
    { key: "status", header: "Status" },
    { key: "action", header: "Action" }
  ];
  const getStatusBadge = (status) => {
    switch (status?.toLowerCase()) {
      case "active":
        return "bg-green-100 text-green-700 border border-green-200";
      case "suspended":
        return "bg-red-100 text-red-700 border border-red-200";
      default:
        return "bg-gray-100 text-gray-600 border border-gray-200";
    }
  };
  const getBranchTypeColor = (type) => {
    switch (type) {
      case "HEAD_OFFICE":
        return "bg-indigo-100 text-indigo-700";
      case "REGIONAL_OFFICE":
        return "bg-purple-100 text-purple-700";
      case "CORPORATE_OFFICE":
        return "bg-teal-100 text-teal-700";
      default:
        return "bg-blue-100 text-blue-700";
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
        lineNumber: 387,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 388,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
        lineNumber: 394,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 min-w-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Branches Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 399,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => openEdit(null),
              className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Create Branch"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 400,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 398,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 397,
          columnNumber: 21
        }, this),
        tableBranches.length > 0 && !loading ? /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5", children: branches.map(
          (branch) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "bg-white rounded-xl shadow-md border border-gray-100 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 overflow-hidden",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-900 px-4 py-3 flex items-start justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(FaBuilding, { className: "text-white text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 420,
                      columnNumber: 49
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 419,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxDEV("h3", { className: "text-white font-semibold truncate", children: branch.branch_name || "N/A" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                        lineNumber: 423,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-1.5 mt-1", children: [
                        /* @__PURE__ */ jsxDEV(
                          "span",
                          {
                            className: `px-2 py-0.5 text-[10px] font-medium rounded-full capitalize ${getBranchTypeColor(
                              branch.branch_type
                            )}`,
                            children: (branch.branch_type || "N/A").replace(/_/g, " ")
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                            lineNumber: 427,
                            columnNumber: 53
                          },
                          this
                        ),
                        branch.is_head_office && /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 text-[10px] font-semibold rounded-full bg-amber-400 text-amber-950", children: "★ Head Office" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                          lineNumber: 435,
                          columnNumber: 23
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                        lineNumber: 426,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 422,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 418,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Dropdown,
                    {
                      menu: {
                        items: [
                          {
                            key: "1",
                            label: /* @__PURE__ */ jsxDEV(
                              "div",
                              {
                                className: "text-green-600",
                                onClick: () => openEdit(branch),
                                children: "Edit"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                                lineNumber: 449,
                                columnNumber: 23
                              },
                              this
                            )
                          },
                          {
                            key: "2",
                            label: /* @__PURE__ */ jsxDEV(
                              "div",
                              {
                                className: "text-red-600",
                                onClick: () => handleDelete(branch._id),
                                children: "Delete"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                                lineNumber: 460,
                                columnNumber: 23
                              },
                              this
                            )
                          }
                        ]
                      },
                      placement: "bottomRight",
                      trigger: ["click"],
                      children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-white text-2xl hover:bg-white/10 rounded px-1" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                        lineNumber: 473,
                        columnNumber: 45
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 443,
                      columnNumber: 41
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 417,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-4 space-y-2.5 text-sm", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV(MdPerson2, { className: "text-gray-400 flex-shrink-0" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 480,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: branch.manager_name || "No manager assigned" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 481,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 479,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV(MdPhone, { className: "text-gray-400 flex-shrink-0" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 486,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: branch.phone_number || "N/A" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 487,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 485,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV(MdEmail, { className: "text-gray-400 flex-shrink-0" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 490,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: branch.email || "N/A" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 491,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 489,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV(MdLocationOn, { className: "text-gray-400 flex-shrink-0" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 494,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: [branch.address?.city, branch.address?.state].filter(Boolean).join(", ") || "N/A" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 495,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 493,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "pt-3 border-t border-gray-100 flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `px-2.5 py-1 text-xs font-semibold rounded-full capitalize ${getStatusBadge(
                          branch.status
                        )}`,
                        children: branch.status || "Inactive"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                        lineNumber: 504,
                        columnNumber: 45
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs text-gray-500", children: [
                      /* @__PURE__ */ jsxDEV(MdCalendarToday, { className: "text-gray-400" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                        lineNumber: 512,
                        columnNumber: 49
                      }, this),
                      branch.opening_date ? new Date(branch.opening_date).toLocaleDateString("en-GB") : "N/A"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                      lineNumber: 511,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 503,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 478,
                  columnNumber: 37
                }, this)
              ]
            },
            branch._id,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 412,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 410,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading: loading,
            failure: !loading && branches.length === 0,
            data: "Branch Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 523,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
        lineNumber: 396,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
      lineNumber: 386,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: modalVisible, onClose: () => setModalVisible(false), children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 lg:p-8 w-full max-h-[85vh] overflow-y-auto bg-slate-50", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-slate-800 tracking-tight", children: currentBranch ? "Update Branch" : "Create New Branch" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 537,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500 mt-1", children: currentBranch ? "Modify the details of the branch below." : "Fill in the details to set up a new branch." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 540,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
        lineNumber: 536,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-xl p-5 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-slate-800 mb-5 flex items-center gap-2.5 uppercase tracking-wide", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-5 bg-blue-600 rounded-full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 550,
              columnNumber: 33
            }, this),
            "Basic Information"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 549,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-x-5 gap-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: [
                "Branch Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 556,
                  columnNumber: 53
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 555,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "e.g. Downtown Branch",
                  size: "large",
                  value: formData.branch_name,
                  onChange: (e) => handleInputChange("branch_name", e.target.value),
                  required: true
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 558,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 554,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: [
                "Branch Type ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 569,
                  columnNumber: 53
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 568,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  placeholder: "Select branch type",
                  className: "w-full",
                  size: "large",
                  value: formData.branch_type || void 0,
                  onChange: (value) => handleSelectChange("branch_type", value),
                  options: branchTypeOptions
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 571,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 567,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Status" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 582,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  placeholder: "Select status",
                  className: "w-full",
                  size: "large",
                  value: formData.status || void 0,
                  onChange: (value) => handleSelectChange("status", value),
                  options: statusOptions
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 585,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 581,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Is Head Office?" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 596,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  placeholder: "Is this the head office?",
                  className: "w-full",
                  size: "large",
                  value: formData.is_head_office ? "yes" : "no",
                  onChange: (value) => handleSelectChange("is_head_office", value === "yes"),
                  options: [
                    { value: "yes", label: "Yes" },
                    { value: "no", label: "No" }
                  ]
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 599,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 595,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Opening Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 613,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                DatePicker,
                {
                  className: "w-full",
                  size: "large",
                  format: "DD-MM-YYYY",
                  value: formData.opening_date ? dayjs(formData.opening_date) : null,
                  onChange: handleDateChange,
                  placeholder: "Select opening date"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 616,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 612,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 553,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 548,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-xl p-5 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-slate-800 mb-5 flex items-center gap-2.5 uppercase tracking-wide", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-5 bg-emerald-500 rounded-full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 631,
              columnNumber: 33
            }, this),
            "Contact Information"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 630,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-x-5 gap-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Phone Number" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 636,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Enter phone number",
                  size: "large",
                  value: formData.phone_number,
                  onChange: (e) => handleInputChange("phone_number", e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 639,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 635,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Email Address" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 648,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Enter email address",
                  size: "large",
                  type: "email",
                  value: formData.email,
                  onChange: (e) => handleInputChange("email", e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 651,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 647,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 634,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 629,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-xl p-5 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-slate-800 mb-5 flex items-center gap-2.5 uppercase tracking-wide", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-5 bg-violet-500 rounded-full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 665,
              columnNumber: 33
            }, this),
            "Address Information"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 664,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Street Address Line 1" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 670,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                TextArea,
                {
                  placeholder: "Enter street address",
                  rows: 2,
                  value: formData.street_address,
                  onChange: (e) => handleInputChange("street_address", e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 673,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 669,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Street Address Line 2" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 682,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                TextArea,
                {
                  placeholder: "Enter street address 2 (Optional)",
                  rows: 2,
                  value: formData.street_address2,
                  onChange: (e) => handleInputChange("street_address2", e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 685,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 681,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-5 gap-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "City" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 695,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    placeholder: "Enter city",
                    size: "large",
                    value: formData.city,
                    onChange: (e) => handleInputChange("city", e.target.value)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 698,
                    columnNumber: 41
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 694,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "District" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 707,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    placeholder: "Enter district",
                    size: "large",
                    value: formData.district,
                    onChange: (e) => handleInputChange("district", e.target.value)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 710,
                    columnNumber: 41
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 706,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "State" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 719,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    placeholder: "Enter state",
                    size: "large",
                    value: formData.state,
                    onChange: (e) => handleInputChange("state", e.target.value)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 722,
                    columnNumber: 41
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 718,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Country" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 731,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    placeholder: "Enter country",
                    size: "large",
                    value: formData.country,
                    onChange: (e) => handleInputChange("country", e.target.value)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 734,
                    columnNumber: 41
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 730,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Pincode" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 743,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    placeholder: "Enter pincode",
                    size: "large",
                    value: formData.pincode,
                    onChange: (e) => handleInputChange("pincode", e.target.value)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                    lineNumber: 746,
                    columnNumber: 41
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 742,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 693,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 668,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 663,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-xl p-5 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-slate-800 mb-5 flex items-center gap-2.5 uppercase tracking-wide", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-5 bg-amber-500 rounded-full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 760,
              columnNumber: 33
            }, this),
            "Manager Information"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 759,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-x-5 gap-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Manager Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 765,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Enter manager name",
                  size: "large",
                  value: formData.manager_name,
                  onChange: (e) => handleInputChange("manager_name", e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 768,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 764,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "Manager Phone" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 777,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Enter manager phone",
                  size: "large",
                  value: formData.manager_phone,
                  onChange: (e) => handleInputChange("manager_phone", e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 780,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 776,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 763,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 758,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-xl p-5 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-slate-800 mb-5 flex items-center gap-2.5 uppercase tracking-wide", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-5 bg-rose-500 rounded-full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 793,
              columnNumber: 33
            }, this),
            "Tax Information"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 792,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-x-5 gap-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "GST Number" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 798,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Enter GST number",
                  size: "large",
                  value: formData.gst_number,
                  onChange: (e) => handleInputChange("gst_number", e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 801,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 797,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5", children: "PAN Number" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                lineNumber: 810,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Enter PAN number",
                  size: "large",
                  value: formData.pan_number,
                  onChange: (e) => handleInputChange("pan_number", e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
                  lineNumber: 813,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
              lineNumber: 809,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 796,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 791,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-2 pb-2", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-semibold px-10 py-3 rounded-xl shadow-lg shadow-blue-600/20 transition-all duration-200",
            children: currentBranch ? "Update Branch" : "Create Branch"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
            lineNumber: 825,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
          lineNumber: 824,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
        lineNumber: 545,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
      lineNumber: 534,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
      lineNumber: 533,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx",
    lineNumber: 385,
    columnNumber: 5
  }, this);
};
_s(Branches, "h8cKsLYHBV+BLLtHCqoBSabxjDo=");
_c = Branches;
export default Branches;
var _c;
$RefreshReg$(_c, "Branches");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Branches.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEd3QyxTQW9SaEMsVUFwUmdDOzJCQTVHeEM7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsVUFBVUMsUUFBUUMsT0FBT0Msa0JBQWtCO0FBQ3BELFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU1QsU0FBU1UsZ0JBQWdCO0FBQ2xDLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGlCQUFpQkMsU0FBU0MsY0FBY0MsV0FBV0MsZUFBZTtBQUUzRSxNQUFNLEVBQUVDLFFBQVEsSUFBSVI7QUFDcEIsTUFBTSxFQUFFUyxTQUFTLElBQUliO0FBRXJCLE1BQU1jLFdBQVdBLE1BQU07QUFBQUMsS0FBQTtBQUVuQixRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSTFCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUMyQixlQUFlQyxnQkFBZ0IsSUFBSTVCLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUM2QixTQUFTQyxVQUFVLElBQUk5QixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDK0IsY0FBY0MsZUFBZSxJQUFJaEMsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ2lDLGVBQWVDLGdCQUFnQixJQUFJbEMsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ21DLGVBQWVDLGdCQUFnQixJQUFJcEMsU0FBUyxDQUFDO0FBR3BELFFBQU0sQ0FBQ3FDLFVBQVVDLFdBQVcsSUFBSXRDLFNBQVM7QUFBQSxJQUNyQ3VDLGFBQWE7QUFBQTtBQUFBLElBRWJDLGFBQWE7QUFBQSxJQUNiQyxnQkFBZ0I7QUFBQSxJQUNoQkMsY0FBYztBQUFBLElBQ2RDLE9BQU87QUFBQSxJQUNQQyxnQkFBZ0I7QUFBQSxJQUNoQkMsaUJBQWlCO0FBQUEsSUFDakJDLE1BQU07QUFBQSxJQUNOQyxVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLElBQ1BDLFNBQVM7QUFBQSxJQUNUQyxTQUFTO0FBQUEsSUFDVEMsY0FBYztBQUFBLElBQ2RDLGVBQWU7QUFBQSxJQUNmQyxRQUFRO0FBQUEsSUFDUkMsY0FBYztBQUFBLElBQ2RDLFlBQVk7QUFBQSxJQUNaQyxZQUFZO0FBQUE7QUFBQSxFQUVoQixDQUFDO0FBR0QsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUkxRCxTQUFTO0FBQUEsSUFDM0MyRCxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNWLENBQUM7QUFHRCxRQUFNQyxvQkFBb0I7QUFBQSxJQUN0QixFQUFFQyxPQUFPLGVBQWVDLE9BQU8sY0FBYztBQUFBLElBQzdDLEVBQUVELE9BQU8sVUFBVUMsT0FBTyxTQUFTO0FBQUEsSUFDbkMsRUFBRUQsT0FBTyxtQkFBbUJDLE9BQU8sa0JBQWtCO0FBQUEsSUFDckQsRUFBRUQsT0FBTyxvQkFBb0JDLE9BQU8sbUJBQW1CO0FBQUEsRUFBQztBQUc1RCxRQUFNQyxnQkFBZ0I7QUFBQSxJQUNsQixFQUFFRixPQUFPLFVBQVVDLE9BQU8sU0FBUztBQUFBLElBQ25DLEVBQUVELE9BQU8sWUFBWUMsT0FBTyxXQUFXO0FBQUEsSUFDdkMsRUFBRUQsT0FBTyxhQUFhQyxPQUFPLFlBQVk7QUFBQSxFQUFDO0FBSTlDLFFBQU1FLGdCQUFnQixZQUFZO0FBQzlCLFFBQUk7QUFDQXBDLGlCQUFXLElBQUk7QUFDZixZQUFNcUMsV0FBVyxNQUFNOUQsSUFBSStELElBQUksb0JBQW9CO0FBRW5ELFlBQU1DLGVBQWVDLE1BQU1DLFFBQVFKLFNBQVNLLElBQUksSUFDMUNMLFNBQVNLLE9BQ1RMLFNBQVNLLE1BQU1BLFFBQVE7QUFHN0IsWUFBTUMsWUFBWUosYUFBYUssSUFBSSxDQUFDQyxRQUFRQyxXQUFXO0FBQUEsUUFDbkRDLEtBQUtGLE9BQU9FO0FBQUFBLFFBQ1pDLElBQUlGLFFBQVE7QUFBQSxRQUNaRyxZQUFZSixPQUFPSyxlQUFlO0FBQUEsUUFDbENDLFlBQVlOLE9BQU9wQyxlQUFlO0FBQUEsUUFDbEMyQyxZQUFZUCxPQUFPbkMsY0FDYm1DLE9BQU9uQyxZQUFZMkMsUUFBUSxNQUFNLEdBQUcsSUFDcEM7QUFBQSxRQUNOQyxhQUFhVCxPQUFPakMsZ0JBQWdCO0FBQUEsUUFDcENDLE9BQU9nQyxPQUFPaEMsU0FBUztBQUFBLFFBQ3ZCMEMsU0FBU1YsT0FBT1UsUUFBUXpDLGtCQUFrQjtBQUFBLFFBQzFDRSxNQUFNNkIsT0FBT1UsU0FBU3ZDLFFBQVE7QUFBQSxRQUM5QkUsT0FBTzJCLE9BQU9VLFNBQVNyQyxTQUFTO0FBQUEsUUFDaENzQyxhQUFhWCxPQUFPeEIsZ0JBQWdCO0FBQUEsUUFDcENFLFFBQVFzQixPQUFPdEIsVUFBVTtBQUFBLFFBQ3pCa0MsYUFBYVosT0FBT3JCLGVBQ2QsSUFBSWtDLEtBQUtiLE9BQU9yQixZQUFZLEVBQUVtQyxtQkFBbUIsT0FBTyxJQUN4RDtBQUFBLFFBQ05DLFFBQ0k7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQU07QUFBQSxjQUNGQyxPQUFPO0FBQUEsZ0JBQ0g7QUFBQSxrQkFDSUMsS0FBSztBQUFBLGtCQUNMNUIsT0FDSTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxXQUFVO0FBQUEsc0JBQ1YsU0FBUyxNQUFNNkIsU0FBU2xCLE1BQU07QUFBQSxzQkFBRTtBQUFBO0FBQUEsb0JBRnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGdCQUVSO0FBQUEsZ0JBQ0E7QUFBQSxrQkFDSWlCLEtBQUs7QUFBQSxrQkFDTDVCLE9BQ0k7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csV0FBVTtBQUFBLHNCQUNWLFNBQVMsTUFBTThCLGFBQWFuQixPQUFPRSxHQUFHO0FBQUEsc0JBQUU7QUFBQTtBQUFBLG9CQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxnQkFFUjtBQUFBLGNBQUM7QUFBQSxZQUVUO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFFVixpQ0FBQyxZQUFTLFdBQVUsb0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUE7QUFBQSxVQTdCeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBOEJBO0FBQUE7QUFBQSxRQUdKa0IsS0FBS3BCO0FBQUFBLE1BQ1QsRUFBRTtBQUVGL0MsdUJBQWlCNkMsU0FBUztBQUMxQi9DLGtCQUFZMkMsWUFBWTtBQUFBLElBQzVCLFNBQVMyQixPQUFPO0FBQ1pDLGNBQVFELE1BQU0sNEJBQTRCQSxLQUFLO0FBQy9DdEMscUJBQWU7QUFBQSxRQUNYQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNWLENBQUM7QUFBQSxJQUNMLFVBQUM7QUFDRy9CLGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFFQW9FLFlBQVUsTUFBTTtBQUNaaEMsa0JBQWM7QUFBQSxFQUNsQixHQUFHLENBQUMvQixhQUFhLENBQUM7QUFHbEIsUUFBTWdFLG9CQUFvQkEsQ0FBQ0MsTUFBTXJDLFVBQVU7QUFDdkN6QixnQkFBWSxDQUFDK0QsVUFBVTtBQUFBLE1BQ25CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsSUFBSSxHQUFHckM7QUFBQUEsSUFDWixFQUFFO0FBQUEsRUFDTjtBQUVBLFFBQU11QyxxQkFBcUJBLENBQUNGLE1BQU1yQyxVQUFVO0FBQ3hDekIsZ0JBQVksQ0FBQytELFVBQVU7QUFBQSxNQUNuQixHQUFHQTtBQUFBQSxNQUNILENBQUNELElBQUksR0FBR3JDO0FBQUFBLElBQ1osRUFBRTtBQUFBLEVBQ047QUFFQSxRQUFNd0MsbUJBQW1CQSxDQUFDQyxNQUFNQyxlQUFlO0FBQzNDbkUsZ0JBQVksQ0FBQytELFVBQVU7QUFBQSxNQUNuQixHQUFHQTtBQUFBQSxNQUNIL0MsY0FBY2tELE9BQU9BLEtBQUtFLFlBQVksSUFBSTtBQUFBLElBQzlDLEVBQUU7QUFBQSxFQUNOO0FBRUEsUUFBTUMsWUFBWUEsTUFBTTtBQUNwQnJFLGdCQUFZO0FBQUEsTUFDUkMsYUFBYTtBQUFBO0FBQUEsTUFFYkMsYUFBYTtBQUFBLE1BQ2JDLGdCQUFnQjtBQUFBLE1BQ2hCQyxjQUFjO0FBQUEsTUFDZEMsT0FBTztBQUFBLE1BQ1BDLGdCQUFnQjtBQUFBLE1BQ2hCQyxpQkFBaUI7QUFBQSxNQUNqQkMsTUFBTTtBQUFBLE1BQ05DLFVBQVU7QUFBQSxNQUNWQyxPQUFPO0FBQUEsTUFDUEMsU0FBUztBQUFBLE1BQ1RDLFNBQVM7QUFBQSxNQUNUQyxjQUFjO0FBQUEsTUFDZEMsZUFBZTtBQUFBLE1BQ2ZDLFFBQVE7QUFBQSxNQUNSQyxjQUFjO0FBQUEsTUFDZEMsWUFBWTtBQUFBLE1BQ1pDLFlBQVk7QUFBQTtBQUFBLElBRWhCLENBQUM7QUFDRHRCLHFCQUFpQixJQUFJO0FBQUEsRUFDekI7QUFFQSxRQUFNMkQsV0FBV0EsQ0FBQ2xCLFdBQVc7QUFDekIsUUFBSUEsUUFBUTtBQUNSLFlBQU1pQyxjQUFjakMsT0FBT1UsV0FBVyxDQUFDO0FBRXZDL0Msa0JBQVk7QUFBQSxRQUNSQyxhQUFhb0MsT0FBT3BDLGVBQWU7QUFBQTtBQUFBLFFBRW5DQyxhQUFhbUMsT0FBT25DLGVBQWU7QUFBQSxRQUNuQ0MsZ0JBQWdCa0MsT0FBT2xDLGtCQUFrQjtBQUFBLFFBQ3pDQyxjQUFjaUMsT0FBT2pDLGdCQUFnQjtBQUFBLFFBQ3JDQyxPQUFPZ0MsT0FBT2hDLFNBQVM7QUFBQSxRQUN2QkMsZ0JBQWdCZ0UsWUFBWWhFLGtCQUFrQjtBQUFBLFFBQzlDQyxpQkFBaUIrRCxZQUFZL0QsbUJBQW1CO0FBQUEsUUFDaERDLE1BQU04RCxZQUFZOUQsUUFBUTtBQUFBLFFBQzFCQyxVQUFVNkQsWUFBWTdELFlBQVk7QUFBQSxRQUNsQ0MsT0FBTzRELFlBQVk1RCxTQUFTO0FBQUEsUUFDNUJDLFNBQVMyRCxZQUFZM0QsV0FBVztBQUFBLFFBQ2hDQyxTQUFTMEQsWUFBWTFELFdBQVc7QUFBQSxRQUNoQ0MsY0FBY3dCLE9BQU94QixnQkFBZ0I7QUFBQSxRQUNyQ0MsZUFBZXVCLE9BQU92QixpQkFBaUI7QUFBQSxRQUN2Q0MsUUFBUXNCLE9BQU90QixVQUFVO0FBQUEsUUFDekJDLGNBQWNxQixPQUFPckIsZ0JBQWdCO0FBQUEsUUFDckNDLFlBQVlvQixPQUFPcEIsY0FBYztBQUFBLFFBQ2pDQyxZQUFZbUIsT0FBT25CLGNBQWM7QUFBQTtBQUFBLE1BRXJDLENBQUM7QUFDRHRCLHVCQUFpQnlDLE9BQU9FLEdBQUc7QUFBQSxJQUMvQixPQUFPO0FBRUg4QixnQkFBVTtBQUFBLElBQ2Q7QUFDQTNFLG9CQUFnQixJQUFJO0FBQUEsRUFDeEI7QUFFQSxRQUFNNkUsZUFBZSxPQUFPQyxNQUFNO0FBQzlCQSxNQUFFQyxlQUFlO0FBR2pCLFFBQUksQ0FBQzFFLFNBQVNFLGVBQWUsQ0FBQ0YsU0FBU0csYUFBYTtBQUNoRGtCLHFCQUFlO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDVixDQUFDO0FBQ0Q7QUFBQSxJQUNKO0FBRUEsUUFBSTtBQUNBL0IsaUJBQVcsSUFBSTtBQUdmLFlBQU1rRixVQUFVO0FBQUEsUUFDWnpFLGFBQWFGLFNBQVNFO0FBQUFBO0FBQUFBLFFBRXRCQyxhQUFhSCxTQUFTRztBQUFBQSxRQUN0QkMsZ0JBQWdCSixTQUFTSTtBQUFBQSxRQUN6QkMsY0FBY0wsU0FBU0s7QUFBQUEsUUFDdkJDLE9BQU9OLFNBQVNNO0FBQUFBLFFBQ2hCUSxjQUFjZCxTQUFTYztBQUFBQSxRQUN2QkMsZUFBZWYsU0FBU2U7QUFBQUEsUUFDeEJDLFFBQVFoQixTQUFTZ0I7QUFBQUEsUUFDakJDLGNBQWNqQixTQUFTaUIsZ0JBQWdCO0FBQUEsUUFDdkNDLFlBQVlsQixTQUFTa0I7QUFBQUEsUUFDckJDLFlBQVluQixTQUFTbUI7QUFBQUE7QUFBQUEsUUFFckI2QixTQUFTO0FBQUEsVUFDTHpDLGdCQUFnQlAsU0FBU087QUFBQUEsVUFDekJDLGlCQUFpQlIsU0FBU1E7QUFBQUEsVUFDMUJDLE1BQU1ULFNBQVNTO0FBQUFBLFVBQ2ZDLFVBQVVWLFNBQVNVO0FBQUFBLFVBQ25CQyxPQUFPWCxTQUFTVztBQUFBQSxVQUNoQkMsU0FBU1osU0FBU1ksV0FBVztBQUFBLFVBQzdCQyxTQUFTYixTQUFTYTtBQUFBQSxRQUN0QjtBQUFBLE1BQ0o7QUFFQSxVQUFJakIsZUFBZTtBQUVmLGNBQU01QixJQUFJNEcsSUFBSSxzQkFBc0JoRixhQUFhLElBQUkrRSxPQUFPO0FBQzVEdEQsdUJBQWU7QUFBQSxVQUNYQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNWLENBQUM7QUFBQSxNQUNMLE9BQU87QUFFSCxjQUFNeEQsSUFBSTZHLEtBQUssc0JBQXNCRixPQUFPO0FBQzVDdEQsdUJBQWU7QUFBQSxVQUNYQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNWLENBQUM7QUFBQSxNQUNMO0FBRUE3QixzQkFBZ0IsS0FBSztBQUNyQjJFLGdCQUFVO0FBQ1Z2RSx1QkFBaUIsQ0FBQ2lFLFNBQVNBLE9BQU8sQ0FBQztBQUFBLElBQ3ZDLFNBQVNMLE9BQU87QUFDWkMsY0FBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFDM0N0QyxxQkFBZTtBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaQyxTQUFTb0MsTUFBTTdCLFVBQVVLLE1BQU1aLFdBQVc7QUFBQSxRQUMxQ0MsTUFBTTtBQUFBLE1BQ1YsQ0FBQztBQUFBLElBQ0wsVUFBQztBQUNHL0IsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUdBLFFBQU1nRSxlQUFlLE9BQU9oQixPQUFPO0FBQy9CekQsWUFBUTtBQUFBLE1BQ0o4RixPQUFPO0FBQUEsTUFDUEMsU0FBUztBQUFBLE1BQ1RDLFFBQVE7QUFBQSxNQUNSQyxZQUFZO0FBQUEsTUFDWkMsVUFBVTtBQUFBLE1BQ1ZDLFFBQVE7QUFBQSxNQUNSQyxNQUFNLFlBQVk7QUFDZCxZQUFJO0FBQ0EsZ0JBQU1wSCxJQUFJcUgsT0FBTyxzQkFBc0I1QyxFQUFFLEVBQUU7QUFDM0MxQywyQkFBaUIsQ0FBQ2lFLFNBQVNBLE9BQU8sQ0FBQztBQUNuQzNDLHlCQUFlO0FBQUEsWUFDWEMsWUFBWTtBQUFBLFlBQ1pDLFNBQVM7QUFBQSxZQUNUQyxNQUFNO0FBQUEsVUFDVixDQUFDO0FBQUEsUUFDTCxTQUFTbUMsT0FBTztBQUNaQyxrQkFBUUQsTUFBTSwwQkFBMEJBLEtBQUs7QUFDN0N0Qyx5QkFBZTtBQUFBLFlBQ1hDLFlBQVk7QUFBQSxZQUNaQyxTQUFTO0FBQUEsWUFDVEMsTUFBTTtBQUFBLFVBQ1YsQ0FBQztBQUFBLFFBQ0w7QUFBQSxNQUNKO0FBQUEsSUFDSixDQUFDO0FBQUEsRUFDTDtBQUdBLFFBQU04RCxVQUFVO0FBQUEsSUFDWixFQUFFL0IsS0FBSyxNQUFNZ0MsUUFBUSxRQUFRO0FBQUEsSUFDN0IsRUFBRWhDLEtBQUssY0FBY2dDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVoQyxLQUFLLGNBQWNnQyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFaEMsS0FBSyxjQUFjZ0MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRWhDLEtBQUssZUFBZWdDLFFBQVEsVUFBVTtBQUFBLElBQ3hDLEVBQUVoQyxLQUFLLGVBQWVnQyxRQUFRLFFBQVE7QUFBQSxJQUN0QyxFQUFFaEMsS0FBSyxTQUFTZ0MsUUFBUSxRQUFRO0FBQUEsSUFDaEMsRUFBRWhDLEtBQUssV0FBV2dDLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVoQyxLQUFLLFFBQVFnQyxRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFaEMsS0FBSyxTQUFTZ0MsUUFBUSxRQUFRO0FBQUEsSUFDaEMsRUFBRWhDLEtBQUssVUFBVWdDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVoQyxLQUFLLFVBQVVnQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3ZDLFFBQU1DLGlCQUFpQkEsQ0FBQ3hFLFdBQVc7QUFDL0IsWUFBUUEsUUFBUXlFLFlBQVksR0FBQztBQUFBLE1BQ3pCLEtBQUs7QUFDRCxlQUFPO0FBQUEsTUFDWCxLQUFLO0FBQ0QsZUFBTztBQUFBLE1BQ1g7QUFDSSxlQUFPO0FBQUEsSUFDZjtBQUFBLEVBQ0o7QUFFQSxRQUFNQyxxQkFBcUJBLENBQUNsRSxTQUFTO0FBQ2pDLFlBQVFBLE1BQUk7QUFBQSxNQUNSLEtBQUs7QUFDRCxlQUFPO0FBQUEsTUFDWCxLQUFLO0FBQ0QsZUFBTztBQUFBLE1BQ1gsS0FBSztBQUNELGVBQU87QUFBQSxNQUNYO0FBQ0ksZUFBTztBQUFBLElBQ2Y7QUFBQSxFQUNKO0FBRUEsU0FDSSxtQ0FDSTtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNYO0FBQUEsNkJBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBTUosWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUFNRixlQUFlLENBQUMyQyxVQUFVLEVBQUUsR0FBR0EsTUFBTTFDLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUo1RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJOEU7QUFBQSxNQUU5RSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BRVIsdUJBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ1gsaUNBQUMsU0FBSSxXQUFVLDRDQUNYO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBCQUF5QixtQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUMxRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csU0FBUyxNQUFNa0MsU0FBUyxJQUFJO0FBQUEsY0FDNUIsV0FBVTtBQUFBLGNBQW1HO0FBQUE7QUFBQSxZQUZqSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLEtBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQ2xFLGNBQWNxRyxTQUFTLEtBQUssQ0FBQ25HLFVBQzFCLHVCQUFDLFNBQUksV0FBVSx1RUFDVkosbUJBQVNpRDtBQUFBQSxVQUFJLENBQUNDLFdBQ1g7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVHLFdBQVU7QUFBQSxjQUdWO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDREQUNYO0FBQUEseUNBQUMsU0FBSSxXQUFVLG1DQUNYO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHFGQUNYLGlDQUFDLGNBQVcsV0FBVSx3QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMEMsS0FEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxXQUNYO0FBQUEsNkNBQUMsUUFBRyxXQUFVLHFDQUNUQSxpQkFBT3BDLGVBQWUsU0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FDWDtBQUFBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNHLFdBQVcsK0RBQStEd0Y7QUFBQUEsOEJBQ3RFcEQsT0FBT25DO0FBQUFBLDRCQUNYLENBQUM7QUFBQSw0QkFFQ21DLGtCQUFPbkMsZUFBZSxPQUFPMkMsUUFBUSxNQUFNLEdBQUc7QUFBQTtBQUFBLDBCQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBTUE7QUFBQSx3QkFDQ1IsT0FBT2xDLGtCQUNKLHVCQUFDLFVBQUssV0FBVSxrRkFBaUYsNkJBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSwyQkFYUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWFBO0FBQUEseUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBa0JBO0FBQUEsdUJBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdUJBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csTUFBTTtBQUFBLHdCQUNGa0QsT0FBTztBQUFBLDBCQUNIO0FBQUEsNEJBQ0lDLEtBQUs7QUFBQSw0QkFDTDVCLE9BQ0k7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0csV0FBVTtBQUFBLGdDQUNWLFNBQVMsTUFBTTZCLFNBQVNsQixNQUFNO0FBQUEsZ0NBQUU7QUFBQTtBQUFBLDhCQUZwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBS0E7QUFBQSwwQkFFUjtBQUFBLDBCQUNBO0FBQUEsNEJBQ0lpQixLQUFLO0FBQUEsNEJBQ0w1QixPQUNJO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNHLFdBQVU7QUFBQSxnQ0FDVixTQUFTLE1BQU04QixhQUFhbkIsT0FBT0UsR0FBRztBQUFBLGdDQUFFO0FBQUE7QUFBQSw4QkFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUtBO0FBQUEsMEJBRVI7QUFBQSx3QkFBQztBQUFBLHNCQUVUO0FBQUEsc0JBQ0EsV0FBVTtBQUFBLHNCQUNWLFNBQVMsQ0FBQyxPQUFPO0FBQUEsc0JBRWpCLGlDQUFDLFlBQVMsV0FBVSx1RUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUY7QUFBQTtBQUFBLG9CQTlCM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQStCQTtBQUFBLHFCQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBEQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLHlDQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBLDJDQUFDLGFBQVUsV0FBVSxpQ0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0Q7QUFBQSxvQkFDbEQsdUJBQUMsVUFBSyxXQUFVLFlBQ1hGLGlCQUFPeEIsZ0JBQWdCLHlCQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBLDJDQUFDLFdBQVEsV0FBVSxpQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0Q7QUFBQSxvQkFDaEQsdUJBQUMsVUFBSyxXQUFVLFlBQVl3QixpQkFBT2pDLGdCQUFnQixTQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5RDtBQUFBLHVCQUY3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsMkNBQUMsV0FBUSxXQUFVLGlDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRDtBQUFBLG9CQUNoRCx1QkFBQyxVQUFLLFdBQVUsWUFBWWlDLGlCQUFPaEMsU0FBUyxTQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRDtBQUFBLHVCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsMkNBQUMsZ0JBQWEsV0FBVSxpQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUQ7QUFBQSxvQkFDckQsdUJBQUMsVUFBSyxXQUFVLFlBQ1gsV0FBQ2dDLE9BQU9VLFNBQVN2QyxNQUFNNkIsT0FBT1UsU0FBU3JDLEtBQUssRUFDeENpRixPQUFPQyxPQUFPLEVBQ2RDLEtBQUssSUFBSSxLQUFLLFNBSHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxXQUFVLG1FQUNYO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csV0FBVyw2REFBNkROO0FBQUFBLDBCQUNwRWxELE9BQU90QjtBQUFBQSx3QkFDWCxDQUFDO0FBQUEsd0JBRUFzQixpQkFBT3RCLFVBQVU7QUFBQTtBQUFBLHNCQUx0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsbURBQ1g7QUFBQSw2Q0FBQyxtQkFBZ0IsV0FBVSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMEM7QUFBQSxzQkFDekNzQixPQUFPckIsZUFDRixJQUFJa0MsS0FBS2IsT0FBT3JCLFlBQVksRUFBRW1DLG1CQUFtQixPQUFPLElBQ3hEO0FBQUEseUJBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLHVCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBY0E7QUFBQSxxQkF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF3Q0E7QUFBQTtBQUFBO0FBQUEsWUF6R0tkLE9BQU9FO0FBQUFBLFlBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUEyR0E7QUFBQSxRQUNILEtBOUdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErR0EsSUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBV2hEO0FBQUFBLFlBQ1gsU0FBUyxDQUFDQSxXQUFXSixTQUFTdUcsV0FBVztBQUFBLFlBQ3pDLE1BQUs7QUFBQTtBQUFBLFVBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3NCO0FBQUEsV0FsSTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxSUE7QUFBQSxTQS9JSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0pBO0FBQUEsSUFHQSx1QkFBQyxTQUFNLFdBQVdqRyxjQUFjLFNBQVMsTUFBTUMsZ0JBQWdCLEtBQUssR0FDaEUsaUNBQUMsU0FBSSxXQUFVLDhEQUVYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFFBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0RBQ1RDLDBCQUFnQixrQkFBa0IsdUJBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUNSQSwwQkFBZ0IsNENBQTRDLGlEQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVNEUsY0FBYyxXQUFVLGFBR3BDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZEQUNYO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDJGQUNWO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHdDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRDtBQUFBLFlBQU87QUFBQSxlQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsbURBQ1g7QUFBQSxtQ0FBQyxTQUNHO0FBQUEscUNBQUMsV0FBTSxXQUFVLDhFQUE2RTtBQUFBO0FBQUEsZ0JBQzlFLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csYUFBWTtBQUFBLGtCQUNaLE1BQUs7QUFBQSxrQkFDTCxPQUFPeEUsU0FBU0U7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQ3VFLE1BQU1YLGtCQUFrQixlQUFlVyxFQUFFc0IsT0FBT3JFLEtBQUs7QUFBQSxrQkFDaEUsVUFBUTtBQUFBO0FBQUEsZ0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS1k7QUFBQSxpQkFUaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBRUEsdUJBQUMsU0FDRztBQUFBLHFDQUFDLFdBQU0sV0FBVSw4RUFBNkU7QUFBQTtBQUFBLGdCQUM5RSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLE9BQU8xQixTQUFTRyxlQUFlNkY7QUFBQUEsa0JBQy9CLFVBQVUsQ0FBQ3RFLFVBQVV1QyxtQkFBbUIsZUFBZXZDLEtBQUs7QUFBQSxrQkFDNUQsU0FBU0Q7QUFBQUE7QUFBQUEsZ0JBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTStCO0FBQUEsaUJBVm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUVBLHVCQUFDLFNBQ0c7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsOEVBQTZFLHNCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxhQUFZO0FBQUEsa0JBQ1osV0FBVTtBQUFBLGtCQUNWLE1BQUs7QUFBQSxrQkFDTCxPQUFPekIsU0FBU2dCLFVBQVVnRjtBQUFBQSxrQkFDMUIsVUFBVSxDQUFDdEUsVUFBVXVDLG1CQUFtQixVQUFVdkMsS0FBSztBQUFBLGtCQUN2RCxTQUFTRTtBQUFBQTtBQUFBQSxnQkFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNMkI7QUFBQSxpQkFWL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBRUEsdUJBQUMsU0FDRztBQUFBLHFDQUFDLFdBQU0sV0FBVSw4RUFBNkUsK0JBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLE9BQU81QixTQUFTSSxpQkFBaUIsUUFBUTtBQUFBLGtCQUN6QyxVQUFVLENBQUNzQixVQUFVdUMsbUJBQW1CLGtCQUFrQnZDLFVBQVUsS0FBSztBQUFBLGtCQUN6RSxTQUFTO0FBQUEsb0JBQ0wsRUFBRUEsT0FBTyxPQUFPQyxPQUFPLE1BQU07QUFBQSxvQkFDN0IsRUFBRUQsT0FBTyxNQUFNQyxPQUFPLEtBQUs7QUFBQSxrQkFBQztBQUFBO0FBQUEsZ0JBUnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVNNO0FBQUEsaUJBYlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEscUNBQUMsV0FBTSxXQUFVLDhFQUE2RSw0QkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csV0FBVTtBQUFBLGtCQUNWLE1BQUs7QUFBQSxrQkFDTCxRQUFPO0FBQUEsa0JBQ1AsT0FBTzNCLFNBQVNpQixlQUFleEMsTUFBTXVCLFNBQVNpQixZQUFZLElBQUk7QUFBQSxrQkFDOUQsVUFBVWlEO0FBQUFBLGtCQUNWLGFBQVk7QUFBQTtBQUFBLGdCQU5oQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNcUM7QUFBQSxpQkFWekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLGVBdkVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0VBO0FBQUEsYUE3RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThFQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNYO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDJGQUNWO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDJDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLFlBQU87QUFBQSxlQURuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsbURBQ1g7QUFBQSxtQ0FBQyxTQUNHO0FBQUEscUNBQUMsV0FBTSxXQUFVLDhFQUE2RSw0QkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csYUFBWTtBQUFBLGtCQUNaLE1BQUs7QUFBQSxrQkFDTCxPQUFPbEUsU0FBU0s7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQ29FLE1BQU1YLGtCQUFrQixnQkFBZ0JXLEVBQUVzQixPQUFPckUsS0FBSztBQUFBO0FBQUEsZ0JBSnJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1RTtBQUFBLGlCQVIzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFFQSx1QkFBQyxTQUNHO0FBQUEscUNBQUMsV0FBTSxXQUFVLDhFQUE2RSw2QkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csYUFBWTtBQUFBLGtCQUNaLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBTzFCLFNBQVNNO0FBQUFBLGtCQUNoQixVQUFVLENBQUNtRSxNQUFNWCxrQkFBa0IsU0FBU1csRUFBRXNCLE9BQU9yRSxLQUFLO0FBQUE7QUFBQSxnQkFMOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS2dFO0FBQUEsaUJBVHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLGFBOUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSw2REFDWDtBQUFBLGlDQUFDLFFBQUcsV0FBVSwyRkFDVjtBQUFBLG1DQUFDLFVBQUssV0FBVSwwQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxZQUFPO0FBQUEsZUFEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUEsbUNBQUMsU0FDRztBQUFBLHFDQUFDLFdBQU0sV0FBVSw4RUFBNkUscUNBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLGFBQVk7QUFBQSxrQkFDWixNQUFNO0FBQUEsa0JBQ04sT0FBTzFCLFNBQVNPO0FBQUFBLGtCQUNoQixVQUFVLENBQUNrRSxNQUFNWCxrQkFBa0Isa0JBQWtCVyxFQUFFc0IsT0FBT3JFLEtBQUs7QUFBQTtBQUFBLGdCQUp2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJeUU7QUFBQSxpQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsU0FDRztBQUFBLHFDQUFDLFdBQU0sV0FBVSw4RUFBNkUscUNBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLGFBQVk7QUFBQSxrQkFDWixNQUFNO0FBQUEsa0JBQ04sT0FBTzFCLFNBQVNRO0FBQUFBLGtCQUNoQixVQUFVLENBQUNpRSxNQUFNWCxrQkFBa0IsbUJBQW1CVyxFQUFFc0IsT0FBT3JFLEtBQUs7QUFBQTtBQUFBLGdCQUp4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJMEU7QUFBQSxpQkFSOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGtFQUNYO0FBQUEscUNBQUMsU0FDRztBQUFBLHVDQUFDLFdBQU0sV0FBVSw4RUFBNkUsb0JBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxhQUFZO0FBQUEsb0JBQ1osTUFBSztBQUFBLG9CQUNMLE9BQU8xQixTQUFTUztBQUFBQSxvQkFDaEIsVUFBVSxDQUFDZ0UsTUFBTVgsa0JBQWtCLFFBQVFXLEVBQUVzQixPQUFPckUsS0FBSztBQUFBO0FBQUEsa0JBSjdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJK0Q7QUFBQSxtQkFSbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBRUEsdUJBQUMsU0FDRztBQUFBLHVDQUFDLFdBQU0sV0FBVSw4RUFBNkUsd0JBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxhQUFZO0FBQUEsb0JBQ1osTUFBSztBQUFBLG9CQUNMLE9BQU8xQixTQUFTVTtBQUFBQSxvQkFDaEIsVUFBVSxDQUFDK0QsTUFBTVgsa0JBQWtCLFlBQVlXLEVBQUVzQixPQUFPckUsS0FBSztBQUFBO0FBQUEsa0JBSmpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJbUU7QUFBQSxtQkFSdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBRUEsdUJBQUMsU0FDRztBQUFBLHVDQUFDLFdBQU0sV0FBVSw4RUFBNkUscUJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxhQUFZO0FBQUEsb0JBQ1osTUFBSztBQUFBLG9CQUNMLE9BQU8xQixTQUFTVztBQUFBQSxvQkFDaEIsVUFBVSxDQUFDOEQsTUFBTVgsa0JBQWtCLFNBQVNXLEVBQUVzQixPQUFPckUsS0FBSztBQUFBO0FBQUEsa0JBSjlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJZ0U7QUFBQSxtQkFScEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBRUEsdUJBQUMsU0FDRztBQUFBLHVDQUFDLFdBQU0sV0FBVSw4RUFBNkUsdUJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxhQUFZO0FBQUEsb0JBQ1osTUFBSztBQUFBLG9CQUNMLE9BQU8xQixTQUFTWTtBQUFBQSxvQkFDaEIsVUFBVSxDQUFDNkQsTUFBTVgsa0JBQWtCLFdBQVdXLEVBQUVzQixPQUFPckUsS0FBSztBQUFBO0FBQUEsa0JBSmhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJa0U7QUFBQSxtQkFSdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBRUEsdUJBQUMsU0FDRztBQUFBLHVDQUFDLFdBQU0sV0FBVSw4RUFBNkUsdUJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxhQUFZO0FBQUEsb0JBQ1osTUFBSztBQUFBLG9CQUNMLE9BQU8xQixTQUFTYTtBQUFBQSxvQkFDaEIsVUFBVSxDQUFDNEQsTUFBTVgsa0JBQWtCLFdBQVdXLEVBQUVzQixPQUFPckUsS0FBSztBQUFBO0FBQUEsa0JBSmhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJa0U7QUFBQSxtQkFSdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGlCQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTREQTtBQUFBLGVBckZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0ZBO0FBQUEsYUEzRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRGQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNYO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDJGQUNWO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLFlBQU87QUFBQSxlQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsbURBQ1g7QUFBQSxtQ0FBQyxTQUNHO0FBQUEscUNBQUMsV0FBTSxXQUFVLDhFQUE2RSw0QkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csYUFBWTtBQUFBLGtCQUNaLE1BQUs7QUFBQSxrQkFDTCxPQUFPMUIsU0FBU2M7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQzJELE1BQU1YLGtCQUFrQixnQkFBZ0JXLEVBQUVzQixPQUFPckUsS0FBSztBQUFBO0FBQUEsZ0JBSnJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1RTtBQUFBLGlCQVIzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFFQSx1QkFBQyxTQUNHO0FBQUEscUNBQUMsV0FBTSxXQUFVLDhFQUE2RSw2QkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csYUFBWTtBQUFBLGtCQUNaLE1BQUs7QUFBQSxrQkFDTCxPQUFPMUIsU0FBU2U7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQzBELE1BQU1YLGtCQUFrQixpQkFBaUJXLEVBQUVzQixPQUFPckUsS0FBSztBQUFBO0FBQUEsZ0JBSnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl3RTtBQUFBLGlCQVI1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUF2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxhQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ1g7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMkZBQ1Y7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsd0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFBTztBQUFBLGVBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxtREFDWDtBQUFBLG1DQUFDLFNBQ0c7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsOEVBQTZFLDBCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxhQUFZO0FBQUEsa0JBQ1osTUFBSztBQUFBLGtCQUNMLE9BQU8xQixTQUFTa0I7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQ3VELE1BQU1YLGtCQUFrQixjQUFjVyxFQUFFc0IsT0FBT3JFLEtBQUs7QUFBQTtBQUFBLGdCQUpuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJcUU7QUFBQSxpQkFSekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsU0FDRztBQUFBLHFDQUFDLFdBQU0sV0FBVSw4RUFBNkUsMEJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLGFBQVk7QUFBQSxrQkFDWixNQUFLO0FBQUEsa0JBQ0wsT0FBTzFCLFNBQVNtQjtBQUFBQSxrQkFDaEIsVUFBVSxDQUFDc0QsTUFBTVgsa0JBQWtCLGNBQWNXLEVBQUVzQixPQUFPckUsS0FBSztBQUFBO0FBQUEsZ0JBSm5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlxRTtBQUFBLGlCQVJ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUF2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxhQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsOEJBQ1g7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUVUOUIsMEJBQWdCLGtCQUFrQjtBQUFBO0FBQUEsVUFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0EsS0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQTlSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK1JBO0FBQUEsU0ExU0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJTQSxLQTVTSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNlNBO0FBQUEsT0FqY0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtjQTtBQUVSO0FBQUVULEdBbHpCSUQsVUFBUTtBQUFBK0csS0FBUi9HO0FBb3pCTixlQUFlQTtBQUFTLElBQUErRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJTaWRlYmFyIiwiTmF2YmFyIiwiTW9kYWwiLCJEYXRhVGFibGUiLCJhcGkiLCJDaXJjdWxhckxvYWRlciIsIkRyb3Bkb3duIiwiU2VsZWN0IiwiSW5wdXQiLCJEYXRlUGlja2VyIiwiSW9NZE1vcmUiLCJDdXN0b21BbGVydERpYWxvZyIsImFudE1vZGFsIiwiZGF5anMiLCJGYUJ1aWxkaW5nIiwiTWRDYWxlbmRhclRvZGF5IiwiTWRFbWFpbCIsIk1kTG9jYXRpb25PbiIsIk1kUGVyc29uMiIsIk1kUGhvbmUiLCJjb25maXJtIiwiVGV4dEFyZWEiLCJCcmFuY2hlcyIsIl9zIiwiYnJhbmNoZXMiLCJzZXRCcmFuY2hlcyIsInRhYmxlQnJhbmNoZXMiLCJzZXRUYWJsZUJyYW5jaGVzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJtb2RhbFZpc2libGUiLCJzZXRNb2RhbFZpc2libGUiLCJjdXJyZW50QnJhbmNoIiwic2V0Q3VycmVudEJyYW5jaCIsInJlbG9hZFRyaWdnZXIiLCJzZXRSZWxvYWRUcmlnZ2VyIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImJyYW5jaF9uYW1lIiwiYnJhbmNoX3R5cGUiLCJpc19oZWFkX29mZmljZSIsInBob25lX251bWJlciIsImVtYWlsIiwic3RyZWV0X2FkZHJlc3MiLCJzdHJlZXRfYWRkcmVzczIiLCJjaXR5IiwiZGlzdHJpY3QiLCJzdGF0ZSIsImNvdW50cnkiLCJwaW5jb2RlIiwibWFuYWdlcl9uYW1lIiwibWFuYWdlcl9waG9uZSIsInN0YXR1cyIsIm9wZW5pbmdfZGF0ZSIsImdzdF9udW1iZXIiLCJwYW5fbnVtYmVyIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImJyYW5jaFR5cGVPcHRpb25zIiwidmFsdWUiLCJsYWJlbCIsInN0YXR1c09wdGlvbnMiLCJmZXRjaEJyYW5jaGVzIiwicmVzcG9uc2UiLCJnZXQiLCJicmFuY2hlc0RhdGEiLCJBcnJheSIsImlzQXJyYXkiLCJkYXRhIiwiZm9ybWF0dGVkIiwibWFwIiwiYnJhbmNoIiwiaW5kZXgiLCJfaWQiLCJpZCIsImJyYW5jaENvZGUiLCJicmFuY2hfY29kZSIsImJyYW5jaE5hbWUiLCJicmFuY2hUeXBlIiwicmVwbGFjZSIsInBob25lTnVtYmVyIiwiYWRkcmVzcyIsIm1hbmFnZXJOYW1lIiwib3BlbmluZ0RhdGUiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiYWN0aW9uIiwiaXRlbXMiLCJrZXkiLCJvcGVuRWRpdCIsImhhbmRsZURlbGV0ZSIsInJhdyIsImVycm9yIiwiY29uc29sZSIsInVzZUVmZmVjdCIsImhhbmRsZUlucHV0Q2hhbmdlIiwibmFtZSIsInByZXYiLCJoYW5kbGVTZWxlY3RDaGFuZ2UiLCJoYW5kbGVEYXRlQ2hhbmdlIiwiZGF0ZSIsImRhdGVTdHJpbmciLCJ0b0lTT1N0cmluZyIsInJlc2V0Rm9ybSIsImFkZHJlc3NEYXRhIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwicGF5bG9hZCIsInB1dCIsInBvc3QiLCJ0aXRsZSIsImNvbnRlbnQiLCJva1RleHQiLCJjYW5jZWxUZXh0IiwiY2VudGVyZWQiLCJva1R5cGUiLCJvbk9rIiwiZGVsZXRlIiwiY29sdW1ucyIsImhlYWRlciIsImdldFN0YXR1c0JhZGdlIiwidG9Mb3dlckNhc2UiLCJnZXRCcmFuY2hUeXBlQ29sb3IiLCJsZW5ndGgiLCJmaWx0ZXIiLCJCb29sZWFuIiwiam9pbiIsInRhcmdldCIsInVuZGVmaW5lZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJyYW5jaGVzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IERyb3Bkb3duLCBTZWxlY3QsIElucHV0LCBEYXRlUGlja2VyIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgeyBNb2RhbCBhcyBhbnRNb2RhbCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IHsgRmFCdWlsZGluZyB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBNZENhbGVuZGFyVG9kYXksIE1kRW1haWwsIE1kTG9jYXRpb25PbiwgTWRQZXJzb24yLCBNZFBob25lIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcblxyXG5jb25zdCB7IGNvbmZpcm0gfSA9IGFudE1vZGFsO1xyXG5jb25zdCB7IFRleHRBcmVhIH0gPSBJbnB1dDtcclxuXHJcbmNvbnN0IEJyYW5jaGVzID0gKCkgPT4ge1xyXG4gICAgLy8gLS0tLS0tLS0tLSBEYXRhIHN0YXRlcyAtLS0tLS0tLS0tXHJcbiAgICBjb25zdCBbYnJhbmNoZXMsIHNldEJyYW5jaGVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFt0YWJsZUJyYW5jaGVzLCBzZXRUYWJsZUJyYW5jaGVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFttb2RhbFZpc2libGUsIHNldE1vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbY3VycmVudEJyYW5jaCwgc2V0Q3VycmVudEJyYW5jaF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICAgIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICAgIC8vIC0tLS0tLS0tLS0gRm9ybSBzdGF0ZSAtLS0tLS0tLS0tXHJcbiAgICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICBicmFuY2hfbmFtZTogXCJcIixcclxuICAgICAgICAvLyBicmFuY2hfY29kZTogXCJcIixcclxuICAgICAgICBicmFuY2hfdHlwZTogXCJcIixcclxuICAgICAgICBpc19oZWFkX29mZmljZTogZmFsc2UsXHJcbiAgICAgICAgcGhvbmVfbnVtYmVyOiBcIlwiLFxyXG4gICAgICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgICAgIHN0cmVldF9hZGRyZXNzOiBcIlwiLFxyXG4gICAgICAgIHN0cmVldF9hZGRyZXNzMjogXCJcIixcclxuICAgICAgICBjaXR5OiBcIlwiLFxyXG4gICAgICAgIGRpc3RyaWN0OiBcIlwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiXCIsXHJcbiAgICAgICAgcGluY29kZTogXCJcIixcclxuICAgICAgICBtYW5hZ2VyX25hbWU6IFwiXCIsXHJcbiAgICAgICAgbWFuYWdlcl9waG9uZTogXCJcIixcclxuICAgICAgICBzdGF0dXM6IFwiYWN0aXZlXCIsXHJcbiAgICAgICAgb3BlbmluZ19kYXRlOiBudWxsLFxyXG4gICAgICAgIGdzdF9udW1iZXI6IFwiXCIsXHJcbiAgICAgICAgcGFuX251bWJlcjogXCJcIixcclxuICAgICAgICAvLyBwZXJtaXNzaW9uczogW10sXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBBbGVydCBzdGF0ZVxyXG4gICAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICAgICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgICAgICB0eXBlOiBcImluZm9cIixcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIC0tLS0tLS0tLS0gQnJhbmNoIHR5cGUgb3B0aW9ucyAtLS0tLS0tLS0tXHJcbiAgICBjb25zdCBicmFuY2hUeXBlT3B0aW9ucyA9IFtcclxuICAgICAgICB7IHZhbHVlOiBcIkhFQURfT0ZGSUNFXCIsIGxhYmVsOiBcIkhlYWQgT2ZmaWNlXCIgfSxcclxuICAgICAgICB7IHZhbHVlOiBcIkJSQU5DSFwiLCBsYWJlbDogXCJCcmFuY2hcIiB9LFxyXG4gICAgICAgIHsgdmFsdWU6IFwiUkVHSU9OQUxfT0ZGSUNFXCIsIGxhYmVsOiBcIlJlZ2lvbmFsIE9mZmljZVwiIH0sXHJcbiAgICAgICAgeyB2YWx1ZTogXCJDT1JQT1JBVEVfT0ZGSUNFXCIsIGxhYmVsOiBcIkNvcnBvcmF0ZSBPZmZpY2VcIiB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBjb25zdCBzdGF0dXNPcHRpb25zID0gW1xyXG4gICAgICAgIHsgdmFsdWU6IFwiYWN0aXZlXCIsIGxhYmVsOiBcIkFjdGl2ZVwiIH0sXHJcbiAgICAgICAgeyB2YWx1ZTogXCJpbmFjdGl2ZVwiLCBsYWJlbDogXCJJbmFjdGl2ZVwiIH0sXHJcbiAgICAgICAgeyB2YWx1ZTogXCJzdXNwZW5kZWRcIiwgbGFiZWw6IFwiU3VzcGVuZGVkXCIgfSxcclxuICAgIF07XHJcblxyXG4gICAgLy8gLS0tLS0tLS0tLSBGZXRjaCBicmFuY2hlcyAtLS0tLS0tLS0tXHJcbiAgICBjb25zdCBmZXRjaEJyYW5jaGVzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi9icmFuY2hlc1wiKTsgLy8gQWRqdXN0IEFQSSBlbmRwb2ludCBhcyBuZWVkZWRcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGJyYW5jaGVzRGF0YSA9IEFycmF5LmlzQXJyYXkocmVzcG9uc2UuZGF0YSlcclxuICAgICAgICAgICAgICAgID8gcmVzcG9uc2UuZGF0YVxyXG4gICAgICAgICAgICAgICAgOiByZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgICAgICAgLy8gRm9ybWF0IGJyYW5jaGVzIGZvciB0YWJsZSBkaXNwbGF5XHJcbiAgICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGJyYW5jaGVzRGF0YS5tYXAoKGJyYW5jaCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IGJyYW5jaC5faWQsXHJcbiAgICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgICAgYnJhbmNoQ29kZTogYnJhbmNoLmJyYW5jaF9jb2RlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICBicmFuY2hOYW1lOiBicmFuY2guYnJhbmNoX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgIGJyYW5jaFR5cGU6IGJyYW5jaC5icmFuY2hfdHlwZVxyXG4gICAgICAgICAgICAgICAgICAgID8gYnJhbmNoLmJyYW5jaF90eXBlLnJlcGxhY2UoL18vZywgXCIgXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgcGhvbmVOdW1iZXI6IGJyYW5jaC5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgIGVtYWlsOiBicmFuY2guZW1haWwgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgIGFkZHJlc3M6IGJyYW5jaC5hZGRyZXNzLnN0cmVldF9hZGRyZXNzIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICBjaXR5OiBicmFuY2guYWRkcmVzcz8uY2l0eSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgc3RhdGU6IGJyYW5jaC5hZGRyZXNzPy5zdGF0ZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgbWFuYWdlck5hbWU6IGJyYW5jaC5tYW5hZ2VyX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgIHN0YXR1czogYnJhbmNoLnN0YXR1cyB8fCBcIkluYWN0aXZlXCIsXHJcbiAgICAgICAgICAgICAgICBvcGVuaW5nRGF0ZTogYnJhbmNoLm9wZW5pbmdfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUoYnJhbmNoLm9wZW5pbmdfZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIilcclxuICAgICAgICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5FZGl0KGJyYW5jaCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGUoYnJhbmNoLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgLy8gS2VlcCByYXcgZGF0YSBmb3IgZnV0dXJlIHVzZVxyXG4gICAgICAgICAgICAgICAgcmF3OiBicmFuY2gsXHJcbiAgICAgICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgICAgIHNldFRhYmxlQnJhbmNoZXMoZm9ybWF0dGVkKTtcclxuICAgICAgICAgICAgc2V0QnJhbmNoZXMoYnJhbmNoZXNEYXRhKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYnJhbmNoZXM6XCIsIGVycm9yKTtcclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgYnJhbmNoZXNcIixcclxuICAgICAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGZldGNoQnJhbmNoZXMoKTtcclxuICAgIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gICAgLy8gLS0tLS0tLS0tLSBGb3JtIGhhbmRsZXJzIC0tLS0tLS0tLS1cclxuICAgIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKG5hbWUsIHZhbHVlKSA9PiB7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVTZWxlY3RDaGFuZ2UgPSAobmFtZSwgdmFsdWUpID0+IHtcclxuICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgICAgICB9KSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZURhdGVDaGFuZ2UgPSAoZGF0ZSwgZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICBvcGVuaW5nX2RhdGU6IGRhdGUgPyBkYXRlLnRvSVNPU3RyaW5nKCkgOiBudWxsLFxyXG4gICAgICAgIH0pKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVzZXRGb3JtID0gKCkgPT4ge1xyXG4gICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgYnJhbmNoX25hbWU6IFwiXCIsXHJcbiAgICAgICAgICAgIC8vIGJyYW5jaF9jb2RlOiBcIlwiLFxyXG4gICAgICAgICAgICBicmFuY2hfdHlwZTogXCJcIixcclxuICAgICAgICAgICAgaXNfaGVhZF9vZmZpY2U6IGZhbHNlLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICAgICAgICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgICAgICAgICBzdHJlZXRfYWRkcmVzczogXCJcIixcclxuICAgICAgICAgICAgc3RyZWV0X2FkZHJlc3MyOiBcIlwiLFxyXG4gICAgICAgICAgICBjaXR5OiBcIlwiLFxyXG4gICAgICAgICAgICBkaXN0cmljdDogXCJcIixcclxuICAgICAgICAgICAgc3RhdGU6IFwiXCIsXHJcbiAgICAgICAgICAgIGNvdW50cnk6IFwiXCIsXHJcbiAgICAgICAgICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICAgICAgICAgIG1hbmFnZXJfbmFtZTogXCJcIixcclxuICAgICAgICAgICAgbWFuYWdlcl9waG9uZTogXCJcIixcclxuICAgICAgICAgICAgc3RhdHVzOiBcImFjdGl2ZVwiLFxyXG4gICAgICAgICAgICBvcGVuaW5nX2RhdGU6IG51bGwsXHJcbiAgICAgICAgICAgIGdzdF9udW1iZXI6IFwiXCIsXHJcbiAgICAgICAgICAgIHBhbl9udW1iZXI6IFwiXCIsXHJcbiAgICAgICAgICAgIC8vIHBlcm1pc3Npb25zOiBbXSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRDdXJyZW50QnJhbmNoKG51bGwpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBvcGVuRWRpdCA9IChicmFuY2gpID0+IHtcclxuICAgICAgICBpZiAoYnJhbmNoKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGFkZHJlc3NEYXRhID0gYnJhbmNoLmFkZHJlc3MgfHwge307XHJcblxyXG4gICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICBicmFuY2hfbmFtZTogYnJhbmNoLmJyYW5jaF9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAvLyBicmFuY2hfY29kZTogYnJhbmNoLmJyYW5jaF9jb2RlIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBicmFuY2hfdHlwZTogYnJhbmNoLmJyYW5jaF90eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBpc19oZWFkX29mZmljZTogYnJhbmNoLmlzX2hlYWRfb2ZmaWNlIHx8IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBicmFuY2gucGhvbmVfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBlbWFpbDogYnJhbmNoLmVtYWlsIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBzdHJlZXRfYWRkcmVzczogYWRkcmVzc0RhdGEuc3RyZWV0X2FkZHJlc3MgfHwgXCJcIixcclxuICAgICAgICAgICAgICAgIHN0cmVldF9hZGRyZXNzMjogYWRkcmVzc0RhdGEuc3RyZWV0X2FkZHJlc3MyIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBjaXR5OiBhZGRyZXNzRGF0YS5jaXR5IHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBkaXN0cmljdDogYWRkcmVzc0RhdGEuZGlzdHJpY3QgfHwgXCJcIixcclxuICAgICAgICAgICAgICAgIHN0YXRlOiBhZGRyZXNzRGF0YS5zdGF0ZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgY291bnRyeTogYWRkcmVzc0RhdGEuY291bnRyeSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgcGluY29kZTogYWRkcmVzc0RhdGEucGluY29kZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgbWFuYWdlcl9uYW1lOiBicmFuY2gubWFuYWdlcl9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBtYW5hZ2VyX3Bob25lOiBicmFuY2gubWFuYWdlcl9waG9uZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgc3RhdHVzOiBicmFuY2guc3RhdHVzIHx8IFwiYWN0aXZlXCIsXHJcbiAgICAgICAgICAgICAgICBvcGVuaW5nX2RhdGU6IGJyYW5jaC5vcGVuaW5nX2RhdGUgfHwgbnVsbCxcclxuICAgICAgICAgICAgICAgIGdzdF9udW1iZXI6IGJyYW5jaC5nc3RfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBwYW5fbnVtYmVyOiBicmFuY2gucGFuX251bWJlciB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgLy8gcGVybWlzc2lvbnM6IGJyYW5jaC5wZXJtaXNzaW9ucyB8fCBbXSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRCcmFuY2goYnJhbmNoLl9pZCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gQ3JlYXRlIG1vZGVcclxuICAgICAgICAgICAgcmVzZXRGb3JtKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldE1vZGFsVmlzaWJsZSh0cnVlKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgICAgIC8vIFZhbGlkYXRpb25cclxuICAgICAgICBpZiAoIWZvcm1EYXRhLmJyYW5jaF9uYW1lIHx8ICFmb3JtRGF0YS5icmFuY2hfdHlwZSkge1xyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJCcmFuY2ggTmFtZSwgQ29kZSwgYW5kIFR5cGUgYXJlIHJlcXVpcmVkXCIsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgICAgICAgLy8gUHJlcGFyZSBwYXlsb2FkIC0gYWRkcmVzcyBmaWVsZHMgbmVzdGVkIHVuZGVyIGFkZHJlc3Mgb2JqZWN0XHJcbiAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAgICAgICBicmFuY2hfbmFtZTogZm9ybURhdGEuYnJhbmNoX25hbWUsXHJcbiAgICAgICAgICAgICAgICAvLyBicmFuY2hfY29kZTogZm9ybURhdGEuYnJhbmNoX2NvZGUsXHJcbiAgICAgICAgICAgICAgICBicmFuY2hfdHlwZTogZm9ybURhdGEuYnJhbmNoX3R5cGUsXHJcbiAgICAgICAgICAgICAgICBpc19oZWFkX29mZmljZTogZm9ybURhdGEuaXNfaGVhZF9vZmZpY2UsXHJcbiAgICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGZvcm1EYXRhLnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAgIGVtYWlsOiBmb3JtRGF0YS5lbWFpbCxcclxuICAgICAgICAgICAgICAgIG1hbmFnZXJfbmFtZTogZm9ybURhdGEubWFuYWdlcl9uYW1lLFxyXG4gICAgICAgICAgICAgICAgbWFuYWdlcl9waG9uZTogZm9ybURhdGEubWFuYWdlcl9waG9uZSxcclxuICAgICAgICAgICAgICAgIHN0YXR1czogZm9ybURhdGEuc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgb3BlbmluZ19kYXRlOiBmb3JtRGF0YS5vcGVuaW5nX2RhdGUgfHwgbnVsbCxcclxuICAgICAgICAgICAgICAgIGdzdF9udW1iZXI6IGZvcm1EYXRhLmdzdF9udW1iZXIsXHJcbiAgICAgICAgICAgICAgICBwYW5fbnVtYmVyOiBmb3JtRGF0YS5wYW5fbnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgLy8gcGVybWlzc2lvbnM6IGZvcm1EYXRhLnBlcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgYWRkcmVzczoge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0cmVldF9hZGRyZXNzOiBmb3JtRGF0YS5zdHJlZXRfYWRkcmVzcyxcclxuICAgICAgICAgICAgICAgICAgICBzdHJlZXRfYWRkcmVzczI6IGZvcm1EYXRhLnN0cmVldF9hZGRyZXNzMixcclxuICAgICAgICAgICAgICAgICAgICBjaXR5OiBmb3JtRGF0YS5jaXR5LFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc3RyaWN0OiBmb3JtRGF0YS5kaXN0cmljdCxcclxuICAgICAgICAgICAgICAgICAgICBzdGF0ZTogZm9ybURhdGEuc3RhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgY291bnRyeTogZm9ybURhdGEuY291bnRyeSB8fCBcIkluZGlhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcGluY29kZTogZm9ybURhdGEucGluY29kZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgaWYgKGN1cnJlbnRCcmFuY2gpIHtcclxuICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSBleGlzdGluZyBicmFuY2hcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wdXQoYC92MS9hZG1pbi9icmFuY2hlcy8ke2N1cnJlbnRCcmFuY2h9YCwgcGF5bG9hZCk7XHJcbiAgICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIkJyYW5jaCB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyBDcmVhdGUgbmV3IGJyYW5jaFxyXG4gICAgICAgICAgICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvdjEvYWRtaW4vYnJhbmNoZXNcIiwgcGF5bG9hZCk7XHJcbiAgICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIkJyYW5jaCBjcmVhdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHNldE1vZGFsVmlzaWJsZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHJlc2V0Rm9ybSgpO1xyXG4gICAgICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHNhdmluZyBicmFuY2g6XCIsIGVycm9yKTtcclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHNhdmUgYnJhbmNoXCIsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gLS0tLS0tLS0tLSBEZWxldGUgYnJhbmNoIC0tLS0tLS0tLS1cclxuICAgIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgICAgIGNvbmZpcm0oe1xyXG4gICAgICAgICAgICB0aXRsZTogXCJEZWxldGUgQnJhbmNoXCIsXHJcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGJyYW5jaD8gVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS5cIixcclxuICAgICAgICAgICAgb2tUZXh0OiBcIlllcywgRGVsZXRlXCIsXHJcbiAgICAgICAgICAgIGNhbmNlbFRleHQ6IFwiQ2FuY2VsXCIsXHJcbiAgICAgICAgICAgIGNlbnRlcmVkOiB0cnVlLFxyXG4gICAgICAgICAgICBva1R5cGU6IFwiZGFuZ2VyXCIsXHJcbiAgICAgICAgICAgIG9uT2s6IGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL3YxL2FkbWluL2JyYW5jaGVzLyR7aWR9YCk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJCcmFuY2ggZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBicmFuY2g6XCIsIGVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGRlbGV0ZSBicmFuY2hcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyAtLS0tLS0tLS0tIFRhYmxlIGNvbHVtbnMgLS0tLS0tLS0tLVxyXG4gICAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgICAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wgTm9cIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImJyYW5jaENvZGVcIiwgaGVhZGVyOiBcIkJyYW5jaCBDb2RlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJicmFuY2hOYW1lXCIsIGhlYWRlcjogXCJCcmFuY2ggTmFtZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYnJhbmNoVHlwZVwiLCBoZWFkZXI6IFwiQnJhbmNoIFR5cGVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcIm1hbmFnZXJOYW1lXCIsIGhlYWRlcjogXCJNYW5hZ2VyXCIgfSxcclxuICAgICAgICB7IGtleTogXCJwaG9uZU51bWJlclwiLCBoZWFkZXI6IFwiUGhvbmVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImVtYWlsXCIsIGhlYWRlcjogXCJFbWFpbFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYWRkcmVzc1wiLCBoZWFkZXI6IFwiYWRkcmVzc1wiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiY2l0eVwiLCBoZWFkZXI6IFwiQ2l0eVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwic3RhdGVcIiwgaGVhZGVyOiBcIlN0YXRlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gICAgXTtcclxuICAgIC8vIC0tLS0tLS0tLS0gQmFkZ2UgaGVscGVycyAtLS0tLS0tLS0tXHJcbiAgICBjb25zdCBnZXRTdGF0dXNCYWRnZSA9IChzdGF0dXMpID0+IHtcclxuICAgICAgICBzd2l0Y2ggKHN0YXR1cz8udG9Mb3dlckNhc2UoKSkge1xyXG4gICAgICAgICAgICBjYXNlIFwiYWN0aXZlXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDAgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDBcIjtcclxuICAgICAgICAgICAgY2FzZSBcInN1c3BlbmRlZFwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAgYm9yZGVyIGJvcmRlci1yZWQtMjAwXCI7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNjAwIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIjtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGdldEJyYW5jaFR5cGVDb2xvciA9ICh0eXBlKSA9PiB7XHJcbiAgICAgICAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgXCJIRUFEX09GRklDRVwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiYmctaW5kaWdvLTEwMCB0ZXh0LWluZGlnby03MDBcIjtcclxuICAgICAgICAgICAgY2FzZSBcIlJFR0lPTkFMX09GRklDRVwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS03MDBcIjtcclxuICAgICAgICAgICAgY2FzZSBcIkNPUlBPUkFURV9PRkZJQ0VcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybiBcImJnLXRlYWwtMTAwIHRleHQtdGVhbC03MDBcIjtcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHJldHVybiBcImJnLWJsdWUtMTAwIHRleHQtYmx1ZS03MDBcIjtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5CcmFuY2hlcyBNYW5hZ2VtZW50PC9oMT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuRWRpdChudWxsKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICArIENyZWF0ZSBCcmFuY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge3RhYmxlQnJhbmNoZXMubGVuZ3RoID4gMCAmJiAhbG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIHhsOmdyaWQtY29scy00IGdhcC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YnJhbmNoZXMubWFwKChicmFuY2gpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17YnJhbmNoLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgb3ZlcmZsb3ctaGlkZGVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDYXJkIEhlYWRlciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtOTAwIHB4LTQgcHktMyBmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLXdoaXRlLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhQnVpbGRpbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JyYW5jaC5icmFuY2hfbmFtZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMS41IG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgdGV4dC1bMTBweF0gZm9udC1tZWRpdW0gcm91bmRlZC1mdWxsIGNhcGl0YWxpemUgJHtnZXRCcmFuY2hUeXBlQ29sb3IoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyYW5jaC5icmFuY2hfdHlwZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGJyYW5jaC5icmFuY2hfdHlwZSB8fCBcIk4vQVwiKS5yZXBsYWNlKC9fL2csIFwiIFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHticmFuY2guaXNfaGVhZF9vZmZpY2UgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTQwMCB0ZXh0LWFtYmVyLTk1MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDimIUgSGVhZCBPZmZpY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5FZGl0KGJyYW5jaCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKGJyYW5jaC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21SaWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHRleHQtd2hpdGUgdGV4dC0yeGwgaG92ZXI6Ymctd2hpdGUvMTAgcm91bmRlZCBweC0xXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENhcmQgQm9keSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgc3BhY2UteS0yLjUgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kUGVyc29uMiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGZsZXgtc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHticmFuY2gubWFuYWdlcl9uYW1lIHx8IFwiTm8gbWFuYWdlciBhc3NpZ25lZFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kUGhvbmUgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBmbGV4LXNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPnticmFuY2gucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWRFbWFpbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGZsZXgtc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+e2JyYW5jaC5lbWFpbCB8fCBcIk4vQVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kTG9jYXRpb25PbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGZsZXgtc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtbYnJhbmNoLmFkZHJlc3M/LmNpdHksIGJyYW5jaC5hZGRyZXNzPy5zdGF0ZV1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5qb2luKFwiLCBcIikgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQ2FyZCBGb290ZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLWZ1bGwgY2FwaXRhbGl6ZSAke2dldFN0YXR1c0JhZGdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJhbmNoLnN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YnJhbmNoLnN0YXR1cyB8fCBcIkluYWN0aXZlXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kQ2FsZW5kYXJUb2RheSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JyYW5jaC5vcGVuaW5nX2RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUoYnJhbmNoLm9wZW5pbmdfZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9eyFsb2FkaW5nICYmIGJyYW5jaGVzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9XCJCcmFuY2ggRGF0YVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNb2RhbCBmb3IgQ3JlYXRlL0VkaXQgKi99XHJcbiAgICAgICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e21vZGFsVmlzaWJsZX0gb25DbG9zZT17KCkgPT4gc2V0TW9kYWxWaXNpYmxlKGZhbHNlKX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBsZzpwLTggdy1mdWxsIG1heC1oLVs4NXZoXSBvdmVyZmxvdy15LWF1dG8gYmctc2xhdGUtNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIHRyYWNraW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEJyYW5jaCA/IFwiVXBkYXRlIEJyYW5jaFwiIDogXCJDcmVhdGUgTmV3IEJyYW5jaFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QnJhbmNoID8gXCJNb2RpZnkgdGhlIGRldGFpbHMgb2YgdGhlIGJyYW5jaCBiZWxvdy5cIiA6IFwiRmlsbCBpbiB0aGUgZGV0YWlscyB0byBzZXQgdXAgYSBuZXcgYnJhbmNoLlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEJhc2ljIEluZm9ybWF0aW9uIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC14bCBwLTUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgbWItNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC01IGJnLWJsdWUtNjAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYXNpYyBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAteC01IGdhcC15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJyYW5jaCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIERvd250b3duIEJyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmJyYW5jaF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcImJyYW5jaF9uYW1lXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQnJhbmNoIFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgYnJhbmNoIHR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYnJhbmNoX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlU2VsZWN0Q2hhbmdlKFwiYnJhbmNoX3R5cGVcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17YnJhbmNoVHlwZU9wdGlvbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IHN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5zdGF0dXMgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlU2VsZWN0Q2hhbmdlKFwic3RhdHVzXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e3N0YXR1c09wdGlvbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSXMgSGVhZCBPZmZpY2U/XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSXMgdGhpcyB0aGUgaGVhZCBvZmZpY2U/XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmlzX2hlYWRfb2ZmaWNlID8gXCJ5ZXNcIiA6IFwibm9cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZVNlbGVjdENoYW5nZShcImlzX2hlYWRfb2ZmaWNlXCIsIHZhbHVlID09PSBcInllc1wiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiBcInllc1wiLCBsYWJlbDogXCJZZXNcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6IFwibm9cIiwgbGFiZWw6IFwiTm9cIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3BlbmluZyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIkRELU1NLVlZWVlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm9wZW5pbmdfZGF0ZSA/IGRheWpzKGZvcm1EYXRhLm9wZW5pbmdfZGF0ZSkgOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZURhdGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvcGVuaW5nIGRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIENvbnRhY3QgSW5mb3JtYXRpb24gU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLXhsIHAtNSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBtYi01IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEuNSBoLTUgYmctZW1lcmFsZC01MDAgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbnRhY3QgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLXgtNSBnYXAteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHBob25lIG51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoXCJwaG9uZV9udW1iZXJcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVtYWlsIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGVtYWlsIGFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKFwiZW1haWxcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFkZHJlc3MgSW5mb3JtYXRpb24gU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLXhsIHAtNSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBtYi01IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEuNSBoLTUgYmctdmlvbGV0LTUwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzcyBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RyZWV0IEFkZHJlc3MgTGluZSAxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0QXJlYVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBzdHJlZXQgYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnN0cmVldF9hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcInN0cmVldF9hZGRyZXNzXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTdHJlZXQgQWRkcmVzcyBMaW5lIDJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRBcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHN0cmVldCBhZGRyZXNzIDIgKE9wdGlvbmFsKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnN0cmVldF9hZGRyZXNzMn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoXCJzdHJlZXRfYWRkcmVzczJcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLXgtNSBnYXAteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDaXR5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBjaXR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jaXR5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoXCJjaXR5XCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERpc3RyaWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBkaXN0cmljdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGlzdHJpY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcImRpc3RyaWN0XCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0YXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBzdGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc3RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcInN0YXRlXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvdW50cnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGNvdW50cnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvdW50cnl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcImNvdW50cnlcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGluY29kZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgcGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKFwicGluY29kZVwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBNYW5hZ2VyIEluZm9ybWF0aW9uIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC14bCBwLTUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgbWItNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC01IGJnLWFtYmVyLTUwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWFuYWdlciBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAteC01IGdhcC15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1hbmFnZXIgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgbWFuYWdlciBuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubWFuYWdlcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcIm1hbmFnZXJfbmFtZVwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWFuYWdlciBQaG9uZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgbWFuYWdlciBwaG9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm1hbmFnZXJfcGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKFwibWFuYWdlcl9waG9uZVwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogVGF4IEluZm9ybWF0aW9uIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC14bCBwLTUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgbWItNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC01IGJnLXJvc2UtNTAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYXggSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLXgtNSBnYXAteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHU1QgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHU1QgbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3N0X251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoXCJnc3RfbnVtYmVyXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQQU4gTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQQU4gbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGFuX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoXCJwYW5fbnVtYmVyXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdWJtaXQgQnV0dG9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtMiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgYWN0aXZlOnNjYWxlLTk1IHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCBweC0xMCBweS0zIHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTYwMC8yMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QnJhbmNoID8gXCJVcGRhdGUgQnJhbmNoXCIgOiBcIkNyZWF0ZSBCcmFuY2hcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8Lz5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCcmFuY2hlcztcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0JyYW5jaGVzLmpzeCJ9