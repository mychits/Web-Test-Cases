import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PenaltySettings.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import api from "/src/instance/TokenInstance.js";
import {
  Select,
  InputNumber,
  Drawer,
  Button,
  message,
  Card,
  Row,
  Col,
  Table,
  Modal,
  Form,
  Space,
  Typography,
  Statistic,
  Divider,
  Tabs,
  Tag,
  Empty,
  Collapse,
  Progress,
  Tooltip,
  Avatar,
  Input
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdSave } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import {
  CalculatorOutlined,
  TeamOutlined,
  EditOutlined,
  FileTextOutlined,
  CheckCircleOutlined,
  ThunderboltOutlined,
  SettingOutlined,
  ClockCircleOutlined,
  PercentageOutlined,
  DollarOutlined,
  CalendarOutlined,
  PlusOutlined,
  InfoCircleOutlined,
  DeleteOutlined,
  ExclamationCircleOutlined,
  DollarCircleOutlined,
  WarningOutlined,
  ScheduleOutlined,
  MoneyCollectOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
const { Title, Text, Paragraph } = Typography;
const { TabPane } = Tabs;
const { Panel } = Collapse;
const { Search } = Input;
const PenaltySettings = () => {
  _s();
  const navigate = useNavigate();
  const [groups, setGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [penaltyRate, setPenaltyRate] = useState(0);
  const [graceDays, setGraceDays] = useState(0);
  const [penaltyAmount, setPenaltyAmount] = useState(0);
  const [latePaymentAmount, setLatePaymentAmount] = useState(0);
  const [daysLateThreshold, setDaysLateThreshold] = useState(0);
  const [saving, setSaving] = useState(false);
  const [storedPenalties, setStoredPenalties] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editDrawerOpen, setEditDrawerOpen] = useState(false);
  const [editingPenalty, setEditingPenalty] = useState(null);
  const [editRow, setEditRow] = useState(null);
  const [modalForm] = Form.useForm();
  const [activeTab, setActiveTab] = useState("configure");
  const [additionalCharges, setAdditionalCharges] = useState([]);
  const [isAddChargeModalOpen, setIsAddChargeModalOpen] = useState(false);
  const [addChargeForm] = Form.useForm();
  const [searchText, setSearchText] = useState("");
  const isGroupSelected = !!selectedGroup;
  const [vacantChitPenaltyAmount, setVacantChitPenaltyAmount] = useState(0);
  const [vacantChitGraceDays, setVacantChitGraceDays] = useState(30);
  const [vacantChitPenaltyRate, setVacantChitPenaltyRate] = useState(0);
  const [latePaymentRate, setLatePaymentRate] = useState(0);
  const [penaltyPreview, setPenaltyPreview] = useState(null);
  const [showPenaltyPreview, setShowPenaltyPreview] = useState(false);
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    if (selectedGroup && penaltyRate >= 0) {
      const installment = getInstallmentAmount(selectedGroup);
      const penalty = parseFloat((installment * penaltyRate / 100).toFixed(2));
      setPenaltyAmount(penalty);
    } else {
      setPenaltyAmount(0);
    }
  }, [penaltyRate, selectedGroup]);
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(e.target.tagName)) return;
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "m") {
        e.preventDefault();
        navigate("/penalty-monitor");
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [navigate]);
  useEffect(() => {
    fetchGroups();
    fetchPenalties();
  }, []);
  const fetchGroups = async () => {
    try {
      const res = await api.get("/group/get-group");
      setGroups(res.data || []);
    } catch (err) {
      message.error("Failed to load groups");
    }
  };
  const fetchPenalties = async () => {
    try {
      setLoading(true);
      const res = await api.get("/penalty/penalty-settings");
      const penalties = (res.data || []).map((p) => {
        const group = groups.find((g) => g._id === p.group_id);
        return {
          ...p,
          group_name: group?.group_name || p.group_name || "N/A",
          installment_amount: group ? group.monthly_installment || group.group_installment || group.group_install || group.weekly_installment || group.daily_installment || 0 : p.installment_amount || 0
        };
      });
      setStoredPenalties(penalties);
    } catch (err) {
      message.error("Failed to load penalty settings");
    } finally {
      setLoading(false);
    }
  };
  const getInstallmentAmount = (group) => {
    if (!group) return 0;
    return group.monthly_installment || group.group_installment || group.group_install || group.weekly_installment || group.daily_installment || 0;
  };
  const handleGroupChange = (value) => {
    const group = groups.find((g) => g._id === value);
    setSelectedGroup(group);
    const existing = storedPenalties.find((p) => p.group_id === value);
    if (existing) {
      setPenaltyPreview({
        ...existing,
        monthly_installment: group?.monthly_installment || 0,
        weekly_installment: group?.weekly_installment || 0,
        daily_installment: group?.daily_installment || 0,
        groupData: group
      });
      setShowPenaltyPreview(true);
    }
    setPenaltyRate(0);
    setGraceDays(0);
    setPenaltyAmount(0);
    setLatePaymentAmount(0);
    setLatePaymentRate(0);
    setDaysLateThreshold(0);
    setAdditionalCharges([]);
  };
  const handleDrawerSave = async () => {
    if (!editingPenalty) return;
    try {
      await api.post(`/penalty/penalty-settings/${editingPenalty.group_id}`, {
        penalty_type: "percentage",
        penalty_rate: editingPenalty.penalty_rate,
        grace_days: editingPenalty.grace_days,
        penalty_amount: editingPenalty.penalty_amount,
        late_payment_amount: editingPenalty.late_payment_amount,
        late_payment_rate: editingPenalty.late_payment_rate,
        days_late_threshold: editingPenalty.days_late_threshold,
        installment_amount: editingPenalty.installment_amount,
        group_name: editingPenalty.group_name,
        vacant_chit_penalty_amount: editingPenalty.vacant_chit_penalty_amount,
        vacant_chit_grace_days: editingPenalty.vacant_chit_grace_days,
        vacant_chit_penalty_rate: editingPenalty.vacant_chit_penalty_rate
      });
      message.success("Penalty updated successfully");
      setEditDrawerOpen(false);
      fetchPenalties();
    } catch (err) {
      message.error("Failed to update penalty");
    }
  };
  const handleSave = async () => {
    if (!selectedGroup) return message.warning("Select a group");
    try {
      setSaving(true);
      const installmentAmount = getInstallmentAmount(selectedGroup);
      await api.post(`/penalty/penalty-settings/${selectedGroup._id}`, {
        penalty_type: "percentage",
        penalty_rate: penaltyRate,
        grace_days: graceDays,
        penalty_amount: penaltyAmount,
        late_payment_amount: latePaymentAmount,
        late_payment_rate: latePaymentRate,
        days_late_threshold: daysLateThreshold,
        installment_amount: installmentAmount,
        group_name: selectedGroup.group_name,
        additional_charges: additionalCharges,
        vacant_chit_penalty_amount: vacantChitPenaltyAmount,
        vacant_chit_grace_days: vacantChitGraceDays,
        vacant_chit_penalty_rate: vacantChitPenaltyRate
      });
      message.success("Penalty saved successfully");
      fetchPenalties();
      setSelectedGroup(null);
      setPenaltyRate(0);
      setGraceDays(0);
      setPenaltyAmount(0);
      setLatePaymentAmount(0);
      setDaysLateThreshold(0);
      setAdditionalCharges([]);
      setActiveTab("records");
    } catch (err) {
      console.error(err);
      message.error("Failed to save penalty");
    } finally {
      setSaving(false);
    }
  };
  const openEditDrawer = (row) => {
    const fullGroup = groups.find((g) => g._id === row.group_id);
    console.log(groups, row, row.group_id, "this is full group");
    setEditingPenalty({
      ...row,
      // always pull these LIVE from group collection
      installment_amount: Number(fullGroup?.monthly_installment) || Number(fullGroup?.weekly_installment) || Number(fullGroup?.daily_installment) || 0,
      monthly_installment: Number(fullGroup?.monthly_installment || 0),
      weekly_installment: Number(fullGroup?.weekly_installment || 0),
      daily_installment: Number(fullGroup?.daily_installment || 0),
      late_payment_amount: row.late_payment_amount || 0,
      days_late_threshold: row.days_late_threshold || 0,
      vacant_chit_penalty_amount: row.vacant_chit_penalty_amount || 0,
      vacant_chit_grace_days: row.vacant_chit_grace_days || 0,
      vacant_chit_penalty_rate: row.vacant_chit_penalty_rate || 0
    });
    setEditDrawerOpen(true);
  };
  const handleModalCalculate = () => {
    const values = modalForm.getFieldsValue();
    const penalty = parseFloat((values.installment_amount * values.penalty_rate / 100).toFixed(2));
    modalForm.setFieldsValue({ penalty_amount: penalty });
  };
  const handleAddCharge = () => {
    addChargeForm.validateFields().then((values) => {
      const newCharge = {
        id: Date.now(),
        name: values.charge_name,
        type: values.charge_type,
        amount: values.charge_amount,
        rate: values.charge_rate,
        description: values.charge_description
      };
      setAdditionalCharges([...additionalCharges, newCharge]);
      addChargeForm.resetFields();
      setIsAddChargeModalOpen(false);
      message.success("Additional charge added successfully");
    });
  };
  const removeAdditionalCharge = (id) => {
    setAdditionalCharges(additionalCharges.filter((charge) => charge.id !== id));
    message.success("Charge removed successfully");
  };
  const filteredPenalties = storedPenalties.filter(
    (penalty) => penalty.group_name.toLowerCase().includes(searchText.toLowerCase())
  );
  const columns = [
    {
      title: "No.",
      render: (_, __, i) => /* @__PURE__ */ jsxDEV("div", { style: {
        width: "36px",
        height: "36px",
        borderRadius: "8px",
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#ffffff",
        fontWeight: "600",
        fontSize: "14px"
      }, children: String(i + 1).padStart(2, "0") }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
        lineNumber: 342,
        columnNumber: 5
      }, this),
      width: 80,
      align: "center"
    },
    {
      title: "Group Name",
      dataIndex: "group_name",
      render: (text) => /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center" }, children: [
        /* @__PURE__ */ jsxDEV(Avatar, { style: {
          backgroundColor: "#1890ff",
          marginRight: "12px",
          fontWeight: "bold"
        }, children: text.charAt(0).toUpperCase() }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
          lineNumber: 365,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { fontSize: "14px", color: "#1e293b" }, children: text }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
          lineNumber: 372,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
        lineNumber: 364,
        columnNumber: 5
      }, this)
    },
    // {
    //   title: "Installment Amount",
    //   dataIndex: "installment_amount",
    //   align: 'right',
    //   render: (v) => (
    //     <div style={{
    //       background: '#f0f9ff',
    //       padding: '4px 8px',
    //       borderRadius: '6px',
    //       display: 'inline-block'
    //     }}>
    //       <Text style={{ fontWeight: '600', fontSize: '14px', color: '#0369a1' }}>
    //         ₹{Number(v || 0).toLocaleString("en-IN")}
    //       </Text>
    //     </div>
    //   ),
    // },
    {
      title: "Penalty Rate",
      dataIndex: "penalty_rate",
      align: "center",
      render: (v) => /* @__PURE__ */ jsxDEV(
        Progress,
        {
          percent: v,
          size: "small",
          strokeColor: {
            "0%": "#108ee9",
            "100%": "#87d068"
          },
          format: () => `${v}%`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
          lineNumber: 398,
          columnNumber: 5
        },
        this
      )
    },
    {
      title: "Penalty Amount",
      dataIndex: "penalty_amount",
      align: "right",
      render: (v) => /* @__PURE__ */ jsxDEV("div", { style: {
        background: "#fff1f0",
        padding: "4px 8px",
        borderRadius: "6px",
        display: "inline-block"
      }, children: /* @__PURE__ */ jsxDEV(Text, { style: { color: "#cf1322", fontWeight: "700", fontSize: "14px" }, children: [
        "₹",
        Number(v || 0).toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
        lineNumber: 420,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
        lineNumber: 414,
        columnNumber: 5
      }, this)
    },
    {
      title: "Late Fee",
      dataIndex: "late_payment_amount",
      align: "right",
      render: (v) => /* @__PURE__ */ jsxDEV("div", { style: {
        background: "#fff7e6",
        padding: "4px 8px",
        borderRadius: "6px",
        display: "inline-block"
      }, children: /* @__PURE__ */ jsxDEV(Text, { style: { color: "#d46b08", fontWeight: "700", fontSize: "14px" }, children: [
        "₹",
        Number(v || 0).toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
        lineNumber: 437,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
        lineNumber: 431,
        columnNumber: 5
      }, this)
    },
    {
      title: "Grace days (Late Fee)",
      dataIndex: "days_late_threshold",
      align: "center",
      render: (v) => /* @__PURE__ */ jsxDEV(Tag, { color: "violet", style: { fontWeight: "600", fontSize: "13px" }, children: [
        v,
        " days"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
        lineNumber: 448,
        columnNumber: 5
      }, this)
    },
    // {
    //   title: "Grace Days",
    //   dataIndex: "grace_days",
    //   align: 'center',
    //   render: (v) => (
    //     <Tag color="green" style={{ fontWeight: '600', fontSize: '13px' }}>
    //       {v} days
    //     </Tag>
    //   ),
    // },
    {
      title: "Actions",
      align: "center",
      width: 100,
      fixed: "right",
      render: (_, row) => /* @__PURE__ */ jsxDEV(
        Button,
        {
          type: "primary",
          icon: /* @__PURE__ */ jsxDEV(EditOutlined, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
            lineNumber: 471,
            columnNumber: 13
          }, this),
          onClick: () => openEditDrawer(row),
          style: {
            borderRadius: "6px",
            fontWeight: "500",
            height: "32px",
            background: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
            border: "none"
          },
          children: "Edit"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
          lineNumber: 469,
          columnNumber: 5
        },
        this
      )
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", style: { backgroundColor: "#f0f2f5", minHeight: "100vh" }, children: [
    /* @__PURE__ */ jsxDEV(SettingSidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
      lineNumber: 489,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
          lineNumber: 491,
          columnNumber: 8
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px 32px", marginTop: "10px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: {
          marginBottom: "24px",
          background: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
          borderRadius: "16px",
          padding: "32px",
          boxShadow: "0 10px 20px rgba(0, 0, 0, 0.1)",
          position: "relative",
          overflow: "hidden"
        }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { position: "absolute", top: 0, right: 0, height: "100%", width: "40%", background: "rgba(255, 255, 255, 0.1)", transform: "skewX(-15deg)" } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
            lineNumber: 508,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { position: "relative", zIndex: 1 }, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", marginBottom: "16px" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: {
              width: "64px",
              height: "64px",
              borderRadius: "16px",
              background: "rgba(255, 255, 255, 0.2)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              marginRight: "20px",
              backdropFilter: "blur(4px)"
            }, children: /* @__PURE__ */ jsxDEV(SettingOutlined, { style: { fontSize: "32px", color: "#ffffff" } }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 522,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 511,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(Title, { level: 1, style: { margin: 0, fontWeight: "700", color: "#ffffff", fontSize: "28px" }, children: "Penalty Settings" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 525,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 524,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
            lineNumber: 510,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
            lineNumber: 509,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
          lineNumber: 499,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            type: "dashed",
            onClick: () => navigate("/penalty-monitor"),
            style: { marginBottom: 16 },
            children: "Go to Penalty Monitor"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
            lineNumber: 535,
            columnNumber: 4
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Card,
          {
            style: {
              borderRadius: "16px",
              border: "none",
              boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
              marginBottom: "24px",
              overflow: "hidden"
            },
            bodyStyle: { padding: 0 },
            children: /* @__PURE__ */ jsxDEV(
              Tabs,
              {
                activeKey: activeTab,
                onChange: setActiveTab,
                style: { marginBottom: 0 },
                tabBarStyle: {
                  margin: 0,
                  padding: "0 24px",
                  background: "#ffffff",
                  borderBottom: "1px solid #f0f0f0"
                },
                children: [
                  /* @__PURE__ */ jsxDEV(
                    TabPane,
                    {
                      tab: /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", alignItems: "center" }, children: [
                        /* @__PURE__ */ jsxDEV(SettingOutlined, { style: { marginRight: "8px" } }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 567,
                          columnNumber: 21
                        }, this),
                        "Add Penalty"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 566,
                        columnNumber: 17
                      }, this),
                      children: /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px", background: "#fafafa" }, children: [
                        /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], style: { marginBottom: "24px" }, children: [
                          /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 8, children: /* @__PURE__ */ jsxDEV(Card, { style: {
                            borderRadius: "12px",
                            border: "none",
                            background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                            height: "100%",
                            boxShadow: "0 4px 12px rgba(102, 126, 234, 0.3)",
                            overflow: "hidden",
                            position: "relative"
                          }, children: [
                            /* @__PURE__ */ jsxDEV("div", { style: { position: "absolute", top: 0, right: 0, height: "100%", width: "30%", background: "rgba(255, 255, 255, 0.1)", transform: "skewX(-15deg)" } }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 586,
                              columnNumber: 25
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { style: { position: "relative", zIndex: 1, padding: "20px" }, children: /* @__PURE__ */ jsxDEV(
                              Statistic,
                              {
                                title: /* @__PURE__ */ jsxDEV("span", { style: { color: "rgba(255, 255, 255, 0.9)", fontSize: "14px", fontWeight: "500" }, children: "Total Groups" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 590,
                                  columnNumber: 29
                                }, this),
                                value: groups.length,
                                prefix: /* @__PURE__ */ jsxDEV(TeamOutlined, { style: { color: "rgba(255, 255, 255, 0.9)", fontSize: "24px" } }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 595,
                                  columnNumber: 37
                                }, this),
                                valueStyle: { color: "#ffffff", fontWeight: "700", fontSize: "28px" }
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 588,
                                columnNumber: 27
                              },
                              this
                            ) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 587,
                              columnNumber: 25
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 577,
                            columnNumber: 23
                          }, this) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 576,
                            columnNumber: 21
                          }, this),
                          /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 8, children: /* @__PURE__ */ jsxDEV(Card, { style: {
                            borderRadius: "12px",
                            border: "none",
                            background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
                            height: "100%",
                            boxShadow: "0 4px 12px rgba(240, 147, 251, 0.3)",
                            overflow: "hidden",
                            position: "relative"
                          }, children: [
                            /* @__PURE__ */ jsxDEV("div", { style: { position: "absolute", top: 0, right: 0, height: "100%", width: "30%", background: "rgba(255, 255, 255, 0.1)", transform: "skewX(-15deg)" } }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 611,
                              columnNumber: 25
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { style: { position: "relative", zIndex: 1, padding: "20px" }, children: /* @__PURE__ */ jsxDEV(
                              Statistic,
                              {
                                title: /* @__PURE__ */ jsxDEV("span", { style: { color: "rgba(255, 255, 255, 0.9)", fontSize: "14px", fontWeight: "500" }, children: "Active Penalties" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 615,
                                  columnNumber: 29
                                }, this),
                                value: storedPenalties.length,
                                prefix: /* @__PURE__ */ jsxDEV(FileTextOutlined, { style: { color: "rgba(255, 255, 255, 0.9)", fontSize: "24px" } }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 620,
                                  columnNumber: 37
                                }, this),
                                valueStyle: { color: "#ffffff", fontWeight: "700", fontSize: "28px" }
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 613,
                                columnNumber: 27
                              },
                              this
                            ) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 612,
                              columnNumber: 25
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 602,
                            columnNumber: 23
                          }, this) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 601,
                            columnNumber: 21
                          }, this),
                          /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 8, children: /* @__PURE__ */ jsxDEV(Card, { style: {
                            borderRadius: "12px",
                            border: "none",
                            background: "linear-gradient(135deg, #fa709a 0%, #fee140 100%)",
                            height: "100%",
                            boxShadow: "0 4px 12px rgba(250, 112, 154, 0.3)",
                            overflow: "hidden",
                            position: "relative"
                          }, children: [
                            /* @__PURE__ */ jsxDEV("div", { style: { position: "absolute", top: 0, right: 0, height: "100%", width: "30%", background: "rgba(255, 255, 255, 0.1)", transform: "skewX(-15deg)" } }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 636,
                              columnNumber: 25
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { style: { position: "relative", zIndex: 1, padding: "20px" }, children: /* @__PURE__ */ jsxDEV(
                              Statistic,
                              {
                                title: /* @__PURE__ */ jsxDEV("span", { style: { color: "rgba(255, 255, 255, 0.9)", fontSize: "14px", fontWeight: "500" }, children: "Avg. Late Fee" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 640,
                                  columnNumber: 29
                                }, this),
                                prefix: "₹",
                                value: storedPenalties.length > 0 ? (storedPenalties.reduce((acc, p) => acc + (p.late_payment_amount || 0), 0) / storedPenalties.length).toFixed(2) : 0,
                                valueStyle: { color: "#ffffff", fontWeight: "700", fontSize: "28px" }
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 638,
                                columnNumber: 27
                              },
                              this
                            ) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 637,
                              columnNumber: 25
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 627,
                            columnNumber: 23
                          }, this) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 626,
                            columnNumber: 21
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 575,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV(Card, { style: {
                          borderRadius: "12px",
                          border: "none",
                          boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
                          marginBottom: "24px",
                          background: "#ffffff"
                        }, children: /* @__PURE__ */ jsxDEV("div", { style: { padding: "20px 24px" }, children: [
                          /* @__PURE__ */ jsxDEV(Title, { level: 4, style: {
                            marginTop: 0,
                            marginBottom: "24px",
                            color: "#1e293b",
                            fontWeight: "600",
                            fontSize: "18px",
                            display: "flex",
                            alignItems: "center"
                          }, children: [
                            /* @__PURE__ */ jsxDEV(TeamOutlined, { style: { marginRight: "8px", color: "#1890ff" } }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 673,
                              columnNumber: 25
                            }, this),
                            "Select Group"
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 664,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], align: "middle", children: [
                            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                              /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                                /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Group Name" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 679,
                                  columnNumber: 29
                                }, this),
                                /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 682,
                                  columnNumber: 29
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 678,
                                columnNumber: 27
                              }, this),
                              /* @__PURE__ */ jsxDEV(
                                Select,
                                {
                                  style: { width: "100%" },
                                  placeholder: "Select a group",
                                  loading: !groups.length,
                                  onChange: handleGroupChange,
                                  value: selectedGroup?._id,
                                  size: "large",
                                  showSearch: true,
                                  optionFilterProp: "children",
                                  children: groups.map(
                                    (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g._id, children: g.group_name }, g._id, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                      lineNumber: 695,
                                      columnNumber: 29
                                    }, this)
                                  )
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 684,
                                  columnNumber: 27
                                },
                                this
                              )
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 677,
                              columnNumber: 25
                            }, this),
                            selectedGroup && /* @__PURE__ */ jsxDEV(Col, { xs: 24, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "16px", width: "100%" }, children: [
                              /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: [
                                /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "6px" }, children: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Monthly" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 709,
                                  columnNumber: 35
                                }, this) }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 708,
                                  columnNumber: 33
                                }, this),
                                /* @__PURE__ */ jsxDEV(
                                  "div",
                                  {
                                    style: {
                                      padding: "12px 16px",
                                      background: "linear-gradient(to right, #f0f9ff, #e0f2fe)",
                                      border: "1px solid #bae6fd",
                                      borderRadius: "8px",
                                      fontWeight: "600",
                                      fontSize: "16px",
                                      color: "#0369a1"
                                    },
                                    children: [
                                      "₹",
                                      Number(selectedGroup.monthly_installment || 0).toLocaleString("en-IN")
                                    ]
                                  },
                                  void 0,
                                  true,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 713,
                                    columnNumber: 33
                                  },
                                  this
                                )
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 707,
                                columnNumber: 31
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: [
                                /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "6px" }, children: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Weekly" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 731,
                                  columnNumber: 35
                                }, this) }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 730,
                                  columnNumber: 33
                                }, this),
                                /* @__PURE__ */ jsxDEV(
                                  "div",
                                  {
                                    style: {
                                      padding: "12px 16px",
                                      background: "linear-gradient(to right, #fef9c3, #fef3c7)",
                                      border: "1px solid #fde68a",
                                      borderRadius: "8px",
                                      fontWeight: "600",
                                      fontSize: "16px",
                                      color: "#ca8a04"
                                    },
                                    children: [
                                      "₹",
                                      Number(selectedGroup.weekly_installment || 0).toLocaleString("en-IN")
                                    ]
                                  },
                                  void 0,
                                  true,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 735,
                                    columnNumber: 33
                                  },
                                  this
                                )
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 729,
                                columnNumber: 31
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: [
                                /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "6px" }, children: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Daily" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 753,
                                  columnNumber: 35
                                }, this) }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 752,
                                  columnNumber: 33
                                }, this),
                                /* @__PURE__ */ jsxDEV(
                                  "div",
                                  {
                                    style: {
                                      padding: "12px 16px",
                                      background: "linear-gradient(to right, #fef2f2, #fee2e2)",
                                      border: "1px solid #fecaca",
                                      borderRadius: "8px",
                                      fontWeight: "600",
                                      fontSize: "16px",
                                      color: "#b91c1c"
                                    },
                                    children: [
                                      "₹",
                                      Number(selectedGroup.daily_installment || 0).toLocaleString("en-IN")
                                    ]
                                  },
                                  void 0,
                                  true,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 757,
                                    columnNumber: 33
                                  },
                                  this
                                )
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 751,
                                columnNumber: 31
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 704,
                              columnNumber: 29
                            }, this) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 703,
                              columnNumber: 25
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 676,
                            columnNumber: 23
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 663,
                          columnNumber: 21
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 656,
                          columnNumber: 19
                        }, this),
                        !penaltyPreview && /* @__PURE__ */ jsxDEV(Fragment, { children: isGroupSelected && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                          /* @__PURE__ */ jsxDEV(Card, { style: {
                            borderRadius: "12px",
                            border: "none",
                            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
                            marginBottom: "24px",
                            background: "#ffffff",
                            overflow: "hidden"
                          }, children: [
                            /* @__PURE__ */ jsxDEV("div", { style: {
                              background: "linear-gradient(to right, #fff7e6, #fff2cc)",
                              padding: "16px 24px",
                              borderBottom: "1px solid #ffd591"
                            }, children: /* @__PURE__ */ jsxDEV(Title, { level: 4, style: {
                              margin: 0,
                              color: "#d46b08",
                              fontWeight: "600",
                              fontSize: "18px",
                              display: "flex",
                              alignItems: "center"
                            }, children: [
                              /* @__PURE__ */ jsxDEV(ThunderboltOutlined, { style: { marginRight: "8px" } }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 807,
                                columnNumber: 33
                              }, this),
                              "Late Charges"
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 799,
                              columnNumber: 31
                            }, this) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 794,
                              columnNumber: 29
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px" }, children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                              /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, children: [
                                /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                                  /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Grace Days (Late Fee)" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 815,
                                    columnNumber: 37
                                  }, this),
                                  /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 818,
                                    columnNumber: 37
                                  }, this)
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 814,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV(
                                  InputNumber,
                                  {
                                    style: { width: "100%" },
                                    min: 0,
                                    value: daysLateThreshold,
                                    onChange: setDaysLateThreshold,
                                    size: "large",
                                    placeholder: "Enter threshold days"
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 820,
                                    columnNumber: 35
                                  },
                                  this
                                )
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 813,
                                columnNumber: 33
                              }, this),
                              /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, children: [
                                /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                                  /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Late Fee Rate (%)" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 831,
                                    columnNumber: 37
                                  }, this),
                                  /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 834,
                                    columnNumber: 37
                                  }, this)
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 830,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV(
                                  InputNumber,
                                  {
                                    style: { width: "100%" },
                                    min: 0,
                                    max: 100,
                                    value: latePaymentRate,
                                    onChange: (val) => {
                                      setLatePaymentRate(val || 0);
                                      if (selectedGroup) {
                                        const amount = getInstallmentAmount(selectedGroup);
                                        const lateFee = amount > 0 ? parseFloat((amount * (val || 0) / 100).toFixed(2)) : 0;
                                        setLatePaymentAmount(lateFee);
                                      }
                                    },
                                    size: "large",
                                    placeholder: "Enter rate"
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 836,
                                    columnNumber: 35
                                  },
                                  this
                                )
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 829,
                                columnNumber: 33
                              }, this),
                              /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, children: [
                                /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                                  /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Late Fee Amount (₹)" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 855,
                                    columnNumber: 37
                                  }, this),
                                  /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 858,
                                    columnNumber: 37
                                  }, this)
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 854,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV(
                                  InputNumber,
                                  {
                                    style: { width: "100%" },
                                    min: 0,
                                    value: latePaymentAmount,
                                    onChange: (val) => {
                                      setLatePaymentAmount(val || 0);
                                      if (selectedGroup) {
                                        const amount = getInstallmentAmount(selectedGroup);
                                        const rate = amount > 0 ? parseFloat((val || 0) / amount * 100).toFixed(2) : 0;
                                        setLatePaymentRate(parseFloat(rate));
                                      }
                                    },
                                    size: "large",
                                    formatter: (value) => `₹${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                                    parser: (value) => value.replace(/\₹\s?|(,*)/g, ""),
                                    placeholder: "Enter amount"
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 860,
                                    columnNumber: 35
                                  },
                                  this
                                )
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 853,
                                columnNumber: 33
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 812,
                              columnNumber: 31
                            }, this) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 811,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 786,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(Card, { style: {
                            borderRadius: "12px",
                            border: "none",
                            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
                            marginBottom: "24px",
                            background: "#ffffff",
                            overflow: "hidden"
                          }, children: [
                            /* @__PURE__ */ jsxDEV("div", { style: {
                              background: "linear-gradient(to right, #fff1f0, #ffccc7)",
                              padding: "16px 24px",
                              borderBottom: "1px solid #ffa39e"
                            }, children: /* @__PURE__ */ jsxDEV(Title, { level: 4, style: {
                              margin: 0,
                              color: "#cf1322",
                              fontWeight: "600",
                              fontSize: "18px",
                              display: "flex",
                              alignItems: "center"
                            }, children: [
                              /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { style: { marginRight: "8px" } }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 904,
                                columnNumber: 33
                              }, this),
                              "Overdue Charges"
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 896,
                              columnNumber: 31
                            }, this) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 891,
                              columnNumber: 29
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px" }, children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                              /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                                /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                                  /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Penalty Rate (%)" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 928,
                                    columnNumber: 37
                                  }, this),
                                  /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 931,
                                    columnNumber: 37
                                  }, this)
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 927,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV(
                                  InputNumber,
                                  {
                                    style: { width: "100%" },
                                    min: 0,
                                    max: 100,
                                    value: penaltyRate,
                                    onChange: (val) => {
                                      setPenaltyRate(val || 0);
                                      if (selectedGroup) {
                                        const amount = getInstallmentAmount(selectedGroup);
                                        const penalty = amount > 0 ? parseFloat((amount * (val || 0) / 100).toFixed(2)) : 0;
                                        setPenaltyAmount(penalty);
                                      }
                                    },
                                    size: "large",
                                    placeholder: "Enter rate"
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 933,
                                    columnNumber: 35
                                  },
                                  this
                                )
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 926,
                                columnNumber: 33
                              }, this),
                              /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                                /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                                  /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Penalty Amount" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 952,
                                    columnNumber: 37
                                  }, this),
                                  /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 955,
                                    columnNumber: 37
                                  }, this)
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 951,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV(
                                  InputNumber,
                                  {
                                    style: { width: "100%" },
                                    min: 0,
                                    value: penaltyAmount,
                                    onChange: (val) => {
                                      setPenaltyAmount(val || 0);
                                      if (selectedGroup) {
                                        const amount = getInstallmentAmount(selectedGroup);
                                        const rate = amount > 0 ? parseFloat((val || 0) / amount * 100).toFixed(2) : 0;
                                        setPenaltyRate(parseFloat(rate));
                                      }
                                    },
                                    size: "large",
                                    formatter: (value) => `₹${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                                    parser: (value) => value.replace(/\₹\s?|(,*)/g, ""),
                                    placeholder: "Enter amount"
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 957,
                                    columnNumber: 35
                                  },
                                  this
                                )
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 950,
                                columnNumber: 33
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 909,
                              columnNumber: 31
                            }, this) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 908,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 883,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            Card,
                            {
                              style: {
                                borderRadius: "12px",
                                border: "none",
                                boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
                                marginBottom: "24px",
                                background: "#ffffff",
                                overflow: "hidden"
                              },
                              children: [
                                /* @__PURE__ */ jsxDEV(
                                  "div",
                                  {
                                    style: {
                                      background: "linear-gradient(to right, #ffe7cc, #ffd8a8)",
                                      padding: "16px 24px",
                                      borderBottom: "1px solid #ffc078"
                                    },
                                    children: /* @__PURE__ */ jsxDEV(
                                      Title,
                                      {
                                        level: 4,
                                        style: {
                                          margin: 0,
                                          color: "#d9480f",
                                          fontWeight: "600",
                                          fontSize: "18px",
                                          display: "flex",
                                          alignItems: "center"
                                        },
                                        children: [
                                          /* @__PURE__ */ jsxDEV(WarningOutlined, { style: { marginRight: "8px" } }, void 0, false, {
                                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                            lineNumber: 1008,
                                            columnNumber: 33
                                          }, this),
                                          "Overdue Charges for Vacant Chit"
                                        ]
                                      },
                                      void 0,
                                      true,
                                      {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                        lineNumber: 997,
                                        columnNumber: 31
                                      },
                                      this
                                    )
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 990,
                                    columnNumber: 29
                                  },
                                  this
                                ),
                                /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px" }, children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                                  /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                                    /* @__PURE__ */ jsxDEV(Text, { strong: true, children: "Grace Days (Vacant Chit)" }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                      lineNumber: 1015,
                                      columnNumber: 35
                                    }, this),
                                    /* @__PURE__ */ jsxDEV(
                                      InputNumber,
                                      {
                                        style: { width: "100%" },
                                        min: 0,
                                        value: vacantChitGraceDays,
                                        onChange: setVacantChitGraceDays,
                                        size: "large"
                                      },
                                      void 0,
                                      false,
                                      {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                        lineNumber: 1016,
                                        columnNumber: 35
                                      },
                                      this
                                    )
                                  ] }, void 0, true, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 1014,
                                    columnNumber: 33
                                  }, this),
                                  /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                                    /* @__PURE__ */ jsxDEV(Text, { strong: true, children: "Vacant Chit Penalty Rate (%)" }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                      lineNumber: 1027,
                                      columnNumber: 35
                                    }, this),
                                    /* @__PURE__ */ jsxDEV(
                                      InputNumber,
                                      {
                                        style: { width: "100%" },
                                        min: 0,
                                        max: 100,
                                        value: vacantChitPenaltyRate,
                                        onChange: (val) => {
                                          setVacantChitPenaltyRate(val || 0);
                                          if (selectedGroup) {
                                            const amount = getInstallmentAmount(selectedGroup);
                                            const penalty = amount > 0 ? parseFloat((amount * (val || 0) / 100).toFixed(2)) : 0;
                                            setVacantChitPenaltyAmount(penalty);
                                          }
                                        },
                                        size: "large",
                                        placeholder: "Enter rate"
                                      },
                                      void 0,
                                      false,
                                      {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                        lineNumber: 1028,
                                        columnNumber: 35
                                      },
                                      this
                                    )
                                  ] }, void 0, true, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 1026,
                                    columnNumber: 33
                                  }, this),
                                  /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                                    /* @__PURE__ */ jsxDEV(Text, { strong: true, children: "Vacant Chit Penalty Amount (₹)" }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                      lineNumber: 1048,
                                      columnNumber: 35
                                    }, this),
                                    /* @__PURE__ */ jsxDEV(
                                      InputNumber,
                                      {
                                        style: { width: "100%" },
                                        min: 0,
                                        value: vacantChitPenaltyAmount,
                                        onChange: (val) => {
                                          setVacantChitPenaltyAmount(val || 0);
                                          if (selectedGroup) {
                                            const amount = getInstallmentAmount(selectedGroup);
                                            const rate = amount > 0 ? parseFloat((val || 0) / amount * 100).toFixed(2) : 0;
                                            setVacantChitPenaltyRate(parseFloat(rate));
                                          }
                                        },
                                        size: "large",
                                        formatter: (value) => `₹${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                                        parser: (value) => value.replace(/\₹\s?|(,*)/g, ""),
                                        placeholder: "Enter amount"
                                      },
                                      void 0,
                                      false,
                                      {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                        lineNumber: 1049,
                                        columnNumber: 35
                                      },
                                      this
                                    )
                                  ] }, void 0, true, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                    lineNumber: 1047,
                                    columnNumber: 33
                                  }, this)
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 1013,
                                  columnNumber: 31
                                }, this) }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                  lineNumber: 1012,
                                  columnNumber: 29
                                }, this)
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 980,
                              columnNumber: 27
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end", marginTop: "24px" }, children: /* @__PURE__ */ jsxDEV(
                            Button,
                            {
                              type: "primary",
                              icon: /* @__PURE__ */ jsxDEV(IoMdSave, {}, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 1075,
                                columnNumber: 33
                              }, this),
                              loading: saving,
                              onClick: handleSave,
                              size: "large",
                              style: {
                                fontWeight: "600",
                                borderRadius: "8px",
                                background: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
                                border: "none",
                                boxShadow: "0 4px 12px rgba(79, 172, 254, 0.3)",
                                height: "48px",
                                paddingLeft: "24px",
                                paddingRight: "24px"
                              },
                              children: "Save Settings"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 1073,
                              columnNumber: 29
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1072,
                            columnNumber: 27
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 784,
                          columnNumber: 21
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 782,
                          columnNumber: 19
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 573,
                        columnNumber: 17
                      }, this)
                    },
                    "configure",
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 564,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    TabPane,
                    {
                      tab: /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", alignItems: "center" }, children: [
                        /* @__PURE__ */ jsxDEV(FileTextOutlined, { style: { marginRight: "8px" } }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1106,
                          columnNumber: 21
                        }, this),
                        "View Penality"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1105,
                        columnNumber: 17
                      }, this),
                      children: /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px", background: "#fafafa" }, children: /* @__PURE__ */ jsxDEV(Card, { style: {
                        borderRadius: "12px",
                        border: "none",
                        boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
                        background: "#ffffff"
                      }, children: [
                        /* @__PURE__ */ jsxDEV("div", { style: {
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          marginBottom: "16px",
                          padding: "16px 24px",
                          borderBottom: "1px solid #f0f0f0"
                        }, children: [
                          /* @__PURE__ */ jsxDEV(Title, { level: 4, style: {
                            margin: 0,
                            color: "#1e293b",
                            fontWeight: "600",
                            fontSize: "18px",
                            display: "flex",
                            alignItems: "center"
                          }, children: [
                            /* @__PURE__ */ jsxDEV(FileTextOutlined, { style: { marginRight: "8px", color: "#1890ff" } }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 1135,
                              columnNumber: 25
                            }, this),
                            "Penalty Records"
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1127,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center" }, children: [
                            /* @__PURE__ */ jsxDEV(
                              Search,
                              {
                                placeholder: "Search by group name",
                                allowClear: true,
                                enterButton: true,
                                size: "middle",
                                style: { width: 250, marginRight: 16 },
                                onSearch: setSearchText,
                                onChange: (e) => setSearchText(e.target.value)
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 1139,
                                columnNumber: 25
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV("span", { style: {
                              background: "linear-gradient(to right, #e6f7ff, #bae7ff)",
                              color: "#1890ff",
                              padding: "6px 12px",
                              borderRadius: "16px",
                              fontSize: "13px",
                              fontWeight: "600"
                            }, children: [
                              filteredPenalties.length,
                              " records"
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                              lineNumber: 1148,
                              columnNumber: 25
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1138,
                            columnNumber: 23
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1119,
                          columnNumber: 21
                        }, this),
                        loading ? /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "center", padding: "60px 0" }, children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1162,
                          columnNumber: 25
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1161,
                          columnNumber: 21
                        }, this) : /* @__PURE__ */ jsxDEV(
                          Table,
                          {
                            dataSource: filteredPenalties.map((p, i) => ({
                              ...p,
                              key: p._id || i
                            })),
                            columns,
                            pagination: {
                              pageSize: 10,
                              showSizeChanger: true,
                              showTotal: (total, range) => /* @__PURE__ */ jsxDEV("span", { style: { color: "#64748b", fontWeight: "500", fontSize: "13px" }, children: [
                                "Showing ",
                                range[0],
                                "-",
                                range[1],
                                " of ",
                                total,
                                " records"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 1175,
                                columnNumber: 25
                              }, this),
                              position: ["bottomCenter"]
                            },
                            scroll: { x: 1e3 }
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1165,
                            columnNumber: 21
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1113,
                        columnNumber: 19
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1112,
                        columnNumber: 17
                      }, this)
                    },
                    "records",
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1103,
                      columnNumber: 15
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                lineNumber: 553,
                columnNumber: 13
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
            lineNumber: 543,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Drawer,
          {
            title: /* @__PURE__ */ jsxDEV("div", { style: {
              display: "flex",
              alignItems: "center",
              gap: "12px",
              background: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
              padding: "20px 24px",
              borderTopLeftRadius: "8px",
              borderTopRightRadius: "8px"
            }, children: [
              /* @__PURE__ */ jsxDEV(EditOutlined, { style: { fontSize: "20px", color: "#ffffff" } }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                lineNumber: 1204,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "18px", fontWeight: "600", color: "#ffffff" }, children: [
                "Edit Penalty: ",
                editingPenalty?.group_name
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                lineNumber: 1205,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 1193,
              columnNumber: 13
            }, this),
            width: 900,
            open: editDrawerOpen,
            onClose: () => setEditDrawerOpen(false),
            footer: /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "right" }, children: /* @__PURE__ */ jsxDEV(Space, { size: 12, children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => setEditDrawerOpen(false),
                  style: { height: "36px", fontWeight: "500" },
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1216,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1225,
                    columnNumber: 25
                  }, this),
                  onClick: handleDrawerSave,
                  style: {
                    height: "36px",
                    fontWeight: "600",
                    background: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
                    border: "none"
                  },
                  children: "Update"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1223,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 1215,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 1214,
              columnNumber: 13
            }, this),
            children: editDrawerOpen && editingPenalty && /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px", background: "#fafafa" }, children: [
              /* @__PURE__ */ jsxDEV(
                Card,
                {
                  style: {
                    borderRadius: "12px",
                    border: "none",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.05)",
                    marginBottom: "24px",
                    background: "#ffffff"
                  },
                  children: /* @__PURE__ */ jsxDEV("div", { style: { padding: "20px 24px" }, children: [
                    /* @__PURE__ */ jsxDEV(
                      Title,
                      {
                        level: 4,
                        style: {
                          margin: 0,
                          color: "#1e293b",
                          fontWeight: "600",
                          fontSize: "18px",
                          display: "flex",
                          alignItems: "center"
                        },
                        children: [
                          /* @__PURE__ */ jsxDEV(CalendarOutlined, { style: { marginRight: "8px", color: "#1890ff" } }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1264,
                            columnNumber: 23
                          }, this),
                          "Installment Details"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1253,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], style: { marginTop: "16px" }, children: [
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 8, children: [
                        /* @__PURE__ */ jsxDEV(Text, { strong: true, children: "Monthly Installment" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1270,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            style: {
                              padding: "12px 16px",
                              background: "#e0f2fe",
                              border: "1px solid #bae6fd",
                              borderRadius: "8px",
                              marginTop: "6px",
                              fontWeight: "600",
                              fontSize: "16px",
                              color: "#0369a1"
                            },
                            children: [
                              "₹",
                              Number(editingPenalty.monthly_installment).toLocaleString("en-IN")
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1271,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1269,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 8, children: [
                        /* @__PURE__ */ jsxDEV(Text, { strong: true, children: "Weekly Installment" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1288,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            style: {
                              padding: "12px 16px",
                              background: "#fef3c7",
                              border: "1px solid #fde68a",
                              borderRadius: "8px",
                              marginTop: "6px",
                              fontWeight: "600",
                              fontSize: "16px",
                              color: "#ca8a04"
                            },
                            children: [
                              "₹",
                              Number(editingPenalty.weekly_installment).toLocaleString("en-IN")
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1289,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1287,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 8, children: [
                        /* @__PURE__ */ jsxDEV(Text, { strong: true, children: "Daily Installment" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1306,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            style: {
                              padding: "12px 16px",
                              background: "#fee2e2",
                              border: "1px solid #fecaca",
                              borderRadius: "8px",
                              marginTop: "6px",
                              fontWeight: "600",
                              fontSize: "16px",
                              color: "#b91c1c"
                            },
                            children: [
                              "₹",
                              Number(editingPenalty.daily_installment).toLocaleString("en-IN")
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1307,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1305,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1268,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1252,
                    columnNumber: 19
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1243,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Card,
                {
                  style: {
                    borderRadius: "12px",
                    border: "none",
                    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
                    marginBottom: "24px",
                    background: "#ffffff",
                    overflow: "hidden"
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        style: {
                          background: "linear-gradient(to right, #fff7e6, #fff2cc)",
                          padding: "16px 24px",
                          borderBottom: "1px solid #ffd591"
                        },
                        children: /* @__PURE__ */ jsxDEV(
                          Title,
                          {
                            level: 4,
                            style: {
                              margin: 0,
                              color: "#d46b08",
                              fontWeight: "600",
                              fontSize: "18px",
                              display: "flex",
                              alignItems: "center"
                            },
                            children: [
                              /* @__PURE__ */ jsxDEV(ThunderboltOutlined, { style: { marginRight: "8px" } }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 1355,
                                columnNumber: 23
                              }, this),
                              "Late Charges"
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1344,
                            columnNumber: 21
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1337,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px" }, children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                        /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                          /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Grace Days (Late Fee)" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1363,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1366,
                            columnNumber: 27
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1362,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            value: editingPenalty.days_late_threshold || 0,
                            onChange: (val) => setEditingPenalty((prev) => ({ ...prev, days_late_threshold: val ?? 0 })),
                            size: "large",
                            placeholder: "Enter threshold days"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1368,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1361,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                        /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                          /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Late Fee Rate (%)" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1381,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1384,
                            columnNumber: 27
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1380,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            max: 100,
                            value: Number(editingPenalty.late_payment_rate || 0),
                            onChange: (val) => {
                              const installment = Number(editingPenalty.monthly_installment) || 0;
                              console.log(installment, val, "this is val");
                              const rate = typeof val === "number" && !isNaN(val) ? val : 0;
                              const amount = installment > 0 ? parseFloat((installment * rate / 100).toFixed(2)) : 0;
                              setEditingPenalty((prev) => ({
                                ...prev,
                                late_payment_rate: rate,
                                late_payment_amount: amount
                              }));
                            },
                            size: "large",
                            placeholder: "Enter rate"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1386,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1379,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                        /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                          /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Late Fee Amount (₹)" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1408,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1411,
                            columnNumber: 27
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1407,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            value: editingPenalty.late_payment_amount ?? 0,
                            onChange: (val) => {
                              const installment = Number(editingPenalty.installment_amount) || 0;
                              const amount = typeof val === "number" && !isNaN(val) ? val : 0;
                              const rate = installment > 0 ? parseFloat((amount / installment * 100).toFixed(2)) : 0;
                              setEditingPenalty((prev) => ({
                                ...prev,
                                late_payment_amount: amount,
                                late_payment_rate: rate
                              }));
                            },
                            size: "large",
                            formatter: (value) => `₹${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                            parser: (value) => value.replace(/\₹\s?|(,*)/g, ""),
                            placeholder: "Enter late fee"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1413,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1406,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1360,
                      columnNumber: 21
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1359,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1327,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Card,
                {
                  style: {
                    borderRadius: "12px",
                    border: "none",
                    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
                    marginBottom: "24px",
                    background: "#ffffff",
                    overflow: "hidden"
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        style: {
                          background: "linear-gradient(to right, #fff1f0, #ffccc7)",
                          padding: "16px 24px",
                          borderBottom: "1px solid #ffa39e"
                        },
                        children: /* @__PURE__ */ jsxDEV(
                          Title,
                          {
                            level: 4,
                            style: {
                              margin: 0,
                              color: "#cf1322",
                              fontWeight: "600",
                              fontSize: "18px",
                              display: "flex",
                              alignItems: "center"
                            },
                            children: [
                              /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { style: { marginRight: "8px" } }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 1468,
                                columnNumber: 23
                              }, this),
                              "Overdue Charges"
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1457,
                            columnNumber: 21
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1450,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px" }, children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                        /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                          /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Penalty Rate (%)" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1476,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1479,
                            columnNumber: 27
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1475,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            max: 100,
                            value: editingPenalty.penalty_rate ?? 0,
                            onChange: (val) => {
                              const installment = Number(editingPenalty.installment_amount) || 0;
                              const rate = typeof val === "number" && !isNaN(val) ? val : 0;
                              const amount = installment > 0 ? parseFloat((installment * rate / 100).toFixed(2)) : 0;
                              setEditingPenalty((prev) => ({
                                ...prev,
                                penalty_rate: rate,
                                penalty_amount: amount
                              }));
                            },
                            size: "large",
                            placeholder: "Enter rate"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1481,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1474,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                        /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: [
                          /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Penalty Amount (₹)" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1502,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(Text, { type: "danger", children: " *" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1505,
                            columnNumber: 27
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1501,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            value: editingPenalty.penalty_amount ?? 0,
                            onChange: (val) => {
                              const installment = Number(editingPenalty.installment_amount) || 0;
                              const amount = typeof val === "number" && !isNaN(val) ? val : 0;
                              const rate = installment > 0 ? parseFloat((amount / installment * 100).toFixed(2)) : 0;
                              setEditingPenalty((prev) => ({
                                ...prev,
                                penalty_amount: amount,
                                penalty_rate: rate
                              }));
                            },
                            size: "large",
                            formatter: (value) => `₹${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                            parser: (value) => value.replace(/\₹\s?|(,*)/g, ""),
                            placeholder: "Enter amount"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1507,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1500,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1473,
                      columnNumber: 21
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1472,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1440,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Card,
                {
                  style: {
                    borderRadius: "12px",
                    border: "none",
                    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
                    marginBottom: "24px",
                    background: "#ffffff",
                    overflow: "hidden"
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        style: {
                          background: "linear-gradient(to right, #ffe7cc, #ffd8a8)",
                          padding: "16px 24px",
                          borderBottom: "1px solid #ffc078"
                        },
                        children: /* @__PURE__ */ jsxDEV(
                          Title,
                          {
                            level: 4,
                            style: {
                              margin: 0,
                              color: "#d9480f",
                              fontWeight: "600",
                              fontSize: "18px",
                              display: "flex",
                              alignItems: "center"
                            },
                            children: [
                              /* @__PURE__ */ jsxDEV(WarningOutlined, { style: { marginRight: "8px" } }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                                lineNumber: 1562,
                                columnNumber: 23
                              }, this),
                              "Overdue Charges for Vacant Chit"
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1551,
                            columnNumber: 21
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1544,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px" }, children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                        /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Grace Days (Vacant Chit)" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1570,
                          columnNumber: 27
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1569,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            value: editingPenalty.vacant_chit_grace_days ?? 0,
                            onChange: (val) => setEditingPenalty((prev) => ({ ...prev, vacant_chit_grace_days: val ?? 0 })),
                            size: "large",
                            placeholder: "Enter days"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1574,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1568,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                        /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Vacant Chit Penalty Rate (%)" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1587,
                          columnNumber: 27
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1586,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            max: 100,
                            value: editingPenalty.vacant_chit_penalty_rate ?? 0,
                            onChange: (val) => {
                              const installment = Number(editingPenalty.installment_amount) || 0;
                              const rate = typeof val === "number" && !isNaN(val) ? val : 0;
                              const amount = installment > 0 ? parseFloat((installment * rate / 100).toFixed(2)) : 0;
                              setEditingPenalty((prev) => ({
                                ...prev,
                                vacant_chit_penalty_rate: rate,
                                vacant_chit_penalty_amount: amount
                              }));
                            },
                            size: "large",
                            placeholder: "Enter rate"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1591,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1585,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, children: [
                        /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "8px" }, children: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { color: "#475569", fontSize: "14px" }, children: "Vacant Chit Penalty Amount (₹)" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1612,
                          columnNumber: 27
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1611,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            value: editingPenalty.vacant_chit_penalty_amount ?? 0,
                            onChange: (val) => {
                              const installment = Number(editingPenalty.installment_amount) || 0;
                              console.log(installment);
                              const amount = typeof val === "number" && !isNaN(val) ? val : 0;
                              const rate = installment > 0 ? parseFloat((amount / installment * 100).toFixed(2)) : 0;
                              setEditingPenalty((prev) => ({
                                ...prev,
                                vacant_chit_penalty_amount: amount,
                                vacant_chit_penalty_rate: rate
                              }));
                            },
                            size: "large",
                            formatter: (value) => `₹${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                            parser: (value) => value.replace(/\₹\s?|(,*)/g, ""),
                            placeholder: "Enter amount"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1616,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1610,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1567,
                      columnNumber: 21
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1566,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1534,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 1241,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
            lineNumber: 1191,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Modal,
          {
            title: /* @__PURE__ */ jsxDEV("div", { style: {
              display: "flex",
              alignItems: "center",
              gap: "12px",
              background: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
              margin: "-24px -24px 20px -24px",
              padding: "20px 24px",
              borderTopLeftRadius: "8px",
              borderTopRightRadius: "8px"
            }, children: [
              /* @__PURE__ */ jsxDEV(PlusOutlined, { style: { fontSize: "20px", color: "#ffffff" } }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                lineNumber: 1660,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "18px", fontWeight: "600", color: "#ffffff" }, children: "Add Additional Charge" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                lineNumber: 1661,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 1650,
              columnNumber: 13
            }, this),
            open: isAddChargeModalOpen,
            onCancel: () => {
              setIsAddChargeModalOpen(false);
              addChargeForm.resetFields();
            },
            width: 600,
            footer: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => {
                    setIsAddChargeModalOpen(false);
                    addChargeForm.resetFields();
                  },
                  style: {
                    borderRadius: "6px",
                    fontWeight: "500",
                    height: "36px"
                  },
                  children: "Cancel"
                },
                "cancel",
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1673,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1690,
                    columnNumber: 21
                  }, this),
                  onClick: handleAddCharge,
                  style: {
                    borderRadius: "6px",
                    fontWeight: "600",
                    height: "36px",
                    background: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
                    border: "none"
                  },
                  children: "Add Charge"
                },
                "save",
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1687,
                  columnNumber: 13
                },
                this
              )
            ],
            children: /* @__PURE__ */ jsxDEV(Form, { form: addChargeForm, layout: "vertical", style: { marginTop: "20px" }, children: [
              /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  label: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { fontSize: "14px", color: "#475569" }, children: "Charge Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1706,
                    columnNumber: 24
                  }, this),
                  name: "charge_name",
                  rules: [{ required: true, message: "Please enter charge name" }],
                  children: /* @__PURE__ */ jsxDEV(Input, { style: { width: "100%" }, placeholder: "e.g., Processing Fee" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1710,
                    columnNumber: 17
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1705,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  label: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { fontSize: "14px", color: "#475569" }, children: "Charge Type" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1714,
                    columnNumber: 24
                  }, this),
                  name: "charge_type",
                  rules: [{ required: true, message: "Please select charge type" }],
                  initialValue: "fixed",
                  children: /* @__PURE__ */ jsxDEV(Select, { style: { width: "100%" }, children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "fixed", children: "Fixed Amount" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1720,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "percentage", children: "Percentage" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1721,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1719,
                    columnNumber: 17
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1713,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  noStyle: true,
                  shouldUpdate: (prevValues, currentValues) => prevValues.charge_type !== currentValues.charge_type,
                  children: ({ getFieldValue }) => {
                    const chargeType = getFieldValue("charge_type");
                    return chargeType === "fixed" ? /* @__PURE__ */ jsxDEV(
                      Form.Item,
                      {
                        label: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { fontSize: "14px", color: "#475569" }, children: "Amount (₹)" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1733,
                          columnNumber: 28
                        }, this),
                        name: "charge_amount",
                        rules: [{ required: true, message: "Please enter amount" }],
                        children: /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            formatter: (value) => `₹${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                            parser: (value) => value.replace(/\₹\s?|(,*)/g, ""),
                            placeholder: "Enter amount"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1737,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1732,
                        columnNumber: 19
                      },
                      this
                    ) : /* @__PURE__ */ jsxDEV(
                      Form.Item,
                      {
                        label: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { fontSize: "14px", color: "#475569" }, children: "Rate (%)" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1747,
                          columnNumber: 28
                        }, this),
                        name: "charge_rate",
                        rules: [{ required: true, message: "Please enter rate" }],
                        children: /* @__PURE__ */ jsxDEV(
                          InputNumber,
                          {
                            style: { width: "100%" },
                            min: 0,
                            max: 100,
                            placeholder: "Enter rate"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                            lineNumber: 1751,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1746,
                        columnNumber: 19
                      },
                      this
                    );
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1725,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  label: /* @__PURE__ */ jsxDEV(Text, { strong: true, style: { fontSize: "14px", color: "#475569" }, children: "Description" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1763,
                    columnNumber: 24
                  }, this),
                  name: "charge_description",
                  children: /* @__PURE__ */ jsxDEV(Input.TextArea, { rows: 3, placeholder: "Enter description (optional)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1766,
                    columnNumber: 17
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1762,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 1704,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
            lineNumber: 1648,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Modal,
          {
            open: showPenaltyPreview,
            onCancel: () => setShowPenaltyPreview(false),
            footer: null,
            width: 850,
            closable: false,
            style: { top: 40 },
            bodyStyle: { padding: 0, background: "#f5f7fa" },
            children: penaltyPreview && /* @__PURE__ */ jsxDEV("div", { style: { padding: "24px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: {
                background: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
                padding: "20px 24px",
                borderRadius: "12px",
                marginBottom: "20px",
                color: "#fff",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center"
              }, children: [
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "18px", fontWeight: "600" }, children: [
                  "Penalty Already Set — ",
                  penaltyPreview.group_name
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1793,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "primary",
                    style: {
                      borderRadius: "6px",
                      fontWeight: "600"
                    },
                    onClick: () => {
                      setShowPenaltyPreview(false);
                      openEditDrawer(penaltyPreview);
                    },
                    children: "Edit Penalty"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                    lineNumber: 1797,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                lineNumber: 1783,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Card,
                {
                  style: {
                    borderRadius: "12px",
                    marginBottom: "20px",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.05)"
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV(Title, { level: 4, style: { marginBottom: 16 }, children: "Installment Details" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1823,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV(Text, { strong: true, children: "Monthly Installment" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1829,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "info-box violetBox", children: [
                          "₹",
                          penaltyPreview.monthly_installment
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1830,
                          columnNumber: 23
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1828,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV(Text, { strong: true, children: "Weekly Installment" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1836,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "info-box yellowBox", children: [
                          "₹",
                          penaltyPreview.weekly_installment
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1837,
                          columnNumber: 23
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1835,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV(Text, { strong: true, children: "Daily Installment" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1843,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "info-box redBox", children: [
                          "₹",
                          penaltyPreview.daily_installment
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1844,
                          columnNumber: 23
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1842,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1827,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1816,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Card,
                {
                  style: {
                    borderRadius: "12px",
                    marginBottom: "20px",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.05)"
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV(Title, { level: 4, style: { marginBottom: 16 }, children: "Late Charges" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1859,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV("b", { children: "Grace Days:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1861,
                          columnNumber: 35
                        }, this),
                        " ",
                        penaltyPreview.days_late_threshold
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1861,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV("b", { children: "Late Fee Rate:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1862,
                          columnNumber: 35
                        }, this),
                        " ",
                        penaltyPreview.late_payment_rate,
                        "%"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1862,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV("b", { children: "Late Fee Amount:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1863,
                          columnNumber: 35
                        }, this),
                        " ₹",
                        penaltyPreview.late_payment_amount
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1863,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1860,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1852,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Card,
                {
                  style: {
                    borderRadius: "12px",
                    marginBottom: "20px",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.05)"
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV(Title, { level: 4, style: { marginBottom: 16 }, children: "Overdue Charges" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1875,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV("b", { children: "Penalty Rate:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1877,
                          columnNumber: 35
                        }, this),
                        " ",
                        penaltyPreview.penalty_rate,
                        "%"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1877,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV("b", { children: "Penalty Amount:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1878,
                          columnNumber: 35
                        }, this),
                        " ₹",
                        penaltyPreview.penalty_amount
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1878,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1876,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1868,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Card,
                {
                  style: {
                    borderRadius: "12px",
                    marginBottom: "20px",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.05)"
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV(Title, { level: 4, style: { marginBottom: 16 }, children: "Vacant Chit Charges" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1891,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV("b", { children: "Grace Days:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1893,
                          columnNumber: 35
                        }, this),
                        " ",
                        penaltyPreview.vacant_chit_grace_days
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1893,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV("b", { children: "Rate:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1894,
                          columnNumber: 35
                        }, this),
                        " ",
                        penaltyPreview.vacant_chit_penalty_rate,
                        "%"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1894,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Col, { span: 8, children: [
                        /* @__PURE__ */ jsxDEV("b", { children: "Amount:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                          lineNumber: 1895,
                          columnNumber: 35
                        }, this),
                        " ₹",
                        penaltyPreview.vacant_chit_penalty_amount
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                        lineNumber: 1895,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                      lineNumber: 1892,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                  lineNumber: 1884,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "right", marginTop: 20 }, children: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setShowPenaltyPreview(false), children: "Close" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                lineNumber: 1901,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
                lineNumber: 1900,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
              lineNumber: 1780,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
            lineNumber: 1770,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("style", { children: `
            .ant-select-selector {
              border-radius: 8px !important;
              border: 1px solid #d9d9d9 !important;
              transition: all 0.2s ease !important;
            }
            
            .ant-select-selector:hover {
              border-color: #40a9ff !important;
            }
            
            .ant-select-focused .ant-select-selector {
              border-color: #40a9ff !important;
              box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.2) !important;
            }
            
            .ant-input-number {
              border-radius: 8px !important;
              border: 1px solid #d9d9d9 !important;
              transition: all 0.2s ease !important;
            }
            
            .ant-input-number:hover {
              border-color: #40a9ff !important;
            }
            
            .ant-input-number-focused {
              border-color: #40a9ff !important;
              box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.2) !important;
            }
            
            .ant-table {
              border-radius: 8px !important;
            }
            
            .ant-table-thead > tr > th {
              background: #fafafa !important;
              font-weight: 600 !important;
              color: #262626 !important;
              border-bottom: 1px solid #f0f0f0 !important;
              font-size: 14px !important;
              padding: 16px !important;
            }
            
            .ant-table-tbody > tr {
              transition: all 0.2s ease !important;
            }
            
            .ant-table-tbody > tr:hover > td {
              background: #f5f5f5 !important;
            }
            
            .ant-table-tbody > tr > td {
              padding: 16px !important;
              border-bottom: 1px solid #f0f0f0 !important;
            }
            
            .ant-pagination-item {
              border-radius: 6px !important;
            }
            
            .ant-pagination-item-active {
              background: #1890ff !important;
              border-color: #1890ff !important;
              font-weight: 600 !important;
            }
            
            .ant-pagination-item-active a {
              color: white !important;
            }
            
            .ant-btn-primary {
              background: #1890ff !important;
              border-color: #1890ff !important;
              border-radius: 6px !important;
            }
            
            .ant-btn-primary:hover:not(:disabled) {
              background: #40a9ff !important;
              border-color: #40a9ff !important;
            }
            
            .ant-btn {
              border-radius: 6px !important;
              transition: all 0.2s ease !important;
            }
            
            .ant-modal-header {
              border-bottom: none !important;
              padding: 0 !important;
            }
            
            .ant-modal-body {
              padding: 24px !important;
            }
            
            .ant-modal-footer {
              border-top: 1px solid #f0f0f0 !important;
              padding: 16px 24px !important;
            }
            
            .ant-card {
              box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06) !important;
            }
            
            .ant-statistic-title {
              margin-bottom: 8px !important;
            }
            
            .ant-form-item-label > label {
              font-size: 14px !important;
              color: #262626 !important;
              font-weight: 500 !important;
            }
            
            .ant-tabs-tab {
              padding: 12px 16px !important;
              margin: 0 !important;
            }
            
            .ant-tabs-tab-active {
              color: #1890ff !important;
            }
            
            .ant-tabs-ink-bar {
              background: #1890ff !important;
            }
            
            .ant-collapse-header {
              padding: 12px 16px !important;
            }
            
            .ant-collapse-content-box {
              padding: 16px !important;
            }
              .info-box {
  padding: 12px 16px;
  border-radius: 8px;
  margin-top: 6px;
  font-weight: 600;
  font-size: 16px;
}

.violetBox {
  background: #e0f2fe;
  border: 1px solid #bae6fd;
  color: #0369a1;
}

.yellowBox {
  background: #fef9c3;
  border: 1px solid #fde68a;
  color: #ca8a04;
}

.redBox {
  background: #fee2e2;
  border: 1px solid #fecaca;
  color: #b91c1c;
}

          ` }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
          lineNumber: 1910,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
        lineNumber: 495,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
      lineNumber: 490,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx",
    lineNumber: 488,
    columnNumber: 5
  }, this);
};
_s(PenaltySettings, "KHzMNSMEUrEqyti41o9wGGdwyGM=", false, function() {
  return [useNavigate, Form.useForm, Form.useForm];
});
_c = PenaltySettings;
export default PenaltySettings;
var _c;
$RefreshReg$(_c, "PenaltySettings");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltySettings.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcVZRLFNBMGJnQixVQTFiaEI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcFZSLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxTQUFTO0FBQ2hCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGdCQUFnQjtBQUN6QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsbUJBQW1CO0FBRTVCLE1BQU0sRUFBRUMsT0FBT0MsTUFBTUMsVUFBVSxJQUFJbkM7QUFDbkMsTUFBTSxFQUFFb0MsUUFBUSxJQUFJakM7QUFDcEIsTUFBTSxFQUFFa0MsTUFBTSxJQUFJL0I7QUFDbEIsTUFBTSxFQUFFZ0MsT0FBTyxJQUFJNUI7QUFFbkIsTUFBTTZCLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU1DLFdBQVdULFlBQVk7QUFDN0IsUUFBTSxDQUFDVSxRQUFRQyxTQUFTLElBQUkzRCxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDNEQsZUFBZUMsZ0JBQWdCLElBQUk3RCxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDOEQsYUFBYUMsY0FBYyxJQUFJL0QsU0FBUyxDQUFDO0FBQ2hELFFBQU0sQ0FBQ2dFLFdBQVdDLFlBQVksSUFBSWpFLFNBQVMsQ0FBQztBQUM1QyxRQUFNLENBQUNrRSxlQUFlQyxnQkFBZ0IsSUFBSW5FLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUNvRSxtQkFBbUJDLG9CQUFvQixJQUFJckUsU0FBUyxDQUFDO0FBQzVELFFBQU0sQ0FBQ3NFLG1CQUFtQkMsb0JBQW9CLElBQUl2RSxTQUFTLENBQUM7QUFDNUQsUUFBTSxDQUFDd0UsUUFBUUMsU0FBUyxJQUFJekUsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQzBFLGlCQUFpQkMsa0JBQWtCLElBQUkzRSxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDNEUsU0FBU0MsVUFBVSxJQUFJN0UsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQzhFLGdCQUFnQkMsaUJBQWlCLElBQUkvRSxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDZ0YsZ0JBQWdCQyxpQkFBaUIsSUFBSWpGLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUNrRixTQUFTQyxVQUFVLElBQUluRixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDb0YsU0FBUyxJQUFJdEUsS0FBS3VFLFFBQVE7QUFDakMsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUl2RixTQUFTLFdBQVc7QUFDdEQsUUFBTSxDQUFDd0YsbUJBQW1CQyxvQkFBb0IsSUFBSXpGLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUMwRixzQkFBc0JDLHVCQUF1QixJQUFJM0YsU0FBUyxLQUFLO0FBQ3RFLFFBQU0sQ0FBQzRGLGFBQWEsSUFBSTlFLEtBQUt1RSxRQUFRO0FBQ3JDLFFBQU0sQ0FBQ1EsWUFBWUMsYUFBYSxJQUFJOUYsU0FBUyxFQUFFO0FBQy9DLFFBQU0rRixrQkFBa0IsQ0FBQyxDQUFDbkM7QUFFMUIsUUFBTSxDQUFDb0MseUJBQXlCQywwQkFBMEIsSUFBSWpHLFNBQVMsQ0FBQztBQUN4RSxRQUFNLENBQUNrRyxxQkFBcUJDLHNCQUFzQixJQUFJbkcsU0FBUyxFQUFFO0FBQ2pFLFFBQU0sQ0FBQ29HLHVCQUF1QkMsd0JBQXdCLElBQUlyRyxTQUFTLENBQUM7QUFFcEUsUUFBTSxDQUFDc0csaUJBQWlCQyxrQkFBa0IsSUFBSXZHLFNBQVMsQ0FBQztBQUV4RCxRQUFNLENBQUN3RyxnQkFBZ0JDLGlCQUFpQixJQUFJekcsU0FBUyxJQUFJO0FBQ3pELFFBQU0sQ0FBQzBHLG9CQUFvQkMscUJBQXFCLElBQUkzRyxTQUFTLEtBQUs7QUFFaEUsUUFBTTRHLDRCQUE0QkEsQ0FBQ0MsTUFBTTtBQUN6QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJqQixrQkFBY2dCLEtBQUs7QUFBQSxFQUNyQjtBQUdBL0csWUFBVSxNQUFNO0FBQ2QsUUFBSTZELGlCQUFpQkUsZUFBZSxHQUFHO0FBQ3JDLFlBQU1rRCxjQUFjQyxxQkFBcUJyRCxhQUFhO0FBQ3RELFlBQU1zRCxVQUFVQyxZQUFhSCxjQUFjbEQsY0FBZSxLQUFLc0QsUUFBUSxDQUFDLENBQUM7QUFDekVqRCx1QkFBaUIrQyxPQUFPO0FBQUEsSUFDMUIsT0FBTztBQUNML0MsdUJBQWlCLENBQUM7QUFBQSxJQUNwQjtBQUFBLEVBQ0YsR0FBRyxDQUFDTCxhQUFhRixhQUFhLENBQUM7QUFHL0I3RCxZQUFVLE1BQU07QUFDZCxVQUFNc0gsZ0JBQWdCQSxDQUFDUixNQUFNO0FBRTNCLFVBQUksQ0FBQyxTQUFTLFlBQVksUUFBUSxFQUFFUyxTQUFTVCxFQUFFRSxPQUFPUSxPQUFPLEVBQUc7QUFFaEUsVUFBSVYsRUFBRVcsV0FBV1gsRUFBRVksWUFBWVosRUFBRWEsSUFBSUMsWUFBWSxNQUFNLEtBQUs7QUFDMURkLFVBQUVlLGVBQWU7QUFDakJuRSxpQkFBUyxrQkFBa0I7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFFQW9FLFdBQU9DLGlCQUFpQixXQUFXVCxhQUFhO0FBQ2hELFdBQU8sTUFBTVEsT0FBT0Usb0JBQW9CLFdBQVdWLGFBQWE7QUFBQSxFQUNsRSxHQUFHLENBQUM1RCxRQUFRLENBQUM7QUFHYjFELFlBQVUsTUFBTTtBQUNkaUksZ0JBQVk7QUFDWkMsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxRQUFNRCxjQUFjLFlBQVk7QUFDOUIsUUFBSTtBQUNGLFlBQU1FLE1BQU0sTUFBTS9ILElBQUlnSSxJQUFJLGtCQUFrQjtBQUM1Q3hFLGdCQUFVdUUsSUFBSUUsUUFBUSxFQUFFO0FBQUEsSUFDMUIsU0FBU0MsS0FBSztBQUNaN0gsY0FBUThILE1BQU0sdUJBQXVCO0FBQUEsSUFDdkM7QUFBQSxFQUNGO0FBRUEsUUFBTUwsaUJBQWlCLFlBQVk7QUFDakMsUUFBSTtBQUNGcEQsaUJBQVcsSUFBSTtBQUNmLFlBQU1xRCxNQUFNLE1BQU0vSCxJQUFJZ0ksSUFBSSwyQkFBMkI7QUFDckQsWUFBTUksYUFBYUwsSUFBSUUsUUFBUSxJQUFJSSxJQUFJLENBQUNDLE1BQU07QUFDNUMsY0FBTUMsUUFBUWhGLE9BQU9pRixLQUFLLENBQUNDLE1BQU1BLEVBQUVDLFFBQVFKLEVBQUVLLFFBQVE7QUFDckQsZUFBTztBQUFBLFVBQ0wsR0FBR0w7QUFBQUEsVUFDSE0sWUFBWUwsT0FBT0ssY0FBY04sRUFBRU0sY0FBYztBQUFBLFVBQ2pEQyxvQkFBb0JOLFFBQ2hCQSxNQUFNTyx1QkFDUlAsTUFBTVEscUJBQ05SLE1BQU1TLGlCQUNOVCxNQUFNVSxzQkFDTlYsTUFBTVcscUJBQ04sSUFDRVosRUFBRU8sc0JBQXNCO0FBQUEsUUFDOUI7QUFBQSxNQUNGLENBQUM7QUFDRHJFLHlCQUFtQjRELFNBQVM7QUFBQSxJQUM5QixTQUFTRixLQUFLO0FBQ1o3SCxjQUFROEgsTUFBTSxpQ0FBaUM7QUFBQSxJQUNqRCxVQUFDO0FBQ0N6RCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTW9DLHVCQUF1QkEsQ0FBQ3lCLFVBQVU7QUFDdEMsUUFBSSxDQUFDQSxNQUFPLFFBQU87QUFDbkIsV0FDRUEsTUFBTU8sdUJBQ05QLE1BQU1RLHFCQUNOUixNQUFNUyxpQkFDTlQsTUFBTVUsc0JBQ05WLE1BQU1XLHFCQUNOO0FBQUEsRUFFSjtBQUVBLFFBQU1DLG9CQUFvQkEsQ0FBQ3hDLFVBQVU7QUFDbkMsVUFBTTRCLFFBQVFoRixPQUFPaUYsS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxRQUFRL0IsS0FBSztBQUM5Q2pELHFCQUFpQjZFLEtBQUs7QUFFdEIsVUFBTWEsV0FBVzdFLGdCQUFnQmlFLEtBQUssQ0FBQUYsTUFBS0EsRUFBRUssYUFBYWhDLEtBQUs7QUFFL0QsUUFBSXlDLFVBQVU7QUFDWjlDLHdCQUFrQjtBQUFBLFFBQ2hCLEdBQUc4QztBQUFBQSxRQUNITixxQkFBcUJQLE9BQU9PLHVCQUF1QjtBQUFBLFFBQ25ERyxvQkFBb0JWLE9BQU9VLHNCQUFzQjtBQUFBLFFBQ2pEQyxtQkFBbUJYLE9BQU9XLHFCQUFxQjtBQUFBLFFBQy9DRyxXQUFXZDtBQUFBQSxNQUNiLENBQUM7QUFDRC9CLDRCQUFzQixJQUFJO0FBQUEsSUFDNUI7QUFHQTVDLG1CQUFlLENBQUM7QUFDaEJFLGlCQUFhLENBQUM7QUFDZEUscUJBQWlCLENBQUM7QUFDbEJFLHlCQUFxQixDQUFDO0FBQ3RCa0MsdUJBQW1CLENBQUM7QUFDcEJoQyx5QkFBcUIsQ0FBQztBQUN0QmtCLHlCQUFxQixFQUFFO0FBQUEsRUFDekI7QUFJQSxRQUFNZ0UsbUJBQW1CLFlBQVk7QUFDbkMsUUFBSSxDQUFDekUsZUFBZ0I7QUFDckIsUUFBSTtBQUNGLFlBQU03RSxJQUFJdUosS0FBSyw2QkFBNkIxRSxlQUFlOEQsUUFBUSxJQUFJO0FBQUEsUUFDckVhLGNBQWM7QUFBQSxRQUNkQyxjQUFjNUUsZUFBZTRFO0FBQUFBLFFBQzdCQyxZQUFZN0UsZUFBZTZFO0FBQUFBLFFBQzNCQyxnQkFBZ0I5RSxlQUFlOEU7QUFBQUEsUUFDL0JDLHFCQUFxQi9FLGVBQWUrRTtBQUFBQSxRQUNwQ0MsbUJBQW1CaEYsZUFBZWdGO0FBQUFBLFFBQ2xDQyxxQkFBcUJqRixlQUFlaUY7QUFBQUEsUUFDcENqQixvQkFBb0JoRSxlQUFlZ0U7QUFBQUEsUUFDbkNELFlBQVkvRCxlQUFlK0Q7QUFBQUEsUUFDM0JtQiw0QkFBNEJsRixlQUFla0Y7QUFBQUEsUUFDM0NDLHdCQUF3Qm5GLGVBQWVtRjtBQUFBQSxRQUN2Q0MsMEJBQTBCcEYsZUFBZW9GO0FBQUFBLE1BQzNDLENBQUM7QUFDRDVKLGNBQVE2SixRQUFRLDhCQUE4QjtBQUM5Q3RGLHdCQUFrQixLQUFLO0FBQ3ZCa0QscUJBQWU7QUFBQSxJQUNqQixTQUFTSSxLQUFLO0FBQ1o3SCxjQUFROEgsTUFBTSwwQkFBMEI7QUFBQSxJQUMxQztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0MsYUFBYSxZQUFZO0FBQzdCLFFBQUksQ0FBQzFHLGNBQWUsUUFBT3BELFFBQVErSixRQUFRLGdCQUFnQjtBQUUzRCxRQUFJO0FBQ0Y5RixnQkFBVSxJQUFJO0FBQ2QsWUFBTStGLG9CQUFvQnZELHFCQUFxQnJELGFBQWE7QUFFNUQsWUFBTXpELElBQUl1SixLQUFLLDZCQUE2QjlGLGNBQWNpRixHQUFHLElBQUk7QUFBQSxRQUMvRGMsY0FBYztBQUFBLFFBQ2RDLGNBQWM5RjtBQUFBQSxRQUNkK0YsWUFBWTdGO0FBQUFBLFFBQ1o4RixnQkFBZ0I1RjtBQUFBQSxRQUNoQjZGLHFCQUFxQjNGO0FBQUFBLFFBQ3JCNEYsbUJBQW1CMUQ7QUFBQUEsUUFDbkIyRCxxQkFBcUIzRjtBQUFBQSxRQUNyQjBFLG9CQUFvQndCO0FBQUFBLFFBQ3BCekIsWUFBWW5GLGNBQWNtRjtBQUFBQSxRQUMxQjBCLG9CQUFvQmpGO0FBQUFBLFFBQ3BCMEUsNEJBQTRCbEU7QUFBQUEsUUFDNUJtRSx3QkFBd0JqRTtBQUFBQSxRQUN4QmtFLDBCQUEwQmhFO0FBQUFBLE1BRTVCLENBQUM7QUFFRDVGLGNBQVE2SixRQUFRLDRCQUE0QjtBQUM1Q3BDLHFCQUFlO0FBQ2ZwRSx1QkFBaUIsSUFBSTtBQUNyQkUscUJBQWUsQ0FBQztBQUNoQkUsbUJBQWEsQ0FBQztBQUNkRSx1QkFBaUIsQ0FBQztBQUNsQkUsMkJBQXFCLENBQUM7QUFDdEJFLDJCQUFxQixDQUFDO0FBQ3RCa0IsMkJBQXFCLEVBQUU7QUFDdkJGLG1CQUFhLFNBQVM7QUFBQSxJQUN4QixTQUFTOEMsS0FBSztBQUNacUMsY0FBUXBDLE1BQU1ELEdBQUc7QUFDakI3SCxjQUFROEgsTUFBTSx3QkFBd0I7QUFBQSxJQUN4QyxVQUFDO0FBQ0M3RCxnQkFBVSxLQUFLO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTWtHLGlCQUFpQkEsQ0FBQ0MsUUFBUTtBQUM5QixVQUFNQyxZQUFZbkgsT0FBT2lGLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsUUFBUStCLElBQUk5QixRQUFRO0FBQ3pENEIsWUFBUUksSUFBSXBILFFBQVFrSCxLQUFLQSxJQUFJOUIsVUFBVSxvQkFBb0I7QUFDM0Q3RCxzQkFBa0I7QUFBQSxNQUNoQixHQUFHMkY7QUFBQUE7QUFBQUEsTUFHSDVCLG9CQUNFK0IsT0FBT0YsV0FBVzVCLG1CQUFtQixLQUNyQzhCLE9BQU9GLFdBQVd6QixrQkFBa0IsS0FDcEMyQixPQUFPRixXQUFXeEIsaUJBQWlCLEtBQ25DO0FBQUEsTUFFRkoscUJBQXFCOEIsT0FBT0YsV0FBVzVCLHVCQUF1QixDQUFDO0FBQUEsTUFDL0RHLG9CQUFvQjJCLE9BQU9GLFdBQVd6QixzQkFBc0IsQ0FBQztBQUFBLE1BQzdEQyxtQkFBbUIwQixPQUFPRixXQUFXeEIscUJBQXFCLENBQUM7QUFBQSxNQUUzRFUscUJBQXFCYSxJQUFJYix1QkFBdUI7QUFBQSxNQUNoREUscUJBQXFCVyxJQUFJWCx1QkFBdUI7QUFBQSxNQUVoREMsNEJBQTRCVSxJQUFJViw4QkFBOEI7QUFBQSxNQUM5REMsd0JBQXdCUyxJQUFJVCwwQkFBMEI7QUFBQSxNQUN0REMsMEJBQTBCUSxJQUFJUiw0QkFBNEI7QUFBQSxJQUM1RCxDQUFDO0FBRURyRixzQkFBa0IsSUFBSTtBQUFBLEVBQ3hCO0FBS0EsUUFBTWlHLHVCQUF1QkEsTUFBTTtBQUNqQyxVQUFNQyxTQUFTN0YsVUFBVThGLGVBQWU7QUFDeEMsVUFBTWhFLFVBQVVDLFlBQWE4RCxPQUFPakMscUJBQXFCaUMsT0FBT3JCLGVBQWdCLEtBQUt4QyxRQUFRLENBQUMsQ0FBQztBQUMvRmhDLGNBQVUrRixlQUFlLEVBQUVyQixnQkFBZ0I1QyxRQUFRLENBQUM7QUFBQSxFQUN0RDtBQUVBLFFBQU1rRSxrQkFBa0JBLE1BQU07QUFDNUJ4RixrQkFBY3lGLGVBQWUsRUFBRUMsS0FBSyxDQUFBTCxXQUFVO0FBQzVDLFlBQU1NLFlBQVk7QUFBQSxRQUNoQkMsSUFBSUMsS0FBS0MsSUFBSTtBQUFBLFFBQ2JDLE1BQU1WLE9BQU9XO0FBQUFBLFFBQ2JDLE1BQU1aLE9BQU9hO0FBQUFBLFFBQ2JDLFFBQVFkLE9BQU9lO0FBQUFBLFFBQ2ZDLE1BQU1oQixPQUFPaUI7QUFBQUEsUUFDYkMsYUFBYWxCLE9BQU9tQjtBQUFBQSxNQUN0QjtBQUNBM0csMkJBQXFCLENBQUMsR0FBR0QsbUJBQW1CK0YsU0FBUyxDQUFDO0FBQ3REM0Ysb0JBQWN5RyxZQUFZO0FBQzFCMUcsOEJBQXdCLEtBQUs7QUFDN0JuRixjQUFRNkosUUFBUSxzQ0FBc0M7QUFBQSxJQUN4RCxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1pQyx5QkFBeUJBLENBQUNkLE9BQU87QUFDckMvRix5QkFBcUJELGtCQUFrQitHLE9BQU8sQ0FBQUMsV0FBVUEsT0FBT2hCLE9BQU9BLEVBQUUsQ0FBQztBQUN6RWhMLFlBQVE2SixRQUFRLDZCQUE2QjtBQUFBLEVBQy9DO0FBRUEsUUFBTW9DLG9CQUFvQi9ILGdCQUFnQjZIO0FBQUFBLElBQU8sQ0FBQXJGLFlBQy9DQSxRQUFRNkIsV0FBV3BCLFlBQVksRUFBRUwsU0FBU3pCLFdBQVc4QixZQUFZLENBQUM7QUFBQSxFQUNwRTtBQUVBLFFBQU0rRSxVQUFVO0FBQUEsSUFDZDtBQUFBLE1BQ0VDLE9BQU87QUFBQSxNQUNQQyxRQUFRQSxDQUFDQyxHQUFHQyxJQUFJQyxNQUNkLHVCQUFDLFNBQUksT0FBTztBQUFBLFFBQ1ZDLE9BQU87QUFBQSxRQUNQQyxRQUFRO0FBQUEsUUFDUkMsY0FBYztBQUFBLFFBQ2RDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsWUFBWTtBQUFBLFFBQ1pDLGdCQUFnQjtBQUFBLFFBQ2hCQyxPQUFPO0FBQUEsUUFDUEMsWUFBWTtBQUFBLFFBQ1pDLFVBQVU7QUFBQSxNQUNaLEdBQ0dDLGlCQUFPWCxJQUFJLENBQUMsRUFBRVksU0FBUyxHQUFHLEdBQUcsS0FaaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFFRlgsT0FBTztBQUFBLE1BQ1BZLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VqQixPQUFPO0FBQUEsTUFDUGtCLFdBQVc7QUFBQSxNQUNYakIsUUFBUUEsQ0FBQ2tCLFNBQ1AsdUJBQUMsU0FBSSxPQUFPLEVBQUVWLFNBQVMsUUFBUUMsWUFBWSxTQUFTLEdBQ2xEO0FBQUEsK0JBQUMsVUFBTyxPQUFPO0FBQUEsVUFDYlUsaUJBQWlCO0FBQUEsVUFDakJDLGFBQWE7QUFBQSxVQUNiUixZQUFZO0FBQUEsUUFDZCxHQUNHTSxlQUFLRyxPQUFPLENBQUMsRUFBRUMsWUFBWSxLQUw5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFFBQUssUUFBTSxNQUFDLE9BQU8sRUFBRVQsVUFBVSxRQUFRRixPQUFPLFVBQVUsR0FBSU8sa0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxXQVJwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxJQUVKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBa0JBO0FBQUEsTUFDRW5CLE9BQU87QUFBQSxNQUNQa0IsV0FBVztBQUFBLE1BQ1hELE9BQU87QUFBQSxNQUNQaEIsUUFBUUEsQ0FBQ3VCLE1BQ1A7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNBO0FBQUFBLFVBQ1QsTUFBSztBQUFBLFVBQ0wsYUFBYTtBQUFBLFlBQ1gsTUFBTTtBQUFBLFlBQ04sUUFBUTtBQUFBLFVBQ1Y7QUFBQSxVQUNBLFFBQVEsTUFBTSxHQUFHQSxDQUFDO0FBQUE7QUFBQSxRQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPd0I7QUFBQSxJQUc1QjtBQUFBLElBQ0E7QUFBQSxNQUNFeEIsT0FBTztBQUFBLE1BQ1BrQixXQUFXO0FBQUEsTUFDWEQsT0FBTztBQUFBLE1BQ1BoQixRQUFRQSxDQUFDdUIsTUFDUCx1QkFBQyxTQUFJLE9BQU87QUFBQSxRQUNWaEIsWUFBWTtBQUFBLFFBQ1ppQixTQUFTO0FBQUEsUUFDVGxCLGNBQWM7QUFBQSxRQUNkRSxTQUFTO0FBQUEsTUFDWCxHQUNFLGlDQUFDLFFBQUssT0FBTyxFQUFFRyxPQUFPLFdBQVdDLFlBQVksT0FBT0MsVUFBVSxPQUFPLEdBQUc7QUFBQTtBQUFBLFFBQ3BFMUMsT0FBT29ELEtBQUssQ0FBQyxFQUFFRSxlQUFlLE9BQU87QUFBQSxXQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxJQUVKO0FBQUEsSUFDQTtBQUFBLE1BQ0UxQixPQUFPO0FBQUEsTUFDUGtCLFdBQVc7QUFBQSxNQUNYRCxPQUFPO0FBQUEsTUFDUGhCLFFBQVFBLENBQUN1QixNQUNQLHVCQUFDLFNBQUksT0FBTztBQUFBLFFBQ1ZoQixZQUFZO0FBQUEsUUFDWmlCLFNBQVM7QUFBQSxRQUNUbEIsY0FBYztBQUFBLFFBQ2RFLFNBQVM7QUFBQSxNQUNYLEdBQ0UsaUNBQUMsUUFBSyxPQUFPLEVBQUVHLE9BQU8sV0FBV0MsWUFBWSxPQUFPQyxVQUFVLE9BQU8sR0FBRztBQUFBO0FBQUEsUUFDcEUxQyxPQUFPb0QsS0FBSyxDQUFDLEVBQUVFLGVBQWUsT0FBTztBQUFBLFdBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLElBRUo7QUFBQSxJQUNBO0FBQUEsTUFDRTFCLE9BQU87QUFBQSxNQUNQa0IsV0FBVztBQUFBLE1BQ1hELE9BQU87QUFBQSxNQUNQaEIsUUFBUUEsQ0FBQ3VCLE1BQ1AsdUJBQUMsT0FBSSxPQUFNLFVBQVMsT0FBTyxFQUFFWCxZQUFZLE9BQU9DLFVBQVUsT0FBTyxHQUM5RFU7QUFBQUE7QUFBQUEsUUFBRTtBQUFBLFdBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFXQTtBQUFBLE1BQ0V4QixPQUFPO0FBQUEsTUFDUGlCLE9BQU87QUFBQSxNQUNQWixPQUFPO0FBQUEsTUFDUHNCLE9BQU87QUFBQSxNQUNQMUIsUUFBUUEsQ0FBQ0MsR0FBR2pDLFFBQ1Y7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBLFVBQ25CLFNBQVMsTUFBTUQsZUFBZUMsR0FBRztBQUFBLFVBQ2pDLE9BQU87QUFBQSxZQUNMc0MsY0FBYztBQUFBLFlBQ2RNLFlBQVk7QUFBQSxZQUNaUCxRQUFRO0FBQUEsWUFDUkUsWUFBWTtBQUFBLFlBQ1pvQixRQUFRO0FBQUEsVUFDVjtBQUFBLFVBQUU7QUFBQTtBQUFBLFFBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BYUE7QUFBQSxJQUVKO0FBQUEsRUFBQztBQUdILFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFUixpQkFBaUIsV0FBV1MsV0FBVyxRQUFRLEdBQ2xGO0FBQUEsMkJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsSUFDZix1QkFBQyxTQUFJLE9BQU8sRUFBRUMsTUFBTSxFQUFFLEdBQ3JCO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNJLDZCQUE2QjdIO0FBQUFBLFVBQzdCLFlBQVk7QUFBQTtBQUFBLFFBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVzQjtBQUFBLE1BRXJCLHVCQUFDLFNBQUksT0FBTyxFQUFFd0gsU0FBUyxhQUFhTSxXQUFXLE9BQU8sR0FJcEQ7QUFBQSwrQkFBQyxTQUFJLE9BQU87QUFBQSxVQUNWQyxjQUFjO0FBQUEsVUFDZHhCLFlBQVk7QUFBQSxVQUNaRCxjQUFjO0FBQUEsVUFDZGtCLFNBQVM7QUFBQSxVQUNUUSxXQUFXO0FBQUEsVUFDWEMsVUFBVTtBQUFBLFVBQ1ZDLFVBQVU7QUFBQSxRQUNaLEdBQ0U7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUQsVUFBVSxZQUFZRSxLQUFLLEdBQUdDLE9BQU8sR0FBRy9CLFFBQVEsUUFBUUQsT0FBTyxPQUFPRyxZQUFZLDRCQUE0QjhCLFdBQVcsZ0JBQWdCLEtBQXZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBKO0FBQUEsVUFDMUosdUJBQUMsU0FBSSxPQUFPLEVBQUVKLFVBQVUsWUFBWUssUUFBUSxFQUFFLEdBQzVDLGlDQUFDLFNBQUksT0FBTyxFQUFFOUIsU0FBUyxRQUFRQyxZQUFZLFVBQVVzQixjQUFjLE9BQU8sR0FDeEU7QUFBQSxtQ0FBQyxTQUFJLE9BQU87QUFBQSxjQUNWM0IsT0FBTztBQUFBLGNBQ1BDLFFBQVE7QUFBQSxjQUNSQyxjQUFjO0FBQUEsY0FDZEMsWUFBWTtBQUFBLGNBQ1pDLFNBQVM7QUFBQSxjQUNUQyxZQUFZO0FBQUEsY0FDWkMsZ0JBQWdCO0FBQUEsY0FDaEJVLGFBQWE7QUFBQSxjQUNibUIsZ0JBQWdCO0FBQUEsWUFDbEIsR0FDRSxpQ0FBQyxtQkFBZ0IsT0FBTyxFQUFFMUIsVUFBVSxRQUFRRixPQUFPLFVBQVUsS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0QsS0FYakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQyxpQ0FBQyxTQUFNLE9BQU8sR0FBRyxPQUFPLEVBQUU2QixRQUFRLEdBQUc1QixZQUFZLE9BQU9ELE9BQU8sV0FBV0UsVUFBVSxPQUFPLEdBQUcsZ0NBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkEsS0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxhQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsUUFDUDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQzBCLE1BQUs7QUFBQSxZQUVMLFNBQVMsTUFBTWhLLFNBQVMsa0JBQWtCO0FBQUEsWUFDMUMsT0FBTyxFQUFFa0wsY0FBYyxHQUFHO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFKdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT3lCO0FBQUEsUUFDbEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU87QUFBQSxjQUNMekIsY0FBYztBQUFBLGNBQ2RxQixRQUFRO0FBQUEsY0FDUkssV0FBVztBQUFBLGNBQ1hELGNBQWM7QUFBQSxjQUNkRyxVQUFVO0FBQUEsWUFDWjtBQUFBLFlBQ0EsV0FBVyxFQUFFVixTQUFTLEVBQUU7QUFBQSxZQUV4QjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVc5STtBQUFBQSxnQkFDWCxVQUFVQztBQUFBQSxnQkFDVixPQUFPLEVBQUVvSixjQUFjLEVBQUU7QUFBQSxnQkFDekIsYUFBYTtBQUFBLGtCQUNYUyxRQUFRO0FBQUEsa0JBQ1JoQixTQUFTO0FBQUEsa0JBQ1RqQixZQUFZO0FBQUEsa0JBQ1prQyxjQUFjO0FBQUEsZ0JBQ2hCO0FBQUEsZ0JBRUE7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxLQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFakMsU0FBUyxRQUFRQyxZQUFZLFNBQVMsR0FDbkQ7QUFBQSwrQ0FBQyxtQkFBZ0IsT0FBTyxFQUFFVyxhQUFhLE1BQU0sS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0M7QUFBQSx3QkFBRztBQUFBLDJCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBSUYsaUNBQUMsU0FBSSxPQUFPLEVBQUVJLFNBQVMsUUFBUWpCLFlBQVksVUFBVSxHQUVuRDtBQUFBLCtDQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQUFHLE9BQU8sRUFBRXdCLGNBQWMsT0FBTyxHQUNuRDtBQUFBLGlEQUFDLE9BQUksSUFBSSxJQUFJLElBQUksR0FDZixpQ0FBQyxRQUFLLE9BQU87QUFBQSw0QkFDWHpCLGNBQWM7QUFBQSw0QkFDZHFCLFFBQVE7QUFBQSw0QkFDUnBCLFlBQVk7QUFBQSw0QkFDWkYsUUFBUTtBQUFBLDRCQUNSMkIsV0FBVztBQUFBLDRCQUNYRSxVQUFVO0FBQUEsNEJBQ1ZELFVBQVU7QUFBQSwwQkFDWixHQUNFO0FBQUEsbURBQUMsU0FBSSxPQUFPLEVBQUVBLFVBQVUsWUFBWUUsS0FBSyxHQUFHQyxPQUFPLEdBQUcvQixRQUFRLFFBQVFELE9BQU8sT0FBT0csWUFBWSw0QkFBNEI4QixXQUFXLGdCQUFnQixLQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUEwSjtBQUFBLDRCQUMxSix1QkFBQyxTQUFJLE9BQU8sRUFBRUosVUFBVSxZQUFZSyxRQUFRLEdBQUdkLFNBQVMsT0FBTyxHQUM3RDtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxPQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFYixPQUFPLDRCQUE0QkUsVUFBVSxRQUFRRCxZQUFZLE1BQU0sR0FBRyw0QkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBLGdDQUVGLE9BQU85SixPQUFPNEw7QUFBQUEsZ0NBQ2QsUUFBUSx1QkFBQyxnQkFBYSxPQUFPLEVBQUUvQixPQUFPLDRCQUE0QkUsVUFBVSxPQUFPLEtBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQTZFO0FBQUEsZ0NBQ3JGLFlBQVksRUFBRUYsT0FBTyxXQUFXQyxZQUFZLE9BQU9DLFVBQVUsT0FBTztBQUFBO0FBQUEsOEJBUnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFRd0UsS0FUMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FXQTtBQUFBLCtCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXNCQSxLQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXdCQTtBQUFBLDBCQUNBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksR0FDZixpQ0FBQyxRQUFLLE9BQU87QUFBQSw0QkFDWFAsY0FBYztBQUFBLDRCQUNkcUIsUUFBUTtBQUFBLDRCQUNScEIsWUFBWTtBQUFBLDRCQUNaRixRQUFRO0FBQUEsNEJBQ1IyQixXQUFXO0FBQUEsNEJBQ1hFLFVBQVU7QUFBQSw0QkFDVkQsVUFBVTtBQUFBLDBCQUNaLEdBQ0U7QUFBQSxtREFBQyxTQUFJLE9BQU8sRUFBRUEsVUFBVSxZQUFZRSxLQUFLLEdBQUdDLE9BQU8sR0FBRy9CLFFBQVEsUUFBUUQsT0FBTyxPQUFPRyxZQUFZLDRCQUE0QjhCLFdBQVcsZ0JBQWdCLEtBQXZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQTBKO0FBQUEsNEJBQzFKLHVCQUFDLFNBQUksT0FBTyxFQUFFSixVQUFVLFlBQVlLLFFBQVEsR0FBR2QsU0FBUyxPQUFPLEdBQzdEO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLE9BQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUViLE9BQU8sNEJBQTRCRSxVQUFVLFFBQVFELFlBQVksTUFBTSxHQUFHLGdDQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsZ0NBRUYsT0FBTzlJLGdCQUFnQjRLO0FBQUFBLGdDQUN2QixRQUFRLHVCQUFDLG9CQUFpQixPQUFPLEVBQUUvQixPQUFPLDRCQUE0QkUsVUFBVSxPQUFPLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQWlGO0FBQUEsZ0NBQ3pGLFlBQVksRUFBRUYsT0FBTyxXQUFXQyxZQUFZLE9BQU9DLFVBQVUsT0FBTztBQUFBO0FBQUEsOEJBUnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFRd0UsS0FUMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FXQTtBQUFBLCtCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXNCQSxLQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXdCQTtBQUFBLDBCQUNBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksR0FDZixpQ0FBQyxRQUFLLE9BQU87QUFBQSw0QkFDWFAsY0FBYztBQUFBLDRCQUNkcUIsUUFBUTtBQUFBLDRCQUNScEIsWUFBWTtBQUFBLDRCQUNaRixRQUFRO0FBQUEsNEJBQ1IyQixXQUFXO0FBQUEsNEJBQ1hFLFVBQVU7QUFBQSw0QkFDVkQsVUFBVTtBQUFBLDBCQUNaLEdBQ0U7QUFBQSxtREFBQyxTQUFJLE9BQU8sRUFBRUEsVUFBVSxZQUFZRSxLQUFLLEdBQUdDLE9BQU8sR0FBRy9CLFFBQVEsUUFBUUQsT0FBTyxPQUFPRyxZQUFZLDRCQUE0QjhCLFdBQVcsZ0JBQWdCLEtBQXZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQTBKO0FBQUEsNEJBQzFKLHVCQUFDLFNBQUksT0FBTyxFQUFFSixVQUFVLFlBQVlLLFFBQVEsR0FBR2QsU0FBUyxPQUFPLEdBQzdEO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLE9BQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUViLE9BQU8sNEJBQTRCRSxVQUFVLFFBQVFELFlBQVksTUFBTSxHQUFHLDZCQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsZ0NBRUYsUUFBTztBQUFBLGdDQUNQLE9BQU85SSxnQkFBZ0I0SyxTQUFTLEtBQzNCNUssZ0JBQWdCNkssT0FBTyxDQUFDQyxLQUFLL0csTUFBTStHLE9BQU8vRyxFQUFFc0IsdUJBQXVCLElBQUksQ0FBQyxJQUFJckYsZ0JBQWdCNEssUUFBUWxJLFFBQVEsQ0FBQyxJQUM5RztBQUFBLGdDQUNKLFlBQVksRUFBRW1HLE9BQU8sV0FBV0MsWUFBWSxPQUFPQyxVQUFVLE9BQU87QUFBQTtBQUFBLDhCQVZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBVXdFLEtBWDFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBYUE7QUFBQSwrQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0F3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0EwQkE7QUFBQSw2QkE3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkE4RUE7QUFBQSx3QkFHQSx1QkFBQyxRQUFLLE9BQU87QUFBQSwwQkFDWFAsY0FBYztBQUFBLDBCQUNkcUIsUUFBUTtBQUFBLDBCQUNSSyxXQUFXO0FBQUEsMEJBQ1hELGNBQWM7QUFBQSwwQkFDZHhCLFlBQVk7QUFBQSx3QkFDZCxHQUNFLGlDQUFDLFNBQUksT0FBTyxFQUFFaUIsU0FBUyxZQUFZLEdBQ2pDO0FBQUEsaURBQUMsU0FBTSxPQUFPLEdBQUcsT0FBTztBQUFBLDRCQUN0Qk0sV0FBVztBQUFBLDRCQUNYQyxjQUFjO0FBQUEsNEJBQ2RwQixPQUFPO0FBQUEsNEJBQ1BDLFlBQVk7QUFBQSw0QkFDWkMsVUFBVTtBQUFBLDRCQUNWTCxTQUFTO0FBQUEsNEJBQ1RDLFlBQVk7QUFBQSwwQkFDZCxHQUNFO0FBQUEsbURBQUMsZ0JBQWEsT0FBTyxFQUFFVyxhQUFhLE9BQU9ULE9BQU8sVUFBVSxLQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUE4RDtBQUFBLDRCQUFHO0FBQUEsK0JBVG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBV0E7QUFBQSwwQkFDQSx1QkFBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FBRyxPQUFNLFVBQzNCO0FBQUEsbURBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkI7QUFBQSxxREFBQyxTQUFJLE9BQU8sRUFBRW9CLGNBQWMsTUFBTSxHQUNoQztBQUFBLHVEQUFDLFFBQUssUUFBTSxNQUFDLE9BQU8sRUFBRXBCLE9BQU8sV0FBV0UsVUFBVSxPQUFPLEdBQUcsMEJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxnQ0FDQSx1QkFBQyxRQUFLLE1BQUssVUFBUyxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBc0I7QUFBQSxtQ0FKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FLQTtBQUFBLDhCQUNBO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLE9BQU8sRUFBRVQsT0FBTyxPQUFPO0FBQUEsa0NBQ3ZCLGFBQVk7QUFBQSxrQ0FDWixTQUFTLENBQUN0SixPQUFPNEw7QUFBQUEsa0NBQ2pCLFVBQVVoRztBQUFBQSxrQ0FDVixPQUFPMUYsZUFBZWlGO0FBQUFBLGtDQUN0QixNQUFLO0FBQUEsa0NBQ0w7QUFBQSxrQ0FDQSxrQkFBaUI7QUFBQSxrQ0FFaEJuRixpQkFBTzhFO0FBQUFBLG9DQUFJLENBQUNJLE1BQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUVDLEtBQ2pDRCxZQUFFRyxjQURlSCxFQUFFQyxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQUVBO0FBQUEsa0NBQ0Q7QUFBQTtBQUFBLGdDQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFlQTtBQUFBLGlDQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQXVCQTtBQUFBLDRCQUVDakYsaUJBQ0MsdUJBQUMsT0FBSSxJQUFJLElBQ1AsaUNBQUMsU0FBSSxPQUFPLEVBQUV3SixTQUFTLFFBQVFxQyxLQUFLLFFBQVF6QyxPQUFPLE9BQU8sR0FHeEQ7QUFBQSxxREFBQyxTQUFJLE9BQU8sRUFBRXlCLE1BQU0sRUFBRSxHQUNwQjtBQUFBLHVEQUFDLFNBQUksT0FBTyxFQUFFRSxjQUFjLE1BQU0sR0FDaEMsaUNBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyx1QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBSUE7QUFBQSxnQ0FDQTtBQUFBLGtDQUFDO0FBQUE7QUFBQSxvQ0FDQyxPQUFPO0FBQUEsc0NBQ0xXLFNBQVM7QUFBQSxzQ0FDVGpCLFlBQVk7QUFBQSxzQ0FDWm9CLFFBQVE7QUFBQSxzQ0FDUnJCLGNBQWM7QUFBQSxzQ0FDZE0sWUFBWTtBQUFBLHNDQUNaQyxVQUFVO0FBQUEsc0NBQ1ZGLE9BQU87QUFBQSxvQ0FDVDtBQUFBLG9DQUFFO0FBQUE7QUFBQSxzQ0FFQXhDLE9BQU9uSCxjQUFjcUYsdUJBQXVCLENBQUMsRUFBRW9GLGVBQWUsT0FBTztBQUFBO0FBQUE7QUFBQSxrQ0FYekU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQVlBO0FBQUEsbUNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBbUJBO0FBQUEsOEJBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVJLE1BQU0sRUFBRSxHQUNwQjtBQUFBLHVEQUFDLFNBQUksT0FBTyxFQUFFRSxjQUFjLE1BQU0sR0FDaEMsaUNBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyxzQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBSUE7QUFBQSxnQ0FDQTtBQUFBLGtDQUFDO0FBQUE7QUFBQSxvQ0FDQyxPQUFPO0FBQUEsc0NBQ0xXLFNBQVM7QUFBQSxzQ0FDVGpCLFlBQVk7QUFBQSxzQ0FDWm9CLFFBQVE7QUFBQSxzQ0FDUnJCLGNBQWM7QUFBQSxzQ0FDZE0sWUFBWTtBQUFBLHNDQUNaQyxVQUFVO0FBQUEsc0NBQ1ZGLE9BQU87QUFBQSxvQ0FDVDtBQUFBLG9DQUFFO0FBQUE7QUFBQSxzQ0FFQXhDLE9BQU9uSCxjQUFjd0Ysc0JBQXNCLENBQUMsRUFBRWlGLGVBQWUsT0FBTztBQUFBO0FBQUE7QUFBQSxrQ0FYeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQVlBO0FBQUEsbUNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBbUJBO0FBQUEsOEJBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVJLE1BQU0sRUFBRSxHQUNwQjtBQUFBLHVEQUFDLFNBQUksT0FBTyxFQUFFRSxjQUFjLE1BQU0sR0FDaEMsaUNBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyxxQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBSUE7QUFBQSxnQ0FDQTtBQUFBLGtDQUFDO0FBQUE7QUFBQSxvQ0FDQyxPQUFPO0FBQUEsc0NBQ0xXLFNBQVM7QUFBQSxzQ0FDVGpCLFlBQVk7QUFBQSxzQ0FDWm9CLFFBQVE7QUFBQSxzQ0FDUnJCLGNBQWM7QUFBQSxzQ0FDZE0sWUFBWTtBQUFBLHNDQUNaQyxVQUFVO0FBQUEsc0NBQ1ZGLE9BQU87QUFBQSxvQ0FDVDtBQUFBLG9DQUFFO0FBQUE7QUFBQSxzQ0FFQXhDLE9BQU9uSCxjQUFjeUYscUJBQXFCLENBQUMsRUFBRWdGLGVBQWUsT0FBTztBQUFBO0FBQUE7QUFBQSxrQ0FYdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQVlBO0FBQUEsbUNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBbUJBO0FBQUEsaUNBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBb0VBLEtBckVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBc0VBO0FBQUEsK0JBakdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBcUdBO0FBQUEsNkJBbEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBbUhBLEtBMUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBMkhBO0FBQUEsd0JBRUMsQ0FBQzdILGtCQUNBLG1DQUNHVCw2QkFDQyxtQ0FFRTtBQUFBLGlEQUFDLFFBQUssT0FBTztBQUFBLDRCQUNYbUgsY0FBYztBQUFBLDRCQUNkcUIsUUFBUTtBQUFBLDRCQUNSSyxXQUFXO0FBQUEsNEJBQ1hELGNBQWM7QUFBQSw0QkFDZHhCLFlBQVk7QUFBQSw0QkFDWjJCLFVBQVU7QUFBQSwwQkFDWixHQUNFO0FBQUEsbURBQUMsU0FBSSxPQUFPO0FBQUEsOEJBQ1YzQixZQUFZO0FBQUEsOEJBQ1ppQixTQUFTO0FBQUEsOEJBQ1RpQixjQUFjO0FBQUEsNEJBQ2hCLEdBQ0UsaUNBQUMsU0FBTSxPQUFPLEdBQUcsT0FBTztBQUFBLDhCQUN0QkQsUUFBUTtBQUFBLDhCQUNSN0IsT0FBTztBQUFBLDhCQUNQQyxZQUFZO0FBQUEsOEJBQ1pDLFVBQVU7QUFBQSw4QkFDVkwsU0FBUztBQUFBLDhCQUNUQyxZQUFZO0FBQUEsNEJBQ2QsR0FDRTtBQUFBLHFEQUFDLHVCQUFvQixPQUFPLEVBQUVXLGFBQWEsTUFBTSxLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUFtRDtBQUFBLDhCQUFHO0FBQUEsaUNBUnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBVUEsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQWdCQTtBQUFBLDRCQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFSSxTQUFTLE9BQU8sR0FDNUIsaUNBQUMsT0FBSSxRQUFRLENBQUMsSUFBSSxFQUFFLEdBQ2xCO0FBQUEscURBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkI7QUFBQSx1REFBQyxTQUFJLE9BQU8sRUFBRU8sY0FBYyxNQUFNLEdBQ2hDO0FBQUEseURBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyxxQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FFQTtBQUFBLGtDQUNBLHVCQUFDLFFBQUssTUFBSyxVQUFTLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUFzQjtBQUFBLHFDQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUtBO0FBQUEsZ0NBQ0E7QUFBQSxrQ0FBQztBQUFBO0FBQUEsb0NBQ0MsT0FBTyxFQUFFVCxPQUFPLE9BQU87QUFBQSxvQ0FDdkIsS0FBSztBQUFBLG9DQUNMLE9BQU8xSTtBQUFBQSxvQ0FDUCxVQUFVQztBQUFBQSxvQ0FDVixNQUFLO0FBQUEsb0NBQ0wsYUFBWTtBQUFBO0FBQUEsa0NBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQU1vQztBQUFBLG1DQWJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQWVBO0FBQUEsOEJBQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkI7QUFBQSx1REFBQyxTQUFJLE9BQU8sRUFBRW9LLGNBQWMsTUFBTSxHQUNoQztBQUFBLHlEQUFDLFFBQUssUUFBTSxNQUFDLE9BQU8sRUFBRXBCLE9BQU8sV0FBV0UsVUFBVSxPQUFPLEdBQUcsaUNBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUNBRUE7QUFBQSxrQ0FDQSx1QkFBQyxRQUFLLE1BQUssVUFBUyxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FBc0I7QUFBQSxxQ0FKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FLQTtBQUFBLGdDQUNBO0FBQUEsa0NBQUM7QUFBQTtBQUFBLG9DQUNDLE9BQU8sRUFBRVQsT0FBTyxPQUFPO0FBQUEsb0NBQ3ZCLEtBQUs7QUFBQSxvQ0FDTCxLQUFLO0FBQUEsb0NBQ0wsT0FBTzFHO0FBQUFBLG9DQUNQLFVBQVUsQ0FBQ29KLFFBQVE7QUFDakJuSix5REFBbUJtSixPQUFPLENBQUM7QUFDM0IsMENBQUk5TCxlQUFlO0FBQ2pCLDhDQUFNbUksU0FBUzlFLHFCQUFxQnJELGFBQWE7QUFDakQsOENBQU0rTCxVQUFVNUQsU0FBUyxJQUFJNUUsWUFBYTRFLFVBQVUyRCxPQUFPLEtBQU0sS0FBS3RJLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDcEYvQyw2REFBcUJzTCxPQUFPO0FBQUEsc0NBQzlCO0FBQUEsb0NBQ0Y7QUFBQSxvQ0FDQSxNQUFLO0FBQUEsb0NBQ0wsYUFBWTtBQUFBO0FBQUEsa0NBZGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQWMwQjtBQUFBLG1DQXJCNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0F1QkE7QUFBQSw4QkFDQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QjtBQUFBLHVEQUFDLFNBQUksT0FBTyxFQUFFaEIsY0FBYyxNQUFNLEdBQ2hDO0FBQUEseURBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyxtQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FFQTtBQUFBLGtDQUNBLHVCQUFDLFFBQUssTUFBSyxVQUFTLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUFzQjtBQUFBLHFDQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUtBO0FBQUEsZ0NBQ0E7QUFBQSxrQ0FBQztBQUFBO0FBQUEsb0NBQ0MsT0FBTyxFQUFFVCxPQUFPLE9BQU87QUFBQSxvQ0FDdkIsS0FBSztBQUFBLG9DQUNMLE9BQU81STtBQUFBQSxvQ0FDUCxVQUFVLENBQUNzTCxRQUFRO0FBQ2pCckwsMkRBQXFCcUwsT0FBTyxDQUFDO0FBQzdCLDBDQUFJOUwsZUFBZTtBQUNqQiw4Q0FBTW1JLFNBQVM5RSxxQkFBcUJyRCxhQUFhO0FBQ2pELDhDQUFNcUksT0FBT0YsU0FBUyxJQUFJNUUsWUFBYXVJLE9BQU8sS0FBSzNELFNBQVUsR0FBRyxFQUFFM0UsUUFBUSxDQUFDLElBQUk7QUFDL0ViLDJEQUFtQlksV0FBVzhFLElBQUksQ0FBQztBQUFBLHNDQUNyQztBQUFBLG9DQUNGO0FBQUEsb0NBQ0EsTUFBSztBQUFBLG9DQUNMLFdBQVcsQ0FBQW5GLFVBQVMsSUFBSUEsS0FBSyxHQUFHOEksUUFBUSx5QkFBeUIsR0FBRztBQUFBLG9DQUNwRSxRQUFRLENBQUE5SSxVQUFTQSxNQUFNOEksUUFBUSxlQUFlLEVBQUU7QUFBQSxvQ0FDaEQsYUFBWTtBQUFBO0FBQUEsa0NBZmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQWU0QjtBQUFBLG1DQXRCOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0F3QkE7QUFBQSxpQ0FqRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FrRUEsS0FuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FvRUE7QUFBQSwrQkE3RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0E4RkE7QUFBQSwwQkFHQSx1QkFBQyxRQUFLLE9BQU87QUFBQSw0QkFDWDFDLGNBQWM7QUFBQSw0QkFDZHFCLFFBQVE7QUFBQSw0QkFDUkssV0FBVztBQUFBLDRCQUNYRCxjQUFjO0FBQUEsNEJBQ2R4QixZQUFZO0FBQUEsNEJBQ1oyQixVQUFVO0FBQUEsMEJBQ1osR0FDRTtBQUFBLG1EQUFDLFNBQUksT0FBTztBQUFBLDhCQUNWM0IsWUFBWTtBQUFBLDhCQUNaaUIsU0FBUztBQUFBLDhCQUNUaUIsY0FBYztBQUFBLDRCQUNoQixHQUNFLGlDQUFDLFNBQU0sT0FBTyxHQUFHLE9BQU87QUFBQSw4QkFDdEJELFFBQVE7QUFBQSw4QkFDUjdCLE9BQU87QUFBQSw4QkFDUEMsWUFBWTtBQUFBLDhCQUNaQyxVQUFVO0FBQUEsOEJBQ1ZMLFNBQVM7QUFBQSw4QkFDVEMsWUFBWTtBQUFBLDRCQUNkLEdBQ0U7QUFBQSxxREFBQyx1QkFBb0IsT0FBTyxFQUFFVyxhQUFhLE1BQU0sS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBbUQ7QUFBQSw4QkFBRztBQUFBLGlDQVJ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQVVBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FnQkE7QUFBQSw0QkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUksU0FBUyxPQUFPLEdBQzVCLGlDQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQWlCbEI7QUFBQSxxREFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QjtBQUFBLHVEQUFDLFNBQUksT0FBTyxFQUFFTyxjQUFjLE1BQU0sR0FDaEM7QUFBQSx5REFBQyxRQUFLLFFBQU0sTUFBQyxPQUFPLEVBQUVwQixPQUFPLFdBQVdFLFVBQVUsT0FBTyxHQUFHLGdDQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUVBO0FBQUEsa0NBQ0EsdUJBQUMsUUFBSyxNQUFLLFVBQVMsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUNBQXNCO0FBQUEscUNBSnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBS0E7QUFBQSxnQ0FDQTtBQUFBLGtDQUFDO0FBQUE7QUFBQSxvQ0FDQyxPQUFPLEVBQUVULE9BQU8sT0FBTztBQUFBLG9DQUN2QixLQUFLO0FBQUEsb0NBQ0wsS0FBSztBQUFBLG9DQUNMLE9BQU9sSjtBQUFBQSxvQ0FDUCxVQUFVLENBQUM0TCxRQUFRO0FBQ2pCM0wscURBQWUyTCxPQUFPLENBQUM7QUFDdkIsMENBQUk5TCxlQUFlO0FBQ2pCLDhDQUFNbUksU0FBUzlFLHFCQUFxQnJELGFBQWE7QUFDakQsOENBQU1zRCxVQUFVNkUsU0FBUyxJQUFJNUUsWUFBYTRFLFVBQVUyRCxPQUFPLEtBQU0sS0FBS3RJLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDcEZqRCx5REFBaUIrQyxPQUFPO0FBQUEsc0NBQzFCO0FBQUEsb0NBQ0Y7QUFBQSxvQ0FDQSxNQUFLO0FBQUEsb0NBQ0wsYUFBWTtBQUFBO0FBQUEsa0NBZGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQWMwQjtBQUFBLG1DQXJCNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0F1QkE7QUFBQSw4QkFDQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QjtBQUFBLHVEQUFDLFNBQUksT0FBTyxFQUFFeUgsY0FBYyxNQUFNLEdBQ2hDO0FBQUEseURBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyw4QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FFQTtBQUFBLGtDQUNBLHVCQUFDLFFBQUssTUFBSyxVQUFTLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUFzQjtBQUFBLHFDQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUtBO0FBQUEsZ0NBQ0E7QUFBQSxrQ0FBQztBQUFBO0FBQUEsb0NBQ0MsT0FBTyxFQUFFVCxPQUFPLE9BQU87QUFBQSxvQ0FDdkIsS0FBSztBQUFBLG9DQUNMLE9BQU85STtBQUFBQSxvQ0FDUCxVQUFVLENBQUN3TCxRQUFRO0FBQ2pCdkwsdURBQWlCdUwsT0FBTyxDQUFDO0FBQ3pCLDBDQUFJOUwsZUFBZTtBQUNqQiw4Q0FBTW1JLFNBQVM5RSxxQkFBcUJyRCxhQUFhO0FBQ2pELDhDQUFNcUksT0FBT0YsU0FBUyxJQUFJNUUsWUFBYXVJLE9BQU8sS0FBSzNELFNBQVUsR0FBRyxFQUFFM0UsUUFBUSxDQUFDLElBQUk7QUFDL0VyRCx1REFBZW9ELFdBQVc4RSxJQUFJLENBQUM7QUFBQSxzQ0FDakM7QUFBQSxvQ0FDRjtBQUFBLG9DQUNBLE1BQUs7QUFBQSxvQ0FDTCxXQUFXLENBQUFuRixVQUFTLElBQUlBLEtBQUssR0FBRzhJLFFBQVEseUJBQXlCLEdBQUc7QUFBQSxvQ0FDcEUsUUFBUSxDQUFBOUksVUFBU0EsTUFBTThJLFFBQVEsZUFBZSxFQUFFO0FBQUEsb0NBQ2hELGFBQVk7QUFBQTtBQUFBLGtDQWZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FlNEI7QUFBQSxtQ0F0QjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBd0JBO0FBQUEsaUNBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBa0VBLEtBbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBb0VBO0FBQUEsK0JBN0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBOEZBO0FBQUEsMEJBR0E7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsT0FBTztBQUFBLGdDQUNMMUMsY0FBYztBQUFBLGdDQUNkcUIsUUFBUTtBQUFBLGdDQUNSSyxXQUFXO0FBQUEsZ0NBQ1hELGNBQWM7QUFBQSxnQ0FDZHhCLFlBQVk7QUFBQSxnQ0FDWjJCLFVBQVU7QUFBQSw4QkFDWjtBQUFBLDhCQUVBO0FBQUE7QUFBQSxrQ0FBQztBQUFBO0FBQUEsb0NBQ0MsT0FBTztBQUFBLHNDQUNMM0IsWUFBWTtBQUFBLHNDQUNaaUIsU0FBUztBQUFBLHNDQUNUaUIsY0FBYztBQUFBLG9DQUNoQjtBQUFBLG9DQUVBO0FBQUEsc0NBQUM7QUFBQTtBQUFBLHdDQUNDLE9BQU87QUFBQSx3Q0FDUCxPQUFPO0FBQUEsMENBQ0xELFFBQVE7QUFBQSwwQ0FDUjdCLE9BQU87QUFBQSwwQ0FDUEMsWUFBWTtBQUFBLDBDQUNaQyxVQUFVO0FBQUEsMENBQ1ZMLFNBQVM7QUFBQSwwQ0FDVEMsWUFBWTtBQUFBLHdDQUNkO0FBQUEsd0NBRUE7QUFBQSxpRUFBQyxtQkFBZ0IsT0FBTyxFQUFFVyxhQUFhLE1BQU0sS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpREFBK0M7QUFBQSwwQ0FBRztBQUFBO0FBQUE7QUFBQSxzQ0FYcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQWFBO0FBQUE7QUFBQSxrQ0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQXFCQTtBQUFBLGdDQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFSSxTQUFTLE9BQU8sR0FDNUIsaUNBQUMsT0FBSSxRQUFRLENBQUMsSUFBSSxFQUFFLEdBQ2xCO0FBQUEseURBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkI7QUFBQSwyREFBQyxRQUFLLFFBQU0sTUFBQyx3Q0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQUFxQztBQUFBLG9DQUNyQztBQUFBLHNDQUFDO0FBQUE7QUFBQSx3Q0FDQyxPQUFPLEVBQUVwQixPQUFPLE9BQU87QUFBQSx3Q0FDdkIsS0FBSztBQUFBLHdDQUNMLE9BQU85RztBQUFBQSx3Q0FDUCxVQUFVQztBQUFBQSx3Q0FDVixNQUFLO0FBQUE7QUFBQSxzQ0FMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBS2M7QUFBQSx1Q0FQaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FTQTtBQUFBLGtDQUdBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQ3ZCO0FBQUEsMkRBQUMsUUFBSyxRQUFNLE1BQUMsNENBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FBeUM7QUFBQSxvQ0FDekM7QUFBQSxzQ0FBQztBQUFBO0FBQUEsd0NBQ0MsT0FBTyxFQUFFNkcsT0FBTyxPQUFPO0FBQUEsd0NBQ3ZCLEtBQUs7QUFBQSx3Q0FDTCxLQUFLO0FBQUEsd0NBQ0wsT0FBTzVHO0FBQUFBLHdDQUNQLFVBQVUsQ0FBQ3NKLFFBQVE7QUFDakJySixtRUFBeUJxSixPQUFPLENBQUM7QUFDakMsOENBQUk5TCxlQUFlO0FBQ2pCLGtEQUFNbUksU0FBUzlFLHFCQUFxQnJELGFBQWE7QUFDakQsa0RBQU1zRCxVQUFVNkUsU0FBUyxJQUFJNUUsWUFBYTRFLFVBQVUyRCxPQUFPLEtBQU0sS0FBS3RJLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDcEZuQix1RUFBMkJpQixPQUFPO0FBQUEsMENBQ3BDO0FBQUEsd0NBQ0Y7QUFBQSx3Q0FDQSxNQUFLO0FBQUEsd0NBQ0wsYUFBWTtBQUFBO0FBQUEsc0NBZGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQWMwQjtBQUFBLHVDQWhCNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FrQkE7QUFBQSxrQ0FHQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QjtBQUFBLDJEQUFDLFFBQUssUUFBTSxNQUFDLDhDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBQTJDO0FBQUEsb0NBQzNDO0FBQUEsc0NBQUM7QUFBQTtBQUFBLHdDQUNDLE9BQU8sRUFBRThGLE9BQU8sT0FBTztBQUFBLHdDQUN2QixLQUFLO0FBQUEsd0NBQ0wsT0FBT2hIO0FBQUFBLHdDQUNQLFVBQVUsQ0FBQzBKLFFBQVE7QUFDakJ6SixxRUFBMkJ5SixPQUFPLENBQUM7QUFDbkMsOENBQUk5TCxlQUFlO0FBQ2pCLGtEQUFNbUksU0FBUzlFLHFCQUFxQnJELGFBQWE7QUFDakQsa0RBQU1xSSxPQUFPRixTQUFTLElBQUk1RSxZQUFhdUksT0FBTyxLQUFLM0QsU0FBVSxHQUFHLEVBQUUzRSxRQUFRLENBQUMsSUFBSTtBQUMvRWYscUVBQXlCYyxXQUFXOEUsSUFBSSxDQUFDO0FBQUEsMENBQzNDO0FBQUEsd0NBQ0Y7QUFBQSx3Q0FDQSxNQUFLO0FBQUEsd0NBQ0wsV0FBVyxDQUFBbkYsVUFBUyxJQUFJQSxLQUFLLEdBQUc4SSxRQUFRLHlCQUF5QixHQUFHO0FBQUEsd0NBQ3BFLFFBQVEsQ0FBQTlJLFVBQVNBLE1BQU04SSxRQUFRLGVBQWUsRUFBRTtBQUFBLHdDQUNoRCxhQUFZO0FBQUE7QUFBQSxzQ0FmZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBZTRCO0FBQUEsdUNBakI5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQW1CQTtBQUFBLHFDQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQXNEQSxLQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQXdEQTtBQUFBO0FBQUE7QUFBQSw0QkF4RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQXlGQTtBQUFBLDBCQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFeEMsU0FBUyxRQUFRRSxnQkFBZ0IsWUFBWW9CLFdBQVcsT0FBTyxHQUMzRTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxNQUFLO0FBQUEsOEJBQ0wsTUFBTSx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBQVM7QUFBQSw4QkFDZixTQUFTbEs7QUFBQUEsOEJBQ1QsU0FBUzhGO0FBQUFBLDhCQUNULE1BQUs7QUFBQSw4QkFDTCxPQUFPO0FBQUEsZ0NBQ0xrRCxZQUFZO0FBQUEsZ0NBQ1pOLGNBQWM7QUFBQSxnQ0FDZEMsWUFBWTtBQUFBLGdDQUNab0IsUUFBUTtBQUFBLGdDQUNSSyxXQUFXO0FBQUEsZ0NBQ1gzQixRQUFRO0FBQUEsZ0NBQ1I0QyxhQUFhO0FBQUEsZ0NBQ2JDLGNBQWM7QUFBQSw4QkFDaEI7QUFBQSw4QkFBRTtBQUFBO0FBQUEsNEJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXFCQTtBQUFBLDZCQXJURjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQXVUQSxLQXpUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQTRUQTtBQUFBLDJCQTdnQko7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFnaEJBO0FBQUE7QUFBQSxvQkFsaEJJO0FBQUEsb0JBUE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkEwaEJBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsS0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRTFDLFNBQVMsUUFBUUMsWUFBWSxTQUFTLEdBQ25EO0FBQUEsK0NBQUMsb0JBQWlCLE9BQU8sRUFBRVcsYUFBYSxNQUFNLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdEO0FBQUEsd0JBQUc7QUFBQSwyQkFEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUlGLGlDQUFDLFNBQUksT0FBTyxFQUFFSSxTQUFTLFFBQVFqQixZQUFZLFVBQVUsR0FDbkQsaUNBQUMsUUFBSyxPQUFPO0FBQUEsd0JBQ1hELGNBQWM7QUFBQSx3QkFDZHFCLFFBQVE7QUFBQSx3QkFDUkssV0FBVztBQUFBLHdCQUNYekIsWUFBWTtBQUFBLHNCQUNkLEdBQ0U7QUFBQSwrQ0FBQyxTQUFJLE9BQU87QUFBQSwwQkFDVkMsU0FBUztBQUFBLDBCQUNURSxnQkFBZ0I7QUFBQSwwQkFDaEJELFlBQVk7QUFBQSwwQkFDWnNCLGNBQWM7QUFBQSwwQkFDZFAsU0FBUztBQUFBLDBCQUNUaUIsY0FBYztBQUFBLHdCQUNoQixHQUNFO0FBQUEsaURBQUMsU0FBTSxPQUFPLEdBQUcsT0FBTztBQUFBLDRCQUN0QkQsUUFBUTtBQUFBLDRCQUNSN0IsT0FBTztBQUFBLDRCQUNQQyxZQUFZO0FBQUEsNEJBQ1pDLFVBQVU7QUFBQSw0QkFDVkwsU0FBUztBQUFBLDRCQUNUQyxZQUFZO0FBQUEsMEJBQ2QsR0FDRTtBQUFBLG1EQUFDLG9CQUFpQixPQUFPLEVBQUVXLGFBQWEsT0FBT1QsT0FBTyxVQUFVLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWtFO0FBQUEsNEJBQUc7QUFBQSwrQkFSdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FVQTtBQUFBLDBCQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFSCxTQUFTLFFBQVFDLFlBQVksU0FBUyxHQUNsRDtBQUFBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLGFBQVk7QUFBQSxnQ0FDWjtBQUFBLGdDQUNBO0FBQUEsZ0NBQ0EsTUFBSztBQUFBLGdDQUNMLE9BQU8sRUFBRUwsT0FBTyxLQUFLZ0IsYUFBYSxHQUFHO0FBQUEsZ0NBQ3JDLFVBQVVsSTtBQUFBQSxnQ0FDVixVQUFVLENBQUFlLE1BQUtmLGNBQWNlLEVBQUVFLE9BQU9ELEtBQUs7QUFBQTtBQUFBLDhCQVA3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBTytDO0FBQUEsNEJBRS9DLHVCQUFDLFVBQUssT0FBTztBQUFBLDhCQUNYcUcsWUFBWTtBQUFBLDhCQUNaSSxPQUFPO0FBQUEsOEJBQ1BhLFNBQVM7QUFBQSw4QkFDVGxCLGNBQWM7QUFBQSw4QkFDZE8sVUFBVTtBQUFBLDhCQUNWRCxZQUFZO0FBQUEsNEJBQ2QsR0FDR2Y7QUFBQUEsZ0RBQWtCNkM7QUFBQUEsOEJBQU87QUFBQSxpQ0FSNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FTQTtBQUFBLCtCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQW9CQTtBQUFBLDZCQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQXdDQTtBQUFBLHdCQUNDMUssVUFDQyx1QkFBQyxTQUFJLE9BQU8sRUFBRXdJLFNBQVMsUUFBUUUsZ0JBQWdCLFVBQVVjLFNBQVMsU0FBUyxHQUN6RSxpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUEsSUFFQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxZQUFZM0Isa0JBQWtCakUsSUFBSSxDQUFDQyxHQUFHc0UsT0FBTztBQUFBLDhCQUMzQyxHQUFHdEU7QUFBQUEsOEJBQ0hmLEtBQUtlLEVBQUVJLE9BQU9rRTtBQUFBQSw0QkFDaEIsRUFBRTtBQUFBLDRCQUNGO0FBQUEsNEJBQ0EsWUFBWTtBQUFBLDhCQUNWZ0QsVUFBVTtBQUFBLDhCQUNWQyxpQkFBaUI7QUFBQSw4QkFDakJDLFdBQVdBLENBQUNDLE9BQU9DLFVBQ2pCLHVCQUFDLFVBQUssT0FBTyxFQUFFNUMsT0FBTyxXQUFXQyxZQUFZLE9BQU9DLFVBQVUsT0FBTyxHQUFHO0FBQUE7QUFBQSxnQ0FDN0QwQyxNQUFNLENBQUM7QUFBQSxnQ0FBRTtBQUFBLGdDQUFFQSxNQUFNLENBQUM7QUFBQSxnQ0FBRTtBQUFBLGdDQUFLRDtBQUFBQSxnQ0FBTTtBQUFBLG1DQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUVBO0FBQUEsOEJBRUZyQixVQUFVLENBQUMsY0FBYztBQUFBLDRCQUMzQjtBQUFBLDRCQUNBLFFBQVEsRUFBRXVCLEdBQUcsSUFBSztBQUFBO0FBQUEsMEJBaEJwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBZ0JzQjtBQUFBLDJCQXBFMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF1RUEsS0F4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF5RUE7QUFBQTtBQUFBLG9CQTNFSTtBQUFBLG9CQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBbUZBO0FBQUE7QUFBQTtBQUFBLGNBem5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUEwbkJBO0FBQUE7QUFBQSxVQXBvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBcW9CQTtBQUFBLFFBR0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQ0UsdUJBQUMsU0FBSSxPQUFPO0FBQUEsY0FDVmhELFNBQVM7QUFBQSxjQUNUQyxZQUFZO0FBQUEsY0FDWm9DLEtBQUs7QUFBQSxjQUNMdEMsWUFBWTtBQUFBLGNBR1ppQixTQUFTO0FBQUEsY0FDVGlDLHFCQUFxQjtBQUFBLGNBQ3JCQyxzQkFBc0I7QUFBQSxZQUN4QixHQUNFO0FBQUEscUNBQUMsZ0JBQWEsT0FBTyxFQUFFN0MsVUFBVSxRQUFRRixPQUFPLFVBQVUsS0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEQ7QUFBQSxjQUM1RCx1QkFBQyxVQUFLLE9BQU8sRUFBRUUsVUFBVSxRQUFRRCxZQUFZLE9BQU9ELE9BQU8sVUFBVSxHQUFHO0FBQUE7QUFBQSxnQkFDdkR2SSxnQkFBZ0IrRDtBQUFBQSxtQkFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUVGLE9BQU87QUFBQSxZQUNQLE1BQU1qRTtBQUFBQSxZQUNOLFNBQVMsTUFBTUMsa0JBQWtCLEtBQUs7QUFBQSxZQUN0QyxRQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFd0wsV0FBVyxRQUFRLEdBQy9CLGlDQUFDLFNBQU0sTUFBTSxJQUNYO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNeEwsa0JBQWtCLEtBQUs7QUFBQSxrQkFDdEMsT0FBTyxFQUFFa0ksUUFBUSxRQUFRTyxZQUFZLE1BQU07QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQjtBQUFBLGtCQUMxQixTQUFTL0Q7QUFBQUEsa0JBQ1QsT0FBTztBQUFBLG9CQUNMd0QsUUFBUTtBQUFBLG9CQUNSTyxZQUFZO0FBQUEsb0JBQ1pMLFlBQVk7QUFBQSxvQkFDWm9CLFFBQVE7QUFBQSxrQkFDVjtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FZQTtBQUFBLGlCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQTtBQUFBLFlBR0R6Siw0QkFBa0JFLGtCQUNqQix1QkFBQyxTQUFJLE9BQU8sRUFBRW9KLFNBQVMsUUFBUWpCLFlBQVksVUFBVSxHQUVuRDtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU87QUFBQSxvQkFDTEQsY0FBYztBQUFBLG9CQUNkcUIsUUFBUTtBQUFBLG9CQUNSSyxXQUFXO0FBQUEsb0JBQ1hELGNBQWM7QUFBQSxvQkFDZHhCLFlBQVk7QUFBQSxrQkFDZDtBQUFBLGtCQUVBLGlDQUFDLFNBQUksT0FBTyxFQUFFaUIsU0FBUyxZQUFZLEdBQ2pDO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTztBQUFBLHdCQUNQLE9BQU87QUFBQSwwQkFDTGdCLFFBQVE7QUFBQSwwQkFDUjdCLE9BQU87QUFBQSwwQkFDUEMsWUFBWTtBQUFBLDBCQUNaQyxVQUFVO0FBQUEsMEJBQ1ZMLFNBQVM7QUFBQSwwQkFDVEMsWUFBWTtBQUFBLHdCQUNkO0FBQUEsd0JBRUE7QUFBQSxpREFBQyxvQkFBaUIsT0FBTyxFQUFFVyxhQUFhLE9BQU9ULE9BQU8sVUFBVSxLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFrRTtBQUFBLDBCQUFHO0FBQUE7QUFBQTtBQUFBLHNCQVh2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBYUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FBRyxPQUFPLEVBQUVtQixXQUFXLE9BQU8sR0FDaEQ7QUFBQSw2Q0FBQyxPQUFJLElBQUksSUFBSSxJQUFJLEdBQ2Y7QUFBQSwrQ0FBQyxRQUFLLFFBQU0sTUFBQyxtQ0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBLHdCQUNoQztBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxPQUFPO0FBQUEsOEJBQ0xOLFNBQVM7QUFBQSw4QkFDVGpCLFlBQVk7QUFBQSw4QkFDWm9CLFFBQVE7QUFBQSw4QkFDUnJCLGNBQWM7QUFBQSw4QkFDZHdCLFdBQVc7QUFBQSw4QkFDWGxCLFlBQVk7QUFBQSw4QkFDWkMsVUFBVTtBQUFBLDhCQUNWRixPQUFPO0FBQUEsNEJBQ1Q7QUFBQSw0QkFBRTtBQUFBO0FBQUEsOEJBRUF4QyxPQUFPL0YsZUFBZWlFLG1CQUFtQixFQUFFb0YsZUFBZSxPQUFPO0FBQUE7QUFBQTtBQUFBLDBCQVpyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBYUE7QUFBQSwyQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWdCQTtBQUFBLHNCQUVBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksR0FDZjtBQUFBLCtDQUFDLFFBQUssUUFBTSxNQUFDLGtDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStCO0FBQUEsd0JBQy9CO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE9BQU87QUFBQSw4QkFDTEQsU0FBUztBQUFBLDhCQUNUakIsWUFBWTtBQUFBLDhCQUNab0IsUUFBUTtBQUFBLDhCQUNSckIsY0FBYztBQUFBLDhCQUNkd0IsV0FBVztBQUFBLDhCQUNYbEIsWUFBWTtBQUFBLDhCQUNaQyxVQUFVO0FBQUEsOEJBQ1ZGLE9BQU87QUFBQSw0QkFDVDtBQUFBLDRCQUFFO0FBQUE7QUFBQSw4QkFFQXhDLE9BQU8vRixlQUFlb0Usa0JBQWtCLEVBQUVpRixlQUFlLE9BQU87QUFBQTtBQUFBO0FBQUEsMEJBWnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFhQTtBQUFBLDJCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBZ0JBO0FBQUEsc0JBRUEsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxHQUNmO0FBQUEsK0NBQUMsUUFBSyxRQUFNLE1BQUMsaUNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBOEI7QUFBQSx3QkFDOUI7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsT0FBTztBQUFBLDhCQUNMRCxTQUFTO0FBQUEsOEJBQ1RqQixZQUFZO0FBQUEsOEJBQ1pvQixRQUFRO0FBQUEsOEJBQ1JyQixjQUFjO0FBQUEsOEJBQ2R3QixXQUFXO0FBQUEsOEJBQ1hsQixZQUFZO0FBQUEsOEJBQ1pDLFVBQVU7QUFBQSw4QkFDVkYsT0FBTztBQUFBLDRCQUNUO0FBQUEsNEJBQUU7QUFBQTtBQUFBLDhCQUVBeEMsT0FBTy9GLGVBQWVxRSxpQkFBaUIsRUFBRWdGLGVBQWUsT0FBTztBQUFBO0FBQUE7QUFBQSwwQkFabkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWFBO0FBQUEsMkJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFnQkE7QUFBQSx5QkFyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFzREE7QUFBQSx1QkF0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF1RUE7QUFBQTtBQUFBLGdCQWhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpRkE7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU87QUFBQSxvQkFDTG5CLGNBQWM7QUFBQSxvQkFDZHFCLFFBQVE7QUFBQSxvQkFDUkssV0FBVztBQUFBLG9CQUNYRCxjQUFjO0FBQUEsb0JBQ2R4QixZQUFZO0FBQUEsb0JBQ1oyQixVQUFVO0FBQUEsa0JBQ1o7QUFBQSxrQkFFQTtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU87QUFBQSwwQkFDTDNCLFlBQVk7QUFBQSwwQkFDWmlCLFNBQVM7QUFBQSwwQkFDVGlCLGNBQWM7QUFBQSx3QkFDaEI7QUFBQSx3QkFFQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxPQUFPO0FBQUEsNEJBQ1AsT0FBTztBQUFBLDhCQUNMRCxRQUFRO0FBQUEsOEJBQ1I3QixPQUFPO0FBQUEsOEJBQ1BDLFlBQVk7QUFBQSw4QkFDWkMsVUFBVTtBQUFBLDhCQUNWTCxTQUFTO0FBQUEsOEJBQ1RDLFlBQVk7QUFBQSw0QkFDZDtBQUFBLDRCQUVBO0FBQUEscURBQUMsdUJBQW9CLE9BQU8sRUFBRVcsYUFBYSxNQUFNLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBQW1EO0FBQUEsOEJBQUc7QUFBQTtBQUFBO0FBQUEsMEJBWHhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFhQTtBQUFBO0FBQUEsc0JBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFxQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUksU0FBUyxPQUFPLEdBQzVCLGlDQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQUNsQjtBQUFBLDZDQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQ3ZCO0FBQUEsK0NBQUMsU0FBSSxPQUFPLEVBQUVPLGNBQWMsTUFBTSxHQUNoQztBQUFBLGlEQUFDLFFBQUssUUFBTSxNQUFDLE9BQU8sRUFBRXBCLE9BQU8sV0FBV0UsVUFBVSxPQUFPLEdBQUcscUNBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQSx1QkFBQyxRQUFLLE1BQUssVUFBUyxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBc0I7QUFBQSw2QkFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE9BQU8sRUFBRVQsT0FBTyxPQUFPO0FBQUEsNEJBQ3ZCLEtBQUs7QUFBQSw0QkFDTCxPQUFPaEksZUFBZWlGLHVCQUF1QjtBQUFBLDRCQUM3QyxVQUFVLENBQUN5RixRQUNUekssa0JBQWtCLENBQUF1TCxVQUFTLEVBQUUsR0FBR0EsTUFBTXZHLHFCQUFxQnlGLE9BQU8sRUFBRSxFQUFFO0FBQUEsNEJBRXhFLE1BQUs7QUFBQSw0QkFDTCxhQUFZO0FBQUE7QUFBQSwwQkFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUW9DO0FBQUEsMkJBZnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBaUJBO0FBQUEsc0JBQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkI7QUFBQSwrQ0FBQyxTQUFJLE9BQU8sRUFBRWYsY0FBYyxNQUFNLEdBQ2hDO0FBQUEsaURBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyxpQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUssTUFBSyxVQUFTLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFzQjtBQUFBLDZCQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsT0FBTyxFQUFFVCxPQUFPLE9BQU87QUFBQSw0QkFDdkIsS0FBSztBQUFBLDRCQUNMLEtBQUs7QUFBQSw0QkFDTCxPQUFPakMsT0FBTy9GLGVBQWVnRixxQkFBcUIsQ0FBQztBQUFBLDRCQUNuRCxVQUFVLENBQUMwRixRQUFRO0FBQ2pCLG9DQUFNMUksY0FBYytELE9BQU8vRixlQUFlaUUsbUJBQW1CLEtBQUs7QUFDbEV5QixzQ0FBUUksSUFBSTlELGFBQWEwSSxLQUFLLGFBQWE7QUFDM0Msb0NBQU16RCxPQUFPLE9BQU95RCxRQUFRLFlBQVksQ0FBQ2UsTUFBTWYsR0FBRyxJQUFJQSxNQUFNO0FBQzVELG9DQUFNM0QsU0FBUy9FLGNBQWMsSUFBSUcsWUFBYUgsY0FBY2lGLE9BQVEsS0FBSzdFLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDdkZuQyxnREFBa0IsQ0FBQXVMLFVBQVM7QUFBQSxnQ0FDekIsR0FBR0E7QUFBQUEsZ0NBQ0h4RyxtQkFBbUJpQztBQUFBQSxnQ0FDbkJsQyxxQkFBcUJnQztBQUFBQSw4QkFDdkIsRUFBRTtBQUFBLDRCQUNKO0FBQUEsNEJBQ0EsTUFBSztBQUFBLDRCQUNMLGFBQVk7QUFBQTtBQUFBLDBCQWpCZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBaUIwQjtBQUFBLDJCQXhCNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkEwQkE7QUFBQSxzQkFDQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QjtBQUFBLCtDQUFDLFNBQUksT0FBTyxFQUFFNEMsY0FBYyxNQUFNLEdBQ2hDO0FBQUEsaURBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyxtQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUssTUFBSyxVQUFTLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFzQjtBQUFBLDZCQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsT0FBTyxFQUFFVCxPQUFPLE9BQU87QUFBQSw0QkFDdkIsS0FBSztBQUFBLDRCQUNMLE9BQU9oSSxlQUFlK0UsdUJBQXVCO0FBQUEsNEJBQzdDLFVBQVUsQ0FBQzJGLFFBQVE7QUFDakIsb0NBQU0xSSxjQUFjK0QsT0FBTy9GLGVBQWVnRSxrQkFBa0IsS0FBSztBQUNqRSxvQ0FBTStDLFNBQVMsT0FBTzJELFFBQVEsWUFBWSxDQUFDZSxNQUFNZixHQUFHLElBQUlBLE1BQU07QUFDOUQsb0NBQU16RCxPQUFPakYsY0FBYyxJQUFJRyxZQUFhNEUsU0FBUy9FLGNBQWUsS0FBS0ksUUFBUSxDQUFDLENBQUMsSUFBSTtBQUN2Rm5DLGdEQUFrQixDQUFBdUwsVUFBUztBQUFBLGdDQUN6QixHQUFHQTtBQUFBQSxnQ0FDSHpHLHFCQUFxQmdDO0FBQUFBLGdDQUNyQi9CLG1CQUFtQmlDO0FBQUFBLDhCQUNyQixFQUFFO0FBQUEsNEJBQ0o7QUFBQSw0QkFDQSxNQUFLO0FBQUEsNEJBQ0wsV0FBVyxDQUFDbkYsVUFDVixJQUFJQSxLQUFLLEdBQUc4SSxRQUFRLHlCQUF5QixHQUFHO0FBQUEsNEJBRWxELFFBQVEsQ0FBQzlJLFVBQVVBLE1BQU04SSxRQUFRLGVBQWUsRUFBRTtBQUFBLDRCQUNsRCxhQUFZO0FBQUE7QUFBQSwwQkFuQmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQW1COEI7QUFBQSwyQkExQmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBNEJBO0FBQUEseUJBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBMkVBLEtBNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBNkVBO0FBQUE7QUFBQTtBQUFBLGdCQTdHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0E4R0E7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU87QUFBQSxvQkFDTDFDLGNBQWM7QUFBQSxvQkFDZHFCLFFBQVE7QUFBQSxvQkFDUkssV0FBVztBQUFBLG9CQUNYRCxjQUFjO0FBQUEsb0JBQ2R4QixZQUFZO0FBQUEsb0JBQ1oyQixVQUFVO0FBQUEsa0JBQ1o7QUFBQSxrQkFFQTtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU87QUFBQSwwQkFDTDNCLFlBQVk7QUFBQSwwQkFDWmlCLFNBQVM7QUFBQSwwQkFDVGlCLGNBQWM7QUFBQSx3QkFDaEI7QUFBQSx3QkFFQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxPQUFPO0FBQUEsNEJBQ1AsT0FBTztBQUFBLDhCQUNMRCxRQUFRO0FBQUEsOEJBQ1I3QixPQUFPO0FBQUEsOEJBQ1BDLFlBQVk7QUFBQSw4QkFDWkMsVUFBVTtBQUFBLDhCQUNWTCxTQUFTO0FBQUEsOEJBQ1RDLFlBQVk7QUFBQSw0QkFDZDtBQUFBLDRCQUVBO0FBQUEscURBQUMsdUJBQW9CLE9BQU8sRUFBRVcsYUFBYSxNQUFNLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBQW1EO0FBQUEsOEJBQUc7QUFBQTtBQUFBO0FBQUEsMEJBWHhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFhQTtBQUFBO0FBQUEsc0JBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFxQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUksU0FBUyxPQUFPLEdBQzVCLGlDQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQUNsQjtBQUFBLDZDQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQ3ZCO0FBQUEsK0NBQUMsU0FBSSxPQUFPLEVBQUVPLGNBQWMsTUFBTSxHQUNoQztBQUFBLGlEQUFDLFFBQUssUUFBTSxNQUFDLE9BQU8sRUFBRXBCLE9BQU8sV0FBV0UsVUFBVSxPQUFPLEdBQUcsZ0NBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQSx1QkFBQyxRQUFLLE1BQUssVUFBUyxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBc0I7QUFBQSw2QkFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE9BQU8sRUFBRVQsT0FBTyxPQUFPO0FBQUEsNEJBQ3ZCLEtBQUs7QUFBQSw0QkFDTCxLQUFLO0FBQUEsNEJBQ0wsT0FBT2hJLGVBQWU0RSxnQkFBZ0I7QUFBQSw0QkFDdEMsVUFBVSxDQUFDOEYsUUFBUTtBQUNqQixvQ0FBTTFJLGNBQWMrRCxPQUFPL0YsZUFBZWdFLGtCQUFrQixLQUFLO0FBQ2pFLG9DQUFNaUQsT0FBTyxPQUFPeUQsUUFBUSxZQUFZLENBQUNlLE1BQU1mLEdBQUcsSUFBSUEsTUFBTTtBQUM1RCxvQ0FBTTNELFNBQVMvRSxjQUFjLElBQUlHLFlBQWFILGNBQWNpRixPQUFRLEtBQUs3RSxRQUFRLENBQUMsQ0FBQyxJQUFJO0FBQ3ZGbkMsZ0RBQWtCLENBQUF1TCxVQUFTO0FBQUEsZ0NBQ3pCLEdBQUdBO0FBQUFBLGdDQUNINUcsY0FBY3FDO0FBQUFBLGdDQUNkbkMsZ0JBQWdCaUM7QUFBQUEsOEJBQ2xCLEVBQUU7QUFBQSw0QkFDSjtBQUFBLDRCQUNBLE1BQUs7QUFBQSw0QkFDTCxhQUFZO0FBQUE7QUFBQSwwQkFoQmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWdCMEI7QUFBQSwyQkF2QjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBeUJBO0FBQUEsc0JBQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkI7QUFBQSwrQ0FBQyxTQUFJLE9BQU8sRUFBRTRDLGNBQWMsTUFBTSxHQUNoQztBQUFBLGlEQUFDLFFBQUssUUFBTSxNQUFDLE9BQU8sRUFBRXBCLE9BQU8sV0FBV0UsVUFBVSxPQUFPLEdBQUcsa0NBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQSx1QkFBQyxRQUFLLE1BQUssVUFBUyxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBc0I7QUFBQSw2QkFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE9BQU8sRUFBRVQsT0FBTyxPQUFPO0FBQUEsNEJBQ3ZCLEtBQUs7QUFBQSw0QkFDTCxPQUFPaEksZUFBZThFLGtCQUFrQjtBQUFBLDRCQUN4QyxVQUFVLENBQUM0RixRQUFRO0FBQ2pCLG9DQUFNMUksY0FBYytELE9BQU8vRixlQUFlZ0Usa0JBQWtCLEtBQUs7QUFDakUsb0NBQU0rQyxTQUFTLE9BQU8yRCxRQUFRLFlBQVksQ0FBQ2UsTUFBTWYsR0FBRyxJQUFJQSxNQUFNO0FBQzlELG9DQUFNekQsT0FBT2pGLGNBQWMsSUFBSUcsWUFBYTRFLFNBQVMvRSxjQUFlLEtBQUtJLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDdkZuQyxnREFBa0IsQ0FBQXVMLFVBQVM7QUFBQSxnQ0FDekIsR0FBR0E7QUFBQUEsZ0NBQ0gxRyxnQkFBZ0JpQztBQUFBQSxnQ0FDaEJuQyxjQUFjcUM7QUFBQUEsOEJBQ2hCLEVBQUU7QUFBQSw0QkFDSjtBQUFBLDRCQUNBLE1BQUs7QUFBQSw0QkFDTCxXQUFXLENBQUNuRixVQUNWLElBQUlBLEtBQUssR0FBRzhJLFFBQVEseUJBQXlCLEdBQUc7QUFBQSw0QkFFbEQsUUFBUSxDQUFDOUksVUFBVUEsTUFBTThJLFFBQVEsZUFBZSxFQUFFO0FBQUEsNEJBQ2xELGFBQVk7QUFBQTtBQUFBLDBCQW5CZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBbUI0QjtBQUFBLDJCQTFCOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkE0QkE7QUFBQSx5QkF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkF3REEsS0F6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkEwREE7QUFBQTtBQUFBO0FBQUEsZ0JBMUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTJGQTtBQUFBLGNBR0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTztBQUFBLG9CQUNMMUMsY0FBYztBQUFBLG9CQUNkcUIsUUFBUTtBQUFBLG9CQUNSSyxXQUFXO0FBQUEsb0JBQ1hELGNBQWM7QUFBQSxvQkFDZHhCLFlBQVk7QUFBQSxvQkFDWjJCLFVBQVU7QUFBQSxrQkFDWjtBQUFBLGtCQUVBO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTztBQUFBLDBCQUNMM0IsWUFBWTtBQUFBLDBCQUNaaUIsU0FBUztBQUFBLDBCQUNUaUIsY0FBYztBQUFBLHdCQUNoQjtBQUFBLHdCQUVBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE9BQU87QUFBQSw0QkFDUCxPQUFPO0FBQUEsOEJBQ0xELFFBQVE7QUFBQSw4QkFDUjdCLE9BQU87QUFBQSw4QkFDUEMsWUFBWTtBQUFBLDhCQUNaQyxVQUFVO0FBQUEsOEJBQ1ZMLFNBQVM7QUFBQSw4QkFDVEMsWUFBWTtBQUFBLDRCQUNkO0FBQUEsNEJBRUE7QUFBQSxxREFBQyxtQkFBZ0IsT0FBTyxFQUFFVyxhQUFhLE1BQU0sS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBK0M7QUFBQSw4QkFBRztBQUFBO0FBQUE7QUFBQSwwQkFYcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWFBO0FBQUE7QUFBQSxzQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXFCQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFSSxTQUFTLE9BQU8sR0FDNUIsaUNBQUMsT0FBSSxRQUFRLENBQUMsSUFBSSxFQUFFLEdBQ2xCO0FBQUEsNkNBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkI7QUFBQSwrQ0FBQyxTQUFJLE9BQU8sRUFBRU8sY0FBYyxNQUFNLEdBQ2hDLGlDQUFDLFFBQUssUUFBTSxNQUFDLE9BQU8sRUFBRXBCLE9BQU8sV0FBV0UsVUFBVSxPQUFPLEdBQUcsd0NBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsT0FBTyxFQUFFVCxPQUFPLE9BQU87QUFBQSw0QkFDdkIsS0FBSztBQUFBLDRCQUNMLE9BQU9oSSxlQUFlbUYsMEJBQTBCO0FBQUEsNEJBQ2hELFVBQVUsQ0FBQ3VGLFFBQ1R6SyxrQkFBa0IsQ0FBQXVMLFVBQVMsRUFBRSxHQUFHQSxNQUFNckcsd0JBQXdCdUYsT0FBTyxFQUFFLEVBQUU7QUFBQSw0QkFFM0UsTUFBSztBQUFBLDRCQUNMLGFBQVk7QUFBQTtBQUFBLDBCQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFRMEI7QUFBQSwyQkFkNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFnQkE7QUFBQSxzQkFDQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QjtBQUFBLCtDQUFDLFNBQUksT0FBTyxFQUFFZixjQUFjLE1BQU0sR0FDaEMsaUNBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyw0Q0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSUE7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxPQUFPLEVBQUVULE9BQU8sT0FBTztBQUFBLDRCQUN2QixLQUFLO0FBQUEsNEJBQ0wsS0FBSztBQUFBLDRCQUNMLE9BQU9oSSxlQUFlb0YsNEJBQTRCO0FBQUEsNEJBQ2xELFVBQVUsQ0FBQ3NGLFFBQVE7QUFDakIsb0NBQU0xSSxjQUFjK0QsT0FBTy9GLGVBQWVnRSxrQkFBa0IsS0FBSztBQUNqRSxvQ0FBTWlELE9BQU8sT0FBT3lELFFBQVEsWUFBWSxDQUFDZSxNQUFNZixHQUFHLElBQUlBLE1BQU07QUFDNUQsb0NBQU0zRCxTQUFTL0UsY0FBYyxJQUFJRyxZQUFhSCxjQUFjaUYsT0FBUSxLQUFLN0UsUUFBUSxDQUFDLENBQUMsSUFBSTtBQUN2Rm5DLGdEQUFrQixDQUFBdUwsVUFBUztBQUFBLGdDQUN6QixHQUFHQTtBQUFBQSxnQ0FDSHBHLDBCQUEwQjZCO0FBQUFBLGdDQUMxQi9CLDRCQUE0QjZCO0FBQUFBLDhCQUM5QixFQUFFO0FBQUEsNEJBQ0o7QUFBQSw0QkFDQSxNQUFLO0FBQUEsNEJBQ0wsYUFBWTtBQUFBO0FBQUEsMEJBaEJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFnQjBCO0FBQUEsMkJBdEI1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXdCQTtBQUFBLHNCQUNBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQ3ZCO0FBQUEsK0NBQUMsU0FBSSxPQUFPLEVBQUU0QyxjQUFjLE1BQU0sR0FDaEMsaUNBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFcEIsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FBRyw4Q0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSUE7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxPQUFPLEVBQUVULE9BQU8sT0FBTztBQUFBLDRCQUN2QixLQUFLO0FBQUEsNEJBQ0wsT0FBT2hJLGVBQWVrRiw4QkFBOEI7QUFBQSw0QkFDcEQsVUFBVSxDQUFDd0YsUUFBUTtBQUNqQixvQ0FBTTFJLGNBQWMrRCxPQUFPL0YsZUFBZWdFLGtCQUFrQixLQUFLO0FBQ2pFMEIsc0NBQVFJLElBQUk5RCxXQUFXO0FBQ3ZCLG9DQUFNK0UsU0FBUyxPQUFPMkQsUUFBUSxZQUFZLENBQUNlLE1BQU1mLEdBQUcsSUFBSUEsTUFBTTtBQUM5RCxvQ0FBTXpELE9BQU9qRixjQUFjLElBQUlHLFlBQWE0RSxTQUFTL0UsY0FBZSxLQUFLSSxRQUFRLENBQUMsQ0FBQyxJQUFJO0FBQ3ZGbkMsZ0RBQWtCLENBQUF1TCxVQUFTO0FBQUEsZ0NBQ3pCLEdBQUdBO0FBQUFBLGdDQUNIdEcsNEJBQTRCNkI7QUFBQUEsZ0NBQzVCM0IsMEJBQTBCNkI7QUFBQUEsOEJBQzVCLEVBQUU7QUFBQSw0QkFDSjtBQUFBLDRCQUNBLE1BQUs7QUFBQSw0QkFDTCxXQUFXLENBQUNuRixVQUNWLElBQUlBLEtBQUssR0FBRzhJLFFBQVEseUJBQXlCLEdBQUc7QUFBQSw0QkFFbEQsUUFBUSxDQUFDOUksVUFBVUEsTUFBTThJLFFBQVEsZUFBZSxFQUFFO0FBQUEsNEJBQ2xELGFBQVk7QUFBQTtBQUFBLDBCQXBCZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBb0I0QjtBQUFBLDJCQTFCOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkE0QkE7QUFBQSx5QkF2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkF3RUEsS0F6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkEwRUE7QUFBQTtBQUFBO0FBQUEsZ0JBMUdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTJHQTtBQUFBLGlCQWhaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlaQTtBQUFBO0FBQUEsVUFuY0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBc2NBO0FBQUEsUUFHQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FDRSx1QkFBQyxTQUFJLE9BQU87QUFBQSxjQUNWeEMsU0FBUztBQUFBLGNBQ1RDLFlBQVk7QUFBQSxjQUNab0MsS0FBSztBQUFBLGNBQ0x0QyxZQUFZO0FBQUEsY0FDWmlDLFFBQVE7QUFBQSxjQUNSaEIsU0FBUztBQUFBLGNBQ1RpQyxxQkFBcUI7QUFBQSxjQUNyQkMsc0JBQXNCO0FBQUEsWUFDeEIsR0FDRTtBQUFBLHFDQUFDLGdCQUFhLE9BQU8sRUFBRTdDLFVBQVUsUUFBUUYsT0FBTyxVQUFVLEtBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTREO0FBQUEsY0FDNUQsdUJBQUMsVUFBSyxPQUFPLEVBQUVFLFVBQVUsUUFBUUQsWUFBWSxPQUFPRCxPQUFPLFVBQVUsR0FBRyxxQ0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUVGLE1BQU03SDtBQUFBQSxZQUNOLFVBQVUsTUFBTTtBQUNkQyxzQ0FBd0IsS0FBSztBQUM3QkMsNEJBQWN5RyxZQUFZO0FBQUEsWUFDNUI7QUFBQSxZQUNBLE9BQU87QUFBQSxZQUNQLFFBQVE7QUFBQSxjQUNOO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFNBQVMsTUFBTTtBQUNiMUcsNENBQXdCLEtBQUs7QUFDN0JDLGtDQUFjeUcsWUFBWTtBQUFBLGtCQUM1QjtBQUFBLGtCQUNBLE9BQU87QUFBQSxvQkFDTGEsY0FBYztBQUFBLG9CQUNkTSxZQUFZO0FBQUEsb0JBQ1pQLFFBQVE7QUFBQSxrQkFDVjtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFURTtBQUFBLGdCQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsTUFBSztBQUFBLGtCQUNMLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0I7QUFBQSxrQkFDMUIsU0FBUzdCO0FBQUFBLGtCQUNULE9BQU87QUFBQSxvQkFDTDhCLGNBQWM7QUFBQSxvQkFDZE0sWUFBWTtBQUFBLG9CQUNaUCxRQUFRO0FBQUEsb0JBQ1JFLFlBQVk7QUFBQSxvQkFDWm9CLFFBQVE7QUFBQSxrQkFDVjtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFWRTtBQUFBLGdCQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjQTtBQUFBLFlBQVM7QUFBQSxZQUdYLGlDQUFDLFFBQUssTUFBTTNJLGVBQWUsUUFBTyxZQUFXLE9BQU8sRUFBRThJLFdBQVcsT0FBTyxHQUN0RTtBQUFBO0FBQUEsZ0JBQUMsS0FBSztBQUFBLGdCQUFMO0FBQUEsa0JBQ0MsT0FBTyx1QkFBQyxRQUFLLFFBQU0sTUFBQyxPQUFPLEVBQUVqQixVQUFVLFFBQVFGLE9BQU8sVUFBVSxHQUFHLDJCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLGtCQUM5RSxNQUFLO0FBQUEsa0JBQ0wsT0FBTyxDQUFDLEVBQUVtRCxVQUFVLE1BQU1sUSxTQUFTLDJCQUEyQixDQUFDO0FBQUEsa0JBRS9ELGlDQUFDLFNBQU0sT0FBTyxFQUFFd00sT0FBTyxPQUFPLEdBQUcsYUFBWSwwQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUU7QUFBQTtBQUFBLGdCQUxyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBRUE7QUFBQSxnQkFBQyxLQUFLO0FBQUEsZ0JBQUw7QUFBQSxrQkFDQyxPQUFPLHVCQUFDLFFBQUssUUFBTSxNQUFDLE9BQU8sRUFBRVMsVUFBVSxRQUFRRixPQUFPLFVBQVUsR0FBRywyQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUU7QUFBQSxrQkFDOUUsTUFBSztBQUFBLGtCQUNMLE9BQU8sQ0FBQyxFQUFFbUQsVUFBVSxNQUFNbFEsU0FBUyw0QkFBNEIsQ0FBQztBQUFBLGtCQUNoRSxjQUFhO0FBQUEsa0JBRWIsaUNBQUMsVUFBTyxPQUFPLEVBQUV3TSxPQUFPLE9BQU8sR0FDN0I7QUFBQSwyQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFNBQVEsNEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlDO0FBQUEsb0JBQ3pDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sY0FBYSwwQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNEM7QUFBQSx1QkFGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBO0FBQUEsZ0JBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVUE7QUFBQSxjQUVBO0FBQUEsZ0JBQUMsS0FBSztBQUFBLGdCQUFMO0FBQUEsa0JBQ0M7QUFBQSxrQkFDQSxjQUFjLENBQUMyRCxZQUFZQyxrQkFBa0JELFdBQVc3RSxnQkFBZ0I4RSxjQUFjOUU7QUFBQUEsa0JBRXJGLFdBQUMsRUFBRStFLGNBQWMsTUFBTTtBQUN0QiwwQkFBTUMsYUFBYUQsY0FBYyxhQUFhO0FBQzlDLDJCQUFPQyxlQUFlLFVBQ3BCO0FBQUEsc0JBQUMsS0FBSztBQUFBLHNCQUFMO0FBQUEsd0JBQ0MsT0FBTyx1QkFBQyxRQUFLLFFBQU0sTUFBQyxPQUFPLEVBQUVyRCxVQUFVLFFBQVFGLE9BQU8sVUFBVSxHQUFHLDBCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFzRTtBQUFBLHdCQUM3RSxNQUFLO0FBQUEsd0JBQ0wsT0FBTyxDQUFDLEVBQUVtRCxVQUFVLE1BQU1sUSxTQUFTLHNCQUFzQixDQUFDO0FBQUEsd0JBRTFEO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE9BQU8sRUFBRXdNLE9BQU8sT0FBTztBQUFBLDRCQUN2QixLQUFLO0FBQUEsNEJBQ0wsV0FBVyxDQUFBbEcsVUFBUyxJQUFJQSxLQUFLLEdBQUc4SSxRQUFRLHlCQUF5QixHQUFHO0FBQUEsNEJBQ3BFLFFBQVEsQ0FBQTlJLFVBQVNBLE1BQU04SSxRQUFRLGVBQWUsRUFBRTtBQUFBLDRCQUNoRCxhQUFZO0FBQUE7QUFBQSwwQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSzRCO0FBQUE7QUFBQSxzQkFWOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVlBLElBRUE7QUFBQSxzQkFBQyxLQUFLO0FBQUEsc0JBQUw7QUFBQSx3QkFDQyxPQUFPLHVCQUFDLFFBQUssUUFBTSxNQUFDLE9BQU8sRUFBRW5DLFVBQVUsUUFBUUYsT0FBTyxVQUFVLEdBQUcsd0JBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW9FO0FBQUEsd0JBQzNFLE1BQUs7QUFBQSx3QkFDTCxPQUFPLENBQUMsRUFBRW1ELFVBQVUsTUFBTWxRLFNBQVMsb0JBQW9CLENBQUM7QUFBQSx3QkFFeEQ7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsT0FBTyxFQUFFd00sT0FBTyxPQUFPO0FBQUEsNEJBQ3ZCLEtBQUs7QUFBQSw0QkFDTCxLQUFLO0FBQUEsNEJBQ0wsYUFBWTtBQUFBO0FBQUEsMEJBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUkwQjtBQUFBO0FBQUEsc0JBVDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXQTtBQUFBLGtCQUVKO0FBQUE7QUFBQSxnQkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUNBO0FBQUEsY0FFQTtBQUFBLGdCQUFDLEtBQUs7QUFBQSxnQkFBTDtBQUFBLGtCQUNDLE9BQU8sdUJBQUMsUUFBSyxRQUFNLE1BQUMsT0FBTyxFQUFFUyxVQUFVLFFBQVFGLE9BQU8sVUFBVSxHQUFHLDJCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLGtCQUM5RSxNQUFLO0FBQUEsa0JBRUwsaUNBQUMsTUFBTSxVQUFOLEVBQWUsTUFBTSxHQUFHLGFBQVksa0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1FO0FBQUE7QUFBQSxnQkFKckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnRUE7QUFBQTtBQUFBLFVBeEhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXlIQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU03RztBQUFBQSxZQUNOLFVBQVUsTUFBTUMsc0JBQXNCLEtBQUs7QUFBQSxZQUMzQyxRQUFRO0FBQUEsWUFDUixPQUFPO0FBQUEsWUFDUCxVQUFVO0FBQUEsWUFDVixPQUFPLEVBQUVvSSxLQUFLLEdBQUc7QUFBQSxZQUNqQixXQUFXLEVBQUVYLFNBQVMsR0FBR2pCLFlBQVksVUFBVTtBQUFBLFlBRTlDM0csNEJBQ0MsdUJBQUMsU0FBSSxPQUFPLEVBQUU0SCxTQUFTLE9BQU8sR0FHNUI7QUFBQSxxQ0FBQyxTQUFJLE9BQU87QUFBQSxnQkFDVmpCLFlBQVk7QUFBQSxnQkFDWmlCLFNBQVM7QUFBQSxnQkFDVGxCLGNBQWM7QUFBQSxnQkFDZHlCLGNBQWM7QUFBQSxnQkFDZHBCLE9BQU87QUFBQSxnQkFDUEgsU0FBUztBQUFBLGdCQUNURSxnQkFBZ0I7QUFBQSxnQkFDaEJELFlBQVk7QUFBQSxjQUNkLEdBQ0U7QUFBQSx1Q0FBQyxVQUFLLE9BQU8sRUFBRUksVUFBVSxRQUFRRCxZQUFZLE1BQU0sR0FBRztBQUFBO0FBQUEsa0JBQzdCaEgsZUFBZXVDO0FBQUFBLHFCQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU87QUFBQSxzQkFHTG1FLGNBQWM7QUFBQSxzQkFDZE0sWUFBWTtBQUFBLG9CQUVkO0FBQUEsb0JBQ0EsU0FBUyxNQUFNO0FBQ2I3Ryw0Q0FBc0IsS0FBSztBQUMzQmdFLHFDQUFlbkUsY0FBYztBQUFBLG9CQUMvQjtBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZUE7QUFBQSxtQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE4QkE7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU87QUFBQSxvQkFDTDBHLGNBQWM7QUFBQSxvQkFDZHlCLGNBQWM7QUFBQSxvQkFDZEMsV0FBVztBQUFBLGtCQUNiO0FBQUEsa0JBRUE7QUFBQSwyQ0FBQyxTQUFNLE9BQU8sR0FBRyxPQUFPLEVBQUVELGNBQWMsR0FBRyxHQUFHLG1DQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUEsdUJBQUMsT0FBSSxRQUFRLENBQUMsSUFBSSxFQUFFLEdBQ2xCO0FBQUEsNkNBQUMsT0FBSSxNQUFNLEdBQ1Q7QUFBQSwrQ0FBQyxRQUFLLFFBQU0sTUFBQyxtQ0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBLHdCQUNoQyx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCO0FBQUE7QUFBQSwwQkFDaENuSSxlQUFleUM7QUFBQUEsNkJBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSwyQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEsc0JBRUEsdUJBQUMsT0FBSSxNQUFNLEdBQ1Q7QUFBQSwrQ0FBQyxRQUFLLFFBQU0sTUFBQyxrQ0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUErQjtBQUFBLHdCQUMvQix1QkFBQyxTQUFJLFdBQVUsc0JBQXFCO0FBQUE7QUFBQSwwQkFDaEN6QyxlQUFlNEM7QUFBQUEsNkJBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSwyQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEsc0JBRUEsdUJBQUMsT0FBSSxNQUFNLEdBQ1Q7QUFBQSwrQ0FBQyxRQUFLLFFBQU0sTUFBQyxpQ0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE4QjtBQUFBLHdCQUM5Qix1QkFBQyxTQUFJLFdBQVUsbUJBQWtCO0FBQUE7QUFBQSwwQkFDN0I1QyxlQUFlNkM7QUFBQUEsNkJBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSwyQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEseUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBcUJBO0FBQUE7QUFBQTtBQUFBLGdCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQ0E7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU87QUFBQSxvQkFDTDZELGNBQWM7QUFBQSxvQkFDZHlCLGNBQWM7QUFBQSxvQkFDZEMsV0FBVztBQUFBLGtCQUNiO0FBQUEsa0JBRUE7QUFBQSwyQ0FBQyxTQUFNLE9BQU8sR0FBRyxPQUFPLEVBQUVELGNBQWMsR0FBRyxHQUFHLDRCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEwRDtBQUFBLG9CQUMxRCx1QkFBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FDbEI7QUFBQSw2Q0FBQyxPQUFJLE1BQU0sR0FBRztBQUFBLCtDQUFDLE9BQUUsMkJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBYztBQUFBLHdCQUFJO0FBQUEsd0JBQUVuSSxlQUFleUQ7QUFBQUEsMkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXFFO0FBQUEsc0JBQ3JFLHVCQUFDLE9BQUksTUFBTSxHQUFHO0FBQUEsK0NBQUMsT0FBRSw4QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpQjtBQUFBLHdCQUFJO0FBQUEsd0JBQUV6RCxlQUFld0Q7QUFBQUEsd0JBQWtCO0FBQUEsMkJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVFO0FBQUEsc0JBQ3ZFLHVCQUFDLE9BQUksTUFBTSxHQUFHO0FBQUEsK0NBQUMsT0FBRSxnQ0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtQjtBQUFBLHdCQUFJO0FBQUEsd0JBQUd4RCxlQUFldUQ7QUFBQUEsMkJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJFO0FBQUEseUJBSDdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQTtBQUFBO0FBQUEsZ0JBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYUE7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU87QUFBQSxvQkFDTG1ELGNBQWM7QUFBQSxvQkFDZHlCLGNBQWM7QUFBQSxvQkFDZEMsV0FBVztBQUFBLGtCQUNiO0FBQUEsa0JBRUE7QUFBQSwyQ0FBQyxTQUFNLE9BQU8sR0FBRyxPQUFPLEVBQUVELGNBQWMsR0FBRyxHQUFHLCtCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RDtBQUFBLG9CQUM3RCx1QkFBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FDbEI7QUFBQSw2Q0FBQyxPQUFJLE1BQU0sR0FBRztBQUFBLCtDQUFDLE9BQUUsNkJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0I7QUFBQSx3QkFBSTtBQUFBLHdCQUFFbkksZUFBZW9EO0FBQUFBLHdCQUFhO0FBQUEsMkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlFO0FBQUEsc0JBQ2pFLHVCQUFDLE9BQUksTUFBTSxHQUFHO0FBQUEsK0NBQUMsT0FBRSwrQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFrQjtBQUFBLHdCQUFJO0FBQUEsd0JBQUdwRCxlQUFlc0Q7QUFBQUEsMkJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXFFO0FBQUEseUJBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQTtBQUFBO0FBQUEsZ0JBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYUE7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU87QUFBQSxvQkFDTG9ELGNBQWM7QUFBQSxvQkFDZHlCLGNBQWM7QUFBQSxvQkFDZEMsV0FBVztBQUFBLGtCQUNiO0FBQUEsa0JBRUE7QUFBQSwyQ0FBQyxTQUFNLE9BQU8sR0FBRyxPQUFPLEVBQUVELGNBQWMsR0FBRyxHQUFHLG1DQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRTtBQUFBLG9CQUNqRSx1QkFBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FDbEI7QUFBQSw2Q0FBQyxPQUFJLE1BQU0sR0FBRztBQUFBLCtDQUFDLE9BQUUsMkJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBYztBQUFBLHdCQUFJO0FBQUEsd0JBQUVuSSxlQUFlMkQ7QUFBQUEsMkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXdFO0FBQUEsc0JBQ3hFLHVCQUFDLE9BQUksTUFBTSxHQUFHO0FBQUEsK0NBQUMsT0FBRSxxQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFRO0FBQUEsd0JBQUk7QUFBQSx3QkFBRTNELGVBQWU0RDtBQUFBQSx3QkFBeUI7QUFBQSwyQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBcUU7QUFBQSxzQkFDckUsdUJBQUMsT0FBSSxNQUFNLEdBQUc7QUFBQSwrQ0FBQyxPQUFFLHVCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQVU7QUFBQSx3QkFBSTtBQUFBLHdCQUFHNUQsZUFBZTBEO0FBQUFBLDJCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5RTtBQUFBLHlCQUgzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUE7QUFBQTtBQUFBLGdCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXFHLFdBQVcsU0FBUzdCLFdBQVcsR0FBRyxHQUM5QyxpQ0FBQyxVQUFPLFNBQVMsTUFBTS9ILHNCQUFzQixLQUFLLEdBQUcscUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBNUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkhBO0FBQUE7QUFBQSxVQXZJSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF5SUE7QUFBQSxRQUdBLHVCQUFDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlLRTtBQUFBLFdBeGlESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeWlEQTtBQUFBLFNBOWlERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK2lEQTtBQUFBLE9BampERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa2pEQTtBQUVKO0FBQUVuRCxHQS85RElELGlCQUFlO0FBQUEsVUFDRlAsYUFjR2xDLEtBQUt1RSxTQUlEdkUsS0FBS3VFLE9BQU87QUFBQTtBQUFBMEwsS0FuQmhDeE47QUFpK0ROLGVBQWVBO0FBQWdCLElBQUF3TjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTZXR0aW5nU2lkZWJhciIsIk5hdmJhciIsImFwaSIsIlNlbGVjdCIsIklucHV0TnVtYmVyIiwiRHJhd2VyIiwiQnV0dG9uIiwibWVzc2FnZSIsIkNhcmQiLCJSb3ciLCJDb2wiLCJUYWJsZSIsIk1vZGFsIiwiRm9ybSIsIlNwYWNlIiwiVHlwb2dyYXBoeSIsIlN0YXRpc3RpYyIsIkRpdmlkZXIiLCJUYWJzIiwiVGFnIiwiRW1wdHkiLCJDb2xsYXBzZSIsIlByb2dyZXNzIiwiVG9vbHRpcCIsIkF2YXRhciIsIklucHV0IiwiSW9NZFNhdmUiLCJDYWxjdWxhdG9yT3V0bGluZWQiLCJUZWFtT3V0bGluZWQiLCJFZGl0T3V0bGluZWQiLCJGaWxlVGV4dE91dGxpbmVkIiwiQ2hlY2tDaXJjbGVPdXRsaW5lZCIsIlRodW5kZXJib2x0T3V0bGluZWQiLCJTZXR0aW5nT3V0bGluZWQiLCJDbG9ja0NpcmNsZU91dGxpbmVkIiwiUGVyY2VudGFnZU91dGxpbmVkIiwiRG9sbGFyT3V0bGluZWQiLCJDYWxlbmRhck91dGxpbmVkIiwiUGx1c091dGxpbmVkIiwiSW5mb0NpcmNsZU91dGxpbmVkIiwiRGVsZXRlT3V0bGluZWQiLCJFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIiwiRG9sbGFyQ2lyY2xlT3V0bGluZWQiLCJXYXJuaW5nT3V0bGluZWQiLCJTY2hlZHVsZU91dGxpbmVkIiwiTW9uZXlDb2xsZWN0T3V0bGluZWQiLCJDaXJjdWxhckxvYWRlciIsInVzZU5hdmlnYXRlIiwiVGl0bGUiLCJUZXh0IiwiUGFyYWdyYXBoIiwiVGFiUGFuZSIsIlBhbmVsIiwiU2VhcmNoIiwiUGVuYWx0eVNldHRpbmdzIiwiX3MiLCJuYXZpZ2F0ZSIsImdyb3VwcyIsInNldEdyb3VwcyIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwicGVuYWx0eVJhdGUiLCJzZXRQZW5hbHR5UmF0ZSIsImdyYWNlRGF5cyIsInNldEdyYWNlRGF5cyIsInBlbmFsdHlBbW91bnQiLCJzZXRQZW5hbHR5QW1vdW50IiwibGF0ZVBheW1lbnRBbW91bnQiLCJzZXRMYXRlUGF5bWVudEFtb3VudCIsImRheXNMYXRlVGhyZXNob2xkIiwic2V0RGF5c0xhdGVUaHJlc2hvbGQiLCJzYXZpbmciLCJzZXRTYXZpbmciLCJzdG9yZWRQZW5hbHRpZXMiLCJzZXRTdG9yZWRQZW5hbHRpZXMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVkaXREcmF3ZXJPcGVuIiwic2V0RWRpdERyYXdlck9wZW4iLCJlZGl0aW5nUGVuYWx0eSIsInNldEVkaXRpbmdQZW5hbHR5IiwiZWRpdFJvdyIsInNldEVkaXRSb3ciLCJtb2RhbEZvcm0iLCJ1c2VGb3JtIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwiYWRkaXRpb25hbENoYXJnZXMiLCJzZXRBZGRpdGlvbmFsQ2hhcmdlcyIsImlzQWRkQ2hhcmdlTW9kYWxPcGVuIiwic2V0SXNBZGRDaGFyZ2VNb2RhbE9wZW4iLCJhZGRDaGFyZ2VGb3JtIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJpc0dyb3VwU2VsZWN0ZWQiLCJ2YWNhbnRDaGl0UGVuYWx0eUFtb3VudCIsInNldFZhY2FudENoaXRQZW5hbHR5QW1vdW50IiwidmFjYW50Q2hpdEdyYWNlRGF5cyIsInNldFZhY2FudENoaXRHcmFjZURheXMiLCJ2YWNhbnRDaGl0UGVuYWx0eVJhdGUiLCJzZXRWYWNhbnRDaGl0UGVuYWx0eVJhdGUiLCJsYXRlUGF5bWVudFJhdGUiLCJzZXRMYXRlUGF5bWVudFJhdGUiLCJwZW5hbHR5UHJldmlldyIsInNldFBlbmFsdHlQcmV2aWV3Iiwic2hvd1BlbmFsdHlQcmV2aWV3Iiwic2V0U2hvd1BlbmFsdHlQcmV2aWV3IiwiR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImluc3RhbGxtZW50IiwiZ2V0SW5zdGFsbG1lbnRBbW91bnQiLCJwZW5hbHR5IiwicGFyc2VGbG9hdCIsInRvRml4ZWQiLCJoYW5kbGVLZXlEb3duIiwiaW5jbHVkZXMiLCJ0YWdOYW1lIiwiY3RybEtleSIsInNoaWZ0S2V5Iiwia2V5IiwidG9Mb3dlckNhc2UiLCJwcmV2ZW50RGVmYXVsdCIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiZmV0Y2hHcm91cHMiLCJmZXRjaFBlbmFsdGllcyIsInJlcyIsImdldCIsImRhdGEiLCJlcnIiLCJlcnJvciIsInBlbmFsdGllcyIsIm1hcCIsInAiLCJncm91cCIsImZpbmQiLCJnIiwiX2lkIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwiaW5zdGFsbG1lbnRfYW1vdW50IiwibW9udGhseV9pbnN0YWxsbWVudCIsImdyb3VwX2luc3RhbGxtZW50IiwiZ3JvdXBfaW5zdGFsbCIsIndlZWtseV9pbnN0YWxsbWVudCIsImRhaWx5X2luc3RhbGxtZW50IiwiaGFuZGxlR3JvdXBDaGFuZ2UiLCJleGlzdGluZyIsImdyb3VwRGF0YSIsImhhbmRsZURyYXdlclNhdmUiLCJwb3N0IiwicGVuYWx0eV90eXBlIiwicGVuYWx0eV9yYXRlIiwiZ3JhY2VfZGF5cyIsInBlbmFsdHlfYW1vdW50IiwibGF0ZV9wYXltZW50X2Ftb3VudCIsImxhdGVfcGF5bWVudF9yYXRlIiwiZGF5c19sYXRlX3RocmVzaG9sZCIsInZhY2FudF9jaGl0X3BlbmFsdHlfYW1vdW50IiwidmFjYW50X2NoaXRfZ3JhY2VfZGF5cyIsInZhY2FudF9jaGl0X3BlbmFsdHlfcmF0ZSIsInN1Y2Nlc3MiLCJoYW5kbGVTYXZlIiwid2FybmluZyIsImluc3RhbGxtZW50QW1vdW50IiwiYWRkaXRpb25hbF9jaGFyZ2VzIiwiY29uc29sZSIsIm9wZW5FZGl0RHJhd2VyIiwicm93IiwiZnVsbEdyb3VwIiwibG9nIiwiTnVtYmVyIiwiaGFuZGxlTW9kYWxDYWxjdWxhdGUiLCJ2YWx1ZXMiLCJnZXRGaWVsZHNWYWx1ZSIsInNldEZpZWxkc1ZhbHVlIiwiaGFuZGxlQWRkQ2hhcmdlIiwidmFsaWRhdGVGaWVsZHMiLCJ0aGVuIiwibmV3Q2hhcmdlIiwiaWQiLCJEYXRlIiwibm93IiwibmFtZSIsImNoYXJnZV9uYW1lIiwidHlwZSIsImNoYXJnZV90eXBlIiwiYW1vdW50IiwiY2hhcmdlX2Ftb3VudCIsInJhdGUiLCJjaGFyZ2VfcmF0ZSIsImRlc2NyaXB0aW9uIiwiY2hhcmdlX2Rlc2NyaXB0aW9uIiwicmVzZXRGaWVsZHMiLCJyZW1vdmVBZGRpdGlvbmFsQ2hhcmdlIiwiZmlsdGVyIiwiY2hhcmdlIiwiZmlsdGVyZWRQZW5hbHRpZXMiLCJjb2x1bW5zIiwidGl0bGUiLCJyZW5kZXIiLCJfIiwiX18iLCJpIiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsImNvbG9yIiwiZm9udFdlaWdodCIsImZvbnRTaXplIiwiU3RyaW5nIiwicGFkU3RhcnQiLCJhbGlnbiIsImRhdGFJbmRleCIsInRleHQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJtYXJnaW5SaWdodCIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwidiIsInBhZGRpbmciLCJ0b0xvY2FsZVN0cmluZyIsImZpeGVkIiwiYm9yZGVyIiwibWluSGVpZ2h0IiwiZmxleCIsIm1hcmdpblRvcCIsIm1hcmdpbkJvdHRvbSIsImJveFNoYWRvdyIsInBvc2l0aW9uIiwib3ZlcmZsb3ciLCJ0b3AiLCJyaWdodCIsInRyYW5zZm9ybSIsInpJbmRleCIsImJhY2tkcm9wRmlsdGVyIiwibWFyZ2luIiwiYm9yZGVyQm90dG9tIiwibGVuZ3RoIiwicmVkdWNlIiwiYWNjIiwiZ2FwIiwidmFsIiwibGF0ZUZlZSIsInJlcGxhY2UiLCJwYWRkaW5nTGVmdCIsInBhZGRpbmdSaWdodCIsInBhZ2VTaXplIiwic2hvd1NpemVDaGFuZ2VyIiwic2hvd1RvdGFsIiwidG90YWwiLCJyYW5nZSIsIngiLCJib3JkZXJUb3BMZWZ0UmFkaXVzIiwiYm9yZGVyVG9wUmlnaHRSYWRpdXMiLCJ0ZXh0QWxpZ24iLCJwcmV2IiwiaXNOYU4iLCJyZXF1aXJlZCIsInByZXZWYWx1ZXMiLCJjdXJyZW50VmFsdWVzIiwiZ2V0RmllbGRWYWx1ZSIsImNoYXJnZVR5cGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQZW5hbHR5U2V0dGluZ3MuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTZXR0aW5nU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NldHRpbmdTaWRlYmFyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQge1xyXG4gIFNlbGVjdCxcclxuICBJbnB1dE51bWJlcixcclxuICBEcmF3ZXIsXHJcbiAgQnV0dG9uLFxyXG4gIG1lc3NhZ2UsXHJcbiAgQ2FyZCxcclxuICBSb3csXHJcbiAgQ29sLFxyXG4gIFRhYmxlLFxyXG4gIE1vZGFsLFxyXG4gIEZvcm0sXHJcbiAgU3BhY2UsXHJcbiAgVHlwb2dyYXBoeSxcclxuICBTdGF0aXN0aWMsXHJcbiAgRGl2aWRlcixcclxuICBUYWJzLFxyXG4gIFRhZyxcclxuICBFbXB0eSxcclxuICBDb2xsYXBzZSxcclxuICBQcm9ncmVzcyxcclxuICBUb29sdGlwLFxyXG4gIEF2YXRhcixcclxuICBJbnB1dCxcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kU2F2ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQge1xyXG4gIENhbGN1bGF0b3JPdXRsaW5lZCxcclxuICBUZWFtT3V0bGluZWQsXHJcbiAgRWRpdE91dGxpbmVkLFxyXG4gIEZpbGVUZXh0T3V0bGluZWQsXHJcbiAgQ2hlY2tDaXJjbGVPdXRsaW5lZCxcclxuICBUaHVuZGVyYm9sdE91dGxpbmVkLFxyXG4gIFNldHRpbmdPdXRsaW5lZCxcclxuICBDbG9ja0NpcmNsZU91dGxpbmVkLFxyXG4gIFBlcmNlbnRhZ2VPdXRsaW5lZCxcclxuICBEb2xsYXJPdXRsaW5lZCxcclxuICBDYWxlbmRhck91dGxpbmVkLFxyXG4gIFBsdXNPdXRsaW5lZCxcclxuICBJbmZvQ2lyY2xlT3V0bGluZWQsXHJcbiAgRGVsZXRlT3V0bGluZWQsXHJcbiAgRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCxcclxuICBEb2xsYXJDaXJjbGVPdXRsaW5lZCxcclxuICBXYXJuaW5nT3V0bGluZWQsXHJcbiAgU2NoZWR1bGVPdXRsaW5lZCxcclxuICBNb25leUNvbGxlY3RPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuXHJcbmNvbnN0IHsgVGl0bGUsIFRleHQsIFBhcmFncmFwaCB9ID0gVHlwb2dyYXBoeTtcclxuY29uc3QgeyBUYWJQYW5lIH0gPSBUYWJzO1xyXG5jb25zdCB7IFBhbmVsIH0gPSBDb2xsYXBzZTtcclxuY29uc3QgeyBTZWFyY2ggfSA9IElucHV0O1xyXG5cclxuY29uc3QgUGVuYWx0eVNldHRpbmdzID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtwZW5hbHR5UmF0ZSwgc2V0UGVuYWx0eVJhdGVdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2dyYWNlRGF5cywgc2V0R3JhY2VEYXlzXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtwZW5hbHR5QW1vdW50LCBzZXRQZW5hbHR5QW1vdW50XSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtsYXRlUGF5bWVudEFtb3VudCwgc2V0TGF0ZVBheW1lbnRBbW91bnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2RheXNMYXRlVGhyZXNob2xkLCBzZXREYXlzTGF0ZVRocmVzaG9sZF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzdG9yZWRQZW5hbHRpZXMsIHNldFN0b3JlZFBlbmFsdGllc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0RHJhd2VyT3Blbiwgc2V0RWRpdERyYXdlck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0aW5nUGVuYWx0eSwgc2V0RWRpdGluZ1BlbmFsdHldID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2VkaXRSb3csIHNldEVkaXRSb3ddID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW21vZGFsRm9ybV0gPSBGb3JtLnVzZUZvcm0oKTtcclxuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUoXCJjb25maWd1cmVcIik7XHJcbiAgY29uc3QgW2FkZGl0aW9uYWxDaGFyZ2VzLCBzZXRBZGRpdGlvbmFsQ2hhcmdlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzQWRkQ2hhcmdlTW9kYWxPcGVuLCBzZXRJc0FkZENoYXJnZU1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FkZENoYXJnZUZvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgaXNHcm91cFNlbGVjdGVkID0gISFzZWxlY3RlZEdyb3VwO1xyXG5cclxuICBjb25zdCBbdmFjYW50Q2hpdFBlbmFsdHlBbW91bnQsIHNldFZhY2FudENoaXRQZW5hbHR5QW1vdW50XSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFt2YWNhbnRDaGl0R3JhY2VEYXlzLCBzZXRWYWNhbnRDaGl0R3JhY2VEYXlzXSA9IHVzZVN0YXRlKDMwKTtcclxuICBjb25zdCBbdmFjYW50Q2hpdFBlbmFsdHlSYXRlLCBzZXRWYWNhbnRDaGl0UGVuYWx0eVJhdGVdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIGNvbnN0IFtsYXRlUGF5bWVudFJhdGUsIHNldExhdGVQYXltZW50UmF0ZV0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgY29uc3QgW3BlbmFsdHlQcmV2aWV3LCBzZXRQZW5hbHR5UHJldmlld10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2hvd1BlbmFsdHlQcmV2aWV3LCBzZXRTaG93UGVuYWx0eVByZXZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IEdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG5cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzZWxlY3RlZEdyb3VwICYmIHBlbmFsdHlSYXRlID49IDApIHtcclxuICAgICAgY29uc3QgaW5zdGFsbG1lbnQgPSBnZXRJbnN0YWxsbWVudEFtb3VudChzZWxlY3RlZEdyb3VwKTtcclxuICAgICAgY29uc3QgcGVuYWx0eSA9IHBhcnNlRmxvYXQoKChpbnN0YWxsbWVudCAqIHBlbmFsdHlSYXRlKSAvIDEwMCkudG9GaXhlZCgyKSk7XHJcbiAgICAgIHNldFBlbmFsdHlBbW91bnQocGVuYWx0eSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRQZW5hbHR5QW1vdW50KDApO1xyXG4gICAgfVxyXG4gIH0sIFtwZW5hbHR5UmF0ZSwgc2VsZWN0ZWRHcm91cF0pO1xyXG5cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZSkgPT4ge1xyXG4gICAgICAvLyBTa2lwIGlmIHR5cGluZyBpbiBpbnB1dCwgdGV4dGFyZWEsIGV0Yy5cclxuICAgICAgaWYgKFsnSU5QVVQnLCAnVEVYVEFSRUEnLCAnU0VMRUNUJ10uaW5jbHVkZXMoZS50YXJnZXQudGFnTmFtZSkpIHJldHVybjtcclxuXHJcbiAgICAgIGlmIChlLmN0cmxLZXkgJiYgZS5zaGlmdEtleSAmJiBlLmtleS50b0xvd2VyQ2FzZSgpID09PSAnbScpIHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgbmF2aWdhdGUoJy9wZW5hbHR5LW1vbml0b3InKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xyXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XHJcbiAgfSwgW25hdmlnYXRlXSk7XHJcblxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICAgIGZldGNoUGVuYWx0aWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwXCIpO1xyXG4gICAgICBzZXRHcm91cHMocmVzLmRhdGEgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBncm91cHNcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hQZW5hbHRpZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL3BlbmFsdHkvcGVuYWx0eS1zZXR0aW5nc1wiKTtcclxuICAgICAgY29uc3QgcGVuYWx0aWVzID0gKHJlcy5kYXRhIHx8IFtdKS5tYXAoKHApID0+IHtcclxuICAgICAgICBjb25zdCBncm91cCA9IGdyb3Vwcy5maW5kKChnKSA9PiBnLl9pZCA9PT0gcC5ncm91cF9pZCk7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfbmFtZSB8fCBwLmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGluc3RhbGxtZW50X2Ftb3VudDogZ3JvdXBcclxuICAgICAgICAgICAgPyBncm91cC5tb250aGx5X2luc3RhbGxtZW50IHx8XHJcbiAgICAgICAgICAgIGdyb3VwLmdyb3VwX2luc3RhbGxtZW50IHx8XHJcbiAgICAgICAgICAgIGdyb3VwLmdyb3VwX2luc3RhbGwgfHxcclxuICAgICAgICAgICAgZ3JvdXAud2Vla2x5X2luc3RhbGxtZW50IHx8XHJcbiAgICAgICAgICAgIGdyb3VwLmRhaWx5X2luc3RhbGxtZW50IHx8XHJcbiAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgOiBwLmluc3RhbGxtZW50X2Ftb3VudCB8fCAwLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTdG9yZWRQZW5hbHRpZXMocGVuYWx0aWVzKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGxvYWQgcGVuYWx0eSBzZXR0aW5nc1wiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldEluc3RhbGxtZW50QW1vdW50ID0gKGdyb3VwKSA9PiB7XHJcbiAgICBpZiAoIWdyb3VwKSByZXR1cm4gMDtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIGdyb3VwLm1vbnRobHlfaW5zdGFsbG1lbnQgfHxcclxuICAgICAgZ3JvdXAuZ3JvdXBfaW5zdGFsbG1lbnQgfHxcclxuICAgICAgZ3JvdXAuZ3JvdXBfaW5zdGFsbCB8fFxyXG4gICAgICBncm91cC53ZWVrbHlfaW5zdGFsbG1lbnQgfHxcclxuICAgICAgZ3JvdXAuZGFpbHlfaW5zdGFsbG1lbnQgfHxcclxuICAgICAgMFxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cENoYW5nZSA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgY29uc3QgZ3JvdXAgPSBncm91cHMuZmluZChnID0+IGcuX2lkID09PSB2YWx1ZSk7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwKGdyb3VwKTtcclxuXHJcbiAgICBjb25zdCBleGlzdGluZyA9IHN0b3JlZFBlbmFsdGllcy5maW5kKHAgPT4gcC5ncm91cF9pZCA9PT0gdmFsdWUpO1xyXG5cclxuICAgIGlmIChleGlzdGluZykge1xyXG4gICAgICBzZXRQZW5hbHR5UHJldmlldyh7XHJcbiAgICAgICAgLi4uZXhpc3RpbmcsXHJcbiAgICAgICAgbW9udGhseV9pbnN0YWxsbWVudDogZ3JvdXA/Lm1vbnRobHlfaW5zdGFsbG1lbnQgfHwgMCxcclxuICAgICAgICB3ZWVrbHlfaW5zdGFsbG1lbnQ6IGdyb3VwPy53ZWVrbHlfaW5zdGFsbG1lbnQgfHwgMCxcclxuICAgICAgICBkYWlseV9pbnN0YWxsbWVudDogZ3JvdXA/LmRhaWx5X2luc3RhbGxtZW50IHx8IDAsXHJcbiAgICAgICAgZ3JvdXBEYXRhOiBncm91cFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0U2hvd1BlbmFsdHlQcmV2aWV3KHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHJlc2V0IGZpZWxkc1xyXG4gICAgc2V0UGVuYWx0eVJhdGUoMCk7XHJcbiAgICBzZXRHcmFjZURheXMoMCk7XHJcbiAgICBzZXRQZW5hbHR5QW1vdW50KDApO1xyXG4gICAgc2V0TGF0ZVBheW1lbnRBbW91bnQoMCk7XHJcbiAgICBzZXRMYXRlUGF5bWVudFJhdGUoMCk7XHJcbiAgICBzZXREYXlzTGF0ZVRocmVzaG9sZCgwKTtcclxuICAgIHNldEFkZGl0aW9uYWxDaGFyZ2VzKFtdKTtcclxuICB9O1xyXG5cclxuXHJcblxyXG4gIGNvbnN0IGhhbmRsZURyYXdlclNhdmUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWVkaXRpbmdQZW5hbHR5KSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkucG9zdChgL3BlbmFsdHkvcGVuYWx0eS1zZXR0aW5ncy8ke2VkaXRpbmdQZW5hbHR5Lmdyb3VwX2lkfWAsIHtcclxuICAgICAgICBwZW5hbHR5X3R5cGU6IFwicGVyY2VudGFnZVwiLFxyXG4gICAgICAgIHBlbmFsdHlfcmF0ZTogZWRpdGluZ1BlbmFsdHkucGVuYWx0eV9yYXRlLFxyXG4gICAgICAgIGdyYWNlX2RheXM6IGVkaXRpbmdQZW5hbHR5LmdyYWNlX2RheXMsXHJcbiAgICAgICAgcGVuYWx0eV9hbW91bnQ6IGVkaXRpbmdQZW5hbHR5LnBlbmFsdHlfYW1vdW50LFxyXG4gICAgICAgIGxhdGVfcGF5bWVudF9hbW91bnQ6IGVkaXRpbmdQZW5hbHR5LmxhdGVfcGF5bWVudF9hbW91bnQsXHJcbiAgICAgICAgbGF0ZV9wYXltZW50X3JhdGU6IGVkaXRpbmdQZW5hbHR5LmxhdGVfcGF5bWVudF9yYXRlLFxyXG4gICAgICAgIGRheXNfbGF0ZV90aHJlc2hvbGQ6IGVkaXRpbmdQZW5hbHR5LmRheXNfbGF0ZV90aHJlc2hvbGQsXHJcbiAgICAgICAgaW5zdGFsbG1lbnRfYW1vdW50OiBlZGl0aW5nUGVuYWx0eS5pbnN0YWxsbWVudF9hbW91bnQsXHJcbiAgICAgICAgZ3JvdXBfbmFtZTogZWRpdGluZ1BlbmFsdHkuZ3JvdXBfbmFtZSxcclxuICAgICAgICB2YWNhbnRfY2hpdF9wZW5hbHR5X2Ftb3VudDogZWRpdGluZ1BlbmFsdHkudmFjYW50X2NoaXRfcGVuYWx0eV9hbW91bnQsXHJcbiAgICAgICAgdmFjYW50X2NoaXRfZ3JhY2VfZGF5czogZWRpdGluZ1BlbmFsdHkudmFjYW50X2NoaXRfZ3JhY2VfZGF5cyxcclxuICAgICAgICB2YWNhbnRfY2hpdF9wZW5hbHR5X3JhdGU6IGVkaXRpbmdQZW5hbHR5LnZhY2FudF9jaGl0X3BlbmFsdHlfcmF0ZSxcclxuICAgICAgfSk7XHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIlBlbmFsdHkgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgIHNldEVkaXREcmF3ZXJPcGVuKGZhbHNlKTtcclxuICAgICAgZmV0Y2hQZW5hbHRpZXMoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBwZW5hbHR5XCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkR3JvdXApIHJldHVybiBtZXNzYWdlLndhcm5pbmcoXCJTZWxlY3QgYSBncm91cFwiKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRTYXZpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IGluc3RhbGxtZW50QW1vdW50ID0gZ2V0SW5zdGFsbG1lbnRBbW91bnQoc2VsZWN0ZWRHcm91cCk7XHJcblxyXG4gICAgICBhd2FpdCBhcGkucG9zdChgL3BlbmFsdHkvcGVuYWx0eS1zZXR0aW5ncy8ke3NlbGVjdGVkR3JvdXAuX2lkfWAsIHtcclxuICAgICAgICBwZW5hbHR5X3R5cGU6IFwicGVyY2VudGFnZVwiLFxyXG4gICAgICAgIHBlbmFsdHlfcmF0ZTogcGVuYWx0eVJhdGUsXHJcbiAgICAgICAgZ3JhY2VfZGF5czogZ3JhY2VEYXlzLFxyXG4gICAgICAgIHBlbmFsdHlfYW1vdW50OiBwZW5hbHR5QW1vdW50LFxyXG4gICAgICAgIGxhdGVfcGF5bWVudF9hbW91bnQ6IGxhdGVQYXltZW50QW1vdW50LFxyXG4gICAgICAgIGxhdGVfcGF5bWVudF9yYXRlOiBsYXRlUGF5bWVudFJhdGUsXHJcbiAgICAgICAgZGF5c19sYXRlX3RocmVzaG9sZDogZGF5c0xhdGVUaHJlc2hvbGQsXHJcbiAgICAgICAgaW5zdGFsbG1lbnRfYW1vdW50OiBpbnN0YWxsbWVudEFtb3VudCxcclxuICAgICAgICBncm91cF9uYW1lOiBzZWxlY3RlZEdyb3VwLmdyb3VwX25hbWUsXHJcbiAgICAgICAgYWRkaXRpb25hbF9jaGFyZ2VzOiBhZGRpdGlvbmFsQ2hhcmdlcyxcclxuICAgICAgICB2YWNhbnRfY2hpdF9wZW5hbHR5X2Ftb3VudDogdmFjYW50Q2hpdFBlbmFsdHlBbW91bnQsXHJcbiAgICAgICAgdmFjYW50X2NoaXRfZ3JhY2VfZGF5czogdmFjYW50Q2hpdEdyYWNlRGF5cyxcclxuICAgICAgICB2YWNhbnRfY2hpdF9wZW5hbHR5X3JhdGU6IHZhY2FudENoaXRQZW5hbHR5UmF0ZSxcclxuXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiUGVuYWx0eSBzYXZlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgIGZldGNoUGVuYWx0aWVzKCk7XHJcbiAgICAgIHNldFNlbGVjdGVkR3JvdXAobnVsbCk7XHJcbiAgICAgIHNldFBlbmFsdHlSYXRlKDApO1xyXG4gICAgICBzZXRHcmFjZURheXMoMCk7XHJcbiAgICAgIHNldFBlbmFsdHlBbW91bnQoMCk7XHJcbiAgICAgIHNldExhdGVQYXltZW50QW1vdW50KDApO1xyXG4gICAgICBzZXREYXlzTGF0ZVRocmVzaG9sZCgwKTtcclxuICAgICAgc2V0QWRkaXRpb25hbENoYXJnZXMoW10pO1xyXG4gICAgICBzZXRBY3RpdmVUYWIoXCJyZWNvcmRzXCIpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBzYXZlIHBlbmFsdHlcIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRTYXZpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9wZW5FZGl0RHJhd2VyID0gKHJvdykgPT4ge1xyXG4gICAgY29uc3QgZnVsbEdyb3VwID0gZ3JvdXBzLmZpbmQoZyA9PiBnLl9pZCA9PT0gcm93Lmdyb3VwX2lkKTtcclxuICAgIGNvbnNvbGUubG9nKGdyb3Vwcywgcm93LCByb3cuZ3JvdXBfaWQsICd0aGlzIGlzIGZ1bGwgZ3JvdXAnKVxyXG4gICAgc2V0RWRpdGluZ1BlbmFsdHkoe1xyXG4gICAgICAuLi5yb3csXHJcblxyXG4gICAgICAvLyBhbHdheXMgcHVsbCB0aGVzZSBMSVZFIGZyb20gZ3JvdXAgY29sbGVjdGlvblxyXG4gICAgICBpbnN0YWxsbWVudF9hbW91bnQ6XHJcbiAgICAgICAgTnVtYmVyKGZ1bGxHcm91cD8ubW9udGhseV9pbnN0YWxsbWVudCkgfHxcclxuICAgICAgICBOdW1iZXIoZnVsbEdyb3VwPy53ZWVrbHlfaW5zdGFsbG1lbnQpIHx8XHJcbiAgICAgICAgTnVtYmVyKGZ1bGxHcm91cD8uZGFpbHlfaW5zdGFsbG1lbnQpIHx8XHJcbiAgICAgICAgMCxcclxuXHJcbiAgICAgIG1vbnRobHlfaW5zdGFsbG1lbnQ6IE51bWJlcihmdWxsR3JvdXA/Lm1vbnRobHlfaW5zdGFsbG1lbnQgfHwgMCksXHJcbiAgICAgIHdlZWtseV9pbnN0YWxsbWVudDogTnVtYmVyKGZ1bGxHcm91cD8ud2Vla2x5X2luc3RhbGxtZW50IHx8IDApLFxyXG4gICAgICBkYWlseV9pbnN0YWxsbWVudDogTnVtYmVyKGZ1bGxHcm91cD8uZGFpbHlfaW5zdGFsbG1lbnQgfHwgMCksXHJcblxyXG4gICAgICBsYXRlX3BheW1lbnRfYW1vdW50OiByb3cubGF0ZV9wYXltZW50X2Ftb3VudCB8fCAwLFxyXG4gICAgICBkYXlzX2xhdGVfdGhyZXNob2xkOiByb3cuZGF5c19sYXRlX3RocmVzaG9sZCB8fCAwLFxyXG5cclxuICAgICAgdmFjYW50X2NoaXRfcGVuYWx0eV9hbW91bnQ6IHJvdy52YWNhbnRfY2hpdF9wZW5hbHR5X2Ftb3VudCB8fCAwLFxyXG4gICAgICB2YWNhbnRfY2hpdF9ncmFjZV9kYXlzOiByb3cudmFjYW50X2NoaXRfZ3JhY2VfZGF5cyB8fCAwLFxyXG4gICAgICB2YWNhbnRfY2hpdF9wZW5hbHR5X3JhdGU6IHJvdy52YWNhbnRfY2hpdF9wZW5hbHR5X3JhdGUgfHwgMCxcclxuICAgIH0pO1xyXG5cclxuICAgIHNldEVkaXREcmF3ZXJPcGVuKHRydWUpO1xyXG4gIH07XHJcblxyXG5cclxuXHJcblxyXG4gIGNvbnN0IGhhbmRsZU1vZGFsQ2FsY3VsYXRlID0gKCkgPT4ge1xyXG4gICAgY29uc3QgdmFsdWVzID0gbW9kYWxGb3JtLmdldEZpZWxkc1ZhbHVlKCk7XHJcbiAgICBjb25zdCBwZW5hbHR5ID0gcGFyc2VGbG9hdCgoKHZhbHVlcy5pbnN0YWxsbWVudF9hbW91bnQgKiB2YWx1ZXMucGVuYWx0eV9yYXRlKSAvIDEwMCkudG9GaXhlZCgyKSk7XHJcbiAgICBtb2RhbEZvcm0uc2V0RmllbGRzVmFsdWUoeyBwZW5hbHR5X2Ftb3VudDogcGVuYWx0eSB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBZGRDaGFyZ2UgPSAoKSA9PiB7XHJcbiAgICBhZGRDaGFyZ2VGb3JtLnZhbGlkYXRlRmllbGRzKCkudGhlbih2YWx1ZXMgPT4ge1xyXG4gICAgICBjb25zdCBuZXdDaGFyZ2UgPSB7XHJcbiAgICAgICAgaWQ6IERhdGUubm93KCksXHJcbiAgICAgICAgbmFtZTogdmFsdWVzLmNoYXJnZV9uYW1lLFxyXG4gICAgICAgIHR5cGU6IHZhbHVlcy5jaGFyZ2VfdHlwZSxcclxuICAgICAgICBhbW91bnQ6IHZhbHVlcy5jaGFyZ2VfYW1vdW50LFxyXG4gICAgICAgIHJhdGU6IHZhbHVlcy5jaGFyZ2VfcmF0ZSxcclxuICAgICAgICBkZXNjcmlwdGlvbjogdmFsdWVzLmNoYXJnZV9kZXNjcmlwdGlvbixcclxuICAgICAgfTtcclxuICAgICAgc2V0QWRkaXRpb25hbENoYXJnZXMoWy4uLmFkZGl0aW9uYWxDaGFyZ2VzLCBuZXdDaGFyZ2VdKTtcclxuICAgICAgYWRkQ2hhcmdlRm9ybS5yZXNldEZpZWxkcygpO1xyXG4gICAgICBzZXRJc0FkZENoYXJnZU1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIkFkZGl0aW9uYWwgY2hhcmdlIGFkZGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlbW92ZUFkZGl0aW9uYWxDaGFyZ2UgPSAoaWQpID0+IHtcclxuICAgIHNldEFkZGl0aW9uYWxDaGFyZ2VzKGFkZGl0aW9uYWxDaGFyZ2VzLmZpbHRlcihjaGFyZ2UgPT4gY2hhcmdlLmlkICE9PSBpZCkpO1xyXG4gICAgbWVzc2FnZS5zdWNjZXNzKFwiQ2hhcmdlIHJlbW92ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkUGVuYWx0aWVzID0gc3RvcmVkUGVuYWx0aWVzLmZpbHRlcihwZW5hbHR5ID0+XHJcbiAgICBwZW5hbHR5Lmdyb3VwX25hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXh0LnRvTG93ZXJDYXNlKCkpXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiTm8uXCIsXHJcbiAgICAgIHJlbmRlcjogKF8sIF9fLCBpKSA9PiAoXHJcbiAgICAgICAgPGRpdiBzdHlsZT17e1xyXG4gICAgICAgICAgd2lkdGg6ICczNnB4JyxcclxuICAgICAgICAgIGhlaWdodDogJzM2cHgnLFxyXG4gICAgICAgICAgYm9yZGVyUmFkaXVzOiAnOHB4JyxcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjNjY3ZWVhIDAlLCAjNzY0YmEyIDEwMCUpJyxcclxuICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxyXG4gICAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxyXG4gICAgICAgICAgY29sb3I6ICcjZmZmZmZmJyxcclxuICAgICAgICAgIGZvbnRXZWlnaHQ6ICc2MDAnLFxyXG4gICAgICAgICAgZm9udFNpemU6ICcxNHB4JyxcclxuICAgICAgICB9fT5cclxuICAgICAgICAgIHtTdHJpbmcoaSArIDEpLnBhZFN0YXJ0KDIsICcwJyl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICksXHJcbiAgICAgIHdpZHRoOiA4MCxcclxuICAgICAgYWxpZ246ICdjZW50ZXInLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiR3JvdXAgTmFtZVwiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwiZ3JvdXBfbmFtZVwiLFxyXG4gICAgICByZW5kZXI6ICh0ZXh0KSA9PiAoXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInIH19PlxyXG4gICAgICAgICAgPEF2YXRhciBzdHlsZT17e1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjMTg5MGZmJyxcclxuICAgICAgICAgICAgbWFyZ2luUmlnaHQ6ICcxMnB4JyxcclxuICAgICAgICAgICAgZm9udFdlaWdodDogJ2JvbGQnXHJcbiAgICAgICAgICB9fT5cclxuICAgICAgICAgICAge3RleHQuY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICA8L0F2YXRhcj5cclxuICAgICAgICAgIDxUZXh0IHN0cm9uZyBzdHlsZT17eyBmb250U2l6ZTogJzE0cHgnLCBjb2xvcjogJyMxZTI5M2InIH19Pnt0ZXh0fTwvVGV4dD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIHRpdGxlOiBcIkluc3RhbGxtZW50IEFtb3VudFwiLFxyXG4gICAgLy8gICBkYXRhSW5kZXg6IFwiaW5zdGFsbG1lbnRfYW1vdW50XCIsXHJcbiAgICAvLyAgIGFsaWduOiAncmlnaHQnLFxyXG4gICAgLy8gICByZW5kZXI6ICh2KSA9PiAoXHJcbiAgICAvLyAgICAgPGRpdiBzdHlsZT17e1xyXG4gICAgLy8gICAgICAgYmFja2dyb3VuZDogJyNmMGY5ZmYnLFxyXG4gICAgLy8gICAgICAgcGFkZGluZzogJzRweCA4cHgnLFxyXG4gICAgLy8gICAgICAgYm9yZGVyUmFkaXVzOiAnNnB4JyxcclxuICAgIC8vICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snXHJcbiAgICAvLyAgICAgfX0+XHJcbiAgICAvLyAgICAgICA8VGV4dCBzdHlsZT17eyBmb250V2VpZ2h0OiAnNjAwJywgZm9udFNpemU6ICcxNHB4JywgY29sb3I6ICcjMDM2OWExJyB9fT5cclxuICAgIC8vICAgICAgICAg4oK5e051bWJlcih2IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAvLyAgICAgICA8L1RleHQ+XHJcbiAgICAvLyAgICAgPC9kaXY+XHJcbiAgICAvLyAgICksXHJcbiAgICAvLyB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJQZW5hbHR5IFJhdGVcIixcclxuICAgICAgZGF0YUluZGV4OiBcInBlbmFsdHlfcmF0ZVwiLFxyXG4gICAgICBhbGlnbjogJ2NlbnRlcicsXHJcbiAgICAgIHJlbmRlcjogKHYpID0+IChcclxuICAgICAgICA8UHJvZ3Jlc3NcclxuICAgICAgICAgIHBlcmNlbnQ9e3Z9XHJcbiAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgc3Ryb2tlQ29sb3I9e3tcclxuICAgICAgICAgICAgJzAlJzogJyMxMDhlZTknLFxyXG4gICAgICAgICAgICAnMTAwJSc6ICcjODdkMDY4JyxcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBmb3JtYXQ9eygpID0+IGAke3Z9JWB9XHJcbiAgICAgICAgLz5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIlBlbmFsdHkgQW1vdW50XCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJwZW5hbHR5X2Ftb3VudFwiLFxyXG4gICAgICBhbGlnbjogJ3JpZ2h0JyxcclxuICAgICAgcmVuZGVyOiAodikgPT4gKFxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3tcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICcjZmZmMWYwJyxcclxuICAgICAgICAgIHBhZGRpbmc6ICc0cHggOHB4JyxcclxuICAgICAgICAgIGJvcmRlclJhZGl1czogJzZweCcsXHJcbiAgICAgICAgICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJ1xyXG4gICAgICAgIH19PlxyXG4gICAgICAgICAgPFRleHQgc3R5bGU9e3sgY29sb3I6ICcjY2YxMzIyJywgZm9udFdlaWdodDogJzcwMCcsIGZvbnRTaXplOiAnMTRweCcgfX0+XHJcbiAgICAgICAgICAgIOKCuXtOdW1iZXIodiB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiTGF0ZSBGZWVcIixcclxuICAgICAgZGF0YUluZGV4OiBcImxhdGVfcGF5bWVudF9hbW91bnRcIixcclxuICAgICAgYWxpZ246ICdyaWdodCcsXHJcbiAgICAgIHJlbmRlcjogKHYpID0+IChcclxuICAgICAgICA8ZGl2IHN0eWxlPXt7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAnI2ZmZjdlNicsXHJcbiAgICAgICAgICBwYWRkaW5nOiAnNHB4IDhweCcsXHJcbiAgICAgICAgICBib3JkZXJSYWRpdXM6ICc2cHgnLFxyXG4gICAgICAgICAgZGlzcGxheTogJ2lubGluZS1ibG9jaydcclxuICAgICAgICB9fT5cclxuICAgICAgICAgIDxUZXh0IHN0eWxlPXt7IGNvbG9yOiAnI2Q0NmIwOCcsIGZvbnRXZWlnaHQ6ICc3MDAnLCBmb250U2l6ZTogJzE0cHgnIH19PlxyXG4gICAgICAgICAgICDigrl7TnVtYmVyKHYgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIkdyYWNlIGRheXMgKExhdGUgRmVlKVwiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwiZGF5c19sYXRlX3RocmVzaG9sZFwiLFxyXG4gICAgICBhbGlnbjogJ2NlbnRlcicsXHJcbiAgICAgIHJlbmRlcjogKHYpID0+IChcclxuICAgICAgICA8VGFnIGNvbG9yPVwidmlvbGV0XCIgc3R5bGU9e3sgZm9udFdlaWdodDogJzYwMCcsIGZvbnRTaXplOiAnMTNweCcgfX0+XHJcbiAgICAgICAgICB7dn0gZGF5c1xyXG4gICAgICAgIDwvVGFnPlxyXG4gICAgICApLFxyXG4gICAgfSxcclxuICAgIC8vIHtcclxuICAgIC8vICAgdGl0bGU6IFwiR3JhY2UgRGF5c1wiLFxyXG4gICAgLy8gICBkYXRhSW5kZXg6IFwiZ3JhY2VfZGF5c1wiLFxyXG4gICAgLy8gICBhbGlnbjogJ2NlbnRlcicsXHJcbiAgICAvLyAgIHJlbmRlcjogKHYpID0+IChcclxuICAgIC8vICAgICA8VGFnIGNvbG9yPVwiZ3JlZW5cIiBzdHlsZT17eyBmb250V2VpZ2h0OiAnNjAwJywgZm9udFNpemU6ICcxM3B4JyB9fT5cclxuICAgIC8vICAgICAgIHt2fSBkYXlzXHJcbiAgICAvLyAgICAgPC9UYWc+XHJcbiAgICAvLyAgICksXHJcbiAgICAvLyB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJBY3Rpb25zXCIsXHJcbiAgICAgIGFsaWduOiBcImNlbnRlclwiLFxyXG4gICAgICB3aWR0aDogMTAwLFxyXG4gICAgICBmaXhlZDogJ3JpZ2h0JyxcclxuICAgICAgcmVuZGVyOiAoXywgcm93KSA9PiAoXHJcbiAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgaWNvbj17PEVkaXRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5FZGl0RHJhd2VyKHJvdyl9XHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc2cHgnLFxyXG4gICAgICAgICAgICBmb250V2VpZ2h0OiAnNTAwJyxcclxuICAgICAgICAgICAgaGVpZ2h0OiAnMzJweCcsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0ZmFjZmUgMCUsICMwMGYyZmUgMTAwJSknLFxyXG4gICAgICAgICAgICBib3JkZXI6ICdub25lJyxcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgRWRpdFxyXG4gICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICApLFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnI2YwZjJmNScsIG1pbkhlaWdodDogJzEwMHZoJyB9fT5cclxuICAgICAgPFNldHRpbmdTaWRlYmFyIC8+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSB9fT5cclxuICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6ICcyNHB4IDMycHgnLCBtYXJnaW5Ub3A6ICcxMHB4JyB9fT5cclxuXHJcbiAgICAgICAgICBcclxuICAgICAgICAgIHsvKiBIZWFkZXIgU2VjdGlvbiAqL31cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3tcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMjRweCcsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0ZmFjZmUgMCUsICMwMGYyZmUgMTAwJSknLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxNnB4JyxcclxuICAgICAgICAgICAgcGFkZGluZzogJzMycHgnLFxyXG4gICAgICAgICAgICBib3hTaGFkb3c6ICcwIDEwcHggMjBweCByZ2JhKDAsIDAsIDAsIDAuMSknLFxyXG4gICAgICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcclxuICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxyXG4gICAgICAgICAgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdhYnNvbHV0ZScsIHRvcDogMCwgcmlnaHQ6IDAsIGhlaWdodDogJzEwMCUnLCB3aWR0aDogJzQwJScsIGJhY2tncm91bmQ6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSknLCB0cmFuc2Zvcm06ICdza2V3WCgtMTVkZWcpJyB9fT48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ3JlbGF0aXZlJywgekluZGV4OiAxIH19PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgbWFyZ2luQm90dG9tOiAnMTZweCcgfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiAnNjRweCcsXHJcbiAgICAgICAgICAgICAgICAgIGhlaWdodDogJzY0cHgnLFxyXG4gICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxNnB4JyxcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4yKScsXHJcbiAgICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXHJcbiAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luUmlnaHQ6ICcyMHB4JyxcclxuICAgICAgICAgICAgICAgICAgYmFja2Ryb3BGaWx0ZXI6ICdibHVyKDRweCknLFxyXG4gICAgICAgICAgICAgICAgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxTZXR0aW5nT3V0bGluZWQgc3R5bGU9e3sgZm9udFNpemU6ICczMnB4JywgY29sb3I6ICcjZmZmZmZmJyB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezF9IHN0eWxlPXt7IG1hcmdpbjogMCwgZm9udFdlaWdodDogJzcwMCcsIGNvbG9yOiAnI2ZmZmZmZicsIGZvbnRTaXplOiAnMjhweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgUGVuYWx0eSBTZXR0aW5nc1xyXG4gICAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPFBhcmFncmFwaCBzdHlsZT17eyBtYXJnaW46IDAsIGNvbG9yOiAncmdiYSgyNTUsIDI1NSwgMjU1LCAwLjkpJywgZm9udFNpemU6ICcxNnB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICBBZGQgcGVuYWx0eSByYXRlcywgbGF0ZSBmZWVzLCBhbmQgZ3JhY2UgcGVyaW9kcyBmb3IgR3JvdXBzXHJcbiAgICAgICAgICAgICAgICAgIDwvUGFyYWdyYXBoPiAqL31cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXNoZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL3BlbmFsdHktbW9uaXRvcicpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDE2IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdvIHRvIFBlbmFsdHkgTW9uaXRvclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzE2cHgnLFxyXG4gICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICAgICAgICAgIGJveFNoYWRvdzogJzAgNHB4IDEycHggcmdiYSgwLCAwLCAwLCAwLjA1KScsXHJcbiAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMjRweCcsXHJcbiAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGJvZHlTdHlsZT17eyBwYWRkaW5nOiAwIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxUYWJzXHJcbiAgICAgICAgICAgICAgYWN0aXZlS2V5PXthY3RpdmVUYWJ9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldEFjdGl2ZVRhYn1cclxuICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDAgfX1cclxuICAgICAgICAgICAgICB0YWJCYXJTdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogJzAgMjRweCcsXHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnI2ZmZmZmZicsXHJcbiAgICAgICAgICAgICAgICBib3JkZXJCb3R0b206ICcxcHggc29saWQgI2YwZjBmMCdcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFRhYlBhbmVcclxuICAgICAgICAgICAgICAgIHRhYj17XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNldHRpbmdPdXRsaW5lZCBzdHlsZT17eyBtYXJnaW5SaWdodDogJzhweCcgfX0gLz5cclxuICAgICAgICAgICAgICAgICAgICBBZGQgUGVuYWx0eVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBrZXk9XCJjb25maWd1cmVcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzI0cHgnLCBiYWNrZ3JvdW5kOiAnI2ZhZmFmYScgfX0+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBTdGF0cyBDYXJkcyAqL31cclxuICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfSBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcyNHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhcmQgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzY2N2VlYSAwJSwgIzc2NGJhMiAxMDAlKScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzEwMCUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3hTaGFkb3c6ICcwIDRweCAxMnB4IHJnYmEoMTAyLCAxMjYsIDIzNCwgMC4zKScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgdG9wOiAwLCByaWdodDogMCwgaGVpZ2h0OiAnMTAwJScsIHdpZHRoOiAnMzAlJywgYmFja2dyb3VuZDogJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4xKScsIHRyYW5zZm9ybTogJ3NrZXdYKC0xNWRlZyknIH19PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiAncmVsYXRpdmUnLCB6SW5kZXg6IDEsIHBhZGRpbmc6ICcyMHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiAncmdiYSgyNTUsIDI1NSwgMjU1LCAwLjkpJywgZm9udFNpemU6ICcxNHB4JywgZm9udFdlaWdodDogJzUwMCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgR3JvdXBzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cHMubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlZml4PXs8VGVhbU91dGxpbmVkIHN0eWxlPXt7IGNvbG9yOiAncmdiYSgyNTUsIDI1NSwgMjU1LCAwLjkpJywgZm9udFNpemU6ICcyNHB4JyB9fSAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3sgY29sb3I6ICcjZmZmZmZmJywgZm9udFdlaWdodDogJzcwMCcsIGZvbnRTaXplOiAnMjhweCcgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhcmQgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywgI2YwOTNmYiAwJSwgI2Y1NTc2YyAxMDAlKScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzEwMCUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3hTaGFkb3c6ICcwIDRweCAxMnB4IHJnYmEoMjQwLCAxNDcsIDI1MSwgMC4zKScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgdG9wOiAwLCByaWdodDogMCwgaGVpZ2h0OiAnMTAwJScsIHdpZHRoOiAnMzAlJywgYmFja2dyb3VuZDogJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4xKScsIHRyYW5zZm9ybTogJ3NrZXdYKC0xNWRlZyknIH19PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiAncmVsYXRpdmUnLCB6SW5kZXg6IDEsIHBhZGRpbmc6ICcyMHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiAncmdiYSgyNTUsIDI1NSwgMjU1LCAwLjkpJywgZm9udFNpemU6ICcxNHB4JywgZm9udFdlaWdodDogJzUwMCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWN0aXZlIFBlbmFsdGllc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3RvcmVkUGVuYWx0aWVzLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD17PEZpbGVUZXh0T3V0bGluZWQgc3R5bGU9e3sgY29sb3I6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOSknLCBmb250U2l6ZTogJzI0cHgnIH19IC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17eyBjb2xvcjogJyNmZmZmZmYnLCBmb250V2VpZ2h0OiAnNzAwJywgZm9udFNpemU6ICcyOHB4JyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2FyZCBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxMnB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjZmE3MDlhIDAlLCAjZmVlMTQwIDEwMCUpJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAnMTAwJScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogJzAgNHB4IDEycHggcmdiYSgyNTAsIDExMiwgMTU0LCAwLjMpJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcclxuICAgICAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiAnYWJzb2x1dGUnLCB0b3A6IDAsIHJpZ2h0OiAwLCBoZWlnaHQ6ICcxMDAlJywgd2lkdGg6ICczMCUnLCBiYWNrZ3JvdW5kOiAncmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEpJywgdHJhbnNmb3JtOiAnc2tld1goLTE1ZGVnKScgfX0+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdyZWxhdGl2ZScsIHpJbmRleDogMSwgcGFkZGluZzogJzIwcHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOSknLCBmb250U2l6ZTogJzE0cHgnLCBmb250V2VpZ2h0OiAnNTAwJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBdmcuIExhdGUgRmVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3RvcmVkUGVuYWx0aWVzLmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAoc3RvcmVkUGVuYWx0aWVzLnJlZHVjZSgoYWNjLCBwKSA9PiBhY2MgKyAocC5sYXRlX3BheW1lbnRfYW1vdW50IHx8IDApLCAwKSAvIHN0b3JlZFBlbmFsdGllcy5sZW5ndGgpLnRvRml4ZWQoMilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17eyBjb2xvcjogJyNmZmZmZmYnLCBmb250V2VpZ2h0OiAnNzAwJywgZm9udFNpemU6ICcyOHB4JyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBHcm91cCBTZWxlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxDYXJkIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMDUpJyxcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcyNHB4JyxcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnI2ZmZmZmZicsXHJcbiAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzIwcHggMjRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezR9IHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpblRvcDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMjRweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAnIzFlMjkzYicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6ICc2MDAnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogJzE4cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInXHJcbiAgICAgICAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRlYW1PdXRsaW5lZCBzdHlsZT17eyBtYXJnaW5SaWdodDogJzhweCcsIGNvbG9yOiAnIzE4OTBmZicgfX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfSBhbGlnbj1cIm1pZGRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBtZD17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIHN0eWxlPXt7IGNvbG9yOiAnIzQ3NTU2OScsIGZvbnRTaXplOiAnMTRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJkYW5nZXJcIj4gKjwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGEgZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17IWdyb3Vwcy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlR3JvdXBDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cD8uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtnLl9pZH0gdmFsdWU9e2cuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zy5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRHcm91cCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzE2cHgnLCB3aWR0aDogJzEwMCUnIH19PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1vbnRobHkgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzZweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgc3R5bGU9e3sgY29sb3I6ICcjNDc1NTY5JywgZm9udFNpemU6ICcxNHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTW9udGhseVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICcxMnB4IDE2cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZjBmOWZmLCAjZTBmMmZlKScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJzFweCBzb2xpZCAjYmFlNmZkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnOHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogJzYwMCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMTZweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAnIzAzNjlhMSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e051bWJlcihzZWxlY3RlZEdyb3VwLm1vbnRobHlfaW5zdGFsbG1lbnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFdlZWtseSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnNnB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBzdHlsZT17eyBjb2xvcjogJyM0NzU1NjknLCBmb250U2l6ZTogJzE0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBXZWVrbHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAnMTJweCAxNnB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZlZjljMywgI2ZlZjNjNyknLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6ICcxcHggc29saWQgI2ZkZTY4YScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzhweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6ICc2MDAnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogJzE2cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJyNjYThhMDQnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtOdW1iZXIoc2VsZWN0ZWRHcm91cC53ZWVrbHlfaW5zdGFsbG1lbnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIERhaWx5ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc2cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIHN0eWxlPXt7IGNvbG9yOiAnIzQ3NTU2OScsIGZvbnRTaXplOiAnMTRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERhaWx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogJzEycHggMTZweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZWYyZjIsICNmZWUyZTIpJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkICNmZWNhY2EnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc4cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiAnNjAwJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcxNnB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICcjYjkxYzFjJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKHNlbGVjdGVkR3JvdXAuZGFpbHlfaW5zdGFsbG1lbnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgeyFwZW5hbHR5UHJldmlldyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgIHtpc0dyb3VwU2VsZWN0ZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBMYXRlIENoYXJnZXMgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZCBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6ICdub25lJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogJzAgNHB4IDEycHggcmdiYSgwLCAwLCAwLCAwLjA1KScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcyNHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICcjZmZmZmZmJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmZjdlNiwgI2ZmZjJjYyknLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAnMTZweCAyNHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tOiAnMXB4IHNvbGlkICNmZmQ1OTEnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRpdGxlIGxldmVsPXs0fSBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJyNkNDZiMDgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6ICc2MDAnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMThweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUaHVuZGVyYm9sdE91dGxpbmVkIHN0eWxlPXt7IG1hcmdpblJpZ2h0OiAnOHB4JyB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExhdGUgQ2hhcmdlc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6ICcyNHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBtZD17Nn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzhweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBzdHlsZT17eyBjb2xvcjogJyM0NzU1NjknLCBmb250U2l6ZTogJzE0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyYWNlIERheXMgKExhdGUgRmVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJkYW5nZXJcIj4gKjwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0TnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXlzTGF0ZVRocmVzaG9sZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldERheXNMYXRlVGhyZXNob2xkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRocmVzaG9sZCBkYXlzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgc3R5bGU9e3sgY29sb3I6ICcjNDc1NTY5JywgZm9udFNpemU6ICcxNHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMYXRlIEZlZSBSYXRlICglKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJkYW5nZXJcIj4gKjwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0TnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heD17MTAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bGF0ZVBheW1lbnRSYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldExhdGVQYXltZW50UmF0ZSh2YWwgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFtb3VudCA9IGdldEluc3RhbGxtZW50QW1vdW50KHNlbGVjdGVkR3JvdXApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbGF0ZUZlZSA9IGFtb3VudCA+IDAgPyBwYXJzZUZsb2F0KCgoYW1vdW50ICogKHZhbCB8fCAwKSkgLyAxMDApLnRvRml4ZWQoMikpIDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldExhdGVQYXltZW50QW1vdW50KGxhdGVGZWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgc3R5bGU9e3sgY29sb3I6ICcjNDc1NTY5JywgZm9udFNpemU6ICcxNHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMYXRlIEZlZSBBbW91bnQgKOKCuSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwiZGFuZ2VyXCI+ICo8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bGF0ZVBheW1lbnRBbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TGF0ZVBheW1lbnRBbW91bnQodmFsIHx8IDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZEdyb3VwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhbW91bnQgPSBnZXRJbnN0YWxsbWVudEFtb3VudChzZWxlY3RlZEdyb3VwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJhdGUgPSBhbW91bnQgPiAwID8gcGFyc2VGbG9hdCgoKHZhbCB8fCAwKSAvIGFtb3VudCkgKiAxMDApLnRvRml4ZWQoMikgOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TGF0ZVBheW1lbnRSYXRlKHBhcnNlRmxvYXQocmF0ZSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybWF0dGVyPXt2YWx1ZSA9PiBg4oK5JHt2YWx1ZX1gLnJlcGxhY2UoL1xcQig/PShcXGR7M30pKyg/IVxcZCkpL2csICcsJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlcj17dmFsdWUgPT4gdmFsdWUucmVwbGFjZSgvXFzigrlcXHM/fCgsKikvZywgJycpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE92ZXJkdWUgQ2hhcmdlcyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxMnB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMDUpJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogJzI0cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJyNmZmZmZmYnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZmMWYwLCAjZmZjY2M3KScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICcxNnB4IDI0cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJCb3R0b206ICcxcHggc29saWQgI2ZmYTM5ZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezR9IHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAnI2NmMTMyMicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogJzYwMCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcxOHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcidcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENsb2NrQ2lyY2xlT3V0bGluZWQgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICc4cHgnIH19IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3ZlcmR1ZSBDaGFyZ2VzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzI0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8Q29sIHhzPXsyNH0gc209ezEyfSBtZD17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnOHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgc3R5bGU9e3sgY29sb3I6ICcjNDc1NTY5JywgZm9udFNpemU6ICcxNHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyYWNlIERheXMgKE92ZXJkdWUgQ2hhcmdlcylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cImRhbmdlclwiPiAqPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0TnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncmFjZURheXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldEdyYWNlRGF5c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgZGF5c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgc3R5bGU9e3sgY29sb3I6ICcjNDc1NTY5JywgZm9udFNpemU6ICcxNHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZW5hbHR5IFJhdGUgKCUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cImRhbmdlclwiPiAqPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXROdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4PXsxMDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwZW5hbHR5UmF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQZW5hbHR5UmF0ZSh2YWwgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFtb3VudCA9IGdldEluc3RhbGxtZW50QW1vdW50KHNlbGVjdGVkR3JvdXApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGVuYWx0eSA9IGFtb3VudCA+IDAgPyBwYXJzZUZsb2F0KCgoYW1vdW50ICogKHZhbCB8fCAwKSkgLyAxMDApLnRvRml4ZWQoMikpIDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBlbmFsdHlBbW91bnQocGVuYWx0eSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHJhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBtZD17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzhweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBzdHlsZT17eyBjb2xvcjogJyM0NzU1NjknLCBmb250U2l6ZTogJzE0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlbmFsdHkgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cImRhbmdlclwiPiAqPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXROdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BlbmFsdHlBbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGVuYWx0eUFtb3VudCh2YWwgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFtb3VudCA9IGdldEluc3RhbGxtZW50QW1vdW50KHNlbGVjdGVkR3JvdXApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF0ZSA9IGFtb3VudCA+IDAgPyBwYXJzZUZsb2F0KCgodmFsIHx8IDApIC8gYW1vdW50KSAqIDEwMCkudG9GaXhlZCgyKSA6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQZW5hbHR5UmF0ZShwYXJzZUZsb2F0KHJhdGUpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdHRlcj17dmFsdWUgPT4gYOKCuSR7dmFsdWV9YC5yZXBsYWNlKC9cXEIoPz0oXFxkezN9KSsoPyFcXGQpKS9nLCAnLCcpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZXI9e3ZhbHVlID0+IHZhbHVlLnJlcGxhY2UoL1xc4oK5XFxzP3woLCopL2csICcnKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3hTaGFkb3c6ICcwIDRweCAxMnB4IHJnYmEoMCwgMCwgMCwgMC4wNSknLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcyNHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJyNmZmZmZmYnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZlN2NjLCAjZmZkOGE4KScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogJzE2cHggMjRweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tOiAnMXB4IHNvbGlkICNmZmMwNzgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGl0bGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXZlbD17NH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICcjZDk0ODBmJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6ICc2MDAnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcxOHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8V2FybmluZ091dGxpbmVkIHN0eWxlPXt7IG1hcmdpblJpZ2h0OiAnOHB4JyB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE92ZXJkdWUgQ2hhcmdlcyBmb3IgVmFjYW50IENoaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UaXRsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMjRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nPkdyYWNlIERheXMgKFZhY2FudCBDaGl0KTwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3ZhY2FudENoaXRHcmFjZURheXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRWYWNhbnRDaGl0R3JhY2VEYXlzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFZhY2FudCBDaGl0IFBlbmFsdHkgUmF0ZSAoJSkgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nPlZhY2FudCBDaGl0IFBlbmFsdHkgUmF0ZSAoJSk8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXROdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heD17MTAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dmFjYW50Q2hpdFBlbmFsdHlSYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhY2FudENoaXRQZW5hbHR5UmF0ZSh2YWwgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFtb3VudCA9IGdldEluc3RhbGxtZW50QW1vdW50KHNlbGVjdGVkR3JvdXApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGVuYWx0eSA9IGFtb3VudCA+IDAgPyBwYXJzZUZsb2F0KCgoYW1vdW50ICogKHZhbCB8fCAwKSkgLyAxMDApLnRvRml4ZWQoMikpIDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhY2FudENoaXRQZW5hbHR5QW1vdW50KHBlbmFsdHkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBWYWNhbnQgQ2hpdCBQZW5hbHR5IEFtb3VudCAo4oK5KSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBtZD17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmc+VmFjYW50IENoaXQgUGVuYWx0eSBBbW91bnQgKOKCuSk8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXROdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt2YWNhbnRDaGl0UGVuYWx0eUFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWYWNhbnRDaGl0UGVuYWx0eUFtb3VudCh2YWwgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFtb3VudCA9IGdldEluc3RhbGxtZW50QW1vdW50KHNlbGVjdGVkR3JvdXApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF0ZSA9IGFtb3VudCA+IDAgPyBwYXJzZUZsb2F0KCgodmFsIHx8IDApIC8gYW1vdW50KSAqIDEwMCkudG9GaXhlZCgyKSA6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWYWNhbnRDaGl0UGVuYWx0eVJhdGUocGFyc2VGbG9hdChyYXRlKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtYXR0ZXI9e3ZhbHVlID0+IGDigrkke3ZhbHVlfWAucmVwbGFjZSgvXFxCKD89KFxcZHszfSkrKD8hXFxkKSkvZywgJywnKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VyPXt2YWx1ZSA9PiB2YWx1ZS5yZXBsYWNlKC9cXOKCuVxccz98KCwqKS9nLCAnJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU2F2ZSBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnZmxleC1lbmQnLCBtYXJnaW5Ub3A6ICcyNHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8SW9NZFNhdmUgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e3NhdmluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiAnNjAwJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc4cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0ZmFjZmUgMCUsICMwMGYyZmUgMTAwJSknLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogJzAgNHB4IDEycHggcmdiYSg3OSwgMTcyLCAyNTQsIDAuMyknLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzQ4cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmdMZWZ0OiAnMjRweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZ1JpZ2h0OiAnMjRweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNhdmUgU2V0dGluZ3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvVGFiUGFuZT5cclxuICAgICAgICAgICAgICA8VGFiUGFuZVxyXG4gICAgICAgICAgICAgICAgdGFiPXtcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHRPdXRsaW5lZCBzdHlsZT17eyBtYXJnaW5SaWdodDogJzhweCcgfX0gLz5cclxuICAgICAgICAgICAgICAgICAgICBWaWV3IFBlbmFsaXR5XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGtleT1cInJlY29yZHNcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzI0cHgnLCBiYWNrZ3JvdW5kOiAnI2ZhZmFmYScgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxDYXJkIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMDUpJyxcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnI2ZmZmZmZicsXHJcbiAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogJzE2cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogJzE2cHggMjRweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXJCb3R0b206ICcxcHggc29saWQgI2YwZjBmMCdcclxuICAgICAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJyMxZTI5M2InLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiAnNjAwJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcxOHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dE91dGxpbmVkIHN0eWxlPXt7IG1hcmdpblJpZ2h0OiAnOHB4JywgY29sb3I6ICcjMTg5MGZmJyB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQZW5hbHR5IFJlY29yZHNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBncm91cCBuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZW50ZXJCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibWlkZGxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjUwLCBtYXJnaW5SaWdodDogMTYgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaD17c2V0U2VhcmNoVGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZTZmN2ZmLCAjYmFlN2ZmKScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICcjMTg5MGZmJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAnNnB4IDEycHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzE2cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMTNweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogJzYwMCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFBlbmFsdGllcy5sZW5ndGh9IHJlY29yZHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLCBwYWRkaW5nOiAnNjBweCAwJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U9e2ZpbHRlcmVkUGVuYWx0aWVzLm1hcCgocCwgaSkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogcC5faWQgfHwgaSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWdpbmF0aW9uPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGFnZVNpemU6IDEwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTaXplQ2hhbmdlcjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93VG90YWw6ICh0b3RhbCwgcmFuZ2UpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiAnIzY0NzQ4YicsIGZvbnRXZWlnaHQ6ICc1MDAnLCBmb250U2l6ZTogJzEzcHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTaG93aW5nIHtyYW5nZVswXX0te3JhbmdlWzFdfSBvZiB7dG90YWx9IHJlY29yZHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBbJ2JvdHRvbUNlbnRlciddLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzY3JvbGw9e3sgeDogMTAwMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L1RhYlBhbmU+XHJcbiAgICAgICAgICAgIDwvVGFicz5cclxuICAgICAgICAgIDwvQ2FyZD5cclxuXHJcblxyXG4gICAgICAgICAgPERyYXdlclxyXG4gICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXHJcbiAgICAgICAgICAgICAgICBnYXA6ICcxMnB4JyxcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0ZmFjZmUgMCUsICMwMGYyZmUgMTAwJSknLFxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAnMjBweCAyNHB4JyxcclxuICAgICAgICAgICAgICAgIGJvcmRlclRvcExlZnRSYWRpdXM6ICc4cHgnLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyVG9wUmlnaHRSYWRpdXM6ICc4cHgnLFxyXG4gICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgPEVkaXRPdXRsaW5lZCBzdHlsZT17eyBmb250U2l6ZTogJzIwcHgnLCBjb2xvcjogJyNmZmZmZmYnIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzE4cHgnLCBmb250V2VpZ2h0OiAnNjAwJywgY29sb3I6ICcjZmZmZmZmJyB9fT5cclxuICAgICAgICAgICAgICAgICAgRWRpdCBQZW5hbHR5OiB7ZWRpdGluZ1BlbmFsdHk/Lmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgd2lkdGg9ezkwMH1cclxuICAgICAgICAgICAgb3Blbj17ZWRpdERyYXdlck9wZW59XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEVkaXREcmF3ZXJPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgZm9vdGVyPXtcclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHRleHRBbGlnbjogJ3JpZ2h0JyB9fT5cclxuICAgICAgICAgICAgICAgIDxTcGFjZSBzaXplPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFZGl0RHJhd2VyT3BlbihmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiAnMzZweCcsIGZvbnRXZWlnaHQ6ICc1MDAnIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIGljb249ezxDaGVja0NpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURyYXdlclNhdmV9XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzM2cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogJzYwMCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNGZhY2ZlIDAlLCAjMDBmMmZlIDEwMCUpJyxcclxuICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L1NwYWNlPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtlZGl0RHJhd2VyT3BlbiAmJiBlZGl0aW5nUGVuYWx0eSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMjRweCcsIGJhY2tncm91bmQ6ICcjZmFmYWZhJyB9fT5cclxuXHJcbiAgICAgICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCIxMnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIm5vbmVcIixcclxuICAgICAgICAgICAgICAgICAgICBib3hTaGFkb3c6IFwiMCA0cHggMTJweCByZ2JhKDAsMCwwLDAuMDUpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBcIjI0cHhcIixcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcIiNmZmZmZmZcIixcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiBcIjIwcHggMjRweFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUaXRsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgbGV2ZWw9ezR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMxZTI5M2JcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogXCI2MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMThweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyT3V0bGluZWQgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6IFwiOHB4XCIsIGNvbG9yOiBcIiMxODkwZmZcIiB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgSW5zdGFsbG1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0gc3R5bGU9e3sgbWFyZ2luVG9wOiBcIjE2cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZz5Nb250aGx5IEluc3RhbGxtZW50PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMTJweCAxNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcIiNlMGYyZmVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgI2JhZTZmZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjhweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luVG9wOiBcIjZweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogXCI2MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjE2cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMwMzY5YTFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e051bWJlcihlZGl0aW5nUGVuYWx0eS5tb250aGx5X2luc3RhbGxtZW50KS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZz5XZWVrbHkgSW5zdGFsbG1lbnQ8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIxMnB4IDE2cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiI2ZlZjNjN1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZmRlNjhhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiOHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IFwiNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjYwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTZweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiI2NhOGEwNFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKGVkaXRpbmdQZW5hbHR5LndlZWtseV9pbnN0YWxsbWVudCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmc+RGFpbHkgSW5zdGFsbG1lbnQ8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIxMnB4IDE2cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiI2ZlZTJlMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZmVjYWNhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiOHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IFwiNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjYwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTZweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiI2I5MWMxY1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKGVkaXRpbmdQZW5hbHR5LmRhaWx5X2luc3RhbGxtZW50KS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogPT09IExhdGUgQ2hhcmdlcyBTZWN0aW9uID09PSAqL31cclxuICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMDUpJyxcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcyNHB4JyxcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnI2ZmZmZmZicsXHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmY3ZTYsICNmZmYyY2MpJyxcclxuICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICcxNnB4IDI0cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tOiAnMXB4IHNvbGlkICNmZmQ1OTEnLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8VGl0bGVcclxuICAgICAgICAgICAgICAgICAgICAgIGxldmVsPXs0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJyNkNDZiMDgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiAnNjAwJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcxOHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRodW5kZXJib2x0T3V0bGluZWQgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICc4cHgnIH19IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBMYXRlIENoYXJnZXNcclxuICAgICAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMjRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBzdHlsZT17eyBjb2xvcjogJyM0NzU1NjknLCBmb250U2l6ZTogJzE0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JhY2UgRGF5cyAoTGF0ZSBGZWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJkYW5nZXJcIj4gKjwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRpbmdQZW5hbHR5LmRheXNfbGF0ZV90aHJlc2hvbGQgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRpbmdQZW5hbHR5KHByZXYgPT4gKHsgLi4ucHJldiwgZGF5c19sYXRlX3RocmVzaG9sZDogdmFsID8/IDAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aHJlc2hvbGQgZGF5c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBzdHlsZT17eyBjb2xvcjogJyM0NzU1NjknLCBmb250U2l6ZTogJzE0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTGF0ZSBGZWUgUmF0ZSAoJSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cImRhbmdlclwiPiAqPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0TnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9ezEwMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17TnVtYmVyKGVkaXRpbmdQZW5hbHR5LmxhdGVfcGF5bWVudF9yYXRlIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpbnN0YWxsbWVudCA9IE51bWJlcihlZGl0aW5nUGVuYWx0eS5tb250aGx5X2luc3RhbGxtZW50KSB8fCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coaW5zdGFsbG1lbnQsIHZhbCwgXCJ0aGlzIGlzIHZhbFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF0ZSA9IHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmICFpc05hTih2YWwpID8gdmFsIDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFtb3VudCA9IGluc3RhbGxtZW50ID4gMCA/IHBhcnNlRmxvYXQoKChpbnN0YWxsbWVudCAqIHJhdGUpIC8gMTAwKS50b0ZpeGVkKDIpKSA6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nUGVuYWx0eShwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhdGVfcGF5bWVudF9yYXRlOiByYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXRlX3BheW1lbnRfYW1vdW50OiBhbW91bnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgcmF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBzdHlsZT17eyBjb2xvcjogJyM0NzU1NjknLCBmb250U2l6ZTogJzE0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTGF0ZSBGZWUgQW1vdW50ICjigrkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJkYW5nZXJcIj4gKjwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRpbmdQZW5hbHR5LmxhdGVfcGF5bWVudF9hbW91bnQgPz8gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5zdGFsbG1lbnQgPSBOdW1iZXIoZWRpdGluZ1BlbmFsdHkuaW5zdGFsbG1lbnRfYW1vdW50KSB8fCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYW1vdW50ID0gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgIWlzTmFOKHZhbCkgPyB2YWwgOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF0ZSA9IGluc3RhbGxtZW50ID4gMCA/IHBhcnNlRmxvYXQoKChhbW91bnQgLyBpbnN0YWxsbWVudCkgKiAxMDApLnRvRml4ZWQoMikpIDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRpbmdQZW5hbHR5KHByZXYgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGF0ZV9wYXltZW50X2Ftb3VudDogYW1vdW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXRlX3BheW1lbnRfcmF0ZTogcmF0ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybWF0dGVyPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHt2YWx1ZX1gLnJlcGxhY2UoL1xcQig/PShcXGR7M30pKyg/IVxcZCkpL2csICcsJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VyPXsodmFsdWUpID0+IHZhbHVlLnJlcGxhY2UoL1xc4oK5XFxzP3woLCopL2csICcnKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGxhdGUgZmVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogPT09IE92ZXJkdWUgQ2hhcmdlcyBTZWN0aW9uID09PSAqL31cclxuICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMDUpJyxcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcyNHB4JyxcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnI2ZmZmZmZicsXHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmYxZjAsICNmZmNjYzcpJyxcclxuICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICcxNnB4IDI0cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tOiAnMXB4IHNvbGlkICNmZmEzOWUnLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8VGl0bGVcclxuICAgICAgICAgICAgICAgICAgICAgIGxldmVsPXs0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJyNjZjEzMjInLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiAnNjAwJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcxOHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENsb2NrQ2lyY2xlT3V0bGluZWQgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICc4cHgnIH19IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBPdmVyZHVlIENoYXJnZXNcclxuICAgICAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMjRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBzdHlsZT17eyBjb2xvcjogJyM0NzU1NjknLCBmb250U2l6ZTogJzE0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGVuYWx0eSBSYXRlICglKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwiZGFuZ2VyXCI+ICo8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXROdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heD17MTAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0aW5nUGVuYWx0eS5wZW5hbHR5X3JhdGUgPz8gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5zdGFsbG1lbnQgPSBOdW1iZXIoZWRpdGluZ1BlbmFsdHkuaW5zdGFsbG1lbnRfYW1vdW50KSB8fCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF0ZSA9IHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmICFpc05hTih2YWwpID8gdmFsIDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFtb3VudCA9IGluc3RhbGxtZW50ID4gMCA/IHBhcnNlRmxvYXQoKChpbnN0YWxsbWVudCAqIHJhdGUpIC8gMTAwKS50b0ZpeGVkKDIpKSA6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nUGVuYWx0eShwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlbmFsdHlfcmF0ZTogcmF0ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVuYWx0eV9hbW91bnQ6IGFtb3VudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzhweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIHN0eWxlPXt7IGNvbG9yOiAnIzQ3NTU2OScsIGZvbnRTaXplOiAnMTRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZW5hbHR5IEFtb3VudCAo4oK5KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwiZGFuZ2VyXCI+ICo8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXROdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0aW5nUGVuYWx0eS5wZW5hbHR5X2Ftb3VudCA/PyAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpbnN0YWxsbWVudCA9IE51bWJlcihlZGl0aW5nUGVuYWx0eS5pbnN0YWxsbWVudF9hbW91bnQpIHx8IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhbW91bnQgPSB0eXBlb2YgdmFsID09PSAnbnVtYmVyJyAmJiAhaXNOYU4odmFsKSA/IHZhbCA6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByYXRlID0gaW5zdGFsbG1lbnQgPiAwID8gcGFyc2VGbG9hdCgoKGFtb3VudCAvIGluc3RhbGxtZW50KSAqIDEwMCkudG9GaXhlZCgyKSkgOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1BlbmFsdHkocHJldiA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZW5hbHR5X2Ftb3VudDogYW1vdW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZW5hbHR5X3JhdGU6IHJhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdHRlcj17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYOKCuSR7dmFsdWV9YC5yZXBsYWNlKC9cXEIoPz0oXFxkezN9KSsoPyFcXGQpKS9nLCAnLCcpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlcj17KHZhbHVlKSA9PiB2YWx1ZS5yZXBsYWNlKC9cXOKCuVxccz98KCwqKS9nLCAnJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiA9PT0gVmFjYW50IENoaXQgQ2hhcmdlcyBTZWN0aW9uID09PSAqL31cclxuICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMDUpJyxcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcyNHB4JyxcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnI2ZmZmZmZicsXHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmU3Y2MsICNmZmQ4YTgpJyxcclxuICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICcxNnB4IDI0cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tOiAnMXB4IHNvbGlkICNmZmMwNzgnLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8VGl0bGVcclxuICAgICAgICAgICAgICAgICAgICAgIGxldmVsPXs0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJyNkOTQ4MGYnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiAnNjAwJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcxOHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFdhcm5pbmdPdXRsaW5lZCBzdHlsZT17eyBtYXJnaW5SaWdodDogJzhweCcgfX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgIE92ZXJkdWUgQ2hhcmdlcyBmb3IgVmFjYW50IENoaXRcclxuICAgICAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMjRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBzdHlsZT17eyBjb2xvcjogJyM0NzU1NjknLCBmb250U2l6ZTogJzE0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JhY2UgRGF5cyAoVmFjYW50IENoaXQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0TnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdGluZ1BlbmFsdHkudmFjYW50X2NoaXRfZ3JhY2VfZGF5cyA/PyAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1BlbmFsdHkocHJldiA9PiAoeyAuLi5wcmV2LCB2YWNhbnRfY2hpdF9ncmFjZV9kYXlzOiB2YWwgPz8gMCB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGRheXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBtZD17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnOHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgc3R5bGU9e3sgY29sb3I6ICcjNDc1NTY5JywgZm9udFNpemU6ICcxNHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhY2FudCBDaGl0IFBlbmFsdHkgUmF0ZSAoJSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXROdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heD17MTAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0aW5nUGVuYWx0eS52YWNhbnRfY2hpdF9wZW5hbHR5X3JhdGUgPz8gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5zdGFsbG1lbnQgPSBOdW1iZXIoZWRpdGluZ1BlbmFsdHkuaW5zdGFsbG1lbnRfYW1vdW50KSB8fCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF0ZSA9IHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmICFpc05hTih2YWwpID8gdmFsIDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFtb3VudCA9IGluc3RhbGxtZW50ID4gMCA/IHBhcnNlRmxvYXQoKChpbnN0YWxsbWVudCAqIHJhdGUpIC8gMTAwKS50b0ZpeGVkKDIpKSA6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nUGVuYWx0eShwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhY2FudF9jaGl0X3BlbmFsdHlfcmF0ZTogcmF0ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFjYW50X2NoaXRfcGVuYWx0eV9hbW91bnQ6IGFtb3VudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzhweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIHN0eWxlPXt7IGNvbG9yOiAnIzQ3NTU2OScsIGZvbnRTaXplOiAnMTRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWYWNhbnQgQ2hpdCBQZW5hbHR5IEFtb3VudCAo4oK5KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRpbmdQZW5hbHR5LnZhY2FudF9jaGl0X3BlbmFsdHlfYW1vdW50ID8/IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGluc3RhbGxtZW50ID0gTnVtYmVyKGVkaXRpbmdQZW5hbHR5Lmluc3RhbGxtZW50X2Ftb3VudCkgfHwgMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGluc3RhbGxtZW50KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYW1vdW50ID0gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgIWlzTmFOKHZhbCkgPyB2YWwgOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF0ZSA9IGluc3RhbGxtZW50ID4gMCA/IHBhcnNlRmxvYXQoKChhbW91bnQgLyBpbnN0YWxsbWVudCkgKiAxMDApLnRvRml4ZWQoMikpIDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRpbmdQZW5hbHR5KHByZXYgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFjYW50X2NoaXRfcGVuYWx0eV9hbW91bnQ6IGFtb3VudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFjYW50X2NoaXRfcGVuYWx0eV9yYXRlOiByYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtYXR0ZXI9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGDigrkke3ZhbHVlfWAucmVwbGFjZSgvXFxCKD89KFxcZHszfSkrKD8hXFxkKSkvZywgJywnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZXI9eyh2YWx1ZSkgPT4gdmFsdWUucmVwbGFjZSgvXFzigrlcXHM/fCgsKikvZywgJycpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICA8L0RyYXdlcj5cclxuXHJcbiAgICAgICAgICB7LyogQWRkIENoYXJnZSBNb2RhbCAqL31cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXHJcbiAgICAgICAgICAgICAgICBnYXA6ICcxMnB4JyxcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0ZmFjZmUgMCUsICMwMGYyZmUgMTAwJSknLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAnLTI0cHggLTI0cHggMjBweCAtMjRweCcsXHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAnMjBweCAyNHB4JyxcclxuICAgICAgICAgICAgICAgIGJvcmRlclRvcExlZnRSYWRpdXM6ICc4cHgnLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyVG9wUmlnaHRSYWRpdXM6ICc4cHgnLFxyXG4gICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgPFBsdXNPdXRsaW5lZCBzdHlsZT17eyBmb250U2l6ZTogJzIwcHgnLCBjb2xvcjogJyNmZmZmZmYnIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzE4cHgnLCBmb250V2VpZ2h0OiAnNjAwJywgY29sb3I6ICcjZmZmZmZmJyB9fT5cclxuICAgICAgICAgICAgICAgICAgQWRkIEFkZGl0aW9uYWwgQ2hhcmdlXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3Blbj17aXNBZGRDaGFyZ2VNb2RhbE9wZW59XHJcbiAgICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0SXNBZGRDaGFyZ2VNb2RhbE9wZW4oZmFsc2UpO1xyXG4gICAgICAgICAgICAgIGFkZENoYXJnZUZvcm0ucmVzZXRGaWVsZHMoKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgd2lkdGg9ezYwMH1cclxuICAgICAgICAgICAgZm9vdGVyPXtbXHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAga2V5PVwiY2FuY2VsXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0SXNBZGRDaGFyZ2VNb2RhbE9wZW4oZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICBhZGRDaGFyZ2VGb3JtLnJlc2V0RmllbGRzKCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnNnB4JyxcclxuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogJzUwMCcsXHJcbiAgICAgICAgICAgICAgICAgIGhlaWdodDogJzM2cHgnLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAga2V5PVwic2F2ZVwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBpY29uPXs8Q2hlY2tDaXJjbGVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZENoYXJnZX1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzZweCcsXHJcbiAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6ICc2MDAnLFxyXG4gICAgICAgICAgICAgICAgICBoZWlnaHQ6ICczNnB4JyxcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzRmYWNmZSAwJSwgIzAwZjJmZSAxMDAlKScsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBBZGQgQ2hhcmdlXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgICAgICBdfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8Rm9ybSBmb3JtPXthZGRDaGFyZ2VGb3JtfSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIHN0eWxlPXt7IG1hcmdpblRvcDogJzIwcHgnIH19PlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPXs8VGV4dCBzdHJvbmcgc3R5bGU9e3sgZm9udFNpemU6ICcxNHB4JywgY29sb3I6ICcjNDc1NTY5JyB9fT5DaGFyZ2UgTmFtZTwvVGV4dD59XHJcbiAgICAgICAgICAgICAgICBuYW1lPVwiY2hhcmdlX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUGxlYXNlIGVudGVyIGNoYXJnZSBuYW1lJyB9XX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXQgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19IHBsYWNlaG9sZGVyPVwiZS5nLiwgUHJvY2Vzc2luZyBGZWVcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17PFRleHQgc3Ryb25nIHN0eWxlPXt7IGZvbnRTaXplOiAnMTRweCcsIGNvbG9yOiAnIzQ3NTU2OScgfX0+Q2hhcmdlIFR5cGU8L1RleHQ+fVxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImNoYXJnZV90eXBlXCJcclxuICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogJ1BsZWFzZSBzZWxlY3QgY2hhcmdlIHR5cGUnIH1dfVxyXG4gICAgICAgICAgICAgICAgaW5pdGlhbFZhbHVlPVwiZml4ZWRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3Qgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImZpeGVkXCI+Rml4ZWQgQW1vdW50PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cInBlcmNlbnRhZ2VcIj5QZXJjZW50YWdlPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcblxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIG5vU3R5bGVcclxuICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZT17KHByZXZWYWx1ZXMsIGN1cnJlbnRWYWx1ZXMpID0+IHByZXZWYWx1ZXMuY2hhcmdlX3R5cGUgIT09IGN1cnJlbnRWYWx1ZXMuY2hhcmdlX3R5cGV9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgeyh7IGdldEZpZWxkVmFsdWUgfSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBjaGFyZ2VUeXBlID0gZ2V0RmllbGRWYWx1ZSgnY2hhcmdlX3R5cGUnKTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNoYXJnZVR5cGUgPT09ICdmaXhlZCcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9ezxUZXh0IHN0cm9uZyBzdHlsZT17eyBmb250U2l6ZTogJzE0cHgnLCBjb2xvcjogJyM0NzU1NjknIH19PkFtb3VudCAo4oK5KTwvVGV4dD59XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hhcmdlX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6ICdQbGVhc2UgZW50ZXIgYW1vdW50JyB9XX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXROdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9ybWF0dGVyPXt2YWx1ZSA9PiBg4oK5JHt2YWx1ZX1gLnJlcGxhY2UoL1xcQig/PShcXGR7M30pKyg/IVxcZCkpL2csICcsJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlcj17dmFsdWUgPT4gdmFsdWUucmVwbGFjZSgvXFzigrlcXHM/fCgsKikvZywgJycpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXs8VGV4dCBzdHJvbmcgc3R5bGU9e3sgZm9udFNpemU6ICcxNHB4JywgY29sb3I6ICcjNDc1NTY5JyB9fT5SYXRlICglKTwvVGV4dD59XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hhcmdlX3JhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUGxlYXNlIGVudGVyIHJhdGUnIH1dfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg9ezEwMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17PFRleHQgc3Ryb25nIHN0eWxlPXt7IGZvbnRTaXplOiAnMTRweCcsIGNvbG9yOiAnIzQ3NTU2OScgfX0+RGVzY3JpcHRpb248L1RleHQ+fVxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImNoYXJnZV9kZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0LlRleHRBcmVhIHJvd3M9ezN9IHBsYWNlaG9sZGVyPVwiRW50ZXIgZGVzY3JpcHRpb24gKG9wdGlvbmFsKVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvRm9ybT5cclxuICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgb3Blbj17c2hvd1BlbmFsdHlQcmV2aWV3fVxyXG4gICAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0U2hvd1BlbmFsdHlQcmV2aWV3KGZhbHNlKX1cclxuICAgICAgICAgICAgZm9vdGVyPXtudWxsfVxyXG4gICAgICAgICAgICB3aWR0aD17ODUwfVxyXG4gICAgICAgICAgICBjbG9zYWJsZT17ZmFsc2V9XHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHRvcDogNDAgfX1cclxuICAgICAgICAgICAgYm9keVN0eWxlPXt7IHBhZGRpbmc6IDAsIGJhY2tncm91bmQ6IFwiI2Y1ZjdmYVwiIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtwZW5hbHR5UHJldmlldyAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMjRweCcgfX0+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEhFQURFUiAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzRmYWNmZSAwJSwgIzAwZjJmZSAxMDAlKScsXHJcbiAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICcyMHB4IDI0cHgnLFxyXG4gICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxMnB4JyxcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMjBweCcsXHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiAnI2ZmZicsXHJcbiAgICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJyxcclxuICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcidcclxuICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzE4cHgnLCBmb250V2VpZ2h0OiAnNjAwJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICBQZW5hbHR5IEFscmVhZHkgU2V0IOKAlCB7cGVuYWx0eVByZXZpZXcuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjYwMFwiLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dQZW5hbHR5UHJldmlldyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcGVuRWRpdERyYXdlcihwZW5hbHR5UHJldmlldyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVkaXQgUGVuYWx0eVxyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBJTlNUQUxMTUVOVFMgQ0FSRCAqL31cclxuICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMjBweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggMTJweCByZ2JhKDAsMCwwLDAuMDUpJ1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezR9IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgSW5zdGFsbG1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfT5cclxuICAgICAgICAgICAgICAgICAgICA8Q29sIHNwYW49ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nPk1vbnRobHkgSW5zdGFsbG1lbnQ8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8tYm94IHZpb2xldEJveFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDigrl7cGVuYWx0eVByZXZpZXcubW9udGhseV9pbnN0YWxsbWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8Q29sIHNwYW49ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nPldlZWtseSBJbnN0YWxsbWVudDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby1ib3ggeWVsbG93Qm94XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtwZW5hbHR5UHJldmlldy53ZWVrbHlfaW5zdGFsbG1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPENvbCBzcGFuPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZz5EYWlseSBJbnN0YWxsbWVudDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby1ib3ggcmVkQm94XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtwZW5hbHR5UHJldmlldy5kYWlseV9pbnN0YWxsbWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogTEFURSBDSEFSR0VTICovfVxyXG4gICAgICAgICAgICAgICAgPENhcmRcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxMnB4JyxcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcyMHB4JyxcclxuICAgICAgICAgICAgICAgICAgICBib3hTaGFkb3c6ICcwIDRweCAxMnB4IHJnYmEoMCwwLDAsMC4wNSknXHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAxNiB9fT5MYXRlIENoYXJnZXM8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17OH0+PGI+R3JhY2UgRGF5czo8L2I+IHtwZW5hbHR5UHJldmlldy5kYXlzX2xhdGVfdGhyZXNob2xkfTwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17OH0+PGI+TGF0ZSBGZWUgUmF0ZTo8L2I+IHtwZW5hbHR5UHJldmlldy5sYXRlX3BheW1lbnRfcmF0ZX0lPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbCBzcGFuPXs4fT48Yj5MYXRlIEZlZSBBbW91bnQ6PC9iPiDigrl7cGVuYWx0eVByZXZpZXcubGF0ZV9wYXltZW50X2Ftb3VudH08L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIE9WRVJEVUUgQ0hBUkdFUyAqL31cclxuICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMjBweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggMTJweCByZ2JhKDAsMCwwLDAuMDUpJ1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezR9IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMTYgfX0+T3ZlcmR1ZSBDaGFyZ2VzPC9UaXRsZT5cclxuICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfT5cclxuICAgICAgICAgICAgICAgICAgICA8Q29sIHNwYW49ezh9PjxiPlBlbmFsdHkgUmF0ZTo8L2I+IHtwZW5hbHR5UHJldmlldy5wZW5hbHR5X3JhdGV9JTwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17OH0+PGI+UGVuYWx0eSBBbW91bnQ6PC9iPiDigrl7cGVuYWx0eVByZXZpZXcucGVuYWx0eV9hbW91bnR9PC9Db2w+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogVkFDQU5UIENISVQgKi99XHJcbiAgICAgICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzEycHgnLFxyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogJzIwcHgnLFxyXG4gICAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogJzAgNHB4IDEycHggcmdiYSgwLDAsMCwwLjA1KSdcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPFRpdGxlIGxldmVsPXs0fSBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDE2IH19PlZhY2FudCBDaGl0IENoYXJnZXM8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17OH0+PGI+R3JhY2UgRGF5czo8L2I+IHtwZW5hbHR5UHJldmlldy52YWNhbnRfY2hpdF9ncmFjZV9kYXlzfTwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17OH0+PGI+UmF0ZTo8L2I+IHtwZW5hbHR5UHJldmlldy52YWNhbnRfY2hpdF9wZW5hbHR5X3JhdGV9JTwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17OH0+PGI+QW1vdW50OjwvYj4g4oK5e3BlbmFsdHlQcmV2aWV3LnZhY2FudF9jaGl0X3BlbmFsdHlfYW1vdW50fTwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ0xPU0UgQlVUVE9OICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwicmlnaHRcIiwgbWFyZ2luVG9wOiAyMCB9fT5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGVuYWx0eVByZXZpZXcoZmFsc2UpfT5cclxuICAgICAgICAgICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuXHJcblxyXG4gICAgICAgICAgPHN0eWxlPntgXHJcbiAgICAgICAgICAgIC5hbnQtc2VsZWN0LXNlbGVjdG9yIHtcclxuICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZDlkOWQ5ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbjogYWxsIDAuMnMgZWFzZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LXNlbGVjdC1zZWxlY3Rvcjpob3ZlciB7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAjNDBhOWZmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC5hbnQtc2VsZWN0LWZvY3VzZWQgLmFudC1zZWxlY3Qtc2VsZWN0b3Ige1xyXG4gICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogIzQwYTlmZiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDJweCByZ2JhKDI0LCAxNDQsIDI1NSwgMC4yKSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LWlucHV0LW51bWJlciB7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2Q5ZDlkOSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAwLjJzIGVhc2UgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLmFudC1pbnB1dC1udW1iZXI6aG92ZXIge1xyXG4gICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogIzQwYTlmZiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LWlucHV0LW51bWJlci1mb2N1c2VkIHtcclxuICAgICAgICAgICAgICBib3JkZXItY29sb3I6ICM0MGE5ZmYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBib3gtc2hhZG93OiAwIDAgMCAycHggcmdiYSgyNCwgMTQ0LCAyNTUsIDAuMikgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLmFudC10YWJsZSB7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoIHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmFmYWZhICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIGNvbG9yOiAjMjYyNjI2ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmMGYwZjAgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBwYWRkaW5nOiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC5hbnQtdGFibGUtdGJvZHkgPiB0ciB7XHJcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbjogYWxsIDAuMnMgZWFzZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LXRhYmxlLXRib2R5ID4gdHI6aG92ZXIgPiB0ZCB7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2Y1ZjVmNSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCB7XHJcbiAgICAgICAgICAgICAgcGFkZGluZzogMTZweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZjBmMGYwICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC5hbnQtcGFnaW5hdGlvbi1pdGVtIHtcclxuICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA2cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLmFudC1wYWdpbmF0aW9uLWl0ZW0tYWN0aXZlIHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjMTg5MGZmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAjMTg5MGZmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LXBhZ2luYXRpb24taXRlbS1hY3RpdmUgYSB7XHJcbiAgICAgICAgICAgICAgY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC5hbnQtYnRuLXByaW1hcnkge1xyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6ICMxODkwZmYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBib3JkZXItY29sb3I6ICMxODkwZmYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA2cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLmFudC1idG4tcHJpbWFyeTpob3Zlcjpub3QoOmRpc2FibGVkKSB7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogIzQwYTlmZiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogIzQwYTlmZiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LWJ0biB7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbjogYWxsIDAuMnMgZWFzZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LW1vZGFsLWhlYWRlciB7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLmFudC1tb2RhbC1ib2R5IHtcclxuICAgICAgICAgICAgICBwYWRkaW5nOiAyNHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC5hbnQtbW9kYWwtZm9vdGVyIHtcclxuICAgICAgICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgI2YwZjBmMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IDE2cHggMjRweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LWNhcmQge1xyXG4gICAgICAgICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMDYpICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC5hbnQtc3RhdGlzdGljLXRpdGxlIHtcclxuICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA4cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLmFudC1mb3JtLWl0ZW0tbGFiZWwgPiBsYWJlbCB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgY29sb3I6ICMyNjI2MjYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC5hbnQtdGFicy10YWIge1xyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IDEycHggMTZweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LXRhYnMtdGFiLWFjdGl2ZSB7XHJcbiAgICAgICAgICAgICAgY29sb3I6ICMxODkwZmYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLmFudC10YWJzLWluay1iYXIge1xyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6ICMxODkwZmYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLmFudC1jb2xsYXBzZS1oZWFkZXIge1xyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IDEycHggMTZweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAuYW50LWNvbGxhcHNlLWNvbnRlbnQtYm94IHtcclxuICAgICAgICAgICAgICBwYWRkaW5nOiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAuaW5mby1ib3gge1xyXG4gIHBhZGRpbmc6IDEycHggMTZweDtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgbWFyZ2luLXRvcDogNnB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcblxyXG4udmlvbGV0Qm94IHtcclxuICBiYWNrZ3JvdW5kOiAjZTBmMmZlO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNiYWU2ZmQ7XHJcbiAgY29sb3I6ICMwMzY5YTE7XHJcbn1cclxuXHJcbi55ZWxsb3dCb3gge1xyXG4gIGJhY2tncm91bmQ6ICNmZWY5YzM7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZkZTY4YTtcclxuICBjb2xvcjogI2NhOGEwNDtcclxufVxyXG5cclxuLnJlZEJveCB7XHJcbiAgYmFja2dyb3VuZDogI2ZlZTJlMjtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZmVjYWNhO1xyXG4gIGNvbG9yOiAjYjkxYzFjO1xyXG59XHJcblxyXG4gICAgICAgICAgYH08L3N0eWxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQZW5hbHR5U2V0dGluZ3M7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1BlbmFsdHlTZXR0aW5ncy5qc3gifQ==