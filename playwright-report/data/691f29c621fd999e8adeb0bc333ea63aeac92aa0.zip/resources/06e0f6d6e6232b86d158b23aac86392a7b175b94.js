import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PaymentLinkTransactions.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import API from "/src/instance/TokenInstance.js";
import { Tag, Tooltip, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import __vite__cjsImport10_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport10_dayjs.__esModule ? __vite__cjsImport10_dayjs.default : __vite__cjsImport10_dayjs;
import {
  CheckCircleOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
  CopyOutlined,
  LinkOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const PaymentLinkTransactions = () => {
  _s();
  const [isLoading, setIsLoading] = useState(false);
  const [tableTransactions, setTableTransactions] = useState([]);
  const handleCopyLink = (url) => {
    if (!url) {
      message.warning("No payment link available");
      return;
    }
    navigator.clipboard.writeText(url);
    message.success("Link copied to clipboard!");
  };
  async function getTransactions() {
    try {
      setIsLoading(true);
      const response = await API.get("/cashfree-pg-orders");
      const transactionsData = response.data?.data;
      const filteredData = transactionsData.map((order, index) => {
        const status = order?.status;
        const color = status === "ACTIVE" ? "violet" : status === "PAID" ? "green" : "red";
        const icon = status === "ACTIVE" ? /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
          lineNumber: 41,
          columnNumber: 44
        }, this) : status === "PAID" ? /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
          lineNumber: 41,
          columnNumber: 90
        }, this) : /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
          lineNumber: 41,
          columnNumber: 116
        }, this);
        const groupsString = (order.groups?.map((g) => `${g?.group_id?.group_name} | ${g?.ticket}`) || []).join(" | ");
        const pigmysString = (order.pigmys?.map((p) => `${p?.payable_amount} | ${p?.pigme_id}`) || []).join(" | ");
        const loansString = (order.loans?.map((l) => `${l?.loan_amount} | ${l?.loan_id}`) || []).join(" | ");
        return {
          id: index + 1,
          createdAt: order.createdAt ? dayjs(order.createdAt).format("YYYY-MM-DD") : "N/A",
          orderType: order?.order_type,
          user_name: order?.user_id?.full_name,
          phone_number: order?.user_id?.phone_number,
          others: groupsString + pigmysString + loansString,
          status: /* @__PURE__ */ jsxDEV(Tag, { color, icon, variant: "filled", children: status }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
            lineNumber: 55,
            columnNumber: 11
          }, this),
          statusRaw: status,
          collectedBy: order?.collected_by || "Online",
          amount: order?.amount,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(Tooltip, { title: order.link_url ? "Copy Link" : "No Link", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleCopyLink(order.link_url),
                className: `p-2 rounded-full transition-colors ${order.link_url ? "text-violet-600 hover:bg-violet-50" : "text-gray-300"}`,
                children: /* @__PURE__ */ jsxDEV(CopyOutlined, { style: { fontSize: "16px" } }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
                  lineNumber: 69,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
                lineNumber: 65,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
              lineNumber: 64,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { title: "View Link", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => order.link_url ? window.open(order.link_url, "_blank") : message.info("Link not found"),
                className: `p-2 rounded-full transition-colors ${order.link_url ? "text-gray-600 hover:bg-gray-100" : "text-gray-300"}`,
                children: /* @__PURE__ */ jsxDEV(LinkOutlined, { style: { fontSize: "16px" } }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
                  lineNumber: 78,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
                lineNumber: 74,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
              lineNumber: 73,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
            lineNumber: 63,
            columnNumber: 11
          }, this)
        };
      });
      setTableTransactions(filteredData);
    } catch (error) {
      console.error(error);
      setTableTransactions([]);
    } finally {
      setIsLoading(false);
    }
  }
  useEffect(() => {
    getTransactions();
  }, []);
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "createdAt", header: "Date" },
    { key: "user_name", header: "User Name" },
    { key: "others", header: "Details" },
    { key: "amount", header: "Amount" },
    { key: "status", header: "Status" },
    { key: "collectedBy", header: "Collected By" },
    { key: "action", header: "Actions" }
    // Added column
  ];
  const exportColumns = [
    { key: "id", header: "SL. NO" },
    { key: "createdAt", header: "Date" },
    { key: "orderType", header: "Order Type" },
    { key: "user_name", header: "User Name" },
    { key: "statusRaw", header: "Status" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
      lineNumber: 119,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
        lineNumber: 121,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 bg-gray-50 min-h-screen", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8 flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800", children: "Payment Link Transactions" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
            lineNumber: 124,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: getTransactions,
              className: "px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm hover:bg-gray-50 transition-all",
              children: "Refresh Data"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
              lineNumber: 127,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
          lineNumber: 123,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden", children: isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "p-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading, data: "Transactions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
          lineNumber: 138,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
          lineNumber: 137,
          columnNumber: 13
        }, this) : tableTransactions.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            data: tableTransactions,
            columns,
            exportCols: exportColumns,
            exportedPdfName: "Payment_Link_Transactions",
            exportedFileName: "Payment_Transactions.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
            lineNumber: 141,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "p-20 text-center text-gray-400 italic", children: "No transactions found." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
          lineNumber: 150,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
          lineNumber: 135,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
        lineNumber: 122,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
      lineNumber: 120,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx",
    lineNumber: 118,
    columnNumber: 5
  }, this);
};
_s(PaymentLinkTransactions, "+jVjNppMUe1G50PUVMAp1GMkq9o=");
_c = PaymentLinkTransactions;
export default PaymentLinkTransactions;
var _c;
$RefreshReg$(_c, "PaymentLinkTransactions");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkTransactions.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0MyQzsyQkF4QzNDO0FBQWdCQSxNQUFVQyxjQUFTLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbEQsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsS0FBS0MsU0FBU0MsZUFBZTtBQUN0QyxPQUFPQyxXQUFXO0FBQ2xCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFFQUM7QUFBQUEsT0FDSztBQUVQLE1BQU1DLDBCQUEwQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BDLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJbkIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ29CLG1CQUFtQkMsb0JBQW9CLElBQUlyQixTQUFTLEVBQUU7QUFHN0QsUUFBTXNCLGlCQUFpQkEsQ0FBQ0MsUUFBUTtBQUM5QixRQUFJLENBQUNBLEtBQUs7QUFDUmQsY0FBUWUsUUFBUSwyQkFBMkI7QUFDM0M7QUFBQSxJQUNGO0FBQ0FDLGNBQVVDLFVBQVVDLFVBQVVKLEdBQUc7QUFDakNkLFlBQVFtQixRQUFRLDJCQUEyQjtBQUFBLEVBQzdDO0FBRUEsaUJBQWVDLGtCQUFrQjtBQUMvQixRQUFJO0FBQ0ZWLG1CQUFhLElBQUk7QUFDakIsWUFBTVcsV0FBVyxNQUFNeEIsSUFBSXlCLElBQUkscUJBQXFCO0FBQ3BELFlBQU1DLG1CQUFtQkYsU0FBU0csTUFBTUE7QUFFeEMsWUFBTUMsZUFBZUYsaUJBQWlCRyxJQUFJLENBQUNDLE9BQU9DLFVBQVU7QUFDMUQsY0FBTUMsU0FBU0YsT0FBT0U7QUFDdEIsY0FBTUMsUUFBUUQsV0FBVyxXQUFXLFdBQVdBLFdBQVcsU0FBUyxVQUFVO0FBQzdFLGNBQU1FLE9BQU9GLFdBQVcsV0FBVyx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CLElBQU1BLFdBQVcsU0FBUyx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CLElBQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQjtBQUUvSCxjQUFNRyxnQkFBZ0JMLE1BQU1NLFFBQVFQLElBQUksQ0FBQVEsTUFBSyxHQUFHQSxHQUFHQyxVQUFVQyxVQUFVLE1BQU1GLEdBQUdHLE1BQU0sRUFBRSxLQUFLLElBQUlDLEtBQUssS0FBSztBQUMzRyxjQUFNQyxnQkFBZ0JaLE1BQU1hLFFBQVFkLElBQUksQ0FBQWUsTUFBSyxHQUFHQSxHQUFHQyxjQUFjLE1BQU1ELEdBQUdFLFFBQVEsRUFBRSxLQUFLLElBQUlMLEtBQUssS0FBSztBQUN2RyxjQUFNTSxlQUFlakIsTUFBTWtCLE9BQU9uQixJQUFJLENBQUFvQixNQUFLLEdBQUdBLEdBQUdDLFdBQVcsTUFBTUQsR0FBR0UsT0FBTyxFQUFFLEtBQUssSUFBSVYsS0FBSyxLQUFLO0FBRWpHLGVBQVE7QUFBQSxVQUNOVyxJQUFJckIsUUFBUTtBQUFBLFVBQ1pzQixXQUFXdkIsTUFBTXVCLFlBQVlqRCxNQUFNMEIsTUFBTXVCLFNBQVMsRUFBRUMsT0FBTyxZQUFZLElBQUk7QUFBQSxVQUMzRUMsV0FBV3pCLE9BQU8wQjtBQUFBQSxVQUNsQkMsV0FBVzNCLE9BQU80QixTQUFTQztBQUFBQSxVQUMzQkMsY0FBYzlCLE9BQU80QixTQUFTRTtBQUFBQSxVQUM5QkMsUUFBUTFCLGVBQWVPLGVBQWVLO0FBQUFBLFVBQ3RDZixRQUNFLHVCQUFDLE9BQUksT0FBYyxNQUFZLFNBQVEsVUFDcENBLG9CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVGOEIsV0FBVzlCO0FBQUFBLFVBQ1grQixhQUFhakMsT0FBT2tDLGdCQUFnQjtBQUFBLFVBQ3BDQyxRQUFPbkMsT0FBT21DO0FBQUFBLFVBQ2RDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsV0FBUSxPQUFPcEMsTUFBTXFDLFdBQVcsY0FBYyxXQUM3QztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTW5ELGVBQWVjLE1BQU1xQyxRQUFRO0FBQUEsZ0JBQzVDLFdBQVcsc0NBQXNDckMsTUFBTXFDLFdBQVcsdUNBQXVDLGVBQWU7QUFBQSxnQkFFeEgsaUNBQUMsZ0JBQWEsT0FBTyxFQUFFQyxVQUFVLE9BQU8sS0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEM7QUFBQTtBQUFBLGNBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBRUEsdUJBQUMsV0FBUSxPQUFNLGFBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU10QyxNQUFNcUMsV0FBV0UsT0FBT0MsS0FBS3hDLE1BQU1xQyxVQUFVLFFBQVEsSUFBSWhFLFFBQVFvRSxLQUFLLGdCQUFnQjtBQUFBLGdCQUNyRyxXQUFXLHNDQUFzQ3pDLE1BQU1xQyxXQUFXLG9DQUFvQyxlQUFlO0FBQUEsZ0JBRXJILGlDQUFDLGdCQUFhLE9BQU8sRUFBRUMsVUFBVSxPQUFPLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUE7QUFBQSxjQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFFBRUo7QUFBQSxNQUNGLENBQUM7QUFDRHJELDJCQUFxQmEsWUFBWTtBQUFBLElBQ25DLFNBQVM0QyxPQUFPO0FBQ2RDLGNBQVFELE1BQU1BLEtBQUs7QUFDbkJ6RCwyQkFBcUIsRUFBRTtBQUFBLElBQ3pCLFVBQUM7QUFDQ0YsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBbEIsWUFBVSxNQUFNO0FBQ2Q0QixvQkFBZ0I7QUFBQSxFQUNsQixHQUFHLEVBQUU7QUFFTCxRQUFNbUQsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLGFBQWFDLFFBQVEsT0FBTztBQUFBLElBQ25DLEVBQUVELEtBQUssYUFBYUMsUUFBUSxZQUFZO0FBQUEsSUFDeEMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFVBQVU7QUFBQSxJQUNuQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGVBQWU7QUFBQSxJQUM3QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsVUFBVTtBQUFBO0FBQUEsRUFBRTtBQUd2QyxRQUFNQyxnQkFBZ0I7QUFBQSxJQUNwQixFQUFFRixLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssYUFBYUMsUUFBUSxPQUFPO0FBQUEsSUFDbkMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUd4QyxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxvQ0FBbUMseUNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTckQ7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBOEY7QUFBQTtBQUFBLFlBRjFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx3RUFDWlgsc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsa0JBQWUsV0FBc0IsTUFBSyxrQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RCxLQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFDRUUsa0JBQWtCZ0UsU0FBUyxJQUM3QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsTUFBTWhFO0FBQUFBLFlBQ047QUFBQSxZQUNBLFlBQVkrRDtBQUFBQSxZQUNaLGlCQUFnQjtBQUFBLFlBQ2hCLGtCQUFpQjtBQUFBO0FBQUEsVUFObkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTTZDLElBRzdDLHVCQUFDLFNBQUksV0FBVSx5Q0FBd0Msc0NBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsV0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlDQTtBQUFBLFNBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxPQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNBO0FBRUo7QUFBRWxFLEdBN0lJRCx5QkFBdUI7QUFBQXFFLEtBQXZCckU7QUErSU4sZUFBZUE7QUFBd0IsSUFBQXFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkRhdGFUYWJsZSIsIk5hdmJhciIsIkNpcmN1bGFyTG9hZGVyIiwiU2lkZWJhciIsIkFQSSIsIlRhZyIsIlRvb2x0aXAiLCJtZXNzYWdlIiwiZGF5anMiLCJDaGVja0NpcmNsZU91dGxpbmVkIiwiQ2xvY2tDaXJjbGVPdXRsaW5lZCIsIkNsb3NlQ2lyY2xlT3V0bGluZWQiLCJDb3B5T3V0bGluZWQiLCJMaW5rT3V0bGluZWQiLCJQYXltZW50TGlua1RyYW5zYWN0aW9ucyIsIl9zIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwidGFibGVUcmFuc2FjdGlvbnMiLCJzZXRUYWJsZVRyYW5zYWN0aW9ucyIsImhhbmRsZUNvcHlMaW5rIiwidXJsIiwid2FybmluZyIsIm5hdmlnYXRvciIsImNsaXBib2FyZCIsIndyaXRlVGV4dCIsInN1Y2Nlc3MiLCJnZXRUcmFuc2FjdGlvbnMiLCJyZXNwb25zZSIsImdldCIsInRyYW5zYWN0aW9uc0RhdGEiLCJkYXRhIiwiZmlsdGVyZWREYXRhIiwibWFwIiwib3JkZXIiLCJpbmRleCIsInN0YXR1cyIsImNvbG9yIiwiaWNvbiIsImdyb3Vwc1N0cmluZyIsImdyb3VwcyIsImciLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ0aWNrZXQiLCJqb2luIiwicGlnbXlzU3RyaW5nIiwicGlnbXlzIiwicCIsInBheWFibGVfYW1vdW50IiwicGlnbWVfaWQiLCJsb2Fuc1N0cmluZyIsImxvYW5zIiwibCIsImxvYW5fYW1vdW50IiwibG9hbl9pZCIsImlkIiwiY3JlYXRlZEF0IiwiZm9ybWF0Iiwib3JkZXJUeXBlIiwib3JkZXJfdHlwZSIsInVzZXJfbmFtZSIsInVzZXJfaWQiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJvdGhlcnMiLCJzdGF0dXNSYXciLCJjb2xsZWN0ZWRCeSIsImNvbGxlY3RlZF9ieSIsImFtb3VudCIsImFjdGlvbiIsImxpbmtfdXJsIiwiZm9udFNpemUiLCJ3aW5kb3ciLCJvcGVuIiwiaW5mbyIsImVycm9yIiwiY29uc29sZSIsImNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJleHBvcnRDb2x1bW5zIiwibGVuZ3RoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGF5bWVudExpbmtUcmFuc2FjdGlvbnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBUYWcsIFRvb2x0aXAsIG1lc3NhZ2UgfSBmcm9tICdhbnRkJzsgLy8gQWRkZWQgbWVzc2FnZSBhbmQgVG9vbHRpcFxyXG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XHJcbmltcG9ydCB7XHJcbiAgQ2hlY2tDaXJjbGVPdXRsaW5lZCxcclxuICBDbG9ja0NpcmNsZU91dGxpbmVkLFxyXG4gIENsb3NlQ2lyY2xlT3V0bGluZWQsXHJcbiAgQ29weU91dGxpbmVkLCAvLyBBZGRlZFxyXG5cclxuICBMaW5rT3V0bGluZWQgXHJcbn0gZnJvbSAnQGFudC1kZXNpZ24vaWNvbnMnO1xyXG5cclxuY29uc3QgUGF5bWVudExpbmtUcmFuc2FjdGlvbnMgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdGFibGVUcmFuc2FjdGlvbnMsIHNldFRhYmxlVHJhbnNhY3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgLy8gQ29weSBGdW5jdGlvbmFsaXR5XHJcbiAgY29uc3QgaGFuZGxlQ29weUxpbmsgPSAodXJsKSA9PiB7XHJcbiAgICBpZiAoIXVybCkge1xyXG4gICAgICBtZXNzYWdlLndhcm5pbmcoXCJObyBwYXltZW50IGxpbmsgYXZhaWxhYmxlXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh1cmwpO1xyXG4gICAgbWVzc2FnZS5zdWNjZXNzKFwiTGluayBjb3BpZWQgdG8gY2xpcGJvYXJkIVwiKTtcclxuICB9O1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRUcmFuc2FjdGlvbnMoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9jYXNoZnJlZS1wZy1vcmRlcnNcIik7XHJcbiAgICAgIGNvbnN0IHRyYW5zYWN0aW9uc0RhdGEgPSByZXNwb25zZS5kYXRhPy5kYXRhO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgZmlsdGVyZWREYXRhID0gdHJhbnNhY3Rpb25zRGF0YS5tYXAoKG9yZGVyLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHN0YXR1cyA9IG9yZGVyPy5zdGF0dXM7XHJcbiAgICAgICAgY29uc3QgY29sb3IgPSBzdGF0dXMgPT09IFwiQUNUSVZFXCIgPyBcInZpb2xldFwiIDogc3RhdHVzID09PSBcIlBBSURcIiA/IFwiZ3JlZW5cIiA6IFwicmVkXCI7XHJcbiAgICAgICAgY29uc3QgaWNvbiA9IHN0YXR1cyA9PT0gXCJBQ1RJVkVcIiA/IDxDbG9ja0NpcmNsZU91dGxpbmVkIC8+IDogc3RhdHVzID09PSBcIlBBSURcIiA/IDxDaGVja0NpcmNsZU91dGxpbmVkIC8+IDogPENsb3NlQ2lyY2xlT3V0bGluZWQgLz47XHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc3QgZ3JvdXBzU3RyaW5nID0gKG9yZGVyLmdyb3Vwcz8ubWFwKGcgPT4gYCR7Zz8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9IHwgJHtnPy50aWNrZXR9YCkgfHwgW10pLmpvaW4oXCIgfCBcIik7XHJcbiAgICAgICAgY29uc3QgcGlnbXlzU3RyaW5nID0gKG9yZGVyLnBpZ215cz8ubWFwKHAgPT4gYCR7cD8ucGF5YWJsZV9hbW91bnR9IHwgJHtwPy5waWdtZV9pZH1gKSB8fCBbXSkuam9pbihcIiB8IFwiKTtcclxuICAgICAgICBjb25zdCBsb2Fuc1N0cmluZyA9IChvcmRlci5sb2Fucz8ubWFwKGwgPT4gYCR7bD8ubG9hbl9hbW91bnR9IHwgJHtsPy5sb2FuX2lkfWApIHx8IFtdKS5qb2luKFwiIHwgXCIpO1xyXG5cclxuICAgICAgICByZXR1cm4gKHtcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6IG9yZGVyLmNyZWF0ZWRBdCA/IGRheWpzKG9yZGVyLmNyZWF0ZWRBdCkuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSA6IFwiTi9BXCIsXHJcbiAgICAgICAgICBvcmRlclR5cGU6IG9yZGVyPy5vcmRlcl90eXBlLFxyXG4gICAgICAgICAgdXNlcl9uYW1lOiBvcmRlcj8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBvcmRlcj8udXNlcl9pZD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgb3RoZXJzOiBncm91cHNTdHJpbmcgKyBwaWdteXNTdHJpbmcgKyBsb2Fuc1N0cmluZyxcclxuICAgICAgICAgIHN0YXR1czogKFxyXG4gICAgICAgICAgICA8VGFnIGNvbG9yPXtjb2xvcn0gaWNvbj17aWNvbn0gdmFyaWFudD1cImZpbGxlZFwiPlxyXG4gICAgICAgICAgICAgIHtzdGF0dXN9XHJcbiAgICAgICAgICAgIDwvVGFnPlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICAgIHN0YXR1c1Jhdzogc3RhdHVzLFxyXG4gICAgICAgICAgY29sbGVjdGVkQnk6IG9yZGVyPy5jb2xsZWN0ZWRfYnkgfHwgXCJPbmxpbmVcIixcclxuICAgICAgICAgIGFtb3VudDpvcmRlcj8uYW1vdW50LFxyXG4gICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT17b3JkZXIubGlua191cmwgPyBcIkNvcHkgTGlua1wiIDogXCJObyBMaW5rXCJ9PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDb3B5TGluayhvcmRlci5saW5rX3VybCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1jb2xvcnMgJHtvcmRlci5saW5rX3VybCA/ICd0ZXh0LXZpb2xldC02MDAgaG92ZXI6YmctdmlvbGV0LTUwJyA6ICd0ZXh0LWdyYXktMzAwJ31gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8Q29weU91dGxpbmVkIHN0eWxlPXt7IGZvbnRTaXplOiAnMTZweCcgfX0gLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuXHJcbiAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJWaWV3IExpbmtcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3JkZXIubGlua191cmwgPyB3aW5kb3cub3BlbihvcmRlci5saW5rX3VybCwgXCJfYmxhbmtcIikgOiBtZXNzYWdlLmluZm8oXCJMaW5rIG5vdCBmb3VuZFwiKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWNvbG9ycyAke29yZGVyLmxpbmtfdXJsID8gJ3RleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS0xMDAnIDogJ3RleHQtZ3JheS0zMDAnfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rT3V0bGluZWQgc3R5bGU9e3sgZm9udFNpemU6ICcxNnB4JyB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIClcclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFRhYmxlVHJhbnNhY3Rpb25zKGZpbHRlcmVkRGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgc2V0VGFibGVUcmFuc2FjdGlvbnMoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBnZXRUcmFuc2FjdGlvbnMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImNyZWF0ZWRBdFwiLCBoZWFkZXI6IFwiRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyX25hbWVcIiwgaGVhZGVyOiBcIlVzZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJvdGhlcnNcIiwgaGVhZGVyOiBcIkRldGFpbHNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGVkQnlcIiwgaGVhZGVyOiBcIkNvbGxlY3RlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvbnNcIiB9IC8vIEFkZGVkIGNvbHVtblxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGV4cG9ydENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImNyZWF0ZWRBdFwiLCBoZWFkZXI6IFwiRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJvcmRlclR5cGVcIiwgaGVhZGVyOiBcIk9yZGVyIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlcl9uYW1lXCIsIGhlYWRlcjogXCJVc2VyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzUmF3XCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9XHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgYmctZ3JheS01MCBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04IGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICBQYXltZW50IExpbmsgVHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgb25DbGljaz17Z2V0VHJhbnNhY3Rpb25zfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgdGV4dC1zbSBob3ZlcjpiZy1ncmF5LTUwIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJlZnJlc2ggRGF0YVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMjBcIj5cclxuICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e2lzTG9hZGluZ30gZGF0YT1cIlRyYW5zYWN0aW9uc1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiB0YWJsZVRyYW5zYWN0aW9ucy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgZGF0YT17dGFibGVUcmFuc2FjdGlvbnN9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0Q29scz17ZXhwb3J0Q29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlBheW1lbnRfTGlua19UcmFuc2FjdGlvbnNcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIlBheW1lbnRfVHJhbnNhY3Rpb25zLmNzdlwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMjAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTQwMCBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgIE5vIHRyYW5zYWN0aW9ucyBmb3VuZC5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYXltZW50TGlua1RyYW5zYWN0aW9uczsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGF5bWVudExpbmtUcmFuc2FjdGlvbnMuanN4In0=