import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Group.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select, Dropdown, Collapse } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const { Panel } = Collapse;
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const Group = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableGroups, setTableGroups] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [showModalClose, setShowModalClose] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [deletionGroupName, setDeletionGroupName] = useState("");
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [activeTab, setActiveTab] = useState("groups");
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    group_name: "",
    group_type: "",
    group_value: "",
    group_install: "",
    group_members: "",
    group_duration: "",
    start_date: "",
    end_date: "",
    minimum_bid: "",
    maximum_bid: "",
    commission: "1",
    group_commission: "5",
    incentives: "1",
    reg_fee: "",
    monthly_installment: "",
    weekly_installment: "",
    daily_installment: "",
    relationship_manager: "",
    app_display_vacany_seat: "",
    auction_processing_type: "",
    auction_mode: "",
    group_code: ""
  });
  const [errors, setErrors] = useState({});
  const [employees, setEmployees] = useState([]);
  const [updateFormData, setUpdateFormData] = useState({
    group_name: "",
    group_type: "",
    group_value: "",
    group_install: "",
    group_members: "",
    group_duration: "",
    start_date_type: "",
    start_date: "",
    end_date: "",
    minimum_bid: "",
    maximum_bid: "",
    commission: "",
    group_commission: "",
    incentives: "",
    reg_fee: "",
    monthly_installment: "",
    weekly_installment: "",
    daily_installment: "",
    relationship_manager: "",
    app_display_vacany_seat: "",
    auction_processing_type: "",
    auction_mode: "",
    group_code: ""
  });
  const refreshGroups = () => {
    setReloadTrigger((prev) => prev + 1);
  };
  useEffect(() => {
    window.refreshGroups = refreshGroups;
    return () => {
      delete window.refreshGroups;
    };
  }, []);
  useEffect(() => {
    async function getEmployees() {
      try {
        const response = await api.get("/employee");
        const responseData = response.data?.employee;
        setEmployees(responseData ? responseData : []);
      } catch (error) {
        setEmployees([]);
        console.log("Error Fetching Employees");
      }
    }
    getEmployees();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        setIsLoading(true);
        const response = await api.get(
          activeTab === "closed" ? "/v1/admin/groups/status/closed" : "/v1/admin/groups/"
        );
        const groupData = response.data?.data || [];
        setGroups(groupData);
        const filteredData = activeTab === "closed" ? groupData : groupData.filter(
          (group) => group?.status?.toLowerCase() !== "closed"
        );
        const formattedData = filteredData.map((group, index) => ({
          _id: group?._id,
          id: index + 1,
          name: group?.group_name,
          type: group?.group_type?.charAt(0).toUpperCase() + group?.group_type?.slice(1) + " Group",
          value: group?.group_value,
          monthly_installment: group.monthly_installment,
          weekly_installment: group.weekly_installment,
          daily_installment: group.daily_installment,
          relationship_manager: group.relationship_manager?.name || "N/A",
          installment: group.group_install,
          incentives: group.incentives,
          members: group?.group_members,
          start_date: group.start_date ? group.start_date.split("T")[0].split("-").reverse().join("-") : "",
          end_date: group.end_date ? group.end_date.split("T")[0].split("-").reverse().join("-") : "",
          app_display_vacany_seat: group?.app_display_vacany_seat,
          date: group?.createdAt,
          auction_processing_type: group?.auction_processing_type,
          auction_mode: group?.auction_mode,
          group_code: group?.group_code,
          status: group?.status,
          createdAt: group?.createdAt ? group?.createdAt?.split("T")[0].split("-").reverse().join("-") : "",
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: activeTab === "closed" ? [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 194,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 207,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        onClick: () => handleShareClick(group?._id),
                        className: "text-blue-600",
                        children: "Copy"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 220,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ] : [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 235,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 248,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        onClick: () => handleShareClick(group?._id),
                        className: "text-blue-600",
                        children: "Copy"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 261,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "4",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        onClick: () => handleCloseGroupModalOpen(group._id),
                        className: "text-orange-600",
                        children: "Close Group"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 274,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 288,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 185,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
            lineNumber: 184,
            columnNumber: 11
          }, this)
        }));
        setTableGroups(formattedData);
      } catch (error) {
        console.error("Error fetching group data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchGroups();
  }, [reloadTrigger, activeTab]);
  const handleShareClick = (groupId) => {
    if (!groupId) {
      console.error("Missing or invalid groupId");
      return;
    }
    const baseUrl = "http://prod-chit-new.s3-website.eu-north-1.amazonaws.com";
    const fullUrl = `${baseUrl}/enrollment-request-form/?group_id=${groupId}`;
    window.open(fullUrl, "_blank");
  };
  const handleCloseGroupModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/v1/admin/groups/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalClose(true);
    } catch (error) {
      console.error("Error fetching group:", error);
    }
  };
  const handleCloseGroup = async () => {
    try {
      await api.patch(`/v1/admin/groups/${currentGroup?.data?._id}/status/closed`, {
        status: "closed"
      });
      setAlertConfig({
        message: "Group closed successfully",
        type: "success",
        visibility: true
      });
      setShowModalClose(false);
      setCurrentGroup(null);
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      console.error("Error closing group:", error);
      setAlertConfig({
        message: "Failed to close group",
        type: "error",
        visibility: true
      });
    }
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addGroup" ? formData : updateFormData;
    if (!data.group_name.trim()) {
      newErrors.group_name = "Group Name is required";
    }
    if (!data.group_type) {
      newErrors.group_type = "Group Type is required";
    }
    if (!data.group_value) {
      newErrors.group_value = "Group Value is required";
    } else if (isNaN(data.group_value) || data.group_value <= 0) {
      newErrors.group_value = "Group Value must be greater than zero (no";
    }
    if (!data.group_install) {
      newErrors.group_install = "Group Installment Amount is required";
    } else if (!data.group_install || isNaN(data.group_install) || data.group_install <= 0) {
      newErrors.group_install = "Group Installment Amount must be greater than zero (no symbols).";
    }
    if (!data.group_members) {
      newErrors.group_members = "Group Members is required";
    } else if (!data.group_members || isNaN(data.group_members) || data.group_members <= 0) {
      newErrors.group_members = "Group Members must be greater than zero (no symbols).";
    }
    if (!data.relationship_manager) {
      newErrors.relationship_manager = "Relationship Manager is required";
    }
    if (!data.monthly_installment) {
      newErrors.monthly_installment = "Monthly Installment is required";
    }
    if (!data.weekly_installment) {
      newErrors.weekly_installment = "Weekly Installment is required";
    }
    if (!data.daily_installment) {
      newErrors.daily_installment = "Daily Installment is required";
    }
    if (!data.group_duration) {
      newErrors.group_duration = "Group Duration is required";
    } else if (!data.group_duration || isNaN(data.group_duration) || data.group_duration <= 0) {
      newErrors.group_duration = "Group Duration must be greater than zero (no symbols).";
    }
    if (!data.reg_fee) {
      newErrors.reg_fee = "Registration Fee is required";
    } else if (!data.reg_fee || isNaN(data.reg_fee) || data.reg_fee < 0) {
      newErrors.reg_fee = "Registration Fee must be a zero or greater than zero (no symbols).";
    }
    if (!data.start_date) {
      newErrors.start_date = "Start Date is required";
    }
    if (!data.auction_mode) {
      newErrors.auction_mode = "auction mode is required";
    }
    if (!data.auction_processing_type) {
      newErrors.auction_processing_type = "auction processing type is required ";
    }
    if (!data.app_display_vacany_seat) {
      newErrors.app_display_vacany_seat = "Please Enter Display Vacant Seat";
    }
    if (formData.end_date && !data.end_date) {
      newErrors.end_date = "End Date is required";
    } else if (formData.end_date && new Date(data.end_date) < new Date(data.start_date)) {
      newErrors.end_date = "End Date cannot be earlier than Start Date";
    }
    if (!data.minimum_bid) {
      newErrors.minimum_bid = "Minimum Bid is required";
    } else if (!data.minimum_bid || isNaN(data.minimum_bid) || data.minimum_bid <= 0) {
      newErrors.minimum_bid = "Minimum Bid must be greater than zero (no symbols).";
    }
    if (!data.maximum_bid) {
      newErrors.maximum_bid = "Maximum Bid is required";
    } else if (!data.maximum_bid || isNaN(data.maximum_bid) || data.maximum_bid <= 0) {
      newErrors.maximum_bid = "Maximum Bid must be greater than zero (no symbols).";
    } else if (parseFloat(data.maximum_bid) < parseFloat(data.minimum_bid)) {
      newErrors.maximum_bid = "Maximum Bid must be greater than or equal to Minimum Bid";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm("addGroup");
    try {
      if (isValid) {
        const response = await api.post("/group/add-group", formData, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Group Added Successfully",
          type: "success"
        });
        setShowModal(false);
        setFormData({
          group_name: "",
          group_type: "",
          group_value: "",
          group_install: "",
          group_members: "",
          group_duration: "",
          group_commission: "5",
          start_date: "",
          end_date: "",
          minimum_bid: "",
          maximum_bid: "",
          commission: "",
          incentives: "",
          relationship_manager: "",
          monthly_installment: "",
          app_display_vacany_seat: "",
          auction_processing_type: "",
          auction_mode: ""
        });
      } else {
        console.log(errors);
      }
    } catch (error) {
      console.error("Error adding group:", error);
    }
  };
  const filteredGroups = groups.filter(
    (group) => group.group_name?.toLowerCase().includes(searchTerm?.toLowerCase())
  );
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/v1/admin/groups/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching group:", error);
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    const editUrl = `/add-new-group?edit=true&groupId=${groupId}`;
    window.open(editUrl, "_blank");
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors({ ...errors, [name]: "" });
  };
  const handleDeleteGroup = async (e) => {
    if (currentGroup && deletionGroupName.toString().trim() === currentGroup.group_name) {
      try {
        await api.delete(`/v1/admin/groups/${currentGroup._id}`);
        setAlertConfig({
          message: "Group deleted successfully",
          type: "success",
          visibility: true
        });
        setReloadTrigger((prev) => prev + 1);
        setShowModalDelete(false);
        setCurrentGroup(null);
      } catch (error) {
        console.error("Error deleting group:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        await api.put(
          `/v1/admin/groups/${currentUpdateGroup._id}`,
          updateFormData
        );
        setShowModalUpdate(false);
        setAlertConfig({
          message: "Group updated successfully",
          type: "success",
          visibility: true
        });
        setReloadTrigger((prev) => prev + 1);
      }
    } catch (error) {
      console.error("Error updating group:", error);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "group_code", header: "Group Code" },
    { key: "name", header: "Group Name" },
    { key: "type", header: "Group Type" },
    { key: "value", header: "Group Value" },
    { key: "members", header: "Group Members" },
    { key: "installment", header: "Group Installment" },
    { key: "start_date", header: "Start Date" },
    { key: "end_date", header: "End Date" },
    { key: "daily_installment", header: "Daily Installment" },
    { key: "app_display_vacany_seat", header: "App Display Vacany Seat" },
    { key: "weekly_installment", header: "Weekly Installment" },
    { key: "monthly_installment", header: "Monthly Installment" },
    { key: "relationship_manager", header: "Relationship Manager" },
    { key: "createdAt", header: "Created At" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: true,
        onGlobalSearchChangeHandler
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 676,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 681,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Groups" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
          lineNumber: 694,
          columnNumber: 17
        }, this),
        activeTab === "groups" && /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              window.open("/add-new-group", "_blank");
            },
            className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
            children: "+ Add Group"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
            lineNumber: 697,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 693,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 692,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-6 mb-4 border-b border-gray-200", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setActiveTab("groups"),
            className: `px-6 py-3 text-sm font-semibold transition-all duration-200 border-b-2 ${activeTab === "groups" ? "text-blue-950 border-blue-950" : "text-gray-500 border-transparent hover:text-blue-950"}`,
            children: "Groups"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
            lineNumber: 710,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setActiveTab("closed"),
            className: `px-6 py-3 text-sm font-semibold transition-all duration-200 border-b-2 ${activeTab === "closed" ? "text-blue-950 border-blue-950" : "text-gray-500 border-transparent hover:text-blue-950"}`,
            children: "Closed Groups"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
            lineNumber: 721,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 709,
        columnNumber: 13
      }, this),
      TableGroups.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          catcher: "_id",
          updateHandler: handleUpdateModalOpen,
          data: filterOption(TableGroups, searchText),
          columns,
          exportedPdfName: activeTab === "closed" ? "Closed Groups" : "Groups",
          exportedFileName: activeTab === "closed" ? "Closed-Groups.csv" : "Groups.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
          lineNumber: 734,
          columnNumber: 13
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          failure: TableGroups.length <= 0,
          data: activeTab === "closed" ? "Closed Group Data" : "Group Data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
          lineNumber: 749,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 760,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
      lineNumber: 691,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
      lineNumber: 690,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Group" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 766,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        "form",
        {
          className: "space-y-6",
          onSubmit: handleSubmit,
          noValidate: true,
          children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Group Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 780,
                      columnNumber: 30
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 776,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "group_name",
                  value: formData.group_name,
                  onChange: handleChange,
                  id: "name",
                  placeholder: "Enter the Group Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 783,
                  columnNumber: 17
                },
                this
              ),
              errors.group_name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 795,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 775,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Group Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 806,
                      columnNumber: 30
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 802,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select or Search Group Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "group_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: formData?.group_type || void 0,
                  onChange: (value) => handleAntDSelect("group_type", value),
                  children: ["Divident", "Double"].map(
                    (gType) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: gType.toLowerCase(),
                        children: gType
                      },
                      gType,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 826,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 809,
                  columnNumber: 17
                },
                this
              ),
              errors.group_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 836,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 801,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Relationship Manager",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 849,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 844,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    placeholder: "Select or Search Relationship Manager",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "relationship_manager",
                    filterOption: (input, option) => {
                      const text = `${option.children}`;
                      return text.toLowerCase().includes(input.toLowerCase());
                    },
                    value: formData?.relationship_manager || void 0,
                    onChange: (value) => handleAntDSelect(
                      "relationship_manager",
                      value
                    ),
                    children: (Array.isArray(employees) ? employees : []).map(
                      (employee) => /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: employee?._id,
                          children: [
                            employee?.name,
                            " | ",
                            employee?.phone_number
                          ]
                        },
                        employee?._id,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                          lineNumber: 876,
                          columnNumber: 23
                        },
                        this
                      )
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 852,
                    columnNumber: 19
                  },
                  this
                ),
                errors.relationship_manager && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.relationship_manager }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 887,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 843,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "App Display Vacany Seat",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 899,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 894,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "app_display_vacany_seat",
                    value: formData.app_display_vacany_seat,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter App Display Vacany Seat",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 902,
                    columnNumber: 19
                  },
                  this
                ),
                errors.app_display_vacany_seat && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.app_display_vacany_seat }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 914,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                  formData.app_display_vacany_seat || 0
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 919,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 893,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 842,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Group Value ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 933,
                        columnNumber: 33
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 929,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "group_value",
                    value: formData.group_value,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Group Value",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 936,
                    columnNumber: 19
                  },
                  this
                ),
                errors.group_value && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_value }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 948,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(formData.group_value || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 953,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 928,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Group Installment Amount",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 964,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 959,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "group_install",
                    value: formData.group_install,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Group Installment Amount",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 967,
                    columnNumber: 19
                  },
                  this
                ),
                errors.group_install && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_install }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 979,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(formData.group_install || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 984,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 958,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 927,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Group Members ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 996,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 992,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "group_members",
                    value: formData.group_members,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Group Members",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 999,
                    columnNumber: 19
                  },
                  this
                ),
                errors.group_members && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_members }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1011,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(formData.group_members || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1016,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 991,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Group Duration",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1027,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1022,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "group_duration",
                    value: formData.group_duration,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Group Duration",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1030,
                    columnNumber: 19
                  },
                  this
                ),
                errors.group_duration && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_duration }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1042,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(formData.group_duration || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1047,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1021,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 990,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Daily Installment",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1060,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1055,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "daily_installment",
                    value: formData.daily_installment,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Daily Installment",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1063,
                    columnNumber: 19
                  },
                  this
                ),
                errors.daily_installment && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.daily_installment }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1075,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                  formData.daily_installment || 0
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1080,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1054,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Weekly Installment",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1093,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1088,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "weekly_installment",
                    value: formData.weekly_installment,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Weekly Installment",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1096,
                    columnNumber: 19
                  },
                  this
                ),
                errors.weekly_installment && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.weekly_installment }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1108,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                  formData.weekly_installment || 0
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1113,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1087,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 1053,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "monthly_install",
                    children: [
                      "Monthly Installment",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1128,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1123,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "monthly_installment",
                    value: formData.monthly_installment,
                    onChange: handleChange,
                    id: "monthly_install",
                    placeholder: "Enter Monthly Installment",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1131,
                    columnNumber: 19
                  },
                  this
                ),
                errors.monthly_installment && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.monthly_installment }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1143,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                  formData.monthly_installment || 0
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1148,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1122,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Registration Fee",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1161,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1156,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "reg_fee",
                    value: formData.reg_fee,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Registration Fee",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1164,
                    columnNumber: 19
                  },
                  this
                ),
                errors.reg_fee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.reg_fee }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1176,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(formData.reg_fee || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1181,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1155,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 1121,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Start Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1193,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1189,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "start_date",
                    value: formData.start_date,
                    onChange: handleChange,
                    id: "date",
                    placeholder: "Enter the Date",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1196,
                    columnNumber: 19
                  },
                  this
                ),
                errors.start_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.start_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1208,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1188,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "End Date"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1215,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "end_date",
                    value: formData.end_date,
                    onChange: handleChange,
                    id: "date",
                    placeholder: "Enter the Date",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1222,
                    columnNumber: 19
                  },
                  this
                ),
                errors.end_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.end_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1234,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1214,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 1187,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Minimum Bid ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1247,
                        columnNumber: 33
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1243,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "minimum_bid",
                    value: formData.minimum_bid,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Minimum Bid",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1250,
                    columnNumber: 19
                  },
                  this
                ),
                errors.minimum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.minimum_bid }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1262,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(formData.minimum_bid || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1267,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1242,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Maximum Bid ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1277,
                        columnNumber: 33
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1273,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "maximum_bid",
                    value: formData.maximum_bid,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Maximum Bid",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1280,
                    columnNumber: 19
                  },
                  this
                ),
                errors.maximum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.maximum_bid }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1292,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(formData.maximum_bid || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1297,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1272,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 1241,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Agent Commission %" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1305,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "commission",
                    value: formData.commission,
                    onChange: handleChange,
                    placeholder: "Enter Commission",
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1309,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(formData.commission || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1318,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1304,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Company Commission %" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1324,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "group_commission",
                    value: formData.group_commission,
                    onChange: handleChange,
                    placeholder: "Enter Group Commission",
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1328,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                  formData.group_commission || 0
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1337,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1323,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Employee Incentives %" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1345,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "incentives",
                    value: formData.incentives,
                    onChange: handleChange,
                    placeholder: "Enter Incentives",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1349,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(formData.incentives || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1358,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1344,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 1303,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
                children: "Save Group"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 1365,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 1364,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
          lineNumber: 770,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
      lineNumber: 765,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
      lineNumber: 764,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
            lineNumber: 1381,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "form",
            {
              className: "space-y-6",
              onSubmit: handleUpdate,
              noValidate: true,
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "email",
                      children: [
                        "Group Name ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                          lineNumber: 1395,
                          columnNumber: 30
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1391,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "group_name",
                      value: updateFormData.group_name,
                      onChange: handleInputChange,
                      id: "name",
                      placeholder: "Enter the Group Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1398,
                      columnNumber: 17
                    },
                    this
                  ),
                  errors.group_name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1410,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1390,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "category",
                      children: [
                        "Group Type ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                          lineNumber: 1421,
                          columnNumber: 30
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1417,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select or Search Group Type",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "group_type",
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      value: updateFormData?.group_type || void 0,
                      onChange: (value) => handleAntInputDSelect("group_type", value),
                      children: ["Divident", "Double", "Fixed"].map(
                        (gType) => /* @__PURE__ */ jsxDEV(
                          Select.Option,
                          {
                            value: gType.toLowerCase(),
                            children: gType
                          },
                          gType,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1441,
                            columnNumber: 19
                          },
                          this
                        )
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1424,
                      columnNumber: 17
                    },
                    this
                  ),
                  errors.group_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_type }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1451,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1416,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "category",
                        children: [
                          "Relationship Manager",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1464,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1459,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select or Search Relationship Manager",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "relationship_manager",
                        filterOption: (input, option) => {
                          const text = `${option.children}`;
                          return text.toLowerCase().includes(input.toLowerCase());
                        },
                        value: updateFormData?.relationship_manager || void 0,
                        onChange: (value) => handleAntInputDSelect(
                          "relationship_manager",
                          value
                        ),
                        children: (Array.isArray(employees) ? employees : []).map(
                          (employee) => /* @__PURE__ */ jsxDEV(
                            Select.Option,
                            {
                              value: employee?._id,
                              children: [
                                employee?.name,
                                " | ",
                                employee?.phone_number
                              ]
                            },
                            employee?._id,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                              lineNumber: 1492,
                              columnNumber: 23
                            },
                            this
                          )
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1467,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.relationship_manager && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.relationship_manager }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1503,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1458,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "App Display Vacany Seat",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1515,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1510,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "app_display_vacany_seat",
                        value: updateFormData.app_display_vacany_seat,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter App Display Vacany Seat",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1518,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.app_display_vacany_seat && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.app_display_vacany_seat }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1530,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.app_display_vacany_seat || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1535,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1509,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1457,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Group Value ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1549,
                            columnNumber: 33
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1545,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "group_value",
                        value: updateFormData.group_value,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Group Value",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1552,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.group_value && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_value }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1564,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.group_value || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1569,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1544,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Group Installment Amount",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1582,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1577,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "group_install",
                        value: updateFormData.group_install,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Group Installment Amount",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1585,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.group_install && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_install }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1597,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.group_install || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1602,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1576,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1543,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Group Members ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1616,
                            columnNumber: 35
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1612,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "group_members",
                        value: updateFormData.group_members,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Group Members",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1619,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.group_members && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_members }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1631,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.group_members || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1636,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1611,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Group Duration",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1649,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1644,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "group_duration",
                        value: updateFormData.group_duration,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Group Duration",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1652,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.group_duration && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_duration }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1664,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.group_duration || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1669,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1643,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1610,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Daily Installment",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1684,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1679,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "daily_installment",
                        value: updateFormData.daily_installment,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Group Members",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1687,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.daily_installment && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.daily_installment }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1699,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.daily_installment || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1704,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1678,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Weekly Installment",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1717,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1712,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "weekly_installment",
                        value: updateFormData.weekly_installment,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Group Duration",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1720,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.weekly_installment && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.weekly_installment }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1732,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.weekly_installment || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1737,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1711,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1677,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "monthly_install",
                        children: [
                          "Monthly Installment",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1752,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1747,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "monthly_installment",
                        value: updateFormData.monthly_installment,
                        onChange: handleInputChange,
                        id: "monthly_install",
                        placeholder: "Enter Monthly Installment",
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1755,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.monthly_installment && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.monthly_installment }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1767,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.monthly_installment || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1772,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1746,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "email",
                        children: [
                          "Registration Fee",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1785,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1780,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "reg_fee",
                        value: updateFormData.reg_fee,
                        onChange: handleInputChange,
                        id: "name",
                        placeholder: "Enter the Registration Fee",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1788,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.reg_fee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.reg_fee }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1800,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.reg_fee || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1805,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1779,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1745,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Start Date Type",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1817,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1815,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-6 mt-2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "flex items-center space-x-2 cursor-pointer", children: [
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "radio",
                          name: "start_date_type",
                          value: "expected",
                          checked: updateFormData?.start_date_type === "expected",
                          onChange: handleInputChange,
                          className: "w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                          lineNumber: 1822,
                          columnNumber: 23
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: "Expected" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1833,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1821,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("label", { className: "flex items-center space-x-2 cursor-pointer", children: [
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "radio",
                          name: "start_date_type",
                          value: "fixed",
                          checked: updateFormData?.start_date_type === "fixed",
                          onChange: handleInputChange,
                          className: "w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                          lineNumber: 1839,
                          columnNumber: 23
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: "Fixed" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1849,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1838,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1820,
                    columnNumber: 19
                  }, this),
                  errors.start_date_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.start_date_type }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1856,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1814,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1813,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Start Date ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1869,
                            columnNumber: 32
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1865,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        name: "start_date",
                        value: updateFormData.start_date,
                        onChange: handleInputChange,
                        id: "date",
                        placeholder: "Enter the Date",
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1872,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.start_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.start_date }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1884,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1864,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: "End Date"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1891,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        name: "end_date",
                        value: updateFormData.end_date,
                        onChange: handleInputChange,
                        id: "date",
                        placeholder: "Enter the Date",
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1898,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.end_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.end_date }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1910,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1890,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1863,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Minimum Bid %",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1924,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1919,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "minimum_bid",
                        value: updateFormData.minimum_bid,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Minimum Bid",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1927,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.minimum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.minimum_bid }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1939,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.minimum_bid || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1944,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1918,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Maximum Bid %",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 1957,
                            columnNumber: 21
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1952,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "maximum_bid",
                        value: updateFormData.maximum_bid,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Maximum Bid",
                        required: true,
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1960,
                        columnNumber: 19
                      },
                      this
                    ),
                    errors.maximum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.maximum_bid }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1972,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.maximum_bid || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1977,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1951,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1917,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Agent Commission %" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 1987,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "commission",
                        value: updateFormData.commission,
                        onChange: handleInputChange,
                        placeholder: "Enter Commission",
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 1991,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.commission || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 2e3,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 1986,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Company Commission %" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 2008,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "group_commission",
                        value: updateFormData.group_commission,
                        onChange: handleInputChange,
                        placeholder: "Enter Group Commission",
                        className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 2012,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.group_commission || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 2021,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 2007,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Employee Incentives %" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 2029,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "incentives",
                        value: updateFormData.incentives,
                        onChange: handleInputChange,
                        placeholder: "Enter Incentives",
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 2033,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700", children: numberToIndianWords(
                      updateFormData.incentives || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 2042,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 2028,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 1985,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Collapse,
                  {
                    defaultActiveKey: ["1"],
                    className: "bg-white rounded-xl shadow-md border border-gray-200",
                    children: /* @__PURE__ */ jsxDEV(
                      Panel,
                      {
                        header: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: "Auction Details" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                          lineNumber: 2056,
                          columnNumber: 19
                        }, this),
                        children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Auction Processing Type" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                              lineNumber: 2064,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              Select,
                              {
                                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                                placeholder: "Select Processing Type",
                                popupMatchSelectWidth: false,
                                showSearch: true,
                                name: "auction_processing_type",
                                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                                value: updateFormData?.auction_processing_type || void 0,
                                onChange: (value) => handleAntInputDSelect(
                                  "auction_processing_type",
                                  value
                                ),
                                children: ["SYSTEM", "MANUAL"].map(
                                  (stype) => /* @__PURE__ */ jsxDEV(
                                    Select.Option,
                                    {
                                      value: stype,
                                      children: stype.charAt(0).toUpperCase() + stype.slice(1).toLowerCase()
                                    },
                                    stype,
                                    false,
                                    {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                                      lineNumber: 2091,
                                      columnNumber: 25
                                    },
                                    this
                                  )
                                )
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                                lineNumber: 2068,
                                columnNumber: 23
                              },
                              this
                            )
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 2063,
                            columnNumber: 21
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Auction Mode" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                              lineNumber: 2103,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              Select,
                              {
                                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                                placeholder: "Select Auction Mode",
                                popupMatchSelectWidth: false,
                                showSearch: true,
                                name: "auction_mode",
                                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                                value: updateFormData?.auction_mode || void 0,
                                onChange: (value) => handleAntInputDSelect(
                                  "auction_mode",
                                  value
                                ),
                                children: ["ONLINE", "OFFLINE"].map(
                                  (stype) => /* @__PURE__ */ jsxDEV(
                                    Select.Option,
                                    {
                                      value: stype,
                                      children: stype.charAt(0).toUpperCase() + stype.slice(1).toLowerCase()
                                    },
                                    stype,
                                    false,
                                    {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                                      lineNumber: 2129,
                                      columnNumber: 25
                                    },
                                    this
                                  )
                                )
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                                lineNumber: 2107,
                                columnNumber: 23
                              },
                              this
                            )
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                            lineNumber: 2102,
                            columnNumber: 21
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                          lineNumber: 2062,
                          columnNumber: 19
                        }, this)
                      },
                      "1",
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                        lineNumber: 2054,
                        columnNumber: 17
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 2050,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
                    children: "Update"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 2144,
                    columnNumber: 17
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 2143,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 1385,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
          lineNumber: 1380,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 1376,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
            lineNumber: 2163,
            columnNumber: 13
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteGroup();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentGroup.group_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                          lineNumber: 2181,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                          lineNumber: 2185,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 2176,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the Group Name",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5",
                      onChange: (e) => setDeletionGroupName(e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                      lineNumber: 2188,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                  lineNumber: 2175,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                    lineNumber: 2200,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 2168,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
          lineNumber: 2162,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 2155,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalClose,
        onClose: () => {
          setShowModalClose(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Close Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
            lineNumber: 2219,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "py-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-full bg-orange-100 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-2xl text-orange-600", children: "!" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 2226,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 2225,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 2224,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-center text-gray-700 text-base", children: "Do you want to close this group?" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 2230,
              columnNumber: 15
            }, this),
            currentGroup?.data?.group_name && /* @__PURE__ */ jsxDEV("p", { className: "text-center mt-2 font-semibold text-gray-900", children: currentGroup?.data?.group_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
              lineNumber: 2235,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
            lineNumber: 2223,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-6", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  setShowModalClose(false);
                  setCurrentGroup(null);
                },
                className: "px-5 py-2.5 rounded-lg border border-gray-300 text-gray-700 bg-white hover:bg-gray-100 font-medium",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 2242,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: handleCloseGroup,
                className: "px-5 py-2.5 rounded-lg bg-orange-600 hover:bg-orange-700 text-white font-medium",
                children: "Yes, Close Group"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
                lineNumber: 2253,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
            lineNumber: 2241,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
          lineNumber: 2218,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
        lineNumber: 2211,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
    lineNumber: 675,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx",
    lineNumber: 674,
    columnNumber: 5
  }, this);
};
_s(Group, "nxjVBGdBqC+wW/P8PaBNsvkqsss=");
_c = Group;
export default Group;
var _c;
$RefreshReg$(_c, "Group");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Group.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaU00QixTQWdleEIsVUFoZXdCOzJCQWpNNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxRQUFRQyxVQUFVQyxnQkFBZ0I7QUFDM0MsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsTUFBTSxFQUFFQyxNQUFNLElBQUlOO0FBRWxCLE9BQU9PLHVCQUF1QjtBQUU5QixTQUFTQywyQkFBMkI7QUFDcEMsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLFFBQVFBLE1BQU07QUFBQUMsS0FBQTtBQUNsQixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSXBCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNxQixhQUFhQyxjQUFjLElBQUl0QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDdUIsWUFBWUMsYUFBYSxJQUFJeEIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3lCLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyQixpQkFBaUJDLGtCQUFrQixJQUFJNUIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzZCLGlCQUFpQkMsa0JBQWtCLElBQUk5QixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDK0IsZ0JBQWdCQyxpQkFBaUIsSUFBSWhDLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUNpQyxjQUFjQyxlQUFlLElBQUlsQyxTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDbUMsb0JBQW9CQyxxQkFBcUIsSUFBSXBDLFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUNxQyxZQUFZQyxhQUFhLElBQUl0QyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDdUMsV0FBV0MsWUFBWSxJQUFJeEMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3lDLG1CQUFtQkMsb0JBQW9CLElBQUkxQyxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDMkMsZUFBZUMsZ0JBQWdCLElBQUk1QyxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDNkMsV0FBV0MsWUFBWSxJQUFJOUMsU0FBUyxRQUFRO0FBRW5ELFFBQU0rQyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCWixrQkFBY1csS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTSxDQUFDRSxhQUFhQyxjQUFjLElBQUlwRCxTQUFTO0FBQUEsSUFDN0NxRCxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSXpELFNBQVM7QUFBQSxJQUN2QzBELFlBQVk7QUFBQSxJQUNaQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLGVBQWU7QUFBQSxJQUNmQyxlQUFlO0FBQUEsSUFDZkMsZ0JBQWdCO0FBQUEsSUFDaEJDLFlBQVk7QUFBQSxJQUNaQyxVQUFVO0FBQUEsSUFDVkMsYUFBYTtBQUFBLElBQ2JDLGFBQWE7QUFBQSxJQUNiQyxZQUFZO0FBQUEsSUFDWkMsa0JBQWtCO0FBQUEsSUFDbEJDLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMscUJBQXFCO0FBQUEsSUFDckJDLG9CQUFvQjtBQUFBLElBQ3BCQyxtQkFBbUI7QUFBQSxJQUNuQkMsc0JBQXNCO0FBQUEsSUFDdEJDLHlCQUF5QjtBQUFBLElBQ3pCQyx5QkFBeUI7QUFBQSxJQUN6QkMsY0FBYztBQUFBLElBQ2RDLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFFRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWpGLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ2tGLFdBQVdDLFlBQVksSUFBSW5GLFNBQVMsRUFBRTtBQUU3QyxRQUFNLENBQUNvRixnQkFBZ0JDLGlCQUFpQixJQUFJckYsU0FBUztBQUFBLElBQ25EMEQsWUFBWTtBQUFBLElBQ1pDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUEsSUFDYkMsZUFBZTtBQUFBLElBQ2ZDLGVBQWU7QUFBQSxJQUNmQyxnQkFBZ0I7QUFBQSxJQUNoQnVCLGlCQUFpQjtBQUFBLElBQ2pCdEIsWUFBWTtBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxhQUFhO0FBQUEsSUFDYkMsYUFBYTtBQUFBLElBQ2JDLFlBQVk7QUFBQSxJQUNaQyxrQkFBa0I7QUFBQSxJQUNsQkMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxxQkFBcUI7QUFBQSxJQUNyQkMsb0JBQW9CO0FBQUEsSUFDcEJDLG1CQUFtQjtBQUFBLElBQ25CQyxzQkFBc0I7QUFBQSxJQUN0QkMseUJBQXlCO0FBQUEsSUFDekJDLHlCQUF5QjtBQUFBLElBQ3pCQyxjQUFjO0FBQUEsSUFDZEMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVELFFBQU1RLGdCQUFnQkEsTUFBTTtBQUMxQjNDLHFCQUFpQixDQUFDNEMsU0FBU0EsT0FBTyxDQUFDO0FBQUEsRUFDckM7QUFFQXpGLFlBQVUsTUFBTTtBQUNkMEYsV0FBT0YsZ0JBQWdCQTtBQUN2QixXQUFPLE1BQU07QUFDWCxhQUFPRSxPQUFPRjtBQUFBQSxJQUNoQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUx4RixZQUFVLE1BQU07QUFDZCxtQkFBZTJGLGVBQWU7QUFDNUIsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTXhGLElBQUl5RixJQUFJLFdBQVc7QUFDMUMsY0FBTUMsZUFBZUYsU0FBU0csTUFBTUM7QUFDcENaLHFCQUFhVSxlQUFlQSxlQUFlLEVBQUU7QUFBQSxNQUMvQyxTQUFTRyxPQUFPO0FBQ2RiLHFCQUFhLEVBQUU7QUFDZmMsZ0JBQVFDLElBQUksMEJBQTBCO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0FSLGlCQUFhO0FBQUEsRUFDZixHQUFHLEVBQUU7QUFFTDNGLFlBQVUsTUFBTTtBQUNkLFVBQU1vRyxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGM0QscUJBQWEsSUFBSTtBQUVqQixjQUFNbUQsV0FBVyxNQUFNeEYsSUFBSXlGO0FBQUFBLFVBQ3pCL0MsY0FBYyxXQUNWLG1DQUNBO0FBQUEsUUFDTjtBQUVBLGNBQU11RCxZQUFZVCxTQUFTRyxNQUFNQSxRQUFRO0FBRXpDMUUsa0JBQVVnRixTQUFTO0FBRW5CLGNBQU1DLGVBQ0p4RCxjQUFjLFdBQ1Z1RCxZQUNBQSxVQUFVRTtBQUFBQSxVQUNWLENBQUNDLFVBQVVBLE9BQU9DLFFBQVFDLFlBQVksTUFBTTtBQUFBLFFBQzlDO0FBRUosY0FBTUMsZ0JBQWdCTCxhQUFhTSxJQUFJLENBQUNKLE9BQU9LLFdBQVc7QUFBQSxVQUN4REMsS0FBS04sT0FBT007QUFBQUEsVUFDWkMsSUFBSUYsUUFBUTtBQUFBLFVBQ1pHLE1BQU1SLE9BQU83QztBQUFBQSxVQUNiSCxNQUNFZ0QsT0FBTzVDLFlBQVlxRCxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUN6Q1YsT0FBTzVDLFlBQVl1RCxNQUFNLENBQUMsSUFDMUI7QUFBQSxVQUNGakUsT0FBT3NELE9BQU8zQztBQUFBQSxVQUNkWSxxQkFBcUIrQixNQUFNL0I7QUFBQUEsVUFDM0JDLG9CQUFvQjhCLE1BQU05QjtBQUFBQSxVQUMxQkMsbUJBQW1CNkIsTUFBTTdCO0FBQUFBLFVBQ3pCQyxzQkFBc0I0QixNQUFNNUIsc0JBQXNCb0MsUUFBUTtBQUFBLFVBQzFESSxhQUFhWixNQUFNMUM7QUFBQUEsVUFDbkJTLFlBQVlpQyxNQUFNakM7QUFBQUEsVUFDbEI4QyxTQUFTYixPQUFPekM7QUFBQUEsVUFDaEJFLFlBQVl1QyxNQUFNdkMsYUFDZHVDLE1BQU12QyxXQUFXcUQsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFQSxNQUFNLEdBQUcsRUFBRUMsUUFBUSxFQUFFQyxLQUFLLEdBQUcsSUFDNUQ7QUFBQSxVQUNKdEQsVUFBVXNDLE1BQU10QyxXQUNac0MsTUFBTXRDLFNBQVNvRCxNQUFNLEdBQUcsRUFBRSxDQUFDLEVBQUVBLE1BQU0sR0FBRyxFQUFFQyxRQUFRLEVBQUVDLEtBQUssR0FBRyxJQUMxRDtBQUFBLFVBQ0ozQyx5QkFBeUIyQixPQUFPM0I7QUFBQUEsVUFDaEM0QyxNQUFNakIsT0FBT2tCO0FBQUFBLFVBQ2I1Qyx5QkFBeUIwQixPQUFPMUI7QUFBQUEsVUFDaENDLGNBQWN5QixPQUFPekI7QUFBQUEsVUFDckJDLFlBQVl3QixPQUFPeEI7QUFBQUEsVUFDbkJ5QixRQUFRRCxPQUFPQztBQUFBQSxVQUNmaUIsV0FBV2xCLE9BQU9rQixZQUNkbEIsT0FBT2tCLFdBQ0xKLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFDYkEsTUFBTSxHQUFHLEVBQ1RDLFFBQVEsRUFDUkMsS0FBSyxHQUFHLElBQ1Q7QUFBQSxVQUNKRyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxDQUFDLE9BQU87QUFBQSxjQUNqQixNQUFNO0FBQUEsZ0JBQ0pDLE9BQ0U5RSxjQUFjLFdBQ1Y7QUFBQSxrQkFDQTtBQUFBLG9CQUNFK0UsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQ1BDLHNCQUFzQnZCLE1BQU1NLEdBQUc7QUFBQSx3QkFDaEM7QUFBQTtBQUFBLHNCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRWUsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQ1BFLHNCQUFzQnhCLE1BQU1NLEdBQUc7QUFBQSx3QkFDaEM7QUFBQTtBQUFBLHNCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRWUsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFNBQVMsTUFDUEcsaUJBQWlCekIsT0FBT00sR0FBRztBQUFBLHdCQUU3QixXQUFVO0FBQUEsd0JBQWU7QUFBQTtBQUFBLHNCQUozQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSxrQkFFSjtBQUFBLGdCQUFDLElBRUQ7QUFBQSxrQkFDQTtBQUFBLG9CQUNFZSxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFDUEMsc0JBQXNCdkIsTUFBTU0sR0FBRztBQUFBLHdCQUNoQztBQUFBO0FBQUEsc0JBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9BO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFZSxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFDUEUsc0JBQXNCeEIsTUFBTU0sR0FBRztBQUFBLHdCQUNoQztBQUFBO0FBQUEsc0JBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9BO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFZSxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsU0FBUyxNQUNQRyxpQkFBaUJ6QixPQUFPTSxHQUFHO0FBQUEsd0JBRTdCLFdBQVU7QUFBQSx3QkFBZTtBQUFBO0FBQUEsc0JBSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRWUsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFNBQVMsTUFDUEksMEJBQTBCMUIsTUFBTU0sR0FBRztBQUFBLHdCQUVyQyxXQUFVO0FBQUEsd0JBQWlCO0FBQUE7QUFBQSxzQkFKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9BO0FBQUEsa0JBRUo7QUFBQSxnQkFBQztBQUFBLGNBRVQ7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBO0FBQUEsWUF2R2pDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXdHQSxLQXpHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBHQTtBQUFBLFFBRUosRUFBRTtBQUVGdkYsdUJBQWVvRixhQUFhO0FBQUEsTUFDOUIsU0FBU1YsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRCxVQUFDO0FBQ0N4RCxxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBRUEyRCxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDeEQsZUFBZUUsU0FBUyxDQUFDO0FBRTdCLFFBQU1tRixtQkFBbUJBLENBQUNFLFlBQVk7QUFDcEMsUUFBSSxDQUFDQSxTQUFTO0FBQ1pqQyxjQUFRRCxNQUFNLDRCQUE0QjtBQUMxQztBQUFBLElBQ0Y7QUFFQSxVQUFNbUMsVUFDSjtBQUNGLFVBQU1DLFVBQVUsR0FBR0QsT0FBTyxzQ0FBc0NELE9BQU87QUFFdkV6QyxXQUFPNEMsS0FBS0QsU0FBUyxRQUFRO0FBQUEsRUFDL0I7QUFFQSxRQUFNSCw0QkFBNEIsT0FBT0MsWUFBWTtBQUNuRCxRQUFJO0FBQ0YsWUFBTXZDLFdBQVcsTUFBTXhGLElBQUl5RixJQUFJLG9CQUFvQnNDLE9BQU8sRUFBRTtBQUM1RGhHLHNCQUFnQnlELFNBQVNHLElBQUk7QUFDN0I5RCx3QkFBa0IsSUFBSTtBQUFBLElBQ3hCLFNBQVNnRSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTXNDLG1CQUFtQixZQUFZO0FBS25DLFFBQUk7QUFDRixZQUFNbkksSUFBSW9JLE1BQU0sb0JBQW9CdEcsY0FBYzZELE1BQU1lLEdBQUcsa0JBQWtCO0FBQUEsUUFDM0VMLFFBQVE7QUFBQSxNQUNWLENBQUM7QUFFRHBELHFCQUFlO0FBQUEsUUFDYkUsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxRQUNORixZQUFZO0FBQUEsTUFDZCxDQUFDO0FBRURyQix3QkFBa0IsS0FBSztBQUN2QkUsc0JBQWdCLElBQUk7QUFDcEJVLHVCQUFpQixDQUFDNEMsU0FBU0EsT0FBTyxDQUFDO0FBQUEsSUFDckMsU0FBU1EsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUUzQzVDLHFCQUFlO0FBQUEsUUFDYkUsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxRQUNORixZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUYsZUFBZUEsQ0FBQ3hGLE1BQU07QUFDMUIsVUFBTSxFQUFFK0QsTUFBTTlELE1BQU0sSUFBSUQsRUFBRUU7QUFFMUJPLGdCQUFZLENBQUNnRixjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDMUIsSUFBSSxHQUFHOUQ7QUFBQUEsSUFDVixFQUFFO0FBRUZnQyxjQUFVLENBQUN3RCxjQUFjO0FBQUEsTUFDdkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDMUIsSUFBSSxHQUFHO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU0yQixlQUFlQSxDQUFDbkYsU0FBUztBQUM3QixVQUFNb0YsWUFBWSxDQUFDO0FBRW5CLFVBQU03QyxPQUFPdkMsU0FBUyxhQUFhQyxXQUFXNEI7QUFFOUMsUUFBSSxDQUFDVSxLQUFLcEMsV0FBV2tGLEtBQUssR0FBRztBQUMzQkQsZ0JBQVVqRixhQUFhO0FBQUEsSUFDekI7QUFFQSxRQUFJLENBQUNvQyxLQUFLbkMsWUFBWTtBQUNwQmdGLGdCQUFVaEYsYUFBYTtBQUFBLElBQ3pCO0FBRUEsUUFBSSxDQUFDbUMsS0FBS2xDLGFBQWE7QUFDckIrRSxnQkFBVS9FLGNBQWM7QUFBQSxJQUMxQixXQUFXaUYsTUFBTS9DLEtBQUtsQyxXQUFXLEtBQUtrQyxLQUFLbEMsZUFBZSxHQUFHO0FBQzNEK0UsZ0JBQVUvRSxjQUFjO0FBQUEsSUFDMUI7QUFFQSxRQUFJLENBQUNrQyxLQUFLakMsZUFBZTtBQUN2QjhFLGdCQUFVOUUsZ0JBQWdCO0FBQUEsSUFDNUIsV0FDRSxDQUFDaUMsS0FBS2pDLGlCQUNOZ0YsTUFBTS9DLEtBQUtqQyxhQUFhLEtBQ3hCaUMsS0FBS2pDLGlCQUFpQixHQUN0QjtBQUNBOEUsZ0JBQVU5RSxnQkFDUjtBQUFBLElBQ0o7QUFFQSxRQUFJLENBQUNpQyxLQUFLaEMsZUFBZTtBQUN2QjZFLGdCQUFVN0UsZ0JBQWdCO0FBQUEsSUFDNUIsV0FDRSxDQUFDZ0MsS0FBS2hDLGlCQUNOK0UsTUFBTS9DLEtBQUtoQyxhQUFhLEtBQ3hCZ0MsS0FBS2hDLGlCQUFpQixHQUN0QjtBQUNBNkUsZ0JBQVU3RSxnQkFDUjtBQUFBLElBQ0o7QUFFQSxRQUFJLENBQUNnQyxLQUFLbkIsc0JBQXNCO0FBQzlCZ0UsZ0JBQVVoRSx1QkFBdUI7QUFBQSxJQUNuQztBQUVBLFFBQUksQ0FBQ21CLEtBQUt0QixxQkFBcUI7QUFDN0JtRSxnQkFBVW5FLHNCQUFzQjtBQUFBLElBQ2xDO0FBRUEsUUFBSSxDQUFDc0IsS0FBS3JCLG9CQUFvQjtBQUM1QmtFLGdCQUFVbEUscUJBQXFCO0FBQUEsSUFDakM7QUFFQSxRQUFJLENBQUNxQixLQUFLcEIsbUJBQW1CO0FBQzNCaUUsZ0JBQVVqRSxvQkFBb0I7QUFBQSxJQUNoQztBQUVBLFFBQUksQ0FBQ29CLEtBQUsvQixnQkFBZ0I7QUFDeEI0RSxnQkFBVTVFLGlCQUFpQjtBQUFBLElBQzdCLFdBQ0UsQ0FBQytCLEtBQUsvQixrQkFDTjhFLE1BQU0vQyxLQUFLL0IsY0FBYyxLQUN6QitCLEtBQUsvQixrQkFBa0IsR0FDdkI7QUFDQTRFLGdCQUFVNUUsaUJBQ1I7QUFBQSxJQUNKO0FBRUEsUUFBSSxDQUFDK0IsS0FBS3ZCLFNBQVM7QUFDakJvRSxnQkFBVXBFLFVBQVU7QUFBQSxJQUN0QixXQUFXLENBQUN1QixLQUFLdkIsV0FBV3NFLE1BQU0vQyxLQUFLdkIsT0FBTyxLQUFLdUIsS0FBS3ZCLFVBQVUsR0FBRztBQUNuRW9FLGdCQUFVcEUsVUFDUjtBQUFBLElBQ0o7QUFFQSxRQUFJLENBQUN1QixLQUFLOUIsWUFBWTtBQUNwQjJFLGdCQUFVM0UsYUFBYTtBQUFBLElBQ3pCO0FBRUEsUUFBSSxDQUFDOEIsS0FBS2hCLGNBQWM7QUFDdEI2RCxnQkFBVTdELGVBQWU7QUFBQSxJQUMzQjtBQUVBLFFBQUksQ0FBQ2dCLEtBQUtqQix5QkFBeUI7QUFDakM4RCxnQkFBVTlELDBCQUNSO0FBQUEsSUFDSjtBQUVBLFFBQUksQ0FBQ2lCLEtBQUtsQix5QkFBeUI7QUFDakMrRCxnQkFBVS9ELDBCQUEwQjtBQUFBLElBQ3RDO0FBRUEsUUFBSXBCLFNBQVNTLFlBQVksQ0FBQzZCLEtBQUs3QixVQUFVO0FBQ3ZDMEUsZ0JBQVUxRSxXQUFXO0FBQUEsSUFDdkIsV0FDRVQsU0FBU1MsWUFDVCxJQUFJNkUsS0FBS2hELEtBQUs3QixRQUFRLElBQUksSUFBSTZFLEtBQUtoRCxLQUFLOUIsVUFBVSxHQUNsRDtBQUNBMkUsZ0JBQVUxRSxXQUFXO0FBQUEsSUFDdkI7QUFFQSxRQUFJLENBQUM2QixLQUFLNUIsYUFBYTtBQUNyQnlFLGdCQUFVekUsY0FBYztBQUFBLElBQzFCLFdBQ0UsQ0FBQzRCLEtBQUs1QixlQUNOMkUsTUFBTS9DLEtBQUs1QixXQUFXLEtBQ3RCNEIsS0FBSzVCLGVBQWUsR0FDcEI7QUFDQXlFLGdCQUFVekUsY0FDUjtBQUFBLElBQ0o7QUFFQSxRQUFJLENBQUM0QixLQUFLM0IsYUFBYTtBQUNyQndFLGdCQUFVeEUsY0FBYztBQUFBLElBQzFCLFdBQ0UsQ0FBQzJCLEtBQUszQixlQUNOMEUsTUFBTS9DLEtBQUszQixXQUFXLEtBQ3RCMkIsS0FBSzNCLGVBQWUsR0FDcEI7QUFDQXdFLGdCQUFVeEUsY0FDUjtBQUFBLElBQ0osV0FBVzRFLFdBQVdqRCxLQUFLM0IsV0FBVyxJQUFJNEUsV0FBV2pELEtBQUs1QixXQUFXLEdBQUc7QUFDdEV5RSxnQkFBVXhFLGNBQ1I7QUFBQSxJQUNKO0FBRUFjLGNBQVUwRCxTQUFTO0FBQ25CLFdBQU9LLE9BQU9DLEtBQUtOLFNBQVMsRUFBRU8sV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTUMsZUFBZSxPQUFPbkcsTUFBTTtBQUNoQ0EsTUFBRW9HLGVBQWU7QUFFakIsVUFBTUMsVUFBVVgsYUFBYSxVQUFVO0FBRXZDLFFBQUk7QUFDRixVQUFJVyxTQUFTO0FBQ1gsY0FBTTFELFdBQVcsTUFBTXhGLElBQUltSixLQUFLLG9CQUFvQjlGLFVBQVU7QUFBQSxVQUM1RCtGLFNBQVM7QUFBQSxZQUNQLGdCQUFnQjtBQUFBLFVBQ2xCO0FBQUEsUUFDRixDQUFDO0FBRUQzRyx5QkFBaUIsQ0FBQzRDLFNBQVNBLE9BQU8sQ0FBQztBQUVuQ3BDLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBRUQ3QixxQkFBYSxLQUFLO0FBRWxCK0Isb0JBQVk7QUFBQSxVQUNWQyxZQUFZO0FBQUEsVUFDWkMsWUFBWTtBQUFBLFVBQ1pDLGFBQWE7QUFBQSxVQUNiQyxlQUFlO0FBQUEsVUFDZkMsZUFBZTtBQUFBLFVBQ2ZDLGdCQUFnQjtBQUFBLFVBQ2hCTSxrQkFBa0I7QUFBQSxVQUNsQkwsWUFBWTtBQUFBLFVBQ1pDLFVBQVU7QUFBQSxVQUNWQyxhQUFhO0FBQUEsVUFDYkMsYUFBYTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaRSxZQUFZO0FBQUEsVUFDWkssc0JBQXNCO0FBQUEsVUFDdEJILHFCQUFxQjtBQUFBLFVBQ3JCSSx5QkFBeUI7QUFBQSxVQUN6QkMseUJBQXlCO0FBQUEsVUFDekJDLGNBQWM7QUFBQSxRQUNoQixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0xtQixnQkFBUUMsSUFBSWxCLE1BQU07QUFBQSxNQUNwQjtBQUFBLElBQ0YsU0FBU2dCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx1QkFBdUJBLEtBQUs7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNd0QsaUJBQWlCckksT0FBT21GO0FBQUFBLElBQU8sQ0FBQ0MsVUFDcENBLE1BQU03QyxZQUFZK0MsWUFBWSxFQUFFZ0QsU0FBU2xJLFlBQVlrRixZQUFZLENBQUM7QUFBQSxFQUNwRTtBQUVBLFFBQU1zQix3QkFBd0IsT0FBT0csWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTXZDLFdBQVcsTUFBTXhGLElBQUl5RixJQUFJLG9CQUFvQnNDLE9BQU8sRUFBRTtBQUM1RGhHLHNCQUFnQnlELFNBQVNHLElBQUk7QUFDN0JsRSx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVNvRSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTThCLHdCQUF3QixPQUFPSSxZQUFZO0FBQy9DLFVBQU13QixVQUFVLG9DQUFvQ3hCLE9BQU87QUFDM0R6QyxXQUFPNEMsS0FBS3FCLFNBQVMsUUFBUTtBQUFBLEVBQy9CO0FBRUEsUUFBTUMsbUJBQW1CQSxDQUFDQyxPQUFPM0csVUFBVTtBQUN6Q1EsZ0JBQVksQ0FBQ2dGLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNtQixLQUFLLEdBQUczRztBQUFBQSxJQUNYLEVBQUU7QUFFRmdDLGNBQVUsQ0FBQzRFLGdCQUFnQjtBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsS0FBSyxHQUFHO0FBQUEsSUFDWCxFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1FLHdCQUF3QkEsQ0FBQ0YsT0FBTzNHLFVBQVU7QUFDOUNvQyxzQkFBa0IsQ0FBQ29ELGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUNtQixLQUFLLEdBQUczRztBQUFBQSxJQUNYLEVBQUU7QUFFRmdDLGNBQVUsRUFBRSxHQUFHRCxRQUFRLENBQUM0RSxLQUFLLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFFQSxRQUFNRyxvQkFBb0JBLENBQUMvRyxNQUFNO0FBQy9CLFVBQU0sRUFBRStELE1BQU05RCxNQUFNLElBQUlELEVBQUVFO0FBRTFCbUMsc0JBQWtCLENBQUNvRCxjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDMUIsSUFBSSxHQUFHOUQ7QUFBQUEsSUFDVixFQUFFO0FBRUZnQyxjQUFVLEVBQUUsR0FBR0QsUUFBUSxDQUFDK0IsSUFBSSxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQ3JDO0FBRUEsUUFBTWlELG9CQUFvQixPQUFPaEgsTUFBTTtBQUNyQyxRQUNFZixnQkFDQVEsa0JBQWtCd0gsU0FBUyxFQUFFckIsS0FBSyxNQUFNM0csYUFBYXlCLFlBQ3JEO0FBQ0EsVUFBSTtBQUNGLGNBQU12RCxJQUFJK0osT0FBTyxvQkFBb0JqSSxhQUFhNEUsR0FBRyxFQUFFO0FBRXZEekQsdUJBQWU7QUFBQSxVQUNiRSxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFVBQ05GLFlBQVk7QUFBQSxRQUNkLENBQUM7QUFFRFQseUJBQWlCLENBQUM0QyxTQUFTQSxPQUFPLENBQUM7QUFDbkM1RCwyQkFBbUIsS0FBSztBQUN4Qk0sd0JBQWdCLElBQUk7QUFBQSxNQUN0QixTQUFTOEQsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxNQUM5QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTW1FLGVBQWUsT0FBT25ILE1BQU07QUFDaENBLE1BQUVvRyxlQUFlO0FBRWpCLFVBQU1DLFVBQVVYLGFBQWE7QUFFN0IsUUFBSTtBQUNGLFVBQUlXLFNBQVM7QUFDWCxjQUFNbEosSUFBSWlLO0FBQUFBLFVBQ1Isb0JBQW9CakksbUJBQW1CMEUsR0FBRztBQUFBLFVBQzFDekI7QUFBQUEsUUFDRjtBQUVBdEQsMkJBQW1CLEtBQUs7QUFFeEJzQix1QkFBZTtBQUFBLFVBQ2JFLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsVUFDTkYsWUFBWTtBQUFBLFFBQ2QsQ0FBQztBQUVEVCx5QkFBaUIsQ0FBQzRDLFNBQVNBLE9BQU8sQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRixTQUFTUSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTXFFLFVBQVU7QUFBQSxJQUNkLEVBQUV6QyxLQUFLLE1BQU0wQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFMUMsS0FBSyxjQUFjMEMsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRTFDLEtBQUssUUFBUTBDLFFBQVEsYUFBYTtBQUFBLElBQ3BDLEVBQUUxQyxLQUFLLFFBQVEwQyxRQUFRLGFBQWE7QUFBQSxJQUNwQyxFQUFFMUMsS0FBSyxTQUFTMEMsUUFBUSxjQUFjO0FBQUEsSUFDdEMsRUFBRTFDLEtBQUssV0FBVzBDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDMUMsRUFBRTFDLEtBQUssZUFBZTBDLFFBQVEsb0JBQW9CO0FBQUEsSUFDbEQsRUFBRTFDLEtBQUssY0FBYzBDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUUxQyxLQUFLLFlBQVkwQyxRQUFRLFdBQVc7QUFBQSxJQUN0QyxFQUFFMUMsS0FBSyxxQkFBcUIwQyxRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUUxQyxLQUFLLDJCQUEyQjBDLFFBQVEsMEJBQTBCO0FBQUEsSUFDcEUsRUFBRTFDLEtBQUssc0JBQXNCMEMsUUFBUSxxQkFBcUI7QUFBQSxJQUMxRCxFQUFFMUMsS0FBSyx1QkFBdUIwQyxRQUFRLHNCQUFzQjtBQUFBLElBQzVELEVBQUUxQyxLQUFLLHdCQUF3QjBDLFFBQVEsdUJBQXVCO0FBQUEsSUFDOUQsRUFBRTFDLEtBQUssYUFBYTBDLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUUxQyxLQUFLLFVBQVUwQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFNBQ0UsbUNBQ0UsaUNBQUMsU0FDQztBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxZQUFZO0FBQUEsUUFDWjtBQUFBO0FBQUEsTUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFMkQ7QUFBQSxJQUczRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTW5ILFlBQVlJO0FBQUFBLFFBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFFBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDb0MsVUFBVSxFQUFFLEdBQUdBLE1BQU1uQyxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsTUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxJQUdILHVCQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxJQUNiLGlDQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSwwQkFBeUIsc0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUU1Q1IsY0FBYyxZQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU07QUFDYjRDLHFCQUFPNEMsS0FBSyxrQkFBa0IsUUFBUTtBQUFBLFlBQ3hDO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFBbUc7QUFBQTtBQUFBLFVBSi9HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU12RixhQUFhLFFBQVE7QUFBQSxZQUNwQyxXQUFXLDBFQUEwRUQsY0FBYyxXQUM3RixrQ0FDQSxzREFBc0Q7QUFBQSxZQUN2RDtBQUFBO0FBQUEsVUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTUMsYUFBYSxRQUFRO0FBQUEsWUFDcEMsV0FBVywwRUFBMEVELGNBQWMsV0FDN0Ysa0NBQ0Esc0RBQXNEO0FBQUEsWUFDdkQ7QUFBQTtBQUFBLFVBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0E7QUFBQSxXQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBO0FBQUEsTUFFQ3hCLFlBQVk2SCxTQUFTLEtBQUssQ0FBQzNHLFlBQzFCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixlQUFldUY7QUFBQUEsVUFDZixNQUFNcEgsYUFBYVcsYUFBYWdCLFVBQVU7QUFBQSxVQUMxQztBQUFBLFVBQ0EsaUJBQ0VRLGNBQWMsV0FBVyxrQkFBa0I7QUFBQSxVQUU3QyxrQkFDRUEsY0FBYyxXQUNWLHNCQUNBO0FBQUE7QUFBQSxRQVhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVlHLElBR0g7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxTQUFTeEIsWUFBWTZILFVBQVU7QUFBQSxVQUMvQixNQUNFckcsY0FBYyxXQUNWLHNCQUNBO0FBQUE7QUFBQSxRQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9HO0FBQUEsTUFJTCx1QkFBQyxTQUFJLFdBQVUseUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRjtBQUFBLFNBckV2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0VBLEtBdkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3RUE7QUFBQSxJQUVBLHVCQUFDLFNBQU0sV0FBV3BCLFdBQVcsU0FBUyxNQUFNQyxhQUFhLEtBQUssR0FDNUQsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHdDQUF1Qyx5QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsVUFBVXlIO0FBQUFBLFVBQ1YsWUFBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBTztBQUFBO0FBQUEsb0JBRUosdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBO0FBQUE7QUFBQSxnQkFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBTzNGLFNBQVNFO0FBQUFBLGtCQUNoQixVQUFVOEU7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDNUgsVUFBVTJKLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNko7QUFBQSxjQUc1SnZGLE9BQU90QixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnNCLGlCQUFPdEIsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVQLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUM4RyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmpFLFlBQVksRUFDWmdELFNBQVNlLE1BQU0vRCxZQUFZLENBQUM7QUFBQSxrQkFFakMsT0FBT2pELFVBQVVHLGNBQWNnSDtBQUFBQSxrQkFDL0IsVUFBVSxDQUFDMUgsVUFDVDBHLGlCQUFpQixjQUFjMUcsS0FBSztBQUFBLGtCQUdyQyxXQUFDLFlBQVksUUFBUSxFQUFFMEQ7QUFBQUEsb0JBQUksQ0FBQ2lFLFVBQzNCO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBRUMsT0FBT0EsTUFBTW5FLFlBQVk7QUFBQSx3QkFFeEJtRTtBQUFBQTtBQUFBQSxzQkFISUE7QUFBQUEsc0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkF2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBd0JBO0FBQUEsY0FFQzVGLE9BQU9yQixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnFCLGlCQUFPckIsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVU7QUFBQTtBQUFBLHNCQUVHO0FBQUEsc0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUNMLGNBQWMsQ0FBQzZHLE9BQU9DLFdBQVc7QUFDL0IsNEJBQU1JLE9BQU8sR0FBR0osT0FBT0MsUUFBUTtBQUMvQiw2QkFBT0csS0FDSnBFLFlBQVksRUFDWmdELFNBQVNlLE1BQU0vRCxZQUFZLENBQUM7QUFBQSxvQkFDakM7QUFBQSxvQkFDQSxPQUNFakQsVUFBVW1CLHdCQUF3QmdHO0FBQUFBLG9CQUVwQyxVQUFVLENBQUMxSCxVQUNUMEc7QUFBQUEsc0JBQ0U7QUFBQSxzQkFDQTFHO0FBQUFBLG9CQUNGO0FBQUEsb0JBR0E2SCxpQkFBTUMsUUFBUTdGLFNBQVMsSUFBSUEsWUFBWSxJQUFJeUI7QUFBQUEsc0JBQzNDLENBQUNaLGFBQ0M7QUFBQSx3QkFBQyxPQUFPO0FBQUEsd0JBQVA7QUFBQSwwQkFFQyxPQUFPQSxVQUFVYztBQUFBQSwwQkFFaEJkO0FBQUFBLHNDQUFVZ0I7QUFBQUEsNEJBQUs7QUFBQSw0QkFBSWhCLFVBQVVpRjtBQUFBQTtBQUFBQTtBQUFBQSx3QkFIekJqRixVQUFVYztBQUFBQSx3QkFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUVKO0FBQUE7QUFBQSxrQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWdDQTtBQUFBLGdCQUVDN0IsT0FBT0wsd0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWSyxpQkFBT0wsd0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQTlDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdEQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFVTtBQUFBLHNCQUN4Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUE7QUFBQTtBQUFBLGtCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9uQixTQUFTb0I7QUFBQUEsb0JBQ2hCLFVBQVU0RDtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxnREFBZ0Q1SCxVQUFVMkosTUFBTTtBQUFBO0FBQUEsa0JBUjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRd0s7QUFBQSxnQkFHdkt2RixPQUFPSiwyQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZJLGlCQUFPSiwyQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiN0Q7QUFBQUEsa0JBQ0N5QyxTQUFTb0IsMkJBQTJCO0FBQUEsZ0JBQ3RDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQStCQTtBQUFBLGlCQWxGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1GQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFRix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUE7QUFBQTtBQUFBLGtCQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9wQixTQUFTSTtBQUFBQSxvQkFDaEIsVUFBVTRFO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLGdEQUFnRDVILFVBQVUySixNQUFNO0FBQUE7QUFBQSxrQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVF3SztBQUFBLGdCQUd2S3ZGLE9BQU9wQixlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVm9CLGlCQUFPcEIsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiN0MsOEJBQW9CeUMsU0FBU0ksZUFBZSxDQUFDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0QkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRVc7QUFBQSxzQkFDekIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBO0FBQUE7QUFBQSxrQkFMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPSixTQUFTSztBQUFBQSxvQkFDaEIsVUFBVTJFO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLGdEQUFnRDVILFVBQVUySixNQUFNO0FBQUE7QUFBQSxrQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVF3SztBQUFBLGdCQUd2S3ZGLE9BQU9uQixpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZtQixpQkFBT25CLGlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHRix1QkFBQyxVQUFLLFdBQVUsb0NBQ2I5Qyw4QkFBb0J5QyxTQUFTSyxpQkFBaUIsQ0FBQyxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNkJBO0FBQUEsaUJBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkRBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVBLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT0wsU0FBU007QUFBQUEsb0JBQ2hCLFVBQVUwRTtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxnREFBZ0Q1SCxVQUFVMkosTUFBTTtBQUFBO0FBQUEsa0JBUjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRd0s7QUFBQSxnQkFHdkt2RixPQUFPbEIsaUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWa0IsaUJBQU9sQixpQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiL0MsOEJBQW9CeUMsU0FBU00saUJBQWlCLENBQUMsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRCQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFQztBQUFBLHNCQUNmLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT04sU0FBU087QUFBQUEsb0JBQ2hCLFVBQVV5RTtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxnREFBZ0Q1SCxVQUFVMkosTUFBTTtBQUFBO0FBQUEsa0JBUjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRd0s7QUFBQSxnQkFHdkt2RixPQUFPakIsa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaUIsaUJBQU9qQixrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiaEQsOEJBQW9CeUMsU0FBU08sa0JBQWtCLENBQUMsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTZCQTtBQUFBLGlCQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZEQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFSTtBQUFBLHNCQUNsQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUE7QUFBQTtBQUFBLGtCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9QLFNBQVNrQjtBQUFBQSxvQkFDaEIsVUFBVThEO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLGdEQUFnRDVILFVBQVUySixNQUFNO0FBQUE7QUFBQSxrQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVF3SztBQUFBLGdCQUd2S3ZGLE9BQU9OLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVk0saUJBQU9OLHFCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHRix1QkFBQyxVQUFLLFdBQVUsb0NBQ2IzRDtBQUFBQSxrQkFDQ3lDLFNBQVNrQixxQkFBcUI7QUFBQSxnQkFDaEMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK0JBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVLO0FBQUEsc0JBQ25CLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT2xCLFNBQVNpQjtBQUFBQSxvQkFDaEIsVUFBVStEO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLGdEQUFnRDVILFVBQVUySixNQUFNO0FBQUE7QUFBQSxrQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVF3SztBQUFBLGdCQUd2S3ZGLE9BQU9QLHNCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVk8saUJBQU9QLHNCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHRix1QkFBQyxVQUFLLFdBQVUsb0NBQ2IxRDtBQUFBQSxrQkFDQ3lDLFNBQVNpQixzQkFBc0I7QUFBQSxnQkFDakMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK0JBO0FBQUEsaUJBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0VBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWlCO0FBQUE7QUFBQSxzQkFFTDtBQUFBLHNCQUNwQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUE7QUFBQTtBQUFBLGtCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9qQixTQUFTZ0I7QUFBQUEsb0JBQ2hCLFVBQVVnRTtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUM1SCxVQUFVMkosTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNko7QUFBQSxnQkFHNUp2RixPQUFPUix1QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZRLGlCQUFPUix1QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiekQ7QUFBQUEsa0JBQ0N5QyxTQUFTZ0IsdUJBQXVCO0FBQUEsZ0JBQ2xDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQStCQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFRztBQUFBLHNCQUNqQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUE7QUFBQTtBQUFBLGtCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9oQixTQUFTZTtBQUFBQSxvQkFDaEIsVUFBVWlFO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLGdEQUFnRDVILFVBQVUySixNQUFNO0FBQUE7QUFBQSxrQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVF3SztBQUFBLGdCQUd2S3ZGLE9BQU9ULFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWUyxpQkFBT1QsV0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNieEQsOEJBQW9CeUMsU0FBU2UsV0FBVyxDQUFDLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2QkE7QUFBQSxpQkEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnRUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRUgsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBO0FBQUE7QUFBQSxrQkFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPZixTQUFTUTtBQUFBQSxvQkFDaEIsVUFBVXdFO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQzVILFVBQVUySixNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2SjtBQUFBLGdCQUc1SnZGLE9BQU9oQixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmdCLGlCQUFPaEIsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBd0JBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLGtCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9SLFNBQVNTO0FBQUFBLG9CQUNoQixVQUFVdUU7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDNUgsVUFBVTJKLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZKO0FBQUEsZ0JBRzVKdkYsT0FBT2YsWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZlLGlCQUFPZixZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3QkE7QUFBQSxpQkFuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvREE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRUYsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBO0FBQUE7QUFBQSxrQkFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPVCxTQUFTVTtBQUFBQSxvQkFDaEIsVUFBVXNFO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLGdEQUFnRDVILFVBQVUySixNQUFNO0FBQUE7QUFBQSxrQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVF3SztBQUFBLGdCQUd2S3ZGLE9BQU9kLGVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWYyxpQkFBT2QsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNibkQsOEJBQW9CeUMsU0FBU1UsZUFBZSxDQUFDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0QkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRUYsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBO0FBQUE7QUFBQSxrQkFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPVixTQUFTVztBQUFBQSxvQkFDaEIsVUFBVXFFO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLGdEQUFnRDVILFVBQVUySixNQUFNO0FBQUE7QUFBQSxrQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVF3SztBQUFBLGdCQUd2S3ZGLE9BQU9iLGVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWYSxpQkFBT2IsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNicEQsOEJBQW9CeUMsU0FBU1csZUFBZSxDQUFDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0QkE7QUFBQSxpQkEzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0REE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyxrQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT1gsU0FBU1k7QUFBQUEsb0JBQ2hCLFVBQVVvRTtBQUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osV0FBVyxnREFBZ0Q1SCxVQUFVMkosTUFBTTtBQUFBO0FBQUEsa0JBTjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNd0s7QUFBQSxnQkFHeEssdUJBQUMsVUFBSyxXQUFVLG9DQUNieEosOEJBQW9CeUMsU0FBU1ksY0FBYyxDQUFDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyxvQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT1osU0FBU2E7QUFBQUEsb0JBQ2hCLFVBQVVtRTtBQUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osV0FBVyxnREFBZ0Q1SCxVQUFVMkosTUFBTTtBQUFBO0FBQUEsa0JBTjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNd0s7QUFBQSxnQkFHeEssdUJBQUMsVUFBSyxXQUFVLG9DQUNieEo7QUFBQUEsa0JBQ0N5QyxTQUFTYSxvQkFBb0I7QUFBQSxnQkFDL0IsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MscUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9iLFNBQVNjO0FBQUFBLG9CQUNoQixVQUFVa0U7QUFBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLFdBQVcscUNBQXFDNUgsVUFBVTJKLE1BQU07QUFBQTtBQUFBLGtCQU5sRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTTZKO0FBQUEsZ0JBRzdKLHVCQUFDLFVBQUssV0FBVSxvQ0FDYnhKLDhCQUFvQnlDLFNBQVNjLGNBQWMsQ0FBQyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsaUJBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkRBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUFpTDtBQUFBO0FBQUEsY0FGN0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUE7QUFBQTtBQUFBLFFBemxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUEwbEJBO0FBQUEsU0EvbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnbUJBLEtBam1CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa21CQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVd6QztBQUFBQSxRQUNYLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxRQUV2QyxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsVUFBVXFJO0FBQUFBLGNBQ1YsWUFBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBTztBQUFBO0FBQUEsd0JBRUosdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBO0FBQUE7QUFBQSxvQkFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxPQUFPL0UsZUFBZTFCO0FBQUFBLHNCQUN0QixVQUFVcUc7QUFBQUEsc0JBQ1YsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUNBQXFDbkosVUFBVTJKLE1BQU07QUFBQTtBQUFBLG9CQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUTZKO0FBQUEsa0JBRzVKdkYsT0FBT3RCLGNBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWc0IsaUJBQU90QixjQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF3QkE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVU7QUFBQTtBQUFBLHdCQUVQLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0M7QUFBQTtBQUFBO0FBQUEsb0JBSjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osdUJBQXVCO0FBQUEsc0JBQ3ZCO0FBQUEsc0JBQ0EsTUFBSztBQUFBLHNCQUNMLGNBQWMsQ0FBQzhHLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKakUsWUFBWSxFQUNaZ0QsU0FBU2UsTUFBTS9ELFlBQVksQ0FBQztBQUFBLHNCQUVqQyxPQUFPckIsZ0JBQWdCekIsY0FBY2dIO0FBQUFBLHNCQUNyQyxVQUFVLENBQUMxSCxVQUNUNkcsc0JBQXNCLGNBQWM3RyxLQUFLO0FBQUEsc0JBRzFDLFdBQUMsWUFBWSxVQUFVLE9BQU8sRUFBRTBEO0FBQUFBLHdCQUFJLENBQUNpRSxVQUNwQztBQUFBLDBCQUFDLE9BQU87QUFBQSwwQkFBUDtBQUFBLDRCQUVDLE9BQU9BLE1BQU1uRSxZQUFZO0FBQUEsNEJBRXhCbUU7QUFBQUE7QUFBQUEsMEJBSElBO0FBQUFBLDBCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBS0E7QUFBQSxzQkFDRDtBQUFBO0FBQUEsb0JBdkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkF3QkE7QUFBQSxrQkFFQzVGLE9BQU9yQixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnFCLGlCQUFPckIsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUNBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFVO0FBQUE7QUFBQSwwQkFFRztBQUFBLDBCQUNyQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUE7QUFBQTtBQUFBLHNCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTUE7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLHVCQUF1QjtBQUFBLHdCQUN2QjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUM2RyxPQUFPQyxXQUFXO0FBQy9CLGdDQUFNSSxPQUFPLEdBQUdKLE9BQU9DLFFBQVE7QUFDL0IsaUNBQU9HLEtBQ0pwRSxZQUFZLEVBQ1pnRCxTQUFTZSxNQUFNL0QsWUFBWSxDQUFDO0FBQUEsd0JBQ2pDO0FBQUEsd0JBQ0EsT0FDRXJCLGdCQUFnQlQsd0JBQ2hCZ0c7QUFBQUEsd0JBRUYsVUFBVSxDQUFDMUgsVUFDVDZHO0FBQUFBLDBCQUNFO0FBQUEsMEJBQ0E3RztBQUFBQSx3QkFDRjtBQUFBLHdCQUdBNkgsaUJBQU1DLFFBQVE3RixTQUFTLElBQUlBLFlBQVksSUFBSXlCO0FBQUFBLDBCQUMzQyxDQUFDWixhQUNDO0FBQUEsNEJBQUMsT0FBTztBQUFBLDRCQUFQO0FBQUEsOEJBRUMsT0FBT0EsVUFBVWM7QUFBQUEsOEJBRWhCZDtBQUFBQSwwQ0FBVWdCO0FBQUFBLGdDQUFLO0FBQUEsZ0NBQUloQixVQUFVaUY7QUFBQUE7QUFBQUE7QUFBQUEsNEJBSHpCakYsVUFBVWM7QUFBQUEsNEJBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBS0E7QUFBQSx3QkFFSjtBQUFBO0FBQUEsc0JBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFpQ0E7QUFBQSxvQkFFQzdCLE9BQU9MLHdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVkssaUJBQU9MLHdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkEvQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpREE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLDBCQUVVO0FBQUEsMEJBQ3hCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBZ0M7QUFBQTtBQUFBO0FBQUEsc0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT1MsZUFBZVI7QUFBQUEsd0JBQ3RCLFVBQVVtRjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxnREFBZ0RuSixVQUFVMkosTUFBTTtBQUFBO0FBQUEsc0JBUjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRd0s7QUFBQSxvQkFHdkt2RixPQUFPSiwyQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZJLGlCQUFPSiwyQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiN0Q7QUFBQUEsc0JBQ0NxRSxlQUFlUiwyQkFBMkI7QUFBQSxvQkFDNUMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0JBO0FBQUEscUJBbkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0ZBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFNO0FBQUE7QUFBQSwwQkFFRix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUE7QUFBQTtBQUFBLHNCQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9RLGVBQWV4QjtBQUFBQSx3QkFDdEIsVUFBVW1HO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFXLGdEQUFnRG5KLFVBQVUySixNQUFNO0FBQUE7QUFBQSxzQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVF3SztBQUFBLG9CQUd2S3ZGLE9BQU9wQixlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVm9CLGlCQUFPcEIsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiN0M7QUFBQUEsc0JBQ0NxRSxlQUFleEIsZUFBZTtBQUFBLG9CQUNoQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE4QkE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLDBCQUVXO0FBQUEsMEJBQ3pCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBZ0M7QUFBQTtBQUFBO0FBQUEsc0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3dCLGVBQWV2QjtBQUFBQSx3QkFDdEIsVUFBVWtHO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFXLGdEQUFnRG5KLFVBQVUySixNQUFNO0FBQUE7QUFBQSxzQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVF3SztBQUFBLG9CQUd2S3ZGLE9BQU9uQixpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZtQixpQkFBT25CLGlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFHRix1QkFBQyxVQUFLLFdBQVUsb0NBQ2I5QztBQUFBQSxzQkFDQ3FFLGVBQWV2QixpQkFBaUI7QUFBQSxvQkFDbEMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0JBO0FBQUEscUJBaEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFNO0FBQUE7QUFBQSwwQkFFQSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUE7QUFBQTtBQUFBLHNCQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU91QixlQUFldEI7QUFBQUEsd0JBQ3RCLFVBQVVpRztBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxnREFBZ0RuSixVQUFVMkosTUFBTTtBQUFBO0FBQUEsc0JBUjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRd0s7QUFBQSxvQkFHdkt2RixPQUFPbEIsaUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWa0IsaUJBQU9sQixpQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiL0M7QUFBQUEsc0JBQ0NxRSxlQUFldEIsaUJBQWlCO0FBQUEsb0JBQ2xDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLHVCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQThCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBTTtBQUFBO0FBQUEsMEJBRUM7QUFBQSwwQkFDZix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUE7QUFBQTtBQUFBLHNCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTUE7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9zQixlQUFlckI7QUFBQUEsd0JBQ3RCLFVBQVVnRztBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxnREFBZ0RuSixVQUFVMkosTUFBTTtBQUFBO0FBQUEsc0JBUjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRd0s7QUFBQSxvQkFHdkt2RixPQUFPakIsa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaUIsaUJBQU9qQixrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiaEQ7QUFBQUEsc0JBQ0NxRSxlQUFlckIsa0JBQWtCO0FBQUEsb0JBQ25DLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLHVCQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQStCQTtBQUFBLHFCQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlFQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBTTtBQUFBO0FBQUEsMEJBRUk7QUFBQSwwQkFDbEIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFnQztBQUFBO0FBQUE7QUFBQSxzQkFMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1BO0FBQUEsb0JBRUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPcUIsZUFBZVY7QUFBQUEsd0JBQ3RCLFVBQVVxRjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxnREFBZ0RuSixVQUFVMkosTUFBTTtBQUFBO0FBQUEsc0JBUjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRd0s7QUFBQSxvQkFHdkt2RixPQUFPTixxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZNLGlCQUFPTixxQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiM0Q7QUFBQUEsc0JBQ0NxRSxlQUFlVixxQkFBcUI7QUFBQSxvQkFDdEMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0JBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFNO0FBQUE7QUFBQSwwQkFFSztBQUFBLDBCQUNuQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUE7QUFBQTtBQUFBLHNCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTUE7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9VLGVBQWVYO0FBQUFBLHdCQUN0QixVQUFVc0Y7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVcsZ0RBQWdEbkosVUFBVTJKLE1BQU07QUFBQTtBQUFBLHNCQVI3RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUXdLO0FBQUEsb0JBR3ZLdkYsT0FBT1Asc0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWTyxpQkFBT1Asc0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUdGLHVCQUFDLFVBQUssV0FBVSxvQ0FDYjFEO0FBQUFBLHNCQUNDcUUsZUFBZVgsc0JBQXNCO0FBQUEsb0JBQ3ZDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLHVCQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQStCQTtBQUFBLHFCQWpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtFQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBaUI7QUFBQTtBQUFBLDBCQUVMO0FBQUEsMEJBQ3BCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBZ0M7QUFBQTtBQUFBO0FBQUEsc0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT1csZUFBZVo7QUFBQUEsd0JBQ3RCLFVBQVV1RjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxxQ0FBcUNuSixVQUFVMkosTUFBTTtBQUFBO0FBQUEsc0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRNko7QUFBQSxvQkFHNUp2RixPQUFPUix1QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZRLGlCQUFPUix1QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNiekQ7QUFBQUEsc0JBQ0NxRSxlQUFlWix1QkFBdUI7QUFBQSxvQkFDeEMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0JBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFPO0FBQUE7QUFBQSwwQkFFRTtBQUFBLDBCQUNqQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUE7QUFBQTtBQUFBLHNCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTUE7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9ZLGVBQWViO0FBQUFBLHdCQUN0QixVQUFVd0Y7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVcsZ0RBQWdEbkosVUFBVTJKLE1BQU07QUFBQTtBQUFBLHNCQVI3RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUXdLO0FBQUEsb0JBR3ZLdkYsT0FBT1QsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZTLGlCQUFPVCxXQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFHRix1QkFBQyxVQUFLLFdBQVUsb0NBQ2J4RDtBQUFBQSxzQkFDQ3FFLGVBQWViLFdBQVc7QUFBQSxvQkFDNUIsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0JBO0FBQUEscUJBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0VBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLCtDQUNiLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQzlDO0FBQUEsb0JBQ2hCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSw4Q0FDZjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBTTtBQUFBLDBCQUNOLFNBQ0VhLGdCQUFnQkUsb0JBQ2hCO0FBQUEsMEJBRUYsVUFBVXlFO0FBQUFBLDBCQUNWLFdBQVU7QUFBQTtBQUFBLHdCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFTdUU7QUFBQSxzQkFFdkUsdUJBQUMsVUFBSyxXQUFVLHlCQUF3Qix3QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZUE7QUFBQSxvQkFFQSx1QkFBQyxXQUFNLFdBQVUsOENBQ2Y7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU07QUFBQSwwQkFDTixTQUNFM0UsZ0JBQWdCRSxvQkFBb0I7QUFBQSwwQkFFdEMsVUFBVXlFO0FBQUFBLDBCQUNWLFdBQVU7QUFBQTtBQUFBLHdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFRdUU7QUFBQSxzQkFFdkUsdUJBQUMsVUFBSyxXQUFVLHlCQUF3QixxQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBY0E7QUFBQSx1QkFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQ0E7QUFBQSxrQkFFQy9FLE9BQU9NLG1CQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVk4saUJBQU9NLG1CQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkE1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4Q0EsS0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnREE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLDBCQUVILHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBZ0M7QUFBQTtBQUFBO0FBQUEsc0JBSjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT0YsZUFBZXBCO0FBQUFBLHdCQUN0QixVQUFVK0Y7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVcscUNBQXFDbkosVUFBVTJKLE1BQU07QUFBQTtBQUFBLHNCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUTZKO0FBQUEsb0JBRzVKdkYsT0FBT2hCLGNBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWZ0IsaUJBQU9oQixjQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF3QkE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLHNCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9vQixlQUFlbkI7QUFBQUEsd0JBQ3RCLFVBQVU4RjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxxQ0FBcUNuSixVQUFVMkosTUFBTTtBQUFBO0FBQUEsc0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRNko7QUFBQSxvQkFHNUp2RixPQUFPZixZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmUsaUJBQU9mLFlBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXdCQTtBQUFBLHFCQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW9EQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBTTtBQUFBO0FBQUEsMEJBRUE7QUFBQSwwQkFDZCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUE7QUFBQTtBQUFBLHNCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTUE7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9tQixlQUFlbEI7QUFBQUEsd0JBQ3RCLFVBQVU2RjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxnREFBZ0RuSixVQUFVMkosTUFBTTtBQUFBO0FBQUEsc0JBUjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRd0s7QUFBQSxvQkFHdkt2RixPQUFPZCxlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmMsaUJBQU9kLGVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUdGLHVCQUFDLFVBQUssV0FBVSxvQ0FDYm5EO0FBQUFBLHNCQUNDcUUsZUFBZWxCLGVBQWU7QUFBQSxvQkFDaEMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0JBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFNO0FBQUE7QUFBQSwwQkFFQTtBQUFBLDBCQUNkLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBZ0M7QUFBQTtBQUFBO0FBQUEsc0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT2tCLGVBQWVqQjtBQUFBQSx3QkFDdEIsVUFBVTRGO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFXLGdEQUFnRG5KLFVBQVUySixNQUFNO0FBQUE7QUFBQSxzQkFSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVF3SztBQUFBLG9CQUd2S3ZGLE9BQU9iLGVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWYSxpQkFBT2IsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBR0YsdUJBQUMsVUFBSyxXQUFVLG9DQUNicEQ7QUFBQUEsc0JBQ0NxRSxlQUFlakIsZUFBZTtBQUFBLG9CQUNoQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkErQkE7QUFBQSxxQkFqRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrRUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0Msa0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9pQixlQUFlaEI7QUFBQUEsd0JBQ3RCLFVBQVUyRjtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVyxxQ0FBcUNuSixVQUFVMkosTUFBTTtBQUFBO0FBQUEsc0JBTmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNNko7QUFBQSxvQkFHN0osdUJBQUMsVUFBSyxXQUFVLG9DQUNieEo7QUFBQUEsc0JBQ0NxRSxlQUFlaEIsY0FBYztBQUFBLG9CQUMvQixLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQkE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0Msb0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9nQixlQUFlZjtBQUFBQSx3QkFDdEIsVUFBVTBGO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFXLGdEQUFnRG5KLFVBQVUySixNQUFNO0FBQUE7QUFBQSxzQkFON0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU13SztBQUFBLG9CQUd4Syx1QkFBQyxVQUFLLFdBQVUsb0NBQ2J4SjtBQUFBQSxzQkFDQ3FFLGVBQWVmLG9CQUFvQjtBQUFBLG9CQUNyQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQkE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MscUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9lLGVBQWVkO0FBQUFBLHdCQUN0QixVQUFVeUY7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVcscUNBQXFDbkosVUFBVTJKLE1BQU07QUFBQTtBQUFBLHNCQU5sRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTTZKO0FBQUEsb0JBRzdKLHVCQUFDLFVBQUssV0FBVSxvQ0FDYnhKO0FBQUFBLHNCQUNDcUUsZUFBZWQsY0FBYztBQUFBLG9CQUMvQixLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQkE7QUFBQSxxQkE5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkErREE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxrQkFBa0IsQ0FBQyxHQUFHO0FBQUEsb0JBQ3RCLFdBQVU7QUFBQSxvQkFFVjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxRQUNFLHVCQUFDLFVBQUssV0FBVSx1Q0FBc0MsK0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFJRixpQ0FBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpREFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLG1EQUFDLFdBQU0sV0FBVSxnREFBK0MsdUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFFQTtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxXQUFVO0FBQUEsZ0NBQ1YsYUFBWTtBQUFBLGdDQUNaLHVCQUF1QjtBQUFBLGdDQUN2QjtBQUFBLGdDQUNBLE1BQUs7QUFBQSxnQ0FDTCxjQUFjLENBQUNrRyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmpFLFlBQVksRUFDWmdELFNBQVNlLE1BQU0vRCxZQUFZLENBQUM7QUFBQSxnQ0FFakMsT0FDRXJCLGdCQUFnQlAsMkJBQ2hCOEY7QUFBQUEsZ0NBRUYsVUFBVSxDQUFDMUgsVUFDVDZHO0FBQUFBLGtDQUNFO0FBQUEsa0NBQ0E3RztBQUFBQSxnQ0FDRjtBQUFBLGdDQUdELFdBQUMsVUFBVSxRQUFRLEVBQUUwRDtBQUFBQSxrQ0FBSSxDQUFDc0UsVUFDekI7QUFBQSxvQ0FBQyxPQUFPO0FBQUEsb0NBQVA7QUFBQSxzQ0FFQyxPQUFPQTtBQUFBQSxzQ0FFTkEsZ0JBQU1qRSxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUMzQmdFLE1BQU0vRCxNQUFNLENBQUMsRUFBRVQsWUFBWTtBQUFBO0FBQUEsb0NBSnhCd0U7QUFBQUEsb0NBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FNQTtBQUFBLGdDQUNEO0FBQUE7QUFBQSw4QkE5Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQStCQTtBQUFBLCtCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXFDQTtBQUFBLDBCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbURBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDRCQUVBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLFdBQVU7QUFBQSxnQ0FDVixhQUFZO0FBQUEsZ0NBQ1osdUJBQXVCO0FBQUEsZ0NBQ3ZCO0FBQUEsZ0NBQ0EsTUFBSztBQUFBLGdDQUNMLGNBQWMsQ0FBQ1QsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pqRSxZQUFZLEVBQ1pnRCxTQUFTZSxNQUFNL0QsWUFBWSxDQUFDO0FBQUEsZ0NBRWpDLE9BQ0VyQixnQkFBZ0JOLGdCQUFnQjZGO0FBQUFBLGdDQUVsQyxVQUFVLENBQUMxSCxVQUNUNkc7QUFBQUEsa0NBQ0U7QUFBQSxrQ0FDQTdHO0FBQUFBLGdDQUNGO0FBQUEsZ0NBR0QsV0FBQyxVQUFVLFNBQVMsRUFBRTBEO0FBQUFBLGtDQUFJLENBQUNzRSxVQUMxQjtBQUFBLG9DQUFDLE9BQU87QUFBQSxvQ0FBUDtBQUFBLHNDQUVDLE9BQU9BO0FBQUFBLHNDQUVOQSxnQkFBTWpFLE9BQU8sQ0FBQyxFQUFFQyxZQUFZLElBQzNCZ0UsTUFBTS9ELE1BQU0sQ0FBQyxFQUFFVCxZQUFZO0FBQUE7QUFBQSxvQ0FKeEJ3RTtBQUFBQSxvQ0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQU1BO0FBQUEsZ0NBQ0Q7QUFBQTtBQUFBLDhCQTdCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBOEJBO0FBQUEsK0JBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBb0NBO0FBQUEsNkJBNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBNkVBO0FBQUE7QUFBQSxzQkEvRUk7QUFBQSxzQkFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXNGQTtBQUFBO0FBQUEsa0JBMUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkEyRkE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFBaUw7QUFBQTtBQUFBLGtCQUY3TDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUE7QUFBQTtBQUFBLFlBN3ZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUE4dkJBO0FBQUEsYUFud0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvd0JBO0FBQUE7QUFBQSxNQXh3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBeXdCQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVd0SjtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4Qk0sMEJBQWdCLElBQUk7QUFBQSxRQUN0QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1Qyw0QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUNELGdCQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUNlLE1BQU07QUFDZkEsa0JBQUVvRyxlQUFlO0FBQ2pCWSxrQ0FBa0I7QUFBQSxjQUNwQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVztBQUFBO0FBQUEsd0JBRU47QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2IvSCx1QkFBYXlCLGNBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFBUTtBQUFBLHdCQUFJO0FBQUEsd0JBQ1M7QUFBQSx3QkFDckIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBO0FBQUE7QUFBQSxvQkFUbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxhQUFZO0FBQUEsc0JBQ1o7QUFBQSxzQkFDQSxXQUFVO0FBQUEsc0JBQ1YsVUFBVSxDQUFDVixNQUNUTixxQkFBcUJNLEVBQUVFLE9BQU9ELEtBQUs7QUFBQTtBQUFBLG9CQVB2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUc7QUFBQSxxQkFyQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1QkE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUEwSjtBQUFBO0FBQUEsa0JBRnRLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBO0FBQUE7QUFBQSxZQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFzQ0E7QUFBQSxhQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOENBO0FBQUE7QUFBQSxNQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFzREE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXbEI7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNEJBQWtCLEtBQUs7QUFDdkJFLDBCQUFnQixJQUFJO0FBQUEsUUFDdEI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsMkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlDQUNiLGlDQUFDLFNBQUksV0FBVSx5RUFDYixpQ0FBQyxVQUFLLFdBQVUsNEJBQTJCLGlCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBRUEsdUJBQUMsT0FBRSxXQUFVLHVDQUFzQyxnREFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUNELGNBQWM2RCxNQUFNcEMsY0FDbkIsdUJBQUMsT0FBRSxXQUFVLGdEQUNWekIsd0JBQWM2RCxNQUFNcEMsY0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTTtBQUNiMUIsb0NBQWtCLEtBQUs7QUFDdkJFLGtDQUFnQixJQUFJO0FBQUEsZ0JBQ3RCO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUFvRztBQUFBO0FBQUEsY0FOaEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNvRztBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQWlGO0FBQUE7QUFBQSxjQUg3RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJDQTtBQUFBO0FBQUEsTUFsREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbURBO0FBQUEsT0FuakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvakRBLEtBcmpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc2pEQTtBQUVKO0FBQUVwSCxHQXRzRUlELE9BQUs7QUFBQWlLLEtBQUxqSztBQXdzRU4sZUFBZUE7QUFBTSxJQUFBaUs7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsIk1vZGFsIiwiYXBpIiwiRGF0YVRhYmxlIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJDb2xsYXBzZSIsIklvTWRNb3JlIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiQ2lyY3VsYXJMb2FkZXIiLCJmaWVsZFNpemUiLCJQYW5lbCIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIkJyZWFkY3J1bWIiLCJHcm91cCIsIl9zIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiVGFibGVHcm91cHMiLCJzZXRUYWJsZUdyb3VwcyIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwic2hvd01vZGFsQ2xvc2UiLCJzZXRTaG93TW9kYWxDbG9zZSIsImN1cnJlbnRHcm91cCIsInNldEN1cnJlbnRHcm91cCIsImN1cnJlbnRVcGRhdGVHcm91cCIsInNldEN1cnJlbnRVcGRhdGVHcm91cCIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiZGVsZXRpb25Hcm91cE5hbWUiLCJzZXREZWxldGlvbkdyb3VwTmFtZSIsInJlbG9hZFRyaWdnZXIiLCJzZXRSZWxvYWRUcmlnZ2VyIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJncm91cF9uYW1lIiwiZ3JvdXBfdHlwZSIsImdyb3VwX3ZhbHVlIiwiZ3JvdXBfaW5zdGFsbCIsImdyb3VwX21lbWJlcnMiLCJncm91cF9kdXJhdGlvbiIsInN0YXJ0X2RhdGUiLCJlbmRfZGF0ZSIsIm1pbmltdW1fYmlkIiwibWF4aW11bV9iaWQiLCJjb21taXNzaW9uIiwiZ3JvdXBfY29tbWlzc2lvbiIsImluY2VudGl2ZXMiLCJyZWdfZmVlIiwibW9udGhseV9pbnN0YWxsbWVudCIsIndlZWtseV9pbnN0YWxsbWVudCIsImRhaWx5X2luc3RhbGxtZW50IiwicmVsYXRpb25zaGlwX21hbmFnZXIiLCJhcHBfZGlzcGxheV92YWNhbnlfc2VhdCIsImF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlIiwiYXVjdGlvbl9tb2RlIiwiZ3JvdXBfY29kZSIsImVycm9ycyIsInNldEVycm9ycyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJzdGFydF9kYXRlX3R5cGUiLCJyZWZyZXNoR3JvdXBzIiwicHJldiIsIndpbmRvdyIsImdldEVtcGxveWVlcyIsInJlc3BvbnNlIiwiZ2V0IiwicmVzcG9uc2VEYXRhIiwiZGF0YSIsImVtcGxveWVlIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIiwiZmV0Y2hHcm91cHMiLCJncm91cERhdGEiLCJmaWx0ZXJlZERhdGEiLCJmaWx0ZXIiLCJncm91cCIsInN0YXR1cyIsInRvTG93ZXJDYXNlIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImluZGV4IiwiX2lkIiwiaWQiLCJuYW1lIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzbGljZSIsImluc3RhbGxtZW50IiwibWVtYmVycyIsInNwbGl0IiwicmV2ZXJzZSIsImpvaW4iLCJkYXRlIiwiY3JlYXRlZEF0IiwiYWN0aW9uIiwiaXRlbXMiLCJrZXkiLCJsYWJlbCIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImhhbmRsZVNoYXJlQ2xpY2siLCJoYW5kbGVDbG9zZUdyb3VwTW9kYWxPcGVuIiwiZ3JvdXBJZCIsImJhc2VVcmwiLCJmdWxsVXJsIiwib3BlbiIsImhhbmRsZUNsb3NlR3JvdXAiLCJwYXRjaCIsImhhbmRsZUNoYW5nZSIsInByZXZEYXRhIiwidmFsaWRhdGVGb3JtIiwibmV3RXJyb3JzIiwidHJpbSIsImlzTmFOIiwiRGF0ZSIsInBhcnNlRmxvYXQiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwicG9zdCIsImhlYWRlcnMiLCJmaWx0ZXJlZEdyb3VwcyIsImluY2x1ZGVzIiwiZWRpdFVybCIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInByZXZFcnJvcnMiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3QiLCJoYW5kbGVJbnB1dENoYW5nZSIsImhhbmRsZURlbGV0ZUdyb3VwIiwidG9TdHJpbmciLCJkZWxldGUiLCJoYW5kbGVVcGRhdGUiLCJwdXQiLCJjb2x1bW5zIiwiaGVhZGVyIiwiaGVpZ2h0IiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInVuZGVmaW5lZCIsImdUeXBlIiwidGV4dCIsIkFycmF5IiwiaXNBcnJheSIsInBob25lX251bWJlciIsInN0eXBlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR3JvdXAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgRHJvcGRvd24sIENvbGxhcHNlIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuY29uc3QgeyBQYW5lbCB9ID0gQ29sbGFwc2U7XHJcblxyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcblxyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5jb25zdCBHcm91cCA9ICgpID0+IHtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZUdyb3Vwcywgc2V0VGFibGVHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxDbG9zZSwgc2V0U2hvd01vZGFsQ2xvc2VdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50R3JvdXAsIHNldEN1cnJlbnRHcm91cF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZGVsZXRpb25Hcm91cE5hbWUsIHNldERlbGV0aW9uR3JvdXBOYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShcImdyb3Vwc1wiKTtcclxuXHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBncm91cF9uYW1lOiBcIlwiLFxyXG4gICAgZ3JvdXBfdHlwZTogXCJcIixcclxuICAgIGdyb3VwX3ZhbHVlOiBcIlwiLFxyXG4gICAgZ3JvdXBfaW5zdGFsbDogXCJcIixcclxuICAgIGdyb3VwX21lbWJlcnM6IFwiXCIsXHJcbiAgICBncm91cF9kdXJhdGlvbjogXCJcIixcclxuICAgIHN0YXJ0X2RhdGU6IFwiXCIsXHJcbiAgICBlbmRfZGF0ZTogXCJcIixcclxuICAgIG1pbmltdW1fYmlkOiBcIlwiLFxyXG4gICAgbWF4aW11bV9iaWQ6IFwiXCIsXHJcbiAgICBjb21taXNzaW9uOiBcIjFcIixcclxuICAgIGdyb3VwX2NvbW1pc3Npb246IFwiNVwiLFxyXG4gICAgaW5jZW50aXZlczogXCIxXCIsXHJcbiAgICByZWdfZmVlOiBcIlwiLFxyXG4gICAgbW9udGhseV9pbnN0YWxsbWVudDogXCJcIixcclxuICAgIHdlZWtseV9pbnN0YWxsbWVudDogXCJcIixcclxuICAgIGRhaWx5X2luc3RhbGxtZW50OiBcIlwiLFxyXG4gICAgcmVsYXRpb25zaGlwX21hbmFnZXI6IFwiXCIsXHJcbiAgICBhcHBfZGlzcGxheV92YWNhbnlfc2VhdDogXCJcIixcclxuICAgIGF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlOiBcIlwiLFxyXG4gICAgYXVjdGlvbl9tb2RlOiBcIlwiLFxyXG4gICAgZ3JvdXBfY29kZTogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwX25hbWU6IFwiXCIsXHJcbiAgICBncm91cF90eXBlOiBcIlwiLFxyXG4gICAgZ3JvdXBfdmFsdWU6IFwiXCIsXHJcbiAgICBncm91cF9pbnN0YWxsOiBcIlwiLFxyXG4gICAgZ3JvdXBfbWVtYmVyczogXCJcIixcclxuICAgIGdyb3VwX2R1cmF0aW9uOiBcIlwiLFxyXG4gICAgc3RhcnRfZGF0ZV90eXBlOiBcIlwiLFxyXG4gICAgc3RhcnRfZGF0ZTogXCJcIixcclxuICAgIGVuZF9kYXRlOiBcIlwiLFxyXG4gICAgbWluaW11bV9iaWQ6IFwiXCIsXHJcbiAgICBtYXhpbXVtX2JpZDogXCJcIixcclxuICAgIGNvbW1pc3Npb246IFwiXCIsXHJcbiAgICBncm91cF9jb21taXNzaW9uOiBcIlwiLFxyXG4gICAgaW5jZW50aXZlczogXCJcIixcclxuICAgIHJlZ19mZWU6IFwiXCIsXHJcbiAgICBtb250aGx5X2luc3RhbGxtZW50OiBcIlwiLFxyXG4gICAgd2Vla2x5X2luc3RhbGxtZW50OiBcIlwiLFxyXG4gICAgZGFpbHlfaW5zdGFsbG1lbnQ6IFwiXCIsXHJcbiAgICByZWxhdGlvbnNoaXBfbWFuYWdlcjogXCJcIixcclxuICAgIGFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0OiBcIlwiLFxyXG4gICAgYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGU6IFwiXCIsXHJcbiAgICBhdWN0aW9uX21vZGU6IFwiXCIsXHJcbiAgICBncm91cF9jb2RlOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByZWZyZXNoR3JvdXBzID0gKCkgPT4ge1xyXG4gICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICB3aW5kb3cucmVmcmVzaEdyb3VwcyA9IHJlZnJlc2hHcm91cHM7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBkZWxldGUgd2luZG93LnJlZnJlc2hHcm91cHM7XHJcbiAgICB9O1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEVtcGxveWVlcygpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZW1wbG95ZWVcIik7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID0gcmVzcG9uc2UuZGF0YT8uZW1wbG95ZWU7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKHJlc3BvbnNlRGF0YSA/IHJlc3BvbnNlRGF0YSA6IFtdKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRFbXBsb3llZXMoW10pO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgRmV0Y2hpbmcgRW1wbG95ZWVzXCIpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBnZXRFbXBsb3llZXMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJjbG9zZWRcIlxyXG4gICAgICAgICAgICA/IFwiL3YxL2FkbWluL2dyb3Vwcy9zdGF0dXMvY2xvc2VkXCJcclxuICAgICAgICAgICAgOiBcIi92MS9hZG1pbi9ncm91cHMvXCJcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBjb25zdCBncm91cERhdGEgPSByZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgICBzZXRHcm91cHMoZ3JvdXBEYXRhKTtcclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyZWREYXRhID1cclxuICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJjbG9zZWRcIlxyXG4gICAgICAgICAgICA/IGdyb3VwRGF0YVxyXG4gICAgICAgICAgICA6IGdyb3VwRGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgKGdyb3VwKSA9PiBncm91cD8uc3RhdHVzPy50b0xvd2VyQ2FzZSgpICE9PSBcImNsb3NlZFwiXHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBmaWx0ZXJlZERhdGEubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGdyb3VwPy5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgbmFtZTogZ3JvdXA/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICB0eXBlOlxyXG4gICAgICAgICAgICBncm91cD8uZ3JvdXBfdHlwZT8uY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICBncm91cD8uZ3JvdXBfdHlwZT8uc2xpY2UoMSkgK1xyXG4gICAgICAgICAgICBcIiBHcm91cFwiLFxyXG4gICAgICAgICAgdmFsdWU6IGdyb3VwPy5ncm91cF92YWx1ZSxcclxuICAgICAgICAgIG1vbnRobHlfaW5zdGFsbG1lbnQ6IGdyb3VwLm1vbnRobHlfaW5zdGFsbG1lbnQsXHJcbiAgICAgICAgICB3ZWVrbHlfaW5zdGFsbG1lbnQ6IGdyb3VwLndlZWtseV9pbnN0YWxsbWVudCxcclxuICAgICAgICAgIGRhaWx5X2luc3RhbGxtZW50OiBncm91cC5kYWlseV9pbnN0YWxsbWVudCxcclxuICAgICAgICAgIHJlbGF0aW9uc2hpcF9tYW5hZ2VyOiBncm91cC5yZWxhdGlvbnNoaXBfbWFuYWdlcj8ubmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgaW5zdGFsbG1lbnQ6IGdyb3VwLmdyb3VwX2luc3RhbGwsXHJcbiAgICAgICAgICBpbmNlbnRpdmVzOiBncm91cC5pbmNlbnRpdmVzLFxyXG4gICAgICAgICAgbWVtYmVyczogZ3JvdXA/Lmdyb3VwX21lbWJlcnMsXHJcbiAgICAgICAgICBzdGFydF9kYXRlOiBncm91cC5zdGFydF9kYXRlXHJcbiAgICAgICAgICAgID8gZ3JvdXAuc3RhcnRfZGF0ZS5zcGxpdChcIlRcIilbMF0uc3BsaXQoXCItXCIpLnJldmVyc2UoKS5qb2luKFwiLVwiKVxyXG4gICAgICAgICAgICA6IFwiXCIsXHJcbiAgICAgICAgICBlbmRfZGF0ZTogZ3JvdXAuZW5kX2RhdGVcclxuICAgICAgICAgICAgPyBncm91cC5lbmRfZGF0ZS5zcGxpdChcIlRcIilbMF0uc3BsaXQoXCItXCIpLnJldmVyc2UoKS5qb2luKFwiLVwiKVxyXG4gICAgICAgICAgICA6IFwiXCIsXHJcbiAgICAgICAgICBhcHBfZGlzcGxheV92YWNhbnlfc2VhdDogZ3JvdXA/LmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0LFxyXG4gICAgICAgICAgZGF0ZTogZ3JvdXA/LmNyZWF0ZWRBdCxcclxuICAgICAgICAgIGF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlOiBncm91cD8uYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGUsXHJcbiAgICAgICAgICBhdWN0aW9uX21vZGU6IGdyb3VwPy5hdWN0aW9uX21vZGUsXHJcbiAgICAgICAgICBncm91cF9jb2RlOiBncm91cD8uZ3JvdXBfY29kZSxcclxuICAgICAgICAgIHN0YXR1czogZ3JvdXA/LnN0YXR1cyxcclxuICAgICAgICAgIGNyZWF0ZWRBdDogZ3JvdXA/LmNyZWF0ZWRBdFxyXG4gICAgICAgICAgICA/IGdyb3VwPy5jcmVhdGVkQXRcclxuICAgICAgICAgICAgICA/LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgIC5zcGxpdChcIi1cIilcclxuICAgICAgICAgICAgICAucmV2ZXJzZSgpXHJcbiAgICAgICAgICAgICAgLmpvaW4oXCItXCIpXHJcbiAgICAgICAgICAgIDogXCJcIixcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICBpdGVtczpcclxuICAgICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwiY2xvc2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwLl9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cC5faWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVNoYXJlQ2xpY2soZ3JvdXA/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29weVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgICAgICAgIDogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwLl9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cC5faWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVNoYXJlQ2xpY2soZ3JvdXA/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29weVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCI0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDbG9zZUdyb3VwTW9kYWxPcGVuKGdyb3VwLl9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbG9zZSBHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgc2V0VGFibGVHcm91cHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXIsIGFjdGl2ZVRhYl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTaGFyZUNsaWNrID0gKGdyb3VwSWQpID0+IHtcclxuICAgIGlmICghZ3JvdXBJZCkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiTWlzc2luZyBvciBpbnZhbGlkIGdyb3VwSWRcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBiYXNlVXJsID1cclxuICAgICAgXCJodHRwOi8vcHJvZC1jaGl0LW5ldy5zMy13ZWJzaXRlLmV1LW5vcnRoLTEuYW1hem9uYXdzLmNvbVwiO1xyXG4gICAgY29uc3QgZnVsbFVybCA9IGAke2Jhc2VVcmx9L2Vucm9sbG1lbnQtcmVxdWVzdC1mb3JtLz9ncm91cF9pZD0ke2dyb3VwSWR9YDtcclxuXHJcbiAgICB3aW5kb3cub3BlbihmdWxsVXJsLCBcIl9ibGFua1wiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDbG9zZUdyb3VwTW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL2dyb3Vwcy8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsQ2xvc2UodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXA6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDbG9zZUdyb3VwID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgLy8gaWYgKCFjdXJyZW50R3JvdXA/Ll9pZCkge1xyXG4gICAgLy8gICByZXR1cm47XHJcbiAgICAvLyB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnBhdGNoKGAvdjEvYWRtaW4vZ3JvdXBzLyR7Y3VycmVudEdyb3VwPy5kYXRhPy5faWR9L3N0YXR1cy9jbG9zZWRgLCB7XHJcbiAgICAgICAgc3RhdHVzOiBcImNsb3NlZFwiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICBtZXNzYWdlOiBcIkdyb3VwIGNsb3NlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFNob3dNb2RhbENsb3NlKGZhbHNlKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY2xvc2luZyBncm91cDpcIiwgZXJyb3IpO1xyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGNsb3NlIGdyb3VwXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuXHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG5cclxuICAgIGNvbnN0IGRhdGEgPSB0eXBlID09PSBcImFkZEdyb3VwXCIgPyBmb3JtRGF0YSA6IHVwZGF0ZUZvcm1EYXRhO1xyXG5cclxuICAgIGlmICghZGF0YS5ncm91cF9uYW1lLnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXBfbmFtZSA9IFwiR3JvdXAgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5ncm91cF90eXBlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ncm91cF90eXBlID0gXCJHcm91cCBUeXBlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLmdyb3VwX3ZhbHVlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ncm91cF92YWx1ZSA9IFwiR3JvdXAgVmFsdWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoaXNOYU4oZGF0YS5ncm91cF92YWx1ZSkgfHwgZGF0YS5ncm91cF92YWx1ZSA8PSAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ncm91cF92YWx1ZSA9IFwiR3JvdXAgVmFsdWUgbXVzdCBiZSBncmVhdGVyIHRoYW4gemVybyAobm9cIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEuZ3JvdXBfaW5zdGFsbCkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXBfaW5zdGFsbCA9IFwiR3JvdXAgSW5zdGFsbG1lbnQgQW1vdW50IGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKFxyXG4gICAgICAhZGF0YS5ncm91cF9pbnN0YWxsIHx8XHJcbiAgICAgIGlzTmFOKGRhdGEuZ3JvdXBfaW5zdGFsbCkgfHxcclxuICAgICAgZGF0YS5ncm91cF9pbnN0YWxsIDw9IDBcclxuICAgICkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXBfaW5zdGFsbCA9XHJcbiAgICAgICAgXCJHcm91cCBJbnN0YWxsbWVudCBBbW91bnQgbXVzdCBiZSBncmVhdGVyIHRoYW4gemVybyAobm8gc3ltYm9scykuXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLmdyb3VwX21lbWJlcnMpIHtcclxuICAgICAgbmV3RXJyb3JzLmdyb3VwX21lbWJlcnMgPSBcIkdyb3VwIE1lbWJlcnMgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICFkYXRhLmdyb3VwX21lbWJlcnMgfHxcclxuICAgICAgaXNOYU4oZGF0YS5ncm91cF9tZW1iZXJzKSB8fFxyXG4gICAgICBkYXRhLmdyb3VwX21lbWJlcnMgPD0gMFxyXG4gICAgKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ncm91cF9tZW1iZXJzID1cclxuICAgICAgICBcIkdyb3VwIE1lbWJlcnMgbXVzdCBiZSBncmVhdGVyIHRoYW4gemVybyAobm8gc3ltYm9scykuXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLnJlbGF0aW9uc2hpcF9tYW5hZ2VyKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5yZWxhdGlvbnNoaXBfbWFuYWdlciA9IFwiUmVsYXRpb25zaGlwIE1hbmFnZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEubW9udGhseV9pbnN0YWxsbWVudCkge1xyXG4gICAgICBuZXdFcnJvcnMubW9udGhseV9pbnN0YWxsbWVudCA9IFwiTW9udGhseSBJbnN0YWxsbWVudCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS53ZWVrbHlfaW5zdGFsbG1lbnQpIHtcclxuICAgICAgbmV3RXJyb3JzLndlZWtseV9pbnN0YWxsbWVudCA9IFwiV2Vla2x5IEluc3RhbGxtZW50IGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLmRhaWx5X2luc3RhbGxtZW50KSB7XHJcbiAgICAgIG5ld0Vycm9ycy5kYWlseV9pbnN0YWxsbWVudCA9IFwiRGFpbHkgSW5zdGFsbG1lbnQgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEuZ3JvdXBfZHVyYXRpb24pIHtcclxuICAgICAgbmV3RXJyb3JzLmdyb3VwX2R1cmF0aW9uID0gXCJHcm91cCBEdXJhdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmIChcclxuICAgICAgIWRhdGEuZ3JvdXBfZHVyYXRpb24gfHxcclxuICAgICAgaXNOYU4oZGF0YS5ncm91cF9kdXJhdGlvbikgfHxcclxuICAgICAgZGF0YS5ncm91cF9kdXJhdGlvbiA8PSAwXHJcbiAgICApIHtcclxuICAgICAgbmV3RXJyb3JzLmdyb3VwX2R1cmF0aW9uID1cclxuICAgICAgICBcIkdyb3VwIER1cmF0aW9uIG11c3QgYmUgZ3JlYXRlciB0aGFuIHplcm8gKG5vIHN5bWJvbHMpLlwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5yZWdfZmVlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5yZWdfZmVlID0gXCJSZWdpc3RyYXRpb24gRmVlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFkYXRhLnJlZ19mZWUgfHwgaXNOYU4oZGF0YS5yZWdfZmVlKSB8fCBkYXRhLnJlZ19mZWUgPCAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5yZWdfZmVlID1cclxuICAgICAgICBcIlJlZ2lzdHJhdGlvbiBGZWUgbXVzdCBiZSBhIHplcm8gb3IgZ3JlYXRlciB0aGFuIHplcm8gKG5vIHN5bWJvbHMpLlwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5zdGFydF9kYXRlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5zdGFydF9kYXRlID0gXCJTdGFydCBEYXRlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLmF1Y3Rpb25fbW9kZSkge1xyXG4gICAgICBuZXdFcnJvcnMuYXVjdGlvbl9tb2RlID0gXCJhdWN0aW9uIG1vZGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEuYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGUpIHtcclxuICAgICAgbmV3RXJyb3JzLmF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlID1cclxuICAgICAgICBcImF1Y3Rpb24gcHJvY2Vzc2luZyB0eXBlIGlzIHJlcXVpcmVkIFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5hcHBfZGlzcGxheV92YWNhbnlfc2VhdCkge1xyXG4gICAgICBuZXdFcnJvcnMuYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQgPSBcIlBsZWFzZSBFbnRlciBEaXNwbGF5IFZhY2FudCBTZWF0XCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGZvcm1EYXRhLmVuZF9kYXRlICYmICFkYXRhLmVuZF9kYXRlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5lbmRfZGF0ZSA9IFwiRW5kIERhdGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgIGZvcm1EYXRhLmVuZF9kYXRlICYmXHJcbiAgICAgIG5ldyBEYXRlKGRhdGEuZW5kX2RhdGUpIDwgbmV3IERhdGUoZGF0YS5zdGFydF9kYXRlKVxyXG4gICAgKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5lbmRfZGF0ZSA9IFwiRW5kIERhdGUgY2Fubm90IGJlIGVhcmxpZXIgdGhhbiBTdGFydCBEYXRlXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLm1pbmltdW1fYmlkKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5taW5pbXVtX2JpZCA9IFwiTWluaW11bSBCaWQgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICFkYXRhLm1pbmltdW1fYmlkIHx8XHJcbiAgICAgIGlzTmFOKGRhdGEubWluaW11bV9iaWQpIHx8XHJcbiAgICAgIGRhdGEubWluaW11bV9iaWQgPD0gMFxyXG4gICAgKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5taW5pbXVtX2JpZCA9XHJcbiAgICAgICAgXCJNaW5pbXVtIEJpZCBtdXN0IGJlIGdyZWF0ZXIgdGhhbiB6ZXJvIChubyBzeW1ib2xzKS5cIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEubWF4aW11bV9iaWQpIHtcclxuICAgICAgbmV3RXJyb3JzLm1heGltdW1fYmlkID0gXCJNYXhpbXVtIEJpZCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmIChcclxuICAgICAgIWRhdGEubWF4aW11bV9iaWQgfHxcclxuICAgICAgaXNOYU4oZGF0YS5tYXhpbXVtX2JpZCkgfHxcclxuICAgICAgZGF0YS5tYXhpbXVtX2JpZCA8PSAwXHJcbiAgICApIHtcclxuICAgICAgbmV3RXJyb3JzLm1heGltdW1fYmlkID1cclxuICAgICAgICBcIk1heGltdW0gQmlkIG11c3QgYmUgZ3JlYXRlciB0aGFuIHplcm8gKG5vIHN5bWJvbHMpLlwiO1xyXG4gICAgfSBlbHNlIGlmIChwYXJzZUZsb2F0KGRhdGEubWF4aW11bV9iaWQpIDwgcGFyc2VGbG9hdChkYXRhLm1pbmltdW1fYmlkKSkge1xyXG4gICAgICBuZXdFcnJvcnMubWF4aW11bV9iaWQgPVxyXG4gICAgICAgIFwiTWF4aW11bSBCaWQgbXVzdCBiZSBncmVhdGVyIHRoYW4gb3IgZXF1YWwgdG8gTWluaW11bSBCaWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJhZGRHcm91cFwiKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXCIvZ3JvdXAvYWRkLWdyb3VwXCIsIGZvcm1EYXRhLCB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG5cclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJHcm91cCBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG5cclxuICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICBncm91cF9uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgZ3JvdXBfdHlwZTogXCJcIixcclxuICAgICAgICAgIGdyb3VwX3ZhbHVlOiBcIlwiLFxyXG4gICAgICAgICAgZ3JvdXBfaW5zdGFsbDogXCJcIixcclxuICAgICAgICAgIGdyb3VwX21lbWJlcnM6IFwiXCIsXHJcbiAgICAgICAgICBncm91cF9kdXJhdGlvbjogXCJcIixcclxuICAgICAgICAgIGdyb3VwX2NvbW1pc3Npb246IFwiNVwiLFxyXG4gICAgICAgICAgc3RhcnRfZGF0ZTogXCJcIixcclxuICAgICAgICAgIGVuZF9kYXRlOiBcIlwiLFxyXG4gICAgICAgICAgbWluaW11bV9iaWQ6IFwiXCIsXHJcbiAgICAgICAgICBtYXhpbXVtX2JpZDogXCJcIixcclxuICAgICAgICAgIGNvbW1pc3Npb246IFwiXCIsXHJcbiAgICAgICAgICBpbmNlbnRpdmVzOiBcIlwiLFxyXG4gICAgICAgICAgcmVsYXRpb25zaGlwX21hbmFnZXI6IFwiXCIsXHJcbiAgICAgICAgICBtb250aGx5X2luc3RhbGxtZW50OiBcIlwiLFxyXG4gICAgICAgICAgYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQ6IFwiXCIsXHJcbiAgICAgICAgICBhdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZTogXCJcIixcclxuICAgICAgICAgIGF1Y3Rpb25fbW9kZTogXCJcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcnMpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIGdyb3VwOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRHcm91cHMgPSBncm91cHMuZmlsdGVyKChncm91cCkgPT5cclxuICAgIGdyb3VwLmdyb3VwX25hbWU/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybT8udG9Mb3dlckNhc2UoKSlcclxuICApO1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vZ3JvdXBzLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXA6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgY29uc3QgZWRpdFVybCA9IGAvYWRkLW5ldy1ncm91cD9lZGl0PXRydWUmZ3JvdXBJZD0ke2dyb3VwSWR9YDtcclxuICAgIHdpbmRvdy5vcGVuKGVkaXRVcmwsIFwiX2JsYW5rXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuXHJcbiAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7XHJcbiAgICAgIC4uLnByZXZFcnJvcnMsXHJcbiAgICAgIFtmaWVsZF06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKHsgLi4uZXJyb3JzLCBbZmllbGRdOiBcIlwiIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG5cclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKHsgLi4uZXJyb3JzLCBbbmFtZV06IFwiXCIgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlR3JvdXAgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgaWYgKFxyXG4gICAgICBjdXJyZW50R3JvdXAgJiZcclxuICAgICAgZGVsZXRpb25Hcm91cE5hbWUudG9TdHJpbmcoKS50cmltKCkgPT09IGN1cnJlbnRHcm91cC5ncm91cF9uYW1lXHJcbiAgICApIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvdjEvYWRtaW4vZ3JvdXBzLyR7Y3VycmVudEdyb3VwLl9pZH1gKTtcclxuXHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJHcm91cCBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGdyb3VwOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgICBgL3YxL2FkbWluL2dyb3Vwcy8ke2N1cnJlbnRVcGRhdGVHcm91cC5faWR9YCxcclxuICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuXHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJHcm91cCB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBncm91cDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX2NvZGVcIiwgaGVhZGVyOiBcIkdyb3VwIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0eXBlXCIsIGhlYWRlcjogXCJHcm91cCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInZhbHVlXCIsIGhlYWRlcjogXCJHcm91cCBWYWx1ZVwiIH0sXHJcbiAgICB7IGtleTogXCJtZW1iZXJzXCIsIGhlYWRlcjogXCJHcm91cCBNZW1iZXJzXCIgfSxcclxuICAgIHsga2V5OiBcImluc3RhbGxtZW50XCIsIGhlYWRlcjogXCJHcm91cCBJbnN0YWxsbWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJzdGFydF9kYXRlXCIsIGhlYWRlcjogXCJTdGFydCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImVuZF9kYXRlXCIsIGhlYWRlcjogXCJFbmQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJkYWlseV9pbnN0YWxsbWVudFwiLCBoZWFkZXI6IFwiRGFpbHkgSW5zdGFsbG1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXRcIiwgaGVhZGVyOiBcIkFwcCBEaXNwbGF5IFZhY2FueSBTZWF0XCIgfSxcclxuICAgIHsga2V5OiBcIndlZWtseV9pbnN0YWxsbWVudFwiLCBoZWFkZXI6IFwiV2Vla2x5IEluc3RhbGxtZW50XCIgfSxcclxuICAgIHsga2V5OiBcIm1vbnRobHlfaW5zdGFsbG1lbnRcIiwgaGVhZGVyOiBcIk1vbnRobHkgSW5zdGFsbG1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVsYXRpb25zaGlwX21hbmFnZXJcIiwgaGVhZGVyOiBcIlJlbGF0aW9uc2hpcCBNYW5hZ2VyXCIgfSxcclxuICAgIHsga2V5OiBcImNyZWF0ZWRBdFwiLCBoZWFkZXI6IFwiQ3JlYXRlZCBBdFwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+R3JvdXBzPC9oMT5cclxuXHJcbiAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcImdyb3Vwc1wiICYmIChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKFwiL2FkZC1uZXctZ3JvdXBcIiwgXCJfYmxhbmtcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICsgQWRkIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG10LTYgbWItNCBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYihcImdyb3Vwc1wiKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTYgcHktMyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGJvcmRlci1iLTIgJHthY3RpdmVUYWIgPT09IFwiZ3JvdXBzXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ibHVlLTk1MCBib3JkZXItYmx1ZS05NTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNTAwIGJvcmRlci10cmFuc3BhcmVudCBob3Zlcjp0ZXh0LWJsdWUtOTUwXCJcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgR3JvdXBzXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwiY2xvc2VkXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNiBweS0zIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgYm9yZGVyLWItMiAke2FjdGl2ZVRhYiA9PT0gXCJjbG9zZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LWJsdWUtOTUwIGJvcmRlci1ibHVlLTk1MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtZ3JheS01MDAgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOnRleHQtYmx1ZS05NTBcIlxyXG4gICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDbG9zZWQgR3JvdXBzXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge1RhYmxlR3JvdXBzLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZUdyb3Vwcywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcImNsb3NlZFwiID8gXCJDbG9zZWQgR3JvdXBzXCIgOiBcIkdyb3Vwc1wiXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcImNsb3NlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcIkNsb3NlZC1Hcm91cHMuY3N2XCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwiR3JvdXBzLmNzdlwiXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgZmFpbHVyZT17VGFibGVHcm91cHMubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtcclxuICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcImNsb3NlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcIkNsb3NlZCBHcm91cCBEYXRhXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwiR3JvdXAgRGF0YVwiXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtMyBsZzpncmlkLWNvbHMtNCBnYXAtOFwiPjwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgQWRkIEdyb3VwXHJcbiAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH1cclxuICAgICAgICAgICAgICBub1ZhbGlkYXRlXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgR3JvdXAgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBHcm91cCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEdyb3VwIFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggR3JvdXAgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZ3JvdXBfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImdyb3VwX3R5cGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge1tcIkRpdmlkZW50XCIsIFwiRG91YmxlXCJdLm1hcCgoZ1R5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtnVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnVHlwZS50b0xvd2VyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtnVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBSZWxhdGlvbnNoaXAgTWFuYWdlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3IgU2VhcmNoIFJlbGF0aW9uc2hpcCBNYW5hZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVsYXRpb25zaGlwX21hbmFnZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRleHQgPSBgJHtvcHRpb24uY2hpbGRyZW59YDtcclxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0ZXh0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhPy5yZWxhdGlvbnNoaXBfbWFuYWdlciB8fCB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwicmVsYXRpb25zaGlwX21hbmFnZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7KEFycmF5LmlzQXJyYXkoZW1wbG95ZWVzKSA/IGVtcGxveWVlcyA6IFtdKS5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAoZW1wbG95ZWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2VtcGxveWVlPy5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtcGxveWVlPy5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWU/Lm5hbWV9IHwge2VtcGxveWVlPy5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucmVsYXRpb25zaGlwX21hbmFnZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucmVsYXRpb25zaGlwX21hbmFnZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQXBwIERpc3BsYXkgVmFjYW55IFNlYXR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhcHBfZGlzcGxheV92YWNhbnlfc2VhdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFwcCBEaXNwbGF5IFZhY2FueSBTZWF0XCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG5vLXNwaW5uZXIgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0IHx8IDBcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIFZhbHVlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBfdmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF92YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHcm91cCBWYWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX3ZhbHVlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGEuZ3JvdXBfdmFsdWUgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIEluc3RhbGxtZW50IEFtb3VudHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2luc3RhbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF9pbnN0YWxsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEdyb3VwIEluc3RhbGxtZW50IEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX2luc3RhbGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfaW5zdGFsbH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhLmdyb3VwX2luc3RhbGwgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgTWVtYmVycyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX21lbWJlcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF9tZW1iZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEdyb3VwIE1lbWJlcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9tZW1iZXJzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX21lbWJlcnN9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5ncm91cF9tZW1iZXJzIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cCBEdXJhdGlvbntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2R1cmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3JvdXBfZHVyYXRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgRHVyYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9kdXJhdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9kdXJhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhLmdyb3VwX2R1cmF0aW9uIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIERhaWx5IEluc3RhbGxtZW50e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGFpbHlfaW5zdGFsbG1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5kYWlseV9pbnN0YWxsbWVudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBEYWlseSBJbnN0YWxsbWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRhaWx5X2luc3RhbGxtZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRhaWx5X2luc3RhbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5kYWlseV9pbnN0YWxsbWVudCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgV2Vla2x5IEluc3RhbGxtZW50e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwid2Vla2x5X2luc3RhbGxtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEud2Vla2x5X2luc3RhbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFdlZWtseSBJbnN0YWxsbWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLndlZWtseV9pbnN0YWxsbWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy53ZWVrbHlfaW5zdGFsbG1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLndlZWtseV9pbnN0YWxsbWVudCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwibW9udGhseV9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIE1vbnRobHkgSW5zdGFsbG1lbnR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibW9udGhseV9pbnN0YWxsbWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm1vbnRobHlfaW5zdGFsbG1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cIm1vbnRobHlfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBNb250aGx5IEluc3RhbGxtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLm1vbnRobHlfaW5zdGFsbG1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubW9udGhseV9pbnN0YWxsbWVudH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEubW9udGhseV9pbnN0YWxsbWVudCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVnaXN0cmF0aW9uIEZlZXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZ19mZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5yZWdfZmVlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFJlZ2lzdHJhdGlvbiBGZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5yZWdfZmVlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnJlZ19mZWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5yZWdfZmVlIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFN0YXJ0IERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3RhcnRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnN0YXJ0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc3RhcnRfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdGFydF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVuZCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVuZF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW5kX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW5kX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW5kX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBNaW5pbXVtIEJpZCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1pbmltdW1fYmlkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubWluaW11bV9iaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgTWluaW11bSBCaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5taW5pbXVtX2JpZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5taW5pbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhLm1pbmltdW1fYmlkIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBNYXhpbXVtIEJpZCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1heGltdW1fYmlkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubWF4aW11bV9iaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgTWF4aW11bSBCaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5tYXhpbXVtX2JpZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5tYXhpbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhLm1heGltdW1fYmlkIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQWdlbnQgQ29tbWlzc2lvbiAlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29tbWlzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvbW1pc3Npb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIENvbW1pc3Npb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG5vLXNwaW5uZXIgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGEuY29tbWlzc2lvbiB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBDb21wYW55IENvbW1pc3Npb24gJVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2NvbW1pc3Npb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF9jb21taXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHcm91cCBDb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuZ3JvdXBfY29tbWlzc2lvbiB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBFbXBsb3llZSBJbmNlbnRpdmVzICVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiaW5jZW50aXZlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmluY2VudGl2ZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEluY2VudGl2ZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhLmluY2VudGl2ZXMgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBHcm91cFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxVcGRhdGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBVcGRhdGUgR3JvdXBcclxuICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuICAgICAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfVxyXG4gICAgICAgICAgICAgIG5vVmFsaWRhdGVcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBHcm91cCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgR3JvdXAgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBHcm91cCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3IgU2VhcmNoIEdyb3VwIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/Lmdyb3VwX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcImdyb3VwX3R5cGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge1tcIkRpdmlkZW50XCIsIFwiRG91YmxlXCIsIFwiRml4ZWRcIl0ubWFwKChnVHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2dUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dUeXBlLnRvTG93ZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlbGF0aW9uc2hpcCBNYW5hZ2Vye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggUmVsYXRpb25zaGlwIE1hbmFnZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWxhdGlvbnNoaXBfbWFuYWdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGV4dCA9IGAke29wdGlvbi5jaGlsZHJlbn1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LnJlbGF0aW9uc2hpcF9tYW5hZ2VyIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJyZWxhdGlvbnNoaXBfbWFuYWdlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHsoQXJyYXkuaXNBcnJheShlbXBsb3llZXMpID8gZW1wbG95ZWVzIDogW10pLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAgIChlbXBsb3llZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17ZW1wbG95ZWU/Ll9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1wbG95ZWU/Ll9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZT8ubmFtZX0gfCB7ZW1wbG95ZWU/LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5yZWxhdGlvbnNoaXBfbWFuYWdlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5yZWxhdGlvbnNoaXBfbWFuYWdlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBBcHAgRGlzcGxheSBWYWNhbnkgU2VhdHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBcHAgRGlzcGxheSBWYWNhbnkgU2VhdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5hcHBfZGlzcGxheV92YWNhbnlfc2VhdCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cCBWYWx1ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfdmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHcm91cCBWYWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX3ZhbHVlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5ncm91cF92YWx1ZSB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgSW5zdGFsbG1lbnQgQW1vdW50e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmdyb3VwX2luc3RhbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHcm91cCBJbnN0YWxsbWVudCBBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9pbnN0YWxsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX2luc3RhbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmdyb3VwX2luc3RhbGwgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgTWVtYmVycyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX21lbWJlcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ncm91cF9tZW1iZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgTWVtYmVyc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX21lbWJlcnMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfbWVtYmVyc31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZ3JvdXBfbWVtYmVycyB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgRHVyYXRpb257XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9kdXJhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmdyb3VwX2R1cmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgRHVyYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9kdXJhdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9kdXJhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZ3JvdXBfZHVyYXRpb24gfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRGFpbHkgSW5zdGFsbG1lbnR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkYWlseV9pbnN0YWxsbWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmRhaWx5X2luc3RhbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgTWVtYmVyc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRhaWx5X2luc3RhbGxtZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRhaWx5X2luc3RhbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5kYWlseV9pbnN0YWxsbWVudCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgV2Vla2x5IEluc3RhbGxtZW50e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwid2Vla2x5X2luc3RhbGxtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEud2Vla2x5X2luc3RhbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgRHVyYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy53ZWVrbHlfaW5zdGFsbG1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMud2Vla2x5X2luc3RhbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS53ZWVrbHlfaW5zdGFsbG1lbnQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm1vbnRobHlfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBNb250aGx5IEluc3RhbGxtZW50e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1vbnRobHlfaW5zdGFsbG1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5tb250aGx5X2luc3RhbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cIm1vbnRobHlfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBNb250aGx5IEluc3RhbGxtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLm1vbnRobHlfaW5zdGFsbG1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubW9udGhseV9pbnN0YWxsbWVudH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEubW9udGhseV9pbnN0YWxsbWVudCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlZ2lzdHJhdGlvbiBGZWV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWdfZmVlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEucmVnX2ZlZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBSZWdpc3RyYXRpb24gRmVlXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG5vLXNwaW5uZXIgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucmVnX2ZlZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5yZWdfZmVlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5yZWdfZmVlIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBTdGFydCBEYXRlIFR5cGV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC02IG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN0YXJ0X2RhdGVfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPVwiZXhwZWN0ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uc3RhcnRfZGF0ZV90eXBlID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiZXhwZWN0ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsdWUtNjAwIGZvY3VzOnJpbmctYmx1ZS01MDAgYm9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRXhwZWN0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN0YXJ0X2RhdGVfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPVwiZml4ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uc3RhcnRfZGF0ZV90eXBlID09PSBcImZpeGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTYwMCBmb2N1czpyaW5nLWJsdWUtNTAwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEZpeGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnN0YXJ0X2RhdGVfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdGFydF9kYXRlX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBTdGFydCBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN0YXJ0X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5zdGFydF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc3RhcnRfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdGFydF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVuZCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVuZF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZW5kX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbmRfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbmRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIE1pbmltdW0gQmlkICV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJtaW5pbXVtX2JpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLm1pbmltdW1fYmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgTWluaW11bSBCaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5taW5pbXVtX2JpZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5taW5pbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEubWluaW11bV9iaWQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIE1heGltdW0gQmlkICV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJtYXhpbXVtX2JpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLm1heGltdW1fYmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgTWF4aW11bSBCaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbm8tc3Bpbm5lciBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5tYXhpbXVtX2JpZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5tYXhpbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEubWF4aW11bV9iaWQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBBZ2VudCBDb21taXNzaW9uICVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY29tbWlzc2lvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmNvbW1pc3Npb24gfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ29tcGFueSBDb21taXNzaW9uICVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9jb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfY29tbWlzc2lvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHcm91cCBDb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZ3JvdXBfY29tbWlzc2lvbiB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBFbXBsb3llZSBJbmNlbnRpdmVzICVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiaW5jZW50aXZlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmluY2VudGl2ZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgSW5jZW50aXZlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5pbmNlbnRpdmVzIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPENvbGxhcHNlXHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0QWN0aXZlS2V5PXtbXCIxXCJdfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFBhbmVsXHJcbiAgICAgICAgICAgICAgICAgIGhlYWRlcj17XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBrZXk9XCIxXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQXVjdGlvbiBQcm9jZXNzaW5nIFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBQcm9jZXNzaW5nIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5hdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1tcIlNZU1RFTVwiLCBcIk1BTlVBTFwiXS5tYXAoKHN0eXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17c3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0eXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5cGUuc2xpY2UoMSkudG9Mb3dlckNhc2UoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIE1vZGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBBdWN0aW9uIE1vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uX21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uYXVjdGlvbl9tb2RlIHx8IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhdWN0aW9uX21vZGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJPTkxJTkVcIiwgXCJPRkZMSU5FXCJdLm1hcCgoc3R5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtzdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3R5cGUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlwZS5zbGljZSgxKS50b0xvd2VyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L1BhbmVsPlxyXG4gICAgICAgICAgICAgIDwvQ29sbGFwc2U+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctYmx1ZS03MDAgaG92ZXI6YmctYmx1ZS04MDAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlciBib3JkZXItMiBib3JkZXItYmxhY2tcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsRGVsZXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBEZWxldGUgR3JvdXBcclxuICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgIHtjdXJyZW50R3JvdXAgJiYgKFxyXG4gICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVHcm91cCgpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHRvIGNvbmZpcm0gZGVsZXRpb24ue1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEdyb3VwIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0RGVsZXRpb25Hcm91cE5hbWUoZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxDbG9zZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsQ2xvc2UoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBDbG9zZSBHcm91cFxyXG4gICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLWZ1bGwgYmctb3JhbmdlLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LW9yYW5nZS02MDBcIj4hPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtZ3JheS03MDAgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICBEbyB5b3Ugd2FudCB0byBjbG9zZSB0aGlzIGdyb3VwP1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAge2N1cnJlbnRHcm91cD8uZGF0YT8uZ3JvdXBfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtdC0yIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwPy5kYXRhPy5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIG10LTZcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsQ2xvc2UoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS03MDAgYmctd2hpdGUgaG92ZXI6YmctZ3JheS0xMDAgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsb3NlR3JvdXB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIuNSByb3VuZGVkLWxnIGJnLW9yYW5nZS02MDAgaG92ZXI6Ymctb3JhbmdlLTcwMCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBZZXMsIENsb3NlIEdyb3VwXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgR3JvdXA7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0dyb3VwLmpzeCJ9