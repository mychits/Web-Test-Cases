import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChitPayoutReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
const ChitPayoutReport = () => {
  _s();
  const [dataTable, setDataTable] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedFromDate, setSelectedFromDate] = useState("");
  const [selectedToDate, setSelectedToDate] = useState("");
  const [showFilterField, setShowFilterField] = useState(false);
  const [summary, setSummary] = useState({
    totalAmount: 0,
    totalCount: 0,
    totalUsers: 0
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    user: "",
    filterType: "Today"
  });
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };
  const formatDate = (date) => date.toLocaleDateString("en-CA");
  const handleSelectFilter = (value) => {
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    let from = "";
    let to = "";
    if (value === "Today") {
      from = to = formatDate(today);
    } else if (value === "Yesterday") {
      const y = new Date(today);
      y.setDate(today.getDate() - 1);
      from = to = formatDate(y);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      from = formatDate(start);
      to = formatDate(end);
    } else if (value === "Custom") {
      setShowFilterField(true);
      return;
    }
    setSelectedFromDate(from);
    setSelectedToDate(to);
  };
  useEffect(() => {
    handleSelectFilter(formData.filterType);
  }, [formData.filterType]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await api.get("/user/get-user");
        setUsers(res.data || []);
      } catch (err) {
        console.error("Error fetching users:", err);
      }
    };
    fetchUsers();
  }, []);
  const fetchPayouts = async () => {
    try {
      setLoading(true);
      let url = `v1/admin/payments-out/`;
      const params = new URLSearchParams();
      if (formData.user) params.append("user_id", formData.user);
      if (selectedFromDate) params.append("from_date", selectedFromDate);
      if (selectedToDate) params.append("to_date", selectedToDate);
      if (params.toString()) url += `?${params.toString()}`;
      const res = await api.get(url);
      const data = res?.data?.data || [];
      const totalAmount = data.reduce(
        (sum, item) => sum + Number(item?.amount || 0),
        0
      );
      const uniqueUsers = new Set(data.map((d) => d?.user_id?._id).filter(Boolean));
      setSummary({
        totalAmount,
        totalCount: data.length,
        totalUsers: uniqueUsers.size
      });
      const formatted = data.map((item, index) => ({
        id: item?._id,
        slNo: index + 1,
        // Customer
        name: item?.user_id?.full_name || "-",
        phone: item?.user_id?.phone_number || "-",
        // Group & Ticket
        groupName: item?.group_id ? item?.group_id?.group_name : item?.loan ? item?.loan?.loan_id + " (" + item?.loan?.loan_amount + ")" : item?.pigme ? item?.pigme?.pigme_id : "-",
        ticket: item?.ticket || "-",
        // Payment details
        receiptNo: item?.receipt_no || "-",
        payDate: item?.pay_date ? item.pay_date.split("-").reverse().join("-") : "-",
        payType: item?.pay_type || "-",
        transactionId: item?.pay_type === "cheque" ? ` Chq No: ${item?.cheque_number || "-"} | 
                  Chq Date: ${item?.cheque_date ? item.cheque_date.split("T")[0].split("-").reverse().join("-") : "-"}` : item?.transaction_id,
        payFor: item?.pay_for || "-",
        disbursementType: item?.disbursement_type || "-",
        admin_type: item?.admin_type?.name || "-",
        // Amount
        amount: Number(item?.amount || 0),
        // Action dropdown (print)
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            menu: {
              items: [
                {
                  key: "1",
                  label: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-purple-600",
                      onClick: () => handlePrint(item._id),
                      children: "Print"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
                      lineNumber: 158,
                      columnNumber: 17
                    },
                    this
                  )
                }
              ]
            },
            placement: "bottomLeft",
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
              lineNumber: 170,
              columnNumber: 29
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 151,
            columnNumber: 25
          },
          this
        ) }, item._id, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
          lineNumber: 150,
          columnNumber: 9
        }, this)
      }));
      setDataTable(formatted);
    } catch (err) {
      console.error("❌ Payout Fetch Error:", err);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch payout data",
        type: "error"
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (selectedFromDate && selectedToDate) {
      fetchPayouts();
    }
  }, [selectedFromDate, selectedToDate, formData.user]);
  const handlePrint = async (payoutId) => {
    try {
      window.open(`/print/payout/${payoutId}`, "_blank");
    } catch (error) {
      console.error("Print error:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to generate print",
        type: "error"
      });
    }
  };
  const columns = [
    { key: "slNo", header: "Sl No" },
    { key: "receiptNo", header: "Receipt No" },
    { key: "payDate", header: "Pay Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone", header: "Phone" },
    { key: "groupName", header: "Group/Loan/Pigmy" },
    { key: "ticket", header: "Ticket" },
    { key: "payType", header: "Pay Type" },
    { key: "transactionId", header: "Transaction ID" },
    { key: "payFor", header: "Pay For" },
    { key: "disbursementType", header: "Disbursement Type" },
    { key: "amount", header: "Amount (₹)" },
    { key: "admin_type", header: "Created By" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-10", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
      lineNumber: 230,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
        lineNumber: 231,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-x-hidden", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mb-6", children: "Payout Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
        lineNumber: 241,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/4", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-[42px]",
            placeholder: "All Users",
            popupMatchSelectWidth: false,
            showSearch: true,
            filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
            value: formData.user || void 0,
            onChange: (val) => handleAntDSelect("user", val),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
                lineNumber: 258,
                columnNumber: 29
              }, this),
              users.map(
                (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u._id, children: u.full_name }, u._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
                  lineNumber: 260,
                  columnNumber: 15
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 247,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
          lineNumber: 246,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/4", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-[42px]",
            value: formData.filterType,
            onChange: (val) => handleAntDSelect("filterType", val),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "Today", children: "Today" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
                lineNumber: 274,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
                lineNumber: 275,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "ThisMonth", children: "This Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
                lineNumber: 276,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "Custom", children: "Custom" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
                lineNumber: 277,
                columnNumber: 29
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 269,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
          lineNumber: 268,
          columnNumber: 21
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/5", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              className: "w-full h-[42px] px-3 border border-gray-300 rounded-lg",
              value: selectedFromDate,
              onChange: (e) => setSelectedFromDate(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
              lineNumber: 285,
              columnNumber: 33
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 284,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/5", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              className: "w-full h-[42px] px-3 border border-gray-300 rounded-lg",
              value: selectedToDate,
              onChange: (e) => setSelectedToDate(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
              lineNumber: 294,
              columnNumber: 33
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 293,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
          lineNumber: 283,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
        lineNumber: 244,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Amount" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 308,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: [
            "₹",
            summary.totalAmount.toLocaleString()
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 309,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
          lineNumber: 307,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Transactions" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 313,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalCount }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 314,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
          lineNumber: 312,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Customers" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 318,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalUsers }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
            lineNumber: 319,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
          lineNumber: 317,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
        lineNumber: 306,
        columnNumber: 17
      }, this),
      dataTable.length > 0 && !loading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns,
          data: dataTable,
          exportedFileName: "Payout_Report"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
          lineNumber: 325,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: loading }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
        lineNumber: 331,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
      lineNumber: 240,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx",
    lineNumber: 229,
    columnNumber: 5
  }, this);
};
_s(ChitPayoutReport, "dTdIN1VLV2MwGCkBoz608z+Vu6M=");
_c = ChitPayoutReport;
export default ChitPayoutReport;
var _c;
$RefreshReg$(_c, "ChitPayoutReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitPayoutReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNko0QyxTQTZIcEIsVUE3SG9COzJCQTdKNUM7QUFBbUJBLG9CQUFpQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEIsU0FBU0MsUUFBUUMsZ0JBQWdCO0FBQ2pDLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsdUJBQXVCO0FBRTlCLE1BQU1DLG1CQUFtQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzNCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlGLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNHLFNBQVNDLFVBQVUsSUFBSUosU0FBUyxLQUFLO0FBRTVDLFFBQU0sQ0FBQ0ssa0JBQWtCQyxtQkFBbUIsSUFBSU4sU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQ08sZ0JBQWdCQyxpQkFBaUIsSUFBSVIsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ1MsaUJBQWlCQyxrQkFBa0IsSUFBSVYsU0FBUyxLQUFLO0FBRTVELFFBQU0sQ0FBQ1csU0FBU0MsVUFBVSxJQUFJWixTQUFTO0FBQUEsSUFDbkNhLGFBQWE7QUFBQSxJQUNiQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLEVBQ2hCLENBQUM7QUFFRCxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSWpCLFNBQVM7QUFBQSxJQUMzQ2tCLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1YsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJdEIsU0FBUztBQUFBLElBQ3JDdUIsTUFBTTtBQUFBLElBQ05DLFlBQVk7QUFBQSxFQUNoQixDQUFDO0FBR0QsUUFBTUMsbUJBQW1CQSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3ZDTCxnQkFBWSxDQUFDTSxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDRixLQUFLLEdBQUdDLE1BQU0sRUFBRTtBQUFBLEVBQ3ZEO0FBRUEsUUFBTUUsYUFBYUEsQ0FBQ0MsU0FBU0EsS0FBS0MsbUJBQW1CLE9BQU87QUFHNUQsUUFBTUMscUJBQXFCQSxDQUFDTCxVQUFVO0FBQ2xDakIsdUJBQW1CLEtBQUs7QUFFeEIsVUFBTXVCLFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsUUFBSUMsT0FBTztBQUNYLFFBQUlDLEtBQUs7QUFFVCxRQUFJVCxVQUFVLFNBQVM7QUFDbkJRLGFBQU9DLEtBQUtQLFdBQVdJLEtBQUs7QUFBQSxJQUNoQyxXQUFXTixVQUFVLGFBQWE7QUFDOUIsWUFBTVUsSUFBSSxJQUFJSCxLQUFLRCxLQUFLO0FBQ3hCSSxRQUFFQyxRQUFRTCxNQUFNTSxRQUFRLElBQUksQ0FBQztBQUM3QkosYUFBT0MsS0FBS1AsV0FBV1EsQ0FBQztBQUFBLElBQzVCLFdBQVdWLFVBQVUsYUFBYTtBQUM5QixZQUFNYSxRQUFRLElBQUlOLEtBQUtELE1BQU1RLFlBQVksR0FBR1IsTUFBTVMsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTUMsTUFBTSxJQUFJVCxLQUFLRCxNQUFNUSxZQUFZLEdBQUdSLE1BQU1TLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakVQLGFBQU9OLFdBQVdXLEtBQUs7QUFDdkJKLFdBQUtQLFdBQVdjLEdBQUc7QUFBQSxJQUN2QixXQUFXaEIsVUFBVSxVQUFVO0FBQzNCakIseUJBQW1CLElBQUk7QUFDdkI7QUFBQSxJQUNKO0FBRUFKLHdCQUFvQjZCLElBQUk7QUFDeEIzQixzQkFBa0I0QixFQUFFO0FBQUEsRUFDeEI7QUFFQWxELFlBQVUsTUFBTTtBQUNaOEMsdUJBQW1CWCxTQUFTRyxVQUFVO0FBQUEsRUFDMUMsR0FBRyxDQUFDSCxTQUFTRyxVQUFVLENBQUM7QUFHeEJ0QyxZQUFVLE1BQU07QUFDWixVQUFNMEQsYUFBYSxZQUFZO0FBQzNCLFVBQUk7QUFDQSxjQUFNQyxNQUFNLE1BQU16RCxJQUFJMEQsSUFBSSxnQkFBZ0I7QUFDMUM1QyxpQkFBUzJDLElBQUlFLFFBQVEsRUFBRTtBQUFBLE1BQzNCLFNBQVNDLEtBQUs7QUFDVkMsZ0JBQVFDLE1BQU0seUJBQXlCRixHQUFHO0FBQUEsTUFDOUM7QUFBQSxJQUNKO0FBQ0FKLGVBQVc7QUFBQSxFQUNmLEdBQUcsRUFBRTtBQUdMLFFBQU1PLGVBQWUsWUFBWTtBQUM3QixRQUFJO0FBQ0EvQyxpQkFBVyxJQUFJO0FBRWYsVUFBSWdELE1BQU07QUFDVixZQUFNQyxTQUFTLElBQUlDLGdCQUFnQjtBQUVuQyxVQUFJakMsU0FBU0UsS0FBTThCLFFBQU9FLE9BQU8sV0FBV2xDLFNBQVNFLElBQUk7QUFDekQsVUFBSWxCLGlCQUFrQmdELFFBQU9FLE9BQU8sYUFBYWxELGdCQUFnQjtBQUNqRSxVQUFJRSxlQUFnQjhDLFFBQU9FLE9BQU8sV0FBV2hELGNBQWM7QUFFM0QsVUFBSThDLE9BQU9HLFNBQVMsRUFBR0osUUFBTyxJQUFJQyxPQUFPRyxTQUFTLENBQUM7QUFFbkQsWUFBTVgsTUFBTSxNQUFNekQsSUFBSTBELElBQUlNLEdBQUc7QUFDN0IsWUFBTUwsT0FBT0YsS0FBS0UsTUFBTUEsUUFBUTtBQUdoQyxZQUFNbEMsY0FBY2tDLEtBQUtVO0FBQUFBLFFBQ3JCLENBQUNDLEtBQUtDLFNBQVNELE1BQU1FLE9BQU9ELE1BQU1FLFVBQVUsQ0FBQztBQUFBLFFBQzdDO0FBQUEsTUFDSjtBQUNBLFlBQU1DLGNBQWMsSUFBSUMsSUFBSWhCLEtBQUtpQixJQUFJLENBQUNDLE1BQU1BLEdBQUdDLFNBQVNDLEdBQUcsRUFBRUMsT0FBT0MsT0FBTyxDQUFDO0FBRTVFekQsaUJBQVc7QUFBQSxRQUNQQztBQUFBQSxRQUNBQyxZQUFZaUMsS0FBS3VCO0FBQUFBLFFBQ2pCdkQsWUFBWStDLFlBQVlTO0FBQUFBLE1BQzVCLENBQUM7QUFHRCxZQUFNQyxZQUFZekIsS0FBS2lCLElBQUksQ0FBQ0wsTUFBTWMsV0FBVztBQUFBLFFBQ3pDQyxJQUFJZixNQUFNUTtBQUFBQSxRQUNWUSxNQUFNRixRQUFRO0FBQUE7QUFBQSxRQUdkRyxNQUFNakIsTUFBTU8sU0FBU1csYUFBYTtBQUFBLFFBQ2xDQyxPQUFPbkIsTUFBTU8sU0FBU2EsZ0JBQWdCO0FBQUE7QUFBQSxRQUd0Q0MsV0FBV3JCLE1BQU1zQixXQUFXdEIsTUFBTXNCLFVBQVVDLGFBQWF2QixNQUFNd0IsT0FBT3hCLE1BQU13QixNQUFNQyxVQUFVLE9BQU96QixNQUFNd0IsTUFBTUUsY0FBYyxNQUFNMUIsTUFBTTJCLFFBQVEzQixNQUFNMkIsT0FBT0MsV0FBVztBQUFBLFFBQ3pLQyxRQUFRN0IsTUFBTTZCLFVBQVU7QUFBQTtBQUFBLFFBR3hCQyxXQUFXOUIsTUFBTStCLGNBQWM7QUFBQSxRQUMvQkMsU0FBU2hDLE1BQU1pQyxXQUNUakMsS0FBS2lDLFNBQVNDLE1BQU0sR0FBRyxFQUFFQyxRQUFRLEVBQUVDLEtBQUssR0FBRyxJQUMzQztBQUFBLFFBQ05DLFNBQVNyQyxNQUFNc0MsWUFBWTtBQUFBLFFBQzNCQyxlQUFldkMsTUFBTXNDLGFBQWEsV0FDNUIsWUFBWXRDLE1BQU13QyxpQkFBaUIsR0FBRztBQUFBLDhCQUM5QnhDLE1BQU15QyxjQUFjekMsS0FBS3lDLFlBQVlQLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRUEsTUFBTSxHQUFHLEVBQUVDLFFBQVEsRUFBRUMsS0FBSyxHQUFHLElBQUksR0FBRyxLQUFLcEMsTUFBTTBDO0FBQUFBLFFBQ2hIQyxRQUFRM0MsTUFBTTRDLFdBQVc7QUFBQSxRQUN6QkMsa0JBQWtCN0MsTUFBTThDLHFCQUFxQjtBQUFBLFFBQzdDQyxZQUFZL0MsTUFBTStDLFlBQVk5QixRQUFRO0FBQUE7QUFBQSxRQUd0Q2YsUUFBUUQsT0FBT0QsTUFBTUUsVUFBVSxDQUFDO0FBQUE7QUFBQSxRQUdoQzhDLFFBQ0ksdUJBQUMsU0FBSSxXQUFVLDZCQUNYO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxTQUFTLENBQUMsT0FBTztBQUFBLFlBQ2pCLE1BQU07QUFBQSxjQUNGQyxPQUFPO0FBQUEsZ0JBQ0g7QUFBQSxrQkFDSUMsS0FBSztBQUFBLGtCQUNMQyxPQUNJO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLFdBQVU7QUFBQSxzQkFDVixTQUFTLE1BQU1DLFlBQVlwRCxLQUFLUSxHQUFHO0FBQUEsc0JBQUU7QUFBQTtBQUFBLG9CQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxnQkFFUjtBQUFBLGNBQUM7QUFBQSxZQUVUO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQTtBQUFBLFVBbkJuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvQkEsS0FyQjRDUixLQUFLUSxLQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsTUFFUixFQUFFO0FBRUZwRSxtQkFBYXlFLFNBQVM7QUFBQSxJQUMxQixTQUFTeEIsS0FBSztBQUNWQyxjQUFRQyxNQUFNLHlCQUF5QkYsR0FBRztBQUMxQy9CLHFCQUFlO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDVixDQUFDO0FBQUEsSUFDTCxVQUFDO0FBQ0doQixpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBR0FsQixZQUFVLE1BQU07QUFDWixRQUFJbUIsb0JBQW9CRSxnQkFBZ0I7QUFDcEM0QyxtQkFBYTtBQUFBLElBQ2pCO0FBQUEsRUFDSixHQUFHLENBQUM5QyxrQkFBa0JFLGdCQUFnQmMsU0FBU0UsSUFBSSxDQUFDO0FBR3BELFFBQU13RixjQUFjLE9BQU9DLGFBQWE7QUFDcEMsUUFBSTtBQUNBQyxhQUFPQyxLQUFLLGlCQUFpQkYsUUFBUSxJQUFJLFFBQVE7QUFBQSxJQUNyRCxTQUFTOUQsT0FBTztBQUNaRCxjQUFRQyxNQUFNLGdCQUFnQkEsS0FBSztBQUNuQ2pDLHFCQUFlO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDVixDQUFDO0FBQUEsSUFDTDtBQUFBLEVBQ0o7QUFHQSxRQUFNK0YsVUFBVTtBQUFBLElBQ1osRUFBRU4sS0FBSyxRQUFRTyxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFUCxLQUFLLGFBQWFPLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUVQLEtBQUssV0FBV08sUUFBUSxXQUFXO0FBQUEsSUFDckMsRUFBRVAsS0FBSyxRQUFRTyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUVQLEtBQUssU0FBU08sUUFBUSxRQUFRO0FBQUEsSUFDaEMsRUFBRVAsS0FBSyxhQUFhTyxRQUFRLG1CQUFtQjtBQUFBLElBQy9DLEVBQUVQLEtBQUssVUFBVU8sUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRVAsS0FBSyxXQUFXTyxRQUFRLFdBQVc7QUFBQSxJQUNyQyxFQUFFUCxLQUFLLGlCQUFpQk8sUUFBUSxpQkFBaUI7QUFBQSxJQUNqRCxFQUFFUCxLQUFLLFVBQVVPLFFBQVEsVUFBVTtBQUFBLElBQ25DLEVBQUVQLEtBQUssb0JBQW9CTyxRQUFRLG9CQUFvQjtBQUFBLElBQ3ZELEVBQUVQLEtBQUssVUFBVU8sUUFBUSxhQUFhO0FBQUEsSUFDdEMsRUFBRVAsS0FBSyxjQUFjTyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFUCxLQUFLLFVBQVVPLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHdkMsU0FDSSx1QkFBQyxTQUFJLFdBQVUsY0FDWDtBQUFBLDJCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFDekI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQU1wRyxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ0xGLGVBQWUsQ0FBQ1csVUFBVSxFQUFFLEdBQUdBLE1BQU1WLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUxqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNSztBQUFBLElBR0wsdUJBQUMsU0FBSSxXQUFVLG1DQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtCQUE4Qiw2QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RDtBQUFBLE1BR3pELHVCQUFDLFNBQUksV0FBVSx1Q0FFWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQkFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBVTtBQUFBLFlBQ1YsYUFBWTtBQUFBLFlBQ1osdUJBQXVCO0FBQUEsWUFDdkI7QUFBQSxZQUNBLGNBQWMsQ0FBQ21HLE9BQU9DLFdBQ2xCQSxPQUFPQyxTQUFTQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLFlBRTlELE9BQU9uRyxTQUFTRSxRQUFRbUc7QUFBQUEsWUFDeEIsVUFBVSxDQUFDQyxRQUFRbEcsaUJBQWlCLFFBQVFrRyxHQUFHO0FBQUEsWUFFL0M7QUFBQSxxQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDMUIxSCxNQUFNK0Q7QUFBQUEsZ0JBQUksQ0FBQzRELE1BQ1IsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUV6RCxLQUMvQnlELFlBQUUvQyxhQURhK0MsRUFBRXpELEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNIO0FBQUE7QUFBQTtBQUFBLFVBaEJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWlCQSxLQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ1g7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVU7QUFBQSxZQUNWLE9BQU85QyxTQUFTRztBQUFBQSxZQUNoQixVQUFVLENBQUNtRyxRQUFRbEcsaUJBQWlCLGNBQWNrRyxHQUFHO0FBQUEsWUFFckQ7QUFBQSxxQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFNBQVEscUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FDbEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxhQUFZLHlCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQztBQUFBLGNBQzFDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sYUFBWSwwQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQSxjQUMzQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUE7QUFBQTtBQUFBLFVBUnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFHQ2xILG1CQUNHLG1DQUNJO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1CQUNYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixPQUFPSjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ3dILE1BQU12SCxvQkFBb0J1SCxFQUFFQyxPQUFPbkcsS0FBSztBQUFBO0FBQUEsWUFKdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXlELEtBTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDWDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBT3BCO0FBQUFBLGNBQ1AsVUFBVSxDQUFDc0gsTUFBTXJILGtCQUFrQnFILEVBQUVDLE9BQU9uRyxLQUFLO0FBQUE7QUFBQSxZQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJdUQsS0FMM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxXQXpEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkRBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSxpQ0FBQyxPQUFFLDRCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQSxVQUNmLHVCQUFDLFFBQUc7QUFBQTtBQUFBLFlBQUVoQixRQUFRRSxZQUFZa0gsZUFBZTtBQUFBLGVBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsYUFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ1g7QUFBQSxpQ0FBQyxPQUFFLGtDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCO0FBQUEsVUFDckIsdUJBQUMsUUFBSXBILGtCQUFRRyxjQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUEsYUFGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxpQ0FBQyxPQUFFLCtCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUEsVUFDbEIsdUJBQUMsUUFBSUgsa0JBQVFJLGNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0I7QUFBQSxhQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BR0NqQixVQUFVd0UsU0FBUyxLQUFLLENBQUNuRSxVQUN0QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0c7QUFBQSxVQUNBLE1BQU1MO0FBQUFBLFVBQ04sa0JBQWlCO0FBQUE7QUFBQSxRQUhyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHb0MsSUFHcEMsdUJBQUMsa0JBQWUsV0FBV0ssV0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLFNBM0YzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkZBO0FBQUEsT0F4R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlHQTtBQUVSO0FBQUVOLEdBclVJRCxrQkFBZ0I7QUFBQW9JLEtBQWhCcEk7QUF1VU4sZUFBZUE7QUFBaUIsSUFBQW9JO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJEYXRhVGFibGUiLCJhcGkiLCJOYXZiYXIiLCJTaWRlYmFyIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJDaXJjdWxhckxvYWRlciIsIklvTWRNb3JlIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJDaGl0UGF5b3V0UmVwb3J0IiwiX3MiLCJkYXRhVGFibGUiLCJzZXREYXRhVGFibGUiLCJ1c2VTdGF0ZSIsInVzZXJzIiwic2V0VXNlcnMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNlbGVjdGVkRnJvbURhdGUiLCJzZXRTZWxlY3RlZEZyb21EYXRlIiwic2VsZWN0ZWRUb0RhdGUiLCJzZXRTZWxlY3RlZFRvRGF0ZSIsInNob3dGaWx0ZXJGaWVsZCIsInNldFNob3dGaWx0ZXJGaWVsZCIsInN1bW1hcnkiLCJzZXRTdW1tYXJ5IiwidG90YWxBbW91bnQiLCJ0b3RhbENvdW50IiwidG90YWxVc2VycyIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwidXNlciIsImZpbHRlclR5cGUiLCJoYW5kbGVBbnREU2VsZWN0IiwiZmllbGQiLCJ2YWx1ZSIsInByZXYiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImhhbmRsZVNlbGVjdEZpbHRlciIsInRvZGF5IiwiRGF0ZSIsImZyb20iLCJ0byIsInkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInN0YXJ0IiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImVuZCIsImZldGNoVXNlcnMiLCJyZXMiLCJnZXQiLCJkYXRhIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiZmV0Y2hQYXlvdXRzIiwidXJsIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwiYXBwZW5kIiwidG9TdHJpbmciLCJyZWR1Y2UiLCJzdW0iLCJpdGVtIiwiTnVtYmVyIiwiYW1vdW50IiwidW5pcXVlVXNlcnMiLCJTZXQiLCJtYXAiLCJkIiwidXNlcl9pZCIsIl9pZCIsImZpbHRlciIsIkJvb2xlYW4iLCJsZW5ndGgiLCJzaXplIiwiZm9ybWF0dGVkIiwiaW5kZXgiLCJpZCIsInNsTm8iLCJuYW1lIiwiZnVsbF9uYW1lIiwicGhvbmUiLCJwaG9uZV9udW1iZXIiLCJncm91cE5hbWUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJsb2FuIiwibG9hbl9pZCIsImxvYW5fYW1vdW50IiwicGlnbWUiLCJwaWdtZV9pZCIsInRpY2tldCIsInJlY2VpcHRObyIsInJlY2VpcHRfbm8iLCJwYXlEYXRlIiwicGF5X2RhdGUiLCJzcGxpdCIsInJldmVyc2UiLCJqb2luIiwicGF5VHlwZSIsInBheV90eXBlIiwidHJhbnNhY3Rpb25JZCIsImNoZXF1ZV9udW1iZXIiLCJjaGVxdWVfZGF0ZSIsInRyYW5zYWN0aW9uX2lkIiwicGF5Rm9yIiwicGF5X2ZvciIsImRpc2J1cnNlbWVudFR5cGUiLCJkaXNidXJzZW1lbnRfdHlwZSIsImFkbWluX3R5cGUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlUHJpbnQiLCJwYXlvdXRJZCIsIndpbmRvdyIsIm9wZW4iLCJjb2x1bW5zIiwiaGVhZGVyIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1bmRlZmluZWQiLCJ2YWwiLCJ1IiwiZSIsInRhcmdldCIsInRvTG9jYWxlU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2hpdFBheW91dFJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuXHJcbmNvbnN0IENoaXRQYXlvdXRSZXBvcnQgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbZGF0YVRhYmxlLCBzZXREYXRhVGFibGVdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRUb0RhdGUsIHNldFNlbGVjdGVkVG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3Nob3dGaWx0ZXJGaWVsZCwgc2V0U2hvd0ZpbHRlckZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgdG90YWxBbW91bnQ6IDAsXHJcbiAgICAgICAgdG90YWxDb3VudDogMCxcclxuICAgICAgICB0b3RhbFVzZXJzOiAwLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICAgICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgICAgICB0eXBlOiBcImluZm9cIixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIHVzZXI6IFwiXCIsXHJcbiAgICAgICAgZmlsdGVyVHlwZTogXCJUb2RheVwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gSGFuZGxlIFNlbGVjdFxyXG4gICAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcblxyXG4gICAgLy8gRmlsdGVyIExvZ2ljXHJcbiAgICBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuICAgICAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuICAgICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgbGV0IGZyb20gPSBcIlwiO1xyXG4gICAgICAgIGxldCB0byA9IFwiXCI7XHJcblxyXG4gICAgICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbiAgICAgICAgICAgIGZyb20gPSB0byA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuICAgICAgICAgICAgY29uc3QgeSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgICAgICAgeS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICAgICAgICBmcm9tID0gdG8gPSBmb3JtYXREYXRlKHkpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICAgICAgICBmcm9tID0gZm9ybWF0RGF0ZShzdGFydCk7XHJcbiAgICAgICAgICAgIHRvID0gZm9ybWF0RGF0ZShlbmQpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuICAgICAgICAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKHRydWUpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZyb20pO1xyXG4gICAgICAgIHNldFNlbGVjdGVkVG9EYXRlKHRvKTtcclxuICAgIH07XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoZm9ybURhdGEuZmlsdGVyVHlwZSk7XHJcbiAgICB9LCBbZm9ybURhdGEuZmlsdGVyVHlwZV0pO1xyXG5cclxuICAgIC8vIEZldGNoIFVzZXJzXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgICAgICAgICBzZXRVc2VycyhyZXMuZGF0YSB8fCBbXSk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXJzOlwiLCBlcnIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBmZXRjaFVzZXJzKCk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgLy8gRmV0Y2ggUGF5b3V0c1xyXG4gICAgY29uc3QgZmV0Y2hQYXlvdXRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICBsZXQgdXJsID0gYHYxL2FkbWluL3BheW1lbnRzLW91dC9gO1xyXG4gICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XHJcblxyXG4gICAgICAgICAgICBpZiAoZm9ybURhdGEudXNlcikgcGFyYW1zLmFwcGVuZChcInVzZXJfaWRcIiwgZm9ybURhdGEudXNlcik7XHJcbiAgICAgICAgICAgIGlmIChzZWxlY3RlZEZyb21EYXRlKSBwYXJhbXMuYXBwZW5kKFwiZnJvbV9kYXRlXCIsIHNlbGVjdGVkRnJvbURhdGUpO1xyXG4gICAgICAgICAgICBpZiAoc2VsZWN0ZWRUb0RhdGUpIHBhcmFtcy5hcHBlbmQoXCJ0b19kYXRlXCIsIHNlbGVjdGVkVG9EYXRlKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChwYXJhbXMudG9TdHJpbmcoKSkgdXJsICs9IGA/JHtwYXJhbXMudG9TdHJpbmcoKX1gO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG4gICAgICAgICAgICBjb25zdCBkYXRhID0gcmVzPy5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgICAgICAgLy8gU3VtbWFyeVxyXG4gICAgICAgICAgICBjb25zdCB0b3RhbEFtb3VudCA9IGRhdGEucmVkdWNlKFxyXG4gICAgICAgICAgICAgICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgTnVtYmVyKGl0ZW0/LmFtb3VudCB8fCAwKSxcclxuICAgICAgICAgICAgICAgIDAsXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGNvbnN0IHVuaXF1ZVVzZXJzID0gbmV3IFNldChkYXRhLm1hcCgoZCkgPT4gZD8udXNlcl9pZD8uX2lkKS5maWx0ZXIoQm9vbGVhbikpO1xyXG5cclxuICAgICAgICAgICAgc2V0U3VtbWFyeSh7XHJcbiAgICAgICAgICAgICAgICB0b3RhbEFtb3VudCxcclxuICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IGRhdGEubGVuZ3RoLFxyXG4gICAgICAgICAgICAgICAgdG90YWxVc2VyczogdW5pcXVlVXNlcnMuc2l6ZSxcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAvLyBGb3JtYXQgdGFibGUgZGF0YVxyXG4gICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBkYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgICAgICBpZDogaXRlbT8uX2lkLFxyXG4gICAgICAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG5cclxuICAgICAgICAgICAgICAgIC8vIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICBuYW1lOiBpdGVtPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICBwaG9uZTogaXRlbT8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAgIC8vIEdyb3VwICYgVGlja2V0XHJcbiAgICAgICAgICAgICAgICBncm91cE5hbWU6IGl0ZW0/Lmdyb3VwX2lkID8gaXRlbT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgOiBpdGVtPy5sb2FuID8gaXRlbT8ubG9hbj8ubG9hbl9pZCArIFwiIChcIiArIGl0ZW0/LmxvYW4/LmxvYW5fYW1vdW50ICsgXCIpXCIgOiBpdGVtPy5waWdtZSA/IGl0ZW0/LnBpZ21lPy5waWdtZV9pZCA6IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgdGlja2V0OiBpdGVtPy50aWNrZXQgfHwgXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgICAgLy8gUGF5bWVudCBkZXRhaWxzXHJcbiAgICAgICAgICAgICAgICByZWNlaXB0Tm86IGl0ZW0/LnJlY2VpcHRfbm8gfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICBwYXlEYXRlOiBpdGVtPy5wYXlfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgID8gaXRlbS5wYXlfZGF0ZS5zcGxpdChcIi1cIikucmV2ZXJzZSgpLmpvaW4oXCItXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuICAgICAgICAgICAgICAgIHBheVR5cGU6IGl0ZW0/LnBheV90eXBlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgdHJhbnNhY3Rpb25JZDogaXRlbT8ucGF5X3R5cGUgPT09IFwiY2hlcXVlXCJcclxuICAgICAgICAgICAgICAgICAgICA/IGAgQ2hxIE5vOiAke2l0ZW0/LmNoZXF1ZV9udW1iZXIgfHwgXCItXCJ9IHwgXHJcbiAgICAgICAgICAgICAgICAgIENocSBEYXRlOiAke2l0ZW0/LmNoZXF1ZV9kYXRlID8gaXRlbS5jaGVxdWVfZGF0ZS5zcGxpdChcIlRcIilbMF0uc3BsaXQoXCItXCIpLnJldmVyc2UoKS5qb2luKFwiLVwiKSA6ICctJ31gIDogaXRlbT8udHJhbnNhY3Rpb25faWQsXHJcbiAgICAgICAgICAgICAgICBwYXlGb3I6IGl0ZW0/LnBheV9mb3IgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICBkaXNidXJzZW1lbnRUeXBlOiBpdGVtPy5kaXNidXJzZW1lbnRfdHlwZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgIGFkbWluX3R5cGU6IGl0ZW0/LmFkbWluX3R5cGU/Lm5hbWUgfHwgXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgICAgLy8gQW1vdW50XHJcbiAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcihpdGVtPy5hbW91bnQgfHwgMCksXHJcblxyXG4gICAgICAgICAgICAgICAgLy8gQWN0aW9uIGRyb3Bkb3duIChwcmludClcclxuICAgICAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiIGtleT17aXRlbS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJpbnQoaXRlbS5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgICAgICBzZXREYXRhVGFibGUoZm9ybWF0dGVkKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIuKdjCBQYXlvdXQgRmV0Y2ggRXJyb3I6XCIsIGVycik7XHJcbiAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBmZXRjaCBwYXlvdXQgZGF0YVwiLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIFRyaWdnZXIgRmV0Y2hcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgaWYgKHNlbGVjdGVkRnJvbURhdGUgJiYgc2VsZWN0ZWRUb0RhdGUpIHtcclxuICAgICAgICAgICAgZmV0Y2hQYXlvdXRzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW3NlbGVjdGVkRnJvbURhdGUsIHNlbGVjdGVkVG9EYXRlLCBmb3JtRGF0YS51c2VyXSk7XHJcblxyXG4gICAgLy8gUHJpbnQgaGFuZGxlclxyXG4gICAgY29uc3QgaGFuZGxlUHJpbnQgPSBhc3luYyAocGF5b3V0SWQpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICB3aW5kb3cub3BlbihgL3ByaW50L3BheW91dC8ke3BheW91dElkfWAsIFwiX2JsYW5rXCIpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJQcmludCBlcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gZ2VuZXJhdGUgcHJpbnRcIixcclxuICAgICAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBUYWJsZSBDb2x1bW5zXHJcbiAgICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgICAgIHsga2V5OiBcInNsTm9cIiwgaGVhZGVyOiBcIlNsIE5vXCIgfSxcclxuICAgICAgICB7IGtleTogXCJyZWNlaXB0Tm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInBheURhdGVcIiwgaGVhZGVyOiBcIlBheSBEYXRlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgICAgICB7IGtleTogXCJwaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAvTG9hbi9QaWdteVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInBheVR5cGVcIiwgaGVhZGVyOiBcIlBheSBUeXBlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJ0cmFuc2FjdGlvbklkXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBJRFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwicGF5Rm9yXCIsIGhlYWRlcjogXCJQYXkgRm9yXCIgfSxcclxuICAgICAgICB7IGtleTogXCJkaXNidXJzZW1lbnRUeXBlXCIsIGhlYWRlcjogXCJEaXNidXJzZW1lbnQgVHlwZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnQgKOKCuSlcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImFkbWluX3R5cGVcIiwgaGVhZGVyOiBcIkNyZWF0ZWQgQnlcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICAgIF07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMTBcIj5cclxuICAgICAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgb3ZlcmZsb3cteC1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTZcIj5QYXlvdXQgUmVwb3J0PC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogRmlsdGVycyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtZW5kIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogVXNlciBTZWxlY3QgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWQ6dy0xLzRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtWzQycHhdXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWxsIFVzZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudXNlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gaGFuZGxlQW50RFNlbGVjdChcInVzZXJcIiwgdmFsKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1Ll9pZH0gdmFsdWU9e3UuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3UuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEZpbHRlciBUeXBlICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctMS80XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLVs0MnB4XVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZmlsdGVyVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiZmlsdGVyVHlwZVwiLCB2YWwpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlRvZGF5XCI+VG9kYXk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlllc3RlcmRheVwiPlllc3RlcmRheTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiVGhpc01vbnRoXCI+VGhpcyBNb250aDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQ3VzdG9tXCI+Q3VzdG9tPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIERhdGUgRmlsdGVycyAqL31cclxuICAgICAgICAgICAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctMS81XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtWzQycHhdIHB4LTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctMS81XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtWzQycHhdIHB4LTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkVG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogU3VtbWFyeSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTEwMCBwLTQgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5Ub3RhbCBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMj7igrl7c3VtbWFyeS50b3RhbEFtb3VudC50b0xvY2FsZVN0cmluZygpfTwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlRvdGFsIFRyYW5zYWN0aW9uczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyPntzdW1tYXJ5LnRvdGFsQ291bnR9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy15ZWxsb3ctMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlRvdGFsIEN1c3RvbWVyczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyPntzdW1tYXJ5LnRvdGFsVXNlcnN9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBUYWJsZSAqL31cclxuICAgICAgICAgICAgICAgIHtkYXRhVGFibGUubGVuZ3RoID4gMCAmJiAhbG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e2RhdGFUYWJsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIlBheW91dF9SZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e2xvYWRpbmd9IC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDaGl0UGF5b3V0UmVwb3J0OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DaGl0UGF5b3V0UmVwb3J0LmpzeCJ9