import {
  require_react
} from "/node_modules/.vite/deps/chunk-73THXJN7.js?v=819e0a34";
import "/node_modules/.vite/deps/chunk-2TUXWMP5.js?v=819e0a34";
export default require_react();
//# sourceMappingURL=react.js.map
