import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/QuickSearch.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useRef = __vite__cjsImport3_react["useRef"];
import { Table, Tooltip, Card, Tabs, Input, Button, Tag } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  UserOutlined,
  UserSwitchOutlined,
  TeamOutlined,
  SafetyCertificateOutlined,
  PhoneOutlined,
  IdcardOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FiCheckCircle } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Fuse from "/node_modules/.vite/deps/fuse__js.js?v=819e0a34";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { EyeOutlined, SearchOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
function useDebounce(value, delay) {
  _s();
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}
_s(useDebounce, "KDuPAtDOgxm8PU6legVJOb3oOmA=");
const FILTERS_CONFIG = [
  { id: "1", filterName: "ID", key: "customer_id" },
  { id: "2", filterName: "Name", key: "name" },
  { id: "3", filterName: "Phone", key: "phone_number" },
  { id: "4", filterName: "Aadhaar", key: "aadhaar_number" },
  { id: "5", filterName: "Pan", key: "pan_number" },
  {
    id: "7",
    filterName: "Status",
    key: "customer_status",
    icon: FiCheckCircle
  }
];
const QuickSearch = () => {
  _s2();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("all");
  const [tableUsers, setTableUsers] = useState([]);
  const [tableLeads, setTableLeads] = useState([]);
  const [tableAgents, setTableAgents] = useState([]);
  const [tableEmployees, setTableEmployees] = useState([]);
  const [tableLoans, setTableLoans] = useState([]);
  const [tablePigmy, setTablePigmy] = useState([]);
  const [selectedExactMatch, setSelectedExactMatch] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [activeFilters, setActiveFilters] = useState([]);
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 100
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [apiLoaders, setApiLoaders] = useState({
    users: false,
    leads: false,
    agents: false,
    employees: false,
    loans: false,
    // NEW
    pigmy: false
    // NEW
  });
  const isAnyApiLoading = Object.values(apiLoaders).some((loading) => loading);
  const leadsFetchedRef = useRef(false);
  const loansFetchedRef = useRef(false);
  const pigmyFetchedRef = useRef(false);
  const updateApiLoader = useCallback((apiName, loading) => {
    setApiLoaders((prev) => ({ ...prev, [apiName]: loading }));
  }, []);
  useEffect(() => {
    const fetchUsers = async () => {
      updateApiLoader("users", true);
      try {
        const response = await api.get("/user/get-user");
        const formatted = response.data.map((u, i) => ({
          _id: u._id,
          id: i + 1,
          name: u.full_name,
          phone_number: u.phone_number,
          address: u.address,
          pincode: u.pincode,
          customer_id: u.customer_id,
          collection_area: u.collection_area?.route_name,
          aadhaar_number: u.adhaar_no || "—",
          pan_number: u.pan_no || "—",
          isCustomer: true,
          approval_status: u.approval_status
        }));
        setTableUsers(formatted);
      } catch (error) {
        console.error("Error fetching users:", error);
      } finally {
        updateApiLoader("users", false);
      }
    };
    fetchUsers();
  }, [reloadTrigger, updateApiLoader]);
  useEffect(() => {
    if (activeTab !== "leads") return;
    if (leadsFetchedRef.current) return;
    const fetchLeads = async () => {
      leadsFetchedRef.current = true;
      updateApiLoader("leads", true);
      try {
        const response = await api.get("/lead/new-non-converted");
        const formatted = response.data?.map((l, i) => ({
          _id: l._id,
          id: i + 1,
          name: l.lead_name || "—",
          phone_number: l.lead_phone || "—",
          address: l.lead_address || "—",
          pincode: l.pincode || "—",
          customer_id: l.leadCode,
          collection_area: l.group_id?.group_name || "—",
          customer_status: "Active",
          aadhaar_number: l.adhaar_no || l.lead_aadhaar || "—",
          pan_number: l.pan_no || l.lead_pan || "—",
          isLead: true,
          uniqueKey: `lead_${l._id}`
        }));
        setTableLeads(formatted);
      } catch (error) {
        console.error("Error fetching leads:", error);
        leadsFetchedRef.current = false;
      } finally {
        updateApiLoader("leads", false);
      }
    };
    fetchLeads();
  }, [activeTab, updateApiLoader]);
  useEffect(() => {
    if (activeTab !== "loans") return;
    if (loansFetchedRef.current) return;
    const fetchLoans = async () => {
      loansFetchedRef.current = true;
      updateApiLoader("loans", true);
      try {
        const response = await api.get("/v1/admin/loans/?approval_status=COMPLETED");
        const formatted = (response.data?.data || []).map((l, i) => ({
          _id: l._id,
          // loan _id
          id: i + 1,
          customer_id: l.borrower?.customer_id || "—",
          name: l.borrower?.full_name || "—",
          phone_number: l.borrower?.phone_number || "—",
          aadhaar_number: "—",
          // not provided
          pan_number: "—",
          // not provided
          collection_area: "—",
          // not provided
          customer_status: "Active",
          isLoan: true,
          user_id: l.borrower?._id || l._id
          // customer user id
        }));
        setTableLoans(formatted);
      } catch (error) {
        console.error("Error fetching loans:", error);
        loansFetchedRef.current = false;
      } finally {
        updateApiLoader("loans", false);
      }
    };
    fetchLoans();
  }, [activeTab, updateApiLoader]);
  useEffect(() => {
    if (activeTab !== "pigmy") return;
    if (pigmyFetchedRef.current) return;
    const fetchPigmy = async () => {
      pigmyFetchedRef.current = true;
      updateApiLoader("pigmy", true);
      try {
        const response = await api.get("/pigme/get-all-pigme-customers");
        const formatted = (response.data || []).map((p, i) => ({
          _id: p._id,
          id: i + 1,
          customer_id: p.customer?.customer_id || "—",
          name: p.customer?.full_name || "—",
          phone_number: p.customer?.phone_number || "—",
          aadhaar_number: p.customer?.adhaar_no || "—",
          pan_number: p.customer?.pan_no || "—",
          collection_area: "—",
          // or maybe p.customer?.collection_area? but it's an ID
          customer_status: "Active",
          isPigmy: true,
          user_id: p.customer?._id || p._id
        }));
        setTablePigmy(formatted);
      } catch (error) {
        console.error("Error fetching pigmy:", error);
        pigmyFetchedRef.current = false;
      } finally {
        updateApiLoader("pigmy", false);
      }
    };
    fetchPigmy();
  }, [activeTab, updateApiLoader]);
  useEffect(() => {
    const fetchAgents = async () => {
      updateApiLoader("agents", true);
      try {
        const response = await api.get("/agent/get");
        const formatted = (response.data?.agent || []).map((a, i) => ({
          _id: a._id,
          id: i + 1,
          name: a.name || "—",
          phone_number: a.phone_number || "—",
          address: a.address || "—",
          pincode: a.pincode || "—",
          customer_id: a.employeeCode,
          collection_area: a.designation_id?.title || "—",
          customer_status: "Active",
          aadhaar_number: a.adhaar_no || "—",
          pan_number: a.pan_no || "—",
          isAgent: true
        }));
        setTableAgents(formatted);
      } catch (error) {
        console.error("Error fetching agents:", error);
      } finally {
        updateApiLoader("agents", false);
      }
    };
    fetchAgents();
  }, [reloadTrigger, updateApiLoader]);
  useEffect(() => {
    const fetchEmployees = async () => {
      updateApiLoader("employees", true);
      try {
        const response = await api.get("/agent/get-employee");
        const formatted = (response.data?.employee || []).map((e, i) => ({
          _id: e._id,
          id: i + 1,
          name: e.name || "—",
          phone_number: e.phone_number || "—",
          address: e.address || "—",
          pincode: e.pincode || "—",
          customer_id: e.employeeCode,
          collection_area: e.designation_id?.title || "—",
          customer_status: "Active",
          aadhaar_number: e.adhaar_no || "—",
          pan_number: e.pan_no || "—",
          isEmployee: true
        }));
        setTableEmployees(formatted);
      } catch (error) {
        console.error("Error fetching employees:", error);
      } finally {
        updateApiLoader("employees", false);
      }
    };
    fetchEmployees();
  }, [reloadTrigger, updateApiLoader]);
  useEffect(() => {
    setSelectedExactMatch(null);
  }, [searchText]);
  const combinedData = useMemo(() => {
    const customerPhoneSet = new Set(tableUsers.map((user) => user.phone_number));
    const uniqueLeadsMap = /* @__PURE__ */ new Map();
    tableLeads.forEach((lead) => {
      if (customerPhoneSet.has(lead.phone_number)) return;
      if (!uniqueLeadsMap.has(lead.phone_number)) {
        uniqueLeadsMap.set(lead.phone_number, lead);
      }
    });
    const finalLeads = Array.from(uniqueLeadsMap.values());
    return [
      ...tableUsers,
      ...finalLeads,
      ...tableAgents,
      ...tableEmployees,
      ...tableLoans,
      // NEW
      ...tablePigmy
      // NEW
    ];
  }, [tableUsers, tableLeads, tableAgents, tableEmployees, tableLoans, tablePigmy]);
  const searchableKeys = useMemo(() => {
    if (activeFilters.length > 0) {
      return FILTERS_CONFIG.filter((f) => activeFilters.includes(f.id)).map((f) => f.key);
    }
    return FILTERS_CONFIG.map((f) => f.key);
  }, [activeFilters]);
  const getTypeInfo = (record) => {
    if (record.isLead) return { label: "Lead", color: "orange", bg: "bg-orange-50", border: "border-orange-200", text: "text-orange-700", icon: /* @__PURE__ */ jsxDEV(UserSwitchOutlined, { className: "text-2xl" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 302,
      columnNumber: 145
    }, this) };
    if (record.isAgent) return { label: "Agent", color: "purple", bg: "bg-purple-50", border: "border-purple-200", text: "text-purple-700", icon: /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-2xl" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 303,
      columnNumber: 147
    }, this) };
    if (record.isEmployee) return { label: "Employee", color: "cyan", bg: "bg-cyan-50", border: "border-cyan-200", text: "text-cyan-700", icon: /* @__PURE__ */ jsxDEV(SafetyCertificateOutlined, { className: "text-2xl" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 304,
      columnNumber: 145
    }, this) };
    if (record.isCustomer) return { label: "Customer", color: "blue", bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700", icon: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-2xl" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 305,
      columnNumber: 145
    }, this) };
    if (record.isLoan) return { label: "Loan", color: "green", bg: "bg-green-50", border: "border-green-200", text: "text-green-700", icon: /* @__PURE__ */ jsxDEV(IdcardOutlined, { className: "text-2xl" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 306,
      columnNumber: 141
    }, this) };
    if (record.isPigmy) return { label: "Pigmy", color: "gold", bg: "bg-yellow-50", border: "border-yellow-200", text: "text-yellow-700", icon: /* @__PURE__ */ jsxDEV(IdcardOutlined, { className: "text-2xl" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 307,
      columnNumber: 145
    }, this) };
    return { label: "Unknown", color: "default", bg: "bg-gray-50", border: "border-gray-200", text: "text-gray-700", icon: /* @__PURE__ */ jsxDEV(IdcardOutlined, { className: "text-2xl" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 308,
      columnNumber: 124
    }, this) };
  };
  const getApprovalStatus = (record) => {
    if (!record.isCustomer) return null;
    if (record.approval_status === "true") return { text: "Approved", color: "success" };
    if (record.approval_status === "false") return { text: "Pending", color: "warning" };
    return { text: "Approved", color: "success" };
  };
  const columns = useMemo(
    () => [
      {
        title: "SL. NO",
        key: "s_no",
        width: 80,
        align: "center",
        render: (_, __, index) => index + 1
      },
      {
        title: "Type",
        key: "type",
        width: 100,
        render: (_, record) => {
          const info = getTypeInfo(record);
          return /* @__PURE__ */ jsxDEV(Tag, { color: info.color, children: info.label }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 331,
            columnNumber: 14
          }, this);
        }
      },
      { dataIndex: "customer_id", title: "ID", key: "customer_id", width: 120 },
      { dataIndex: "name", title: "Name", key: "name", width: 180 },
      { dataIndex: "phone_number", title: "Phone", key: "phone_number", width: 140 },
      {
        dataIndex: "aadhaar_number",
        title: "Aadhaar",
        key: "aadhaar_number",
        width: 150,
        render: (text) => /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-sm", children: text }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 339,
          columnNumber: 23
        }, this)
      },
      {
        dataIndex: "pan_number",
        title: "Pan",
        key: "pan_number",
        width: 140,
        render: (text) => /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-sm uppercase", children: text }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 343,
          columnNumber: 23
        }, this)
      },
      {
        key: "action",
        width: 100,
        render: (_, record) => {
          let route = "#", tooltip = "";
          if (record.isLead) {
            route = `/reports/lead-report?lead_id=${record._id}`;
            tooltip = "View Lead";
          } else if (record.isAgent) {
            route = `/staff-menu/agent?agent_id=${record._id}`;
            tooltip = "View Agent";
          } else if (record.isEmployee) {
            route = `/staff-menu/employee-menu/employee?employee_id=${record._id}`;
            tooltip = "View Employee";
          } else if (record.isLoan || record.isPigmy) {
            const userId = record.user_id || record._id;
            route = `/customer-view?user_id=${userId}`;
            tooltip = "View Customer";
          } else {
            route = `/customer-view?user_id=${record._id}`;
            tooltip = "View Customer";
          }
          return /* @__PURE__ */ jsxDEV(Tooltip, { title: tooltip, children: /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(route), className: "flex items-center justify-center gap-1 px-3 py-1.5 rounded-md border border-gray-300 text-gray-700 hover:bg-violet-600 hover:text-white hover:shadow transition", children: [
            /* @__PURE__ */ jsxDEV(EyeOutlined, { className: "text-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 372,
              columnNumber: 15
            }, this),
            " ",
            /* @__PURE__ */ jsxDEV("span", { children: "View" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 372,
              columnNumber: 51
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 371,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 370,
            columnNumber: 9
          }, this);
        }
      }
    ],
    [navigate]
  );
  const debouncedSearchText = useDebounce(searchText, 300);
  const currentDataSource = useMemo(() => {
    if (activeTab === "customers") return tableUsers;
    if (activeTab === "leads") return tableLeads;
    if (activeTab === "agents") return tableAgents;
    if (activeTab === "employees") return tableEmployees;
    if (activeTab === "loans") return tableLoans;
    if (activeTab === "pigmy") return tablePigmy;
    return combinedData;
  }, [activeTab, tableUsers, tableLeads, tableAgents, tableEmployees, tableLoans, tablePigmy, combinedData]);
  const fuseInstance = useMemo(() => {
    if (!currentDataSource || currentDataSource.length === 0) return null;
    return new Fuse(currentDataSource, {
      includeScore: true,
      keys: searchableKeys,
      threshold: 0.5,
      ignoreFieldNorm: true
    });
  }, [currentDataSource, searchableKeys]);
  const rawSearchResults = useMemo(() => {
    if (!debouncedSearchText.trim() || !fuseInstance) return [];
    return fuseInstance.search(debouncedSearchText);
  }, [debouncedSearchText, fuseInstance]);
  const getProcessedResults = useCallback(() => {
    if (!debouncedSearchText.trim()) {
      return { mode: "all", dataSource: currentDataSource };
    }
    if (rawSearchResults.length === 0) {
      return { mode: "search", hasResults: false };
    }
    let exactMatches = rawSearchResults.filter((r) => r.score <= 0.1).map((r) => r.item);
    let relatedMatches = rawSearchResults.filter((r) => r.score > 0.1).map((r) => r.item);
    if (selectedExactMatch) {
      if (!exactMatches.find((m) => m._id === selectedExactMatch._id)) {
        exactMatches = [selectedExactMatch];
      }
      relatedMatches = relatedMatches.filter((item) => item._id !== selectedExactMatch._id);
    }
    return {
      mode: "search",
      exactMatches,
      relatedMatches,
      hasResults: true
    };
  }, [debouncedSearchText, currentDataSource, rawSearchResults, selectedExactMatch]);
  const handleFilterToggle = (id) => {
    setActiveFilters((prev) => prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]);
  };
  const renderContent = () => {
    if (isAnyApiLoading) {
      return /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-12", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, failure: false, data: "Records" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 446,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 446,
        columnNumber: 14
      }, this);
    }
    const searchState = getProcessedResults();
    if (searchState.mode === "all") {
      return /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV(Table, { pagination: { pageSize: 10, showSizeChanger: false, hideOnSinglePage: true }, scroll: { x: "max-content" }, columns, dataSource: searchState.dataSource, rowKey: "_id", size: "middle" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 455,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 454,
        columnNumber: 9
      }, this);
    }
    if (!searchState.hasResults) {
      return /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "inline-block p-3 rounded-full bg-gray-100 mb-3", children: /* @__PURE__ */ jsxDEV(SearchOutlined, { className: "text-xl text-gray-400" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 464,
          columnNumber: 75
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 464,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: [
          "No matches found in ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: activeTab === "all" ? "all records" : activeTab }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 465,
            columnNumber: 60
          }, this),
          "."
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 465,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 463,
        columnNumber: 9
      }, this);
    }
    let topRecord = null;
    let tableRecords = [];
    if (searchState.exactMatches.length > 0) {
      topRecord = searchState.exactMatches[0];
      tableRecords = [
        ...searchState.exactMatches.slice(1),
        ...searchState.relatedMatches
      ];
    } else if (searchState.relatedMatches.length > 0) {
      topRecord = searchState.relatedMatches[0];
      tableRecords = searchState.relatedMatches.slice(1);
    }
    const typeInfo = topRecord ? getTypeInfo(topRecord) : null;
    const approvalStatus = topRecord ? getApprovalStatus(topRecord) : null;
    return /* @__PURE__ */ jsxDEV("div", { children: [
      topRecord && /* @__PURE__ */ jsxDEV("div", { className: `mb-8 rounded-xl shadow-lg border-l-8 ${typeInfo.border} bg-white overflow-hidden`, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-6 flex flex-col md:flex-row md:items-center justify-between gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: `p-4 rounded-full ${typeInfo.bg} ${typeInfo.text} shadow-inner flex-shrink-0`, children: typeInfo.icon }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 497,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: `px-2.5 py-0.5 rounded text-xs font-bold uppercase tracking-wide ${typeInfo.bg} ${typeInfo.text}`, children: typeInfo.label }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                  lineNumber: 502,
                  columnNumber: 21
                }, this),
                searchState.exactMatches.includes(topRecord) && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full border border-green-200", children: "Exact Match" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                  lineNumber: 506,
                  columnNumber: 19
                }, this),
                approvalStatus && /* @__PURE__ */ jsxDEV(Tag, { icon: approvalStatus.text === "Approved" ? /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                  lineNumber: 511,
                  columnNumber: 67
                }, this) : /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                  lineNumber: 511,
                  columnNumber: 93
                }, this), color: approvalStatus.color, children: approvalStatus.text }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                  lineNumber: 511,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                lineNumber: 501,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800", children: topRecord.name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                lineNumber: 517,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:gap-6 mt-2 text-sm text-gray-600", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(IdcardOutlined, { className: "text-gray-400" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                    lineNumber: 520,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "ID: ",
                    topRecord.customer_id
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                    lineNumber: 521,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                  lineNumber: 519,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(PhoneOutlined, { className: "text-gray-400" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                    lineNumber: 524,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: topRecord.phone_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                    lineNumber: 525,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                  lineNumber: 523,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                lineNumber: 518,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 500,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 496,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              size: "large",
              icon: /* @__PURE__ */ jsxDEV(EyeOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
                lineNumber: 536,
                columnNumber: 23
              }, this),
              onClick: () => {
                let route = "#";
                if (topRecord.isLead) {
                  route = `/reports/lead-report?lead_id=${topRecord._id}`;
                } else if (topRecord.isAgent) {
                  route = `/staff-menu/agent?agent_id=${topRecord._id}`;
                } else if (topRecord.isEmployee) {
                  route = `/staff-menu/employee-menu/employee?employee_id=${topRecord._id}`;
                } else if (topRecord.isLoan || topRecord.isPigmy) {
                  const userId = topRecord.user_id || topRecord._id;
                  route = `/customer-view?user_id=${userId}`;
                } else {
                  route = `/customer-view?user_id=${topRecord._id}`;
                }
                navigate(route);
              },
              className: "h-12 px-6 rounded-lg shadow-md bg-violet-600 hover:bg-violet-700 border-none",
              children: "View Profile"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 533,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 532,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 493,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-6 py-3 border-t border-gray-100 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs text-gray-500", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block font-semibold text-gray-400", children: "Aadhaar" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 563,
              columnNumber: 17
            }, this),
            topRecord.aadhaar_number
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 562,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block font-semibold text-gray-400", children: "Pan" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 567,
              columnNumber: 17
            }, this),
            topRecord.pan_number
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 566,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block font-semibold text-gray-400", children: "Area" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 571,
              columnNumber: 17
            }, this),
            topRecord.collection_area
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 570,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block font-semibold text-gray-400", children: "Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 575,
              columnNumber: 17
            }, this),
            topRecord.customer_status || "Active"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 574,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 561,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 492,
        columnNumber: 9
      }, this),
      tableRecords.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-gray-700 font-semibold mb-4 text-lg border-l-4 border-gray-300 pl-3", children: "Other Results" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 585,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Table,
          {
            pagination: {
              ...pagination,
              showSizeChanger: true,
              showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`,
              onChange: (page, pageSize) => {
                setPagination({
                  current: page,
                  pageSize: pageSize || 50
                });
              },
              onShowSizeChange: (current, size) => {
                setPagination({
                  current: 1,
                  pageSize: 50
                });
              }
            },
            scroll: { x: "max-content" },
            columns,
            dataSource: tableRecords,
            rowKey: "_id",
            size: "middle",
            onRow: (record) => ({
              onClick: () => {
                setSelectedExactMatch(record);
              }
            }),
            rowClassName: () => "cursor-pointer hover:bg-gray-50 transition-all"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 588,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 584,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 489,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 628,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Navbar, { onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value), visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 629,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(CustomAlertDialog, { type: alertConfig.type, isVisible: alertConfig.visibility, message: alertConfig.message, onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false })) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 630,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-4 md:p-8 md:mr-11 pb-8", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl sm:text-3xl font-bold text-gray-500 mb-2", children: [
          "AI ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-violet-700", children: "Search" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 634,
            columnNumber: 82
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 634,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 max-w-2xl", children: "Professional search results prioritized by relevance." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 635,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 633,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "mb-6 shadow-sm border border-gray-200 rounded-xl", bodyStyle: { padding: "1.25rem" }, children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "relative w-full lg:w-1/3", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: "Search by ID, Name, Phone, Aadhaar, or Pan...",
              value: searchText,
              onChange: (e) => setSearchText(e.target.value),
              className: "w-full rounded-lg border border-gray-300 pl-12 pr-5 py-2.5 text-sm shadow-sm focus:border-violet-600 focus:ring-2 focus:ring-violet-200 outline-none transition",
              autoFocus: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
              lineNumber: 641,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(SearchOutlined, { className: "absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 649,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 640,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2.5 justify-center lg:justify-start", children: FILTERS_CONFIG.map((filter) => {
          const isActive = activeFilters.includes(filter.id);
          return /* @__PURE__ */ jsxDEV(Tooltip, { title: `Search by ${filter.filterName}`, placement: "top", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => handleFilterToggle(filter.id), className: `px-4 py-1.5 text-sm font-medium rounded-lg transition-all ${isActive ? "bg-violet-600 text-white shadow" : "bg-gray-100 text-gray-700 border border-gray-200 hover:bg-gray-200"}`, children: filter.filterName }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 656,
            columnNumber: 23
          }, this) }, filter.id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
            lineNumber: 655,
            columnNumber: 21
          }, this);
        }) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 651,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 639,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 638,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "shadow-md border border-gray-200 rounded-xl overflow-hidden", children: /* @__PURE__ */ jsxDEV(
        Tabs,
        {
          defaultActiveKey: "all",
          animated: false,
          size: "large",
          activeKey: activeTab,
          onChange: (key) => setActiveTab(key),
          items: [
            { key: "all", label: "All", children: renderContent() },
            { key: "customers", label: "Customers", children: renderContent() },
            { key: "leads", label: "Leads", children: renderContent() },
            { key: "agents", label: "Agents", children: renderContent() },
            { key: "employees", label: "Employees", children: renderContent() },
            { key: "loans", label: "Loans", children: renderContent() },
            // NEW
            { key: "pigmy", label: "Pigmy", children: renderContent() }
            // NEW
          ]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
          lineNumber: 667,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
        lineNumber: 666,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
      lineNumber: 632,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
    lineNumber: 627,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx",
    lineNumber: 626,
    columnNumber: 5
  }, this);
};
_s2(QuickSearch, "iQWHV04gEyj1s1cTKAgAxIMQpv4=", false, function() {
  return [useNavigate, useDebounce];
});
_c = QuickSearch;
export default QuickSearch;
var _c;
$RefreshReg$(_c, "QuickSearch");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearch.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNlNnSjs7QUE3U2hKLG9CQUFvQkEsNkJBQW1CQyxlQUFtQixnQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6RSxTQUFTQyxPQUFPQyxTQUFTQyxNQUFNQyxNQUFNQyxPQUFPQyxRQUFRQyxXQUFXO0FBQy9EO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLHFCQUFxQjtBQUM5QixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhQyxzQkFBc0I7QUFDNUMsT0FBT0MsWUFBWTtBQUduQixTQUFTQyxZQUFZQyxPQUFPQyxPQUFPO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJaEMsU0FBUzRCLEtBQUs7QUFDMURLLFlBQVUsTUFBTTtBQUNkLFVBQU1DLFVBQVVDLFdBQVcsTUFBTTtBQUMvQkgsd0JBQWtCSixLQUFLO0FBQUEsSUFDekIsR0FBR0MsS0FBSztBQUNSLFdBQU8sTUFBTTtBQUNYTyxtQkFBYUYsT0FBTztBQUFBLElBQ3RCO0FBQUEsRUFDRixHQUFHLENBQUNOLE9BQU9DLEtBQUssQ0FBQztBQUNqQixTQUFPRTtBQUNUO0FBRUFELEdBYlNILGFBQVc7QUFjcEIsTUFBTVUsaUJBQWlCO0FBQUEsRUFDckIsRUFBRUMsSUFBSSxLQUFLQyxZQUFZLE1BQU1DLEtBQUssY0FBYztBQUFBLEVBQ2hELEVBQUVGLElBQUksS0FBS0MsWUFBWSxRQUFRQyxLQUFLLE9BQU87QUFBQSxFQUMzQyxFQUFFRixJQUFJLEtBQUtDLFlBQVksU0FBU0MsS0FBSyxlQUFlO0FBQUEsRUFDcEQsRUFBRUYsSUFBSSxLQUFLQyxZQUFZLFdBQVdDLEtBQUssaUJBQWlCO0FBQUEsRUFDeEQsRUFBRUYsSUFBSSxLQUFLQyxZQUFZLE9BQU9DLEtBQUssYUFBYTtBQUFBLEVBQ2hEO0FBQUEsSUFDRUYsSUFBSTtBQUFBLElBQ0pDLFlBQVk7QUFBQSxJQUNaQyxLQUFLO0FBQUEsSUFDTEMsTUFBTXhCO0FBQUFBLEVBQ1I7QUFBQztBQUdILE1BQU15QixjQUFjQSxNQUFNO0FBQUFDLE1BQUE7QUFDeEIsUUFBTUMsV0FBV3JCLFlBQVk7QUFDN0IsUUFBTSxDQUFDc0IsV0FBV0MsWUFBWSxJQUFJOUMsU0FBUyxLQUFLO0FBR2hELFFBQU0sQ0FBQytDLFlBQVlDLGFBQWEsSUFBSWhELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNpRCxZQUFZQyxhQUFhLElBQUlsRCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUQsYUFBYUMsY0FBYyxJQUFJcEQsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3FELGdCQUFnQkMsaUJBQWlCLElBQUl0RCxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDdUQsWUFBWUMsYUFBYSxJQUFJeEQsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3lELFlBQVlDLGFBQWEsSUFBSTFELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMyRCxvQkFBb0JDLHFCQUFxQixJQUFJNUQsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQzZELGVBQWVDLGdCQUFnQixJQUFJOUQsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQytELFlBQVlDLGFBQWEsSUFBSWhFLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNpRSxlQUFlQyxnQkFBZ0IsSUFBSWxFLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNtRSxZQUFZQyxhQUFhLElBQUlwRSxTQUFTO0FBQUEsSUFDM0NxRSxTQUFTO0FBQUEsSUFDVEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUVELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJeEUsU0FBUztBQUFBLElBQzdDeUUsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUk3RSxTQUFTO0FBQUEsSUFDM0M4RSxPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLElBQ1BDLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsSUFDWEMsT0FBTztBQUFBO0FBQUEsSUFDUEMsT0FBTztBQUFBO0FBQUEsRUFDVCxDQUFDO0FBRUQsUUFBTUMsa0JBQWtCQyxPQUFPQyxPQUFPVixVQUFVLEVBQUVXLEtBQUssQ0FBQ0MsWUFBWUEsT0FBTztBQUMzRSxRQUFNQyxrQkFBa0JDLE9BQU8sS0FBSztBQUNwQyxRQUFNQyxrQkFBa0JELE9BQU8sS0FBSztBQUNwQyxRQUFNRSxrQkFBa0JGLE9BQU8sS0FBSztBQUdwQyxRQUFNRyxrQkFBa0I1RixZQUFZLENBQUM2RixTQUFTTixZQUFZO0FBQ3hEWCxrQkFBYyxDQUFDa0IsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsT0FBTyxHQUFHTixRQUFRLEVBQUU7QUFBQSxFQUMzRCxHQUFHLEVBQUU7QUFHTHZELFlBQVUsTUFBTTtBQUNkLFVBQU0rRCxhQUFhLFlBQVk7QUFDN0JILHNCQUFnQixTQUFTLElBQUk7QUFDN0IsVUFBSTtBQUNGLGNBQU1JLFdBQVcsTUFBTTlFLElBQUkrRSxJQUFJLGdCQUFnQjtBQUMvQyxjQUFNQyxZQUFZRixTQUFTRyxLQUFLQyxJQUFJLENBQUNDLEdBQUdDLE9BQU87QUFBQSxVQUM3Q0MsS0FBS0YsRUFBRUU7QUFBQUEsVUFDUGxFLElBQUlpRSxJQUFJO0FBQUEsVUFDUkUsTUFBTUgsRUFBRUk7QUFBQUEsVUFDUkMsY0FBY0wsRUFBRUs7QUFBQUEsVUFDaEJDLFNBQVNOLEVBQUVNO0FBQUFBLFVBQ1hDLFNBQVNQLEVBQUVPO0FBQUFBLFVBQ1hDLGFBQWFSLEVBQUVRO0FBQUFBLFVBQ2ZDLGlCQUFpQlQsRUFBRVMsaUJBQWlCQztBQUFBQSxVQUNwQ0MsZ0JBQWdCWCxFQUFFWSxhQUFhO0FBQUEsVUFDL0JDLFlBQVliLEVBQUVjLFVBQVU7QUFBQSxVQUN4QkMsWUFBWTtBQUFBLFVBQ1pDLGlCQUFpQmhCLEVBQUVnQjtBQUFBQSxRQUNyQixFQUFFO0FBQ0Z0RSxzQkFBY21ELFNBQVM7QUFBQSxNQUN6QixTQUFTb0IsT0FBTztBQUFFQyxnQkFBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxNQUFHLFVBQUM7QUFDeEQxQix3QkFBZ0IsU0FBUyxLQUFLO0FBQUEsTUFBRztBQUFBLElBQzdDO0FBQ0FHLGVBQVc7QUFBQSxFQUNiLEdBQUcsQ0FBQ25DLGVBQWVnQyxlQUFlLENBQUM7QUFHbkM1RCxZQUFVLE1BQU07QUFDZCxRQUFJWSxjQUFjLFFBQVM7QUFDM0IsUUFBSTRDLGdCQUFnQnBCLFFBQVM7QUFFN0IsVUFBTW9ELGFBQWEsWUFBWTtBQUM3QmhDLHNCQUFnQnBCLFVBQVU7QUFDMUJ3QixzQkFBZ0IsU0FBUyxJQUFJO0FBQzdCLFVBQUk7QUFDRixjQUFNSSxXQUFXLE1BQU05RSxJQUFJK0UsSUFBSSx5QkFBeUI7QUFDeEQsY0FBTUMsWUFBWUYsU0FBU0csTUFBTUMsSUFBSSxDQUFDcUIsR0FBR25CLE9BQU87QUFBQSxVQUM5Q0MsS0FBS2tCLEVBQUVsQjtBQUFBQSxVQUNQbEUsSUFBSWlFLElBQUk7QUFBQSxVQUNSRSxNQUFNaUIsRUFBRUMsYUFBYTtBQUFBLFVBQ3JCaEIsY0FBY2UsRUFBRUUsY0FBYztBQUFBLFVBQzlCaEIsU0FBU2MsRUFBRUcsZ0JBQWdCO0FBQUEsVUFDM0JoQixTQUFTYSxFQUFFYixXQUFXO0FBQUEsVUFDdEJDLGFBQWFZLEVBQUVJO0FBQUFBLFVBQ2ZmLGlCQUFpQlcsRUFBRUssVUFBVUMsY0FBYztBQUFBLFVBQzNDQyxpQkFBaUI7QUFBQSxVQUNqQmhCLGdCQUFnQlMsRUFBRVIsYUFBYVEsRUFBRVEsZ0JBQWdCO0FBQUEsVUFDakRmLFlBQVlPLEVBQUVOLFVBQVVNLEVBQUVTLFlBQVk7QUFBQSxVQUN0Q0MsUUFBUTtBQUFBLFVBQ1JDLFdBQVcsUUFBUVgsRUFBRWxCLEdBQUc7QUFBQSxRQUMxQixFQUFFO0FBQ0Z0RCxzQkFBY2lELFNBQVM7QUFBQSxNQUN6QixTQUFTb0IsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUM5Qix3QkFBZ0JwQixVQUFVO0FBQUEsTUFDNUIsVUFBQztBQUNDd0Isd0JBQWdCLFNBQVMsS0FBSztBQUFBLE1BQ2hDO0FBQUEsSUFDRjtBQUNBNEIsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDNUUsV0FBV2dELGVBQWUsQ0FBQztBQUcvQjVELFlBQVUsTUFBTTtBQUNkLFFBQUlZLGNBQWMsUUFBUztBQUMzQixRQUFJOEMsZ0JBQWdCdEIsUUFBUztBQUU3QixVQUFNaUUsYUFBYSxZQUFZO0FBQzdCM0Msc0JBQWdCdEIsVUFBVTtBQUMxQndCLHNCQUFnQixTQUFTLElBQUk7QUFDN0IsVUFBSTtBQUVGLGNBQU1JLFdBQVcsTUFBTTlFLElBQUkrRSxJQUFJLDRDQUE0QztBQUMzRSxjQUFNQyxhQUFhRixTQUFTRyxNQUFNQSxRQUFRLElBQUlDLElBQUksQ0FBQ3FCLEdBQUduQixPQUFPO0FBQUEsVUFDM0RDLEtBQUtrQixFQUFFbEI7QUFBQUE7QUFBQUEsVUFDUGxFLElBQUlpRSxJQUFJO0FBQUEsVUFDUk8sYUFBYVksRUFBRWEsVUFBVXpCLGVBQWU7QUFBQSxVQUN4Q0wsTUFBTWlCLEVBQUVhLFVBQVU3QixhQUFhO0FBQUEsVUFDL0JDLGNBQWNlLEVBQUVhLFVBQVU1QixnQkFBZ0I7QUFBQSxVQUMxQ00sZ0JBQWdCO0FBQUE7QUFBQSxVQUNoQkUsWUFBWTtBQUFBO0FBQUEsVUFDWkosaUJBQWlCO0FBQUE7QUFBQSxVQUNqQmtCLGlCQUFpQjtBQUFBLFVBQ2pCTyxRQUFRO0FBQUEsVUFDUkMsU0FBU2YsRUFBRWEsVUFBVS9CLE9BQU9rQixFQUFFbEI7QUFBQUE7QUFBQUEsUUFDaEMsRUFBRTtBQUNGaEQsc0JBQWMyQyxTQUFTO0FBQUEsTUFDekIsU0FBU29CLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDNUIsd0JBQWdCdEIsVUFBVTtBQUFBLE1BQzVCLFVBQUM7QUFDQ3dCLHdCQUFnQixTQUFTLEtBQUs7QUFBQSxNQUNoQztBQUFBLElBQ0Y7QUFDQXlDLGVBQVc7QUFBQSxFQUNiLEdBQUcsQ0FBQ3pGLFdBQVdnRCxlQUFlLENBQUM7QUFHL0I1RCxZQUFVLE1BQU07QUFDZCxRQUFJWSxjQUFjLFFBQVM7QUFDM0IsUUFBSStDLGdCQUFnQnZCLFFBQVM7QUFFN0IsVUFBTXFFLGFBQWEsWUFBWTtBQUM3QjlDLHNCQUFnQnZCLFVBQVU7QUFDMUJ3QixzQkFBZ0IsU0FBUyxJQUFJO0FBQzdCLFVBQUk7QUFDRixjQUFNSSxXQUFXLE1BQU05RSxJQUFJK0UsSUFBSSxnQ0FBZ0M7QUFDL0QsY0FBTUMsYUFBYUYsU0FBU0csUUFBUSxJQUFJQyxJQUFJLENBQUNzQyxHQUFHcEMsT0FBTztBQUFBLFVBQ3JEQyxLQUFLbUMsRUFBRW5DO0FBQUFBLFVBQ1BsRSxJQUFJaUUsSUFBSTtBQUFBLFVBQ1JPLGFBQWE2QixFQUFFQyxVQUFVOUIsZUFBZTtBQUFBLFVBQ3hDTCxNQUFNa0MsRUFBRUMsVUFBVWxDLGFBQWE7QUFBQSxVQUMvQkMsY0FBY2dDLEVBQUVDLFVBQVVqQyxnQkFBZ0I7QUFBQSxVQUMxQ00sZ0JBQWdCMEIsRUFBRUMsVUFBVTFCLGFBQWE7QUFBQSxVQUN6Q0MsWUFBWXdCLEVBQUVDLFVBQVV4QixVQUFVO0FBQUEsVUFDbENMLGlCQUFpQjtBQUFBO0FBQUEsVUFDakJrQixpQkFBaUI7QUFBQSxVQUNqQlksU0FBUztBQUFBLFVBQ1RKLFNBQVNFLEVBQUVDLFVBQVVwQyxPQUFPbUMsRUFBRW5DO0FBQUFBLFFBQ2hDLEVBQUU7QUFDRjlDLHNCQUFjeUMsU0FBUztBQUFBLE1BQ3pCLFNBQVNvQixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUM1QzNCLHdCQUFnQnZCLFVBQVU7QUFBQSxNQUM1QixVQUFDO0FBQ0N3Qix3QkFBZ0IsU0FBUyxLQUFLO0FBQUEsTUFDaEM7QUFBQSxJQUNGO0FBQ0E2QyxlQUFXO0FBQUEsRUFDYixHQUFHLENBQUM3RixXQUFXZ0QsZUFBZSxDQUFDO0FBRy9CNUQsWUFBVSxNQUFNO0FBQ2QsVUFBTTZHLGNBQWMsWUFBWTtBQUM5QmpELHNCQUFnQixVQUFVLElBQUk7QUFDOUIsVUFBSTtBQUNGLGNBQU1JLFdBQVcsTUFBTTlFLElBQUkrRSxJQUFJLFlBQVk7QUFDM0MsY0FBTUMsYUFBYUYsU0FBU0csTUFBTTJDLFNBQVMsSUFBSTFDLElBQUksQ0FBQzJDLEdBQUd6QyxPQUFPO0FBQUEsVUFDNURDLEtBQUt3QyxFQUFFeEM7QUFBQUEsVUFBS2xFLElBQUlpRSxJQUFJO0FBQUEsVUFBR0UsTUFBTXVDLEVBQUV2QyxRQUFRO0FBQUEsVUFBS0UsY0FBY3FDLEVBQUVyQyxnQkFBZ0I7QUFBQSxVQUM1RUMsU0FBU29DLEVBQUVwQyxXQUFXO0FBQUEsVUFBS0MsU0FBU21DLEVBQUVuQyxXQUFXO0FBQUEsVUFBS0MsYUFBYWtDLEVBQUVDO0FBQUFBLFVBQ3JFbEMsaUJBQWlCaUMsRUFBRUUsZ0JBQWdCQyxTQUFTO0FBQUEsVUFBS2xCLGlCQUFpQjtBQUFBLFVBQ2xFaEIsZ0JBQWdCK0IsRUFBRTlCLGFBQWE7QUFBQSxVQUFLQyxZQUFZNkIsRUFBRTVCLFVBQVU7QUFBQSxVQUFLZ0MsU0FBUztBQUFBLFFBQzVFLEVBQUU7QUFDRmhHLHVCQUFlK0MsU0FBUztBQUFBLE1BQzFCLFNBQVNvQixPQUFPO0FBQUVDLGdCQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUFBLE1BQUcsVUFBQztBQUN6RDFCLHdCQUFnQixVQUFVLEtBQUs7QUFBQSxNQUFHO0FBQUEsSUFDOUM7QUFDQWlELGdCQUFZO0FBQUEsRUFDZCxHQUFHLENBQUNqRixlQUFlZ0MsZUFBZSxDQUFDO0FBRW5DNUQsWUFBVSxNQUFNO0FBQ2QsVUFBTW9ILGlCQUFpQixZQUFZO0FBQ2pDeEQsc0JBQWdCLGFBQWEsSUFBSTtBQUNqQyxVQUFJO0FBQ0YsY0FBTUksV0FBVyxNQUFNOUUsSUFBSStFLElBQUkscUJBQXFCO0FBQ3BELGNBQU1DLGFBQWFGLFNBQVNHLE1BQU1rRCxZQUFZLElBQUlqRCxJQUFJLENBQUNrRCxHQUFHaEQsT0FBTztBQUFBLFVBQy9EQyxLQUFLK0MsRUFBRS9DO0FBQUFBLFVBQUtsRSxJQUFJaUUsSUFBSTtBQUFBLFVBQUdFLE1BQU04QyxFQUFFOUMsUUFBUTtBQUFBLFVBQUtFLGNBQWM0QyxFQUFFNUMsZ0JBQWdCO0FBQUEsVUFDNUVDLFNBQVMyQyxFQUFFM0MsV0FBVztBQUFBLFVBQUtDLFNBQVMwQyxFQUFFMUMsV0FBVztBQUFBLFVBQUtDLGFBQWF5QyxFQUFFTjtBQUFBQSxVQUNyRWxDLGlCQUFpQndDLEVBQUVMLGdCQUFnQkMsU0FBUztBQUFBLFVBQUtsQixpQkFBaUI7QUFBQSxVQUNsRWhCLGdCQUFnQnNDLEVBQUVyQyxhQUFhO0FBQUEsVUFBS0MsWUFBWW9DLEVBQUVuQyxVQUFVO0FBQUEsVUFBS29DLFlBQVk7QUFBQSxRQUMvRSxFQUFFO0FBQ0ZsRywwQkFBa0I2QyxTQUFTO0FBQUEsTUFDN0IsU0FBU29CLE9BQU87QUFBRUMsZ0JBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFBRyxVQUFDO0FBQzVEMUIsd0JBQWdCLGFBQWEsS0FBSztBQUFBLE1BQUc7QUFBQSxJQUNqRDtBQUNBd0QsbUJBQWU7QUFBQSxFQUNqQixHQUFHLENBQUN4RixlQUFlZ0MsZUFBZSxDQUFDO0FBRW5DNUQsWUFBVSxNQUFNO0FBQUUyQiwwQkFBc0IsSUFBSTtBQUFBLEVBQUcsR0FBRyxDQUFDRyxVQUFVLENBQUM7QUFLOUQsUUFBTTBGLGVBQWVDLFFBQVEsTUFBTTtBQUNqQyxVQUFNQyxtQkFBbUIsSUFBSUMsSUFBSTdHLFdBQVdzRCxJQUFJLENBQUF3RCxTQUFRQSxLQUFLbEQsWUFBWSxDQUFDO0FBQzFFLFVBQU1tRCxpQkFBaUIsb0JBQUlDLElBQUk7QUFFL0I5RyxlQUFXK0csUUFBUSxDQUFBQyxTQUFRO0FBQ3pCLFVBQUlOLGlCQUFpQk8sSUFBSUQsS0FBS3RELFlBQVksRUFBRztBQUM3QyxVQUFJLENBQUNtRCxlQUFlSSxJQUFJRCxLQUFLdEQsWUFBWSxHQUFHO0FBQzFDbUQsdUJBQWVLLElBQUlGLEtBQUt0RCxjQUFjc0QsSUFBSTtBQUFBLE1BQzVDO0FBQUEsSUFDRixDQUFDO0FBRUQsVUFBTUcsYUFBYUMsTUFBTUMsS0FBS1IsZUFBZXhFLE9BQU8sQ0FBQztBQUNyRCxXQUFPO0FBQUEsTUFDTCxHQUFHdkM7QUFBQUEsTUFDSCxHQUFHcUg7QUFBQUEsTUFDSCxHQUFHakg7QUFBQUEsTUFDSCxHQUFHRTtBQUFBQSxNQUNILEdBQUdFO0FBQUFBO0FBQUFBLE1BQ0gsR0FBR0U7QUFBQUE7QUFBQUEsSUFBZTtBQUFBLEVBRXRCLEdBQUcsQ0FBQ1YsWUFBWUUsWUFBWUUsYUFBYUUsZ0JBQWdCRSxZQUFZRSxVQUFVLENBQUM7QUFFaEYsUUFBTThHLGlCQUFpQmIsUUFBUSxNQUFNO0FBQ25DLFFBQUl6RixjQUFjdUcsU0FBUyxHQUFHO0FBQzVCLGFBQU9uSSxlQUFlb0ksT0FBTyxDQUFBQyxNQUFLekcsY0FBYzBHLFNBQVNELEVBQUVwSSxFQUFFLENBQUMsRUFBRStELElBQUksQ0FBQXFFLE1BQUtBLEVBQUVsSSxHQUFHO0FBQUEsSUFDaEY7QUFDQSxXQUFPSCxlQUFlZ0UsSUFBSSxDQUFBcUUsTUFBS0EsRUFBRWxJLEdBQUc7QUFBQSxFQUN0QyxHQUFHLENBQUN5QixhQUFhLENBQUM7QUFHbEIsUUFBTTJHLGNBQWNBLENBQUNDLFdBQVc7QUFDOUIsUUFBSUEsT0FBT3pDLE9BQVEsUUFBTyxFQUFFMEMsT0FBTyxRQUFRQyxPQUFPLFVBQVVDLElBQUksZ0JBQWdCQyxRQUFRLHFCQUFxQkMsTUFBTSxtQkFBbUJ6SSxNQUFNLHVCQUFDLHNCQUFtQixXQUFVLGNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0MsRUFBSTtBQUN4TCxRQUFJb0ksT0FBT3pCLFFBQVMsUUFBTyxFQUFFMEIsT0FBTyxTQUFTQyxPQUFPLFVBQVVDLElBQUksZ0JBQWdCQyxRQUFRLHFCQUFxQkMsTUFBTSxtQkFBbUJ6SSxNQUFNLHVCQUFDLGdCQUFhLFdBQVUsY0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQyxFQUFJO0FBQ3BMLFFBQUlvSSxPQUFPckIsV0FBWSxRQUFPLEVBQUVzQixPQUFPLFlBQVlDLE9BQU8sUUFBUUMsSUFBSSxjQUFjQyxRQUFRLG1CQUFtQkMsTUFBTSxpQkFBaUJ6SSxNQUFNLHVCQUFDLDZCQUEwQixXQUFVLGNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0MsRUFBSTtBQUMvTCxRQUFJb0ksT0FBT3hELFdBQVksUUFBTyxFQUFFeUQsT0FBTyxZQUFZQyxPQUFPLFFBQVFDLElBQUksY0FBY0MsUUFBUSxtQkFBbUJDLE1BQU0saUJBQWlCekksTUFBTSx1QkFBQyxnQkFBYSxXQUFVLGNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0MsRUFBSTtBQUNsTCxRQUFJb0ksT0FBT3JDLE9BQVEsUUFBTyxFQUFFc0MsT0FBTyxRQUFRQyxPQUFPLFNBQVNDLElBQUksZUFBZUMsUUFBUSxvQkFBb0JDLE1BQU0sa0JBQWtCekksTUFBTSx1QkFBQyxrQkFBZSxXQUFVLGNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0MsRUFBSTtBQUNoTCxRQUFJb0ksT0FBT2hDLFFBQVMsUUFBTyxFQUFFaUMsT0FBTyxTQUFTQyxPQUFPLFFBQVFDLElBQUksZ0JBQWdCQyxRQUFRLHFCQUFxQkMsTUFBTSxtQkFBbUJ6SSxNQUFNLHVCQUFDLGtCQUFlLFdBQVUsY0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQyxFQUFJO0FBQ3BMLFdBQU8sRUFBRXFJLE9BQU8sV0FBV0MsT0FBTyxXQUFXQyxJQUFJLGNBQWNDLFFBQVEsbUJBQW1CQyxNQUFNLGlCQUFpQnpJLE1BQU0sdUJBQUMsa0JBQWUsV0FBVSxjQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9DLEVBQUk7QUFBQSxFQUNqSztBQUVBLFFBQU0wSSxvQkFBb0JBLENBQUNOLFdBQVc7QUFDcEMsUUFBSSxDQUFDQSxPQUFPeEQsV0FBWSxRQUFPO0FBQy9CLFFBQUl3RCxPQUFPdkQsb0JBQW9CLE9BQVEsUUFBTyxFQUFFNEQsTUFBTSxZQUFZSCxPQUFPLFVBQVU7QUFDbkYsUUFBSUYsT0FBT3ZELG9CQUFvQixRQUFTLFFBQU8sRUFBRTRELE1BQU0sV0FBV0gsT0FBTyxVQUFVO0FBQ25GLFdBQU8sRUFBRUcsTUFBTSxZQUFZSCxPQUFPLFVBQVU7QUFBQSxFQUM5QztBQUdBLFFBQU1LLFVBQVUxQjtBQUFBQSxJQUFRLE1BQU07QUFBQSxNQUM1QjtBQUFBLFFBQ0VQLE9BQU87QUFBQSxRQUNQM0csS0FBSztBQUFBLFFBQ0w2SSxPQUFPO0FBQUEsUUFDUEMsT0FBTztBQUFBLFFBQ1BDLFFBQVFBLENBQUNDLEdBQUdDLElBQUlDLFVBQVVBLFFBQVE7QUFBQSxNQUNwQztBQUFBLE1BQ0E7QUFBQSxRQUNFdkMsT0FBTztBQUFBLFFBQVEzRyxLQUFLO0FBQUEsUUFBUTZJLE9BQU87QUFBQSxRQUNuQ0UsUUFBUUEsQ0FBQ0MsR0FBR1gsV0FBVztBQUNyQixnQkFBTWMsT0FBT2YsWUFBWUMsTUFBTTtBQUMvQixpQkFBTyx1QkFBQyxPQUFJLE9BQU9jLEtBQUtaLE9BQVFZLGVBQUtiLFNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9DO0FBQUEsUUFDN0M7QUFBQSxNQUNGO0FBQUEsTUFDQSxFQUFFYyxXQUFXLGVBQWV6QyxPQUFPLE1BQU0zRyxLQUFLLGVBQWU2SSxPQUFPLElBQUk7QUFBQSxNQUN4RSxFQUFFTyxXQUFXLFFBQVF6QyxPQUFPLFFBQVEzRyxLQUFLLFFBQVE2SSxPQUFPLElBQUk7QUFBQSxNQUM1RCxFQUFFTyxXQUFXLGdCQUFnQnpDLE9BQU8sU0FBUzNHLEtBQUssZ0JBQWdCNkksT0FBTyxJQUFJO0FBQUEsTUFDN0U7QUFBQSxRQUNFTyxXQUFXO0FBQUEsUUFBa0J6QyxPQUFPO0FBQUEsUUFBVzNHLEtBQUs7QUFBQSxRQUFrQjZJLE9BQU87QUFBQSxRQUM3RUUsUUFBUUEsQ0FBQ0wsU0FBUyx1QkFBQyxVQUFLLFdBQVUscUJBQXFCQSxrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLE1BQzlEO0FBQUEsTUFDQTtBQUFBLFFBQ0VVLFdBQVc7QUFBQSxRQUFjekMsT0FBTztBQUFBLFFBQU8zRyxLQUFLO0FBQUEsUUFBYzZJLE9BQU87QUFBQSxRQUNqRUUsUUFBUUEsQ0FBQ0wsU0FBUyx1QkFBQyxVQUFLLFdBQVUsK0JBQStCQSxrQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLE1BQ3hFO0FBQUEsTUFDQTtBQUFBLFFBQ0UxSSxLQUFLO0FBQUEsUUFBVTZJLE9BQU87QUFBQSxRQUN0QkUsUUFBUUEsQ0FBQ0MsR0FBR1gsV0FBVztBQUNyQixjQUFJZ0IsUUFBUSxLQUFLQyxVQUFVO0FBQzNCLGNBQUlqQixPQUFPekMsUUFBUTtBQUNqQnlELG9CQUFRLGdDQUFnQ2hCLE9BQU9yRSxHQUFHO0FBQ2xEc0Ysc0JBQVU7QUFBQSxVQUNaLFdBQVdqQixPQUFPekIsU0FBUztBQUN6QnlDLG9CQUFRLDhCQUE4QmhCLE9BQU9yRSxHQUFHO0FBQ2hEc0Ysc0JBQVU7QUFBQSxVQUNaLFdBQVdqQixPQUFPckIsWUFBWTtBQUM1QnFDLG9CQUFRLGtEQUFrRGhCLE9BQU9yRSxHQUFHO0FBQ3BFc0Ysc0JBQVU7QUFBQSxVQUNaLFdBQVdqQixPQUFPckMsVUFBVXFDLE9BQU9oQyxTQUFTO0FBRTFDLGtCQUFNa0QsU0FBU2xCLE9BQU9wQyxXQUFXb0MsT0FBT3JFO0FBQ3hDcUYsb0JBQVEsMEJBQTBCRSxNQUFNO0FBQ3hDRCxzQkFBVTtBQUFBLFVBQ1osT0FBTztBQUVMRCxvQkFBUSwwQkFBMEJoQixPQUFPckUsR0FBRztBQUM1Q3NGLHNCQUFVO0FBQUEsVUFDWjtBQUVBLGlCQUNFLHVCQUFDLFdBQVEsT0FBT0EsU0FDZCxpQ0FBQyxZQUFPLFNBQVMsTUFBTWxKLFNBQVNpSixLQUFLLEdBQUcsV0FBVSxtS0FDaEQ7QUFBQSxtQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxZQUFHO0FBQUEsWUFBQyx1QkFBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVU7QUFBQSxlQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFFBRUo7QUFBQSxNQUNGO0FBQUEsSUFBQztBQUFBLElBQ0EsQ0FBQ2pKLFFBQVE7QUFBQSxFQUFDO0FBSWIsUUFBTW9KLHNCQUFzQnJLLFlBQVlvQyxZQUFZLEdBQUc7QUFHdkQsUUFBTWtJLG9CQUFvQnZDLFFBQVEsTUFBTTtBQUN0QyxRQUFJN0csY0FBYyxZQUFhLFFBQU9FO0FBQ3RDLFFBQUlGLGNBQWMsUUFBUyxRQUFPSTtBQUNsQyxRQUFJSixjQUFjLFNBQVUsUUFBT007QUFDbkMsUUFBSU4sY0FBYyxZQUFhLFFBQU9RO0FBQ3RDLFFBQUlSLGNBQWMsUUFBUyxRQUFPVTtBQUNsQyxRQUFJVixjQUFjLFFBQVMsUUFBT1k7QUFDbEMsV0FBT2dHO0FBQUFBLEVBQ1QsR0FBRyxDQUFDNUcsV0FBV0UsWUFBWUUsWUFBWUUsYUFBYUUsZ0JBQWdCRSxZQUFZRSxZQUFZZ0csWUFBWSxDQUFDO0FBR3pHLFFBQU15QyxlQUFleEMsUUFBUSxNQUFNO0FBQ2pDLFFBQUksQ0FBQ3VDLHFCQUFxQkEsa0JBQWtCekIsV0FBVyxFQUFHLFFBQU87QUFDakUsV0FBTyxJQUFJbEosS0FBSzJLLG1CQUFtQjtBQUFBLE1BQ2pDRSxjQUFjO0FBQUEsTUFDZEMsTUFBTTdCO0FBQUFBLE1BQ044QixXQUFXO0FBQUEsTUFDWEMsaUJBQWlCO0FBQUEsSUFDbkIsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDTCxtQkFBbUIxQixjQUFjLENBQUM7QUFFdEMsUUFBTWdDLG1CQUFtQjdDLFFBQVEsTUFBTTtBQUNyQyxRQUFJLENBQUNzQyxvQkFBb0JRLEtBQUssS0FBSyxDQUFDTixhQUFjLFFBQU87QUFDekQsV0FBT0EsYUFBYU8sT0FBT1QsbUJBQW1CO0FBQUEsRUFDaEQsR0FBRyxDQUFDQSxxQkFBcUJFLFlBQVksQ0FBQztBQUV0QyxRQUFNUSxzQkFBc0J6TSxZQUFZLE1BQU07QUFDNUMsUUFBSSxDQUFDK0wsb0JBQW9CUSxLQUFLLEdBQUc7QUFDL0IsYUFBTyxFQUFFRyxNQUFNLE9BQU9DLFlBQVlYLGtCQUFrQjtBQUFBLElBQ3REO0FBRUEsUUFBSU0saUJBQWlCL0IsV0FBVyxHQUFHO0FBQ2pDLGFBQU8sRUFBRW1DLE1BQU0sVUFBVUUsWUFBWSxNQUFNO0FBQUEsSUFDN0M7QUFFQSxRQUFJQyxlQUFlUCxpQkFBaUI5QixPQUFPLENBQUFzQyxNQUFLQSxFQUFFQyxTQUFTLEdBQUcsRUFBRTNHLElBQUksQ0FBQTBHLE1BQUtBLEVBQUVFLElBQUk7QUFDL0UsUUFBSUMsaUJBQWlCWCxpQkFBaUI5QixPQUFPLENBQUFzQyxNQUFLQSxFQUFFQyxRQUFRLEdBQUcsRUFBRTNHLElBQUksQ0FBQTBHLE1BQUtBLEVBQUVFLElBQUk7QUFFaEYsUUFBSXRKLG9CQUFvQjtBQUN0QixVQUFJLENBQUNtSixhQUFhSyxLQUFLLENBQUFDLE1BQUtBLEVBQUU1RyxRQUFRN0MsbUJBQW1CNkMsR0FBRyxHQUFHO0FBQzdEc0csdUJBQWUsQ0FBQ25KLGtCQUFrQjtBQUFBLE1BQ3BDO0FBQ0F1Six1QkFBaUJBLGVBQWV6QyxPQUFPLENBQUN3QyxTQUFTQSxLQUFLekcsUUFBUTdDLG1CQUFtQjZDLEdBQUc7QUFBQSxJQUN0RjtBQUVBLFdBQU87QUFBQSxNQUNMbUcsTUFBTTtBQUFBLE1BQ05HO0FBQUFBLE1BQ0FJO0FBQUFBLE1BQ0FMLFlBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLENBQUNiLHFCQUFxQkMsbUJBQW1CTSxrQkFBa0I1SSxrQkFBa0IsQ0FBQztBQUVqRixRQUFNMEoscUJBQXFCQSxDQUFDL0ssT0FBTztBQUNqQzRCLHFCQUFpQixDQUFDNkIsU0FBU0EsS0FBSzRFLFNBQVNySSxFQUFFLElBQUl5RCxLQUFLMEUsT0FBTyxDQUFDQyxNQUFNQSxNQUFNcEksRUFBRSxJQUFJLENBQUMsR0FBR3lELE1BQU16RCxFQUFFLENBQUM7QUFBQSxFQUM3RjtBQUlBLFFBQU1nTCxnQkFBZ0JBLE1BQU07QUFDMUIsUUFBSWxJLGlCQUFpQjtBQUNuQixhQUFPLHVCQUFDLFNBQUksV0FBVSw2QkFBNEIsaUNBQUMsa0JBQWUsV0FBVyxNQUFNLFNBQVMsT0FBTyxNQUFLLGFBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0QsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RztBQUFBLElBQ3RIO0FBRUEsVUFBTW1JLGNBQWNiLG9CQUFvQjtBQUd4QyxRQUFJYSxZQUFZWixTQUFTLE9BQU87QUFDOUIsYUFDRSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsU0FBTSxZQUFZLEVBQUVySSxVQUFVLElBQUlrSixpQkFBaUIsT0FBT0Msa0JBQWtCLEtBQUssR0FBRyxRQUFRLEVBQUVDLEdBQUcsY0FBYyxHQUFHLFNBQWtCLFlBQVlILFlBQVlYLFlBQVksUUFBTyxPQUFNLE1BQUssWUFBM0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtTSxLQURyTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUVKO0FBR0EsUUFBSSxDQUFDVyxZQUFZVixZQUFZO0FBQzNCLGFBQ0UsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGtEQUFpRCxpQ0FBQyxrQkFBZSxXQUFVLDJCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlELEtBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0g7QUFBQSxRQUNwSCx1QkFBQyxPQUFFLFdBQVUsaUJBQWdCO0FBQUE7QUFBQSxVQUFvQix1QkFBQyxVQUFLLFdBQVUsZUFBZWhLLHdCQUFjLFFBQVEsZ0JBQWdCQSxhQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQU87QUFBQSxhQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdJO0FBQUEsV0FGMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsSUFFSjtBQUdBLFFBQUk4SyxZQUFZO0FBQ2hCLFFBQUlDLGVBQWU7QUFFbkIsUUFBSUwsWUFBWVQsYUFBYXRDLFNBQVMsR0FBRztBQUN2Q21ELGtCQUFZSixZQUFZVCxhQUFhLENBQUM7QUFDdENjLHFCQUFlO0FBQUEsUUFDYixHQUFHTCxZQUFZVCxhQUFhZSxNQUFNLENBQUM7QUFBQSxRQUNuQyxHQUFHTixZQUFZTDtBQUFBQSxNQUFjO0FBQUEsSUFFakMsV0FBV0ssWUFBWUwsZUFBZTFDLFNBQVMsR0FBRztBQUNoRG1ELGtCQUFZSixZQUFZTCxlQUFlLENBQUM7QUFDeENVLHFCQUFlTCxZQUFZTCxlQUFlVyxNQUFNLENBQUM7QUFBQSxJQUNuRDtBQUVBLFVBQU1DLFdBQVdILFlBQVkvQyxZQUFZK0MsU0FBUyxJQUFJO0FBQ3RELFVBQU1JLGlCQUFpQkosWUFBWXhDLGtCQUFrQndDLFNBQVMsSUFBSTtBQUVsRSxXQUNFLHVCQUFDLFNBRUVBO0FBQUFBLG1CQUNDLHVCQUFDLFNBQUksV0FBVyx3Q0FBd0NHLFNBQVM3QyxNQUFNLDZCQUNyRTtBQUFBLCtCQUFDLFNBQUksV0FBVSx1RUFHYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVyxvQkFBb0I2QyxTQUFTOUMsRUFBRSxJQUFJOEMsU0FBUzVDLElBQUksK0JBQzdENEMsbUJBQVNyTCxRQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFXLG1FQUFtRXFMLFNBQVM5QyxFQUFFLElBQUk4QyxTQUFTNUMsSUFBSSxJQUM3RzRDLG1CQUFTaEQsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0N5QyxZQUFZVCxhQUFhbkMsU0FBU2dELFNBQVMsS0FDMUMsdUJBQUMsVUFBSyxXQUFVLG1HQUFrRywyQkFBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVESSxrQkFDQyx1QkFBQyxPQUFJLE1BQU1BLGVBQWU3QyxTQUFTLGFBQWEsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0IsSUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQixHQUFLLE9BQU82QyxlQUFlaEQsT0FDdEhnRCx5QkFBZTdDLFFBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsY0FFQSx1QkFBQyxRQUFHLFdBQVUsb0NBQW9DeUMsb0JBQVVsSCxRQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRTtBQUFBLGNBQ2pFLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLGtCQUFlLFdBQVUsbUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlDO0FBQUEsa0JBQ3pDLHVCQUFDLFVBQUs7QUFBQTtBQUFBLG9CQUFLa0gsVUFBVTdHO0FBQUFBLHVCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBLHFCQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsaUJBQWMsV0FBVSxtQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0M7QUFBQSxrQkFDeEMsdUJBQUMsVUFBTTZHLG9CQUFVaEgsZ0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEscUJBRmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsZUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsTUFBTSx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFZO0FBQUEsY0FDbEIsU0FBUyxNQUFNO0FBQ2Isb0JBQUlrRixRQUFRO0FBQ1osb0JBQUk4QixVQUFVdkYsUUFBUTtBQUNwQnlELDBCQUFRLGdDQUFnQzhCLFVBQVVuSCxHQUFHO0FBQUEsZ0JBQ3ZELFdBQVdtSCxVQUFVdkUsU0FBUztBQUM1QnlDLDBCQUFRLDhCQUE4QjhCLFVBQVVuSCxHQUFHO0FBQUEsZ0JBQ3JELFdBQVdtSCxVQUFVbkUsWUFBWTtBQUMvQnFDLDBCQUFRLGtEQUFrRDhCLFVBQVVuSCxHQUFHO0FBQUEsZ0JBQ3pFLFdBQVdtSCxVQUFVbkYsVUFBVW1GLFVBQVU5RSxTQUFTO0FBQ2hELHdCQUFNa0QsU0FBUzRCLFVBQVVsRixXQUFXa0YsVUFBVW5IO0FBQzlDcUYsMEJBQVEsMEJBQTBCRSxNQUFNO0FBQUEsZ0JBQzFDLE9BQU87QUFDTEYsMEJBQVEsMEJBQTBCOEIsVUFBVW5ILEdBQUc7QUFBQSxnQkFDakQ7QUFDQTVELHlCQUFTaUosS0FBSztBQUFBLGNBQ2hCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBOEU7QUFBQTtBQUFBLFlBcEIxRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUF1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkE7QUFBQSxhQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUVBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHFDQUFvQyx1QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkQ7QUFBQSxZQUMxRDhCLFVBQVUxRztBQUFBQSxlQUZiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxVQUFLLFdBQVUscUNBQW9DLG1CQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLFlBQ3REMEcsVUFBVXhHO0FBQUFBLGVBRmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSxxQ0FBb0Msb0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsWUFDdkR3RyxVQUFVNUc7QUFBQUEsZUFGYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxzQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUN6RDRHLFVBQVUxRixtQkFBbUI7QUFBQSxlQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFdBdEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1RkE7QUFBQSxNQUlEMkYsYUFBYXBELFNBQVMsS0FDckIsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSw0RUFBMkUsNkJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFlBQVk7QUFBQSxjQUNWLEdBQUdyRztBQUFBQSxjQUNIcUosaUJBQWlCO0FBQUEsY0FDakJRLFdBQVdBLENBQUNDLE9BQU9DLFVBQ2pCLEdBQUdBLE1BQU0sQ0FBQyxDQUFDLElBQUlBLE1BQU0sQ0FBQyxDQUFDLE9BQU9ELEtBQUs7QUFBQSxjQUNyQ0UsVUFBVUEsQ0FBQ0MsTUFBTTlKLGFBQWE7QUFDNUJGLDhCQUFjO0FBQUEsa0JBQ1pDLFNBQVMrSjtBQUFBQSxrQkFDVDlKLFVBQVVBLFlBQVk7QUFBQSxnQkFDeEIsQ0FBQztBQUFBLGNBQ0g7QUFBQSxjQUNBK0osa0JBQWtCQSxDQUFDaEssU0FBU2lLLFNBQVM7QUFDbkNsSyw4QkFBYztBQUFBLGtCQUNaQyxTQUFTO0FBQUEsa0JBQ1RDLFVBQVU7QUFBQSxnQkFDWixDQUFDO0FBQUEsY0FDSDtBQUFBLFlBQ0Y7QUFBQSxZQUNBLFFBQVEsRUFBRW9KLEdBQUcsY0FBYztBQUFBLFlBQzNCO0FBQUEsWUFDQSxZQUFZRTtBQUFBQSxZQUNaLFFBQU87QUFBQSxZQUNQLE1BQUs7QUFBQSxZQUNMLE9BQU8sQ0FBQy9DLFlBQVk7QUFBQSxjQUNsQjBELFNBQVNBLE1BQU07QUFDYjNLLHNDQUFzQmlILE1BQU07QUFBQSxjQUM5QjtBQUFBLFlBQ0Y7QUFBQSxZQUNBLGNBQWMsTUFBTTtBQUFBO0FBQUEsVUE3QnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQTZCdUU7QUFBQSxXQWpDekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1DQTtBQUFBLFNBbElKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvSUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUNDLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFVBQU8sNkJBQTZCLENBQUN0QixNQUFNdkYsY0FBY3VGLEVBQUVpRixPQUFPNU0sS0FBSyxHQUFHLFlBQVksUUFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RjtBQUFBLElBQzVGLHVCQUFDLHFCQUFrQixNQUFNMkMsWUFBWUksTUFBTSxXQUFXSixZQUFZRSxZQUFZLFNBQVNGLFlBQVlHLFNBQVMsU0FBUyxNQUFNRixlQUFlLENBQUN1QixVQUFVLEVBQUUsR0FBR0EsTUFBTXRCLFlBQVksTUFBTSxFQUFFLEtBQXBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0w7QUFBQSxJQUV0TCx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSw2QkFBQyxZQUFPLFdBQVUsUUFDaEI7QUFBQSwrQkFBQyxRQUFHLFdBQVUscURBQW9EO0FBQUE7QUFBQSxVQUFHLHVCQUFDLFVBQUssV0FBVSxtQkFBa0Isc0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsYUFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSDtBQUFBLFFBQ3BILHVCQUFDLE9BQUUsV0FBVSwyQkFBMEIscUVBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEY7QUFBQSxXQUY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFFBQUssV0FBVSxvREFBbUQsV0FBVyxFQUFFZ0ssU0FBUyxVQUFVLEdBQ2pHLGlDQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxhQUFZO0FBQUEsY0FDWixPQUFPMUs7QUFBQUEsY0FDUCxVQUFVLENBQUN3RixNQUFNdkYsY0FBY3VGLEVBQUVpRixPQUFPNU0sS0FBSztBQUFBLGNBQzdDLFdBQVU7QUFBQSxjQUNWLFdBQVM7QUFBQTtBQUFBLFlBTlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTVc7QUFBQSxVQUVYLHVCQUFDLGtCQUFlLFdBQVUsb0VBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBGO0FBQUEsYUFUNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMERBQ1pTLHlCQUFlZ0UsSUFBSSxDQUFDb0UsV0FBVztBQUM5QixnQkFBTWlFLFdBQVd6SyxjQUFjMEcsU0FBU0YsT0FBT25JLEVBQUU7QUFDakQsaUJBQ0UsdUJBQUMsV0FBd0IsT0FBTyxhQUFhbUksT0FBT2xJLFVBQVUsSUFBSSxXQUFVLE9BQzFFLGlDQUFDLFlBQU8sU0FBUyxNQUFNOEssbUJBQW1CNUMsT0FBT25JLEVBQUUsR0FBRyxXQUFXLDZEQUE2RG9NLFdBQVcsb0NBQW9DLG9FQUFvRSxJQUM5T2pFLGlCQUFPbEksY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSFlrSSxPQUFPbkksSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFFBRUosQ0FBQyxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQTtBQUFBLE1BRUEsdUJBQUMsUUFBSyxXQUFVLCtEQUNkO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxrQkFBaUI7QUFBQSxVQUNqQixVQUFVO0FBQUEsVUFDVixNQUFLO0FBQUEsVUFDTCxXQUFXTztBQUFBQSxVQUNYLFVBQVUsQ0FBQ0wsUUFBUU0sYUFBYU4sR0FBRztBQUFBLFVBQ25DLE9BQU87QUFBQSxZQUNMLEVBQUVBLEtBQUssT0FBT3NJLE9BQU8sT0FBTzZELFVBQVVyQixjQUFjLEVBQUU7QUFBQSxZQUN0RCxFQUFFOUssS0FBSyxhQUFhc0ksT0FBTyxhQUFhNkQsVUFBVXJCLGNBQWMsRUFBRTtBQUFBLFlBQ2xFLEVBQUU5SyxLQUFLLFNBQVNzSSxPQUFPLFNBQVM2RCxVQUFVckIsY0FBYyxFQUFFO0FBQUEsWUFDMUQsRUFBRTlLLEtBQUssVUFBVXNJLE9BQU8sVUFBVTZELFVBQVVyQixjQUFjLEVBQUU7QUFBQSxZQUM1RCxFQUFFOUssS0FBSyxhQUFhc0ksT0FBTyxhQUFhNkQsVUFBVXJCLGNBQWMsRUFBRTtBQUFBLFlBQ2xFLEVBQUU5SyxLQUFLLFNBQVNzSSxPQUFPLFNBQVM2RCxVQUFVckIsY0FBYyxFQUFFO0FBQUE7QUFBQSxZQUMxRCxFQUFFOUssS0FBSyxTQUFTc0ksT0FBTyxTQUFTNkQsVUFBVXJCLGNBQWMsRUFBRTtBQUFBO0FBQUEsVUFBSztBQUFBO0FBQUEsUUFibkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BY0ksS0FmTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsU0FuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9EQTtBQUFBLE9BekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwREEsS0EzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTREQTtBQUVKO0FBQUUzSyxJQTVuQklELGFBQVc7QUFBQSxVQUNFbkIsYUF5VVdJLFdBQVc7QUFBQTtBQUFBaU4sS0ExVW5DbE07QUE4bkJOLGVBQWVBO0FBQVksSUFBQWtNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUNhbGxiYWNrIiwiVGFibGUiLCJUb29sdGlwIiwiQ2FyZCIsIlRhYnMiLCJJbnB1dCIsIkJ1dHRvbiIsIlRhZyIsIlVzZXJPdXRsaW5lZCIsIlVzZXJTd2l0Y2hPdXRsaW5lZCIsIlRlYW1PdXRsaW5lZCIsIlNhZmV0eUNlcnRpZmljYXRlT3V0bGluZWQiLCJQaG9uZU91dGxpbmVkIiwiSWRjYXJkT3V0bGluZWQiLCJDaGVja0NpcmNsZU91dGxpbmVkIiwiQ2xvY2tDaXJjbGVPdXRsaW5lZCIsIkZpQ2hlY2tDaXJjbGUiLCJTaWRlYmFyIiwiYXBpIiwiQ2lyY3VsYXJMb2FkZXIiLCJDdXN0b21BbGVydERpYWxvZyIsIkZ1c2UiLCJ1c2VOYXZpZ2F0ZSIsIkV5ZU91dGxpbmVkIiwiU2VhcmNoT3V0bGluZWQiLCJOYXZiYXIiLCJ1c2VEZWJvdW5jZSIsInZhbHVlIiwiZGVsYXkiLCJfcyIsImRlYm91bmNlZFZhbHVlIiwic2V0RGVib3VuY2VkVmFsdWUiLCJ1c2VFZmZlY3QiLCJoYW5kbGVyIiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsIkZJTFRFUlNfQ09ORklHIiwiaWQiLCJmaWx0ZXJOYW1lIiwia2V5IiwiaWNvbiIsIlF1aWNrU2VhcmNoIiwiX3MyIiwibmF2aWdhdGUiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJ0YWJsZVVzZXJzIiwic2V0VGFibGVVc2VycyIsInRhYmxlTGVhZHMiLCJzZXRUYWJsZUxlYWRzIiwidGFibGVBZ2VudHMiLCJzZXRUYWJsZUFnZW50cyIsInRhYmxlRW1wbG95ZWVzIiwic2V0VGFibGVFbXBsb3llZXMiLCJ0YWJsZUxvYW5zIiwic2V0VGFibGVMb2FucyIsInRhYmxlUGlnbXkiLCJzZXRUYWJsZVBpZ215Iiwic2VsZWN0ZWRFeGFjdE1hdGNoIiwic2V0U2VsZWN0ZWRFeGFjdE1hdGNoIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImFjdGl2ZUZpbHRlcnMiLCJzZXRBY3RpdmVGaWx0ZXJzIiwicGFnaW5hdGlvbiIsInNldFBhZ2luYXRpb24iLCJjdXJyZW50IiwicGFnZVNpemUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiYXBpTG9hZGVycyIsInNldEFwaUxvYWRlcnMiLCJ1c2VycyIsImxlYWRzIiwiYWdlbnRzIiwiZW1wbG95ZWVzIiwibG9hbnMiLCJwaWdteSIsImlzQW55QXBpTG9hZGluZyIsIk9iamVjdCIsInZhbHVlcyIsInNvbWUiLCJsb2FkaW5nIiwibGVhZHNGZXRjaGVkUmVmIiwidXNlUmVmIiwibG9hbnNGZXRjaGVkUmVmIiwicGlnbXlGZXRjaGVkUmVmIiwidXBkYXRlQXBpTG9hZGVyIiwiYXBpTmFtZSIsInByZXYiLCJmZXRjaFVzZXJzIiwicmVzcG9uc2UiLCJnZXQiLCJmb3JtYXR0ZWQiLCJkYXRhIiwibWFwIiwidSIsImkiLCJfaWQiLCJuYW1lIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiYWRkcmVzcyIsInBpbmNvZGUiLCJjdXN0b21lcl9pZCIsImNvbGxlY3Rpb25fYXJlYSIsInJvdXRlX25hbWUiLCJhYWRoYWFyX251bWJlciIsImFkaGFhcl9ubyIsInBhbl9udW1iZXIiLCJwYW5fbm8iLCJpc0N1c3RvbWVyIiwiYXBwcm92YWxfc3RhdHVzIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hMZWFkcyIsImwiLCJsZWFkX25hbWUiLCJsZWFkX3Bob25lIiwibGVhZF9hZGRyZXNzIiwibGVhZENvZGUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJjdXN0b21lcl9zdGF0dXMiLCJsZWFkX2FhZGhhYXIiLCJsZWFkX3BhbiIsImlzTGVhZCIsInVuaXF1ZUtleSIsImZldGNoTG9hbnMiLCJib3Jyb3dlciIsImlzTG9hbiIsInVzZXJfaWQiLCJmZXRjaFBpZ215IiwicCIsImN1c3RvbWVyIiwiaXNQaWdteSIsImZldGNoQWdlbnRzIiwiYWdlbnQiLCJhIiwiZW1wbG95ZWVDb2RlIiwiZGVzaWduYXRpb25faWQiLCJ0aXRsZSIsImlzQWdlbnQiLCJmZXRjaEVtcGxveWVlcyIsImVtcGxveWVlIiwiZSIsImlzRW1wbG95ZWUiLCJjb21iaW5lZERhdGEiLCJ1c2VNZW1vIiwiY3VzdG9tZXJQaG9uZVNldCIsIlNldCIsInVzZXIiLCJ1bmlxdWVMZWFkc01hcCIsIk1hcCIsImZvckVhY2giLCJsZWFkIiwiaGFzIiwic2V0IiwiZmluYWxMZWFkcyIsIkFycmF5IiwiZnJvbSIsInNlYXJjaGFibGVLZXlzIiwibGVuZ3RoIiwiZmlsdGVyIiwiZiIsImluY2x1ZGVzIiwiZ2V0VHlwZUluZm8iLCJyZWNvcmQiLCJsYWJlbCIsImNvbG9yIiwiYmciLCJib3JkZXIiLCJ0ZXh0IiwiZ2V0QXBwcm92YWxTdGF0dXMiLCJjb2x1bW5zIiwid2lkdGgiLCJhbGlnbiIsInJlbmRlciIsIl8iLCJfXyIsImluZGV4IiwiaW5mbyIsImRhdGFJbmRleCIsInJvdXRlIiwidG9vbHRpcCIsInVzZXJJZCIsImRlYm91bmNlZFNlYXJjaFRleHQiLCJjdXJyZW50RGF0YVNvdXJjZSIsImZ1c2VJbnN0YW5jZSIsImluY2x1ZGVTY29yZSIsImtleXMiLCJ0aHJlc2hvbGQiLCJpZ25vcmVGaWVsZE5vcm0iLCJyYXdTZWFyY2hSZXN1bHRzIiwidHJpbSIsInNlYXJjaCIsImdldFByb2Nlc3NlZFJlc3VsdHMiLCJtb2RlIiwiZGF0YVNvdXJjZSIsImhhc1Jlc3VsdHMiLCJleGFjdE1hdGNoZXMiLCJyIiwic2NvcmUiLCJpdGVtIiwicmVsYXRlZE1hdGNoZXMiLCJmaW5kIiwibSIsImhhbmRsZUZpbHRlclRvZ2dsZSIsInJlbmRlckNvbnRlbnQiLCJzZWFyY2hTdGF0ZSIsInNob3dTaXplQ2hhbmdlciIsImhpZGVPblNpbmdsZVBhZ2UiLCJ4IiwidG9wUmVjb3JkIiwidGFibGVSZWNvcmRzIiwic2xpY2UiLCJ0eXBlSW5mbyIsImFwcHJvdmFsU3RhdHVzIiwic2hvd1RvdGFsIiwidG90YWwiLCJyYW5nZSIsIm9uQ2hhbmdlIiwicGFnZSIsIm9uU2hvd1NpemVDaGFuZ2UiLCJzaXplIiwib25DbGljayIsInRhcmdldCIsInBhZGRpbmciLCJpc0FjdGl2ZSIsImNoaWxkcmVuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUXVpY2tTZWFyY2guanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8sIHVzZUNhbGxiYWNrLCB1c2VSZWYgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgVGFibGUsIFRvb2x0aXAsIENhcmQsIFRhYnMsIElucHV0LCBCdXR0b24sIFRhZyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7XHJcbiAgVXNlck91dGxpbmVkLFxyXG4gIFVzZXJTd2l0Y2hPdXRsaW5lZCxcclxuICBUZWFtT3V0bGluZWQsXHJcbiAgU2FmZXR5Q2VydGlmaWNhdGVPdXRsaW5lZCxcclxuICBQaG9uZU91dGxpbmVkLFxyXG4gIElkY2FyZE91dGxpbmVkLFxyXG4gIENoZWNrQ2lyY2xlT3V0bGluZWQsXHJcbiAgQ2xvY2tDaXJjbGVPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IHsgRmlDaGVja0NpcmNsZSB9IGZyb20gXCJyZWFjdC1pY29ucy9maVwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBGdXNlIGZyb20gXCJmdXNlLmpzXCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgRXllT3V0bGluZWQsIFNlYXJjaE91dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuXHJcbi8vIC0tLSBDdXN0b20gSG9vayBmb3IgRGVib3VuY2luZyAtLS1cclxuZnVuY3Rpb24gdXNlRGVib3VuY2UodmFsdWUsIGRlbGF5KSB7XHJcbiAgY29uc3QgW2RlYm91bmNlZFZhbHVlLCBzZXREZWJvdW5jZWRWYWx1ZV0gPSB1c2VTdGF0ZSh2YWx1ZSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGhhbmRsZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0RGVib3VuY2VkVmFsdWUodmFsdWUpO1xyXG4gICAgfSwgZGVsYXkpO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgY2xlYXJUaW1lb3V0KGhhbmRsZXIpO1xyXG4gICAgfTtcclxuICB9LCBbdmFsdWUsIGRlbGF5XSk7XHJcbiAgcmV0dXJuIGRlYm91bmNlZFZhbHVlO1xyXG59XHJcblxyXG4vLyBTdGF0aWMgY29uZmlndXJhdGlvbnNcclxuY29uc3QgRklMVEVSU19DT05GSUcgPSBbXHJcbiAgeyBpZDogXCIxXCIsIGZpbHRlck5hbWU6IFwiSURcIiwga2V5OiBcImN1c3RvbWVyX2lkXCIgfSxcclxuICB7IGlkOiBcIjJcIiwgZmlsdGVyTmFtZTogXCJOYW1lXCIsIGtleTogXCJuYW1lXCIgfSxcclxuICB7IGlkOiBcIjNcIiwgZmlsdGVyTmFtZTogXCJQaG9uZVwiLCBrZXk6IFwicGhvbmVfbnVtYmVyXCIgfSxcclxuICB7IGlkOiBcIjRcIiwgZmlsdGVyTmFtZTogXCJBYWRoYWFyXCIsIGtleTogXCJhYWRoYWFyX251bWJlclwiIH0sXHJcbiAgeyBpZDogXCI1XCIsIGZpbHRlck5hbWU6IFwiUGFuXCIsIGtleTogXCJwYW5fbnVtYmVyXCIgfSxcclxuICB7XHJcbiAgICBpZDogXCI3XCIsXHJcbiAgICBmaWx0ZXJOYW1lOiBcIlN0YXR1c1wiLFxyXG4gICAga2V5OiBcImN1c3RvbWVyX3N0YXR1c1wiLFxyXG4gICAgaWNvbjogRmlDaGVja0NpcmNsZSxcclxuICB9LFxyXG5dO1xyXG5cclxuY29uc3QgUXVpY2tTZWFyY2ggPSAoKSA9PiB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShcImFsbFwiKTsgLy8gVHJhY2sgYWN0aXZlIHRhYlxyXG5cclxuICAvLyBTdGF0ZXNcclxuICBjb25zdCBbdGFibGVVc2Vycywgc2V0VGFibGVVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RhYmxlTGVhZHMsIHNldFRhYmxlTGVhZHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZUFnZW50cywgc2V0VGFibGVBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZUVtcGxveWVlcywgc2V0VGFibGVFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZUxvYW5zLCBzZXRUYWJsZUxvYW5zXSA9IHVzZVN0YXRlKFtdKTsgICAgICAgIC8vIE5FV1xyXG4gIGNvbnN0IFt0YWJsZVBpZ215LCBzZXRUYWJsZVBpZ215XSA9IHVzZVN0YXRlKFtdKTsgICAgICAgIC8vIE5FV1xyXG4gIGNvbnN0IFtzZWxlY3RlZEV4YWN0TWF0Y2gsIHNldFNlbGVjdGVkRXhhY3RNYXRjaF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWN0aXZlRmlsdGVycywgc2V0QWN0aXZlRmlsdGVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3BhZ2luYXRpb24sIHNldFBhZ2luYXRpb25dID0gdXNlU3RhdGUoe1xyXG4gICAgY3VycmVudDogMSxcclxuICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFthcGlMb2FkZXJzLCBzZXRBcGlMb2FkZXJzXSA9IHVzZVN0YXRlKHtcclxuICAgIHVzZXJzOiBmYWxzZSxcclxuICAgIGxlYWRzOiBmYWxzZSxcclxuICAgIGFnZW50czogZmFsc2UsXHJcbiAgICBlbXBsb3llZXM6IGZhbHNlLFxyXG4gICAgbG9hbnM6IGZhbHNlLCAgICAgIC8vIE5FV1xyXG4gICAgcGlnbXk6IGZhbHNlLCAgICAgIC8vIE5FV1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBpc0FueUFwaUxvYWRpbmcgPSBPYmplY3QudmFsdWVzKGFwaUxvYWRlcnMpLnNvbWUoKGxvYWRpbmcpID0+IGxvYWRpbmcpO1xyXG4gIGNvbnN0IGxlYWRzRmV0Y2hlZFJlZiA9IHVzZVJlZihmYWxzZSk7XHJcbiAgY29uc3QgbG9hbnNGZXRjaGVkUmVmID0gdXNlUmVmKGZhbHNlKTsgICAgIC8vIE5FV1xyXG4gIGNvbnN0IHBpZ215RmV0Y2hlZFJlZiA9IHVzZVJlZihmYWxzZSk7ICAgICAvLyBORVdcclxuXHJcbiAgLy8gLS0tIERhdGEgRmV0Y2hpbmcgLS0tXHJcbiAgY29uc3QgdXBkYXRlQXBpTG9hZGVyID0gdXNlQ2FsbGJhY2soKGFwaU5hbWUsIGxvYWRpbmcpID0+IHtcclxuICAgIHNldEFwaUxvYWRlcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFthcGlOYW1lXTogbG9hZGluZyB9KSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBGZXRjaCBVc2Vyc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB1cGRhdGVBcGlMb2FkZXIoJ3VzZXJzJywgdHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gcmVzcG9uc2UuZGF0YS5tYXAoKHUsIGkpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IHUuX2lkLFxyXG4gICAgICAgICAgaWQ6IGkgKyAxLFxyXG4gICAgICAgICAgbmFtZTogdS5mdWxsX25hbWUsXHJcbiAgICAgICAgICBwaG9uZV9udW1iZXI6IHUucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgYWRkcmVzczogdS5hZGRyZXNzLFxyXG4gICAgICAgICAgcGluY29kZTogdS5waW5jb2RlLFxyXG4gICAgICAgICAgY3VzdG9tZXJfaWQ6IHUuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICBjb2xsZWN0aW9uX2FyZWE6IHUuY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9uYW1lLFxyXG4gICAgICAgICAgYWFkaGFhcl9udW1iZXI6IHUuYWRoYWFyX25vIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBwYW5fbnVtYmVyOiB1LnBhbl9ubyB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgaXNDdXN0b21lcjogdHJ1ZSxcclxuICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czogdS5hcHByb3ZhbF9zdGF0dXMsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFRhYmxlVXNlcnMoZm9ybWF0dGVkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHsgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXJzOlwiLCBlcnJvcik7IH1cclxuICAgICAgZmluYWxseSB7IHVwZGF0ZUFwaUxvYWRlcigndXNlcnMnLCBmYWxzZSk7IH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXIsIHVwZGF0ZUFwaUxvYWRlcl0pO1xyXG5cclxuICAvLyBGZXRjaCBMZWFkcyAob25seSBvbmNlIHBlciBzZXNzaW9uKVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoYWN0aXZlVGFiICE9PSBcImxlYWRzXCIpIHJldHVybjtcclxuICAgIGlmIChsZWFkc0ZldGNoZWRSZWYuY3VycmVudCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGZldGNoTGVhZHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGxlYWRzRmV0Y2hlZFJlZi5jdXJyZW50ID0gdHJ1ZTtcclxuICAgICAgdXBkYXRlQXBpTG9hZGVyKFwibGVhZHNcIiwgdHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2xlYWQvbmV3LW5vbi1jb252ZXJ0ZWRcIik7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gcmVzcG9uc2UuZGF0YT8ubWFwKChsLCBpKSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBsLl9pZCxcclxuICAgICAgICAgIGlkOiBpICsgMSxcclxuICAgICAgICAgIG5hbWU6IGwubGVhZF9uYW1lIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBwaG9uZV9udW1iZXI6IGwubGVhZF9waG9uZSB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgYWRkcmVzczogbC5sZWFkX2FkZHJlc3MgfHwgXCLigJRcIixcclxuICAgICAgICAgIHBpbmNvZGU6IGwucGluY29kZSB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJfaWQ6IGwubGVhZENvZGUsXHJcbiAgICAgICAgICBjb2xsZWN0aW9uX2FyZWE6IGwuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCLigJRcIixcclxuICAgICAgICAgIGN1c3RvbWVyX3N0YXR1czogXCJBY3RpdmVcIixcclxuICAgICAgICAgIGFhZGhhYXJfbnVtYmVyOiBsLmFkaGFhcl9ubyB8fCBsLmxlYWRfYWFkaGFhciB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgcGFuX251bWJlcjogbC5wYW5fbm8gfHwgbC5sZWFkX3BhbiB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgaXNMZWFkOiB0cnVlLFxyXG4gICAgICAgICAgdW5pcXVlS2V5OiBgbGVhZF8ke2wuX2lkfWAsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFRhYmxlTGVhZHMoZm9ybWF0dGVkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbGVhZHM6XCIsIGVycm9yKTtcclxuICAgICAgICBsZWFkc0ZldGNoZWRSZWYuY3VycmVudCA9IGZhbHNlOyAvLyBhbGxvdyByZXRyeVxyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHVwZGF0ZUFwaUxvYWRlcihcImxlYWRzXCIsIGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoTGVhZHMoKTtcclxuICB9LCBbYWN0aXZlVGFiLCB1cGRhdGVBcGlMb2FkZXJdKTtcclxuXHJcbiAgLy8gRmV0Y2ggTG9hbnMgKG9ubHkgb25jZSBwZXIgc2Vzc2lvbilcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGFjdGl2ZVRhYiAhPT0gXCJsb2Fuc1wiKSByZXR1cm47XHJcbiAgICBpZiAobG9hbnNGZXRjaGVkUmVmLmN1cnJlbnQpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBmZXRjaExvYW5zID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBsb2Fuc0ZldGNoZWRSZWYuY3VycmVudCA9IHRydWU7XHJcbiAgICAgIHVwZGF0ZUFwaUxvYWRlcihcImxvYW5zXCIsIHRydWUpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIC8vIEFkanVzdCB0aGUgZW5kcG9pbnQgYW5kIGZpZWxkIG1hcHBpbmcgYWNjb3JkaW5nIHRvIHlvdXIgQVBJXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL2xvYW5zLz9hcHByb3ZhbF9zdGF0dXM9Q09NUExFVEVEXCIpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IChyZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdKS5tYXAoKGwsIGkpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGwuX2lkLCAvLyBsb2FuIF9pZFxyXG4gICAgICAgICAgaWQ6IGkgKyAxLFxyXG4gICAgICAgICAgY3VzdG9tZXJfaWQ6IGwuYm9ycm93ZXI/LmN1c3RvbWVyX2lkIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBuYW1lOiBsLmJvcnJvd2VyPy5mdWxsX25hbWUgfHwgXCLigJRcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogbC5ib3Jyb3dlcj8ucGhvbmVfbnVtYmVyIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBhYWRoYWFyX251bWJlcjogXCLigJRcIiwgICAvLyBub3QgcHJvdmlkZWRcclxuICAgICAgICAgIHBhbl9udW1iZXI6IFwi4oCUXCIsICAgICAgIC8vIG5vdCBwcm92aWRlZFxyXG4gICAgICAgICAgY29sbGVjdGlvbl9hcmVhOiBcIuKAlFwiLCAgLy8gbm90IHByb3ZpZGVkXHJcbiAgICAgICAgICBjdXN0b21lcl9zdGF0dXM6IFwiQWN0aXZlXCIsXHJcbiAgICAgICAgICBpc0xvYW46IHRydWUsXHJcbiAgICAgICAgICB1c2VyX2lkOiBsLmJvcnJvd2VyPy5faWQgfHwgbC5faWQsIC8vIGN1c3RvbWVyIHVzZXIgaWRcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVMb2Fucyhmb3JtYXR0ZWQpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBsb2FuczpcIiwgZXJyb3IpO1xyXG4gICAgICAgIGxvYW5zRmV0Y2hlZFJlZi5jdXJyZW50ID0gZmFsc2U7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgdXBkYXRlQXBpTG9hZGVyKFwibG9hbnNcIiwgZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hMb2FucygpO1xyXG4gIH0sIFthY3RpdmVUYWIsIHVwZGF0ZUFwaUxvYWRlcl0pO1xyXG5cclxuICAvLyBGZXRjaCBQaWdteSAob25seSBvbmNlIHBlciBzZXNzaW9uKVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoYWN0aXZlVGFiICE9PSBcInBpZ215XCIpIHJldHVybjtcclxuICAgIGlmIChwaWdteUZldGNoZWRSZWYuY3VycmVudCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGZldGNoUGlnbXkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHBpZ215RmV0Y2hlZFJlZi5jdXJyZW50ID0gdHJ1ZTtcclxuICAgICAgdXBkYXRlQXBpTG9hZGVyKFwicGlnbXlcIiwgdHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3BpZ21lL2dldC1hbGwtcGlnbWUtY3VzdG9tZXJzXCIpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IChyZXNwb25zZS5kYXRhIHx8IFtdKS5tYXAoKHAsIGkpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IHAuX2lkLFxyXG4gICAgICAgICAgaWQ6IGkgKyAxLFxyXG4gICAgICAgICAgY3VzdG9tZXJfaWQ6IHAuY3VzdG9tZXI/LmN1c3RvbWVyX2lkIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBuYW1lOiBwLmN1c3RvbWVyPy5mdWxsX25hbWUgfHwgXCLigJRcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogcC5jdXN0b21lcj8ucGhvbmVfbnVtYmVyIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBhYWRoYWFyX251bWJlcjogcC5jdXN0b21lcj8uYWRoYWFyX25vIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBwYW5fbnVtYmVyOiBwLmN1c3RvbWVyPy5wYW5fbm8gfHwgXCLigJRcIixcclxuICAgICAgICAgIGNvbGxlY3Rpb25fYXJlYTogXCLigJRcIiwgLy8gb3IgbWF5YmUgcC5jdXN0b21lcj8uY29sbGVjdGlvbl9hcmVhPyBidXQgaXQncyBhbiBJRFxyXG4gICAgICAgICAgY3VzdG9tZXJfc3RhdHVzOiBcIkFjdGl2ZVwiLFxyXG4gICAgICAgICAgaXNQaWdteTogdHJ1ZSxcclxuICAgICAgICAgIHVzZXJfaWQ6IHAuY3VzdG9tZXI/Ll9pZCB8fCBwLl9pZCxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVQaWdteShmb3JtYXR0ZWQpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwaWdteTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHBpZ215RmV0Y2hlZFJlZi5jdXJyZW50ID0gZmFsc2U7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgdXBkYXRlQXBpTG9hZGVyKFwicGlnbXlcIiwgZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hQaWdteSgpO1xyXG4gIH0sIFthY3RpdmVUYWIsIHVwZGF0ZUFwaUxvYWRlcl0pO1xyXG5cclxuICAvLyBGZXRjaCBBZ2VudHMgJiBFbXBsb3llZXMgKHVuY2hhbmdlZClcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hBZ2VudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHVwZGF0ZUFwaUxvYWRlcignYWdlbnRzJywgdHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldFwiKTtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSAocmVzcG9uc2UuZGF0YT8uYWdlbnQgfHwgW10pLm1hcCgoYSwgaSkgPT4gKHtcclxuICAgICAgICAgIF9pZDogYS5faWQsIGlkOiBpICsgMSwgbmFtZTogYS5uYW1lIHx8IFwi4oCUXCIsIHBob25lX251bWJlcjogYS5waG9uZV9udW1iZXIgfHwgXCLigJRcIixcclxuICAgICAgICAgIGFkZHJlc3M6IGEuYWRkcmVzcyB8fCBcIuKAlFwiLCBwaW5jb2RlOiBhLnBpbmNvZGUgfHwgXCLigJRcIiwgY3VzdG9tZXJfaWQ6IGEuZW1wbG95ZWVDb2RlLFxyXG4gICAgICAgICAgY29sbGVjdGlvbl9hcmVhOiBhLmRlc2lnbmF0aW9uX2lkPy50aXRsZSB8fCBcIuKAlFwiLCBjdXN0b21lcl9zdGF0dXM6IFwiQWN0aXZlXCIsXHJcbiAgICAgICAgICBhYWRoYWFyX251bWJlcjogYS5hZGhhYXJfbm8gfHwgXCLigJRcIiwgcGFuX251bWJlcjogYS5wYW5fbm8gfHwgXCLigJRcIiwgaXNBZ2VudDogdHJ1ZSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVBZ2VudHMoZm9ybWF0dGVkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHsgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFnZW50czpcIiwgZXJyb3IpOyB9XHJcbiAgICAgIGZpbmFsbHkgeyB1cGRhdGVBcGlMb2FkZXIoJ2FnZW50cycsIGZhbHNlKTsgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQWdlbnRzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXIsIHVwZGF0ZUFwaUxvYWRlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHVwZGF0ZUFwaUxvYWRlcignZW1wbG95ZWVzJywgdHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1lbXBsb3llZVwiKTtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSAocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW10pLm1hcCgoZSwgaSkgPT4gKHtcclxuICAgICAgICAgIF9pZDogZS5faWQsIGlkOiBpICsgMSwgbmFtZTogZS5uYW1lIHx8IFwi4oCUXCIsIHBob25lX251bWJlcjogZS5waG9uZV9udW1iZXIgfHwgXCLigJRcIixcclxuICAgICAgICAgIGFkZHJlc3M6IGUuYWRkcmVzcyB8fCBcIuKAlFwiLCBwaW5jb2RlOiBlLnBpbmNvZGUgfHwgXCLigJRcIiwgY3VzdG9tZXJfaWQ6IGUuZW1wbG95ZWVDb2RlLFxyXG4gICAgICAgICAgY29sbGVjdGlvbl9hcmVhOiBlLmRlc2lnbmF0aW9uX2lkPy50aXRsZSB8fCBcIuKAlFwiLCBjdXN0b21lcl9zdGF0dXM6IFwiQWN0aXZlXCIsXHJcbiAgICAgICAgICBhYWRoYWFyX251bWJlcjogZS5hZGhhYXJfbm8gfHwgXCLigJRcIiwgcGFuX251bWJlcjogZS5wYW5fbm8gfHwgXCLigJRcIiwgaXNFbXBsb3llZTogdHJ1ZSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVFbXBsb3llZXMoZm9ybWF0dGVkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHsgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlczpcIiwgZXJyb3IpOyB9XHJcbiAgICAgIGZpbmFsbHkgeyB1cGRhdGVBcGlMb2FkZXIoJ2VtcGxveWVlcycsIGZhbHNlKTsgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXIsIHVwZGF0ZUFwaUxvYWRlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4geyBzZXRTZWxlY3RlZEV4YWN0TWF0Y2gobnVsbCk7IH0sIFtzZWFyY2hUZXh0XSk7XHJcblxyXG4gIC8vIC0tLSBDb21wdXRlZCBWYWx1ZXMgLS0tXHJcblxyXG4gIC8vIENvbWJpbmVkIGRhdGEgZm9yIFwiQWxsXCIgdGFiIOKAkyBpbmNsdWRlcyBhbGwgdHlwZXNcclxuICBjb25zdCBjb21iaW5lZERhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGN1c3RvbWVyUGhvbmVTZXQgPSBuZXcgU2V0KHRhYmxlVXNlcnMubWFwKHVzZXIgPT4gdXNlci5waG9uZV9udW1iZXIpKTtcclxuICAgIGNvbnN0IHVuaXF1ZUxlYWRzTWFwID0gbmV3IE1hcCgpO1xyXG5cclxuICAgIHRhYmxlTGVhZHMuZm9yRWFjaChsZWFkID0+IHtcclxuICAgICAgaWYgKGN1c3RvbWVyUGhvbmVTZXQuaGFzKGxlYWQucGhvbmVfbnVtYmVyKSkgcmV0dXJuO1xyXG4gICAgICBpZiAoIXVuaXF1ZUxlYWRzTWFwLmhhcyhsZWFkLnBob25lX251bWJlcikpIHtcclxuICAgICAgICB1bmlxdWVMZWFkc01hcC5zZXQobGVhZC5waG9uZV9udW1iZXIsIGxlYWQpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBmaW5hbExlYWRzID0gQXJyYXkuZnJvbSh1bmlxdWVMZWFkc01hcC52YWx1ZXMoKSk7XHJcbiAgICByZXR1cm4gW1xyXG4gICAgICAuLi50YWJsZVVzZXJzLFxyXG4gICAgICAuLi5maW5hbExlYWRzLFxyXG4gICAgICAuLi50YWJsZUFnZW50cyxcclxuICAgICAgLi4udGFibGVFbXBsb3llZXMsXHJcbiAgICAgIC4uLnRhYmxlTG9hbnMsICAgIC8vIE5FV1xyXG4gICAgICAuLi50YWJsZVBpZ215LCAgICAvLyBORVdcclxuICAgIF07XHJcbiAgfSwgW3RhYmxlVXNlcnMsIHRhYmxlTGVhZHMsIHRhYmxlQWdlbnRzLCB0YWJsZUVtcGxveWVlcywgdGFibGVMb2FucywgdGFibGVQaWdteV0pO1xyXG5cclxuICBjb25zdCBzZWFyY2hhYmxlS2V5cyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKGFjdGl2ZUZpbHRlcnMubGVuZ3RoID4gMCkge1xyXG4gICAgICByZXR1cm4gRklMVEVSU19DT05GSUcuZmlsdGVyKGYgPT4gYWN0aXZlRmlsdGVycy5pbmNsdWRlcyhmLmlkKSkubWFwKGYgPT4gZi5rZXkpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIEZJTFRFUlNfQ09ORklHLm1hcChmID0+IGYua2V5KTtcclxuICB9LCBbYWN0aXZlRmlsdGVyc10pO1xyXG5cclxuICAvLyBEZXRlcm1pbmUgdHlwZSBpbmZvIGZvciBkaXNwbGF5XHJcbiAgY29uc3QgZ2V0VHlwZUluZm8gPSAocmVjb3JkKSA9PiB7XHJcbiAgICBpZiAocmVjb3JkLmlzTGVhZCkgcmV0dXJuIHsgbGFiZWw6IFwiTGVhZFwiLCBjb2xvcjogXCJvcmFuZ2VcIiwgYmc6IFwiYmctb3JhbmdlLTUwXCIsIGJvcmRlcjogXCJib3JkZXItb3JhbmdlLTIwMFwiLCB0ZXh0OiBcInRleHQtb3JhbmdlLTcwMFwiLCBpY29uOiA8VXNlclN3aXRjaE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtMnhsXCIgLz4gfTtcclxuICAgIGlmIChyZWNvcmQuaXNBZ2VudCkgcmV0dXJuIHsgbGFiZWw6IFwiQWdlbnRcIiwgY29sb3I6IFwicHVycGxlXCIsIGJnOiBcImJnLXB1cnBsZS01MFwiLCBib3JkZXI6IFwiYm9yZGVyLXB1cnBsZS0yMDBcIiwgdGV4dDogXCJ0ZXh0LXB1cnBsZS03MDBcIiwgaWNvbjogPFRlYW1PdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiIC8+IH07XHJcbiAgICBpZiAocmVjb3JkLmlzRW1wbG95ZWUpIHJldHVybiB7IGxhYmVsOiBcIkVtcGxveWVlXCIsIGNvbG9yOiBcImN5YW5cIiwgYmc6IFwiYmctY3lhbi01MFwiLCBib3JkZXI6IFwiYm9yZGVyLWN5YW4tMjAwXCIsIHRleHQ6IFwidGV4dC1jeWFuLTcwMFwiLCBpY29uOiA8U2FmZXR5Q2VydGlmaWNhdGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiIC8+IH07XHJcbiAgICBpZiAocmVjb3JkLmlzQ3VzdG9tZXIpIHJldHVybiB7IGxhYmVsOiBcIkN1c3RvbWVyXCIsIGNvbG9yOiBcImJsdWVcIiwgYmc6IFwiYmctYmx1ZS01MFwiLCBib3JkZXI6IFwiYm9yZGVyLWJsdWUtMjAwXCIsIHRleHQ6IFwidGV4dC1ibHVlLTcwMFwiLCBpY29uOiA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtMnhsXCIgLz4gfTtcclxuICAgIGlmIChyZWNvcmQuaXNMb2FuKSByZXR1cm4geyBsYWJlbDogXCJMb2FuXCIsIGNvbG9yOiBcImdyZWVuXCIsIGJnOiBcImJnLWdyZWVuLTUwXCIsIGJvcmRlcjogXCJib3JkZXItZ3JlZW4tMjAwXCIsIHRleHQ6IFwidGV4dC1ncmVlbi03MDBcIiwgaWNvbjogPElkY2FyZE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtMnhsXCIgLz4gfTtcclxuICAgIGlmIChyZWNvcmQuaXNQaWdteSkgcmV0dXJuIHsgbGFiZWw6IFwiUGlnbXlcIiwgY29sb3I6IFwiZ29sZFwiLCBiZzogXCJiZy15ZWxsb3ctNTBcIiwgYm9yZGVyOiBcImJvcmRlci15ZWxsb3ctMjAwXCIsIHRleHQ6IFwidGV4dC15ZWxsb3ctNzAwXCIsIGljb246IDxJZGNhcmRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiIC8+IH07XHJcbiAgICByZXR1cm4geyBsYWJlbDogXCJVbmtub3duXCIsIGNvbG9yOiBcImRlZmF1bHRcIiwgYmc6IFwiYmctZ3JheS01MFwiLCBib3JkZXI6IFwiYm9yZGVyLWdyYXktMjAwXCIsIHRleHQ6IFwidGV4dC1ncmF5LTcwMFwiLCBpY29uOiA8SWRjYXJkT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC0yeGxcIiAvPiB9O1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldEFwcHJvdmFsU3RhdHVzID0gKHJlY29yZCkgPT4ge1xyXG4gICAgaWYgKCFyZWNvcmQuaXNDdXN0b21lcikgcmV0dXJuIG51bGw7XHJcbiAgICBpZiAocmVjb3JkLmFwcHJvdmFsX3N0YXR1cyA9PT0gXCJ0cnVlXCIpIHJldHVybiB7IHRleHQ6IFwiQXBwcm92ZWRcIiwgY29sb3I6IFwic3VjY2Vzc1wiIH07XHJcbiAgICBpZiAocmVjb3JkLmFwcHJvdmFsX3N0YXR1cyA9PT0gXCJmYWxzZVwiKSByZXR1cm4geyB0ZXh0OiBcIlBlbmRpbmdcIiwgY29sb3I6IFwid2FybmluZ1wiIH07XHJcbiAgICByZXR1cm4geyB0ZXh0OiBcIkFwcHJvdmVkXCIsIGNvbG9yOiBcInN1Y2Nlc3NcIiB9O1xyXG4gIH07XHJcblxyXG4gIC8vIFRhYmxlIGNvbHVtbnMg4oCTIGFkZCBhY3Rpb24gdG8gbmF2aWdhdGUgdG8gY3VzdG9tZXIgdmlldyBmb3IgbG9hbnMvcGlnbXlcclxuICBjb25zdCBjb2x1bW5zID0gdXNlTWVtbygoKSA9PiBbXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIlNMLiBOT1wiLFxyXG4gICAgICBrZXk6IFwic19ub1wiLFxyXG4gICAgICB3aWR0aDogODAsXHJcbiAgICAgIGFsaWduOiBcImNlbnRlclwiLFxyXG4gICAgICByZW5kZXI6IChfLCBfXywgaW5kZXgpID0+IGluZGV4ICsgMSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIlR5cGVcIiwga2V5OiBcInR5cGVcIiwgd2lkdGg6IDEwMCxcclxuICAgICAgcmVuZGVyOiAoXywgcmVjb3JkKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaW5mbyA9IGdldFR5cGVJbmZvKHJlY29yZCk7XHJcbiAgICAgICAgcmV0dXJuIDxUYWcgY29sb3I9e2luZm8uY29sb3J9PntpbmZvLmxhYmVsfTwvVGFnPjtcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7IGRhdGFJbmRleDogXCJjdXN0b21lcl9pZFwiLCB0aXRsZTogXCJJRFwiLCBrZXk6IFwiY3VzdG9tZXJfaWRcIiwgd2lkdGg6IDEyMCB9LFxyXG4gICAgeyBkYXRhSW5kZXg6IFwibmFtZVwiLCB0aXRsZTogXCJOYW1lXCIsIGtleTogXCJuYW1lXCIsIHdpZHRoOiAxODAgfSxcclxuICAgIHsgZGF0YUluZGV4OiBcInBob25lX251bWJlclwiLCB0aXRsZTogXCJQaG9uZVwiLCBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIHdpZHRoOiAxNDAgfSxcclxuICAgIHtcclxuICAgICAgZGF0YUluZGV4OiBcImFhZGhhYXJfbnVtYmVyXCIsIHRpdGxlOiBcIkFhZGhhYXJcIiwga2V5OiBcImFhZGhhYXJfbnVtYmVyXCIsIHdpZHRoOiAxNTAsXHJcbiAgICAgIHJlbmRlcjogKHRleHQpID0+IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNtXCI+e3RleHR9PC9zcGFuPlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgZGF0YUluZGV4OiBcInBhbl9udW1iZXJcIiwgdGl0bGU6IFwiUGFuXCIsIGtleTogXCJwYW5fbnVtYmVyXCIsIHdpZHRoOiAxNDAsXHJcbiAgICAgIHJlbmRlcjogKHRleHQpID0+IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNtIHVwcGVyY2FzZVwiPnt0ZXh0fTwvc3Bhbj5cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJhY3Rpb25cIiwgd2lkdGg6IDEwMCxcclxuICAgICAgcmVuZGVyOiAoXywgcmVjb3JkKSA9PiB7XHJcbiAgICAgICAgbGV0IHJvdXRlID0gXCIjXCIsIHRvb2x0aXAgPSBcIlwiO1xyXG4gICAgICAgIGlmIChyZWNvcmQuaXNMZWFkKSB7XHJcbiAgICAgICAgICByb3V0ZSA9IGAvcmVwb3J0cy9sZWFkLXJlcG9ydD9sZWFkX2lkPSR7cmVjb3JkLl9pZH1gO1xyXG4gICAgICAgICAgdG9vbHRpcCA9IFwiVmlldyBMZWFkXCI7XHJcbiAgICAgICAgfSBlbHNlIGlmIChyZWNvcmQuaXNBZ2VudCkge1xyXG4gICAgICAgICAgcm91dGUgPSBgL3N0YWZmLW1lbnUvYWdlbnQ/YWdlbnRfaWQ9JHtyZWNvcmQuX2lkfWA7XHJcbiAgICAgICAgICB0b29sdGlwID0gXCJWaWV3IEFnZW50XCI7XHJcbiAgICAgICAgfSBlbHNlIGlmIChyZWNvcmQuaXNFbXBsb3llZSkge1xyXG4gICAgICAgICAgcm91dGUgPSBgL3N0YWZmLW1lbnUvZW1wbG95ZWUtbWVudS9lbXBsb3llZT9lbXBsb3llZV9pZD0ke3JlY29yZC5faWR9YDtcclxuICAgICAgICAgIHRvb2x0aXAgPSBcIlZpZXcgRW1wbG95ZWVcIjtcclxuICAgICAgICB9IGVsc2UgaWYgKHJlY29yZC5pc0xvYW4gfHwgcmVjb3JkLmlzUGlnbXkpIHtcclxuICAgICAgICAgIC8vIEZvciBsb2Fucy9waWdteSwgZ28gdG8gY3VzdG9tZXIgdmlldyB1c2luZyB1c2VyX2lkXHJcbiAgICAgICAgICBjb25zdCB1c2VySWQgPSByZWNvcmQudXNlcl9pZCB8fCByZWNvcmQuX2lkOyAvLyBmYWxsYmFjayB0byBfaWQgaWYgdXNlcl9pZCBtaXNzaW5nXHJcbiAgICAgICAgICByb3V0ZSA9IGAvY3VzdG9tZXItdmlldz91c2VyX2lkPSR7dXNlcklkfWA7XHJcbiAgICAgICAgICB0b29sdGlwID0gXCJWaWV3IEN1c3RvbWVyXCI7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIC8vIEN1c3RvbWVycyAoYW5kIGFueSBvdGhlcikgdXNlIF9pZFxyXG4gICAgICAgICAgcm91dGUgPSBgL2N1c3RvbWVyLXZpZXc/dXNlcl9pZD0ke3JlY29yZC5faWR9YDtcclxuICAgICAgICAgIHRvb2x0aXAgPSBcIlZpZXcgQ3VzdG9tZXJcIjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8VG9vbHRpcCB0aXRsZT17dG9vbHRpcH0+XHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUocm91dGUpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSBweC0zIHB5LTEuNSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy12aW9sZXQtNjAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6c2hhZG93IHRyYW5zaXRpb25cIj5cclxuICAgICAgICAgICAgICA8RXllT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+IDxzcGFuPlZpZXc8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICk7XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIF0sIFtuYXZpZ2F0ZV0pO1xyXG5cclxuICAvLyAtLS0gT3B0aW1pemVkIFNlYXJjaCBMb2dpYyAtLS1cclxuXHJcbiAgY29uc3QgZGVib3VuY2VkU2VhcmNoVGV4dCA9IHVzZURlYm91bmNlKHNlYXJjaFRleHQsIDMwMCk7XHJcblxyXG4gIC8vIERldGVybWluZSBjdXJyZW50IGRhdGEgc291cmNlIGJhc2VkIG9uIGFjdGl2ZSB0YWJcclxuICBjb25zdCBjdXJyZW50RGF0YVNvdXJjZSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJjdXN0b21lcnNcIikgcmV0dXJuIHRhYmxlVXNlcnM7XHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSBcImxlYWRzXCIpIHJldHVybiB0YWJsZUxlYWRzO1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJhZ2VudHNcIikgcmV0dXJuIHRhYmxlQWdlbnRzO1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJlbXBsb3llZXNcIikgcmV0dXJuIHRhYmxlRW1wbG95ZWVzO1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJsb2Fuc1wiKSByZXR1cm4gdGFibGVMb2FuczsgICAgLy8gTkVXXHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSBcInBpZ215XCIpIHJldHVybiB0YWJsZVBpZ215OyAgICAvLyBORVdcclxuICAgIHJldHVybiBjb21iaW5lZERhdGE7XHJcbiAgfSwgW2FjdGl2ZVRhYiwgdGFibGVVc2VycywgdGFibGVMZWFkcywgdGFibGVBZ2VudHMsIHRhYmxlRW1wbG95ZWVzLCB0YWJsZUxvYW5zLCB0YWJsZVBpZ215LCBjb21iaW5lZERhdGFdKTtcclxuXHJcbiAgLy8gQ3JlYXRlIEZ1c2UgaW5zdGFuY2VcclxuICBjb25zdCBmdXNlSW5zdGFuY2UgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGlmICghY3VycmVudERhdGFTb3VyY2UgfHwgY3VycmVudERhdGFTb3VyY2UubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcclxuICAgIHJldHVybiBuZXcgRnVzZShjdXJyZW50RGF0YVNvdXJjZSwge1xyXG4gICAgICBpbmNsdWRlU2NvcmU6IHRydWUsXHJcbiAgICAgIGtleXM6IHNlYXJjaGFibGVLZXlzLFxyXG4gICAgICB0aHJlc2hvbGQ6IDAuNSxcclxuICAgICAgaWdub3JlRmllbGROb3JtOiB0cnVlLFxyXG4gICAgfSk7XHJcbiAgfSwgW2N1cnJlbnREYXRhU291cmNlLCBzZWFyY2hhYmxlS2V5c10pO1xyXG5cclxuICBjb25zdCByYXdTZWFyY2hSZXN1bHRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoIWRlYm91bmNlZFNlYXJjaFRleHQudHJpbSgpIHx8ICFmdXNlSW5zdGFuY2UpIHJldHVybiBbXTtcclxuICAgIHJldHVybiBmdXNlSW5zdGFuY2Uuc2VhcmNoKGRlYm91bmNlZFNlYXJjaFRleHQpO1xyXG4gIH0sIFtkZWJvdW5jZWRTZWFyY2hUZXh0LCBmdXNlSW5zdGFuY2VdKTtcclxuXHJcbiAgY29uc3QgZ2V0UHJvY2Vzc2VkUmVzdWx0cyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIGlmICghZGVib3VuY2VkU2VhcmNoVGV4dC50cmltKCkpIHtcclxuICAgICAgcmV0dXJuIHsgbW9kZTogJ2FsbCcsIGRhdGFTb3VyY2U6IGN1cnJlbnREYXRhU291cmNlIH07XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHJhd1NlYXJjaFJlc3VsdHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHJldHVybiB7IG1vZGU6ICdzZWFyY2gnLCBoYXNSZXN1bHRzOiBmYWxzZSB9O1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBleGFjdE1hdGNoZXMgPSByYXdTZWFyY2hSZXN1bHRzLmZpbHRlcihyID0+IHIuc2NvcmUgPD0gMC4xKS5tYXAociA9PiByLml0ZW0pO1xyXG4gICAgbGV0IHJlbGF0ZWRNYXRjaGVzID0gcmF3U2VhcmNoUmVzdWx0cy5maWx0ZXIociA9PiByLnNjb3JlID4gMC4xKS5tYXAociA9PiByLml0ZW0pO1xyXG5cclxuICAgIGlmIChzZWxlY3RlZEV4YWN0TWF0Y2gpIHtcclxuICAgICAgaWYgKCFleGFjdE1hdGNoZXMuZmluZChtID0+IG0uX2lkID09PSBzZWxlY3RlZEV4YWN0TWF0Y2guX2lkKSkge1xyXG4gICAgICAgIGV4YWN0TWF0Y2hlcyA9IFtzZWxlY3RlZEV4YWN0TWF0Y2hdO1xyXG4gICAgICB9XHJcbiAgICAgIHJlbGF0ZWRNYXRjaGVzID0gcmVsYXRlZE1hdGNoZXMuZmlsdGVyKChpdGVtKSA9PiBpdGVtLl9pZCAhPT0gc2VsZWN0ZWRFeGFjdE1hdGNoLl9pZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgbW9kZTogJ3NlYXJjaCcsXHJcbiAgICAgIGV4YWN0TWF0Y2hlcyxcclxuICAgICAgcmVsYXRlZE1hdGNoZXMsXHJcbiAgICAgIGhhc1Jlc3VsdHM6IHRydWVcclxuICAgIH07XHJcbiAgfSwgW2RlYm91bmNlZFNlYXJjaFRleHQsIGN1cnJlbnREYXRhU291cmNlLCByYXdTZWFyY2hSZXN1bHRzLCBzZWxlY3RlZEV4YWN0TWF0Y2hdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRmlsdGVyVG9nZ2xlID0gKGlkKSA9PiB7XHJcbiAgICBzZXRBY3RpdmVGaWx0ZXJzKChwcmV2KSA9PiBwcmV2LmluY2x1ZGVzKGlkKSA/IHByZXYuZmlsdGVyKChmKSA9PiBmICE9PSBpZCkgOiBbLi4ucHJldiwgaWRdKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0gUmVuZGVyIEhlbHBlcnMgLS0tXHJcblxyXG4gIGNvbnN0IHJlbmRlckNvbnRlbnQgPSAoKSA9PiB7XHJcbiAgICBpZiAoaXNBbnlBcGlMb2FkaW5nKSB7XHJcbiAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktMTJcIj48Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSBmYWlsdXJlPXtmYWxzZX0gZGF0YT1cIlJlY29yZHNcIiAvPjwvZGl2PjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzZWFyY2hTdGF0ZSA9IGdldFByb2Nlc3NlZFJlc3VsdHMoKTtcclxuXHJcbiAgICAvLyBDYXNlIDE6IE5vIFNlYXJjaFxyXG4gICAgaWYgKHNlYXJjaFN0YXRlLm1vZGUgPT09ICdhbGwnKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgIDxUYWJsZSBwYWdpbmF0aW9uPXt7IHBhZ2VTaXplOiAxMCwgc2hvd1NpemVDaGFuZ2VyOiBmYWxzZSwgaGlkZU9uU2luZ2xlUGFnZTogdHJ1ZSB9fSBzY3JvbGw9e3sgeDogXCJtYXgtY29udGVudFwiIH19IGNvbHVtbnM9e2NvbHVtbnN9IGRhdGFTb3VyY2U9e3NlYXJjaFN0YXRlLmRhdGFTb3VyY2V9IHJvd0tleT1cIl9pZFwiIHNpemU9XCJtaWRkbGVcIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENhc2UgMjogTm8gUmVzdWx0c1xyXG4gICAgaWYgKCFzZWFyY2hTdGF0ZS5oYXNSZXN1bHRzKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcC0zIHJvdW5kZWQtZnVsbCBiZy1ncmF5LTEwMCBtYi0zXCI+PFNlYXJjaE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQteGwgdGV4dC1ncmF5LTQwMFwiIC8+PC9kaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+Tm8gbWF0Y2hlcyBmb3VuZCBpbiA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPnthY3RpdmVUYWIgPT09IFwiYWxsXCIgPyBcImFsbCByZWNvcmRzXCIgOiBhY3RpdmVUYWJ9PC9zcGFuPi48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gQ2FzZSAzOiBTZWFyY2ggUmVzdWx0c1xyXG4gICAgbGV0IHRvcFJlY29yZCA9IG51bGw7XHJcbiAgICBsZXQgdGFibGVSZWNvcmRzID0gW107XHJcblxyXG4gICAgaWYgKHNlYXJjaFN0YXRlLmV4YWN0TWF0Y2hlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHRvcFJlY29yZCA9IHNlYXJjaFN0YXRlLmV4YWN0TWF0Y2hlc1swXTtcclxuICAgICAgdGFibGVSZWNvcmRzID0gW1xyXG4gICAgICAgIC4uLnNlYXJjaFN0YXRlLmV4YWN0TWF0Y2hlcy5zbGljZSgxKSxcclxuICAgICAgICAuLi5zZWFyY2hTdGF0ZS5yZWxhdGVkTWF0Y2hlcyxcclxuICAgICAgXTtcclxuICAgIH0gZWxzZSBpZiAoc2VhcmNoU3RhdGUucmVsYXRlZE1hdGNoZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICB0b3BSZWNvcmQgPSBzZWFyY2hTdGF0ZS5yZWxhdGVkTWF0Y2hlc1swXTtcclxuICAgICAgdGFibGVSZWNvcmRzID0gc2VhcmNoU3RhdGUucmVsYXRlZE1hdGNoZXMuc2xpY2UoMSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdHlwZUluZm8gPSB0b3BSZWNvcmQgPyBnZXRUeXBlSW5mbyh0b3BSZWNvcmQpIDogbnVsbDtcclxuICAgIGNvbnN0IGFwcHJvdmFsU3RhdHVzID0gdG9wUmVjb3JkID8gZ2V0QXBwcm92YWxTdGF0dXModG9wUmVjb3JkKSA6IG51bGw7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgICB7LyogLS0tIFRPUCBIRVJPIENBUkQgLS0tICovfVxyXG4gICAgICAgIHt0b3BSZWNvcmQgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BtYi04IHJvdW5kZWQteGwgc2hhZG93LWxnIGJvcmRlci1sLTggJHt0eXBlSW5mby5ib3JkZXJ9IGJnLXdoaXRlIG92ZXJmbG93LWhpZGRlbmB9PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTZcIj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIExlZnQ6IFR5cGUgJiBJY29uICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BwLTQgcm91bmRlZC1mdWxsICR7dHlwZUluZm8uYmd9ICR7dHlwZUluZm8udGV4dH0gc2hhZG93LWlubmVyIGZsZXgtc2hyaW5rLTBgfT5cclxuICAgICAgICAgICAgICAgICAge3R5cGVJbmZvLmljb259XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yLjUgcHktMC41IHJvdW5kZWQgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgJHt0eXBlSW5mby5iZ30gJHt0eXBlSW5mby50ZXh0fWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3R5cGVJbmZvLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB7c2VhcmNoU3RhdGUuZXhhY3RNYXRjaGVzLmluY2x1ZGVzKHRvcFJlY29yZCkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTYwMCBiZy1ncmVlbi01MCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRXhhY3QgTWF0Y2hcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHthcHByb3ZhbFN0YXR1cyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGFnIGljb249e2FwcHJvdmFsU3RhdHVzLnRleHQgPT09IFwiQXBwcm92ZWRcIiA/IDxDaGVja0NpcmNsZU91dGxpbmVkIC8+IDogPENsb2NrQ2lyY2xlT3V0bGluZWQgLz59IGNvbG9yPXthcHByb3ZhbFN0YXR1cy5jb2xvcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthcHByb3ZhbFN0YXR1cy50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9UYWc+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57dG9wUmVjb3JkLm5hbWV9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOmdhcC02IG10LTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElkY2FyZE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+SUQ6IHt0b3BSZWNvcmQuY3VzdG9tZXJfaWR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxQaG9uZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3RvcFJlY29yZC5waG9uZV9udW1iZXJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogUmlnaHQ6IEFjdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBpY29uPXs8RXllT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcm91dGUgPSBcIiNcIjtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodG9wUmVjb3JkLmlzTGVhZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgcm91dGUgPSBgL3JlcG9ydHMvbGVhZC1yZXBvcnQ/bGVhZF9pZD0ke3RvcFJlY29yZC5faWR9YDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRvcFJlY29yZC5pc0FnZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICByb3V0ZSA9IGAvc3RhZmYtbWVudS9hZ2VudD9hZ2VudF9pZD0ke3RvcFJlY29yZC5faWR9YDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRvcFJlY29yZC5pc0VtcGxveWVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICByb3V0ZSA9IGAvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51L2VtcGxveWVlP2VtcGxveWVlX2lkPSR7dG9wUmVjb3JkLl9pZH1gO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodG9wUmVjb3JkLmlzTG9hbiB8fCB0b3BSZWNvcmQuaXNQaWdteSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXNlcklkID0gdG9wUmVjb3JkLnVzZXJfaWQgfHwgdG9wUmVjb3JkLl9pZDtcclxuICAgICAgICAgICAgICAgICAgICAgIHJvdXRlID0gYC9jdXN0b21lci12aWV3P3VzZXJfaWQ9JHt1c2VySWR9YDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgcm91dGUgPSBgL2N1c3RvbWVyLXZpZXc/dXNlcl9pZD0ke3RvcFJlY29yZC5faWR9YDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbmF2aWdhdGUocm91dGUpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEyIHB4LTYgcm91bmRlZC1sZyBzaGFkb3ctbWQgYmctdmlvbGV0LTYwMCBob3ZlcjpiZy12aW9sZXQtNzAwIGJvcmRlci1ub25lXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVmlldyBQcm9maWxlXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogT3B0aW9uYWw6IEV4dHJhIGRldGFpbHMgcm93ICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcHgtNiBweS0zIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy00IGdhcC00IHRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDBcIj5BYWRoYWFyPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge3RvcFJlY29yZC5hYWRoYWFyX251bWJlcn1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwXCI+UGFuPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge3RvcFJlY29yZC5wYW5fbnVtYmVyfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDBcIj5BcmVhPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge3RvcFJlY29yZC5jb2xsZWN0aW9uX2FyZWF9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMFwiPlN0YXR1czwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIHt0b3BSZWNvcmQuY3VzdG9tZXJfc3RhdHVzIHx8ICdBY3RpdmUnfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHsvKiAtLS0gQk9UVE9NIFRBQkxFIFNFQ1RJT04gLS0tICovfVxyXG4gICAgICAgIHt0YWJsZVJlY29yZHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBmb250LXNlbWlib2xkIG1iLTQgdGV4dC1sZyBib3JkZXItbC00IGJvcmRlci1ncmF5LTMwMCBwbC0zXCI+XHJcbiAgICAgICAgICAgICAgT3RoZXIgUmVzdWx0c1xyXG4gICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICA8VGFibGVcclxuICAgICAgICAgICAgICBwYWdpbmF0aW9uPXt7XHJcbiAgICAgICAgICAgICAgICAuLi5wYWdpbmF0aW9uLFxyXG4gICAgICAgICAgICAgICAgc2hvd1NpemVDaGFuZ2VyOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgc2hvd1RvdGFsOiAodG90YWwsIHJhbmdlKSA9PlxyXG4gICAgICAgICAgICAgICAgICBgJHtyYW5nZVswXX0tJHtyYW5nZVsxXX0gb2YgJHt0b3RhbH0gaXRlbXNgLFxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U6IChwYWdlLCBwYWdlU2l6ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRQYWdpbmF0aW9uKHtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50OiBwYWdlLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhZ2VTaXplOiBwYWdlU2l6ZSB8fCA1MCxcclxuICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgb25TaG93U2l6ZUNoYW5nZTogKGN1cnJlbnQsIHNpemUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0UGFnaW5hdGlvbih7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudDogMSxcclxuICAgICAgICAgICAgICAgICAgICBwYWdlU2l6ZTogNTAsXHJcbiAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIHNjcm9sbD17eyB4OiBcIm1heC1jb250ZW50XCIgfX1cclxuICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgIGRhdGFTb3VyY2U9e3RhYmxlUmVjb3Jkc31cclxuICAgICAgICAgICAgICByb3dLZXk9XCJfaWRcIlxyXG4gICAgICAgICAgICAgIHNpemU9XCJtaWRkbGVcIlxyXG4gICAgICAgICAgICAgIG9uUm93PXsocmVjb3JkKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgb25DbGljazogKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEV4YWN0TWF0Y2gocmVjb3JkKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgcm93Q2xhc3NOYW1lPXsoKSA9PiBcImN1cnNvci1wb2ludGVyIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1hbGxcIn1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8TmF2YmFyIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfSB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZyB0eXBlPXthbGVydENvbmZpZy50eXBlfSBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9IG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9IG9uQ2xvc2U9eygpID0+IHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSl9IC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHAtNCBtZDpwLTggbWQ6bXItMTEgcGItOFwiPlxyXG4gICAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBzbTp0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCBtYi0yXCI+QUkgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNzAwXCI+U2VhcmNoPC9zcGFuPjwvaDE+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgbWF4LXctMnhsXCI+UHJvZmVzc2lvbmFsIHNlYXJjaCByZXN1bHRzIHByaW9yaXRpemVkIGJ5IHJlbGV2YW5jZS48L3A+XHJcbiAgICAgICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJtYi02IHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGxcIiBib2R5U3R5bGU9e3sgcGFkZGluZzogXCIxLjI1cmVtXCIgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBsZzppdGVtcy1jZW50ZXIgbGc6anVzdGlmeS1iZXR3ZWVuIGdhcC01XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbGc6dy0xLzNcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IElELCBOYW1lLCBQaG9uZSwgQWFkaGFhciwgb3IgUGFuLi4uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRleHR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcGwtMTIgcHItNSBweS0yLjUgdGV4dC1zbSBzaGFkb3ctc20gZm9jdXM6Ym9yZGVyLXZpb2xldC02MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTIwMCBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxTZWFyY2hPdXRsaW5lZCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTQgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtZ3JheS00MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMi41IGp1c3RpZnktY2VudGVyIGxnOmp1c3RpZnktc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgIHtGSUxURVJTX0NPTkZJRy5tYXAoKGZpbHRlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGFjdGl2ZUZpbHRlcnMuaW5jbHVkZXMoZmlsdGVyLmlkKTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCBrZXk9e2ZpbHRlci5pZH0gdGl0bGU9e2BTZWFyY2ggYnkgJHtmaWx0ZXIuZmlsdGVyTmFtZX1gfSBwbGFjZW1lbnQ9XCJ0b3BcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlRmlsdGVyVG9nZ2xlKGZpbHRlci5pZCl9IGNsYXNzTmFtZT17YHB4LTQgcHktMS41IHRleHQtc20gZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke2lzQWN0aXZlID8gXCJiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgc2hhZG93XCIgOiBcImJnLWdyYXktMTAwIHRleHQtZ3JheS03MDAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBob3ZlcjpiZy1ncmF5LTIwMFwifWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyLmZpbHRlck5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L0NhcmQ+XHJcblxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LW1kIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgPFRhYnNcclxuICAgICAgICAgICAgICBkZWZhdWx0QWN0aXZlS2V5PVwiYWxsXCJcclxuICAgICAgICAgICAgICBhbmltYXRlZD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICBhY3RpdmVLZXk9e2FjdGl2ZVRhYn1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGtleSkgPT4gc2V0QWN0aXZlVGFiKGtleSl9XHJcbiAgICAgICAgICAgICAgaXRlbXM9e1tcclxuICAgICAgICAgICAgICAgIHsga2V5OiBcImFsbFwiLCBsYWJlbDogXCJBbGxcIiwgY2hpbGRyZW46IHJlbmRlckNvbnRlbnQoKSB9LFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6IFwiY3VzdG9tZXJzXCIsIGxhYmVsOiBcIkN1c3RvbWVyc1wiLCBjaGlsZHJlbjogcmVuZGVyQ29udGVudCgpIH0sXHJcbiAgICAgICAgICAgICAgICB7IGtleTogXCJsZWFkc1wiLCBsYWJlbDogXCJMZWFkc1wiLCBjaGlsZHJlbjogcmVuZGVyQ29udGVudCgpIH0sXHJcbiAgICAgICAgICAgICAgICB7IGtleTogXCJhZ2VudHNcIiwgbGFiZWw6IFwiQWdlbnRzXCIsIGNoaWxkcmVuOiByZW5kZXJDb250ZW50KCkgfSxcclxuICAgICAgICAgICAgICAgIHsga2V5OiBcImVtcGxveWVlc1wiLCBsYWJlbDogXCJFbXBsb3llZXNcIiwgY2hpbGRyZW46IHJlbmRlckNvbnRlbnQoKSB9LFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6IFwibG9hbnNcIiwgbGFiZWw6IFwiTG9hbnNcIiwgY2hpbGRyZW46IHJlbmRlckNvbnRlbnQoKSB9LCAgIC8vIE5FV1xyXG4gICAgICAgICAgICAgICAgeyBrZXk6IFwicGlnbXlcIiwgbGFiZWw6IFwiUGlnbXlcIiwgY2hpbGRyZW46IHJlbmRlckNvbnRlbnQoKSB9LCAgIC8vIE5FV1xyXG4gICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFF1aWNrU2VhcmNoOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9RdWlja1NlYXJjaC5qc3gifQ==