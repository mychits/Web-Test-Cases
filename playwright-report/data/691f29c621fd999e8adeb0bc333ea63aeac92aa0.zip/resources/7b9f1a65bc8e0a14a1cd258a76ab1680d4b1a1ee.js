import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/error/ErrorPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { FiRefreshCw, FiArrowLeftCircle } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
const ErrorBoundaryHandler = () => {
  _s();
  const navigate = useNavigate();
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center min-h-screen bg-gray-100 text-gray-800 px-6", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-xl text-center bg-white shadow-lg rounded-2xl p-10", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold mb-4 text-red-600", children: "Page Under Construction" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx",
      lineNumber: 10,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-lg text-gray-600 mb-8", children: "This page is currently under development." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx",
      lineNumber: 13,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-6", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => navigate(-1),
          className: "flex items-center gap-2 bg-violet-900 text-white px-4 py-2 rounded-xl hover:bg-violet-600 transition",
          children: [
            /* @__PURE__ */ jsxDEV(FiArrowLeftCircle, { className: "text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx",
              lineNumber: 22,
              columnNumber: 13
            }, this),
            "Go Back"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx",
          lineNumber: 18,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => window.location.reload(),
          className: "flex items-center gap-2 bg-green-900 text-white px-4 py-2 rounded-xl hover:bg-green-600 transition",
          children: [
            /* @__PURE__ */ jsxDEV(FiRefreshCw, { className: "text-xl animate-spin-slow" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx",
              lineNumber: 30,
              columnNumber: 13
            }, this),
            "Refresh"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx",
          lineNumber: 26,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx",
      lineNumber: 17,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx",
    lineNumber: 9,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx",
    lineNumber: 8,
    columnNumber: 5
  }, this);
};
_s(ErrorBoundaryHandler, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
  return [useNavigate];
});
_c = ErrorBoundaryHandler;
export default ErrorBoundaryHandler;
var _c;
$RefreshReg$(_c, "ErrorBoundaryHandler");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/error/ErrorPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1E7MkJBVFI7QUFBa0IsTUFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxhQUFhQyx5QkFBeUI7QUFDL0MsU0FBU0MsbUJBQW1CO0FBQzVCLE1BQU1DLHVCQUF1QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2pDLFFBQU1DLFdBQVdILFlBQVk7QUFFN0IsU0FDRSx1QkFBQyxTQUFJLFdBQVUseUZBQ2IsaUNBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLHdDQUF1Qyx1Q0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHlEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1HLFNBQVMsRUFBRTtBQUFBLFVBQzFCLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMscUJBQWtCLFdBQVUsYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUFHO0FBQUE7QUFBQTtBQUFBLFFBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNQyxPQUFPQyxTQUFTQyxPQUFPO0FBQUEsVUFDdEMsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxlQUFZLFdBQVUsK0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUEsWUFBRztBQUFBO0FBQUE7QUFBQSxRQUp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLE9BeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQTtBQUVKO0FBQUVKLEdBakNJRCxzQkFBb0I7QUFBQSxVQUNQRCxXQUFXO0FBQUE7QUFBQU8sS0FEeEJOO0FBbUNOLGVBQWVBO0FBQXFCLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJGaVJlZnJlc2hDdyIsIkZpQXJyb3dMZWZ0Q2lyY2xlIiwidXNlTmF2aWdhdGUiLCJFcnJvckJvdW5kYXJ5SGFuZGxlciIsIl9zIiwibmF2aWdhdGUiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsInJlbG9hZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVycm9yUGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBGaVJlZnJlc2hDdywgRmlBcnJvd0xlZnRDaXJjbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5jb25zdCBFcnJvckJvdW5kYXJ5SGFuZGxlciA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLXNjcmVlbiBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwIHB4LTZcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy14bCB0ZXh0LWNlbnRlciBiZy13aGl0ZSBzaGFkb3ctbGcgcm91bmRlZC0yeGwgcC0xMFwiPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGQgbWItNCB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgUGFnZSBVbmRlciBDb25zdHJ1Y3Rpb25cclxuICAgICAgICA8L2gxPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgdGV4dC1ncmF5LTYwMCBtYi04XCI+XHJcbiAgICAgICAgICAgVGhpcyBwYWdlIGlzIGN1cnJlbnRseSB1bmRlciBkZXZlbG9wbWVudC5cclxuICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoLTEpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy12aW9sZXQtOTAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQteGwgaG92ZXI6YmctdmlvbGV0LTYwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEZpQXJyb3dMZWZ0Q2lyY2xlIGNsYXNzTmFtZT1cInRleHQteGxcIiAvPlxyXG4gICAgICAgICAgICBHbyBCYWNrXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctZ3JlZW4tOTAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQteGwgaG92ZXI6YmctZ3JlZW4tNjAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8RmlSZWZyZXNoQ3cgY2xhc3NOYW1lPVwidGV4dC14bCBhbmltYXRlLXNwaW4tc2xvd1wiIC8+XHJcbiAgICAgICAgICAgIFJlZnJlc2hcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFcnJvckJvdW5kYXJ5SGFuZGxlcjtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3JvdXRlcy9lcnJvci9FcnJvclBhZ2UuanN4In0=