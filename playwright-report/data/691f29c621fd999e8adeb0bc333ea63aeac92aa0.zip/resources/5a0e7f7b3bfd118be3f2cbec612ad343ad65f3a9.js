import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LeadReferredByWhatsappMessage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, Input } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const LeadReferredByWhatsappMessage = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const [selectAll, setSelectAll] = useState(false);
  const [auctionData, setAuctionData] = useState([]);
  const today = /* @__PURE__ */ new Date();
  const todayString = today.toISOString().split("T")[0];
  const [selectedDate, setSelectedDate] = useState(todayString);
  const [selectedLabel, setSelectedLabel] = useState("All");
  const groupOptions = [
    ...new Set(
      usersData.filter(
        (u) => u.groupName !== void 0 && u.groupName !== "" && u.groupName !== "   "
      ).map((u) => u.groupName)
    )
  ];
  const filteredUsers = useMemo(() => {
    const filtered = usersData.filter((u) => {
      const matchGroup = groupFilter ? u.groupName === groupFilter : true;
      const matchSingleDate = selectedDate ? new Date(u.enrollDate).toISOString().split("T")[0] === selectedDate : true;
      const matchFromDate = fromDate ? new Date(u.enrollDate) >= new Date(fromDate) : true;
      const matchToDate = toDate ? new Date(u.enrollDate) <= new Date(toDate) : true;
      return matchGroup && matchFromDate && matchToDate && matchSingleDate;
    });
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    leadPhone: user.leadPhone,
                    groupName: user.groupName,
                    leadName: user.leadName,
                    referredBy: user.referredBy
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
            lineNumber: 180,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, selectedDate, activeUserData]);
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    const today2 = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      setSelectedDate(formatDate(today2));
      setFromDate("");
      setToDate("");
    } else if (value === "Yesterday") {
      const yesterday = new Date(today2);
      yesterday.setDate(yesterday.getDate() - 1);
      setSelectedDate(formatDate(yesterday));
      setFromDate("");
      setToDate("");
    } else if (value === "TwoDaysAgo") {
      const twoDaysAgo = new Date(today2);
      twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
      setSelectedDate(formatDate(twoDaysAgo));
      setFromDate("");
      setToDate("");
    } else if (value === "ThisWeek") {
      const day = today2.getDay();
      const diffToMonday = day === 0 ? 6 : day - 1;
      const monday = new Date(today2);
      monday.setDate(today2.getDate() - diffToMonday);
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      setFromDate(formatDate(monday));
      setToDate(formatDate(sunday));
      setSelectedDate("");
    } else if (value === "LastWeek") {
      const day = today2.getDay();
      const diffToMonday = day === 0 ? 6 : day - 1;
      const thisMonday = new Date(today2);
      thisMonday.setDate(today2.getDate() - diffToMonday);
      const lastMonday = new Date(thisMonday);
      lastMonday.setDate(thisMonday.getDate() - 7);
      const lastSunday = new Date(lastMonday);
      lastSunday.setDate(lastMonday.getDate() + 6);
      setFromDate(formatDate(lastMonday));
      setToDate(formatDate(lastSunday));
      setSelectedDate("");
    } else if (value === "ThisMonth") {
      const start = new Date(today2.getFullYear(), today2.getMonth(), 1);
      const end = new Date(today2.getFullYear(), today2.getMonth() + 1, 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "LastMonth") {
      const start = new Date(today2.getFullYear(), today2.getMonth() - 1, 1);
      const end = new Date(today2.getFullYear(), today2.getMonth(), 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "ThisYear") {
      const start = new Date(today2.getFullYear(), 0, 1);
      const end = new Date(today2.getFullYear(), 11, 31);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "All") {
      const start = new Date(2e3, 0, 1);
      const end = today2;
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "Custom") {
    }
  };
  useEffect(() => {
    handleSelectFilter("All");
  }, []);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp..",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      const test = await api.post("/whatsapp/lead-referred-by-message", {
        receivers: visibleActiveUsers
      });
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete newActiveUserData[user._id];
        }
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Has Been Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  useEffect(() => {
    const allChecked = filteredUsers.length > 0 && filteredUsers.every((user) => activeUserData[user._id]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredUsers, activeUserData]);
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/lead/get-lead");
      const usersList = [];
      const tempActive = {};
      const data = reportResponse.data?.map((lead, index) => {
        const id = lead._id;
        const leadName = lead?.lead_name;
        const leadPhone = lead?.lead_phone;
        const groupName = lead?.group_id?.group_name;
        const enrollDate = lead?.createdAt.split("T")[0];
        const referredBy = lead?.lead_agent?.name;
        tempActive[id] = {
          info: {
            status: false
          }
        };
        const tempUsr = {
          _id: id,
          leadName,
          leadPhone,
          groupName,
          // groupId,
          enrollmentDate: lead?.group_id?.createdAt,
          enrollDate,
          referredBy
          // leadenrollDate,
        };
        usersList.push(tempUsr);
        return {
          slNo: index + 1,
          groupName,
          leadName,
          leadPhone,
          //  groupId,
          referredBy,
          enrollDate
        };
      });
      console.info(data, "jkgnsdkgjsbng");
      setAuctionData(data);
      setUsersData(usersList);
      setActiveUserData(tempActive);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "checkBoxs", header: "Select User" },
    { key: "leadName", header: "Lead Name" },
    { key: "leadPhone", header: "Phone Number" },
    { key: "enrollDate", header: "Joined on" },
    { key: "referredBy", header: "Referred By" },
    // { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" }
    //  {key: "paymentsTicket", header: "Ticket"},
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
        lineNumber: 417,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
      lineNumber: 421,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
        lineNumber: 424,
        columnNumber: 14
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Lead ReferredBy Message" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
        lineNumber: 425,
        columnNumber: 11
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
          lineNumber: 430,
          columnNumber: 13
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
          lineNumber: 433,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
          lineNumber: 432,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Leads" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                  lineNumber: 440,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                  lineNumber: 441,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                lineNumber: 439,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                lineNumber: 445,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
              lineNumber: 438,
              columnNumber: 3
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                  lineNumber: 450,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                  lineNumber: 451,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                lineNumber: 449,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                lineNumber: 455,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
              lineNumber: 448,
              columnNumber: 3
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
            lineNumber: 437,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Select Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                lineNumber: 460,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  style: { width: 200 },
                  allowClear: true,
                  placeholder: "--All groups--",
                  onChange: (value) => setGroupFilter(value),
                  value: groupFilter || void 0,
                  className: "w-full max-w-xs h-11 ",
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 472,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                  lineNumber: 463,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
              lineNumber: 459,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mb-5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "font-medium", children: "Select Date Filter" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                lineNumber: 480,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  className: "border p-2 rounded text-sm",
                  value: selectedLabel,
                  onChange: (e) => handleSelectFilter(e.target.value),
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "Today", children: "Today" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 486,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 487,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "TwoDaysAgo", children: "Two Days Ago" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 488,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "ThisWeek", children: "This Week" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 489,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "LastWeek", children: "Last Week" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 490,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "ThisMonth", children: "This Month" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 491,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "LastMonth", children: "Last Month" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 492,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "ThisYear", children: "This Year" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 493,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "All", children: "All" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 494,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Custom", children: "Custom" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 495,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                  lineNumber: 481,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
              lineNumber: 479,
              columnNumber: 19
            }, this),
            selectedLabel && /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                lineNumber: 501,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "date",
                  value: selectedDate,
                  onChange: (e) => {
                    setSelectedDate(e.target?.value?.split("T")[0]);
                  },
                  className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full max-w-xs"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                  lineNumber: 502,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
              lineNumber: 500,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-5", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                lineNumber: 514,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  className: "ml-4 w-4 h-4 mb-3",
                  checked: selectAll,
                  onChange: (e) => {
                    const checked = e.target.checked;
                    setSelectAll(checked);
                    const updatedData = { ...activeUserData };
                    filteredUsers.forEach((user) => {
                      updatedData[user._id] = {
                        info: {
                          status: checked,
                          leadPhone: user.leadPhone,
                          groupName: user.groupName,
                          leadName: user.leadName,
                          referredBy: user.referredBy
                          // groupId: user.groupId?._id || user.groupId,
                          //  userId: user.userId,
                        }
                      };
                    });
                    setActiveUserData(updatedData);
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                  lineNumber: 517,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
              lineNumber: 513,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
            lineNumber: 458,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                      lineNumber: 557,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                    lineNumber: 553,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
                  lineNumber: 560,
                  columnNumber: 21
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
              lineNumber: 548,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
            lineNumber: 547,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Lead Refferred Whatsapp Message",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Lead Refferred Whatsapp Message.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
              lineNumber: 564,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
          lineNumber: 436,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
        lineNumber: 429,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
      lineNumber: 423,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
    lineNumber: 416,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx",
    lineNumber: 415,
    columnNumber: 5
  }, this);
};
_s(LeadReferredByWhatsappMessage, "hBQX0jBIJoGq/9LdF3OTbTN9l6A=", false, function() {
  return [notification.useNotification];
});
_c = LeadReferredByWhatsappMessage;
export default LeadReferredByWhatsappMessage;
var _c;
$RefreshReg$(_c, "LeadReferredByWhatsappMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReferredByWhatsappMessage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUxVOzJCQW5MVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLFFBQVFDLGFBQWE7QUFDOUIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFHdkIsTUFBTUMsZ0NBQWdDQSxNQUFNO0FBQUFDLEtBQUE7QUFDMUMsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlsQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUIsV0FBV0MsWUFBWSxJQUFJcEIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3FCLGFBQWFDLGNBQWMsSUFBSXRCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUN1QixVQUFVQyxXQUFXLElBQUl4QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDeUIsUUFBUUMsU0FBUyxJQUFJMUIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzJCLGdCQUFnQkMsaUJBQWlCLElBQUk1QixTQUFTLENBQUMsQ0FBQztBQUN2RCxRQUFNLENBQUM2QixXQUFXQyxZQUFZLElBQUk5QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDK0IsWUFBWUMsYUFBYSxJQUFJaEMsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ2lDLFVBQVVDLGFBQWEsSUFBSXhCLGFBQWF5QixnQkFBZ0I7QUFDL0QsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlyQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDc0MsYUFBYUMsY0FBYyxJQUFJdkMsU0FBUyxFQUFFO0FBQ2pELFFBQU13QyxRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFFBQU1DLGNBQWNGLE1BQU1HLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNwRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSTlDLFNBQVMwQyxXQUFXO0FBQzVELFFBQU0sQ0FBQ0ssZUFBZUMsZ0JBQWdCLElBQUloRCxTQUFTLEtBQUs7QUFFeEQsUUFBTWlELGVBQWU7QUFBQSxJQUNuQixHQUFHLElBQUlDO0FBQUFBLE1BQ0wvQixVQUNHZ0M7QUFBQUEsUUFDQyxDQUFDQyxNQUNDQSxFQUFFQyxjQUFjQyxVQUNoQkYsRUFBRUMsY0FBYyxNQUNoQkQsRUFBRUMsY0FBYztBQUFBLE1BQ3BCLEVBQ0NFLElBQUksQ0FBQ0gsTUFBTUEsRUFBRUMsU0FBUztBQUFBLElBQzNCO0FBQUEsRUFBQztBQWdISCxRQUFNRyxnQkFBZ0J2RCxRQUFRLE1BQU07QUFDbEMsVUFBTXdELFdBQVd0QyxVQUFVZ0MsT0FBTyxDQUFDQyxNQUFNO0FBQ3ZDLFlBQU1NLGFBQWFyQyxjQUFjK0IsRUFBRUMsY0FBY2hDLGNBQWM7QUFFL0QsWUFBTXNDLGtCQUFrQmQsZUFDcEIsSUFBSUosS0FBS1csRUFBRVEsVUFBVSxFQUFFakIsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDLE1BQU1DLGVBQ3ZEO0FBRUosWUFBTWdCLGdCQUFnQnRDLFdBQ2xCLElBQUlrQixLQUFLVyxFQUFFUSxVQUFVLEtBQUssSUFBSW5CLEtBQUtsQixRQUFRLElBQzNDO0FBRUosWUFBTXVDLGNBQWNyQyxTQUNoQixJQUFJZ0IsS0FBS1csRUFBRVEsVUFBVSxLQUFLLElBQUluQixLQUFLaEIsTUFBTSxJQUN6QztBQUVKLGFBQU9pQyxjQUFjRyxpQkFBaUJDLGVBQWVIO0FBQUFBLElBQ3ZELENBQUM7QUFFRCxXQUFPRixTQUFTRixJQUFJLENBQUNRLE1BQU1DLFVBQVU7QUFDbkMsWUFBTUMsYUFBYSxDQUFDLENBQUN0QyxlQUFlb0MsS0FBS0csR0FBRyxHQUFHQyxNQUFNQztBQUVyRCxhQUFPO0FBQUEsUUFDTCxHQUFHTDtBQUFBQSxRQUNITSxPQUFPTCxRQUFRO0FBQUEsUUFDZk0sV0FDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU0w7QUFBQUEsWUFDVCxVQUFVLENBQUNNLE1BQU07QUFDZjNDLGdDQUFrQixDQUFDNEMsVUFBVTtBQUFBLGdCQUMzQixHQUFHQTtBQUFBQSxnQkFDSCxDQUFDVCxLQUFLRyxHQUFHLEdBQUc7QUFBQSxrQkFDVkMsTUFBTTtBQUFBLG9CQUNKQyxRQUFRRyxFQUFFRSxPQUFPQztBQUFBQSxvQkFDakJDLFdBQVdaLEtBQUtZO0FBQUFBLG9CQUNoQnRCLFdBQVdVLEtBQUtWO0FBQUFBLG9CQUNoQnVCLFVBQVViLEtBQUthO0FBQUFBLG9CQUNmQyxZQUFZZCxLQUFLYztBQUFBQSxrQkFDbkI7QUFBQSxnQkFDRjtBQUFBLGNBQ0YsRUFBRTtBQUFBLFlBQ0o7QUFBQTtBQUFBLFVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWdCSTtBQUFBLFFBR05aO0FBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQzlDLFdBQVdFLGFBQWFFLFVBQVVFLFFBQVFvQixjQUFjbEIsY0FBYyxDQUFDO0FBRTNFLFFBQU1tRCxxQkFBcUJBLENBQUNDLFVBQVU7QUFDcEMvQixxQkFBaUIrQixLQUFLO0FBRXRCLFVBQU12QyxTQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFVBQU11QyxhQUFhQSxDQUFDQyxTQUFTQSxLQUFLQyxtQkFBbUIsT0FBTztBQUU1RCxRQUFJSCxVQUFVLFNBQVM7QUFDckJqQyxzQkFBZ0JrQyxXQUFXeEMsTUFBSyxDQUFDO0FBQ2pDaEIsa0JBQVksRUFBRTtBQUNkRSxnQkFBVSxFQUFFO0FBQUEsSUFDZCxXQUFXcUQsVUFBVSxhQUFhO0FBQ2hDLFlBQU1JLFlBQVksSUFBSTFDLEtBQUtELE1BQUs7QUFDaEMyQyxnQkFBVUMsUUFBUUQsVUFBVUUsUUFBUSxJQUFJLENBQUM7QUFDekN2QyxzQkFBZ0JrQyxXQUFXRyxTQUFTLENBQUM7QUFDckMzRCxrQkFBWSxFQUFFO0FBQ2RFLGdCQUFVLEVBQUU7QUFBQSxJQUNkLFdBQVdxRCxVQUFVLGNBQWM7QUFDakMsWUFBTU8sYUFBYSxJQUFJN0MsS0FBS0QsTUFBSztBQUNqQzhDLGlCQUFXRixRQUFRRSxXQUFXRCxRQUFRLElBQUksQ0FBQztBQUMzQ3ZDLHNCQUFnQmtDLFdBQVdNLFVBQVUsQ0FBQztBQUN0QzlELGtCQUFZLEVBQUU7QUFDZEUsZ0JBQVUsRUFBRTtBQUFBLElBQ2QsV0FBV3FELFVBQVUsWUFBWTtBQUMvQixZQUFNUSxNQUFNL0MsT0FBTWdELE9BQU87QUFDekIsWUFBTUMsZUFBZUYsUUFBUSxJQUFJLElBQUlBLE1BQU07QUFDM0MsWUFBTUcsU0FBUyxJQUFJakQsS0FBS0QsTUFBSztBQUM3QmtELGFBQU9OLFFBQVE1QyxPQUFNNkMsUUFBUSxJQUFJSSxZQUFZO0FBQzdDLFlBQU1FLFNBQVMsSUFBSWxELEtBQUtpRCxNQUFNO0FBQzlCQyxhQUFPUCxRQUFRTSxPQUFPTCxRQUFRLElBQUksQ0FBQztBQUNuQzdELGtCQUFZd0QsV0FBV1UsTUFBTSxDQUFDO0FBQzlCaEUsZ0JBQVVzRCxXQUFXVyxNQUFNLENBQUM7QUFDNUI3QyxzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCLFdBQVdpQyxVQUFVLFlBQVk7QUFDL0IsWUFBTVEsTUFBTS9DLE9BQU1nRCxPQUFPO0FBQ3pCLFlBQU1DLGVBQWVGLFFBQVEsSUFBSSxJQUFJQSxNQUFNO0FBQzNDLFlBQU1LLGFBQWEsSUFBSW5ELEtBQUtELE1BQUs7QUFDakNvRCxpQkFBV1IsUUFBUTVDLE9BQU02QyxRQUFRLElBQUlJLFlBQVk7QUFDakQsWUFBTUksYUFBYSxJQUFJcEQsS0FBS21ELFVBQVU7QUFDdENDLGlCQUFXVCxRQUFRUSxXQUFXUCxRQUFRLElBQUksQ0FBQztBQUMzQyxZQUFNUyxhQUFhLElBQUlyRCxLQUFLb0QsVUFBVTtBQUN0Q0MsaUJBQVdWLFFBQVFTLFdBQVdSLFFBQVEsSUFBSSxDQUFDO0FBQzNDN0Qsa0JBQVl3RCxXQUFXYSxVQUFVLENBQUM7QUFDbENuRSxnQkFBVXNELFdBQVdjLFVBQVUsQ0FBQztBQUNoQ2hELHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsV0FBV2lDLFVBQVUsYUFBYTtBQUNoQyxZQUFNZ0IsUUFBUSxJQUFJdEQsS0FBS0QsT0FBTXdELFlBQVksR0FBR3hELE9BQU15RCxTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUl6RCxLQUFLRCxPQUFNd0QsWUFBWSxHQUFHeEQsT0FBTXlELFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakV6RSxrQkFBWXdELFdBQVdlLEtBQUssQ0FBQztBQUM3QnJFLGdCQUFVc0QsV0FBV2tCLEdBQUcsQ0FBQztBQUN6QnBELHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsV0FBV2lDLFVBQVUsYUFBYTtBQUNoQyxZQUFNZ0IsUUFBUSxJQUFJdEQsS0FBS0QsT0FBTXdELFlBQVksR0FBR3hELE9BQU15RCxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ25FLFlBQU1DLE1BQU0sSUFBSXpELEtBQUtELE9BQU13RCxZQUFZLEdBQUd4RCxPQUFNeUQsU0FBUyxHQUFHLENBQUM7QUFDN0R6RSxrQkFBWXdELFdBQVdlLEtBQUssQ0FBQztBQUM3QnJFLGdCQUFVc0QsV0FBV2tCLEdBQUcsQ0FBQztBQUN6QnBELHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsV0FBV2lDLFVBQVUsWUFBWTtBQUMvQixZQUFNZ0IsUUFBUSxJQUFJdEQsS0FBS0QsT0FBTXdELFlBQVksR0FBRyxHQUFHLENBQUM7QUFDaEQsWUFBTUUsTUFBTSxJQUFJekQsS0FBS0QsT0FBTXdELFlBQVksR0FBRyxJQUFJLEVBQUU7QUFDaER4RSxrQkFBWXdELFdBQVdlLEtBQUssQ0FBQztBQUM3QnJFLGdCQUFVc0QsV0FBV2tCLEdBQUcsQ0FBQztBQUN6QnBELHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsV0FBV2lDLFVBQVUsT0FBTztBQUMxQixZQUFNZ0IsUUFBUSxJQUFJdEQsS0FBSyxLQUFNLEdBQUcsQ0FBQztBQUNqQyxZQUFNeUQsTUFBTTFEO0FBQ1poQixrQkFBWXdELFdBQVdlLEtBQUssQ0FBQztBQUM3QnJFLGdCQUFVc0QsV0FBV2tCLEdBQUcsQ0FBQztBQUN6QnBELHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsV0FBV2lDLFVBQVUsVUFBVTtBQUFBLElBQzdCO0FBQUEsRUFFSjtBQUVBaEYsWUFBVSxNQUFNO0FBQ2QrRSx1QkFBbUIsS0FBSztBQUFBLEVBQzFCLEdBQUcsRUFBRTtBQUVMLFFBQU1xQix1QkFBdUJsRyxRQUFRLE1BQU07QUFDekMsV0FBT3VELGNBQWNMLE9BQU8sQ0FBQ1ksU0FBU0EsS0FBS0UsVUFBVSxFQUFFbUM7QUFBQUEsRUFDekQsR0FBRyxDQUFDNUMsYUFBYSxDQUFDO0FBRWxCLFFBQU02QyxlQUFlLFlBQVk7QUFDL0IsVUFBTUMsTUFBTTtBQUNaLFFBQUk7QUFDRnJFLGVBQVNzRSxLQUFLO0FBQUEsUUFDWkQ7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RDLGFBQWE7QUFBQSxRQUNiQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUVELFlBQU1DLHFCQUFxQixDQUFDO0FBQzVCcEQsb0JBQWNxRCxRQUFRLENBQUM5QyxTQUFTO0FBQzlCLFlBQUlBLEtBQUtFLGNBQWN0QyxlQUFlb0MsS0FBS0csR0FBRyxHQUFHO0FBQy9DMEMsNkJBQW1CN0MsS0FBS0csR0FBRyxJQUFJdkMsZUFBZW9DLEtBQUtHLEdBQUc7QUFBQSxRQUN4RDtBQUFBLE1BQ0YsQ0FBQztBQUVELFlBQU00QyxPQUFPLE1BQU01RyxJQUFJNkcsS0FBSyxzQ0FBc0M7QUFBQSxRQUNoRUMsV0FBV0o7QUFBQUEsTUFDYixDQUFDO0FBR0QsWUFBTUssb0JBQW9CLEVBQUUsR0FBR3RGLGVBQWU7QUFDOUM2QixvQkFBY3FELFFBQVEsQ0FBQzlDLFNBQVM7QUFDOUIsWUFBSUEsS0FBS0UsWUFBWTtBQUNuQixpQkFBT2dELGtCQUFrQmxELEtBQUtHLEdBQUc7QUFBQSxRQUNuQztBQUFBLE1BQ0YsQ0FBQztBQUNEdEMsd0JBQWtCcUYsaUJBQWlCO0FBRW5DaEYsZUFBU3NFLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxTQUFTTyxLQUFLO0FBQ1pqRixlQUFTc0UsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhUyxJQUFJVixXQUFXO0FBQUEsUUFDNUJFLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFDQTVHLFlBQVUsTUFBTTtBQUVkLFVBQU1vSCxhQUNKM0QsY0FBYzRDLFNBQVMsS0FDdkI1QyxjQUFjNEQsTUFBTSxDQUFDckQsU0FBU3BDLGVBQWVvQyxLQUFLRyxHQUFHLEdBQUdDLE1BQU1DLE1BQU07QUFDdEUvQixpQkFBYThFLFVBQVU7QUFBQSxFQUN6QixHQUFHLENBQUMzRCxlQUFlN0IsY0FBYyxDQUFDO0FBRWxDLFFBQU0wRixZQUFZLFlBQVk7QUFDNUIsUUFBSTtBQUNGdkYsbUJBQWEsSUFBSTtBQUNqQixZQUFNd0YsaUJBQWlCLE1BQU1wSCxJQUFJcUgsSUFBSSxnQkFBZ0I7QUFFckQsWUFBTUMsWUFBWTtBQUNsQixZQUFNQyxhQUFhLENBQUM7QUFDcEIsWUFBTUMsT0FBT0osZUFBZUksTUFBTW5FLElBQUksQ0FBQ29FLE1BQU0zRCxVQUFVO0FBQ3JELGNBQU00RCxLQUFLRCxLQUFLekQ7QUFFaEIsY0FBTVUsV0FBVytDLE1BQU1FO0FBQ3ZCLGNBQU1sRCxZQUFZZ0QsTUFBTUc7QUFDeEIsY0FBTXpFLFlBQVlzRSxNQUFNSSxVQUFVQztBQUNsQyxjQUFNcEUsYUFBYStELE1BQU1NLFVBQVVyRixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQy9DLGNBQU1pQyxhQUFhOEMsTUFBTU8sWUFBWUM7QUFFckNWLG1CQUFXRyxFQUFFLElBQUk7QUFBQSxVQUNmekQsTUFBTTtBQUFBLFlBQ0pDLFFBQVE7QUFBQSxVQUNWO0FBQUEsUUFDRjtBQUVBLGNBQU1nRSxVQUFVO0FBQUEsVUFDZGxFLEtBQUswRDtBQUFBQSxVQUNMaEQ7QUFBQUEsVUFDQUQ7QUFBQUEsVUFDQXRCO0FBQUFBO0FBQUFBLFVBRUFnRixnQkFBZ0JWLE1BQU1JLFVBQVVFO0FBQUFBLFVBQ2hDckU7QUFBQUEsVUFDQWlCO0FBQUFBO0FBQUFBLFFBRUY7QUFDQTJDLGtCQUFVYyxLQUFLRixPQUFPO0FBRXRCLGVBQU87QUFBQSxVQUNMRyxNQUFNdkUsUUFBUTtBQUFBLFVBQ2RYO0FBQUFBLFVBQ0F1QjtBQUFBQSxVQUNBRDtBQUFBQTtBQUFBQSxVQUVBRTtBQUFBQSxVQUNBakI7QUFBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUNENEUsY0FBUXJFLEtBQUt1RCxNQUFNLGVBQWU7QUFFbENuRixxQkFBZW1GLElBQUk7QUFDbkJ0RyxtQkFBYW9HLFNBQVM7QUFDdEI1Rix3QkFBa0I2RixVQUFVO0FBQUEsSUFDOUIsU0FBU2dCLE9BQU87QUFDZEQsY0FBUUMsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxJQUM3QyxVQUFDO0FBQ0MzRyxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEvQixZQUFVLE1BQU07QUFDZHNILGNBQVU7QUFBQSxFQUNaLEdBQUcsRUFBRTtBQUVMLFFBQU1xQixpQkFBaUI7QUFBQSxJQUNyQixFQUFFcEMsS0FBSyxTQUFTcUMsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRXJDLEtBQUssYUFBYXFDLFFBQVEsY0FBYztBQUFBLElBQzFDLEVBQUVyQyxLQUFLLFlBQVlxQyxRQUFRLFlBQVk7QUFBQSxJQUN2QyxFQUFFckMsS0FBSyxhQUFhcUMsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRXJDLEtBQUssY0FBY3FDLFFBQVEsWUFBWTtBQUFBLElBQ3pDLEVBQUVyQyxLQUFLLGNBQWNxQyxRQUFRLGNBQWM7QUFBQTtBQUFBLElBRTNDLEVBQUVyQyxLQUFLLGFBQWFxQyxRQUFRLGFBQWE7QUFBQTtBQUFBLEVBQ3pDO0FBR0YsU0FDRSx1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyw2QkFBNkIsQ0FBQ3BFLE1BQU1yRCxjQUFjcUQsRUFBRUUsT0FBT00sS0FBSztBQUFBLFFBQ2hFLFlBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1CO0FBQUEsSUFFbkIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUVSLHVCQUFDLFNBQUksV0FBVSxpQkFDVjtBQUFBLDZCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVztBQUFBLE1BQ2QsdUJBQUMsUUFBRyxXQUFVLHVDQUFzQyx1Q0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQzdDO0FBQUFBLE1BQ0QsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBQ2pFTCxZQUNDLHVCQUFDLFNBQUksV0FBVSxVQUNiLGlDQUFDLGtCQUFlLE9BQU0sb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbURBQzdCO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlFQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLE9BQUUsV0FBVSx5QkFBd0IsMkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdEO0FBQUEsZ0JBQ2hELHVCQUFDLE9BQUUsV0FBVSxzQ0FDVjJCLHdCQUFjNEMsVUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFdBQVEsV0FBVSw4QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkM7QUFBQSxpQkFQL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLE9BQUUsV0FBVSx5QkFBd0Isa0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsZ0JBQ3ZELHVCQUFDLE9BQUUsV0FBVSxxQ0FDVkQsa0NBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLGlCQUFjLFdBQVUsNkJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtEO0FBQUEsaUJBUHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQW5CYztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CaEI7QUFBQSxVQUNnQix1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTyxFQUFFeUMsT0FBTyxJQUFJO0FBQUEsa0JBQ3BCO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaLFVBQVUsQ0FBQzdELFVBQVV6RCxlQUFleUQsS0FBSztBQUFBLGtCQUN6QyxPQUFPMUQsZUFBZWlDO0FBQUFBLGtCQUN0QixXQUFVO0FBQUEsa0JBRVRMLHVCQUFhTTtBQUFBQSxvQkFBSSxDQUFDc0YsVUFDakIsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLE9BQy9CQSxtQkFEaUJBLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxlQUFjLGtDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRDtBQUFBLGNBQ2pEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPOUY7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDd0IsTUFBTU8sbUJBQW1CUCxFQUFFRSxPQUFPTSxLQUFLO0FBQUEsa0JBRWxEO0FBQUEsMkNBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJCO0FBQUEsb0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQztBQUFBLG9CQUNuQyx1QkFBQyxZQUFPLE9BQU0sY0FBYSw0QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUM7QUFBQSxvQkFDdkMsdUJBQUMsWUFBTyxPQUFNLFlBQVcseUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtDO0FBQUEsb0JBQ2xDLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrQztBQUFBLG9CQUNsQyx1QkFBQyxZQUFPLE9BQU0sYUFBWSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0M7QUFBQSxvQkFDcEMsdUJBQUMsWUFBTyxPQUFNLGFBQVksMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUEsb0JBQ3BDLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrQztBQUFBLG9CQUNsQyx1QkFBQyxZQUFPLE9BQU0sT0FBTSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUI7QUFBQSxvQkFDdkIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZCO0FBQUE7QUFBQTtBQUFBLGdCQWQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FlQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBLFlBRUNoQyxpQkFDQyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFdBQU0sb0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBVztBQUFBLGNBQ1g7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9GO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQzBCLE1BQU07QUFDZnpCLG9DQUFnQnlCLEVBQUVFLFFBQVFNLE9BQU9uQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFBQSxrQkFDaEQ7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNNkY7QUFBQSxpQkFSL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBR0YsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBU1I7QUFBQUEsa0JBQ1QsVUFBVSxDQUFDbUMsTUFBTTtBQUNmLDBCQUFNRyxVQUFVSCxFQUFFRSxPQUFPQztBQUN6QnJDLGlDQUFhcUMsT0FBTztBQUVwQiwwQkFBTW9FLGNBQWMsRUFBRSxHQUFHbkgsZUFBZTtBQUd4QzZCLGtDQUFjcUQsUUFBUSxDQUFDOUMsU0FBUztBQUM5QitFLGtDQUFZL0UsS0FBS0csR0FBRyxJQUFJO0FBQUEsd0JBQ3RCQyxNQUFNO0FBQUEsMEJBQ0pDLFFBQVFNO0FBQUFBLDBCQUNSQyxXQUFXWixLQUFLWTtBQUFBQSwwQkFDaEJ0QixXQUFXVSxLQUFLVjtBQUFBQSwwQkFDaEJ1QixVQUFVYixLQUFLYTtBQUFBQSwwQkFDZkMsWUFBWWQsS0FBS2M7QUFBQUE7QUFBQUE7QUFBQUEsd0JBR25CO0FBQUEsc0JBQ0Y7QUFBQSxvQkFDRixDQUFDO0FBRURqRCxzQ0FBa0JrSCxXQUFXO0FBQUEsa0JBQy9CO0FBQUE7QUFBQSxnQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMEJJO0FBQUEsaUJBOUJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0NBO0FBQUEsZUF2RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3RkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU3pDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVRGO0FBQUFBLHVDQUF1QixLQUN0QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxpQ0FBaUNBLG9CQUFvQjtBQUFBLG9CQUU1RCxpQ0FBQyxVQUFNQSxrQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0QjtBQUFBO0FBQUEsa0JBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUVGLHVCQUFDLGNBQVcsV0FBVSxRQUFPLE1BQU0sTUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxnQkFBRztBQUFBO0FBQUE7QUFBQSxZQVozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTNDO0FBQUFBLGNBQ04sU0FBU2tGO0FBQUFBLGNBQ1QsU0FBUTtBQUFBLGNBQ1IsaUJBQWdCO0FBQUEsY0FDaEIsaUJBQWlCLENBQUMsWUFBWTtBQUFBLGNBQzlCLG1CQUFtQixDQUFDckgsV0FBVztBQUFBLGNBQy9CLGtCQUFrQjtBQUFBO0FBQUEsWUFQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTzBEO0FBQUEsYUF2STVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5SUE7QUFBQSxXQWhKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0pBO0FBQUEsU0F4SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlKQTtBQUFBLE9BaEtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpS0EsS0FsS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1LQTtBQUVKO0FBQUVMLEdBcmpCSUQsK0JBQTZCO0FBQUEsVUFTQ0wsYUFBYXlCLGVBQWU7QUFBQTtBQUFBNEcsS0FUMURoSTtBQXVqQk4sZUFBZUE7QUFBOEIsSUFBQWdJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIlNlbGVjdCIsIklucHV0IiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiRmFXaGF0c2FwcCIsIm5vdGlmaWNhdGlvbiIsIlNpZGViYXIiLCJGYVVzZXJzIiwiRmFDaGVja0NpcmNsZSIsIkJyZWFkY3J1bWIiLCJMZWFkUmVmZXJyZWRCeVdoYXRzYXBwTWVzc2FnZSIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ0b3RhbFVzZXJzIiwic2V0VG90YWxVc2VycyIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsImF1Y3Rpb25EYXRhIiwic2V0QXVjdGlvbkRhdGEiLCJ0b2RheSIsIkRhdGUiLCJ0b2RheVN0cmluZyIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJzZWxlY3RlZExhYmVsIiwic2V0U2VsZWN0ZWRMYWJlbCIsImdyb3VwT3B0aW9ucyIsIlNldCIsImZpbHRlciIsInUiLCJncm91cE5hbWUiLCJ1bmRlZmluZWQiLCJtYXAiLCJmaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWQiLCJtYXRjaEdyb3VwIiwibWF0Y2hTaW5nbGVEYXRlIiwiZW5yb2xsRGF0ZSIsIm1hdGNoRnJvbURhdGUiLCJtYXRjaFRvRGF0ZSIsInVzZXIiLCJpbmRleCIsImlzU2VsZWN0ZWQiLCJfaWQiLCJpbmZvIiwic3RhdHVzIiwic2xfbm8iLCJjaGVja0JveHMiLCJlIiwicHJldiIsInRhcmdldCIsImNoZWNrZWQiLCJsZWFkUGhvbmUiLCJsZWFkTmFtZSIsInJlZmVycmVkQnkiLCJoYW5kbGVTZWxlY3RGaWx0ZXIiLCJ2YWx1ZSIsImZvcm1hdERhdGUiLCJkYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwieWVzdGVyZGF5Iiwic2V0RGF0ZSIsImdldERhdGUiLCJ0d29EYXlzQWdvIiwiZGF5IiwiZ2V0RGF5IiwiZGlmZlRvTW9uZGF5IiwibW9uZGF5Iiwic3VuZGF5IiwidGhpc01vbmRheSIsImxhc3RNb25kYXkiLCJsYXN0U3VuZGF5Iiwic3RhcnQiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZW5kIiwidmlzaWJsZVNlbGVjdGVkQ291bnQiLCJsZW5ndGgiLCJzZW5kV2hhdHNhcHAiLCJrZXkiLCJvcGVuIiwibWVzc2FnZSIsImRlc2NyaXB0aW9uIiwiY2xhc3NOYW1lIiwiZHVyYXRpb24iLCJ2aXNpYmxlQWN0aXZlVXNlcnMiLCJmb3JFYWNoIiwidGVzdCIsInBvc3QiLCJyZWNlaXZlcnMiLCJuZXdBY3RpdmVVc2VyRGF0YSIsImVyciIsImFsbENoZWNrZWQiLCJldmVyeSIsImZldGNoRGF0YSIsInJlcG9ydFJlc3BvbnNlIiwiZ2V0IiwidXNlcnNMaXN0IiwidGVtcEFjdGl2ZSIsImRhdGEiLCJsZWFkIiwiaWQiLCJsZWFkX25hbWUiLCJsZWFkX3Bob25lIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwiY3JlYXRlZEF0IiwibGVhZF9hZ2VudCIsIm5hbWUiLCJ0ZW1wVXNyIiwiZW5yb2xsbWVudERhdGUiLCJwdXNoIiwic2xObyIsImNvbnNvbGUiLCJlcnJvciIsIkF1Y3Rpb25jb2x1bW5zIiwiaGVhZGVyIiwid2lkdGgiLCJncm91cCIsInVwZGF0ZWREYXRhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGVhZFJlZmVycmVkQnlXaGF0c2FwcE1lc3NhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIElucHV0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBGYVVzZXJzLCBGYUNoZWNrQ2lyY2xlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcblxyXG5jb25zdCBMZWFkUmVmZXJyZWRCeVdoYXRzYXBwTWVzc2FnZSA9ICgpID0+IHtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG90YWxVc2Vycywgc2V0VG90YWxVc2Vyc10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2F1Y3Rpb25EYXRhLCBzZXRBdWN0aW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IHRvZGF5U3RyaW5nID0gdG9kYXkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyaW5nKTtcclxuICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuICAvL2NvbnN0IGdyb3VwT3B0aW9ucyA9IFsuLi5uZXcgU2V0KHVzZXJzRGF0YS5tYXAoKHUpID0+IHUuZ3JvdXBOYW1lKSldO1xyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIC4uLm5ldyBTZXQoXHJcbiAgICAgIHVzZXJzRGF0YVxyXG4gICAgICAgIC5maWx0ZXIoXHJcbiAgICAgICAgICAodSkgPT5cclxuICAgICAgICAgICAgdS5ncm91cE5hbWUgIT09IHVuZGVmaW5lZCAmJlxyXG4gICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gXCJcIiAmJlxyXG4gICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gXCIgICBcIlxyXG4gICAgICAgIClcclxuICAgICAgICAubWFwKCh1KSA9PiB1Lmdyb3VwTmFtZSlcclxuICAgICksXHJcbiAgXTtcclxuICAvLyBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgLy8gICBjb25zdCBmaWx0ZXJlZCA9IHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuICAvLyAgICAgY29uc3QgbWF0Y2hHcm91cCA9IGdyb3VwRmlsdGVyID8gdS5ncm91cE5hbWUgPT09IGdyb3VwRmlsdGVyIDogdHJ1ZTtcclxuICAvLyAgICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSBuZXcgRGF0ZSh1LmVucm9sbG1lbnREYXRlKTtcclxuICAvLyAgICAgY29uc3QgZmlsdGVyRW5yb2xsRGF0ZSA9IHNlbGVjdGVkRGF0ZSA9PT0gdS5lbnJvbGxEYXRlXHJcbiAgLy8gICAgIGNvbnN0IG1hdGNoRnJvbURhdGUgPSBmcm9tRGF0ZVxyXG4gIC8vICAgICAgID8gZW5yb2xsbWVudERhdGUgPj0gbmV3IERhdGUoZnJvbURhdGUpXHJcbiAgLy8gICAgICAgOiB0cnVlO1xyXG4gIC8vICAgICBjb25zdCBtYXRjaFRvRGF0ZSA9IHRvRGF0ZSA/IGVucm9sbG1lbnREYXRlIDw9IG5ldyBEYXRlKHRvRGF0ZSkgOiB0cnVlO1xyXG4gIC8vICAgICByZXR1cm4gbWF0Y2hHcm91cCAmJiBtYXRjaEZyb21EYXRlICYmIG1hdGNoVG9EYXRlICYmIGZpbHRlckVucm9sbERhdGU7XHJcbiAgLy8gICB9KTtcclxuXHJcbiAgLy8gICByZXR1cm4gZmlsdGVyZWQubWFwKCh1c2VyLCBpbmRleCkgPT4ge1xyXG4gIC8vICAgICBjb25zdCBpc1NlbGVjdGVkID0gISFhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cztcclxuXHJcbiAgLy8gICAgIHJldHVybiB7XHJcbiAgLy8gICAgICAgLi4udXNlcixcclxuICAvLyAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4gIC8vICAgICAgIGNoZWNrQm94czogKFxyXG4gIC8vICAgICAgICAgPGlucHV0XHJcbiAgLy8gICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgLy8gICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgLy8gICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gIC8vICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gIC8vICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAvLyAgICAgICAgICAgICAgIFt1c2VyLl9pZF06IHtcclxuICAvLyAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gIC8vICAgICAgICAgICAgICAgICAgIHN0YXR1czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAvLyAgICAgICAgICAgICAgICAgICBsZWFkUGhvbmU6IHVzZXIubGVhZFBob25lLFxyXG4gIC8vICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbiAgLy8gICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgLy8gICAgICAgICAgICAgICAgICAgcmVmZXJyZWRCeTogdXNlci5yZWZlcnJlZEJ5LFxyXG4gIC8vICAgICAgICAgICAgICAgICB9LFxyXG4gIC8vICAgICAgICAgICAgICAgfSxcclxuICAvLyAgICAgICAgICAgICB9KSk7XHJcbiAgLy8gICAgICAgICAgIH19XHJcbiAgLy8gICAgICAgICAvPlxyXG4gIC8vICAgICAgICksXHJcbiAgLy8gICAgICAgaXNTZWxlY3RlZCxcclxuICAvLyAgICAgfTtcclxuICAvLyAgIH0pO1xyXG4gIC8vIH0sIFtcclxuICAvLyAgIHVzZXJzRGF0YSxcclxuICAvLyAgIGdyb3VwRmlsdGVyLFxyXG4gIC8vICAgZnJvbURhdGUsXHJcbiAgLy8gICB0b0RhdGUsXHJcbiAgLy8gICBzZWFyY2hUZXh0LFxyXG4gIC8vICAgYWN0aXZlVXNlckRhdGEsXHJcbiAgLy8gICBzZWFyY2hUZXh0LFxyXG4gIC8vICAgc2VsZWN0ZWREYXRlXHJcbiAgLy8gXSk7XHJcblxyXG4gIC8vICAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gIC8vICAgY29uc3QgZmlsdGVyZWQgPSB1c2Vyc0RhdGEuZmlsdGVyKCh1KSA9PiB7XHJcbiAgLy8gICAgIGNvbnN0IG1hdGNoR3JvdXAgPSBncm91cEZpbHRlciA/IHUuZ3JvdXBOYW1lID09PSBncm91cEZpbHRlciA6IHRydWU7XHJcbiAgLy8gICAgIGNvbnN0IGVucm9sbG1lbnREYXRlID0gbmV3IERhdGUodS5lbnJvbGxtZW50RGF0ZSk7XHJcblxyXG4gIC8vICAgICBjb25zdCBtYXRjaFNpbmdsZURhdGUgPSBzZWxlY3RlZERhdGVcclxuICAvLyAgICAgICA/IHUuZW5yb2xsRGF0ZSA9PT0gc2VsZWN0ZWREYXRlXHJcbiAgLy8gICAgICAgOiB0cnVlO1xyXG5cclxuICAvLyAgICAgY29uc3QgbWF0Y2hGcm9tRGF0ZSA9IGZyb21EYXRlXHJcbiAgLy8gICAgICAgPyBlbnJvbGxtZW50RGF0ZSA+PSBuZXcgRGF0ZShmcm9tRGF0ZSlcclxuICAvLyAgICAgICA6IHRydWU7XHJcblxyXG4gIC8vICAgICBjb25zdCBtYXRjaFRvRGF0ZSA9IHRvRGF0ZVxyXG4gIC8vICAgICAgID8gZW5yb2xsbWVudERhdGUgPD0gbmV3IERhdGUodG9EYXRlKVxyXG4gIC8vICAgICAgIDogdHJ1ZTtcclxuXHJcbiAgLy8gICAgIHJldHVybiBtYXRjaEdyb3VwICYmIG1hdGNoRnJvbURhdGUgJiYgbWF0Y2hUb0RhdGUgJiYgbWF0Y2hTaW5nbGVEYXRlO1xyXG4gIC8vICAgfSk7XHJcblxyXG4gIC8vICAgcmV0dXJuIGZpbHRlcmVkLm1hcCgodXNlciwgaW5kZXgpID0+IHtcclxuICAvLyAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXM7XHJcblxyXG4gIC8vICAgICByZXR1cm4ge1xyXG4gIC8vICAgICAgIC4uLnVzZXIsXHJcbiAgLy8gICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAvLyAgICAgICBjaGVja0JveHM6IChcclxuICAvLyAgICAgICAgIDxpbnB1dFxyXG4gIC8vICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gIC8vICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gIC8vICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAvLyAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuICAvLyAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgLy8gICAgICAgICAgICAgICBbdXNlci5faWRdOiB7XHJcbiAgLy8gICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAvLyAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgLy8gICAgICAgICAgICAgICAgICAgbGVhZFBob25lOiB1c2VyLmxlYWRQaG9uZSxcclxuICAvLyAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gIC8vICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gIC8vICAgICAgICAgICAgICAgICAgIHJlZmVycmVkQnk6IHVzZXIucmVmZXJyZWRCeSxcclxuICAvLyAgICAgICAgICAgICAgICAgfSxcclxuICAvLyAgICAgICAgICAgICAgIH0sXHJcbiAgLy8gICAgICAgICAgICAgfSkpO1xyXG4gIC8vICAgICAgICAgICB9fVxyXG4gIC8vICAgICAgICAgLz5cclxuICAvLyAgICAgICApLFxyXG4gIC8vICAgICAgIGlzU2VsZWN0ZWQsXHJcbiAgLy8gICAgIH07XHJcbiAgLy8gICB9KTtcclxuICAvLyB9LCBbXHJcbiAgLy8gICB1c2Vyc0RhdGEsXHJcbiAgLy8gICBncm91cEZpbHRlcixcclxuICAvLyAgIGZyb21EYXRlLFxyXG4gIC8vICAgdG9EYXRlLFxyXG4gIC8vICAgc2VsZWN0ZWREYXRlLFxyXG4gIC8vICAgYWN0aXZlVXNlckRhdGEsXHJcbiAgLy8gXSk7XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkVXNlcnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGZpbHRlcmVkID0gdXNlcnNEYXRhLmZpbHRlcigodSkgPT4ge1xyXG4gICAgICBjb25zdCBtYXRjaEdyb3VwID0gZ3JvdXBGaWx0ZXIgPyB1Lmdyb3VwTmFtZSA9PT0gZ3JvdXBGaWx0ZXIgOiB0cnVlO1xyXG5cclxuICAgICAgY29uc3QgbWF0Y2hTaW5nbGVEYXRlID0gc2VsZWN0ZWREYXRlXHJcbiAgICAgICAgPyBuZXcgRGF0ZSh1LmVucm9sbERhdGUpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdID09PSBzZWxlY3RlZERhdGVcclxuICAgICAgICA6IHRydWU7XHJcblxyXG4gICAgICBjb25zdCBtYXRjaEZyb21EYXRlID0gZnJvbURhdGVcclxuICAgICAgICA/IG5ldyBEYXRlKHUuZW5yb2xsRGF0ZSkgPj0gbmV3IERhdGUoZnJvbURhdGUpXHJcbiAgICAgICAgOiB0cnVlO1xyXG5cclxuICAgICAgY29uc3QgbWF0Y2hUb0RhdGUgPSB0b0RhdGVcclxuICAgICAgICA/IG5ldyBEYXRlKHUuZW5yb2xsRGF0ZSkgPD0gbmV3IERhdGUodG9EYXRlKVxyXG4gICAgICAgIDogdHJ1ZTtcclxuXHJcbiAgICAgIHJldHVybiBtYXRjaEdyb3VwICYmIG1hdGNoRnJvbURhdGUgJiYgbWF0Y2hUb0RhdGUgJiYgbWF0Y2hTaW5nbGVEYXRlO1xyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGZpbHRlcmVkLm1hcCgodXNlciwgaW5kZXgpID0+IHtcclxuICAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXM7XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnVzZXIsXHJcbiAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgICBjaGVja0JveHM6IChcclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICBbdXNlci5faWRdOiB7XHJcbiAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgbGVhZFBob25lOiB1c2VyLmxlYWRQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGxlYWROYW1lOiB1c2VyLmxlYWROYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHJlZmVycmVkQnk6IHVzZXIucmVmZXJyZWRCeSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApLFxyXG4gICAgICAgIGlzU2VsZWN0ZWQsXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICB9LCBbdXNlcnNEYXRhLCBncm91cEZpbHRlciwgZnJvbURhdGUsIHRvRGF0ZSwgc2VsZWN0ZWREYXRlLCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkTGFiZWwodmFsdWUpO1xyXG5cclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZSh0b2RheSkpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShcIlwiKTtcclxuICAgICAgc2V0VG9EYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHllc3RlcmRheS5zZXREYXRlKHllc3RlcmRheS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoeWVzdGVyZGF5KSk7XHJcbiAgICAgIHNldEZyb21EYXRlKFwiXCIpO1xyXG4gICAgICBzZXRUb0RhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlR3b0RheXNBZ29cIikge1xyXG4gICAgICBjb25zdCB0d29EYXlzQWdvID0gbmV3IERhdGUodG9kYXkpO1xyXG4gICAgICB0d29EYXlzQWdvLnNldERhdGUodHdvRGF5c0Fnby5nZXREYXRlKCkgLSAyKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUodHdvRGF5c0FnbykpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShcIlwiKTtcclxuICAgICAgc2V0VG9EYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzV2Vla1wiKSB7XHJcbiAgICAgIGNvbnN0IGRheSA9IHRvZGF5LmdldERheSgpOyAvLyBTdW5kYXk9MCwgTW9uZGF5PTEsIC4uLlxyXG4gICAgICBjb25zdCBkaWZmVG9Nb25kYXkgPSBkYXkgPT09IDAgPyA2IDogZGF5IC0gMTsgLy8gYWRqdXN0IGlmIHRvZGF5IGlzIFN1bmRheVxyXG4gICAgICBjb25zdCBtb25kYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIG1vbmRheS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIGRpZmZUb01vbmRheSk7XHJcbiAgICAgIGNvbnN0IHN1bmRheSA9IG5ldyBEYXRlKG1vbmRheSk7XHJcbiAgICAgIHN1bmRheS5zZXREYXRlKG1vbmRheS5nZXREYXRlKCkgKyA2KTtcclxuICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShtb25kYXkpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoc3VuZGF5KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdFdlZWtcIikge1xyXG4gICAgICBjb25zdCBkYXkgPSB0b2RheS5nZXREYXkoKTtcclxuICAgICAgY29uc3QgZGlmZlRvTW9uZGF5ID0gZGF5ID09PSAwID8gNiA6IGRheSAtIDE7XHJcbiAgICAgIGNvbnN0IHRoaXNNb25kYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHRoaXNNb25kYXkuc2V0RGF0ZSh0b2RheS5nZXREYXRlKCkgLSBkaWZmVG9Nb25kYXkpO1xyXG4gICAgICBjb25zdCBsYXN0TW9uZGF5ID0gbmV3IERhdGUodGhpc01vbmRheSk7XHJcbiAgICAgIGxhc3RNb25kYXkuc2V0RGF0ZSh0aGlzTW9uZGF5LmdldERhdGUoKSAtIDcpO1xyXG4gICAgICBjb25zdCBsYXN0U3VuZGF5ID0gbmV3IERhdGUobGFzdE1vbmRheSk7XHJcbiAgICAgIGxhc3RTdW5kYXkuc2V0RGF0ZShsYXN0TW9uZGF5LmdldERhdGUoKSArIDYpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKGxhc3RNb25kYXkpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUobGFzdFN1bmRheSkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbiAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkFsbFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUoMjAwMCwgMCwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IHRvZGF5O1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgIC8vIHVzZXIgc2VsZWN0cyBtYW51YWxseSDihpIgZG9u4oCZdCBvdmVycmlkZVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoXCJBbGxcIik7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCB2aXNpYmxlU2VsZWN0ZWRDb3VudCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGZpbHRlcmVkVXNlcnMuZmlsdGVyKCh1c2VyKSA9PiB1c2VyLmlzU2VsZWN0ZWQpLmxlbmd0aDtcclxuICB9LCBbZmlsdGVyZWRVc2Vyc10pO1xyXG5cclxuICBjb25zdCBzZW5kV2hhdHNhcHAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBrZXkgPSBcInVwZGF0YWJsZVwiO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU2VuZGluZyBNZXNzYWdlcyBWaWEgV2hhdHNhcHAuLlwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2Nlc3NpbmcuLi5cIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgdmlzaWJsZUFjdGl2ZVVzZXJzID0ge307XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQgJiYgYWN0aXZlVXNlckRhdGFbdXNlci5faWRdKSB7XHJcbiAgICAgICAgICB2aXNpYmxlQWN0aXZlVXNlcnNbdXNlci5faWRdID0gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCB0ZXN0ID0gYXdhaXQgYXBpLnBvc3QoXCIvd2hhdHNhcHAvbGVhZC1yZWZlcnJlZC1ieS1tZXNzYWdlXCIsIHtcclxuICAgICAgICByZWNlaXZlcnM6IHZpc2libGVBY3RpdmVVc2VycyxcclxuICAgICAgfSk7XHJcbiAgICAgIC8vIGNvbnNvbGUuaW5mbyh0ZXN0LCBcImhnaGdmZ2hnZmZcIik7XHJcblxyXG4gICAgICBjb25zdCBuZXdBY3RpdmVVc2VyRGF0YSA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCkge1xyXG4gICAgICAgICAgZGVsZXRlIG5ld0FjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBY3RpdmVVc2VyRGF0YShuZXdBY3RpdmVVc2VyRGF0YSk7XHJcblxyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJXaGF0c2FwcCBNZXNzYWdlcyBIYXMgQmVlbiBTZW50IFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlN1Y2Nlc3NcIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBTZW5kIFdoYXRzYXBwXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGVyci5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyBBdXRvbWF0aWNhbGx5IHVwZGF0ZSBzZWxlY3RBbGwgYmFzZWQgb24gZmlsdGVyZWRVc2Vyc1xyXG4gICAgY29uc3QgYWxsQ2hlY2tlZCA9XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMubGVuZ3RoID4gMCAmJlxyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmV2ZXJ5KCh1c2VyKSA9PiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cyk7XHJcbiAgICBzZXRTZWxlY3RBbGwoYWxsQ2hlY2tlZCk7XHJcbiAgfSwgW2ZpbHRlcmVkVXNlcnMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVwb3J0UmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2xlYWQvZ2V0LWxlYWRcIik7XHJcblxyXG4gICAgICBjb25zdCB1c2Vyc0xpc3QgPSBbXTtcclxuICAgICAgY29uc3QgdGVtcEFjdGl2ZSA9IHt9O1xyXG4gICAgICBjb25zdCBkYXRhID0gcmVwb3J0UmVzcG9uc2UuZGF0YT8ubWFwKChsZWFkLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGlkID0gbGVhZC5faWQ7XHJcbiAgICAgICAgLy8gIGNvbnN0IGdyb3VwSWQgPSBsZWFkPy5ncm91cF9pZDtcclxuICAgICAgICBjb25zdCBsZWFkTmFtZSA9IGxlYWQ/LmxlYWRfbmFtZTtcclxuICAgICAgICBjb25zdCBsZWFkUGhvbmUgPSBsZWFkPy5sZWFkX3Bob25lO1xyXG4gICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9IGxlYWQ/Lmdyb3VwX2lkPy5ncm91cF9uYW1lO1xyXG4gICAgICAgIGNvbnN0IGVucm9sbERhdGUgPSBsZWFkPy5jcmVhdGVkQXQuc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgICAgIGNvbnN0IHJlZmVycmVkQnkgPSBsZWFkPy5sZWFkX2FnZW50Py5uYW1lO1xyXG5cclxuICAgICAgICB0ZW1wQWN0aXZlW2lkXSA9IHtcclxuICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgY29uc3QgdGVtcFVzciA9IHtcclxuICAgICAgICAgIF9pZDogaWQsXHJcbiAgICAgICAgICBsZWFkTmFtZSxcclxuICAgICAgICAgIGxlYWRQaG9uZSxcclxuICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgIC8vIGdyb3VwSWQsXHJcbiAgICAgICAgICBlbnJvbGxtZW50RGF0ZTogbGVhZD8uZ3JvdXBfaWQ/LmNyZWF0ZWRBdCxcclxuICAgICAgICAgIGVucm9sbERhdGUsXHJcbiAgICAgICAgICByZWZlcnJlZEJ5LFxyXG4gICAgICAgICAgLy8gbGVhZGVucm9sbERhdGUsXHJcbiAgICAgICAgfTtcclxuICAgICAgICB1c2Vyc0xpc3QucHVzaCh0ZW1wVXNyKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgIGxlYWROYW1lLFxyXG4gICAgICAgICAgbGVhZFBob25lLFxyXG4gICAgICAgICAgLy8gIGdyb3VwSWQsXHJcbiAgICAgICAgICByZWZlcnJlZEJ5LFxyXG4gICAgICAgICAgZW5yb2xsRGF0ZSxcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuICAgICAgY29uc29sZS5pbmZvKGRhdGEsIFwiamtnbnNka2dqc2JuZ1wiKTtcclxuXHJcbiAgICAgIHNldEF1Y3Rpb25EYXRhKGRhdGEpO1xyXG4gICAgICBzZXRVc2Vyc0RhdGEodXNlcnNMaXN0KTsgLy8g4pyFIHVwZGF0ZSB1c2Vyc0RhdGEgZm9yIGZpbHRlcmluZyArIGNoZWNrYm94ZXNcclxuICAgICAgc2V0QWN0aXZlVXNlckRhdGEodGVtcEFjdGl2ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBBdWN0aW9uY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY2hlY2tCb3hzXCIsIGhlYWRlcjogXCJTZWxlY3QgVXNlclwiIH0sXHJcbiAgICB7IGtleTogXCJsZWFkTmFtZVwiLCBoZWFkZXI6IFwiTGVhZCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImxlYWRQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbERhdGVcIiwgaGVhZGVyOiBcIkpvaW5lZCBvblwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZEJ5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJjdXN0b21lcklkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgLy8gIHtrZXk6IFwicGF5bWVudHNUaWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwifSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciBtdC0yXCI+XHJcbiAgICAgICAgICAgIExlYWQgUmVmZXJyZWRCeSBNZXNzYWdlXHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1zdGFydCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgbWItNFwiPjwvZGl2PlxyXG4gICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgY29sb3I9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC02IG10LTggbWItNlwiPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5Ub3RhbCBMZWFkczwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4gICAgICAgIHtmaWx0ZXJlZFVzZXJzLmxlbmd0aH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFVc2VycyBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgdGV4dC00eGxcIiAvPlxyXG4gIDwvZGl2PlxyXG5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5TZWxlY3RlZCBDdXN0b21lcnM8L3A+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgIHt2aXNpYmxlU2VsZWN0ZWRDb3VudH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB0ZXh0LTR4bFwiIC8+XHJcbiAgPC9kaXY+XHJcbjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tQWxsIGdyb3Vwcy0tXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEdyb3VwRmlsdGVyKHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cEZpbHRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMSBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktMiBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+U2VsZWN0IERhdGUgRmlsdGVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWQgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VsZWN0RmlsdGVyKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVG9kYXlcIj5Ub2RheTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlllc3RlcmRheVwiPlllc3RlcmRheTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlR3b0RheXNBZ29cIj5Ud28gRGF5cyBBZ288L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUaGlzV2Vla1wiPlRoaXMgV2Vlazwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhc3RXZWVrXCI+TGFzdCBXZWVrPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVGhpc01vbnRoXCI+VGhpcyBNb250aDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhc3RNb250aFwiPkxhc3QgTW9udGg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUaGlzWWVhclwiPlRoaXMgWWVhcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFsbFwiPkFsbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkN1c3RvbVwiPkN1c3RvbTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZExhYmVsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5EYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRGF0ZShlLnRhcmdldD8udmFsdWU/LnNwbGl0KFwiVFwiKVswXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGwgbWF4LXcteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IHctNCBoLTQgbWItM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTsgLy8gU2V0IGdsb2JhbCBjaGVja2JveCBzdGF0ZVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZERhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBMb29wIHRocm91Z2ggYWxsIGZpbHRlcmVkIHVzZXJzIGFuZCBhcHBseSB0aGUgc2VsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhW3VzZXIuX2lkXSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWFkUGhvbmU6IHVzZXIubGVhZFBob25lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWFkTmFtZTogdXNlci5sZWFkTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmZXJyZWRCeTogdXNlci5yZWZlcnJlZEJ5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBncm91cElkOiB1c2VyLmdyb3VwSWQ/Ll9pZCB8fCB1c2VyLmdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHVwZGF0ZWREYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZW5kV2hhdHNhcHB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNiBoLTYgYWJzb2x1dGUgLXJpZ2h0LTMgLXRvcC0yIHNoYWRvdy1sZyBob3ZlcjpiZy1yZWQtNjAwIGJnLXJlZC00MDAgcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHt2aXNpYmxlU2VsZWN0ZWRDb3VudH0gY3VzdG9tZXJzYH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Zpc2libGVTZWxlY3RlZENvdW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwibXItMlwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFdoYXRzQXBwXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e0F1Y3Rpb25jb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiTGVhZCBSZWZmZXJyZWQgV2hhdHNhcHAgTWVzc2FnZVwiXHJcbiAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1wiR3JvdXAgTmFtZVwiXX1cclxuICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tncm91cEZpbHRlcl19XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BMZWFkIFJlZmZlcnJlZCBXaGF0c2FwcCBNZXNzYWdlLmNzdmB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IExlYWRSZWZlcnJlZEJ5V2hhdHNhcHBNZXNzYWdlO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvTGVhZFJlZmVycmVkQnlXaGF0c2FwcE1lc3NhZ2UuanN4In0=