import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeTarget.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Dropdown, Drawer } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore, IoMdAdd, IoMdClose } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Loader from "/src/components/loaders/CircularLoader.jsx";
import { Collapse } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FileTextOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaMoneyBill } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const today = /* @__PURE__ */ new Date();
const currentYear = today.getFullYear();
const currentMonth = String(today.getMonth() + 1).padStart(2, "0");
const currentYearMonth = `${currentYear}-${currentMonth}`;
function formatDate(date) {
  const year = date.getFullYear();
  const month = `0${date.getMonth() + 1}`.slice(-2);
  const day = `0${date.getDate()}`.slice(-2);
  return `${year}-${month}-${day}`;
}
const monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
];
const EmployeeTarget = () => {
  _s();
  const [selectedId, setSelectedId] = useState("all");
  const [employees, setEmployees] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: ""
  });
  const [initialDataLoading, setInitialDataLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [isBulkMode, setIsBulkMode] = useState(false);
  const [editTargetId, setEditTargetId] = useState(null);
  const [selectedDate, setSelectedDate] = useState(currentYearMonth);
  const [selectedPerson, setSelectedPerson] = useState(null);
  const [reload, setReload] = useState(0);
  const [targetData, setTargetData] = useState([]);
  const [monthValues, setMonthValues] = useState({
    January: 0,
    February: 0,
    March: 0,
    April: 0,
    May: 0,
    June: 0,
    July: 0,
    August: 0,
    September: 0,
    October: 0,
    November: 0,
    December: 0
  });
  const [fetchedTargetData, setFetchedTargetData] = useState(null);
  const alertShownRef = useRef({
    employees: false,
    targets: false
  });
  const parseDate = (dateString) => {
    const [year, month] = dateString.split("-");
    return {
      year,
      month: String(parseInt(month)).padStart(2, "0"),
      monthName: monthNames[parseInt(month) - 1]
    };
  };
  const formatToYearMonth = (year, month) => {
    return `${year}-${String(month).padStart(2, "0")}`;
  };
  const getMonthDateRange = (dateString) => {
    const { year, month } = parseDate(dateString);
    const startDate = new Date(year, parseInt(month) - 1, 1);
    const endDate = new Date(year, parseInt(month), 0);
    return {
      from_date: formatDate(startDate),
      to_date: formatDate(endDate)
    };
  };
  useEffect(() => {
    const fetchData = async () => {
      setInitialDataLoading(true);
      try {
        const employeeRes = await api.get("/employee");
        setEmployees(employeeRes.data?.employee || []);
        alertShownRef.current.employees = false;
      } catch (err) {
        console.error("Error fetching employees:", err);
        if (!alertShownRef.current.employees) {
          setAlertConfig({
            visibility: true,
            message: "Failed to load employees",
            type: "error"
          });
          alertShownRef.current.employees = true;
          setTimeout(() => {
            alertShownRef.current.employees = false;
          }, 3e3);
        }
      } finally {
        setInitialDataLoading(false);
      }
    };
    fetchData();
  }, [reload]);
  useEffect(() => {
    const abortController = new AbortController();
    setDataLoading(true);
    const fetchTargets = async () => {
      try {
        const { from_date, to_date } = getMonthDateRange(selectedDate);
        const res = await api.get("/target/employee", {
          params: {
            from_date,
            to_date
          },
          signal: abortController.signal
        });
        if (res.data.success && res.data.summaries) {
          setTargetData(res.data.summaries);
          alertShownRef.current.targets = false;
        } else {
          setTargetData([]);
        }
      } catch (err) {
        if (err.name !== "AbortError") {
          console.error("Error fetching targets:", err);
          if (!alertShownRef.current.targets) {
            alertShownRef.current.targets = true;
            setTimeout(() => {
              alertShownRef.current.targets = false;
            }, 3e3);
          }
          setTargetData([]);
        }
      } finally {
        if (!abortController.signal.aborted) {
          setDataLoading(false);
        }
      }
    };
    if (!initialDataLoading) {
      fetchTargets();
    }
    return () => {
      abortController.abort();
    };
  }, [selectedDate, initialDataLoading, reload]);
  useEffect(() => {
    if (targetData.length > 0) {
      let filteredData = targetData;
      if (selectedId !== "all") {
        filteredData = targetData.filter(
          (item) => item.agent.id === selectedId
        );
      }
      const anyTargetExists = filteredData.some(
        (item) => item.agent.target.value !== "Not Set"
      );
      const formattedData = filteredData.map((item) => {
        const hasTarget = item.agent.target.value !== "Not Set";
        const dropdownItems = [{ key: "update", label: "Edit Target" }];
        if (!hasTarget) {
          dropdownItems.unshift({ key: "set", label: "Set Target" });
        }
        const actionDropdown = /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            menu: {
              items: dropdownItems,
              onClick: ({ key }) => {
                if (key === "set") {
                  setIsBulkMode(false);
                  setIsEditMode(false);
                  openSetDrawer(item);
                }
                if (key === "update") {
                  setIsBulkMode(false);
                  setIsEditMode(true);
                  openEditDrawer(item);
                }
              }
            },
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 236,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
            lineNumber: 218,
            columnNumber: 9
          },
          this
        );
        return {
          name: item.agent.name,
          phone_number: item.agent.phone,
          actual_business: item?.metrics?.actual_business,
          target_difference: item?.metrics?.target_difference,
          target_remaining_digits: item?.metrics?.target_remaining_digits,
          target: item.agent?.target?.value,
          action: actionDropdown,
          _item: item
        };
      });
      setTableData(formattedData);
    } else {
      setTableData([]);
    }
  }, [selectedId, targetData]);
  const fetchTargetDetails = async (item) => {
    try {
      const { year } = parseDate(selectedDate);
      const res = await api.get(`/target/agent/${item.agent.id}`, {
        params: { year }
      });
      let monthData = null;
      if (res.data && res.data.length > 0) {
        const target = res.data[0];
        monthData = target.monthData || null;
      }
      setFetchedTargetData(monthData);
      return monthData;
    } catch (err) {
      console.error("Error fetching target details:", err);
      setFetchedTargetData(null);
      return null;
    }
  };
  const openSetDrawer = async (item) => {
    setSelectedPerson(item);
    setIsEditMode(false);
    setIsBulkMode(false);
    setEditTargetId(item.agent.id);
    const monthData = await fetchTargetDetails(item);
    const monthValues2 = {
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0
    };
    if (monthData) {
      Object.keys(monthValues2).forEach((month) => {
        monthValues2[month] = monthData[month] || 0;
      });
    }
    setMonthValues(monthValues2);
    setDrawerVisible(true);
  };
  const openEditDrawer = async (item) => {
    setSelectedPerson(item);
    setIsEditMode(true);
    setIsBulkMode(false);
    setEditTargetId(item.agent.id);
    const monthData = await fetchTargetDetails(item);
    const monthValues2 = {
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0
    };
    if (monthData) {
      Object.keys(monthValues2).forEach((month) => {
        monthValues2[month] = monthData[month] || 0;
      });
    }
    setMonthValues(monthValues2);
    setDrawerVisible(true);
  };
  const openBulkDrawer = () => {
    setIsBulkMode(true);
    setIsEditMode(false);
    setDrawerVisible(true);
    setMonthValues({
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0
    });
  };
  const handleMonthChange = (month, value) => {
    setMonthValues((prev) => ({
      ...prev,
      [month]: value === "" ? "" : Number(value)
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { year } = parseDate(selectedDate);
      if (isBulkMode) {
        const agentIds = employees.map((e2) => e2._id);
        await api.patch(`/target/bulk`, {
          agentIds,
          year,
          monthValues
        });
      } else {
        await api.patch(
          `/target/agent/${editTargetId}?year=${year}`,
          monthValues
        );
      }
      setAlertConfig({
        visibility: true,
        message: isBulkMode ? "Bulk targets updated successfully" : isEditMode ? "Target updated successfully" : "Target set successfully",
        type: "success"
      });
      setDrawerVisible(false);
      setReload((prev) => prev + 1);
    } catch (err) {
      console.error("Submit failed", err);
      setAlertConfig({
        visibility: true,
        message: isBulkMode ? "Bulk update failed" : isEditMode ? "Update failed" : "Add failed",
        type: "error"
      });
    }
  };
  const getColumns = () => {
    return [
      { key: "name", header: "Name" },
      { key: "phone_number", header: "Phone Number" },
      { key: "target", header: "Target" },
      { key: "actual_business", header: "Actual Business" },
      { key: "target_difference", header: "Target Difference" },
      { key: "target_remaining_digits", header: "Target Remaining Digits" },
      { key: "action", header: "Action" }
    ];
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
        lineNumber: 441,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
        lineNumber: 442,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => {
            setAlertConfig((prev) => ({ ...prev, visibility: false }));
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
          lineNumber: 443,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-6", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
          lineNumber: 453,
          columnNumber: 14
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Employee Targets Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
            lineNumber: 455,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: openBulkDrawer,
              className: "flex items-center bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700",
              children: [
                /* @__PURE__ */ jsxDEV(IoMdAdd, { className: "mr-2" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                  lineNumber: 460,
                  columnNumber: 15
                }, this),
                " Bulk Update Targets"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 456,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
          lineNumber: 454,
          columnNumber: 11
        }, this),
        initialDataLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(Loader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
          lineNumber: 466,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
          lineNumber: 465,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "my-6", children: /* @__PURE__ */ jsxDEV(
            Collapse,
            {
              items: [
                {
                  key: "1",
                  label: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-base", children: "Shortcut Keys" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                    lineNumber: 476,
                    columnNumber: 19
                  }, this),
                  children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-4", children: [
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/reports/target-commission",
                        className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-blue-500 hover:text-blue-600 transition-colors",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            FaRupeeSign,
                            {
                              className: "text-blue-500",
                              size: 30
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                              lineNumber: 486,
                              columnNumber: 29
                            },
                            this
                          ),
                          "Commission Report"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                        lineNumber: 482,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/reports/target-incentive",
                        className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-blue-500 hover:text-blue-600 transition-colors",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            FileTextOutlined,
                            {
                              className: "text-blue-500",
                              size: 30
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                              lineNumber: 497,
                              columnNumber: 29
                            },
                            this
                          ),
                          "Incentive Report"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                        lineNumber: 493,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
                        className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-blue-500 hover:text-blue-600 transition-colors",
                        children: [
                          /* @__PURE__ */ jsxDEV(FaMoneyBill, { className: "text-blue-500", size: 30 }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                            lineNumber: 508,
                            columnNumber: 29
                          }, this),
                          "Salary Payout"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                        lineNumber: 504,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                    lineNumber: 481,
                    columnNumber: 19
                  }, this)
                }
              ],
              defaultActiveKey: ["1"],
              className: "rounded-lg border border-gray-200 bg-white shadow-sm"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 471,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
            lineNumber: 470,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 flex-wrap mb-6 items-end", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Employee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 522,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  className: "p-2 border rounded w-full min-w-[200px]",
                  value: selectedId,
                  onChange: (e) => setSelectedId(e.target.value),
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "all", children: "All Employees" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                      lineNumber: 530,
                      columnNumber: 21
                    }, this),
                    employees.map(
                      (employee) => /* @__PURE__ */ jsxDEV("option", { value: employee._id, children: employee.name || "Unknown Employee" }, employee._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                        lineNumber: 532,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                  lineNumber: 525,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 521,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Target Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 540,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "month",
                  className: "p-2 border rounded w-full min-w-[150px]",
                  value: selectedDate,
                  onChange: (e) => setSelectedDate(e.target.value),
                  max: formatToYearMonth(currentYear, currentMonth)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                  lineNumber: 543,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 539,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
            lineNumber: 519,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative min-h-[200px]", children: [
            dataLoading && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-white bg-opacity-70 flex items-center justify-center z-10", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-10 w-10 border-4 border-blue-600 border-t-transparent" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 556,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 555,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: tableData,
                columns: getColumns(),
                exportedPdfName: "Employee-Target-Report",
                exportedFileName: "Employee-Target-Report.csv"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 559,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
            lineNumber: 553,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
          lineNumber: 469,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
        lineNumber: 452,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
      lineNumber: 440,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { children: isBulkMode ? "Bulk Update Targets" : isEditMode ? "Edit Target" : "Set Target" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
            lineNumber: 575,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setDrawerVisible(false),
              className: "text-gray-500 hover:text-gray-700",
              children: /* @__PURE__ */ jsxDEV(IoMdClose, { size: 20 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 586,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 582,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
          lineNumber: 574,
          columnNumber: 9
        }, this),
        placement: "right",
        closable: false,
        onClose: () => setDrawerVisible(false),
        open: drawerVisible,
        width: 500,
        className: "target-drawer",
        styles: {
          body: {
            padding: 0,
            overflow: "hidden"
          },
          header: {
            borderBottom: "1px solid #f0f0f0",
            padding: "16px 24px"
          }
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-4", children: [
          !isBulkMode && selectedPerson && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: "Target For" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 611,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full p-2 border rounded bg-gray-50", children: selectedPerson.agent.name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 612,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
            lineNumber: 610,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: "Year" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 620,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full p-2 border rounded bg-gray-50", children: parseDate(selectedDate).year }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 621,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 619,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: "Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 626,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full p-2 border rounded bg-gray-50", children: parseDate(selectedDate).monthName }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 627,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 625,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
            lineNumber: 618,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: monthNames.map(
            (month) => /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: month }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 636,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: "₹" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                  lineNumber: 638,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    value: monthValues[month],
                    onChange: (e) => handleMonthChange(month, e.target.value),
                    className: "w-full p-2 border rounded",
                    min: "0",
                    placeholder: `Enter ${month} target`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                    lineNumber: 639,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 637,
                columnNumber: 19
              }, this),
              monthValues[month] > 0 && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 mt-1 italic", children: numberToIndianWords(monthValues[month]) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
                lineNumber: 649,
                columnNumber: 17
              }, this)
            ] }, month, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 635,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
            lineNumber: 633,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700 mt-6",
              children: isBulkMode ? "Update All Targets" : isEditMode ? "Update Target" : "Save Target"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
              lineNumber: 657,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
          lineNumber: 608,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
          lineNumber: 607,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
        lineNumber: 572,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx",
    lineNumber: 439,
    columnNumber: 5
  }, this);
};
_s(EmployeeTarget, "AdR394h+bOa5otUGvFRDEpAfW6s=");
_c = EmployeeTarget;
export default EmployeeTarget;
var _c;
$RefreshReg$(_c, "EmployeeTarget");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeTarget.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMk9ZLFNBeU9BLFVBek9BOzJCQTNPWjtBQUFvQkEsb0JBQWdCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLFVBQVVDLFNBQVNDLGlCQUFpQjtBQUM3QyxPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyx3QkFBdUI7QUFDaEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDJCQUEyQjtBQUVwQyxTQUFTQyxtQkFBbUI7QUFDNUIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsTUFBTUMsY0FBY0YsTUFBTUcsWUFBWTtBQUN0QyxNQUFNQyxlQUFlQyxPQUFPTCxNQUFNTSxTQUFTLElBQUksQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUNqRSxNQUFNQyxtQkFBbUIsR0FBR04sV0FBVyxJQUFJRSxZQUFZO0FBRXZELFNBQVNLLFdBQVdDLE1BQU07QUFDeEIsUUFBTUMsT0FBT0QsS0FBS1AsWUFBWTtBQUM5QixRQUFNUyxRQUFRLElBQUlGLEtBQUtKLFNBQVMsSUFBSSxDQUFDLEdBQUdPLE1BQU0sRUFBRTtBQUNoRCxRQUFNQyxNQUFNLElBQUlKLEtBQUtLLFFBQVEsQ0FBQyxHQUFHRixNQUFNLEVBQUU7QUFDekMsU0FBTyxHQUFHRixJQUFJLElBQUlDLEtBQUssSUFBSUUsR0FBRztBQUNoQztBQUVBLE1BQU1FLGFBQWE7QUFBQSxFQUNqQjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQVU7QUFHWixNQUFNQyxpQkFBaUJBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSXZDLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUN3QyxXQUFXQyxZQUFZLElBQUl6QyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDMEMsV0FBV0MsWUFBWSxJQUFJM0MsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzRDLGVBQWVDLGdCQUFnQixJQUFJN0MsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzhDLGFBQWFDLGNBQWMsSUFBSS9DLFNBQVM7QUFBQSxJQUM3Q2dELFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0Msb0JBQW9CQyxxQkFBcUIsSUFBSXBELFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUNxRCxhQUFhQyxjQUFjLElBQUl0RCxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDdUQsWUFBWUMsYUFBYSxJQUFJeEQsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ3lELFlBQVlDLGFBQWEsSUFBSTFELFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUMyRCxjQUFjQyxlQUFlLElBQUk1RCxTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDNkQsY0FBY0MsZUFBZSxJQUFJOUQsU0FBUzJCLGdCQUFnQjtBQUNqRSxRQUFNLENBQUNvQyxnQkFBZ0JDLGlCQUFpQixJQUFJaEUsU0FBUyxJQUFJO0FBQ3pELFFBQU0sQ0FBQ2lFLFFBQVFDLFNBQVMsSUFBSWxFLFNBQVMsQ0FBQztBQUN0QyxRQUFNLENBQUNtRSxZQUFZQyxhQUFhLElBQUlwRSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDcUUsYUFBYUMsY0FBYyxJQUFJdEUsU0FBUztBQUFBLElBQzdDdUUsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLElBQ1BDLEtBQUs7QUFBQSxJQUNMQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsSUFDWEMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxtQkFBbUJDLG9CQUFvQixJQUFJcEYsU0FBUyxJQUFJO0FBRS9ELFFBQU1xRixnQkFBZ0JDLE9BQU87QUFBQSxJQUMzQjlDLFdBQVc7QUFBQSxJQUNYK0MsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1DLFlBQVlBLENBQUNDLGVBQWU7QUFDaEMsVUFBTSxDQUFDM0QsTUFBTUMsS0FBSyxJQUFJMEQsV0FBV0MsTUFBTSxHQUFHO0FBQzFDLFdBQU87QUFBQSxNQUNMNUQ7QUFBQUEsTUFDQUMsT0FBT1AsT0FBT21FLFNBQVM1RCxLQUFLLENBQUMsRUFBRUwsU0FBUyxHQUFHLEdBQUc7QUFBQSxNQUM5Q2tFLFdBQVd6RCxXQUFXd0QsU0FBUzVELEtBQUssSUFBSSxDQUFDO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBRUEsUUFBTThELG9CQUFvQkEsQ0FBQy9ELE1BQU1DLFVBQVU7QUFDekMsV0FBTyxHQUFHRCxJQUFJLElBQUlOLE9BQU9PLEtBQUssRUFBRUwsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQ2xEO0FBRUEsUUFBTW9FLG9CQUFvQkEsQ0FBQ0wsZUFBZTtBQUN4QyxVQUFNLEVBQUUzRCxNQUFNQyxNQUFNLElBQUl5RCxVQUFVQyxVQUFVO0FBQzVDLFVBQU1NLFlBQVksSUFBSTNFLEtBQUtVLE1BQU02RCxTQUFTNUQsS0FBSyxJQUFJLEdBQUcsQ0FBQztBQUN2RCxVQUFNaUUsVUFBVSxJQUFJNUUsS0FBS1UsTUFBTTZELFNBQVM1RCxLQUFLLEdBQUcsQ0FBQztBQUVqRCxXQUFPO0FBQUEsTUFDTGtFLFdBQVdyRSxXQUFXbUUsU0FBUztBQUFBLE1BQy9CRyxTQUFTdEUsV0FBV29FLE9BQU87QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFFQUcsWUFBVSxNQUFNO0FBQ2QsVUFBTUMsWUFBWSxZQUFZO0FBQzVCaEQsNEJBQXNCLElBQUk7QUFDMUIsVUFBSTtBQUVGLGNBQU1pRCxjQUFjLE1BQU1sRyxJQUFJbUcsSUFBSSxXQUFXO0FBRTdDN0QscUJBQWE0RCxZQUFZRSxNQUFNQyxZQUFZLEVBQUU7QUFFN0NuQixzQkFBY29CLFFBQVFqRSxZQUFZO0FBQUEsTUFDcEMsU0FBU2tFLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0sNkJBQTZCRixHQUFHO0FBRTlDLFlBQUksQ0FBQ3JCLGNBQWNvQixRQUFRakUsV0FBVztBQUNwQ08seUJBQWU7QUFBQSxZQUNiQyxZQUFZO0FBQUEsWUFDWkMsU0FBUztBQUFBLFlBQ1RDLE1BQU07QUFBQSxVQUNSLENBQUM7QUFDRG1DLHdCQUFjb0IsUUFBUWpFLFlBQVk7QUFFbENxRSxxQkFBVyxNQUFNO0FBQ2Z4QiwwQkFBY29CLFFBQVFqRSxZQUFZO0FBQUEsVUFDcEMsR0FBRyxHQUFJO0FBQUEsUUFDVDtBQUFBLE1BQ0YsVUFBQztBQUNDWSw4QkFBc0IsS0FBSztBQUFBLE1BQzdCO0FBQUEsSUFDRjtBQUVBZ0QsY0FBVTtBQUFBLEVBQ1osR0FBRyxDQUFDbkMsTUFBTSxDQUFDO0FBRVhrQyxZQUFVLE1BQU07QUFDZCxVQUFNVyxrQkFBa0IsSUFBSUMsZ0JBQWdCO0FBRTVDekQsbUJBQWUsSUFBSTtBQUVuQixVQUFNMEQsZUFBZSxZQUFZO0FBQy9CLFVBQUk7QUFDRixjQUFNLEVBQUVmLFdBQVdDLFFBQVEsSUFBSUosa0JBQWtCakMsWUFBWTtBQUc3RCxjQUFNb0QsTUFBTSxNQUFNOUcsSUFBSW1HLElBQUksb0JBQW9CO0FBQUEsVUFDNUNZLFFBQVE7QUFBQSxZQUNOakI7QUFBQUEsWUFDQUM7QUFBQUEsVUFDRjtBQUFBLFVBQ0FpQixRQUFRTCxnQkFBZ0JLO0FBQUFBLFFBQzFCLENBQUM7QUFFRCxZQUFJRixJQUFJVixLQUFLYSxXQUFXSCxJQUFJVixLQUFLYyxXQUFXO0FBQzFDakQsd0JBQWM2QyxJQUFJVixLQUFLYyxTQUFTO0FBQ2hDaEMsd0JBQWNvQixRQUFRbEIsVUFBVTtBQUFBLFFBQ2xDLE9BQU87QUFDTG5CLHdCQUFjLEVBQUU7QUFBQSxRQUNsQjtBQUFBLE1BQ0YsU0FBU3NDLEtBQUs7QUFDWixZQUFJQSxJQUFJWSxTQUFTLGNBQWM7QUFDN0JYLGtCQUFRQyxNQUFNLDJCQUEyQkYsR0FBRztBQUM1QyxjQUFJLENBQUNyQixjQUFjb0IsUUFBUWxCLFNBQVM7QUFDbENGLDBCQUFjb0IsUUFBUWxCLFVBQVU7QUFFaENzQix1QkFBVyxNQUFNO0FBQ2Z4Qiw0QkFBY29CLFFBQVFsQixVQUFVO0FBQUEsWUFDbEMsR0FBRyxHQUFJO0FBQUEsVUFDVDtBQUNBbkIsd0JBQWMsRUFBRTtBQUFBLFFBQ2xCO0FBQUEsTUFDRixVQUFDO0FBQ0MsWUFBSSxDQUFDMEMsZ0JBQWdCSyxPQUFPSSxTQUFTO0FBQ25DakUseUJBQWUsS0FBSztBQUFBLFFBQ3RCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxRQUFJLENBQUNILG9CQUFvQjtBQUN2QjZELG1CQUFhO0FBQUEsSUFDZjtBQUVBLFdBQU8sTUFBTTtBQUNYRixzQkFBZ0JVLE1BQU07QUFBQSxJQUN4QjtBQUFBLEVBQ0YsR0FBRyxDQUFDM0QsY0FBY1Ysb0JBQW9CYyxNQUFNLENBQUM7QUFFN0NrQyxZQUFVLE1BQU07QUFDZCxRQUFJaEMsV0FBV3NELFNBQVMsR0FBRztBQUN6QixVQUFJQyxlQUFldkQ7QUFFbkIsVUFBSTdCLGVBQWUsT0FBTztBQUN4Qm9GLHVCQUFldkQsV0FBV3dEO0FBQUFBLFVBQ3hCLENBQUNDLFNBQVNBLEtBQUtDLE1BQU1DLE9BQU94RjtBQUFBQSxRQUM5QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNeUYsa0JBQWtCTCxhQUFhTTtBQUFBQSxRQUNuQyxDQUFDSixTQUFTQSxLQUFLQyxNQUFNSSxPQUFPQyxVQUFVO0FBQUEsTUFDeEM7QUFFQSxZQUFNQyxnQkFBZ0JULGFBQWFVLElBQUksQ0FBQ1IsU0FBUztBQUMvQyxjQUFNUyxZQUFZVCxLQUFLQyxNQUFNSSxPQUFPQyxVQUFVO0FBQzlDLGNBQU1JLGdCQUFnQixDQUFDLEVBQUVDLEtBQUssVUFBVUMsT0FBTyxjQUFjLENBQUM7QUFFOUQsWUFBSSxDQUFDSCxXQUFXO0FBQ2RDLHdCQUFjRyxRQUFRLEVBQUVGLEtBQUssT0FBT0MsT0FBTyxhQUFhLENBQUM7QUFBQSxRQUMzRDtBQUVBLGNBQU1FLGlCQUNKO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLENBQUMsT0FBTztBQUFBLFlBQ2pCLE1BQU07QUFBQSxjQUNKQyxPQUFPTDtBQUFBQSxjQUNQTSxTQUFTQSxDQUFDLEVBQUVMLElBQUksTUFBTTtBQUNwQixvQkFBSUEsUUFBUSxPQUFPO0FBQ2pCN0UsZ0NBQWMsS0FBSztBQUNuQkYsZ0NBQWMsS0FBSztBQUNuQnFGLGdDQUFjakIsSUFBSTtBQUFBLGdCQUNwQjtBQUNBLG9CQUFJVyxRQUFRLFVBQVU7QUFDcEI3RSxnQ0FBYyxLQUFLO0FBQ25CRixnQ0FBYyxJQUFJO0FBQ2xCc0YsaUNBQWVsQixJQUFJO0FBQUEsZ0JBQ3JCO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxZQUVBLGlDQUFDLFlBQVMsV0FBVSxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0M7QUFBQTtBQUFBLFVBbEJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFtQkE7QUFHRixlQUFPO0FBQUEsVUFDTE4sTUFBTU0sS0FBS0MsTUFBTVA7QUFBQUEsVUFDakJ5QixjQUFjbkIsS0FBS0MsTUFBTW1CO0FBQUFBLFVBQ3pCQyxpQkFBaUJyQixNQUFNc0IsU0FBU0Q7QUFBQUEsVUFDaENFLG1CQUFtQnZCLE1BQU1zQixTQUFTQztBQUFBQSxVQUNsQ0MseUJBQXlCeEIsTUFBTXNCLFNBQVNFO0FBQUFBLFVBQ3hDbkIsUUFBUUwsS0FBS0MsT0FBT0ksUUFBUUM7QUFBQUEsVUFDNUJtQixRQUFRWDtBQUFBQSxVQUNSWSxPQUFPMUI7QUFBQUEsUUFDVDtBQUFBLE1BQ0YsQ0FBQztBQUVEakYsbUJBQWF3RixhQUFhO0FBQUEsSUFDNUIsT0FBTztBQUNMeEYsbUJBQWEsRUFBRTtBQUFBLElBQ2pCO0FBQUEsRUFDRixHQUFHLENBQUNMLFlBQVk2QixVQUFVLENBQUM7QUFFM0IsUUFBTW9GLHFCQUFxQixPQUFPM0IsU0FBUztBQUN6QyxRQUFJO0FBQ0YsWUFBTSxFQUFFOUYsS0FBSyxJQUFJMEQsVUFBVTNCLFlBQVk7QUFHdkMsWUFBTW9ELE1BQU0sTUFBTTlHLElBQUltRyxJQUFJLGlCQUFpQnNCLEtBQUtDLE1BQU1DLEVBQUUsSUFBSTtBQUFBLFFBQzFEWixRQUFRLEVBQUVwRixLQUFLO0FBQUEsTUFDakIsQ0FBQztBQUVELFVBQUkwSCxZQUFZO0FBRWhCLFVBQUl2QyxJQUFJVixRQUFRVSxJQUFJVixLQUFLa0IsU0FBUyxHQUFHO0FBQ25DLGNBQU1RLFNBQVNoQixJQUFJVixLQUFLLENBQUM7QUFDekJpRCxvQkFBWXZCLE9BQU91QixhQUFhO0FBQUEsTUFDbEM7QUFFQXBFLDJCQUFxQm9FLFNBQVM7QUFDOUIsYUFBT0E7QUFBQUEsSUFDVCxTQUFTOUMsS0FBSztBQUNaQyxjQUFRQyxNQUFNLGtDQUFrQ0YsR0FBRztBQUNuRHRCLDJCQUFxQixJQUFJO0FBQ3pCLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFFBQU15RCxnQkFBZ0IsT0FBT2pCLFNBQVM7QUFDcEM1RCxzQkFBa0I0RCxJQUFJO0FBQ3RCcEUsa0JBQWMsS0FBSztBQUNuQkUsa0JBQWMsS0FBSztBQUNuQkUsb0JBQWdCZ0UsS0FBS0MsTUFBTUMsRUFBRTtBQUU3QixVQUFNMEIsWUFBWSxNQUFNRCxtQkFBbUIzQixJQUFJO0FBRS9DLFVBQU12RCxlQUFjO0FBQUEsTUFDbEJFLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxNQUNQQyxLQUFLO0FBQUEsTUFDTEMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxRQUFRO0FBQUEsTUFDUkMsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsVUFBVTtBQUFBLElBQ1o7QUFFQSxRQUFJc0UsV0FBVztBQUNiQyxhQUFPQyxLQUFLckYsWUFBVyxFQUFFc0YsUUFBUSxDQUFDNUgsVUFBVTtBQUMxQ3NDLHFCQUFZdEMsS0FBSyxJQUFJeUgsVUFBVXpILEtBQUssS0FBSztBQUFBLE1BQzNDLENBQUM7QUFBQSxJQUNIO0FBRUF1QyxtQkFBZUQsWUFBVztBQUMxQnhCLHFCQUFpQixJQUFJO0FBQUEsRUFDdkI7QUFFQSxRQUFNaUcsaUJBQWlCLE9BQU9sQixTQUFTO0FBQ3JDNUQsc0JBQWtCNEQsSUFBSTtBQUN0QnBFLGtCQUFjLElBQUk7QUFDbEJFLGtCQUFjLEtBQUs7QUFDbkJFLG9CQUFnQmdFLEtBQUtDLE1BQU1DLEVBQUU7QUFFN0IsVUFBTTBCLFlBQVksTUFBTUQsbUJBQW1CM0IsSUFBSTtBQUUvQyxVQUFNdkQsZUFBYztBQUFBLE1BQ2xCRSxTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsUUFBUTtBQUFBLE1BQ1JDLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLFVBQVU7QUFBQSxJQUNaO0FBRUEsUUFBSXNFLFdBQVc7QUFDYkMsYUFBT0MsS0FBS3JGLFlBQVcsRUFBRXNGLFFBQVEsQ0FBQzVILFVBQVU7QUFDMUNzQyxxQkFBWXRDLEtBQUssSUFBSXlILFVBQVV6SCxLQUFLLEtBQUs7QUFBQSxNQUMzQyxDQUFDO0FBQUEsSUFDSDtBQUVBdUMsbUJBQWVELFlBQVc7QUFDMUJ4QixxQkFBaUIsSUFBSTtBQUFBLEVBQ3ZCO0FBRUEsUUFBTStHLGlCQUFpQkEsTUFBTTtBQUMzQmxHLGtCQUFjLElBQUk7QUFDbEJGLGtCQUFjLEtBQUs7QUFDbkJYLHFCQUFpQixJQUFJO0FBRXJCeUIsbUJBQWU7QUFBQSxNQUNiQyxTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsUUFBUTtBQUFBLE1BQ1JDLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLFVBQVU7QUFBQSxJQUNaLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTTJFLG9CQUFvQkEsQ0FBQzlILE9BQU9tRyxVQUFVO0FBQzFDNUQsbUJBQWUsQ0FBQ3dGLFVBQVU7QUFBQSxNQUN4QixHQUFHQTtBQUFBQSxNQUNILENBQUMvSCxLQUFLLEdBQUdtRyxVQUFVLEtBQUssS0FBSzZCLE9BQU83QixLQUFLO0FBQUEsSUFDM0MsRUFBRTtBQUFBLEVBQ0o7QUFHQSxRQUFNOEIsZUFBZSxPQUFPQyxNQUFNO0FBQ2hDQSxNQUFFQyxlQUFlO0FBRWpCLFFBQUk7QUFDRixZQUFNLEVBQUVwSSxLQUFLLElBQUkwRCxVQUFVM0IsWUFBWTtBQUV2QyxVQUFJSixZQUFZO0FBR2QsY0FBTTBHLFdBQVczSCxVQUFVNEYsSUFBSSxDQUFDNkIsT0FBTUEsR0FBRUcsR0FBRztBQUUzQyxjQUFNakssSUFBSWtLLE1BQU0sZ0JBQWdCO0FBQUEsVUFDOUJGO0FBQUFBLFVBQ0FySTtBQUFBQSxVQUNBdUM7QUFBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0wsY0FBTWxFLElBQUlrSztBQUFBQSxVQUNSLGlCQUFpQjFHLFlBQVksU0FBUzdCLElBQUk7QUFBQSxVQUMxQ3VDO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUF0QixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTUSxhQUNMLHNDQUNBRixhQUNBLGdDQUNBO0FBQUEsUUFDSkwsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNETCx1QkFBaUIsS0FBSztBQUN0QnFCLGdCQUFVLENBQUM0RixTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUM5QixTQUFTcEQsS0FBSztBQUNaQyxjQUFRQyxNQUFNLGlCQUFpQkYsR0FBRztBQUNsQzNELHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVNRLGFBQ0wsdUJBQ0FGLGFBQ0Esa0JBQ0E7QUFBQSxRQUNKTCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0gsYUFBYUEsTUFBTTtBQUN2QixXQUFPO0FBQUEsTUFDTCxFQUFFL0IsS0FBSyxRQUFRZ0MsUUFBUSxPQUFPO0FBQUEsTUFDOUIsRUFBRWhDLEtBQUssZ0JBQWdCZ0MsUUFBUSxlQUFlO0FBQUEsTUFDOUMsRUFBRWhDLEtBQUssVUFBVWdDLFFBQVEsU0FBUztBQUFBLE1BQ2xDLEVBQUVoQyxLQUFLLG1CQUFtQmdDLFFBQVEsa0JBQWtCO0FBQUEsTUFDcEQsRUFBRWhDLEtBQUsscUJBQXFCZ0MsUUFBUSxvQkFBb0I7QUFBQSxNQUN4RCxFQUFFaEMsS0FBSywyQkFBMkJnQyxRQUFRLDBCQUEwQjtBQUFBLE1BQ3BFLEVBQUVoQyxLQUFLLFVBQVVnQyxRQUFRLFNBQVM7QUFBQSxJQUFDO0FBQUEsRUFFdkM7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTXpILFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFBTTtBQUNiRiwyQkFBZSxDQUFDK0csVUFBVSxFQUFFLEdBQUdBLE1BQU05RyxZQUFZLE1BQU0sRUFBRTtBQUFBLFVBQzNEO0FBQUE7QUFBQSxRQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1JO0FBQUEsTUFHSix1QkFBQyxTQUFJLFdBQVUsaUJBQ1Y7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNkLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSwwQkFBeUIsMkNBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUEsVUFDbEU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVM0RztBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsV0FBUSxXQUFVLFVBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUEsZ0JBQUc7QUFBQTtBQUFBO0FBQUEsWUFKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUN6RyxxQkFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU8sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQSxtQ0FDRTtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPO0FBQUEsZ0JBQ0w7QUFBQSxrQkFDRW9GLEtBQUs7QUFBQSxrQkFDTEMsT0FDRSx1QkFBQyxVQUFLLFdBQVUseUNBQXdDLDZCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUZnQyxVQUNFLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLElBQUc7QUFBQSx3QkFDSCxXQUFVO0FBQUEsd0JBRVY7QUFBQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFVO0FBQUEsOEJBQ1YsTUFBTTtBQUFBO0FBQUEsNEJBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUVXO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVNBO0FBQUEsb0JBRUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsSUFBRztBQUFBLHdCQUNILFdBQVU7QUFBQSx3QkFFVjtBQUFBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVU7QUFBQSw4QkFDVixNQUFNO0FBQUE7QUFBQSw0QkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBU0E7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxJQUFHO0FBQUEsd0JBQ0gsV0FBVTtBQUFBLHdCQUVWO0FBQUEsaURBQUMsZUFBWSxXQUFVLGlCQUFnQixNQUFNLE1BQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdEO0FBQUEsMEJBQUc7QUFBQTtBQUFBO0FBQUEsc0JBSnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLHVCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQThCQTtBQUFBLGdCQUVKO0FBQUEsY0FBQztBQUFBLGNBRUgsa0JBQWtCLENBQUMsR0FBRztBQUFBLGNBQ3RCLFdBQVU7QUFBQTtBQUFBLFlBN0NaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTZDa0UsS0E5Q3BFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0RBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBRWI7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyx3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE9BQU9sSTtBQUFBQSxrQkFDUCxVQUFVLENBQUMySCxNQUFNMUgsY0FBYzBILEVBQUVoQyxPQUFPQyxLQUFLO0FBQUEsa0JBRTdDO0FBQUEsMkNBQUMsWUFBTyxPQUFNLE9BQU0sNkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsb0JBQ2hDMUYsVUFBVTRGO0FBQUFBLHNCQUFJLENBQUM1QixhQUNkLHVCQUFDLFlBQTBCLE9BQU9BLFNBQVM0RCxLQUN4QzVELG1CQUFTYyxRQUFRLHNCQURQZCxTQUFTNEQsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsaUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLE9BQU92RztBQUFBQSxrQkFDUCxVQUFVLENBQUNvRyxNQUFNbkcsZ0JBQWdCbUcsRUFBRWhDLE9BQU9DLEtBQUs7QUFBQSxrQkFDL0MsS0FBS3JDLGtCQUFrQnhFLGFBQWFFLFlBQVk7QUFBQTtBQUFBLGdCQUxsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLb0Q7QUFBQSxpQkFUdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0NBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1o4QjtBQUFBQSwyQkFDQyx1QkFBQyxTQUFJLFdBQVUsaUZBQ2IsaUNBQUMsU0FBSSxXQUFVLHVGQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1HLEtBRHJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTVg7QUFBQUEsZ0JBQ04sU0FBUzRILFdBQVc7QUFBQSxnQkFDcEIsaUJBQWdCO0FBQUEsZ0JBQ2hCLGtCQUFpQjtBQUFBO0FBQUEsY0FKbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSStDO0FBQUEsZUFWakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpR0E7QUFBQSxXQWxISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0hBO0FBQUEsU0FoSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlJQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsVUFDRTdHLHVCQUNHLHdCQUNBRixhQUNBLGdCQUNBLGdCQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU1WLGlCQUFpQixLQUFLO0FBQUEsY0FDckMsV0FBVTtBQUFBLGNBRVYsaUNBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9CO0FBQUE7QUFBQSxZQUp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFRixXQUFVO0FBQUEsUUFDVixVQUFVO0FBQUEsUUFDVixTQUFTLE1BQU1BLGlCQUFpQixLQUFLO0FBQUEsUUFDckMsTUFBTUQ7QUFBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxXQUFVO0FBQUEsUUFDVixRQUFRO0FBQUEsVUFDTjZILE1BQU07QUFBQSxZQUNKQyxTQUFTO0FBQUEsWUFDVEMsVUFBVTtBQUFBLFVBQ1o7QUFBQSxVQUNBSixRQUFRO0FBQUEsWUFDTkssY0FBYztBQUFBLFlBQ2RGLFNBQVM7QUFBQSxVQUNYO0FBQUEsUUFDRjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsVUFBSyxVQUFVVixjQUFjLFdBQVUsYUFDckM7QUFBQSxXQUFDdkcsY0FBY00sa0JBQ2QsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwwQkFBeUIsMEJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUEsWUFDcEQsdUJBQUMsU0FBSSxXQUFVLHdDQUNaQSx5QkFBZThELE1BQU1QLFFBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUdGLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsMEJBQXlCLG9CQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBLGNBQzlDLHVCQUFDLFNBQUksV0FBVSx3Q0FDWjlCLG9CQUFVM0IsWUFBWSxFQUFFL0IsUUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsMEJBQXlCLHFCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGNBQy9DLHVCQUFDLFNBQUksV0FBVSx3Q0FDWjBELG9CQUFVM0IsWUFBWSxFQUFFK0IsYUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWnpELHFCQUFXaUc7QUFBQUEsWUFBSSxDQUFDckcsVUFDZix1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDBCQUEwQkEsbUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlEO0FBQUEsY0FDakQsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLFFBQU8saUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdCO0FBQUEsZ0JBQ3hCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPc0MsWUFBWXRDLEtBQUs7QUFBQSxvQkFDeEIsVUFBVSxDQUFDa0ksTUFBTUosa0JBQWtCOUgsT0FBT2tJLEVBQUVoQyxPQUFPQyxLQUFLO0FBQUEsb0JBQ3hELFdBQVU7QUFBQSxvQkFDVixLQUFJO0FBQUEsb0JBQ0osYUFBYSxTQUFTbkcsS0FBSztBQUFBO0FBQUEsa0JBTjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNdUM7QUFBQSxtQkFSekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0NzQyxZQUFZdEMsS0FBSyxJQUFJLEtBQ3BCLHVCQUFDLFNBQUksV0FBVSxxQ0FDWmYsOEJBQW9CcUQsWUFBWXRDLEtBQUssQ0FBQyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBaEJNQSxPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsVUFDRCxLQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUVUMEIsdUJBQ0csdUJBQ0FGLGFBQ0Esa0JBQ0E7QUFBQTtBQUFBLFlBUk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkRBLEtBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2REE7QUFBQTtBQUFBLE1BaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlHQTtBQUFBLE9BdE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1T0E7QUFFSjtBQUFFbEIsR0FsbkJJRCxnQkFBYztBQUFBeUksS0FBZHpJO0FBb25CTixlQUFlQTtBQUFlLElBQUF5STtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJOYXZiYXIiLCJTaWRlYmFyIiwiYXBpIiwiRGF0YVRhYmxlIiwiRHJvcGRvd24iLCJEcmF3ZXIiLCJJb01kTW9yZSIsIklvTWRBZGQiLCJJb01kQ2xvc2UiLCJDdXN0b21BbGVydERpYWxvZyIsIkxvYWRlciIsIkNvbGxhcHNlIiwiTGluayIsIkZpbGVUZXh0T3V0bGluZWQiLCJGYU1vbmV5QmlsbCIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJGYVJ1cGVlU2lnbiIsIkJyZWFkY3J1bWIiLCJ0b2RheSIsIkRhdGUiLCJjdXJyZW50WWVhciIsImdldEZ1bGxZZWFyIiwiY3VycmVudE1vbnRoIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImN1cnJlbnRZZWFyTW9udGgiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInllYXIiLCJtb250aCIsInNsaWNlIiwiZGF5IiwiZ2V0RGF0ZSIsIm1vbnRoTmFtZXMiLCJFbXBsb3llZVRhcmdldCIsIl9zIiwic2VsZWN0ZWRJZCIsInNldFNlbGVjdGVkSWQiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJ0YWJsZURhdGEiLCJzZXRUYWJsZURhdGEiLCJkcmF3ZXJWaXNpYmxlIiwic2V0RHJhd2VyVmlzaWJsZSIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJpbml0aWFsRGF0YUxvYWRpbmciLCJzZXRJbml0aWFsRGF0YUxvYWRpbmciLCJkYXRhTG9hZGluZyIsInNldERhdGFMb2FkaW5nIiwiaXNFZGl0TW9kZSIsInNldElzRWRpdE1vZGUiLCJpc0J1bGtNb2RlIiwic2V0SXNCdWxrTW9kZSIsImVkaXRUYXJnZXRJZCIsInNldEVkaXRUYXJnZXRJZCIsInNlbGVjdGVkRGF0ZSIsInNldFNlbGVjdGVkRGF0ZSIsInNlbGVjdGVkUGVyc29uIiwic2V0U2VsZWN0ZWRQZXJzb24iLCJyZWxvYWQiLCJzZXRSZWxvYWQiLCJ0YXJnZXREYXRhIiwic2V0VGFyZ2V0RGF0YSIsIm1vbnRoVmFsdWVzIiwic2V0TW9udGhWYWx1ZXMiLCJKYW51YXJ5IiwiRmVicnVhcnkiLCJNYXJjaCIsIkFwcmlsIiwiTWF5IiwiSnVuZSIsIkp1bHkiLCJBdWd1c3QiLCJTZXB0ZW1iZXIiLCJPY3RvYmVyIiwiTm92ZW1iZXIiLCJEZWNlbWJlciIsImZldGNoZWRUYXJnZXREYXRhIiwic2V0RmV0Y2hlZFRhcmdldERhdGEiLCJhbGVydFNob3duUmVmIiwidXNlUmVmIiwidGFyZ2V0cyIsInBhcnNlRGF0ZSIsImRhdGVTdHJpbmciLCJzcGxpdCIsInBhcnNlSW50IiwibW9udGhOYW1lIiwiZm9ybWF0VG9ZZWFyTW9udGgiLCJnZXRNb250aERhdGVSYW5nZSIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwidXNlRWZmZWN0IiwiZmV0Y2hEYXRhIiwiZW1wbG95ZWVSZXMiLCJnZXQiLCJkYXRhIiwiZW1wbG95ZWUiLCJjdXJyZW50IiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwic2V0VGltZW91dCIsImFib3J0Q29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsImZldGNoVGFyZ2V0cyIsInJlcyIsInBhcmFtcyIsInNpZ25hbCIsInN1Y2Nlc3MiLCJzdW1tYXJpZXMiLCJuYW1lIiwiYWJvcnRlZCIsImFib3J0IiwibGVuZ3RoIiwiZmlsdGVyZWREYXRhIiwiZmlsdGVyIiwiaXRlbSIsImFnZW50IiwiaWQiLCJhbnlUYXJnZXRFeGlzdHMiLCJzb21lIiwidGFyZ2V0IiwidmFsdWUiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiaGFzVGFyZ2V0IiwiZHJvcGRvd25JdGVtcyIsImtleSIsImxhYmVsIiwidW5zaGlmdCIsImFjdGlvbkRyb3Bkb3duIiwiaXRlbXMiLCJvbkNsaWNrIiwib3BlblNldERyYXdlciIsIm9wZW5FZGl0RHJhd2VyIiwicGhvbmVfbnVtYmVyIiwicGhvbmUiLCJhY3R1YWxfYnVzaW5lc3MiLCJtZXRyaWNzIiwidGFyZ2V0X2RpZmZlcmVuY2UiLCJ0YXJnZXRfcmVtYWluaW5nX2RpZ2l0cyIsImFjdGlvbiIsIl9pdGVtIiwiZmV0Y2hUYXJnZXREZXRhaWxzIiwibW9udGhEYXRhIiwiT2JqZWN0Iiwia2V5cyIsImZvckVhY2giLCJvcGVuQnVsa0RyYXdlciIsImhhbmRsZU1vbnRoQ2hhbmdlIiwicHJldiIsIk51bWJlciIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImFnZW50SWRzIiwiX2lkIiwicGF0Y2giLCJnZXRDb2x1bW5zIiwiaGVhZGVyIiwiY2hpbGRyZW4iLCJib2R5IiwicGFkZGluZyIsIm92ZXJmbG93IiwiYm9yZGVyQm90dG9tIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRW1wbG95ZWVUYXJnZXQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgRHJvcGRvd24sIERyYXdlciB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlLCBJb01kQWRkLCBJb01kQ2xvc2UgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgQ29sbGFwc2UgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgRmlsZVRleHRPdXRsaW5lZH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCB7IEZhTW9uZXlCaWxsIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcblxyXG5pbXBvcnQgeyBGYVJ1cGVlU2lnbiB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5jb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbmNvbnN0IGN1cnJlbnRZZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuY29uc3QgY3VycmVudE1vbnRoID0gU3RyaW5nKHRvZGF5LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbmNvbnN0IGN1cnJlbnRZZWFyTW9udGggPSBgJHtjdXJyZW50WWVhcn0tJHtjdXJyZW50TW9udGh9YDtcclxuXHJcbmZ1bmN0aW9uIGZvcm1hdERhdGUoZGF0ZSkge1xyXG4gIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgY29uc3QgbW9udGggPSBgMCR7ZGF0ZS5nZXRNb250aCgpICsgMX1gLnNsaWNlKC0yKTtcclxuICBjb25zdCBkYXkgPSBgMCR7ZGF0ZS5nZXREYXRlKCl9YC5zbGljZSgtMik7XHJcbiAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWA7XHJcbn1cclxuXHJcbmNvbnN0IG1vbnRoTmFtZXMgPSBbXHJcbiAgXCJKYW51YXJ5XCIsXHJcbiAgXCJGZWJydWFyeVwiLFxyXG4gIFwiTWFyY2hcIixcclxuICBcIkFwcmlsXCIsXHJcbiAgXCJNYXlcIixcclxuICBcIkp1bmVcIixcclxuICBcIkp1bHlcIixcclxuICBcIkF1Z3VzdFwiLFxyXG4gIFwiU2VwdGVtYmVyXCIsXHJcbiAgXCJPY3RvYmVyXCIsXHJcbiAgXCJOb3ZlbWJlclwiLFxyXG4gIFwiRGVjZW1iZXJcIixcclxuXTtcclxuXHJcbmNvbnN0IEVtcGxveWVlVGFyZ2V0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtzZWxlY3RlZElkLCBzZXRTZWxlY3RlZElkXSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RhYmxlRGF0YSwgc2V0VGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZHJhd2VyVmlzaWJsZSwgc2V0RHJhd2VyVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiXCIsXHJcbiAgICB0eXBlOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtpbml0aWFsRGF0YUxvYWRpbmcsIHNldEluaXRpYWxEYXRhTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZGF0YUxvYWRpbmcsIHNldERhdGFMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNFZGl0TW9kZSwgc2V0SXNFZGl0TW9kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzQnVsa01vZGUsIHNldElzQnVsa01vZGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0VGFyZ2V0SWQsIHNldEVkaXRUYXJnZXRJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUoY3VycmVudFllYXJNb250aCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGVyc29uLCBzZXRTZWxlY3RlZFBlcnNvbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcmVsb2FkLCBzZXRSZWxvYWRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3RhcmdldERhdGEsIHNldFRhcmdldERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFttb250aFZhbHVlcywgc2V0TW9udGhWYWx1ZXNdID0gdXNlU3RhdGUoe1xyXG4gICAgSmFudWFyeTogMCxcclxuICAgIEZlYnJ1YXJ5OiAwLFxyXG4gICAgTWFyY2g6IDAsXHJcbiAgICBBcHJpbDogMCxcclxuICAgIE1heTogMCxcclxuICAgIEp1bmU6IDAsXHJcbiAgICBKdWx5OiAwLFxyXG4gICAgQXVndXN0OiAwLFxyXG4gICAgU2VwdGVtYmVyOiAwLFxyXG4gICAgT2N0b2JlcjogMCxcclxuICAgIE5vdmVtYmVyOiAwLFxyXG4gICAgRGVjZW1iZXI6IDAsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2ZldGNoZWRUYXJnZXREYXRhLCBzZXRGZXRjaGVkVGFyZ2V0RGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgY29uc3QgYWxlcnRTaG93blJlZiA9IHVzZVJlZih7XHJcbiAgICBlbXBsb3llZXM6IGZhbHNlLFxyXG4gICAgdGFyZ2V0czogZmFsc2UsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHBhcnNlRGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBbeWVhciwgbW9udGhdID0gZGF0ZVN0cmluZy5zcGxpdChcIi1cIik7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICB5ZWFyLFxyXG4gICAgICBtb250aDogU3RyaW5nKHBhcnNlSW50KG1vbnRoKSkucGFkU3RhcnQoMiwgXCIwXCIpLFxyXG4gICAgICBtb250aE5hbWU6IG1vbnRoTmFtZXNbcGFyc2VJbnQobW9udGgpIC0gMV0sXHJcbiAgICB9O1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdFRvWWVhck1vbnRoID0gKHllYXIsIG1vbnRoKSA9PiB7XHJcbiAgICByZXR1cm4gYCR7eWVhcn0tJHtTdHJpbmcobW9udGgpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldE1vbnRoRGF0ZVJhbmdlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IHsgeWVhciwgbW9udGggfSA9IHBhcnNlRGF0ZShkYXRlU3RyaW5nKTtcclxuICAgIGNvbnN0IHN0YXJ0RGF0ZSA9IG5ldyBEYXRlKHllYXIsIHBhcnNlSW50KG1vbnRoKSAtIDEsIDEpO1xyXG4gICAgY29uc3QgZW5kRGF0ZSA9IG5ldyBEYXRlKHllYXIsIHBhcnNlSW50KG1vbnRoKSwgMCk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZnJvbV9kYXRlOiBmb3JtYXREYXRlKHN0YXJ0RGF0ZSksXHJcbiAgICAgIHRvX2RhdGU6IGZvcm1hdERhdGUoZW5kRGF0ZSksXHJcbiAgICB9O1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHNldEluaXRpYWxEYXRhTG9hZGluZyh0cnVlKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBGZXRjaGluZyBvbmx5IEVtcGxveWVlc1xyXG4gICAgICAgIGNvbnN0IGVtcGxveWVlUmVzID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZVwiKTtcclxuXHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKGVtcGxveWVlUmVzLmRhdGE/LmVtcGxveWVlIHx8IFtdKTtcclxuXHJcbiAgICAgICAgYWxlcnRTaG93blJlZi5jdXJyZW50LmVtcGxveWVlcyA9IGZhbHNlO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWVzOlwiLCBlcnIpO1xyXG5cclxuICAgICAgICBpZiAoIWFsZXJ0U2hvd25SZWYuY3VycmVudC5lbXBsb3llZXMpIHtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gbG9hZCBlbXBsb3llZXNcIixcclxuICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBhbGVydFNob3duUmVmLmN1cnJlbnQuZW1wbG95ZWVzID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgYWxlcnRTaG93blJlZi5jdXJyZW50LmVtcGxveWVlcyA9IGZhbHNlO1xyXG4gICAgICAgICAgfSwgMzAwMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldEluaXRpYWxEYXRhTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgfSwgW3JlbG9hZF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG5cclxuICAgIHNldERhdGFMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIGNvbnN0IGZldGNoVGFyZ2V0cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB7IGZyb21fZGF0ZSwgdG9fZGF0ZSB9ID0gZ2V0TW9udGhEYXRlUmFuZ2Uoc2VsZWN0ZWREYXRlKTtcclxuXHJcbiAgICAgICAgLy8gRmV0Y2hpbmcgRW1wbG95ZWUgVGFyZ2V0c1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvdGFyZ2V0L2VtcGxveWVlXCIsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICBmcm9tX2RhdGUsXHJcbiAgICAgICAgICAgIHRvX2RhdGUsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAocmVzLmRhdGEuc3VjY2VzcyAmJiByZXMuZGF0YS5zdW1tYXJpZXMpIHtcclxuICAgICAgICAgIHNldFRhcmdldERhdGEocmVzLmRhdGEuc3VtbWFyaWVzKTtcclxuICAgICAgICAgIGFsZXJ0U2hvd25SZWYuY3VycmVudC50YXJnZXRzID0gZmFsc2U7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldFRhcmdldERhdGEoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgaWYgKGVyci5uYW1lICE9PSBcIkFib3J0RXJyb3JcIikge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHRhcmdldHM6XCIsIGVycik7XHJcbiAgICAgICAgICBpZiAoIWFsZXJ0U2hvd25SZWYuY3VycmVudC50YXJnZXRzKSB7XHJcbiAgICAgICAgICAgIGFsZXJ0U2hvd25SZWYuY3VycmVudC50YXJnZXRzID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgIGFsZXJ0U2hvd25SZWYuY3VycmVudC50YXJnZXRzID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH0sIDMwMDApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc2V0VGFyZ2V0RGF0YShbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIGlmICghYWJvcnRDb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSB7XHJcbiAgICAgICAgICBzZXREYXRhTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGlmICghaW5pdGlhbERhdGFMb2FkaW5nKSB7XHJcbiAgICAgIGZldGNoVGFyZ2V0cygpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xyXG4gICAgfTtcclxuICB9LCBbc2VsZWN0ZWREYXRlLCBpbml0aWFsRGF0YUxvYWRpbmcsIHJlbG9hZF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHRhcmdldERhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICBsZXQgZmlsdGVyZWREYXRhID0gdGFyZ2V0RGF0YTtcclxuXHJcbiAgICAgIGlmIChzZWxlY3RlZElkICE9PSBcImFsbFwiKSB7XHJcbiAgICAgICAgZmlsdGVyZWREYXRhID0gdGFyZ2V0RGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAoaXRlbSkgPT4gaXRlbS5hZ2VudC5pZCA9PT0gc2VsZWN0ZWRJZFxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IGFueVRhcmdldEV4aXN0cyA9IGZpbHRlcmVkRGF0YS5zb21lKFxyXG4gICAgICAgIChpdGVtKSA9PiBpdGVtLmFnZW50LnRhcmdldC52YWx1ZSAhPT0gXCJOb3QgU2V0XCJcclxuICAgICAgKTtcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBmaWx0ZXJlZERhdGEubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaGFzVGFyZ2V0ID0gaXRlbS5hZ2VudC50YXJnZXQudmFsdWUgIT09IFwiTm90IFNldFwiO1xyXG4gICAgICAgIGNvbnN0IGRyb3Bkb3duSXRlbXMgPSBbeyBrZXk6IFwidXBkYXRlXCIsIGxhYmVsOiBcIkVkaXQgVGFyZ2V0XCIgfV07XHJcblxyXG4gICAgICAgIGlmICghaGFzVGFyZ2V0KSB7XHJcbiAgICAgICAgICBkcm9wZG93bkl0ZW1zLnVuc2hpZnQoeyBrZXk6IFwic2V0XCIsIGxhYmVsOiBcIlNldCBUYXJnZXRcIiB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGFjdGlvbkRyb3Bkb3duID0gKFxyXG4gICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgaXRlbXM6IGRyb3Bkb3duSXRlbXMsXHJcbiAgICAgICAgICAgICAgb25DbGljazogKHsga2V5IH0pID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChrZXkgPT09IFwic2V0XCIpIHtcclxuICAgICAgICAgICAgICAgICAgc2V0SXNCdWxrTW9kZShmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgIHNldElzRWRpdE1vZGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICBvcGVuU2V0RHJhd2VyKGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKGtleSA9PT0gXCJ1cGRhdGVcIikge1xyXG4gICAgICAgICAgICAgICAgICBzZXRJc0J1bGtNb2RlKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgc2V0SXNFZGl0TW9kZSh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgb3BlbkVkaXREcmF3ZXIoaXRlbSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyXCIgLz5cclxuICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIG5hbWU6IGl0ZW0uYWdlbnQubmFtZSxcclxuICAgICAgICAgIHBob25lX251bWJlcjogaXRlbS5hZ2VudC5waG9uZSxcclxuICAgICAgICAgIGFjdHVhbF9idXNpbmVzczogaXRlbT8ubWV0cmljcz8uYWN0dWFsX2J1c2luZXNzLFxyXG4gICAgICAgICAgdGFyZ2V0X2RpZmZlcmVuY2U6IGl0ZW0/Lm1ldHJpY3M/LnRhcmdldF9kaWZmZXJlbmNlLFxyXG4gICAgICAgICAgdGFyZ2V0X3JlbWFpbmluZ19kaWdpdHM6IGl0ZW0/Lm1ldHJpY3M/LnRhcmdldF9yZW1haW5pbmdfZGlnaXRzLFxyXG4gICAgICAgICAgdGFyZ2V0OiBpdGVtLmFnZW50Py50YXJnZXQ/LnZhbHVlLFxyXG4gICAgICAgICAgYWN0aW9uOiBhY3Rpb25Ecm9wZG93bixcclxuICAgICAgICAgIF9pdGVtOiBpdGVtLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0VGFibGVEYXRhKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0VGFibGVEYXRhKFtdKTtcclxuICAgIH1cclxuICB9LCBbc2VsZWN0ZWRJZCwgdGFyZ2V0RGF0YV0pO1xyXG5cclxuICBjb25zdCBmZXRjaFRhcmdldERldGFpbHMgPSBhc3luYyAoaXRlbSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgeyB5ZWFyIH0gPSBwYXJzZURhdGUoc2VsZWN0ZWREYXRlKTtcclxuXHJcbiAgICAgIC8vIE5vdGU6IEtlZXBpbmcgb3JpZ2luYWwgZW5kcG9pbnQgbG9naWMgZm9yIGVtcGxveWVlc1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KGAvdGFyZ2V0L2FnZW50LyR7aXRlbS5hZ2VudC5pZH1gLCB7XHJcbiAgICAgICAgcGFyYW1zOiB7IHllYXIgfSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBsZXQgbW9udGhEYXRhID0gbnVsbDtcclxuXHJcbiAgICAgIGlmIChyZXMuZGF0YSAmJiByZXMuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gcmVzLmRhdGFbMF07XHJcbiAgICAgICAgbW9udGhEYXRhID0gdGFyZ2V0Lm1vbnRoRGF0YSB8fCBudWxsO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRGZXRjaGVkVGFyZ2V0RGF0YShtb250aERhdGEpO1xyXG4gICAgICByZXR1cm4gbW9udGhEYXRhO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YXJnZXQgZGV0YWlsczpcIiwgZXJyKTtcclxuICAgICAgc2V0RmV0Y2hlZFRhcmdldERhdGEobnVsbCk7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9wZW5TZXREcmF3ZXIgPSBhc3luYyAoaXRlbSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRQZXJzb24oaXRlbSk7XHJcbiAgICBzZXRJc0VkaXRNb2RlKGZhbHNlKTtcclxuICAgIHNldElzQnVsa01vZGUoZmFsc2UpO1xyXG4gICAgc2V0RWRpdFRhcmdldElkKGl0ZW0uYWdlbnQuaWQpO1xyXG5cclxuICAgIGNvbnN0IG1vbnRoRGF0YSA9IGF3YWl0IGZldGNoVGFyZ2V0RGV0YWlscyhpdGVtKTtcclxuXHJcbiAgICBjb25zdCBtb250aFZhbHVlcyA9IHtcclxuICAgICAgSmFudWFyeTogMCxcclxuICAgICAgRmVicnVhcnk6IDAsXHJcbiAgICAgIE1hcmNoOiAwLFxyXG4gICAgICBBcHJpbDogMCxcclxuICAgICAgTWF5OiAwLFxyXG4gICAgICBKdW5lOiAwLFxyXG4gICAgICBKdWx5OiAwLFxyXG4gICAgICBBdWd1c3Q6IDAsXHJcbiAgICAgIFNlcHRlbWJlcjogMCxcclxuICAgICAgT2N0b2JlcjogMCxcclxuICAgICAgTm92ZW1iZXI6IDAsXHJcbiAgICAgIERlY2VtYmVyOiAwLFxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAobW9udGhEYXRhKSB7XHJcbiAgICAgIE9iamVjdC5rZXlzKG1vbnRoVmFsdWVzKS5mb3JFYWNoKChtb250aCkgPT4ge1xyXG4gICAgICAgIG1vbnRoVmFsdWVzW21vbnRoXSA9IG1vbnRoRGF0YVttb250aF0gfHwgMDtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TW9udGhWYWx1ZXMobW9udGhWYWx1ZXMpO1xyXG4gICAgc2V0RHJhd2VyVmlzaWJsZSh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBvcGVuRWRpdERyYXdlciA9IGFzeW5jIChpdGVtKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFBlcnNvbihpdGVtKTtcclxuICAgIHNldElzRWRpdE1vZGUodHJ1ZSk7XHJcbiAgICBzZXRJc0J1bGtNb2RlKGZhbHNlKTtcclxuICAgIHNldEVkaXRUYXJnZXRJZChpdGVtLmFnZW50LmlkKTtcclxuXHJcbiAgICBjb25zdCBtb250aERhdGEgPSBhd2FpdCBmZXRjaFRhcmdldERldGFpbHMoaXRlbSk7XHJcblxyXG4gICAgY29uc3QgbW9udGhWYWx1ZXMgPSB7XHJcbiAgICAgIEphbnVhcnk6IDAsXHJcbiAgICAgIEZlYnJ1YXJ5OiAwLFxyXG4gICAgICBNYXJjaDogMCxcclxuICAgICAgQXByaWw6IDAsXHJcbiAgICAgIE1heTogMCxcclxuICAgICAgSnVuZTogMCxcclxuICAgICAgSnVseTogMCxcclxuICAgICAgQXVndXN0OiAwLFxyXG4gICAgICBTZXB0ZW1iZXI6IDAsXHJcbiAgICAgIE9jdG9iZXI6IDAsXHJcbiAgICAgIE5vdmVtYmVyOiAwLFxyXG4gICAgICBEZWNlbWJlcjogMCxcclxuICAgIH07XHJcblxyXG4gICAgaWYgKG1vbnRoRGF0YSkge1xyXG4gICAgICBPYmplY3Qua2V5cyhtb250aFZhbHVlcykuZm9yRWFjaCgobW9udGgpID0+IHtcclxuICAgICAgICBtb250aFZhbHVlc1ttb250aF0gPSBtb250aERhdGFbbW9udGhdIHx8IDA7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHNldE1vbnRoVmFsdWVzKG1vbnRoVmFsdWVzKTtcclxuICAgIHNldERyYXdlclZpc2libGUodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlbkJ1bGtEcmF3ZXIgPSAoKSA9PiB7XHJcbiAgICBzZXRJc0J1bGtNb2RlKHRydWUpO1xyXG4gICAgc2V0SXNFZGl0TW9kZShmYWxzZSk7XHJcbiAgICBzZXREcmF3ZXJWaXNpYmxlKHRydWUpO1xyXG5cclxuICAgIHNldE1vbnRoVmFsdWVzKHtcclxuICAgICAgSmFudWFyeTogMCxcclxuICAgICAgRmVicnVhcnk6IDAsXHJcbiAgICAgIE1hcmNoOiAwLFxyXG4gICAgICBBcHJpbDogMCxcclxuICAgICAgTWF5OiAwLFxyXG4gICAgICBKdW5lOiAwLFxyXG4gICAgICBKdWx5OiAwLFxyXG4gICAgICBBdWd1c3Q6IDAsXHJcbiAgICAgIFNlcHRlbWJlcjogMCxcclxuICAgICAgT2N0b2JlcjogMCxcclxuICAgICAgTm92ZW1iZXI6IDAsXHJcbiAgICAgIERlY2VtYmVyOiAwLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTW9udGhDaGFuZ2UgPSAobW9udGgsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRNb250aFZhbHVlcygocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgW21vbnRoXTogdmFsdWUgPT09IFwiXCIgPyBcIlwiIDogTnVtYmVyKHZhbHVlKSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB7IHllYXIgfSA9IHBhcnNlRGF0ZShzZWxlY3RlZERhdGUpO1xyXG5cclxuICAgICAgaWYgKGlzQnVsa01vZGUpIHtcclxuICAgICAgICAvLyBCdWxrIHVwZGF0ZSBmb3IgRW1wbG95ZWVzXHJcbiAgICAgICAgLy8gVXNpbmcgYWdlbnRJZHMga2V5IGFzIHBlciBvcmlnaW5hbCBjb2RlIGxvZ2ljIHRvIHByZXNlcnZlIGZ1bmN0aW9uYWxpdHlcclxuICAgICAgICBjb25zdCBhZ2VudElkcyA9IGVtcGxveWVlcy5tYXAoKGUpID0+IGUuX2lkKTtcclxuXHJcbiAgICAgICAgYXdhaXQgYXBpLnBhdGNoKGAvdGFyZ2V0L2J1bGtgLCB7XHJcbiAgICAgICAgICBhZ2VudElkcyxcclxuICAgICAgICAgIHllYXIsXHJcbiAgICAgICAgICBtb250aFZhbHVlcyxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhd2FpdCBhcGkucGF0Y2goXHJcbiAgICAgICAgICBgL3RhcmdldC9hZ2VudC8ke2VkaXRUYXJnZXRJZH0/eWVhcj0ke3llYXJ9YCxcclxuICAgICAgICAgIG1vbnRoVmFsdWVzXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogaXNCdWxrTW9kZVxyXG4gICAgICAgICAgPyBcIkJ1bGsgdGFyZ2V0cyB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiXHJcbiAgICAgICAgICA6IGlzRWRpdE1vZGVcclxuICAgICAgICAgID8gXCJUYXJnZXQgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIlxyXG4gICAgICAgICAgOiBcIlRhcmdldCBzZXQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXREcmF3ZXJWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIlN1Ym1pdCBmYWlsZWRcIiwgZXJyKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogaXNCdWxrTW9kZVxyXG4gICAgICAgICAgPyBcIkJ1bGsgdXBkYXRlIGZhaWxlZFwiXHJcbiAgICAgICAgICA6IGlzRWRpdE1vZGVcclxuICAgICAgICAgID8gXCJVcGRhdGUgZmFpbGVkXCJcclxuICAgICAgICAgIDogXCJBZGQgZmFpbGVkXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRDb2x1bW5zID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIFtcclxuICAgICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiTmFtZVwiIH0sXHJcbiAgICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgICAgeyBrZXk6IFwidGFyZ2V0XCIsIGhlYWRlcjogXCJUYXJnZXRcIiB9LFxyXG4gICAgICB7IGtleTogXCJhY3R1YWxfYnVzaW5lc3NcIiwgaGVhZGVyOiBcIkFjdHVhbCBCdXNpbmVzc1wiIH0sXHJcbiAgICAgIHsga2V5OiBcInRhcmdldF9kaWZmZXJlbmNlXCIsIGhlYWRlcjogXCJUYXJnZXQgRGlmZmVyZW5jZVwiIH0sXHJcbiAgICAgIHsga2V5OiBcInRhcmdldF9yZW1haW5pbmdfZGlnaXRzXCIsIGhlYWRlcjogXCJUYXJnZXQgUmVtYWluaW5nIERpZ2l0c1wiIH0sXHJcbiAgICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICAgIF07XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNlwiPlxyXG4gICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5FbXBsb3llZSBUYXJnZXRzIE1hbmFnZW1lbnQ8L2gxPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17b3BlbkJ1bGtEcmF3ZXJ9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBob3ZlcjpiZy1ibHVlLTcwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SW9NZEFkZCBjbGFzc05hbWU9XCJtci0yXCIgLz4gQnVsayBVcGRhdGUgVGFyZ2V0c1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHtpbml0aWFsRGF0YUxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgaC02NFwiPlxyXG4gICAgICAgICAgICAgIDxMb2FkZXIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNlwiPlxyXG4gICAgICAgICAgICAgICAgPENvbGxhcHNlXHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1zPXtbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBTaG9ydGN1dCBLZXlzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTUgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy90YXJnZXQtY29tbWlzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItYmx1ZS01MDAgaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXszMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb21taXNzaW9uIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3JlcG9ydHMvdGFyZ2V0LWluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItYmx1ZS01MDAgaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0T3V0bGluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezMwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluY2VudGl2ZSBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvc2FsYXJ5LXBheW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCB0ZXh0LWJhc2UgaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciAgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIHRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLWJsdWUtNTAwIGhvdmVyOnRleHQtYmx1ZS02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYU1vbmV5QmlsbCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCIgc2l6ZT17MzB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTYWxhcnkgUGF5b3V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgZGVmYXVsdEFjdGl2ZUtleT17W1wiMVwiXX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCBmbGV4LXdyYXAgbWItNiBpdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRW1wbG95ZWVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBib3JkZXIgcm91bmRlZCB3LWZ1bGwgbWluLXctWzIwMHB4XVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZElkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhbGxcIj5BbGwgRW1wbG95ZWVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcGxveWVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZW1wbG95ZWUuX2lkfSB2YWx1ZT17ZW1wbG95ZWUuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlLm5hbWUgfHwgXCJVbmtub3duIEVtcGxveWVlXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBUYXJnZXQgTW9udGhcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYm9yZGVyIHJvdW5kZWQgdy1mdWxsIG1pbi13LVsxNTBweF1cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIG1heD17Zm9ybWF0VG9ZZWFyTW9udGgoY3VycmVudFllYXIsIGN1cnJlbnRNb250aCl9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtaW4taC1bMjAwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICB7ZGF0YUxvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctd2hpdGUgYmctb3BhY2l0eS03MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtMTAgdy0xMCBib3JkZXItNCBib3JkZXItYmx1ZS02MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnRcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXt0YWJsZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2dldENvbHVtbnMoKX1cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiRW1wbG95ZWUtVGFyZ2V0LVJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJFbXBsb3llZS1UYXJnZXQtUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFRhcmdldCBEcmF3ZXIgKi99XHJcbiAgICAgIDxEcmF3ZXJcclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICB7aXNCdWxrTW9kZVxyXG4gICAgICAgICAgICAgICAgPyBcIkJ1bGsgVXBkYXRlIFRhcmdldHNcIlxyXG4gICAgICAgICAgICAgICAgOiBpc0VkaXRNb2RlXHJcbiAgICAgICAgICAgICAgICA/IFwiRWRpdCBUYXJnZXRcIlxyXG4gICAgICAgICAgICAgICAgOiBcIlNldCBUYXJnZXRcIn1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RHJhd2VyVmlzaWJsZShmYWxzZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJb01kQ2xvc2Ugc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHBsYWNlbWVudD1cInJpZ2h0XCJcclxuICAgICAgICBjbG9zYWJsZT17ZmFsc2V9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0RHJhd2VyVmlzaWJsZShmYWxzZSl9XHJcbiAgICAgICAgb3Blbj17ZHJhd2VyVmlzaWJsZX1cclxuICAgICAgICB3aWR0aD17NTAwfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cInRhcmdldC1kcmF3ZXJcIlxyXG4gICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwLFxyXG4gICAgICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBoZWFkZXI6IHtcclxuICAgICAgICAgICAgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjZjBmMGYwXCIsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6IFwiMTZweCAyNHB4XCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIHshaXNCdWxrTW9kZSAmJiBzZWxlY3RlZFBlcnNvbiAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bSBtYi0xXCI+VGFyZ2V0IEZvcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQgYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQZXJzb24uYWdlbnQubmFtZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00IG1iLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtIG1iLTFcIj5ZZWFyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwYXJzZURhdGUoc2VsZWN0ZWREYXRlKS55ZWFyfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bSBtYi0xXCI+TW9udGg8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkIGJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAge3BhcnNlRGF0ZShzZWxlY3RlZERhdGUpLm1vbnRoTmFtZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIHttb250aE5hbWVzLm1hcCgobW9udGgpID0+IChcclxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXttb250aH0+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bSBtYi0xXCI+e21vbnRofTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yXCI+4oK5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bW9udGhWYWx1ZXNbbW9udGhdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVNb250aENoYW5nZShtb250aCwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtgRW50ZXIgJHttb250aH0gdGFyZ2V0YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAge21vbnRoVmFsdWVzW21vbnRoXSA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTEgaXRhbGljXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhtb250aFZhbHVlc1ttb250aF0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHAtMiByb3VuZGVkIGhvdmVyOmJnLWJsdWUtNzAwIG10LTZcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2lzQnVsa01vZGVcclxuICAgICAgICAgICAgICAgID8gXCJVcGRhdGUgQWxsIFRhcmdldHNcIlxyXG4gICAgICAgICAgICAgICAgOiBpc0VkaXRNb2RlXHJcbiAgICAgICAgICAgICAgICA/IFwiVXBkYXRlIFRhcmdldFwiXHJcbiAgICAgICAgICAgICAgICA6IFwiU2F2ZSBUYXJnZXRcIn1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvRHJhd2VyPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEVtcGxveWVlVGFyZ2V0OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9FbXBsb3llZVRhcmdldC5qc3gifQ==