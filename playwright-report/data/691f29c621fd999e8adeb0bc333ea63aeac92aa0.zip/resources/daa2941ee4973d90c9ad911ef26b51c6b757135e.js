import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/WhatsappAdd.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import whatsappApi from "/src/instance/WhatsappInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
const WhatsappAdd = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [TableUsers, setTableUsers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [isLoading, setIsLoading] = useState(false);
  const [selectUser, setSelectUser] = useState({});
  const [customerCount, setCustomerCount] = useState(0);
  const [selectAll, setSelectAll] = useState({ msg: "No", checked: false });
  const [formData, setFormData] = useState({
    template_name: ""
  });
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [errors, setErrors] = useState({});
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/user/get-user");
        setUsers(response.data);
        const initialSelected = {};
        response.data.forEach((user) => {
          initialSelected[user._id] = false;
        });
        setSelectUser(initialSelected);
      } catch (error) {
        console.error("Error fetching user data:", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUsers();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    if (!formData.template_name.trim()) {
      newErrors.template_name = "Template name is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        setDisabled(true);
        const response = await whatsappApi.post("/marketing", {
          selectUser,
          template_name: formData?.template_name
        });
        if (response.status >= 400) {
          setShowModal(false);
          setDisabled(false);
          setErrors({});
          setFormData({
            template_name: ""
          });
          setAlertConfig({
            type: "error",
            message: "Whatsapp Failure",
            visibility: true
          });
        }
        if (response.status === 201) {
          setShowModal(false);
          setErrors({});
          setFormData({
            template_name: ""
          });
          setReloadTrigger((prev) => prev + 1);
          setAlertConfig({
            type: "success",
            message: "Whatsapped Successfully",
            visibility: true
          });
        }
        setShowModal(false);
        setErrors({});
        setFormData({
          template_name: ""
        });
      }
    } catch (err) {
      setAlertConfig({
        type: "error",
        message: "Whatsapp Failure",
        visibility: true
      });
      setDisabled(false);
      console.error("whatsapp error", err.message);
    }
  };
  const handleSelectAll = () => {
    const checked = !selectAll.checked;
    setSelectAll({
      ...selectAll,
      msg: selectAll.msg === "All" ? "No" : "All",
      checked: !selectAll.checked
    });
    const tempSelectUser = {};
    Object.keys(selectUser).forEach((user_id) => {
      tempSelectUser[user_id] = checked;
    });
    setSelectUser(tempSelectUser);
  };
  useEffect(() => {
    const updateUI = () => {
      const formattedData = users.map((group, index) => ({
        id: index + 1,
        name: group.full_name,
        phone_number: group.phone_number,
        customer_id: group.customer_id || `Updating soon...`,
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: "border border-green-400 text-white px-4 py-2 rounded-md shadow hover:border-green-700 transition duration-200",
            onClick: () => {
              setSelectUser((prevSelectedUser) => ({
                ...prevSelectedUser,
                [group._id]: !prevSelectedUser[group._id]
              }));
            },
            children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                checked: selectUser[group?._id] ?? false,
                className: "checked:text-green-600 focus:ring-0  rounded-lg p-2"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                lineNumber: 159,
                columnNumber: 15
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
            lineNumber: 150,
            columnNumber: 13
          },
          this
        ) }, group._id, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
          lineNumber: 149,
          columnNumber: 9
        }, this)
      }));
      setTableUsers(formattedData);
    };
    updateUI();
  }, [selectUser, reloadTrigger]);
  useEffect(() => {
    const countCustomer = () => {
      let counter = 0;
      Object.values(selectUser).forEach((ele) => {
        if (ele) {
          counter++;
        }
      });
      setCustomerCount(counter);
    };
    countCustomer();
  }, [selectUser, reloadTrigger]);
  const columns = [
    { key: "action", header: "Action" },
    { key: "id", header: "SL. NO" },
    { key: "customer_id", header: "Customer Id" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "", children: [
    /* @__PURE__ */ jsxDEV("div", { className: " flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
          lineNumber: 198,
          columnNumber: 12
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
              /* @__PURE__ */ jsxDEV(FaWhatsapp, { color: "green", size: "30", className: "m-2" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                lineNumber: 212,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold flex items-center", children: "Whatsapp Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                lineNumber: 213,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
              lineNumber: 211,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "flex items-center my-2 cursor-pointer select-none",
                onClick: handleSelectAll,
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "checkbox",
                      checked: selectAll.checked,
                      className: "rounded-sm mx-2 text-green-400 focus:outline-none cursor-pointer "
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                      lineNumber: 222,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("h2", { className: "font-medium", children: `Select ${selectAll.msg} Customers` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                    lineNumber: 227,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                lineNumber: 218,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
            lineNumber: 210,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
              },
              className: "relative ml-4 bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200",
              children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                customerCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-10 min-h-10 absolute -right-4 bottom-6 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white p-2",
                    title: `Message will be sent to total ${customerCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { className: "shadow-sm font-medium", children: customerCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                      lineNumber: 243,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                    lineNumber: 239,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mx-1", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                  lineNumber: 248,
                  columnNumber: 21
                }, this),
                "Whatsapp"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
                lineNumber: 237,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
              lineNumber: 231,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
          lineNumber: 209,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
          lineNumber: 208,
          columnNumber: 13
        }, this),
        TableUsers.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            isExportEnabled: false,
            data: TableUsers,
            columns,
            exportedFileName: `whatsapp-${TableUsers.length > 0 ? TableUsers[0].name + " to " + TableUsers[TableUsers.length - 1].name : "empty"}.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
            lineNumber: 255,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableUsers.length <= 0,
            data: "Group Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
            lineNumber: 267,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
        lineNumber: 207,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
      lineNumber: 196,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Send Message" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
        lineNumber: 277,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "template",
              children: "Template Name"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
              lineNumber: 282,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              name: "template_name",
              value: formData.template_name,
              onChange: handleChange,
              id: "templateName",
              placeholder: "Paste template name",
              required: true,
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 w-full p-2.5"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
              lineNumber: 288,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
          lineNumber: 281,
          columnNumber: 15
        }, this),
        errors.template_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.template_name }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
          lineNumber: 300,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            disabled,
            className: "w-full text-white bg-green-700 hover:bg-green-800\r\n              focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
            children: "Send"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
            lineNumber: 304,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
        lineNumber: 280,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
      lineNumber: 276,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
      lineNumber: 275,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
    lineNumber: 195,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx",
    lineNumber: 194,
    columnNumber: 5
  }, this);
};
_s(WhatsappAdd, "U7Jus45eoC5kiuQhBMcVWLAff4U=");
_c = WhatsappAdd;
export default WhatsappAdd;
var _c;
$RefreshReg$(_c, "WhatsappAdd");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappAdd.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEpjLFNBbUNWLFVBbkNVOzJCQTlKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0Msa0JBQWtCO0FBQzNCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixNQUFNQyxjQUFjQSxNQUFNO0FBQUFDLEtBQUE7QUFDeEIsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlaLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNhLFlBQVlDLGFBQWEsSUFBSWQsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2UsV0FBV0MsWUFBWSxJQUFJaEIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2lCLFVBQVVDLFdBQVcsSUFBSWxCLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNtQixhQUFhQyxjQUFjLElBQUlwQixTQUFTO0FBQUEsSUFDN0NxQixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXpCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTLENBQUMsQ0FBQztBQUMvQyxRQUFNLENBQUM0QixlQUFlQyxnQkFBZ0IsSUFBSTdCLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUM4QixXQUFXQyxZQUFZLElBQUkvQixTQUFTLEVBQUVnQyxLQUFLLE1BQU1DLFNBQVMsTUFBTSxDQUFDO0FBQ3hFLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJbkMsU0FBUztBQUFBLElBQ3ZDb0MsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDQSxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJdEMsU0FBUyxDQUFDO0FBQ3JELFFBQU0sQ0FBQ3VDLFFBQVFDLFNBQVMsSUFBSXhDLFNBQVMsQ0FBQyxDQUFDO0FBR3JDRCxZQUFVLE1BQU07QUFDaEIsVUFBTTBDLGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0ZoQixxQkFBYSxJQUFJO0FBQ2pCLGNBQU1pQixXQUFXLE1BQU10QyxJQUFJdUMsSUFBSSxnQkFBZ0I7QUFDL0MvQixpQkFBUzhCLFNBQVNFLElBQUk7QUFDdEIsY0FBTUMsa0JBQWtCLENBQUM7QUFDekJILGlCQUFTRSxLQUFLRSxRQUFRLENBQUNDLFNBQVM7QUFDOUJGLDBCQUFnQkUsS0FBS0MsR0FBRyxJQUFJO0FBQUEsUUFDOUIsQ0FBQztBQUNEckIsc0JBQWNrQixlQUFlO0FBQUEsTUFDL0IsU0FBU0ksT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw2QkFBNkJBLE1BQU0zQixPQUFPO0FBQUEsTUFDMUQsVUFBQztBQUNDRyxxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0FnQixlQUFXO0FBQUEsRUFDYixHQUFHLENBQUNKLGFBQWEsQ0FBQztBQUdsQixRQUFNYyxlQUFlQSxDQUFDQyxNQUFNO0FBQzFCLFVBQU0sRUFBRUMsTUFBTUMsTUFBTSxJQUFJRixFQUFFRztBQUMxQnBCLGdCQUFZLENBQUNxQixjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDSCxJQUFJLEdBQUdDO0FBQUFBLElBQ1YsRUFBRTtBQUFBLEVBQ0o7QUFDQSxRQUFNRyxlQUFlQSxDQUFDbEMsU0FBUztBQUM3QixVQUFNbUMsWUFBWSxDQUFDO0FBRW5CLFFBQUksQ0FBQ3hCLFNBQVNFLGNBQWN1QixLQUFLLEdBQUc7QUFDbENELGdCQUFVdEIsZ0JBQWdCO0FBQUEsSUFDNUI7QUFFQUksY0FBVWtCLFNBQVM7QUFDbkIsV0FBT0UsT0FBT0MsS0FBS0gsU0FBUyxFQUFFSSxXQUFXO0FBQUEsRUFDM0M7QUFDQSxRQUFNQyxlQUFlLE9BQU9YLE1BQU07QUFDaENBLE1BQUVZLGVBQWU7QUFDakIsVUFBTUMsVUFBVVIsYUFBYTtBQUM3QixRQUFJO0FBQ0YsVUFBSVEsU0FBUztBQUNYL0Msb0JBQVksSUFBSTtBQUNoQixjQUFNd0IsV0FBVyxNQUFNbkMsWUFBWTJELEtBQUssY0FBYztBQUFBLFVBQ3BEeEM7QUFBQUEsVUFDQVUsZUFBZUYsVUFBVUU7QUFBQUEsUUFDM0IsQ0FBQztBQUNELFlBQUlNLFNBQVN5QixVQUFVLEtBQUs7QUFDMUJuRCx1QkFBYSxLQUFLO0FBQ2xCRSxzQkFBWSxLQUFLO0FBQ2pCc0Isb0JBQVUsQ0FBQyxDQUFDO0FBQ1pMLHNCQUFZO0FBQUEsWUFDVkMsZUFBZTtBQUFBLFVBQ2pCLENBQUM7QUFFRGhCLHlCQUFlO0FBQUEsWUFDYkcsTUFBTTtBQUFBLFlBQ05ELFNBQVM7QUFBQSxZQUNURCxZQUFZO0FBQUEsVUFDZCxDQUFDO0FBQUEsUUFFSDtBQUNBLFlBQUlxQixTQUFTeUIsV0FBVyxLQUFLO0FBRzNCbkQsdUJBQWEsS0FBSztBQUNsQndCLG9CQUFVLENBQUMsQ0FBQztBQUNaTCxzQkFBWTtBQUFBLFlBQ1ZDLGVBQWU7QUFBQSxVQUNqQixDQUFDO0FBQ0RFLDJCQUFpQixDQUFDOEIsU0FBU0EsT0FBTyxDQUFDO0FBQ25DaEQseUJBQWU7QUFBQSxZQUNiRyxNQUFNO0FBQUEsWUFDTkQsU0FBUztBQUFBLFlBQ1RELFlBQVk7QUFBQSxVQUNkLENBQUM7QUFBQSxRQUNIO0FBRUFMLHFCQUFhLEtBQUs7QUFDbEJ3QixrQkFBVSxDQUFDLENBQUM7QUFDWkwsb0JBQVk7QUFBQSxVQUNWQyxlQUFlO0FBQUEsUUFDakIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNpQyxLQUFLO0FBQ1pqRCxxQkFBZTtBQUFBLFFBQ2JHLE1BQU07QUFBQSxRQUNORCxTQUFTO0FBQUEsUUFDVEQsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUNESCxrQkFBWSxLQUFLO0FBQ2pCZ0MsY0FBUUQsTUFBTSxrQkFBa0JvQixJQUFJL0MsT0FBTztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUNBLFFBQU1nRCxrQkFBa0JBLE1BQU07QUFDNUIsVUFBTXJDLFVBQVUsQ0FBQ0gsVUFBVUc7QUFDM0JGLGlCQUFhO0FBQUEsTUFDWCxHQUFHRDtBQUFBQSxNQUNIRSxLQUFLRixVQUFVRSxRQUFRLFFBQVEsT0FBTztBQUFBLE1BQ3RDQyxTQUFTLENBQUNILFVBQVVHO0FBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNc0MsaUJBQWlCLENBQUM7QUFDeEJYLFdBQU9DLEtBQUtuQyxVQUFVLEVBQUVvQixRQUFRLENBQUMwQixZQUFZO0FBQzNDRCxxQkFBZUMsT0FBTyxJQUFJdkM7QUFBQUEsSUFDNUIsQ0FBQztBQUNETixrQkFBYzRDLGNBQWM7QUFBQSxFQUM5QjtBQUVBeEUsWUFBVSxNQUFNO0FBQ2QsVUFBTTBFLFdBQVdBLE1BQU07QUFDckIsWUFBTUMsZ0JBQWdCL0QsTUFBTWdFLElBQUksQ0FBQ0MsT0FBT0MsV0FBVztBQUFBLFFBQ2pEQyxJQUFJRCxRQUFRO0FBQUEsUUFDWnhCLE1BQU11QixNQUFNRztBQUFBQSxRQUNaQyxjQUFjSixNQUFNSTtBQUFBQSxRQUNwQkMsYUFBYUwsTUFBTUssZUFBZTtBQUFBLFFBQ2xDQyxRQUNFLHVCQUFDLFNBQW9CLFdBQVUsNkJBQzdCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU07QUFDYnZELDRCQUFjLENBQUN3RCxzQkFBc0I7QUFBQSxnQkFDbkMsR0FBR0E7QUFBQUEsZ0JBQ0gsQ0FBQ1AsTUFBTTVCLEdBQUcsR0FBRyxDQUFDbUMsaUJBQWlCUCxNQUFNNUIsR0FBRztBQUFBLGNBQzFDLEVBQUU7QUFBQSxZQUNKO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTdEIsV0FBV2tELE9BQU81QixHQUFHLEtBQUs7QUFBQSxnQkFDbkMsV0FBVTtBQUFBO0FBQUEsY0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHaUU7QUFBQTtBQUFBLFVBWm5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNBLEtBZlE0QixNQUFNNUIsS0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLE1BRUosRUFBRTtBQUNGbEMsb0JBQWM0RCxhQUFhO0FBQUEsSUFDN0I7QUFDQUQsYUFBUztBQUFBLEVBQ1gsR0FBRyxDQUFDL0MsWUFBWVcsYUFBYSxDQUFDO0FBQzlCdEMsWUFBVSxNQUFNO0FBQ2QsVUFBTXFGLGdCQUFnQkEsTUFBTTtBQUMxQixVQUFJQyxVQUFVO0FBQ2R6QixhQUFPMEIsT0FBTzVELFVBQVUsRUFBRW9CLFFBQVEsQ0FBQ3lDLFFBQVE7QUFDekMsWUFBSUEsS0FBSztBQUNQRjtBQUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQ0R4RCx1QkFBaUJ3RCxPQUFPO0FBQUEsSUFDMUI7QUFDQUQsa0JBQWM7QUFBQSxFQUNoQixHQUFHLENBQUMxRCxZQUFZVyxhQUFhLENBQUM7QUFFOUIsUUFBTW1ELFVBQVU7QUFBQSxJQUNkLEVBQUVDLEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLGVBQWVDLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVELEtBQUssUUFBUUMsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSx3QkFBd0I7QUFBQSxFQUFDO0FBRzFELFNBQ0UsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLElBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZUFFWjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRixNQUFNdkUsWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUNnRCxVQUFVLEVBQUUsR0FBR0EsTUFBTS9DLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUwxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLE1BR0QsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxjQUFXLE9BQU0sU0FBUSxNQUFLLE1BQUssV0FBVSxTQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRDtBQUFBLGNBQ25ELHVCQUFDLFFBQUcsV0FBVSw0Q0FBMkMsa0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFTaUQ7QUFBQUEsZ0JBRVQ7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBU3hDLFVBQVVHO0FBQUFBLHNCQUNuQixXQUFVO0FBQUE7QUFBQSxvQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRytFO0FBQUEsa0JBRS9FLHVCQUFDLFFBQUcsV0FBVSxlQUFlLG9CQUFVSCxVQUFVRSxHQUFHLGdCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRTtBQUFBO0FBQUE7QUFBQSxjQVRuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2JoQiw2QkFBYSxJQUFJO0FBQUEsY0FDbkI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFNBQUksV0FBVSxxQkFDWlk7QUFBQUEsZ0NBQWdCLEtBQ2Y7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE9BQU8saUNBQWlDQSxhQUFhO0FBQUEsb0JBRXJELGlDQUFDLFVBQUssV0FBVSx5QkFDYkEsMkJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUEsa0JBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBRUYsdUJBQUMsY0FBVyxXQUFVLFFBQU8sTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUFHO0FBQUEsbUJBWDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQTtBQUFBLFlBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW9CQTtBQUFBLGFBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQ0EsS0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZDQTtBQUFBLFFBQ0VmLFdBQVdpRCxTQUFTLEtBQUssQ0FBQ3RDLFlBQzVCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxpQkFBaUI7QUFBQSxZQUNqQixNQUFNWDtBQUFBQSxZQUNOO0FBQUEsWUFDQSxrQkFBa0IsWUFDaEJBLFdBQVdpRCxTQUFTLElBQ2hCakQsV0FBVyxDQUFDLEVBQUV3QyxPQUNkLFNBQ0F4QyxXQUFXQSxXQUFXaUQsU0FBUyxDQUFDLEVBQUVULE9BQ2xDLE9BQU87QUFBQTtBQUFBLFVBVGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVVMsSUFFUDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFNBQVN4QyxXQUFXaUQsVUFBVTtBQUFBLFlBQzlCLE1BQU07QUFBQTtBQUFBLFVBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3FCO0FBQUEsV0EvRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrRUE7QUFBQSxTQTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEVBO0FBQUEsSUFDQSx1QkFBQyxTQUFNLFdBQVcvQyxXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVStDLGNBQWMsWUFBVSxNQUM1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQVU7QUFBQTtBQUFBLFlBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBTzdCLFNBQVNFO0FBQUFBLGNBQ2hCLFVBQVVlO0FBQUFBLGNBQ1YsSUFBRztBQUFBLGNBQ0gsYUFBWTtBQUFBLGNBQ1o7QUFBQSxjQUNBLFdBQVU7QUFBQTtBQUFBLFlBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUXlJO0FBQUEsYUFmM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBQ0NaLE9BQU9ILGlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVkcsaUJBQU9ILGlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFDZ0c7QUFBQTtBQUFBLFVBSjVHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDQTtBQUFBLFNBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQ0EsS0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVDQTtBQUFBLE9BdkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3SEEsS0F6SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBIQTtBQUVKO0FBQUUxQixHQW5USUQsYUFBVztBQUFBa0YsS0FBWGxGO0FBcVROLGVBQWVBO0FBQVksSUFBQWtGO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJNb2RhbCIsIkZhV2hhdHNhcHAiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydERpYWxvZyIsIndoYXRzYXBwQXBpIiwiQ2lyY3VsYXJMb2FkZXIiLCJXaGF0c2FwcEFkZCIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsIlRhYmxlVXNlcnMiLCJzZXRUYWJsZVVzZXJzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwiZGlzYWJsZWQiLCJzZXREaXNhYmxlZCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzZWxlY3RVc2VyIiwic2V0U2VsZWN0VXNlciIsImN1c3RvbWVyQ291bnQiLCJzZXRDdXN0b21lckNvdW50Iiwic2VsZWN0QWxsIiwic2V0U2VsZWN0QWxsIiwibXNnIiwiY2hlY2tlZCIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ0ZW1wbGF0ZV9uYW1lIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJmZXRjaFVzZXJzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiaW5pdGlhbFNlbGVjdGVkIiwiZm9yRWFjaCIsInVzZXIiLCJfaWQiLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVDaGFuZ2UiLCJlIiwibmFtZSIsInZhbHVlIiwidGFyZ2V0IiwicHJldkRhdGEiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJ0cmltIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZCIsInBvc3QiLCJzdGF0dXMiLCJwcmV2IiwiZXJyIiwiaGFuZGxlU2VsZWN0QWxsIiwidGVtcFNlbGVjdFVzZXIiLCJ1c2VyX2lkIiwidXBkYXRlVUkiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiZ3JvdXAiLCJpbmRleCIsImlkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiY3VzdG9tZXJfaWQiLCJhY3Rpb24iLCJwcmV2U2VsZWN0ZWRVc2VyIiwiY291bnRDdXN0b21lciIsImNvdW50ZXIiLCJ2YWx1ZXMiLCJlbGUiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiV2hhdHNhcHBBZGQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IHsgRmFXaGF0c2FwcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgd2hhdHNhcHBBcGkgZnJvbSBcIi4uL2luc3RhbmNlL1doYXRzYXBwSW5zdGFuY2VcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuY29uc3QgV2hhdHNhcHBBZGQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlVXNlcnMsIHNldFRhYmxlVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Rpc2FibGVkLCBzZXREaXNhYmxlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RVc2VyLCBzZXRTZWxlY3RVc2VyXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbY3VzdG9tZXJDb3VudCwgc2V0Q3VzdG9tZXJDb3VudF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbc2VsZWN0QWxsLCBzZXRTZWxlY3RBbGxdID0gdXNlU3RhdGUoeyBtc2c6IFwiTm9cIiwgY2hlY2tlZDogZmFsc2UgfSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0ZW1wbGF0ZV9uYW1lOiBcIlwiLFxyXG4gIH0pO1xyXG4gICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgY29uc3QgaW5pdGlhbFNlbGVjdGVkID0ge307XHJcbiAgICAgICAgcmVzcG9uc2UuZGF0YS5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgICBpbml0aWFsU2VsZWN0ZWRbdXNlci5faWRdID0gZmFsc2U7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0U2VsZWN0VXNlcihpbml0aWFsU2VsZWN0ZWQpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRhdGE6XCIsIGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICB9ZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoVXNlcnMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICBcclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG5cclxuICAgIGlmICghZm9ybURhdGEudGVtcGxhdGVfbmFtZS50cmltKCkpIHtcclxuICAgICAgbmV3RXJyb3JzLnRlbXBsYXRlX25hbWUgPSBcIlRlbXBsYXRlIG5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgIHNldERpc2FibGVkKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgd2hhdHNhcHBBcGkucG9zdChcIi9tYXJrZXRpbmdcIiwge1xyXG4gICAgICAgICAgc2VsZWN0VXNlcixcclxuICAgICAgICAgIHRlbXBsYXRlX25hbWU6IGZvcm1EYXRhPy50ZW1wbGF0ZV9uYW1lLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKSB7XHJcbiAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0RGlzYWJsZWQoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgdGVtcGxhdGVfbmFtZTogXCJcIixcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwIEZhaWx1cmVcIixcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwMSkge1xyXG4gICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgdGVtcGxhdGVfbmFtZTogXCJcIixcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJXaGF0c2FwcGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgdGVtcGxhdGVfbmFtZTogXCJcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJXaGF0c2FwcCBGYWlsdXJlXCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldERpc2FibGVkKGZhbHNlKTtcclxuICAgICAgY29uc29sZS5lcnJvcihcIndoYXRzYXBwIGVycm9yXCIsIGVyci5tZXNzYWdlKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEFsbCA9ICgpID0+IHtcclxuICAgIGNvbnN0IGNoZWNrZWQgPSAhc2VsZWN0QWxsLmNoZWNrZWQ7XHJcbiAgICBzZXRTZWxlY3RBbGwoe1xyXG4gICAgICAuLi5zZWxlY3RBbGwsXHJcbiAgICAgIG1zZzogc2VsZWN0QWxsLm1zZyA9PT0gXCJBbGxcIiA/IFwiTm9cIiA6IFwiQWxsXCIsXHJcbiAgICAgIGNoZWNrZWQ6ICFzZWxlY3RBbGwuY2hlY2tlZCxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgdGVtcFNlbGVjdFVzZXIgPSB7fTtcclxuICAgIE9iamVjdC5rZXlzKHNlbGVjdFVzZXIpLmZvckVhY2goKHVzZXJfaWQpID0+IHtcclxuICAgICAgdGVtcFNlbGVjdFVzZXJbdXNlcl9pZF0gPSBjaGVja2VkO1xyXG4gICAgfSk7XHJcbiAgICBzZXRTZWxlY3RVc2VyKHRlbXBTZWxlY3RVc2VyKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXBkYXRlVUkgPSAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSB1c2Vycy5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgIG5hbWU6IGdyb3VwLmZ1bGxfbmFtZSxcclxuICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwLnBob25lX251bWJlcixcclxuICAgICAgICBjdXN0b21lcl9pZDogZ3JvdXAuY3VzdG9tZXJfaWQgfHwgYFVwZGF0aW5nIHNvb24uLi5gLFxyXG4gICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgPGRpdiBrZXk9e2dyb3VwLl9pZH0gY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmVlbi00MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1tZCBzaGFkb3cgaG92ZXI6Ym9yZGVyLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0VXNlcigocHJldlNlbGVjdGVkVXNlcikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgLi4ucHJldlNlbGVjdGVkVXNlcixcclxuICAgICAgICAgICAgICAgICAgW2dyb3VwLl9pZF06ICFwcmV2U2VsZWN0ZWRVc2VyW2dyb3VwLl9pZF0sXHJcbiAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdFVzZXJbZ3JvdXA/Ll9pZF0gPz8gZmFsc2V9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjaGVja2VkOnRleHQtZ3JlZW4tNjAwIGZvY3VzOnJpbmctMCAgcm91bmRlZC1sZyBwLTJcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRUYWJsZVVzZXJzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgfTtcclxuICAgIHVwZGF0ZVVJKCk7XHJcbiAgfSwgW3NlbGVjdFVzZXIsIHJlbG9hZFRyaWdnZXJdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgY291bnRDdXN0b21lciA9ICgpID0+IHtcclxuICAgICAgbGV0IGNvdW50ZXIgPSAwO1xyXG4gICAgICBPYmplY3QudmFsdWVzKHNlbGVjdFVzZXIpLmZvckVhY2goKGVsZSkgPT4ge1xyXG4gICAgICAgIGlmIChlbGUpIHtcclxuICAgICAgICAgIGNvdW50ZXIrKztcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRDdXN0b21lckNvdW50KGNvdW50ZXIpO1xyXG4gICAgfTtcclxuICAgIGNvdW50Q3VzdG9tZXIoKTtcclxuICB9LCBbc2VsZWN0VXNlciwgcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9pZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCIgZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgey8qIDxTaWRlYmFyIC8+ICovfVxyXG4gICAgICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBjb2xvcj1cImdyZWVuXCIgc2l6ZT1cIjMwXCIgY2xhc3NOYW1lPVwibS0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgV2hhdHNhcHAgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbXktMiBjdXJzb3ItcG9pbnRlciBzZWxlY3Qtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2VsZWN0QWxsfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0QWxsLmNoZWNrZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXNtIG14LTIgdGV4dC1ncmVlbi00MDAgZm9jdXM6b3V0bGluZS1ub25lIGN1cnNvci1wb2ludGVyIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57YFNlbGVjdCAke3NlbGVjdEFsbC5tc2d9IEN1c3RvbWVyc2B9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIG1sLTQgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtaW4tdy0xMCBtaW4taC0xMCBhYnNvbHV0ZSAtcmlnaHQtNCBib3R0b20tNiBzaGFkb3ctbGcgaG92ZXI6YmctcmVkLTYwMCBiZy1yZWQtNDAwIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIHAtMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHtjdXN0b21lckNvdW50fSBjdXN0b21lcnNgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaGFkb3ctc20gZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJDb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJteC0xXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgV2hhdHNhcHBcclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsoVGFibGVVc2Vycy5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcpID8gKFxyXG4gICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgaXNFeHBvcnRFbmFibGVkPXtmYWxzZX1cclxuICAgICAgICAgICAgICBkYXRhPXtUYWJsZVVzZXJzfVxyXG4gICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YHdoYXRzYXBwLSR7XHJcbiAgICAgICAgICAgICAgICBUYWJsZVVzZXJzLmxlbmd0aCA+IDAgXHJcbiAgICAgICAgICAgICAgICAgID8gVGFibGVVc2Vyc1swXS5uYW1lICtcclxuICAgICAgICAgICAgICAgICAgICBcIiB0byBcIiArXHJcbiAgICAgICAgICAgICAgICAgICAgVGFibGVVc2Vyc1tUYWJsZVVzZXJzLmxlbmd0aCAtIDFdLm5hbWVcclxuICAgICAgICAgICAgICAgICAgOiBcImVtcHR5XCJcclxuICAgICAgICAgICAgICB9LmNzdmB9XHJcbiAgICAgICAgICAgIC8+KTogKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXtUYWJsZVVzZXJzLmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgZGF0YT17XCJHcm91cCBEYXRhXCJ9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgU2VuZCBNZXNzYWdlXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ0ZW1wbGF0ZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFRlbXBsYXRlIE5hbWVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwidGVtcGxhdGVfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS50ZW1wbGF0ZV9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cInRlbXBsYXRlTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGFzdGUgdGVtcGxhdGUgbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWdyZWVuLTUwMCBmb2N1czpib3JkZXItZ3JlZW4tNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMudGVtcGxhdGVfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMudGVtcGxhdGVfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctZ3JlZW4tNzAwIGhvdmVyOmJnLWdyZWVuLTgwMFxyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ncmVlbi0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBTZW5kXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFdoYXRzYXBwQWRkO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvV2hhdHNhcHBBZGQuanN4In0=