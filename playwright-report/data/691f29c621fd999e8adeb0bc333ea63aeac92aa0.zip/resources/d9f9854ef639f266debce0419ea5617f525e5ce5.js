import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DueMessage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const DueMessage = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const [selectAll, setSelectAll] = useState(false);
  const groupOptions = useMemo(() => {
    return [
      ...new Map(
        usersData.filter((u) => u.groupName || u.group_value).map(
          (u) => [
            u.groupId,
            {
              groupId: u.groupId,
              groupName: u.groupName,
              group_value: u.group_value
            }
          ]
        )
      ).values()
    ];
  }, [usersData]);
  const filteredUsers = useMemo(() => {
    const filtered = usersData.filter((u) => {
      const matchGroup = groupFilter ? u.groupId === groupFilter : true;
      const enrollmentDate = new Date(u.enrollmentDate);
      const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
      const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
      const search = searchText.trim().toLowerCase();
      const matchSearch = search ? [
        u.userName,
        u.userPhone,
        u.customerId,
        u.groupName,
        u.group_value,
        u.paymentsTicket,
        u.payment_type,
        u.customer_status
      ].some(
        (value) => String(value ?? "").toLowerCase().includes(search)
      ) : true;
      return matchGroup && matchFromDate && matchToDate && matchSearch;
    });
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    balance: user.balance,
                    userPhone: user.userPhone,
                    paymentsTicket: user.paymentsTicket,
                    groupName: user.groupName,
                    userName: user.userName,
                    groupId: user.groupId,
                    userId: user.userId,
                    amountPaid: user.amountPaid,
                    amountToBePaid: user.totalToBePaid
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
            lineNumber: 84,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, searchText, activeUserData]);
  useEffect(() => {
    if (filteredUsers.length > 0) {
      const allSelected = filteredUsers.every((user) => user.isSelected);
      setSelectAll(allSelected);
    } else {
      setSelectAll(false);
    }
  }, [filteredUsers]);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp..",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/whatsapp/due-message", visibleActiveUsers);
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete newActiveUserData[user._id];
        }
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Has Been Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/v1/admin/users/outstanding");
      const usersList = reportResponse.data?.data?.map((data) => ({
        _id: data._id,
        userName: data.user_id.full_name,
        userPhone: data.user_id.phone_number,
        customerId: data.user_id.customer_id,
        amountPaid: data.total_investment,
        paymentsTicket: data.tickets,
        customer_status: data?.customer_status,
        amountToBePaid: data.total_payable,
        groupName: data.group_id?.group_name,
        group_value: data.group_id?.group_value,
        payment_type: data?.payment_type,
        totalToBePaid: data.total_payable,
        balance: data.total_balance,
        groupId: data.group_id?._id,
        userId: data.user_id?._id
      }));
      setUsersData(usersList);
      setTotalUsers(usersList.length);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "checkBoxs", header: "Select User" },
    { key: "sl_no", header: "SL. NO" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" },
    { key: "payment_type", header: "Payment Type" },
    { key: "paymentsTicket", header: "Ticket" },
    { key: "totalToBePaid", header: "Amount Payable" },
    { key: "customer_status", header: "Customer Status" },
    { key: "amountPaid", header: "Paid Amount" },
    { key: "balance", header: "Balance" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
        lineNumber: 224,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
      lineNumber: 228,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0 p-7 mt-2", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
        lineNumber: 230,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center", children: "Whatsapp Outstanding Messages" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
        lineNumber: 231,
        columnNumber: 11
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
          lineNumber: 237,
          columnNumber: 13
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
          lineNumber: 240,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
          lineNumber: 239,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                  lineNumber: 247,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                  lineNumber: 248,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                lineNumber: 246,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                lineNumber: 252,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
              lineNumber: 245,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                  lineNumber: 257,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                  lineNumber: 260,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                lineNumber: 256,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                lineNumber: 264,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
              lineNumber: 255,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
            lineNumber: 244,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Group Filter" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                lineNumber: 269,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  allowClear: true,
                  popupMatchSelectWidth: false,
                  value: groupFilter || void 0,
                  placeholder: "--All groups--",
                  onChange: (value) => setGroupFilter(value),
                  className: "border h-14 w-[8cm]",
                  filterOption: (input, option) => {
                    const search = input.toLowerCase();
                    return option?.groupName?.toLowerCase().includes(search) || String(option?.groupValue ?? "").toLowerCase().includes(search);
                  },
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: group.groupId,
                        groupName: group.groupName || "",
                        groupValue: group.group_value || "",
                        children: [
                          group.groupName,
                          group.group_value ? ` - ${group.group_value}` : ""
                        ]
                      },
                      group.groupId,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                        lineNumber: 305,
                        columnNumber: 21
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                  lineNumber: 285,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
              lineNumber: 268,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mt-6", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: selectAll,
                  onChange: (e) => {
                    const isChecked = e.target.checked;
                    setSelectAll(isChecked);
                    setActiveUserData((prev) => {
                      const updated = { ...prev };
                      filteredUsers.forEach((user) => {
                        updated[user._id] = {
                          info: {
                            ...updated[user._id]?.info,
                            status: isChecked,
                            balance: user.balance,
                            userPhone: user.userPhone,
                            paymentsTicket: user.paymentsTicket,
                            groupName: user.groupName,
                            userName: user.userName,
                            groupId: user.groupId,
                            userId: user.userId,
                            amountPaid: user.amountPaid,
                            amountToBePaid: user.totalToBePaid
                          }
                        };
                      });
                      return updated;
                    });
                  },
                  className: "mr-2"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                  lineNumber: 318,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium text-gray-700", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                lineNumber: 350,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
              lineNumber: 317,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
            lineNumber: 267,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                      lineNumber: 365,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                    lineNumber: 361,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
                  lineNumber: 368,
                  columnNumber: 21
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
              lineNumber: 356,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
            lineNumber: 355,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "min-w-[1000px]", children: /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Outstanding Whatsapp Message",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: "Outstanding Whatsapp Message.csv"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
              lineNumber: 374,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
            lineNumber: 373,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
            lineNumber: 372,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
          lineNumber: 243,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
        lineNumber: 236,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
      lineNumber: 229,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
    lineNumber: 223,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx",
    lineNumber: 222,
    columnNumber: 5
  }, this);
};
_s(DueMessage, "3FDRUE0DccwsOdSFL4cQjGHpaY4=", false, function() {
  return [notification.useNotification];
});
_c = DueMessage;
export default DueMessage;
var _c;
$RefreshReg$(_c, "DueMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueMessage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUZROzJCQW5GUjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsYUFBYUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJakIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2tCLFdBQVdDLFlBQVksSUFBSW5CLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNvQixhQUFhQyxjQUFjLElBQUlyQixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDc0IsVUFBVUMsV0FBVyxJQUFJdkIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3dCLFFBQVFDLFNBQVMsSUFBSXpCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUMwQixnQkFBZ0JDLGlCQUFpQixJQUFJM0IsU0FBUyxDQUFDLENBQUM7QUFDdkQsUUFBTSxDQUFDNEIsV0FBV0MsWUFBWSxJQUFJN0IsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzhCLFlBQVlDLGFBQWEsSUFBSS9CLFNBQVMsQ0FBQztBQUM5QyxRQUFNLENBQUNnQyxVQUFVQyxhQUFhLElBQUl4QixhQUFheUIsZ0JBQWdCO0FBQy9ELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJcEMsU0FBUyxLQUFLO0FBQ2hELFFBQU1xQyxlQUFlcEMsUUFBUSxNQUFNO0FBQ2pDLFdBQU87QUFBQSxNQUNMLEdBQUcsSUFBSXFDO0FBQUFBLFFBQ0xwQixVQUNHcUIsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxhQUFhRCxFQUFFRSxXQUFXLEVBQzFDQztBQUFBQSxVQUFJLENBQUNILE1BQU07QUFBQSxZQUNWQSxFQUFFSTtBQUFBQSxZQUNGO0FBQUEsY0FDRUEsU0FBU0osRUFBRUk7QUFBQUEsY0FDWEgsV0FBV0QsRUFBRUM7QUFBQUEsY0FDYkMsYUFBYUYsRUFBRUU7QUFBQUEsWUFDakI7QUFBQSxVQUFDO0FBQUEsUUFDRjtBQUFBLE1BQ0wsRUFBRUcsT0FBTztBQUFBLElBQUM7QUFBQSxFQUVkLEdBQUcsQ0FBQzNCLFNBQVMsQ0FBQztBQUVkLFFBQU00QixnQkFBZ0I3QyxRQUFRLE1BQU07QUFDcEMsVUFBTThDLFdBQVc3QixVQUFVcUIsT0FBTyxDQUFDQyxNQUFNO0FBRXZDLFlBQU1RLGFBQWE1QixjQUFjb0IsRUFBRUksWUFBWXhCLGNBQWM7QUFFN0QsWUFBTTZCLGlCQUFpQixJQUFJQyxLQUFLVixFQUFFUyxjQUFjO0FBRWhELFlBQU1FLGdCQUFnQjdCLFdBQ2xCMkIsa0JBQWtCLElBQUlDLEtBQUs1QixRQUFRLElBQ25DO0FBRUosWUFBTThCLGNBQWM1QixTQUFTeUIsa0JBQWtCLElBQUlDLEtBQUsxQixNQUFNLElBQUk7QUFFbEUsWUFBTTZCLFNBQVNyQyxXQUFXc0MsS0FBSyxFQUFFQyxZQUFZO0FBRTdDLFlBQU1DLGNBQWNILFNBQ2hCO0FBQUEsUUFDRWIsRUFBRWlCO0FBQUFBLFFBQ0ZqQixFQUFFa0I7QUFBQUEsUUFDRmxCLEVBQUVtQjtBQUFBQSxRQUNGbkIsRUFBRUM7QUFBQUEsUUFDRkQsRUFBRUU7QUFBQUEsUUFDRkYsRUFBRW9CO0FBQUFBLFFBQ0ZwQixFQUFFcUI7QUFBQUEsUUFDRnJCLEVBQUVzQjtBQUFBQSxNQUFlLEVBQ2pCQztBQUFBQSxRQUFLLENBQUNDLFVBQ05DLE9BQU9ELFNBQVMsRUFBRSxFQUNmVCxZQUFZLEVBQ1pXLFNBQVNiLE1BQU07QUFBQSxNQUNwQixJQUNBO0FBRUosYUFBT0wsY0FBY0csaUJBQWlCQyxlQUFlSTtBQUFBQSxJQUN2RCxDQUFDO0FBRUQsV0FBT1QsU0FBU0osSUFBSSxDQUFDd0IsTUFBTUMsVUFBVTtBQUNuQyxZQUFNQyxhQUFhLENBQUMsQ0FBQzNDLGVBQWV5QyxLQUFLRyxHQUFHLEdBQUdDLE1BQU1DO0FBRXJELGFBQU87QUFBQSxRQUNMLEdBQUdMO0FBQUFBLFFBQ0hNLE9BQU9MLFFBQVE7QUFBQSxRQUNmTSxXQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTTDtBQUFBQSxZQUNULFVBQVUsQ0FBQ00sTUFBTTtBQUNmaEQsZ0NBQWtCLENBQUNpRCxVQUFVO0FBQUEsZ0JBQzNCLEdBQUdBO0FBQUFBLGdCQUNILENBQUNULEtBQUtHLEdBQUcsR0FBRztBQUFBLGtCQUNWQyxNQUFNO0FBQUEsb0JBQ0pDLFFBQVFHLEVBQUVFLE9BQU9DO0FBQUFBLG9CQUNqQkMsU0FBU1osS0FBS1k7QUFBQUEsb0JBQ2RyQixXQUFXUyxLQUFLVDtBQUFBQSxvQkFDaEJFLGdCQUFnQk8sS0FBS1A7QUFBQUEsb0JBQ3JCbkIsV0FBVzBCLEtBQUsxQjtBQUFBQSxvQkFDaEJnQixVQUFVVSxLQUFLVjtBQUFBQSxvQkFDZmIsU0FBU3VCLEtBQUt2QjtBQUFBQSxvQkFDZG9DLFFBQVFiLEtBQUthO0FBQUFBLG9CQUNiQyxZQUFZZCxLQUFLYztBQUFBQSxvQkFDakJDLGdCQUFnQmYsS0FBS2dCO0FBQUFBLGtCQUN2QjtBQUFBLGdCQUNGO0FBQUEsY0FDRixFQUFFO0FBQUEsWUFDSjtBQUFBO0FBQUEsVUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBcUJJO0FBQUEsUUFHTmQ7QUFBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDbkQsV0FBV0UsYUFBYUUsVUFBVUUsUUFBUVIsWUFBWVUsY0FBYyxDQUFDO0FBQ3ZFM0IsWUFBVSxNQUFNO0FBQ2QsUUFBSStDLGNBQWNzQyxTQUFTLEdBQUc7QUFDNUIsWUFBTUMsY0FBY3ZDLGNBQWN3QyxNQUFNLENBQUNuQixTQUFTQSxLQUFLRSxVQUFVO0FBQ2pFakMsbUJBQWFpRCxXQUFXO0FBQUEsSUFDMUIsT0FBTztBQUNMakQsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRixHQUFHLENBQUNVLGFBQWEsQ0FBQztBQUVsQixRQUFNeUMsdUJBQXVCdEYsUUFBUSxNQUFNO0FBQ3pDLFdBQU82QyxjQUFjUCxPQUFPLENBQUM0QixTQUFTQSxLQUFLRSxVQUFVLEVBQUVlO0FBQUFBLEVBQ3pELEdBQUcsQ0FBQ3RDLGFBQWEsQ0FBQztBQUVsQixRQUFNMEMsZUFBZSxZQUFZO0FBQy9CLFVBQU1DLE1BQU07QUFDWixRQUFJO0FBQ0Z6RCxlQUFTMEQsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFFRCxZQUFNQyxxQkFBcUIsQ0FBQztBQUM1QmpELG9CQUFja0QsUUFBUSxDQUFDN0IsU0FBUztBQUM5QixZQUFJQSxLQUFLRSxjQUFjM0MsZUFBZXlDLEtBQUtHLEdBQUcsR0FBRztBQUMvQ3lCLDZCQUFtQjVCLEtBQUtHLEdBQUcsSUFBSTVDLGVBQWV5QyxLQUFLRyxHQUFHO0FBQUEsUUFDeEQ7QUFBQSxNQUNGLENBQUM7QUFFRCxZQUFNcEUsSUFBSStGLEtBQUsseUJBQXlCRixrQkFBa0I7QUFFMUQsWUFBTUcsb0JBQW9CLEVBQUUsR0FBR3hFLGVBQWU7QUFDOUNvQixvQkFBY2tELFFBQVEsQ0FBQzdCLFNBQVM7QUFDOUIsWUFBSUEsS0FBS0UsWUFBWTtBQUNuQixpQkFBTzZCLGtCQUFrQi9CLEtBQUtHLEdBQUc7QUFBQSxRQUNuQztBQUFBLE1BQ0YsQ0FBQztBQUNEM0Msd0JBQWtCdUUsaUJBQWlCO0FBRW5DbEUsZUFBUzBELEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxTQUFTSyxLQUFLO0FBQ1puRSxlQUFTMEQsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhTyxJQUFJUixXQUFXO0FBQUEsUUFDNUJFLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNTSxZQUFZLFlBQVk7QUFDNUIsUUFBSTtBQUNGdkUsbUJBQWEsSUFBSTtBQUNqQixZQUFNd0UsaUJBQWlCLE1BQU1uRyxJQUFJb0csSUFBSSw2QkFBNkI7QUFDbEUsWUFBTUMsWUFBWUYsZUFBZUcsTUFBTUEsTUFBTTdELElBQUksQ0FBQzZELFVBQVU7QUFBQSxRQUMxRGxDLEtBQUtrQyxLQUFLbEM7QUFBQUEsUUFDVmIsVUFBVStDLEtBQUtDLFFBQVFDO0FBQUFBLFFBQ3ZCaEQsV0FBVzhDLEtBQUtDLFFBQVFFO0FBQUFBLFFBQ3hCaEQsWUFBWTZDLEtBQUtDLFFBQVFHO0FBQUFBLFFBQ3pCM0IsWUFBWXVCLEtBQUtLO0FBQUFBLFFBQ2pCakQsZ0JBQWdCNEMsS0FBS007QUFBQUEsUUFDckJoRCxpQkFBaUIwQyxNQUFNMUM7QUFBQUEsUUFDdkJvQixnQkFBZ0JzQixLQUFLTztBQUFBQSxRQUNyQnRFLFdBQVcrRCxLQUFLUSxVQUFVQztBQUFBQSxRQUMxQnZFLGFBQWE4RCxLQUFLUSxVQUFVdEU7QUFBQUEsUUFDNUJtQixjQUFjMkMsTUFBTTNDO0FBQUFBLFFBQ3BCc0IsZUFBZXFCLEtBQUtPO0FBQUFBLFFBQ3BCaEMsU0FBU3lCLEtBQUtVO0FBQUFBLFFBQ2R0RSxTQUFTNEQsS0FBS1EsVUFBVTFDO0FBQUFBLFFBQ3hCVSxRQUFRd0IsS0FBS0MsU0FBU25DO0FBQUFBLE1BQ3hCLEVBQUU7QUFFRm5ELG1CQUFhb0YsU0FBUztBQUN0QnhFLG9CQUFjd0UsVUFBVW5CLE1BQU07QUFBQSxJQUNoQyxTQUFTK0IsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDLFVBQUM7QUFDQ3RGLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQTlCLFlBQVUsTUFBTTtBQUNkcUcsY0FBVTtBQUFBLEVBQ1osR0FBRyxFQUFFO0FBRUwsUUFBTWlCLGlCQUFpQjtBQUFBLElBQ3JCLEVBQUU1QixLQUFLLGFBQWE2QixRQUFRLGNBQWM7QUFBQSxJQUMxQyxFQUFFN0IsS0FBSyxTQUFTNkIsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRTdCLEtBQUssWUFBWTZCLFFBQVEsZ0JBQWdCO0FBQUEsSUFDM0MsRUFBRTdCLEtBQUssYUFBYTZCLFFBQVEsZUFBZTtBQUFBLElBQzNDLEVBQUU3QixLQUFLLGNBQWM2QixRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFN0IsS0FBSyxhQUFhNkIsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRTdCLEtBQUssZ0JBQWdCNkIsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRTdCLEtBQUssa0JBQWtCNkIsUUFBUSxTQUFTO0FBQUEsSUFDMUMsRUFBRTdCLEtBQUssaUJBQWlCNkIsUUFBUSxpQkFBaUI7QUFBQSxJQUNqRCxFQUFFN0IsS0FBSyxtQkFBbUI2QixRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUU3QixLQUFLLGNBQWM2QixRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFN0IsS0FBSyxXQUFXNkIsUUFBUSxVQUFVO0FBQUEsRUFBQztBQUd2QyxTQUNFLHVCQUFDLFNBQUksV0FBVSxVQUNiLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLDZCQUE2QixDQUFDM0MsTUFBTTFELGNBQWMwRCxFQUFFRSxPQUFPYixLQUFLO0FBQUEsUUFDaEUsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBQ1IsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFDWCx1QkFBQyxRQUFHLFdBQVUsa0NBQWlDLDZDQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDL0I7QUFBQUEsTUFFRCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFDakVMLFlBQ0MsdUJBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsa0JBQWUsT0FBTSxvQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Q7QUFBQSxnQkFDcEQsdUJBQUMsT0FBRSxXQUFVLHNDQUNWa0Isd0JBQWNzQyxVQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsV0FBUSxXQUFVLDhCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBLGlCQVAvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUF3QixrQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxxQ0FDVkcsa0NBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLGlCQUFjLFdBQVUsNkJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtEO0FBQUEsaUJBVHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxlQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQWNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQSx1QkFBdUI7QUFBQSxrQkFDdkIsT0FBT25FLGVBQWVtRztBQUFBQSxrQkFDdEIsYUFBWTtBQUFBLGtCQUNaLFVBQVUsQ0FBQ3ZELFVBQVUzQyxlQUFlMkMsS0FBSztBQUFBLGtCQUN6QyxXQUFVO0FBQUEsa0JBQ1YsY0FBYyxDQUFDd0QsT0FBT0MsV0FBVztBQUMvQiwwQkFBTXBFLFNBQVNtRSxNQUFNakUsWUFBWTtBQUVqQywyQkFDRWtFLFFBQVFoRixXQUFXYyxZQUFZLEVBQUVXLFNBQVNiLE1BQU0sS0FDaERZLE9BQU93RCxRQUFRQyxjQUFjLEVBQUUsRUFDNUJuRSxZQUFZLEVBQ1pXLFNBQVNiLE1BQU07QUFBQSxrQkFFdEI7QUFBQSxrQkFFQ2hCLHVCQUFhTTtBQUFBQSxvQkFBSSxDQUFDZ0YsVUFDakI7QUFBQSxzQkFBQyxPQUFPO0FBQUEsc0JBQVA7QUFBQSx3QkFFQyxPQUFPQSxNQUFNL0U7QUFBQUEsd0JBQ2IsV0FBVytFLE1BQU1sRixhQUFhO0FBQUEsd0JBQzlCLFlBQVlrRixNQUFNakYsZUFBZTtBQUFBLHdCQUVoQ2lGO0FBQUFBLGdDQUFNbEY7QUFBQUEsMEJBQ05rRixNQUFNakYsY0FBYyxNQUFNaUYsTUFBTWpGLFdBQVcsS0FBSztBQUFBO0FBQUE7QUFBQSxzQkFONUNpRixNQUFNL0U7QUFBQUEsc0JBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkE3Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBOEJBO0FBQUEsaUJBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0RBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBU1Q7QUFBQUEsa0JBQ1QsVUFBVSxDQUFDd0MsTUFBTTtBQUNmLDBCQUFNaUQsWUFBWWpELEVBQUVFLE9BQU9DO0FBQzNCMUMsaUNBQWF3RixTQUFTO0FBR3RCakcsc0NBQWtCLENBQUNpRCxTQUFTO0FBQzFCLDRCQUFNaUQsVUFBVSxFQUFFLEdBQUdqRCxLQUFLO0FBQzFCOUIsb0NBQWNrRCxRQUFRLENBQUM3QixTQUFTO0FBQzlCMEQsZ0NBQVExRCxLQUFLRyxHQUFHLElBQUk7QUFBQSwwQkFDbEJDLE1BQU07QUFBQSw0QkFDSixHQUFHc0QsUUFBUTFELEtBQUtHLEdBQUcsR0FBR0M7QUFBQUEsNEJBQ3RCQyxRQUFRb0Q7QUFBQUEsNEJBQ1I3QyxTQUFTWixLQUFLWTtBQUFBQSw0QkFDZHJCLFdBQVdTLEtBQUtUO0FBQUFBLDRCQUNoQkUsZ0JBQWdCTyxLQUFLUDtBQUFBQSw0QkFDckJuQixXQUFXMEIsS0FBSzFCO0FBQUFBLDRCQUNoQmdCLFVBQVVVLEtBQUtWO0FBQUFBLDRCQUNmYixTQUFTdUIsS0FBS3ZCO0FBQUFBLDRCQUNkb0MsUUFBUWIsS0FBS2E7QUFBQUEsNEJBQ2JDLFlBQVlkLEtBQUtjO0FBQUFBLDRCQUNqQkMsZ0JBQWdCZixLQUFLZ0I7QUFBQUEsMEJBQ3ZCO0FBQUEsd0JBQ0Y7QUFBQSxzQkFDRixDQUFDO0FBQ0QsNkJBQU8wQztBQUFBQSxvQkFDVCxDQUFDO0FBQUEsa0JBQ0g7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkE5Qlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBOEJrQjtBQUFBLGNBRWxCLHVCQUFDLFdBQU0sV0FBVSxxQ0FBb0MsMEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQ0E7QUFBQSxlQXRGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVGQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTckM7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVEQ7QUFBQUEsdUNBQXVCLEtBQ3RCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPLGlDQUFpQ0Esb0JBQW9CO0FBQUEsb0JBRTVELGlDQUFDLFVBQU1BLGtDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRCO0FBQUE7QUFBQSxrQkFKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUYsdUJBQUMsY0FBVyxXQUFVLFFBQU8sTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBWjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYixpQ0FBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU16QztBQUFBQSxjQUNOLFNBQVN1RTtBQUFBQSxjQUNULFNBQVE7QUFBQSxjQUNSLGlCQUFnQjtBQUFBLGNBQ2hCLGlCQUFpQixDQUFDLFlBQVk7QUFBQSxjQUM5QixtQkFBbUIsQ0FBQ2pHLFdBQVc7QUFBQSxjQUMvQixrQkFBaUI7QUFBQTtBQUFBLFlBUG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9xRCxLQVJ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBN0lGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4SUE7QUFBQSxXQXJKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUpBO0FBQUEsU0E5SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStKQTtBQUFBLE9BcktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzS0EsS0F2S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdLQTtBQUVKO0FBQUVMLEdBMVhJRCxZQUFVO0FBQUEsVUFTb0JMLGFBQWF5QixlQUFlO0FBQUE7QUFBQTRGLEtBVDFEaEg7QUE0WE4sZUFBZUE7QUFBVyxJQUFBZ0g7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiU2VsZWN0IiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiRmFXaGF0c2FwcCIsIm5vdGlmaWNhdGlvbiIsIlNpZGViYXIiLCJGYVVzZXJzIiwiRmFDaGVja0NpcmNsZSIsIkJyZWFkY3J1bWIiLCJEdWVNZXNzYWdlIiwiX3MiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInVzZXJzRGF0YSIsInNldFVzZXJzRGF0YSIsImdyb3VwRmlsdGVyIiwic2V0R3JvdXBGaWx0ZXIiLCJmcm9tRGF0ZSIsInNldEZyb21EYXRlIiwidG9EYXRlIiwic2V0VG9EYXRlIiwiYWN0aXZlVXNlckRhdGEiLCJzZXRBY3RpdmVVc2VyRGF0YSIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInRvdGFsVXNlcnMiLCJzZXRUb3RhbFVzZXJzIiwibm90aWZpZXIiLCJjb250ZXh0SG9sZGVyIiwidXNlTm90aWZpY2F0aW9uIiwic2VsZWN0QWxsIiwic2V0U2VsZWN0QWxsIiwiZ3JvdXBPcHRpb25zIiwiTWFwIiwiZmlsdGVyIiwidSIsImdyb3VwTmFtZSIsImdyb3VwX3ZhbHVlIiwibWFwIiwiZ3JvdXBJZCIsInZhbHVlcyIsImZpbHRlcmVkVXNlcnMiLCJmaWx0ZXJlZCIsIm1hdGNoR3JvdXAiLCJlbnJvbGxtZW50RGF0ZSIsIkRhdGUiLCJtYXRjaEZyb21EYXRlIiwibWF0Y2hUb0RhdGUiLCJzZWFyY2giLCJ0cmltIiwidG9Mb3dlckNhc2UiLCJtYXRjaFNlYXJjaCIsInVzZXJOYW1lIiwidXNlclBob25lIiwiY3VzdG9tZXJJZCIsInBheW1lbnRzVGlja2V0IiwicGF5bWVudF90eXBlIiwiY3VzdG9tZXJfc3RhdHVzIiwic29tZSIsInZhbHVlIiwiU3RyaW5nIiwiaW5jbHVkZXMiLCJ1c2VyIiwiaW5kZXgiLCJpc1NlbGVjdGVkIiwiX2lkIiwiaW5mbyIsInN0YXR1cyIsInNsX25vIiwiY2hlY2tCb3hzIiwiZSIsInByZXYiLCJ0YXJnZXQiLCJjaGVja2VkIiwiYmFsYW5jZSIsInVzZXJJZCIsImFtb3VudFBhaWQiLCJhbW91bnRUb0JlUGFpZCIsInRvdGFsVG9CZVBhaWQiLCJsZW5ndGgiLCJhbGxTZWxlY3RlZCIsImV2ZXJ5IiwidmlzaWJsZVNlbGVjdGVkQ291bnQiLCJzZW5kV2hhdHNhcHAiLCJrZXkiLCJvcGVuIiwibWVzc2FnZSIsImRlc2NyaXB0aW9uIiwiY2xhc3NOYW1lIiwiZHVyYXRpb24iLCJ2aXNpYmxlQWN0aXZlVXNlcnMiLCJmb3JFYWNoIiwicG9zdCIsIm5ld0FjdGl2ZVVzZXJEYXRhIiwiZXJyIiwiZmV0Y2hEYXRhIiwicmVwb3J0UmVzcG9uc2UiLCJnZXQiLCJ1c2Vyc0xpc3QiLCJkYXRhIiwidXNlcl9pZCIsImZ1bGxfbmFtZSIsInBob25lX251bWJlciIsImN1c3RvbWVyX2lkIiwidG90YWxfaW52ZXN0bWVudCIsInRpY2tldHMiLCJ0b3RhbF9wYXlhYmxlIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwidG90YWxfYmFsYW5jZSIsImVycm9yIiwiY29uc29sZSIsIkF1Y3Rpb25jb2x1bW5zIiwiaGVhZGVyIiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJncm91cFZhbHVlIiwiZ3JvdXAiLCJpc0NoZWNrZWQiLCJ1cGRhdGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRHVlTWVzc2FnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHsgRmFXaGF0c2FwcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgRmFVc2VycywgRmFDaGVja0NpcmNsZSB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5jb25zdCBEdWVNZXNzYWdlID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt1c2Vyc0RhdGEsIHNldFVzZXJzRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3VwRmlsdGVyLCBzZXRHcm91cEZpbHRlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0b0RhdGUsIHNldFRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWN0aXZlVXNlckRhdGEsIHNldEFjdGl2ZVVzZXJEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt0b3RhbFVzZXJzLCBzZXRUb3RhbFVzZXJzXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtub3RpZmllciwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcbiAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBncm91cE9wdGlvbnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBbXHJcbiAgICAgIC4uLm5ldyBNYXAoXHJcbiAgICAgICAgdXNlcnNEYXRhXHJcbiAgICAgICAgICAuZmlsdGVyKCh1KSA9PiB1Lmdyb3VwTmFtZSB8fCB1Lmdyb3VwX3ZhbHVlKVxyXG4gICAgICAgICAgLm1hcCgodSkgPT4gW1xyXG4gICAgICAgICAgICB1Lmdyb3VwSWQsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBncm91cElkOiB1Lmdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgZ3JvdXBOYW1lOiB1Lmdyb3VwTmFtZSxcclxuICAgICAgICAgICAgICBncm91cF92YWx1ZTogdS5ncm91cF92YWx1ZSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIF0pXHJcbiAgICAgICkudmFsdWVzKCksXHJcbiAgICBdO1xyXG4gIH0sIFt1c2Vyc0RhdGFdKTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gIGNvbnN0IGZpbHRlcmVkID0gdXNlcnNEYXRhLmZpbHRlcigodSkgPT4ge1xyXG4gICAgLy8g4pyFIEZJWEVEOiBDb21wYXJlIHRoZSBJRCBpbnN0ZWFkIG9mIHRoZSBOYW1lXHJcbiAgICBjb25zdCBtYXRjaEdyb3VwID0gZ3JvdXBGaWx0ZXIgPyB1Lmdyb3VwSWQgPT09IGdyb3VwRmlsdGVyIDogdHJ1ZTtcclxuXHJcbiAgICBjb25zdCBlbnJvbGxtZW50RGF0ZSA9IG5ldyBEYXRlKHUuZW5yb2xsbWVudERhdGUpO1xyXG5cclxuICAgIGNvbnN0IG1hdGNoRnJvbURhdGUgPSBmcm9tRGF0ZVxyXG4gICAgICA/IGVucm9sbG1lbnREYXRlID49IG5ldyBEYXRlKGZyb21EYXRlKVxyXG4gICAgICA6IHRydWU7XHJcblxyXG4gICAgY29uc3QgbWF0Y2hUb0RhdGUgPSB0b0RhdGUgPyBlbnJvbGxtZW50RGF0ZSA8PSBuZXcgRGF0ZSh0b0RhdGUpIDogdHJ1ZTtcclxuXHJcbiAgICBjb25zdCBzZWFyY2ggPSBzZWFyY2hUZXh0LnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgIGNvbnN0IG1hdGNoU2VhcmNoID0gc2VhcmNoXHJcbiAgICAgID8gW1xyXG4gICAgICAgICAgdS51c2VyTmFtZSxcclxuICAgICAgICAgIHUudXNlclBob25lLFxyXG4gICAgICAgICAgdS5jdXN0b21lcklkLFxyXG4gICAgICAgICAgdS5ncm91cE5hbWUsXHJcbiAgICAgICAgICB1Lmdyb3VwX3ZhbHVlLFxyXG4gICAgICAgICAgdS5wYXltZW50c1RpY2tldCxcclxuICAgICAgICAgIHUucGF5bWVudF90eXBlLFxyXG4gICAgICAgICAgdS5jdXN0b21lcl9zdGF0dXMsXHJcbiAgICAgICAgXS5zb21lKCh2YWx1ZSkgPT5cclxuICAgICAgICAgIFN0cmluZyh2YWx1ZSA/PyBcIlwiKVxyXG4gICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAuaW5jbHVkZXMoc2VhcmNoKVxyXG4gICAgICAgIClcclxuICAgICAgOiB0cnVlO1xyXG5cclxuICAgIHJldHVybiBtYXRjaEdyb3VwICYmIG1hdGNoRnJvbURhdGUgJiYgbWF0Y2hUb0RhdGUgJiYgbWF0Y2hTZWFyY2g7XHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiBmaWx0ZXJlZC5tYXAoKHVzZXIsIGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCBpc1NlbGVjdGVkID0gISFhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cztcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAuLi51c2VyLFxyXG4gICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4gICAgICBjaGVja0JveHM6IChcclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgW3VzZXIuX2lkXToge1xyXG4gICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgIGJhbGFuY2U6IHVzZXIuYmFsYW5jZSxcclxuICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgcGF5bWVudHNUaWNrZXQ6IHVzZXIucGF5bWVudHNUaWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICBncm91cElkOiB1c2VyLmdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICAgIHVzZXJJZDogdXNlci51c2VySWQsXHJcbiAgICAgICAgICAgICAgICAgIGFtb3VudFBhaWQ6IHVzZXIuYW1vdW50UGFpZCxcclxuICAgICAgICAgICAgICAgICAgYW1vdW50VG9CZVBhaWQ6IHVzZXIudG90YWxUb0JlUGFpZCxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApLFxyXG4gICAgICBpc1NlbGVjdGVkLFxyXG4gICAgfTtcclxuICB9KTtcclxufSwgW3VzZXJzRGF0YSwgZ3JvdXBGaWx0ZXIsIGZyb21EYXRlLCB0b0RhdGUsIHNlYXJjaFRleHQsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChmaWx0ZXJlZFVzZXJzLmxlbmd0aCA+IDApIHtcclxuICAgICAgY29uc3QgYWxsU2VsZWN0ZWQgPSBmaWx0ZXJlZFVzZXJzLmV2ZXJ5KCh1c2VyKSA9PiB1c2VyLmlzU2VsZWN0ZWQpO1xyXG4gICAgICBzZXRTZWxlY3RBbGwoYWxsU2VsZWN0ZWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuICAgIH1cclxuICB9LCBbZmlsdGVyZWRVc2Vyc10pO1xyXG5cclxuICBjb25zdCB2aXNpYmxlU2VsZWN0ZWRDb3VudCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGZpbHRlcmVkVXNlcnMuZmlsdGVyKCh1c2VyKSA9PiB1c2VyLmlzU2VsZWN0ZWQpLmxlbmd0aDtcclxuICB9LCBbZmlsdGVyZWRVc2Vyc10pO1xyXG5cclxuICBjb25zdCBzZW5kV2hhdHNhcHAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBrZXkgPSBcInVwZGF0YWJsZVwiO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU2VuZGluZyBNZXNzYWdlcyBWaWEgV2hhdHNhcHAuLlwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2Nlc3NpbmcuLi5cIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgdmlzaWJsZUFjdGl2ZVVzZXJzID0ge307XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQgJiYgYWN0aXZlVXNlckRhdGFbdXNlci5faWRdKSB7XHJcbiAgICAgICAgICB2aXNpYmxlQWN0aXZlVXNlcnNbdXNlci5faWRdID0gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi93aGF0c2FwcC9kdWUtbWVzc2FnZVwiLCB2aXNpYmxlQWN0aXZlVXNlcnMpO1xyXG5cclxuICAgICAgY29uc3QgbmV3QWN0aXZlVXNlckRhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQpIHtcclxuICAgICAgICAgIGRlbGV0ZSBuZXdBY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF07XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgICAgc2V0QWN0aXZlVXNlckRhdGEobmV3QWN0aXZlVXNlckRhdGEpO1xyXG5cclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiV2hhdHNhcHAgTWVzc2FnZXMgSGFzIEJlZW4gU2VudCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogXCJTdWNjZXNzXCIsXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gU2VuZCBXaGF0c2FwcFwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBlcnIubWVzc2FnZSB8fCBcIlNvbWV0aGluZyB3ZW50IHdyb25nXCIsXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJnLXJlZC0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXBvcnRSZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vdXNlcnMvb3V0c3RhbmRpbmdcIik7XHJcbiAgICAgIGNvbnN0IHVzZXJzTGlzdCA9IHJlcG9ydFJlc3BvbnNlLmRhdGE/LmRhdGE/Lm1hcCgoZGF0YSkgPT4gKHtcclxuICAgICAgICBfaWQ6IGRhdGEuX2lkLFxyXG4gICAgICAgIHVzZXJOYW1lOiBkYXRhLnVzZXJfaWQuZnVsbF9uYW1lLFxyXG4gICAgICAgIHVzZXJQaG9uZTogZGF0YS51c2VyX2lkLnBob25lX251bWJlcixcclxuICAgICAgICBjdXN0b21lcklkOiBkYXRhLnVzZXJfaWQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgYW1vdW50UGFpZDogZGF0YS50b3RhbF9pbnZlc3RtZW50LFxyXG4gICAgICAgIHBheW1lbnRzVGlja2V0OiBkYXRhLnRpY2tldHMsXHJcbiAgICAgICAgY3VzdG9tZXJfc3RhdHVzOiBkYXRhPy5jdXN0b21lcl9zdGF0dXMsXHJcbiAgICAgICAgYW1vdW50VG9CZVBhaWQ6IGRhdGEudG90YWxfcGF5YWJsZSxcclxuICAgICAgICBncm91cE5hbWU6IGRhdGEuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgZ3JvdXBfdmFsdWU6IGRhdGEuZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlLFxyXG4gICAgICAgIHBheW1lbnRfdHlwZTogZGF0YT8ucGF5bWVudF90eXBlLFxyXG4gICAgICAgIHRvdGFsVG9CZVBhaWQ6IGRhdGEudG90YWxfcGF5YWJsZSxcclxuICAgICAgICBiYWxhbmNlOiBkYXRhLnRvdGFsX2JhbGFuY2UsXHJcbiAgICAgICAgZ3JvdXBJZDogZGF0YS5ncm91cF9pZD8uX2lkLFxyXG4gICAgICAgIHVzZXJJZDogZGF0YS51c2VyX2lkPy5faWQsXHJcbiAgICAgIH0pKTtcclxuXHJcbiAgICAgIHNldFVzZXJzRGF0YSh1c2Vyc0xpc3QpO1xyXG4gICAgICBzZXRUb3RhbFVzZXJzKHVzZXJzTGlzdC5sZW5ndGgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgQXVjdGlvbmNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJjaGVja0JveHNcIiwgaGVhZGVyOiBcIlNlbGVjdCBVc2VyXCIgfSxcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRzVGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxUb0JlUGFpZFwiLCBoZWFkZXI6IFwiQW1vdW50IFBheWFibGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfc3RhdHVzXCIsIGhlYWRlcjogXCJDdXN0b21lciBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50UGFpZFwiLCBoZWFkZXI6IFwiUGFpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMCBwLTcgbXQtMlwiPlxyXG4gICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgV2hhdHNhcHAgT3V0c3RhbmRpbmcgTWVzc2FnZXNcclxuICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1zdGFydCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgbWItNFwiPjwvZGl2PlxyXG4gICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgY29sb3I9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNiBtdC04IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtMTAwIHJvdW5kZWQteGwgcC02IHNoYWRvdyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+VG90YWwgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRVc2Vycy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhVXNlcnMgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIHRleHQtNHhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3RlZCBDdXN0b21lcnNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhQ2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgdGV4dC00eGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXAgRmlsdGVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIwMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItLUFsbCBncm91cHMtLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRHcm91cEZpbHRlcih2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXBGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXBGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItLUFsbCBncm91cHMtLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRHcm91cEZpbHRlcih2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgaC0xNCB3LVs4Y21dXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2VhcmNoID0gaW5wdXQudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5ncm91cE5hbWU/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoKSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFN0cmluZyhvcHRpb24/Lmdyb3VwVmFsdWUgPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoc2VhcmNoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2dyb3VwLmdyb3VwSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLmdyb3VwSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBOYW1lPXtncm91cC5ncm91cE5hbWUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cFZhbHVlPXtncm91cC5ncm91cF92YWx1ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfdmFsdWUgPyBgIC0gJHtncm91cC5ncm91cF92YWx1ZX1gIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG10LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNDaGVja2VkID0gZS50YXJnZXQuY2hlY2tlZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0QWxsKGlzQ2hlY2tlZCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBVcGRhdGUgYWxsIGZpbHRlcmVkIHVzZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4ucHJldiB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFt1c2VyLl9pZF0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVkW3VzZXIuX2lkXT8uaW5mbyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGlzQ2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWxhbmNlOiB1c2VyLmJhbGFuY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXltZW50c1RpY2tldDogdXNlci5wYXltZW50c1RpY2tldCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwSWQ6IHVzZXIuZ3JvdXBJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudFBhaWQ6IHVzZXIuYW1vdW50UGFpZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnRUb0JlUGFpZDogdXNlci50b3RhbFRvQmVQYWlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdXBkYXRlZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXItMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZW5kV2hhdHNhcHB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNiBoLTYgYWJzb2x1dGUgLXJpZ2h0LTMgLXRvcC0yIHNoYWRvdy1sZyBob3ZlcjpiZy1yZWQtNjAwIGJnLXJlZC00MDAgcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHt2aXNpYmxlU2VsZWN0ZWRDb3VudH0gY3VzdG9tZXJzYH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Zpc2libGVTZWxlY3RlZENvdW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwibXItMlwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFdoYXRzQXBwXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMTAwMHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtBdWN0aW9uY29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiT3V0c3RhbmRpbmcgV2hhdHNhcHAgTWVzc2FnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcIkdyb3VwIE5hbWVcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W2dyb3VwRmlsdGVyXX1cclxuICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJPdXRzdGFuZGluZyBXaGF0c2FwcCBNZXNzYWdlLmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEdWVNZXNzYWdlO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRHVlTWVzc2FnZS5qc3gifQ==