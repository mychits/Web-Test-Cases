import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { createBrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import ProtectedRoute from "/src/components/authentication/ProtectedRoute.jsx?t=1792822406834";
import SuperAdminRoute from "/src/components/authentication/SuperAdminRoute.jsx";
import Login from "/src/pages/Login.jsx";
import Home from "/src/pages/Home.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Group from "/src/pages/Group.jsx";
import User from "/src/pages/User.jsx";
import Task from "/src/pages/Task.jsx";
import Target from "/src/pages/Target.jsx";
import EnrollmentRequestForm from "/src/pages/EnrollmentRequestForm.jsx";
import FilterGroups from "/src/pages/FilterGroups.jsx";
import Payroll from "/src/pages/Payroll.jsx";
import Staff from "/src/pages/Staff.jsx";
import Employee from "/src/pages/Employee.jsx";
import WeekGroup from "/src/pages/WeekGroup.jsx";
import Enroll from "/src/pages/Enroll.jsx";
import Loan from "/src/pages/Loan.jsx";
import Pigme from "/src/pages/Pigme.jsx";
import Auction from "/src/pages/Auction.jsx";
import Payment from "/src/pages/Payment.jsx";
import CollectionArea from "/src/pages/CollectionArea.jsx";
import Agent from "/src/pages/Agent.jsx";
import Lead from "/src/pages/Lead.jsx";
import LeadSetting from "/src/pages/LeadSetting.jsx";
import AppSettings from "/src/pages/AppSettings.jsx";
import GroupSettings from "/src/pages/GroupSettings.jsx";
import AdministrativePrivileges from "/src/pages/AdministrativePrivileges.jsx";
import AdminAccessRights from "/src/pages/AdminAccessRights.jsx";
import Marketing from "/src/pages/Marketing.jsx";
import Profile from "/src/pages/Profile.jsx";
import Daybook from "/src/pages/Daybook.jsx";
import SalesReport from "/src/pages/SalesReport.jsx";
import Receipt from "/src/pages/Receipt.jsx";
import GroupReport from "/src/pages/GroupReport.jsx";
import AllGroupReport from "/src/pages/AllGroupReport.jsx";
import AuctionReport from "/src/pages/AuctionReport.jsx";
import LeadReport from "/src/pages/LeadReport.jsx";
import UserReport from "/src/pages/UserReport.jsx";
import AllUserReport from "/src/pages/AllUserReport.jsx";
import LoanReport from "/src/pages/LoanReport.jsx";
import PigmeReport from "/src/pages/PigmeReport.jsx";
import EmployeeReport from "/src/pages/EmployeeReport.jsx";
import CommissionReport from "/src/pages/CommissionReport.jsx";
import EnrollmentReport from "/src/pages/EnrollmentReport.jsx";
import PaymentSummary from "/src/pages/PaymentSummary.jsx";
import WhatsappAdd from "/src/pages/WhatsappAdd.jsx";
import WhatsappFailed from "/src/pages/WhatsappFailed.jsx";
import DueMessage from "/src/pages/DueMessage.jsx";
import OutstandingReport from "/src/pages/OutstandingReport.jsx";
import Reports from "/src/pages/Reports.jsx";
import LeadSettings from "/src/pages/LeadSettings.jsx";
import Designation from "/src/pages/Designation.jsx";
import PayOutMenu from "/src/pages/PayOutMenu.jsx";
import GeneralPaymentOut from "/src/pages/GeneralPaymentOut.jsx";
import Print from "/src/pages/Print.jsx";
import PayOutCommission from "/src/pages/PayOutCommission.jsx";
import PayOutPettyCash from "/src/pages/PayOutPettyCash.jsx";
import PayOutSalary from "/src/pages/PayOutSalary.jsx";
import PayOutReport from "/src/pages/PayoutReport.jsx";
import ErrorPage from "/src/routes/error/ErrorPage.jsx";
import Guarantor from "/src/pages/Guarantor.jsx";
import DreamAsset from "/src/pages/DreamAsset.jsx";
import BecomeAgent from "/src/pages/BecomeAgent.jsx";
import PayOutOthers from "/src/pages/PayOutOthers.jsx";
import PayInMenu from "/src/pages/PayInMenu.jsx";
import RegistrationFee from "/src/pages/RegistrationFees.jsx";
import PrintPaymentOut from "/src/pages/PrintPaymentOut.jsx";
import RegistrationReceipt from "/src/pages/RegistrationReceipt.jsx";
import AuctionIntemationMessage from "/src/pages/AuctionIntemationMessage.jsx";
import OverDueMessage from "/src/pages/OverDueMessage.jsx";
import DueEmail from "/src/pages/DueEmail.jsx";
import OverDueEmail from "/src/pages/OverDueEmail.jsx";
import WhatsappPromo from "/src/pages/WhatsappPromo.jsx";
import QuickSearch from "/src/pages/QuickSearch.jsx";
import BidWinner from "/src/pages/BidWinner.jsx";
import TransferCustomer from "/src/pages/SoftTransferCustomer.jsx";
import SoftTransferCustomer from "/src/pages/SoftTransferCustomer.jsx";
import HardTransferCustomer from "/src/pages/HardTransfer.jsx";
import UnApprovedCustomer from "/src/pages/UnApprovedCustomer.jsx";
import PaymentLink from "/src/pages/PaymentLink.jsx";
import MobileAppEnroll from "/src/pages/MobileAppEnroll.jsx";
import PaymentLinkMenu from "/src/pages/PaymentLinkMenu.jsx";
import ChitBulkPaymentLink from "/src/pages/BulkChitPaymentLink.jsx";
import IndividualChitPaymentLink from "/src/pages/IndividualChitPaymentLink.jsx";
import TargetIncentiveNewReport from "/src/pages/TargetIncentiveNewReport.jsx";
import ChitCollectionIncentiveReport from "/src/pages/ChitCollectionIncentiveReport.jsx";
import LoanCollectionIncentiveReport from "/src/pages/LoanCollectionIncentiveReport.jsx";
import PigmyCollectionIncentiveReport from "/src/pages/PigmyCollectionIncentiveReport.jsx";
import IndividualRegistrationChitPaymentLink from "/src/pages/IndividualRegistrationChitPaymentLink.jsx";
import TargetIncentiveReport from "/src/pages/TargetIncentive.jsx";
import TargetPayOutSalary from "/src/pages/TargetPayoutSalary.jsx";
import TargetPayOutCommissionIncentive from "/src/pages/TargetPayOutCommissionIncentive.jsx";
import TargetCommission from "/src/pages/TargetCommission.jsx";
import MonthlyInstallmentTurnoverReport from "/src/pages/MonthlyInstallmentTurnoverReport.jsx";
import HoldedCustomerReport from "/src/pages/HoldedCustomerReport.jsx";
import AuctionBidStatus from "/src/pages/AuctionBidStatus.jsx";
import AuctionWinnerDocuments from "/src/pages/AuctionWinnerDocuments.jsx";
import AuctionInformation from "/src/pages/AuctionInformation.jsx";
import AuctionTermsandCondition from "/src/pages/AuctionTermsandCondition.jsx";
import LeadWhatsappWelcomeMessage from "/src/pages/LeadWhatsappWelcomeMessage.jsx";
import LeadReferredByWhatsappMessage from "/src/pages/LeadReferredByWhatsappMessage.jsx";
import CustomerWelcomeWhatsappMessage from "/src/pages/CustomerWelcomeWhatsappMessage.jsx";
import CustomerChitPlanWhatsappMessage from "/src/pages/CustomerChitPlanWhatsappMessage.jsx";
import Insurance from "/src/pages/Insurance.jsx";
import CustomerRewards from "/src/pages/CustomerRewards.jsx";
import PayInOutMenu from "/src/pages/PayInOutMenu.jsx";
import RegistrationFeeReport from "/src/pages/RegistrationFeeReport.jsx";
import CollectionExecutiveReport from "/src/pages/CollectionExecutiveReport.jsx";
import StaffMenu from "/src/pages/StaffMenu.jsx";
import EmployeeAttendance from "/src/pages/EmployeeAttendanceReport.jsx";
import EmployeeMonthlyReport from "/src/pages/EmployeeMonthlyReport.jsx";
import EmployeeMenu from "/src/pages/EmployeeMenu.jsx";
import PaymentMenu from "/src/pages/PaymentMenu.jsx";
import CustomerLoanReport from "/src/pages/CustomerLoanReport.jsx";
import CollectionAreaReport from "/src/pages/CollectionAreaReport.jsx";
import PayoutSalaryReport from "/src/pages/PayoutSalaryReport.jsx";
import TargetMenu from "/src/pages/TargetMenu.jsx";
import EnrollmentMenu from "/src/pages/EnrollmentView.jsx";
import ChitCollectionExecutiveReport from "/src/pages/ChitCollectionExecutiveReport.jsx";
import PenaltySettings from "/src/pages/PenaltySettings.jsx";
import PenaltyMonitor from "/src/pages/PenaltyMonitor.jsx";
import UserMenu from "/src/pages/UserMenu.jsx";
import OtherServicesMenu from "/src/pages/OtherServicesMenu.jsx";
import LegalsMenu from "/src/pages/LegalsMenu.jsx";
import UnApprovedCustomerReport from "/src/pages/UnApprovedCustomerReport.jsx";
import PaymentReport from "/src/pages/PaymentReport.jsx";
import UserEventLogger from "/src/pages/CustomerAppEvents.jsx";
import PigmySummaryReport from "/src/pages/PigmySummaryReport.jsx";
import ChitAskingMonthReport from "/src/pages/ChitAskingMonthReport.jsx";
import SalaryRemainingReport from "/src/pages/SalaryRemainingReport.jsx";
import AdminApprovalMenu from "/src/pages/AdminApprovalsMenu.jsx";
import SuspensePayments from "/src/pages/SuspensePayments.jsx";
import InActiveUserReport from "/src/pages/InActiveUserReport.jsx";
import NonConvertedLead from "/src/pages/NonConvertedLead.jsx";
import ConvertedLead from "/src/pages/ConvertedLead.jsx";
import UserRegistrationSourceSummaryReport from "/src/pages/UserRegistrationSourceSummaryReport.jsx";
import HRMenu from "/src/pages/HRMenu.jsx";
import SalaryPayment from "/src/pages/SalaryPayment.jsx";
import TransferMenu from "/src/pages/TransferMenu.jsx";
import CollectionMenu from "/src/pages/CollectionMenu.jsx";
import SalarySlipPrint from "/src/components/printFormats/SalarySlipPrint.jsx";
import EmployeeSalaryReport from "/src/pages/EmployeeSalaryReport.jsx";
import HRSalaryManagement from "/src/pages/HRSalaryManagement.jsx";
import EmployeeStatement from "/src/pages/EmployeeStatement.jsx";
import SalaryIncentive from "/src/pages/SalaryIncentive.jsx";
import UnapprovedLoans from "/src/pages/UnapprovedLoans.jsx";
import EmployeeDeductionReport from "/src/pages/EmployeeDeductionReport.jsx";
import MarketingMenu from "/src/pages/MarketingMenu.jsx";
import EmailMarketingMenu from "/src/pages/EmailMarketingMenu.jsx";
import PaymentLinkMarketingMenu from "/src/pages/PaymentLinkMarketingMenu.jsx";
import WhatsappMarketingMenu from "/src/pages/WhatsappMarketingMenu.jsx";
import DueWhatsappMessageMenu from "/src/pages/DueWhatsappMessageMenu.jsx";
import LeadWhatsappMessageMenu from "/src/pages/LeadWhatsappMessageMenu.jsx";
import CustomerWhatsappMessageMenu from "/src/pages/CustomerWhatsappMessageMenu.jsx";
import AuctionWhatsappMessageMenu from "/src/pages/AuctionWhatsappMessageMenu.jsx";
import PromotionWhatsappMessageMenu from "/src/pages/PromotionWhatsappMessageMenu.jsx";
import DueEmailMenu from "/src/pages/DueEmailMenu.jsx";
import RCSMarketingMenu from "/src/pages/RCSMarketingMenu.jsx";
import SMSMarketingMenu from "/src/pages/SMSMarketingMenu.jsx";
import CoApplicant from "/src/pages/CoApplicant.jsx";
import CoApplicantPrint from "/src/components/printFormats/CoApplicantPrint.js";
import PaymentWithPenalty from "/src/pages/PaymentWithPenalty.jsx";
import PenaltyWhatsappMessageMenu from "/src/pages/PenaltyWhatsappMessageMenu.jsx";
import CustomerView from "/src/pages/CustomerView.jsx";
import Analytics from "/src/pages/Analytics.jsx";
import TotalRevenue from "/src/pages/TotalRevenue.jsx";
import MonthlyRevenue from "/src/pages/MonthlyRevenue.jsx";
import AdvanceSalary from "/src/pages/AdvanceSalary.jsx";
import PaymentLinkTransactions from "/src/pages/PaymentLinkTransactions.jsx";
import CustomerRewardPoints from "/src/pages/CustomerRewards.jsx";
import RedemptionPointsReport from "/src/pages/RedemptionPointsReport.jsx";
import LoanCompletionReport from "/src/pages/LoanCompletionReport.jsx";
import HelpAndSupport from "/src/pages/HelpAndSupport.jsx";
import ComplaintForm from "/src/pages/ComplaintForm.jsx";
import Supports from "/src/pages/Supports.jsx";
import EmployeeRewardPoints from "/src/pages/EmployeeRewardPoints.jsx";
import RewardSettings from "/src/pages/RewardSettings.jsx";
import RewardMenu from "/src/pages/RewardsMenu.jsx";
import CustomerLoanWhatsappMenu from "/src/pages/CustomerLoanWhatsAppMenu.jsx";
import DueLoanReport from "/src/pages/DueLoanReport.jsx";
import DateWiseRewardreport from "/src/pages/DateWiseRewardreport.jsx";
import DueLoanWhatsappMessage from "/src/pages/DueLoanWhatsappMessage.jsx";
import Visitor from "/src/pages/Visitor.jsx";
import VisitorList from "/src/pages/VisitorList.jsx";
import EmployeeTasks from "/src/components/employee/EmployeeTasks.jsx";
import PrizedCustomerReport from "/src/pages/PrizedCustomerReport.jsx";
import AddGroupForm from "/src/pages/AddGroupForm.jsx";
import AuctionFilterReport from "/src/pages/AuctionFilterReport.jsx";
import Register from "/src/pages/Registration.jsx";
import TransactionHistory from "/src/pages/TransactionHistory.jsx";
import AgentTarget from "/src/pages/AgentTarget.jsx";
import EmployeeTarget from "/src/pages/EmployeeTarget.jsx";
import AgentMenu from "/src/pages/AgentMenu.jsx";
import BidRequest from "/src/pages/BidRequest.jsx";
import CreateBidRequest from "/src/pages/CreateBidRequest.jsx";
import CreateLoanRequest from "/src/pages/CreateLoanRequest.jsx";
import UnverifiedAgent from "/src/pages/UnverifiedAgent.jsx";
import ChitCancellationReport from "/src/pages/ChitCancellationReport.jsx";
import LoanPaymentOut from "/src/pages/LoanPaymentOut.jsx";
import GroupMenu from "/src/pages/GroupMenu.jsx";
import BidRequestReport from "/src/pages/BidRequestReport.jsx";
import LoanPayoutReport from "/src/pages/LoanPayoutReport.jsx";
import RecentAuction from "/src/pages/RecentAuction.jsx";
import PenaltyManagement from "/src/pages/PenaltyManagement.jsx";
import UserAccountsMenu from "/src/pages/UserAccountsMenu.jsx";
import ChitCancelPaymentOut from "/src/pages/ChitCancelPaymentOut.jsx";
import ChitCancelPaymentIn from "/src/pages/ChitCancelPaymentIn.jsx";
import ActivateCustomer from "/src/pages/ActivateCustomer.jsx";
import PigmyPaymentOut from "/src/pages/PigmyPaymentOut.jsx";
import Plans from "/src/pages/Plans.jsx";
import Subscriptions from "/src/pages/Subscriptions.jsx";
import EnquireCall from "/src/pages/EnquireCall.jsx";
import CustomerAppInstallation from "/src/pages/CustomerAppInstallation.jsx";
import UserDocuments from "/src/pages/CustomerDocuments.jsx";
import EmployeeAdvancePaymentIn from "/src/pages/AdvancePaymentIn.jsx";
import EmployeeSalaryIncentive from "/src/pages/EmployeeIncentivePayment.jsx";
import AgentCommission from "/src/pages/AgentCommission.jsx";
import AdditionalSalary from "/src/pages/AdditionalSalary.jsx";
import UnApprovedEmployee from "/src/pages/UnApprovedEmployee.jsx";
import PigmyPayoutReport from "/src/pages/PigmyPayoutReport.jsx";
import PigmyPreclosurePrint from "/src/components/printFormats/PigmyPreclosurePrint.jsx";
import ChitPayoutReport from "/src/pages/ChitPayoutReport.jsx";
import LoanDocumentation from "/src/pages/LoanDocumentation.jsx";
import SuspendedCustomerReport from "/src/pages/SuspendedCustomerReport.jsx";
import EmployeeReferredCustomers from "/src/pages/EmployeeReferredCustomers.jsx";
import EmployeeCollectionCustomerReport from "/src/pages/EmployeeCollectionCustomerReport.jsx";
import ChitUpgrade from "/src/pages/ChitUpgrade.jsx";
import GSTServiceChargeReport from "/src/pages/GSTServiceChargeReport.jsx";
import CustomerAllocation from "/src/pages/CustomerAllocation.jsx";
import Branches from "/src/pages/Branches.jsx";
import CustomerArea from "/src/pages/CustomerArea.jsx";
import CustomerVisitTrackerReport from "/src/pages/CustomerVisitTrackerReport.jsx";
import PincodeReport from "/src/pages/PincodeReport.jsx";
import UnlinkEnrollment from "/src/pages/UnlinkEnrollment.jsx";
import CustomerTrackingReport from "/src/pages/CustomerTrackingReport.jsx";
import CustomerAreaReport from "/src/pages/CustomerAreaReport.jsx";
import EmployeeRelationshipManagerReport from "/src/pages/EmployeeRelationshipManagerReport.jsx";
import LinkedGuarantor from "/src/pages/LinkedGuarantor.jsx";
const mainRoutes = createBrowserRouter([
  {
    path: "/",
    element: /* @__PURE__ */ jsxDEV(Login, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 257,
      columnNumber: 12
    }, this)
  },
  //     {
  //   path:"/register",
  //   element: <Register />
  // },
  {
    path: "/dashboard",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Home, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 267,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 266,
      columnNumber: 3
    }, this)
  },
  {
    path: "/quick-search",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: [
      /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 275,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(QuickSearch, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 276,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 274,
      columnNumber: 3
    }, this)
  },
  {
    path: "/activate-customer",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(ActivateCustomer, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 284,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 283,
      columnNumber: 3
    }, this)
  },
  {
    path: "/help",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(HelpAndSupport, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 293,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 292,
      columnNumber: 3
    }, this)
  },
  {
    path: "/customer-area",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(CustomerArea, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 301,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 300,
      columnNumber: 3
    }, this)
  },
  {
    path: "/help&support",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(HelpAndSupport, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 309,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 308,
      columnNumber: 3
    }, this)
  },
  {
    path: "/help-support",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(ComplaintForm, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 317,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 316,
      columnNumber: 3
    }, this)
  },
  {
    path: "/bid-request",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(BidRequest, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 325,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 324,
      columnNumber: 3
    }, this)
  },
  {
    path: "/enquire-call",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(EnquireCall, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 333,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 332,
      columnNumber: 3
    }, this)
  },
  {
    path: "/bid-request/create",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(CreateBidRequest, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 341,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 340,
      columnNumber: 3
    }, this)
  },
  // {
  //   path: "/loan-request",
  //   element: (
  //     <ProtectedRoute>
  //       <LoanRequest/>
  //     </ProtectedRoute>
  //   ),
  // },
  {
    path: "/loan-request/create",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(CreateLoanRequest, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 358,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 357,
      columnNumber: 3
    }, this)
  },
  {
    path: "/my-tasks",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(EmployeeTasks, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 367,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 366,
      columnNumber: 3
    }, this)
  },
  {
    path: "/analytics",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Analytics, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 376,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 375,
      columnNumber: 3
    }, this)
  },
  // {
  //   path: "/analytics",
  //   element: (
  //     <ProtectedRoute>
  //       <Navbar />
  //     </ProtectedRoute>
  //   ),
  // },
  {
    path: "/reg-fee-print/:id",
    element: /* @__PURE__ */ jsxDEV(RegistrationReceipt, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 391,
      columnNumber: 12
    }, this)
  },
  {
    path: "/group-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(GroupMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 398,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 397,
      columnNumber: 3
    }, this)
  },
  {
    path: "/group-menu/group",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Group, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 407,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 406,
      columnNumber: 3
    }, this)
  },
  {
    path: "/group-menu/filter-groups",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Group, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 415,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 414,
      columnNumber: 3
    }, this)
  },
  {
    path: "/supports",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Supports, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 423,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 422,
      columnNumber: 3
    }, this)
  },
  {
    path: "/unlink-link-customer",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(UnlinkEnrollment, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 431,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 430,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/agent-menu/unverified-agent",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(UnverifiedAgent, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 439,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 438,
      columnNumber: 3
    }, this)
  },
  {
    path: "/reward-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(RewardMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 447,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 446,
      columnNumber: 3
    }, this)
  },
  {
    path: "/reward-menu/employee-reward-points",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: [
      " ",
      /* @__PURE__ */ jsxDEV(EmployeeRewardPoints, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 456,
        columnNumber: 9
      }, this),
      " "
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 454,
      columnNumber: 3
    }, this)
  },
  {
    path: "/reward-menu/customer-reward-points",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: [
      " ",
      /* @__PURE__ */ jsxDEV(CustomerRewardPoints, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 465,
        columnNumber: 9
      }, this),
      " "
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 463,
      columnNumber: 3
    }, this)
  },
  {
    path: "/employee-reward-points",
    element: /* @__PURE__ */ jsxDEV(EmployeeRewardPoints, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 472,
      columnNumber: 12
    }, this)
  },
  {
    path: "/reward-settings",
    element: /* @__PURE__ */ jsxDEV(RewardSettings, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 476,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/loan-whatsapp-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(CustomerLoanWhatsappMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 483,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 482,
      columnNumber: 3
    }, this)
  },
  { path: "customer-view", element: /* @__PURE__ */ jsxDEV(CustomerView, {}, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
    lineNumber: 488,
    columnNumber: 35
  }, this) },
  { path: "/total-revenue", element: /* @__PURE__ */ jsxDEV(TotalRevenue, {}, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
    lineNumber: 489,
    columnNumber: 36
  }, this) },
  { path: "/monthly-revenue", element: /* @__PURE__ */ jsxDEV(MonthlyRevenue, {}, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
    lineNumber: 490,
    columnNumber: 38
  }, this) },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PayInMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 496,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 495,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PayInOutMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 504,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 503,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/payment",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Payment, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 512,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 511,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/penalty-payment",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PaymentWithPenalty, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 520,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 519,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/suspense-payments",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(SuspensePayments, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 528,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 527,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/advance-payment-in",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(EmployeeAdvancePaymentIn, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 536,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 535,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/registration-fee",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(RegistrationFee, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 544,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 543,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-link-transactions",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PaymentLinkTransactions, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 553,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 552,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/payment-link-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PaymentLinkMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 562,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 561,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/chit-transfer-pay-in",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(ChitCancelPaymentOut, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 572,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 570,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/chit-cancelation-pay-out",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(ChitCancelPaymentOut, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 580,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 579,
      columnNumber: 3
    }, this)
  },
  //     {
  //   path: "/co-applicant-print/:id",
  //   element: <CoApplicantPrint />,
  // },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/payment-link-menu/chit-payment",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(IndividualChitPaymentLink, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 593,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 592,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/payment-link-menu/registration-chit-payment",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(IndividualRegistrationChitPaymentLink, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 601,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 600,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-in-menu/payment-link-menu/chit-bulk-payment",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(ChitBulkPaymentLink, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 609,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 608,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/advance-payment",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AdvanceSalary, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 618,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 617,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/payment-out/agent-commission",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AgentCommission, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 627,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 626,
      columnNumber: 3
    }, this)
  },
  {
    path: "/print-payment-out/:id",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PrintPaymentOut, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 636,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 635,
      columnNumber: 3
    }, this)
  },
  {
    path: "/pigmy-preclosure-print/:id",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PigmyPreclosurePrint, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 644,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 643,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/employee-salary-incentive",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(EmployeeSalaryIncentive, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 652,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 651,
      columnNumber: 3
    }, this)
  },
  {
    // path: "/salary-incentive",
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-incentive",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(SalaryIncentive, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 661,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 660,
      columnNumber: 3
    }, this)
  },
  {
    path: "/enroll-menu/mobile-app-enroll",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(MobileAppEnroll, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 670,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 669,
      columnNumber: 3
    }, this)
  },
  {
    path: "/legals-menu/co-applicant",
    element: /* @__PURE__ */ jsxDEV(CoApplicant, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 676,
      columnNumber: 12
    }, this)
  },
  {
    path: "/legals-menu/Recent-Auction",
    element: /* @__PURE__ */ jsxDEV(RecentAuction, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 680,
      columnNumber: 12
    }, this)
  },
  {
    path: "/legals-menu/Recent-Loans",
    element: /* @__PURE__ */ jsxDEV(LoanDocumentation, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 684,
      columnNumber: 12
    }, this)
  },
  {
    path: "/legals-menu/user-document",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(UserDocuments, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 690,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 689,
      columnNumber: 3
    }, this)
  },
  {
    path: "/approval-menu/mobile-app-enroll",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(MobileAppEnroll, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 700,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 699,
      columnNumber: 3
    }, this)
  },
  {
    path: "/user",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(User, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 709,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 708,
      columnNumber: 3
    }, this)
  },
  {
    path: "/visitorsection",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Visitor, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 718,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 717,
      columnNumber: 3
    }, this)
  },
  {
    path: "/visitor-list",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(VisitorList, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 726,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 725,
      columnNumber: 3
    }, this)
  },
  {
    path: "/customer-menu/un-approved-customer",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(UnApprovedCustomer, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 735,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 734,
      columnNumber: 3
    }, this)
  },
  {
    path: "/approval-menu/un-approved-customer",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(UnApprovedCustomer, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 743,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 742,
      columnNumber: 3
    }, this)
  },
  {
    path: "/approval-menu/un-approved-loans",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(UnapprovedLoans, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 752,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 751,
      columnNumber: 3
    }, this)
  },
  {
    path: "/task",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Task, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 760,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 759,
      columnNumber: 3
    }, this)
  },
  {
    path: "/chit-upgrade",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(ChitUpgrade, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 768,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 767,
      columnNumber: 3
    }, this)
  },
  {
    path: "/target-menu/target",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Target, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 777,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 776,
      columnNumber: 3
    }, this)
  },
  {
    path: "/enrollment-request-form",
    element: /* @__PURE__ */ jsxDEV(EnrollmentRequestForm, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 783,
      columnNumber: 12
    }, this)
  },
  {
    path: "/legals-menu/guarantor",
    element: /* @__PURE__ */ jsxDEV(Guarantor, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 787,
      columnNumber: 12
    }, this)
  },
  {
    path: "/legals-menu/linked-guarantor",
    element: /* @__PURE__ */ jsxDEV(LinkedGuarantor, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 791,
      columnNumber: 12
    }, this)
  },
  {
    path: "/legals-menu",
    element: /* @__PURE__ */ jsxDEV(LegalsMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 795,
      columnNumber: 12
    }, this)
  },
  // {
  //   path: "/group-menu/filter-groups",
  //   element: (
  //     <ProtectedRoute>
  //       <FilterGroups />
  //     </ProtectedRoute>
  //   ),
  // },
  {
    path: "/approval-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AdminApprovalMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 809,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 808,
      columnNumber: 3
    }, this)
  },
  {
    path: "/hr-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(HRMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 817,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 816,
      columnNumber: 3
    }, this)
  },
  {
    path: "/branches",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Branches, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 825,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 824,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/employee-menu/payroll",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Payroll, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 833,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 832,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/employee-menu/unapproved-employee",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(UnApprovedEmployee, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 841,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 840,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/employee-menu/salary-management",
    element: (
      // <ProtectedRoute>
      //   <HRSalaryManagement />
      // </ProtectedRoute>
      /* @__PURE__ */ jsxDEV(SuperAdminRoute, { children: /* @__PURE__ */ jsxDEV(HRSalaryManagement, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 852,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 851,
        columnNumber: 3
      }, this)
    )
  },
  {
    path: "/customer-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(UserMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 860,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 859,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(StaffMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 868,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 867,
      columnNumber: 3
    }, this)
  },
  {
    path: "/penalty-management",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PenaltyManagement, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 877,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 876,
      columnNumber: 3
    }, this)
  },
  {
    path: "/other-transactions",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(UserAccountsMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 885,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 884,
      columnNumber: 3
    }, this)
  },
  {
    path: "/target-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(TargetMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 894,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 893,
      columnNumber: 3
    }, this)
  },
  {
    path: "/enroll-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(EnrollmentMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 902,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 901,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/employee-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(EmployeeMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 910,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 909,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/employee-menu/employee",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Employee, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 918,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 917,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/employee-menu/add-employee-attendance",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(EmployeeAttendance, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 926,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 925,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/employee-menu/employee-statement",
    element: /* @__PURE__ */ jsxDEV(SuperAdminRoute, { children: /* @__PURE__ */ jsxDEV(EmployeeStatement, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 934,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 933,
      columnNumber: 3
    }, this)
  },
  {
    path: "/week-group",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(WeekGroup, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 942,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 941,
      columnNumber: 3
    }, this)
  },
  {
    path: "/customer-menu/user",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(User, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 950,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 949,
      columnNumber: 3
    }, this)
  },
  {
    path: "/enroll-menu/enrollment",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Enroll, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 958,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 957,
      columnNumber: 3
    }, this)
  },
  {
    path: "/other-service-menu/",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(OtherServicesMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 966,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 965,
      columnNumber: 3
    }, this)
  },
  {
    path: "/other-service-menu/loan",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Loan, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 974,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 973,
      columnNumber: 3
    }, this)
  },
  {
    path: "/other-service-menu/pigme",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Pigme, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 982,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 981,
      columnNumber: 3
    }, this)
  },
  {
    path: "/auction",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Auction, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 990,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 989,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PaymentMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 998,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 997,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Payment, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1006,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1005,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PayOutMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1014,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1013,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/loan-payout",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(LoanPaymentOut, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1022,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1021,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/pigmy-payout",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PigmyPaymentOut, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1030,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1029,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/:paymentType",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(GeneralPaymentOut, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1038,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1037,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/commission",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PayOutCommission, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1046,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1045,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
    element: /* @__PURE__ */ jsxDEV(SuperAdminRoute, { children: /* @__PURE__ */ jsxDEV(SalaryPayment, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1054,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1053,
      columnNumber: 3
    }, this)
  },
  // subscriptions page routs can be added here
  {
    path: "/plans",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Plans, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1064,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1063,
      columnNumber: 3
    }, this)
  },
  {
    path: "/subscriptions",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Subscriptions, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1072,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1071,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/petty-Cash",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PayOutPettyCash, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1081,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1080,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/additional-salary",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AdditionalSalary, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1089,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1088,
      columnNumber: 3
    }, this)
  },
  {
    path: "/payment-menu/payment-in-out-menu/pay-out-menu/others",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PayOutOthers, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1097,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1096,
      columnNumber: 3
    }, this)
  },
  {
    path: "/collection-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(CollectionMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1105,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1104,
      columnNumber: 3
    }, this)
  },
  {
    path: "/collection-menu/collection-area-request",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(CollectionArea, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1113,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1112,
      columnNumber: 3
    }, this)
  },
  {
    path: "/collection-menu/customer-allocation",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(CustomerAllocation, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1121,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1120,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/agent-menu/agent",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Agent, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1129,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1128,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/agent-menu/agent-target",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AgentTarget, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1138,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1137,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/employee-menu/employee-target",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(EmployeeTarget, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1147,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1146,
      columnNumber: 3
    }, this)
  },
  {
    path: "/staff-menu/agent-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AgentMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1156,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1155,
      columnNumber: 3
    }, this)
  },
  {
    path: "/lead",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: [
      /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1165,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Lead, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1166,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1164,
      columnNumber: 3
    }, this)
  },
  {
    path: "/lead-setting",
    element: /* @__PURE__ */ jsxDEV(LeadSetting, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1173,
      columnNumber: 12
    }, this),
    children: [
      {
        index: true,
        element: /* @__PURE__ */ jsxDEV(LeadSettings, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1177,
          columnNumber: 14
        }, this)
      },
      {
        path: "app-settings",
        element: /* @__PURE__ */ jsxDEV(AppSettings, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1181,
          columnNumber: 14
        }, this),
        children: [
          {
            path: "groups/mobile-access",
            element: /* @__PURE__ */ jsxDEV(GroupSettings, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
              lineNumber: 1185,
              columnNumber: 16
            }, this)
          },
          {
            path: "groups/asset",
            element: /* @__PURE__ */ jsxDEV(DreamAsset, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
              lineNumber: 1189,
              columnNumber: 16
            }, this)
          },
          {
            path: "groups/become-agent",
            element: /* @__PURE__ */ jsxDEV(BecomeAgent, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
              lineNumber: 1193,
              columnNumber: 16
            }, this)
          }
        ]
      }
    ]
  },
  {
    path: "/designation",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Designation, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1204,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1203,
      columnNumber: 3
    }, this)
  },
  {
    path: "/transfer-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(TransferMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1213,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1212,
      columnNumber: 3
    }, this)
  },
  {
    path: "/transfer-menu/soft-transfer",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(SoftTransferCustomer, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1221,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1220,
      columnNumber: 3
    }, this)
  },
  ,
  {
    path: "/transfer-menu/hard-transfer",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(HardTransferCustomer, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1230,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1229,
      columnNumber: 3
    }, this)
  },
  {
    path: "/administrative-privileges",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: [
      /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1238,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(AdministrativePrivileges, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1239,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1237,
      columnNumber: 3
    }, this)
  },
  {
    path: "/admin-access-rights",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: [
      /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1247,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(AdminAccessRights, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1248,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1246,
      columnNumber: 3
    }, this)
  },
  // {
  //   path: "/marketing",
  //   element: (
  //     <ProtectedRoute>
  //       <Navbar />
  //       <Marketing />
  //     </ProtectedRoute>
  //   ),
  // },
  {
    path: "/profile",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: [
      /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1265,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Profile, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1266,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1264,
      columnNumber: 3
    }, this)
  },
  {
    path: "/penalty-settings",
    element: /* @__PURE__ */ jsxDEV(PenaltySettings, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1273,
      columnNumber: 12
    }, this)
  },
  {
    path: "/penalty-monitor",
    element: /* @__PURE__ */ jsxDEV(PenaltyMonitor, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1278,
      columnNumber: 12
    }, this)
  },
  {
    path: "/gift-received",
    element: /* @__PURE__ */ jsxDEV(CustomerRewards, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1283,
      columnNumber: 12
    }, this)
  },
  {
    path: "/reports",
    element: /* @__PURE__ */ jsxDEV(Reports, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1288,
      columnNumber: 12
    }, this),
    children: [
      { path: "daybook", element: /* @__PURE__ */ jsxDEV(Daybook, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1292,
        columnNumber: 31
      }, this) },
      { path: "payout", element: /* @__PURE__ */ jsxDEV(PayOutReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1293,
        columnNumber: 30
      }, this) },
      { path: "sales-report", element: /* @__PURE__ */ jsxDEV(SalesReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1294,
        columnNumber: 36
      }, this) },
      { path: "pigmy-summary-report", element: /* @__PURE__ */ jsxDEV(PigmySummaryReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1295,
        columnNumber: 44
      }, this) },
      // { path: "receipt", element: <Receipt /> },
      { path: "receipt-report", element: /* @__PURE__ */ jsxDEV(PaymentReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1297,
        columnNumber: 38
      }, this) },
      { path: "customer-event-logger-report", element: /* @__PURE__ */ jsxDEV(UserEventLogger, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1298,
        columnNumber: 52
      }, this) },
      { path: "collection-executive", element: /* @__PURE__ */ jsxDEV(CollectionExecutiveReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1299,
        columnNumber: 44
      }, this) },
      { path: "collection-area-report", element: /* @__PURE__ */ jsxDEV(CollectionAreaReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1300,
        columnNumber: 46
      }, this) },
      { path: "registration-fee-receipt", element: /* @__PURE__ */ jsxDEV(RegistrationFeeReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1301,
        columnNumber: 48
      }, this) },
      { path: "group-report", element: /* @__PURE__ */ jsxDEV(GroupReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1302,
        columnNumber: 36
      }, this) },
      { path: "all-group-report", element: /* @__PURE__ */ jsxDEV(AllGroupReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1303,
        columnNumber: 40
      }, this) },
      { path: "auction-report", element: /* @__PURE__ */ jsxDEV(AuctionReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1304,
        columnNumber: 38
      }, this) },
      { path: "auction-report", element: /* @__PURE__ */ jsxDEV(AuctionReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1305,
        columnNumber: 38
      }, this) },
      { path: "lead-report", element: /* @__PURE__ */ jsxDEV(LeadReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1306,
        columnNumber: 35
      }, this) },
      { path: "loan-payout-report", element: /* @__PURE__ */ jsxDEV(LoanPayoutReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1307,
        columnNumber: 42
      }, this) },
      { path: "payout-report", element: /* @__PURE__ */ jsxDEV(ChitPayoutReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1308,
        columnNumber: 37
      }, this) },
      { path: "customer-report", element: /* @__PURE__ */ jsxDEV(UserReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1309,
        columnNumber: 39
      }, this) },
      { path: "inactive-user-report", element: /* @__PURE__ */ jsxDEV(InActiveUserReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1310,
        columnNumber: 44
      }, this) },
      { path: "all-user-report", element: /* @__PURE__ */ jsxDEV(AllUserReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1311,
        columnNumber: 39
      }, this) },
      { path: "loan-report", element: /* @__PURE__ */ jsxDEV(LoanReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1312,
        columnNumber: 35
      }, this) },
      { path: "pigme-report", element: /* @__PURE__ */ jsxDEV(PigmeReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1313,
        columnNumber: 36
      }, this) },
      { path: "employee-report", element: /* @__PURE__ */ jsxDEV(EmployeeReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1314,
        columnNumber: 39
      }, this) },
      { path: "commission-report", element: /* @__PURE__ */ jsxDEV(CommissionReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1315,
        columnNumber: 41
      }, this) },
      { path: "enrollment-report", element: /* @__PURE__ */ jsxDEV(EnrollmentReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1316,
        columnNumber: 41
      }, this) },
      { path: "pincode-report", element: /* @__PURE__ */ jsxDEV(PincodeReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1317,
        columnNumber: 38
      }, this) },
      { path: "payment-summary", element: /* @__PURE__ */ jsxDEV(PaymentSummary, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1318,
        columnNumber: 39
      }, this) },
      { path: "holded-customer-report", element: /* @__PURE__ */ jsxDEV(HoldedCustomerReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1319,
        columnNumber: 46
      }, this) },
      {
        path: "transaction-history",
        element: /* @__PURE__ */ jsxDEV(TransactionHistory, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1322,
          columnNumber: 14
        }, this)
      },
      {
        path: "collection-executive-summary",
        element: /* @__PURE__ */ jsxDEV(ChitCollectionExecutiveReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1325,
          columnNumber: 52
        }, this)
      },
      {
        path: "monthly-install-turnover",
        element: /* @__PURE__ */ jsxDEV(MonthlyInstallmentTurnoverReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1329,
          columnNumber: 14
        }, this)
      },
      { path: "employee-monthly-report", element: /* @__PURE__ */ jsxDEV(EmployeeMonthlyReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1331,
        columnNumber: 47
      }, this) },
      { path: "customer-loan-report", element: /* @__PURE__ */ jsxDEV(CustomerLoanReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1332,
        columnNumber: 44
      }, this) },
      {
        path: "unverified-customer-report",
        element: /* @__PURE__ */ jsxDEV(UnApprovedCustomerReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1335,
          columnNumber: 14
        }, this)
      },
      { path: "payment-report", element: /* @__PURE__ */ jsxDEV(PaymentReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1337,
        columnNumber: 38
      }, this) },
      { path: "prized-customer-report", element: /* @__PURE__ */ jsxDEV(PrizedCustomerReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1338,
        columnNumber: 46
      }, this) },
      { path: "chit-cancellation-report", element: /* @__PURE__ */ jsxDEV(ChitCancellationReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1339,
        columnNumber: 48
      }, this) },
      {
        path: "outstanding-report",
        element: /* @__PURE__ */ jsxDEV(OutstandingReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1342,
          columnNumber: 14
        }, this)
      },
      { path: "chit-asking-month-report", element: /* @__PURE__ */ jsxDEV(ChitAskingMonthReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1344,
        columnNumber: 48
      }, this) },
      { path: "payout-salary-report", element: /* @__PURE__ */ jsxDEV(PayoutSalaryReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1345,
        columnNumber: 44
      }, this) },
      { path: "customer-area-report", element: /* @__PURE__ */ jsxDEV(CustomerAreaReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1346,
        columnNumber: 44
      }, this) },
      {
        path: "target-incentive",
        element: /* @__PURE__ */ jsxDEV(TargetIncentiveReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1349,
          columnNumber: 14
        }, this)
      },
      {
        path: "target-commission",
        element: /* @__PURE__ */ jsxDEV(TargetCommission, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1353,
          columnNumber: 14
        }, this)
      },
      { path: "salary-remaining", element: /* @__PURE__ */ jsxDEV(SalaryRemainingReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1355,
        columnNumber: 40
      }, this) },
      { path: "non-converted-lead-report", element: /* @__PURE__ */ jsxDEV(NonConvertedLead, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1356,
        columnNumber: 49
      }, this) },
      { path: "converted-lead-report", element: /* @__PURE__ */ jsxDEV(ConvertedLead, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1357,
        columnNumber: 45
      }, this) },
      { path: "employee-salary-report", element: /* @__PURE__ */ jsxDEV(EmployeeSalaryReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1358,
        columnNumber: 46
      }, this) },
      {
        path: "user-registration-source-summary-report",
        element: /* @__PURE__ */ jsxDEV(UserRegistrationSourceSummaryReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1361,
          columnNumber: 14
        }, this)
      },
      {
        path: "chitcollection-incentive",
        element: /* @__PURE__ */ jsxDEV(ChitCollectionIncentiveReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1365,
          columnNumber: 14
        }, this)
      },
      {
        path: "loancollection-incentive",
        element: /* @__PURE__ */ jsxDEV(LoanCollectionIncentiveReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1369,
          columnNumber: 14
        }, this)
      },
      {
        path: "customer-payment-tracking-report",
        element: /* @__PURE__ */ jsxDEV(CustomerTrackingReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1372,
          columnNumber: 56
        }, this)
      },
      {
        path: "pigmycollection-incentive",
        element: /* @__PURE__ */ jsxDEV(PigmyCollectionIncentiveReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1376,
          columnNumber: 14
        }, this)
      },
      {
        path: "employee-deduction-report",
        element: /* @__PURE__ */ jsxDEV(EmployeeDeductionReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1380,
          columnNumber: 14
        }, this)
      },
      { path: "redemtion-points", element: /* @__PURE__ */ jsxDEV(RedemptionPointsReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1382,
        columnNumber: 40
      }, this) },
      { path: "loan-completion-report", element: /* @__PURE__ */ jsxDEV(LoanCompletionReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1383,
        columnNumber: 46
      }, this) },
      { path: "loan-due-report", element: /* @__PURE__ */ jsxDEV(DueLoanReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1384,
        columnNumber: 39
      }, this) },
      { path: "date-wise-reward-points", element: /* @__PURE__ */ jsxDEV(DateWiseRewardreport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1385,
        columnNumber: 47
      }, this) },
      { path: "auction-filter-report", element: /* @__PURE__ */ jsxDEV(AuctionFilterReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1386,
        columnNumber: 45
      }, this) },
      { path: "bid-request-report", element: /* @__PURE__ */ jsxDEV(BidRequestReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1387,
        columnNumber: 42
      }, this) },
      { path: "mobile-app-installs", element: /* @__PURE__ */ jsxDEV(CustomerAppInstallation, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1388,
        columnNumber: 43
      }, this) },
      {
        path: "target-incentive-new",
        element: /* @__PURE__ */ jsxDEV(TargetIncentiveNewReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1391,
          columnNumber: 14
        }, this)
      },
      { path: "pigmy-payout-report", element: /* @__PURE__ */ jsxDEV(PigmyPayoutReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1393,
        columnNumber: 43
      }, this) },
      {
        path: "suspend-report",
        element: /* @__PURE__ */ jsxDEV(SuspendedCustomerReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1396,
          columnNumber: 14
        }, this)
      },
      {
        path: "employee-customer-referral-report",
        element: /* @__PURE__ */ jsxDEV(EmployeeReferredCustomers, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1400,
          columnNumber: 14
        }, this)
      },
      {
        path: "employee-collection-customer-report",
        element: /* @__PURE__ */ jsxDEV(EmployeeCollectionCustomerReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1404,
          columnNumber: 14
        }, this)
      },
      {
        path: "employee-relationship-manager-report",
        element: /* @__PURE__ */ jsxDEV(EmployeeRelationshipManagerReport, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
          lineNumber: 1408,
          columnNumber: 14
        }, this)
      },
      { path: "gst-service-charge", element: /* @__PURE__ */ jsxDEV(GSTServiceChargeReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1410,
        columnNumber: 42
      }, this) },
      { path: "customer-visit-tracker", element: /* @__PURE__ */ jsxDEV(CustomerVisitTrackerReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
        lineNumber: 1411,
        columnNumber: 46
      }, this) }
    ]
  },
  {
    path: "/target-commission-incentive",
    element: /* @__PURE__ */ jsxDEV(TargetPayOutCommissionIncentive, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1417,
      columnNumber: 12
    }, this)
  },
  // {
  //   path: "/target-payout-menu",
  //   element: <TargetPayOutMenu />,
  // },
  {
    path: "/target-payout-salary",
    element: /* @__PURE__ */ jsxDEV(TargetPayOutSalary, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1425,
      columnNumber: 12
    }, this)
  },
  {
    path: "/insurance",
    element: /* @__PURE__ */ jsxDEV(Insurance, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1430,
      columnNumber: 12
    }, this)
  },
  {
    path: "/print/:id",
    element: /* @__PURE__ */ jsxDEV(Print, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1436,
      columnNumber: 12
    }, this)
  },
  {
    path: "/salary-slip-print/:id",
    element: /* @__PURE__ */ jsxDEV(SalarySlipPrint, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1441,
      columnNumber: 12
    }, this)
  },
  {
    path: "/marketing-menu",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(MarketingMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1447,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1446,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/email-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(EmailMarketingMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1455,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1454,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/payment-link-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PaymentLinkMarketingMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1463,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1462,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(WhatsappMarketingMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1471,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1470,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/due-whatsapp-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(DueWhatsappMessageMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1479,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1478,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/lead-whatsapp-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(LeadWhatsappMessageMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1487,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1486,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/customer-whatsapp-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(CustomerWhatsappMessageMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1495,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1494,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AuctionWhatsappMessageMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1504,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1503,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/promo-whatsapp-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PromotionWhatsappMessageMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1512,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1511,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/penalty-whatsapp-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(PenaltyWhatsappMessageMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1520,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1519,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/email-marketing/due-email-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(DueEmailMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1528,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1527,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/sms-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(SMSMarketingMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1536,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1535,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/rcs-marketing",
    element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(RCSMarketingMenu, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1544,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1543,
      columnNumber: 3
    }, this)
  },
  {
    path: "/market-menu/email-marketing/due-email-marketing/due-email",
    element: /* @__PURE__ */ jsxDEV(DueEmail, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1551,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/email-marketing/due-email-marketing/over-due-email",
    element: /* @__PURE__ */ jsxDEV(OverDueEmail, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1555,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/what-add",
    element: /* @__PURE__ */ jsxDEV(WhatsappAdd, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1559,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/failed-whatuser",
    element: /* @__PURE__ */ jsxDEV(WhatsappFailed, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1563,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/due-whatsapp-marketing/due-message",
    element: /* @__PURE__ */ jsxDEV(DueMessage, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1567,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/auction-intimation-message",
    element: /* @__PURE__ */ jsxDEV(AuctionIntemationMessage, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1571,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/due-whatsapp-marketing/over-due-message",
    element: /* @__PURE__ */ jsxDEV(OverDueMessage, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1575,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/promo-whatsapp-marketing/what-promo",
    element: /* @__PURE__ */ jsxDEV(WhatsappPromo, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1579,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/bid-winner",
    element: /* @__PURE__ */ jsxDEV(BidWinner, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1583,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/payment-link-marketing/payment-link",
    element: /* @__PURE__ */ jsxDEV(PaymentLink, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1587,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/bid-status",
    element: /* @__PURE__ */ jsxDEV(AuctionBidStatus, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1591,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/auction-info",
    element: /* @__PURE__ */ jsxDEV(AuctionInformation, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1595,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/winner-document",
    element: /* @__PURE__ */ jsxDEV(AuctionWinnerDocuments, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1599,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/auction-terms-condition",
    element: /* @__PURE__ */ jsxDEV(AuctionTermsandCondition, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1603,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/lead-whatsapp-marketing/lead-welcome-message",
    element: /* @__PURE__ */ jsxDEV(LeadWhatsappWelcomeMessage, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1607,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/lead-whatsapp-marketing/lead-referredby-message",
    element: /* @__PURE__ */ jsxDEV(LeadReferredByWhatsappMessage, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1611,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/customer-whatsapp-marketing/customer-welcome-message",
    element: /* @__PURE__ */ jsxDEV(CustomerWelcomeWhatsappMessage, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1615,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/customer-whatsapp-marketing/customer-chitplan-message",
    element: /* @__PURE__ */ jsxDEV(CustomerChitPlanWhatsappMessage, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1619,
      columnNumber: 12
    }, this)
  },
  {
    path: "/market-menu/whatsapp-marketing/loan-whatsapp-marketing/due-loan-message",
    element: /* @__PURE__ */ jsxDEV(DueLoanWhatsappMessage, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
      lineNumber: 1623,
      columnNumber: 12
    }, this)
  },
  { path: "/add-new-group", element: /* @__PURE__ */ jsxDEV(AddGroupForm, {}, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/routes/mainRoutes.jsx",
    lineNumber: 1625,
    columnNumber: 36
  }, this) }
  // {
  //   path: "/marketing",
  //   element: (
  //     <ProtectedRoute>
  //       <Navbar />
  //       <Marketing />
  //     </ProtectedRoute>
  //   ),
  //   children: [
  //     { path: "what-add", element: <WhatsappAdd /> },
  //     { path: "failed-whatuser", element: <WhatsappFailed /> },
  //     { path: "due-message", element: <DueMessage /> },
  //     {
  //       path: "auction-intimation-message",
  //       element: <AuctionIntemationMessage />,
  //     },
  //     { path: "over-due-message", element: <OverDueMessage /> },
  //     // { path: "due-email", element: <DueEmail /> },
  //     // { path: "over-due-email", element: <OverDueEmail /> },
  //     { path: "what-promo", element: <WhatsappPromo /> },
  //     { path: "bid-winner", element: <BidWinner /> },
  //     { path: "payment-link", element: <PaymentLink /> },
  //      {path: "bid-status", element: <AuctionBidStatus/>},
  //     {path: "auction-info", element: <AuctionInformation/>},
  //     {path: "winner-document", element: <AuctionWinnerDocuments/>},
  //     {path: "auction-terms-condition", element: <AuctionTermsandCondition/>},
  //     {path: "lead-welcome-message", element: <LeadWhatsappWelcomeMessage/>},
  //     {path: "lead-referredby-message", element: <LeadReferredByWhatsappMessage/>},
  //     {path: "customer-welcome-message", element: <CustomerWelcomeWhatsappMessage/>},
  //     {path: "customer-chitplan-message", element: <CustomerChitPlanWhatsappMessage/>},
  //   ],
  // },
]);
export default mainRoutes;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1FhO0FBaFFiLFNBQVNBLDJCQUEyQjtBQUNwQyxPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLDhCQUE4QjtBQUNyQyxPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0MseUJBQXlCO0FBQ2hDLE9BQU9DLDhCQUE4QjtBQUNyQyxPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQywwQkFBMEI7QUFDakMsT0FBT0MsMEJBQTBCO0FBQ2pDLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyx5QkFBeUI7QUFDaEMsT0FBT0MsK0JBQStCO0FBQ3RDLE9BQU9DLDhCQUE4QjtBQUNyQyxPQUFPQyxtQ0FBbUM7QUFDMUMsT0FBT0MsbUNBQW1DO0FBQzFDLE9BQU9DLG9DQUFvQztBQUUzQyxPQUFPQywyQ0FBMkM7QUFDbEQsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQyxxQ0FBcUM7QUFDNUMsT0FBT0Msc0JBQXNCO0FBRTdCLE9BQU9DLHNDQUFzQztBQUM3QyxPQUFPQywwQkFBMEI7QUFDakMsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLDRCQUE0QjtBQUNuQyxPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsOEJBQThCO0FBQ3JDLE9BQU9DLGdDQUFnQztBQUN2QyxPQUFPQyxtQ0FBbUM7QUFDMUMsT0FBT0Msb0NBQW9DO0FBQzNDLE9BQU9DLHFDQUFxQztBQUM1QyxPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLCtCQUErQjtBQUN0QyxPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQywyQkFBMkI7QUFDbEMsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsMEJBQTBCO0FBQ2pDLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLG1DQUFtQztBQUUxQyxPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyw4QkFBOEI7QUFDckMsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyx3QkFBd0I7QUFFL0IsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLDJCQUEyQjtBQUNsQyxPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLHlDQUF5QztBQUNoRCxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQywwQkFBMEI7QUFDakMsT0FBT0Msd0JBQXdCO0FBQy9CLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLDZCQUE2QjtBQUNwQyxPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0Msd0JBQXdCO0FBQy9CLE9BQU9DLDhCQUE4QjtBQUNyQyxPQUFPQywyQkFBMkI7QUFDbEMsT0FBT0MsNEJBQTRCO0FBQ25DLE9BQU9DLDZCQUE2QjtBQUNwQyxPQUFPQyxpQ0FBaUM7QUFDeEMsT0FBT0MsZ0NBQWdDO0FBQ3ZDLE9BQU9DLGtDQUFrQztBQUN6QyxPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQyxnQ0FBZ0M7QUFFdkMsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGVBQWU7QUFFdEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUUzQixPQUFPQyxtQkFBbUI7QUFFMUIsT0FBT0MsNkJBQTZCO0FBRXBDLE9BQU9DLDBCQUEwQjtBQUNqQyxPQUFPQyw0QkFBNEI7QUFDbkMsT0FBT0MsMEJBQTBCO0FBQ2pDLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0MsY0FBYztBQUNyQixPQUFPQywwQkFBMEI7QUFDakMsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGdCQUFnQjtBQUV2QixPQUFPQyw4QkFBOEI7QUFDckMsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLDBCQUEwQjtBQUNqQyxPQUFPQyw0QkFBNEI7QUFFbkMsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLDBCQUEwQjtBQUNqQyxPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MseUJBQXlCO0FBRWhDLE9BQU9DLGNBQWM7QUFDckIsT0FBT0Msd0JBQXdCO0FBRS9CLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0Msc0JBQXNCO0FBRTdCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0MsNEJBQTRCO0FBQ25DLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MsMEJBQTBCO0FBQ2pDLE9BQU9DLHlCQUF5QjtBQUNoQyxPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyw2QkFBNkI7QUFDcEMsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLDhCQUE4QjtBQUNyQyxPQUFPQyw2QkFBNkI7QUFDcEMsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLDBCQUEwQjtBQUNqQyxPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLDZCQUE2QjtBQUNwQyxPQUFPQywrQkFBK0I7QUFDdEMsT0FBT0Msc0NBQXNDO0FBQzdDLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyw0QkFBNEI7QUFDbkMsT0FBT0Msd0JBQXdCO0FBQy9CLE9BQU9DLGNBQWM7QUFDckIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGdDQUFnQztBQUN2QyxPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLDRCQUE0QjtBQUNuQyxPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsdUNBQXVDO0FBQzlDLE9BQU9DLHFCQUFxQjtBQUM1QixNQUFNQyxhQUFhL08sb0JBQW9CO0FBQUEsRUFDckM7QUFBQSxJQUNFZ1AsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU07QUFBQSxFQUNqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLLEtBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQztBQUFBLDZCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPO0FBQUEsTUFDUCx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVk7QUFBQSxTQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQixLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYSxLQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjLEtBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXLEtBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUIsS0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQixLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYyxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQjtBQUFBLEVBQy9CO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTSxLQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU0sS0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVyxLQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0U7QUFBQTtBQUFBLE1BQ0QsdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQjtBQUFBLE1BQUk7QUFBQSxTQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNFO0FBQUE7QUFBQSxNQUNELHVCQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUI7QUFBQSxNQUFJO0FBQUEsU0FGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCO0FBQUEsRUFDaEM7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsRUFDMUI7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsOEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QixLQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFFQSxFQUFFRCxNQUFNLGlCQUFpQkMsU0FBUyx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWEsRUFBSTtBQUFBLEVBQ25ELEVBQUVELE1BQU0sa0JBQWtCQyxTQUFTLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBYSxFQUFJO0FBQUEsRUFDcEQsRUFBRUQsTUFBTSxvQkFBb0JDLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlLEVBQUk7QUFBQSxFQUV4RDtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWEsS0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRLEtBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQixLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLDhCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUIsS0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCLEtBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsNkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QixLQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0IsS0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFFQyxpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCLEtBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQixLQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQixLQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLDJDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CLEtBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjLEtBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0IsS0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCLEtBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsNkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QixLQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBO0FBQUEsSUFFRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0IsS0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVk7QUFBQSxFQUN2QjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxFQUN6QjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCO0FBQUEsRUFDN0I7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjLEtBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBR0o7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLLEtBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0IsS0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSyxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTyxLQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQjtBQUFBLEVBQ2pDO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUFTLHVCQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVO0FBQUEsRUFDckI7QUFBQSxFQUNDO0FBQUEsSUFDQ0QsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLEVBQzNCO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUFTLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVztBQUFBLEVBQ3RCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQztBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQSxNQUlFLHVCQUFDLG1CQUNDLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVSxLQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQixLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUIsS0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVcsS0FEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYSxLQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVMsS0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUIsS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxtQkFDQyxpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVUsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLLEtBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTyxLQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQixLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLLEtBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTSxLQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVEsS0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVEsS0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVyxLQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0IsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsbUJBQ0MsaUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjLEtBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQTtBQUFBLEVBR0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTSxLQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjLEtBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUIsS0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWEsS0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUIsS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTSxLQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVSxLQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0M7QUFBQSw2QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTztBQUFBLE1BQ1AsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUs7QUFBQSxTQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsSUFDckJDLFVBQVU7QUFBQSxNQUNSO0FBQUEsUUFDRUMsT0FBTztBQUFBLFFBQ1BGLFNBQVMsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsTUFDeEI7QUFBQSxNQUNBO0FBQUEsUUFDRUQsTUFBTTtBQUFBLFFBQ05DLFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZO0FBQUEsUUFDckJDLFVBQVU7QUFBQSxVQUNSO0FBQUEsWUFDRUYsTUFBTTtBQUFBLFlBQ05DLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYztBQUFBLFVBQ3pCO0FBQUEsVUFDQTtBQUFBLFlBQ0VELE1BQU07QUFBQSxZQUNOQyxTQUFTLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVc7QUFBQSxVQUN0QjtBQUFBLFVBQ0E7QUFBQSxZQUNFRCxNQUFNO0FBQUEsWUFDTkMsU0FBUyx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFZO0FBQUEsVUFDdkI7QUFBQSxRQUFDO0FBQUEsTUFFTDtBQUFBLElBQUM7QUFBQSxFQUVMO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhLEtBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCLEtBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUFDO0FBQUEsRUFFRDtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUIsS0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQztBQUFBLDZCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPO0FBQUEsTUFDUCx1QkFBQyw4QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsU0FGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQztBQUFBLDZCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPO0FBQUEsTUFDUCx1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCO0FBQUEsU0FGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsRUFFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBVUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQztBQUFBLDZCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPO0FBQUEsTUFDUCx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLFNBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCO0FBQUEsRUFDM0I7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsRUFDMUI7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLEVBQzNCO0FBQUEsRUFFQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUFTLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFDakJDLFVBQVU7QUFBQSxNQUdSLEVBQUVGLE1BQU0sV0FBV0MsU0FBUyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUSxFQUFJO0FBQUEsTUFDeEMsRUFBRUQsTUFBTSxVQUFVQyxTQUFTLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYSxFQUFJO0FBQUEsTUFDNUMsRUFBRUQsTUFBTSxnQkFBZ0JDLFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLEVBQUk7QUFBQSxNQUNqRCxFQUFFRCxNQUFNLHdCQUF3QkMsU0FBUyx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1CLEVBQUk7QUFBQTtBQUFBLE1BRWhFLEVBQUVELE1BQU0sa0JBQWtCQyxTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxFQUFJO0FBQUEsTUFDckQsRUFBRUQsTUFBTSxnQ0FBZ0NDLFNBQVMsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQixFQUFJO0FBQUEsTUFDckUsRUFBRUQsTUFBTSx3QkFBd0JDLFNBQVMsdUJBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQixFQUFJO0FBQUEsTUFDdkUsRUFBRUQsTUFBTSwwQkFBMEJDLFNBQVMsdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQixFQUFJO0FBQUEsTUFDcEUsRUFBRUQsTUFBTSw0QkFBNEJDLFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQixFQUFJO0FBQUEsTUFDdkUsRUFBRUQsTUFBTSxnQkFBZ0JDLFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLEVBQUk7QUFBQSxNQUNqRCxFQUFFRCxNQUFNLG9CQUFvQkMsU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsRUFBSTtBQUFBLE1BQ3hELEVBQUVELE1BQU0sa0JBQWtCQyxTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxFQUFJO0FBQUEsTUFDckQsRUFBRUQsTUFBTSxrQkFBa0JDLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjLEVBQUk7QUFBQSxNQUNyRCxFQUFFRCxNQUFNLGVBQWVDLFNBQVMsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXLEVBQUk7QUFBQSxNQUMvQyxFQUFFRCxNQUFNLHNCQUFzQkMsU0FBUyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCLEVBQUk7QUFBQSxNQUM1RCxFQUFFRCxNQUFNLGlCQUFpQkMsU0FBUyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCLEVBQUk7QUFBQSxNQUN2RCxFQUFFRCxNQUFNLG1CQUFtQkMsU0FBUyx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVcsRUFBSTtBQUFBLE1BQ25ELEVBQUVELE1BQU0sd0JBQXdCQyxTQUFTLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsRUFBSTtBQUFBLE1BQ2hFLEVBQUVELE1BQU0sbUJBQW1CQyxTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxFQUFJO0FBQUEsTUFDdEQsRUFBRUQsTUFBTSxlQUFlQyxTQUFTLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVyxFQUFJO0FBQUEsTUFDL0MsRUFBRUQsTUFBTSxnQkFBZ0JDLFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLEVBQUk7QUFBQSxNQUNqRCxFQUFFRCxNQUFNLG1CQUFtQkMsU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsRUFBSTtBQUFBLE1BQ3ZELEVBQUVELE1BQU0scUJBQXFCQyxTQUFTLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUIsRUFBSTtBQUFBLE1BQzNELEVBQUVELE1BQU0scUJBQXFCQyxTQUFTLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUIsRUFBSTtBQUFBLE1BQzNELEVBQUVELE1BQU0sa0JBQWtCQyxTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxFQUFJO0FBQUEsTUFDckQsRUFBRUQsTUFBTSxtQkFBbUJDLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEVBQUk7QUFBQSxNQUN2RCxFQUFFRCxNQUFNLDBCQUEwQkMsU0FBUyx1QkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFCLEVBQUk7QUFBQSxNQUNwRTtBQUFBLFFBQ0VELE1BQU07QUFBQSxRQUNOQyxTQUFTLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxNQUM5QjtBQUFBLE1BQ0E7QUFBQSxRQUNFRCxNQUFNO0FBQUEsUUFBZ0NDLFNBQVMsdUJBQUMsbUNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLE1BQy9FO0FBQUEsTUFDQTtBQUFBLFFBQ0VELE1BQU07QUFBQSxRQUNOQyxTQUFTLHVCQUFDLHNDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxNQUM1QztBQUFBLE1BQ0EsRUFBRUQsTUFBTSwyQkFBMkJDLFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQixFQUFJO0FBQUEsTUFDdEUsRUFBRUQsTUFBTSx3QkFBd0JDLFNBQVMsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQixFQUFJO0FBQUEsTUFDaEU7QUFBQSxRQUNFRCxNQUFNO0FBQUEsUUFDTkMsU0FBUyx1QkFBQyw4QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsTUFDcEM7QUFBQSxNQUNBLEVBQUVELE1BQU0sa0JBQWtCQyxTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxFQUFJO0FBQUEsTUFDckQsRUFBRUQsTUFBTSwwQkFBMEJDLFNBQVMsdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQixFQUFJO0FBQUEsTUFDcEUsRUFBRUQsTUFBTSw0QkFBNEJDLFNBQVMsdUJBQUMsNEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QixFQUFJO0FBQUEsTUFDeEU7QUFBQSxRQUNFRCxNQUFNO0FBQUEsUUFDTkMsU0FBUyx1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtCO0FBQUEsTUFDN0I7QUFBQSxNQUNBLEVBQUVELE1BQU0sNEJBQTRCQyxTQUFTLHVCQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0IsRUFBSTtBQUFBLE1BQ3ZFLEVBQUVELE1BQU0sd0JBQXdCQyxTQUFTLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsRUFBSTtBQUFBLE1BQ2hFLEVBQUVELE1BQU0sd0JBQXdCQyxTQUFTLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsRUFBSTtBQUFBLE1BQ2hFO0FBQUEsUUFDRUQsTUFBTTtBQUFBLFFBQ05DLFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQjtBQUFBLE1BQ2pDO0FBQUEsTUFDQTtBQUFBLFFBQ0VELE1BQU07QUFBQSxRQUNOQyxTQUFTLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUI7QUFBQSxNQUM1QjtBQUFBLE1BQ0EsRUFBRUQsTUFBTSxvQkFBb0JDLFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQixFQUFJO0FBQUEsTUFDL0QsRUFBRUQsTUFBTSw2QkFBNkJDLFNBQVMsdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQixFQUFJO0FBQUEsTUFDbkUsRUFBRUQsTUFBTSx5QkFBeUJDLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjLEVBQUk7QUFBQSxNQUM1RCxFQUFFRCxNQUFNLDBCQUEwQkMsU0FBUyx1QkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFCLEVBQUk7QUFBQSxNQUNwRTtBQUFBLFFBQ0VELE1BQU07QUFBQSxRQUNOQyxTQUFTLHVCQUFDLHlDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxNQUMvQztBQUFBLE1BQ0E7QUFBQSxRQUNFRCxNQUFNO0FBQUEsUUFDTkMsU0FBUyx1QkFBQyxtQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUEsTUFDekM7QUFBQSxNQUNBO0FBQUEsUUFDRUQsTUFBTTtBQUFBLFFBQ05DLFNBQVMsdUJBQUMsbUNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLE1BQ3pDO0FBQUEsTUFDQTtBQUFBLFFBQ0VELE1BQU07QUFBQSxRQUFvQ0MsU0FBUyx1QkFBQyw0QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsTUFDNUU7QUFBQSxNQUNBO0FBQUEsUUFDRUQsTUFBTTtBQUFBLFFBQ05DLFNBQVMsdUJBQUMsb0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLE1BQzFDO0FBQUEsTUFDQTtBQUFBLFFBQ0VELE1BQU07QUFBQSxRQUNOQyxTQUFTLHVCQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxNQUNuQztBQUFBLE1BQ0EsRUFBRUQsTUFBTSxvQkFBb0JDLFNBQVMsdUJBQUMsNEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QixFQUFJO0FBQUEsTUFDaEUsRUFBRUQsTUFBTSwwQkFBMEJDLFNBQVMsdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQixFQUFJO0FBQUEsTUFDcEUsRUFBRUQsTUFBTSxtQkFBbUJDLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjLEVBQUk7QUFBQSxNQUN0RCxFQUFFRCxNQUFNLDJCQUEyQkMsU0FBUyx1QkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFCLEVBQUk7QUFBQSxNQUNyRSxFQUFFRCxNQUFNLHlCQUF5QkMsU0FBUyx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CLEVBQUk7QUFBQSxNQUNsRSxFQUFFRCxNQUFNLHNCQUFzQkMsU0FBUyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCLEVBQUk7QUFBQSxNQUM1RCxFQUFFRCxNQUFNLHVCQUF1QkMsU0FBUyx1QkFBQyw2QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCLEVBQUk7QUFBQSxNQUNwRTtBQUFBLFFBQ0VELE1BQU07QUFBQSxRQUNOQyxTQUFTLHVCQUFDLDhCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxNQUNwQztBQUFBLE1BQ0EsRUFBRUQsTUFBTSx1QkFBdUJDLFNBQVMsdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQixFQUFJO0FBQUEsTUFDOUQ7QUFBQSxRQUNFRCxNQUFNO0FBQUEsUUFDTkMsU0FBUyx1QkFBQyw2QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsTUFDbkM7QUFBQSxNQUNBO0FBQUEsUUFDRUQsTUFBTTtBQUFBLFFBQ05DLFNBQVMsdUJBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLE1BQ3JDO0FBQUEsTUFDQTtBQUFBLFFBQ0VELE1BQU07QUFBQSxRQUNOQyxTQUFTLHVCQUFDLHNDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxNQUM1QztBQUFBLE1BQ0E7QUFBQSxRQUNFRCxNQUFNO0FBQUEsUUFDTkMsU0FBUyx1QkFBQyx1Q0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsTUFDN0M7QUFBQSxNQUNBLEVBQUVELE1BQU0sc0JBQXNCQyxTQUFTLHVCQUFDLDRCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUIsRUFBSTtBQUFBLE1BQ2xFLEVBQUVELE1BQU0sMEJBQTBCQyxTQUFTLHVCQUFDLGdDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkIsRUFBSTtBQUFBLElBQUM7QUFBQSxFQUUvRTtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxxQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdDO0FBQUEsRUFDM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CO0FBQUEsRUFDOUI7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVU7QUFBQSxFQUNyQjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFFTkMsU0FBUyx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTTtBQUFBLEVBQ2pCO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUVOQyxTQUFTLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0I7QUFBQSxFQUMzQjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWMsS0FEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsOEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QixLQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0IsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyw0QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCLEtBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsNkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QixLQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGlDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEIsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBRUE7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxnQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQ0UsdUJBQUMsa0JBQ0MsaUNBQUMsa0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLGdDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWEsS0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUNFLHVCQUFDLGtCQUNDLGlDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUIsS0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFBQSxFQUVBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxFQUNwQjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWE7QUFBQSxFQUN4QjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVk7QUFBQSxFQUN2QjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWU7QUFBQSxFQUMxQjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVc7QUFBQSxFQUN0QjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyw4QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsRUFDcEM7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsRUFDMUI7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBQUEsRUFDekI7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVU7QUFBQSxFQUNyQjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVk7QUFBQSxFQUN2QjtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCO0FBQUEsRUFDNUI7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQjtBQUFBLEVBQzlCO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUFTLHVCQUFDLDRCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUI7QUFBQSxFQUNsQztBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyw4QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsRUFDcEM7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMsZ0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLEVBQ3RDO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUFTLHVCQUFDLG1DQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEI7QUFBQSxFQUN6QztBQUFBLEVBQ0E7QUFBQSxJQUNFRCxNQUFNO0FBQUEsSUFDTkMsU0FBUyx1QkFBQyxvQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStCO0FBQUEsRUFDMUM7QUFBQSxFQUNBO0FBQUEsSUFDRUQsTUFBTTtBQUFBLElBQ05DLFNBQVMsdUJBQUMscUNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQztBQUFBLEVBQzNDO0FBQUEsRUFDQTtBQUFBLElBQ0VELE1BQU07QUFBQSxJQUNOQyxTQUFTLHVCQUFDLDRCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUI7QUFBQSxFQUNsQztBQUFBLEVBQ0EsRUFBRUQsTUFBTSxrQkFBa0JDLFNBQVMsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFhLEVBQUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBa0NwRCxDQUNEO0FBQ0QsZUFBZUYiLCJuYW1lcyI6WyJjcmVhdGVCcm93c2VyUm91dGVyIiwiUHJvdGVjdGVkUm91dGUiLCJTdXBlckFkbWluUm91dGUiLCJMb2dpbiIsIkhvbWUiLCJOYXZiYXIiLCJHcm91cCIsIlVzZXIiLCJUYXNrIiwiVGFyZ2V0IiwiRW5yb2xsbWVudFJlcXVlc3RGb3JtIiwiRmlsdGVyR3JvdXBzIiwiUGF5cm9sbCIsIlN0YWZmIiwiRW1wbG95ZWUiLCJXZWVrR3JvdXAiLCJFbnJvbGwiLCJMb2FuIiwiUGlnbWUiLCJBdWN0aW9uIiwiUGF5bWVudCIsIkNvbGxlY3Rpb25BcmVhIiwiQWdlbnQiLCJMZWFkIiwiTGVhZFNldHRpbmciLCJBcHBTZXR0aW5ncyIsIkdyb3VwU2V0dGluZ3MiLCJBZG1pbmlzdHJhdGl2ZVByaXZpbGVnZXMiLCJBZG1pbkFjY2Vzc1JpZ2h0cyIsIk1hcmtldGluZyIsIlByb2ZpbGUiLCJEYXlib29rIiwiU2FsZXNSZXBvcnQiLCJSZWNlaXB0IiwiR3JvdXBSZXBvcnQiLCJBbGxHcm91cFJlcG9ydCIsIkF1Y3Rpb25SZXBvcnQiLCJMZWFkUmVwb3J0IiwiVXNlclJlcG9ydCIsIkFsbFVzZXJSZXBvcnQiLCJMb2FuUmVwb3J0IiwiUGlnbWVSZXBvcnQiLCJFbXBsb3llZVJlcG9ydCIsIkNvbW1pc3Npb25SZXBvcnQiLCJFbnJvbGxtZW50UmVwb3J0IiwiUGF5bWVudFN1bW1hcnkiLCJXaGF0c2FwcEFkZCIsIldoYXRzYXBwRmFpbGVkIiwiRHVlTWVzc2FnZSIsIk91dHN0YW5kaW5nUmVwb3J0IiwiUmVwb3J0cyIsIkxlYWRTZXR0aW5ncyIsIkRlc2lnbmF0aW9uIiwiUGF5T3V0TWVudSIsIkdlbmVyYWxQYXltZW50T3V0IiwiUHJpbnQiLCJQYXlPdXRDb21taXNzaW9uIiwiUGF5T3V0UGV0dHlDYXNoIiwiUGF5T3V0U2FsYXJ5IiwiUGF5T3V0UmVwb3J0IiwiRXJyb3JQYWdlIiwiR3VhcmFudG9yIiwiRHJlYW1Bc3NldCIsIkJlY29tZUFnZW50IiwiUGF5T3V0T3RoZXJzIiwiUGF5SW5NZW51IiwiUmVnaXN0cmF0aW9uRmVlIiwiUHJpbnRQYXltZW50T3V0IiwiUmVnaXN0cmF0aW9uUmVjZWlwdCIsIkF1Y3Rpb25JbnRlbWF0aW9uTWVzc2FnZSIsIk92ZXJEdWVNZXNzYWdlIiwiRHVlRW1haWwiLCJPdmVyRHVlRW1haWwiLCJXaGF0c2FwcFByb21vIiwiUXVpY2tTZWFyY2giLCJCaWRXaW5uZXIiLCJUcmFuc2ZlckN1c3RvbWVyIiwiU29mdFRyYW5zZmVyQ3VzdG9tZXIiLCJIYXJkVHJhbnNmZXJDdXN0b21lciIsIlVuQXBwcm92ZWRDdXN0b21lciIsIlBheW1lbnRMaW5rIiwiTW9iaWxlQXBwRW5yb2xsIiwiUGF5bWVudExpbmtNZW51IiwiQ2hpdEJ1bGtQYXltZW50TGluayIsIkluZGl2aWR1YWxDaGl0UGF5bWVudExpbmsiLCJUYXJnZXRJbmNlbnRpdmVOZXdSZXBvcnQiLCJDaGl0Q29sbGVjdGlvbkluY2VudGl2ZVJlcG9ydCIsIkxvYW5Db2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0IiwiUGlnbXlDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0IiwiSW5kaXZpZHVhbFJlZ2lzdHJhdGlvbkNoaXRQYXltZW50TGluayIsIlRhcmdldEluY2VudGl2ZVJlcG9ydCIsIlRhcmdldFBheU91dFNhbGFyeSIsIlRhcmdldFBheU91dENvbW1pc3Npb25JbmNlbnRpdmUiLCJUYXJnZXRDb21taXNzaW9uIiwiTW9udGhseUluc3RhbGxtZW50VHVybm92ZXJSZXBvcnQiLCJIb2xkZWRDdXN0b21lclJlcG9ydCIsIkF1Y3Rpb25CaWRTdGF0dXMiLCJBdWN0aW9uV2lubmVyRG9jdW1lbnRzIiwiQXVjdGlvbkluZm9ybWF0aW9uIiwiQXVjdGlvblRlcm1zYW5kQ29uZGl0aW9uIiwiTGVhZFdoYXRzYXBwV2VsY29tZU1lc3NhZ2UiLCJMZWFkUmVmZXJyZWRCeVdoYXRzYXBwTWVzc2FnZSIsIkN1c3RvbWVyV2VsY29tZVdoYXRzYXBwTWVzc2FnZSIsIkN1c3RvbWVyQ2hpdFBsYW5XaGF0c2FwcE1lc3NhZ2UiLCJJbnN1cmFuY2UiLCJDdXN0b21lclJld2FyZHMiLCJQYXlJbk91dE1lbnUiLCJSZWdpc3RyYXRpb25GZWVSZXBvcnQiLCJDb2xsZWN0aW9uRXhlY3V0aXZlUmVwb3J0IiwiU3RhZmZNZW51IiwiRW1wbG95ZWVBdHRlbmRhbmNlIiwiRW1wbG95ZWVNb250aGx5UmVwb3J0IiwiRW1wbG95ZWVNZW51IiwiUGF5bWVudE1lbnUiLCJDdXN0b21lckxvYW5SZXBvcnQiLCJDb2xsZWN0aW9uQXJlYVJlcG9ydCIsIlBheW91dFNhbGFyeVJlcG9ydCIsIlRhcmdldE1lbnUiLCJFbnJvbGxtZW50TWVudSIsIkNoaXRDb2xsZWN0aW9uRXhlY3V0aXZlUmVwb3J0IiwiUGVuYWx0eVNldHRpbmdzIiwiUGVuYWx0eU1vbml0b3IiLCJVc2VyTWVudSIsIk90aGVyU2VydmljZXNNZW51IiwiTGVnYWxzTWVudSIsIlVuQXBwcm92ZWRDdXN0b21lclJlcG9ydCIsIlBheW1lbnRSZXBvcnQiLCJVc2VyRXZlbnRMb2dnZXIiLCJQaWdteVN1bW1hcnlSZXBvcnQiLCJDaGl0QXNraW5nTW9udGhSZXBvcnQiLCJTYWxhcnlSZW1haW5pbmdSZXBvcnQiLCJBZG1pbkFwcHJvdmFsTWVudSIsIlN1c3BlbnNlUGF5bWVudHMiLCJJbkFjdGl2ZVVzZXJSZXBvcnQiLCJOb25Db252ZXJ0ZWRMZWFkIiwiQ29udmVydGVkTGVhZCIsIlVzZXJSZWdpc3RyYXRpb25Tb3VyY2VTdW1tYXJ5UmVwb3J0IiwiSFJNZW51IiwiU2FsYXJ5UGF5bWVudCIsIlRyYW5zZmVyTWVudSIsIkNvbGxlY3Rpb25NZW51IiwiU2FsYXJ5U2xpcFByaW50IiwiRW1wbG95ZWVTYWxhcnlSZXBvcnQiLCJIUlNhbGFyeU1hbmFnZW1lbnQiLCJFbXBsb3llZVN0YXRlbWVudCIsIlNhbGFyeUluY2VudGl2ZSIsIlVuYXBwcm92ZWRMb2FucyIsIkVtcGxveWVlRGVkdWN0aW9uUmVwb3J0IiwiTWFya2V0aW5nTWVudSIsIkVtYWlsTWFya2V0aW5nTWVudSIsIlBheW1lbnRMaW5rTWFya2V0aW5nTWVudSIsIldoYXRzYXBwTWFya2V0aW5nTWVudSIsIkR1ZVdoYXRzYXBwTWVzc2FnZU1lbnUiLCJMZWFkV2hhdHNhcHBNZXNzYWdlTWVudSIsIkN1c3RvbWVyV2hhdHNhcHBNZXNzYWdlTWVudSIsIkF1Y3Rpb25XaGF0c2FwcE1lc3NhZ2VNZW51IiwiUHJvbW90aW9uV2hhdHNhcHBNZXNzYWdlTWVudSIsIkR1ZUVtYWlsTWVudSIsIlJDU01hcmtldGluZ01lbnUiLCJTTVNNYXJrZXRpbmdNZW51IiwiQ29BcHBsaWNhbnQiLCJDb0FwcGxpY2FudFByaW50IiwiUGF5bWVudFdpdGhQZW5hbHR5IiwiUGVuYWx0eVdoYXRzYXBwTWVzc2FnZU1lbnUiLCJDdXN0b21lclZpZXciLCJBbmFseXRpY3MiLCJUb3RhbFJldmVudWUiLCJNb250aGx5UmV2ZW51ZSIsIkFkdmFuY2VTYWxhcnkiLCJQYXltZW50TGlua1RyYW5zYWN0aW9ucyIsIkN1c3RvbWVyUmV3YXJkUG9pbnRzIiwiUmVkZW1wdGlvblBvaW50c1JlcG9ydCIsIkxvYW5Db21wbGV0aW9uUmVwb3J0IiwiSGVscEFuZFN1cHBvcnQiLCJDb21wbGFpbnRGb3JtIiwiU3VwcG9ydHMiLCJFbXBsb3llZVJld2FyZFBvaW50cyIsIlJld2FyZFNldHRpbmdzIiwiUmV3YXJkTWVudSIsIkN1c3RvbWVyTG9hbldoYXRzYXBwTWVudSIsIkR1ZUxvYW5SZXBvcnQiLCJEYXRlV2lzZVJld2FyZHJlcG9ydCIsIkR1ZUxvYW5XaGF0c2FwcE1lc3NhZ2UiLCJWaXNpdG9yIiwiVmlzaXRvckxpc3QiLCJFbXBsb3llZVRhc2tzIiwiUHJpemVkQ3VzdG9tZXJSZXBvcnQiLCJBZGRHcm91cEZvcm0iLCJBdWN0aW9uRmlsdGVyUmVwb3J0IiwiUmVnaXN0ZXIiLCJUcmFuc2FjdGlvbkhpc3RvcnkiLCJBZ2VudFRhcmdldCIsIkVtcGxveWVlVGFyZ2V0IiwiQWdlbnRNZW51IiwiQmlkUmVxdWVzdCIsIkNyZWF0ZUJpZFJlcXVlc3QiLCJDcmVhdGVMb2FuUmVxdWVzdCIsIlVudmVyaWZpZWRBZ2VudCIsIkNoaXRDYW5jZWxsYXRpb25SZXBvcnQiLCJMb2FuUGF5bWVudE91dCIsIkdyb3VwTWVudSIsIkJpZFJlcXVlc3RSZXBvcnQiLCJMb2FuUGF5b3V0UmVwb3J0IiwiUmVjZW50QXVjdGlvbiIsIlBlbmFsdHlNYW5hZ2VtZW50IiwiVXNlckFjY291bnRzTWVudSIsIkNoaXRDYW5jZWxQYXltZW50T3V0IiwiQ2hpdENhbmNlbFBheW1lbnRJbiIsIkFjdGl2YXRlQ3VzdG9tZXIiLCJQaWdteVBheW1lbnRPdXQiLCJQbGFucyIsIlN1YnNjcmlwdGlvbnMiLCJFbnF1aXJlQ2FsbCIsIkN1c3RvbWVyQXBwSW5zdGFsbGF0aW9uIiwiVXNlckRvY3VtZW50cyIsIkVtcGxveWVlQWR2YW5jZVBheW1lbnRJbiIsIkVtcGxveWVlU2FsYXJ5SW5jZW50aXZlIiwiQWdlbnRDb21taXNzaW9uIiwiQWRkaXRpb25hbFNhbGFyeSIsIlVuQXBwcm92ZWRFbXBsb3llZSIsIlBpZ215UGF5b3V0UmVwb3J0IiwiUGlnbXlQcmVjbG9zdXJlUHJpbnQiLCJDaGl0UGF5b3V0UmVwb3J0IiwiTG9hbkRvY3VtZW50YXRpb24iLCJTdXNwZW5kZWRDdXN0b21lclJlcG9ydCIsIkVtcGxveWVlUmVmZXJyZWRDdXN0b21lcnMiLCJFbXBsb3llZUNvbGxlY3Rpb25DdXN0b21lclJlcG9ydCIsIkNoaXRVcGdyYWRlIiwiR1NUU2VydmljZUNoYXJnZVJlcG9ydCIsIkN1c3RvbWVyQWxsb2NhdGlvbiIsIkJyYW5jaGVzIiwiQ3VzdG9tZXJBcmVhIiwiQ3VzdG9tZXJWaXNpdFRyYWNrZXJSZXBvcnQiLCJQaW5jb2RlUmVwb3J0IiwiVW5saW5rRW5yb2xsbWVudCIsIkN1c3RvbWVyVHJhY2tpbmdSZXBvcnQiLCJDdXN0b21lckFyZWFSZXBvcnQiLCJFbXBsb3llZVJlbGF0aW9uc2hpcE1hbmFnZXJSZXBvcnQiLCJMaW5rZWRHdWFyYW50b3IiLCJtYWluUm91dGVzIiwicGF0aCIsImVsZW1lbnQiLCJjaGlsZHJlbiIsImluZGV4Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIm1haW5Sb3V0ZXMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUJyb3dzZXJSb3V0ZXIgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgUHJvdGVjdGVkUm91dGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvYXV0aGVudGljYXRpb24vUHJvdGVjdGVkUm91dGVcIjtcclxuaW1wb3J0IFN1cGVyQWRtaW5Sb3V0ZSBmcm9tIFwiLi4vY29tcG9uZW50cy9hdXRoZW50aWNhdGlvbi9TdXBlckFkbWluUm91dGVcIjtcclxuaW1wb3J0IExvZ2luIGZyb20gXCIuLi9wYWdlcy9Mb2dpblwiO1xyXG5pbXBvcnQgSG9tZSBmcm9tIFwiLi4vcGFnZXMvSG9tZVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBHcm91cCBmcm9tIFwiLi4vcGFnZXMvR3JvdXBcIjtcclxuaW1wb3J0IFVzZXIgZnJvbSBcIi4uL3BhZ2VzL1VzZXJcIjtcclxuaW1wb3J0IFRhc2sgZnJvbSBcIi4uL3BhZ2VzL1Rhc2tcIjtcclxuaW1wb3J0IFRhcmdldCBmcm9tIFwiLi4vcGFnZXMvVGFyZ2V0XCI7XHJcbmltcG9ydCBFbnJvbGxtZW50UmVxdWVzdEZvcm0gZnJvbSBcIi4uL3BhZ2VzL0Vucm9sbG1lbnRSZXF1ZXN0Rm9ybVwiO1xyXG5pbXBvcnQgRmlsdGVyR3JvdXBzIGZyb20gXCIuLi9wYWdlcy9GaWx0ZXJHcm91cHNcIjtcclxuaW1wb3J0IFBheXJvbGwgZnJvbSBcIi4uL3BhZ2VzL1BheXJvbGxcIjtcclxuaW1wb3J0IFN0YWZmIGZyb20gXCIuLi9wYWdlcy9TdGFmZlwiO1xyXG5pbXBvcnQgRW1wbG95ZWUgZnJvbSBcIi4uL3BhZ2VzL0VtcGxveWVlXCI7XHJcbmltcG9ydCBXZWVrR3JvdXAgZnJvbSBcIi4uL3BhZ2VzL1dlZWtHcm91cFwiO1xyXG5pbXBvcnQgRW5yb2xsIGZyb20gXCIuLi9wYWdlcy9FbnJvbGxcIjtcclxuaW1wb3J0IExvYW4gZnJvbSBcIi4uL3BhZ2VzL0xvYW5cIjtcclxuaW1wb3J0IFBpZ21lIGZyb20gXCIuLi9wYWdlcy9QaWdtZVwiO1xyXG5pbXBvcnQgQXVjdGlvbiBmcm9tIFwiLi4vcGFnZXMvQXVjdGlvblwiO1xyXG5pbXBvcnQgUGF5bWVudCBmcm9tIFwiLi4vcGFnZXMvUGF5bWVudFwiO1xyXG5pbXBvcnQgQ29sbGVjdGlvbkFyZWEgZnJvbSBcIi4uL3BhZ2VzL0NvbGxlY3Rpb25BcmVhXCI7XHJcbmltcG9ydCBBZ2VudCBmcm9tIFwiLi4vcGFnZXMvQWdlbnRcIjtcclxuaW1wb3J0IExlYWQgZnJvbSBcIi4uL3BhZ2VzL0xlYWRcIjtcclxuaW1wb3J0IExlYWRTZXR0aW5nIGZyb20gXCIuLi9wYWdlcy9MZWFkU2V0dGluZ1wiO1xyXG5pbXBvcnQgQXBwU2V0dGluZ3MgZnJvbSBcIi4uL3BhZ2VzL0FwcFNldHRpbmdzXCI7XHJcbmltcG9ydCBHcm91cFNldHRpbmdzIGZyb20gXCIuLi9wYWdlcy9Hcm91cFNldHRpbmdzXCI7XHJcbmltcG9ydCBBZG1pbmlzdHJhdGl2ZVByaXZpbGVnZXMgZnJvbSBcIi4uL3BhZ2VzL0FkbWluaXN0cmF0aXZlUHJpdmlsZWdlc1wiO1xyXG5pbXBvcnQgQWRtaW5BY2Nlc3NSaWdodHMgZnJvbSBcIi4uL3BhZ2VzL0FkbWluQWNjZXNzUmlnaHRzXCI7XHJcbmltcG9ydCBNYXJrZXRpbmcgZnJvbSBcIi4uL3BhZ2VzL01hcmtldGluZ1wiO1xyXG5pbXBvcnQgUHJvZmlsZSBmcm9tIFwiLi4vcGFnZXMvUHJvZmlsZVwiO1xyXG5pbXBvcnQgRGF5Ym9vayBmcm9tIFwiLi4vcGFnZXMvRGF5Ym9va1wiO1xyXG5pbXBvcnQgU2FsZXNSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL1NhbGVzUmVwb3J0XCI7XHJcbmltcG9ydCBSZWNlaXB0IGZyb20gXCIuLi9wYWdlcy9SZWNlaXB0XCI7XHJcbmltcG9ydCBHcm91cFJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvR3JvdXBSZXBvcnRcIjtcclxuaW1wb3J0IEFsbEdyb3VwUmVwb3J0IGZyb20gXCIuLi9wYWdlcy9BbGxHcm91cFJlcG9ydFwiO1xyXG5pbXBvcnQgQXVjdGlvblJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvQXVjdGlvblJlcG9ydFwiO1xyXG5pbXBvcnQgTGVhZFJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvTGVhZFJlcG9ydFwiO1xyXG5pbXBvcnQgVXNlclJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvVXNlclJlcG9ydFwiO1xyXG5pbXBvcnQgQWxsVXNlclJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvQWxsVXNlclJlcG9ydFwiO1xyXG5pbXBvcnQgTG9hblJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvTG9hblJlcG9ydFwiO1xyXG5pbXBvcnQgUGlnbWVSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL1BpZ21lUmVwb3J0XCI7XHJcbmltcG9ydCBFbXBsb3llZVJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvRW1wbG95ZWVSZXBvcnRcIjtcclxuaW1wb3J0IENvbW1pc3Npb25SZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0NvbW1pc3Npb25SZXBvcnRcIjtcclxuaW1wb3J0IEVucm9sbG1lbnRSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0Vucm9sbG1lbnRSZXBvcnRcIjtcclxuaW1wb3J0IFBheW1lbnRTdW1tYXJ5IGZyb20gXCIuLi9wYWdlcy9QYXltZW50U3VtbWFyeVwiO1xyXG5pbXBvcnQgV2hhdHNhcHBBZGQgZnJvbSBcIi4uL3BhZ2VzL1doYXRzYXBwQWRkXCI7XHJcbmltcG9ydCBXaGF0c2FwcEZhaWxlZCBmcm9tIFwiLi4vcGFnZXMvV2hhdHNhcHBGYWlsZWRcIjtcclxuaW1wb3J0IER1ZU1lc3NhZ2UgZnJvbSBcIi4uL3BhZ2VzL0R1ZU1lc3NhZ2VcIjtcclxuaW1wb3J0IE91dHN0YW5kaW5nUmVwb3J0IGZyb20gXCIuLi9wYWdlcy9PdXRzdGFuZGluZ1JlcG9ydFwiO1xyXG5pbXBvcnQgUmVwb3J0cyBmcm9tIFwiLi4vcGFnZXMvUmVwb3J0c1wiO1xyXG5pbXBvcnQgTGVhZFNldHRpbmdzIGZyb20gXCIuLi9wYWdlcy9MZWFkU2V0dGluZ3NcIjtcclxuaW1wb3J0IERlc2lnbmF0aW9uIGZyb20gXCIuLi9wYWdlcy9EZXNpZ25hdGlvblwiO1xyXG5pbXBvcnQgUGF5T3V0TWVudSBmcm9tIFwiLi4vcGFnZXMvUGF5T3V0TWVudVwiO1xyXG5pbXBvcnQgR2VuZXJhbFBheW1lbnRPdXQgZnJvbSBcIi4uL3BhZ2VzL0dlbmVyYWxQYXltZW50T3V0XCI7XHJcbmltcG9ydCBQcmludCBmcm9tIFwiLi4vcGFnZXMvUHJpbnRcIjtcclxuaW1wb3J0IFBheU91dENvbW1pc3Npb24gZnJvbSBcIi4uL3BhZ2VzL1BheU91dENvbW1pc3Npb25cIjtcclxuaW1wb3J0IFBheU91dFBldHR5Q2FzaCBmcm9tIFwiLi4vcGFnZXMvUGF5T3V0UGV0dHlDYXNoXCI7XHJcbmltcG9ydCBQYXlPdXRTYWxhcnkgZnJvbSBcIi4uL3BhZ2VzL1BheU91dFNhbGFyeVwiO1xyXG5pbXBvcnQgUGF5T3V0UmVwb3J0IGZyb20gXCIuLi9wYWdlcy9QYXlvdXRSZXBvcnRcIjtcclxuaW1wb3J0IEVycm9yUGFnZSBmcm9tIFwiLi9lcnJvci9FcnJvclBhZ2VcIjtcclxuaW1wb3J0IEd1YXJhbnRvciBmcm9tIFwiLi4vcGFnZXMvR3VhcmFudG9yXCI7XHJcbmltcG9ydCBEcmVhbUFzc2V0IGZyb20gXCIuLi9wYWdlcy9EcmVhbUFzc2V0XCI7XHJcbmltcG9ydCBCZWNvbWVBZ2VudCBmcm9tIFwiLi4vcGFnZXMvQmVjb21lQWdlbnRcIjtcclxuaW1wb3J0IFBheU91dE90aGVycyBmcm9tIFwiLi4vcGFnZXMvUGF5T3V0T3RoZXJzXCI7XHJcbmltcG9ydCBQYXlJbk1lbnUgZnJvbSBcIi4uL3BhZ2VzL1BheUluTWVudVwiO1xyXG5pbXBvcnQgUmVnaXN0cmF0aW9uRmVlIGZyb20gXCIuLi9wYWdlcy9SZWdpc3RyYXRpb25GZWVzXCI7XHJcbmltcG9ydCBQcmludFBheW1lbnRPdXQgZnJvbSBcIi4uL3BhZ2VzL1ByaW50UGF5bWVudE91dFwiO1xyXG5pbXBvcnQgUmVnaXN0cmF0aW9uUmVjZWlwdCBmcm9tIFwiLi4vcGFnZXMvUmVnaXN0cmF0aW9uUmVjZWlwdFwiO1xyXG5pbXBvcnQgQXVjdGlvbkludGVtYXRpb25NZXNzYWdlIGZyb20gXCIuLi9wYWdlcy9BdWN0aW9uSW50ZW1hdGlvbk1lc3NhZ2VcIjtcclxuaW1wb3J0IE92ZXJEdWVNZXNzYWdlIGZyb20gXCIuLi9wYWdlcy9PdmVyRHVlTWVzc2FnZVwiO1xyXG5pbXBvcnQgRHVlRW1haWwgZnJvbSBcIi4uL3BhZ2VzL0R1ZUVtYWlsXCI7XHJcbmltcG9ydCBPdmVyRHVlRW1haWwgZnJvbSBcIi4uL3BhZ2VzL092ZXJEdWVFbWFpbFwiO1xyXG5pbXBvcnQgV2hhdHNhcHBQcm9tbyBmcm9tIFwiLi4vcGFnZXMvV2hhdHNhcHBQcm9tb1wiO1xyXG5pbXBvcnQgUXVpY2tTZWFyY2ggZnJvbSBcIi4uL3BhZ2VzL1F1aWNrU2VhcmNoXCI7XHJcbmltcG9ydCBCaWRXaW5uZXIgZnJvbSBcIi4uL3BhZ2VzL0JpZFdpbm5lclwiO1xyXG5pbXBvcnQgVHJhbnNmZXJDdXN0b21lciBmcm9tIFwiLi4vcGFnZXMvU29mdFRyYW5zZmVyQ3VzdG9tZXJcIjtcclxuaW1wb3J0IFNvZnRUcmFuc2ZlckN1c3RvbWVyIGZyb20gXCIuLi9wYWdlcy9Tb2Z0VHJhbnNmZXJDdXN0b21lclwiO1xyXG5pbXBvcnQgSGFyZFRyYW5zZmVyQ3VzdG9tZXIgZnJvbSBcIi4uL3BhZ2VzL0hhcmRUcmFuc2ZlclwiO1xyXG5pbXBvcnQgVW5BcHByb3ZlZEN1c3RvbWVyIGZyb20gXCIuLi9wYWdlcy9VbkFwcHJvdmVkQ3VzdG9tZXJcIjtcclxuaW1wb3J0IFBheW1lbnRMaW5rIGZyb20gXCIuLi9wYWdlcy9QYXltZW50TGlua1wiO1xyXG5pbXBvcnQgTW9iaWxlQXBwRW5yb2xsIGZyb20gXCIuLi9wYWdlcy9Nb2JpbGVBcHBFbnJvbGxcIjtcclxuaW1wb3J0IFBheW1lbnRMaW5rTWVudSBmcm9tIFwiLi4vcGFnZXMvUGF5bWVudExpbmtNZW51XCI7XHJcbmltcG9ydCBDaGl0QnVsa1BheW1lbnRMaW5rIGZyb20gXCIuLi9wYWdlcy9CdWxrQ2hpdFBheW1lbnRMaW5rXCI7XHJcbmltcG9ydCBJbmRpdmlkdWFsQ2hpdFBheW1lbnRMaW5rIGZyb20gXCIuLi9wYWdlcy9JbmRpdmlkdWFsQ2hpdFBheW1lbnRMaW5rXCI7XHJcbmltcG9ydCBUYXJnZXRJbmNlbnRpdmVOZXdSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL1RhcmdldEluY2VudGl2ZU5ld1JlcG9ydFwiO1xyXG5pbXBvcnQgQ2hpdENvbGxlY3Rpb25JbmNlbnRpdmVSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0NoaXRDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0XCI7XHJcbmltcG9ydCBMb2FuQ29sbGVjdGlvbkluY2VudGl2ZVJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvTG9hbkNvbGxlY3Rpb25JbmNlbnRpdmVSZXBvcnRcIjtcclxuaW1wb3J0IFBpZ215Q29sbGVjdGlvbkluY2VudGl2ZVJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvUGlnbXlDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0XCI7XHJcblxyXG5pbXBvcnQgSW5kaXZpZHVhbFJlZ2lzdHJhdGlvbkNoaXRQYXltZW50TGluayBmcm9tIFwiLi4vcGFnZXMvSW5kaXZpZHVhbFJlZ2lzdHJhdGlvbkNoaXRQYXltZW50TGlua1wiO1xyXG5pbXBvcnQgVGFyZ2V0SW5jZW50aXZlUmVwb3J0IGZyb20gXCIuLi9wYWdlcy9UYXJnZXRJbmNlbnRpdmVcIjtcclxuaW1wb3J0IFRhcmdldFBheU91dFNhbGFyeSBmcm9tIFwiLi4vcGFnZXMvVGFyZ2V0UGF5b3V0U2FsYXJ5XCI7XHJcbmltcG9ydCBUYXJnZXRQYXlPdXRDb21taXNzaW9uSW5jZW50aXZlIGZyb20gXCIuLi9wYWdlcy9UYXJnZXRQYXlPdXRDb21taXNzaW9uSW5jZW50aXZlXCI7XHJcbmltcG9ydCBUYXJnZXRDb21taXNzaW9uIGZyb20gXCIuLi9wYWdlcy9UYXJnZXRDb21taXNzaW9uXCI7XHJcbi8vIGltcG9ydCBUYXJnZXRQYXlPdXRNZW51IGZyb20gXCIuLi9wYWdlcy9UYXJnZXRQYXlPdXRNZW51XCI7XHJcbmltcG9ydCBNb250aGx5SW5zdGFsbG1lbnRUdXJub3ZlclJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvTW9udGhseUluc3RhbGxtZW50VHVybm92ZXJSZXBvcnRcIjtcclxuaW1wb3J0IEhvbGRlZEN1c3RvbWVyUmVwb3J0IGZyb20gXCIuLi9wYWdlcy9Ib2xkZWRDdXN0b21lclJlcG9ydFwiO1xyXG5pbXBvcnQgQXVjdGlvbkJpZFN0YXR1cyBmcm9tIFwiLi4vcGFnZXMvQXVjdGlvbkJpZFN0YXR1c1wiO1xyXG5pbXBvcnQgQXVjdGlvbldpbm5lckRvY3VtZW50cyBmcm9tIFwiLi4vcGFnZXMvQXVjdGlvbldpbm5lckRvY3VtZW50c1wiO1xyXG5pbXBvcnQgQXVjdGlvbkluZm9ybWF0aW9uIGZyb20gXCIuLi9wYWdlcy9BdWN0aW9uSW5mb3JtYXRpb25cIjtcclxuaW1wb3J0IEF1Y3Rpb25UZXJtc2FuZENvbmRpdGlvbiBmcm9tIFwiLi4vcGFnZXMvQXVjdGlvblRlcm1zYW5kQ29uZGl0aW9uXCI7XHJcbmltcG9ydCBMZWFkV2hhdHNhcHBXZWxjb21lTWVzc2FnZSBmcm9tIFwiLi4vcGFnZXMvTGVhZFdoYXRzYXBwV2VsY29tZU1lc3NhZ2VcIjtcclxuaW1wb3J0IExlYWRSZWZlcnJlZEJ5V2hhdHNhcHBNZXNzYWdlIGZyb20gXCIuLi9wYWdlcy9MZWFkUmVmZXJyZWRCeVdoYXRzYXBwTWVzc2FnZVwiO1xyXG5pbXBvcnQgQ3VzdG9tZXJXZWxjb21lV2hhdHNhcHBNZXNzYWdlIGZyb20gXCIuLi9wYWdlcy9DdXN0b21lcldlbGNvbWVXaGF0c2FwcE1lc3NhZ2VcIjtcclxuaW1wb3J0IEN1c3RvbWVyQ2hpdFBsYW5XaGF0c2FwcE1lc3NhZ2UgZnJvbSBcIi4uL3BhZ2VzL0N1c3RvbWVyQ2hpdFBsYW5XaGF0c2FwcE1lc3NhZ2VcIjtcclxuaW1wb3J0IEluc3VyYW5jZSBmcm9tIFwiLi4vcGFnZXMvSW5zdXJhbmNlXCI7XHJcbmltcG9ydCBDdXN0b21lclJld2FyZHMgZnJvbSBcIi4uL3BhZ2VzL0N1c3RvbWVyUmV3YXJkc1wiO1xyXG5pbXBvcnQgUGF5SW5PdXRNZW51IGZyb20gXCIuLi9wYWdlcy9QYXlJbk91dE1lbnVcIjtcclxuaW1wb3J0IFJlZ2lzdHJhdGlvbkZlZVJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvUmVnaXN0cmF0aW9uRmVlUmVwb3J0XCI7XHJcbmltcG9ydCBDb2xsZWN0aW9uRXhlY3V0aXZlUmVwb3J0IGZyb20gXCIuLi9wYWdlcy9Db2xsZWN0aW9uRXhlY3V0aXZlUmVwb3J0XCI7XHJcbmltcG9ydCBTdGFmZk1lbnUgZnJvbSBcIi4uL3BhZ2VzL1N0YWZmTWVudVwiO1xyXG5pbXBvcnQgRW1wbG95ZWVBdHRlbmRhbmNlIGZyb20gXCIuLi9wYWdlcy9FbXBsb3llZUF0dGVuZGFuY2VSZXBvcnRcIjtcclxuaW1wb3J0IEVtcGxveWVlTW9udGhseVJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvRW1wbG95ZWVNb250aGx5UmVwb3J0XCI7XHJcbmltcG9ydCBFbXBsb3llZU1lbnUgZnJvbSBcIi4uL3BhZ2VzL0VtcGxveWVlTWVudVwiO1xyXG5pbXBvcnQgUGF5bWVudE1lbnUgZnJvbSBcIi4uL3BhZ2VzL1BheW1lbnRNZW51XCI7XHJcbmltcG9ydCBDdXN0b21lckxvYW5SZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0N1c3RvbWVyTG9hblJlcG9ydFwiO1xyXG5pbXBvcnQgQ29sbGVjdGlvbkFyZWFSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0NvbGxlY3Rpb25BcmVhUmVwb3J0XCI7XHJcbmltcG9ydCBQYXlvdXRTYWxhcnlSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL1BheW91dFNhbGFyeVJlcG9ydFwiO1xyXG5pbXBvcnQgVGFyZ2V0TWVudSBmcm9tIFwiLi4vcGFnZXMvVGFyZ2V0TWVudVwiO1xyXG5pbXBvcnQgRW5yb2xsbWVudE1lbnUgZnJvbSBcIi4uL3BhZ2VzL0Vucm9sbG1lbnRWaWV3XCI7XHJcbmltcG9ydCBDaGl0Q29sbGVjdGlvbkV4ZWN1dGl2ZVJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvQ2hpdENvbGxlY3Rpb25FeGVjdXRpdmVSZXBvcnRcIjtcclxuXHJcbmltcG9ydCBQZW5hbHR5U2V0dGluZ3MgZnJvbSBcIi4uL3BhZ2VzL1BlbmFsdHlTZXR0aW5nc1wiO1xyXG5pbXBvcnQgUGVuYWx0eU1vbml0b3IgZnJvbSBcIi4uL3BhZ2VzL1BlbmFsdHlNb25pdG9yXCI7XHJcbmltcG9ydCBVc2VyTWVudSBmcm9tIFwiLi4vcGFnZXMvVXNlck1lbnVcIjtcclxuaW1wb3J0IE90aGVyU2VydmljZXNNZW51IGZyb20gXCIuLi9wYWdlcy9PdGhlclNlcnZpY2VzTWVudVwiO1xyXG5pbXBvcnQgTGVnYWxzTWVudSBmcm9tIFwiLi4vcGFnZXMvTGVnYWxzTWVudVwiO1xyXG5pbXBvcnQgVW5BcHByb3ZlZEN1c3RvbWVyUmVwb3J0IGZyb20gXCIuLi9wYWdlcy9VbkFwcHJvdmVkQ3VzdG9tZXJSZXBvcnRcIjtcclxuaW1wb3J0IFBheW1lbnRSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL1BheW1lbnRSZXBvcnRcIjtcclxuaW1wb3J0IFVzZXJFdmVudExvZ2dlciBmcm9tIFwiLi4vcGFnZXMvQ3VzdG9tZXJBcHBFdmVudHNcIjtcclxuaW1wb3J0IFBpZ215U3VtbWFyeVJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvUGlnbXlTdW1tYXJ5UmVwb3J0XCI7XHJcblxyXG5pbXBvcnQgQ2hpdEFza2luZ01vbnRoUmVwb3J0IGZyb20gXCIuLi9wYWdlcy9DaGl0QXNraW5nTW9udGhSZXBvcnRcIjtcclxuaW1wb3J0IFNhbGFyeVJlbWFpbmluZ1JlcG9ydCBmcm9tIFwiLi4vcGFnZXMvU2FsYXJ5UmVtYWluaW5nUmVwb3J0XCI7XHJcbmltcG9ydCBBZG1pbkFwcHJvdmFsTWVudSBmcm9tIFwiLi4vcGFnZXMvQWRtaW5BcHByb3ZhbHNNZW51XCI7XHJcbmltcG9ydCBTdXNwZW5zZVBheW1lbnRzIGZyb20gXCIuLi9wYWdlcy9TdXNwZW5zZVBheW1lbnRzXCI7XHJcbmltcG9ydCBJbkFjdGl2ZVVzZXJSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0luQWN0aXZlVXNlclJlcG9ydFwiO1xyXG5pbXBvcnQgTm9uQ29udmVydGVkTGVhZCBmcm9tIFwiLi4vcGFnZXMvTm9uQ29udmVydGVkTGVhZFwiO1xyXG5pbXBvcnQgQ29udmVydGVkTGVhZCBmcm9tIFwiLi4vcGFnZXMvQ29udmVydGVkTGVhZFwiO1xyXG5pbXBvcnQgVXNlclJlZ2lzdHJhdGlvblNvdXJjZVN1bW1hcnlSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL1VzZXJSZWdpc3RyYXRpb25Tb3VyY2VTdW1tYXJ5UmVwb3J0XCI7XHJcbmltcG9ydCBIUk1lbnUgZnJvbSBcIi4uL3BhZ2VzL0hSTWVudVwiO1xyXG5pbXBvcnQgU2FsYXJ5UGF5bWVudCBmcm9tIFwiLi4vcGFnZXMvU2FsYXJ5UGF5bWVudFwiO1xyXG5pbXBvcnQgVHJhbnNmZXJNZW51IGZyb20gXCIuLi9wYWdlcy9UcmFuc2Zlck1lbnVcIjtcclxuaW1wb3J0IENvbGxlY3Rpb25NZW51IGZyb20gXCIuLi9wYWdlcy9Db2xsZWN0aW9uTWVudVwiO1xyXG5pbXBvcnQgU2FsYXJ5U2xpcFByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9TYWxhcnlTbGlwUHJpbnRcIjtcclxuaW1wb3J0IEVtcGxveWVlU2FsYXJ5UmVwb3J0IGZyb20gXCIuLi9wYWdlcy9FbXBsb3llZVNhbGFyeVJlcG9ydFwiO1xyXG5pbXBvcnQgSFJTYWxhcnlNYW5hZ2VtZW50IGZyb20gXCIuLi9wYWdlcy9IUlNhbGFyeU1hbmFnZW1lbnRcIjtcclxuaW1wb3J0IEVtcGxveWVlU3RhdGVtZW50IGZyb20gXCIuLi9wYWdlcy9FbXBsb3llZVN0YXRlbWVudFwiO1xyXG5pbXBvcnQgU2FsYXJ5SW5jZW50aXZlIGZyb20gXCIuLi9wYWdlcy9TYWxhcnlJbmNlbnRpdmVcIjtcclxuaW1wb3J0IFVuYXBwcm92ZWRMb2FucyBmcm9tIFwiLi4vcGFnZXMvVW5hcHByb3ZlZExvYW5zXCI7XHJcbmltcG9ydCBFbXBsb3llZURlZHVjdGlvblJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvRW1wbG95ZWVEZWR1Y3Rpb25SZXBvcnRcIjtcclxuaW1wb3J0IE1hcmtldGluZ01lbnUgZnJvbSBcIi4uL3BhZ2VzL01hcmtldGluZ01lbnVcIjtcclxuaW1wb3J0IEVtYWlsTWFya2V0aW5nTWVudSBmcm9tIFwiLi4vcGFnZXMvRW1haWxNYXJrZXRpbmdNZW51XCI7XHJcbmltcG9ydCBQYXltZW50TGlua01hcmtldGluZ01lbnUgZnJvbSBcIi4uL3BhZ2VzL1BheW1lbnRMaW5rTWFya2V0aW5nTWVudVwiO1xyXG5pbXBvcnQgV2hhdHNhcHBNYXJrZXRpbmdNZW51IGZyb20gXCIuLi9wYWdlcy9XaGF0c2FwcE1hcmtldGluZ01lbnVcIjtcclxuaW1wb3J0IER1ZVdoYXRzYXBwTWVzc2FnZU1lbnUgZnJvbSBcIi4uL3BhZ2VzL0R1ZVdoYXRzYXBwTWVzc2FnZU1lbnVcIjtcclxuaW1wb3J0IExlYWRXaGF0c2FwcE1lc3NhZ2VNZW51IGZyb20gXCIuLi9wYWdlcy9MZWFkV2hhdHNhcHBNZXNzYWdlTWVudVwiO1xyXG5pbXBvcnQgQ3VzdG9tZXJXaGF0c2FwcE1lc3NhZ2VNZW51IGZyb20gXCIuLi9wYWdlcy9DdXN0b21lcldoYXRzYXBwTWVzc2FnZU1lbnVcIjtcclxuaW1wb3J0IEF1Y3Rpb25XaGF0c2FwcE1lc3NhZ2VNZW51IGZyb20gXCIuLi9wYWdlcy9BdWN0aW9uV2hhdHNhcHBNZXNzYWdlTWVudVwiO1xyXG5pbXBvcnQgUHJvbW90aW9uV2hhdHNhcHBNZXNzYWdlTWVudSBmcm9tIFwiLi4vcGFnZXMvUHJvbW90aW9uV2hhdHNhcHBNZXNzYWdlTWVudVwiO1xyXG5pbXBvcnQgRHVlRW1haWxNZW51IGZyb20gXCIuLi9wYWdlcy9EdWVFbWFpbE1lbnVcIjtcclxuaW1wb3J0IFJDU01hcmtldGluZ01lbnUgZnJvbSBcIi4uL3BhZ2VzL1JDU01hcmtldGluZ01lbnVcIjtcclxuaW1wb3J0IFNNU01hcmtldGluZ01lbnUgZnJvbSBcIi4uL3BhZ2VzL1NNU01hcmtldGluZ01lbnVcIjtcclxuaW1wb3J0IENvQXBwbGljYW50IGZyb20gXCIuLi9wYWdlcy9Db0FwcGxpY2FudFwiO1xyXG5pbXBvcnQgQ29BcHBsaWNhbnRQcmludCBmcm9tIFwiLi4vY29tcG9uZW50cy9wcmludEZvcm1hdHMvQ29BcHBsaWNhbnRQcmludFwiO1xyXG5pbXBvcnQgUGF5bWVudFdpdGhQZW5hbHR5IGZyb20gXCIuLi9wYWdlcy9QYXltZW50V2l0aFBlbmFsdHlcIjtcclxuaW1wb3J0IFBlbmFsdHlXaGF0c2FwcE1lc3NhZ2VNZW51IGZyb20gXCIuLi9wYWdlcy9QZW5hbHR5V2hhdHNhcHBNZXNzYWdlTWVudVwiO1xyXG5cclxuaW1wb3J0IEN1c3RvbWVyVmlldyBmcm9tIFwiLi4vcGFnZXMvQ3VzdG9tZXJWaWV3XCI7XHJcbmltcG9ydCBBbmFseXRpY3MgZnJvbSBcIi4uL3BhZ2VzL0FuYWx5dGljc1wiO1xyXG5cclxuaW1wb3J0IFRvdGFsUmV2ZW51ZSBmcm9tIFwiLi4vcGFnZXMvVG90YWxSZXZlbnVlXCI7XHJcbmltcG9ydCBNb250aGx5UmV2ZW51ZSBmcm9tIFwiLi4vcGFnZXMvTW9udGhseVJldmVudWVcIjtcclxuXHJcbmltcG9ydCBBZHZhbmNlU2FsYXJ5IGZyb20gXCIuLi9wYWdlcy9BZHZhbmNlU2FsYXJ5XCI7XHJcblxyXG5pbXBvcnQgUGF5bWVudExpbmtUcmFuc2FjdGlvbnMgZnJvbSBcIi4uL3BhZ2VzL1BheW1lbnRMaW5rVHJhbnNhY3Rpb25zXCI7XHJcblxyXG5pbXBvcnQgQ3VzdG9tZXJSZXdhcmRQb2ludHMgZnJvbSBcIi4uL3BhZ2VzL0N1c3RvbWVyUmV3YXJkc1wiO1xyXG5pbXBvcnQgUmVkZW1wdGlvblBvaW50c1JlcG9ydCBmcm9tIFwiLi4vcGFnZXMvUmVkZW1wdGlvblBvaW50c1JlcG9ydFwiO1xyXG5pbXBvcnQgTG9hbkNvbXBsZXRpb25SZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0xvYW5Db21wbGV0aW9uUmVwb3J0XCI7XHJcbmltcG9ydCBIZWxwQW5kU3VwcG9ydCBmcm9tIFwiLi4vcGFnZXMvSGVscEFuZFN1cHBvcnRcIjtcclxuaW1wb3J0IENvbXBsYWludEZvcm0gZnJvbSBcIi4uL3BhZ2VzL0NvbXBsYWludEZvcm1cIjtcclxuaW1wb3J0IFN1cHBvcnRzIGZyb20gXCIuLi9wYWdlcy9TdXBwb3J0c1wiO1xyXG5pbXBvcnQgRW1wbG95ZWVSZXdhcmRQb2ludHMgZnJvbSBcIi4uL3BhZ2VzL0VtcGxveWVlUmV3YXJkUG9pbnRzXCI7XHJcbmltcG9ydCBSZXdhcmRTZXR0aW5ncyBmcm9tIFwiLi4vcGFnZXMvUmV3YXJkU2V0dGluZ3NcIjtcclxuaW1wb3J0IFJld2FyZE1lbnUgZnJvbSBcIi4uL3BhZ2VzL1Jld2FyZHNNZW51XCI7XHJcblxyXG5pbXBvcnQgQ3VzdG9tZXJMb2FuV2hhdHNhcHBNZW51IGZyb20gXCIuLi9wYWdlcy9DdXN0b21lckxvYW5XaGF0c0FwcE1lbnVcIjtcclxuaW1wb3J0IER1ZUxvYW5SZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0R1ZUxvYW5SZXBvcnRcIjtcclxuaW1wb3J0IERhdGVXaXNlUmV3YXJkcmVwb3J0IGZyb20gXCIuLi9wYWdlcy9EYXRlV2lzZVJld2FyZHJlcG9ydFwiO1xyXG5pbXBvcnQgRHVlTG9hbldoYXRzYXBwTWVzc2FnZSBmcm9tIFwiLi4vcGFnZXMvRHVlTG9hbldoYXRzYXBwTWVzc2FnZVwiO1xyXG5cclxuaW1wb3J0IFZpc2l0b3IgZnJvbSBcIi4uL3BhZ2VzL1Zpc2l0b3JcIjtcclxuaW1wb3J0IFZpc2l0b3JMaXN0IGZyb20gXCIuLi9wYWdlcy9WaXNpdG9yTGlzdFwiO1xyXG5pbXBvcnQgRW1wbG95ZWVUYXNrcyBmcm9tIFwiLi4vY29tcG9uZW50cy9lbXBsb3llZS9FbXBsb3llZVRhc2tzXCI7XHJcbmltcG9ydCBQcml6ZWRDdXN0b21lclJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvUHJpemVkQ3VzdG9tZXJSZXBvcnRcIjtcclxuaW1wb3J0IEFkZEdyb3VwRm9ybSBmcm9tIFwiLi4vcGFnZXMvQWRkR3JvdXBGb3JtXCI7XHJcbmltcG9ydCBBdWN0aW9uRmlsdGVyUmVwb3J0IGZyb20gXCIuLi9wYWdlcy9BdWN0aW9uRmlsdGVyUmVwb3J0XCI7XHJcblxyXG5pbXBvcnQgUmVnaXN0ZXIgZnJvbSBcIi4uL3BhZ2VzL1JlZ2lzdHJhdGlvblwiO1xyXG5pbXBvcnQgVHJhbnNhY3Rpb25IaXN0b3J5IGZyb20gXCIuLi9wYWdlcy9UcmFuc2FjdGlvbkhpc3RvcnlcIjtcclxuXHJcbmltcG9ydCBBZ2VudFRhcmdldCBmcm9tIFwiLi4vcGFnZXMvQWdlbnRUYXJnZXRcIjtcclxuaW1wb3J0IEVtcGxveWVlVGFyZ2V0IGZyb20gXCIuLi9wYWdlcy9FbXBsb3llZVRhcmdldFwiO1xyXG5pbXBvcnQgQWdlbnRNZW51IGZyb20gXCIuLi9wYWdlcy9BZ2VudE1lbnVcIjtcclxuaW1wb3J0IEJpZFJlcXVlc3QgZnJvbSBcIi4uL3BhZ2VzL0JpZFJlcXVlc3RcIjtcclxuaW1wb3J0IENyZWF0ZUJpZFJlcXVlc3QgZnJvbSBcIi4uL3BhZ2VzL0NyZWF0ZUJpZFJlcXVlc3RcIjtcclxuLy8gaW1wb3J0IExvYW5SZXF1ZXN0IGZyb20gXCIuLi9wYWdlcy9Mb2FuUmVxdWVzdFwiO1xyXG5pbXBvcnQgQ3JlYXRlTG9hblJlcXVlc3QgZnJvbSBcIi4uL3BhZ2VzL0NyZWF0ZUxvYW5SZXF1ZXN0XCI7XHJcbmltcG9ydCBVbnZlcmlmaWVkQWdlbnQgZnJvbSBcIi4uL3BhZ2VzL1VudmVyaWZpZWRBZ2VudFwiO1xyXG5pbXBvcnQgQ2hpdENhbmNlbGxhdGlvblJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvQ2hpdENhbmNlbGxhdGlvblJlcG9ydFwiO1xyXG5pbXBvcnQgTG9hblBheW1lbnRPdXQgZnJvbSBcIi4uL3BhZ2VzL0xvYW5QYXltZW50T3V0XCI7XHJcbmltcG9ydCBHcm91cE1lbnUgZnJvbSBcIi4uL3BhZ2VzL0dyb3VwTWVudVwiO1xyXG5pbXBvcnQgQmlkUmVxdWVzdFJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvQmlkUmVxdWVzdFJlcG9ydFwiO1xyXG5pbXBvcnQgTG9hblBheW91dFJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvTG9hblBheW91dFJlcG9ydFwiO1xyXG5pbXBvcnQgUmVjZW50QXVjdGlvbiBmcm9tIFwiLi4vcGFnZXMvUmVjZW50QXVjdGlvblwiO1xyXG5pbXBvcnQgUGVuYWx0eU1hbmFnZW1lbnQgZnJvbSBcIi4uL3BhZ2VzL1BlbmFsdHlNYW5hZ2VtZW50XCI7XHJcbmltcG9ydCBVc2VyQWNjb3VudHNNZW51IGZyb20gXCIuLi9wYWdlcy9Vc2VyQWNjb3VudHNNZW51XCI7XHJcbmltcG9ydCBDaGl0Q2FuY2VsUGF5bWVudE91dCBmcm9tIFwiLi4vcGFnZXMvQ2hpdENhbmNlbFBheW1lbnRPdXRcIjtcclxuaW1wb3J0IENoaXRDYW5jZWxQYXltZW50SW4gZnJvbSBcIi4uL3BhZ2VzL0NoaXRDYW5jZWxQYXltZW50SW5cIjtcclxuaW1wb3J0IEFjdGl2YXRlQ3VzdG9tZXIgZnJvbSBcIi4uL3BhZ2VzL0FjdGl2YXRlQ3VzdG9tZXJcIjtcclxuaW1wb3J0IFBpZ215UGF5bWVudE91dCBmcm9tIFwiLi4vcGFnZXMvUGlnbXlQYXltZW50T3V0XCI7XHJcbmltcG9ydCBQbGFucyBmcm9tIFwiLi4vcGFnZXMvUGxhbnNcIjtcclxuaW1wb3J0IFN1YnNjcmlwdGlvbnMgZnJvbSBcIi4uL3BhZ2VzL1N1YnNjcmlwdGlvbnNcIjtcclxuaW1wb3J0IEVucXVpcmVDYWxsIGZyb20gXCIuLi9wYWdlcy9FbnF1aXJlQ2FsbFwiO1xyXG5pbXBvcnQgQ3VzdG9tZXJBcHBJbnN0YWxsYXRpb24gZnJvbSBcIi4uL3BhZ2VzL0N1c3RvbWVyQXBwSW5zdGFsbGF0aW9uXCI7XHJcbmltcG9ydCBVc2VyRG9jdW1lbnRzIGZyb20gXCIuLi9wYWdlcy9DdXN0b21lckRvY3VtZW50c1wiO1xyXG5pbXBvcnQgRW1wbG95ZWVBZHZhbmNlUGF5bWVudEluIGZyb20gXCIuLi9wYWdlcy9BZHZhbmNlUGF5bWVudEluXCI7XHJcbmltcG9ydCBFbXBsb3llZVNhbGFyeUluY2VudGl2ZSBmcm9tIFwiLi4vcGFnZXMvRW1wbG95ZWVJbmNlbnRpdmVQYXltZW50XCI7XHJcbmltcG9ydCBBZ2VudENvbW1pc3Npb24gZnJvbSBcIi4uL3BhZ2VzL0FnZW50Q29tbWlzc2lvblwiO1xyXG5pbXBvcnQgQWRkaXRpb25hbFNhbGFyeSBmcm9tIFwiLi4vcGFnZXMvQWRkaXRpb25hbFNhbGFyeVwiO1xyXG5pbXBvcnQgVW5BcHByb3ZlZEVtcGxveWVlIGZyb20gXCIuLi9wYWdlcy9VbkFwcHJvdmVkRW1wbG95ZWVcIjtcclxuaW1wb3J0IFBpZ215UGF5b3V0UmVwb3J0IGZyb20gXCIuLi9wYWdlcy9QaWdteVBheW91dFJlcG9ydFwiO1xyXG5pbXBvcnQgUGlnbXlQcmVjbG9zdXJlUHJpbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvcHJpbnRGb3JtYXRzL1BpZ215UHJlY2xvc3VyZVByaW50XCI7XHJcbmltcG9ydCBDaGl0UGF5b3V0UmVwb3J0IGZyb20gXCIuLi9wYWdlcy9DaGl0UGF5b3V0UmVwb3J0XCI7XHJcbmltcG9ydCBMb2FuRG9jdW1lbnRhdGlvbiBmcm9tIFwiLi4vcGFnZXMvTG9hbkRvY3VtZW50YXRpb25cIjtcclxuaW1wb3J0IFN1c3BlbmRlZEN1c3RvbWVyUmVwb3J0IGZyb20gXCIuLi9wYWdlcy9TdXNwZW5kZWRDdXN0b21lclJlcG9ydFwiO1xyXG5pbXBvcnQgRW1wbG95ZWVSZWZlcnJlZEN1c3RvbWVycyBmcm9tIFwiLi4vcGFnZXMvRW1wbG95ZWVSZWZlcnJlZEN1c3RvbWVyc1wiO1xyXG5pbXBvcnQgRW1wbG95ZWVDb2xsZWN0aW9uQ3VzdG9tZXJSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0VtcGxveWVlQ29sbGVjdGlvbkN1c3RvbWVyUmVwb3J0XCI7XHJcbmltcG9ydCBDaGl0VXBncmFkZSBmcm9tIFwiLi4vcGFnZXMvQ2hpdFVwZ3JhZGVcIjtcclxuaW1wb3J0IEdTVFNlcnZpY2VDaGFyZ2VSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0dTVFNlcnZpY2VDaGFyZ2VSZXBvcnRcIjtcclxuaW1wb3J0IEN1c3RvbWVyQWxsb2NhdGlvbiBmcm9tIFwiLi4vcGFnZXMvQ3VzdG9tZXJBbGxvY2F0aW9uXCI7XHJcbmltcG9ydCBCcmFuY2hlcyBmcm9tIFwiLi4vcGFnZXMvQnJhbmNoZXNcIjtcclxuaW1wb3J0IEN1c3RvbWVyQXJlYSBmcm9tIFwiLi4vcGFnZXMvQ3VzdG9tZXJBcmVhXCI7XHJcbmltcG9ydCBDdXN0b21lclZpc2l0VHJhY2tlclJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvQ3VzdG9tZXJWaXNpdFRyYWNrZXJSZXBvcnRcIjtcclxuaW1wb3J0IFBpbmNvZGVSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL1BpbmNvZGVSZXBvcnRcIjtcclxuaW1wb3J0IFVubGlua0Vucm9sbG1lbnQgZnJvbSBcIi4uL3BhZ2VzL1VubGlua0Vucm9sbG1lbnRcIjtcclxuaW1wb3J0IEN1c3RvbWVyVHJhY2tpbmdSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0N1c3RvbWVyVHJhY2tpbmdSZXBvcnRcIjtcclxuaW1wb3J0IEN1c3RvbWVyQXJlYVJlcG9ydCBmcm9tIFwiLi4vcGFnZXMvQ3VzdG9tZXJBcmVhUmVwb3J0XCI7XHJcbmltcG9ydCBFbXBsb3llZVJlbGF0aW9uc2hpcE1hbmFnZXJSZXBvcnQgZnJvbSBcIi4uL3BhZ2VzL0VtcGxveWVlUmVsYXRpb25zaGlwTWFuYWdlclJlcG9ydFwiO1xyXG5pbXBvcnQgTGlua2VkR3VhcmFudG9yIGZyb20gXCIuLi9wYWdlcy9MaW5rZWRHdWFyYW50b3JcIjtcclxuY29uc3QgbWFpblJvdXRlcyA9IGNyZWF0ZUJyb3dzZXJSb3V0ZXIoW1xyXG4gIHtcclxuICAgIHBhdGg6IFwiL1wiLFxyXG4gICAgZWxlbWVudDogPExvZ2luIC8+LFxyXG4gIH0sXHJcbiAgLy8gICAgIHtcclxuICAvLyAgIHBhdGg6XCIvcmVnaXN0ZXJcIixcclxuICAvLyAgIGVsZW1lbnQ6IDxSZWdpc3RlciAvPlxyXG4gIC8vIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvZGFzaGJvYXJkXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8SG9tZSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3F1aWNrLXNlYXJjaFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPE5hdmJhciAvPlxyXG4gICAgICAgIDxRdWlja1NlYXJjaCAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2FjdGl2YXRlLWN1c3RvbWVyXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8QWN0aXZhdGVDdXN0b21lciAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9oZWxwXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8SGVscEFuZFN1cHBvcnQgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9jdXN0b21lci1hcmVhXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8Q3VzdG9tZXJBcmVhIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvaGVscCZzdXBwb3J0XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8SGVscEFuZFN1cHBvcnQgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9oZWxwLXN1cHBvcnRcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxDb21wbGFpbnRGb3JtIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvYmlkLXJlcXVlc3RcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxCaWRSZXF1ZXN0IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvZW5xdWlyZS1jYWxsXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8RW5xdWlyZUNhbGwgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9iaWQtcmVxdWVzdC9jcmVhdGVcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxDcmVhdGVCaWRSZXF1ZXN0IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIC8vIHtcclxuICAvLyAgIHBhdGg6IFwiL2xvYW4tcmVxdWVzdFwiLFxyXG4gIC8vICAgZWxlbWVudDogKFxyXG4gIC8vICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgLy8gICAgICAgPExvYW5SZXF1ZXN0Lz5cclxuICAvLyAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAvLyAgICksXHJcbiAgLy8gfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9sb2FuLXJlcXVlc3QvY3JlYXRlXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8Q3JlYXRlTG9hblJlcXVlc3QgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbXktdGFza3NcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxFbXBsb3llZVRhc2tzIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2FuYWx5dGljc1wiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEFuYWx5dGljcyAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICAvLyB7XHJcbiAgLy8gICBwYXRoOiBcIi9hbmFseXRpY3NcIixcclxuICAvLyAgIGVsZW1lbnQ6IChcclxuICAvLyAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gIC8vICAgICAgIDxOYXZiYXIgLz5cclxuICAvLyAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAvLyAgICksXHJcbiAgLy8gfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9yZWctZmVlLXByaW50LzppZFwiLFxyXG4gICAgZWxlbWVudDogPFJlZ2lzdHJhdGlvblJlY2VpcHQgLz4sXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvZ3JvdXAtbWVudVwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEdyb3VwTWVudSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9ncm91cC1tZW51L2dyb3VwXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8R3JvdXAgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9ncm91cC1tZW51L2ZpbHRlci1ncm91cHNcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxHcm91cCAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3N1cHBvcnRzXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8U3VwcG9ydHMgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi91bmxpbmstbGluay1jdXN0b21lclwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFVubGlua0Vucm9sbG1lbnQgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9zdGFmZi1tZW51L2FnZW50LW1lbnUvdW52ZXJpZmllZC1hZ2VudFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFVudmVyaWZpZWRBZ2VudCAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3Jld2FyZC1tZW51XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UmV3YXJkTWVudSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3Jld2FyZC1tZW51L2VtcGxveWVlLXJld2FyZC1wb2ludHNcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIHtcIiBcIn1cclxuICAgICAgICA8RW1wbG95ZWVSZXdhcmRQb2ludHMgLz57XCIgXCJ9XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcmV3YXJkLW1lbnUvY3VzdG9tZXItcmV3YXJkLXBvaW50c1wiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAge1wiIFwifVxyXG4gICAgICAgIDxDdXN0b21lclJld2FyZFBvaW50cyAvPntcIiBcIn1cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvZW1wbG95ZWUtcmV3YXJkLXBvaW50c1wiLFxyXG4gICAgZWxlbWVudDogPEVtcGxveWVlUmV3YXJkUG9pbnRzIC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcmV3YXJkLXNldHRpbmdzXCIsXHJcbiAgICBlbGVtZW50OiA8UmV3YXJkU2V0dGluZ3MgLz4sXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2xvYW4td2hhdHNhcHAtbWFya2V0aW5nXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8Q3VzdG9tZXJMb2FuV2hhdHNhcHBNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHsgcGF0aDogXCJjdXN0b21lci12aWV3XCIsIGVsZW1lbnQ6IDxDdXN0b21lclZpZXcgLz4gfSxcclxuICB7IHBhdGg6IFwiL3RvdGFsLXJldmVudWVcIiwgZWxlbWVudDogPFRvdGFsUmV2ZW51ZSAvPiB9LFxyXG4gIHsgcGF0aDogXCIvbW9udGhseS1yZXZlbnVlXCIsIGVsZW1lbnQ6IDxNb250aGx5UmV2ZW51ZSAvPiB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudVwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFBheUluTWVudSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UGF5SW5PdXRNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvcGF5bWVudFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFBheW1lbnQgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9wZW5hbHR5LXBheW1lbnRcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxQYXltZW50V2l0aFBlbmFsdHkgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9zdXNwZW5zZS1wYXltZW50c1wiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFN1c3BlbnNlUGF5bWVudHMgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9hZHZhbmNlLXBheW1lbnQtaW5cIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxFbXBsb3llZUFkdmFuY2VQYXltZW50SW4gLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9yZWdpc3RyYXRpb24tZmVlXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UmVnaXN0cmF0aW9uRmVlIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3BheW1lbnQtbGluay10cmFuc2FjdGlvbnNcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxQYXltZW50TGlua1RyYW5zYWN0aW9ucyAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9wYXltZW50LWxpbmstbWVudVwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFBheW1lbnRMaW5rTWVudSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9jaGl0LXRyYW5zZmVyLXBheS1pblwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgey8qIDxDaGl0Q2FuY2VsUGF5bWVudEluIC8+ICovfVxyXG4gICAgICAgIDxDaGl0Q2FuY2VsUGF5bWVudE91dCAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9jaGl0LWNhbmNlbGF0aW9uLXBheS1vdXRcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxDaGl0Q2FuY2VsUGF5bWVudE91dCAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIC8vICAgICB7XHJcbiAgLy8gICBwYXRoOiBcIi9jby1hcHBsaWNhbnQtcHJpbnQvOmlkXCIsXHJcblxyXG4gIC8vICAgZWxlbWVudDogPENvQXBwbGljYW50UHJpbnQgLz4sXHJcbiAgLy8gfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9wYXltZW50LWxpbmstbWVudS9jaGl0LXBheW1lbnRcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxJbmRpdmlkdWFsQ2hpdFBheW1lbnRMaW5rIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvcGF5bWVudC1saW5rLW1lbnUvcmVnaXN0cmF0aW9uLWNoaXQtcGF5bWVudFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEluZGl2aWR1YWxSZWdpc3RyYXRpb25DaGl0UGF5bWVudExpbmsgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9wYXltZW50LWxpbmstbWVudS9jaGl0LWJ1bGstcGF5bWVudFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPENoaXRCdWxrUGF5bWVudExpbmsgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L2FkdmFuY2UtcGF5bWVudFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEFkdmFuY2VTYWxhcnkgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5bWVudC1vdXQvYWdlbnQtY29tbWlzc2lvblwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEFnZW50Q29tbWlzc2lvbiAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9wcmludC1wYXltZW50LW91dC86aWRcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxQcmludFBheW1lbnRPdXQgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9waWdteS1wcmVjbG9zdXJlLXByaW50LzppZFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFBpZ215UHJlY2xvc3VyZVByaW50IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L2VtcGxveWVlLXNhbGFyeS1pbmNlbnRpdmVcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxFbXBsb3llZVNhbGFyeUluY2VudGl2ZSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIC8vIHBhdGg6IFwiL3NhbGFyeS1pbmNlbnRpdmVcIixcclxuICAgIHBhdGg6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9zYWxhcnktaW5jZW50aXZlXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8U2FsYXJ5SW5jZW50aXZlIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2Vucm9sbC1tZW51L21vYmlsZS1hcHAtZW5yb2xsXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8TW9iaWxlQXBwRW5yb2xsIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbGVnYWxzLW1lbnUvY28tYXBwbGljYW50XCIsXHJcbiAgICBlbGVtZW50OiA8Q29BcHBsaWNhbnQgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9sZWdhbHMtbWVudS9SZWNlbnQtQXVjdGlvblwiLFxyXG4gICAgZWxlbWVudDogPFJlY2VudEF1Y3Rpb24gLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9sZWdhbHMtbWVudS9SZWNlbnQtTG9hbnNcIixcclxuICAgIGVsZW1lbnQ6IDxMb2FuRG9jdW1lbnRhdGlvbiAvPixcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2xlZ2Fscy1tZW51L3VzZXItZG9jdW1lbnRcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxVc2VyRG9jdW1lbnRzIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcblxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9hcHByb3ZhbC1tZW51L21vYmlsZS1hcHAtZW5yb2xsXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8TW9iaWxlQXBwRW5yb2xsIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3VzZXJcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxVc2VyIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3Zpc2l0b3JzZWN0aW9uXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8VmlzaXRvciAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3Zpc2l0b3ItbGlzdFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFZpc2l0b3JMaXN0IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2N1c3RvbWVyLW1lbnUvdW4tYXBwcm92ZWQtY3VzdG9tZXJcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxVbkFwcHJvdmVkQ3VzdG9tZXIgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9hcHByb3ZhbC1tZW51L3VuLWFwcHJvdmVkLWN1c3RvbWVyXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8VW5BcHByb3ZlZEN1c3RvbWVyIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2FwcHJvdmFsLW1lbnUvdW4tYXBwcm92ZWQtbG9hbnNcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxVbmFwcHJvdmVkTG9hbnMgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi90YXNrXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8VGFzayAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2NoaXQtdXBncmFkZVwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPENoaXRVcGdyYWRlIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3RhcmdldC1tZW51L3RhcmdldFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFRhcmdldCAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2Vucm9sbG1lbnQtcmVxdWVzdC1mb3JtXCIsXHJcbiAgICBlbGVtZW50OiA8RW5yb2xsbWVudFJlcXVlc3RGb3JtIC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbGVnYWxzLW1lbnUvZ3VhcmFudG9yXCIsXHJcbiAgICBlbGVtZW50OiA8R3VhcmFudG9yIC8+LFxyXG4gIH0sXHJcbiAgIHtcclxuICAgIHBhdGg6IFwiL2xlZ2Fscy1tZW51L2xpbmtlZC1ndWFyYW50b3JcIixcclxuICAgIGVsZW1lbnQ6IDxMaW5rZWRHdWFyYW50b3IgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9sZWdhbHMtbWVudVwiLFxyXG4gICAgZWxlbWVudDogPExlZ2Fsc01lbnUgLz4sXHJcbiAgfSxcclxuICAvLyB7XHJcbiAgLy8gICBwYXRoOiBcIi9ncm91cC1tZW51L2ZpbHRlci1ncm91cHNcIixcclxuICAvLyAgIGVsZW1lbnQ6IChcclxuICAvLyAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gIC8vICAgICAgIDxGaWx0ZXJHcm91cHMgLz5cclxuICAvLyAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAvLyAgICksXHJcbiAgLy8gfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9hcHByb3ZhbC1tZW51XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8QWRtaW5BcHByb3ZhbE1lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9oci1tZW51XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8SFJNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvYnJhbmNoZXNcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxCcmFuY2hlcyAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3N0YWZmLW1lbnUvZW1wbG95ZWUtbWVudS9wYXlyb2xsXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UGF5cm9sbCAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3N0YWZmLW1lbnUvZW1wbG95ZWUtbWVudS91bmFwcHJvdmVkLWVtcGxveWVlXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8VW5BcHByb3ZlZEVtcGxveWVlIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51L3NhbGFyeS1tYW5hZ2VtZW50XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIC8vIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgLy8gICA8SFJTYWxhcnlNYW5hZ2VtZW50IC8+XHJcbiAgICAgIC8vIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICAgIDxTdXBlckFkbWluUm91dGU+XHJcbiAgICAgICAgPEhSU2FsYXJ5TWFuYWdlbWVudCAvPlxyXG4gICAgICA8L1N1cGVyQWRtaW5Sb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9jdXN0b21lci1tZW51XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8VXNlck1lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9zdGFmZi1tZW51XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8U3RhZmZNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3BlbmFsdHktbWFuYWdlbWVudFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFBlbmFsdHlNYW5hZ2VtZW50IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvb3RoZXItdHJhbnNhY3Rpb25zXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8VXNlckFjY291bnRzTWVudSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi90YXJnZXQtbWVudVwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFRhcmdldE1lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9lbnJvbGwtbWVudVwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEVucm9sbG1lbnRNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8RW1wbG95ZWVNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51L2VtcGxveWVlXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8RW1wbG95ZWUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9zdGFmZi1tZW51L2VtcGxveWVlLW1lbnUvYWRkLWVtcGxveWVlLWF0dGVuZGFuY2VcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxFbXBsb3llZUF0dGVuZGFuY2UgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9zdGFmZi1tZW51L2VtcGxveWVlLW1lbnUvZW1wbG95ZWUtc3RhdGVtZW50XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxTdXBlckFkbWluUm91dGU+XHJcbiAgICAgICAgPEVtcGxveWVlU3RhdGVtZW50IC8+XHJcbiAgICAgIDwvU3VwZXJBZG1pblJvdXRlID5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi93ZWVrLWdyb3VwXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8V2Vla0dyb3VwIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvY3VzdG9tZXItbWVudS91c2VyXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8VXNlciAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2Vucm9sbC1tZW51L2Vucm9sbG1lbnRcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxFbnJvbGwgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9vdGhlci1zZXJ2aWNlLW1lbnUvXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8T3RoZXJTZXJ2aWNlc01lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9vdGhlci1zZXJ2aWNlLW1lbnUvbG9hblwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPExvYW4gLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9vdGhlci1zZXJ2aWNlLW1lbnUvcGlnbWVcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxQaWdtZSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2F1Y3Rpb25cIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxBdWN0aW9uIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UGF5bWVudE1lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFBheW1lbnQgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnVcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxQYXlPdXRNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L2xvYW4tcGF5b3V0XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8TG9hblBheW1lbnRPdXQgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvcGlnbXktcGF5b3V0XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UGlnbXlQYXltZW50T3V0IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51LzpwYXltZW50VHlwZVwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEdlbmVyYWxQYXltZW50T3V0IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L2NvbW1pc3Npb25cIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxQYXlPdXRDb21taXNzaW9uIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L3NhbGFyeS1wYXltZW50XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxTdXBlckFkbWluUm91dGU+XHJcbiAgICAgICAgPFNhbGFyeVBheW1lbnQgLz5cclxuICAgICAgPC9TdXBlckFkbWluUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIC8vIHN1YnNjcmlwdGlvbnMgcGFnZSByb3V0cyBjYW4gYmUgYWRkZWQgaGVyZVxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3BsYW5zXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UGxhbnMgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9zdWJzY3JpcHRpb25zXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8U3Vic2NyaXB0aW9ucyAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvcGV0dHktQ2FzaFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFBheU91dFBldHR5Q2FzaCAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9hZGRpdGlvbmFsLXNhbGFyeVwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEFkZGl0aW9uYWxTYWxhcnkgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvb3RoZXJzXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UGF5T3V0T3RoZXJzIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvY29sbGVjdGlvbi1tZW51XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8Q29sbGVjdGlvbk1lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9jb2xsZWN0aW9uLW1lbnUvY29sbGVjdGlvbi1hcmVhLXJlcXVlc3RcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxDb2xsZWN0aW9uQXJlYSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2NvbGxlY3Rpb24tbWVudS9jdXN0b21lci1hbGxvY2F0aW9uXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8Q3VzdG9tZXJBbGxvY2F0aW9uIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvc3RhZmYtbWVudS9hZ2VudC1tZW51L2FnZW50XCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8QWdlbnQgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvc3RhZmYtbWVudS9hZ2VudC1tZW51L2FnZW50LXRhcmdldFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEFnZW50VGFyZ2V0IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3N0YWZmLW1lbnUvZW1wbG95ZWUtbWVudS9lbXBsb3llZS10YXJnZXRcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxFbXBsb3llZVRhcmdldCAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9zdGFmZi1tZW51L2FnZW50LW1lbnVcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxBZ2VudE1lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbGVhZFwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPE5hdmJhciAvPlxyXG4gICAgICAgIDxMZWFkIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2xlYWQtc2V0dGluZ1wiLFxyXG4gICAgZWxlbWVudDogPExlYWRTZXR0aW5nIC8+LFxyXG4gICAgY2hpbGRyZW46IFtcclxuICAgICAge1xyXG4gICAgICAgIGluZGV4OiB0cnVlLFxyXG4gICAgICAgIGVsZW1lbnQ6IDxMZWFkU2V0dGluZ3MgLz4sXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcImFwcC1zZXR0aW5nc1wiLFxyXG4gICAgICAgIGVsZW1lbnQ6IDxBcHBTZXR0aW5ncyAvPixcclxuICAgICAgICBjaGlsZHJlbjogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBwYXRoOiBcImdyb3Vwcy9tb2JpbGUtYWNjZXNzXCIsXHJcbiAgICAgICAgICAgIGVsZW1lbnQ6IDxHcm91cFNldHRpbmdzIC8+LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgcGF0aDogXCJncm91cHMvYXNzZXRcIixcclxuICAgICAgICAgICAgZWxlbWVudDogPERyZWFtQXNzZXQgLz4sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBwYXRoOiBcImdyb3Vwcy9iZWNvbWUtYWdlbnRcIixcclxuICAgICAgICAgICAgZWxlbWVudDogPEJlY29tZUFnZW50IC8+LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9kZXNpZ25hdGlvblwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPERlc2lnbmF0aW9uIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3RyYW5zZmVyLW1lbnVcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxUcmFuc2Zlck1lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi90cmFuc2Zlci1tZW51L3NvZnQtdHJhbnNmZXJcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxTb2Z0VHJhbnNmZXJDdXN0b21lciAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gICxcclxuICB7XHJcbiAgICBwYXRoOiBcIi90cmFuc2Zlci1tZW51L2hhcmQtdHJhbnNmZXJcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxIYXJkVHJhbnNmZXJDdXN0b21lciAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL2FkbWluaXN0cmF0aXZlLXByaXZpbGVnZXNcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxOYXZiYXIgLz5cclxuICAgICAgICA8QWRtaW5pc3RyYXRpdmVQcml2aWxlZ2VzIC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvYWRtaW4tYWNjZXNzLXJpZ2h0c1wiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPE5hdmJhciAvPlxyXG4gICAgICAgIDxBZG1pbkFjY2Vzc1JpZ2h0cyAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIC8vIHtcclxuICAvLyAgIHBhdGg6IFwiL21hcmtldGluZ1wiLFxyXG4gIC8vICAgZWxlbWVudDogKFxyXG4gIC8vICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgLy8gICAgICAgPE5hdmJhciAvPlxyXG4gIC8vICAgICAgIDxNYXJrZXRpbmcgLz5cclxuICAvLyAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAvLyAgICksXHJcbiAgLy8gfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9wcm9maWxlXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8TmF2YmFyIC8+XHJcbiAgICAgICAgPFByb2ZpbGUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvcGVuYWx0eS1zZXR0aW5nc1wiLFxyXG4gICAgZWxlbWVudDogPFBlbmFsdHlTZXR0aW5ncyAvPixcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9wZW5hbHR5LW1vbml0b3JcIixcclxuICAgIGVsZW1lbnQ6IDxQZW5hbHR5TW9uaXRvciAvPixcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9naWZ0LXJlY2VpdmVkXCIsXHJcbiAgICBlbGVtZW50OiA8Q3VzdG9tZXJSZXdhcmRzIC8+LFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3JlcG9ydHNcIixcclxuICAgIGVsZW1lbnQ6IDxSZXBvcnRzIC8+LFxyXG4gICAgY2hpbGRyZW46IFtcclxuXHJcblxyXG4gICAgICB7IHBhdGg6IFwiZGF5Ym9va1wiLCBlbGVtZW50OiA8RGF5Ym9vayAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwicGF5b3V0XCIsIGVsZW1lbnQ6IDxQYXlPdXRSZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcInNhbGVzLXJlcG9ydFwiLCBlbGVtZW50OiA8U2FsZXNSZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcInBpZ215LXN1bW1hcnktcmVwb3J0XCIsIGVsZW1lbnQ6IDxQaWdteVN1bW1hcnlSZXBvcnQgLz4gfSxcclxuICAgICAgLy8geyBwYXRoOiBcInJlY2VpcHRcIiwgZWxlbWVudDogPFJlY2VpcHQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcInJlY2VpcHQtcmVwb3J0XCIsIGVsZW1lbnQ6IDxQYXltZW50UmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJjdXN0b21lci1ldmVudC1sb2dnZXItcmVwb3J0XCIsIGVsZW1lbnQ6IDxVc2VyRXZlbnRMb2dnZXIgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImNvbGxlY3Rpb24tZXhlY3V0aXZlXCIsIGVsZW1lbnQ6IDxDb2xsZWN0aW9uRXhlY3V0aXZlUmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJjb2xsZWN0aW9uLWFyZWEtcmVwb3J0XCIsIGVsZW1lbnQ6IDxDb2xsZWN0aW9uQXJlYVJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwicmVnaXN0cmF0aW9uLWZlZS1yZWNlaXB0XCIsIGVsZW1lbnQ6IDxSZWdpc3RyYXRpb25GZWVSZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImdyb3VwLXJlcG9ydFwiLCBlbGVtZW50OiA8R3JvdXBSZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImFsbC1ncm91cC1yZXBvcnRcIiwgZWxlbWVudDogPEFsbEdyb3VwUmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJhdWN0aW9uLXJlcG9ydFwiLCBlbGVtZW50OiA8QXVjdGlvblJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiYXVjdGlvbi1yZXBvcnRcIiwgZWxlbWVudDogPEF1Y3Rpb25SZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImxlYWQtcmVwb3J0XCIsIGVsZW1lbnQ6IDxMZWFkUmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJsb2FuLXBheW91dC1yZXBvcnRcIiwgZWxlbWVudDogPExvYW5QYXlvdXRSZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcInBheW91dC1yZXBvcnRcIiwgZWxlbWVudDogPENoaXRQYXlvdXRSZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImN1c3RvbWVyLXJlcG9ydFwiLCBlbGVtZW50OiA8VXNlclJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiaW5hY3RpdmUtdXNlci1yZXBvcnRcIiwgZWxlbWVudDogPEluQWN0aXZlVXNlclJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiYWxsLXVzZXItcmVwb3J0XCIsIGVsZW1lbnQ6IDxBbGxVc2VyUmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJsb2FuLXJlcG9ydFwiLCBlbGVtZW50OiA8TG9hblJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwicGlnbWUtcmVwb3J0XCIsIGVsZW1lbnQ6IDxQaWdtZVJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiZW1wbG95ZWUtcmVwb3J0XCIsIGVsZW1lbnQ6IDxFbXBsb3llZVJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiY29tbWlzc2lvbi1yZXBvcnRcIiwgZWxlbWVudDogPENvbW1pc3Npb25SZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImVucm9sbG1lbnQtcmVwb3J0XCIsIGVsZW1lbnQ6IDxFbnJvbGxtZW50UmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJwaW5jb2RlLXJlcG9ydFwiLCBlbGVtZW50OiA8UGluY29kZVJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwicGF5bWVudC1zdW1tYXJ5XCIsIGVsZW1lbnQ6IDxQYXltZW50U3VtbWFyeSAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiaG9sZGVkLWN1c3RvbWVyLXJlcG9ydFwiLCBlbGVtZW50OiA8SG9sZGVkQ3VzdG9tZXJSZXBvcnQgLz4gfSxcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6IFwidHJhbnNhY3Rpb24taGlzdG9yeVwiLFxyXG4gICAgICAgIGVsZW1lbnQ6IDxUcmFuc2FjdGlvbkhpc3RvcnkgLz4sXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcImNvbGxlY3Rpb24tZXhlY3V0aXZlLXN1bW1hcnlcIiwgZWxlbWVudDogPENoaXRDb2xsZWN0aW9uRXhlY3V0aXZlUmVwb3J0IC8+LFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogXCJtb250aGx5LWluc3RhbGwtdHVybm92ZXJcIixcclxuICAgICAgICBlbGVtZW50OiA8TW9udGhseUluc3RhbGxtZW50VHVybm92ZXJSZXBvcnQgLz4sXHJcbiAgICAgIH0sXHJcbiAgICAgIHsgcGF0aDogXCJlbXBsb3llZS1tb250aGx5LXJlcG9ydFwiLCBlbGVtZW50OiA8RW1wbG95ZWVNb250aGx5UmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJjdXN0b21lci1sb2FuLXJlcG9ydFwiLCBlbGVtZW50OiA8Q3VzdG9tZXJMb2FuUmVwb3J0IC8+IH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcInVudmVyaWZpZWQtY3VzdG9tZXItcmVwb3J0XCIsXHJcbiAgICAgICAgZWxlbWVudDogPFVuQXBwcm92ZWRDdXN0b21lclJlcG9ydCAvPixcclxuICAgICAgfSxcclxuICAgICAgeyBwYXRoOiBcInBheW1lbnQtcmVwb3J0XCIsIGVsZW1lbnQ6IDxQYXltZW50UmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJwcml6ZWQtY3VzdG9tZXItcmVwb3J0XCIsIGVsZW1lbnQ6IDxQcml6ZWRDdXN0b21lclJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiY2hpdC1jYW5jZWxsYXRpb24tcmVwb3J0XCIsIGVsZW1lbnQ6IDxDaGl0Q2FuY2VsbGF0aW9uUmVwb3J0IC8+IH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcIm91dHN0YW5kaW5nLXJlcG9ydFwiLFxyXG4gICAgICAgIGVsZW1lbnQ6IDxPdXRzdGFuZGluZ1JlcG9ydCAvPixcclxuICAgICAgfSxcclxuICAgICAgeyBwYXRoOiBcImNoaXQtYXNraW5nLW1vbnRoLXJlcG9ydFwiLCBlbGVtZW50OiA8Q2hpdEFza2luZ01vbnRoUmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJwYXlvdXQtc2FsYXJ5LXJlcG9ydFwiLCBlbGVtZW50OiA8UGF5b3V0U2FsYXJ5UmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJjdXN0b21lci1hcmVhLXJlcG9ydFwiLCBlbGVtZW50OiA8Q3VzdG9tZXJBcmVhUmVwb3J0IC8+IH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcInRhcmdldC1pbmNlbnRpdmVcIixcclxuICAgICAgICBlbGVtZW50OiA8VGFyZ2V0SW5jZW50aXZlUmVwb3J0IC8+LFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogXCJ0YXJnZXQtY29tbWlzc2lvblwiLFxyXG4gICAgICAgIGVsZW1lbnQ6IDxUYXJnZXRDb21taXNzaW9uIC8+LFxyXG4gICAgICB9LFxyXG4gICAgICB7IHBhdGg6IFwic2FsYXJ5LXJlbWFpbmluZ1wiLCBlbGVtZW50OiA8U2FsYXJ5UmVtYWluaW5nUmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJub24tY29udmVydGVkLWxlYWQtcmVwb3J0XCIsIGVsZW1lbnQ6IDxOb25Db252ZXJ0ZWRMZWFkIC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJjb252ZXJ0ZWQtbGVhZC1yZXBvcnRcIiwgZWxlbWVudDogPENvbnZlcnRlZExlYWQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImVtcGxveWVlLXNhbGFyeS1yZXBvcnRcIiwgZWxlbWVudDogPEVtcGxveWVlU2FsYXJ5UmVwb3J0IC8+IH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcInVzZXItcmVnaXN0cmF0aW9uLXNvdXJjZS1zdW1tYXJ5LXJlcG9ydFwiLFxyXG4gICAgICAgIGVsZW1lbnQ6IDxVc2VyUmVnaXN0cmF0aW9uU291cmNlU3VtbWFyeVJlcG9ydCAvPixcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6IFwiY2hpdGNvbGxlY3Rpb24taW5jZW50aXZlXCIsXHJcbiAgICAgICAgZWxlbWVudDogPENoaXRDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0IC8+LFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogXCJsb2FuY29sbGVjdGlvbi1pbmNlbnRpdmVcIixcclxuICAgICAgICBlbGVtZW50OiA8TG9hbkNvbGxlY3Rpb25JbmNlbnRpdmVSZXBvcnQgLz4sXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcImN1c3RvbWVyLXBheW1lbnQtdHJhY2tpbmctcmVwb3J0XCIsIGVsZW1lbnQ6IDxDdXN0b21lclRyYWNraW5nUmVwb3J0IC8+XHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcInBpZ215Y29sbGVjdGlvbi1pbmNlbnRpdmVcIixcclxuICAgICAgICBlbGVtZW50OiA8UGlnbXlDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0IC8+LFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogXCJlbXBsb3llZS1kZWR1Y3Rpb24tcmVwb3J0XCIsXHJcbiAgICAgICAgZWxlbWVudDogPEVtcGxveWVlRGVkdWN0aW9uUmVwb3J0IC8+LFxyXG4gICAgICB9LFxyXG4gICAgICB7IHBhdGg6IFwicmVkZW10aW9uLXBvaW50c1wiLCBlbGVtZW50OiA8UmVkZW1wdGlvblBvaW50c1JlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwibG9hbi1jb21wbGV0aW9uLXJlcG9ydFwiLCBlbGVtZW50OiA8TG9hbkNvbXBsZXRpb25SZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImxvYW4tZHVlLXJlcG9ydFwiLCBlbGVtZW50OiA8RHVlTG9hblJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiZGF0ZS13aXNlLXJld2FyZC1wb2ludHNcIiwgZWxlbWVudDogPERhdGVXaXNlUmV3YXJkcmVwb3J0IC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJhdWN0aW9uLWZpbHRlci1yZXBvcnRcIiwgZWxlbWVudDogPEF1Y3Rpb25GaWx0ZXJSZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImJpZC1yZXF1ZXN0LXJlcG9ydFwiLCBlbGVtZW50OiA8QmlkUmVxdWVzdFJlcG9ydCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwibW9iaWxlLWFwcC1pbnN0YWxsc1wiLCBlbGVtZW50OiA8Q3VzdG9tZXJBcHBJbnN0YWxsYXRpb24gLz4gfSxcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6IFwidGFyZ2V0LWluY2VudGl2ZS1uZXdcIixcclxuICAgICAgICBlbGVtZW50OiA8VGFyZ2V0SW5jZW50aXZlTmV3UmVwb3J0IC8+LFxyXG4gICAgICB9LFxyXG4gICAgICB7IHBhdGg6IFwicGlnbXktcGF5b3V0LXJlcG9ydFwiLCBlbGVtZW50OiA8UGlnbXlQYXlvdXRSZXBvcnQgLz4gfSxcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6IFwic3VzcGVuZC1yZXBvcnRcIixcclxuICAgICAgICBlbGVtZW50OiA8U3VzcGVuZGVkQ3VzdG9tZXJSZXBvcnQgLz4sXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcImVtcGxveWVlLWN1c3RvbWVyLXJlZmVycmFsLXJlcG9ydFwiLFxyXG4gICAgICAgIGVsZW1lbnQ6IDxFbXBsb3llZVJlZmVycmVkQ3VzdG9tZXJzIC8+XHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcImVtcGxveWVlLWNvbGxlY3Rpb24tY3VzdG9tZXItcmVwb3J0XCIsXHJcbiAgICAgICAgZWxlbWVudDogPEVtcGxveWVlQ29sbGVjdGlvbkN1c3RvbWVyUmVwb3J0IC8+XHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcImVtcGxveWVlLXJlbGF0aW9uc2hpcC1tYW5hZ2VyLXJlcG9ydFwiLFxyXG4gICAgICAgIGVsZW1lbnQ6IDxFbXBsb3llZVJlbGF0aW9uc2hpcE1hbmFnZXJSZXBvcnQgLz4sXHJcbiAgICAgIH0sXHJcbiAgICAgIHsgcGF0aDogXCJnc3Qtc2VydmljZS1jaGFyZ2VcIiwgZWxlbWVudDogPEdTVFNlcnZpY2VDaGFyZ2VSZXBvcnQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImN1c3RvbWVyLXZpc2l0LXRyYWNrZXJcIiwgZWxlbWVudDogPEN1c3RvbWVyVmlzaXRUcmFja2VyUmVwb3J0IC8+IH0sXHJcbiAgICBdLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3RhcmdldC1jb21taXNzaW9uLWluY2VudGl2ZVwiLFxyXG4gICAgZWxlbWVudDogPFRhcmdldFBheU91dENvbW1pc3Npb25JbmNlbnRpdmUgLz4sXHJcbiAgfSxcclxuICAvLyB7XHJcbiAgLy8gICBwYXRoOiBcIi90YXJnZXQtcGF5b3V0LW1lbnVcIixcclxuICAvLyAgIGVsZW1lbnQ6IDxUYXJnZXRQYXlPdXRNZW51IC8+LFxyXG4gIC8vIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvdGFyZ2V0LXBheW91dC1zYWxhcnlcIixcclxuICAgIGVsZW1lbnQ6IDxUYXJnZXRQYXlPdXRTYWxhcnkgLz4sXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgcGF0aDogXCIvaW5zdXJhbmNlXCIsXHJcbiAgICBlbGVtZW50OiA8SW5zdXJhbmNlIC8+LFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3ByaW50LzppZFwiLFxyXG5cclxuICAgIGVsZW1lbnQ6IDxQcmludCAvPixcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL3NhbGFyeS1zbGlwLXByaW50LzppZFwiLFxyXG5cclxuICAgIGVsZW1lbnQ6IDxTYWxhcnlTbGlwUHJpbnQgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXRpbmctbWVudVwiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPE1hcmtldGluZ01lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS9lbWFpbC1tYXJrZXRpbmdcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxFbWFpbE1hcmtldGluZ01lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS9wYXltZW50LWxpbmstbWFya2V0aW5nXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UGF5bWVudExpbmtNYXJrZXRpbmdNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8V2hhdHNhcHBNYXJrZXRpbmdNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2R1ZS13aGF0c2FwcC1tYXJrZXRpbmdcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxEdWVXaGF0c2FwcE1lc3NhZ2VNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2xlYWQtd2hhdHNhcHAtbWFya2V0aW5nXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8TGVhZFdoYXRzYXBwTWVzc2FnZU1lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvY3VzdG9tZXItd2hhdHNhcHAtbWFya2V0aW5nXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8Q3VzdG9tZXJXaGF0c2FwcE1lc3NhZ2VNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIHBhdGg6IFwiL21hcmtldC1tZW51L3doYXRzYXBwLW1hcmtldGluZy9hdWN0aW9uLXdoYXRzYXBwLW1hcmtldGluZ1wiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPEF1Y3Rpb25XaGF0c2FwcE1lc3NhZ2VNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL3Byb21vLXdoYXRzYXBwLW1hcmtldGluZ1wiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFByb21vdGlvbldoYXRzYXBwTWVzc2FnZU1lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvcGVuYWx0eS13aGF0c2FwcC1tYXJrZXRpbmdcIixcclxuICAgIGVsZW1lbnQ6IChcclxuICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgIDxQZW5hbHR5V2hhdHNhcHBNZXNzYWdlTWVudSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL21hcmtldC1tZW51L2VtYWlsLW1hcmtldGluZy9kdWUtZW1haWwtbWFya2V0aW5nXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8RHVlRW1haWxNZW51IC8+XHJcbiAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICApLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvc21zLW1hcmtldGluZ1wiLFxyXG4gICAgZWxlbWVudDogKFxyXG4gICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgPFNNU01hcmtldGluZ01lbnUgLz5cclxuICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS9yY3MtbWFya2V0aW5nXCIsXHJcbiAgICBlbGVtZW50OiAoXHJcbiAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICA8UkNTTWFya2V0aW5nTWVudSAvPlxyXG4gICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgKSxcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS9lbWFpbC1tYXJrZXRpbmcvZHVlLWVtYWlsLW1hcmtldGluZy9kdWUtZW1haWxcIixcclxuICAgIGVsZW1lbnQ6IDxEdWVFbWFpbCAvPixcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL21hcmtldC1tZW51L2VtYWlsLW1hcmtldGluZy9kdWUtZW1haWwtbWFya2V0aW5nL292ZXItZHVlLWVtYWlsXCIsXHJcbiAgICBlbGVtZW50OiA8T3ZlckR1ZUVtYWlsIC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL3doYXQtYWRkXCIsXHJcbiAgICBlbGVtZW50OiA8V2hhdHNhcHBBZGQgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvZmFpbGVkLXdoYXR1c2VyXCIsXHJcbiAgICBlbGVtZW50OiA8V2hhdHNhcHBGYWlsZWQgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvZHVlLXdoYXRzYXBwLW1hcmtldGluZy9kdWUtbWVzc2FnZVwiLFxyXG4gICAgZWxlbWVudDogPER1ZU1lc3NhZ2UgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvYXVjdGlvbi13aGF0c2FwcC1tYXJrZXRpbmcvYXVjdGlvbi1pbnRpbWF0aW9uLW1lc3NhZ2VcIixcclxuICAgIGVsZW1lbnQ6IDxBdWN0aW9uSW50ZW1hdGlvbk1lc3NhZ2UgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvZHVlLXdoYXRzYXBwLW1hcmtldGluZy9vdmVyLWR1ZS1tZXNzYWdlXCIsXHJcbiAgICBlbGVtZW50OiA8T3ZlckR1ZU1lc3NhZ2UgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvcHJvbW8td2hhdHNhcHAtbWFya2V0aW5nL3doYXQtcHJvbW9cIixcclxuICAgIGVsZW1lbnQ6IDxXaGF0c2FwcFByb21vIC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24td2hhdHNhcHAtbWFya2V0aW5nL2JpZC13aW5uZXJcIixcclxuICAgIGVsZW1lbnQ6IDxCaWRXaW5uZXIgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS9wYXltZW50LWxpbmstbWFya2V0aW5nL3BheW1lbnQtbGlua1wiLFxyXG4gICAgZWxlbWVudDogPFBheW1lbnRMaW5rIC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24td2hhdHNhcHAtbWFya2V0aW5nL2JpZC1zdGF0dXNcIixcclxuICAgIGVsZW1lbnQ6IDxBdWN0aW9uQmlkU3RhdHVzIC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24td2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24taW5mb1wiLFxyXG4gICAgZWxlbWVudDogPEF1Y3Rpb25JbmZvcm1hdGlvbiAvPixcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL21hcmtldC1tZW51L3doYXRzYXBwLW1hcmtldGluZy9hdWN0aW9uLXdoYXRzYXBwLW1hcmtldGluZy93aW5uZXItZG9jdW1lbnRcIixcclxuICAgIGVsZW1lbnQ6IDxBdWN0aW9uV2lubmVyRG9jdW1lbnRzIC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24td2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24tdGVybXMtY29uZGl0aW9uXCIsXHJcbiAgICBlbGVtZW50OiA8QXVjdGlvblRlcm1zYW5kQ29uZGl0aW9uIC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2xlYWQtd2hhdHNhcHAtbWFya2V0aW5nL2xlYWQtd2VsY29tZS1tZXNzYWdlXCIsXHJcbiAgICBlbGVtZW50OiA8TGVhZFdoYXRzYXBwV2VsY29tZU1lc3NhZ2UgLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvbGVhZC13aGF0c2FwcC1tYXJrZXRpbmcvbGVhZC1yZWZlcnJlZGJ5LW1lc3NhZ2VcIixcclxuICAgIGVsZW1lbnQ6IDxMZWFkUmVmZXJyZWRCeVdoYXRzYXBwTWVzc2FnZSAvPixcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL21hcmtldC1tZW51L3doYXRzYXBwLW1hcmtldGluZy9jdXN0b21lci13aGF0c2FwcC1tYXJrZXRpbmcvY3VzdG9tZXItd2VsY29tZS1tZXNzYWdlXCIsXHJcbiAgICBlbGVtZW50OiA8Q3VzdG9tZXJXZWxjb21lV2hhdHNhcHBNZXNzYWdlIC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2N1c3RvbWVyLXdoYXRzYXBwLW1hcmtldGluZy9jdXN0b21lci1jaGl0cGxhbi1tZXNzYWdlXCIsXHJcbiAgICBlbGVtZW50OiA8Q3VzdG9tZXJDaGl0UGxhbldoYXRzYXBwTWVzc2FnZSAvPixcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6IFwiL21hcmtldC1tZW51L3doYXRzYXBwLW1hcmtldGluZy9sb2FuLXdoYXRzYXBwLW1hcmtldGluZy9kdWUtbG9hbi1tZXNzYWdlXCIsXHJcbiAgICBlbGVtZW50OiA8RHVlTG9hbldoYXRzYXBwTWVzc2FnZSAvPixcclxuICB9LFxyXG4gIHsgcGF0aDogXCIvYWRkLW5ldy1ncm91cFwiLCBlbGVtZW50OiA8QWRkR3JvdXBGb3JtIC8+IH0sXHJcblxyXG4gIC8vIHtcclxuICAvLyAgIHBhdGg6IFwiL21hcmtldGluZ1wiLFxyXG4gIC8vICAgZWxlbWVudDogKFxyXG4gIC8vICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgLy8gICAgICAgPE5hdmJhciAvPlxyXG4gIC8vICAgICAgIDxNYXJrZXRpbmcgLz5cclxuICAvLyAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAvLyAgICksXHJcbiAgLy8gICBjaGlsZHJlbjogW1xyXG4gIC8vICAgICB7IHBhdGg6IFwid2hhdC1hZGRcIiwgZWxlbWVudDogPFdoYXRzYXBwQWRkIC8+IH0sXHJcbiAgLy8gICAgIHsgcGF0aDogXCJmYWlsZWQtd2hhdHVzZXJcIiwgZWxlbWVudDogPFdoYXRzYXBwRmFpbGVkIC8+IH0sXHJcbiAgLy8gICAgIHsgcGF0aDogXCJkdWUtbWVzc2FnZVwiLCBlbGVtZW50OiA8RHVlTWVzc2FnZSAvPiB9LFxyXG4gIC8vICAgICB7XHJcbiAgLy8gICAgICAgcGF0aDogXCJhdWN0aW9uLWludGltYXRpb24tbWVzc2FnZVwiLFxyXG4gIC8vICAgICAgIGVsZW1lbnQ6IDxBdWN0aW9uSW50ZW1hdGlvbk1lc3NhZ2UgLz4sXHJcbiAgLy8gICAgIH0sXHJcbiAgLy8gICAgIHsgcGF0aDogXCJvdmVyLWR1ZS1tZXNzYWdlXCIsIGVsZW1lbnQ6IDxPdmVyRHVlTWVzc2FnZSAvPiB9LFxyXG4gIC8vICAgICAvLyB7IHBhdGg6IFwiZHVlLWVtYWlsXCIsIGVsZW1lbnQ6IDxEdWVFbWFpbCAvPiB9LFxyXG4gIC8vICAgICAvLyB7IHBhdGg6IFwib3Zlci1kdWUtZW1haWxcIiwgZWxlbWVudDogPE92ZXJEdWVFbWFpbCAvPiB9LFxyXG4gIC8vICAgICB7IHBhdGg6IFwid2hhdC1wcm9tb1wiLCBlbGVtZW50OiA8V2hhdHNhcHBQcm9tbyAvPiB9LFxyXG4gIC8vICAgICB7IHBhdGg6IFwiYmlkLXdpbm5lclwiLCBlbGVtZW50OiA8QmlkV2lubmVyIC8+IH0sXHJcbiAgLy8gICAgIHsgcGF0aDogXCJwYXltZW50LWxpbmtcIiwgZWxlbWVudDogPFBheW1lbnRMaW5rIC8+IH0sXHJcbiAgLy8gICAgICB7cGF0aDogXCJiaWQtc3RhdHVzXCIsIGVsZW1lbnQ6IDxBdWN0aW9uQmlkU3RhdHVzLz59LFxyXG4gIC8vICAgICB7cGF0aDogXCJhdWN0aW9uLWluZm9cIiwgZWxlbWVudDogPEF1Y3Rpb25JbmZvcm1hdGlvbi8+fSxcclxuICAvLyAgICAge3BhdGg6IFwid2lubmVyLWRvY3VtZW50XCIsIGVsZW1lbnQ6IDxBdWN0aW9uV2lubmVyRG9jdW1lbnRzLz59LFxyXG4gIC8vICAgICB7cGF0aDogXCJhdWN0aW9uLXRlcm1zLWNvbmRpdGlvblwiLCBlbGVtZW50OiA8QXVjdGlvblRlcm1zYW5kQ29uZGl0aW9uLz59LFxyXG4gIC8vICAgICB7cGF0aDogXCJsZWFkLXdlbGNvbWUtbWVzc2FnZVwiLCBlbGVtZW50OiA8TGVhZFdoYXRzYXBwV2VsY29tZU1lc3NhZ2UvPn0sXHJcbiAgLy8gICAgIHtwYXRoOiBcImxlYWQtcmVmZXJyZWRieS1tZXNzYWdlXCIsIGVsZW1lbnQ6IDxMZWFkUmVmZXJyZWRCeVdoYXRzYXBwTWVzc2FnZS8+fSxcclxuICAvLyAgICAge3BhdGg6IFwiY3VzdG9tZXItd2VsY29tZS1tZXNzYWdlXCIsIGVsZW1lbnQ6IDxDdXN0b21lcldlbGNvbWVXaGF0c2FwcE1lc3NhZ2UvPn0sXHJcbiAgLy8gICAgIHtwYXRoOiBcImN1c3RvbWVyLWNoaXRwbGFuLW1lc3NhZ2VcIiwgZWxlbWVudDogPEN1c3RvbWVyQ2hpdFBsYW5XaGF0c2FwcE1lc3NhZ2UvPn0sXHJcblxyXG4gIC8vICAgXSxcclxuICAvLyB9LFxyXG5dKTtcclxuZXhwb3J0IGRlZmF1bHQgbWFpblJvdXRlcztcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3JvdXRlcy9tYWluUm91dGVzLmpzeCJ9