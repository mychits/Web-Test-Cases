import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/GroupSettings.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { EyeIcon } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
const GroupSettings = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableGroups, setTableGroups] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [updatingGroups, setUpdatingGroups] = useState(/* @__PURE__ */ new Set());
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [isLoading, setIsLoading] = useState(false);
  const [updateFormData, setUpdateFormData] = useState({
    group_name: "",
    group_type: "",
    group_value: "",
    group_install: "",
    group_members: "",
    group_duration: "",
    start_date: "",
    end_date: "",
    minimum_bid: "",
    maximum_bid: "",
    commission: 5,
    reg_fee: ""
  });
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
        const formattedData = response.data.map((group, index) => ({
          checkBox: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV("div", { className: "border border-red-400 text-white px-4 py-2 rounded-md shadow hover:border-red-700 transition duration-200", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              checked: group.mobile_access,
              onChange: () => handleMobileAccessChange(group._id, !group.mobile_access),
              disabled: updatingGroups.has(group._id),
              className: "form-checkbox h-4 w-4 text-red-600 focus:ring-0 focus:ring-offset-0 focus:outline-none checked:bg-red-600 border-gray-300 rounded"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
              lineNumber: 49,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
            lineNumber: 48,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
            lineNumber: 47,
            columnNumber: 11
          }, this),
          id: index + 1,
          name: group.group_name,
          type: `${group.group_type.charAt(0).toUpperCase()}${group.group_type.slice(1)} Group`,
          value: group.group_value,
          installment: group.group_install,
          members: group.group_members,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handleUpdateModalOpen(group._id),
              className: "border border-green-400 text-white px-4 py-2 rounded-md shadow hover:border-green-700 transition duration-200",
              children: /* @__PURE__ */ jsxDEV(EyeIcon, { color: "green" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                lineNumber: 75,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
              lineNumber: 71,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
            lineNumber: 70,
            columnNumber: 11
          }, this)
        }));
        setTableGroups(formattedData);
      } catch (error) {
        console.error("Error fetching group data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchGroups();
  }, [updatingGroups, reloadTrigger]);
  const handleMobileAccessChange = async (groupId, newValue) => {
    setUpdatingGroups((prev) => /* @__PURE__ */ new Set([...prev, groupId]));
    try {
      setGroups(
        (prev) => prev.map(
          (group) => group._id === groupId ? { ...group, mobile_access: newValue } : group
        )
      );
      await api.patch(`/group/update-mobile-access/${groupId}`, {
        mobile_access: newValue
      });
      const response = await api.get("/group/get-group-admin");
      setGroups(response.data);
    } catch (error) {
      setGroups(
        (prev) => prev.map(
          (group) => group._id === groupId ? { ...group, mobile_access: !newValue } : group
        )
      );
      console.error("Error updating mobile access:", error);
      setAlertConfig({
        message: "Failed to update mobile access",
        type: "error",
        visibility: true
      });
    } finally {
      setUpdatingGroups((prev) => {
        const newSet = new Set(prev);
        newSet.delete(groupId);
        return newSet;
      });
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/group/get-by-id-group/${groupId}`);
      const groupData = response.data;
      const formattedStartDate = groupData.start_date.split("T")[0];
      const formattedEndDate = groupData.end_date.split("T")[0];
      setCurrentUpdateGroup(response.data);
      setUpdateFormData({
        group_name: response.data.group_name,
        group_type: response.data.group_type,
        group_value: response.data.group_value,
        group_install: response.data.group_install,
        group_members: response.data.group_members,
        group_duration: response.data.group_duration,
        start_date: formattedStartDate,
        end_date: formattedEndDate,
        minimum_bid: response.data.minimum_bid,
        maximum_bid: response.data.maximum_bid,
        reg_fee: response.data.reg_fee
      });
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching group:", error);
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        await api.put(
          `/group/update-group/${currentUpdateGroup._id}`,
          updateFormData
        );
        setShowModalUpdate(false);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Group updated successfully",
          type: "success",
          visibility: true
        });
      }
    } catch (error) {
      console.error("Error updating group:", error);
    }
  };
  const columns = [
    { key: "checkBox", header: "Mobile Access" },
    { key: "id", header: "SL. NO" },
    { key: "name", header: "Group Name" },
    { key: "type", header: "Group Type" },
    { key: "value", header: "Group Value" },
    { key: "installment", header: "Group Installment" },
    { key: "members", header: "Group Members" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
        lineNumber: 191,
        columnNumber: 10
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Groups" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
        lineNumber: 203,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
        lineNumber: 202,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
        lineNumber: 201,
        columnNumber: 13
      }, this),
      TableGroups.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: TableGroups,
          columns,
          exportedFileName: `Groups-${TableGroups.length > 0 ? TableGroups[0].name + " to " + TableGroups[TableGroups.length - 1].name : "empty"}.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
          lineNumber: 207,
          columnNumber: 13
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          failure: TableGroups.length <= 0,
          data: "Group Data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
          lineNumber: 219,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
        lineNumber: 226,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
      lineNumber: 200,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
      lineNumber: 199,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
            lineNumber: 234,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "Group Name"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                  lineNumber: 237,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "group_name",
                  value: updateFormData.group_name,
                  id: "name",
                  placeholder: "Enter the Group Name",
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                  lineNumber: 243,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
              lineNumber: 236,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Group Type"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                  lineNumber: 254,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "group_type",
                  value: updateFormData.group_type || "",
                  readOnly: true,
                  id: "category",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { readOnly: true, value: "", children: "Select Group Type" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                      lineNumber: 267,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { readOnly: true, value: "divident", children: "Dividend Group" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                      lineNumber: 270,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { readOnly: true, value: "double", children: "Double Group" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                      lineNumber: 273,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                  lineNumber: 260,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
              lineNumber: 253,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Group Value"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 281,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "group_value",
                    value: updateFormData.group_value,
                    id: "text",
                    placeholder: "Enter Group Value",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 287,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                lineNumber: 280,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Group Installment Amount"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 298,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "group_install",
                    value: updateFormData.group_install,
                    id: "text",
                    placeholder: "Enter Group Installment Amount",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 304,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                lineNumber: 297,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
              lineNumber: 279,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Group Members"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 317,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "group_members",
                    value: updateFormData.group_members,
                    id: "text",
                    placeholder: "Enter Group Members",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 323,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                lineNumber: 316,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Group Duration"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 334,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "group_duration",
                    value: updateFormData.group_duration,
                    readOnly: true,
                    id: "text",
                    placeholder: "Enter Group Duration",
                    required: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 340,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                lineNumber: 333,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
              lineNumber: 315,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "Registration Fee"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                  lineNumber: 353,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "reg_fee",
                  value: updateFormData.reg_fee,
                  id: "name",
                  placeholder: "Enter the Registration Fee",
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                  lineNumber: 359,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
              lineNumber: 352,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Start Date"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 371,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "start_date",
                    value: updateFormData.start_date,
                    id: "date",
                    placeholder: "Enter the Date",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 377,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                lineNumber: 370,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "End Date"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 388,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "end_date",
                    value: updateFormData.end_date,
                    readOnly: true,
                    id: "date",
                    placeholder: "Enter the Date",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 394,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                lineNumber: 387,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
              lineNumber: 369,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Minimum Bid %"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 407,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "minimum_bid",
                    value: updateFormData.minimum_bid,
                    readOnly: true,
                    id: "text",
                    placeholder: "Enter Minimum Bid",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 413,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                lineNumber: 406,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Maximum Bid %"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 424,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "maximum_bid",
                    value: updateFormData.maximum_bid,
                    readOnly: true,
                    id: "text",
                    placeholder: "Enter Maximum Bid",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                    lineNumber: 430,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
                lineNumber: 423,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
              lineNumber: 405,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
            lineNumber: 235,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
          lineNumber: 233,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
        lineNumber: 229,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
    lineNumber: 190,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx",
    lineNumber: 189,
    columnNumber: 5
  }, this);
};
_s(GroupSettings, "hY+++TV/Mf9He0WBCnh+U8cIa8U=");
_c = GroupSettings;
export default GroupSettings;
var _c;
$RefreshReg$(_c, "GroupSettings");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupSettings.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0RnQixTQTRJWixVQTVJWTsyQkFoRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLFNBQVNDLGVBQWU7QUFDeEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLG9CQUFvQjtBQUUzQixNQUFNQyxnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSVYsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ1csYUFBYUMsY0FBYyxJQUFJWixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDYSxZQUFZQyxhQUFhLElBQUlkLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNlLGlCQUFpQkMsa0JBQWtCLElBQUloQixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDaUIsb0JBQW9CQyxxQkFBcUIsSUFBSWxCLFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUNtQixnQkFBZ0JDLGlCQUFpQixJQUFJcEIsU0FBUyxvQkFBSXFCLElBQUksQ0FBQztBQUM5RCxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJdkIsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQ3dCLGFBQWFDLGNBQWMsSUFBSXpCLFNBQVM7QUFBQSxJQUM3QzBCLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJOUIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQytCLGdCQUFnQkMsaUJBQWlCLElBQUloQyxTQUFTO0FBQUEsSUFDbkRpQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxlQUFlO0FBQUEsSUFDZkMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsVUFBVTtBQUFBLElBQ1ZDLGFBQWE7QUFBQSxJQUNiQyxhQUFhO0FBQUEsSUFDYkMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFFRDdDLFlBQVUsTUFBTTtBQUNkLFVBQU04QyxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGZixxQkFBYSxJQUFJO0FBQ2pCLGNBQU1nQixXQUFXLE1BQU0zQyxJQUFJNEMsSUFBSSx3QkFBd0I7QUFDdkRyQyxrQkFBVW9DLFNBQVNFLElBQUk7QUFDdkIsY0FBTUMsZ0JBQWdCSCxTQUFTRSxLQUFLRSxJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxVQUN6REMsVUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2IsaUNBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTRixNQUFNRztBQUFBQSxjQUNmLFVBQVUsTUFDUkMseUJBQXlCSixNQUFNSyxLQUFLLENBQUNMLE1BQU1HLGFBQWE7QUFBQSxjQUUxRCxVQUFVbkMsZUFBZXNDLElBQUlOLE1BQU1LLEdBQUc7QUFBQSxjQUN0QyxXQUFVO0FBQUE7QUFBQSxZQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU8rSSxLQVJqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBRUZFLElBQUlOLFFBQVE7QUFBQSxVQUNaTyxNQUFNUixNQUFNbEI7QUFBQUEsVUFDWkwsTUFBTSxHQUFHdUIsTUFBTWpCLFdBQ1owQixPQUFPLENBQUMsRUFDUkMsWUFBWSxDQUFDLEdBQUdWLE1BQU1qQixXQUFXNEIsTUFBTSxDQUFDLENBQUM7QUFBQSxVQUM1Q0MsT0FBT1osTUFBTWhCO0FBQUFBLFVBQ2I2QixhQUFhYixNQUFNZjtBQUFBQSxVQUNuQjZCLFNBQVNkLE1BQU1kO0FBQUFBLFVBQ2Y2QixRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNQyxzQkFBc0JoQixNQUFNSyxHQUFHO0FBQUEsY0FDOUMsV0FBVTtBQUFBLGNBRVYsaUNBQUMsV0FBUSxPQUFNLFdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0I7QUFBQTtBQUFBLFlBSnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFFBRUosRUFBRTtBQUNGNUMsdUJBQWVxQyxhQUFhO0FBQUEsTUFDOUIsU0FBU21CLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQsVUFBQztBQUNDdEMscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBZSxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDMUIsZ0JBQWdCRyxhQUFhLENBQUM7QUFFbEMsUUFBTWlDLDJCQUEyQixPQUFPZSxTQUFTQyxhQUFhO0FBQzVEbkQsc0JBQWtCLENBQUNvRCxTQUFTLG9CQUFJbkQsSUFBSSxDQUFDLEdBQUdtRCxNQUFNRixPQUFPLENBQUMsQ0FBQztBQUV2RCxRQUFJO0FBQ0Y1RDtBQUFBQSxRQUFVLENBQUM4RCxTQUNUQSxLQUFLdEI7QUFBQUEsVUFBSSxDQUFDQyxVQUNSQSxNQUFNSyxRQUFRYyxVQUFVLEVBQUUsR0FBR25CLE9BQU9HLGVBQWVpQixTQUFTLElBQUlwQjtBQUFBQSxRQUNsRTtBQUFBLE1BQ0Y7QUFFQSxZQUFNaEQsSUFBSXNFLE1BQU0sK0JBQStCSCxPQUFPLElBQUk7QUFBQSxRQUN4RGhCLGVBQWVpQjtBQUFBQSxNQUNqQixDQUFDO0FBRUQsWUFBTXpCLFdBQVcsTUFBTTNDLElBQUk0QyxJQUFJLHdCQUF3QjtBQUN2RHJDLGdCQUFVb0MsU0FBU0UsSUFBSTtBQUFBLElBQ3pCLFNBQVNvQixPQUFPO0FBQ2QxRDtBQUFBQSxRQUFVLENBQUM4RCxTQUNUQSxLQUFLdEI7QUFBQUEsVUFBSSxDQUFDQyxVQUNSQSxNQUFNSyxRQUFRYyxVQUFVLEVBQUUsR0FBR25CLE9BQU9HLGVBQWUsQ0FBQ2lCLFNBQVMsSUFBSXBCO0FBQUFBLFFBQ25FO0FBQUEsTUFDRjtBQUNBa0IsY0FBUUQsTUFBTSxpQ0FBaUNBLEtBQUs7QUFDcEQzQyxxQkFBZTtBQUFBLFFBQ2JFLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsUUFFTkYsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDTix3QkFBa0IsQ0FBQ29ELFNBQVM7QUFDMUIsY0FBTUUsU0FBUyxJQUFJckQsSUFBSW1ELElBQUk7QUFDM0JFLGVBQU9DLE9BQU9MLE9BQU87QUFDckIsZUFBT0k7QUFBQUEsTUFDVCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNUCx3QkFBd0IsT0FBT0csWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTXhCLFdBQVcsTUFBTTNDLElBQUk0QyxJQUFJLDBCQUEwQnVCLE9BQU8sRUFBRTtBQUNsRSxZQUFNTSxZQUFZOUIsU0FBU0U7QUFDM0IsWUFBTTZCLHFCQUFxQkQsVUFBVXJDLFdBQVd1QyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzVELFlBQU1DLG1CQUFtQkgsVUFBVXBDLFNBQVNzQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3hENUQsNEJBQXNCNEIsU0FBU0UsSUFBSTtBQUNuQ2hCLHdCQUFrQjtBQUFBLFFBQ2hCQyxZQUFZYSxTQUFTRSxLQUFLZjtBQUFBQSxRQUMxQkMsWUFBWVksU0FBU0UsS0FBS2Q7QUFBQUEsUUFDMUJDLGFBQWFXLFNBQVNFLEtBQUtiO0FBQUFBLFFBQzNCQyxlQUFlVSxTQUFTRSxLQUFLWjtBQUFBQSxRQUM3QkMsZUFBZVMsU0FBU0UsS0FBS1g7QUFBQUEsUUFDN0JDLGdCQUFnQlEsU0FBU0UsS0FBS1Y7QUFBQUEsUUFDOUJDLFlBQVlzQztBQUFBQSxRQUNackMsVUFBVXVDO0FBQUFBLFFBQ1Z0QyxhQUFhSyxTQUFTRSxLQUFLUDtBQUFBQSxRQUMzQkMsYUFBYUksU0FBU0UsS0FBS047QUFBQUEsUUFDM0JFLFNBQVNFLFNBQVNFLEtBQUtKO0FBQUFBLE1BQ3pCLENBQUM7QUFDRDVCLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBU29ELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNWSxlQUFlLE9BQU9DLE1BQU07QUFDaENBLE1BQUVDLGVBQWU7QUFDakIsVUFBTUMsVUFBVUMsYUFBYTtBQUU3QixRQUFJO0FBQ0YsVUFBSUQsU0FBUztBQUNYLGNBQU1oRixJQUFJa0Y7QUFBQUEsVUFDUix1QkFBdUJwRSxtQkFBbUJ1QyxHQUFHO0FBQUEsVUFDN0N6QjtBQUFBQSxRQUNGO0FBQ0FmLDJCQUFtQixLQUFLO0FBQ3hCTyx5QkFBaUIsQ0FBQ2lELFNBQVNBLE9BQU8sQ0FBQztBQUNuQy9DLHVCQUFlO0FBQUEsVUFDYkUsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxVQUNORixZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBUzBDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNa0IsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxZQUFZQyxRQUFRLGdCQUFnQjtBQUFBLElBQzNDLEVBQUVELEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGFBQWE7QUFBQSxJQUNwQyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsYUFBYTtBQUFBLElBQ3BDLEVBQUVELEtBQUssU0FBU0MsUUFBUSxjQUFjO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLG9CQUFvQjtBQUFBLElBQ2xELEVBQUVELEtBQUssV0FBV0MsUUFBUSxnQkFBZ0I7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNBLE1BQU1oRSxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQytDLFVBQVUsRUFBRSxHQUFHQSxNQUFNOUMsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLE1BTDVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1FO0FBQUEsSUFFSCx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsNENBQ2IsaUNBQUMsUUFBRyxXQUFVLDBCQUF5QixzQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNDZixZQUFZOEUsU0FBUyxLQUFLLENBQUM1RCxZQUM1QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTWxCO0FBQUFBLFVBQ047QUFBQSxVQUNBLGtCQUFrQixVQUNoQkEsWUFBWThFLFNBQVMsSUFDakI5RSxZQUFZLENBQUMsRUFBRWdELE9BQ2YsU0FDQWhELFlBQVlBLFlBQVk4RSxTQUFTLENBQUMsRUFBRTlCLE9BQ3BDLE9BQU87QUFBQTtBQUFBLFFBUmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU1MsSUFHUDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFNBQVNoRCxZQUFZOEUsVUFBVTtBQUFBLFVBQy9CLE1BQU07QUFBQTtBQUFBLFFBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3FCO0FBQUEsTUFJdkIsdUJBQUMsU0FBSSxXQUFVLHlFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUY7QUFBQSxTQTFCdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVzFFO0FBQUFBLFFBQ1gsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBRXZDLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMscUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsVUFDMUQsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVWdFLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFPO0FBQUE7QUFBQSxnQkFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT2pELGVBQWVFO0FBQUFBLGtCQUN0QixJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTzJJO0FBQUEsaUJBZDdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLGdCQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9GLGVBQWVHLGNBQWM7QUFBQSxrQkFDcEM7QUFBQSxrQkFDQSxJQUFHO0FBQUEsa0JBQ0gsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsWUFBTyxVQUFRLE1BQUMsT0FBTSxJQUFHLGlDQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsWUFBTyxVQUFRLE1BQUMsT0FBTSxZQUFXLDhCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsWUFBTyxVQUFRLE1BQUMsT0FBTSxVQUFTLDRCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUE7QUFBQTtBQUFBLGdCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWdCQTtBQUFBLGlCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPSCxlQUFlSTtBQUFBQSxvQkFDdEIsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsa0JBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT0osZUFBZUs7QUFBQUEsb0JBQ3RCLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTzJJO0FBQUEsbUJBZDdJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsaUJBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLGtCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9MLGVBQWVNO0FBQUFBLG9CQUN0QixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU8ySTtBQUFBLG1CQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPTixlQUFlTztBQUFBQSxvQkFDdEI7QUFBQSxvQkFDQSxJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVEySTtBQUFBLG1CQWY3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGlCQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9DQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLGdCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPUCxlQUFlYTtBQUFBQSxrQkFDdEIsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU8ySTtBQUFBLGlCQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPYixlQUFlUTtBQUFBQSxvQkFDdEIsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsa0JBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT1IsZUFBZVM7QUFBQUEsb0JBQ3RCO0FBQUEsb0JBQ0EsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWixXQUFVO0FBQUE7QUFBQSxrQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTzJJO0FBQUEsbUJBZDdJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsaUJBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLGtCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9ULGVBQWVVO0FBQUFBLG9CQUN0QjtBQUFBLG9CQUNBLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1osV0FBVTtBQUFBO0FBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU8ySTtBQUFBLG1CQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPVixlQUFlVztBQUFBQSxvQkFDdEI7QUFBQSxvQkFDQSxJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxpQkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQ0E7QUFBQSxlQTdNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThNQTtBQUFBLGFBaE5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpTkE7QUFBQTtBQUFBLE1Bck5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXNOQTtBQUFBLE9BN1BGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4UEEsS0EvUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdRQTtBQUVKO0FBQUVsQyxHQXJiSUQsZUFBYTtBQUFBbUYsS0FBYm5GO0FBdWJOLGVBQWVBO0FBQWMsSUFBQW1GO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkV5ZUljb24iLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiQ2lyY3VsYXJMb2FkZXIiLCJHcm91cFNldHRpbmdzIiwiX3MiLCJncm91cHMiLCJzZXRHcm91cHMiLCJUYWJsZUdyb3VwcyIsInNldFRhYmxlR3JvdXBzIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJjdXJyZW50VXBkYXRlR3JvdXAiLCJzZXRDdXJyZW50VXBkYXRlR3JvdXAiLCJ1cGRhdGluZ0dyb3VwcyIsInNldFVwZGF0aW5nR3JvdXBzIiwiU2V0IiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsImdyb3VwX25hbWUiLCJncm91cF90eXBlIiwiZ3JvdXBfdmFsdWUiLCJncm91cF9pbnN0YWxsIiwiZ3JvdXBfbWVtYmVycyIsImdyb3VwX2R1cmF0aW9uIiwic3RhcnRfZGF0ZSIsImVuZF9kYXRlIiwibWluaW11bV9iaWQiLCJtYXhpbXVtX2JpZCIsImNvbW1pc3Npb24iLCJyZWdfZmVlIiwiZmV0Y2hHcm91cHMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiZ3JvdXAiLCJpbmRleCIsImNoZWNrQm94IiwibW9iaWxlX2FjY2VzcyIsImhhbmRsZU1vYmlsZUFjY2Vzc0NoYW5nZSIsIl9pZCIsImhhcyIsImlkIiwibmFtZSIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJ2YWx1ZSIsImluc3RhbGxtZW50IiwibWVtYmVycyIsImFjdGlvbiIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImVycm9yIiwiY29uc29sZSIsImdyb3VwSWQiLCJuZXdWYWx1ZSIsInByZXYiLCJwYXRjaCIsIm5ld1NldCIsImRlbGV0ZSIsImdyb3VwRGF0YSIsImZvcm1hdHRlZFN0YXJ0RGF0ZSIsInNwbGl0IiwiZm9ybWF0dGVkRW5kRGF0ZSIsImhhbmRsZVVwZGF0ZSIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImlzVmFsaWQiLCJ2YWxpZGF0ZUZvcm0iLCJwdXQiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwibGVuZ3RoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR3JvdXBTZXR0aW5ncy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBFeWVJY29uIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcblxyXG5jb25zdCBHcm91cFNldHRpbmdzID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlR3JvdXBzLCBzZXRUYWJsZUdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3VwZGF0aW5nR3JvdXBzLCBzZXRVcGRhdGluZ0dyb3Vwc10gPSB1c2VTdGF0ZShuZXcgU2V0KCkpO1xyXG4gIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwX25hbWU6IFwiXCIsXHJcbiAgICBncm91cF90eXBlOiBcIlwiLFxyXG4gICAgZ3JvdXBfdmFsdWU6IFwiXCIsXHJcbiAgICBncm91cF9pbnN0YWxsOiBcIlwiLFxyXG4gICAgZ3JvdXBfbWVtYmVyczogXCJcIixcclxuICAgIGdyb3VwX2R1cmF0aW9uOiBcIlwiLFxyXG4gICAgc3RhcnRfZGF0ZTogXCJcIixcclxuICAgIGVuZF9kYXRlOiBcIlwiLFxyXG4gICAgbWluaW11bV9iaWQ6IFwiXCIsXHJcbiAgICBtYXhpbXVtX2JpZDogXCJcIixcclxuICAgIGNvbW1pc3Npb246IDUsXHJcbiAgICByZWdfZmVlOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgY2hlY2tCb3g6IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXJlZC00MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1tZCBzaGFkb3cgaG92ZXI6Ym9yZGVyLXJlZC03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtncm91cC5tb2JpbGVfYWNjZXNzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVNb2JpbGVBY2Nlc3NDaGFuZ2UoZ3JvdXAuX2lkLCAhZ3JvdXAubW9iaWxlX2FjY2VzcylcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dXBkYXRpbmdHcm91cHMuaGFzKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY2hlY2tib3ggaC00IHctNCB0ZXh0LXJlZC02MDAgZm9jdXM6cmluZy0wIGZvY3VzOnJpbmctb2Zmc2V0LTAgZm9jdXM6b3V0bGluZS1ub25lIGNoZWNrZWQ6YmctcmVkLTYwMCBib3JkZXItZ3JheS0zMDAgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgbmFtZTogZ3JvdXAuZ3JvdXBfbmFtZSxcclxuICAgICAgICAgIHR5cGU6IGAke2dyb3VwLmdyb3VwX3R5cGVcclxuICAgICAgICAgICAgLmNoYXJBdCgwKVxyXG4gICAgICAgICAgICAudG9VcHBlckNhc2UoKX0ke2dyb3VwLmdyb3VwX3R5cGUuc2xpY2UoMSl9IEdyb3VwYCxcclxuICAgICAgICAgIHZhbHVlOiBncm91cC5ncm91cF92YWx1ZSxcclxuICAgICAgICAgIGluc3RhbGxtZW50OiBncm91cC5ncm91cF9pbnN0YWxsLFxyXG4gICAgICAgICAgbWVtYmVyczogZ3JvdXAuZ3JvdXBfbWVtYmVycyxcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JlZW4tNDAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbWQgc2hhZG93IGhvdmVyOmJvcmRlci1ncmVlbi03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxFeWVJY29uIGNvbG9yPVwiZ3JlZW5cIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFRhYmxlR3JvdXBzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1maW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbdXBkYXRpbmdHcm91cHMsIHJlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTW9iaWxlQWNjZXNzQ2hhbmdlID0gYXN5bmMgKGdyb3VwSWQsIG5ld1ZhbHVlKSA9PiB7XHJcbiAgICBzZXRVcGRhdGluZ0dyb3VwcygocHJldikgPT4gbmV3IFNldChbLi4ucHJldiwgZ3JvdXBJZF0pKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRHcm91cHMoKHByZXYpID0+XHJcbiAgICAgICAgcHJldi5tYXAoKGdyb3VwKSA9PlxyXG4gICAgICAgICAgZ3JvdXAuX2lkID09PSBncm91cElkID8geyAuLi5ncm91cCwgbW9iaWxlX2FjY2VzczogbmV3VmFsdWUgfSA6IGdyb3VwXHJcbiAgICAgICAgKVxyXG4gICAgICApO1xyXG5cclxuICAgICAgYXdhaXQgYXBpLnBhdGNoKGAvZ3JvdXAvdXBkYXRlLW1vYmlsZS1hY2Nlc3MvJHtncm91cElkfWAsIHtcclxuICAgICAgICBtb2JpbGVfYWNjZXNzOiBuZXdWYWx1ZSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICBzZXRHcm91cHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRHcm91cHMoKHByZXYpID0+XHJcbiAgICAgICAgcHJldi5tYXAoKGdyb3VwKSA9PlxyXG4gICAgICAgICAgZ3JvdXAuX2lkID09PSBncm91cElkID8geyAuLi5ncm91cCwgbW9iaWxlX2FjY2VzczogIW5ld1ZhbHVlIH0gOiBncm91cFxyXG4gICAgICAgIClcclxuICAgICAgKTtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIG1vYmlsZSBhY2Nlc3M6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIHVwZGF0ZSBtb2JpbGUgYWNjZXNzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG5cclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFVwZGF0aW5nR3JvdXBzKChwcmV2KSA9PiB7XHJcbiAgICAgICAgY29uc3QgbmV3U2V0ID0gbmV3IFNldChwcmV2KTtcclxuICAgICAgICBuZXdTZXQuZGVsZXRlKGdyb3VwSWQpO1xyXG4gICAgICAgIHJldHVybiBuZXdTZXQ7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9ncm91cC9nZXQtYnktaWQtZ3JvdXAvJHtncm91cElkfWApO1xyXG4gICAgICBjb25zdCBncm91cERhdGEgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWRTdGFydERhdGUgPSBncm91cERhdGEuc3RhcnRfZGF0ZS5zcGxpdChcIlRcIilbMF07XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZEVuZERhdGUgPSBncm91cERhdGEuZW5kX2RhdGUuc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlR3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICBncm91cF9uYW1lOiByZXNwb25zZS5kYXRhLmdyb3VwX25hbWUsXHJcbiAgICAgICAgZ3JvdXBfdHlwZTogcmVzcG9uc2UuZGF0YS5ncm91cF90eXBlLFxyXG4gICAgICAgIGdyb3VwX3ZhbHVlOiByZXNwb25zZS5kYXRhLmdyb3VwX3ZhbHVlLFxyXG4gICAgICAgIGdyb3VwX2luc3RhbGw6IHJlc3BvbnNlLmRhdGEuZ3JvdXBfaW5zdGFsbCxcclxuICAgICAgICBncm91cF9tZW1iZXJzOiByZXNwb25zZS5kYXRhLmdyb3VwX21lbWJlcnMsXHJcbiAgICAgICAgZ3JvdXBfZHVyYXRpb246IHJlc3BvbnNlLmRhdGEuZ3JvdXBfZHVyYXRpb24sXHJcbiAgICAgICAgc3RhcnRfZGF0ZTogZm9ybWF0dGVkU3RhcnREYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlOiBmb3JtYXR0ZWRFbmREYXRlLFxyXG4gICAgICAgIG1pbmltdW1fYmlkOiByZXNwb25zZS5kYXRhLm1pbmltdW1fYmlkLFxyXG4gICAgICAgIG1heGltdW1fYmlkOiByZXNwb25zZS5kYXRhLm1heGltdW1fYmlkLFxyXG4gICAgICAgIHJlZ19mZWU6IHJlc3BvbnNlLmRhdGEucmVnX2ZlZSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgICBhd2FpdCBhcGkucHV0KFxyXG4gICAgICAgICAgYC9ncm91cC91cGRhdGUtZ3JvdXAvJHtjdXJyZW50VXBkYXRlR3JvdXAuX2lkfWAsXHJcbiAgICAgICAgICB1cGRhdGVGb3JtRGF0YVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJHcm91cCB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZ3JvdXA6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiY2hlY2tCb3hcIiwgaGVhZGVyOiBcIk1vYmlsZSBBY2Nlc3NcIiB9LFxyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInR5cGVcIiwgaGVhZGVyOiBcIkdyb3VwIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidmFsdWVcIiwgaGVhZGVyOiBcIkdyb3VwIFZhbHVlXCIgfSxcclxuICAgIHsga2V5OiBcImluc3RhbGxtZW50XCIsIGhlYWRlcjogXCJHcm91cCBJbnN0YWxsbWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJtZW1iZXJzXCIsIGhlYWRlcjogXCJHcm91cCBNZW1iZXJzXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgIH1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkdyb3VwczwvaDE+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgIHsoVGFibGVHcm91cHMubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nKSA/IChcclxuICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgIGRhdGE9e1RhYmxlR3JvdXBzfVxyXG4gICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEdyb3Vwcy0ke1xyXG4gICAgICAgICAgICAgICAgVGFibGVHcm91cHMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICA/IFRhYmxlR3JvdXBzWzBdLm5hbWUgK1xyXG4gICAgICAgICAgICAgICAgICAgIFwiIHRvIFwiICtcclxuICAgICAgICAgICAgICAgICAgICBUYWJsZUdyb3Vwc1tUYWJsZUdyb3Vwcy5sZW5ndGggLSAxXS5uYW1lXHJcbiAgICAgICAgICAgICAgICAgIDogXCJlbXB0eVwiXHJcbiAgICAgICAgICAgICAgfS5jc3ZgfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgZmFpbHVyZT17VGFibGVHcm91cHMubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtcIkdyb3VwIERhdGFcIn1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy0zIGxnOmdyaWQtY29scy00IGdhcC04XCI+PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+R3JvdXA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBHcm91cCBOYW1lXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgR3JvdXAgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEdyb3VwIFR5cGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmdyb3VwX3R5cGUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiByZWFkT25seSB2YWx1ZT1cIlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBHcm91cCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHJlYWRPbmx5IHZhbHVlPVwiZGl2aWRlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICBEaXZpZGVuZCBHcm91cFxyXG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiByZWFkT25seSB2YWx1ZT1cImRvdWJsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERvdWJsZSBHcm91cFxyXG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgVmFsdWVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfdmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEdyb3VwIFZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgSW5zdGFsbG1lbnQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfaW5zdGFsbH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgSW5zdGFsbG1lbnQgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cCBNZW1iZXJzXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9tZW1iZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfbWVtYmVyc31cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgTWVtYmVyc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIER1cmF0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9kdXJhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmdyb3VwX2R1cmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEdyb3VwIER1cmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBSZWdpc3RyYXRpb24gRmVlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicmVnX2ZlZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5yZWdfZmVlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBSZWdpc3RyYXRpb24gRmVlXCJcclxuICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU3RhcnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN0YXJ0X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5zdGFydF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVuZCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW5kX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5lbmRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIE1pbmltdW0gQmlkICVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1pbmltdW1fYmlkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEubWluaW11bV9iaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgTWluaW11bSBCaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTWF4aW11bSBCaWQgJVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibWF4aW11bV9iaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5tYXhpbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBNYXhpbXVtIEJpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEdyb3VwU2V0dGluZ3M7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Hcm91cFNldHRpbmdzLmpzeCJ9