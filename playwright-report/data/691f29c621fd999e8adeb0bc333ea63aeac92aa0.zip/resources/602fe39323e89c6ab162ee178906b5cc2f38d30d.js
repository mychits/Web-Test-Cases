import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Registration.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import loginImage from "/src/assets/images/login image 1.jpg?import";
import Image from "/src/assets/images/mychits.png?import";
const Register = () => {
  _s();
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/dashboard");
    }
  }, [navigate]);
  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    try {
      const response = await api.post(`/admin/register`, {
        name,
        // Matches backend 'name'
        phoneNumber,
        email,
        password
        // We do NOT send admin_access_right_id here.
        // The backend controller handles it.
      });
      setSuccess("Registration successful! Redirecting to login...");
      setTimeout(() => {
        navigate("/");
      }, 2e3);
      console.log("Registration successful:", response.data);
    } catch (error2) {
      let errorMessage = "Registration failed. Please try again.";
      if (error2.response?.data?.message) {
        const rawMessage = error2.response.data.message;
        if (rawMessage.includes("E11000") || rawMessage.includes("duplicate key")) {
          if (rawMessage.includes("phoneNumber")) {
            errorMessage = "This phone number is already registered.";
          } else if (rawMessage.includes("email")) {
            errorMessage = "This email is already registered.";
          } else {
            errorMessage = "An account with these details already exists.";
          }
        } else {
          errorMessage = rawMessage;
        }
      }
      setError(errorMessage);
      console.error("Registration error:", error2);
    }
  };
  return (
    // Main container: Full height, relative positioning (Matches Login.js)
    /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen relative flex items-center justify-center overflow-hidden bg-slate-900", children: [
      /* @__PURE__ */ jsxDEV(
        "img",
        {
          className: "absolute inset-0 h-full w-full object-cover opacity-60",
          src: loginImage,
          alt: "Login Background"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
          lineNumber: 88,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-slate-900/40 z-0" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
        lineNumber: 95,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 w-full max-w-md mx-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-8 md:p-10", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "relative", children: /* @__PURE__ */ jsxDEV(
          "img",
          {
            className: "size-20",
            src: Image,
            alt: "MyChits Logo"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 104,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
          lineNumber: 103,
          columnNumber: 14
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
          lineNumber: 102,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-center text-3xl font-bold leading-9 tracking-tight text-gray-900 mb-2", children: "Create an Admin Account" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
          lineNumber: 113,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-center text-sm text-gray-600 mb-8", children: [
          "Already have an account?",
          " ",
          /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "font-semibold text-blue-600 hover:text-blue-800 transition-colors", children: "Login here" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 120,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
          lineNumber: 118,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleRegister, className: "space-y-5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                htmlFor: "name",
                className: "block text-sm font-medium leading-6 text-gray-900 mb-1",
                children: "Full Name"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                lineNumber: 130,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "name",
                name: "name",
                type: "text",
                required: true,
                autoComplete: "name",
                value: name,
                onChange: (e) => setName(e.target.value),
                className: "block w-full rounded-md border-0 py-2.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-blue-500 sm:text-sm sm:leading-6 px-3"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                lineNumber: 137,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
              lineNumber: 136,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 129,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                htmlFor: "phoneNumber",
                className: "block text-sm font-medium leading-6 text-gray-900 mb-1",
                children: "Phone Number"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                lineNumber: 152,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "phoneNumber",
                name: "phoneNumber",
                type: "tel",
                required: true,
                autoComplete: "tel",
                value: phoneNumber,
                onChange: (e) => setPhoneNumber(e.target.value),
                className: "block w-full rounded-md border-0 py-2.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-blue-500 sm:text-sm sm:leading-6 px-3"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                lineNumber: 159,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
              lineNumber: 158,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 151,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                htmlFor: "email",
                className: "block text-sm font-medium leading-6 text-gray-900 mb-1",
                children: "Email Address"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                lineNumber: 174,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "email",
                name: "email",
                type: "email",
                required: true,
                autoComplete: "email",
                value: email,
                onChange: (e) => setEmail(e.target.value),
                className: "block w-full rounded-md border-0 py-2.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-blue-500 sm:text-sm sm:leading-6 px-3"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                lineNumber: 181,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
              lineNumber: 180,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 173,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                htmlFor: "password",
                className: "block text-sm font-medium leading-6 text-gray-900 mb-1",
                children: "Password"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                lineNumber: 196,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "password",
                  name: "password",
                  type: showPassword ? "text" : "password",
                  required: true,
                  autoComplete: "new-password",
                  value: password,
                  onChange: (e) => setPassword(e.target.value),
                  className: "block w-full rounded-md border-0 py-2.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-blue-500 sm:text-sm sm:leading-6 px-3 pr-10"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                  lineNumber: 203,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setShowPassword(!showPassword),
                  className: "absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 focus:outline-none",
                  children: showPassword ? (
                    // Eye Slash Icon
                    /* @__PURE__ */ jsxDEV("svg", { className: "h-5 w-5", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                      lineNumber: 221,
                      columnNumber: 23
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                      lineNumber: 220,
                      columnNumber: 19
                    }, this)
                  ) : (
                    // Eye Icon
                    /* @__PURE__ */ jsxDEV("svg", { className: "h-5 w-5", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: [
                      /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                        lineNumber: 226,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                        lineNumber: 227,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                      lineNumber: 225,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
                  lineNumber: 213,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
              lineNumber: 202,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 195,
            columnNumber: 13
          }, this),
          success && /* @__PURE__ */ jsxDEV("div", { className: "rounded-md bg-green-50 p-3 border border-green-100", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-green-800 text-center", children: success }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 237,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 236,
            columnNumber: 13
          }, this),
          error && /* @__PURE__ */ jsxDEV("div", { className: "rounded-md bg-red-50 p-3 border border-red-100", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-800 text-center", children: error }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 244,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 243,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "flex w-full justify-center items-center gap-2 rounded-md bg-blue-600 px-3 py-3 text-lg font-semibold leading-6 text-white shadow-sm hover:bg-blue-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 transition-all duration-200",
              children: "Register"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
              lineNumber: 250,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
            lineNumber: 249,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
          lineNumber: 126,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
        lineNumber: 99,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
        lineNumber: 98,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx",
      lineNumber: 85,
      columnNumber: 5
    }, this)
  );
};
_s(Register, "ZO/+IrULyFqC8SRxRdkbZqN1/NQ=", false, function() {
  return [useNavigate];
});
_c = Register;
export default Register;
var _c;
$RefreshReg$(_c, "Register");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Registration.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZNOzJCQXZGTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxTQUFTQyxhQUFhQyxZQUFZO0FBQ2xDLE9BQU9DLFNBQVM7QUFHaEIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLFdBQVc7QUFFbEIsTUFBTUMsV0FBV0EsTUFBTTtBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJVCxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDVSxhQUFhQyxjQUFjLElBQUlYLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNZLE9BQU9DLFFBQVEsSUFBSWIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2MsVUFBVUMsV0FBVyxJQUFJZixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDZ0IsT0FBT0MsUUFBUSxJQUFJakIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2tCLFNBQVNDLFVBQVUsSUFBSW5CLFNBQVMsRUFBRTtBQUd6QyxRQUFNLENBQUNvQixjQUFjQyxlQUFlLElBQUlyQixTQUFTLEtBQUs7QUFFdEQsUUFBTXNCLFdBQVdyQixZQUFZO0FBRTdCRixZQUFVLE1BQU07QUFDZCxVQUFNd0IsUUFBUUMsYUFBYUMsUUFBUSxPQUFPO0FBQzFDLFFBQUlGLE9BQU87QUFDVEQsZUFBUyxZQUFZO0FBQUEsSUFDdkI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBRWIsUUFBTUksaUJBQWlCLE9BQU9DLE1BQU07QUFDbENBLE1BQUVDLGVBQWU7QUFDakJYLGFBQVMsRUFBRTtBQUNYRSxlQUFXLEVBQUU7QUFFYixRQUFJO0FBSUYsWUFBTVUsV0FBVyxNQUFNMUIsSUFBSTJCLEtBQUssbUJBQW1CO0FBQUEsUUFDakR0QjtBQUFBQTtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBRTtBQUFBQTtBQUFBQTtBQUFBQSxNQUdGLENBQUM7QUFFREssaUJBQVcsa0RBQWtEO0FBRTdEWSxpQkFBVyxNQUFNO0FBQ2ZULGlCQUFTLEdBQUc7QUFBQSxNQUNkLEdBQUcsR0FBSTtBQUVQVSxjQUFRQyxJQUFJLDRCQUE0QkosU0FBU0ssSUFBSTtBQUFBLElBQ3ZELFNBQVNsQixRQUFPO0FBRWQsVUFBSW1CLGVBQWU7QUFHbkIsVUFBSW5CLE9BQU1hLFVBQVVLLE1BQU1FLFNBQVM7QUFDakMsY0FBTUMsYUFBYXJCLE9BQU1hLFNBQVNLLEtBQUtFO0FBR3ZDLFlBQUlDLFdBQVdDLFNBQVMsUUFBUSxLQUFLRCxXQUFXQyxTQUFTLGVBQWUsR0FBRztBQUN6RSxjQUFJRCxXQUFXQyxTQUFTLGFBQWEsR0FBRztBQUN0Q0gsMkJBQWU7QUFBQSxVQUNqQixXQUFXRSxXQUFXQyxTQUFTLE9BQU8sR0FBRztBQUN2Q0gsMkJBQWU7QUFBQSxVQUNqQixPQUFPO0FBQ0xBLDJCQUFlO0FBQUEsVUFDakI7QUFBQSxRQUNGLE9BQU87QUFDTEEseUJBQWVFO0FBQUFBLFFBQ2pCO0FBQUEsTUFDRjtBQUVBcEIsZUFBU2tCLFlBQVk7QUFDckJILGNBQVFoQixNQUFNLHVCQUF1QkEsTUFBSztBQUFBLElBQzVDO0FBQUEsRUFDRjtBQUVBO0FBQUE7QUFBQSxJQUVFLHVCQUFDLFNBQUksV0FBVSx1RkFHYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixLQUFLWjtBQUFBQSxVQUNMLEtBQUk7QUFBQTtBQUFBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3dCO0FBQUEsTUFJeEIsdUJBQUMsU0FBSSxXQUFVLDBDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Q7QUFBQSxNQUd0RCx1QkFBQyxTQUFJLFdBQVUsc0NBQ2IsaUNBQUMsU0FBSSxXQUFVLG1FQUdiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDRCQUNaLGlDQUFDLFNBQUksV0FBVSxZQUNaO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixLQUFLQztBQUFBQSxZQUNMLEtBQUk7QUFBQTtBQUFBLFVBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR29CLEtBSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQSxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBR0EsdUJBQUMsUUFBRyxXQUFVLDhFQUE2RSx1Q0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHQSx1QkFBQyxPQUFFLFdBQVUsMENBQXlDO0FBQUE7QUFBQSxVQUMzQjtBQUFBLFVBQ3pCLHVCQUFDLFFBQUssSUFBRyxLQUFJLFdBQVUscUVBQW9FLDBCQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUdBLHVCQUFDLFVBQUssVUFBVXFCLGdCQUFnQixXQUFVLGFBR3hDO0FBQUEsaUNBQUMsU0FDQztBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLFdBQVU7QUFBQSxnQkFBd0Q7QUFBQTtBQUFBLGNBRnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxjQUFhO0FBQUEsZ0JBQ2IsT0FBT2xCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ21CLE1BQU1sQixRQUFRa0IsRUFBRVksT0FBT0MsS0FBSztBQUFBLGdCQUN2QyxXQUFVO0FBQUE7QUFBQSxjQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFzTixLQVR4TjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVE7QUFBQSxnQkFDUixXQUFVO0FBQUEsZ0JBQXdEO0FBQUE7QUFBQSxjQUZwRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsY0FBYTtBQUFBLGdCQUNiLE9BQU85QjtBQUFBQSxnQkFDUCxVQUFVLENBQUNpQixNQUFNaEIsZUFBZWdCLEVBQUVZLE9BQU9DLEtBQUs7QUFBQSxnQkFDOUMsV0FBVTtBQUFBO0FBQUEsY0FSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRc04sS0FUeE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFRO0FBQUEsZ0JBQ1IsV0FBVTtBQUFBLGdCQUF3RDtBQUFBO0FBQUEsY0FGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxJQUFHO0FBQUEsZ0JBQ0gsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLGNBQWE7QUFBQSxnQkFDYixPQUFPNUI7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDZSxNQUFNZCxTQUFTYyxFQUFFWSxPQUFPQyxLQUFLO0FBQUEsZ0JBQ3hDLFdBQVU7QUFBQTtBQUFBLGNBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUXNOLEtBVHhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLFdBQVU7QUFBQSxnQkFBd0Q7QUFBQTtBQUFBLGNBRnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLElBQUc7QUFBQSxrQkFDSCxNQUFLO0FBQUEsa0JBQ0wsTUFBTXBCLGVBQWUsU0FBUztBQUFBLGtCQUM5QjtBQUFBLGtCQUNBLGNBQWE7QUFBQSxrQkFDYixPQUFPTjtBQUFBQSxrQkFDUCxVQUFVLENBQUNhLE1BQU1aLFlBQVlZLEVBQUVZLE9BQU9DLEtBQUs7QUFBQSxrQkFDM0MsV0FBVTtBQUFBO0FBQUEsZ0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUTROO0FBQUEsY0FFNU47QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTW5CLGdCQUFnQixDQUFDRCxZQUFZO0FBQUEsa0JBQzVDLFdBQVU7QUFBQSxrQkFFVEE7QUFBQUE7QUFBQUEsb0JBRUMsdUJBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFNBQVEsYUFBWSxRQUFPLGdCQUM5RCxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLDhTQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErVyxLQURqWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUE7QUFBQTtBQUFBLG9CQUdBLHVCQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxTQUFRLGFBQVksUUFBTyxnQkFDOUQ7QUFBQSw2Q0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLHNDQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1RztBQUFBLHNCQUN2Ryx1QkFBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLDZIQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4TDtBQUFBLHlCQUZoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUE7QUFBQTtBQUFBLGdCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlCQTtBQUFBLGlCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQTtBQUFBLGVBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUNBO0FBQUEsVUFHQ0YsV0FDQyx1QkFBQyxTQUFJLFdBQVUsc0RBQ2IsaUNBQUMsT0FBRSxXQUFVLHNDQUFzQ0EscUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJELEtBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUlERixTQUNDLHVCQUFDLFNBQUksV0FBVSxrREFDYixpQ0FBQyxPQUFFLFdBQVUsb0NBQW9DQSxtQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQsS0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBSUYsdUJBQUMsU0FDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQStSO0FBQUE7QUFBQSxZQUYzUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQWxJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUlBO0FBQUEsV0E5SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStKQSxLQWhLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUtBO0FBQUEsU0E5S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdMQTtBQUFBO0FBRUo7QUFBRVQsR0E1UElELFVBQVE7QUFBQSxVQVdLTCxXQUFXO0FBQUE7QUFBQXdDLEtBWHhCbkM7QUE4UE4sZUFBZUE7QUFBUyxJQUFBbUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwiYXBpIiwibG9naW5JbWFnZSIsIkltYWdlIiwiUmVnaXN0ZXIiLCJfcyIsIm5hbWUiLCJzZXROYW1lIiwicGhvbmVOdW1iZXIiLCJzZXRQaG9uZU51bWJlciIsImVtYWlsIiwic2V0RW1haWwiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwiZXJyb3IiLCJzZXRFcnJvciIsInN1Y2Nlc3MiLCJzZXRTdWNjZXNzIiwic2hvd1Bhc3N3b3JkIiwic2V0U2hvd1Bhc3N3b3JkIiwibmF2aWdhdGUiLCJ0b2tlbiIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJoYW5kbGVSZWdpc3RlciIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInJlc3BvbnNlIiwicG9zdCIsInNldFRpbWVvdXQiLCJjb25zb2xlIiwibG9nIiwiZGF0YSIsImVycm9yTWVzc2FnZSIsIm1lc3NhZ2UiLCJyYXdNZXNzYWdlIiwiaW5jbHVkZXMiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlZ2lzdHJhdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL3BhZ2VzL1JlZ2lzdGVyLmpzXHJcblxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5cclxuLy8gLS0tIDEuIElNUE9SVCBZT1VSIElNQUdFUyBIRVJFIC0tLVxyXG5pbXBvcnQgbG9naW5JbWFnZSBmcm9tIFwiLi4vYXNzZXRzL2ltYWdlcy9sb2dpbiBpbWFnZSAxLmpwZ1wiO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSBcIi4uL2Fzc2V0cy9pbWFnZXMvbXljaGl0cy5wbmdcIjtcclxuXHJcbmNvbnN0IFJlZ2lzdGVyID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwaG9uZU51bWJlciwgc2V0UGhvbmVOdW1iZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3N1Y2Nlc3MsIHNldFN1Y2Nlc3NdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgXHJcbiAgLy8gLS0tIFBBU1NXT1JEIFZJU0lCSUxJVFkgU1RBVEUgLS0tXHJcbiAgY29uc3QgW3Nob3dQYXNzd29yZCwgc2V0U2hvd1Bhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInRva2VuXCIpO1xyXG4gICAgaWYgKHRva2VuKSB7XHJcbiAgICAgIG5hdmlnYXRlKFwiL2Rhc2hib2FyZFwiKTtcclxuICAgIH1cclxuICB9LCBbbmF2aWdhdGVdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVnaXN0ZXIgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0RXJyb3IoXCJcIik7XHJcbiAgICBzZXRTdWNjZXNzKFwiXCIpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIC0tLSBOTyBDSEFOR0UgTkVFREVEIEhFUkUgLS0tXHJcbiAgICAgIC8vIFdlIHNlbmQgdGhlIGJhc2ljIHVzZXIgaW5mby4gVGhlIGJhY2tlbmQgd2lsbCBmaW5kIGFuZCBhdHRhY2ggXHJcbiAgICAgIC8vIHRoZSBcIm5vbmVcIiBkZXNpZ25hdGlvbiBJRCBhdXRvbWF0aWNhbGx5LlxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KGAvYWRtaW4vcmVnaXN0ZXJgLCB7XHJcbiAgICAgICAgbmFtZSwgICAgICAgICAvLyBNYXRjaGVzIGJhY2tlbmQgJ25hbWUnXHJcbiAgICAgICAgcGhvbmVOdW1iZXIsXHJcbiAgICAgICAgZW1haWwsXHJcbiAgICAgICAgcGFzc3dvcmQsXHJcbiAgICAgICAgLy8gV2UgZG8gTk9UIHNlbmQgYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIGhlcmUuXHJcbiAgICAgICAgLy8gVGhlIGJhY2tlbmQgY29udHJvbGxlciBoYW5kbGVzIGl0LlxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFN1Y2Nlc3MoXCJSZWdpc3RyYXRpb24gc3VjY2Vzc2Z1bCEgUmVkaXJlY3RpbmcgdG8gbG9naW4uLi5cIik7XHJcblxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBuYXZpZ2F0ZShcIi9cIik7XHJcbiAgICAgIH0sIDIwMDApO1xyXG5cclxuICAgICAgY29uc29sZS5sb2coXCJSZWdpc3RyYXRpb24gc3VjY2Vzc2Z1bDpcIiwgcmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAvLyAtLS0gRVJST1IgSEFORExJTkcgTE9HSUMgLS0tXHJcbiAgICAgIGxldCBlcnJvck1lc3NhZ2UgPSBcIlJlZ2lzdHJhdGlvbiBmYWlsZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCI7XHJcblxyXG4gICAgICAvLyBDaGVjayBpZiBiYWNrZW5kIHJldHVybmVkIGEgc3BlY2lmaWMgbWVzc2FnZVxyXG4gICAgICBpZiAoZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UpIHtcclxuICAgICAgICBjb25zdCByYXdNZXNzYWdlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlO1xyXG5cclxuICAgICAgICAvLyBIYW5kbGUgTW9uZ29vc2UgRHVwbGljYXRlIEtleSBFcnJvciAoRTExMDAwKVxyXG4gICAgICAgIGlmIChyYXdNZXNzYWdlLmluY2x1ZGVzKFwiRTExMDAwXCIpIHx8IHJhd01lc3NhZ2UuaW5jbHVkZXMoXCJkdXBsaWNhdGUga2V5XCIpKSB7XHJcbiAgICAgICAgICBpZiAocmF3TWVzc2FnZS5pbmNsdWRlcyhcInBob25lTnVtYmVyXCIpKSB7XHJcbiAgICAgICAgICAgIGVycm9yTWVzc2FnZSA9IFwiVGhpcyBwaG9uZSBudW1iZXIgaXMgYWxyZWFkeSByZWdpc3RlcmVkLlwiO1xyXG4gICAgICAgICAgfSBlbHNlIGlmIChyYXdNZXNzYWdlLmluY2x1ZGVzKFwiZW1haWxcIikpIHtcclxuICAgICAgICAgICAgZXJyb3JNZXNzYWdlID0gXCJUaGlzIGVtYWlsIGlzIGFscmVhZHkgcmVnaXN0ZXJlZC5cIjtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGVycm9yTWVzc2FnZSA9IFwiQW4gYWNjb3VudCB3aXRoIHRoZXNlIGRldGFpbHMgYWxyZWFkeSBleGlzdHMuXCI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGVycm9yTWVzc2FnZSA9IHJhd01lc3NhZ2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRFcnJvcihlcnJvck1lc3NhZ2UpO1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiUmVnaXN0cmF0aW9uIGVycm9yOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIC8vIE1haW4gY29udGFpbmVyOiBGdWxsIGhlaWdodCwgcmVsYXRpdmUgcG9zaXRpb25pbmcgKE1hdGNoZXMgTG9naW4uanMpXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiByZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gYmctc2xhdGUtOTAwXCI+XHJcblxyXG4gICAgICB7LyogMS4gQkFDS0dST1VORCBJTUFHRSBTRUNUSU9OICovfVxyXG4gICAgICA8aW1nXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBoLWZ1bGwgdy1mdWxsIG9iamVjdC1jb3ZlciBvcGFjaXR5LTYwXCJcclxuICAgICAgICBzcmM9e2xvZ2luSW1hZ2V9XHJcbiAgICAgICAgYWx0PVwiTG9naW4gQmFja2dyb3VuZFwiXHJcbiAgICAgIC8+XHJcblxyXG4gICAgICB7LyogRGFyayBPdmVybGF5IHRvIGVuc3VyZSB0ZXh0IHJlYWRhYmlsaXR5ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctc2xhdGUtOTAwLzQwIHotMFwiPjwvZGl2PlxyXG5cclxuICAgICAgey8qIDIuIEdMQVNTTU9SUEhJU00gRk9STSBDQVJEICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgdy1mdWxsIG1heC13LW1kIG14LTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlLzk1IGJhY2tkcm9wLWJsdXItc20gcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBwLTggbWQ6cC0xMFwiPlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICB7LyogTG9nbyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2l6ZS0yMFwiXHJcbiAgICAgICAgICAgICAgICAgIHNyYz17SW1hZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGFsdD1cIk15Q2hpdHMgTG9nb1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtM3hsIGZvbnQtYm9sZCBsZWFkaW5nLTkgdHJhY2tpbmctdGlnaHQgdGV4dC1ncmF5LTkwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgIENyZWF0ZSBhbiBBZG1pbiBBY2NvdW50XHJcbiAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgIHsvKiBMb2dpbiBMaW5rICovfVxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwIG1iLThcIj5cclxuICAgICAgICAgICAgQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/e1wiIFwifVxyXG4gICAgICAgICAgICA8TGluayB0bz1cIi9cIiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTgwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgIExvZ2luIGhlcmVcclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgIHsvKiBGb3JtIENvbnRhaW5lciAqL31cclxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVSZWdpc3Rlcn0gY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XHJcblxyXG4gICAgICAgICAgICB7LyogTmFtZSBJbnB1dCAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gbGVhZGluZy02IHRleHQtZ3JheS05MDAgbWItMVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgRnVsbCBOYW1lXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCByb3VuZGVkLW1kIGJvcmRlci0wIHB5LTIuNSB0ZXh0LWdyYXktOTAwIHNoYWRvdy1zbSByaW5nLTEgcmluZy1pbnNldCByaW5nLWdyYXktMzAwIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5zZXQgZm9jdXM6cmluZy1ibHVlLTUwMCBzbTp0ZXh0LXNtIHNtOmxlYWRpbmctNiBweC0zXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFBob25lIE51bWJlciBJbnB1dCAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwaG9uZU51bWJlclwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwIG1iLTFcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFBob25lIE51bWJlclxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICBpZD1cInBob25lTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInBob25lTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZU51bWJlcn1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQaG9uZU51bWJlcihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCByb3VuZGVkLW1kIGJvcmRlci0wIHB5LTIuNSB0ZXh0LWdyYXktOTAwIHNoYWRvdy1zbSByaW5nLTEgcmluZy1pbnNldCByaW5nLWdyYXktMzAwIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5zZXQgZm9jdXM6cmluZy1ibHVlLTUwMCBzbTp0ZXh0LXNtIHNtOmxlYWRpbmctNiBweC0zXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEVtYWlsIElucHV0ICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gbGVhZGluZy02IHRleHQtZ3JheS05MDAgbWItMVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgRW1haWwgQWRkcmVzc1xyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICBpZD1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXItMCBweS0yLjUgdGV4dC1ncmF5LTkwMCBzaGFkb3ctc20gcmluZy0xIHJpbmctaW5zZXQgcmluZy1ncmF5LTMwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluc2V0IGZvY3VzOnJpbmctYmx1ZS01MDAgc206dGV4dC1zbSBzbTpsZWFkaW5nLTYgcHgtM1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBQYXNzd29yZCBJbnB1dCB3aXRoIFZpc2liaWxpdHkgVG9nZ2xlICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgaHRtbEZvcj1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gbGVhZGluZy02IHRleHQtZ3JheS05MDAgbWItMVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgUGFzc3dvcmRcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT17c2hvd1Bhc3N3b3JkID8gXCJ0ZXh0XCIgOiBcInBhc3N3b3JkXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCByb3VuZGVkLW1kIGJvcmRlci0wIHB5LTIuNSB0ZXh0LWdyYXktOTAwIHNoYWRvdy1zbSByaW5nLTEgcmluZy1pbnNldCByaW5nLWdyYXktMzAwIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5zZXQgZm9jdXM6cmluZy1ibHVlLTUwMCBzbTp0ZXh0LXNtIHNtOmxlYWRpbmctNiBweC0zIHByLTEwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGFzc3dvcmQoIXNob3dQYXNzd29yZCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCByaWdodC0wIHByLTMgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNjAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtzaG93UGFzc3dvcmQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gRXllIFNsYXNoIEljb25cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImgtNSB3LTVcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk0xMy44NzUgMTguODI1QTEwLjA1IDEwLjA1IDAgMDExMiAxOWMtNC40NzggMC04LjI2OC0yLjk0My05LjU0My03YTkuOTcgOS45NyAwIDAxMS41NjMtMy4wMjltNS44NTguOTA4YTMgMyAwIDExNC4yNDMgNC4yNDNNOS44NzggOS44NzhsNC4yNDIgNC4yNDJNOS44OCA5Ljg4bC0zLjI5LTMuMjltNy41MzIgNy41MzJsMy4yOSAzLjI5TTMgM2wzLjU5IDMuNTltMCAwQTkuOTUzIDkuOTUzIDAgMDExMiA1YzQuNDc4IDAgOC4yNjggMi45NDMgOS41NDMgN2ExMC4wMjUgMTAuMDI1IDAgMDEtNC4xMzIgNS40MTFtMCAwTDIxIDIxXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAvLyBFeWUgSWNvblxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC01IHctNVwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTE1IDEyYTMgMyAwIDExLTYgMCAzIDMgMCAwMTYgMHpcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTIuNDU4IDEyQzMuNzMyIDcuOTQzIDcuNTIzIDUgMTIgNWM0LjQ3OCAwIDguMjY4IDIuOTQzIDkuNTQyIDctMS4yNzQgNC4wNTctNS4wNjQgNy05LjU0MiA3LTQuNDc3IDAtOC4yNjgtMi45NDMtOS41NDItN3pcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFN1Y2Nlc3MgTWVzc2FnZSAqL31cclxuICAgICAgICAgICAge3N1Y2Nlc3MgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBiZy1ncmVlbi01MCBwLTMgYm9yZGVyIGJvcmRlci1ncmVlbi0xMDBcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmVlbi04MDAgdGV4dC1jZW50ZXJcIj57c3VjY2Vzc308L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7LyogRXJyb3IgTWVzc2FnZSAqL31cclxuICAgICAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYmctcmVkLTUwIHAtMyBib3JkZXIgYm9yZGVyLXJlZC0xMDBcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1yZWQtODAwIHRleHQtY2VudGVyXCI+e2Vycm9yfTwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdWJtaXQgQnV0dG9uICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtbWQgYmctYmx1ZS02MDAgcHgtMyBweS0zIHRleHQtbGcgZm9udC1zZW1pYm9sZCBsZWFkaW5nLTYgdGV4dC13aGl0ZSBzaGFkb3ctc20gaG92ZXI6YmctYmx1ZS03MDAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtYmx1ZS02MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBSZWdpc3RlclxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlZ2lzdGVyOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9SZWdpc3RyYXRpb24uanN4In0=