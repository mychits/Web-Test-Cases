import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Receipt.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import { MdDelete } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { CiEdit } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import { BsEye } from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import UploadModal from "/src/components/modals/UploadModal.jsx";
import axios from "/node_modules/.vite/deps/axios.js?v=819e0a34";
import url from "/src/data/Url.js";
import { Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import EndlessCircularLoader from "/src/components/loaders/EndlessCircularLoader.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const Receipt = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableDaybook, setTableDaybook] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [receiptNo, setReceiptNo] = useState("");
  const [paymentMode, setPaymentMode] = useState("cash");
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showFilterField, setShowFilterField] = useState(false);
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const [selectedPaymentFor, setSelectedPaymentFor] = useState([]);
  const now = /* @__PURE__ */ new Date();
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const todayString = now.toISOString().split("T")[0];
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedDate, setSelectedDate] = useState(todayString);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState([]);
  const [hideAccountType, setHideAccountType] = useState("");
  const [selectedAccountType, setSelectedAccountType] = useState("");
  const [selectedCustomers, setSelectedCustomers] = useState("");
  const [payments, setPayments] = useState([]);
  const [collectionAgent, setCollectionAgent] = useState("");
  const [collectionAdmin, setCollectionAdmin] = useState("");
  const [agents, setAgents] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [showAllPaymentModes, setShowAllPaymentModes] = useState(false);
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    ticket: "",
    receipt_no: "",
    pay_date: "",
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    collected_by: collectionAgent,
    admin_type: collectionAdmin,
    collection_time: ""
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [overview, setOverview] = useState({
    chit: 0,
    loan: 0,
    pigmy: 0,
    registration: 0
  });
  const handleModalClose = () => setShowUploadModal(false);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const showPaymentsModes = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setShowAllPaymentModes(showPaymentsModes);
    }
  }, []);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const isModify = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setHideAccountType(isModify);
    }
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    (async () => {
      try {
        const [employees, admins2] = await Promise.all(
          [
            api.get("/employee"),
            api.get("/admin/get-sub-admins")
          ]
        );
        const emps = employees?.data?.employee.map((emp) => ({
          _id: emp._id,
          full_name: emp.name,
          phone_number: emp.phone_number,
          selected_type: "agent_type"
        }));
        setAgents(emps);
        const adms = admins2?.data?.map((ad) => ({
          _id: ad?._id,
          full_name: ad?.name,
          phone_number: ad?.phoneNumber,
          selected_type: "admin_type"
        }));
        setAdmins(adms);
        console.log(adms, "adms");
      } catch (error) {
        setAdmins([]);
        setAgents([]);
      }
    })();
  }, []);
  useEffect(() => {
    const fetchReceipt = async () => {
      try {
        const response = await api.get("/payment/get-latest-receipt");
        setReceiptNo(response.data);
      } catch (error) {
        console.error("Error fetching receipt data:", error);
      }
    };
    fetchReceipt();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setFilteredUsers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    if (receiptNo) {
      setFormData((prevData) => ({
        ...prevData,
        receipt_no: receiptNo.receipt_no
      }));
    }
  }, [receiptNo]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleChangeUser = (e) => {
    const { name, value } = e.target;
    const [user_id, ticket] = value.split("-");
    setFormData((prevData) => ({
      ...prevData,
      user_id,
      ticket
    }));
  };
  const handleGroup = async (event) => {
    const groupId = event.target.value;
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      group_id: groupId
    }));
    handleGroupChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        console.error("Error fetching group data:", error);
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const groupOptions = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
  };
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  const formatPayDate = (dateString) => {
    const date = new Date(dateString);
    const options = { day: "numeric", month: "long", year: "numeric" };
    return date.toLocaleDateString("en-US", options).replace(",", "");
  };
  useEffect(
    () => {
      const abortController = new AbortController();
      const fetchPayments = async () => {
        try {
          setIsLoading(true);
          const response = await api.get(`/payment/get-report-receipt`, {
            params: {
              from_date: selectedFromDate,
              to_date: selectedDate,
              groupId: selectedAuctionGroupId,
              userId: selectedCustomers,
              pay_type: selectedPaymentMode,
              account_type: selectedAccountType,
              collected_by: collectionAgent,
              admin_type: collectionAdmin,
              pay_for: selectedPaymentFor
            },
            signal: abortController.signal
          });
          console.info(response.data, "testing account type");
          if (response.data && response.data.length > 0) {
            const validPayments = response.data.filter(
              (payment) => payment.group_id !== null
            );
            setFilteredAuction(validPayments);
            const totalAmount = validPayments.reduce(
              (sum, payment) => sum + Number(payment.amount || 0),
              0
            );
            console.info(totalAmount, "check amount");
            setPayments(totalAmount);
            const formattedData = validPayments.map((group, index) => ({
              _id: group?._id,
              id: index + 1,
              date: group?.pay_date,
              group: group?.group_id?.group_name || group.pay_for,
              name: group?.user_id?.full_name,
              category: group?.pay_for || "Chit",
              phone_number: group?.user_id?.phone_number,
              receipt_no: group?.receipt_no,
              old_receipt_no: group?.old_receipt_no,
              ticket: group?.loan ? group.loan?.loan_id : group?.pigme ? group.pigme?.pigme_id : group?.ticket,
              amount: group?.amount,
              transaction_date: group?.createdAt?.split("T")?.[0],
              mode: group?.pay_type,
              account_type: group?.account_type,
              collection_time: group?.collection_time,
              collected_by: group?.collected_by?.name || group?.admin_type?.admin_name || "Super Admin",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          Link,
                          {
                            target: "_blank",
                            to: `/print/${group._id}`,
                            className: "text-violet-600 ",
                            children: "Print"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                            lineNumber: 362,
                            columnNumber: 21
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                    lineNumber: 375,
                    columnNumber: 19
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 355,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 354,
                columnNumber: 13
              }, this)
            }));
            let chitTotal = 0;
            let loanTotal = 0;
            let pigmyTotal = 0;
            let regTotal = 0;
            validPayments.forEach((p) => {
              const amount = Number(p.amount || 0);
              const heads = (p.pay_for || "").toLowerCase().split("|").map((h) => h.trim()).filter(Boolean);
              if (heads.length === 0 || heads.includes("chit")) {
                chitTotal += amount;
              }
              if (heads.includes("loan")) {
                loanTotal += amount;
              }
              if (heads.includes("pigme")) {
                pigmyTotal += amount;
              }
              if (heads.includes("reg")) {
                regTotal += amount;
              }
            });
            setOverview({
              chit: chitTotal,
              loan: loanTotal,
              pigmy: pigmyTotal,
              registration: regTotal
            });
            setTableDaybook(formattedData);
          } else {
            setFilteredAuction([]);
          }
        } catch (error) {
          console.error("Error fetching payment data:", error);
          setFilteredAuction([]);
          setPayments(0);
        } finally {
          setIsLoading(false);
        }
      };
      fetchPayments();
      return () => {
        abortController.abort();
      };
    },
    [
      selectedAuctionGroupId,
      selectedDate,
      selectedPaymentMode,
      selectedCustomers,
      selectedFromDate,
      selectedAccountType,
      collectionAgent,
      collectionAdmin,
      selectedPaymentFor
    ]
  );
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "group", header: "Group Name" },
    { key: "name", header: "Customer Name" },
    { key: "category", header: "Category" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "receipt_no", header: "Receipt Number" },
    { key: "old_receipt_no", header: "Old Receipt" },
    { key: "ticket", header: "Ticket" },
    { key: "amount", header: "Amount" },
    { key: "mode", header: "Payment Mode" },
    ...hideAccountType ? [{ key: "account_type", header: "Account Type" }] : [],
    { key: "collection_time", header: "Collection Time" },
    { key: "collected_by", header: "Collected By" },
    { key: "action", header: "Action" }
  ];
  useEffect(() => {
    if (groupInfo && formData.bid_amount) {
      const commission = groupInfo.group_value * 5 / 100 || 0;
      const win_amount = (groupInfo.group_value || 0) - (formData.bid_amount || 0);
      const divident = (formData.bid_amount || 0) - commission;
      const divident_head = groupInfo.group_members ? divident / groupInfo.group_members : 0;
      const payable = (groupInfo.group_install || 0) - divident_head;
      setFormData((prevData) => ({
        ...prevData,
        group_id: groupInfo._id,
        commission,
        win_amount,
        divident,
        divident_head,
        payable
      }));
    }
  }, [groupInfo, formData.bid_amount]);
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" ? prevData.transaction_id : ""
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/payment/add-payment", formData);
      if (response.status === 201) {
        alert("Payment Added Successfully");
        setShowModal(false);
      }
    } catch (error) {
      console.error("Error submitting payment data:", error);
    }
  };
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/payment/get-payment-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleDeleteAuction = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/payment/delete-payment/${currentGroup._id}`);
        alert("Payment deleted successfully");
        setShowModalDelete(false);
        setCurrentGroup(null);
        window.location.reload();
      } catch (error) {
        console.error("Error deleting auction:", error);
      }
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/auction/get-auction-by-id/${groupId}`);
      setCurrentUpdateGroup(response.data);
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching auction:", error);
    }
  };
  const handleFileSubmit = async (e) => {
    e.preventDefault();
    const formDatas = new FormData();
    const fileInput = e.target.file;
    if (fileInput && fileInput.files[0]) {
      formDatas.append("file", fileInput.files[0]);
      try {
        const response = await api.post(`/payment/payment-excel`, formDatas, {
          headers: { "Content-Type": "multipart/form-data" }
        });
        if (response.status === 200) {
          alert("File uploaded successfully!");
          window.location.reload();
          setShowUploadModal(false);
        }
      } catch (error) {
        console.error("Error uploading file:", error);
        alert("Failed to upload file.");
      }
    } else {
      alert("Please select a file to upload.");
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "relative flex flex-col [height:calc(100vh-100px)] ", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-30", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
        lineNumber: 584,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
        lineNumber: 588,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8 bg-gradient-to-br from-slate-50 via-violet-50 to-indigo-50 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent", children: "Reports - Receipt" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 595,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Track and manage all receipt transactions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 598,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
        lineNumber: 594,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-500 to-indigo-600 rounded-2xl p-5 text-white shadow-lg", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-80", children: "Chit Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 607,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-2", children: [
            "₹",
            overview.chit.toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 608,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 606,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl p-5 text-white shadow-lg", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-80", children: "Loan Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 615,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-2", children: [
            "₹",
            overview.loan.toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 616,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 614,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-orange-500 to-amber-600 rounded-2xl p-5 text-white shadow-lg", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-80", children: "Pigmy Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 623,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-2", children: [
            "₹",
            overview.pigmy.toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 624,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 622,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-pink-500 to-rose-600 rounded-2xl p-5 text-white shadow-lg", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-80", children: "Registration Fees" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 631,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-2", children: [
            "₹",
            overview.registration.toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 632,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 630,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
        lineNumber: 604,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-6 mb-8 border border-gray-100", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800 mb-6 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "w-5 h-5 text-indigo-600",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                    lineNumber: 647,
                    columnNumber: 21
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 641,
                columnNumber: 19
              },
              this
            ),
            "Filter Options"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 640,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Filter Option" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 660,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  popupMatchSelectWidth: false,
                  onChange: handleSelectFilter,
                  value: selectedLabel,
                  placeholder: "Search Or Select Filter",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  className: "w-full h-11",
                  children: groupOptions.map(
                    (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                      lineNumber: 678,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 663,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 659,
              columnNumber: 19
            }, this),
            showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "From Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 689,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    value: selectedFromDate,
                    onChange: (e) => setSelectedFromDate(e.target.value),
                    className: "w-full h-11 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                    lineNumber: 692,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 688,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "To Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 700,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    value: selectedDate,
                    onChange: (e) => setSelectedDate(e.target.value),
                    className: "w-full h-11 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                    lineNumber: 703,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 699,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 687,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 715,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  popupMatchSelectWidth: false,
                  value: selectedAuctionGroupId,
                  onChange: handleGroupPayment,
                  placeholder: "Search Or Select Group",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  className: "w-full h-11",
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                      lineNumber: 732,
                      columnNumber: 23
                    }, this),
                    groups.map(
                      (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                        lineNumber: 734,
                        columnNumber: 23
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 718,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 714,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 743,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  popupMatchSelectWidth: false,
                  value: selectedCustomers,
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  placeholder: "Search Or Select Customer",
                  onChange: (groupId) => setSelectedCustomers(groupId),
                  className: "w-full h-11",
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                      lineNumber: 760,
                      columnNumber: 23
                    }, this),
                    filteredUsers.map(
                      (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group?._id, children: [
                        group?.full_name,
                        " - ",
                        group.phone_number
                      ] }, group?._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                        lineNumber: 762,
                        columnNumber: 23
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 746,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 742,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Payment Mode" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 771,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "multiple",
                  value: selectedPaymentMode,
                  showSearch: true,
                  placeholder: "Select payment mode",
                  popupMatchSelectWidth: false,
                  onChange: (modes) => {
                    setSelectedPaymentMode(modes);
                  },
                  filterOption: (input, option) => option.label.toString().toLowerCase().includes(input.toLowerCase()),
                  className: "w-full",
                  style: { height: "44px" },
                  options: [
                    { label: "Cash", value: "cash" },
                    { label: "Online", value: "online" },
                    { label: "Payment Link", value: "Payment Link" }
                  ]
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 775,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 770,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Payment For" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 800,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "multiple",
                  value: selectedPaymentFor,
                  showSearch: true,
                  placeholder: "Select payment for",
                  popupMatchSelectWidth: false,
                  onChange: (modes) => {
                    setSelectedPaymentFor(modes);
                  },
                  filterOption: (input, option) => option.label.toString().toLowerCase().includes(input.toLowerCase()),
                  className: "w-full",
                  style: { height: "44px" },
                  options: [
                    { label: "Chit", value: "Chit" },
                    { label: "Pigme", value: "Pigme" },
                    { label: "Loan", value: "Loan" },
                    { label: "Registration", value: "registration" }
                  ]
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 804,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 799,
              columnNumber: 19
            }, this),
            showAllPaymentModes && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Account Type" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 832,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: selectedAccountType,
                  showSearch: true,
                  placeholder: "Search Or Select Account Type",
                  popupMatchSelectWidth: false,
                  onChange: (groupId) => setSelectedAccountType(groupId),
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  className: "w-full h-11",
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "Select Account Type" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                      lineNumber: 849,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "suspense", children: "Suspense" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                      lineNumber: 852,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "credit", children: "Credit" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                      lineNumber: 853,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "adjustment", children: "Adjustment" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                      lineNumber: 854,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "others", children: "Others" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                      lineNumber: 857,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 835,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 831,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Collection Employee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 864,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  placeholder: "Search Or Select Collection Agent",
                  popupMatchSelectWidth: false,
                  onChange: (selection) => {
                    const [id, type] = selection.split("|") || [];
                    if (type === "admin_type") {
                      setCollectionAdmin(id);
                      setCollectionAgent("");
                    } else if (type === "agent_type") {
                      setCollectionAgent(id);
                      setCollectionAdmin("");
                    } else {
                      setCollectionAdmin("");
                      setCollectionAgent("");
                    }
                  },
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  className: "w-full h-11",
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                      lineNumber: 892,
                      columnNumber: 23
                    }, this),
                    [...new Set(agents), ...new Set(admins)].map(
                      (dt) => /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: `${dt._id}|${dt.selected_type}`,
                          children: [
                            dt.selected_type === "admin_type" ? "Admin | " : "Agent | ",
                            dt.full_name,
                            " | ",
                            dt.phone_number
                          ]
                        },
                        dt?._id,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                          lineNumber: 894,
                          columnNumber: 23
                        },
                        this
                      )
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                  lineNumber: 867,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 863,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 657,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 639,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden bg-gradient-to-br from-indigo-600 via-violet-600 to-indigo-700 rounded-2xl shadow-2xl p-8 transform transition-all hover:scale-[1.02] duration-300", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -mr-20 -mt-20" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 912,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full -ml-16 -mb-16" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 913,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-1/2 left-1/2 w-64 h-64 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 914,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 p-4  rounded-xl border border-white/10 shadow-lg", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: /* @__PURE__ */ jsxDEV("p", { className: "text-white/70 text-xs font-medium uppercase tracking-wider", children: "Total Receipt Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 918,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 917,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("span", { className: "text-white text-4xl md:text-5xl font-bold tracking-tight", children: [
                "₹",
                payments ? Number(payments).toLocaleString("en-IN", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                }) : "0.00"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 925,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 924,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("span", { className: "text-white/85 text-base font-medium break-words", children: payments ? numberToIndianWords(Number(payments)) : "Zero Only" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 937,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 936,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 923,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-3 border-t border-white/10", children: /* @__PURE__ */ jsxDEV("p", { className: "text-white/60 text-xs flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "📊" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 947,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Based on active filters • Updated live" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 948,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 946,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 945,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 916,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent transform -skew-x-12" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 953,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 911,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 910,
          columnNumber: 15
        }, this),
        filteredAuction && filteredAuction.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-6 border border-gray-100", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-6", children: [
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "w-5 h-5 text-indigo-600",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                    lineNumber: 967,
                    columnNumber: 23
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
                lineNumber: 961,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800", children: "Receipt Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 974,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 960,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filterOption(TableDaybook, searchText),
              columns,
              exportedPdfName: `Receipt Report`,
              exportedFileName: `Reports Receipt.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 979,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-6 pt-6 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-indigo-50 to-violet-50 px-6 py-3 rounded-xl", children: /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-gray-800", children: [
            "Total Amount:",
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-indigo-600", children: [
              "₹",
              payments?.toLocaleString()
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
              lineNumber: 990,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 988,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 987,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 986,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 959,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-12 text-center border border-gray-100", children: /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: filteredAuction.length <= 0,
            data: "Receipt Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
            lineNumber: 999,
            columnNumber: 19
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
          lineNumber: 998,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
        lineNumber: 638,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
      lineNumber: 593,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
    lineNumber: 583,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
    lineNumber: 582,
    columnNumber: 6
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx",
    lineNumber: 581,
    columnNumber: 5
  }, this);
};
_s(Receipt, "0pk5W5XwX3cCMzeO/drPJXfQaCM=");
_c = Receipt;
export default Receipt;
var _c;
$RefreshReg$(_c, "Receipt");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Receipt.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeVcwQixTQXFVTixVQXJVTTsyQkF6VzFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLGFBQWE7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxRQUFRQyxnQkFBZ0I7QUFDakMsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxpQkFBaUI7QUFFMUIsU0FBU0MsMkJBQTJCO0FBRXBDLE1BQU1DLFVBQVVBLE1BQU07QUFBQUMsS0FBQTtBQUNwQixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSXpCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUMwQixjQUFjQyxlQUFlLElBQUkzQixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDNEIsZUFBZUMsZ0JBQWdCLElBQUk3QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDOEIsc0JBQXNCQyx1QkFBdUIsSUFBSS9CLFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUNnQyxpQkFBaUJDLGtCQUFrQixJQUFJakMsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ2tDLHdCQUF3QkMseUJBQXlCLElBQUluQyxTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDb0MsZUFBZUMsZ0JBQWdCLElBQUlyQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDc0MsaUJBQWlCQyxrQkFBa0IsSUFBSXZDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUN3QyxXQUFXQyxZQUFZLElBQUl6QyxTQUFTLENBQUMsQ0FBQztBQUM3QyxRQUFNLENBQUMwQyxXQUFXQyxZQUFZLElBQUkzQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDNEMsaUJBQWlCQyxrQkFBa0IsSUFBSTdDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM4QyxjQUFjQyxlQUFlLElBQUkvQyxTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDZ0QsaUJBQWlCQyxrQkFBa0IsSUFBSWpELFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNrRCxvQkFBb0JDLHFCQUFxQixJQUFJbkQsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQ29ELGlCQUFpQkMsa0JBQWtCLElBQUlyRCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDc0QsV0FBV0MsWUFBWSxJQUFJdkQsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3dELGFBQWFDLGNBQWMsSUFBSXpELFNBQVMsTUFBTTtBQUNyRCxRQUFNLENBQUMwRCxZQUFZQyxhQUFhLElBQUkzRCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEQsV0FBV0MsWUFBWSxJQUFJN0QsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzhELGlCQUFpQkMsa0JBQWtCLElBQUkvRCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDZ0UsZUFBZUMsZ0JBQWdCLElBQUlqRSxTQUFTLE9BQU87QUFDMUQsUUFBTSxDQUFDa0Usb0JBQW9CQyxxQkFBcUIsSUFBSW5FLFNBQVMsRUFBRTtBQUUvRCxRQUFNb0UsTUFBTSxvQkFBSUMsS0FBSztBQUNyQixRQUFNQyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekNaLGtCQUFjWSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsRUFDOUI7QUFDQSxRQUFNQyxjQUFjTixJQUFJTyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbEQsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJOUUsU0FBUzBFLFdBQVc7QUFDcEUsUUFBTSxDQUFDSyxjQUFjQyxlQUFlLElBQUloRixTQUFTMEUsV0FBVztBQUM1RCxRQUFNLENBQUNPLHFCQUFxQkMsc0JBQXNCLElBQUlsRixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDbUYsaUJBQWlCQyxrQkFBa0IsSUFBSXBGLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNxRixxQkFBcUJDLHNCQUFzQixJQUFJdEYsU0FBUyxFQUFFO0FBQ2pFLFFBQU0sQ0FBQ3VGLG1CQUFtQkMsb0JBQW9CLElBQUl4RixTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDeUYsVUFBVUMsV0FBVyxJQUFJMUYsU0FBUyxFQUFFO0FBRTNDLFFBQU0sQ0FBQzJGLGlCQUFpQkMsa0JBQWtCLElBQUk1RixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDNkYsaUJBQWlCQyxrQkFBa0IsSUFBSTlGLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUMrRixRQUFRQyxTQUFTLElBQUloRyxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDaUcsUUFBUUMsU0FBUyxJQUFJbEcsU0FBUyxFQUFFO0FBRXZDLFFBQU0sQ0FBQ21HLHFCQUFxQkMsc0JBQXNCLElBQUlwRyxTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDcUcsVUFBVUMsV0FBVyxJQUFJdEcsU0FBUztBQUFBLElBQ3ZDdUcsVUFBVTtBQUFBLElBQ1ZDLFNBQVM7QUFBQSxJQUNUQyxRQUFRO0FBQUEsSUFDUkMsWUFBWTtBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxjQUFjcEI7QUFBQUEsSUFDZHFCLFlBQVluQjtBQUFBQSxJQUNab0IsaUJBQWlCO0FBQUEsRUFDbkIsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJbkgsU0FBUztBQUFBLElBQzdDb0gsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUl4SCxTQUFTO0FBQUEsSUFDdkN5SCxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUEsRUFDaEIsQ0FBQztBQUNELFFBQU1DLG1CQUFtQkEsTUFBTXhFLG1CQUFtQixLQUFLO0FBQ3ZEdEQsWUFBVSxNQUFNO0FBQ2QsVUFBTStILE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBRS9CLFFBQ0VHLFdBQ0FBLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxjQUNuRDtBQUNBLFlBQU1DLG9CQUNKTixRQUFRRyx1QkFBdUJDLG9CQUFvQkMsaUJBQ25ELFNBQ0ksT0FDQTtBQUNObEMsNkJBQXVCbUMsaUJBQWlCO0FBQUEsSUFDMUM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUNMeEksWUFBVSxNQUFNO0FBQ2QsVUFBTStILE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBRS9CLFFBQ0VHLFdBQ0FBLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxjQUNuRDtBQUNBLFlBQU1FLFdBQ0pQLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxpQkFDbkQsU0FDSSxPQUNBO0FBQ05sRCx5QkFBbUJvRCxRQUFRO0FBQUEsSUFDN0I7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUNMekksWUFBVSxNQUFNO0FBQ2QsVUFBTTBJLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNeEksSUFBSXlJLElBQUksd0JBQXdCO0FBQ3ZEbEgsa0JBQVVpSCxTQUFTRSxJQUFJO0FBQUEsTUFDekIsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUosZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUNMMUksWUFBVSxNQUFNO0FBQ2QsS0FBQyxZQUFZO0FBQ1gsVUFBSTtBQUNGLGNBQU0sQ0FBQ2dKLFdBQVc5QyxPQUFNLElBQUksTUFBTStDLFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUM1Qy9JLElBQUl5SSxJQUFJLFdBQVc7QUFBQSxZQUNuQnpJLElBQUl5SSxJQUFJLHVCQUF1QjtBQUFBLFVBQUM7QUFBQSxRQUNqQztBQUNELGNBQU1PLE9BQU9ILFdBQVdILE1BQU1PLFNBQVNDLElBQUksQ0FBQ0MsU0FBUztBQUFBLFVBQ25EQyxLQUFLRCxJQUFJQztBQUFBQSxVQUNUQyxXQUFXRixJQUFJRztBQUFBQSxVQUNmQyxjQUFjSixJQUFJSTtBQUFBQSxVQUNsQkMsZUFBZTtBQUFBLFFBQ2pCLEVBQUU7QUFDRjFELGtCQUFVa0QsSUFBSTtBQUNkLGNBQU1TLE9BQU8xRCxTQUFRMkMsTUFBTVEsSUFBSSxDQUFDUSxRQUFRO0FBQUEsVUFDdENOLEtBQUtNLElBQUlOO0FBQUFBLFVBQ1RDLFdBQVdLLElBQUlKO0FBQUFBLFVBQ2ZDLGNBQWNHLElBQUlDO0FBQUFBLFVBQ2xCSCxlQUFlO0FBQUEsUUFDakIsRUFBRTtBQUNGeEQsa0JBQVV5RCxJQUFJO0FBQ2RiLGdCQUFRZ0IsSUFBSUgsTUFBTSxNQUFNO0FBQUEsTUFDMUIsU0FBU2QsT0FBTztBQUNkM0Msa0JBQVUsRUFBRTtBQUNaRixrQkFBVSxFQUFFO0FBQUEsTUFDZDtBQUFBLElBQ0YsR0FBRztBQUFBLEVBQ0wsR0FBRyxFQUFFO0FBQ0xqRyxZQUFVLE1BQU07QUFDZCxVQUFNZ0ssZUFBZSxZQUFZO0FBQy9CLFVBQUk7QUFDRixjQUFNckIsV0FBVyxNQUFNeEksSUFBSXlJLElBQUksNkJBQTZCO0FBQzVEcEYscUJBQWFtRixTQUFTRSxJQUFJO0FBQUEsTUFDNUIsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFDQWtCLGlCQUFhO0FBQUEsRUFDZixHQUFHLEVBQUU7QUFFTGhLLFlBQVUsTUFBTTtBQUNkLFVBQU0wSSxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTXhJLElBQUl5SSxJQUFJLGdCQUFnQjtBQUMvQ3RHLHlCQUFpQnFHLFNBQVNFLElBQUk7QUFBQSxNQUNoQyxTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBSixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUwxSSxZQUFVLE1BQU07QUFDZCxRQUFJdUQsV0FBVztBQUNiZ0Qsa0JBQVksQ0FBQzBELGNBQWM7QUFBQSxRQUN6QixHQUFHQTtBQUFBQSxRQUNIdEQsWUFBWXBELFVBQVVvRDtBQUFBQSxNQUN4QixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0YsR0FBRyxDQUFDcEQsU0FBUyxDQUFDO0FBRWQsUUFBTTJHLGVBQWVBLENBQUMxRixNQUFNO0FBQzFCLFVBQU0sRUFBRWlGLE1BQU0vRSxNQUFNLElBQUlGLEVBQUVDO0FBQzFCOEIsZ0JBQVksQ0FBQzBELGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNSLElBQUksR0FBRy9FO0FBQUFBLElBQ1YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNeUYsbUJBQW1CQSxDQUFDM0YsTUFBTTtBQUM5QixVQUFNLEVBQUVpRixNQUFNL0UsTUFBTSxJQUFJRixFQUFFQztBQUMxQixVQUFNLENBQUNnQyxTQUFTQyxNQUFNLElBQUloQyxNQUFNRyxNQUFNLEdBQUc7QUFDekMwQixnQkFBWSxDQUFDMEQsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0h4RDtBQUFBQSxNQUNBQztBQUFBQSxJQUNGLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTTBELGNBQWMsT0FBT0MsVUFBVTtBQUNuQyxVQUFNQyxVQUFVRCxNQUFNNUYsT0FBT0M7QUFDN0J4Qyx1QkFBbUJvSSxPQUFPO0FBQzFCL0QsZ0JBQVksQ0FBQ2dFLGtCQUFrQjtBQUFBLE1BQzdCLEdBQUdBO0FBQUFBLE1BQ0gvRCxVQUFVOEQ7QUFBQUEsSUFDWixFQUFFO0FBRUZFLHNCQUFrQkYsT0FBTztBQUV6QixRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU0zQixXQUFXLE1BQU14SSxJQUFJeUksSUFBSSwwQkFBMEIwQixPQUFPLEVBQUU7QUFDbEU1SCxxQkFBYWlHLFNBQVNFLFFBQVEsQ0FBQyxDQUFDO0FBQUEsTUFDbEMsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFDakRwRyxxQkFBYSxDQUFDLENBQUM7QUFBQSxNQUNqQjtBQUFBLElBQ0YsT0FBTztBQUNMQSxtQkFBYSxDQUFDLENBQUM7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0gsZUFBZTtBQUFBLElBQ25CLEVBQUUvRixPQUFPLFNBQVNnRyxPQUFPLFFBQVE7QUFBQSxJQUNqQyxFQUFFaEcsT0FBTyxhQUFhZ0csT0FBTyxZQUFZO0FBQUEsSUFDekMsRUFBRWhHLE9BQU8sYUFBYWdHLE9BQU8sYUFBYTtBQUFBLElBQzFDLEVBQUVoRyxPQUFPLGFBQWFnRyxPQUFPLGFBQWE7QUFBQSxJQUMxQyxFQUFFaEcsT0FBTyxZQUFZZ0csT0FBTyxZQUFZO0FBQUEsSUFDeEMsRUFBRWhHLE9BQU8sVUFBVWdHLE9BQU8sU0FBUztBQUFBLEVBQUM7QUFHdEMsUUFBTUMscUJBQXFCLE9BQU9MLFlBQVk7QUFFNUNsSSw4QkFBMEJrSSxPQUFPO0FBQUEsRUFDbkM7QUFFQSxRQUFNTSxxQkFBcUJBLENBQUNsRyxVQUFVO0FBQ3BDUixxQkFBaUJRLEtBQUs7QUFFdEJWLHVCQUFtQixLQUFLO0FBRXhCLFVBQU02RyxRQUFRLG9CQUFJdkcsS0FBSztBQUN2QixVQUFNd0csYUFBYUEsQ0FBQ0MsU0FBU0EsS0FBS0MsbUJBQW1CLE9BQU87QUFFNUQsUUFBSXRHLFVBQVUsU0FBUztBQUNyQixZQUFNdUcsWUFBWUgsV0FBV0QsS0FBSztBQUNsQzlGLDBCQUFvQmtHLFNBQVM7QUFDN0JoRyxzQkFBZ0JnRyxTQUFTO0FBQUEsSUFDM0IsV0FBV3ZHLFVBQVUsYUFBYTtBQUNoQyxZQUFNd0csWUFBWSxJQUFJNUcsS0FBS3VHLEtBQUs7QUFDaENLLGdCQUFVQyxRQUFRRCxVQUFVRSxRQUFRLElBQUksQ0FBQztBQUN6QyxZQUFNSCxZQUFZSCxXQUFXSSxTQUFTO0FBQ3RDbkcsMEJBQW9Ca0csU0FBUztBQUM3QmhHLHNCQUFnQmdHLFNBQVM7QUFBQSxJQUMzQixXQUFXdkcsVUFBVSxhQUFhO0FBQ2hDLFlBQU0yRyxRQUFRLElBQUkvRyxLQUFLdUcsTUFBTVMsWUFBWSxHQUFHVCxNQUFNVSxTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUlsSCxLQUFLdUcsTUFBTVMsWUFBWSxHQUFHVCxNQUFNVSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFeEcsMEJBQW9CK0YsV0FBV08sS0FBSyxDQUFDO0FBQ3JDcEcsc0JBQWdCNkYsV0FBV1UsR0FBRyxDQUFDO0FBQUEsSUFDakMsV0FBVzlHLFVBQVUsYUFBYTtBQUNoQyxZQUFNMkcsUUFBUSxJQUFJL0csS0FBS3VHLE1BQU1TLFlBQVksR0FBR1QsTUFBTVUsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNuRSxZQUFNQyxNQUFNLElBQUlsSCxLQUFLdUcsTUFBTVMsWUFBWSxHQUFHVCxNQUFNVSxTQUFTLEdBQUcsQ0FBQztBQUM3RHhHLDBCQUFvQitGLFdBQVdPLEtBQUssQ0FBQztBQUNyQ3BHLHNCQUFnQjZGLFdBQVdVLEdBQUcsQ0FBQztBQUFBLElBQ2pDLFdBQVc5RyxVQUFVLFlBQVk7QUFDL0IsWUFBTTJHLFFBQVEsSUFBSS9HLEtBQUt1RyxNQUFNUyxZQUFZLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQU1FLE1BQU0sSUFBSWxILEtBQUt1RyxNQUFNUyxZQUFZLEdBQUcsSUFBSSxFQUFFO0FBQ2hEdkcsMEJBQW9CK0YsV0FBV08sS0FBSyxDQUFDO0FBQ3JDcEcsc0JBQWdCNkYsV0FBV1UsR0FBRyxDQUFDO0FBQUEsSUFDakMsV0FBVzlHLFVBQVUsVUFBVTtBQUM3QlYseUJBQW1CLElBQUk7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNeUgsZ0JBQWdCQSxDQUFDQyxlQUFlO0FBQ3BDLFVBQU1YLE9BQU8sSUFBSXpHLEtBQUtvSCxVQUFVO0FBQ2hDLFVBQU1DLFVBQVUsRUFBRUMsS0FBSyxXQUFXQyxPQUFPLFFBQVFDLE1BQU0sVUFBVTtBQUNqRSxXQUFPZixLQUFLQyxtQkFBbUIsU0FBU1csT0FBTyxFQUFFSSxRQUFRLEtBQUssRUFBRTtBQUFBLEVBQ2xFO0FBRUEvTDtBQUFBQSxJQUFVLE1BQU07QUFDZCxZQUFNZ00sa0JBQWtCLElBQUlDLGdCQUFnQjtBQUM1QyxZQUFNQyxnQkFBZ0IsWUFBWTtBQUNoQyxZQUFJO0FBQ0ZwSSx1QkFBYSxJQUFJO0FBQ2pCLGdCQUFNNkUsV0FBVyxNQUFNeEksSUFBSXlJLElBQUksK0JBQStCO0FBQUEsWUFDNUR1RCxRQUFRO0FBQUEsY0FDTkMsV0FBV3RIO0FBQUFBLGNBQ1h1SCxTQUFTckg7QUFBQUEsY0FDVHNGLFNBQVNuSTtBQUFBQSxjQUNUbUssUUFBUTlHO0FBQUFBLGNBQ1JzQixVQUFVNUI7QUFBQUEsY0FDVnFILGNBQWNqSDtBQUFBQSxjQUNkMEIsY0FBY3BCO0FBQUFBLGNBQ2RxQixZQUFZbkI7QUFBQUEsY0FDWjBHLFNBQVNySTtBQUFBQSxZQUNYO0FBQUEsWUFDQXNJLFFBQVFULGdCQUFnQlM7QUFBQUEsVUFDMUIsQ0FBQztBQUNEMUQsa0JBQVEyRCxLQUFLL0QsU0FBU0UsTUFBTSxzQkFBc0I7QUFDbEQsY0FBSUYsU0FBU0UsUUFBUUYsU0FBU0UsS0FBSzhELFNBQVMsR0FBRztBQUM3QyxrQkFBTUMsZ0JBQWdCakUsU0FBU0UsS0FBS2dFO0FBQUFBLGNBQ2xDLENBQUNDLFlBQVlBLFFBQVF0RyxhQUFhO0FBQUEsWUFDcEM7QUFFQWhFLCtCQUFtQm9LLGFBQWE7QUFFaEMsa0JBQU1HLGNBQWNILGNBQWNJO0FBQUFBLGNBQ2hDLENBQUNDLEtBQUtILFlBQVlHLE1BQU1DLE9BQU9KLFFBQVFqRyxVQUFVLENBQUM7QUFBQSxjQUNsRDtBQUFBLFlBQ0Y7QUFDQWtDLG9CQUFRMkQsS0FBS0ssYUFBYSxjQUFjO0FBQ3hDcEgsd0JBQVlvSCxXQUFXO0FBRXZCLGtCQUFNSSxnQkFBZ0JQLGNBQWN2RCxJQUFJLENBQUMrRCxPQUFPQyxXQUFXO0FBQUEsY0FDekQ5RCxLQUFLNkQsT0FBTzdEO0FBQUFBLGNBQ1orRCxJQUFJRCxRQUFRO0FBQUEsY0FDWnRDLE1BQU1xQyxPQUFPeEc7QUFBQUEsY0FDYndHLE9BQU9BLE9BQU81RyxVQUFVK0csY0FBY0gsTUFBTVo7QUFBQUEsY0FDNUMvQyxNQUFNMkQsT0FBTzNHLFNBQVMrQztBQUFBQSxjQUN0QmdFLFVBQVVKLE9BQU9aLFdBQVc7QUFBQSxjQUM1QjlDLGNBQWMwRCxPQUFPM0csU0FBU2lEO0FBQUFBLGNBQzlCL0MsWUFBWXlHLE9BQU96RztBQUFBQSxjQUNuQjhHLGdCQUFnQkwsT0FBT0s7QUFBQUEsY0FDdkIvRyxRQUFRMEcsT0FBT3pGLE9BQ1h5RixNQUFNekYsTUFBTStGLFVBQ1pOLE9BQU9PLFFBQ0xQLE1BQU1PLE9BQU9DLFdBQ2JSLE9BQU8xRztBQUFBQSxjQUNiRyxRQUFRdUcsT0FBT3ZHO0FBQUFBLGNBQ2ZnSCxrQkFBa0JULE9BQU9VLFdBQVdqSixNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsY0FDbERrSixNQUFNWCxPQUFPdEc7QUFBQUEsY0FDYnlGLGNBQWNhLE9BQU9iO0FBQUFBLGNBQ3JCckYsaUJBQWlCa0csT0FBT2xHO0FBQUFBLGNBQ3hCRixjQUNFb0csT0FBT3BHLGNBQWN5QyxRQUNyQjJELE9BQU9uRyxZQUFZK0csY0FDbkI7QUFBQSxjQUNGQyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLGtCQUNqQixNQUFNO0FBQUEsb0JBQ0pDLE9BQU87QUFBQSxzQkFDTDtBQUFBLHdCQUNFQyxLQUFLO0FBQUEsd0JBQ0x6RCxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFFBQU87QUFBQSw0QkFDUCxJQUFJLFVBQVUwQyxNQUFNN0QsR0FBRztBQUFBLDRCQUN2QixXQUFVO0FBQUEsNEJBQWtCO0FBQUE7QUFBQSwwQkFIOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU1BO0FBQUEsc0JBRUo7QUFBQSxvQkFBQztBQUFBLGtCQUVMO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBcEJqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FxQkEsS0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxZQUVKLEVBQUU7QUFHRixnQkFBSTZFLFlBQVk7QUFDaEIsZ0JBQUlDLFlBQVk7QUFDaEIsZ0JBQUlDLGFBQWE7QUFDakIsZ0JBQUlDLFdBQVc7QUFFZjNCLDBCQUFjNEIsUUFBUSxDQUFDQyxNQUFNO0FBQzNCLG9CQUFNNUgsU0FBU3FHLE9BQU91QixFQUFFNUgsVUFBVSxDQUFDO0FBR25DLG9CQUFNNkgsU0FBU0QsRUFBRWpDLFdBQVcsSUFDekJtQyxZQUFZLEVBQ1o5SixNQUFNLEdBQUcsRUFDVHdFLElBQUksQ0FBQ3VGLE1BQU1BLEVBQUVDLEtBQUssQ0FBQyxFQUNuQmhDLE9BQU9pQyxPQUFPO0FBR2pCLGtCQUFJSixNQUFNL0IsV0FBVyxLQUFLK0IsTUFBTUssU0FBUyxNQUFNLEdBQUc7QUFDaERYLDZCQUFhdkg7QUFBQUEsY0FDZjtBQUVBLGtCQUFJNkgsTUFBTUssU0FBUyxNQUFNLEdBQUc7QUFDMUJWLDZCQUFheEg7QUFBQUEsY0FDZjtBQUVBLGtCQUFJNkgsTUFBTUssU0FBUyxPQUFPLEdBQUc7QUFDM0JULDhCQUFjekg7QUFBQUEsY0FDaEI7QUFHQSxrQkFBSTZILE1BQU1LLFNBQVMsS0FBSyxHQUFHO0FBQ3pCUiw0QkFBWTFIO0FBQUFBLGNBQ2Q7QUFBQSxZQUNGLENBQUM7QUFFRFksd0JBQVk7QUFBQSxjQUNWQyxNQUFNMEc7QUFBQUEsY0FDTnpHLE1BQU0wRztBQUFBQSxjQUNOekcsT0FBTzBHO0FBQUFBLGNBQ1B6RyxjQUFjMEc7QUFBQUEsWUFDaEIsQ0FBQztBQUVEM00sNEJBQWdCdUwsYUFBYTtBQUFBLFVBQy9CLE9BQU87QUFDTDNLLCtCQUFtQixFQUFFO0FBQUEsVUFDdkI7QUFBQSxRQUNGLFNBQVNzRyxPQUFPO0FBQ2RDLGtCQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRHRHLDZCQUFtQixFQUFFO0FBQ3JCbUQsc0JBQVksQ0FBQztBQUFBLFFBQ2YsVUFBQztBQUNDN0IsdUJBQWEsS0FBSztBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUVBb0ksb0JBQWM7QUFDZCxhQUFPLE1BQU07QUFDWEYsd0JBQWdCZ0QsTUFBTTtBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUFBLElBQUc7QUFBQSxNQUNEN007QUFBQUEsTUFDQTZDO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FNO0FBQUFBLE1BQ0FWO0FBQUFBLE1BQ0FRO0FBQUFBLE1BQ0FNO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0EzQjtBQUFBQSxJQUFrQjtBQUFBLEVBQ25CO0FBRUQsUUFBTThLLFVBQVU7QUFBQSxJQUNkLEVBQUVkLEtBQUssTUFBTWUsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRWYsS0FBSyxRQUFRZSxRQUFRLFlBQVk7QUFBQSxJQUNuQyxFQUFFZixLQUFLLG9CQUFvQmUsUUFBUSxtQkFBbUI7QUFBQSxJQUN0RCxFQUFFZixLQUFLLFNBQVNlLFFBQVEsYUFBYTtBQUFBLElBQ3JDLEVBQUVmLEtBQUssUUFBUWUsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFZixLQUFLLFlBQVllLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVmLEtBQUssZ0JBQWdCZSxRQUFRLHdCQUF3QjtBQUFBLElBQ3ZELEVBQUVmLEtBQUssY0FBY2UsUUFBUSxpQkFBaUI7QUFBQSxJQUM5QyxFQUFFZixLQUFLLGtCQUFrQmUsUUFBUSxjQUFjO0FBQUEsSUFDL0MsRUFBRWYsS0FBSyxVQUFVZSxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFZixLQUFLLFVBQVVlLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVmLEtBQUssUUFBUWUsUUFBUSxlQUFlO0FBQUEsSUFDdEMsR0FBSTlKLGtCQUNBLENBQUMsRUFBRStJLEtBQUssZ0JBQWdCZSxRQUFRLGVBQWUsQ0FBQyxJQUNoRDtBQUFBLElBQ0osRUFBRWYsS0FBSyxtQkFBbUJlLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRWYsS0FBSyxnQkFBZ0JlLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVmLEtBQUssVUFBVWUsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQ2xQLFlBQVUsTUFBTTtBQUNkLFFBQUl5QyxhQUFhNkQsU0FBUzZJLFlBQVk7QUFDcEMsWUFBTUMsYUFBYzNNLFVBQVU0TSxjQUFjLElBQUssT0FBTztBQUN4RCxZQUFNQyxjQUNIN00sVUFBVTRNLGVBQWUsTUFBTS9JLFNBQVM2SSxjQUFjO0FBQ3pELFlBQU1JLFlBQVlqSixTQUFTNkksY0FBYyxLQUFLQztBQUM5QyxZQUFNSSxnQkFBZ0IvTSxVQUFVZ04sZ0JBQzVCRixXQUFXOU0sVUFBVWdOLGdCQUNyQjtBQUNKLFlBQU1DLFdBQVdqTixVQUFVa04saUJBQWlCLEtBQUtIO0FBRWpEakosa0JBQVksQ0FBQzBELGNBQWM7QUFBQSxRQUN6QixHQUFHQTtBQUFBQSxRQUNIekQsVUFBVS9ELFVBQVU4RztBQUFBQSxRQUNwQjZGO0FBQUFBLFFBQ0FFO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsQ0FBQ2pOLFdBQVc2RCxTQUFTNkksVUFBVSxDQUFDO0FBRW5DLFFBQU1TLDBCQUEwQkEsQ0FBQ3BMLE1BQU07QUFDckMsVUFBTXFMLGVBQWVyTCxFQUFFQyxPQUFPQztBQUM5QmhCLG1CQUFlbU0sWUFBWTtBQUMzQnRKLGdCQUFZLENBQUMwRCxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSG5ELFVBQVUrSTtBQUFBQSxNQUNWOUksZ0JBQWdCOEksaUJBQWlCLFdBQVc1RixTQUFTbEQsaUJBQWlCO0FBQUEsSUFDeEUsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNK0ksZUFBZSxPQUFPdEwsTUFBTTtBQUNoQ0EsTUFBRXVMLGVBQWU7QUFDakIsUUFBSTtBQUNGLFlBQU1wSCxXQUFXLE1BQU14SSxJQUFJNlAsS0FBSyx3QkFBd0IxSixRQUFRO0FBQ2hFLFVBQUlxQyxTQUFTc0gsV0FBVyxLQUFLO0FBQzNCQyxjQUFNLDRCQUE0QjtBQUNsQ3ROLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0YsU0FBU2tHLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxrQ0FBa0NBLEtBQUs7QUFBQSxJQUN2RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNcUgsd0JBQXdCLE9BQU83RixZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNM0IsV0FBVyxNQUFNeEksSUFBSXlJLElBQUksOEJBQThCMEIsT0FBTyxFQUFFO0FBQ3RFdEgsc0JBQWdCMkYsU0FBU0UsSUFBSTtBQUM3Qi9GLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBU2dHLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwwQkFBMEJBLEtBQUs7QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxRQUFNc0gsc0JBQXNCLFlBQVk7QUFDdEMsUUFBSXJOLGNBQWM7QUFDaEIsVUFBSTtBQUNGLGNBQU01QyxJQUFJa1EsT0FBTywyQkFBMkJ0TixhQUFhd0csR0FBRyxFQUFFO0FBQzlEMkcsY0FBTSw4QkFBOEI7QUFDcENwTiwyQkFBbUIsS0FBSztBQUN4QkUsd0JBQWdCLElBQUk7QUFDcEJzTixlQUFPQyxTQUFTQyxPQUFPO0FBQUEsTUFDekIsU0FBUzFILE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMkJBQTJCQSxLQUFLO0FBQUEsTUFDaEQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU0ySCx3QkFBd0IsT0FBT25HLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU0zQixXQUFXLE1BQU14SSxJQUFJeUksSUFBSSw4QkFBOEIwQixPQUFPLEVBQUU7QUFDdEVsSCw0QkFBc0J1RixTQUFTRSxJQUFJO0FBQ25DM0YseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTNEYsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDJCQUEyQkEsS0FBSztBQUFBLElBQ2hEO0FBQUEsRUFDRjtBQUVBLFFBQU00SCxtQkFBbUIsT0FBT2xNLE1BQU07QUFDcENBLE1BQUV1TCxlQUFlO0FBRWpCLFVBQU1ZLFlBQVksSUFBSUMsU0FBUztBQUMvQixVQUFNQyxZQUFZck0sRUFBRUMsT0FBT3FNO0FBQzNCLFFBQUlELGFBQWFBLFVBQVVFLE1BQU0sQ0FBQyxHQUFHO0FBQ25DSixnQkFBVUssT0FBTyxRQUFRSCxVQUFVRSxNQUFNLENBQUMsQ0FBQztBQUUzQyxVQUFJO0FBQ0YsY0FBTXBJLFdBQVcsTUFBTXhJLElBQUk2UCxLQUFLLDBCQUEwQlcsV0FBVztBQUFBLFVBQ25FTSxTQUFTLEVBQUUsZ0JBQWdCLHNCQUFzQjtBQUFBLFFBQ25ELENBQUM7QUFFRCxZQUFJdEksU0FBU3NILFdBQVcsS0FBSztBQUMzQkMsZ0JBQU0sNkJBQTZCO0FBQ25DSSxpQkFBT0MsU0FBU0MsT0FBTztBQUN2QmxOLDZCQUFtQixLQUFLO0FBQUEsUUFDMUI7QUFBQSxNQUNGLFNBQVN3RixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUM1Q29ILGNBQU0sd0JBQXdCO0FBQUEsTUFDaEM7QUFBQSxJQUNGLE9BQU87QUFDTEEsWUFBTSxpQ0FBaUM7QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNDLGlDQUFDLFNBQUksV0FBVSxzREFDWixpQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFlBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1CO0FBQUEsSUFFbkI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU0vSSxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQTtBQUFBQSxNQUh2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHK0I7QUFBQSxJQUUvQix1QkFBQyxTQUFJLFdBQVUseUZBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxtR0FBa0csaUNBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQix5REFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw2REFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3RkFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSxzQkFBcUIsNkJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsVUFDL0MsdUJBQUMsUUFBRyxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsWUFDcENFLFNBQVNFLEtBQUt3SixlQUFlLE9BQU87QUFBQSxlQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSx3RkFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSxzQkFBcUIsNkJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsVUFDL0MsdUJBQUMsUUFBRyxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsWUFDcEMxSixTQUFTRyxLQUFLdUosZUFBZSxPQUFPO0FBQUEsZUFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsc0JBQXFCLDhCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQ2hELHVCQUFDLFFBQUcsV0FBVSwyQkFBMEI7QUFBQTtBQUFBLFlBQ3BDMUosU0FBU0ksTUFBTXNKLGVBQWUsT0FBTztBQUFBLGVBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLG9GQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHNCQUFxQixpQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUNuRCx1QkFBQyxRQUFHLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSxZQUNwQzFKLFNBQVNLLGFBQWFxSixlQUFlLE9BQU87QUFBQSxlQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxvRUFDWjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsU0FBUTtBQUFBLGdCQUVSO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLGVBQWM7QUFBQSxvQkFDZCxnQkFBZTtBQUFBLG9CQUNmLGFBQWE7QUFBQSxvQkFDYixHQUFFO0FBQUE7QUFBQSxrQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSTZKO0FBQUE7QUFBQSxjQVYvSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLFlBQU07QUFBQSxlQWJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx1RUFFYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDJDQUEwQyw2QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0M7QUFBQSxrQkFDQSx1QkFBdUI7QUFBQSxrQkFDdkIsVUFBVXRHO0FBQUFBLGtCQUNWLE9BQU8zRztBQUFBQSxrQkFDUCxhQUFZO0FBQUEsa0JBQ1osY0FBYyxDQUFDa04sT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVDNDLFlBQVksRUFDWkksU0FBU29DLE1BQU14QyxZQUFZLENBQUM7QUFBQSxrQkFFakMsV0FBVTtBQUFBLGtCQUVUbEUsdUJBQWFwQjtBQUFBQSxvQkFBSSxDQUFDa0ksU0FDakIsdUJBQUMsT0FBTyxRQUFQLEVBQStCLE9BQU9BLEtBQUs3TSxPQUN6QzZNLGVBQUs3RyxTQURZNkcsS0FBSzdNLE9BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW1CQTtBQUFBLGlCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLFlBR0NYLG1CQUNDLG1DQUNFO0FBQUEscUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsMkNBQTBDLHlCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU9lO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQ04sTUFBTU8sb0JBQW9CUCxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsb0JBQ25ELFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJNko7QUFBQSxtQkFSL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsMkNBQTBDLHVCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU9NO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQ1IsTUFBTVMsZ0JBQWdCVCxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsb0JBQy9DLFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJNko7QUFBQSxtQkFSL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGlCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQTtBQUFBLFlBSUYsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLHFCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQztBQUFBLGtCQUNBLHVCQUF1QjtBQUFBLGtCQUN2QixPQUFPdkM7QUFBQUEsa0JBQ1AsVUFBVXdJO0FBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixjQUFjLENBQUN3RyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUM0MsWUFBWSxFQUNaSSxTQUFTb0MsTUFBTXhDLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFPLElBQUksbUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZCO0FBQUEsb0JBQzVCbE4sT0FBTzRIO0FBQUFBLHNCQUFJLENBQUMrRCxVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNN0QsS0FDekM2RCxnQkFBTUcsY0FEV0gsTUFBTTdELEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUE7QUFBQSxnQkFuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBb0JBO0FBQUEsaUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsd0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDO0FBQUEsa0JBQ0EsdUJBQXVCO0FBQUEsa0JBQ3ZCLE9BQU8vRDtBQUFBQSxrQkFDUCxjQUFjLENBQUMyTCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUM0MsWUFBWSxFQUNaSSxTQUFTb0MsTUFBTXhDLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxhQUFZO0FBQUEsa0JBQ1osVUFBVSxDQUFDckUsWUFBWTdFLHFCQUFxQjZFLE9BQU87QUFBQSxrQkFDbkQsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQjtBQUFBLG9CQUMxQmpJLGNBQWNnSDtBQUFBQSxzQkFBSSxDQUFDK0QsVUFDbEIsdUJBQUMsT0FBTyxRQUFQLEVBQStCLE9BQU9BLE9BQU83RCxLQUMzQzZEO0FBQUFBLCtCQUFPNUQ7QUFBQUEsd0JBQVU7QUFBQSx3QkFBSTRELE1BQU0xRDtBQUFBQSwyQkFEVjBELE9BQU83RCxLQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBO0FBQUEsZ0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW9CQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNENBQTJDLDRCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT3JFO0FBQUFBLGtCQUNQO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QixVQUFVLENBQUNzTSxVQUFVO0FBQ25Cck0sMkNBQXVCcU0sS0FBSztBQUFBLGtCQUM5QjtBQUFBLGtCQUNBLGNBQWMsQ0FBQ0wsT0FBT0MsV0FDcEJBLE9BQU8xRyxNQUNKNEcsU0FBUyxFQUNUM0MsWUFBWSxFQUNaSSxTQUFTb0MsTUFBTXhDLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTyxFQUFFOEMsUUFBUSxPQUFPO0FBQUEsa0JBQ3hCLFNBQVM7QUFBQSxvQkFDUCxFQUFFL0csT0FBTyxRQUFRaEcsT0FBTyxPQUFPO0FBQUEsb0JBQy9CLEVBQUVnRyxPQUFPLFVBQVVoRyxPQUFPLFNBQVM7QUFBQSxvQkFDbkMsRUFBRWdHLE9BQU8sZ0JBQWdCaEcsT0FBTyxlQUFlO0FBQUEsa0JBQUM7QUFBQTtBQUFBLGdCQXBCcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBcUJJO0FBQUEsaUJBMUJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw0Q0FBMkMsMkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPUDtBQUFBQSxrQkFDUDtBQUFBLGtCQUNBLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkIsVUFBVSxDQUFDcU4sVUFBVTtBQUNuQnBOLDBDQUFzQm9OLEtBQUs7QUFBQSxrQkFDN0I7QUFBQSxrQkFDQSxjQUFjLENBQUNMLE9BQU9DLFdBQ3BCQSxPQUFPMUcsTUFDSjRHLFNBQVMsRUFDVDNDLFlBQVksRUFDWkksU0FBU29DLE1BQU14QyxZQUFZLENBQUM7QUFBQSxrQkFFakMsV0FBVTtBQUFBLGtCQUNWLE9BQU8sRUFBRThDLFFBQVEsT0FBTztBQUFBLGtCQUN4QixTQUFTO0FBQUEsb0JBQ1AsRUFBRS9HLE9BQU8sUUFBUWhHLE9BQU8sT0FBTztBQUFBLG9CQUMvQixFQUFFZ0csT0FBTyxTQUFTaEcsT0FBTyxRQUFRO0FBQUEsb0JBQ2pDLEVBQUVnRyxPQUFPLFFBQVFoRyxPQUFPLE9BQU87QUFBQSxvQkFDL0IsRUFBRWdHLE9BQU8sZ0JBQWdCaEcsT0FBTyxlQUFlO0FBQUEsa0JBQUM7QUFBQTtBQUFBLGdCQXJCcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBc0JJO0FBQUEsaUJBM0JOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsWUFFQzBCLHVCQUNDLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDJDQUEwQyw0QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT2Q7QUFBQUEsa0JBQ1A7QUFBQSxrQkFDQSxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCLFVBQVUsQ0FBQ2dGLFlBQVkvRSx1QkFBdUIrRSxPQUFPO0FBQUEsa0JBQ3JELGNBQWMsQ0FBQzZHLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1QzQyxZQUFZLEVBQ1pJLFNBQVNvQyxNQUFNeEMsWUFBWSxDQUFDO0FBQUEsa0JBRWpDLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxtQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sWUFBVyx3QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0M7QUFBQSxvQkFDeEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvQztBQUFBLG9CQUNwQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLGNBQWEsMEJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUE7QUFBQTtBQUFBLGdCQXRCdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdUJBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsWUFJRix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsbUNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QixVQUFVLENBQUMrQyxjQUFjO0FBQ3ZCLDBCQUFNLENBQUNwRSxJQUFJL0YsSUFBSSxJQUFJbUssVUFBVTdNLE1BQU0sR0FBRyxLQUFLO0FBQzNDLHdCQUFJMEMsU0FBUyxjQUFjO0FBQ3pCeEIseUNBQW1CdUgsRUFBRTtBQUNyQnpILHlDQUFtQixFQUFFO0FBQUEsb0JBQ3ZCLFdBQVcwQixTQUFTLGNBQWM7QUFDaEMxQix5Q0FBbUJ5SCxFQUFFO0FBQ3JCdkgseUNBQW1CLEVBQUU7QUFBQSxvQkFDdkIsT0FBTztBQUNMQSx5Q0FBbUIsRUFBRTtBQUNyQkYseUNBQW1CLEVBQUU7QUFBQSxvQkFDdkI7QUFBQSxrQkFDRjtBQUFBLGtCQUNBLGNBQWMsQ0FBQ3NMLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1QzQyxZQUFZLEVBQ1pJLFNBQVNvQyxNQUFNeEMsWUFBWSxDQUFDO0FBQUEsa0JBRWpDLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkI7QUFBQSxvQkFDMUIsQ0FBQyxHQUFHLElBQUlnRCxJQUFJM0wsTUFBTSxHQUFHLEdBQUcsSUFBSTJMLElBQUl6TCxNQUFNLENBQUMsRUFBRW1EO0FBQUFBLHNCQUFJLENBQUN1SSxPQUM3QztBQUFBLHdCQUFDLE9BQU87QUFBQSx3QkFBUDtBQUFBLDBCQUVDLE9BQU8sR0FBR0EsR0FBR3JJLEdBQUcsSUFBSXFJLEdBQUdqSSxhQUFhO0FBQUEsMEJBRW5DaUk7QUFBQUEsK0JBQUdqSSxrQkFBa0IsZUFDbEIsYUFDQTtBQUFBLDRCQUNIaUksR0FBR3BJO0FBQUFBLDRCQUFVO0FBQUEsNEJBQUlvSSxHQUFHbEk7QUFBQUE7QUFBQUE7QUFBQUEsd0JBTmhCa0ksSUFBSXJJO0FBQUFBLHdCQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBUUE7QUFBQSxvQkFDRDtBQUFBO0FBQUE7QUFBQSxnQkFwQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBcUNBO0FBQUEsaUJBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMENBO0FBQUEsZUF4UEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5UEE7QUFBQSxhQTNRRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNFFBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUsK0tBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxVQUN6Rix1QkFBQyxTQUFJLFdBQVUsK0VBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyxTQUFJLFdBQVUsbUdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0c7QUFBQSxVQUUvRyx1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxPQUFFLFdBQVUsOERBQTZELG9DQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxTQUNDLGlDQUFDLFVBQUssV0FBVSw0REFBMkQ7QUFBQTtBQUFBLGdCQUV4RTdELFdBQ0d3SCxPQUFPeEgsUUFBUSxFQUFFd0wsZUFBZSxTQUFTO0FBQUEsa0JBQ3ZDVyx1QkFBdUI7QUFBQSxrQkFDdkJDLHVCQUF1QjtBQUFBLGdCQUN6QixDQUFDLElBQ0Q7QUFBQSxtQkFQTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBRUEsdUJBQUMsU0FDQyxpQ0FBQyxVQUFLLFdBQVUsbURBQ2JwTSxxQkFDR3BFLG9CQUFvQjRMLE9BQU94SCxRQUFRLENBQUMsSUFDcEMsZUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGlCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHNDQUNiLGlDQUFDLE9BQUUsV0FBVSxtREFDWDtBQUFBLHFDQUFDLFVBQUssa0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUTtBQUFBLGNBQ1IsdUJBQUMsVUFBSyxzREFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QztBQUFBLGlCQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUNBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsd0dBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0g7QUFBQSxhQTFDdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJDQSxLQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkNBO0FBQUEsUUFHQ25ELG1CQUFtQkEsZ0JBQWdCb0ssU0FBUyxLQUFLLENBQUM5SSxZQUNqRCx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBQ0wsUUFBTztBQUFBLGdCQUNQLFNBQVE7QUFBQSxnQkFFUjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxlQUFjO0FBQUEsb0JBQ2QsZ0JBQWU7QUFBQSxvQkFDZixhQUFhO0FBQUEsb0JBQ2IsR0FBRTtBQUFBO0FBQUEsa0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUkwSDtBQUFBO0FBQUEsY0FWNUg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsK0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU0zQyxhQUFhUyxjQUFjZ0MsVUFBVTtBQUFBLGNBQzNDO0FBQUEsY0FDQSxpQkFBaUI7QUFBQSxjQUNqQixrQkFBa0I7QUFBQTtBQUFBLFlBSnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUkwQztBQUFBLFVBRzFDLHVCQUFDLFNBQUksV0FBVSx1REFDYixpQ0FBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsVUFBSyxXQUFVLG1DQUFrQztBQUFBO0FBQUEsWUFDbEM7QUFBQSxZQUNkLHVCQUFDLFVBQUssV0FBVSxtQkFBa0I7QUFBQTtBQUFBLGNBQzlCK0IsVUFBVXdMLGVBQWU7QUFBQSxpQkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFDQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwwRUFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFNBQVMzTyxnQkFBZ0JvSyxVQUFVO0FBQUEsWUFDbkMsTUFBSztBQUFBO0FBQUEsVUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHcUIsS0FKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsV0E5V0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdYQTtBQUFBLFNBN1pGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4WkE7QUFBQSxPQXhhRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeWFBLEtBMWFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyYUMsS0E1YUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZhQTtBQUVKO0FBQUVuTCxHQTM5QklELFNBQU87QUFBQXdRLEtBQVB4UTtBQTY5Qk4sZUFBZUE7QUFBUSxJQUFBd1E7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsImFwaSIsIk1kRGVsZXRlIiwiQ2lFZGl0IiwiTW9kYWwiLCJCc0V5ZSIsIlVwbG9hZE1vZGFsIiwiYXhpb3MiLCJ1cmwiLCJTZWxlY3QiLCJEcm9wZG93biIsIkRhdGFUYWJsZSIsIkN1c3RvbUFsZXJ0IiwiRW5kbGVzc0NpcmN1bGFyTG9hZGVyIiwiQ2lyY3VsYXJMb2FkZXIiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJJb01kTW9yZSIsIkxpbmsiLCJmaWVsZFNpemUiLCJudW1iZXJUb0luZGlhbldvcmRzIiwiUmVjZWlwdCIsIl9zIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiVGFibGVEYXlib29rIiwic2V0VGFibGVEYXlib29rIiwic2VsZWN0ZWRHcm91cCIsInNldFNlbGVjdGVkR3JvdXAiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cCIsInNldFNlbGVjdGVkQXVjdGlvbkdyb3VwIiwic2VsZWN0ZWRHcm91cElkIiwic2V0U2VsZWN0ZWRHcm91cElkIiwic2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsInNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQiLCJmaWx0ZXJlZFVzZXJzIiwic2V0RmlsdGVyZWRVc2VycyIsImZpbHRlcmVkQXVjdGlvbiIsInNldEZpbHRlcmVkQXVjdGlvbiIsImdyb3VwSW5mbyIsInNldEdyb3VwSW5mbyIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsImN1cnJlbnRHcm91cCIsInNldEN1cnJlbnRHcm91cCIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRVcGRhdGVHcm91cCIsInNldEN1cnJlbnRVcGRhdGVHcm91cCIsInNob3dVcGxvYWRNb2RhbCIsInNldFNob3dVcGxvYWRNb2RhbCIsInJlY2VpcHRObyIsInNldFJlY2VpcHRObyIsInBheW1lbnRNb2RlIiwic2V0UGF5bWVudE1vZGUiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNob3dGaWx0ZXJGaWVsZCIsInNldFNob3dGaWx0ZXJGaWVsZCIsInNlbGVjdGVkTGFiZWwiLCJzZXRTZWxlY3RlZExhYmVsIiwic2VsZWN0ZWRQYXltZW50Rm9yIiwic2V0U2VsZWN0ZWRQYXltZW50Rm9yIiwibm93IiwiRGF0ZSIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInRvZGF5U3RyaW5nIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInNlbGVjdGVkRnJvbURhdGUiLCJzZXRTZWxlY3RlZEZyb21EYXRlIiwic2VsZWN0ZWREYXRlIiwic2V0U2VsZWN0ZWREYXRlIiwic2VsZWN0ZWRQYXltZW50TW9kZSIsInNldFNlbGVjdGVkUGF5bWVudE1vZGUiLCJoaWRlQWNjb3VudFR5cGUiLCJzZXRIaWRlQWNjb3VudFR5cGUiLCJzZWxlY3RlZEFjY291bnRUeXBlIiwic2V0U2VsZWN0ZWRBY2NvdW50VHlwZSIsInNlbGVjdGVkQ3VzdG9tZXJzIiwic2V0U2VsZWN0ZWRDdXN0b21lcnMiLCJwYXltZW50cyIsInNldFBheW1lbnRzIiwiY29sbGVjdGlvbkFnZW50Iiwic2V0Q29sbGVjdGlvbkFnZW50IiwiY29sbGVjdGlvbkFkbWluIiwic2V0Q29sbGVjdGlvbkFkbWluIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwiYWRtaW5zIiwic2V0QWRtaW5zIiwic2hvd0FsbFBheW1lbnRNb2RlcyIsInNldFNob3dBbGxQYXltZW50TW9kZXMiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZ3JvdXBfaWQiLCJ1c2VyX2lkIiwidGlja2V0IiwicmVjZWlwdF9ubyIsInBheV9kYXRlIiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsImNvbGxlY3RlZF9ieSIsImFkbWluX3R5cGUiLCJjb2xsZWN0aW9uX3RpbWUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwib3ZlcnZpZXciLCJzZXRPdmVydmlldyIsImNoaXQiLCJsb2FuIiwicGlnbXkiLCJyZWdpc3RyYXRpb24iLCJoYW5kbGVNb2RhbENsb3NlIiwidXNlciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyT2JqIiwiSlNPTiIsInBhcnNlIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50Iiwic2hvd1BheW1lbnRzTW9kZXMiLCJpc01vZGlmeSIsImZldGNoR3JvdXBzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZW1wbG95ZWVzIiwiUHJvbWlzZSIsImFsbCIsImVtcHMiLCJlbXBsb3llZSIsIm1hcCIsImVtcCIsIl9pZCIsImZ1bGxfbmFtZSIsIm5hbWUiLCJwaG9uZV9udW1iZXIiLCJzZWxlY3RlZF90eXBlIiwiYWRtcyIsImFkIiwicGhvbmVOdW1iZXIiLCJsb2ciLCJmZXRjaFJlY2VpcHQiLCJwcmV2RGF0YSIsImhhbmRsZUNoYW5nZSIsImhhbmRsZUNoYW5nZVVzZXIiLCJoYW5kbGVHcm91cCIsImV2ZW50IiwiZ3JvdXBJZCIsInByZXZGb3JtRGF0YSIsImhhbmRsZUdyb3VwQ2hhbmdlIiwiZ3JvdXBPcHRpb25zIiwibGFiZWwiLCJoYW5kbGVHcm91cFBheW1lbnQiLCJoYW5kbGVTZWxlY3RGaWx0ZXIiLCJ0b2RheSIsImZvcm1hdERhdGUiLCJkYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZm9ybWF0dGVkIiwieWVzdGVyZGF5Iiwic2V0RGF0ZSIsImdldERhdGUiLCJzdGFydCIsImdldEZ1bGxZZWFyIiwiZ2V0TW9udGgiLCJlbmQiLCJmb3JtYXRQYXlEYXRlIiwiZGF0ZVN0cmluZyIsIm9wdGlvbnMiLCJkYXkiLCJtb250aCIsInllYXIiLCJyZXBsYWNlIiwiYWJvcnRDb250cm9sbGVyIiwiQWJvcnRDb250cm9sbGVyIiwiZmV0Y2hQYXltZW50cyIsInBhcmFtcyIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJ1c2VySWQiLCJhY2NvdW50X3R5cGUiLCJwYXlfZm9yIiwic2lnbmFsIiwiaW5mbyIsImxlbmd0aCIsInZhbGlkUGF5bWVudHMiLCJmaWx0ZXIiLCJwYXltZW50IiwidG90YWxBbW91bnQiLCJyZWR1Y2UiLCJzdW0iLCJOdW1iZXIiLCJmb3JtYXR0ZWREYXRhIiwiZ3JvdXAiLCJpbmRleCIsImlkIiwiZ3JvdXBfbmFtZSIsImNhdGVnb3J5Iiwib2xkX3JlY2VpcHRfbm8iLCJsb2FuX2lkIiwicGlnbWUiLCJwaWdtZV9pZCIsInRyYW5zYWN0aW9uX2RhdGUiLCJjcmVhdGVkQXQiLCJtb2RlIiwiYWRtaW5fbmFtZSIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwiY2hpdFRvdGFsIiwibG9hblRvdGFsIiwicGlnbXlUb3RhbCIsInJlZ1RvdGFsIiwiZm9yRWFjaCIsInAiLCJoZWFkcyIsInRvTG93ZXJDYXNlIiwiaCIsInRyaW0iLCJCb29sZWFuIiwiaW5jbHVkZXMiLCJhYm9ydCIsImNvbHVtbnMiLCJoZWFkZXIiLCJiaWRfYW1vdW50IiwiY29tbWlzc2lvbiIsImdyb3VwX3ZhbHVlIiwid2luX2Ftb3VudCIsImRpdmlkZW50IiwiZGl2aWRlbnRfaGVhZCIsImdyb3VwX21lbWJlcnMiLCJwYXlhYmxlIiwiZ3JvdXBfaW5zdGFsbCIsImhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlIiwic2VsZWN0ZWRNb2RlIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJwb3N0Iiwic3RhdHVzIiwiYWxlcnQiLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJoYW5kbGVEZWxldGVBdWN0aW9uIiwiZGVsZXRlIiwid2luZG93IiwibG9jYXRpb24iLCJyZWxvYWQiLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJoYW5kbGVGaWxlU3VibWl0IiwiZm9ybURhdGFzIiwiRm9ybURhdGEiLCJmaWxlSW5wdXQiLCJmaWxlIiwiZmlsZXMiLCJhcHBlbmQiLCJoZWFkZXJzIiwidG9Mb2NhbGVTdHJpbmciLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0aW1lIiwibW9kZXMiLCJoZWlnaHQiLCJzZWxlY3Rpb24iLCJTZXQiLCJkdCIsIm1pbmltdW1GcmFjdGlvbkRpZ2l0cyIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlY2VpcHQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IHsgTWREZWxldGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuaW1wb3J0IHsgQ2lFZGl0IH0gZnJvbSBcInJlYWN0LWljb25zL2NpXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IHsgQnNFeWUgfSBmcm9tIFwicmVhY3QtaWNvbnMvYnNcIjtcclxuaW1wb3J0IFVwbG9hZE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9VcGxvYWRNb2RhbFwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB1cmwgZnJvbSBcIi4uL2RhdGEvVXJsXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgRHJvcGRvd24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IEVuZGxlc3NDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0VuZGxlc3NDaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuXHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcblxyXG5jb25zdCBSZWNlaXB0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlRGF5Ym9vaywgc2V0VGFibGVEYXlib29rXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cCwgc2V0U2VsZWN0ZWRHcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBdWN0aW9uR3JvdXAsIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwSWQsIHNldFNlbGVjdGVkR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZmlsdGVyZWRVc2Vycywgc2V0RmlsdGVyZWRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkQXVjdGlvbiwgc2V0RmlsdGVyZWRBdWN0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBJbmZvLCBzZXRHcm91cEluZm9dID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwLCBzZXRDdXJyZW50R3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dVcGxvYWRNb2RhbCwgc2V0U2hvd1VwbG9hZE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVjZWlwdE5vLCBzZXRSZWNlaXB0Tm9dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3BheW1lbnRNb2RlLCBzZXRQYXltZW50TW9kZV0gPSB1c2VTdGF0ZShcImNhc2hcIik7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiVG9kYXlcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGF5bWVudEZvciwgc2V0U2VsZWN0ZWRQYXltZW50Rm9yXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCB0b2RheVN0cmluZyA9IG5vdy50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyaW5nKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYXltZW50TW9kZSwgc2V0U2VsZWN0ZWRQYXltZW50TW9kZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2hpZGVBY2NvdW50VHlwZSwgc2V0SGlkZUFjY291bnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEFjY291bnRUeXBlLCBzZXRTZWxlY3RlZEFjY291bnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVycywgc2V0U2VsZWN0ZWRDdXN0b21lcnNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3BheW1lbnRzLCBzZXRQYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IFtjb2xsZWN0aW9uQWdlbnQsIHNldENvbGxlY3Rpb25BZ2VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY29sbGVjdGlvbkFkbWluLCBzZXRDb2xsZWN0aW9uQWRtaW5dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWRtaW5zLCBzZXRBZG1pbnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbc2hvd0FsbFBheW1lbnRNb2Rlcywgc2V0U2hvd0FsbFBheW1lbnRNb2Rlc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBncm91cF9pZDogXCJcIixcclxuICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICB0aWNrZXQ6IFwiXCIsXHJcbiAgICByZWNlaXB0X25vOiBcIlwiLFxyXG4gICAgcGF5X2RhdGU6IFwiXCIsXHJcbiAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgIGNvbGxlY3RlZF9ieTogY29sbGVjdGlvbkFnZW50LFxyXG4gICAgYWRtaW5fdHlwZTogY29sbGVjdGlvbkFkbWluLFxyXG4gICAgY29sbGVjdGlvbl90aW1lOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW292ZXJ2aWV3LCBzZXRPdmVydmlld10gPSB1c2VTdGF0ZSh7XHJcbiAgICBjaGl0OiAwLFxyXG4gICAgbG9hbjogMCxcclxuICAgIHBpZ215OiAwLFxyXG4gICAgcmVnaXN0cmF0aW9uOiAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IGhhbmRsZU1vZGFsQ2xvc2UgPSAoKSA9PiBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcblxyXG4gICAgaWYgKFxyXG4gICAgICB1c2VyT2JqICYmXHJcbiAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudFxyXG4gICAgKSB7XHJcbiAgICAgIGNvbnN0IHNob3dQYXltZW50c01vZGVzID1cclxuICAgICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnQgPT09XHJcbiAgICAgICAgXCJ0cnVlXCJcclxuICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgc2V0U2hvd0FsbFBheW1lbnRNb2RlcyhzaG93UGF5bWVudHNNb2Rlcyk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcblxyXG4gICAgaWYgKFxyXG4gICAgICB1c2VyT2JqICYmXHJcbiAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudFxyXG4gICAgKSB7XHJcbiAgICAgIGNvbnN0IGlzTW9kaWZ5ID1cclxuICAgICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnQgPT09XHJcbiAgICAgICAgXCJ0cnVlXCJcclxuICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgc2V0SGlkZUFjY291bnRUeXBlKGlzTW9kaWZ5KTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBbZW1wbG95ZWVzLCBhZG1pbnNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgYXBpLmdldChcIi9lbXBsb3llZVwiKSxcclxuICAgICAgICAgIGFwaS5nZXQoXCIvYWRtaW4vZ2V0LXN1Yi1hZG1pbnNcIiksXHJcbiAgICAgICAgXSk7XHJcbiAgICAgICAgY29uc3QgZW1wcyA9IGVtcGxveWVlcz8uZGF0YT8uZW1wbG95ZWUubWFwKChlbXApID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGVtcC5faWQsXHJcbiAgICAgICAgICBmdWxsX25hbWU6IGVtcC5uYW1lLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBlbXAucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgc2VsZWN0ZWRfdHlwZTogXCJhZ2VudF90eXBlXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldEFnZW50cyhlbXBzKTtcclxuICAgICAgICBjb25zdCBhZG1zID0gYWRtaW5zPy5kYXRhPy5tYXAoKGFkKSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBhZD8uX2lkLFxyXG4gICAgICAgICAgZnVsbF9uYW1lOiBhZD8ubmFtZSxcclxuICAgICAgICAgIHBob25lX251bWJlcjogYWQ/LnBob25lTnVtYmVyLFxyXG4gICAgICAgICAgc2VsZWN0ZWRfdHlwZTogXCJhZG1pbl90eXBlXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldEFkbWlucyhhZG1zKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhhZG1zLCBcImFkbXNcIik7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgc2V0QWRtaW5zKFtdKTtcclxuICAgICAgICBzZXRBZ2VudHMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9KSgpO1xyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hSZWNlaXB0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9wYXltZW50L2dldC1sYXRlc3QtcmVjZWlwdFwiKTtcclxuICAgICAgICBzZXRSZWNlaXB0Tm8ocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHJlY2VpcHQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hSZWNlaXB0KCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocmVjZWlwdE5vKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICByZWNlaXB0X25vOiByZWNlaXB0Tm8ucmVjZWlwdF9ubyxcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtyZWNlaXB0Tm9dKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2VVc2VyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgY29uc3QgW3VzZXJfaWQsIHRpY2tldF0gPSB2YWx1ZS5zcGxpdChcIi1cIik7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICB1c2VyX2lkLFxyXG4gICAgICB0aWNrZXQsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXAgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGNvbnN0IGdyb3VwSWQgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkZvcm1EYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2Rm9ybURhdGEsXHJcbiAgICAgIGdyb3VwX2lkOiBncm91cElkLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIGhhbmRsZUdyb3VwQ2hhbmdlKGdyb3VwSWQpO1xyXG5cclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZ3JvdXAvZ2V0LWJ5LWlkLWdyb3VwLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgICBzZXRHcm91cEluZm8ocmVzcG9uc2UuZGF0YSB8fCB7fSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIHsgdmFsdWU6IFwiVG9kYXlcIiwgbGFiZWw6IFwiVG9kYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwUGF5bWVudCA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICAvLyBjb25zdCBncm91cElkID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZChncm91cElkKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkTGFiZWwodmFsdWUpO1xyXG4gICAgLy9jb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNob3dGaWx0ZXJGaWVsZChmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHllc3RlcmRheS5zZXREYXRlKHllc3RlcmRheS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdE1vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpIC0gMSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAwLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMTEsIDMxKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4gICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBmb3JtYXRQYXlEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyaW5nKTtcclxuICAgIGNvbnN0IG9wdGlvbnMgPSB7IGRheTogXCJudW1lcmljXCIsIG1vbnRoOiBcImxvbmdcIiwgeWVhcjogXCJudW1lcmljXCIgfTtcclxuICAgIHJldHVybiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIG9wdGlvbnMpLnJlcGxhY2UoXCIsXCIsIFwiXCIpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XHJcbiAgICBjb25zdCBmZXRjaFBheW1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9wYXltZW50L2dldC1yZXBvcnQtcmVjZWlwdGAsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICBmcm9tX2RhdGU6IHNlbGVjdGVkRnJvbURhdGUsXHJcbiAgICAgICAgICAgIHRvX2RhdGU6IHNlbGVjdGVkRGF0ZSxcclxuICAgICAgICAgICAgZ3JvdXBJZDogc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCxcclxuICAgICAgICAgICAgdXNlcklkOiBzZWxlY3RlZEN1c3RvbWVycyxcclxuICAgICAgICAgICAgcGF5X3R5cGU6IHNlbGVjdGVkUGF5bWVudE1vZGUsXHJcbiAgICAgICAgICAgIGFjY291bnRfdHlwZTogc2VsZWN0ZWRBY2NvdW50VHlwZSxcclxuICAgICAgICAgICAgY29sbGVjdGVkX2J5OiBjb2xsZWN0aW9uQWdlbnQsXHJcbiAgICAgICAgICAgIGFkbWluX3R5cGU6IGNvbGxlY3Rpb25BZG1pbixcclxuICAgICAgICAgICAgcGF5X2Zvcjogc2VsZWN0ZWRQYXltZW50Rm9yLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb25zb2xlLmluZm8ocmVzcG9uc2UuZGF0YSwgXCJ0ZXN0aW5nIGFjY291bnQgdHlwZVwiKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IHZhbGlkUGF5bWVudHMgPSByZXNwb25zZS5kYXRhLmZpbHRlcihcclxuICAgICAgICAgICAgKHBheW1lbnQpID0+IHBheW1lbnQuZ3JvdXBfaWQgIT09IG51bGwsXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbih2YWxpZFBheW1lbnRzKTtcclxuXHJcbiAgICAgICAgICBjb25zdCB0b3RhbEFtb3VudCA9IHZhbGlkUGF5bWVudHMucmVkdWNlKFxyXG4gICAgICAgICAgICAoc3VtLCBwYXltZW50KSA9PiBzdW0gKyBOdW1iZXIocGF5bWVudC5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgIDAsXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgY29uc29sZS5pbmZvKHRvdGFsQW1vdW50LCBcImNoZWNrIGFtb3VudFwiKTtcclxuICAgICAgICAgIHNldFBheW1lbnRzKHRvdGFsQW1vdW50KTtcclxuXHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gdmFsaWRQYXltZW50cy5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgX2lkOiBncm91cD8uX2lkLFxyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBkYXRlOiBncm91cD8ucGF5X2RhdGUsXHJcbiAgICAgICAgICAgIGdyb3VwOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgZ3JvdXAucGF5X2ZvcixcclxuICAgICAgICAgICAgbmFtZTogZ3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgY2F0ZWdvcnk6IGdyb3VwPy5wYXlfZm9yIHx8IFwiQ2hpdFwiLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgIHJlY2VpcHRfbm86IGdyb3VwPy5yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICBvbGRfcmVjZWlwdF9ubzogZ3JvdXA/Lm9sZF9yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICB0aWNrZXQ6IGdyb3VwPy5sb2FuXHJcbiAgICAgICAgICAgICAgPyBncm91cC5sb2FuPy5sb2FuX2lkIFxyXG4gICAgICAgICAgICAgIDogZ3JvdXA/LnBpZ21lXHJcbiAgICAgICAgICAgICAgICA/IGdyb3VwLnBpZ21lPy5waWdtZV9pZFxyXG4gICAgICAgICAgICAgICAgOiBncm91cD8udGlja2V0LFxyXG4gICAgICAgICAgICBhbW91bnQ6IGdyb3VwPy5hbW91bnQsXHJcbiAgICAgICAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IGdyb3VwPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKT8uWzBdLFxyXG4gICAgICAgICAgICBtb2RlOiBncm91cD8ucGF5X3R5cGUsXHJcbiAgICAgICAgICAgIGFjY291bnRfdHlwZTogZ3JvdXA/LmFjY291bnRfdHlwZSxcclxuICAgICAgICAgICAgY29sbGVjdGlvbl90aW1lOiBncm91cD8uY29sbGVjdGlvbl90aW1lLFxyXG4gICAgICAgICAgICBjb2xsZWN0ZWRfYnk6XHJcbiAgICAgICAgICAgICAgZ3JvdXA/LmNvbGxlY3RlZF9ieT8ubmFtZSB8fFxyXG4gICAgICAgICAgICAgIGdyb3VwPy5hZG1pbl90eXBlPy5hZG1pbl9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgXCJTdXBlciBBZG1pblwiLFxyXG4gICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YC9wcmludC8ke2dyb3VwLl9pZH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgICAgLy8gPT09PT0gQ0FURUdPUlkgVE9UQUxTID09PT09XHJcbiAgICAgICAgICBsZXQgY2hpdFRvdGFsID0gMDtcclxuICAgICAgICAgIGxldCBsb2FuVG90YWwgPSAwO1xyXG4gICAgICAgICAgbGV0IHBpZ215VG90YWwgPSAwO1xyXG4gICAgICAgICAgbGV0IHJlZ1RvdGFsID0gMDtcclxuXHJcbiAgICAgICAgICB2YWxpZFBheW1lbnRzLmZvckVhY2goKHApID0+IHtcclxuICAgICAgICAgICAgY29uc3QgYW1vdW50ID0gTnVtYmVyKHAuYW1vdW50IHx8IDApO1xyXG5cclxuICAgICAgICAgICAgLy8gc3BsaXQgaGVhZHMgc2FmZWx5XHJcbiAgICAgICAgICAgIGNvbnN0IGhlYWRzID0gKHAucGF5X2ZvciB8fCBcIlwiKVxyXG4gICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgLnNwbGl0KFwifFwiKVxyXG4gICAgICAgICAgICAgIC5tYXAoKGgpID0+IGgudHJpbSgpKVxyXG4gICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbik7XHJcblxyXG4gICAgICAgICAgICAvLyBJZiBlbXB0eSDihpIgZGVmYXVsdCBjaGl0IHBheW1lbnQgKG9sZCBkYXRhIHN1cHBvcnQpXHJcbiAgICAgICAgICAgIGlmIChoZWFkcy5sZW5ndGggPT09IDAgfHwgaGVhZHMuaW5jbHVkZXMoXCJjaGl0XCIpKSB7XHJcbiAgICAgICAgICAgICAgY2hpdFRvdGFsICs9IGFtb3VudDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGhlYWRzLmluY2x1ZGVzKFwibG9hblwiKSkge1xyXG4gICAgICAgICAgICAgIGxvYW5Ub3RhbCArPSBhbW91bnQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChoZWFkcy5pbmNsdWRlcyhcInBpZ21lXCIpKSB7XHJcbiAgICAgICAgICAgICAgcGlnbXlUb3RhbCArPSBhbW91bnQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIFJlZ2lzdHJhdGlvbiAoaGFuZGxlcyBSZWcsIFJlZ3xDaGl0LCBSZWd8TG9hbiwgUmVnfFBpZ21lKVxyXG4gICAgICAgICAgICBpZiAoaGVhZHMuaW5jbHVkZXMoXCJyZWdcIikpIHtcclxuICAgICAgICAgICAgICByZWdUb3RhbCArPSBhbW91bnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldE92ZXJ2aWV3KHtcclxuICAgICAgICAgICAgY2hpdDogY2hpdFRvdGFsLFxyXG4gICAgICAgICAgICBsb2FuOiBsb2FuVG90YWwsXHJcbiAgICAgICAgICAgIHBpZ215OiBwaWdteVRvdGFsLFxyXG4gICAgICAgICAgICByZWdpc3RyYXRpb246IHJlZ1RvdGFsLFxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgc2V0VGFibGVEYXlib29rKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICBzZXRQYXltZW50cygwKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoUGF5bWVudHMoKTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xyXG4gICAgfTtcclxuICB9LCBbXHJcbiAgICBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLFxyXG4gICAgc2VsZWN0ZWREYXRlLFxyXG4gICAgc2VsZWN0ZWRQYXltZW50TW9kZSxcclxuICAgIHNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgc2VsZWN0ZWRGcm9tRGF0ZSxcclxuICAgIHNlbGVjdGVkQWNjb3VudFR5cGUsXHJcbiAgICBjb2xsZWN0aW9uQWdlbnQsXHJcbiAgICBjb2xsZWN0aW9uQWRtaW4sXHJcbiAgICBzZWxlY3RlZFBheW1lbnRGb3IsXHJcbiAgXSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlBhaWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY2F0ZWdvcnlcIiwgaGVhZGVyOiBcIkNhdGVnb3J5XCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcIm9sZF9yZWNlaXB0X25vXCIsIGhlYWRlcjogXCJPbGQgUmVjZWlwdFwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJtb2RlXCIsIGhlYWRlcjogXCJQYXltZW50IE1vZGVcIiB9LFxyXG4gICAgLi4uKGhpZGVBY2NvdW50VHlwZVxyXG4gICAgICA/IFt7IGtleTogXCJhY2NvdW50X3R5cGVcIiwgaGVhZGVyOiBcIkFjY291bnQgVHlwZVwiIH1dXHJcbiAgICAgIDogW10pLFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGlvbl90aW1lXCIsIGhlYWRlcjogXCJDb2xsZWN0aW9uIFRpbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGVkX2J5XCIsIGhlYWRlcjogXCJDb2xsZWN0ZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoZ3JvdXBJbmZvICYmIGZvcm1EYXRhLmJpZF9hbW91bnQpIHtcclxuICAgICAgY29uc3QgY29tbWlzc2lvbiA9IChncm91cEluZm8uZ3JvdXBfdmFsdWUgKiA1KSAvIDEwMCB8fCAwO1xyXG4gICAgICBjb25zdCB3aW5fYW1vdW50ID1cclxuICAgICAgICAoZ3JvdXBJbmZvLmdyb3VwX3ZhbHVlIHx8IDApIC0gKGZvcm1EYXRhLmJpZF9hbW91bnQgfHwgMCk7XHJcbiAgICAgIGNvbnN0IGRpdmlkZW50ID0gKGZvcm1EYXRhLmJpZF9hbW91bnQgfHwgMCkgLSBjb21taXNzaW9uO1xyXG4gICAgICBjb25zdCBkaXZpZGVudF9oZWFkID0gZ3JvdXBJbmZvLmdyb3VwX21lbWJlcnNcclxuICAgICAgICA/IGRpdmlkZW50IC8gZ3JvdXBJbmZvLmdyb3VwX21lbWJlcnNcclxuICAgICAgICA6IDA7XHJcbiAgICAgIGNvbnN0IHBheWFibGUgPSAoZ3JvdXBJbmZvLmdyb3VwX2luc3RhbGwgfHwgMCkgLSBkaXZpZGVudF9oZWFkO1xyXG5cclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgIGdyb3VwX2lkOiBncm91cEluZm8uX2lkLFxyXG4gICAgICAgIGNvbW1pc3Npb24sXHJcbiAgICAgICAgd2luX2Ftb3VudCxcclxuICAgICAgICBkaXZpZGVudCxcclxuICAgICAgICBkaXZpZGVudF9oZWFkLFxyXG4gICAgICAgIHBheWFibGUsXHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICB9LCBbZ3JvdXBJbmZvLCBmb3JtRGF0YS5iaWRfYW1vdW50XSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkTW9kZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0UGF5bWVudE1vZGUoc2VsZWN0ZWRNb2RlKTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIHBheV90eXBlOiBzZWxlY3RlZE1vZGUsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBzZWxlY3RlZE1vZGUgPT09IFwib25saW5lXCIgPyBwcmV2RGF0YS50cmFuc2FjdGlvbl9pZCA6IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXCIvcGF5bWVudC9hZGQtcGF5bWVudFwiLCBmb3JtRGF0YSk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwMSkge1xyXG4gICAgICAgIGFsZXJ0KFwiUGF5bWVudCBBZGRlZCBTdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHN1Ym1pdHRpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvZ2V0LXBheW1lbnQtYnktaWQvJHtncm91cElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50R3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGw6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVBdWN0aW9uID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRHcm91cCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9wYXltZW50L2RlbGV0ZS1wYXltZW50LyR7Y3VycmVudEdyb3VwLl9pZH1gKTtcclxuICAgICAgICBhbGVydChcIlBheW1lbnQgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBhdWN0aW9uOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9nZXQtYXVjdGlvbi1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGF1Y3Rpb246XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBjb25zdCBmb3JtRGF0YXMgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgIGNvbnN0IGZpbGVJbnB1dCA9IGUudGFyZ2V0LmZpbGU7XHJcbiAgICBpZiAoZmlsZUlucHV0ICYmIGZpbGVJbnB1dC5maWxlc1swXSkge1xyXG4gICAgICBmb3JtRGF0YXMuYXBwZW5kKFwiZmlsZVwiLCBmaWxlSW5wdXQuZmlsZXNbMF0pO1xyXG5cclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KGAvcGF5bWVudC9wYXltZW50LWV4Y2VsYCwgZm9ybURhdGFzLCB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwMCkge1xyXG4gICAgICAgICAgYWxlcnQoXCJGaWxlIHVwbG9hZGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XHJcbiAgICAgICAgICBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBsb2FkaW5nIGZpbGU6XCIsIGVycm9yKTtcclxuICAgICAgICBhbGVydChcIkZhaWxlZCB0byB1cGxvYWQgZmlsZS5cIik7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBhIGZpbGUgdG8gdXBsb2FkLlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggZmxleC1jb2wgW2hlaWdodDpjYWxjKDEwMHZoLTEwMHB4KV0gXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbXQtMzBcIj5cclxuICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0XHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTggYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS01MCB2aWEtdmlvbGV0LTUwIHRvLWluZGlnby01MCBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCBiZy1ncmFkaWVudC10by1yIGZyb20taW5kaWdvLTYwMCB0by12aW9sZXQtNjAwIGJnLWNsaXAtdGV4dCB0ZXh0LXRyYW5zcGFyZW50XCI+XHJcbiAgICAgICAgICAgICAgICBSZXBvcnRzIC0gUmVjZWlwdFxyXG4gICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICBUcmFjayBhbmQgbWFuYWdlIGFsbCByZWNlaXB0IHRyYW5zYWN0aW9uc1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC02IG1iLThcIj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MDAgdG8taW5kaWdvLTYwMCByb3VuZGVkLTJ4bCBwLTUgdGV4dC13aGl0ZSBzaGFkb3ctbGdcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gb3BhY2l0eS04MFwiPkNoaXQgUGF5bWVudHM8L3A+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAg4oK5e292ZXJ2aWV3LmNoaXQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWVtZXJhbGQtNTAwIHRvLWdyZWVuLTYwMCByb3VuZGVkLTJ4bCBwLTUgdGV4dC13aGl0ZSBzaGFkb3ctbGdcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gb3BhY2l0eS04MFwiPkxvYW4gUGF5bWVudHM8L3A+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAg4oK5e292ZXJ2aWV3LmxvYW4udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLW9yYW5nZS01MDAgdG8tYW1iZXItNjAwIHJvdW5kZWQtMnhsIHAtNSB0ZXh0LXdoaXRlIHNoYWRvdy1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBvcGFjaXR5LTgwXCI+UGlnbXkgUGF5bWVudHM8L3A+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAg4oK5e292ZXJ2aWV3LnBpZ215LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcGluay01MDAgdG8tcm9zZS02MDAgcm91bmRlZC0yeGwgcC01IHRleHQtd2hpdGUgc2hhZG93LWxnXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIG9wYWNpdHktODBcIj5SZWdpc3RyYXRpb24gRmVlczwvcD5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICDigrl7b3ZlcnZpZXcucmVnaXN0cmF0aW9uLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgcC02IG1iLTggYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1pbmRpZ28tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMyA0YTEgMSAwIDAxMS0xaDE2YTEgMSAwIDAxMSAxdjIuNTg2YTEgMSAwIDAxLS4yOTMuNzA3bC02LjQxNCA2LjQxNGExIDEgMCAwMC0uMjkzLjcwN1YxN2wtNCA0di02LjU4NmExIDEgMCAwMC0uMjkzLS43MDdMMy4yOTMgNy4yOTNBMSAxIDAgMDEzIDYuNTg2VjR6XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgRmlsdGVyIE9wdGlvbnNcclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIHhsOmdyaWQtY29scy00IGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBGaWx0ZXIgT3B0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpbHRlciBPcHRpb25cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0RmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBPciBTZWxlY3QgRmlsdGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgodGltZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3RpbWUudmFsdWV9IHZhbHVlPXt0aW1lLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dGltZS5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEN1c3RvbSBEYXRlIFJhbmdlICovfVxyXG4gICAgICAgICAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEZyb20gRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tYWxsIG91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBUbyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tYWxsIG91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBHcm91cCBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXBcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBdWN0aW9uR3JvdXBJZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cFBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBPciBTZWxlY3QgR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPXtcIlwifT5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ3VzdG9tZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZ3JvdXBJZCkgPT4gc2V0U2VsZWN0ZWRDdXN0b21lcnMoZ3JvdXBJZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRVc2Vycy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXA/Ll9pZH0gdmFsdWU9e2dyb3VwPy5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cD8uZnVsbF9uYW1lfSAtIHtncm91cC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBQYXltZW50IE1vZGUgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUGF5bWVudE1vZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBwYXltZW50IG1vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsobW9kZXMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQYXltZW50TW9kZShtb2Rlcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogXCI0NHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJDYXNoXCIsIHZhbHVlOiBcImNhc2hcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIk9ubGluZVwiLCB2YWx1ZTogXCJvbmxpbmVcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIlBheW1lbnQgTGlua1wiLCB2YWx1ZTogXCJQYXltZW50IExpbmtcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBGb3JcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUGF5bWVudEZvcn1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IHBheW1lbnQgZm9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KG1vZGVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGF5bWVudEZvcihtb2Rlcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogXCI0NHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJDaGl0XCIsIHZhbHVlOiBcIkNoaXRcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIlBpZ21lXCIsIHZhbHVlOiBcIlBpZ21lXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJMb2FuXCIsIHZhbHVlOiBcIkxvYW5cIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIlJlZ2lzdHJhdGlvblwiLCB2YWx1ZTogXCJyZWdpc3RyYXRpb25cIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgey8qIEFjY291bnQgVHlwZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgIHtzaG93QWxsUGF5bWVudE1vZGVzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBY2NvdW50IFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEFjY291bnRUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIE9yIFNlbGVjdCBBY2NvdW50IFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGdyb3VwSWQpID0+IHNldFNlbGVjdGVkQWNjb3VudFR5cGUoZ3JvdXBJZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWNjb3VudCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJzdXNwZW5zZVwiPlN1c3BlbnNlPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImNyZWRpdFwiPkNyZWRpdDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJhZGp1c3RtZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWRqdXN0bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwib3RoZXJzXCI+T3RoZXJzPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogQ29sbGVjdGlvbiBFbXBsb3llZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ29sbGVjdGlvbiBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IENvbGxlY3Rpb24gQWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoc2VsZWN0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IFtpZCwgdHlwZV0gPSBzZWxlY3Rpb24uc3BsaXQoXCJ8XCIpIHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZSA9PT0gXCJhZG1pbl90eXBlXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDb2xsZWN0aW9uQWRtaW4oaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldENvbGxlY3Rpb25BZ2VudChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlID09PSBcImFnZW50X3R5cGVcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldENvbGxlY3Rpb25BZ2VudChpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29sbGVjdGlvbkFkbWluKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldENvbGxlY3Rpb25BZG1pbihcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDb2xsZWN0aW9uQWdlbnQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Wy4uLm5ldyBTZXQoYWdlbnRzKSwgLi4ubmV3IFNldChhZG1pbnMpXS5tYXAoKGR0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtkdD8uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHtkdC5faWR9fCR7ZHQuc2VsZWN0ZWRfdHlwZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2R0LnNlbGVjdGVkX3R5cGUgPT09IFwiYWRtaW5fdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiQWRtaW4gfCBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkFnZW50IHwgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2R0LmZ1bGxfbmFtZX0gfCB7ZHQucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFRvdGFsIEFtb3VudCBDYXJkICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1pbmRpZ28tNjAwIHZpYS12aW9sZXQtNjAwIHRvLWluZGlnby03MDAgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBwLTggdHJhbnNmb3JtIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLVsxLjAyXSBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctNDAgaC00MCBiZy13aGl0ZS8xMCByb3VuZGVkLWZ1bGwgLW1yLTIwIC1tdC0yMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIGxlZnQtMCB3LTMyIGgtMzIgYmctd2hpdGUvMTAgcm91bmRlZC1mdWxsIC1tbC0xNiAtbWItMTZcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMS8yIGxlZnQtMS8yIHctNjQgaC02NCBiZy13aGl0ZS81IHJvdW5kZWQtZnVsbCAtdHJhbnNsYXRlLXgtMS8yIC10cmFuc2xhdGUteS0xLzJcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBwLTQgIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCBzaGFkb3ctbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtd2hpdGUvNzAgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgUmVjZWlwdCBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LTR4bCBtZDp0ZXh0LTV4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gTnVtYmVyKHBheW1lbnRzKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIjAuMDBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC13aGl0ZS84NSB0ZXh0LWJhc2UgZm9udC1tZWRpdW0gYnJlYWstd29yZHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gbnVtYmVyVG9JbmRpYW5Xb3JkcyhOdW1iZXIocGF5bWVudHMpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlplcm8gT25seVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTMgYm9yZGVyLXQgYm9yZGVyLXdoaXRlLzEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzYwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7wn5OKPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CYXNlZCBvbiBhY3RpdmUgZmlsdGVycyDigKIgVXBkYXRlZCBsaXZlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ncmFkaWVudC10by1yIGZyb20tdHJhbnNwYXJlbnQgdmlhLXdoaXRlLzUgdG8tdHJhbnNwYXJlbnQgdHJhbnNmb3JtIC1za2V3LXgtMTJcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRGF0YSBUYWJsZSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIHtmaWx0ZXJlZEF1Y3Rpb24gJiYgZmlsdGVyZWRBdWN0aW9uLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1pbmRpZ28tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOSAxMmg2bS02IDRoNm0yIDVIN2EyIDIgMCAwMS0yLTJWNWEyIDIgMCAwMTItMmg1LjU4NmExIDEgMCAwMS43MDcuMjkzbDUuNDE0IDUuNDE0YTEgMSAwIDAxLjI5My43MDdWMTlhMiAyIDAgMDEtMiAyelwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUmVjZWlwdCBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlRGF5Ym9vaywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BSZWNlaXB0IFJlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YFJlcG9ydHMgUmVjZWlwdC5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LTYgcHQtNiBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1pbmRpZ28tNTAgdG8tdmlvbGV0LTUwIHB4LTYgcHktMyByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIEFtb3VudDp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtwYXltZW50cz8udG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTEyIHRleHQtY2VudGVyIGJvcmRlciBib3JkZXItZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgZmFpbHVyZT17ZmlsdGVyZWRBdWN0aW9uLmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9XCJSZWNlaXB0IERhdGFcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVjZWlwdDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1JlY2VpcHQuanN4In0=