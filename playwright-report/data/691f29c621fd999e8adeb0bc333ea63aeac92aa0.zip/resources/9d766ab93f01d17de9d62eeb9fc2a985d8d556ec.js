import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CollectionArea.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import { Input, Dropdown, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const CollectionArea = () => {
  _s();
  useEffect(() => {
    (async () => {
      try {
        const response = await api.get("/employee");
        const employees2 = response.data?.employee;
        const filteredEmp = employees2.map((emp) => ({
          value: emp._id,
          label: emp.name
        }));
        setEmployees(filteredEmp);
      } catch (error) {
        console.error("Error Occurred while fetching Employee");
        setEmployees([]);
      }
    })();
  }, []);
  const [currentCollectionArea, setCurrentCollectionArea] = useState(null);
  const [employees, setEmployees] = useState([]);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentUpdateCollectionArea, setCurrentUpdateCollectionArea] = useState(null);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [tableCollectionArea, setTableCollectionArea] = useState([]);
  const [collectionArea, setCollectionArea] = useState([]);
  const [collectionAreaData, setCollectionAreaData] = useState({
    route_name: "",
    route_pincode: "",
    agent_id: ""
  });
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [updateCollectionAreaData, setUpdateCollectionAreaData] = useState({
    route_name: "",
    route_pincode: "",
    agent_id: ""
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [searchText, setSearchText] = useState("");
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    const fetchAreaCollection = async () => {
      try {
        setIsLoading(true);
        const response = await api.get(
          "/collection-area-request/get-collection-area-data"
        );
        setCollectionArea(response.data);
        const collectionAreaData2 = response?.data.map(
          (collectionArea2, index) => {
            return {
              _id: collectionArea2?._id,
              id: index + 1,
              collection_area_code: collectionArea2?.collection_area_code,
              name: collectionArea2?.route_name,
              pincode: collectionArea2?.route_pincode,
              employee_name: collectionArea2?.agent_id?.map((emp) => emp?.name).join(","),
              employee_phone: collectionArea2?.agent_id?.map((emp) => emp?.phone_number).join(","),
              employee_id: collectionArea2?.agent_id?.map((emp) => emp?.employeeCode).join(","),
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(collectionArea2?._id),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                            lineNumber: 95,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleDeleteModalOpen(collectionArea2?._id),
                            children: "Delete"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                            lineNumber: 108,
                            columnNumber: 23
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                    lineNumber: 122,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                  lineNumber: 88,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                lineNumber: 87,
                columnNumber: 15
              }, this)
            };
          }
        );
        setTableCollectionArea(collectionAreaData2);
      } catch (error) {
        console.error("Error fetching collection area data:", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAreaCollection();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setCollectionAreaData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateCollectionAreaData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post(
        "/collection-area-request/add-collection-area-data",
        collectionAreaData,
        {
          headers: {
            "Content-Type": "application/json"
          }
        }
      );
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        type: "success",
        message: "Collection Area Added Successfully",
        visibility: true
      });
      setShowModal(false);
      setCollectionAreaData({
        route_name: "",
        route_pincode: "",
        agent_id: ""
      });
    } catch (error) {
      console.error("Error adding user:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          type: "error",
          message: `${error?.response?.data?.message}`,
          visibility: true
        });
      } else {
        setAlertConfig({
          type: "error",
          message: "An unexpected error occurred. Please try again.",
          visibility: true
        });
      }
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "collection_area_code", header: "Collection Code" },
    { key: "name", header: "Collection Area Name" },
    { key: "pincode", header: "pincode" },
    { key: "employee_name", header: "Employee" },
    { key: "employee_phone", header: "Phone Number" },
    { key: "employee_id", header: "Employee Id" },
    { key: "action", header: "Action" }
  ];
  const handleDeleteModalOpen = async (Id) => {
    try {
      const response = await api.get(
        `/collection-area-request/get-collection-area-data-by-id/${Id}`
      );
      setCurrentCollectionArea(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Collection area Data :", error);
    }
  };
  const handleUpdateModalOpen = async (Id) => {
    try {
      const response = await api.get(
        `/collection-area-request/get-collection-area-data-by-id/${Id}`
      );
      setCurrentUpdateCollectionArea(response?.data);
      setUpdateCollectionAreaData({
        agent_id: response?.data?.agent_id,
        route_name: response?.data?.route_name,
        route_pincode: response?.data?.route_pincode
      });
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching collection area data:", error);
    }
  };
  const filteredRoute = collectionArea.filter(
    (area) => area.route_name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteCollectionArea = async () => {
    if (currentCollectionArea) {
      try {
        await api.delete(
          `/collection-area-request/delete-collection-area-data-by-id/${currentCollectionArea._id}`
        );
        setAlertConfig({
          visibility: true,
          message: "Collection Area deleted successfully",
          type: "success"
        });
        setReloadTrigger((prev) => prev + 1);
        setShowModalDelete(false);
        setCurrentCollectionArea(null);
      } catch (error) {
        console.error("Error deleting Collection Area:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await api.put(
        `/collection-area-request/update-collection-area-data-by-id/${currentUpdateCollectionArea._id}`,
        updateCollectionAreaData
      );
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Collection Area Updated Successfully",
        type: "success"
      });
    } catch (error) {
      console.error("Error updating Collection Area:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error?.response?.data?.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
        lineNumber: 312,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 313,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 317,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-x-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8 min-w-max", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Collection Area" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
            lineNumber: 329,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
              },
              className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
              children: "+ Add Collection Area"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 331,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 328,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 327,
          columnNumber: 13
        }, this),
        tableCollectionArea?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(tableCollectionArea, searchText),
            columns,
            exportedPdfName: "Collection Area",
            exportedFileName: "Collection Area.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
            lineNumber: 342,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: tableCollectionArea.length <= 0,
            data: " Collection Area Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
            lineNumber: 351,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
        lineNumber: 326,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
      lineNumber: 311,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Collection Area" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
        lineNumber: 361,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "name",
              children: "Collection Area Name"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 366,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "route_name",
              value: collectionAreaData?.route_name,
              onChange: handleChange,
              id: "name",
              placeholder: "Enter the Collection Area Name",
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 372,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 365,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "apincode",
              children: "Collection Area Pincode"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 383,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "route_pincode",
              value: collectionAreaData?.route_pincode,
              onChange: handleChange,
              id: "apincode",
              placeholder: "Enter the Collection Area Pincode",
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 389,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 382,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "apincode",
              children: "Select Employee"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 400,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              mode: "multiple",
              size: "large",
              placeholder: "Please select Employee",
              optionFilterProp: "label",
              onChange: (empIdArr) => {
                handleChange({
                  target: { name: "agent_id", value: empIdArr }
                });
              },
              style: { width: "100%" },
              options: employees
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 407,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 399,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
            children: "Save Collection Area"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
            lineNumber: 422,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 421,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
        lineNumber: 364,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
      lineNumber: 360,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
      lineNumber: 359,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Collection Area" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
            lineNumber: 439,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "rname",
                  children: "Collection Area Name"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                  lineNumber: 444,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "route_name",
                  value: updateCollectionAreaData?.route_name,
                  onChange: handleInputChange,
                  id: "rname",
                  placeholder: "Enter the Collection Area Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                  lineNumber: 450,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 443,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pincode",
                  children: "Collection Area Pincode"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                  lineNumber: 462,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "route_pincode",
                  value: updateCollectionAreaData?.route_pincode,
                  onChange: handleInputChange,
                  id: "pincode",
                  placeholder: "Enter the Collection Area Pincode",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                  lineNumber: 468,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 461,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pincode",
                  children: "Select Employee"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                  lineNumber: 479,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "multiple",
                  size: "large",
                  placeholder: "Select Employee",
                  showSearch: true,
                  optionFilterProp: "label",
                  filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
                  defaultValue: updateCollectionAreaData?.agent_id,
                  onChange: (arrayElement) => handleInputChange({ target: { name: "agent_id", value: arrayElement } }),
                  style: { width: "100%" },
                  options: employees
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                  lineNumber: 485,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 478,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                lineNumber: 501,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 500,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
            lineNumber: 442,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 438,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
        lineNumber: 434,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentCollectionArea(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Collection Area" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
            lineNumber: 520,
            columnNumber: 13
          }, this),
          currentCollectionArea && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteCollectionArea();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentCollectionArea?.route_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                          lineNumber: 537,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion."
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                      lineNumber: 532,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "routeName",
                      placeholder: "Enter the Collection Area Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                      lineNumber: 542,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                  lineNumber: 531,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
                    lineNumber: 550,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
              lineNumber: 524,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
          lineNumber: 519,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
        lineNumber: 512,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
    lineNumber: 310,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx",
    lineNumber: 309,
    columnNumber: 5
  }, this);
};
_s(CollectionArea, "3ZPZ1bJd+FvwywH4wDaV8f6XP4Y=");
_c = CollectionArea;
export default CollectionArea;
var _c;
$RefreshReg$(_c, "CollectionArea");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionArea.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEY0QixTQXNOeEIsVUF0TndCOzJCQTlGNUI7QUFBbUJBLG9CQUFpQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLE9BQU9DLFVBQVVDLGNBQWM7QUFDeEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxpQkFBaUI7QUFFMUIsTUFBTUMsaUJBQWlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0JmLFlBQVUsTUFBTTtBQUNkLEtBQUMsWUFBWTtBQUNYLFVBQUk7QUFDRixjQUFNZ0IsV0FBVyxNQUFNWCxJQUFJWSxJQUFJLFdBQVc7QUFDMUMsY0FBTUMsYUFBWUYsU0FBU0csTUFBTUM7QUFDakMsY0FBTUMsY0FBY0gsV0FBVUksSUFBSSxDQUFDQyxTQUFTO0FBQUEsVUFDMUNDLE9BQU9ELElBQUlFO0FBQUFBLFVBQ1hDLE9BQU9ILElBQUlJO0FBQUFBLFFBQ2IsRUFBRTtBQUNGQyxxQkFBYVAsV0FBVztBQUFBLE1BQzFCLFNBQVNRLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0NBQXdDO0FBQ3RERCxxQkFBYSxFQUFFO0FBQUEsTUFDakI7QUFBQSxJQUNGLEdBQUc7QUFBQSxFQUNMLEdBQUcsRUFBRTtBQUNMLFFBQU0sQ0FBQ0csdUJBQXVCQyx3QkFBd0IsSUFBSUMsU0FBUyxJQUFJO0FBQ3ZFLFFBQU0sQ0FBQ2YsV0FBV1UsWUFBWSxJQUFJSyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDQyxpQkFBaUJDLGtCQUFrQixJQUFJRixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDRyw2QkFBNkJDLDhCQUE4QixJQUNoRUosU0FBUyxJQUFJO0FBQ2YsUUFBTSxDQUFDSyxpQkFBaUJDLGtCQUFrQixJQUFJTixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDTyxxQkFBcUJDLHNCQUFzQixJQUFJUixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDUyxnQkFBZ0JDLGlCQUFpQixJQUFJVixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDVyxvQkFBb0JDLHFCQUFxQixJQUFJWixTQUFTO0FBQUEsSUFDM0RhLFlBQVk7QUFBQSxJQUNaQyxlQUFlO0FBQUEsSUFDZkMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJakIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2tCLFdBQVdDLFlBQVksSUFBSW5CLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNvQixZQUFZQyxhQUFhLElBQUlyQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDc0IsZUFBZUMsZ0JBQWdCLElBQUl2QixTQUFTLENBQUM7QUFFcEQsUUFBTSxDQUFDd0IsMEJBQTBCQywyQkFBMkIsSUFBSXpCLFNBQVM7QUFBQSxJQUN2RWEsWUFBWTtBQUFBLElBQ1pDLGVBQWU7QUFBQSxJQUNmQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBRUQsUUFBTSxDQUFDVyxhQUFhQyxjQUFjLElBQUkzQixTQUFTO0FBQUEsSUFDN0M0QixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWhDLFNBQVMsRUFBRTtBQUMvQyxRQUFNaUMsNEJBQTRCQSxDQUFDQyxNQUFNO0FBQ3ZDLFVBQU0sRUFBRTNDLE1BQU0sSUFBSTJDLEVBQUVDO0FBQ3BCSCxrQkFBY3pDLEtBQUs7QUFBQSxFQUNyQjtBQUVBeEIsWUFBVSxNQUFNO0FBQ2QsVUFBTXFFLHNCQUFzQixZQUFZO0FBQ3RDLFVBQUk7QUFDRmpCLHFCQUFhLElBQUk7QUFDakIsY0FBTXBDLFdBQVcsTUFBTVgsSUFBSVk7QUFBQUEsVUFDekI7QUFBQSxRQUNGO0FBQ0EwQiwwQkFBa0IzQixTQUFTRyxJQUFJO0FBQy9CLGNBQU15QixzQkFBcUI1QixVQUFVRyxLQUFLRztBQUFBQSxVQUN4QyxDQUFDb0IsaUJBQWdCNEIsVUFBVTtBQUN6QixtQkFBTztBQUFBLGNBQ0w3QyxLQUFLaUIsaUJBQWdCakI7QUFBQUEsY0FDckI4QyxJQUFJRCxRQUFRO0FBQUEsY0FDWkUsc0JBQXNCOUIsaUJBQWdCOEI7QUFBQUEsY0FDdEM3QyxNQUFNZSxpQkFBZ0JJO0FBQUFBLGNBQ3RCMkIsU0FBUy9CLGlCQUFnQks7QUFBQUEsY0FDekIyQixlQUFlaEMsaUJBQWdCTSxVQUFVMUIsSUFBSSxDQUFBQyxRQUFPQSxLQUFLSSxJQUFJLEVBQUVnRCxLQUFLLEdBQUc7QUFBQSxjQUN2RUMsZ0JBQWdCbEMsaUJBQWdCTSxVQUFVMUIsSUFBSSxDQUFBQyxRQUFPQSxLQUFLc0QsWUFBWSxFQUFFRixLQUFLLEdBQUc7QUFBQSxjQUNoRkcsYUFBYXBDLGlCQUFnQk0sVUFBVTFCLElBQUksQ0FBQUMsUUFBT0EsS0FBS3dELFlBQVksRUFBRUosS0FBSyxHQUFHO0FBQUEsY0FDN0VLLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsa0JBQ2pCLE1BQU07QUFBQSxvQkFDSkMsT0FBTztBQUFBLHNCQUNMO0FBQUEsd0JBQ0VDLEtBQUs7QUFBQSx3QkFDTHhELE9BQ0U7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVMsTUFDUHlELHNCQUFzQnpDLGlCQUFnQmpCLEdBQUc7QUFBQSw0QkFDMUM7QUFBQTtBQUFBLDBCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFPQTtBQUFBLHNCQUVKO0FBQUEsc0JBQ0E7QUFBQSx3QkFDRXlELEtBQUs7QUFBQSx3QkFDTHhELE9BQ0U7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVMsTUFDUDBELHNCQUFzQjFDLGlCQUFnQmpCLEdBQUc7QUFBQSw0QkFDMUM7QUFBQTtBQUFBLDBCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFPQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUM7QUFBQSxrQkFFTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQWxDakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUNBLEtBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUNBO0FBQUEsWUFFSjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBRUFnQiwrQkFBdUJHLG1CQUFrQjtBQUFBLE1BQzNDLFNBQVNmLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0NBQXdDQSxNQUFNaUMsT0FBTztBQUFBLE1BQ3JFLFVBQUM7QUFDQ1YscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBaUIsd0JBQW9CO0FBQUEsRUFDdEIsR0FBRyxDQUFDZCxhQUFhLENBQUM7QUFFbEIsUUFBTThCLGVBQWVBLENBQUNsQixNQUFNO0FBQzFCLFVBQU0sRUFBRXhDLE1BQU1ILE1BQU0sSUFBSTJDLEVBQUVDO0FBRTFCdkIsMEJBQXNCLENBQUN5QyxjQUFjO0FBQUEsTUFDbkMsR0FBR0E7QUFBQUEsTUFDSCxDQUFDM0QsSUFBSSxHQUFHSDtBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTStELG9CQUFvQkEsQ0FBQ3BCLE1BQU07QUFDL0IsVUFBTSxFQUFFeEMsTUFBTUgsTUFBTSxJQUFJMkMsRUFBRUM7QUFDMUJWLGdDQUE0QixDQUFDNEIsY0FBYztBQUFBLE1BQ3pDLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQzNELElBQUksR0FBR0g7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1nRSxlQUFlLE9BQU9yQixNQUFNO0FBQ2hDQSxNQUFFc0IsZUFBZTtBQUVqQixRQUFJO0FBQ0YsWUFBTXBGLElBQUlxRjtBQUFBQSxRQUNSO0FBQUEsUUFDQTlDO0FBQUFBLFFBQ0E7QUFBQSxVQUNFK0MsU0FBUztBQUFBLFlBQ1AsZ0JBQWdCO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBbkMsdUJBQWlCLENBQUNvQyxTQUFTQSxPQUFPLENBQUM7QUFDbkNoQyxxQkFBZTtBQUFBLFFBQ2JHLE1BQU07QUFBQSxRQUNORCxTQUFTO0FBQUEsUUFDVEQsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUVEWCxtQkFBYSxLQUFLO0FBRWxCTCw0QkFBc0I7QUFBQSxRQUNwQkMsWUFBWTtBQUFBLFFBQ1pDLGVBQWU7QUFBQSxRQUNmQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxTQUFTbkIsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHNCQUFzQkEsS0FBSztBQUN6QyxVQUNFQSxNQUFNYixZQUNOYSxNQUFNYixTQUFTRyxRQUNmVSxNQUFNYixTQUFTRyxLQUFLMkMsU0FDcEI7QUFDQUYsdUJBQWU7QUFBQSxVQUNiRyxNQUFNO0FBQUEsVUFDTkQsU0FBUyxHQUFHakMsT0FBT2IsVUFBVUcsTUFBTTJDLE9BQU87QUFBQSxVQUMxQ0QsWUFBWTtBQUFBLFFBQ2QsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMRCx1QkFBZTtBQUFBLFVBQ2JHLE1BQU07QUFBQSxVQUNORCxTQUFTO0FBQUEsVUFDVEQsWUFBWTtBQUFBLFFBQ2QsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1nQyxVQUFVO0FBQUEsSUFDZCxFQUFFWCxLQUFLLE1BQU1ZLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVaLEtBQUssd0JBQXdCWSxRQUFRLGtCQUFrQjtBQUFBLElBQ3pELEVBQUVaLEtBQUssUUFBUVksUUFBUSx1QkFBdUI7QUFBQSxJQUM5QyxFQUFFWixLQUFLLFdBQVdZLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVaLEtBQUssaUJBQWlCWSxRQUFRLFdBQVc7QUFBQSxJQUMzQyxFQUFFWixLQUFLLGtCQUFrQlksUUFBUSxlQUFlO0FBQUEsSUFDaEQsRUFBRVosS0FBSyxlQUFlWSxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFWixLQUFLLFVBQVVZLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTVYsd0JBQXdCLE9BQU9XLE9BQU87QUFDMUMsUUFBSTtBQUNGLFlBQU0vRSxXQUFXLE1BQU1YLElBQUlZO0FBQUFBLFFBQ3pCLDJEQUEyRDhFLEVBQUU7QUFBQSxNQUMvRDtBQUNBL0QsK0JBQXlCaEIsU0FBU0csSUFBSTtBQUN0Q2dCLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBU04sT0FBTztBQUNkQyxjQUFRRCxNQUFNLHlDQUF5Q0EsS0FBSztBQUFBLElBQzlEO0FBQUEsRUFDRjtBQUVBLFFBQU1zRCx3QkFBd0IsT0FBT1ksT0FBTztBQUMxQyxRQUFJO0FBQ0YsWUFBTS9FLFdBQVcsTUFBTVgsSUFBSVk7QUFBQUEsUUFDekIsMkRBQTJEOEUsRUFBRTtBQUFBLE1BQy9EO0FBQ0ExRCxxQ0FBK0JyQixVQUFVRyxJQUFJO0FBQzdDdUMsa0NBQTRCO0FBQUEsUUFDMUJWLFVBQVVoQyxVQUFVRyxNQUFNNkI7QUFBQUEsUUFDMUJGLFlBQVk5QixVQUFVRyxNQUFNMkI7QUFBQUEsUUFDNUJDLGVBQWUvQixVQUFVRyxNQUFNNEI7QUFBQUEsTUFDakMsQ0FBQztBQUNEUix5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVNWLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3Q0FBd0NBLEtBQUs7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUUsZ0JBQWdCdEQsZUFBZXVEO0FBQUFBLElBQU8sQ0FBQ0MsU0FDM0NBLEtBQUtwRCxXQUFXcUQsWUFBWSxFQUFFQyxTQUFTL0MsV0FBVzhDLFlBQVksQ0FBQztBQUFBLEVBQ2pFO0FBRUEsUUFBTUUsNkJBQTZCLFlBQVk7QUFDN0MsUUFBSXRFLHVCQUF1QjtBQUN6QixVQUFJO0FBQ0YsY0FBTTFCLElBQUlpRztBQUFBQSxVQUNSLDhEQUE4RHZFLHNCQUFzQk4sR0FBRztBQUFBLFFBQ3pGO0FBQ0FtQyx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUNEUCx5QkFBaUIsQ0FBQ29DLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ3pELDJCQUFtQixLQUFLO0FBQ3hCSCxpQ0FBeUIsSUFBSTtBQUFBLE1BQy9CLFNBQVNILE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQUEsTUFDeEQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU0wRSxlQUFlLE9BQU9wQyxNQUFNO0FBQ2hDQSxNQUFFc0IsZUFBZTtBQUNqQixRQUFJO0FBQ0YsWUFBTXBGLElBQUltRztBQUFBQSxRQUNSLDhEQUE4RHBFLDRCQUE0QlgsR0FBRztBQUFBLFFBQzdGZ0M7QUFBQUEsTUFDRjtBQUNBbEIseUJBQW1CLEtBQUs7QUFDeEJpQix1QkFBaUIsQ0FBQ29DLFNBQVNBLE9BQU8sQ0FBQztBQUVuQ2hDLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxTQUFTbEMsT0FBTztBQUNkQyxjQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RCxVQUNFQSxNQUFNYixZQUNOYSxNQUFNYixTQUFTRyxRQUNmVSxNQUFNYixTQUFTRyxLQUFLMkMsU0FDcEI7QUFDQUYsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUyxHQUFHakMsT0FBT2IsVUFBVUcsTUFBTTJDLE9BQU87QUFBQSxVQUMxQ0MsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMSCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFNBQ0UsbUNBQ0UsaUNBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyw2QkFBNkJHO0FBQUFBLFVBQzdCLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1QLFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDZ0MsVUFBVSxFQUFFLEdBQUdBLE1BQU0vQixZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUdILHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx1QkFDYixpQ0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLCtCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLFVBRXREO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYlgsNkJBQWEsSUFBSTtBQUFBLGNBQ25CO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBdUc7QUFBQTtBQUFBLFlBSm5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUNDVixxQkFBcUJpRSxTQUFTLEtBQUssQ0FBQ3RELFlBQ25DO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixlQUFlZ0M7QUFBQUEsWUFDZixNQUFNeEUsYUFBYTZCLHFCQUFxQndCLFVBQVU7QUFBQSxZQUNsRDtBQUFBLFlBQ0EsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxVQU5uQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNd0MsSUFHeEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTeEIsb0JBQW9CaUUsVUFBVTtBQUFBLFlBQ3ZDLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRzhCO0FBQUEsV0E1QmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQkE7QUFBQSxTQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0NBO0FBQUEsSUFDQSx1QkFBQyxTQUFNLFdBQVd4RCxXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsbUNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVXNDLGNBQWMsWUFBVSxNQUM1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQU07QUFBQTtBQUFBLFlBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBTzVDLG9CQUFvQkU7QUFBQUEsY0FDM0IsVUFBVXVDO0FBQUFBLGNBQ1YsSUFBRztBQUFBLGNBQ0gsYUFBWTtBQUFBLGNBQ1osV0FBVyxxQ0FBcUN4RSxVQUFVNkYsTUFBTTtBQUFBO0FBQUEsWUFQbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT2lLO0FBQUEsYUFkbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBVTtBQUFBO0FBQUEsWUFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPOUQsb0JBQW9CRztBQUFBQSxjQUMzQixVQUFVc0M7QUFBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWixXQUFXLHFDQUFxQ3hFLFVBQVU2RixNQUFNO0FBQUE7QUFBQSxZQVBsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPaUs7QUFBQSxhQWRuSztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFVO0FBQUE7QUFBQSxZQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLGFBQVk7QUFBQSxjQUNaLGtCQUFpQjtBQUFBLGNBQ2pCLFVBQVUsQ0FBQ0MsYUFBYTtBQUN0QnRCLDZCQUFhO0FBQUEsa0JBQ1hqQixRQUFRLEVBQUV6QyxNQUFNLFlBQVlILE9BQU9tRixTQUFTO0FBQUEsZ0JBQzlDLENBQUM7QUFBQSxjQUNIO0FBQUEsY0FDQSxPQUFPLEVBQUVDLE9BQU8sT0FBTztBQUFBLGNBQ3ZCLFNBQVMxRjtBQUFBQTtBQUFBQSxZQVhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdxQjtBQUFBLGFBbkJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUMrRjtBQUFBO0FBQUEsVUFIM0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQWpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0VBO0FBQUEsU0F0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVFQSxLQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUVBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV29CO0FBQUFBLFFBQ1gsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBRXZDLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsc0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVnRSxjQUFjLFlBQVUsTUFDNUQ7QUFBQSxtQ0FBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBTztBQUFBO0FBQUEsZ0JBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU85QywwQkFBMEJYO0FBQUFBLGtCQUNqQyxVQUFVeUM7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDMUUsVUFBVTZGLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRaUs7QUFBQSxpQkFmbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFTO0FBQUE7QUFBQSxnQkFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT2pELDBCQUEwQlY7QUFBQUEsa0JBQ2pDLFVBQVV3QztBQUFBQSxrQkFDVixJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaLFdBQVcscUNBQXFDMUUsVUFBVTZGLE1BQU07QUFBQTtBQUFBLGdCQVBsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPaUs7QUFBQSxpQkFkbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFTO0FBQUE7QUFBQSxnQkFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFNO0FBQUEsa0JBQ04sYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0Esa0JBQWlCO0FBQUEsa0JBQ2pCLGNBQWMsQ0FBQ0csT0FBT0MsWUFDbkJBLFFBQVFwRixTQUFTLElBQUl5RSxZQUFZLEVBQUVDLFNBQVNTLE1BQU1WLFlBQVksQ0FBQztBQUFBLGtCQUVsRSxjQUFjMUMsMEJBQTBCVDtBQUFBQSxrQkFDeEMsVUFBVSxDQUFDK0QsaUJBQWlCeEIsa0JBQWtCLEVBQUVuQixRQUFRLEVBQUV6QyxNQUFNLFlBQVlILE9BQU91RixhQUFhLEVBQUUsQ0FBQztBQUFBLGtCQUNuRyxPQUFPLEVBQUVILE9BQU8sT0FBTztBQUFBLGtCQUN2QixTQUFTMUY7QUFBQUE7QUFBQUEsZ0JBWlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWXFCO0FBQUEsaUJBbkJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDK0Y7QUFBQTtBQUFBLGNBSDNHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUVBO0FBQUEsYUF2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdFQTtBQUFBO0FBQUEsTUE1RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNkVBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV2dCO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCSCxtQ0FBeUIsSUFBSTtBQUFBLFFBQy9CO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLHNDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0QseUJBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVUsQ0FBQ29DLE1BQU07QUFDZkEsa0JBQUVzQixlQUFlO0FBQ2pCWSwyQ0FBMkI7QUFBQSxjQUM3QjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVztBQUFBO0FBQUEsd0JBRU47QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2J0RSxpQ0FBdUJlLGNBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFBUTtBQUFBLHdCQUFJO0FBQUE7QUFBQTtBQUFBLG9CQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVyxxQ0FBcUNqQyxVQUFVNkYsTUFBTTtBQUFBO0FBQUEsb0JBTGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLaUs7QUFBQSxxQkFoQm5LO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDMkY7QUFBQTtBQUFBLGtCQUh2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQTtBQUFBO0FBQUEsWUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUNBO0FBQUEsYUF0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdDQTtBQUFBO0FBQUEsTUEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0RBO0FBQUEsT0ExUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJQQSxLQTVQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNlBBO0FBRUo7QUFBRTNGLEdBdGlCSUQsZ0JBQWM7QUFBQWtHLEtBQWRsRztBQXVpQk4sZUFBZUE7QUFBZSxJQUFBa0c7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsIlNpZGViYXIiLCJOYXZiYXIiLCJDaXJjdWxhckxvYWRlciIsIk1vZGFsIiwiYXBpIiwiSW5wdXQiLCJEcm9wZG93biIsIlNlbGVjdCIsIklvTWRNb3JlIiwiRGF0YVRhYmxlIiwiZmlsdGVyT3B0aW9uIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJmaWVsZFNpemUiLCJDb2xsZWN0aW9uQXJlYSIsIl9zIiwicmVzcG9uc2UiLCJnZXQiLCJlbXBsb3llZXMiLCJkYXRhIiwiZW1wbG95ZWUiLCJmaWx0ZXJlZEVtcCIsIm1hcCIsImVtcCIsInZhbHVlIiwiX2lkIiwibGFiZWwiLCJuYW1lIiwic2V0RW1wbG95ZWVzIiwiZXJyb3IiLCJjb25zb2xlIiwiY3VycmVudENvbGxlY3Rpb25BcmVhIiwic2V0Q3VycmVudENvbGxlY3Rpb25BcmVhIiwidXNlU3RhdGUiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJjdXJyZW50VXBkYXRlQ29sbGVjdGlvbkFyZWEiLCJzZXRDdXJyZW50VXBkYXRlQ29sbGVjdGlvbkFyZWEiLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJ0YWJsZUNvbGxlY3Rpb25BcmVhIiwic2V0VGFibGVDb2xsZWN0aW9uQXJlYSIsImNvbGxlY3Rpb25BcmVhIiwic2V0Q29sbGVjdGlvbkFyZWEiLCJjb2xsZWN0aW9uQXJlYURhdGEiLCJzZXRDb2xsZWN0aW9uQXJlYURhdGEiLCJyb3V0ZV9uYW1lIiwicm91dGVfcGluY29kZSIsImFnZW50X2lkIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsInVwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YSIsInNldFVwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YSIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsIkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidGFyZ2V0IiwiZmV0Y2hBcmVhQ29sbGVjdGlvbiIsImluZGV4IiwiaWQiLCJjb2xsZWN0aW9uX2FyZWFfY29kZSIsInBpbmNvZGUiLCJlbXBsb3llZV9uYW1lIiwiam9pbiIsImVtcGxveWVlX3Bob25lIiwicGhvbmVfbnVtYmVyIiwiZW1wbG95ZWVfaWQiLCJlbXBsb3llZUNvZGUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImhhbmRsZUNoYW5nZSIsInByZXZEYXRhIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInBvc3QiLCJoZWFkZXJzIiwicHJldiIsImNvbHVtbnMiLCJoZWFkZXIiLCJJZCIsImZpbHRlcmVkUm91dGUiLCJmaWx0ZXIiLCJhcmVhIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImhhbmRsZURlbGV0ZUNvbGxlY3Rpb25BcmVhIiwiZGVsZXRlIiwiaGFuZGxlVXBkYXRlIiwicHV0IiwibGVuZ3RoIiwiaGVpZ2h0IiwiZW1wSWRBcnIiLCJ3aWR0aCIsImlucHV0Iiwib3B0aW9uIiwiYXJyYXlFbGVtZW50IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29sbGVjdGlvbkFyZWEuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCB7IElucHV0LCBEcm9wZG93biwgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5cclxuY29uc3QgQ29sbGVjdGlvbkFyZWEgPSAoKSA9PiB7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIChhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICAgIGNvbnN0IGVtcGxveWVlcyA9IHJlc3BvbnNlLmRhdGE/LmVtcGxveWVlO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlcmVkRW1wID0gZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoe1xyXG4gICAgICAgICAgdmFsdWU6IGVtcC5faWQsXHJcbiAgICAgICAgICBsYWJlbDogZW1wLm5hbWUsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldEVtcGxveWVlcyhmaWx0ZXJlZEVtcCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIE9jY3VycmVkIHdoaWxlIGZldGNoaW5nIEVtcGxveWVlXCIpO1xyXG4gICAgICAgIHNldEVtcGxveWVlcyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH0pKCk7XHJcbiAgfSwgW10pO1xyXG4gIGNvbnN0IFtjdXJyZW50Q29sbGVjdGlvbkFyZWEsIHNldEN1cnJlbnRDb2xsZWN0aW9uQXJlYV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxEZWxldGUsIHNldFNob3dNb2RhbERlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVDb2xsZWN0aW9uQXJlYSwgc2V0Q3VycmVudFVwZGF0ZUNvbGxlY3Rpb25BcmVhXSA9XHJcbiAgICB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt0YWJsZUNvbGxlY3Rpb25BcmVhLCBzZXRUYWJsZUNvbGxlY3Rpb25BcmVhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY29sbGVjdGlvbkFyZWEsIHNldENvbGxlY3Rpb25BcmVhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY29sbGVjdGlvbkFyZWFEYXRhLCBzZXRDb2xsZWN0aW9uQXJlYURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgcm91dGVfbmFtZTogXCJcIixcclxuICAgIHJvdXRlX3BpbmNvZGU6IFwiXCIsXHJcbiAgICBhZ2VudF9pZDogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIGNvbnN0IFt1cGRhdGVDb2xsZWN0aW9uQXJlYURhdGEsIHNldFVwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICByb3V0ZV9uYW1lOiBcIlwiLFxyXG4gICAgcm91dGVfcGluY29kZTogXCJcIixcclxuICAgIGFnZW50X2lkOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQXJlYUNvbGxlY3Rpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIFwiL2NvbGxlY3Rpb24tYXJlYS1yZXF1ZXN0L2dldC1jb2xsZWN0aW9uLWFyZWEtZGF0YVwiXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRDb2xsZWN0aW9uQXJlYShyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICBjb25zdCBjb2xsZWN0aW9uQXJlYURhdGEgPSByZXNwb25zZT8uZGF0YS5tYXAoXHJcbiAgICAgICAgICAoY29sbGVjdGlvbkFyZWEsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBjb2xsZWN0aW9uQXJlYT8uX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgY29sbGVjdGlvbl9hcmVhX2NvZGU6IGNvbGxlY3Rpb25BcmVhPy5jb2xsZWN0aW9uX2FyZWFfY29kZSxcclxuICAgICAgICAgICAgICBuYW1lOiBjb2xsZWN0aW9uQXJlYT8ucm91dGVfbmFtZSxcclxuICAgICAgICAgICAgICBwaW5jb2RlOiBjb2xsZWN0aW9uQXJlYT8ucm91dGVfcGluY29kZSxcclxuICAgICAgICAgICAgICBlbXBsb3llZV9uYW1lOiBjb2xsZWN0aW9uQXJlYT8uYWdlbnRfaWQ/Lm1hcChlbXAgPT4gZW1wPy5uYW1lKS5qb2luKFwiLFwiKSxcclxuICAgICAgICAgICAgICBlbXBsb3llZV9waG9uZTogY29sbGVjdGlvbkFyZWE/LmFnZW50X2lkPy5tYXAoZW1wID0+IGVtcD8ucGhvbmVfbnVtYmVyKS5qb2luKFwiLFwiKSxcclxuICAgICAgICAgICAgICBlbXBsb3llZV9pZDogY29sbGVjdGlvbkFyZWE/LmFnZW50X2lkPy5tYXAoZW1wID0+IGVtcD8uZW1wbG95ZWVDb2RlKS5qb2luKFwiLFwiKSxcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGNvbGxlY3Rpb25BcmVhPy5faWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVNb2RhbE9wZW4oY29sbGVjdGlvbkFyZWE/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgc2V0VGFibGVDb2xsZWN0aW9uQXJlYShjb2xsZWN0aW9uQXJlYURhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjb2xsZWN0aW9uIGFyZWEgZGF0YTpcIiwgZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQXJlYUNvbGxlY3Rpb24oKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcblxyXG4gICAgc2V0Q29sbGVjdGlvbkFyZWFEYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVDb2xsZWN0aW9uQXJlYURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wb3N0KFxyXG4gICAgICAgIFwiL2NvbGxlY3Rpb24tYXJlYS1yZXF1ZXN0L2FkZC1jb2xsZWN0aW9uLWFyZWEtZGF0YVwiLFxyXG4gICAgICAgIGNvbGxlY3Rpb25BcmVhRGF0YSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9XHJcbiAgICAgICk7XHJcblxyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICBtZXNzYWdlOiBcIkNvbGxlY3Rpb24gQXJlYSBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcblxyXG4gICAgICBzZXRDb2xsZWN0aW9uQXJlYURhdGEoe1xyXG4gICAgICAgIHJvdXRlX25hbWU6IFwiXCIsXHJcbiAgICAgICAgcm91dGVfcGluY29kZTogXCJcIixcclxuICAgICAgICBhZ2VudF9pZDogXCJcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIHVzZXI6XCIsIGVycm9yKTtcclxuICAgICAgaWYgKFxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZVxyXG4gICAgICApIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2V9YCxcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25fYXJlYV9jb2RlXCIsIGhlYWRlcjogXCJDb2xsZWN0aW9uIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ29sbGVjdGlvbiBBcmVhIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGluY29kZVwiLCBoZWFkZXI6IFwicGluY29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZV9uYW1lXCIsIGhlYWRlcjogXCJFbXBsb3llZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZV9waG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlX2lkXCIsIGhlYWRlcjogXCJFbXBsb3llZSBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9jb2xsZWN0aW9uLWFyZWEtcmVxdWVzdC9nZXQtY29sbGVjdGlvbi1hcmVhLWRhdGEtYnktaWQvJHtJZH1gXHJcbiAgICAgICk7XHJcbiAgICAgIHNldEN1cnJlbnRDb2xsZWN0aW9uQXJlYShyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIENvbGxlY3Rpb24gYXJlYSBEYXRhIDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvY29sbGVjdGlvbi1hcmVhLXJlcXVlc3QvZ2V0LWNvbGxlY3Rpb24tYXJlYS1kYXRhLWJ5LWlkLyR7SWR9YFxyXG4gICAgICApO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlQ29sbGVjdGlvbkFyZWEocmVzcG9uc2U/LmRhdGEpO1xyXG4gICAgICBzZXRVcGRhdGVDb2xsZWN0aW9uQXJlYURhdGEoe1xyXG4gICAgICAgIGFnZW50X2lkOiByZXNwb25zZT8uZGF0YT8uYWdlbnRfaWQsXHJcbiAgICAgICAgcm91dGVfbmFtZTogcmVzcG9uc2U/LmRhdGE/LnJvdXRlX25hbWUsXHJcbiAgICAgICAgcm91dGVfcGluY29kZTogcmVzcG9uc2U/LmRhdGE/LnJvdXRlX3BpbmNvZGUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgY29sbGVjdGlvbiBhcmVhIGRhdGE6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZFJvdXRlID0gY29sbGVjdGlvbkFyZWEuZmlsdGVyKChhcmVhKSA9PlxyXG4gICAgYXJlYS5yb3V0ZV9uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKVxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUNvbGxlY3Rpb25BcmVhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRDb2xsZWN0aW9uQXJlYSkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoXHJcbiAgICAgICAgICBgL2NvbGxlY3Rpb24tYXJlYS1yZXF1ZXN0L2RlbGV0ZS1jb2xsZWN0aW9uLWFyZWEtZGF0YS1ieS1pZC8ke2N1cnJlbnRDb2xsZWN0aW9uQXJlYS5faWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiQ29sbGVjdGlvbiBBcmVhIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50Q29sbGVjdGlvbkFyZWEobnVsbCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIENvbGxlY3Rpb24gQXJlYTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgYC9jb2xsZWN0aW9uLWFyZWEtcmVxdWVzdC91cGRhdGUtY29sbGVjdGlvbi1hcmVhLWRhdGEtYnktaWQvJHtjdXJyZW50VXBkYXRlQ29sbGVjdGlvbkFyZWEuX2lkfWAsXHJcbiAgICAgICAgdXBkYXRlQ29sbGVjdGlvbkFyZWFEYXRhXHJcbiAgICAgICk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuXHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiQ29sbGVjdGlvbiBBcmVhIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIENvbGxlY3Rpb24gQXJlYTpcIiwgZXJyb3IpO1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2V9YCxcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e0dsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03IG92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOCBtaW4tdy1tYXhcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+Q29sbGVjdGlvbiBBcmVhPC9oMT5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgKyBBZGQgQ29sbGVjdGlvbiBBcmVhXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHt0YWJsZUNvbGxlY3Rpb25BcmVhPy5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXtoYW5kbGVVcGRhdGVNb2RhbE9wZW59XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24odGFibGVDb2xsZWN0aW9uQXJlYSwgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ29sbGVjdGlvbiBBcmVhXCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDb2xsZWN0aW9uIEFyZWEuY3N2XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXt0YWJsZUNvbGxlY3Rpb25BcmVhLmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgZGF0YT1cIiBDb2xsZWN0aW9uIEFyZWEgRGF0YVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgQWRkIENvbGxlY3Rpb24gQXJlYVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENvbGxlY3Rpb24gQXJlYSBOYW1lXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInJvdXRlX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y29sbGVjdGlvbkFyZWFEYXRhPy5yb3V0ZV9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBDb2xsZWN0aW9uIEFyZWEgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ29sbGVjdGlvbiBBcmVhIFBpbmNvZGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicm91dGVfcGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb2xsZWN0aW9uQXJlYURhdGE/LnJvdXRlX3BpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiYXBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBDb2xsZWN0aW9uIEFyZWEgUGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbW9kZT1cIm11bHRpcGxlXCJcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQbGVhc2Ugc2VsZWN0IEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlbXBJZEFycikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ6IHsgbmFtZTogXCJhZ2VudF9pZFwiLCB2YWx1ZTogZW1wSWRBcnIgfSxcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e2VtcGxveWVlc31cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBDb2xsZWN0aW9uIEFyZWFcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgVXBkYXRlIENvbGxlY3Rpb24gQXJlYVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwicm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDb2xsZWN0aW9uIEFyZWEgTmFtZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJyb3V0ZV9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YT8ucm91dGVfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cInJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQ29sbGVjdGlvbiBBcmVhIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ29sbGVjdGlvbiBBcmVhIFBpbmNvZGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicm91dGVfcGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVDb2xsZWN0aW9uQXJlYURhdGE/LnJvdXRlX3BpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQ29sbGVjdGlvbiBBcmVhIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICBzaXplPXtcImxhcmdlXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwibGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIChvcHRpb24/LmxhYmVsID8/IFwiXCIpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9e3VwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YT8uYWdlbnRfaWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoYXJyYXlFbGVtZW50KSA9PiBoYW5kbGVJbnB1dENoYW5nZSh7IHRhcmdldDogeyBuYW1lOiBcImFnZW50X2lkXCIsIHZhbHVlOiBhcnJheUVsZW1lbnQgfSB9KX1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e2VtcGxveWVlc31cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsRGVsZXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRDdXJyZW50Q29sbGVjdGlvbkFyZWEobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBEZWxldGUgQ29sbGVjdGlvbiBBcmVhXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50Q29sbGVjdGlvbkFyZWEgJiYgKFxyXG4gICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVDb2xsZWN0aW9uQXJlYSgpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50Q29sbGVjdGlvbkFyZWE/LnJvdXRlX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB0byBjb25maXJtIGRlbGV0aW9uLlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJyb3V0ZU5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIENvbGxlY3Rpb24gQXJlYSBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDBcclxuICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5leHBvcnQgZGVmYXVsdCBDb2xsZWN0aW9uQXJlYTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0NvbGxlY3Rpb25BcmVhLmpzeCJ9