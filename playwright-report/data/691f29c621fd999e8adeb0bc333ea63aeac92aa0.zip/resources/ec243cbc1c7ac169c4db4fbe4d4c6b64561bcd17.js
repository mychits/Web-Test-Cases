import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/MonthlyInstallmentTurnoverReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const MonthlyInstallmentTurnoverReport = () => {
  _s();
  const [isLoading, setIsLoading] = useState(false);
  const [monthlyInstallmentTable, setMonthlyInstallmentTable] = useState([]);
  const [year, setYear] = useState([]);
  const [isDataTableLoading, setIsDataTableLoading] = useState(false);
  const [month, setMonth] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [agents, setAgents] = useState([]);
  const [agent, setAgent] = useState("");
  const [summaryData, setSummaryData] = useState({});
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = /* @__PURE__ */ new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    return `${yyyy}-${mm}`;
  });
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const monthOptions = [
    { label: "January", value: 1 },
    { label: "February", value: 2 },
    { label: "March", value: 3 },
    { label: "April", value: 4 },
    { label: "May", value: 5 },
    { label: "June", value: 6 },
    { label: "July", value: 7 },
    { label: "August", value: 8 },
    { label: "September", value: 9 },
    { label: "October", value: 10 },
    { label: "November", value: 11 },
    { label: "December", value: 12 }
  ];
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get(`/employee/`);
        setAgents(response.data?.employee);
      } catch (error) {
        console.error("Unable to fetch Employee", error);
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    const fetchMonthlyTurnover = async () => {
      if (!agent) return;
      const [year2, month2] = selectedMonth.split("-");
      const numericYear = Number(year2);
      const numericMonth = Number(month2);
      if (numericMonth < 1 || numericMonth > 12) {
        console.error("Invalid month selected.");
        return;
      }
      try {
        setIsLoading(true);
        setIsDataTableLoading(true);
        const response = await api.get(
          `/user/agent-monthly-turnover-by-id/${agent}`,
          { params: { year: numericYear, month: numericMonth } }
        );
        const agentData = response?.data?.agentData;
        setSummaryData(agentData ? agentData : {});
        const formattedData = response.data?.agentData?.payingCustomers?.map(
          (group, index) => ({
            _id: group?._id,
            id: index + 1,
            group: group?.group_id?.group_name,
            monthlyInstallment: group?.group_id?.monthly_installment,
            userName: group?.user_id?.full_name,
            ticket: group?.ticket,
            totalPaid: group?.totalPaid,
            diffrence: group?.group_id?.monthly_installment - group?.monthlyPaid,
            status: group?.status === "true" ? "Paid" : "Not Paid"
          })
        );
        setMonthlyInstallmentTable(formattedData);
      } catch (error) {
        console.error("Error in fetching Monthly Installment Data", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchMonthlyTurnover();
  }, [agent, selectedMonth, year]);
  const columns = [
    { key: "id", header: "SL No" },
    { key: "userName", header: "Customer Name" },
    { key: "group", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "monthlyInstallment", header: "Monthly Installment Turnover" },
    { key: "diffrence", header: "Not Paid in Month" },
    { key: "totalPaid", header: "Total Paid" },
    { key: "status", header: "Status" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-hidden", children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
        lineNumber: 119,
        columnNumber: 6
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-6", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold mb-6", children: "Reports - Monthly Installment Turnover" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
        lineNumber: 125,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-1/4 min-w-[100px] p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded shadow", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4", children: "Filters" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
            lineNumber: 133,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 font-medium", children: "Select Agent" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
              lineNumber: 136,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                placeholder: "Search or Select Filter",
                onChange: (agent2) => setAgent(agent2),
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "Select Agent" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                    lineNumber: 147,
                    columnNumber: 19
                  }, this),
                  agents.map(
                    (agent2) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent2._id, children: agent2.name }, agent2._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                      lineNumber: 149,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 137,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
            lineNumber: 135,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 font-medium", children: "Select Month" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
              lineNumber: 157,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "month",
                value: selectedMonth,
                onChange: (e) => setSelectedMonth(e.target.value),
                className: "w-full h-11 px-3 rounded border border-gray-300"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 158,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
            lineNumber: 156,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
          lineNumber: 132,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
          lineNumber: 131,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-1/4 min-w-[500px] p-6", children: !!agent && summaryData && /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded  shadow", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-center mb-4", children: "Summary" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
            lineNumber: 171,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 text-base", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Name:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 174,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: summaryData.agentName }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 175,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
              lineNumber: 173,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Phone:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 178,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: summaryData.phone_number }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 179,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
              lineNumber: 177,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Expected Turnover:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 182,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                "₹",
                summaryData.expectedTurnover
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 183,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
              lineNumber: 181,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Total Turnover:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 186,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                "₹",
                summaryData.totalTurnover
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 187,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
              lineNumber: 185,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Total Customers:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 190,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: summaryData.totalCustomers }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
                lineNumber: 191,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
              lineNumber: 189,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
            lineNumber: 172,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
          lineNumber: 170,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
          lineNumber: 167,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
        lineNumber: 129,
        columnNumber: 11
      }, this),
      !isLoading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: monthlyInstallmentTable,
          columns,
          exportedPdfName: "Monthly Installment Turnover ",
          printHeaderKeys: [
            "Name",
            "Phone Number",
            "Expected Turnover",
            "Total Turnover",
            "Total Customers"
          ],
          printHeaderValues: [summaryData.agentName, summaryData.phone_number, summaryData.expectedTurnover, summaryData.totalTurnover, summaryData.totalCustomers],
          exportedFileName: `Monthly Installment Turnover ${summaryData.agentName}.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
          lineNumber: 201,
          columnNumber: 13
        },
        this
      ) : /* @__PURE__ */ jsxDEV("div", { className: "w-full h-40 flex justify-center items-center text-lg font-semibold", children: /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading: isDataTableLoading,
          data: "Monthly Installment Turnover Data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
          lineNumber: 211,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
        lineNumber: 210,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
      lineNumber: 124,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
    lineNumber: 118,
    columnNumber: 12
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
    lineNumber: 117,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx",
    lineNumber: 116,
    columnNumber: 5
  }, this);
};
_s(MonthlyInstallmentTurnoverReport, "1u9gaX11jgSy6e0By+4ZsGSclYE=");
_c = MonthlyInstallmentTurnoverReport;
export default MonthlyInstallmentTurnoverReport;
var _c;
$RefreshReg$(_c, "MonthlyInstallmentTurnoverReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyInstallmentTurnoverReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUhFLG1CQUdHLGNBSEg7MkJBbkhGO0FBQW1CQSxvQkFBaUIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsY0FBYztBQUV2QixNQUFNQyxtQ0FBbUNBLE1BQU07QUFBQUMsS0FBQTtBQUU3QyxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSUMsU0FBUyxLQUFLO0FBRWhELFFBQU0sQ0FBQ0MseUJBQXlCQywwQkFBMEIsSUFBSUYsU0FBUyxFQUFFO0FBQ3pFLFFBQU0sQ0FBQ0csTUFBTUMsT0FBTyxJQUFJSixTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDSyxvQkFBb0JDLHFCQUFxQixJQUFJTixTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDTyxPQUFPQyxRQUFRLElBQUlSLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNTLFlBQVlDLGFBQWEsSUFBSVYsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ1csUUFBUUMsU0FBUyxJQUFJWixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDYSxPQUFPQyxRQUFRLElBQUlkLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNlLGFBQWFDLGNBQWMsSUFBR2hCLFNBQVMsQ0FBQyxDQUFDO0FBQ2hELFFBQU0sQ0FBQ2lCLGVBQWVDLGdCQUFnQixJQUFJbEIsU0FBUyxNQUFNO0FBQ3ZELFVBQU1tQixNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFVBQU1DLE9BQU9GLElBQUlHLFlBQVk7QUFDN0IsVUFBTUMsS0FBS0MsT0FBT0wsSUFBSU0sU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDckQsV0FBTyxHQUFHTCxJQUFJLElBQUlFLEVBQUU7QUFBQSxFQUN0QixDQUFDO0FBQ0QsUUFBTUksNEJBQTRCQSxDQUFDQyxNQUFNO0FBQ3ZDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQnBCLGtCQUFjbUIsS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTUUsZUFBZTtBQUFBLElBQ25CLEVBQUVDLE9BQU8sV0FBV0gsT0FBTyxFQUFFO0FBQUEsSUFDN0IsRUFBRUcsT0FBTyxZQUFZSCxPQUFPLEVBQUU7QUFBQSxJQUM5QixFQUFFRyxPQUFPLFNBQVNILE9BQU8sRUFBRTtBQUFBLElBQzNCLEVBQUVHLE9BQU8sU0FBU0gsT0FBTyxFQUFFO0FBQUEsSUFDM0IsRUFBRUcsT0FBTyxPQUFPSCxPQUFPLEVBQUU7QUFBQSxJQUN6QixFQUFFRyxPQUFPLFFBQVFILE9BQU8sRUFBRTtBQUFBLElBQzFCLEVBQUVHLE9BQU8sUUFBUUgsT0FBTyxFQUFFO0FBQUEsSUFDMUIsRUFBRUcsT0FBTyxVQUFVSCxPQUFPLEVBQUU7QUFBQSxJQUM1QixFQUFFRyxPQUFPLGFBQWFILE9BQU8sRUFBRTtBQUFBLElBQy9CLEVBQUVHLE9BQU8sV0FBV0gsT0FBTyxHQUFHO0FBQUEsSUFDOUIsRUFBRUcsT0FBTyxZQUFZSCxPQUFPLEdBQUc7QUFBQSxJQUMvQixFQUFFRyxPQUFPLFlBQVlILE9BQU8sR0FBRztBQUFBLEVBQUM7QUFHbEN2QyxZQUFVLE1BQU07QUFDZCxVQUFNMkMsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU0zQyxJQUFJNEMsSUFBSSxZQUFZO0FBQzNDdkIsa0JBQVVzQixTQUFTRSxNQUFNQyxRQUFRO0FBQUEsTUFDbkMsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw0QkFBNEJBLEtBQUs7QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFDQUwsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMM0MsWUFBVSxNQUFNO0FBQ2QsVUFBTWtELHVCQUF1QixZQUFZO0FBQ3ZDLFVBQUksQ0FBQzNCLE1BQU87QUFFWixZQUFNLENBQUNWLE9BQU1JLE1BQUssSUFBSVUsY0FBY3dCLE1BQU0sR0FBRztBQUM3QyxZQUFNQyxjQUFjQyxPQUFPeEMsS0FBSTtBQUMvQixZQUFNeUMsZUFBZUQsT0FBT3BDLE1BQUs7QUFHakMsVUFBSXFDLGVBQWUsS0FBS0EsZUFBZSxJQUFJO0FBQ3pDTCxnQkFBUUQsTUFBTSx5QkFBeUI7QUFDdkM7QUFBQSxNQUNGO0FBQ0EsVUFBSTtBQUNGdkMscUJBQWEsSUFBSTtBQUNqQk8sOEJBQXNCLElBQUk7QUFDMUIsY0FBTTRCLFdBQVcsTUFBTTNDLElBQUk0QztBQUFBQSxVQUN6QixzQ0FBc0N0QixLQUFLO0FBQUEsVUFDM0MsRUFBRWdDLFFBQVEsRUFBRTFDLE1BQU11QyxhQUFhbkMsT0FBT3FDLGFBQWEsRUFBRTtBQUFBLFFBQ3ZEO0FBQ0EsY0FBTUUsWUFBV1osVUFBVUUsTUFBTVU7QUFDakM5Qix1QkFBZThCLFlBQVdBLFlBQVUsQ0FBQyxDQUFDO0FBRXRDLGNBQU1DLGdCQUFnQmIsU0FBU0UsTUFBTVUsV0FBV0UsaUJBQWlCQztBQUFBQSxVQUMvRCxDQUFDQyxPQUFPQyxXQUFXO0FBQUEsWUFDakJDLEtBQUtGLE9BQU9FO0FBQUFBLFlBQ1pDLElBQUlGLFFBQVE7QUFBQSxZQUNaRCxPQUFPQSxPQUFPSSxVQUFVQztBQUFBQSxZQUN4QkMsb0JBQW9CTixPQUFPSSxVQUFVRztBQUFBQSxZQUNyQ0MsVUFBVVIsT0FBT1MsU0FBU0M7QUFBQUEsWUFDMUJDLFFBQVFYLE9BQU9XO0FBQUFBLFlBQ2ZDLFdBQVdaLE9BQU9ZO0FBQUFBLFlBQ2xCQyxXQUFZYixPQUFPSSxVQUFVRyxzQkFBc0JQLE9BQU9jO0FBQUFBLFlBQzFEQyxRQUFRZixPQUFPZSxXQUFXLFNBQVMsU0FBUztBQUFBLFVBQzlDO0FBQUEsUUFDRjtBQUNBL0QsbUNBQTJCNkMsYUFBYTtBQUFBLE1BQzFDLFNBQVNULE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sOENBQThDQSxLQUFLO0FBQUEsTUFDbkUsVUFBQztBQUNDdkMscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBeUMseUJBQXFCO0FBQUEsRUFDdkIsR0FBRyxDQUFDM0IsT0FBT0ksZUFBZWQsSUFBSSxDQUFDO0FBRS9CLFFBQU0rRCxVQUFVO0FBQUEsSUFDZCxFQUFFQyxLQUFLLE1BQU1DLFFBQVEsUUFBUTtBQUFBLElBQzVCLEVBQUVELEtBQUssWUFBWUMsUUFBUSxnQkFBZ0I7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLFNBQVNDLFFBQVEsYUFBYTtBQUFBLElBQ3JDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxzQkFBc0JDLFFBQVEsK0JBQStCO0FBQUEsSUFDcEUsRUFBQ0QsS0FBSyxhQUFhQyxRQUFRLG9CQUFtQjtBQUFBLElBQzlDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3RDLFNBQ0MsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLDRCQUNSLGlDQUFDLFNBQ1A7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ00sNkJBQTZCekM7QUFBQUEsUUFDN0IsWUFBWTtBQUFBO0FBQUEsTUFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRXdCO0FBQUEsSUFHckIsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDJCQUEwQixzREFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RTtBQUFBLE1BSTlFLHVCQUFDLFNBQUksV0FBVSx3QkFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDZixpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsOEJBQTZCLHVCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBRWxELHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDBCQUF5Qiw0QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUN0RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLGFBQVk7QUFBQSxnQkFDWixVQUFVLENBQUNkLFdBQVVDLFNBQVNELE1BQUs7QUFBQSxnQkFDbkMsY0FBYyxDQUFDd0QsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNDLFNBQVMsRUFBRUMsWUFBWSxFQUFFQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFdkUsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBLGtCQUNuQzlELE9BQU9zQztBQUFBQSxvQkFBSSxDQUFDcEMsV0FDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsT0FBTXVDLEtBQ3pDdkMsaUJBQU04RCxRQURXOUQsT0FBTXVDLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdCQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDBCQUF5Qiw0QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUN0RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPbkM7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDVyxNQUFNVixpQkFBaUJVLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxnQkFDaEQsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJNkQ7QUFBQSxlQU4vRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlDQSxLQWxDQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBRWQsV0FBQyxDQUFDaEIsU0FBU0UsZUFDVix1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMENBQXlDLHVCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLFVBQzlELHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxlQUFjLHFCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQztBQUFBLGNBQ25DLHVCQUFDLFVBQU1BLHNCQUFZNkQsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLGVBQWMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUEsY0FDcEMsdUJBQUMsVUFBTTdELHNCQUFZOEQsZ0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxlQUFjLGtDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBLGNBQ2hELHVCQUFDLFVBQUs7QUFBQTtBQUFBLGdCQUFFOUQsWUFBWStEO0FBQUFBLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGlCQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsZUFBYywrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkM7QUFBQSxjQUM3Qyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxnQkFBRS9ELFlBQVlnRTtBQUFBQSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxpQkFGcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLGVBQWMsZ0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThDO0FBQUEsY0FDOUMsdUJBQUMsVUFBTWhFLHNCQUFZaUUsa0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsaUJBRnBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkEsS0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZCRjtBQUFBLFdBbkVBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvRUE7QUFBQSxNQUdDLENBQUNsRixZQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBVSxNQUFNRztBQUFBQSxVQUF5QjtBQUFBLFVBQzFDLGlCQUFnQjtBQUFBLFVBQ2hCLGlCQUFpQjtBQUFBLFlBQ2Y7QUFBQSxZQUFPO0FBQUEsWUFBZTtBQUFBLFlBQW9CO0FBQUEsWUFBaUI7QUFBQSxVQUFpQjtBQUFBLFVBRTlFLG1CQUFtQixDQUFDYyxZQUFZNkQsV0FBVTdELFlBQVk4RCxjQUFhOUQsWUFBWStELGtCQUFpQi9ELFlBQVlnRSxlQUFjaEUsWUFBWWlFLGNBQWM7QUFBQSxVQUNwSixrQkFBa0IsZ0NBQWdDakUsWUFBWTZELFNBQVM7QUFBQTtBQUFBLFFBTnZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU04RSxJQUc5RSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFlLFdBQVd2RTtBQUFBQSxVQUMzQixNQUFNO0FBQUE7QUFBQSxRQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUMwQyxLQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQTNGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkZBO0FBQUEsT0FuR0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9HTCxLQXJHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0dBLEtBdkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3R0E7QUFHRjtBQUFFUixHQXZOSUQsa0NBQWdDO0FBQUFxRixLQUFoQ3JGO0FBeU5OLGVBQWVBO0FBQWlDLElBQUFxRjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiYXBpIiwiRGF0YVRhYmxlIiwiTmF2YmFyIiwiQ2lyY3VsYXJMb2FkZXIiLCJTZWxlY3QiLCJNb250aGx5SW5zdGFsbG1lbnRUdXJub3ZlclJlcG9ydCIsIl9zIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwidXNlU3RhdGUiLCJtb250aGx5SW5zdGFsbG1lbnRUYWJsZSIsInNldE1vbnRobHlJbnN0YWxsbWVudFRhYmxlIiwieWVhciIsInNldFllYXIiLCJpc0RhdGFUYWJsZUxvYWRpbmciLCJzZXRJc0RhdGFUYWJsZUxvYWRpbmciLCJtb250aCIsInNldE1vbnRoIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJhZ2VudCIsInNldEFnZW50Iiwic3VtbWFyeURhdGEiLCJzZXRTdW1tYXJ5RGF0YSIsInNlbGVjdGVkTW9udGgiLCJzZXRTZWxlY3RlZE1vbnRoIiwibm93IiwiRGF0ZSIsInl5eXkiLCJnZXRGdWxsWWVhciIsIm1tIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsIkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJtb250aE9wdGlvbnMiLCJsYWJlbCIsImZldGNoQWdlbnRzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZW1wbG95ZWUiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaE1vbnRobHlUdXJub3ZlciIsInNwbGl0IiwibnVtZXJpY1llYXIiLCJOdW1iZXIiLCJudW1lcmljTW9udGgiLCJwYXJhbXMiLCJhZ2VudERhdGEiLCJmb3JtYXR0ZWREYXRhIiwicGF5aW5nQ3VzdG9tZXJzIiwibWFwIiwiZ3JvdXAiLCJpbmRleCIsIl9pZCIsImlkIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwibW9udGhseUluc3RhbGxtZW50IiwibW9udGhseV9pbnN0YWxsbWVudCIsInVzZXJOYW1lIiwidXNlcl9pZCIsImZ1bGxfbmFtZSIsInRpY2tldCIsInRvdGFsUGFpZCIsImRpZmZyZW5jZSIsIm1vbnRobHlQYWlkIiwic3RhdHVzIiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJuYW1lIiwiYWdlbnROYW1lIiwicGhvbmVfbnVtYmVyIiwiZXhwZWN0ZWRUdXJub3ZlciIsInRvdGFsVHVybm92ZXIiLCJ0b3RhbEN1c3RvbWVycyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vbnRobHlJbnN0YWxsbWVudFR1cm5vdmVyUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5jb25zdCBNb250aGx5SW5zdGFsbG1lbnRUdXJub3ZlclJlcG9ydCA9ICgpID0+IHtcclxuXHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW21vbnRobHlJbnN0YWxsbWVudFRhYmxlLCBzZXRNb250aGx5SW5zdGFsbG1lbnRUYWJsZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3llYXIsIHNldFllYXJdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0RhdGFUYWJsZUxvYWRpbmcsIHNldElzRGF0YVRhYmxlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW21vbnRoLCBzZXRNb250aF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWdlbnQsIHNldEFnZW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzdW1tYXJ5RGF0YSwgc2V0U3VtbWFyeURhdGFdPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkTW9udGgsIHNldFNlbGVjdGVkTW9udGhdID0gdXNlU3RhdGUoKCkgPT4ge1xyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IHl5eXkgPSBub3cuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1tID0gU3RyaW5nKG5vdy5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gICAgcmV0dXJuIGAke3l5eXl9LSR7bW19YDsgLy8gZS5nLiwgXCIyMDI1LTA5XCJcclxuICB9KTtcclxuICBjb25zdCBHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgbW9udGhPcHRpb25zID0gW1xyXG4gICAgeyBsYWJlbDogXCJKYW51YXJ5XCIsIHZhbHVlOiAxIH0sXHJcbiAgICB7IGxhYmVsOiBcIkZlYnJ1YXJ5XCIsIHZhbHVlOiAyIH0sXHJcbiAgICB7IGxhYmVsOiBcIk1hcmNoXCIsIHZhbHVlOiAzIH0sXHJcbiAgICB7IGxhYmVsOiBcIkFwcmlsXCIsIHZhbHVlOiA0IH0sXHJcbiAgICB7IGxhYmVsOiBcIk1heVwiLCB2YWx1ZTogNSB9LFxyXG4gICAgeyBsYWJlbDogXCJKdW5lXCIsIHZhbHVlOiA2IH0sXHJcbiAgICB7IGxhYmVsOiBcIkp1bHlcIiwgdmFsdWU6IDcgfSxcclxuICAgIHsgbGFiZWw6IFwiQXVndXN0XCIsIHZhbHVlOiA4IH0sXHJcbiAgICB7IGxhYmVsOiBcIlNlcHRlbWJlclwiLCB2YWx1ZTogOSB9LFxyXG4gICAgeyBsYWJlbDogXCJPY3RvYmVyXCIsIHZhbHVlOiAxMCB9LFxyXG4gICAgeyBsYWJlbDogXCJOb3ZlbWJlclwiLCB2YWx1ZTogMTEgfSxcclxuICAgIHsgbGFiZWw6IFwiRGVjZW1iZXJcIiwgdmFsdWU6IDEyIH0sXHJcbiAgXTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2VtcGxveWVlL2ApO1xyXG4gICAgICAgIHNldEFnZW50cyhyZXNwb25zZS5kYXRhPy5lbXBsb3llZSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIlVuYWJsZSB0byBmZXRjaCBFbXBsb3llZVwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEFnZW50cygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoTW9udGhseVR1cm5vdmVyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBpZiAoIWFnZW50KSByZXR1cm47XHJcblxyXG4gICAgICBjb25zdCBbeWVhciwgbW9udGhdID0gc2VsZWN0ZWRNb250aC5zcGxpdChcIi1cIik7XHJcbiAgICAgIGNvbnN0IG51bWVyaWNZZWFyID0gTnVtYmVyKHllYXIpO1xyXG4gICAgICBjb25zdCBudW1lcmljTW9udGggPSBOdW1iZXIobW9udGgpO1xyXG5cclxuICAgICAgLy8gVmFsaWRhdGUgbW9udGggcmFuZ2VcclxuICAgICAgaWYgKG51bWVyaWNNb250aCA8IDEgfHwgbnVtZXJpY01vbnRoID4gMTIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiSW52YWxpZCBtb250aCBzZWxlY3RlZC5cIik7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIHNldElzRGF0YVRhYmxlTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL3VzZXIvYWdlbnQtbW9udGhseS10dXJub3Zlci1ieS1pZC8ke2FnZW50fWAsXHJcbiAgICAgICAgICB7IHBhcmFtczogeyB5ZWFyOiBudW1lcmljWWVhciwgbW9udGg6IG51bWVyaWNNb250aCB9IH1cclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IGFnZW50RGF0YSA9cmVzcG9uc2U/LmRhdGE/LmFnZW50RGF0YTtcclxuICAgICAgICBzZXRTdW1tYXJ5RGF0YShhZ2VudERhdGE/IGFnZW50RGF0YTp7fSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhPy5hZ2VudERhdGE/LnBheWluZ0N1c3RvbWVycz8ubWFwKFxyXG4gICAgICAgICAgKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgX2lkOiBncm91cD8uX2lkLFxyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBncm91cDogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICBtb250aGx5SW5zdGFsbG1lbnQ6IGdyb3VwPy5ncm91cF9pZD8ubW9udGhseV9pbnN0YWxsbWVudCxcclxuICAgICAgICAgICAgdXNlck5hbWU6IGdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgIHRpY2tldDogZ3JvdXA/LnRpY2tldCxcclxuICAgICAgICAgICAgdG90YWxQYWlkOiBncm91cD8udG90YWxQYWlkLFxyXG4gICAgICAgICAgICBkaWZmcmVuY2U6IChncm91cD8uZ3JvdXBfaWQ/Lm1vbnRobHlfaW5zdGFsbG1lbnQpLShncm91cD8ubW9udGhseVBhaWQpLFxyXG4gICAgICAgICAgICBzdGF0dXM6IGdyb3VwPy5zdGF0dXMgPT09IFwidHJ1ZVwiID8gXCJQYWlkXCIgOiBcIk5vdCBQYWlkXCIsXHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0TW9udGhseUluc3RhbGxtZW50VGFibGUoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIGZldGNoaW5nIE1vbnRobHkgSW5zdGFsbG1lbnQgRGF0YVwiLCBlcnJvcik7XHJcbiAgICAgIH1maW5hbGx5e1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaE1vbnRobHlUdXJub3ZlcigpO1xyXG4gIH0sIFthZ2VudCwgc2VsZWN0ZWRNb250aCwgeWVhcl0pO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMIE5vXCIgfSxcclxuICAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cFwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJtb250aGx5SW5zdGFsbG1lbnRcIiwgaGVhZGVyOiBcIk1vbnRobHkgSW5zdGFsbG1lbnQgVHVybm92ZXJcIiB9LFxyXG4gICAge2tleTogXCJkaWZmcmVuY2VcIiwgaGVhZGVyOiBcIk5vdCBQYWlkIGluIE1vbnRoXCJ9LFxyXG4gICAgeyBrZXk6IFwidG90YWxQYWlkXCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICBdO1xyXG5cclxuIHJldHVybiAoXHJcbiAgPD5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG92ZXJmbG93LXgtaGlkZGVuXCI+XHJcbiAgICAgICAgICAgPGRpdj5cclxuICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17R2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNlwiPlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCBtYi02XCI+UmVwb3J0cyAtIE1vbnRobHkgSW5zdGFsbG1lbnQgVHVybm92ZXI8L2gxPlxyXG5cclxuICAgICAgICAgIHsvKiBGaWx0ZXJzICYgU3VtbWFyeSAqL31cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtNFwiPlxyXG4gICAgICAgICAgICB7Lyog8J+OryBGaWx0ZXJzICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS80IG1pbi13LVsxMDBweF0gcC02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQgc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBtYi00XCI+RmlsdGVyczwvaDI+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEgZm9udC1tZWRpdW1cIj5TZWxlY3QgQWdlbnQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIG9yIFNlbGVjdCBGaWx0ZXJcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGFnZW50KSA9PiBzZXRBZ2VudChhZ2VudCl9XHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgQWdlbnQ8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIGZvbnQtbWVkaXVtXCI+U2VsZWN0IE1vbnRoPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNb250aH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZE1vbnRoKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTEgcHgtMyByb3VuZGVkIGJvcmRlciBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS80IG1pbi13LVs1MDBweF0gcC02XCI+XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHshIWFnZW50ICYmIHN1bW1hcnlEYXRhICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkICBzaGFkb3dcIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1jZW50ZXIgbWItNFwiPlN1bW1hcnk8L2gyPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPk5hbWU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntzdW1tYXJ5RGF0YS5hZ2VudE5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+UGhvbmU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntzdW1tYXJ5RGF0YS5waG9uZV9udW1iZXJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+RXhwZWN0ZWQgVHVybm92ZXI6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPuKCuXtzdW1tYXJ5RGF0YS5leHBlY3RlZFR1cm5vdmVyfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlRvdGFsIFR1cm5vdmVyOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igrl7c3VtbWFyeURhdGEudG90YWxUdXJub3Zlcn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5Ub3RhbCBDdXN0b21lcnM6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntzdW1tYXJ5RGF0YS50b3RhbEN1c3RvbWVyc308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiDwn6e+IFRhYmxlICovfVxyXG4gICAgICAgICAgeyFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxEYXRhVGFibGUgZGF0YT17bW9udGhseUluc3RhbGxtZW50VGFibGV9IGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIk1vbnRobHkgSW5zdGFsbG1lbnQgVHVybm92ZXIgXCJcclxuICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgXCJOYW1lXCIsXCJQaG9uZSBOdW1iZXJcIixcIkV4cGVjdGVkIFR1cm5vdmVyXCIsXCJUb3RhbCBUdXJub3ZlclwiLFwiVG90YWwgQ3VzdG9tZXJzXCIsXHJcbiAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbc3VtbWFyeURhdGEuYWdlbnROYW1lLHN1bW1hcnlEYXRhLnBob25lX251bWJlcixzdW1tYXJ5RGF0YS5leHBlY3RlZFR1cm5vdmVyLHN1bW1hcnlEYXRhLnRvdGFsVHVybm92ZXIsc3VtbWFyeURhdGEudG90YWxDdXN0b21lcnNdfVxyXG4gICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgTW9udGhseSBJbnN0YWxsbWVudCBUdXJub3ZlciAke3N1bW1hcnlEYXRhLmFnZW50TmFtZX0uY3N2YH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtNDAgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdGV4dC1sZyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17aXNEYXRhVGFibGVMb2FkaW5nfSBcclxuICAgICAgICAgICAgICBkYXRhPXtcIk1vbnRobHkgSW5zdGFsbG1lbnQgVHVybm92ZXIgRGF0YVwifVxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgPC8+XHJcbik7XHJcblxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTW9udGhseUluc3RhbGxtZW50VHVybm92ZXJSZXBvcnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Nb250aGx5SW5zdGFsbG1lbnRUdXJub3ZlclJlcG9ydC5qc3gifQ==