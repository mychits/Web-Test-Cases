import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SalaryIncentive.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Drawer, Modal, Empty, Alert, Tabs } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { FiCalendar, FiCreditCard, FiHash } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { RiMoneyRupeeCircleFill } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { MdOutlineMan } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { GrStatusGood } from "/node_modules/.vite/deps/react-icons_gr.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import { User } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const SalaryIncentives = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [tablePayments, setTablePayments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [editId, setEditId] = useState(null);
  const [activeTab, setActiveTab] = useState("1");
  const [activeSubTab, setActiveSubTab] = useState({
    "1": "Pending",
    "2": "Pending",
    "3": "Pending"
  });
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [pendingSummary, setPendingSummary] = useState({ count: 0, totalAmount: 0 });
  const [summaryLoading, setSummaryLoading] = useState(false);
  const today = /* @__PURE__ */ new Date();
  const currentMonth = today.toISOString().slice(0, 7);
  const initialForm = {
    employee_id: "",
    incentive_type: activeTab === "1" ? "Chit" : activeTab === "2" ? "Loan" : "Pigmy",
    incentive_month: currentMonth,
    pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    month: null,
    year: null,
    pay_type: "cash",
    transaction_id: "",
    amount: 0,
    status: editId ? "" : "Completed"
  };
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info",
    noReload: true
  });
  useEffect(() => {
    if (alertConfig.visibility) {
      const timer = setTimeout(() => {
        setAlertConfig((prev) => ({ ...prev, visibility: false }));
      }, 3e3);
      return () => clearTimeout(timer);
    }
  }, [alertConfig.visibility]);
  const getTypeFromTab = (tabKey) => {
    const map = { "1": "Chit", "2": "Loan", "3": "Pigmy" };
    return map[tabKey] || "Chit";
  };
  useEffect(() => {
    fetchEmployees();
    fetchIncentiveHistory(activeTab, activeSubTab[activeTab]);
    fetchPendingSummary(getTypeFromTab(activeTab));
  }, []);
  useEffect(() => {
    if (reloadTrigger > 0) {
      fetchPendingSummary(getTypeFromTab(activeTab));
    }
  }, [reloadTrigger, activeTab]);
  const fetchEmployees = async () => {
    const res = await api.get("/employee");
    if (res.data.status) setEmployees(res.data.employee);
  };
  const fetchPendingSummary = async (type) => {
    try {
      setSummaryLoading(true);
      const response = await api.get(
        `/employee-incentive-payment-out?incentive_type=${type}&status=Pending`
      );
      const data = response.data.data || [];
      const totalAmount = data.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
      setPendingSummary({
        count: data.length,
        totalAmount
      });
    } catch (error) {
      console.error("Failed to fetch pending summary:", error);
    } finally {
      setSummaryLoading(false);
    }
  };
  const fetchIncentiveHistory = async (tabKey, status) => {
    try {
      setIsLoading(true);
      const type = getTypeFromTab(tabKey);
      const response = await api.get(
        `/employee-incentive-payment-out?incentive_type=${type}&status=${status || "Pending"}`
      );
      const formatted = (response.data.data || []).map((item, index) => ({
        ...item,
        id: index + 1,
        incentive_type: item.incentive_type || "N/A",
        reason: item.reason || "N/A",
        pigmy_payable_amount: item.pigmy_payable_amount || "N/A",
        pay_date: item?.pay_date?.split("T")[0] || "N/A",
        month: item?.month || "N/A",
        salary_year: item?.salary_year || "N/A",
        employeeName: item.employee_id?.name || "N/A",
        transaction_id: item.transaction_id || "N/A",
        action: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            menu: {
              items: [
                { key: "1", label: /* @__PURE__ */ jsxDEV("span", { className: "text-green-500", children: "Pay Now" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 143,
                  columnNumber: 32
                }, this), onClick: () => handleEdit(item) },
                {
                  key: "2",
                  label: /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "Delete" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                    lineNumber: 146,
                    columnNumber: 22
                  }, this),
                  onClick: () => showDeleteConfirm(item._id)
                }
              ]
            },
            trigger: ["click"],
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 153,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
            lineNumber: 140,
            columnNumber: 9
          },
          this
        )
      }));
      setTablePayments(formatted);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  const handleMainTabChange = (key) => {
    setActiveTab(key);
    const subTabStatus = activeSubTab[key] || "Pending";
    fetchIncentiveHistory(key, subTabStatus);
    fetchPendingSummary(getTypeFromTab(key));
  };
  const handleSubTabChange = (mainKey, subKey) => {
    setActiveSubTab((prev) => ({ ...prev, [mainKey]: subKey }));
    fetchIncentiveHistory(mainKey, subKey);
  };
  const showDeleteConfirm = (id) => {
    Modal.confirm({
      title: "Are you sure you want to delete this record?",
      content: "This action cannot be undone.",
      okText: "Yes, Delete",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete(id);
      }
    });
  };
  const handleEdit = (item) => {
    const employeeId = typeof item.employee_id === "object" ? item.employee_id._id : item.employee_id;
    setEditId(item._id);
    setFormData({
      employee_id: employeeId,
      pay_date: item.pay_date?.split("T")[0],
      month: item.month,
      year: item.year,
      pay_type: item.pay_type,
      transaction_id: item.transaction_id || "",
      amount: item.amount,
      status: item.status,
      incentive_type: item.incentive_type
    });
    setShowModal(true);
  };
  const handleDelete = async (id) => {
    try {
      setOpenBackdropLoader(true);
      await api.delete(`/employee-incentive-payment-out/${id}`);
      setAlertConfig({
        visibility: true,
        message: "Data Deleted Successfully!",
        type: "success",
        noReload: true
      });
      setReloadTrigger((prev) => prev + 1);
      fetchIncentiveHistory(activeTab, activeSubTab[activeTab]);
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Delete failed",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    try {
      setOpenBackdropLoader(true);
      if (editId) {
        await api.put(`/employee-incentive-payment-out/${editId}`, formData);
      } else {
        await api.post("/employee-incentive-payment-out", formData);
      }
      setAlertConfig({
        visibility: true,
        message: editId ? "Data Updated Successfully!" : "Data Added Successfully!",
        type: "success",
        noReload: true
      });
      setReloadTrigger((prev) => prev + 1);
      closeDrawer();
      fetchIncentiveHistory(activeTab, activeSubTab[activeTab]);
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Error saving data",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  const validateForm = () => {
    const errs = {};
    if (!formData.employee_id) errs.employee = "Required";
    if (!formData.amount || formData.amount <= 0) errs.amount = "Enter valid amount";
    if (!formData.month) errs.month = "Required";
    if (!formData.year) errs.year = "Required";
    if (!formData.pay_date) errs.pay_date = "Required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };
  const closeDrawer = () => {
    setShowModal(false);
    setEditId(null);
    setFormData(initialForm);
    setErrors({});
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "employeeName", header: "Employee" },
    { key: "incentive_type", header: "Incentive Type" },
    { key: "status", header: "Status" },
    { key: "month", header: "Month" },
    { key: "year", header: "Year" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Mode" },
    { key: "transaction_id", header: "Transaction ID" },
    { key: "action", header: "Action" }
  ];
  const TabContent = () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Employee Incentive" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 304,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => {
            setEditId(null);
            setFormData(initialForm);
            setShowModal(true);
          },
          className: "bg-blue-950 text-white px-4 py-2 rounded",
          children: [
            "+ Add ",
            getTypeFromTab(activeTab),
            " Incentive"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
          lineNumber: 305,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
      lineNumber: 303,
      columnNumber: 7
    }, this),
    isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
      lineNumber: 318,
      columnNumber: 5
    }, this) : tablePayments.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Incentive Payment Data Found" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
      lineNumber: 320,
      columnNumber: 5
    }, this) : /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        data: tablePayments.filter(
          (item) => item.employeeName?.toLowerCase().includes(searchText.toLowerCase())
        ),
        columns
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 322,
        columnNumber: 5
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
    lineNumber: 302,
    columnNumber: 3
  }, this);
  const subTabs = [
    { key: "Pending", label: "Pending" },
    { key: "Completed", label: "Completed" }
  ];
  const tabItems = [
    {
      key: "1",
      label: "Chit Incentives",
      children: /* @__PURE__ */ jsxDEV(
        Tabs,
        {
          activeKey: activeSubTab["1"],
          onChange: (subKey) => handleSubTabChange("1", subKey),
          items: subTabs.map((sub) => ({
            ...sub,
            children: /* @__PURE__ */ jsxDEV(TabContent, { type: "chit", status: sub.key }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 347,
              columnNumber: 19
            }, this)
          }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
          lineNumber: 342,
          columnNumber: 5
        },
        this
      )
    },
    {
      key: "2",
      label: "Loan Incentives",
      children: /* @__PURE__ */ jsxDEV(
        Tabs,
        {
          activeKey: activeSubTab["2"],
          onChange: (subKey) => handleSubTabChange("2", subKey),
          items: subTabs.map((sub) => ({
            ...sub,
            children: /* @__PURE__ */ jsxDEV(TabContent, { type: "loan", status: sub.key }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 361,
              columnNumber: 19
            }, this)
          }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
          lineNumber: 356,
          columnNumber: 5
        },
        this
      )
    },
    {
      key: "3",
      label: "Pigmy Incentives",
      children: /* @__PURE__ */ jsxDEV(
        Tabs,
        {
          activeKey: activeSubTab["3"],
          onChange: (subKey) => handleSubTabChange("3", subKey),
          items: subTabs.map((sub) => ({
            ...sub,
            children: /* @__PURE__ */ jsxDEV(TabContent, { type: "pigmy", status: sub.key }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 375,
              columnNumber: 19
            }, this)
          }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
          lineNumber: 370,
          columnNumber: 5
        },
        this
      )
    }
  ];
  const NAV_LINKS = [
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 386,
        columnNumber: 11
      }, this),
      label: "Salary payment"
    },
    {
      to: "/staff-menu/employee-menu/salary-management",
      icon: /* @__PURE__ */ jsxDEV(MdOutlineMan, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 391,
        columnNumber: 11
      }, this),
      label: "Salary management"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-in-menu/advance-payment-in",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 396,
        columnNumber: 11
      }, this),
      label: "Advance repayment"
    },
    {
      to: "/staff-menu/employee-menu/employee-statement",
      icon: /* @__PURE__ */ jsxDEV(User, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 401,
        columnNumber: 11
      }, this),
      label: "Salary Ledger"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/additional-salary",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 406,
        columnNumber: 11
      }, this),
      label: "Additional salary"
    }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    openBackdropLoader && /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "Processing..." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
      lineNumber: 413,
      columnNumber: 30
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
          lineNumber: 415,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 419,
        columnNumber: 9
      }, this),
      alertConfig.visibility && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-5 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-md px-4", children: /* @__PURE__ */ jsxDEV(
        Alert,
        {
          message: alertConfig.message,
          type: alertConfig.type,
          showIcon: true,
          closable: true,
          onClose: () => setAlertConfig({ ...alertConfig, visibility: false })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
          lineNumber: 422,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 421,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
          lineNumber: 433,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Salary Incentive" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 436,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("h1", { className: "text-lg text-black font-bold font-mono p-2 mt-3", children: "Quick Navigator" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 437,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("section", { className: "mb-6", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-widest text-gray-400 mb-3", children: "Quick navigator" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 441,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: NAV_LINKS.map(
                (link) => /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: link.to,
                    className: "flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 hover:border-blue-400 hover:text-blue-600 hover:bg-blue-50 transition-all",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-blue-500", children: link.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                        lineNumber: 451,
                        columnNumber: 23
                      }, this),
                      link.label
                    ]
                  },
                  link.to,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                    lineNumber: 446,
                    columnNumber: 19
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 444,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 440,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
            lineNumber: 435,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-6 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-amber-50 rounded-full", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-6 h-6 text-amber-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 461,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 460,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 font-medium", children: "Pending Payments" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 464,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: summaryLoading ? "..." : pendingSummary.count }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 465,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 463,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 459,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-12 border-l border-gray-200 mx-8" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 470,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-left", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 font-medium", children: "Total Payable" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 472,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: [
                "₹",
                summaryLoading ? "..." : pendingSummary.totalAmount.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 473,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 471,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
            lineNumber: 458,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
          lineNumber: 434,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Tabs,
          {
            activeKey: activeTab,
            onChange: handleMainTabChange,
            items: tabItems
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
            lineNumber: 481,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
        lineNumber: 432,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Drawer,
        {
          title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 492,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 491,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: editId ? "Edit Incentive Payment" : "New Incentive Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 494,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
            lineNumber: 490,
            columnNumber: 11
          }, this),
          open: showModal,
          onClose: closeDrawer,
          width: 480,
          children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6 p-1", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                "Employee ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 507,
                  columnNumber: 26
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 506,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  size: "large",
                  className: "w-full",
                  placeholder: "Search and select employee",
                  value: formData.employee_id || void 0,
                  optionFilterProp: "label",
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  onChange: (val) => setFormData({ ...formData, employee_id: val }),
                  children: employees.map(
                    (emp) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: emp._id,
                        label: `${emp.name} ${emp.employeeCode}`,
                        children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-medium text-blue-700", children: emp.name.charAt(0).toUpperCase() }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                            lineNumber: 528,
                            columnNumber: 23
                          }, this),
                          emp.name,
                          " | ",
                          emp.employeeCode
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                          lineNumber: 527,
                          columnNumber: 21
                        }, this)
                      },
                      emp._id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                        lineNumber: 522,
                        columnNumber: 17
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 509,
                  columnNumber: 15
                },
                this
              ),
              errors.employee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 538,
                  columnNumber: 19
                }, this),
                errors.employee
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 537,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 505,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCreditCard, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 547,
                  columnNumber: 17
                }, this),
                "Incentive Type"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 546,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  className: "w-full",
                  value: formData?.incentive_type,
                  onChange: (val) => setFormData({ ...formData, incentive_type: val }),
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "Chit", children: "Chit" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 556,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "Loan", children: "Loan" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 557,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "Pigmy", children: "Pigmy" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 558,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 550,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 545,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 565,
                  columnNumber: 17
                }, this),
                "Month & Year"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 564,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      className: "w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                      value: formData.month || "",
                      onChange: (e) => setFormData({ ...formData, month: e.target.value }),
                      disabled: !!editId,
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Month" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                          lineNumber: 576,
                          columnNumber: 21
                        }, this),
                        ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"].map(
                          (m) => /* @__PURE__ */ jsxDEV("option", { value: m, children: m }, m, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                            lineNumber: 578,
                            columnNumber: 21
                          }, this)
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 570,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.month && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.month }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                    lineNumber: 581,
                    columnNumber: 36
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 569,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      className: "w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                      value: formData.year || "",
                      onChange: (e) => setFormData({ ...formData, year: e.target.value }),
                      disabled: !!editId,
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Year" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                          lineNumber: 590,
                          columnNumber: 21
                        }, this),
                        Array.from({ length: 10 }, (_, i) => {
                          const year = (/* @__PURE__ */ new Date()).getFullYear() - 5 + i;
                          return /* @__PURE__ */ jsxDEV("option", { value: year, children: year }, year, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                            lineNumber: 593,
                            columnNumber: 30
                          }, this);
                        })
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 584,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.year && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.year }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                    lineNumber: 596,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 583,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 568,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 563,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 604,
                  columnNumber: 17
                }, this),
                "Amount ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 605,
                  columnNumber: 24
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 603,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-medium", children: "₹" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 608,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    step: "0.01",
                    className: "w-full border border-gray-300 rounded-lg pl-8 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                    placeholder: "0.00",
                    value: Number(formData.amount) || "",
                    onChange: (e) => setFormData({ ...formData, amount: Number(e.target.value) || 0 })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                    lineNumber: 609,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 607,
                columnNumber: 15
              }, this),
              formData.amount && /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 border border-blue-200 rounded-lg px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(formData.amount) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 620,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 619,
                columnNumber: 15
              }, this),
              errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs", children: errors.amount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 625,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 602,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 631,
                  columnNumber: 17
                }, this),
                "Payment Date"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 630,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                  value: formData.pay_date,
                  onChange: (e) => setFormData({ ...formData, pay_date: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 634,
                  columnNumber: 15
                },
                this
              ),
              errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs", children: errors.pay_date }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 640,
                columnNumber: 35
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 629,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCreditCard, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 646,
                  columnNumber: 17
                }, this),
                "Payment Mode"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 645,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  className: "w-full",
                  value: formData.pay_type,
                  onChange: (val) => setFormData({ ...formData, pay_type: val }),
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: "Cash" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 655,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: "Online/UPI" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 656,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cheque", children: "Cheque" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 657,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 649,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 644,
              columnNumber: 13
            }, this),
            formData.pay_type !== "cash" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 animate-fadeIn", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiHash, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 665,
                  columnNumber: 19
                }, this),
                formData.pay_type === "cheque" ? "Cheque Number" : "Transaction ID"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 664,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                  placeholder: formData.pay_type === "cheque" ? "Enter cheque number" : "Enter transaction/UPI ID",
                  value: formData.transaction_id,
                  onChange: (e) => setFormData({ ...formData, transaction_id: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 668,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 663,
              columnNumber: 13
            }, this),
            editId && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(GrStatusGood, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 682,
                  columnNumber: 19
                }, this),
                "Status"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 681,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  className: "w-full",
                  value: formData?.status,
                  onChange: (val) => setFormData({ ...formData, status: val }),
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "Pending", children: "Pending" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 691,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "Completed", children: "Completed" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                      lineNumber: 692,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                  lineNumber: 685,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 680,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-200 font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5 flex items-center justify-center gap-2",
                children: editId ? "Update Incentive Payment" : "Save Incentive Payment"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
                lineNumber: 698,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
              lineNumber: 697,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
            lineNumber: 503,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
          lineNumber: 488,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
      lineNumber: 414,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx",
    lineNumber: 412,
    columnNumber: 5
  }, this);
};
_s(SalaryIncentives, "vLhZmQH6h6ATziAqfG3fAc6pLz8=");
_c = SalaryIncentives;
export default SalaryIncentives;
var _c;
$RefreshReg$(_c, "SalaryIncentives");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryIncentive.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEltQyxTQStKL0IsVUEvSitCOzJCQTlJbkM7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFVBQVVDLFFBQVFDLE9BQU9DLE9BQU9DLE9BQU9DLFlBQVk7QUFDcEUsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsWUFBWUMsY0FBY0MsY0FBYztBQUNqRCxTQUFTQyxtQkFBbUI7QUFDNUIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLDhCQUE4QjtBQUN2QyxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxvQkFBb0I7QUFDN0IsT0FBT0MsZ0JBQWdCO0FBQ3ZCLFNBQVNDLFlBQVk7QUFFckIsTUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUk5QixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDK0IsZUFBZUMsZ0JBQWdCLElBQUloQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDaUMsV0FBV0MsWUFBWSxJQUFJbEMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ21DLFdBQVdDLFlBQVksSUFBSXBDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNxQyxZQUFZQyxhQUFhLElBQUl0QyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDdUMsb0JBQW9CQyxxQkFBcUIsSUFBSXhDLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUN5QyxRQUFRQyxTQUFTLElBQUkxQyxTQUFTLElBQUk7QUFDekMsUUFBTSxDQUFDMkMsV0FBV0MsWUFBWSxJQUFJNUMsU0FBUyxHQUFHO0FBQzlDLFFBQU0sQ0FBQzZDLGNBQWNDLGVBQWUsSUFBSTlDLFNBQVM7QUFBQSxJQUMvQyxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsRUFDUCxDQUFDO0FBRUQsUUFBTSxDQUFDK0MsZUFBZUMsZ0JBQWdCLElBQUloRCxTQUFTLENBQUM7QUFHcEQsUUFBTSxDQUFDaUQsZ0JBQWdCQyxpQkFBaUIsSUFBSWxELFNBQVMsRUFBRW1ELE9BQU8sR0FBR0MsYUFBYSxFQUFFLENBQUM7QUFDakYsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJdEQsU0FBUyxLQUFLO0FBRTFELFFBQU11RCxRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFFBQU1DLGVBQWVGLE1BQU1HLFlBQVksRUFBRUMsTUFBTSxHQUFHLENBQUM7QUFFbkQsUUFBTUMsY0FBYztBQUFBLElBQ2xCQyxhQUFhO0FBQUEsSUFDYkMsZ0JBQWdCbkIsY0FBYyxNQUFNLFNBQVNBLGNBQWMsTUFBTSxTQUFTO0FBQUEsSUFDMUVvQixpQkFBaUJOO0FBQUFBLElBQ2pCTyxXQUFVLG9CQUFJUixLQUFLLEdBQUVFLFlBQVksRUFBRU8sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLElBQy9DQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFVBQVU7QUFBQSxJQUNWQyxnQkFBZ0I7QUFBQSxJQUNoQkMsUUFBUTtBQUFBLElBQ1JDLFFBQVE5QixTQUFTLEtBQUs7QUFBQSxFQUN4QjtBQUVBLFFBQU0sQ0FBQytCLFVBQVVDLFdBQVcsSUFBSXpFLFNBQVM0RCxXQUFXO0FBQ3BELFFBQU0sQ0FBQ2MsUUFBUUMsU0FBUyxJQUFJM0UsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDNEUsYUFBYUMsY0FBYyxJQUFJN0UsU0FBUztBQUFBLElBQzdDOEUsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsSUFDTkMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUVEQyxZQUFVLE1BQU07QUFDZCxRQUFJTixZQUFZRSxZQUFZO0FBQzFCLFlBQU1LLFFBQVFDLFdBQVcsTUFBTTtBQUM3QlAsdUJBQWUsQ0FBQ1EsVUFBVSxFQUFFLEdBQUdBLE1BQU1QLFlBQVksTUFBTSxFQUFFO0FBQUEsTUFDM0QsR0FBRyxHQUFJO0FBQ1AsYUFBTyxNQUFNUSxhQUFhSCxLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsQ0FBQ1AsWUFBWUUsVUFBVSxDQUFDO0FBRzNCLFFBQU1TLGlCQUFpQkEsQ0FBQ0MsV0FBVztBQUNqQyxVQUFNQyxNQUFNLEVBQUUsS0FBSyxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVE7QUFDckQsV0FBT0EsSUFBSUQsTUFBTSxLQUFLO0FBQUEsRUFDeEI7QUFHQU4sWUFBVSxNQUFNO0FBQ2RRLG1CQUFlO0FBQ2ZDLDBCQUFzQmhELFdBQVdFLGFBQWFGLFNBQVMsQ0FBQztBQUN4RGlELHdCQUFvQkwsZUFBZTVDLFNBQVMsQ0FBQztBQUFBLEVBQy9DLEdBQUcsRUFBRTtBQUdMdUMsWUFBVSxNQUFNO0FBQ2QsUUFBSW5DLGdCQUFnQixHQUFHO0FBQ3JCNkMsMEJBQW9CTCxlQUFlNUMsU0FBUyxDQUFDO0FBQUEsSUFDL0M7QUFBQSxFQUNGLEdBQUcsQ0FBQ0ksZUFBZUosU0FBUyxDQUFDO0FBRTdCLFFBQU0rQyxpQkFBaUIsWUFBWTtBQUNqQyxVQUFNRyxNQUFNLE1BQU0zRixJQUFJNEYsSUFBSSxXQUFXO0FBQ3JDLFFBQUlELElBQUlFLEtBQUt4QixPQUFRekMsY0FBYStELElBQUlFLEtBQUtDLFFBQVE7QUFBQSxFQUNyRDtBQUdBLFFBQU1KLHNCQUFzQixPQUFPWixTQUFTO0FBQzFDLFFBQUk7QUFDRjFCLHdCQUFrQixJQUFJO0FBQ3RCLFlBQU0yQyxXQUFXLE1BQU0vRixJQUFJNEY7QUFBQUEsUUFDekIsa0RBQWtEZCxJQUFJO0FBQUEsTUFDeEQ7QUFDQSxZQUFNZSxPQUFPRSxTQUFTRixLQUFLQSxRQUFRO0FBQ25DLFlBQU0zQyxjQUFjMkMsS0FBS0csT0FBTyxDQUFDQyxLQUFLQyxTQUFTRCxPQUFPRSxPQUFPRCxLQUFLOUIsTUFBTSxLQUFLLElBQUksQ0FBQztBQUNsRnBCLHdCQUFrQjtBQUFBLFFBQ2hCQyxPQUFPNEMsS0FBS087QUFBQUEsUUFDWmxEO0FBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsU0FBU21ELE9BQU87QUFDZEMsY0FBUUQsTUFBTSxvQ0FBb0NBLEtBQUs7QUFBQSxJQUN6RCxVQUFDO0FBQ0NqRCx3QkFBa0IsS0FBSztBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUVBLFFBQU1xQyx3QkFBd0IsT0FBT0gsUUFBUWpCLFdBQVc7QUFDdEQsUUFBSTtBQUNGbkMsbUJBQWEsSUFBSTtBQUNqQixZQUFNNEMsT0FBT08sZUFBZUMsTUFBTTtBQUNsQyxZQUFNUyxXQUFXLE1BQU0vRixJQUFJNEY7QUFBQUEsUUFDekIsa0RBQWtEZCxJQUFJLFdBQVdULFVBQVUsU0FBUztBQUFBLE1BQ3RGO0FBQ0EsWUFBTWtDLGFBQWFSLFNBQVNGLEtBQUtBLFFBQVEsSUFBSU4sSUFBSSxDQUFDVyxNQUFNTSxXQUFXO0FBQUEsUUFDakUsR0FBR047QUFBQUEsUUFDSE8sSUFBSUQsUUFBUTtBQUFBLFFBQ1o1QyxnQkFBZ0JzQyxLQUFLdEMsa0JBQWtCO0FBQUEsUUFDdkM4QyxRQUFRUixLQUFLUSxVQUFVO0FBQUEsUUFDdkJDLHNCQUFzQlQsS0FBS1Msd0JBQXdCO0FBQUEsUUFDbkQ3QyxVQUFVb0MsTUFBTXBDLFVBQVVDLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLFFBQzNDQyxPQUFPa0MsTUFBTWxDLFNBQVM7QUFBQSxRQUN0QjRDLGFBQWFWLE1BQU1VLGVBQWU7QUFBQSxRQUNsQ0MsY0FBY1gsS0FBS3ZDLGFBQWFtRCxRQUFRO0FBQUEsUUFDeEMzQyxnQkFBZ0IrQixLQUFLL0Isa0JBQWtCO0FBQUEsUUFDdkM0QyxRQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNO0FBQUEsY0FDSkMsT0FBTztBQUFBLGdCQUNMLEVBQUVDLEtBQUssS0FBS0MsT0FBTyx1QkFBQyxVQUFLLFdBQVUsa0JBQWlCLHVCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QyxHQUFTQyxTQUFTQSxNQUFNQyxXQUFXbEIsSUFBSSxFQUFFO0FBQUEsZ0JBQ3BHO0FBQUEsa0JBQ0VlLEtBQUs7QUFBQSxrQkFDTEMsT0FBTyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsc0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQzVDQyxTQUFTQSxNQUFNRSxrQkFBa0JuQixLQUFLb0IsR0FBRztBQUFBLGdCQUMzQztBQUFBLGNBQUM7QUFBQSxZQUVMO0FBQUEsWUFDQSxTQUFTLENBQUMsT0FBTztBQUFBLFlBRWpCLGlDQUFDLFlBQVMsV0FBVSw0QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQTtBQUFBLFVBYjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNBO0FBQUEsTUFFSixFQUFFO0FBRUZ4Rix1QkFBaUJ5RSxTQUFTO0FBQUEsSUFDNUIsU0FBU2dCLEtBQUs7QUFDWmpCLGNBQVFELE1BQU1rQixHQUFHO0FBQUEsSUFDbkIsVUFBQztBQUNDckYsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBLFFBQU1zRixzQkFBc0JBLENBQUNQLFFBQVE7QUFDbkN2RSxpQkFBYXVFLEdBQUc7QUFDaEIsVUFBTVEsZUFBZTlFLGFBQWFzRSxHQUFHLEtBQUs7QUFDMUN4QiwwQkFBc0J3QixLQUFLUSxZQUFZO0FBQ3ZDL0Isd0JBQW9CTCxlQUFlNEIsR0FBRyxDQUFDO0FBQUEsRUFDekM7QUFHQSxRQUFNUyxxQkFBcUJBLENBQUNDLFNBQVNDLFdBQVc7QUFDOUNoRixvQkFBZ0IsQ0FBQXVDLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUN3QyxPQUFPLEdBQUdDLE9BQU8sRUFBRTtBQUN4RG5DLDBCQUFzQmtDLFNBQVNDLE1BQU07QUFBQSxFQUN2QztBQUVBLFFBQU1QLG9CQUFvQkEsQ0FBQ1osT0FBTztBQUNoQ2xHLFVBQU1zSCxRQUFRO0FBQUEsTUFDWkMsT0FBTztBQUFBLE1BQ1BDLFNBQVM7QUFBQSxNQUNUQyxRQUFRO0FBQUEsTUFDUkMsUUFBUTtBQUFBLE1BQ1JDLFlBQVk7QUFBQSxNQUNaQyxPQUFPO0FBQ0xDLHFCQUFhM0IsRUFBRTtBQUFBLE1BQ2pCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1XLGFBQWFBLENBQUNsQixTQUFTO0FBQzNCLFVBQU1tQyxhQUNKLE9BQU9uQyxLQUFLdkMsZ0JBQWdCLFdBQ3hCdUMsS0FBS3ZDLFlBQVkyRCxNQUNqQnBCLEtBQUt2QztBQUVYbkIsY0FBVTBELEtBQUtvQixHQUFHO0FBQ2xCL0MsZ0JBQVk7QUFBQSxNQUNWWixhQUFhMEU7QUFBQUEsTUFDYnZFLFVBQVVvQyxLQUFLcEMsVUFBVUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3JDQyxPQUFPa0MsS0FBS2xDO0FBQUFBLE1BQ1pDLE1BQU1pQyxLQUFLakM7QUFBQUEsTUFDWEMsVUFBVWdDLEtBQUtoQztBQUFBQSxNQUNmQyxnQkFBZ0IrQixLQUFLL0Isa0JBQWtCO0FBQUEsTUFDdkNDLFFBQVE4QixLQUFLOUI7QUFBQUEsTUFDYkMsUUFBUTZCLEtBQUs3QjtBQUFBQSxNQUNiVCxnQkFBZ0JzQyxLQUFLdEM7QUFBQUEsSUFDdkIsQ0FBQztBQUNENUIsaUJBQWEsSUFBSTtBQUFBLEVBQ25CO0FBRUEsUUFBTW9HLGVBQWUsT0FBTzNCLE9BQU87QUFDakMsUUFBSTtBQUNGbkUsNEJBQXNCLElBQUk7QUFDMUIsWUFBTXRDLElBQUlzSSxPQUFPLG1DQUFtQzdCLEVBQUUsRUFBRTtBQUN4RDlCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsUUFDTkMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUNEakMsdUJBQWlCLENBQUNxQyxTQUFTQSxPQUFPLENBQUM7QUFDbkNNLDRCQUFzQmhELFdBQVdFLGFBQWFGLFNBQVMsQ0FBQztBQUFBLElBQzFELFNBQVM0RCxPQUFPO0FBQ2QxQixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLFFBQ05DLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ3pDLDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUEsUUFBTWlHLGVBQWUsT0FBT0MsTUFBTTtBQUNoQ0EsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUNDLGFBQWEsRUFBRztBQUVyQixRQUFJO0FBQ0ZwRyw0QkFBc0IsSUFBSTtBQUMxQixVQUFJQyxRQUFRO0FBQ1YsY0FBTXZDLElBQUkySSxJQUFJLG1DQUFtQ3BHLE1BQU0sSUFBSStCLFFBQVE7QUFBQSxNQUNyRSxPQUFPO0FBQ0wsY0FBTXRFLElBQUk0SSxLQUFLLG1DQUFtQ3RFLFFBQVE7QUFBQSxNQUM1RDtBQUNBSyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTdEMsU0FBUywrQkFBK0I7QUFBQSxRQUNqRHVDLE1BQU07QUFBQSxRQUNOQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQ0RqQyx1QkFBaUIsQ0FBQ3FDLFNBQVNBLE9BQU8sQ0FBQztBQUNuQzBELGtCQUFZO0FBQ1pwRCw0QkFBc0JoRCxXQUFXRSxhQUFhRixTQUFTLENBQUM7QUFBQSxJQUMxRCxTQUFTNEQsT0FBTztBQUNkMUIscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxRQUNOQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0N6Qyw0QkFBc0IsS0FBSztBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUVBLFFBQU1vRyxlQUFlQSxNQUFNO0FBQ3pCLFVBQU1JLE9BQU8sQ0FBQztBQUNkLFFBQUksQ0FBQ3hFLFNBQVNYLFlBQWFtRixNQUFLaEQsV0FBVztBQUMzQyxRQUFJLENBQUN4QixTQUFTRixVQUFVRSxTQUFTRixVQUFVLEVBQUcwRSxNQUFLMUUsU0FBUztBQUM1RCxRQUFJLENBQUNFLFNBQVNOLE1BQU84RSxNQUFLOUUsUUFBUTtBQUNsQyxRQUFJLENBQUNNLFNBQVNMLEtBQU02RSxNQUFLN0UsT0FBTztBQUNoQyxRQUFJLENBQUNLLFNBQVNSLFNBQVVnRixNQUFLaEYsV0FBVztBQUN4Q1csY0FBVXFFLElBQUk7QUFDZCxXQUFPQyxPQUFPQyxLQUFLRixJQUFJLEVBQUUxQyxXQUFXO0FBQUEsRUFDdEM7QUFFQSxRQUFNeUMsY0FBY0EsTUFBTTtBQUN4QjdHLGlCQUFhLEtBQUs7QUFDbEJRLGNBQVUsSUFBSTtBQUNkK0IsZ0JBQVliLFdBQVc7QUFDdkJlLGNBQVUsQ0FBQyxDQUFDO0FBQUEsRUFDZDtBQUVBLFFBQU13RSxVQUFVO0FBQUEsSUFDZCxFQUFFaEMsS0FBSyxNQUFNaUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRWpDLEtBQUssZ0JBQWdCaUMsUUFBUSxXQUFXO0FBQUEsSUFDMUMsRUFBRWpDLEtBQUssa0JBQWtCaUMsUUFBUSxpQkFBaUI7QUFBQSxJQUNsRCxFQUFFakMsS0FBSyxVQUFVaUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRWpDLEtBQUssU0FBU2lDLFFBQVEsUUFBUTtBQUFBLElBQ2hDLEVBQUVqQyxLQUFLLFFBQVFpQyxRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFakMsS0FBSyxVQUFVaUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRWpDLEtBQUssWUFBWWlDLFFBQVEsT0FBTztBQUFBLElBQ2xDLEVBQUVqQyxLQUFLLGtCQUFrQmlDLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRWpDLEtBQUssVUFBVWlDLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTUMsYUFBYUEsTUFDakIsbUNBQ0U7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsMEJBQXlCLGtDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlEO0FBQUEsTUFDekQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTTtBQUNiM0csc0JBQVUsSUFBSTtBQUNkK0Isd0JBQVliLFdBQVc7QUFDdkIxQix5QkFBYSxJQUFJO0FBQUEsVUFDbkI7QUFBQSxVQUNBLFdBQVU7QUFBQSxVQUEwQztBQUFBO0FBQUEsWUFFN0NxRCxlQUFlNUMsU0FBUztBQUFBLFlBQUU7QUFBQTtBQUFBO0FBQUEsUUFSbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU0E7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBRUNSLFlBQ0MsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLElBQ2JKLGNBQWN1RSxVQUFVLElBQzFCLHVCQUFDLFNBQU0sYUFBWSxxQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRCxJQUVwRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTXZFLGNBQWN1SDtBQUFBQSxVQUFPLENBQUNsRCxTQUMxQkEsS0FBS1csY0FBY3dDLFlBQVksRUFBRUMsU0FBU25ILFdBQVdrSCxZQUFZLENBQUM7QUFBQSxRQUNwRTtBQUFBLFFBQ0E7QUFBQTtBQUFBLE1BSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSW1CO0FBQUEsT0F4QnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkE7QUFHRixRQUFNRSxVQUFVO0FBQUEsSUFDZCxFQUFFdEMsS0FBSyxXQUFXQyxPQUFPLFVBQVU7QUFBQSxJQUNuQyxFQUFFRCxLQUFLLGFBQWFDLE9BQU8sWUFBWTtBQUFBLEVBQUM7QUFHMUMsUUFBTXNDLFdBQVc7QUFBQSxJQUNmO0FBQUEsTUFDRXZDLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUHVDLFVBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVc5RyxhQUFhLEdBQUc7QUFBQSxVQUMzQixVQUFVLENBQUNpRixXQUFXRixtQkFBbUIsS0FBS0UsTUFBTTtBQUFBLFVBQ3BELE9BQU8yQixRQUFRaEUsSUFBSSxDQUFDbUUsU0FBUztBQUFBLFlBQzNCLEdBQUdBO0FBQUFBLFlBQ0hELFVBQVUsdUJBQUMsY0FBVyxNQUFLLFFBQU8sUUFBUUMsSUFBSXpDLE9BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsVUFDcEQsRUFBRTtBQUFBO0FBQUEsUUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNTTtBQUFBLElBR1Y7QUFBQSxJQUNBO0FBQUEsTUFDRUEsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQdUMsVUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVzlHLGFBQWEsR0FBRztBQUFBLFVBQzNCLFVBQVUsQ0FBQ2lGLFdBQVdGLG1CQUFtQixLQUFLRSxNQUFNO0FBQUEsVUFDcEQsT0FBTzJCLFFBQVFoRSxJQUFJLENBQUNtRSxTQUFTO0FBQUEsWUFDM0IsR0FBR0E7QUFBQUEsWUFDSEQsVUFBVSx1QkFBQyxjQUFXLE1BQUssUUFBTyxRQUFRQyxJQUFJekMsT0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0M7QUFBQSxVQUNwRCxFQUFFO0FBQUE7QUFBQSxRQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1NO0FBQUEsSUFHVjtBQUFBLElBQ0E7QUFBQSxNQUNFQSxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1B1QyxVQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXOUcsYUFBYSxHQUFHO0FBQUEsVUFDM0IsVUFBVSxDQUFDaUYsV0FBV0YsbUJBQW1CLEtBQUtFLE1BQU07QUFBQSxVQUNwRCxPQUFPMkIsUUFBUWhFLElBQUksQ0FBQ21FLFNBQVM7QUFBQSxZQUMzQixHQUFHQTtBQUFBQSxZQUNIRCxVQUFVLHVCQUFDLGNBQVcsTUFBSyxTQUFRLFFBQVFDLElBQUl6QyxPQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBLFVBQ3JELEVBQUU7QUFBQTtBQUFBLFFBTko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTU07QUFBQSxJQUdWO0FBQUEsRUFBQztBQUlILFFBQU0wQyxZQUFZO0FBQUEsSUFDaEI7QUFBQSxNQUNFQyxJQUFJO0FBQUEsTUFDSkMsTUFBTSx1QkFBQywwQkFBdUIsTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDdkMzQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFMEMsSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVCO0FBQUEsTUFDN0IzQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFMEMsSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsMEJBQXVCLE1BQU0sTUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ3ZDM0MsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRTBDLElBQUk7QUFBQSxNQUNKQyxNQUFNLHVCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ3JCM0MsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRTBDLElBQUk7QUFBQSxNQUNKQyxNQUFNLHVCQUFDLDBCQUF1QixNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUN2QzNDLE9BQU87QUFBQSxJQUNUO0FBQUEsRUFBQztBQUdILFNBQ0UsbUNBQ0c3RTtBQUFBQSwwQkFBc0IsdUJBQUMsc0JBQW1CLE9BQU8sbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkM7QUFBQSxJQUNsRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyw2QkFBNkIsQ0FBQ21HLE1BQU1wRyxjQUFjb0csRUFBRXNCLE9BQU9DLEtBQUs7QUFBQSxVQUNoRSxZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUHJGLFlBQVlFLGNBQ1gsdUJBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTRixZQUFZRztBQUFBQSxVQUNyQixNQUFNSCxZQUFZSTtBQUFBQSxVQUNsQjtBQUFBLFVBQ0E7QUFBQSxVQUNBLFNBQVMsTUFBTUgsZUFBZSxFQUFFLEdBQUdELGFBQWFFLFlBQVksTUFBTSxDQUFDO0FBQUE7QUFBQSxRQUxyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLdUUsS0FOekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNYLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDBCQUF5QixnQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxZQUN2RCx1QkFBQyxRQUFHLFdBQVUsbURBQWtELCtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxhQUFRLFdBQVUsUUFDakI7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsc0VBQXFFLCtCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1orRSxvQkFBVXBFO0FBQUFBLGdCQUFJLENBQUN5RSxTQUNkO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLElBQUlBLEtBQUtKO0FBQUFBLG9CQUNULFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFVBQUssV0FBVSxpQkFBaUJJLGVBQUtILFFBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJDO0FBQUEsc0JBQzFDRyxLQUFLOUM7QUFBQUE7QUFBQUE7QUFBQUEsa0JBTEQ4QyxLQUFLSjtBQUFBQSxrQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsY0FDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLGVBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsbUdBQ2Y7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZ0NBQ2IsaUNBQUMsZUFBWSxXQUFVLDRCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQyxLQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHFDQUFvQyxnQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUU7QUFBQSxnQkFDakUsdUJBQUMsT0FBRSxXQUFVLG9DQUNWekcsMkJBQWlCLFFBQVFKLGVBQWVFLFNBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBQ0UsdUJBQUMsU0FBSSxXQUFVLHdDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUEsWUFDdEQsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUscUNBQW9DLDZCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RDtBQUFBLGNBQzlELHVCQUFDLE9BQUUsV0FBVSxvQ0FBbUM7QUFBQTtBQUFBLGdCQUM1Q0UsaUJBQWlCLFFBQVFKLGVBQWVHLFlBQVkrRyxlQUFlLE9BQU87QUFBQSxtQkFEOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQWxCQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CRjtBQUFBLGFBM0NBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2Q0E7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXeEg7QUFBQUEsWUFDWCxVQUFVK0U7QUFBQUEsWUFDVixPQUFPZ0M7QUFBQUE7QUFBQUEsVUFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHa0I7QUFBQSxXQXBEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNEQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLG1FQUNiLGlDQUFDLGVBQVksV0FBVSxtQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLHlCQUNiakgsbUJBQVMsMkJBQTJCLDJCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFRixNQUFNUjtBQUFBQSxVQUNOLFNBQVM4RztBQUFBQSxVQUNULE9BQU87QUFBQSxVQUVQLGlDQUFDLFVBQUssVUFBVU4sY0FBYyxXQUFVLGlCQUV0QztBQUFBLG1DQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDZEQUE0RDtBQUFBO0FBQUEsZ0JBQ2xFLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0M7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixPQUFPakUsU0FBU1gsZUFBZXVHO0FBQUFBLGtCQUMvQixrQkFBaUI7QUFBQSxrQkFDakIsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsUUFBUWxELE9BQU9tQyxZQUFZLEVBQUVDLFNBQVNhLE1BQU1kLFlBQVksQ0FBQztBQUFBLGtCQUUzRCxVQUFVLENBQUNnQixRQUFROUYsWUFBWSxFQUFFLEdBQUdELFVBQVVYLGFBQWEwRyxJQUFJLENBQUM7QUFBQSxrQkFFL0QxSSxvQkFBVTREO0FBQUFBLG9CQUFJLENBQUMrRSxRQUNkO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBRUMsT0FBT0EsSUFBSWhEO0FBQUFBLHdCQUNYLE9BQU8sR0FBR2dELElBQUl4RCxJQUFJLElBQUl3RCxJQUFJQyxZQUFZO0FBQUEsd0JBRXRDLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlEQUFDLFNBQUksV0FBVSx1R0FDWkQsY0FBSXhELEtBQUswRCxPQUFPLENBQUMsRUFBRUMsWUFBWSxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0NILElBQUl4RDtBQUFBQSwwQkFBSztBQUFBLDBCQUFJd0QsSUFBSUM7QUFBQUEsNkJBSnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBS0E7QUFBQTtBQUFBLHNCQVRLRCxJQUFJaEQ7QUFBQUEsc0JBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkF6Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMEJBO0FBQUEsY0FDQzlDLE9BQU9zQixZQUNOLHVCQUFDLE9BQUUsV0FBVSxxREFDWDtBQUFBLHVDQUFDLFVBQUssV0FBVSxxQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0Q7QUFBQSxnQkFDakR0QixPQUFPc0I7QUFBQUEsbUJBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQW5DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFDQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx1Q0FBQyxnQkFBYSxXQUFVLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQztBQUFBLGdCQUFHO0FBQUEsbUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT3hCLFVBQVVWO0FBQUFBLGtCQUNqQixVQUFVLENBQUN5RyxRQUFROUYsWUFBWSxFQUFFLEdBQUdELFVBQVVWLGdCQUFnQnlHLElBQUksQ0FBQztBQUFBLGtCQUVuRTtBQUFBLDJDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFBTyxvQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSxvQkFDaEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxRQUFPLG9CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLG9CQUNoQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFNBQVEscUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtDO0FBQUE7QUFBQTtBQUFBLGdCQVJwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDZEQUNmO0FBQUEsdUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QztBQUFBLGdCQUFHO0FBQUEsbUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsT0FBTy9GLFNBQVNOLFNBQVM7QUFBQSxzQkFDekIsVUFBVSxDQUFDd0UsTUFBTWpFLFlBQVksRUFBRSxHQUFHRCxVQUFVTixPQUFPd0UsRUFBRXNCLE9BQU9DLE1BQU0sQ0FBQztBQUFBLHNCQUNuRSxVQUFVLENBQUMsQ0FBQ3hIO0FBQUFBLHNCQUVaO0FBQUEsK0NBQUMsWUFBTyxPQUFNLElBQUcsNEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZCO0FBQUEsd0JBQzVCLENBQUMsV0FBVSxZQUFXLFNBQVEsU0FBUSxPQUFNLFFBQU8sUUFBTyxVQUFTLGFBQVksV0FBVSxZQUFXLFVBQVUsRUFBRWdEO0FBQUFBLDBCQUFJLENBQUNtRixNQUNwSCx1QkFBQyxZQUFlLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBNkI7QUFBQSx3QkFDOUI7QUFBQTtBQUFBO0FBQUEsb0JBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVBO0FBQUEsa0JBQ0NsRyxPQUFPUixTQUFTLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJRLGlCQUFPUixTQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RDtBQUFBLHFCQVoxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixPQUFPTSxTQUFTTCxRQUFRO0FBQUEsc0JBQ3hCLFVBQVUsQ0FBQ3VFLE1BQU1qRSxZQUFZLEVBQUUsR0FBR0QsVUFBVUwsTUFBTXVFLEVBQUVzQixPQUFPQyxNQUFNLENBQUM7QUFBQSxzQkFDbEUsVUFBVSxDQUFDLENBQUN4SDtBQUFBQSxzQkFFWjtBQUFBLCtDQUFDLFlBQU8sT0FBTSxJQUFHLDJCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE0QjtBQUFBLHdCQUMzQm9JLE1BQU1DLEtBQUssRUFBRXhFLFFBQVEsR0FBRyxHQUFHLENBQUN5RSxHQUFHQyxNQUFNO0FBQ3BDLGdDQUFNN0csUUFBTyxvQkFBSVgsS0FBSyxHQUFFeUgsWUFBWSxJQUFJLElBQUlEO0FBQzVDLGlDQUFPLHVCQUFDLFlBQWtCLE9BQU83RyxNQUFPQSxrQkFBcEJBLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBc0M7QUFBQSx3QkFDL0MsQ0FBQztBQUFBO0FBQUE7QUFBQSxvQkFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV0E7QUFBQSxrQkFDQ08sT0FBT1AsUUFBUSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCTyxpQkFBT1AsUUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0Q7QUFBQSxxQkFieEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLG1CQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQThCQTtBQUFBLGlCQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9DQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx1Q0FBQyxlQUFZLFdBQVUsMkJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThDO0FBQUEsZ0JBQUc7QUFBQSxnQkFDMUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxzRUFBcUUsaUJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGO0FBQUEsZ0JBQ3RGO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixPQUFPa0MsT0FBTzdCLFNBQVNGLE1BQU0sS0FBSztBQUFBLG9CQUNsQyxVQUFVLENBQUNvRSxNQUFNakUsWUFBWSxFQUFFLEdBQUdELFVBQVVGLFFBQVErQixPQUFPcUMsRUFBRXNCLE9BQU9DLEtBQUssS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBLGtCQU5uRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTXFGO0FBQUEsbUJBUnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNDekYsU0FBU0YsVUFDUix1QkFBQyxTQUFJLFdBQVUsMERBQ2IsaUNBQUMsT0FBRSxXQUFVLDZEQUNWdkQsOEJBQW9CeUQsU0FBU0YsTUFBTSxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGNBRURJLE9BQU9KLFVBQVUsdUJBQUMsT0FBRSxXQUFVLHdCQUF3QkksaUJBQU9KLFVBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsaUJBdkJ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx1Q0FBQyxjQUFXLFdBQVUsMkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDO0FBQUEsZ0JBQUc7QUFBQSxtQkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixPQUFPRSxTQUFTUjtBQUFBQSxrQkFDaEIsVUFBVSxDQUFDMEUsTUFBTWpFLFlBQVksRUFBRSxHQUFHRCxVQUFVUixVQUFVMEUsRUFBRXNCLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsZ0JBSnhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUkwRTtBQUFBLGNBRXpFdkYsT0FBT1YsWUFBWSx1QkFBQyxPQUFFLFdBQVUsd0JBQXdCVSxpQkFBT1YsWUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxpQkFYM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx1Q0FBQyxnQkFBYSxXQUFVLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQztBQUFBLGdCQUFHO0FBQUEsbUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT1EsU0FBU0o7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQ21HLFFBQVE5RixZQUFZLEVBQUUsR0FBR0QsVUFBVUosVUFBVW1HLElBQUksQ0FBQztBQUFBLGtCQUU3RDtBQUFBLDJDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFBTyxvQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSxvQkFDaEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLDBCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3QztBQUFBLG9CQUN4Qyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUE7QUFBQTtBQUFBLGdCQVJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUdDL0YsU0FBU0osYUFBYSxVQUNyQix1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx1Q0FBQyxVQUFPLFdBQVUsMkJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDO0FBQUEsZ0JBQ3hDSSxTQUFTSixhQUFhLFdBQVcsa0JBQWtCO0FBQUEsbUJBRnREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsYUFBYUksU0FBU0osYUFBYSxXQUFXLHdCQUF3QjtBQUFBLGtCQUN0RSxPQUFPSSxTQUFTSDtBQUFBQSxrQkFDaEIsVUFBVSxDQUFDcUUsTUFBTWpFLFlBQVksRUFBRSxHQUFHRCxVQUFVSCxnQkFBZ0JxRSxFQUFFc0IsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxnQkFMOUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS2dGO0FBQUEsaUJBVmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUlEeEgsVUFDQyx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2REFDZjtBQUFBLHVDQUFDLGdCQUFhLFdBQVUsMkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDO0FBQUEsZ0JBQUc7QUFBQSxtQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixPQUFPK0IsVUFBVUQ7QUFBQUEsa0JBQ2pCLFVBQVUsQ0FBQ2dHLFFBQVE5RixZQUFZLEVBQUUsR0FBR0QsVUFBVUQsUUFBUWdHLElBQUksQ0FBQztBQUFBLGtCQUUzRDtBQUFBLDJDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sV0FBVSx1QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0M7QUFBQSxvQkFDdEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxhQUFZLHlCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEwQztBQUFBO0FBQUE7QUFBQSxnQkFQNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUE7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsWUFHRix1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUVUOUgsbUJBQVMsNkJBQTZCO0FBQUE7QUFBQSxjQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQXpNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBNQTtBQUFBO0FBQUEsUUF6TkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BME5BO0FBQUEsU0FwU0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFTQTtBQUFBLE9BdlNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3U0E7QUFFSjtBQUFFYixHQWpyQklELGtCQUFnQjtBQUFBdUosS0FBaEJ2SjtBQW1yQk4sZUFBZUE7QUFBaUIsSUFBQXVKO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIk5hdmJhciIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiRHJhd2VyIiwiTW9kYWwiLCJFbXB0eSIsIkFsZXJ0IiwiVGFicyIsIklvTWRNb3JlIiwiQmFja2Ryb3BCbHVyTG9hZGVyIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIkZpQ2FsZW5kYXIiLCJGaUNyZWRpdENhcmQiLCJGaUhhc2giLCJGYVJ1cGVlU2lnbiIsIkNpcmN1bGFyTG9hZGVyIiwiUmlNb25leVJ1cGVlQ2lyY2xlRmlsbCIsIkxpbmsiLCJNZE91dGxpbmVNYW4iLCJHclN0YXR1c0dvb2QiLCJCcmVhZGNydW1iIiwiVXNlciIsIlNhbGFyeUluY2VudGl2ZXMiLCJfcyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInRhYmxlUGF5bWVudHMiLCJzZXRUYWJsZVBheW1lbnRzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJvcGVuQmFja2Ryb3BMb2FkZXIiLCJzZXRPcGVuQmFja2Ryb3BMb2FkZXIiLCJlZGl0SWQiLCJzZXRFZGl0SWQiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJhY3RpdmVTdWJUYWIiLCJzZXRBY3RpdmVTdWJUYWIiLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsInBlbmRpbmdTdW1tYXJ5Iiwic2V0UGVuZGluZ1N1bW1hcnkiLCJjb3VudCIsInRvdGFsQW1vdW50Iiwic3VtbWFyeUxvYWRpbmciLCJzZXRTdW1tYXJ5TG9hZGluZyIsInRvZGF5IiwiRGF0ZSIsImN1cnJlbnRNb250aCIsInRvSVNPU3RyaW5nIiwic2xpY2UiLCJpbml0aWFsRm9ybSIsImVtcGxveWVlX2lkIiwiaW5jZW50aXZlX3R5cGUiLCJpbmNlbnRpdmVfbW9udGgiLCJwYXlfZGF0ZSIsInNwbGl0IiwibW9udGgiLCJ5ZWFyIiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsImFtb3VudCIsInN0YXR1cyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwibm9SZWxvYWQiLCJ1c2VFZmZlY3QiLCJ0aW1lciIsInNldFRpbWVvdXQiLCJwcmV2IiwiY2xlYXJUaW1lb3V0IiwiZ2V0VHlwZUZyb21UYWIiLCJ0YWJLZXkiLCJtYXAiLCJmZXRjaEVtcGxveWVlcyIsImZldGNoSW5jZW50aXZlSGlzdG9yeSIsImZldGNoUGVuZGluZ1N1bW1hcnkiLCJyZXMiLCJnZXQiLCJkYXRhIiwiZW1wbG95ZWUiLCJyZXNwb25zZSIsInJlZHVjZSIsInN1bSIsIml0ZW0iLCJOdW1iZXIiLCJsZW5ndGgiLCJlcnJvciIsImNvbnNvbGUiLCJmb3JtYXR0ZWQiLCJpbmRleCIsImlkIiwicmVhc29uIiwicGlnbXlfcGF5YWJsZV9hbW91bnQiLCJzYWxhcnlfeWVhciIsImVtcGxveWVlTmFtZSIsIm5hbWUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwib25DbGljayIsImhhbmRsZUVkaXQiLCJzaG93RGVsZXRlQ29uZmlybSIsIl9pZCIsImVyciIsImhhbmRsZU1haW5UYWJDaGFuZ2UiLCJzdWJUYWJTdGF0dXMiLCJoYW5kbGVTdWJUYWJDaGFuZ2UiLCJtYWluS2V5Iiwic3ViS2V5IiwiY29uZmlybSIsInRpdGxlIiwiY29udGVudCIsIm9rVGV4dCIsIm9rVHlwZSIsImNhbmNlbFRleHQiLCJvbk9rIiwiaGFuZGxlRGVsZXRlIiwiZW1wbG95ZWVJZCIsImRlbGV0ZSIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInZhbGlkYXRlRm9ybSIsInB1dCIsInBvc3QiLCJjbG9zZURyYXdlciIsImVycnMiLCJPYmplY3QiLCJrZXlzIiwiY29sdW1ucyIsImhlYWRlciIsIlRhYkNvbnRlbnQiLCJmaWx0ZXIiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwic3ViVGFicyIsInRhYkl0ZW1zIiwiY2hpbGRyZW4iLCJzdWIiLCJOQVZfTElOS1MiLCJ0byIsImljb24iLCJ0YXJnZXQiLCJ2YWx1ZSIsImxpbmsiLCJ0b0xvY2FsZVN0cmluZyIsInVuZGVmaW5lZCIsImlucHV0Iiwib3B0aW9uIiwidmFsIiwiZW1wIiwiZW1wbG95ZWVDb2RlIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJtIiwiQXJyYXkiLCJmcm9tIiwiXyIsImkiLCJnZXRGdWxsWWVhciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNhbGFyeUluY2VudGl2ZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIERyb3Bkb3duLCBEcmF3ZXIsIE1vZGFsLCBFbXB0eSwgQWxlcnQsIFRhYnMgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgQmFja2Ryb3BCbHVyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQmFja2Ryb3BCbHVyTG9hZGVyXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcbmltcG9ydCB7IEZpQ2FsZW5kYXIsIEZpQ3JlZGl0Q2FyZCwgRmlIYXNoIH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbmltcG9ydCB7IEZhUnVwZWVTaWduIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwgfSBmcm9tIFwicmVhY3QtaWNvbnMvcmlcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IE1kT3V0bGluZU1hbiB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBHclN0YXR1c0dvb2QgfSBmcm9tIFwicmVhY3QtaWNvbnMvZ3JcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5cclxuY29uc3QgU2FsYXJ5SW5jZW50aXZlcyA9ICgpID0+IHtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZVBheW1lbnRzLCBzZXRUYWJsZVBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW29wZW5CYWNrZHJvcExvYWRlciwgc2V0T3BlbkJhY2tkcm9wTG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWRpdElkLCBzZXRFZGl0SWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwiMVwiKTtcclxuICBjb25zdCBbYWN0aXZlU3ViVGFiLCBzZXRBY3RpdmVTdWJUYWJdID0gdXNlU3RhdGUoe1xyXG4gICAgXCIxXCI6IFwiUGVuZGluZ1wiLFxyXG4gICAgXCIyXCI6IFwiUGVuZGluZ1wiLFxyXG4gICAgXCIzXCI6IFwiUGVuZGluZ1wiXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIFBlbmRpbmcgU3VtbWFyeSBTdGF0ZSAtLS0tLS0tLS0tXHJcbiAgY29uc3QgW3BlbmRpbmdTdW1tYXJ5LCBzZXRQZW5kaW5nU3VtbWFyeV0gPSB1c2VTdGF0ZSh7IGNvdW50OiAwLCB0b3RhbEFtb3VudDogMCB9KTtcclxuICBjb25zdCBbc3VtbWFyeUxvYWRpbmcsIHNldFN1bW1hcnlMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IGN1cnJlbnRNb250aCA9IHRvZGF5LnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgNyk7XHJcblxyXG4gIGNvbnN0IGluaXRpYWxGb3JtID0ge1xyXG4gICAgZW1wbG95ZWVfaWQ6IFwiXCIsXHJcbiAgICBpbmNlbnRpdmVfdHlwZTogYWN0aXZlVGFiID09PSBcIjFcIiA/IFwiQ2hpdFwiIDogYWN0aXZlVGFiID09PSBcIjJcIiA/IFwiTG9hblwiIDogXCJQaWdteVwiLFxyXG4gICAgaW5jZW50aXZlX21vbnRoOiBjdXJyZW50TW9udGgsXHJcbiAgICBwYXlfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuICAgIG1vbnRoOiBudWxsLFxyXG4gICAgeWVhcjogbnVsbCxcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgYW1vdW50OiAwLFxyXG4gICAgc3RhdHVzOiBlZGl0SWQgPyBcIlwiIDogXCJDb21wbGV0ZWRcIixcclxuICB9O1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKGluaXRpYWxGb3JtKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgICBub1JlbG9hZDogdHJ1ZSxcclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChhbGVydENvbmZpZy52aXNpYmlsaXR5KSB7XHJcbiAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKTtcclxuICAgICAgfSwgMzAwMCk7XHJcbiAgICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodGltZXIpO1xyXG4gICAgfVxyXG4gIH0sIFthbGVydENvbmZpZy52aXNpYmlsaXR5XSk7XHJcblxyXG4gIC8vIE1hcCB0YWIga2V5IHRvIGluY2VudGl2ZSB0eXBlXHJcbiAgY29uc3QgZ2V0VHlwZUZyb21UYWIgPSAodGFiS2V5KSA9PiB7XHJcbiAgICBjb25zdCBtYXAgPSB7IFwiMVwiOiBcIkNoaXRcIiwgXCIyXCI6IFwiTG9hblwiLCBcIjNcIjogXCJQaWdteVwiIH07XHJcbiAgICByZXR1cm4gbWFwW3RhYktleV0gfHwgXCJDaGl0XCI7XHJcbiAgfTtcclxuXHJcbiAgLy8gSW5pdGlhbCBkYXRhIGxvYWRcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuICAgIGZldGNoSW5jZW50aXZlSGlzdG9yeShhY3RpdmVUYWIsIGFjdGl2ZVN1YlRhYlthY3RpdmVUYWJdKTtcclxuICAgIGZldGNoUGVuZGluZ1N1bW1hcnkoZ2V0VHlwZUZyb21UYWIoYWN0aXZlVGFiKSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBSZWZldGNoIHN1bW1hcnkgd2hlbiByZWxvYWRUcmlnZ2VyIGNoYW5nZXMgKGFmdGVyIENSVUQpXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChyZWxvYWRUcmlnZ2VyID4gMCkge1xyXG4gICAgICBmZXRjaFBlbmRpbmdTdW1tYXJ5KGdldFR5cGVGcm9tVGFiKGFjdGl2ZVRhYikpO1xyXG4gICAgfVxyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyLCBhY3RpdmVUYWJdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgaWYgKHJlcy5kYXRhLnN0YXR1cykgc2V0RW1wbG95ZWVzKHJlcy5kYXRhLmVtcGxveWVlKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIEZldGNoIFBlbmRpbmcgU3VtbWFyeSBmb3IgYSBzcGVjaWZpYyB0eXBlIC0tLS0tLS0tLS1cclxuICBjb25zdCBmZXRjaFBlbmRpbmdTdW1tYXJ5ID0gYXN5bmMgKHR5cGUpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldFN1bW1hcnlMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9lbXBsb3llZS1pbmNlbnRpdmUtcGF5bWVudC1vdXQ/aW5jZW50aXZlX3R5cGU9JHt0eXBlfSZzdGF0dXM9UGVuZGluZ2BcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgZGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuICAgICAgY29uc3QgdG90YWxBbW91bnQgPSBkYXRhLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiBzdW0gKyAoTnVtYmVyKGl0ZW0uYW1vdW50KSB8fCAwKSwgMCk7XHJcbiAgICAgIHNldFBlbmRpbmdTdW1tYXJ5KHtcclxuICAgICAgICBjb3VudDogZGF0YS5sZW5ndGgsXHJcbiAgICAgICAgdG90YWxBbW91bnQ6IHRvdGFsQW1vdW50LFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcGVuZGluZyBzdW1tYXJ5OlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRTdW1tYXJ5TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hJbmNlbnRpdmVIaXN0b3J5ID0gYXN5bmMgKHRhYktleSwgc3RhdHVzKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHR5cGUgPSBnZXRUeXBlRnJvbVRhYih0YWJLZXkpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9lbXBsb3llZS1pbmNlbnRpdmUtcGF5bWVudC1vdXQ/aW5jZW50aXZlX3R5cGU9JHt0eXBlfSZzdGF0dXM9JHtzdGF0dXMgfHwgXCJQZW5kaW5nXCJ9YFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSAocmVzcG9uc2UuZGF0YS5kYXRhIHx8IFtdKS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICBpbmNlbnRpdmVfdHlwZTogaXRlbS5pbmNlbnRpdmVfdHlwZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIHJlYXNvbjogaXRlbS5yZWFzb24gfHwgXCJOL0FcIixcclxuICAgICAgICBwaWdteV9wYXlhYmxlX2Ftb3VudDogaXRlbS5waWdteV9wYXlhYmxlX2Ftb3VudCB8fCBcIk4vQVwiLFxyXG4gICAgICAgIHBheV9kYXRlOiBpdGVtPy5wYXlfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgbW9udGg6IGl0ZW0/Lm1vbnRoIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgc2FsYXJ5X3llYXI6IGl0ZW0/LnNhbGFyeV95ZWFyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgZW1wbG95ZWVOYW1lOiBpdGVtLmVtcGxveWVlX2lkPy5uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgdHJhbnNhY3Rpb25faWQ6IGl0ZW0udHJhbnNhY3Rpb25faWQgfHwgXCJOL0FcIixcclxuICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgIHsga2V5OiBcIjFcIiwgbGFiZWw6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwXCI+UGF5IE5vdzwvc3Bhbj4sIG9uQ2xpY2s6ICgpID0+IGhhbmRsZUVkaXQoaXRlbSkgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgbGFiZWw6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPkRlbGV0ZTwvc3Bhbj4sXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IHNob3dEZWxldGVDb25maXJtKGl0ZW0uX2lkKSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWQpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gV2hlbiBtYWluIHRhYiBzd2l0Y2hlc1xyXG4gIGNvbnN0IGhhbmRsZU1haW5UYWJDaGFuZ2UgPSAoa2V5KSA9PiB7XHJcbiAgICBzZXRBY3RpdmVUYWIoa2V5KTtcclxuICAgIGNvbnN0IHN1YlRhYlN0YXR1cyA9IGFjdGl2ZVN1YlRhYltrZXldIHx8IFwiUGVuZGluZ1wiO1xyXG4gICAgZmV0Y2hJbmNlbnRpdmVIaXN0b3J5KGtleSwgc3ViVGFiU3RhdHVzKTtcclxuICAgIGZldGNoUGVuZGluZ1N1bW1hcnkoZ2V0VHlwZUZyb21UYWIoa2V5KSk7IC8vIPCfkYggdXBkYXRlIHN1bW1hcnkgZm9yIHRoaXMgdHlwZVxyXG4gIH07XHJcblxyXG4gIC8vIFdoZW4gc3VidGFiIHN3aXRjaGVzXHJcbiAgY29uc3QgaGFuZGxlU3ViVGFiQ2hhbmdlID0gKG1haW5LZXksIHN1YktleSkgPT4ge1xyXG4gICAgc2V0QWN0aXZlU3ViVGFiKHByZXYgPT4gKHsgLi4ucHJldiwgW21haW5LZXldOiBzdWJLZXkgfSkpO1xyXG4gICAgZmV0Y2hJbmNlbnRpdmVIaXN0b3J5KG1haW5LZXksIHN1YktleSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2hvd0RlbGV0ZUNvbmZpcm0gPSAoaWQpID0+IHtcclxuICAgIE1vZGFsLmNvbmZpcm0oe1xyXG4gICAgICB0aXRsZTogXCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgcmVjb3JkP1wiLFxyXG4gICAgICBjb250ZW50OiBcIlRoaXMgYWN0aW9uIGNhbm5vdCBiZSB1bmRvbmUuXCIsXHJcbiAgICAgIG9rVGV4dDogXCJZZXMsIERlbGV0ZVwiLFxyXG4gICAgICBva1R5cGU6IFwiZGFuZ2VyXCIsXHJcbiAgICAgIGNhbmNlbFRleHQ6IFwiTm9cIixcclxuICAgICAgb25PaygpIHtcclxuICAgICAgICBoYW5kbGVEZWxldGUoaWQpO1xyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRWRpdCA9IChpdGVtKSA9PiB7XHJcbiAgICBjb25zdCBlbXBsb3llZUlkID1cclxuICAgICAgdHlwZW9mIGl0ZW0uZW1wbG95ZWVfaWQgPT09IFwib2JqZWN0XCJcclxuICAgICAgICA/IGl0ZW0uZW1wbG95ZWVfaWQuX2lkXHJcbiAgICAgICAgOiBpdGVtLmVtcGxveWVlX2lkO1xyXG5cclxuICAgIHNldEVkaXRJZChpdGVtLl9pZCk7XHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIGVtcGxveWVlX2lkOiBlbXBsb3llZUlkLFxyXG4gICAgICBwYXlfZGF0ZTogaXRlbS5wYXlfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICBtb250aDogaXRlbS5tb250aCxcclxuICAgICAgeWVhcjogaXRlbS55ZWFyLFxyXG4gICAgICBwYXlfdHlwZTogaXRlbS5wYXlfdHlwZSxcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IGl0ZW0udHJhbnNhY3Rpb25faWQgfHwgXCJcIixcclxuICAgICAgYW1vdW50OiBpdGVtLmFtb3VudCxcclxuICAgICAgc3RhdHVzOiBpdGVtLnN0YXR1cyxcclxuICAgICAgaW5jZW50aXZlX3R5cGU6IGl0ZW0uaW5jZW50aXZlX3R5cGUsXHJcbiAgICB9KTtcclxuICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAoaWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcih0cnVlKTtcclxuICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL2VtcGxveWVlLWluY2VudGl2ZS1wYXltZW50LW91dC8ke2lkfWApO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkRhdGEgRGVsZXRlZCBTdWNjZXNzZnVsbHkhXCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIGZldGNoSW5jZW50aXZlSGlzdG9yeShhY3RpdmVUYWIsIGFjdGl2ZVN1YlRhYlthY3RpdmVUYWJdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRGVsZXRlIGZhaWxlZFwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAoIXZhbGlkYXRlRm9ybSgpKSByZXR1cm47XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG4gICAgICBpZiAoZWRpdElkKSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLnB1dChgL2VtcGxveWVlLWluY2VudGl2ZS1wYXltZW50LW91dC8ke2VkaXRJZH1gLCBmb3JtRGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvZW1wbG95ZWUtaW5jZW50aXZlLXBheW1lbnQtb3V0XCIsIGZvcm1EYXRhKTtcclxuICAgICAgfVxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlZGl0SWQgPyBcIkRhdGEgVXBkYXRlZCBTdWNjZXNzZnVsbHkhXCIgOiBcIkRhdGEgQWRkZWQgU3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBjbG9zZURyYXdlcigpO1xyXG4gICAgICBmZXRjaEluY2VudGl2ZUhpc3RvcnkoYWN0aXZlVGFiLCBhY3RpdmVTdWJUYWJbYWN0aXZlVGFiXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkVycm9yIHNhdmluZyBkYXRhXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZXJycyA9IHt9O1xyXG4gICAgaWYgKCFmb3JtRGF0YS5lbXBsb3llZV9pZCkgZXJycy5lbXBsb3llZSA9IFwiUmVxdWlyZWRcIjtcclxuICAgIGlmICghZm9ybURhdGEuYW1vdW50IHx8IGZvcm1EYXRhLmFtb3VudCA8PSAwKSBlcnJzLmFtb3VudCA9IFwiRW50ZXIgdmFsaWQgYW1vdW50XCI7XHJcbiAgICBpZiAoIWZvcm1EYXRhLm1vbnRoKSBlcnJzLm1vbnRoID0gXCJSZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFmb3JtRGF0YS55ZWFyKSBlcnJzLnllYXIgPSBcIlJlcXVpcmVkXCI7XHJcbiAgICBpZiAoIWZvcm1EYXRhLnBheV9kYXRlKSBlcnJzLnBheV9kYXRlID0gXCJSZXF1aXJlZFwiO1xyXG4gICAgc2V0RXJyb3JzKGVycnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKGVycnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBjbG9zZURyYXdlciA9ICgpID0+IHtcclxuICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICBzZXRFZGl0SWQobnVsbCk7XHJcbiAgICBzZXRGb3JtRGF0YShpbml0aWFsRm9ybSk7XHJcbiAgICBzZXRFcnJvcnMoe30pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlTmFtZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiaW5jZW50aXZlX3R5cGVcIiwgaGVhZGVyOiBcIkluY2VudGl2ZSBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcIm1vbnRoXCIsIGhlYWRlcjogXCJNb250aFwiIH0sXHJcbiAgICB7IGtleTogXCJ5ZWFyXCIsIGhlYWRlcjogXCJZZWFyXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBheV90eXBlXCIsIGhlYWRlcjogXCJNb2RlXCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zYWN0aW9uX2lkXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgVGFiQ29udGVudCA9ICgpID0+IChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkVtcGxveWVlIEluY2VudGl2ZTwvaDE+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRFZGl0SWQobnVsbCk7XHJcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKGluaXRpYWxGb3JtKTtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWRcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgICsgQWRkIHtnZXRUeXBlRnJvbVRhYihhY3RpdmVUYWIpfSBJbmNlbnRpdmVcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICApIDogdGFibGVQYXltZW50cy5sZW5ndGggPD0gMCA/IChcclxuICAgICAgICA8RW1wdHkgZGVzY3JpcHRpb249XCJObyBJbmNlbnRpdmUgUGF5bWVudCBEYXRhIEZvdW5kXCIgLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICBkYXRhPXt0YWJsZVBheW1lbnRzLmZpbHRlcigoaXRlbSkgPT5cclxuICAgICAgICAgICAgaXRlbS5lbXBsb3llZU5hbWU/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvPlxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHN1YlRhYnMgPSBbXHJcbiAgICB7IGtleTogXCJQZW5kaW5nXCIsIGxhYmVsOiBcIlBlbmRpbmdcIiB9LFxyXG4gICAgeyBrZXk6IFwiQ29tcGxldGVkXCIsIGxhYmVsOiBcIkNvbXBsZXRlZFwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdGFiSXRlbXMgPSBbXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgIGxhYmVsOiBcIkNoaXQgSW5jZW50aXZlc1wiLFxyXG4gICAgICBjaGlsZHJlbjogKFxyXG4gICAgICAgIDxUYWJzXHJcbiAgICAgICAgICBhY3RpdmVLZXk9e2FjdGl2ZVN1YlRhYltcIjFcIl19XHJcbiAgICAgICAgICBvbkNoYW5nZT17KHN1YktleSkgPT4gaGFuZGxlU3ViVGFiQ2hhbmdlKFwiMVwiLCBzdWJLZXkpfVxyXG4gICAgICAgICAgaXRlbXM9e3N1YlRhYnMubWFwKChzdWIpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnN1YixcclxuICAgICAgICAgICAgY2hpbGRyZW46IDxUYWJDb250ZW50IHR5cGU9XCJjaGl0XCIgc3RhdHVzPXtzdWIua2V5fSAvPixcclxuICAgICAgICAgIH0pKX1cclxuICAgICAgICAvPlxyXG4gICAgICApLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIjJcIixcclxuICAgICAgbGFiZWw6IFwiTG9hbiBJbmNlbnRpdmVzXCIsXHJcbiAgICAgIGNoaWxkcmVuOiAoXHJcbiAgICAgICAgPFRhYnNcclxuICAgICAgICAgIGFjdGl2ZUtleT17YWN0aXZlU3ViVGFiW1wiMlwiXX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoc3ViS2V5KSA9PiBoYW5kbGVTdWJUYWJDaGFuZ2UoXCIyXCIsIHN1YktleSl9XHJcbiAgICAgICAgICBpdGVtcz17c3ViVGFicy5tYXAoKHN1YikgPT4gKHtcclxuICAgICAgICAgICAgLi4uc3ViLFxyXG4gICAgICAgICAgICBjaGlsZHJlbjogPFRhYkNvbnRlbnQgdHlwZT1cImxvYW5cIiBzdGF0dXM9e3N1Yi5rZXl9IC8+LFxyXG4gICAgICAgICAgfSkpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICBsYWJlbDogXCJQaWdteSBJbmNlbnRpdmVzXCIsXHJcbiAgICAgIGNoaWxkcmVuOiAoXHJcbiAgICAgICAgPFRhYnNcclxuICAgICAgICAgIGFjdGl2ZUtleT17YWN0aXZlU3ViVGFiW1wiM1wiXX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoc3ViS2V5KSA9PiBoYW5kbGVTdWJUYWJDaGFuZ2UoXCIzXCIsIHN1YktleSl9XHJcbiAgICAgICAgICBpdGVtcz17c3ViVGFicy5tYXAoKHN1YikgPT4gKHtcclxuICAgICAgICAgICAgLi4uc3ViLFxyXG4gICAgICAgICAgICBjaGlsZHJlbjogPFRhYkNvbnRlbnQgdHlwZT1cInBpZ215XCIgc3RhdHVzPXtzdWIua2V5fSAvPixcclxuICAgICAgICAgIH0pKX1cclxuICAgICAgICAvPlxyXG4gICAgICApLFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICAvLyBRdWljayBuYXZpZ2F0b3IgbGluayBkYXRhXHJcbiAgY29uc3QgTkFWX0xJTktTID0gW1xyXG4gICAge1xyXG4gICAgICB0bzogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L3NhbGFyeS1wYXltZW50XCIsXHJcbiAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgICAgbGFiZWw6IFwiU2FsYXJ5IHBheW1lbnRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRvOiBcIi9zdGFmZi1tZW51L2VtcGxveWVlLW1lbnUvc2FsYXJ5LW1hbmFnZW1lbnRcIixcclxuICAgICAgaWNvbjogPE1kT3V0bGluZU1hbiBzaXplPXsxNn0gLz4sXHJcbiAgICAgIGxhYmVsOiBcIlNhbGFyeSBtYW5hZ2VtZW50XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0bzogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvYWR2YW5jZS1wYXltZW50LWluXCIsXHJcbiAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgICAgbGFiZWw6IFwiQWR2YW5jZSByZXBheW1lbnRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRvOiBcIi9zdGFmZi1tZW51L2VtcGxveWVlLW1lbnUvZW1wbG95ZWUtc3RhdGVtZW50XCIsXHJcbiAgICAgIGljb246IDxVc2VyIHNpemU9ezE2fSAvPixcclxuICAgICAgbGFiZWw6IFwiU2FsYXJ5IExlZGdlclwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdG86IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9hZGRpdGlvbmFsLXNhbGFyeVwiLFxyXG4gICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlRmlsbCBzaXplPXsxNn0gLz4sXHJcbiAgICAgIGxhYmVsOiBcIkFkZGl0aW9uYWwgc2FsYXJ5XCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7b3BlbkJhY2tkcm9wTG9hZGVyICYmIDxCYWNrZHJvcEJsdXJMb2FkZXIgdGl0bGU9e1wiUHJvY2Vzc2luZy4uLlwifSAvPn1cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICB7YWxlcnRDb25maWcudmlzaWJpbGl0eSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIHRvcC01IGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgei1bMTAwMF0gdy1mdWxsIG1heC13LW1kIHB4LTRcIj5cclxuICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICAgIHNob3dJY29uXHJcbiAgICAgICAgICAgICAgY2xvc2FibGVcclxuICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBbGVydENvbmZpZyh7IC4uLmFsZXJ0Q29uZmlnLCB2aXNpYmlsaXR5OiBmYWxzZSB9KX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIGdhcC02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+U2FsYXJ5IEluY2VudGl2ZTwvaDE+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtbGcgdGV4dC1ibGFjayBmb250LWJvbGQgZm9udC1tb25vIHAtMiBtdC0zXCI+XHJcbiAgICAgICAgICAgICAgICBRdWljayBOYXZpZ2F0b3JcclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtZ3JheS00MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICBRdWljayBuYXZpZ2F0b3JcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAge05BVl9MSU5LUy5tYXAoKGxpbmspID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rLnRvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdG89e2xpbmsudG99XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHRleHQtc20gdGV4dC1ncmF5LTYwMCBob3Zlcjpib3JkZXItYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCI+e2xpbmsuaWNvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bGluay5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHAtNCBtYi02IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctYW1iZXItNTAgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8RmFSdXBlZVNpZ24gY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWFtYmVyLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlBlbmRpbmcgUGF5bWVudHM8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7c3VtbWFyeUxvYWRpbmcgPyBcIi4uLlwiIDogcGVuZGluZ1N1bW1hcnkuY291bnR9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xMiBib3JkZXItbCBib3JkZXItZ3JheS0yMDAgbXgtOFwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlRvdGFsIFBheWFibGU8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIOKCuXtzdW1tYXJ5TG9hZGluZyA/IFwiLi4uXCIgOiBwZW5kaW5nU3VtbWFyeS50b3RhbEFtb3VudC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8VGFic1xyXG4gICAgICAgICAgICBhY3RpdmVLZXk9e2FjdGl2ZVRhYn1cclxuICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZU1haW5UYWJDaGFuZ2V9XHJcbiAgICAgICAgICAgIGl0ZW1zPXt0YWJJdGVtc31cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxEcmF3ZXJcclxuICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBiZy1ibHVlLTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8RmFSdXBlZVNpZ24gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICB7ZWRpdElkID8gXCJFZGl0IEluY2VudGl2ZSBQYXltZW50XCIgOiBcIk5ldyBJbmNlbnRpdmUgUGF5bWVudFwifVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBvcGVuPXtzaG93TW9kYWx9XHJcbiAgICAgICAgICBvbkNsb3NlPXtjbG9zZURyYXdlcn1cclxuICAgICAgICAgIHdpZHRoPXs0ODB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS02IHAtMVwiPlxyXG4gICAgICAgICAgICB7LyogRW1wbG95ZWUgU2VsZWN0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIEVtcGxveWVlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGFuZCBzZWxlY3QgZW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVtcGxveWVlX2lkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJsYWJlbFwiXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgZW1wbG95ZWVfaWQ6IHZhbCB9KX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtlbXAuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbXAuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPXtgJHtlbXAubmFtZX0gJHtlbXAuZW1wbG95ZWVDb2RlfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYmctYmx1ZS0xMDAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX0gfCB7ZW1wLmVtcGxveWVlQ29kZX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5lbXBsb3llZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTEgYmctcmVkLTUwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1wbG95ZWV9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogSW5jZW50aXZlIFR5cGUgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgPEZpQ3JlZGl0Q2FyZCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgSW5jZW50aXZlIFR5cGVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5pbmNlbnRpdmVfdHlwZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBpbmNlbnRpdmVfdHlwZTogdmFsIH0pfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQ2hpdFwiPkNoaXQ8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkxvYW5cIj5Mb2FuPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJQaWdteVwiPlBpZ215PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNb250aCAmIFllYXIgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgPEZpQ2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgIE1vbnRoICYgWWVhclxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC0zIHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm1vbnRoIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBtb250aDogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyEhZWRpdElkfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBNb250aDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCJKYW51YXJ5XCIsXCJGZWJydWFyeVwiLFwiTWFyY2hcIixcIkFwcmlsXCIsXCJNYXlcIixcIkp1bmVcIixcIkp1bHlcIixcIkF1Z3VzdFwiLFwiU2VwdGVtYmVyXCIsXCJPY3RvYmVyXCIsXCJOb3ZlbWJlclwiLFwiRGVjZW1iZXJcIl0ubWFwKChtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bX0gdmFsdWU9e219PnttfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5tb250aCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5tb250aH08L3A+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC0zIHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnllYXIgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHllYXI6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshIWVkaXRJZH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgWWVhcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiAxMCB9LCAoXywgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgeWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKSAtIDUgKyBpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxvcHRpb24ga2V5PXt5ZWFyfSB2YWx1ZT17eWVhcn0+e3llYXJ9PC9vcHRpb24+O1xyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy55ZWFyICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLnllYXJ9PC9wPn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBBbW91bnQgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBBbW91bnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtNCB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPuKCuTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHBsLTggcHItNCBweS0yLjUgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17TnVtYmVyKGZvcm1EYXRhLmFtb3VudCkgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBhbW91bnQ6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfHwgMCB9KX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge2Zvcm1EYXRhLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCByb3VuZGVkLWxnIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5hbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50ICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e2Vycm9ycy5hbW91bnR9PC9wPn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogUGF5bWVudCBEYXRlICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIDxGaUNhbGVuZGFyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBQYXltZW50IERhdGVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHBheV9kYXRlOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGUgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHNcIj57ZXJyb3JzLnBheV9kYXRlfTwvcD59XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFBheW1lbnQgTW9kZSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8RmlDcmVkaXRDYXJkIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV90eXBlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHBheV90eXBlOiB2YWwgfSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjYXNoXCI+Q2FzaDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lL1VQSTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY2hlcXVlXCI+Q2hlcXVlPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUcmFuc2FjdGlvbiBJRCAqL31cclxuICAgICAgICAgICAge2Zvcm1EYXRhLnBheV90eXBlICE9PSBcImNhc2hcIiAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgYW5pbWF0ZS1mYWRlSW5cIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPEZpSGFzaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICB7Zm9ybURhdGEucGF5X3R5cGUgPT09IFwiY2hlcXVlXCIgPyBcIkNoZXF1ZSBOdW1iZXJcIiA6IFwiVHJhbnNhY3Rpb24gSURcIn1cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2Zvcm1EYXRhLnBheV90eXBlID09PSBcImNoZXF1ZVwiID8gXCJFbnRlciBjaGVxdWUgbnVtYmVyXCIgOiBcIkVudGVyIHRyYW5zYWN0aW9uL1VQSSBJRFwifVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgdHJhbnNhY3Rpb25faWQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdGF0dXMgKGVkaXQgb25seSkgKi99XHJcbiAgICAgICAgICAgIHtlZGl0SWQgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxHclN0YXR1c0dvb2QgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHN0YXR1czogdmFsIH0pfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlBlbmRpbmdcIj5QZW5kaW5nPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkNvbXBsZXRlZFwiPkNvbXBsZXRlZDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1ibHVlLTcwMCB0ZXh0LXdoaXRlIHB5LTMgcm91bmRlZC1sZyBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWJsdWUtODAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmb250LXNlbWlib2xkIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNmb3JtIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtlZGl0SWQgPyBcIlVwZGF0ZSBJbmNlbnRpdmUgUGF5bWVudFwiIDogXCJTYXZlIEluY2VudGl2ZSBQYXltZW50XCJ9XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvRHJhd2VyPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTYWxhcnlJbmNlbnRpdmVzOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9TYWxhcnlJbmNlbnRpdmUuanN4In0=