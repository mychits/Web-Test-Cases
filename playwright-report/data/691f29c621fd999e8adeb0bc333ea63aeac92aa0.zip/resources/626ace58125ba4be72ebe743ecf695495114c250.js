import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OverDueMessage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const OverDueMessage = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const [selectAll, setSelectAll] = useState(false);
  const groupOptions = [...new Set(usersData.map((u) => u.groupName))];
  const filteredUsers = useMemo(() => {
    const filtered = filterOption(
      usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
        const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
        return matchGroup && matchFromDate && matchToDate;
      }),
      searchText
    );
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    balance: user.balance,
                    userPhone: user.userPhone,
                    paymentsTicket: user.paymentsTicket,
                    groupName: user.groupName,
                    userName: user.userName,
                    groupId: user.groupId,
                    userId: user.userId,
                    amountPaid: user.amountPaid,
                    amountToBePaid: user.totalToBePaid,
                    latestPaymentDate: user.latestPaymentDate,
                    // ✅ added
                    latestPaymentAmount: user.latestPaymentAmount,
                    // ✅ added
                    paymentType: user.payment_type
                    // ✅ added
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
            lineNumber: 49,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, searchText, activeUserData]);
  useEffect(() => {
    if (filteredUsers.length > 0) {
      const allSelected = filteredUsers.every((user) => user.isSelected);
      setSelectAll(allSelected);
    } else {
      setSelectAll(false);
    }
  }, [filteredUsers]);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp..",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/whatsapp/over-due-message", visibleActiveUsers);
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete newActiveUserData[user._id];
        }
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Has Been Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/user/get-overdue-payments");
      const usersList = [];
      const tempActive = {};
      reportResponse.data.forEach((usrData) => {
        if (usrData?.data) {
          usrData.data.forEach((data) => {
            if (data?.enrollment?.group) {
              const groupInstall = parseInt(
                data.enrollment.group.group_install
              );
              const groupId = data.enrollment.group._id;
              const groupType = data.enrollment.group.group_type;
              const totalPaidAmount = data.payments.totalPaidAmount;
              const auctionCount = parseInt(data?.auction?.auctionCount);
              const totalPayable = data.payable.totalPayable;
              const totalProfit = data.profit.totalProfit;
              const firstDividentHead = data.firstAuction.firstDividentHead;
              const id = data?.enrollment?._id;
              const userPhone = usrData.phone_number;
              const paymentsTicket = data.payments.ticket;
              const groupName = data.enrollment.group.group_name;
              const totalToBePaid = groupType === "double" ? groupInstall * auctionCount + groupInstall : totalPayable + groupInstall + totalProfit;
              const amountToBePaid = totalToBePaid;
              const balance = groupType === "double" ? totalToBePaid - totalPaidAmount : totalPayable + groupInstall + firstDividentHead - totalPaidAmount;
              if (balance <= 0) return;
              const userName = usrData.userName;
              const latestPaymentAmount = data.latestPaymentAmount || 0;
              const latestPaymentDate = data.latestPaymentDate || "";
              tempActive[id] = {
                info: {
                  status: false,
                  balance
                }
              };
              const tempUsr = {
                _id: id,
                userName,
                userPhone,
                customerId: usrData.customer_id,
                amountPaid: totalPaidAmount,
                paymentsTicket,
                amountToBePaid,
                groupName,
                payment_type: data?.enrollment?.payment_type,
                totalToBePaid,
                balance,
                groupId,
                userId: usrData?._id,
                latestPaymentAmount,
                // ⬅ New field
                latestPaymentDate
                // ⬅ New field
              };
              usersList.push(tempUsr);
            }
          });
        }
      });
      setUsersData(usersList);
      setActiveUserData(tempActive);
      setTotalUsers(usersList.length);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" },
    { key: "payment_type", header: "Payment Type" },
    { key: "paymentsTicket", header: "Ticket" },
    { key: "totalToBePaid", header: "Amount Payable" },
    { key: "amountPaid", header: "Paid Amount" },
    { key: "latestPaymentAmount", header: "Last Payment Amount" },
    // ✅ NEW
    {
      key: "latestPaymentDate",
      header: "Last Payment Date",
      render: (value) => value ? new Date(value).toLocaleDateString("en-IN") : "N/A"
      // ✅ NEW
    },
    { key: "balance", header: "Balance" },
    { key: "checkBoxs", header: "Select User" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
        lineNumber: 255,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
      lineNumber: 259,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
        lineNumber: 262,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Whatsapp Outstanding [Over Due] Messages" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
        lineNumber: 263,
        columnNumber: 13
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
          lineNumber: 268,
          columnNumber: 15
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
          lineNumber: 271,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
          lineNumber: 270,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                  lineNumber: 278,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                  lineNumber: 279,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                lineNumber: 277,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                lineNumber: 283,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
              lineNumber: 276,
              columnNumber: 3
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                  lineNumber: 288,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                  lineNumber: 289,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                lineNumber: 287,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                lineNumber: 293,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
              lineNumber: 286,
              columnNumber: 3
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
            lineNumber: 275,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Group Filter" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                lineNumber: 298,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  style: { width: 200 },
                  allowClear: true,
                  placeholder: "--All groups--",
                  onChange: (value) => setGroupFilter(value),
                  value: groupFilter || void 0,
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                      lineNumber: 309,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                  lineNumber: 301,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
              lineNumber: 297,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mt-6", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: selectAll,
                  onChange: (e) => {
                    const isChecked = e.target.checked;
                    setSelectAll(isChecked);
                    setActiveUserData((prev) => {
                      const updated = { ...prev };
                      filteredUsers.forEach((user) => {
                        updated[user._id] = {
                          info: {
                            ...updated[user._id]?.info,
                            status: isChecked,
                            balance: user.balance,
                            userPhone: user.userPhone,
                            paymentsTicket: user.paymentsTicket,
                            groupName: user.groupName,
                            userName: user.userName,
                            groupId: user.groupId,
                            userId: user.userId,
                            amountPaid: user.amountPaid,
                            amountToBePaid: user.totalToBePaid,
                            latestPaymentDate: user.latestPaymentDate,
                            latestPaymentAmount: user.latestPaymentAmount,
                            paymentType: user.payment_type
                          }
                        };
                      });
                      return updated;
                    });
                  },
                  className: "mr-2"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                  lineNumber: 316,
                  columnNumber: 3
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium text-gray-700", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                lineNumber: 351,
                columnNumber: 3
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
              lineNumber: 315,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
            lineNumber: 296,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                      lineNumber: 365,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                    lineNumber: 361,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
                  lineNumber: 368,
                  columnNumber: 21
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
              lineNumber: 356,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
            lineNumber: 355,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Overdue Whatsapp Message",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Overdue Whatsapp Message.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
              lineNumber: 372,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
          lineNumber: 274,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
        lineNumber: 267,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
      lineNumber: 261,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
    lineNumber: 254,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx",
    lineNumber: 253,
    columnNumber: 5
  }, this);
};
_s(OverDueMessage, "XL6j3B4tL9B5cLdvE3A/BXr4E4U=", false, function() {
  return [notification.useNotification];
});
_c = OverDueMessage;
export default OverDueMessage;
var _c;
$RefreshReg$(_c, "OverDueMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueMessage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0RVOzJCQWhEVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFHdkIsTUFBTUMsaUJBQWlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlqQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDa0IsV0FBV0MsWUFBWSxJQUFJbkIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ29CLGFBQWFDLGNBQWMsSUFBSXJCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNzQixVQUFVQyxXQUFXLElBQUl2QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDd0IsUUFBUUMsU0FBUyxJQUFJekIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzBCLGdCQUFnQkMsaUJBQWlCLElBQUkzQixTQUFTLENBQUMsQ0FBQztBQUN2RCxRQUFNLENBQUM0QixXQUFXQyxZQUFZLElBQUk3QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDOEIsWUFBWUMsYUFBYSxJQUFJL0IsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ2dDLFVBQVVDLGFBQWEsSUFBSXhCLGFBQWF5QixnQkFBZ0I7QUFDL0QsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlwQyxTQUFTLEtBQUs7QUFDaEQsUUFBTXFDLGVBQWUsQ0FBQyxHQUFHLElBQUlDLElBQUlwQixVQUFVcUIsSUFBSSxDQUFDQyxNQUFNQSxFQUFFQyxTQUFTLENBQUMsQ0FBQztBQUVuRSxRQUFNQyxnQkFBZ0J6QyxRQUFRLE1BQU07QUFDbEMsVUFBTTBDLFdBQVdwQztBQUFBQSxNQUNmVyxVQUFVMEIsT0FBTyxDQUFDSixNQUFNO0FBQ3RCLGNBQU1LLGFBQWF6QixjQUFjb0IsRUFBRUMsY0FBY3JCLGNBQWM7QUFDL0QsY0FBTTBCLGlCQUFpQixJQUFJQyxLQUFLUCxFQUFFTSxjQUFjO0FBQ2hELGNBQU1FLGdCQUFnQjFCLFdBQ2xCd0Isa0JBQWtCLElBQUlDLEtBQUt6QixRQUFRLElBQ25DO0FBQ0osY0FBTTJCLGNBQWN6QixTQUFTc0Isa0JBQWtCLElBQUlDLEtBQUt2QixNQUFNLElBQUk7QUFDbEUsZUFBT3FCLGNBQWNHLGlCQUFpQkM7QUFBQUEsTUFDeEMsQ0FBQztBQUFBLE1BQ0RqQztBQUFBQSxJQUNGO0FBRUEsV0FBTzJCLFNBQVNKLElBQUksQ0FBQ1csTUFBTUMsVUFBVTtBQUNuQyxZQUFNQyxhQUFhLENBQUMsQ0FBQzFCLGVBQWV3QixLQUFLRyxHQUFHLEdBQUdDLE1BQU1DO0FBRXJELGFBQU87QUFBQSxRQUNMLEdBQUdMO0FBQUFBLFFBQ0hNLE9BQU9MLFFBQVE7QUFBQSxRQUNmTSxXQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTTDtBQUFBQSxZQUNULFVBQVUsQ0FBQ00sTUFBTTtBQUNmL0IsZ0NBQWtCLENBQUNnQyxVQUFVO0FBQUEsZ0JBQzNCLEdBQUdBO0FBQUFBLGdCQUNILENBQUNULEtBQUtHLEdBQUcsR0FBRztBQUFBLGtCQUNWQyxNQUFNO0FBQUEsb0JBQ0pDLFFBQVFHLEVBQUVFLE9BQU9DO0FBQUFBLG9CQUNqQkMsU0FBU1osS0FBS1k7QUFBQUEsb0JBQ2RDLFdBQVdiLEtBQUthO0FBQUFBLG9CQUNoQkMsZ0JBQWdCZCxLQUFLYztBQUFBQSxvQkFDckJ2QixXQUFXUyxLQUFLVDtBQUFBQSxvQkFDaEJ3QixVQUFVZixLQUFLZTtBQUFBQSxvQkFDZkMsU0FBU2hCLEtBQUtnQjtBQUFBQSxvQkFDZEMsUUFBUWpCLEtBQUtpQjtBQUFBQSxvQkFDYkMsWUFBWWxCLEtBQUtrQjtBQUFBQSxvQkFDakJDLGdCQUFnQm5CLEtBQUtvQjtBQUFBQSxvQkFDckJDLG1CQUFtQnJCLEtBQUtxQjtBQUFBQTtBQUFBQSxvQkFDeEJDLHFCQUFxQnRCLEtBQUtzQjtBQUFBQTtBQUFBQSxvQkFDMUJDLGFBQWF2QixLQUFLd0I7QUFBQUE7QUFBQUEsa0JBQ3BCO0FBQUEsZ0JBQ0Y7QUFBQSxjQUNGLEVBQUU7QUFBQSxZQUNKO0FBQUE7QUFBQSxVQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF3Qkk7QUFBQSxRQUdOdEI7QUFBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDbEMsV0FBV0UsYUFBYUUsVUFBVUUsUUFBUVIsWUFBWVUsY0FBYyxDQUFDO0FBQzNFM0IsWUFBVSxNQUFNO0FBQ2QsUUFBSTJDLGNBQWNpQyxTQUFTLEdBQUc7QUFDNUIsWUFBTUMsY0FBY2xDLGNBQWNtQyxNQUFNLENBQUMzQixTQUFTQSxLQUFLRSxVQUFVO0FBQ2pFaEIsbUJBQWF3QyxXQUFXO0FBQUEsSUFDMUIsT0FBTztBQUNMeEMsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRixHQUFHLENBQUNNLGFBQWEsQ0FBQztBQUNoQixRQUFNb0MsdUJBQXVCN0UsUUFBUSxNQUFNO0FBQ3pDLFdBQU95QyxjQUFjRSxPQUFPLENBQUNNLFNBQVNBLEtBQUtFLFVBQVUsRUFBRXVCO0FBQUFBLEVBQ3pELEdBQUcsQ0FBQ2pDLGFBQWEsQ0FBQztBQUVsQixRQUFNcUMsZUFBZSxZQUFZO0FBQy9CLFVBQU1DLE1BQU07QUFDWixRQUFJO0FBQ0ZoRCxlQUFTaUQsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFFRCxZQUFNQyxxQkFBcUIsQ0FBQztBQUM1QjVDLG9CQUFjNkMsUUFBUSxDQUFDckMsU0FBUztBQUM5QixZQUFJQSxLQUFLRSxjQUFjMUIsZUFBZXdCLEtBQUtHLEdBQUcsR0FBRztBQUMvQ2lDLDZCQUFtQnBDLEtBQUtHLEdBQUcsSUFBSTNCLGVBQWV3QixLQUFLRyxHQUFHO0FBQUEsUUFDeEQ7QUFBQSxNQUNGLENBQUM7QUFFRCxZQUFNbkQsSUFBSXNGLEtBQUssOEJBQThCRixrQkFBa0I7QUFFL0QsWUFBTUcsb0JBQW9CLEVBQUUsR0FBRy9ELGVBQWU7QUFDOUNnQixvQkFBYzZDLFFBQVEsQ0FBQ3JDLFNBQVM7QUFDOUIsWUFBSUEsS0FBS0UsWUFBWTtBQUNuQixpQkFBT3FDLGtCQUFrQnZDLEtBQUtHLEdBQUc7QUFBQSxRQUNuQztBQUFBLE1BQ0YsQ0FBQztBQUNEMUIsd0JBQWtCOEQsaUJBQWlCO0FBRW5DekQsZUFBU2lELEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxTQUFTSyxLQUFLO0FBQ1oxRCxlQUFTaUQsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhTyxJQUFJUixXQUFXO0FBQUEsUUFDNUJFLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNTSxZQUFZLFlBQVk7QUFDNUIsUUFBSTtBQUNGOUQsbUJBQWEsSUFBSTtBQUNqQixZQUFNK0QsaUJBQWlCLE1BQU0xRixJQUFJMkYsSUFBSSw0QkFBNEI7QUFDakUsWUFBTUMsWUFBWTtBQUNsQixZQUFNQyxhQUFhLENBQUM7QUFFcEJILHFCQUFlSSxLQUFLVCxRQUFRLENBQUNVLFlBQVk7QUFDdkMsWUFBSUEsU0FBU0QsTUFBTTtBQUNqQkMsa0JBQVFELEtBQUtULFFBQVEsQ0FBQ1MsU0FBUztBQUM3QixnQkFBSUEsTUFBTUUsWUFBWUMsT0FBTztBQUMzQixvQkFBTUMsZUFBZUM7QUFBQUEsZ0JBQ25CTCxLQUFLRSxXQUFXQyxNQUFNRztBQUFBQSxjQUN4QjtBQUNBLG9CQUFNcEMsVUFBVThCLEtBQUtFLFdBQVdDLE1BQU05QztBQUN0QyxvQkFBTWtELFlBQVlQLEtBQUtFLFdBQVdDLE1BQU1LO0FBQ3hDLG9CQUFNQyxrQkFBa0JULEtBQUtVLFNBQVNEO0FBQ3RDLG9CQUFNRSxlQUFlTixTQUFTTCxNQUFNWSxTQUFTRCxZQUFZO0FBQ3pELG9CQUFNRSxlQUFlYixLQUFLYyxRQUFRRDtBQUNsQyxvQkFBTUUsY0FBY2YsS0FBS2dCLE9BQU9EO0FBQ2hDLG9CQUFNRSxvQkFBb0JqQixLQUFLa0IsYUFBYUQ7QUFDNUMsb0JBQU1FLEtBQUtuQixNQUFNRSxZQUFZN0M7QUFDN0Isb0JBQU1VLFlBQVlrQyxRQUFRbUI7QUFDMUIsb0JBQU1wRCxpQkFBaUJnQyxLQUFLVSxTQUFTVztBQUNyQyxvQkFBTTVFLFlBQVl1RCxLQUFLRSxXQUFXQyxNQUFNbUI7QUFHeEMsb0JBQU1oRCxnQkFDSmlDLGNBQWMsV0FDVkgsZUFBZU8sZUFBZVAsZUFDOUJTLGVBQWVULGVBQWVXO0FBQ3BDLG9CQUFNMUMsaUJBQWlCQztBQUV2QixvQkFBTVIsVUFDSnlDLGNBQWMsV0FDVmpDLGdCQUFnQm1DLGtCQUNoQkksZUFDQVQsZUFDQWEsb0JBQ0FSO0FBRU4sa0JBQUkzQyxXQUFXLEVBQUc7QUFFbEIsb0JBQU1HLFdBQVdnQyxRQUFRaEM7QUFHekIsb0JBQU1PLHNCQUFzQndCLEtBQUt4Qix1QkFBdUI7QUFDeEQsb0JBQU1ELG9CQUFvQnlCLEtBQUt6QixxQkFBcUI7QUFFcER3Qix5QkFBV29CLEVBQUUsSUFBSTtBQUFBLGdCQUNmN0QsTUFBTTtBQUFBLGtCQUNKQyxRQUFRO0FBQUEsa0JBQ1JPO0FBQUFBLGdCQUNGO0FBQUEsY0FDRjtBQUVBLG9CQUFNeUQsVUFBVTtBQUFBLGdCQUNkbEUsS0FBSzhEO0FBQUFBLGdCQUNMbEQ7QUFBQUEsZ0JBQ0FGO0FBQUFBLGdCQUNBeUQsWUFBWXZCLFFBQVF3QjtBQUFBQSxnQkFDcEJyRCxZQUFZcUM7QUFBQUEsZ0JBQ1p6QztBQUFBQSxnQkFDQUs7QUFBQUEsZ0JBQ0E1QjtBQUFBQSxnQkFDQWlDLGNBQWNzQixNQUFNRSxZQUFZeEI7QUFBQUEsZ0JBQ2hDSjtBQUFBQSxnQkFDQVI7QUFBQUEsZ0JBQ0FJO0FBQUFBLGdCQUNBQyxRQUFROEIsU0FBUzVDO0FBQUFBLGdCQUNqQm1CO0FBQUFBO0FBQUFBLGdCQUNBRDtBQUFBQTtBQUFBQSxjQUNGO0FBQ0F1Qix3QkFBVTRCLEtBQUtILE9BQU87QUFBQSxZQUN4QjtBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGLENBQUM7QUFFRHBHLG1CQUFhMkUsU0FBUztBQUN0Qm5FLHdCQUFrQm9FLFVBQVU7QUFDNUJoRSxvQkFBYytELFVBQVVuQixNQUFNO0FBQUEsSUFDaEMsU0FBU2dELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxJQUM3QyxVQUFDO0FBQ0M5RixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUE5QixZQUFVLE1BQU07QUFDZDRGLGNBQVU7QUFBQSxFQUNaLEdBQUcsRUFBRTtBQUVMLFFBQU1rQyxpQkFBaUI7QUFBQSxJQUNyQixFQUFFN0MsS0FBSyxTQUFTOEMsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRTlDLEtBQUssWUFBWThDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDM0MsRUFBRTlDLEtBQUssYUFBYThDLFFBQVEsZUFBZTtBQUFBLElBQzNDLEVBQUU5QyxLQUFLLGNBQWM4QyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFOUMsS0FBSyxhQUFhOEMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRTlDLEtBQUssZ0JBQWdCOEMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRTlDLEtBQUssa0JBQWtCOEMsUUFBUSxTQUFTO0FBQUEsSUFDMUMsRUFBRTlDLEtBQUssaUJBQWlCOEMsUUFBUSxpQkFBaUI7QUFBQSxJQUNqRCxFQUFFOUMsS0FBSyxjQUFjOEMsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRTlDLEtBQUssdUJBQXVCOEMsUUFBUSxzQkFBc0I7QUFBQTtBQUFBLElBQzVEO0FBQUEsTUFDRTlDLEtBQUs7QUFBQSxNQUNMOEMsUUFBUTtBQUFBLE1BQ1JDLFFBQVFBLENBQUNDLFVBQ1BBLFFBQVEsSUFBSWpGLEtBQUtpRixLQUFLLEVBQUVDLG1CQUFtQixPQUFPLElBQUk7QUFBQTtBQUFBLElBQzFEO0FBQUEsSUFDQSxFQUFFakQsS0FBSyxXQUFXOEMsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRTlDLEtBQUssYUFBYThDLFFBQVEsY0FBYztBQUFBLEVBQUM7QUFHN0MsU0FDQyx1QkFBQyxTQUFJLFdBQVUsVUFDWixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyw2QkFBNkIsQ0FBQ3BFLE1BQU16QyxjQUFjeUMsRUFBRUUsT0FBT29FLEtBQUs7QUFBQSxRQUNoRSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFFTix1QkFBQyxTQUFJLFdBQVUsaUJBQ1Y7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUNkLHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0Msd0RBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0MvRjtBQUFBQSxNQUNELHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNoRUwsWUFDTix1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxrQkFBZSxPQUFNLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVJLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1EQUM3QjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLCtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxPQUFFLFdBQVUsc0NBQ1ZjLHdCQUFjaUMsVUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFdBQVEsV0FBVSw4QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkM7QUFBQSxpQkFQL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLE9BQUUsV0FBVSx5QkFBd0Isa0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsZ0JBQ3ZELHVCQUFDLE9BQUUsV0FBVSxxQ0FDVkcsa0NBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLGlCQUFjLFdBQVUsNkJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtEO0FBQUEsaUJBUHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQW5CYztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CaEI7QUFBQSxVQUNnQix1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTyxFQUFFb0QsT0FBTyxJQUFJO0FBQUEsa0JBQ3BCO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaLFVBQVUsQ0FBQ0YsVUFBVTNHLGVBQWUyRyxLQUFLO0FBQUEsa0JBQ3pDLE9BQU81RyxlQUFlK0c7QUFBQUEsa0JBRXJCOUYsdUJBQWFFO0FBQUFBLG9CQUFJLENBQUM0RCxVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FZQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUMvQjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTaEU7QUFBQUEsa0JBQ1QsVUFBVSxDQUFDdUIsTUFBTTtBQUNmLDBCQUFNMEUsWUFBWTFFLEVBQUVFLE9BQU9DO0FBQzNCekIsaUNBQWFnRyxTQUFTO0FBR3RCekcsc0NBQWtCLENBQUNnQyxTQUFTO0FBQzFCLDRCQUFNMEUsVUFBVSxFQUFFLEdBQUcxRSxLQUFLO0FBQzFCakIsb0NBQWM2QyxRQUFRLENBQUNyQyxTQUFTO0FBQzlCbUYsZ0NBQVFuRixLQUFLRyxHQUFHLElBQUk7QUFBQSwwQkFDbEJDLE1BQU07QUFBQSw0QkFDSixHQUFHK0UsUUFBUW5GLEtBQUtHLEdBQUcsR0FBR0M7QUFBQUEsNEJBQ3RCQyxRQUFRNkU7QUFBQUEsNEJBQ1J0RSxTQUFTWixLQUFLWTtBQUFBQSw0QkFDZEMsV0FBV2IsS0FBS2E7QUFBQUEsNEJBQ2hCQyxnQkFBZ0JkLEtBQUtjO0FBQUFBLDRCQUNyQnZCLFdBQVdTLEtBQUtUO0FBQUFBLDRCQUNoQndCLFVBQVVmLEtBQUtlO0FBQUFBLDRCQUNmQyxTQUFTaEIsS0FBS2dCO0FBQUFBLDRCQUNkQyxRQUFRakIsS0FBS2lCO0FBQUFBLDRCQUNiQyxZQUFZbEIsS0FBS2tCO0FBQUFBLDRCQUNqQkMsZ0JBQWdCbkIsS0FBS29CO0FBQUFBLDRCQUNyQkMsbUJBQW1CckIsS0FBS3FCO0FBQUFBLDRCQUN4QkMscUJBQXFCdEIsS0FBS3NCO0FBQUFBLDRCQUMxQkMsYUFBYXZCLEtBQUt3QjtBQUFBQSwwQkFDcEI7QUFBQSx3QkFDRjtBQUFBLHNCQUNGLENBQUM7QUFDRCw2QkFBTzJEO0FBQUFBLG9CQUNULENBQUM7QUFBQSxrQkFDSDtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQWpDWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQ2tCO0FBQUEsY0FFbEIsdUJBQUMsV0FBTSxXQUFVLHFDQUFvQywwQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0Q7QUFBQSxpQkFwQy9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUNsQjtBQUFBLGVBeERnQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBEQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTdEQ7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVEQ7QUFBQUEsdUNBQXVCLEtBQ3RCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPLGlDQUFpQ0Esb0JBQW9CO0FBQUEsb0JBRTVELGlDQUFDLFVBQU1BLGtDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRCO0FBQUE7QUFBQSxrQkFKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUYsdUJBQUMsY0FBVyxXQUFVLFFBQU8sTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBWjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNcEM7QUFBQUEsY0FDTixTQUFTbUY7QUFBQUEsY0FDVCxTQUFRO0FBQUEsY0FDUixpQkFBZ0I7QUFBQSxjQUNoQixpQkFBaUIsQ0FBQyxZQUFZO0FBQUEsY0FDOUIsbUJBQW1CLENBQUN6RyxXQUFXO0FBQUEsY0FDL0Isa0JBQWtCO0FBQUE7QUFBQSxZQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPbUQ7QUFBQSxhQXpHckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJHQTtBQUFBLFdBbEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvSEE7QUFBQSxTQTFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkhBO0FBQUEsT0FsSUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9JQSxLQXJJSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0lDO0FBRUo7QUFBRUwsR0F0WElELGdCQUFjO0FBQUEsVUFTZ0JMLGFBQWF5QixlQUFlO0FBQUE7QUFBQW9HLEtBVDFEeEg7QUF3WE4sZUFBZUE7QUFBZSxJQUFBd0g7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiU2VsZWN0IiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiRmFXaGF0c2FwcCIsIm5vdGlmaWNhdGlvbiIsIlNpZGViYXIiLCJGYVVzZXJzIiwiRmFDaGVja0NpcmNsZSIsIkJyZWFkY3J1bWIiLCJPdmVyRHVlTWVzc2FnZSIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ0b3RhbFVzZXJzIiwic2V0VG90YWxVc2VycyIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsImdyb3VwT3B0aW9ucyIsIlNldCIsIm1hcCIsInUiLCJncm91cE5hbWUiLCJmaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWQiLCJmaWx0ZXIiLCJtYXRjaEdyb3VwIiwiZW5yb2xsbWVudERhdGUiLCJEYXRlIiwibWF0Y2hGcm9tRGF0ZSIsIm1hdGNoVG9EYXRlIiwidXNlciIsImluZGV4IiwiaXNTZWxlY3RlZCIsIl9pZCIsImluZm8iLCJzdGF0dXMiLCJzbF9ubyIsImNoZWNrQm94cyIsImUiLCJwcmV2IiwidGFyZ2V0IiwiY2hlY2tlZCIsImJhbGFuY2UiLCJ1c2VyUGhvbmUiLCJwYXltZW50c1RpY2tldCIsInVzZXJOYW1lIiwiZ3JvdXBJZCIsInVzZXJJZCIsImFtb3VudFBhaWQiLCJhbW91bnRUb0JlUGFpZCIsInRvdGFsVG9CZVBhaWQiLCJsYXRlc3RQYXltZW50RGF0ZSIsImxhdGVzdFBheW1lbnRBbW91bnQiLCJwYXltZW50VHlwZSIsInBheW1lbnRfdHlwZSIsImxlbmd0aCIsImFsbFNlbGVjdGVkIiwiZXZlcnkiLCJ2aXNpYmxlU2VsZWN0ZWRDb3VudCIsInNlbmRXaGF0c2FwcCIsImtleSIsIm9wZW4iLCJtZXNzYWdlIiwiZGVzY3JpcHRpb24iLCJjbGFzc05hbWUiLCJkdXJhdGlvbiIsInZpc2libGVBY3RpdmVVc2VycyIsImZvckVhY2giLCJwb3N0IiwibmV3QWN0aXZlVXNlckRhdGEiLCJlcnIiLCJmZXRjaERhdGEiLCJyZXBvcnRSZXNwb25zZSIsImdldCIsInVzZXJzTGlzdCIsInRlbXBBY3RpdmUiLCJkYXRhIiwidXNyRGF0YSIsImVucm9sbG1lbnQiLCJncm91cCIsImdyb3VwSW5zdGFsbCIsInBhcnNlSW50IiwiZ3JvdXBfaW5zdGFsbCIsImdyb3VwVHlwZSIsImdyb3VwX3R5cGUiLCJ0b3RhbFBhaWRBbW91bnQiLCJwYXltZW50cyIsImF1Y3Rpb25Db3VudCIsImF1Y3Rpb24iLCJ0b3RhbFBheWFibGUiLCJwYXlhYmxlIiwidG90YWxQcm9maXQiLCJwcm9maXQiLCJmaXJzdERpdmlkZW50SGVhZCIsImZpcnN0QXVjdGlvbiIsImlkIiwicGhvbmVfbnVtYmVyIiwidGlja2V0IiwiZ3JvdXBfbmFtZSIsInRlbXBVc3IiLCJjdXN0b21lcklkIiwiY3VzdG9tZXJfaWQiLCJwdXNoIiwiZXJyb3IiLCJjb25zb2xlIiwiQXVjdGlvbmNvbHVtbnMiLCJoZWFkZXIiLCJyZW5kZXIiLCJ2YWx1ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIndpZHRoIiwidW5kZWZpbmVkIiwiaXNDaGVja2VkIiwidXBkYXRlZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk92ZXJEdWVNZXNzYWdlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBGYVVzZXJzLCBGYUNoZWNrQ2lyY2xlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcblxyXG5jb25zdCBPdmVyRHVlTWVzc2FnZSA9ICgpID0+IHtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG90YWxVc2Vycywgc2V0VG90YWxVc2Vyc10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gWy4uLm5ldyBTZXQodXNlcnNEYXRhLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpKV07XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkVXNlcnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGZpbHRlcmVkID0gZmlsdGVyT3B0aW9uKFxyXG4gICAgICB1c2Vyc0RhdGEuZmlsdGVyKCh1KSA9PiB7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hHcm91cCA9IGdyb3VwRmlsdGVyID8gdS5ncm91cE5hbWUgPT09IGdyb3VwRmlsdGVyIDogdHJ1ZTtcclxuICAgICAgICBjb25zdCBlbnJvbGxtZW50RGF0ZSA9IG5ldyBEYXRlKHUuZW5yb2xsbWVudERhdGUpO1xyXG4gICAgICAgIGNvbnN0IG1hdGNoRnJvbURhdGUgPSBmcm9tRGF0ZVxyXG4gICAgICAgICAgPyBlbnJvbGxtZW50RGF0ZSA+PSBuZXcgRGF0ZShmcm9tRGF0ZSlcclxuICAgICAgICAgIDogdHJ1ZTtcclxuICAgICAgICBjb25zdCBtYXRjaFRvRGF0ZSA9IHRvRGF0ZSA/IGVucm9sbG1lbnREYXRlIDw9IG5ldyBEYXRlKHRvRGF0ZSkgOiB0cnVlO1xyXG4gICAgICAgIHJldHVybiBtYXRjaEdyb3VwICYmIG1hdGNoRnJvbURhdGUgJiYgbWF0Y2hUb0RhdGU7XHJcbiAgICAgIH0pLFxyXG4gICAgICBzZWFyY2hUZXh0XHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBmaWx0ZXJlZC5tYXAoKHVzZXIsIGluZGV4KSA9PiB7XHJcbiAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSAhIWFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXT8uaW5mbz8uc3RhdHVzO1xyXG5cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi51c2VyLFxyXG4gICAgICAgIHNsX25vOiBpbmRleCArIDEsXHJcbiAgICAgICAgY2hlY2tCb3hzOiAoXHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgY2hlY2tlZD17aXNTZWxlY3RlZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgW3VzZXIuX2lkXToge1xyXG4gICAgICAgICAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhbGFuY2U6IHVzZXIuYmFsYW5jZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXIudXNlclBob25lLFxyXG4gICAgICAgICAgICAgICAgICAgIHBheW1lbnRzVGlja2V0OiB1c2VyLnBheW1lbnRzVGlja2V0LFxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBJZDogdXNlci5ncm91cElkLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJJZDogdXNlci51c2VySWQsXHJcbiAgICAgICAgICAgICAgICAgICAgYW1vdW50UGFpZDogdXNlci5hbW91bnRQYWlkLFxyXG4gICAgICAgICAgICAgICAgICAgIGFtb3VudFRvQmVQYWlkOiB1c2VyLnRvdGFsVG9CZVBhaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgbGF0ZXN0UGF5bWVudERhdGU6IHVzZXIubGF0ZXN0UGF5bWVudERhdGUsIC8vIOKchSBhZGRlZFxyXG4gICAgICAgICAgICAgICAgICAgIGxhdGVzdFBheW1lbnRBbW91bnQ6IHVzZXIubGF0ZXN0UGF5bWVudEFtb3VudCwgLy8g4pyFIGFkZGVkXHJcbiAgICAgICAgICAgICAgICAgICAgcGF5bWVudFR5cGU6IHVzZXIucGF5bWVudF90eXBlLCAvLyDinIUgYWRkZWRcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApLFxyXG4gICAgICAgIGlzU2VsZWN0ZWQsXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICB9LCBbdXNlcnNEYXRhLCBncm91cEZpbHRlciwgZnJvbURhdGUsIHRvRGF0ZSwgc2VhcmNoVGV4dCwgYWN0aXZlVXNlckRhdGFdKTtcclxudXNlRWZmZWN0KCgpID0+IHtcclxuICBpZiAoZmlsdGVyZWRVc2Vycy5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBhbGxTZWxlY3RlZCA9IGZpbHRlcmVkVXNlcnMuZXZlcnkoKHVzZXIpID0+IHVzZXIuaXNTZWxlY3RlZCk7XHJcbiAgICBzZXRTZWxlY3RBbGwoYWxsU2VsZWN0ZWQpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gIH1cclxufSwgW2ZpbHRlcmVkVXNlcnNdKTtcclxuICBjb25zdCB2aXNpYmxlU2VsZWN0ZWRDb3VudCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGZpbHRlcmVkVXNlcnMuZmlsdGVyKCh1c2VyKSA9PiB1c2VyLmlzU2VsZWN0ZWQpLmxlbmd0aDtcclxuICB9LCBbZmlsdGVyZWRVc2Vyc10pO1xyXG5cclxuICBjb25zdCBzZW5kV2hhdHNhcHAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBrZXkgPSBcInVwZGF0YWJsZVwiO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU2VuZGluZyBNZXNzYWdlcyBWaWEgV2hhdHNhcHAuLlwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2Nlc3NpbmcuLi5cIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgdmlzaWJsZUFjdGl2ZVVzZXJzID0ge307XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQgJiYgYWN0aXZlVXNlckRhdGFbdXNlci5faWRdKSB7XHJcbiAgICAgICAgICB2aXNpYmxlQWN0aXZlVXNlcnNbdXNlci5faWRdID0gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi93aGF0c2FwcC9vdmVyLWR1ZS1tZXNzYWdlXCIsIHZpc2libGVBY3RpdmVVc2Vycyk7XHJcblxyXG4gICAgICBjb25zdCBuZXdBY3RpdmVVc2VyRGF0YSA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCkge1xyXG4gICAgICAgICAgZGVsZXRlIG5ld0FjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBY3RpdmVVc2VyRGF0YShuZXdBY3RpdmVVc2VyRGF0YSk7XHJcblxyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJXaGF0c2FwcCBNZXNzYWdlcyBIYXMgQmVlbiBTZW50IFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlN1Y2Nlc3NcIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBTZW5kIFdoYXRzYXBwXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGVyci5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlcG9ydFJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC1vdmVyZHVlLXBheW1lbnRzXCIpO1xyXG4gICAgICBjb25zdCB1c2Vyc0xpc3QgPSBbXTtcclxuICAgICAgY29uc3QgdGVtcEFjdGl2ZSA9IHt9O1xyXG5cclxuICAgICAgcmVwb3J0UmVzcG9uc2UuZGF0YS5mb3JFYWNoKCh1c3JEYXRhKSA9PiB7XHJcbiAgICAgICAgaWYgKHVzckRhdGE/LmRhdGEpIHtcclxuICAgICAgICAgIHVzckRhdGEuZGF0YS5mb3JFYWNoKChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChkYXRhPy5lbnJvbGxtZW50Py5ncm91cCkge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGdyb3VwSW5zdGFsbCA9IHBhcnNlSW50KFxyXG4gICAgICAgICAgICAgICAgZGF0YS5lbnJvbGxtZW50Lmdyb3VwLmdyb3VwX2luc3RhbGxcclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGdyb3VwSWQgPSBkYXRhLmVucm9sbG1lbnQuZ3JvdXAuX2lkO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGdyb3VwVHlwZSA9IGRhdGEuZW5yb2xsbWVudC5ncm91cC5ncm91cF90eXBlO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHRvdGFsUGFpZEFtb3VudCA9IGRhdGEucGF5bWVudHMudG90YWxQYWlkQW1vdW50O1xyXG4gICAgICAgICAgICAgIGNvbnN0IGF1Y3Rpb25Db3VudCA9IHBhcnNlSW50KGRhdGE/LmF1Y3Rpb24/LmF1Y3Rpb25Db3VudCk7XHJcbiAgICAgICAgICAgICAgY29uc3QgdG90YWxQYXlhYmxlID0gZGF0YS5wYXlhYmxlLnRvdGFsUGF5YWJsZTtcclxuICAgICAgICAgICAgICBjb25zdCB0b3RhbFByb2ZpdCA9IGRhdGEucHJvZml0LnRvdGFsUHJvZml0O1xyXG4gICAgICAgICAgICAgIGNvbnN0IGZpcnN0RGl2aWRlbnRIZWFkID0gZGF0YS5maXJzdEF1Y3Rpb24uZmlyc3REaXZpZGVudEhlYWQ7XHJcbiAgICAgICAgICAgICAgY29uc3QgaWQgPSBkYXRhPy5lbnJvbGxtZW50Py5faWQ7XHJcbiAgICAgICAgICAgICAgY29uc3QgdXNlclBob25lID0gdXNyRGF0YS5waG9uZV9udW1iZXI7XHJcbiAgICAgICAgICAgICAgY29uc3QgcGF5bWVudHNUaWNrZXQgPSBkYXRhLnBheW1lbnRzLnRpY2tldDtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cE5hbWUgPSBkYXRhLmVucm9sbG1lbnQuZ3JvdXAuZ3JvdXBfbmFtZTtcclxuXHJcbiAgICAgICAgICAgICAgLy8gIENIQU5HRSAxOiBIYW5kbGUgYW1vdW50VG9CZVBhaWQgYW5kIHRvdGFsVG9CZVBhaWQgY29uc2lzdGVudGx5XHJcbiAgICAgICAgICAgICAgY29uc3QgdG90YWxUb0JlUGFpZCA9XHJcbiAgICAgICAgICAgICAgICBncm91cFR5cGUgPT09IFwiZG91YmxlXCJcclxuICAgICAgICAgICAgICAgICAgPyBncm91cEluc3RhbGwgKiBhdWN0aW9uQ291bnQgKyBncm91cEluc3RhbGxcclxuICAgICAgICAgICAgICAgICAgOiB0b3RhbFBheWFibGUgKyBncm91cEluc3RhbGwgKyB0b3RhbFByb2ZpdDtcclxuICAgICAgICAgICAgICBjb25zdCBhbW91bnRUb0JlUGFpZCA9IHRvdGFsVG9CZVBhaWQ7XHJcblxyXG4gICAgICAgICAgICAgIGNvbnN0IGJhbGFuY2UgPVxyXG4gICAgICAgICAgICAgICAgZ3JvdXBUeXBlID09PSBcImRvdWJsZVwiXHJcbiAgICAgICAgICAgICAgICAgID8gdG90YWxUb0JlUGFpZCAtIHRvdGFsUGFpZEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICA6IHRvdGFsUGF5YWJsZSArXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBJbnN0YWxsICtcclxuICAgICAgICAgICAgICAgICAgICBmaXJzdERpdmlkZW50SGVhZCAtXHJcbiAgICAgICAgICAgICAgICAgICAgdG90YWxQYWlkQW1vdW50O1xyXG5cclxuICAgICAgICAgICAgICBpZiAoYmFsYW5jZSA8PSAwKSByZXR1cm47XHJcblxyXG4gICAgICAgICAgICAgIGNvbnN0IHVzZXJOYW1lID0gdXNyRGF0YS51c2VyTmFtZTtcclxuXHJcbiAgICAgICAgICAgICAgLy8gIENIQU5HRSAyOiBOZXcgZmllbGRzIGZyb20gbGF0ZXN0UGF5bWVudCBpbmZvXHJcbiAgICAgICAgICAgICAgY29uc3QgbGF0ZXN0UGF5bWVudEFtb3VudCA9IGRhdGEubGF0ZXN0UGF5bWVudEFtb3VudCB8fCAwOyAvLyDirIUgQWRkZWQgZm9yIGNsYXJpdHlcclxuICAgICAgICAgICAgICBjb25zdCBsYXRlc3RQYXltZW50RGF0ZSA9IGRhdGEubGF0ZXN0UGF5bWVudERhdGUgfHwgXCJcIjsgLy8g4qyFIEFkZGVkIGZvciBjbGFyaXR5XHJcblxyXG4gICAgICAgICAgICAgIHRlbXBBY3RpdmVbaWRdID0ge1xyXG4gICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICBiYWxhbmNlLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICBjb25zdCB0ZW1wVXNyID0ge1xyXG4gICAgICAgICAgICAgICAgX2lkOiBpZCxcclxuICAgICAgICAgICAgICAgIHVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgdXNlclBob25lLFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXJJZDogdXNyRGF0YS5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgIGFtb3VudFBhaWQ6IHRvdGFsUGFpZEFtb3VudCxcclxuICAgICAgICAgICAgICAgIHBheW1lbnRzVGlja2V0LFxyXG4gICAgICAgICAgICAgICAgYW1vdW50VG9CZVBhaWQsXHJcbiAgICAgICAgICAgICAgICBncm91cE5hbWUsXHJcbiAgICAgICAgICAgICAgICBwYXltZW50X3R5cGU6IGRhdGE/LmVucm9sbG1lbnQ/LnBheW1lbnRfdHlwZSxcclxuICAgICAgICAgICAgICAgIHRvdGFsVG9CZVBhaWQsXHJcbiAgICAgICAgICAgICAgICBiYWxhbmNlLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXBJZDogZ3JvdXBJZCxcclxuICAgICAgICAgICAgICAgIHVzZXJJZDogdXNyRGF0YT8uX2lkLFxyXG4gICAgICAgICAgICAgICAgbGF0ZXN0UGF5bWVudEFtb3VudCwgLy8g4qyFIE5ldyBmaWVsZFxyXG4gICAgICAgICAgICAgICAgbGF0ZXN0UGF5bWVudERhdGUsIC8vIOKshSBOZXcgZmllbGRcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgIHVzZXJzTGlzdC5wdXNoKHRlbXBVc3IpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0VXNlcnNEYXRhKHVzZXJzTGlzdCk7XHJcbiAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHRlbXBBY3RpdmUpOyAvLyDinIUgTWF0Y2ggc3RydWN0dXJlIGZyb20gc2Vjb25kIHNuaXBwZXRcclxuICAgICAgc2V0VG90YWxVc2Vycyh1c2Vyc0xpc3QubGVuZ3RoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaERhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IEF1Y3Rpb25jb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyUGhvbmVcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcklkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudF90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudHNUaWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbFRvQmVQYWlkXCIsIGhlYWRlcjogXCJBbW91bnQgUGF5YWJsZVwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRQYWlkXCIsIGhlYWRlcjogXCJQYWlkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJsYXRlc3RQYXltZW50QW1vdW50XCIsIGhlYWRlcjogXCJMYXN0IFBheW1lbnQgQW1vdW50XCIgfSwgLy8g4pyFIE5FV1xyXG4gICAge1xyXG4gICAgICBrZXk6IFwibGF0ZXN0UGF5bWVudERhdGVcIixcclxuICAgICAgaGVhZGVyOiBcIkxhc3QgUGF5bWVudCBEYXRlXCIsXHJcbiAgICAgIHJlbmRlcjogKHZhbHVlKSA9PlxyXG4gICAgICAgIHZhbHVlID8gbmV3IERhdGUodmFsdWUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIpIDogXCJOL0FcIiwgLy8g4pyFIE5FV1xyXG4gICAgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiY2hlY2tCb3hzXCIsIGhlYWRlcjogXCJTZWxlY3QgVXNlclwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIvPlxyXG4gICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgV2hhdHNhcHAgT3V0c3RhbmRpbmcgW092ZXIgRHVlXSBNZXNzYWdlc1xyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1zdGFydCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgbWItNFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGNvbG9yPVwidGV4dC1ncmVlbi02MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTYgbXQtOCBtYi02XCI+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtMTAwIHJvdW5kZWQteGwgcC02IHNoYWRvdyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlRvdGFsIEN1c3RvbWVyczwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4gICAgICAgIHtmaWx0ZXJlZFVzZXJzLmxlbmd0aH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFVc2VycyBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgdGV4dC00eGxcIiAvPlxyXG4gIDwvZGl2PlxyXG5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5TZWxlY3RlZCBDdXN0b21lcnM8L3A+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgIHt2aXNpYmxlU2VsZWN0ZWRDb3VudH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB0ZXh0LTR4bFwiIC8+XHJcbiAgPC9kaXY+XHJcbjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXAgRmlsdGVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tQWxsIGdyb3Vwcy0tXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEdyb3VwRmlsdGVyKHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cEZpbHRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXB9IHZhbHVlPXtncm91cH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbXQtNlwiPlxyXG4gIDxpbnB1dFxyXG4gICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgIGNoZWNrZWQ9e3NlbGVjdEFsbH1cclxuICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICBjb25zdCBpc0NoZWNrZWQgPSBlLnRhcmdldC5jaGVja2VkO1xyXG4gICAgICBzZXRTZWxlY3RBbGwoaXNDaGVja2VkKTtcclxuXHJcbiAgICAgIC8vIFVwZGF0ZSBhbGwgZmlsdGVyZWQgdXNlcnNcclxuICAgICAgc2V0QWN0aXZlVXNlckRhdGEoKHByZXYpID0+IHtcclxuICAgICAgICBjb25zdCB1cGRhdGVkID0geyAuLi5wcmV2IH07XHJcbiAgICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgICB1cGRhdGVkW3VzZXIuX2lkXSA9IHtcclxuICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgIC4uLnVwZGF0ZWRbdXNlci5faWRdPy5pbmZvLFxyXG4gICAgICAgICAgICAgIHN0YXR1czogaXNDaGVja2VkLFxyXG4gICAgICAgICAgICAgIGJhbGFuY2U6IHVzZXIuYmFsYW5jZSxcclxuICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXIudXNlclBob25lLFxyXG4gICAgICAgICAgICAgIHBheW1lbnRzVGlja2V0OiB1c2VyLnBheW1lbnRzVGlja2V0LFxyXG4gICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbiAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgZ3JvdXBJZDogdXNlci5ncm91cElkLFxyXG4gICAgICAgICAgICAgIHVzZXJJZDogdXNlci51c2VySWQsXHJcbiAgICAgICAgICAgICAgYW1vdW50UGFpZDogdXNlci5hbW91bnRQYWlkLFxyXG4gICAgICAgICAgICAgIGFtb3VudFRvQmVQYWlkOiB1c2VyLnRvdGFsVG9CZVBhaWQsXHJcbiAgICAgICAgICAgICAgbGF0ZXN0UGF5bWVudERhdGU6IHVzZXIubGF0ZXN0UGF5bWVudERhdGUsXHJcbiAgICAgICAgICAgICAgbGF0ZXN0UGF5bWVudEFtb3VudDogdXNlci5sYXRlc3RQYXltZW50QW1vdW50LFxyXG4gICAgICAgICAgICAgIHBheW1lbnRUeXBlOiB1c2VyLnBheW1lbnRfdHlwZSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWQ7XHJcbiAgICAgIH0pO1xyXG4gICAgfX1cclxuICAgIGNsYXNzTmFtZT1cIm1yLTJcIlxyXG4gIC8+XHJcbiAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlNlbGVjdCBBbGw8L2xhYmVsPlxyXG48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZW5kV2hhdHNhcHB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNiBoLTYgYWJzb2x1dGUgLXJpZ2h0LTMgLXRvcC0yIHNoYWRvdy1sZyBob3ZlcjpiZy1yZWQtNjAwIGJnLXJlZC00MDAgcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHt2aXNpYmxlU2VsZWN0ZWRDb3VudH0gY3VzdG9tZXJzYH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Zpc2libGVTZWxlY3RlZENvdW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwibXItMlwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFdoYXRzQXBwXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e0F1Y3Rpb25jb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiT3ZlcmR1ZSBXaGF0c2FwcCBNZXNzYWdlXCJcclxuICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXCJHcm91cCBOYW1lXCJdfVxyXG4gICAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W2dyb3VwRmlsdGVyXX1cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YE92ZXJkdWUgV2hhdHNhcHAgTWVzc2FnZS5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgIFxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBPdmVyRHVlTWVzc2FnZTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL092ZXJEdWVNZXNzYWdlLmpzeCJ9