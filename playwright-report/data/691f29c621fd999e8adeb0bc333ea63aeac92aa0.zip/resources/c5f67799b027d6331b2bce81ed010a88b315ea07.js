import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/loaders/CircularLoader.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import noDataFoundImage from "/src/assets/images/noDataFound.svg?import";
const CircularLoader = ({
  color = "text-violet-600",
  isLoading = true,
  failure = false,
  data = "data"
}) => {
  if (isLoading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center ", children: /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `animate-spin inline-block w-12 h-12 border-4 border-current border-t-transparent ${color} rounded-full`
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx",
        lineNumber: 13,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx",
      lineNumber: 12,
      columnNumber: 7
    }, this);
  }
  if (failure) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center ", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full h-screen flex justify-center ", children: /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV(
        "img",
        {
          src: noDataFoundImage,
          alt: "No Data Found image",
          className: "w-3/4 h-1/2"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx",
          lineNumber: 25,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center text-2xl font-bold text-violet-700", children: [
        "No ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-violet-800", children: data }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx",
          lineNumber: 31,
          columnNumber: 18
        }, this),
        " Found"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx",
        lineNumber: 30,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx",
      lineNumber: 24,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx",
      lineNumber: 23,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this);
  }
};
_c = CircularLoader;
export default CircularLoader;
var _c;
$RefreshReg$(_c, "CircularLoader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/CircularLoader.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYUixPQUFPQSxzQkFBc0I7QUFDN0IsTUFBTUMsaUJBQWlCQSxDQUFDO0FBQUEsRUFDdEJDLFFBQVE7QUFBQSxFQUNSQyxZQUFXO0FBQUEsRUFDWEMsVUFBVTtBQUFBLEVBQ1ZDLE9BQUs7QUFDUCxNQUFNO0FBQ0osTUFBSUYsV0FBWTtBQUVkLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXLG9GQUFvRkQsS0FBSztBQUFBO0FBQUEsTUFEdEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRUMsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxFQUVKO0FBQ0EsTUFBSUUsU0FBVztBQUViLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHFDQUNiLGlDQUFDLFNBQUksV0FBVSx3Q0FDYixpQ0FBQyxTQUNDO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLEtBQUtKO0FBQUFBLFVBQ0wsS0FBSTtBQUFBLFVBQ0osV0FBVTtBQUFBO0FBQUEsUUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHeUI7QUFBQSxNQUV6Qix1QkFBQyxTQUFJLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxRQUMzRCx1QkFBQyxVQUFLLFdBQVUsbUJBQ2xCSyxrQkFERTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUQ7QUFBQSxRQUFPO0FBQUEsV0FIWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLEVBRUo7QUFDRjtBQUFFQyxLQXJDSUw7QUF1Q04sZUFBZUE7QUFBZSxJQUFBSztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsibm9EYXRhRm91bmRJbWFnZSIsIkNpcmN1bGFyTG9hZGVyIiwiY29sb3IiLCJpc0xvYWRpbmciLCJmYWlsdXJlIiwiZGF0YSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNpcmN1bGFyTG9hZGVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IG5vRGF0YUZvdW5kSW1hZ2UgZnJvbSBcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvbm9EYXRhRm91bmQuc3ZnXCI7XHJcbmNvbnN0IENpcmN1bGFyTG9hZGVyID0gKHtcclxuICBjb2xvciA9IFwidGV4dC12aW9sZXQtNjAwXCIsXHJcbiAgaXNMb2FkaW5nID10cnVlLFxyXG4gIGZhaWx1cmUgPSBmYWxzZSxcclxuICBkYXRhPVwiZGF0YVwiXHJcbn0pID0+IHtcclxuICBpZiAoaXNMb2FkaW5nICkge1xyXG4gICAgLy8gJiYgIWZhaWx1cmVcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgXCI+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgYW5pbWF0ZS1zcGluIGlubGluZS1ibG9jayB3LTEyIGgtMTIgYm9yZGVyLTQgYm9yZGVyLWN1cnJlbnQgYm9yZGVyLXQtdHJhbnNwYXJlbnQgJHtjb2xvcn0gcm91bmRlZC1mdWxsYH1cclxuICAgICAgICA+PC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcbiAgaWYgKGZhaWx1cmUgICkge1xyXG4gICBcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1zY3JlZW4gZmxleCBqdXN0aWZ5LWNlbnRlciBcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9e25vRGF0YUZvdW5kSW1hZ2V9XHJcbiAgICAgICAgICAgICAgYWx0PVwiTm8gRGF0YSBGb3VuZCBpbWFnZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zLzQgaC0xLzJcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC03MDBcIj5cclxuICAgICAgICAgICAgICBObyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC04MDBcIj5cclxuICAgICAgICAgICAgICB7ZGF0YX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj4gRm91bmRcclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENpcmN1bGFyTG9hZGVyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyLmpzeCJ9