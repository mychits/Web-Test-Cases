import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/loaders/BackdropBlurLoader.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/BackdropBlurLoader.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const BackdropBlurLoader = ({ title }) => {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed  w-screen h-screen  z-50 flex items-center justify-center\r\n                 bg-black bg-opacity-25 backdrop-blur-sm",
      children: /* @__PURE__ */ jsxDEV(Spin, { tip: `Please wait...`, children: title }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/BackdropBlurLoader.jsx",
        lineNumber: 12,
        columnNumber: 8
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/BackdropBlurLoader.jsx",
      lineNumber: 6,
      columnNumber: 5
    },
    this
  );
};
_c = BackdropBlurLoader;
export default BackdropBlurLoader;
var _c;
$RefreshReg$(_c, "BackdropBlurLoader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/BackdropBlurLoader.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/loaders/BackdropBlurLoader.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV087QUFYUCwyQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDMUIsTUFBTUEscUJBQXFCQSxDQUFDLEVBQUNDLE1BQUssTUFBTTtBQUd0QyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFFQyxXQUFVO0FBQUEsTUFJVCxpQ0FBQyxRQUFLLEtBQUssa0JBQW1CQSxtQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBO0FBQUEsSUFOdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0E7QUFFSjtBQUFFQyxLQWJJRjtBQWVOLGVBQWVBO0FBQW1CLElBQUFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJCYWNrZHJvcEJsdXJMb2FkZXIiLCJ0aXRsZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJhY2tkcm9wQmx1ckxvYWRlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtTcGluIH0gZnJvbSBcImFudGRcIlxyXG5jb25zdCBCYWNrZHJvcEJsdXJMb2FkZXIgPSAoe3RpdGxlfSkgPT4ge1xyXG4gIFxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBcclxuICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgIHctc2NyZWVuIGgtc2NyZWVuICB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXHJcbiAgICAgICAgICAgICAgICAgYmctYmxhY2sgYmctb3BhY2l0eS0yNSBiYWNrZHJvcC1ibHVyLXNtXCJcclxuICAgID5cclxuICAgICBcclxuICAgICAgIDxTcGluIHRpcD17YFBsZWFzZSB3YWl0Li4uYH0+e3RpdGxlfTwvU3Bpbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCYWNrZHJvcEJsdXJMb2FkZXI7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL2NvbXBvbmVudHMvbG9hZGVycy9CYWNrZHJvcEJsdXJMb2FkZXIuanN4In0=