import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PigmySummaryReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import {
  Search,
  PiggyBank,
  Users,
  Calendar,
  TrendingUp,
  Clock
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { DatePicker } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import __vite__cjsImport6_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport6_dayjs.__esModule ? __vite__cjsImport6_dayjs.default : __vite__cjsImport6_dayjs;
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const { RangePicker } = DatePicker;
const PigmySummaryReport = () => {
  _s();
  const [pigmyReportTable, setPigmyReportTable] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPigmyId, setSelectedPigmyId] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [selectedReferredBy, setSelectedReferredBy] = useState("");
  const [dateRange, setDateRange] = useState(null);
  const uniqueReferredBy = useMemo(() => {
    const setRef = /* @__PURE__ */ new Set();
    pigmyReportTable.forEach((p) => {
      if (p.referredBy && p.referredBy !== "N/A") {
        setRef.add(p.referredBy);
      }
    });
    return Array.from(setRef).map((name) => ({
      id: name,
      label: name
    }));
  }, [pigmyReportTable]);
  useEffect(() => {
    const fetchPigmyReport = async () => {
      try {
        const response = await api.get(`/payment/pigme/customers`);
        const formattedData = response.data.data.map((pigmy, index) => ({
          id: pigmy?._id,
          slNo: index + 1,
          pigmyIds: pigmy?.pigme_id || "N/A",
          Duration: pigmy?.duration || "N/A",
          amount: pigmy?.payable_amount || "N/A",
          referredType: pigmy?.referred_type || "N/A",
          referredBy: pigmy?.referred_employee ? pigmy?.referred_employee?.name : pigmy?.referred_agent ? pigmy?.referred_agent : pigmy?.referred_customer ? pigmy?.referred_customer?.full_name : "N/A",
          customerId: pigmy?.customer?.customer_id || "N/A",
          customerName: pigmy?.customer?.full_name || "N/A",
          customerPhone: pigmy?.customer?.phone_number || "N/A",
          pigmyStartDate: pigmy?.start_date ? new Date(pigmy.start_date).toLocaleDateString("en-GB") : "N/A",
          // Store the original date for filtering
          pigmyStartDateObj: pigmy?.start_date ? new Date(pigmy.start_date) : null,
          totalpigmyAmount: pigmy?.total_paid_amount ?? 0
        }));
        setPigmyReportTable(formattedData);
      } catch (error) {
        console.error("Error fetching Pigmy report:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchPigmyReport();
  }, []);
  const uniquePigmyCombos = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    pigmyReportTable.forEach((pigmy) => {
      const key = pigmy.pigmyIds;
      if (!map.has(key)) {
        map.set(key, { id: key, label: `${key}` });
      }
    });
    return Array.from(map.values());
  }, [pigmyReportTable]);
  const uniqueCustomers = useMemo(
    () => pigmyReportTable.map((pigmy) => ({
      id: pigmy?.id,
      name: pigmy?.customerName,
      phone: pigmy?.customerPhone,
      custid: pigmy?.customerId
    })),
    [pigmyReportTable]
  );
  const filteredPigmyReport = useMemo(() => {
    return pigmyReportTable.filter((pigmy) => {
      const matchPigmyId = selectedPigmyId ? pigmy.pigmyIds === selectedPigmyId : true;
      const matchCustomer = selectedCustomer ? pigmy.id === selectedCustomer : true;
      const matchReferredBy = selectedReferredBy ? pigmy.referredBy === selectedReferredBy : true;
      let matchDateRange = true;
      if (dateRange && dateRange.length === 2 && pigmy.pigmyStartDateObj) {
        const startDate = dayjs(dateRange[0]).startOf("day");
        const endDate = dayjs(dateRange[1]).endOf("day");
        const pigmyDate = dayjs(pigmy.pigmyStartDateObj);
        matchDateRange = pigmyDate.isAfter(startDate) && pigmyDate.isBefore(endDate);
      }
      return matchPigmyId && matchCustomer && matchReferredBy && matchDateRange;
    });
  }, [pigmyReportTable, selectedPigmyId, selectedCustomer, selectedReferredBy, dateRange]);
  const summaryStats = useMemo(() => {
    const filtered = filteredPigmyReport;
    const totalAmount = filtered.reduce(
      (sum, pigmy) => sum + pigmy.totalpigmyAmount,
      0
    );
    const totalPayablePigmy = filtered.reduce(
      (sum, pigmy) => sum + Number(pigmy?.amount || 0),
      0
    );
    const avgDuration = filtered.length > 0 ? filtered.reduce((sum, pigmy) => {
      const dur = pigmy.Duration !== "N/A" ? Number(pigmy.Duration) : 0;
      return sum + dur;
    }, 0) / filtered.length : 0;
    return {
      totalPigmy: filtered.length,
      totalAmount,
      totalPayable: totalPayablePigmy,
      avgDuration: avgDuration.toFixed(1),
      uniqueCustomers: new Set(filtered.map((p) => p.customerId)).size
    };
  }, [filteredPigmyReport]);
  const PigmyReportColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "customerId", header: "Customer Id" },
    { key: "customerName", header: "Customer Name" },
    { key: "customerPhone", header: "Phone Number" },
    { key: "pigmyIds", header: "Pigmy ID" },
    { key: "pigmyStartDate", header: "Start Date" },
    { key: "Duration", header: "Duration (months)" },
    { key: "amount", header: "Daily Pay" },
    { key: "totalpigmyAmount", header: "Amount Paid" },
    { key: "referredType", header: "Referred Type" },
    { key: "referredBy", header: "Referred By" }
  ];
  const StatCard = ({ icon: Icon, label, value, color, suffix = "" }) => /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-600 mb-1", children: label }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
        lineNumber: 177,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: [
        value,
        suffix && /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-normal text-gray-500 ml-1", children: suffix }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 181,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
        lineNumber: 178,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
      lineNumber: 176,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `p-3 rounded-lg ${color}`, children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-6 h-6 text-white" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
      lineNumber: 188,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
      lineNumber: 187,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
    lineNumber: 175,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
    lineNumber: 174,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-pink-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(PiggyBank, { className: "w-6 h-6 text-white" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 201,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 200,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-900", children: "Pigmy Summary Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 203,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
        lineNumber: 199,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 ml-14", children: "Comprehensive overview of pigmy savings accounts and customer contributions" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
        lineNumber: 207,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
      lineNumber: 198,
      columnNumber: 9
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-96", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
      lineNumber: 215,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
      lineNumber: 214,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: PiggyBank,
              label: "Total Pigmy Accounts",
              value: summaryStats.totalPigmy,
              color: "bg-gradient-to-br from-pink-500 to-pink-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 223,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words pl-3", children: numberToIndianWords(summaryStats.totalPigmy || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 229,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 222,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: TrendingUp,
              label: "Total Amount Collected",
              value: `₹${summaryStats.totalAmount?.toLocaleString("en-IN") || 0}`,
              color: "bg-gradient-to-br from-green-500 to-green-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 235,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words pl-3", children: numberToIndianWords(summaryStats.totalAmount || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 241,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 234,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: TrendingUp,
              label: "Total Payable",
              value: `₹${summaryStats.totalPayable?.toLocaleString("en-IN") || 0}`,
              color: "bg-gradient-to-br from-orange-500 to-orange-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 247,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words pl-3", children: numberToIndianWords(summaryStats.totalPayable || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 253,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 246,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: Clock,
              label: "Average Duration",
              value: summaryStats.avgDuration,
              suffix: "months",
              color: "bg-gradient-to-br from-violet-500 to-violet-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 259,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words pl-3", children: numberToIndianWords(summaryStats.avgDuration || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 266,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 258,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: Users,
              label: "Unique Customers",
              value: summaryStats.uniqueCustomers,
              color: "bg-gradient-to-br from-purple-500 to-purple-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 272,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words pl-3", children: numberToIndianWords(summaryStats.uniqueCustomers || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 278,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 271,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
        lineNumber: 220,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "w-5 h-5 text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 289,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-900", children: "Filter Options" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 290,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 288,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(PiggyBank, { className: "w-4 h-4" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                lineNumber: 300,
                columnNumber: 23
              }, this),
              "Pigmy ID"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 299,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 298,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Search or select pigmy account",
                value: selectedPigmyId,
                onChange: setSelectedPigmyId,
                allowClear: true,
                filterOption: (input, option) => option.label.toLowerCase().includes(input.toLowerCase()),
                optionLabelProp: "label",
                className: "w-full",
                size: "large",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", label: "All Pigmy Accounts", children: "All Pigmy Accounts" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                    lineNumber: 317,
                    columnNumber: 21
                  }, this),
                  uniquePigmyCombos.map(
                    (pigmy) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: pigmy?.id,
                        label: pigmy?.label,
                        children: pigmy?.label
                      },
                      pigmy?.id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                        lineNumber: 321,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                lineNumber: 304,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 297,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(Users, { className: "w-4 h-4" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                lineNumber: 336,
                columnNumber: 23
              }, this),
              "Customer"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 335,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 334,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Search or select customer",
                value: selectedCustomer,
                onChange: setSelectedCustomer,
                allowClear: true,
                optionLabelProp: "label",
                className: "w-full",
                size: "large",
                filterOption: (input, option) => option.label.toLowerCase().includes(input.toLowerCase()),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", label: "All Customers", children: "All Customers" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                    lineNumber: 353,
                    columnNumber: 21
                  }, this),
                  uniqueCustomers.map(
                    (cust) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: cust?.id,
                        label: `${cust?.custid} | ${cust?.name} | ${cust?.phone}`,
                        children: [
                          cust?.custid,
                          " | ",
                          cust?.name,
                          " | ",
                          cust?.phone
                        ]
                      },
                      cust?.id,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                        lineNumber: 357,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                lineNumber: 340,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 333,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(Users, { className: "w-4 h-4" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                lineNumber: 372,
                columnNumber: 23
              }, this),
              "Referred By"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 371,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 370,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Search or select referred by",
                value: selectedReferredBy,
                onChange: setSelectedReferredBy,
                allowClear: true,
                optionLabelProp: "label",
                className: "w-full",
                size: "large",
                filterOption: (input, option) => option.label.toLowerCase().includes(input.toLowerCase()),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", label: "All Referred By", children: "All Referred By" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                    lineNumber: 390,
                    columnNumber: 21
                  }, this),
                  uniqueReferredBy.map(
                    (ref) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: ref.id,
                        label: ref.label,
                        children: ref.label
                      },
                      ref.id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                        lineNumber: 395,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                lineNumber: 377,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 369,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                lineNumber: 410,
                columnNumber: 23
              }, this),
              "Start Date Range"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 409,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
              lineNumber: 408,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              RangePicker,
              {
                value: dateRange,
                onChange: setDateRange,
                className: "w-full",
                size: "large",
                format: "DD/MM/YYYY"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
                lineNumber: 414,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
            lineNumber: 407,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 295,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
        lineNumber: 287,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns: PigmyReportColumns,
          data: filteredPigmyReport,
          printHeaderKeys: [
            "Total Pigmy",
            "Total Pigmy Amount",
            "Total Payable",
            "Average Duration",
            "Unique Customers"
          ],
          printHeaderValues: [
            summaryStats.totalPigmy,
            `₹ ${summaryStats.totalAmount}`,
            `₹ ${summaryStats.totalPayable}`,
            `₹ ${summaryStats.avgDuration}`,
            `₹ ${summaryStats.uniqueCustomers}`
          ],
          exportedPdfName: "Pigmy Summary Report",
          exportedFileName: "Pigmy Summary Report.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
          lineNumber: 426,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
        lineNumber: 425,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
      lineNumber: 218,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
    lineNumber: 196,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx",
    lineNumber: 195,
    columnNumber: 5
  }, this);
};
_s(PigmySummaryReport, "YfNfKxf639AUU/JllgLj2Ob+Slc=");
_c = PigmySummaryReport;
export default PigmySummaryReport;
var _c;
$RefreshReg$(_c, "PigmySummaryReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmySummaryReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0xVLFNBeUNBLFVBekNBOzJCQWhMVjtBQUFvQkEsb0JBQWlCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDcEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0Msa0JBQWtCO0FBQzNCLE9BQU9DLFdBQVc7QUFFbEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLDJCQUEyQjtBQUVwQyxNQUFNLEVBQUVDLFlBQVksSUFBSVA7QUFFeEIsTUFBTVEscUJBQXFCQSxNQUFNO0FBQUFDLEtBQUE7QUFDL0IsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJbEIsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQ21CLFNBQVNDLFVBQVUsSUFBSXBCLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNxQixpQkFBaUJDLGtCQUFrQixJQUFJdEIsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ3VCLGtCQUFrQkMsbUJBQW1CLElBQUl4QixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDeUIsb0JBQW9CQyxxQkFBcUIsSUFBSTFCLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUMyQixXQUFXQyxZQUFZLElBQUk1QixTQUFTLElBQUk7QUFFL0MsUUFBTTZCLG1CQUFtQkMsUUFBUSxNQUFNO0FBQ3JDLFVBQU1DLFNBQVMsb0JBQUlDLElBQUk7QUFDdkJmLHFCQUFpQmdCLFFBQVEsQ0FBQ0MsTUFBTTtBQUM5QixVQUFJQSxFQUFFQyxjQUFjRCxFQUFFQyxlQUFlLE9BQU87QUFDMUNKLGVBQU9LLElBQUlGLEVBQUVDLFVBQVU7QUFBQSxNQUN6QjtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU9FLE1BQU1DLEtBQUtQLE1BQU0sRUFBRVEsSUFBSSxDQUFDQyxVQUFVO0FBQUEsTUFDdkNDLElBQUlEO0FBQUFBLE1BQ0pFLE9BQU9GO0FBQUFBLElBQ1QsRUFBRTtBQUFBLEVBQ0osR0FBRyxDQUFDdkIsZ0JBQWdCLENBQUM7QUFFckIwQixZQUFVLE1BQU07QUFDZCxVQUFNQyxtQkFBbUIsWUFBWTtBQUNuQyxVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNcEMsSUFBSXFDLElBQUksMEJBQTBCO0FBRXpELGNBQU1DLGdCQUFnQkYsU0FBU0csS0FBS0EsS0FBS1QsSUFBSSxDQUFDVSxPQUFPQyxXQUFXO0FBQUEsVUFDOURULElBQUlRLE9BQU9FO0FBQUFBLFVBQ1hDLE1BQU1GLFFBQVE7QUFBQSxVQUNkRyxVQUFVSixPQUFPSyxZQUFZO0FBQUEsVUFDN0JDLFVBQVVOLE9BQU9PLFlBQVk7QUFBQSxVQUM3QkMsUUFBUVIsT0FBT1Msa0JBQWtCO0FBQUEsVUFDakNDLGNBQWNWLE9BQU9XLGlCQUFpQjtBQUFBLFVBQ3RDekIsWUFBWWMsT0FBT1ksb0JBQ2ZaLE9BQU9ZLG1CQUFtQnJCLE9BQzFCUyxPQUFPYSxpQkFDTGIsT0FBT2EsaUJBQ1BiLE9BQU9jLG9CQUNMZCxPQUFPYyxtQkFBbUJDLFlBQzFCO0FBQUEsVUFDUkMsWUFBWWhCLE9BQU9pQixVQUFVQyxlQUFlO0FBQUEsVUFDNUNDLGNBQWNuQixPQUFPaUIsVUFBVUYsYUFBYTtBQUFBLFVBQzVDSyxlQUFlcEIsT0FBT2lCLFVBQVVJLGdCQUFnQjtBQUFBLFVBQ2hEQyxnQkFBZ0J0QixPQUFPdUIsYUFDbkIsSUFBSUMsS0FBS3hCLE1BQU11QixVQUFVLEVBQUVFLG1CQUFtQixPQUFPLElBQ3JEO0FBQUE7QUFBQSxVQUVKQyxtQkFBbUIxQixPQUFPdUIsYUFBYSxJQUFJQyxLQUFLeEIsTUFBTXVCLFVBQVUsSUFBSTtBQUFBLFVBQ3BFSSxrQkFBa0IzQixPQUFPNEIscUJBQXFCO0FBQUEsUUFDaEQsRUFBRTtBQUVGM0QsNEJBQW9CNkIsYUFBYTtBQUFBLE1BQ25DLFNBQVMrQixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUFBLE1BQ3JELFVBQUM7QUFDQzFELG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFFQXdCLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMLFFBQU1vQyxvQkFBb0JsRCxRQUFRLE1BQU07QUFDdEMsVUFBTVMsTUFBTSxvQkFBSTBDLElBQUk7QUFDcEJoRSxxQkFBaUJnQixRQUFRLENBQUNnQixVQUFVO0FBQ2xDLFlBQU1pQyxNQUFNakMsTUFBTUk7QUFDbEIsVUFBSSxDQUFDZCxJQUFJNEMsSUFBSUQsR0FBRyxHQUFHO0FBQ2pCM0MsWUFBSTZDLElBQUlGLEtBQUssRUFBRXpDLElBQUl5QyxLQUFLeEMsT0FBTyxHQUFHd0MsR0FBRyxHQUFHLENBQUM7QUFBQSxNQUMzQztBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU83QyxNQUFNQyxLQUFLQyxJQUFJOEMsT0FBTyxDQUFDO0FBQUEsRUFDaEMsR0FBRyxDQUFDcEUsZ0JBQWdCLENBQUM7QUFFckIsUUFBTXFFLGtCQUFrQnhEO0FBQUFBLElBQ3RCLE1BQ0ViLGlCQUFpQnNCLElBQUksQ0FBQ1UsV0FBVztBQUFBLE1BQy9CUixJQUFJUSxPQUFPUjtBQUFBQSxNQUNYRCxNQUFNUyxPQUFPbUI7QUFBQUEsTUFDYm1CLE9BQU90QyxPQUFPb0I7QUFBQUEsTUFDZG1CLFFBQVF2QyxPQUFPZ0I7QUFBQUEsSUFDakIsRUFBRTtBQUFBLElBQ0osQ0FBQ2hELGdCQUFnQjtBQUFBLEVBQ25CO0FBRUEsUUFBTXdFLHNCQUFzQjNELFFBQVEsTUFBTTtBQUN4QyxXQUFPYixpQkFBaUJ5RSxPQUFPLENBQUN6QyxVQUFVO0FBQ3hDLFlBQU0wQyxlQUFldEUsa0JBQ2pCNEIsTUFBTUksYUFBYWhDLGtCQUNuQjtBQUVKLFlBQU11RSxnQkFBZ0JyRSxtQkFDbEIwQixNQUFNUixPQUFPbEIsbUJBQ2I7QUFFSixZQUFNc0Usa0JBQWtCcEUscUJBQ3BCd0IsTUFBTWQsZUFBZVYscUJBQ3JCO0FBRUosVUFBSXFFLGlCQUFpQjtBQUNyQixVQUFJbkUsYUFBYUEsVUFBVW9FLFdBQVcsS0FBSzlDLE1BQU0wQixtQkFBbUI7QUFDbEUsY0FBTXFCLFlBQVl4RixNQUFNbUIsVUFBVSxDQUFDLENBQUMsRUFBRXNFLFFBQVEsS0FBSztBQUNuRCxjQUFNQyxVQUFVMUYsTUFBTW1CLFVBQVUsQ0FBQyxDQUFDLEVBQUV3RSxNQUFNLEtBQUs7QUFDL0MsY0FBTUMsWUFBWTVGLE1BQU15QyxNQUFNMEIsaUJBQWlCO0FBQy9DbUIseUJBQWlCTSxVQUFVQyxRQUFRTCxTQUFTLEtBQUtJLFVBQVVFLFNBQVNKLE9BQU87QUFBQSxNQUM3RTtBQUVBLGFBQU9QLGdCQUFnQkMsaUJBQWlCQyxtQkFBbUJDO0FBQUFBLElBQzdELENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQzdFLGtCQUFrQkksaUJBQWlCRSxrQkFBa0JFLG9CQUFvQkUsU0FBUyxDQUFDO0FBR3ZGLFFBQU00RSxlQUFlekUsUUFBUSxNQUFNO0FBQ2pDLFVBQU0wRSxXQUFXZjtBQUNqQixVQUFNZ0IsY0FBY0QsU0FBU0U7QUFBQUEsTUFDM0IsQ0FBQ0MsS0FBSzFELFVBQVUwRCxNQUFNMUQsTUFBTTJCO0FBQUFBLE1BQzVCO0FBQUEsSUFDRjtBQUNBLFVBQU1nQyxvQkFBb0JKLFNBQVNFO0FBQUFBLE1BQ2pDLENBQUNDLEtBQUsxRCxVQUFVMEQsTUFBTUUsT0FBTzVELE9BQU9RLFVBQVUsQ0FBQztBQUFBLE1BQUU7QUFBQSxJQUNuRDtBQUNBLFVBQU1xRCxjQUNKTixTQUFTVCxTQUFTLElBQ2RTLFNBQVNFLE9BQU8sQ0FBQ0MsS0FBSzFELFVBQVU7QUFDaEMsWUFBTThELE1BQU05RCxNQUFNTSxhQUFhLFFBQVFzRCxPQUFPNUQsTUFBTU0sUUFBUSxJQUFJO0FBQ2hFLGFBQU9vRCxNQUFNSTtBQUFBQSxJQUNmLEdBQUcsQ0FBQyxJQUFJUCxTQUFTVCxTQUNmO0FBRU4sV0FBTztBQUFBLE1BQ0xpQixZQUFZUixTQUFTVDtBQUFBQSxNQUNyQlU7QUFBQUEsTUFDQVEsY0FBY0w7QUFBQUEsTUFDZEUsYUFBYUEsWUFBWUksUUFBUSxDQUFDO0FBQUEsTUFDbEM1QixpQkFBaUIsSUFBSXRELElBQUl3RSxTQUFTakUsSUFBSSxDQUFDTCxNQUFNQSxFQUFFK0IsVUFBVSxDQUFDLEVBQUVrRDtBQUFBQSxJQUM5RDtBQUFBLEVBQ0YsR0FBRyxDQUFDMUIsbUJBQW1CLENBQUM7QUFFeEIsUUFBTTJCLHFCQUFxQjtBQUFBLElBQ3pCLEVBQUVsQyxLQUFLLFFBQVFtQyxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFbkMsS0FBSyxjQUFjbUMsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRW5DLEtBQUssZ0JBQWdCbUMsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFbkMsS0FBSyxpQkFBaUJtQyxRQUFRLGVBQWU7QUFBQSxJQUMvQyxFQUFFbkMsS0FBSyxZQUFZbUMsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRW5DLEtBQUssa0JBQWtCbUMsUUFBUSxhQUFhO0FBQUEsSUFDOUMsRUFBRW5DLEtBQUssWUFBWW1DLFFBQVEsb0JBQW9CO0FBQUEsSUFDL0MsRUFBRW5DLEtBQUssVUFBVW1DLFFBQVEsWUFBWTtBQUFBLElBQ3JDLEVBQUVuQyxLQUFLLG9CQUFvQm1DLFFBQVEsY0FBYztBQUFBLElBQ2pELEVBQUVuQyxLQUFLLGdCQUFnQm1DLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRW5DLEtBQUssY0FBY21DLFFBQVEsY0FBYztBQUFBLEVBQUM7QUFJOUMsUUFBTUMsV0FBV0EsQ0FBQyxFQUFFQyxNQUFNQyxNQUFNOUUsT0FBTytFLE9BQU9DLE9BQU9DLFNBQVMsR0FBRyxNQUMvRCx1QkFBQyxTQUFJLFdBQVUsMkdBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUUsV0FBVSwwQ0FBMENqRixtQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdELHVCQUFDLE9BQUUsV0FBVSxvQ0FDVitFO0FBQUFBO0FBQUFBLFFBQ0FFLFVBQ0MsdUJBQUMsVUFBSyxXQUFVLDBDQUNiQSxvQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVcsa0JBQWtCRCxLQUFLLElBQ3JDLGlDQUFDLFFBQUssV0FBVSx3QkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQyxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUJBO0FBR0YsU0FDRSx1QkFBQyxTQUFJLFdBQVUsSUFDYixpQ0FBQyxTQUFJLFdBQVUsZ0JBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSw4QkFDYixpQ0FBQyxhQUFVLFdBQVUsd0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsb0NBQW1DLG9DQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLHVCQUFzQiwyRkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUVDdkcsVUFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLG1DQUVFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDZEQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU1qQjtBQUFBQSxjQUNOLE9BQU07QUFBQSxjQUNOLE9BQU9xRyxhQUFhUztBQUFBQSxjQUNwQixPQUFNO0FBQUE7QUFBQSxZQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlxRDtBQUFBLFVBRXJELHVCQUFDLFVBQUssV0FBVSwwREFDYm5HLDhCQUFvQjBGLGFBQWFTLGNBQWMsQ0FBQyxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNM0c7QUFBQUEsY0FDTixPQUFNO0FBQUEsY0FDTixPQUFPLElBQUlrRyxhQUFhRSxhQUFhbUIsZUFBZSxPQUFPLEtBQUssQ0FBQztBQUFBLGNBQ2pFLE9BQU07QUFBQTtBQUFBLFlBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXVEO0FBQUEsVUFFdkQsdUJBQUMsVUFBSyxXQUFVLDBEQUNiL0csOEJBQW9CMEYsYUFBYUUsZUFBZSxDQUFDLEtBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU1wRztBQUFBQSxjQUNOLE9BQU07QUFBQSxjQUNOLE9BQU8sSUFBSWtHLGFBQWFVLGNBQWNXLGVBQWUsT0FBTyxLQUFLLENBQUM7QUFBQSxjQUNsRSxPQUFNO0FBQUE7QUFBQSxZQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl5RDtBQUFBLFVBRXpELHVCQUFDLFVBQUssV0FBVSwwREFDYi9HLDhCQUFvQjBGLGFBQWFVLGdCQUFnQixDQUFDLEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU0zRztBQUFBQSxjQUNOLE9BQU07QUFBQSxjQUNOLE9BQU9pRyxhQUFhTztBQUFBQSxjQUNwQixRQUFPO0FBQUEsY0FDUCxPQUFNO0FBQUE7QUFBQSxZQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUt5RDtBQUFBLFVBRXpELHVCQUFDLFVBQUssV0FBVSwwREFDYmpHLDhCQUFvQjBGLGFBQWFPLGVBQWUsQ0FBQyxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNM0c7QUFBQUEsY0FDTixPQUFNO0FBQUEsY0FDTixPQUFPb0csYUFBYWpCO0FBQUFBLGNBQ3BCLE9BQU07QUFBQTtBQUFBLFlBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXlEO0FBQUEsVUFFekQsdUJBQUMsVUFBSyxXQUFVLDBEQUNiekUsOEJBQW9CMEYsYUFBYWpCLG1CQUFtQixDQUFDLEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErREE7QUFBQSxNQUlBLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLGlDQUFDLFVBQU8sV0FBVSwyQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxVQUN6Qyx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx3REFFYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQ2YsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThCO0FBQUEsY0FBRztBQUFBLGlCQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPakU7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSxjQUFjLENBQUN1RyxPQUFPQyxXQUNwQkEsT0FBT3BGLE1BQU1xRixZQUFZLEVBQUVDLFNBQVNILE1BQU1FLFlBQVksQ0FBQztBQUFBLGdCQUV6RCxpQkFBZ0I7QUFBQSxnQkFDaEIsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFFTDtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxPQUFNLHNCQUFxQixrQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNDL0Msa0JBQWtCekM7QUFBQUEsb0JBQUksQ0FBQ1UsVUFDdEI7QUFBQSxzQkFBQyxPQUFPO0FBQUEsc0JBQVA7QUFBQSx3QkFFQyxPQUFPQSxPQUFPUjtBQUFBQSx3QkFDZCxPQUFPUSxPQUFPUDtBQUFBQSx3QkFFYk8saUJBQU9QO0FBQUFBO0FBQUFBLHNCQUpITyxPQUFPUjtBQUFBQSxzQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1BO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0F4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBeUJBO0FBQUEsZUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0E7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQ2YsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBCO0FBQUEsY0FBRztBQUFBLGlCQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPbEI7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSxpQkFBZ0I7QUFBQSxnQkFDaEIsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxjQUFjLENBQUNxRyxPQUFPQyxXQUNwQkEsT0FBT3BGLE1BQU1xRixZQUFZLEVBQUVDLFNBQVNILE1BQU1FLFlBQVksQ0FBQztBQUFBLGdCQUd6RDtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxPQUFNLGlCQUFnQiw2QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNDekMsZ0JBQWdCL0M7QUFBQUEsb0JBQUksQ0FBQzBGLFNBQ3BCO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBRUMsT0FBT0EsTUFBTXhGO0FBQUFBLHdCQUNiLE9BQU8sR0FBR3dGLE1BQU16QyxNQUFNLE1BQU15QyxNQUFNekYsSUFBSSxNQUFNeUYsTUFBTTFDLEtBQUs7QUFBQSx3QkFFdEQwQztBQUFBQSxnQ0FBTXpDO0FBQUFBLDBCQUFPO0FBQUEsMEJBQUl5QyxNQUFNekY7QUFBQUEsMEJBQUs7QUFBQSwwQkFBSXlGLE1BQU0xQztBQUFBQTtBQUFBQTtBQUFBQSxzQkFKbEMwQyxNQUFNeEY7QUFBQUEsc0JBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXlCQTtBQUFBLGVBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUNmLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQUc7QUFBQSxpQkFEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osT0FBT2hCO0FBQUFBLGdCQUNQLFVBQVVDO0FBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsaUJBQWdCO0FBQUEsZ0JBQ2hCLFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBQ0wsY0FBYyxDQUFDbUcsT0FBT0MsV0FDcEJBLE9BQU9wRixNQUFNcUYsWUFBWSxFQUFFQyxTQUFTSCxNQUFNRSxZQUFZLENBQUM7QUFBQSxnQkFHekQ7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsT0FBTSxtQkFBa0IsK0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFQ2xHLGlCQUFpQlU7QUFBQUEsb0JBQUksQ0FBQzJGLFFBQ3JCO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBRUMsT0FBT0EsSUFBSXpGO0FBQUFBLHdCQUNYLE9BQU95RixJQUFJeEY7QUFBQUEsd0JBRVZ3RixjQUFJeEY7QUFBQUE7QUFBQUEsc0JBSkF3RixJQUFJekY7QUFBQUEsc0JBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTBCQTtBQUFBLGVBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUNBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUNmLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGNBQUc7QUFBQSxpQkFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT2Q7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUE7QUFBQSxjQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtxQjtBQUFBLGVBWnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxhQTlIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0hBO0FBQUEsV0F2SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdJQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTd0Y7QUFBQUEsVUFDVCxNQUFNM0I7QUFBQUEsVUFDTCxpQkFBaUI7QUFBQSxZQUNoQjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUFrQjtBQUFBLFVBRXBCLG1CQUFtQjtBQUFBLFlBQ2pCYyxhQUFhUztBQUFBQSxZQUNiLEtBQUtULGFBQWFFLFdBQVc7QUFBQSxZQUM3QixLQUFLRixhQUFhVSxZQUFZO0FBQUEsWUFDOUIsS0FBS1YsYUFBYU8sV0FBVztBQUFBLFlBQzdCLEtBQUtQLGFBQWFqQixlQUFlO0FBQUEsVUFBRTtBQUFBLFVBRXJDLGlCQUFnQjtBQUFBLFVBQ2Qsa0JBQWlCO0FBQUE7QUFBQSxRQWxCckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Ba0IrQyxLQW5CakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBcE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxT0E7QUFBQSxPQTNQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNlBBLEtBOVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErUEE7QUFFSjtBQUFFdEUsR0EvYUlELG9CQUFrQjtBQUFBb0gsS0FBbEJwSDtBQWliTixlQUFlQTtBQUFtQixJQUFBb0g7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2VhcmNoIiwiUGlnZ3lCYW5rIiwiVXNlcnMiLCJDYWxlbmRhciIsIlRyZW5kaW5nVXAiLCJDbG9jayIsIkRhdGVQaWNrZXIiLCJkYXlqcyIsImFwaSIsIkRhdGFUYWJsZSIsIlNlbGVjdCIsIkNpcmN1bGFyTG9hZGVyIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIlJhbmdlUGlja2VyIiwiUGlnbXlTdW1tYXJ5UmVwb3J0IiwiX3MiLCJwaWdteVJlcG9ydFRhYmxlIiwic2V0UGlnbXlSZXBvcnRUYWJsZSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2VsZWN0ZWRQaWdteUlkIiwic2V0U2VsZWN0ZWRQaWdteUlkIiwic2VsZWN0ZWRDdXN0b21lciIsInNldFNlbGVjdGVkQ3VzdG9tZXIiLCJzZWxlY3RlZFJlZmVycmVkQnkiLCJzZXRTZWxlY3RlZFJlZmVycmVkQnkiLCJkYXRlUmFuZ2UiLCJzZXREYXRlUmFuZ2UiLCJ1bmlxdWVSZWZlcnJlZEJ5IiwidXNlTWVtbyIsInNldFJlZiIsIlNldCIsImZvckVhY2giLCJwIiwicmVmZXJyZWRCeSIsImFkZCIsIkFycmF5IiwiZnJvbSIsIm1hcCIsIm5hbWUiLCJpZCIsImxhYmVsIiwidXNlRWZmZWN0IiwiZmV0Y2hQaWdteVJlcG9ydCIsInJlc3BvbnNlIiwiZ2V0IiwiZm9ybWF0dGVkRGF0YSIsImRhdGEiLCJwaWdteSIsImluZGV4IiwiX2lkIiwic2xObyIsInBpZ215SWRzIiwicGlnbWVfaWQiLCJEdXJhdGlvbiIsImR1cmF0aW9uIiwiYW1vdW50IiwicGF5YWJsZV9hbW91bnQiLCJyZWZlcnJlZFR5cGUiLCJyZWZlcnJlZF90eXBlIiwicmVmZXJyZWRfZW1wbG95ZWUiLCJyZWZlcnJlZF9hZ2VudCIsInJlZmVycmVkX2N1c3RvbWVyIiwiZnVsbF9uYW1lIiwiY3VzdG9tZXJJZCIsImN1c3RvbWVyIiwiY3VzdG9tZXJfaWQiLCJjdXN0b21lck5hbWUiLCJjdXN0b21lclBob25lIiwicGhvbmVfbnVtYmVyIiwicGlnbXlTdGFydERhdGUiLCJzdGFydF9kYXRlIiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInBpZ215U3RhcnREYXRlT2JqIiwidG90YWxwaWdteUFtb3VudCIsInRvdGFsX3BhaWRfYW1vdW50IiwiZXJyb3IiLCJjb25zb2xlIiwidW5pcXVlUGlnbXlDb21ib3MiLCJNYXAiLCJrZXkiLCJoYXMiLCJzZXQiLCJ2YWx1ZXMiLCJ1bmlxdWVDdXN0b21lcnMiLCJwaG9uZSIsImN1c3RpZCIsImZpbHRlcmVkUGlnbXlSZXBvcnQiLCJmaWx0ZXIiLCJtYXRjaFBpZ215SWQiLCJtYXRjaEN1c3RvbWVyIiwibWF0Y2hSZWZlcnJlZEJ5IiwibWF0Y2hEYXRlUmFuZ2UiLCJsZW5ndGgiLCJzdGFydERhdGUiLCJzdGFydE9mIiwiZW5kRGF0ZSIsImVuZE9mIiwicGlnbXlEYXRlIiwiaXNBZnRlciIsImlzQmVmb3JlIiwic3VtbWFyeVN0YXRzIiwiZmlsdGVyZWQiLCJ0b3RhbEFtb3VudCIsInJlZHVjZSIsInN1bSIsInRvdGFsUGF5YWJsZVBpZ215IiwiTnVtYmVyIiwiYXZnRHVyYXRpb24iLCJkdXIiLCJ0b3RhbFBpZ215IiwidG90YWxQYXlhYmxlIiwidG9GaXhlZCIsInNpemUiLCJQaWdteVJlcG9ydENvbHVtbnMiLCJoZWFkZXIiLCJTdGF0Q2FyZCIsImljb24iLCJJY29uIiwidmFsdWUiLCJjb2xvciIsInN1ZmZpeCIsInRvTG9jYWxlU3RyaW5nIiwiaW5wdXQiLCJvcHRpb24iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiY3VzdCIsInJlZiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBpZ215U3VtbWFyeVJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIFNlYXJjaCxcclxuICBQaWdneUJhbmssXHJcbiAgVXNlcnMsXHJcbiAgQ2FsZW5kYXIsXHJcbiAgVHJlbmRpbmdVcCxcclxuICBDbG9jayxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IERhdGVQaWNrZXIgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XHJcblxyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIlxyXG5cclxuY29uc3QgeyBSYW5nZVBpY2tlciB9ID0gRGF0ZVBpY2tlcjtcclxuXHJcbmNvbnN0IFBpZ215U3VtbWFyeVJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbcGlnbXlSZXBvcnRUYWJsZSwgc2V0UGlnbXlSZXBvcnRUYWJsZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGlnbXlJZCwgc2V0U2VsZWN0ZWRQaWdteUlkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVyLCBzZXRTZWxlY3RlZEN1c3RvbWVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFJlZmVycmVkQnksIHNldFNlbGVjdGVkUmVmZXJyZWRCeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGF0ZVJhbmdlLCBzZXREYXRlUmFuZ2VdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IHVuaXF1ZVJlZmVycmVkQnkgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHNldFJlZiA9IG5ldyBTZXQoKTtcclxuICAgIHBpZ215UmVwb3J0VGFibGUuZm9yRWFjaCgocCkgPT4ge1xyXG4gICAgICBpZiAocC5yZWZlcnJlZEJ5ICYmIHAucmVmZXJyZWRCeSAhPT0gXCJOL0FcIikge1xyXG4gICAgICAgIHNldFJlZi5hZGQocC5yZWZlcnJlZEJ5KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gQXJyYXkuZnJvbShzZXRSZWYpLm1hcCgobmFtZSkgPT4gKHtcclxuICAgICAgaWQ6IG5hbWUsXHJcbiAgICAgIGxhYmVsOiBuYW1lLFxyXG4gICAgfSkpO1xyXG4gIH0sIFtwaWdteVJlcG9ydFRhYmxlXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFBpZ215UmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvcGlnbWUvY3VzdG9tZXJzYCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLmRhdGEubWFwKChwaWdteSwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBpZDogcGlnbXk/Ll9pZCxcclxuICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgIHBpZ215SWRzOiBwaWdteT8ucGlnbWVfaWQgfHwgXCJOL0FcIixcclxuICAgICAgICAgIER1cmF0aW9uOiBwaWdteT8uZHVyYXRpb24gfHwgXCJOL0FcIixcclxuICAgICAgICAgIGFtb3VudDogcGlnbXk/LnBheWFibGVfYW1vdW50IHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICByZWZlcnJlZFR5cGU6IHBpZ215Py5yZWZlcnJlZF90eXBlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICByZWZlcnJlZEJ5OiBwaWdteT8ucmVmZXJyZWRfZW1wbG95ZWVcclxuICAgICAgICAgICAgPyBwaWdteT8ucmVmZXJyZWRfZW1wbG95ZWU/Lm5hbWVcclxuICAgICAgICAgICAgOiBwaWdteT8ucmVmZXJyZWRfYWdlbnRcclxuICAgICAgICAgICAgICA/IHBpZ215Py5yZWZlcnJlZF9hZ2VudFxyXG4gICAgICAgICAgICAgIDogcGlnbXk/LnJlZmVycmVkX2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA/IHBpZ215Py5yZWZlcnJlZF9jdXN0b21lcj8uZnVsbF9uYW1lXHJcbiAgICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICBjdXN0b21lcklkOiBwaWdteT8uY3VzdG9tZXI/LmN1c3RvbWVyX2lkIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBjdXN0b21lck5hbWU6IHBpZ215Py5jdXN0b21lcj8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBjdXN0b21lclBob25lOiBwaWdteT8uY3VzdG9tZXI/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgcGlnbXlTdGFydERhdGU6IHBpZ215Py5zdGFydF9kYXRlXHJcbiAgICAgICAgICAgID8gbmV3IERhdGUocGlnbXkuc3RhcnRfZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIilcclxuICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgLy8gU3RvcmUgdGhlIG9yaWdpbmFsIGRhdGUgZm9yIGZpbHRlcmluZ1xyXG4gICAgICAgICAgcGlnbXlTdGFydERhdGVPYmo6IHBpZ215Py5zdGFydF9kYXRlID8gbmV3IERhdGUocGlnbXkuc3RhcnRfZGF0ZSkgOiBudWxsLFxyXG4gICAgICAgICAgdG90YWxwaWdteUFtb3VudDogcGlnbXk/LnRvdGFsX3BhaWRfYW1vdW50ID8/IDAsXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBzZXRQaWdteVJlcG9ydFRhYmxlKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBQaWdteSByZXBvcnQ6XCIsIGVycm9yKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaFBpZ215UmVwb3J0KCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCB1bmlxdWVQaWdteUNvbWJvcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgbWFwID0gbmV3IE1hcCgpO1xyXG4gICAgcGlnbXlSZXBvcnRUYWJsZS5mb3JFYWNoKChwaWdteSkgPT4ge1xyXG4gICAgICBjb25zdCBrZXkgPSBwaWdteS5waWdteUlkcztcclxuICAgICAgaWYgKCFtYXAuaGFzKGtleSkpIHtcclxuICAgICAgICBtYXAuc2V0KGtleSwgeyBpZDoga2V5LCBsYWJlbDogYCR7a2V5fWAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIEFycmF5LmZyb20obWFwLnZhbHVlcygpKTtcclxuICB9LCBbcGlnbXlSZXBvcnRUYWJsZV0pO1xyXG5cclxuICBjb25zdCB1bmlxdWVDdXN0b21lcnMgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT5cclxuICAgICAgcGlnbXlSZXBvcnRUYWJsZS5tYXAoKHBpZ215KSA9PiAoe1xyXG4gICAgICAgIGlkOiBwaWdteT8uaWQsXHJcbiAgICAgICAgbmFtZTogcGlnbXk/LmN1c3RvbWVyTmFtZSxcclxuICAgICAgICBwaG9uZTogcGlnbXk/LmN1c3RvbWVyUGhvbmUsXHJcbiAgICAgICAgY3VzdGlkOiBwaWdteT8uY3VzdG9tZXJJZCxcclxuICAgICAgfSkpLFxyXG4gICAgW3BpZ215UmVwb3J0VGFibGVdXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRQaWdteVJlcG9ydCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHBpZ215UmVwb3J0VGFibGUuZmlsdGVyKChwaWdteSkgPT4ge1xyXG4gICAgICBjb25zdCBtYXRjaFBpZ215SWQgPSBzZWxlY3RlZFBpZ215SWRcclxuICAgICAgICA/IHBpZ215LnBpZ215SWRzID09PSBzZWxlY3RlZFBpZ215SWRcclxuICAgICAgICA6IHRydWU7XHJcblxyXG4gICAgICBjb25zdCBtYXRjaEN1c3RvbWVyID0gc2VsZWN0ZWRDdXN0b21lclxyXG4gICAgICAgID8gcGlnbXkuaWQgPT09IHNlbGVjdGVkQ3VzdG9tZXJcclxuICAgICAgICA6IHRydWU7XHJcblxyXG4gICAgICBjb25zdCBtYXRjaFJlZmVycmVkQnkgPSBzZWxlY3RlZFJlZmVycmVkQnlcclxuICAgICAgICA/IHBpZ215LnJlZmVycmVkQnkgPT09IHNlbGVjdGVkUmVmZXJyZWRCeVxyXG4gICAgICAgIDogdHJ1ZTtcclxuXHJcbiAgICAgIGxldCBtYXRjaERhdGVSYW5nZSA9IHRydWU7XHJcbiAgICAgIGlmIChkYXRlUmFuZ2UgJiYgZGF0ZVJhbmdlLmxlbmd0aCA9PT0gMiAmJiBwaWdteS5waWdteVN0YXJ0RGF0ZU9iaikge1xyXG4gICAgICAgIGNvbnN0IHN0YXJ0RGF0ZSA9IGRheWpzKGRhdGVSYW5nZVswXSkuc3RhcnRPZignZGF5Jyk7XHJcbiAgICAgICAgY29uc3QgZW5kRGF0ZSA9IGRheWpzKGRhdGVSYW5nZVsxXSkuZW5kT2YoJ2RheScpO1xyXG4gICAgICAgIGNvbnN0IHBpZ215RGF0ZSA9IGRheWpzKHBpZ215LnBpZ215U3RhcnREYXRlT2JqKTtcclxuICAgICAgICBtYXRjaERhdGVSYW5nZSA9IHBpZ215RGF0ZS5pc0FmdGVyKHN0YXJ0RGF0ZSkgJiYgcGlnbXlEYXRlLmlzQmVmb3JlKGVuZERhdGUpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gbWF0Y2hQaWdteUlkICYmIG1hdGNoQ3VzdG9tZXIgJiYgbWF0Y2hSZWZlcnJlZEJ5ICYmIG1hdGNoRGF0ZVJhbmdlO1xyXG4gICAgfSk7XHJcbiAgfSwgW3BpZ215UmVwb3J0VGFibGUsIHNlbGVjdGVkUGlnbXlJZCwgc2VsZWN0ZWRDdXN0b21lciwgc2VsZWN0ZWRSZWZlcnJlZEJ5LCBkYXRlUmFuZ2VdKTtcclxuXHJcbiAgLy8gQ2FsY3VsYXRlIHN1bW1hcnkgc3RhdGlzdGljc1xyXG4gIGNvbnN0IHN1bW1hcnlTdGF0cyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBmaWx0ZXJlZFBpZ215UmVwb3J0O1xyXG4gICAgY29uc3QgdG90YWxBbW91bnQgPSBmaWx0ZXJlZC5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHBpZ215KSA9PiBzdW0gKyBwaWdteS50b3RhbHBpZ215QW1vdW50LFxyXG4gICAgICAwXHJcbiAgICApO1xyXG4gICAgY29uc3QgdG90YWxQYXlhYmxlUGlnbXkgPSBmaWx0ZXJlZC5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHBpZ215KSA9PiBzdW0gKyBOdW1iZXIocGlnbXk/LmFtb3VudCB8fCAwKSwwXHJcbiAgICApXHJcbiAgICBjb25zdCBhdmdEdXJhdGlvbiA9XHJcbiAgICAgIGZpbHRlcmVkLmxlbmd0aCA+IDBcclxuICAgICAgICA/IGZpbHRlcmVkLnJlZHVjZSgoc3VtLCBwaWdteSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgZHVyID0gcGlnbXkuRHVyYXRpb24gIT09IFwiTi9BXCIgPyBOdW1iZXIocGlnbXkuRHVyYXRpb24pIDogMDtcclxuICAgICAgICAgIHJldHVybiBzdW0gKyBkdXI7XHJcbiAgICAgICAgfSwgMCkgLyBmaWx0ZXJlZC5sZW5ndGhcclxuICAgICAgICA6IDA7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWxQaWdteTogZmlsdGVyZWQubGVuZ3RoLFxyXG4gICAgICB0b3RhbEFtb3VudDogdG90YWxBbW91bnQsXHJcbiAgICAgIHRvdGFsUGF5YWJsZTogdG90YWxQYXlhYmxlUGlnbXksXHJcbiAgICAgIGF2Z0R1cmF0aW9uOiBhdmdEdXJhdGlvbi50b0ZpeGVkKDEpLFxyXG4gICAgICB1bmlxdWVDdXN0b21lcnM6IG5ldyBTZXQoZmlsdGVyZWQubWFwKChwKSA9PiBwLmN1c3RvbWVySWQpKS5zaXplLFxyXG4gICAgfTtcclxuICB9LCBbZmlsdGVyZWRQaWdteVJlcG9ydF0pO1xyXG5cclxuICBjb25zdCBQaWdteVJlcG9ydENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbE5vXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcklkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInBpZ215SWRzXCIsIGhlYWRlcjogXCJQaWdteSBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJwaWdteVN0YXJ0RGF0ZVwiLCBoZWFkZXI6IFwiU3RhcnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJEdXJhdGlvblwiLCBoZWFkZXI6IFwiRHVyYXRpb24gKG1vbnRocylcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJEYWlseSBQYXlcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxwaWdteUFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50IFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRUeXBlXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkQnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgU3RhdENhcmQgPSAoeyBpY29uOiBJY29uLCBsYWJlbCwgdmFsdWUsIGNvbG9yLCBzdWZmaXggPSBcIlwiIH0pID0+IChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTYgaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tc2hhZG93IGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMVwiPntsYWJlbH08L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICB7dmFsdWV9XHJcbiAgICAgICAgICAgIHtzdWZmaXggJiYgKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ub3JtYWwgdGV4dC1ncmF5LTUwMCBtbC0xXCI+XHJcbiAgICAgICAgICAgICAgICB7c3VmZml4fVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLWxnICR7Y29sb3J9YH0+XHJcbiAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LXNjcmVlblwiPlxyXG4gICAgICAgIHsvKiBIZWFkZXIgU2VjdGlvbiAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1waW5rLTYwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgPFBpZ2d5QmFuayBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgUGlnbXkgU3VtbWFyeSBSZXBvcnRcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtbC0xNFwiPlxyXG4gICAgICAgICAgICBDb21wcmVoZW5zaXZlIG92ZXJ2aWV3IG9mIHBpZ215IHNhdmluZ3MgYWNjb3VudHMgYW5kIGN1c3RvbWVyXHJcbiAgICAgICAgICAgIGNvbnRyaWJ1dGlvbnNcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGgtOTZcIj5cclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAgey8qIFN1bW1hcnkgU3RhdGlzdGljcyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC02IG1iLThcIj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8U3RhdENhcmRcclxuICAgICAgICAgICAgICAgICAgaWNvbj17UGlnZ3lCYW5rfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlRvdGFsIFBpZ215IEFjY291bnRzXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3N1bW1hcnlTdGF0cy50b3RhbFBpZ215fVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcGluay01MDAgdG8tcGluay02MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIG10LTIgYnJlYWstd29yZHMgcGwtM1wiPlxyXG4gICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhzdW1tYXJ5U3RhdHMudG90YWxQaWdteSB8fCAwKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8U3RhdENhcmRcclxuICAgICAgICAgICAgICAgICAgaWNvbj17VHJlbmRpbmdVcH1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUb3RhbCBBbW91bnQgQ29sbGVjdGVkXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Digrkke3N1bW1hcnlTdGF0cy50b3RhbEFtb3VudD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCAwfWB9XHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmVlbi01MDAgdG8tZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJyZWFrLXdvcmRzIHBsLTNcIj5cclxuICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoc3VtbWFyeVN0YXRzLnRvdGFsQW1vdW50IHx8IDApfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtUcmVuZGluZ1VwfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlRvdGFsIFBheWFibGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7c3VtbWFyeVN0YXRzLnRvdGFsUGF5YWJsZT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCAwfWB9XHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1vcmFuZ2UtNTAwIHRvLW9yYW5nZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIG10LTIgYnJlYWstd29yZHMgcGwtM1wiPlxyXG4gICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhzdW1tYXJ5U3RhdHMudG90YWxQYXlhYmxlIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtDbG9ja31cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJBdmVyYWdlIER1cmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3N1bW1hcnlTdGF0cy5hdmdEdXJhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgc3VmZml4PVwibW9udGhzXCJcclxuICAgICAgICAgICAgICAgICAgY29sb3I9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MDAgdG8tdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmVlbi03MDAgbXQtMiBicmVhay13b3JkcyBwbC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHN1bW1hcnlTdGF0cy5hdmdEdXJhdGlvbiB8fCAwKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8U3RhdENhcmRcclxuICAgICAgICAgICAgICAgICAgaWNvbj17VXNlcnN9XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVW5pcXVlIEN1c3RvbWVyc1wiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1tYXJ5U3RhdHMudW5pcXVlQ3VzdG9tZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwMCB0by1wdXJwbGUtNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJyZWFrLXdvcmRzIHBsLTNcIj5cclxuICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoc3VtbWFyeVN0YXRzLnVuaXF1ZUN1c3RvbWVycyB8fCAwKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgIHsvKiBGaWx0ZXJzIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEZpbHRlciBPcHRpb25zXHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBQaWdteSBJRCBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8UGlnZ3lCYW5rIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGlnbXkgSURcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBvciBzZWxlY3QgcGlnbXkgYWNjb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUGlnbXlJZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRQaWdteUlkfVxyXG4gICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmxhYmVsLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uTGFiZWxQcm9wPVwibGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCIgbGFiZWw9XCJBbGwgUGlnbXkgQWNjb3VudHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEFsbCBQaWdteSBBY2NvdW50c1xyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7dW5pcXVlUGlnbXlDb21ib3MubWFwKChwaWdteSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtwaWdteT8uaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaWdteT8uaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtwaWdteT8ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdteT8ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3Igc2VsZWN0IGN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRDdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uTGFiZWxQcm9wPVwibGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmxhYmVsLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiIGxhYmVsPVwiQWxsIEN1c3RvbWVyc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQWxsIEN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7dW5pcXVlQ3VzdG9tZXJzLm1hcCgoY3VzdCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjdXN0Py5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3Q/LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17YCR7Y3VzdD8uY3VzdGlkfSB8ICR7Y3VzdD8ubmFtZX0gfCAke2N1c3Q/LnBob25lfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0Py5jdXN0aWR9IHwge2N1c3Q/Lm5hbWV9IHwge2N1c3Q/LnBob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBSZWZlcnJlZCBCeSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZWZlcnJlZCBCeVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBvciBzZWxlY3QgcmVmZXJyZWQgYnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFJlZmVycmVkQnl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkUmVmZXJyZWRCeX1cclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uTGFiZWxQcm9wPVwibGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmxhYmVsLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiIGxhYmVsPVwiQWxsIFJlZmVycmVkIEJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBbGwgUmVmZXJyZWQgQnlcclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHt1bmlxdWVSZWZlcnJlZEJ5Lm1hcCgocmVmKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3JlZi5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JlZi5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e3JlZi5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3JlZi5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogRGF0ZSBSYW5nZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTdGFydCBEYXRlIFJhbmdlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxSYW5nZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRlUmFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldERhdGVSYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiREQvTU0vWVlZWVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LXNjcmVlblwiPlxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e1BpZ215UmVwb3J0Q29sdW1uc31cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkUGlnbXlSZXBvcnR9XHJcbiAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgUGlnbXlcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBQaWdteSBBbW91bnRcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBQYXlhYmxlXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiQXZlcmFnZSBEdXJhdGlvblwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlVuaXF1ZSBDdXN0b21lcnNcIixcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgICAgICAgICAgICAgICBzdW1tYXJ5U3RhdHMudG90YWxQaWdteSxcclxuICAgICAgICAgICAgICAgICAgYOKCuSAke3N1bW1hcnlTdGF0cy50b3RhbEFtb3VudH1gLFxyXG4gICAgICAgICAgICAgICAgICBg4oK5ICR7c3VtbWFyeVN0YXRzLnRvdGFsUGF5YWJsZX1gLFxyXG4gICAgICAgICAgICAgICAgICBg4oK5ICR7c3VtbWFyeVN0YXRzLmF2Z0R1cmF0aW9ufWAsXHJcbiAgICAgICAgICAgICAgICAgIGDigrkgJHtzdW1tYXJ5U3RhdHMudW5pcXVlQ3VzdG9tZXJzfWAsXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiUGlnbXkgU3VtbWFyeSBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiUGlnbXkgU3VtbWFyeSBSZXBvcnQuY3N2XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBpZ215U3VtbWFyeVJlcG9ydDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGlnbXlTdW1tYXJ5UmVwb3J0LmpzeCJ9