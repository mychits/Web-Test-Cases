import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Loan.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Input, Select, Modal as AntModal, Dropdown, Tabs, Drawer, Menu, Button, message, Form, DatePicker, Popconfirm, Popover, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaCalculator, FaCalendarAlt, FaCheckCircle, FaEdit, FaEye, FaFlagCheckered, FaHourglassHalf, FaQuestionCircle, FaRegEdit, FaThumbsUp, FaTimesCircle, FaUser, FaUserTie } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import LoanRequestPrint from "/src/components/printFormats/LoanRequestPrint.js";
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import imageInput from "/src/assets/images/Agent.png?import";
import { AiOutlineLoading3Quarters } from "/node_modules/.vite/deps/react-icons_ai.js?v=819e0a34";
import ViewCustomerTransactions from "/src/pages/ViewCustomerTransactions.jsx";
import {
  MoreOutlined,
  UserOutlined,
  CheckCircleOutlined,
  EditOutlined,
  CloseOutlined,
  DollarOutlined,
  CalendarOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
  TrophyOutlined,
  StopOutlined,
  ExclamationCircleOutlined,
  DeleteOutlined,
  SearchOutlined,
  InfoCircleOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import { showConfirm } from "/src/components/alerts/ShowConfirm.jsx";
import { FiPhone, FiFileText, FiClock, FiEye, FiSettings, FiUser, FiUserPlus } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { QuestionCircleOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { RiArrowRightFill } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import { BiRupee } from "/node_modules/.vite/deps/react-icons_bi.js?v=819e0a34";
const Loan = () => {
  _s();
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [borrowers, setBorrowers] = useState([]);
  const [tableBorrowers, setTableBorrowers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentBorrower, setCurrentBorrower] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [currentUpdateBorrower, setCurrentUpdateBorrower] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showRemoveModal, setShowRemoveModal] = useState(false);
  const [removeReason, setRemoveReason] = useState("");
  const [customRemoveReason, setCustomRemoveReason] = useState("");
  const [buttonLoading, setButtonLoading] = useState(false);
  const [showTransactions, setShowTransactions] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedLoan, setSelectedLoan] = useState(null);
  const [activeTab, setActiveTab] = useState("requests");
  const [isAcceptModalOpen, setIsAcceptModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState(false);
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [approvalStatus, setApprovalStatus] = useState("");
  const [approvalNote, setApprovalNote] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [form] = Form.useForm();
  const [totals, setTotals] = useState({
    totalRequests: 0,
    totalAccepted: 0,
    totalPending: 0,
    totalApproved: 0,
    totalRejected: 0,
    totalCompleted: 0,
    totalClosed: 0,
    totalUnknown: 0
  });
  const ORDERED_STATUSES = [
    "REQUESTED",
    "ACCEPTED",
    "PENDING",
    "APPROVED",
    "UNKNOWN",
    "REJECTED",
    "COMPLETED"
  ];
  const [isLoanUpdated, setIsLoanUpdated] = useState(false);
  const [summaryData, setSummaryData] = useState([]);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [allLoans, setAllLoans] = useState({
    requests: [],
    accepted: [],
    pending: [],
    approved: [],
    rejected: [],
    completed: [],
    closed: [],
    unknown: []
  });
  const [allLoansLoaded, setAllLoansLoaded] = useState(false);
  const [globalSearchResults, setGlobalSearchResults] = useState(null);
  const [globalSearchTerm, setGlobalSearchTerm] = useState("");
  const [globalSearchTargetTab, setGlobalSearchTargetTab] = useState(null);
  const [isLoanModalOpen, setIsLoanModalOpen] = useState(false);
  const [searchInput, setSearchInput] = useState("");
  const [loanAmounts, setLoanAmounts] = useState({
    requested_loan_amount: "",
    approved_loan_amount: ""
  });
  const [showPenaltyModal, setShowPenaltyModal] = useState(false);
  const [penaltyLoan, setPenaltyLoan] = useState(null);
  const [penaltyCharges, setPenaltyCharges] = useState(
    [
      { amount: "", reason: "" }
    ]
  );
  const [penaltyLoading, setPenaltyLoading] = useState(false);
  const [loadingCustomerId, setLoadingCustomerId] = useState(null);
  const formatIndianCurrency = (amount) => {
    if (amount === void 0 || amount === null) return "₹0";
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0
    }).format(amount);
  };
  const getAdminId = () => {
    try {
      const user = JSON.parse(localStorage.getItem("user"));
      return user?._id || user?.id || null;
    } catch {
      return null;
    }
  };
  const handleSubmitLoanAmounts = async () => {
    try {
      const payload = {
        approved_loan_amount: loanAmounts.approved_loan_amount,
        updated_by: getAdminId()
      };
      await api.put(`/v1/admin/loans/approved-amount/${selectedLoan?._id}`, payload);
      message.success("Loan amounts updated successfully");
    } catch (error) {
      console.log(error);
      message.error("Failed to update loan amounts");
    } finally {
      setIsLoanModalOpen(false);
      setReloadTrigger((prev) => prev + 1);
    }
  };
  useEffect(() => {
    if (globalSearchTerm && globalSearchTargetTab === activeTab && tableBorrowers.length > 0) {
      const term = globalSearchTerm.toLowerCase();
      const matched = tableBorrowers.filter((row) => {
        const name = (row._searchName || "").toLowerCase();
        const phone = (row.phone_number || "").toLowerCase();
        return name.includes(term) || phone.includes(term);
      });
      if (matched.length > 0) {
        setGlobalSearchResults(matched);
      } else {
        setGlobalSearchResults([]);
      }
    }
  }, [tableBorrowers, globalSearchTerm, globalSearchTargetTab, activeTab]);
  const handleSearch = (term) => {
    const trimmed = term.trim();
    if (!trimmed) {
      setGlobalSearchTerm("");
      setGlobalSearchResults(null);
      setGlobalSearchTargetTab(null);
      setSearchInput("");
      return;
    }
    const termLower = trimmed.toLowerCase();
    let foundLoan = null;
    let foundStatusKey = null;
    for (const [statusKey, loans] of Object.entries(allLoans)) {
      const match = loans.find((loan) => {
        const name = (loan.user_id?.full_name || loan.borrower?.full_name || loan.user?.full_name || "").toLowerCase();
        const phone = (loan.user_id?.phone_number || loan.borrower?.phone_number || loan.user?.phone_number || "").toLowerCase();
        return name.includes(termLower) || phone.includes(termLower);
      });
      if (match) {
        foundLoan = match;
        foundStatusKey = statusKey;
        break;
      }
    }
    if (foundLoan && foundStatusKey) {
      const tabMap = {
        requested: "requests",
        accepted: "accepted",
        pending: "pending",
        approved: "approved",
        rejected: "rejected",
        completed: "completed",
        closed: "closed",
        unknown: "unknown"
      };
      const targetTab = tabMap[foundStatusKey] || foundStatusKey;
      setActiveTab(targetTab);
      setGlobalSearchTargetTab(targetTab);
      setGlobalSearchTerm(trimmed);
      setGlobalSearchResults(null);
      setSearchInput(trimmed);
    } else {
      setGlobalSearchResults([]);
      setGlobalSearchTargetTab(null);
      setGlobalSearchTerm(trimmed);
      alert("No user found with that name or phone number");
    }
  };
  const handleOpenLoanModal = (loan) => {
    setSelectedLoan(loan);
    setLoanAmounts({
      requested_loan_amount: loan?.loan_amount || "",
      approved_loan_amount: loan?.approved_loan_amount || ""
    });
    setIsLoanModalOpen(true);
  };
  const updateLoanStatus = async (loan, newStatus) => {
    showConfirm({
      title: `${newStatus} Loan Request`,
      content: `Are you sure you want to change the status of this loan to ${newStatus}?`,
      onConfirm: async () => {
        try {
          await api.patch("/v1/admin/loans/approval-status", {
            id: loan._id,
            approval_status: newStatus,
            updated_by: getAdminId()
          });
          if (newStatus === "APPROVED") {
            await api.post(
              "/v1/admin/loan-documents",
              {
                loanId: loan._id,
                status: "Pending"
              },
              {
                headers: {
                  "Content-Type": "application/json"
                }
              }
            );
          }
          message.success(`Loan status updated to ${newStatus} successfully`);
          setReloadTrigger((prev) => prev + 1);
        } catch (error) {
          console.error("Error updating loan status:", error);
          message.error("Failed to update loan status");
        }
      }
    });
  };
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    borrower: "",
    loan_amount: "",
    applied_on: "",
    tenure: "",
    service_charges: "",
    document_charges: "",
    daily_payment_amount: "",
    note: "",
    referred_customer: "",
    referred_employee: "",
    referred_agent: "",
    referred_type: "",
    agent_approval_status: "approved",
    approval_status: "approved",
    source: "Chit-Admin"
  });
  const [errors, setErrors] = useState({});
  const [updateFormData, setUpdateFormData] = useState({
    borrower: "",
    loan_amount: "",
    applied_on: "",
    tenure: "",
    service_charges: "",
    document_charges: "",
    daily_payment_amount: "",
    note: "",
    referred_customer: "",
    referred_employee: "",
    referred_agent: "",
    referred_type: "",
    approval_status: "APPROVED"
  });
  const handleRemoveModalOpen = async (borrowerId) => {
    try {
      const response = await api.get(`/loans/get-borrower/${borrowerId}`);
      setCurrentBorrower(response.data);
      setRemoveReason("");
      setShowRemoveModal(true);
    } catch (error) {
      console.error("Error fetching borrower:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch borrower details",
        type: "error"
      });
    }
  };
  const handleRemoveBorrower = async () => {
    if (!removeReason || removeReason === "Other" && !customRemoveReason.trim()) {
      setAlertConfig({
        visibility: true,
        message: "Please select and specify removal reason",
        type: "warning"
      });
      return;
    }
    try {
      await api.patch(`/loans/${currentBorrower._id}/remove`, {
        removal_reason: removeReason === "Other" ? customRemoveReason : removeReason
      });
      setAlertConfig({
        visibility: true,
        message: "Loan removed successfully",
        type: "success"
      });
      setShowRemoveModal(false);
      setRemoveReason("");
      setCustomRemoveReason("");
      setCurrentBorrower(null);
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      console.error("Error removing loan:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to remove loan",
        type: "error"
      });
    }
  };
  const handleApprovalModalOpen = async (borrowerId, status) => {
    try {
      const response = await api.get(`/v1/admin/loans/${borrowerId}`);
      setCurrentBorrower(response.data);
      setApprovalStatus(status);
      setApprovalNote("");
      setShowApprovalModal(true);
    } catch (error) {
      console.error("Error fetching borrower:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch borrower details",
        type: "error"
      });
    }
  };
  const handleUpdateApprovalStatus = async (approvalStatus2) => {
    const loanId = isLoanUpdated ? currentUpdateBorrower?.data?._id : currentBorrower?.data?._id;
    if (!approvalStatus2) {
      setAlertConfig({
        visibility: true,
        message: "Please select an approval status",
        type: "warning"
      });
      return;
    }
    try {
      await api.patch(`/v1/admin/loans/approval-status`, {
        id: loanId,
        approval_status: approvalStatus2,
        updated_by: getAdminId()
      });
      message.success("Loan request status changed to Approved successfully");
      setAlertConfig({
        visibility: true,
        message: `Loan status updated to ${approvalStatus2}`,
        type: "success"
      });
      if (isLoanUpdated) {
        setIsLoanUpdated(false);
        setShowModalUpdate(false);
        setReloadTrigger((prev) => prev + 1);
      }
      setShowApprovalModal(false);
      setApprovalStatus("");
      setApprovalNote("");
      setCurrentBorrower(null);
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      console.error("Error updating approval status:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to update approval status",
        type: "error"
      });
    }
  };
  const generateAndOpenPDF = (downloadOnly = false, loanData) => {
    const colors = {
      primary: [0, 38, 124],
      textMain: [33, 33, 33]
    };
    const sections = [
      {
        title: "CUSTOMER DETAILS",
        fields: [
          { label: "Full Name", value: loanData?.borrower?.full_name },
          { label: "Phone Number", value: loanData?.borrower?.phone_number },
          { label: "Email Address", value: loanData?.borrower?.email },
          { label: "Address", value: loanData?.borrower?.address }
        ]
      },
      {
        title: "LOAN SUMMARY",
        fields: [
          { label: "Loan ID", value: loanData?.loan_id },
          { label: "Loan Amount", value: loanData?.loan_amount },
          {
            label: "Start Date",
            value: loanData?.start_date ? moment(loanData.start_date).format("DD-MM-YYYY") : "N/A"
          },
          { label: "Service Charges", value: loanData?.service_charges },
          {
            label: "End Date",
            value: loanData?.end_date ? moment(loanData.end_date).format("DD-MM-YYYY") : "N/A"
          },
          { label: "Documentation Charges", value: loanData?.document_charges },
          {
            label: "Sanction Date",
            value: loanData?.loan_sanction_date ? moment(loanData.loan_sanction_date).format("DD-MM-YYYY") : "N/A"
          },
          { label: "Daily Payment", value: loanData?.daily_payment_amount },
          { label: "Tenure (Days)", value: loanData?.tenure },
          {
            label: "Disbursement Amount",
            value: (Number(loanData?.loan_amount) || 0) - (Number(loanData?.service_charges) || 0) - (Number(loanData?.document_charges) || 0)
          }
        ]
      },
      {
        title: "REFERRAL INFORMATION",
        fields: [
          { label: "Referred Type", value: loanData?.referred_type },
          { label: "Referred By", value: loanData?.referred_employee?.name || loanData?.referred_agent?.name || loanData?.referred_customer?.full_name || "N/A" }
        ]
      }
    ];
    const doc = new jsPDF("p", "mm", "a4");
    const safeText = (v) => v ? String(v) : "N/A";
    let y = 65;
    if (imageInput) {
      doc.addImage(imageInput, "PNG", 90, 8, 30, 30);
    }
    const loanId = loanData?.loan_id || "N/A";
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    const valueWidth = doc.getTextWidth(loanId);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    const labelWidth = doc.getTextWidth("Loan ID: ");
    const gap = 4;
    const startX = 195 - valueWidth - gap - labelWidth;
    doc.text("Loan ID: ", startX, 20, { align: "left" });
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(...colors.primary);
    doc.text(loanId, startX + labelWidth + gap, 20, { align: "left" });
    doc.setFillColor(0, 38, 124);
    doc.rect(0, 40, 210, 15, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.text("LOAN SANCTION CERTIFICATE", 105, 49, { align: "center" });
    const drawField = (label, value, x, y2) => {
      const boxWidth = 85;
      const labelWidth2 = 38;
      const valueWidth2 = boxWidth - labelWidth2 - 4;
      const valueStr = safeText(value);
      const lines = doc.splitTextToSize(valueStr, valueWidth2);
      const lineHeight = 4;
      const textHeight = lines.length * lineHeight;
      const boxHeight = Math.max(8, textHeight + 4);
      doc.setDrawColor(220, 224, 230);
      doc.rect(x, y2, boxWidth, boxHeight);
      doc.setTextColor(0, 38, 124);
      doc.setFontSize(9);
      doc.text(label + ":", x + 2, y2 + 5);
      doc.setTextColor(33, 33, 33);
      let textY = y2 + 5;
      lines.forEach((line) => {
        doc.text(line, x + labelWidth2 + 2, textY);
        textY += lineHeight;
      });
      return y2 + boxHeight + 5;
    };
    sections.forEach((sec) => {
      doc.setFillColor(0, 38, 124);
      doc.rect(15, y, 180, 10, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(14);
      doc.text(sec.title, 105, y + 7, { align: "center" });
      y += 15;
      for (let i = 0; i < sec.fields.length; i += 2) {
        const leftField = sec.fields[i];
        const rightField = sec.fields[i + 1];
        const startY = y;
        const leftY = drawField(leftField.label, leftField.value, 15, startY);
        let rightY = startY;
        if (rightField) {
          rightY = drawField(rightField.label, rightField.value, 110, startY);
        }
        y = Math.max(leftY, rightY);
      }
      y += 5;
    });
    doc.setFontSize(10);
    doc.text("I hereby declare that the above loan information is true and correct.", 105, y + 10, { align: "center" });
    doc.rect(80, y + 20, 50, 20);
    doc.text("Customer Signature", 105, y + 33, { align: "center" });
    const pageHeight = doc.internal.pageSize.getHeight();
    const footerY = pageHeight - 17;
    doc.setFillColor(0, 38, 124);
    doc.rect(0, footerY, 210, 20, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.text("VIJAYA VINAYAK CHIT FUNDS PRIVATE LIMITED", 105, footerY + 5, { align: "center" });
    doc.text("#11/36-25, 3rd Floor, 2nd Main, Kathriguppe Main Road, Banashankari 3rd Stage, Bengaluru-560085", 105, footerY + 9, { align: "center" });
    doc.text("Mob: 9483900777 | Ph: 080-4979 8763 | Email: info.mychits@gmail.com | www.mychits.co.in", 105, footerY + 13, { align: "center" });
    if (downloadOnly) {
      doc.save(`${loanData?.borrower?.full_name || "Loan"}_Sanction.pdf`);
    } else {
      const pdfBlob = doc.output("blob");
      const pdfUrl = URL.createObjectURL(pdfBlob);
      window.open(pdfUrl, "_blank");
    }
  };
  useEffect(() => {
    const borrowerId = updateFormData.borrower;
    if (!borrowerId) return;
    const selectedUser2 = users.find((user) => user._id === borrowerId);
    if (!selectedUser2) return;
    const refType = selectedUser2.referral_type || "Self Joining";
    setUpdateFormData((prev) => ({
      ...prev,
      referred_type: refType,
      referred_employee: "",
      referred_agent: "",
      referred_customer: ""
    }));
    if (refType === "Employee" && selectedUser2.referred_employee?._id) {
      setUpdateFormData((prev) => ({
        ...prev,
        referred_employee: selectedUser2.referred_employee._id
      }));
    } else if (refType === "Agent" && selectedUser2.referred_agent?._id) {
      setUpdateFormData((prev) => ({
        ...prev,
        referred_agent: selectedUser2.referred_agent._id
      }));
    } else if (refType === "Customer" && selectedUser2.referred_customer?._id) {
      setUpdateFormData((prev) => ({
        ...prev,
        referred_customer: selectedUser2.referred_customer._id
      }));
    }
  }, [updateFormData.borrower, users]);
  useEffect(() => {
    const fetchAllLoans = async () => {
      try {
        const statuses = ["REQUESTED", "ACCEPTED", "PENDING", "APPROVED", "REJECTED", "COMPLETED", "UNKNOWN"];
        const promises = statuses.map((status) => api.get(`/v1/admin/loans?approval_status=${status}`));
        const responses = await Promise.all(promises);
        const result = {};
        statuses.forEach((status, idx) => {
          const key = status.toLowerCase();
          result[key] = responses[idx].data.data || [];
        });
        const closedRes = await api.get("/v1/admin/loans/closed");
        result.closed = closedRes.data.data || [];
        setAllLoans(result);
        setAllLoansLoaded(true);
      } catch (error) {
        console.error("Failed to pre‑fetch all loans", error);
      }
    };
    fetchAllLoans();
  }, []);
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await api.get("/user/get-user");
        if (response.status >= 400) throw new Error("Failed to fetch borrowers");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching Loans Borrower Data:", error);
      }
    };
    fetchCustomers();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get("/agent/get");
        setAgents(response.data?.agent);
      } catch (err) {
        console.error("Failed to fetch Leads", err);
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await api.get("/agent/get-employee");
        setEmployees(response?.data?.employee || []);
      } catch (error) {
        console.error("failed to fetch employees", error);
      }
    };
    fetchEmployees();
  }, []);
  const handlePrint = async (loanPrintId) => {
    try {
      const res = await api.get(`/loans/get-borrower/${loanPrintId}`);
      generateAndOpenPDF(false, res.data);
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Failed to generate PDF",
        type: "error"
      });
    }
  };
  const handlePenaltyModalOpen = (borrower) => {
    setPenaltyLoan(borrower);
    setPenaltyCharges([{ amount: "", reason: "" }]);
    setShowPenaltyModal(true);
  };
  const handleAddPenaltyRow = () => {
    setPenaltyCharges((prev) => [...prev, { amount: "", reason: "" }]);
  };
  const handleRemovePenaltyRow = (index) => {
    setPenaltyCharges((prev) => prev.filter((_, i) => i !== index));
  };
  const handlePenaltyChange = (index, field, value) => {
    setPenaltyCharges(
      (prev) => prev.map((row, i) => i === index ? { ...row, [field]: value } : row)
    );
  };
  const handlePenaltySubmit = async () => {
    const invalid = penaltyCharges.some((c) => !c.amount || !c.reason.trim());
    if (invalid) {
      message.warning("Please fill in all amount and reason fields");
      return;
    }
    setPenaltyLoading(true);
    try {
      const existingCharges = penaltyLoan?.extra_charges || [];
      const newCharges = penaltyCharges.map((c) => ({
        amount: Number(c.amount),
        reason: c.reason.trim(),
        paid: false
      }));
      await api.put(`/v1/admin/loans/loan/${penaltyLoan?._id}`, {
        extra_charges: [...existingCharges, ...newCharges]
        // ...updateFormData,
      });
      message.success("Penalty charges added successfully");
      setShowPenaltyModal(false);
      setPenaltyLoan(null);
      setPenaltyCharges([{ amount: "", reason: "" }]);
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      console.error(error);
      message.error("Failed to add penalty charges");
    } finally {
      setPenaltyLoading(false);
    }
  };
  useEffect(() => {
    const fetchLoanCounts = async () => {
      setSummaryLoading(true);
      try {
        const [requestsRes, closedLoansRes] = await Promise.all(
          [
            api.get("/v1/admin/loans/overview"),
            api.get("/v1/admin/loans/closed")
          ]
        );
        const data = requestsRes.data?.data || [];
        const formatted = data.reduce((acc, item) => {
          acc[item.status] = item.count;
          return acc;
        }, {});
        setSummaryData(data);
        setTotals({
          totalRequests: formatted.REQUESTED || 0,
          totalAccepted: formatted.ACCEPTED || 0,
          totalPending: formatted.PENDING || 0,
          totalApproved: formatted.APPROVED || 0,
          totalRejected: formatted.REJECTED || 0,
          totalCompleted: formatted.COMPLETED || 0,
          totalClosed: closedLoansRes?.data?.data?.length || 0,
          totalUnknown: formatted.UNKNOWN || 0
        });
      } catch (error) {
        console.error("Error fetching loan counts:", error);
      } finally {
        setSummaryLoading(false);
      }
    };
    fetchLoanCounts();
  }, [reloadTrigger]);
  const getStatusOptionsForTab = (tab) => {
    const commonOptions = {
      ACCEPTED: { label: "Accept", value: "ACCEPTED", icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 928,
        columnNumber: 61
      }, this), className: "bg-green-700 text-white hover:bg-green-800" },
      PENDING: { label: "Pending", value: "PENDING", icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 929,
        columnNumber: 60
      }, this), className: "border-yellow-400 text-yellow-600 hover:bg-yellow-50" },
      REJECTED: { label: "Reject", value: "REJECTED", icon: /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 930,
        columnNumber: 61
      }, this), className: "border-red-400 text-red-600 hover:bg-red-50" },
      UNKNOWN: { label: "Unknown", value: "UNKNOWN", icon: /* @__PURE__ */ jsxDEV(QuestionCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 931,
        columnNumber: 60
      }, this), className: "border-yellow-400 text-yellow-600 hover:bg-yellow-50" },
      REQUESTED: { label: "Requested", value: "REQUESTED", icon: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 932,
        columnNumber: 66
      }, this), className: "border-blue-400 text-blue-600 hover:bg-blue-50" },
      APPROVED: { label: "Approve", value: "APPROVED", icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 933,
        columnNumber: 62
      }, this), className: "bg-indigo-600 text-white hover:bg-indigo-700" }
    };
    const optionsMap = {
      requests: ["ACCEPTED", "PENDING", "REJECTED", "UNKNOWN"],
      accepted: ["REQUESTED", "PENDING", "REJECTED", "UNKNOWN", "APPROVED"],
      pending: [
        // "REQUESTED", "ACCEPTED", 
        "REJECTED",
        "APPROVED",
        "UNKNOWN"
      ],
      approved: ["REQUESTED", "ACCEPTED", "PENDING", "REJECTED", "UNKNOWN"],
      rejected: ["REQUESTED", "ACCEPTED", "PENDING", "UNKNOWN"],
      unknown: ["REQUESTED", "ACCEPTED", "PENDING", "REJECTED"]
    };
    const keys = optionsMap[tab] || optionsMap.pending;
    return keys.map((key) => commonOptions[key]);
  };
  useEffect(() => {
    const fetchBorrowers = async () => {
      try {
        setIsLoading(true);
        setFetchError(false);
        let response;
        const routeMap = {
          requests: "/?approval_status=REQUESTED",
          accepted: "/?approval_status=ACCEPTED",
          pending: "/?approval_status=PENDING",
          approved: "/?approval_status=APPROVED",
          rejected: "/?approval_status=REJECTED",
          completed: "/?approval_status=COMPLETED",
          closed: "/closed",
          unknown: "/?approval_status=UNKNOWN"
        };
        const route = routeMap[activeTab] || "PENDING";
        response = await api.get(`/v1/admin/loans${route}`);
        const apiData = response.data?.data || [];
        setBorrowers(apiData);
        let tableData = response.data?.data || [];
        if (activeTab === "requests") {
          tableData = tableData.slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        }
        const getFormattedLoanId = (originalLoanId, currentTab) => {
          if (!originalLoanId) return "N/A";
          const match = originalLoanId.match(/\d+/);
          const numberPart = match ? match[0] : "";
          const tabsWithRQLN = ["requests", "accepted", "pending", "unknown", "rejected"];
          const prefix = tabsWithRQLN.includes(currentTab) ? "RQLN" : "LN";
          return numberPart ? `${prefix}${numberPart}` : originalLoanId;
        };
        const formattedData = tableData?.map((borrower, index) => {
          const getUserId = (loan) => {
            return loan.user_id?._id || loan.borrower?._id || null;
          };
          const buildReferredBy = (loanItem) => {
            const borrowerData = loanItem?.borrower || {};
            const refType = loanItem?.referred_type || borrowerData?.referral_type || "";
            console.log("refType", refType);
            console.log("Full loanItem:", loanItem);
            const renderCell = (children) => /* @__PURE__ */ jsxDEV("div", { className: "min-w-[180px] whitespace-normal", children }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1001,
              columnNumber: 13
            }, this);
            const getReferredData = (type) => {
              const rootRef = loanItem[`referred_${type}`];
              const borrowerRef = borrowerData[`referred_${type}`];
              return rootRef || borrowerRef || null;
            };
            if (refType === "Agent") {
              const agent = getReferredData("agent");
              const name = agent?.name || "N/A";
              const phone = agent?.phone_number || agent?.phone || "-";
              return renderCell(
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col text-sm", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Agent" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1023,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900", children: name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1024,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: phone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1025,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 1022,
                  columnNumber: 17
                }, this)
              );
            } else if (refType === "Customer") {
              const customer = getReferredData("customer");
              const name = customer?.full_name || "N/A";
              const phone = customer?.phone_number || customer?.phone || "-";
              return renderCell(
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col text-sm", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Customer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1035,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900", children: name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1036,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: phone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1037,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 1034,
                  columnNumber: 17
                }, this)
              );
            } else if (refType === "Employee") {
              const employee = getReferredData("employee");
              console.log("Employee data found:", employee);
              const name = employee?.name || "N/A";
              const phone = employee?.phone_number || employee?.phone || "-";
              const empCode = employee?.employeeCode || employee?.unique_code || "";
              return renderCell(
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col text-sm", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Employee" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1051,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900", children: name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1052,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: [
                    phone !== "-" ? phone : "",
                    empCode && phone !== "-" ? " | " : "",
                    empCode || ""
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1053,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 1050,
                  columnNumber: 17
                }, this)
              );
            } else if (refType === "Self Joining") {
              return renderCell(
                /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-700", children: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Self Joining" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 1064,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 1063,
                  columnNumber: 17
                }, this)
              );
            }
            const fallbackEmployee = getReferredData("employee");
            if (fallbackEmployee) {
              const name = fallbackEmployee?.name || "N/A";
              const phone = fallbackEmployee?.phone_number || fallbackEmployee?.phone || "-";
              return renderCell(
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col text-sm", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Employee (Direct)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1076,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900", children: name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1077,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: phone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1078,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 1075,
                  columnNumber: 17
                }, this)
              );
            }
            return renderCell(/* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-400", children: "N/A" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1083,
              columnNumber: 31
            }, this));
          };
          const statusOptions2 = getStatusOptionsForTab(activeTab);
          const popoverContent = /* @__PURE__ */ jsxDEV("div", { className: "w-40 bg-white rounded-lg shadow-md p-2 space-y-2", children: statusOptions2.map(
            (opt) => /* @__PURE__ */ jsxDEV(
              Button,
              {
                icon: opt.icon,
                className: `flex items-center justify-start w-full ${opt.className}`,
                onClick: () => updateLoanStatus(borrower, opt.value),
                children: opt.label
              },
              opt.value,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1090,
                columnNumber: 13
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1088,
            columnNumber: 11
          }, this);
          const actionDropdown = /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  ...activeTab !== "completed" && activeTab !== "closed" ? [
                    { key: "1", label: /* @__PURE__ */ jsxDEV("div", { className: "text-green-600", onClick: () => handleUpdateModalOpen(borrower._id), children: "Edit" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 1108,
                      columnNumber: 37
                    }, this) },
                    {
                      key: "5",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-cyan-600",
                          onClick: () => {
                            const userId = borrower.user_id?._id || borrower.borrower?._id;
                            if (userId) {
                              handleViewTransactions(userId);
                            } else {
                              message.warning("No customer ID found for this loan");
                            }
                          },
                          children: "View Transactions"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                          lineNumber: 1111,
                          columnNumber: 19
                        },
                        this
                      )
                    }
                  ] : [],
                  ...activeTab !== "completed" && activeTab !== "closed" ? [{ key: "2", label: /* @__PURE__ */ jsxDEV(Popover, { placement: "rightTop", trigger: "hover", content: popoverContent, children: /* @__PURE__ */ jsxDEV("div", { className: "text-blue-600 cursor-pointer", children: "Update Status" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1129,
                    columnNumber: 108
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1129,
                    columnNumber: 37
                  }, this) }] : [],
                  ...activeTab === "requests" ? [{
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "flex items-center gap-2 cursor-pointer",
                        onClick: () => {
                          if (borrower?.agent_approval_status === "PENDING" || borrower?.agent_approval_status === "REJECTED") {
                            message.warning("Loan amount cannot be edited as agent approval is pending or rejected");
                          } else {
                            handleOpenLoanModal(borrower);
                          }
                        },
                        children: [
                          /* @__PURE__ */ jsxDEV(FaEdit, { className: "text-blue-500", title: "Edit Loan Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                            lineNumber: 1146,
                            columnNumber: 29
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-blue-600 text-[11px]", children: "Loan Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                            lineNumber: 1147,
                            columnNumber: 29
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 1136,
                        columnNumber: 19
                      },
                      this
                    )
                  }] : [],
                  ...activeTab === "approved" || activeTab === "completed" || activeTab === "closed" ? [{ key: "6", label: /* @__PURE__ */ jsxDEV("div", { className: "text-purple-600", onClick: () => handlePrint(borrower._id), children: "Print" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1153,
                    columnNumber: 37
                  }, this) }] : [],
                  ...activeTab === "completed" ? [{ key: "7", label: /* @__PURE__ */ jsxDEV("div", { className: "text-orange-600", onClick: () => handlePenaltyModalOpen(borrower), children: "View Penalty" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 1156,
                    columnNumber: 37
                  }, this) }] : [],
                  ...activeTab === "approved" ? [
                    {
                      key: "payment",
                      label: /* @__PURE__ */ jsxDEV("span", { className: "text-green-600 flex items-center gap-1", children: [
                        /* @__PURE__ */ jsxDEV(BiRupee, { className: "text-base" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                          lineNumber: 1165,
                          columnNumber: 31
                        }, this),
                        "Make Payment"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 1164,
                        columnNumber: 19
                      }, this),
                      onClick: () => {
                        navigate(
                          `/payment-menu/payment-in-out-menu/pay-out-menu/loan-payout?loanId=${borrower._id}`
                        );
                      }
                    }
                  ] : []
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1183,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1103,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1102,
            columnNumber: 11
          }, this);
          const agentStatus = borrower?.agent_approval_status;
          let agentBadge = null;
          let approvedDate = borrower?.agent_approval_status_updated_at ? new Date(borrower.agent_approval_status_updated_at).toLocaleDateString("en-IN") : " ";
          const approvedAmount = borrower?.approved_loan_amount ? `₹${borrower.approved_loan_amount.toLocaleString()}` : null;
          const remark = borrower?.employee_remark || "No remark provided";
          const borrowerUserId = borrower?.user_id?._id || borrower?.borrower?._id;
          const tooltipContent = /* @__PURE__ */ jsxDEV("div", { className: "text-xs space-y-1", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              "✅ Agent: ",
              borrower?.borrower?.referred_employee?.name || borrower?.borrower?.referred_customer?.full_name || borrower?.borrower?.referred_agent?.name || "Self Joining"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1202,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              "✅ Agent Replied on: ",
              approvedDate
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1203,
              columnNumber: 15
            }, this),
            approvedAmount && /* @__PURE__ */ jsxDEV("div", { children: [
              "💰 Approved Amount: ",
              approvedAmount
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1204,
              columnNumber: 34
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              "📝 Remark: ",
              remark
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1205,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1201,
            columnNumber: 11
          }, this);
          if (agentStatus === "APPROVED") {
            agentBadge = /* @__PURE__ */ jsxDEV(Tooltip, { title: tooltipContent, overlayClassName: "max-w-xs", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-sm whitespace-nowrap flex-shrink-0", children: [
              /* @__PURE__ */ jsxDEV(FaThumbsUp, { className: "w-2.5 h-2.5" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1213,
                columnNumber: 19
              }, this),
              " Agent Approved",
              /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-white text-[8px] opacity-80" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1214,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1212,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1211,
              columnNumber: 13
            }, this);
          } else if (agentStatus === "REJECTED") {
            agentBadge = /* @__PURE__ */ jsxDEV(Tooltip, { title: tooltipContent, overlayClassName: "max-w-xs", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-sm whitespace-nowrap flex-shrink-0", children: [
              /* @__PURE__ */ jsxDEV(FaTimesCircle, { className: "w-2.5 h-2.5" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1222,
                columnNumber: 19
              }, this),
              " Agent Rejected",
              /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-white text-[8px] opacity-80" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1223,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1221,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1220,
              columnNumber: 13
            }, this);
          } else if (agentStatus === "PENDING") {
            agentBadge = /* @__PURE__ */ jsxDEV(Tooltip, { title: tooltipContent, overlayClassName: "max-w-xs", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-gradient-to-r from-amber-400 to-orange-500 text-white shadow-sm whitespace-nowrap flex-shrink-0", children: [
              /* @__PURE__ */ jsxDEV(FaHourglassHalf, { className: "w-2.5 h-2.5" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1231,
                columnNumber: 19
              }, this),
              " Agent Pending",
              /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-white text-[8px] opacity-80" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1232,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1230,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1229,
              columnNumber: 13
            }, this);
          }
          let customerName = /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 group min-w-[220px]", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-900", children: borrower?.user_id?.full_name || borrower?.user?.full_name || borrower?.borrower?.full_name || "Unknown" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1240,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: async (e) => {
                  e.stopPropagation();
                  if (!borrowerUserId) {
                    message.warning("No customer ID found for this loan");
                    return;
                  }
                  setLoadingCustomerId(borrowerUserId);
                  try {
                    const hide = message.loading("Loading transactions...", 0);
                    await handleViewTransactions(borrowerUserId);
                    hide();
                  } catch (err) {
                  } finally {
                    setLoadingCustomerId(null);
                  }
                },
                className: "p-1 rounded-full hover:bg-gray-200 transition",
                title: "View Transactions",
                disabled: loadingCustomerId === borrowerUserId,
                children: loadingCustomerId === borrowerUserId ? /* @__PURE__ */ jsxDEV(AiOutlineLoading3Quarters, { className: "w-4 h-4 text-blue-500 animate-spin" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 1268,
                  columnNumber: 15
                }, this) : /* @__PURE__ */ jsxDEV(FiEye, { className: "w-4 h-4 text-gray-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 1270,
                  columnNumber: 15
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1244,
                columnNumber: 15
              },
              this
            ),
            agentBadge && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: agentBadge }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1275,
              columnNumber: 13
            }, this),
            !agentBadge && /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: `text-xs font-bold px-1.5 py-1 rounded-full shadow-sm transition-all duration-200 ${borrower?.user_id?.referral_type === "Self Joining" ? "bg-emerald-100 text-emerald-700 ring-1 ring-inset ring-emerald-200 group-hover:bg-emerald-200" : "bg-slate-100 text-violet-800 ring-1 ring-inset ring-slate-200 group-hover:bg-slate-200"}`,
                title: borrower?.user_id?.referral_type === "Self Joining" ? "This customer joined without a referral." : "This customer was referred by an existing source.",
                children: borrower?.user_id?.referral_type === "Self Joining" ? "New" : "Existing"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1279,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1239,
            columnNumber: 11
          }, this);
          let LoanAmount = /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 group", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: activeTab === "requested" ? borrower?.requested_loan_amount : borrower?.loan_amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1297,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              FaEdit,
              {
                onClick: () => {
                  handleOpenLoanModal(borrower);
                },
                className: "text-blue-500 cursor-pointer",
                title: "Edit Loan Amount"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1301,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1296,
            columnNumber: 11
          }, this);
          let adminApproved = /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1319,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-800 text-sm sm:text-base font-mono", children: [
                "₹",
                borrower?.approved_loan_amount?.toLocaleString("en-IN") || "-"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1320,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1318,
              columnNumber: 15
            }, this),
            borrower?.approved_loan_amount && borrower?.approved_loan_amount_status && /* @__PURE__ */ jsxDEV("span", { className: `
        inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wide border shadow-sm whitespace-nowrap
        transition-colors duration-200
        ${borrower?.approved_loan_amount_status === "APPROVED" ? "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100" : borrower?.approved_loan_amount_status === "REJECTED" ? "bg-red-50 text-red-700 border-red-200 hover:bg-red-100" : "bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100"}
      `, children: [
              borrower?.approved_loan_amount_status === "APPROVED" && /* @__PURE__ */ jsxDEV(FaThumbsUp, { className: "w-3 h-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1337,
                columnNumber: 76
              }, this),
              borrower?.approved_loan_amount_status === "REJECTED" && /* @__PURE__ */ jsxDEV(FaTimesCircle, { className: "w-3 h-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1338,
                columnNumber: 76
              }, this),
              borrower?.approved_loan_amount_status === "PENDING" && /* @__PURE__ */ jsxDEV(FaHourglassHalf, { className: "w-3 h-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1339,
                columnNumber: 75
              }, this),
              borrower?.approved_loan_amount_status === "APPROVED" ? "Customer Accepted" : borrower?.approved_loan_amount_status === "REJECTED" ? "Customer Rejected" : "Customer Side Pending"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1327,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1316,
            columnNumber: 11
          }, this);
          if (activeTab === "requests") {
            return {
              _id: borrower._id,
              id: index + 1,
              _searchName: borrower?.user_id?.full_name || borrower?.user?.full_name || borrower?.borrower?.full_name || "Unknown",
              loan_id: getFormattedLoanId(borrower?.loan_id, activeTab),
              customer_name: customerName,
              phone_number: borrower?.user_id?.phone_number || borrower?.borrower?.phone_number || "-",
              referred_by: buildReferredBy(borrower),
              admin_approved_amount: adminApproved,
              employee_approved_amount: borrower?.employee_approved_amount || "-",
              employee_remark: borrower?.employee_remark || "-",
              address: borrower?.user_id?.address || "-",
              loan_amount: LoanAmount,
              loan_purpose: borrower?.loan_purpose,
              createdAt: borrower?.createdAt ? new Date(borrower.createdAt).toLocaleDateString("en-IN") : "-",
              createdBy: [
                borrower?.created_by ? `${borrower.created_by.name}` : null,
                borrower?.updated_by ? `Updated: ${borrower.updated_by.name}` : null,
                borrower?.source
              ].filter(Boolean).join(" | ") || "-",
              approval_status: /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-3 py-1 text-sm font-medium text-yellow-800 bg-yellow-100 rounded-full", children: "Requested" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1381,
                columnNumber: 32
              }, this),
              action: actionDropdown
            };
          }
          if (activeTab === "unknown") {
            return {
              id: index + 1,
              _searchName: borrower?.user_id?.full_name || borrower?.user?.full_name || borrower?.borrower?.full_name || "Unknown",
              _id: borrower._id,
              loan_id: getFormattedLoanId(borrower?.loan_id, activeTab),
              referred_by: buildReferredBy(borrower),
              employee_remark: borrower?.employee_remark || "-",
              full_name: customerName || "Unknown",
              phone_number: borrower?.user_id?.phone_number || borrower?.borrower?.phone_number || "-",
              address: borrower?.user_id?.address || borrower?.borrower?.address || "-",
              // loan_amount: borrower?.loan_amount,
              loan_amount: LoanAmount,
              admin_approved_amount: adminApproved,
              employee_approved_amount: borrower?.employee_approved_amount || "-",
              loan_purpose: borrower?.loan_purpose,
              createdBy: borrower?.created_by ? [
                borrower.created_by.name,
                borrower.created_by.admin_name && `(${borrower.created_by.admin_name})`
              ].filter(Boolean).join(" ") : "-",
              createdAt: borrower?.createdAt ? new Date(borrower.createdAt).toLocaleDateString("en-IN") : "-",
              action: actionDropdown
            };
          }
          return {
            _id: borrower._id,
            id: index + 1,
            loan_id: getFormattedLoanId(borrower?.loan_id, activeTab),
            _searchName: borrower?.user_id?.full_name || borrower?.user?.full_name || borrower?.borrower?.full_name || "Unknown",
            createdAt: borrower?.createdAt ? new Date(borrower.createdAt).toLocaleDateString("en-IN") : "-",
            createdBy: borrower?.created_by ? [
              borrower.created_by.name,
              borrower.created_by.admin_name && `(${borrower.created_by.admin_name})`
            ].filter(Boolean).join(" ") : "-",
            borrower_name: activeTab === "completed" || activeTab === "closed" ? borrower?.borrower?.full_name : customerName,
            date: borrower?.createdAt,
            phone_number: borrower?.user_id?.phone_number || borrower?.borrower?.phone_number || "-",
            loan_amount: activeTab === "completed" || activeTab === "closed" ? borrower?.loan_amount : LoanAmount,
            tenure: borrower?.tenure,
            service_charges: borrower?.service_charges,
            loan_sanction_date: borrower?.loan_sanction_date?.split("T")[0],
            document_charges: borrower?.document_charges,
            daily_payment_amount: borrower?.daily_payment_amount,
            start_date: borrower?.start_date?.split("T")[0],
            end_date: borrower?.end_date?.split("T")[0],
            note: borrower?.note,
            referred_type: borrower?.referred_type,
            admin_approved_amount: adminApproved,
            employee_approved_amount: borrower?.employee_approved_amount || "-",
            employee_remark: borrower?.employee_remark || "-",
            approval_status: borrower?.approval_status || "PENDING",
            extra_charges_display: (() => {
              const charges = borrower?.extra_charges || [];
              if (charges.length === 0) return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-xs", children: "None" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1450,
                columnNumber: 48
              }, this);
              const totalOutstanding = charges.reduce((sum, c) => {
                if (c.paid === true) return sum;
                if (c.balance_amount !== void 0) return sum + Number(c.balance_amount);
                const paid = Number(c.paid_amount || 0);
                const amount = Number(c.amount || 0);
                return sum + (amount - paid);
              }, 0);
              return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1", children: [
                "Outstanding: ₹",
                totalOutstanding.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 1460,
                columnNumber: 17
              }, this);
            })(),
            referred_by: buildReferredBy(borrower),
            action: actionDropdown
          };
        });
        setTableBorrowers(formattedData);
        if (!response.data?.data || response.data?.data.length === 0) setFetchError(true);
      } catch (error) {
        console.error("Error fetching loan data:", error);
        setFetchError(true);
        setTableBorrowers([]);
        setAlertConfig({ visibility: true, message: "Failed to fetch loan data. Please try again.", type: "error" });
      } finally {
        setIsLoading(false);
      }
    };
    fetchBorrowers();
  }, [reloadTrigger, activeTab]);
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
    if (field === "borrower" && value) {
      const selectedUser2 = users.find((user) => user._id === value);
      if (selectedUser2) {
        const refType = selectedUser2.referral_type || "Self Joining";
        setFormData((prev) => ({
          ...prev,
          referred_type: refType,
          // Reset referral specific fields
          referred_employee: "",
          referred_agent: "",
          referred_customer: ""
        }));
        if (refType === "Employee" && selectedUser2.referred_employee?._id) {
          setFormData((prev) => ({
            ...prev,
            referred_employee: selectedUser2.referred_employee._id
          }));
        } else if (refType === "Agent" && selectedUser2.referred_agent?._id) {
          setFormData((prev) => ({
            ...prev,
            referred_agent: selectedUser2.referred_agent._id
          }));
        } else if (refType === "Customer" && selectedUser2.referred_customer?._id) {
          setFormData((prev) => ({
            ...prev,
            referred_customer: selectedUser2.referred_customer._id
          }));
        }
      }
    }
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [field]: "" }));
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    const updatedForm = { ...formData, [name]: value };
    setFormData(updatedForm);
    setErrors((prev) => ({ ...prev, [name]: "" }));
    const sanctionDate = new Date(updatedForm.loan_sanction_date);
    const startDate = new Date(updatedForm.start_date);
    if (updatedForm.loan_sanction_date && updatedForm.start_date && startDate < sanctionDate) {
      setAlertConfig({
        visibility: true,
        message: "Start date should be greater than sanction date",
        type: "error"
      });
    }
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addBorrower" ? formData : updateFormData;
    if (!data.borrower) newErrors.borrower = "Borrower Name is required";
    if (!data.loan_amount || isNaN(data.loan_amount) || data.loan_amount <= 0)
      newErrors.loan_amount = "Loan Amount must be a positive number";
    if (!data.tenure || isNaN(data.tenure) || data.tenure <= 0)
      newErrors.tenure = "Tenure must be a positive number";
    if (!data.service_charges) newErrors.service_charges = "service charges is required";
    if (!data.daily_payment_amount) newErrors.daily_payment_amount = "Daily payment amount is required";
    if (!data.document_charges) newErrors.document_charges = "Document Charges is Required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  useEffect(() => {
    if (formData.loan_amount) {
      const amount = Number(formData.loan_amount);
      const tenure = Number(formData.tenure);
      setFormData((prev) => ({
        ...prev,
        service_charges: (amount * 0.1).toFixed(0),
        document_charges: (amount * 0.01).toFixed(0),
        ...tenure > 0 && { daily_payment_amount: (amount / tenure).toFixed(0) }
      }));
    } else {
      setFormData((prev) => ({ ...prev, service_charges: "", document_charges: "", daily_payment_amount: "" }));
    }
  }, [formData.loan_amount, formData.tenure]);
  useEffect(() => {
    if (updateFormData.loan_amount) {
      const amount = Number(updateFormData.loan_amount);
      const tenure = Number(updateFormData.tenure);
      setUpdateFormData((prev) => ({
        ...prev,
        service_charges: (amount * 0.1).toFixed(0),
        document_charges: (amount * 0.01).toFixed(0),
        ...tenure > 0 && { daily_payment_amount: (amount / tenure).toFixed(0) }
      }));
    } else {
      setUpdateFormData((prev) => ({ ...prev, service_charges: "", document_charges: "", daily_payment_amount: "" }));
    }
  }, [updateFormData.loan_amount, updateFormData.tenure]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm("addBorrower");
    if (!isValid) return;
    try {
      const response = await api.post(
        "/v1/admin/loans",
        {
          ...formData,
          created_by: getAdminId()
        },
        {
          headers: {
            "Content-Type": "application/json"
          }
        }
      );
      const loanId = response?.data?.data?._id || response?.data?.loan?._id || response?.data?._id;
      if (loanId) {
        await api.post(
          "/v1/admin/loan-documents",
          {
            loanId,
            status: "Pending"
          },
          {
            headers: {
              "Content-Type": "application/json"
            }
          }
        );
      }
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Borrower Added Successfully",
        type: "success"
      });
      setShowModal(false);
      setFormData({
        borrower: "",
        loan_amount: "",
        tenure: "",
        service_charges: "",
        document_charges: "",
        daily_payment_amount: "",
        note: "",
        referred_customer: "",
        referred_employee: "",
        referred_agent: "",
        referred_type: ""
      });
    } catch (error) {
      console.error("Error adding Borrower:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to add borrower",
        type: "error"
      });
    }
  };
  const handleDeleteModalOpen = async (borrowerId) => {
    try {
      const response = await api.get(`loans/get-borrower/${borrowerId}`);
      setCurrentBorrower(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Borrowers:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch borrower details",
        type: "error"
      });
    }
  };
  const handleUpdateModalOpen = async (borrowerId) => {
    try {
      const response = await api.get(`/loans/get-borrower/${borrowerId}`);
      const borrowerData = response.data;
      const formattedStartDate = borrowerData?.start_date?.split("T")[0];
      const formattedEndDate = borrowerData?.end_date?.split("T")[0];
      const formattedSanctionDate = borrowerData?.loan_sanction_date?.split("T")[0];
      setCurrentUpdateBorrower(response.data);
      setUpdateFormData({
        borrower: response?.data?.borrower._id,
        loan_amount: response?.data?.loan_amount,
        applied_on: response?.data?.createdAt,
        tenure: response?.data?.tenure,
        service_charges: response?.data?.service_charges,
        document_charges: response?.data?.document_charges,
        loan_sanction_date: formattedSanctionDate,
        daily_payment_amount: response?.data?.daily_payment_amount,
        start_date: formattedStartDate,
        end_date: formattedEndDate,
        note: response?.data?.note,
        referred_employee: response?.data?.referred_employee?._id || "",
        referred_customer: response?.data?.referred_customer?._id || "",
        referred_agent: response?.data?.referred_agent?._id || "",
        referred_type: response?.data?.referred_type || "",
        approval_status: response?.data?.approval_status || "APPROVED"
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching group:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch borrower details",
        type: "error"
      });
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({ ...prevData, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const handleDeleteBorrower = async () => {
    if (currentBorrower) {
      try {
        await api.delete(`/loans/delete-borrower/${currentBorrower._id}`);
        setAlertConfig({
          message: "Borrower deleted successfully",
          type: "success",
          visibility: true
        });
        setReloadTrigger((prev) => prev + 1);
        setShowModalDelete(false);
        setCurrentBorrower(null);
      } catch (error) {
        console.error("Error deleting Loan Borrower:", error);
        setAlertConfig({
          visibility: true,
          message: "Failed to delete borrower",
          type: "error"
        });
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (!isValid) {
      return;
    }
    try {
      await api.put(`/v1/admin/loans/${currentUpdateBorrower._id}`, {
        ...updateFormData,
        updated_by: getAdminId()
        // ✅
      });
      setAlertConfig({
        message: "Borrower updated successfully",
        type: "success",
        visibility: true
      });
      setIsLoanUpdated(true);
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      console.error("Error updating Borrower:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to update borrower",
        type: "error"
      });
    }
  };
  const requestColumns = [
    { key: "id", header: "SL.NO" },
    { key: "createdAt", header: "Applied On" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "referred_by", header: "Referred By" },
    { key: "loan_amount", header: "Loan Amount Requested" },
    { key: "employee_approved_amount", header: "Agent Approved Amount" },
    { key: "admin_approved_amount", header: "Admin Approved Amount" },
    { key: "employee_remark", header: "Employee Remark" },
    { key: "loan_purpose", header: "Loan Purpose" },
    { key: "address", header: "Address" },
    { key: "approval_status", header: "Status" },
    { key: "createdBy", header: "Created/Updated By", width: 120 },
    { key: "action", header: "Actions" }
  ];
  const unknownColumns = [
    { key: "id", header: "SL.NO" },
    { key: "createdAt", header: "Applied On" },
    { key: "full_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "referred_by", header: "Referred By" },
    { key: "loan_amount", header: "Loan Amount" },
    { key: "employee_approved_amount", header: "Agent Approved Amount" },
    { key: "admin_approved_amount", header: "Admin Approved Amount" },
    { key: "employee_remark", header: "Employee Remark" },
    { key: "loan_purpose", header: "Loan Purpose" },
    { key: "address", header: "Address" },
    { key: "createdBy", header: "Created/Updated By", width: 120 },
    { key: "approval_status", header: "Status" },
    { key: "action", header: "Actions" }
  ];
  const otherColumns = [
    { key: "id", header: "SL. NO" },
    { key: "createdAt", header: "Applied On" },
    { key: "borrower_name", header: "Borrower Name" },
    { key: "phone_number", header: "Phone Number" },
    ...activeTab === "approved" || activeTab === "completed" || activeTab === "closed" ? [{ key: "loan_id", header: "Loan Id" }] : [],
    { key: "loan_amount", header: "Loan Amount" },
    { key: "employee_approved_amount", header: "Agent Approved Amount" },
    { key: "admin_approved_amount", header: "Admin Approved Amount" },
    { key: "tenure", header: "Tenure" },
    { key: "referred_by", header: "Referred By" },
    { key: "service_charges", header: "Service Charges" },
    { key: "document_charges", header: "Documentation Charges" },
    { key: "extra_charges_display", header: "Extra Charges" },
    { key: "loan_sanction_date", header: "Sanction Date" },
    { key: "start_date", header: "Start Date" },
    { key: "end_date", header: "Due Date" },
    { key: "employee_remark", header: "Employee Remark" },
    { key: "createdBy", header: "Created/Updated By", width: 120 },
    { key: "note", header: "Note" },
    { key: "action", header: "Action" }
  ];
  const columns = useMemo(() => {
    if (activeTab === "requests") return requestColumns;
    if (activeTab === "unknown") return unknownColumns;
    if (activeTab === "completed" || activeTab === "closed") {
      return otherColumns.filter(
        (col) => col.key !== "employee_approved_amount" && col.key !== "admin_approved_amount"
      );
    }
    return otherColumns;
  }, [activeTab]);
  const NoDataFound = () => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-12", children: [
    /* @__PURE__ */ jsxDEV("svg", { className: "w-16 h-16 text-gray-400 mb-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1885,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1884,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900 mb-2", children: "No Data Found" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1887,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
      "There are no ",
      activeTab,
      " loan requests at the moment."
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1888,
      columnNumber: 7
    }, this),
    activeTab === "pending" && /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowModal(true), className: "mt-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200", children: "+ Add New Loan" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1890,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
    lineNumber: 1883,
    columnNumber: 3
  }, this);
  const TAB_CONFIG = [
    { key: "requests", label: "Requests", bgColor: "bg-orange-500", countKey: "totalRequests" },
    { key: "accepted", label: "Accepted", bgColor: "bg-[#00ACC1]", countKey: "totalAccepted" },
    { key: "pending", label: "Pending", bgColor: "bg-yellow-500", countKey: "totalPending" },
    { key: "approved", label: "Approved", bgColor: "bg-green-500", countKey: "totalApproved" },
    { key: "unknown", label: "Unknown", bgColor: "bg-yellow-900", countKey: "totalUnknown" },
    { key: "rejected", label: "Rejected", bgColor: "bg-red-500", countKey: "totalRejected" },
    { key: "completed", label: "Completed", bgColor: "bg-green-900", countKey: "totalCompleted" },
    { key: "closed", label: "Closed", bgColor: "bg-[#00897B]", countKey: "totalClosed" }
  ];
  const tabItems = useMemo(
    () => {
      return TAB_CONFIG.map((tab) => {
        const count = totals[tab.countKey] || 0;
        const isDataReady = !isLoading && !fetchError && (globalSearchTerm && globalSearchTargetTab === tab.key ? globalSearchResults !== null && globalSearchResults.length > 0 : tableBorrowers.length > 0);
        let tableData;
        if (globalSearchTerm && globalSearchTargetTab === tab.key) {
          tableData = globalSearchResults ?? [];
        } else {
          tableData = filterOption(tableBorrowers, searchText);
        }
        const allowUpdate = activeTab !== "completed" && activeTab !== "closed";
        const updateHandler = allowUpdate ? handleUpdateModalOpen : void 0;
        return {
          key: tab.key,
          label: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-base", children: [
            tab.label,
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: `${tab.bgColor} text-white text-[12px] px-2 py-0.5 rounded-full`, children: count }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1933,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1931,
            columnNumber: 9
          }, this),
          children: /* @__PURE__ */ jsxDEV(Fragment, { children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Loan Data" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1941,
            columnNumber: 11
          }, this) : fetchError || tableBorrowers.length === 0 ? /* @__PURE__ */ jsxDEV(NoDataFound, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1943,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              catcher: "_id",
              updateHandler,
              isSearchRequired: false,
              data: tableData,
              columns,
              exportedPdfName: "Loans",
              exportedFileName: `Loans.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 1945,
              columnNumber: 11
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 1939,
            columnNumber: 9
          }, this)
        };
      });
    },
    [
      isLoading,
      fetchError,
      tableBorrowers,
      globalSearchTerm,
      globalSearchTargetTab,
      globalSearchResults,
      searchText,
      columns,
      totals,
      activeTab,
      handleUpdateModalOpen
    ]
  );
  const handleViewTransactions = async (customerId) => {
    setButtonLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2e3));
      setSelectedCustomer(customerId);
      setShowTransactions(true);
    } catch (error) {
      console.error("Failed to fetch transactions", error);
    } finally {
      setButtonLoading(false);
    }
  };
  const statusOptions = [
    { value: "REQUESTED", label: "Requested", icon: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1979,
      columnNumber: 51
    }, this), color: "blue" },
    { value: "PENDING", label: "Pending", icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1980,
      columnNumber: 47
    }, this), color: "orange" },
    { value: "REJECTED", label: "Reject", icon: /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1981,
      columnNumber: 47
    }, this), color: "red" },
    { value: "UNKNOWN", label: "Unknown", icon: /* @__PURE__ */ jsxDEV(QuestionCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1982,
      columnNumber: 47
    }, this), color: "purple" },
    { value: "ACCEPTED", label: "Accepted", icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1983,
      columnNumber: 49
    }, this), color: "green" },
    { value: "APPROVED", label: "Approved", icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1984,
      columnNumber: 49
    }, this), color: "teal" }
  ];
  const handleApprovalStatusChange = (value) => {
    handleAntDSelect("approval_status", value);
    setFormData((prev) => ({
      ...prev,
      approval_status: value
    }));
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true, onGlobalSearchChangeHandler }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 1998,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 1999,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 2006,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-x-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-2 min-w-max", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2009,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-8 flex items-center justify-between gap-4", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold whitespace-nowrap", children: "Loans" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2011,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 max-w-2xl flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Search by customer name or phone number...",
                  value: searchInput,
                  onChange: (e) => setSearchInput(e.target.value),
                  onPressEnter: () => handleSearch(searchInput),
                  allowClear: true,
                  size: "large",
                  prefix: /* @__PURE__ */ jsxDEV(SearchOutlined, { style: { color: "#6b7280" } }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2023,
                    columnNumber: 29
                  }, this),
                  className: "w-full rounded-xl shadow-md border-2 border-blue-100 hover:border-blue-300 focus:border-blue-500 focus:ring focus:ring-blue-200 transition-all duration-200 px-4 py-2 text-base"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2016,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  icon: /* @__PURE__ */ jsxDEV(SearchOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2028,
                    columnNumber: 27
                  }, this),
                  onClick: () => handleSearch(searchInput),
                  className: "h-10 bg-blue-600 hover:bg-blue-700 border-blue-600 flex items-center justify-center rounded-xl shadow-md",
                  children: "Search"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2026,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2015,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 whitespace-nowrap", children: [
              /* @__PURE__ */ jsxDEV(
                Link,
                {
                  to: "/payment-menu/payment-in-out-menu/pay-out-menu/loan-payout",
                  className: "inline-flex items-center px-3 py-1.5 text-sm border border-blue-500 text-blue-600 rounded-lg\r\n      hover:bg-blue-50 hover:text-blue-700 hover:border-blue-600\r\n      transition-all duration-200 font-medium",
                  children: "Loan Payment Out"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2037,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Link,
                {
                  to: "/reports/loan-payout-report",
                  className: "inline-flex items-center px-3 py-1.5 text-sm border border-green-500 text-green-600 rounded-lg\r\n      hover:bg-green-50 hover:text-green-700 hover:border-green-600\r\n      transition-all duration-200 font-medium",
                  children: "Payment Out Report"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2046,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setShowModal(true);
                    setErrors({});
                  },
                  className: "bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
                  children: "+ Add Loan"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2055,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2036,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2010,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2008,
          columnNumber: 13
        }, this),
        summaryLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Loan Summary" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2069,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-4 mb-4", children: ORDERED_STATUSES.map((status) => {
          const found = summaryData.find((item) => item.status === status);
          const count = found?.count || 0;
          const totalAmount = found?.total_amount || 0;
          const statusConfig = {
            REQUESTED: {
              bg: "from-blue-50 to-blue-100",
              border: "border-blue-200",
              text: "text-blue-700",
              icon: /* @__PURE__ */ jsxDEV(FaRegEdit, { className: "text-blue-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2083,
                columnNumber: 27
              }, this)
            },
            ACCEPTED: {
              bg: "from-green-50 to-green-100",
              border: "border-green-200",
              text: "text-green-700",
              icon: /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2089,
                columnNumber: 27
              }, this)
            },
            PENDING: {
              bg: "from-yellow-50 to-yellow-100",
              border: "border-yellow-200",
              text: "text-yellow-700",
              icon: /* @__PURE__ */ jsxDEV(FaHourglassHalf, { className: "text-yellow-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2095,
                columnNumber: 27
              }, this)
            },
            APPROVED: {
              bg: "from-indigo-50 to-indigo-100",
              border: "border-indigo-200",
              text: "text-indigo-700",
              icon: /* @__PURE__ */ jsxDEV(FaThumbsUp, { className: "text-indigo-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2101,
                columnNumber: 27
              }, this)
            },
            UNKNOWN: {
              bg: "from-purple-50 to-purple-100",
              border: "border-purple-200",
              text: "text-purple-700",
              icon: /* @__PURE__ */ jsxDEV(FaQuestionCircle, { className: "text-purple-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2107,
                columnNumber: 27
              }, this)
            },
            REJECTED: {
              bg: "from-red-50 to-red-100",
              border: "border-red-200",
              text: "text-red-700",
              icon: /* @__PURE__ */ jsxDEV(FaTimesCircle, { className: "text-red-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2113,
                columnNumber: 27
              }, this)
            },
            COMPLETED: {
              bg: "from-teal-50 to-teal-100",
              border: "border-teal-200",
              text: "text-teal-700",
              icon: /* @__PURE__ */ jsxDEV(FaFlagCheckered, { className: "text-teal-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2119,
                columnNumber: 27
              }, this)
            }
          };
          const config = statusConfig[status];
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `bg-gradient-to-br ${config.bg} rounded-lg border ${config.border} p-1 shadow-sm hover:shadow transition-all duration-200`,
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: `text-[13px] font-semibold uppercase tracking-wider ${config.text}`, children: status }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2131,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm", children: config.icon }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2134,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2130,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline justify-between mt-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-gray-800", children: count }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2137,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-gray-500", children: "loans" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2138,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2136,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-900 flex items-center gap-1", children: [
                  "Total Loan Amount",
                  /* @__PURE__ */ jsxDEV(RiArrowRightFill, { className: "shrink-0" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2143,
                    columnNumber: 27
                  }, this),
                  formatIndianCurrency(totalAmount)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2141,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2140,
                  columnNumber: 23
                }, this)
              ]
            },
            status,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2126,
              columnNumber: 19
            },
            this
          );
        }) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2071,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded shadow", children: /* @__PURE__ */ jsxDEV(
          Tabs,
          {
            activeKey: activeTab,
            onChange: (key) => {
              setActiveTab(key);
              setGlobalSearchTerm("");
              setGlobalSearchResults(null);
              setGlobalSearchTargetTab(null);
              setSearchInput("");
            },
            items: tabItems,
            destroyInactiveTabPane: true
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2154,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2153,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 2007,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 2005,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Loan" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 2174,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-5", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "borrower_name",
              children: [
                "Borrower Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2181,
                  columnNumber: 33
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2177,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
              placeholder: "Select Or Search  Borrower Name ",
              popupMatchSelectWidth: false,
              showSearch: true,
              name: "borrower",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              value: formData?.borrower || void 0,
              onChange: (value) => handleAntDSelect("borrower", value),
              children: users.map(
                (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                  user.customer_id,
                  " | ",
                  user.full_name,
                  " |",
                  " ",
                  user.phone_number
                ] }, user._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2199,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2183,
              columnNumber: 17
            },
            this
          ),
          errors.borrower && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.borrower }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2206,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2176,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => handleViewTransactions(formData.borrower),
            disabled: !formData?.borrower || buttonLoading,
            className: "text-blue-700 hover:text-white hover:bg-blue-700 border border-blue-700 font-medium rounded px-3 py-1 text-sm transition cursor-pointer flex items-center justify-center",
            children: buttonLoading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "loader mr-2" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2218,
                columnNumber: 23
              }, this),
              " Loading..."
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2217,
              columnNumber: 19
            }, this) : "View Transactions"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2210,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2209,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "loan_amount",
                children: [
                  "Loan Amount ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2231,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2227,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "loan_amount",
                value: formData.loan_amount,
                onChange: handleChange,
                id: "loan_amount",
                placeholder: "Enter Loan Amount",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2233,
                columnNumber: 19
              },
              this
            ),
            errors.loan_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.loan_amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2244,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(formData?.loan_amount) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2249,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2248,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2226,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "tenure",
                children: [
                  "Tenure in Days ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2259,
                    columnNumber: 36
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2255,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "tenure",
                value: formData.tenure,
                onChange: handleChange,
                id: "tenure",
                placeholder: "Enter Tenure in Days",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2261,
                columnNumber: 19
              },
              this
            ),
            errors.tenure && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.tenure }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2272,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(formData?.tenure) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2275,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2274,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2254,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2225,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "service_charges",
                children: [
                  "Service Charges ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2287,
                    columnNumber: 37
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2283,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "service_charges",
                value: formData.service_charges,
                onChange: handleChange,
                id: "service_charges",
                placeholder: "Enter Service Charges",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2289,
                columnNumber: 19
              },
              this
            ),
            errors.service_charges && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.service_charges }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2300,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(formData?.service_charges) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2305,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2304,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2282,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "document_charges",
                children: [
                  "Documentation Charges",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2317,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2312,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "document_charges",
                value: formData.document_charges,
                onChange: handleChange,
                id: "document_charges",
                placeholder: "Enter Documentation Charges",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2319,
                columnNumber: 19
              },
              this
            ),
            errors.document_charges && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.document_charges }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2330,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(formData?.document_charges) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2335,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2334,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2311,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2281,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "daily_payment_amount",
                children: [
                  "Daily Payment Amount",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2348,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2343,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                placeholder: "Daily Payment Amount",
                name: "daily_payment_amount",
                value: formData.daily_payment_amount,
                onChange: handleChange,
                id: "daily_payment_amount",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2350,
                columnNumber: 19
              },
              this
            ),
            errors.daily_payment_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.daily_payment_amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2361,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(formData?.daily_payment_amount) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2366,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2365,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2342,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "disposal_amount",
                children: "Disbursement Amount"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2372,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "disposal_amount",
                id: "disposal_amount",
                placeholder: "Automatically calculated",
                value: Number(formData?.loan_amount || 0) - Number(formData?.service_charges || 0) - Number(formData?.document_charges || 0) || "",
                readOnly: true,
                className: `bg-gray-100 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2378,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(Number(formData?.loan_amount) - Number(formData?.service_charges) - Number(formData?.document_charges)) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2392,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2391,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2371,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2341,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
              "Referred Type ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2479,
                columnNumber: 35
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2478,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full 
                     [&.ant-select-disabled_.ant-select-selection-item]:!text-gray-800
  [&.ant-select-disabled_.ant-select-selection-item]:!opacity-100`,
                placeholder: "Select Referred Type",
                popupMatchSelectWidth: false,
                showSearch: true,
                name: "referred_type",
                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                value: formData?.referred_type || void 0,
                onChange: (value) => handleAntDSelect("referred_type", value),
                children: [
                  "Self Joining",
                  "Customer",
                  "Employee",
                  "Agent",
                  "Others"
                ].map(
                  (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2507,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2481,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2477,
            columnNumber: 17
          }, this),
          formData.referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "category",
                children: [
                  "Select Referred Customer",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2520,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2515,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full 
                       [&.ant-select-disabled_.ant-select-selection-item]:!text-gray-800
  [&.ant-select-disabled_.ant-select-selection-item]:!opacity-100`,
                placeholder: "Select Or Search Referred Customer",
                popupMatchSelectWidth: false,
                showSearch: true,
                name: "referred_customer",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                value: formData?.referred_customer || void 0,
                onChange: (value) => handleAntDSelect("referred_customer", value),
                children: users.map(
                  (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                    user.full_name,
                    " |",
                    " ",
                    user.phone_number ? user.phone_number : "No Number"
                  ] }, user._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2543,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2522,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2514,
            columnNumber: 17
          }, this),
          formData.referred_type === "Agent" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Select Referred Agent",
              " ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2555,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2553,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                placeholder: "Select or Search Referred Agent",
                popupMatchSelectWidth: false,
                showSearch: true,
                name: "referred_agent",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                value: formData.referred_agent || void 0,
                onChange: (value) => handleAntDSelect("referred_agent", value),
                children: agents.map(
                  (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                    agent.name,
                    " | ",
                    agent.phone_number
                  ] }, agent._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2576,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2557,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2552,
            columnNumber: 17
          }, this),
          formData.referred_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "category",
                children: [
                  "Select Referred Employee",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2590,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2585,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full 
  [&.ant-select-disabled_.ant-select-selection-item]:!text-gray-800
  [&.ant-select-disabled_.ant-select-selection-item]:!opacity-100`,
                placeholder: "Select Or Search Referred Employee",
                popupMatchSelectWidth: false,
                showSearch: true,
                optionFilterProp: "label",
                name: "referred_employee",
                filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                value: formData?.referred_employee || void 0,
                onChange: (value) => handleAntDSelect("referred_employee", value),
                children: employees.map(
                  (employee) => /* @__PURE__ */ jsxDEV(
                    Select.Option,
                    {
                      value: employee._id,
                      label: `${employee.name} | ${employee.phone_number}`,
                      children: [
                        employee.name,
                        " | ",
                        employee.phone_number
                      ]
                    },
                    employee._id,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 2612,
                      columnNumber: 21
                    },
                    this
                  )
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2592,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2584,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2476,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex flex-col md:flex-row gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Note" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2628,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "note",
                  value: formData.note,
                  onChange: handleChange,
                  placeholder: "Specify Note if any!",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2632,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "bg-blue-700 hover:bg-blue-800 w-10 h-10 flex justify-center items-center rounded-md cursor-pointer flex-shrink-0",
                  onClick: () => window.open("Calculator:///"),
                  children: /* @__PURE__ */ jsxDEV(FaCalculator, { color: "white" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2644,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2640,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2631,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2627,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Status ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2652,
                columnNumber: 28
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2651,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.approval_status,
                onChange: (value) => handleAntDSelect("approval_status", value),
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`,
                popupMatchSelectWidth: false,
                optionLabelProp: "label",
                children: statusOptions.map(
                  (opt) => /* @__PURE__ */ jsxDEV(Select.Option, { value: opt.value, label: opt.label, children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { style: { color: opt.color }, children: opt.icon }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 2664,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: opt.label }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 2665,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2663,
                    columnNumber: 25
                  }, this) }, opt.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2662,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2654,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2650,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2625,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800\r\nfocus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
            children: "Save Loan"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2674,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2673,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 2175,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 2173,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
      lineNumber: 2172,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: isAcceptModalOpen,
        onClose: () => {
          setIsAcceptModalOpen(false);
          setSelectedLoan(null);
        },
        size: "2xl",
        className: "overflow-hidden",
        children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-6xl bg-gradient-to-br from-white to-blue-50 shadow-xl font-sans text-sm text-gray-800 rounded-xl overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border-b-2 border-blue-900 p-4", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-center text-2xl font-bold text-blue-900 uppercase tracking-wider", children: "Edit Loan Request" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2699,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2698,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: async (e) => {
                  const btn = e.currentTarget;
                  const originalText = btn.innerHTML;
                  btn.disabled = true;
                  btn.innerHTML = `<span class="loader mr-2"></span> Loading...`;
                  try {
                    await handleViewTransactions(selectedLoan?.borrower?._id || selectedLoan?.borrower?.user_id?._id);
                  } catch (err) {
                    console.error(err);
                  } finally {
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                  }
                },
                disabled: !selectedLoan?.borrower?._id,
                className: "text-blue-700 hover:text-white hover:bg-blue-700 border border-blue-700 font-medium rounded-lg px-4 py-2 text-sm transition-all duration-300 cursor-pointer flex items-center justify-center whitespace-nowrap shadow-sm hover:shadow-md",
                children: [
                  /* @__PURE__ */ jsxDEV(FiEye, { className: "mr-2" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2725,
                    columnNumber: 19
                  }, this),
                  "View Transactions"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2705,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2703,
              columnNumber: 15
            }, this),
            (selectedLoan?.user || selectedLoan?.user_id) && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-md p-5 mb-6 border border-gray-100 hover:shadow-lg transition-shadow duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 flex-shrink-0 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg", children: (selectedLoan.user_id?.full_name?.charAt(0) || selectedLoan.user?.full_name?.charAt(0) || "U").toUpperCase() }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2735,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-gray-800 text-lg truncate max-w-[60%]", children: selectedLoan.user_id?.full_name || selectedLoan.user?.full_name || "Unknown" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2746,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800", children: [
                    /* @__PURE__ */ jsxDEV(FiUser, { className: "mr-1" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 2752,
                      columnNumber: 27
                    }, this),
                    "Source : Self"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2751,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2744,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm flex items-center gap-2 mt-2", children: [
                  /* @__PURE__ */ jsxDEV(FiPhone, { className: "w-4 h-4 flex-shrink-0" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2759,
                    columnNumber: 25
                  }, this),
                  selectedLoan.user_id?.phone_number || selectedLoan.user?.phone_number || "-"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2758,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2743,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2733,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2732,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-6", children: [
              selectedLoan?.loan_amount != null && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-4 border border-green-200 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-md", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-6 h-6 text-white" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2775,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2774,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 font-semibold", children: "Loan Amount" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2777,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2773,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-green-700 font-bold text-xl whitespace-nowrap", children: [
                  "₹",
                  selectedLoan?.loan_amount.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2782,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2772,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2771,
                columnNumber: 17
              }, this),
              selectedLoan?.loan_purpose && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4 border border-blue-200 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-md", children: /* @__PURE__ */ jsxDEV(FiFileText, { className: "w-6 h-6 text-white" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2795,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2794,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 font-semibold", children: "Purpose" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2797,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2793,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-blue-700 font-semibold max-w-[50%] truncate text-right", children: selectedLoan?.loan_purpose }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2802,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2792,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2791,
                columnNumber: 17
              }, this),
              selectedLoan?.createdAt && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-4 border border-purple-200 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxDEV(FiClock, { className: "w-6 h-6 text-white" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2815,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2814,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 font-semibold", children: "Applied On" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2817,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2813,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-purple-700 font-semibold text-sm text-right whitespace-nowrap", children: new Date(selectedLoan?.createdAt).toLocaleDateString("en-IN", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                  hour: "2-digit",
                  minute: "2-digit"
                }) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2822,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2812,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2811,
                columnNumber: 17
              }, this),
              (selectedLoan?.user_id?.referred_by_name || selectedLoan?.user_id?.referred_employee) && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-amber-50 to-amber-100 rounded-xl p-4 border border-amber-200 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-xl flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxDEV(FiUserPlus, { className: "w-6 h-6 text-white" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2841,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2840,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 font-semibold", children: "Referred By" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2843,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2839,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-amber-700 font-semibold text-right whitespace-nowrap", children: selectedLoan?.user_id?.referred_employee?.name && selectedLoan?.user_id?.referred_employee?.phone_number ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-end", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "     Employee :- ",
                    selectedLoan?.user_id?.referred_employee.name
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2853,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: selectedLoan?.user_id?.referred_employee?.phone_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2854,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2851,
                  columnNumber: 23
                }, this) : selectedLoan?.user_id?.referred_agent?.name ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-end", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "  Agent:- ",
                    selectedLoan?.user_id?.referred_agent.name
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2861,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: selectedLoan?.user_id?.referred_agent.phone_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2862,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2859,
                  columnNumber: 23
                }, this) : selectedLoan?.user_id?.referred_customer?.full_name && selectedLoan?.user_id?.referred_customer?.phone_number ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-end", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "     Customer:-",
                    selectedLoan?.user_id?.referred_customer.full_name
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2870,
                    columnNumber: 35
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: selectedLoan?.user_id?.referred_customer?.phone_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2871,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2868,
                  columnNumber: 23
                }, this) : "N/A" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2847,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2838,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2837,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2768,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-5 border border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-4 text-lg flex items-center", children: [
                /* @__PURE__ */ jsxDEV(FiSettings, { className: "mr-2" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 2887,
                  columnNumber: 19
                }, this),
                "Update Status"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2886,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-3", children: [
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "default",
                    loading,
                    className: "h-14 font-bold border-yellow-500 text-yellow-600 hover:bg-yellow-50 hover:border-yellow-600 transition-all duration-300 shadow-sm hover:shadow-md",
                    icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 2895,
                      columnNumber: 27
                    }, this),
                    disabled: selectedLoan?.length === 0,
                    onClick: () => {
                      showConfirm({
                        title: "Pending Loan Request",
                        content: `Are you sure you want to Pending this loan request?`,
                        onConfirm: () => updateLoanStatus(selectedLoan, "PENDING")
                      });
                    },
                    block: true,
                    children: "Pending"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2891,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "primary",
                    loading,
                    disabled: selectedLoan?.length === 0,
                    className: "h-14 font-bold bg-green-600 hover:bg-green-700 border-green-600 transition-all duration-300 shadow-sm hover:shadow-md",
                    icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 2918,
                      columnNumber: 27
                    }, this),
                    block: true,
                    onClick: () => {
                      showConfirm({
                        title: "Accept Loan Request",
                        content: `Are you sure you want to Accept this loan request?`,
                        onConfirm: () => updateLoanStatus(selectedLoan, "ACCEPTED")
                      });
                    },
                    children: "Accept"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2913,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "warning",
                    danger: true,
                    loading,
                    className: "h-14 font-bold text-gray-700 bg-yellow-100 hover:bg-yellow-200 border-yellow-300 transition-all duration-300 shadow-sm hover:shadow-md",
                    icon: /* @__PURE__ */ jsxDEV(QuestionCircleOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 2936,
                      columnNumber: 27
                    }, this),
                    disabled: selectedLoan?.length === 0,
                    block: true,
                    onClick: () => {
                      showConfirm({
                        title: "Unknown Loan Request",
                        content: `Are you sure you want to mark this loan request as unknown?`,
                        onConfirm: () => updateLoanStatus(selectedLoan, "UNKNOWN")
                      });
                    },
                    children: "Unknown"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2931,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "danger",
                    danger: true,
                    loading,
                    className: "h-14 font-bold shadow-sm hover:shadow-md !text-white !bg-red-500 !border-red-500 hover:!bg-red-600",
                    icon: /* @__PURE__ */ jsxDEV(CloseOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 2955,
                      columnNumber: 27
                    }, this),
                    disabled: selectedLoan?.length === 0,
                    onClick: () => {
                      showConfirm({
                        title: "Reject Loan Request",
                        content: `Are you sure you want to reject this loan request?`,
                        onConfirm: () => updateLoanStatus(selectedLoan, "REJECTED")
                      });
                    },
                    block: true,
                    children: "Reject"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2950,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    onClick: () => {
                      setIsAcceptModalOpen(false);
                      setSelectedLoan(null);
                    },
                    className: "h-14 font-semibold border-gray-400 hover:bg-gray-100 transition-all duration-300 shadow-sm hover:shadow-md",
                    block: true,
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 2972,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 2890,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 2885,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 2702,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 2696,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 2687,
        columnNumber: 9
      },
      this
    ),
    showTransactions && /* @__PURE__ */ jsxDEV(
      ViewCustomerTransactions,
      {
        customerId: selectedCustomer,
        visible: showTransactions,
        onClose: () => setShowTransactions(false)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 2988,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-4 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-3 mb-4", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Update Loan" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3002,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-sm bg-blue-50 border border-blue-200 rounded-full px-3 py-1 w-fit shadow-sm", children: [
              /* @__PURE__ */ jsxDEV(FaCalendarAlt, { className: "text-blue-500 w-3.5 h-3.5" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3006,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 font-medium", children: "Applied on:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3007,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-semibold", children: updateFormData?.applied_on || updateFormData?.createdAt ? new Date(updateFormData.applied_on || updateFormData.createdAt).toLocaleDateString("en-IN") : "—" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3008,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3005,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 3001,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 3016,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "borrower_name",
                  children: [
                    "Borrower Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 3025,
                      columnNumber: 33
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3021,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5
                   [&.ant-select-disabled_.ant-select-selection-item]:!text-gray-800
  [&.ant-select-disabled_.ant-select-selection-item]:!opacity-100`,
                  placeholder: "Select Or Search Borrower Name",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  disabled: true,
                  name: "borrower",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.borrower || void 0,
                  onChange: (value) => handleAntInputDSelect("borrower", value),
                  children: users?.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 3046,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3027,
                  columnNumber: 17
                },
                this
              ),
              errors.borrower && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.borrower }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3052,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3020,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: async (e) => {
                  const btn = e.currentTarget;
                  const originalText = btn.innerHTML;
                  btn.disabled = true;
                  btn.innerHTML = `<span class="loader mr-2"></span> Loading...`;
                  try {
                    await handleViewTransactions(updateFormData?.borrower);
                  } catch (err) {
                    console.error(err);
                  } finally {
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                  }
                },
                disabled: !updateFormData?.borrower,
                className: "text-blue-700 hover:text-white hover:bg-blue-700 border border-blue-700 font-medium rounded px-3 py-1 text-sm transition cursor-pointer flex items-center justify-center whitespace-nowrap",
                children: "View Transactions"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3070,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3055,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-slate-50 to-blue-50 p-4 rounded-xl border border-slate-200 mb-6 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center gap-4 md:gap-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 w-full md:w-1/3 border-b md:border-b-0 md:border-r border-slate-200 pb-3 md:pb-0 md:pr-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-100 rounded-lg text-blue-600 shadow-sm", children: /* @__PURE__ */ jsxDEV(FaUser, { className: "w-5 h-5" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3100,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3099,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-slate-500 font-bold tracking-wider mb-0.5", children: "Requested" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3103,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-slate-800 leading-none", children: [
                    "₹ ",
                    (currentUpdateBorrower?.requested_loan_amount || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3104,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3102,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3098,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 w-full md:w-1/3 border-b md:border-b-0 md:border-r border-slate-200 pb-3 md:pb-0 md:pr-4 pl-0 md:pl-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-orange-100 rounded-lg text-orange-600 shadow-sm", children: /* @__PURE__ */ jsxDEV(FaUserTie, { className: "w-5 h-5" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3113,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3112,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-slate-500 font-bold tracking-wider mb-0.5", children: "Agent Approved" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3116,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-slate-800 leading-none", children: [
                    "₹ ",
                    (currentUpdateBorrower?.employee_approved_amount || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3117,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3115,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3111,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 w-full md:w-1/3 pl-0 md:pl-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-emerald-100 rounded-lg text-emerald-600 shadow-sm", children: /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "w-5 h-5" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3126,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3125,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-slate-500 font-bold tracking-wider mb-0.5", children: "Admin Approved" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3129,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-slate-800 leading-none", children: [
                    "₹ ",
                    (currentUpdateBorrower?.approved_loan_amount || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3130,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3128,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3124,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3095,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3094,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "loan_amount",
                    children: [
                      "Loan Amount ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: " *" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3144,
                        columnNumber: 33
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3140,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "loan_amount",
                    value: updateFormData.loan_amount,
                    onChange: handleInputChange,
                    id: "loan_amount",
                    placeholder: "Enter Loan Amount",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3146,
                    columnNumber: 19
                  },
                  this
                ),
                errors.loan_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.loan_amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3157,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(updateFormData?.loan_amount) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3162,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3161,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3139,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "tenure",
                    children: [
                      "Tenure in Days ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3172,
                        columnNumber: 36
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3168,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "tenure",
                    value: updateFormData?.tenure,
                    onChange: handleInputChange,
                    id: "tenure",
                    placeholder: "Enter Tenure in Days",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3174,
                    columnNumber: 19
                  },
                  this
                ),
                errors.tenure && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.tenure }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3185,
                  columnNumber: 19
                }, this),
                updateFormData?.tenure && /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(updateFormData?.tenure) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3189,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3188,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3167,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3138,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "service_charges",
                    children: [
                      "Service Charges ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3202,
                        columnNumber: 37
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3198,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "service_charges",
                    value: updateFormData?.service_charges,
                    onChange: handleInputChange,
                    id: "service_charges",
                    placeholder: "Enter Service Charges",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3204,
                    columnNumber: 19
                  },
                  this
                ),
                errors.service_charges && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.service_charges }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3215,
                  columnNumber: 19
                }, this),
                updateFormData?.service_charges && /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(updateFormData?.service_charges) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3221,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3220,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3197,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "document_charges",
                    children: [
                      "Documentation Charges",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3233,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3228,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "document_charges",
                    value: updateFormData?.document_charges,
                    onChange: handleInputChange,
                    id: "document_charges",
                    placeholder: "Enter Documentation Charges",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3235,
                    columnNumber: 19
                  },
                  this
                ),
                errors.document_charges && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.document_charges }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3246,
                  columnNumber: 19
                }, this),
                updateFormData?.document_charges && /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(updateFormData?.document_charges) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3252,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3251,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3227,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3196,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "daily_payment_amount",
                    children: [
                      "Daily Payment Amount",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3268,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3263,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    placeholder: "Daily Payment Amount",
                    name: "daily_payment_amount",
                    value: updateFormData?.daily_payment_amount,
                    onChange: handleInputChange,
                    id: "daily_payment_amount",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3270,
                    columnNumber: 19
                  },
                  this
                ),
                errors?.daily_payment_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors?.daily_payment_amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3281,
                  columnNumber: 19
                }, this),
                updateFormData?.daily_payment_amount && /* @__PURE__ */ jsxDEV("div", { className: " px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(updateFormData?.daily_payment_amount) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3287,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3286,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3262,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "disposal_amount",
                    children: "Disbursement Amount"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3294,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "disposal_amount",
                    id: "disposal_amount",
                    placeholder: "Automatically calculated",
                    value: Number(updateFormData?.loan_amount || 0) - Number(updateFormData?.service_charges || 0) - Number(updateFormData?.document_charges || 0) || "",
                    readOnly: true,
                    className: `bg-gray-100 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3300,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(
                  Number(updateFormData?.loan_amount || 0) - Number(updateFormData?.service_charges || 0) - Number(updateFormData?.document_charges || 0) || ""
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3314,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3313,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3293,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3260,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                  "Referred Type ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3402,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3401,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full
                     [&.ant-select-disabled_.ant-select-selection-item]:!text-gray-800
  [&.ant-select-disabled_.ant-select-selection-item]:!opacity-100`,
                    placeholder: "Select Referred Type",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    styles: {
                      selector: {
                        backgroundColor: "#f9fafb",
                        color: "#111827",
                        opacity: 1,
                        border: "1px solid #d1d5db"
                      }
                    },
                    name: "referred_type",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.referred_type || void 0,
                    onChange: (value) => handleAntInputDSelect("referred_type", value),
                    children: [
                      "Self Joining",
                      "Customer",
                      "Employee",
                      "Agent",
                      "Others"
                    ].map(
                      (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3438,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3404,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3400,
                columnNumber: 17
              }, this),
              updateFormData.referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Select Referred Customer",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3451,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3446,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                    placeholder: "Select Or Search Referred Customer",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "referred_customer",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.referred_customer || void 0,
                    onChange: (value) => handleAntInputDSelect("referred_customer", value),
                    children: users.map(
                      (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                        user.full_name,
                        " |",
                        " ",
                        user.phone_number ? user.phone_number : "No Number"
                      ] }, user._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3472,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3453,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3445,
                columnNumber: 17
              }, this),
              updateFormData.referred_type === "Agent" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Select Referred Agent",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3484,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3482,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                    placeholder: "Select or Search Referred Agent",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "referred_agent",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData.referred_agent || void 0,
                    onChange: (value) => handleAntInputDSelect("referred_agent", value),
                    children: agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                        agent.name,
                        " | ",
                        agent.phone_number
                      ] }, agent._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3505,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3486,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3481,
                columnNumber: 17
              }, this),
              updateFormData.referred_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Select Referred Employee",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3519,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3514,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full
                       [&.ant-select-disabled_.ant-select-selection-item]:!text-gray-800
  [&.ant-select-disabled_.ant-select-selection-item]:!opacity-100 `,
                    placeholder: "Select Or Search Referred Employee",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "referred_employee",
                    filterOption: (input, option) => {
                      if (!option || !option.children) return false;
                      return option.children.toString().toLowerCase().includes(input.toLowerCase());
                    },
                    value: updateFormData?.referred_employee || void 0,
                    onChange: (value) => handleAntInputDSelect("referred_employee", value),
                    children: employees.map(
                      (employee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: employee._id, children: [
                        employee.name,
                        " | ",
                        employee.phone_number
                      ] }, employee._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3543,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3521,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3513,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3399,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex flex-col md:flex-row gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Note" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3554,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      name: "note",
                      value: updateFormData.note,
                      onChange: handleInputChange,
                      placeholder: "Specify Note if any!",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 3558,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "bg-blue-700 hover:bg-blue-800 w-10 h-10 flex justify-center items-center rounded-md cursor-pointer flex-shrink-0",
                      onClick: () => window.open("Calculator:///"),
                      children: /* @__PURE__ */ jsxDEV(FaCalculator, { color: "white" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3570,
                        columnNumber: 23
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 3566,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3557,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3553,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Status ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3578,
                    columnNumber: 28
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3577,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    value: updateFormData.approval_status,
                    onChange: (value) => handleAntInputDSelect("approval_status", value),
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`,
                    popupMatchSelectWidth: false,
                    optionLabelProp: "label",
                    children: statusOptions.map(
                      (opt) => /* @__PURE__ */ jsxDEV(Select.Option, { value: opt.value, label: opt.label, children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { style: { color: opt.color }, children: opt.icon }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                          lineNumber: 3590,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: opt.label }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                          lineNumber: 3591,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3589,
                        columnNumber: 25
                      }, this) }, opt.value, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                        lineNumber: 3588,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3580,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3576,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3551,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end gap-4 mt-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-36 text-white bg-blue-700 hover:bg-blue-800\r\n      focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg\r\n      text-sm px-5 py-2.5 text-center border-2 border-black transition duration-200",
                children: "Update Loan"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3599,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3598,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 3019,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 3e3,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 2996,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentBorrower(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Borrower" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 3621,
            columnNumber: 13
          }, this),
          currentBorrower && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteBorrower();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentBorrower?.borrower?.full_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                          lineNumber: 3638,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                          lineNumber: 3642,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 3633,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "borrowerName",
                      placeholder: "Enter the Borrower Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 3644,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3632,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\nfocus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3652,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3625,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 3620,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 3613,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showRemoveModal,
        onClose: () => {
          setShowRemoveModal(false);
          setCurrentBorrower(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-2 text-xl font-bold text-gray-900", children: "Remove Loan" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 3673,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mb-4 text-sm text-gray-700", children: "Are you sure you want to remove this loan?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 3676,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Removal Reason ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3681,
                columnNumber: 32
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3680,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Select reason",
                value: removeReason || void 0,
                onChange: (value) => {
                  setRemoveReason(value);
                  setCustomRemoveReason("");
                },
                className: "w-full",
                children: [
                  "Loan Completed Successfully",
                  "All EMIs Paid",
                  "Loan Closed Early",
                  "Customer Request",
                  "Duplicate Loan Entry",
                  "Verification Failed",
                  "Loan Replaced With New Loan",
                  "Written Off",
                  "Other"
                ].map(
                  (reason) => /* @__PURE__ */ jsxDEV(Select.Option, { value: reason, children: reason }, reason, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 3703,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3683,
                columnNumber: 15
              },
              this
            ),
            removeReason === "Other" && /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Specify Reason ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3711,
                  columnNumber: 36
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3710,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Enter removal reason",
                  value: customRemoveReason,
                  onChange: (e) => setCustomRemoveReason(e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 3713,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 3709,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 3679,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowRemoveModal(false),
                className: "px-4 py-2 border rounded-md",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3722,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleRemoveBorrower,
                className: "px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700",
                children: "Confirm Remove"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 3728,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 3721,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 3672,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 3665,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showApprovalModal,
        onClose: () => {
          setShowApprovalModal(false);
          setCurrentBorrower(null);
          setApprovalStatus("");
          setApprovalNote("");
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-2 text-xl font-bold text-gray-900", children: "Update  Loan  Status" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4016,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mb-4 text-sm text-gray-700", children: [
            currentBorrower?.borrower?.full_name,
            " - Loan ID:",
            " ",
            currentBorrower?.loan_id
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4022,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Loan Status ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4030,
                columnNumber: 24
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4027,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Select approval status",
                value: approvalStatus || void 0,
                onChange: (value) => setApprovalStatus(value),
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "unknown", children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-yellow-600 font-medium", children: [
                    /* @__PURE__ */ jsxDEV(QuestionCircleOutlined, { className: "text-yellow-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 4043,
                      columnNumber: 21
                    }, this),
                    "Unknown"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4042,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4041,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "accept", children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-green-600 font-medium", children: [
                    /* @__PURE__ */ jsxDEV(CheckCircleOutlined, { className: "text-green-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 4050,
                      columnNumber: 21
                    }, this),
                    "Accepted"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4049,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4048,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "APPROVED", children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-blue-600 font-medium", children: [
                    /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-blue-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 4057,
                      columnNumber: 21
                    }, this),
                    "Approved"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4056,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4055,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "REJECTED", children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-red-600 font-medium", children: [
                    /* @__PURE__ */ jsxDEV(CloseCircleOutlined, { className: "text-red-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 4064,
                      columnNumber: 21
                    }, this),
                    "Rejected"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4063,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4062,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "delete", children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-gray-600 font-medium", children: [
                    /* @__PURE__ */ jsxDEV(DeleteOutlined, { className: "text-gray-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                      lineNumber: 4071,
                      columnNumber: 21
                    }, this),
                    "Deleted"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4070,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4069,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4032,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4026,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Note (Optional)" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4078,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input.TextArea,
              {
                placeholder: "Add any notes regarding this status change",
                value: approvalNote,
                onChange: (e) => setApprovalNote(e.target.value),
                rows: 4,
                className: "w-full"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4081,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4077,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowApprovalModal(false);
                  setCurrentBorrower(null);
                  setApprovalStatus("");
                  setApprovalNote("");
                },
                className: "px-4 py-2 border rounded-md",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4090,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleUpdateApprovalStatus(approvalStatus),
                className: "px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700",
                children: "Update Status"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4101,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4089,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 4015,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 4006,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        open: isLoanModalOpen,
        onCancel: () => setIsLoanModalOpen(false),
        footer: null,
        centered: true,
        width: 420,
        children: /* @__PURE__ */ jsxDEV("div", { className: "p-1", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800", children: "Update Loan Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4121,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Modify requested and approved loan amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4125,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4120,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Requested Loan Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4132,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                size: "large",
                prefix: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: "₹" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4138,
                  columnNumber: 25
                }, this),
                placeholder: "Enter requested amount",
                value: loanAmounts.requested_loan_amount,
                className: "rounded-xl h-12",
                onChange: (e) => setLoanAmounts({
                  ...loanAmounts,
                  requested_loan_amount: e.target.value
                })
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4136,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(loanAmounts?.requested_loan_amount) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4149,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4131,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Approved Loan Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4156,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                size: "large",
                prefix: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: "₹" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4162,
                  columnNumber: 25
                }, this),
                placeholder: "Enter approved amount",
                value: loanAmounts.approved_loan_amount,
                className: "rounded-xl h-12",
                onChange: (e) => setLoanAmounts({
                  ...loanAmounts,
                  approved_loan_amount: e.target.value
                })
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4160,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(loanAmounts?.approved_loan_amount) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4173,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4155,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-3 pt-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setIsLoanModalOpen(false),
                className: "px-5 py-2.5 rounded-xl border border-gray-300 text-gray-700 font-medium hover:bg-gray-100 transition-all duration-200",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4180,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleSubmitLoanAmounts,
                className: "px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold shadow-md hover:shadow-lg hover:scale-[1.02] transition-all duration-200",
                children: "Submit"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4187,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4179,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 4117,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 4110,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        open: showPenaltyModal,
        onCancel: () => {
          setShowPenaltyModal(false);
          setPenaltyLoan(null);
          setPenaltyCharges([{ amount: "", reason: "" }]);
        },
        footer: null,
        centered: true,
        width: 700,
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 font-bold text-lg", children: "View Penalty Charges" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 4210,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 4209,
          columnNumber: 11
        }, this),
        children: /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: [
          penaltyLoan && /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 border border-orange-200 rounded-xl p-4 mb-5", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Borrower" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4220,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: penaltyLoan?.borrower?.full_name || penaltyLoan?.borrower_name || "—" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4221,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4219,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Loan ID" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4226,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: penaltyLoan?.loan_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4227,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4225,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Loan Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4230,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-green-600", children: [
                "₹",
                penaltyLoan?.loan_amount
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4231,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4229,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Due Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4234,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-red-600", children: penaltyLoan?.end_date?.split("T")[0]?.split("-")?.reverse()?.join("-") || "—" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4235,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4233,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4218,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4217,
            columnNumber: 13
          }, this),
          penaltyLoan?.extra_charges?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-600 uppercase mb-2", children: "Existing Charges" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4246,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg border overflow-hidden", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-100 text-gray-600 text-xs font-semibold", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left", children: "Status" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4251,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left", children: "Reason" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4252,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right", children: "Charge (₹)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4253,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right", children: "Paid (₹)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4254,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right", children: "Balance (₹)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4255,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4250,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4249,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-200", children: penaltyLoan.extra_charges.map((charge, idx) => {
                const isPaid = charge.paid === true;
                const paidAmount = charge.paid_amount || (isPaid ? charge.amount : 0);
                const balanceAmount = charge.balance_amount || (isPaid ? 0 : charge.amount - paidAmount);
                let statusText = "Unpaid";
                let statusColor = "bg-red-100 text-red-700";
                if (isPaid) {
                  statusText = "Paid";
                  statusColor = "bg-green-100 text-green-700";
                } else if (paidAmount > 0 && paidAmount < charge.amount) {
                  statusText = "Partially Paid";
                  statusColor = "bg-yellow-100 text-yellow-700";
                }
                return /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-100", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("span", { className: `text-[10px] font-bold px-2 py-0.5 rounded-full ${statusColor}`, children: statusText }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4275,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4274,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-gray-700", children: charge.reason }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4279,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right font-medium text-gray-800", children: [
                    "₹",
                    Number(charge.amount || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4280,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-green-600 font-semibold", children: paidAmount > 0 ? `₹${paidAmount.toLocaleString("en-IN")}` : "—" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4283,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-red-600 font-semibold", children: balanceAmount > 0 ? `₹${balanceAmount.toLocaleString("en-IN")}` : "—" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                    lineNumber: 4286,
                    columnNumber: 29
                  }, this)
                ] }, charge._id || idx, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4273,
                  columnNumber: 25
                }, this);
              }) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4258,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-orange-50 text-orange-800 font-bold", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("td", { colSpan: "2", className: "px-3 py-2 text-sm", children: "Totals" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4295,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: [
                  "₹",
                  penaltyLoan.extra_charges.reduce((s, c) => s + Number(c.amount || 0), 0).toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4296,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: [
                  "₹",
                  penaltyLoan.extra_charges.reduce((s, c) => s + Number(c.paid_amount || (c.paid ? c.amount : 0)), 0).toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4299,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: [
                  "₹",
                  penaltyLoan.extra_charges.reduce((s, c) => s + Number(c.balance_amount || (c.paid ? 0 : c.amount - (c.paid_amount || 0))), 0).toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                  lineNumber: 4302,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4294,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
                lineNumber: 4293,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4248,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4247,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4245,
            columnNumber: 13
          }, this),
          penaltyCharges.some((c) => c.amount) && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 text-right text-sm font-bold text-orange-600", children: [
            "New Charges Total: ₹",
            penaltyCharges.reduce((s, c) => s + Number(c.amount || 0), 0).toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4350,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-6 pt-4 border-t", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowPenaltyModal(false);
                setPenaltyLoan(null);
                setPenaltyCharges([{ amount: "", reason: "" }]);
              },
              className: "px-5 py-2 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 font-medium",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
              lineNumber: 4365,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
            lineNumber: 4364,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
          lineNumber: 4214,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
        lineNumber: 4198,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
    lineNumber: 1997,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx",
    lineNumber: 1996,
    columnNumber: 5
  }, this);
};
_s(Loan, "+UtXTaTtyFEOAYUgju4OeKD7oaI=", false, function() {
  return [useNavigate, Form.useForm];
});
_c = Loan;
export default Loan;
var _c;
$RefreshReg$(_c, "Loan");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Loan.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBKzVCNEQsU0FtL0JsRCxVQW4vQmtEOzJCQS81QjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsU0FBU0MsZ0JBQWdCO0FBQzdDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQVNDLE9BQU9DLFFBQVFMLFNBQVNNLFVBQVVDLFVBQVVDLE1BQU1DLFFBQVFDLE1BQU1DLFFBQVFDLFNBQVNDLE1BQU1DLFlBQVlDLFlBQVlDLFNBQVNDLGVBQWU7QUFDaEosU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLFNBQVNDLGNBQWNDLGVBQWVDLGVBQWVDLFFBQVFDLE9BQU9DLGlCQUFpQkMsaUJBQWlCQyxrQkFBa0JDLFdBQVdDLFlBQVlDLGVBQWVDLFFBQVFDLGlCQUFpQjtBQUN2TCxPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxnQkFBZ0I7QUFDdkIsU0FBU0MsaUNBQWlDO0FBQzFDLE9BQU9DLDhCQUE4QjtBQUNyQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxTQUFTQyxZQUFZQyxTQUFTQyxPQUFPQyxZQUFZQyxRQUFRQyxrQkFBa0I7QUFDcEYsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDhCQUE4QjtBQUN2QyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0Msd0JBQXdCO0FBQ2pDLE9BQU9DLGdCQUFnQjtBQUN2QixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLE9BQU9BLE1BQU07QUFBQUMsS0FBQTtBQUNqQixRQUFNQyxXQUFXdEMsWUFBWTtBQUM3QixRQUFNLENBQUN1QyxPQUFPQyxRQUFRLElBQUkvRSxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0YsUUFBUUMsU0FBUyxJQUFJakYsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2tGLFdBQVdDLFlBQVksSUFBSW5GLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNvRixXQUFXQyxZQUFZLElBQUlyRixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDc0YsZ0JBQWdCQyxpQkFBaUIsSUFBSXZGLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUN3RixXQUFXQyxZQUFZLElBQUl6RixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDMEYsaUJBQWlCQyxrQkFBa0IsSUFBSTNGLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM0RixpQkFBaUJDLGtCQUFrQixJQUFJN0YsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzhGLGlCQUFpQkMsa0JBQWtCLElBQUkvRixTQUFTLElBQUk7QUFDM0QsUUFBTSxDQUFDZ0csZUFBZUMsZ0JBQWdCLElBQUlqRyxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDa0csdUJBQXVCQyx3QkFBd0IsSUFBSW5HLFNBQVMsSUFBSTtBQUN2RSxRQUFNLENBQUNvRyxZQUFZQyxhQUFhLElBQUlyRyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDc0csV0FBV0MsWUFBWSxJQUFJdkcsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3dHLGlCQUFpQkMsa0JBQWtCLElBQUl6RyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDMEcsY0FBY0MsZUFBZSxJQUFJM0csU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQzRHLG9CQUFvQkMscUJBQXFCLElBQUk3RyxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDOEcsZUFBZUMsZ0JBQWdCLElBQUkvRyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDZ0gsa0JBQWtCQyxtQkFBbUIsSUFBSWpILFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUNrSCxrQkFBa0JDLG1CQUFtQixJQUFJbkgsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQ29ILGNBQWNDLGVBQWUsSUFBSXJILFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNzSCxXQUFXQyxZQUFZLElBQUl2SCxTQUFTLFVBQVU7QUFDckQsUUFBTSxDQUFDd0gsbUJBQW1CQyxvQkFBb0IsSUFBSXpILFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUMwSCxTQUFTQyxVQUFVLElBQUkzSCxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDNEgsWUFBWUMsYUFBYSxJQUFJN0gsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzhILG1CQUFtQkMsb0JBQW9CLElBQUkvSCxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDZ0ksZ0JBQWdCQyxpQkFBaUIsSUFBSWpJLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNrSSxjQUFjQyxlQUFlLElBQUluSSxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDb0ksY0FBY0MsZUFBZSxJQUFJckksU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ3NJLElBQUksSUFBSXZILEtBQUt3SCxRQUFRO0FBQzVCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJekksU0FBUztBQUFBLElBQ25DMEksZUFBZTtBQUFBLElBQ2ZDLGVBQWU7QUFBQSxJQUNmQyxjQUFjO0FBQUEsSUFDZEMsZUFBZTtBQUFBLElBQ2ZDLGVBQWU7QUFBQSxJQUNmQyxnQkFBZ0I7QUFBQSxJQUNoQkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNoQixDQUFDO0FBQ0QsUUFBTUMsbUJBQW1CO0FBQUEsSUFDdkI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUFXO0FBRWIsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSXBKLFNBQVMsS0FBSztBQUV4RCxRQUFNLENBQUNxSixhQUFhQyxjQUFjLElBQUl0SixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDdUosZ0JBQWdCQyxpQkFBaUIsSUFBSXhKLFNBQVMsS0FBSztBQUUxRCxRQUFNLENBQUN5SixVQUFVQyxXQUFXLElBQUkxSixTQUFTO0FBQUEsSUFDdkMySixVQUFVO0FBQUEsSUFBSUMsVUFBVTtBQUFBLElBQUlDLFNBQVM7QUFBQSxJQUFJQyxVQUFVO0FBQUEsSUFDbkRDLFVBQVU7QUFBQSxJQUFJQyxXQUFXO0FBQUEsSUFBSUMsUUFBUTtBQUFBLElBQUlDLFNBQVM7QUFBQSxFQUNwRCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJcEssU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ3FLLHFCQUFxQkMsc0JBQXNCLElBQUl0SyxTQUFTLElBQUk7QUFDbkUsUUFBTSxDQUFDdUssa0JBQWtCQyxtQkFBbUIsSUFBSXhLLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUN5Syx1QkFBdUJDLHdCQUF3QixJQUFJMUssU0FBUyxJQUFJO0FBQ3ZFLFFBQU0sQ0FBQzJLLGlCQUFpQkMsa0JBQWtCLElBQUk1SyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNkssYUFBYUMsY0FBYyxJQUFJOUssU0FBUyxFQUFFO0FBRWpELFFBQU0sQ0FBQytLLGFBQWFDLGNBQWMsSUFBSWhMLFNBQVM7QUFBQSxJQUM3Q2lMLHVCQUF1QjtBQUFBLElBQ3ZCQyxzQkFBc0I7QUFBQSxFQUN4QixDQUFDO0FBR0QsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJcEwsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ3FMLGFBQWFDLGNBQWMsSUFBSXRMLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUN1TCxnQkFBZ0JDLGlCQUFpQixJQUFJeEw7QUFBQUEsSUFBUztBQUFBLE1BQ25ELEVBQUV5TCxRQUFRLElBQUlDLFFBQVEsR0FBRztBQUFBLElBQUM7QUFBQSxFQUMzQjtBQUNELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSTVMLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUM2TCxtQkFBbUJDLG9CQUFvQixJQUFJOUwsU0FBUyxJQUFJO0FBRy9ELFFBQU0rTCx1QkFBdUJBLENBQUNOLFdBQVc7QUFDdkMsUUFBSUEsV0FBV08sVUFBYVAsV0FBVyxLQUFNLFFBQU87QUFDcEQsV0FBTyxJQUFJUSxLQUFLQyxhQUFhLFNBQVM7QUFBQSxNQUNwQ0MsT0FBTztBQUFBLE1BQ1BDLFVBQVU7QUFBQSxNQUNWQyx1QkFBdUI7QUFBQSxJQUN6QixDQUFDLEVBQUVDLE9BQU9iLE1BQU07QUFBQSxFQUNsQjtBQUVBLFFBQU1jLGFBQWFBLE1BQU07QUFDdkIsUUFBSTtBQUNGLFlBQU1DLE9BQU9DLEtBQUtDLE1BQU1DLGFBQWFDLFFBQVEsTUFBTSxDQUFDO0FBQ3BELGFBQU9KLE1BQU1LLE9BQU9MLE1BQU1NLE1BQU07QUFBQSxJQUNsQyxRQUFRO0FBQ04sYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBK0ZBLFFBQU1DLDBCQUEwQixZQUFZO0FBQzFDLFFBQUk7QUFDRixZQUFNQyxVQUFVO0FBQUEsUUFDZDlCLHNCQUFzQkgsWUFBWUc7QUFBQUEsUUFDbEMrQixZQUFZVixXQUFXO0FBQUEsTUFDekI7QUFFQSxZQUFNcE0sSUFBSStNLElBQUksbUNBQW1DOUYsY0FBY3lGLEdBQUcsSUFBSUcsT0FBTztBQUU3RWxNLGNBQVFxTSxRQUFRLG1DQUFtQztBQUFBLElBRXJELFNBQVNDLE9BQU87QUFDZEMsY0FBUUMsSUFBSUYsS0FBSztBQUNqQnRNLGNBQVFzTSxNQUFNLCtCQUErQjtBQUFBLElBQy9DLFVBQUM7QUFFQ3hDLHlCQUFtQixLQUFLO0FBQ3hCM0UsdUJBQWlCLENBQUNzSCxTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNyQztBQUFBLEVBQ0Y7QUFHQXpOLFlBQVUsTUFBTTtBQUNkLFFBQUl5SyxvQkFBb0JFLDBCQUEwQm5ELGFBQWFoQyxlQUFla0ksU0FBUyxHQUFHO0FBQ3hGLFlBQU1DLE9BQU9sRCxpQkFBaUJtRCxZQUFZO0FBQzFDLFlBQU1DLFVBQVVySSxlQUFlc0ksT0FBTyxDQUFBQyxRQUFPO0FBQzNDLGNBQU1DLFFBQVFELElBQUlFLGVBQWUsSUFBSUwsWUFBWTtBQUNqRCxjQUFNTSxTQUFTSCxJQUFJSSxnQkFBZ0IsSUFBSVAsWUFBWTtBQUNuRCxlQUFPSSxLQUFLSSxTQUFTVCxJQUFJLEtBQUtPLE1BQU1FLFNBQVNULElBQUk7QUFBQSxNQUNuRCxDQUFDO0FBQ0QsVUFBSUUsUUFBUUgsU0FBUyxHQUFHO0FBQ3RCbEQsK0JBQXVCcUQsT0FBTztBQUFBLE1BQ2hDLE9BQU87QUFFTHJELCtCQUF1QixFQUFFO0FBQUEsTUFDM0I7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUNoRixnQkFBZ0JpRixrQkFBa0JFLHVCQUF1Qm5ELFNBQVMsQ0FBQztBQUV2RSxRQUFNNkcsZUFBZUEsQ0FBQ1YsU0FBUztBQUM3QixVQUFNVyxVQUFVWCxLQUFLWSxLQUFLO0FBQzFCLFFBQUksQ0FBQ0QsU0FBUztBQUVaNUQsMEJBQW9CLEVBQUU7QUFDdEJGLDZCQUF1QixJQUFJO0FBQzNCSSwrQkFBeUIsSUFBSTtBQUM3QkkscUJBQWUsRUFBRTtBQUNqQjtBQUFBLElBQ0Y7QUFFQSxVQUFNd0QsWUFBWUYsUUFBUVYsWUFBWTtBQUN0QyxRQUFJYSxZQUFZO0FBQ2hCLFFBQUlDLGlCQUFpQjtBQUVyQixlQUFXLENBQUNDLFdBQVdDLEtBQUssS0FBS0MsT0FBT0MsUUFBUW5GLFFBQVEsR0FBRztBQUN6RCxZQUFNb0YsUUFBUUgsTUFBTUksS0FBSyxDQUFBQyxTQUFRO0FBQy9CLGNBQU1qQixRQUFRaUIsS0FBS0MsU0FBU0MsYUFBYUYsS0FBS0csVUFBVUQsYUFBYUYsS0FBS3ZDLE1BQU15QyxhQUFhLElBQUl2QixZQUFZO0FBQzdHLGNBQU1NLFNBQVNlLEtBQUtDLFNBQVNmLGdCQUFnQmMsS0FBS0csVUFBVWpCLGdCQUFnQmMsS0FBS3ZDLE1BQU15QixnQkFBZ0IsSUFBSVAsWUFBWTtBQUN2SCxlQUFPSSxLQUFLSSxTQUFTSSxTQUFTLEtBQUtOLE1BQU1FLFNBQVNJLFNBQVM7QUFBQSxNQUM3RCxDQUFDO0FBQ0QsVUFBSU8sT0FBTztBQUNUTixvQkFBWU07QUFDWkwseUJBQWlCQztBQUNqQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsUUFBSUYsYUFBYUMsZ0JBQWdCO0FBQy9CLFlBQU1XLFNBQVM7QUFBQSxRQUNiQyxXQUFXO0FBQUEsUUFDWHhGLFVBQVU7QUFBQSxRQUNWQyxTQUFTO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFVBQVU7QUFBQSxRQUNWQyxXQUFXO0FBQUEsUUFDWEMsUUFBUTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxNQUNYO0FBQ0EsWUFBTW1GLFlBQVlGLE9BQU9YLGNBQWMsS0FBS0E7QUFDNUNqSCxtQkFBYThILFNBQVM7QUFDdEIzRSwrQkFBeUIyRSxTQUFTO0FBQ2xDN0UsMEJBQW9CNEQsT0FBTztBQUUzQjlELDZCQUF1QixJQUFJO0FBRTNCUSxxQkFBZXNELE9BQU87QUFBQSxJQUN4QixPQUFPO0FBRUw5RCw2QkFBdUIsRUFBRTtBQUN6QkksK0JBQXlCLElBQUk7QUFDN0JGLDBCQUFvQjRELE9BQU87QUFDM0JrQixZQUFNLDhDQUE4QztBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUVBLFFBQU1DLHNCQUFzQkEsQ0FBQ1IsU0FBUztBQUNwQzFILG9CQUFnQjBILElBQUk7QUFFcEIvRCxtQkFBZTtBQUFBLE1BQ2JDLHVCQUF1QjhELE1BQU1TLGVBQWU7QUFBQSxNQUM1Q3RFLHNCQUFzQjZELE1BQU03RCx3QkFBd0I7QUFBQSxJQUN0RCxDQUFDO0FBRUROLHVCQUFtQixJQUFJO0FBQUEsRUFDekI7QUFHQSxRQUFNNkUsbUJBQW1CLE9BQU9WLE1BQU1XLGNBQWM7QUFFbEQ3TCxnQkFBWTtBQUFBLE1BQ1Y4TCxPQUFPLEdBQUdELFNBQVM7QUFBQSxNQUNuQkUsU0FBUyw4REFBOERGLFNBQVM7QUFBQSxNQUNoRkcsV0FBVyxZQUFZO0FBQ3JCLFlBQUk7QUFFRixnQkFBTTFQLElBQUkyUCxNQUFNLG1DQUFtQztBQUFBLFlBQ2pEaEQsSUFBSWlDLEtBQUtsQztBQUFBQSxZQUNUa0QsaUJBQWlCTDtBQUFBQSxZQUNqQnpDLFlBQVlWLFdBQVc7QUFBQSxVQUN6QixDQUFDO0FBR0QsY0FBSW1ELGNBQWMsWUFBWTtBQUM1QixrQkFBTXZQLElBQUk2UDtBQUFBQSxjQUNSO0FBQUEsY0FDQTtBQUFBLGdCQUNFQyxRQUFRbEIsS0FBS2xDO0FBQUFBLGdCQUNicUQsUUFBUTtBQUFBLGNBQ1Y7QUFBQSxjQUNBO0FBQUEsZ0JBQ0VDLFNBQVM7QUFBQSxrQkFDUCxnQkFBZ0I7QUFBQSxnQkFDbEI7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFFQXJQLGtCQUFRcU0sUUFBUSwwQkFBMEJ1QyxTQUFTLGVBQWU7QUFDbEV6SiwyQkFBaUIsQ0FBQ3NILFNBQVNBLE9BQU8sQ0FBQztBQUFBLFFBQ3JDLFNBQVNILE9BQU87QUFDZEMsa0JBQVFELE1BQU0sK0JBQStCQSxLQUFLO0FBQ2xEdE0sa0JBQVFzTSxNQUFNLDhCQUE4QjtBQUFBLFFBQzlDO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNZ0QsOEJBQThCQSxDQUFDQyxNQUFNO0FBQ3pDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQmxLLGtCQUFjaUssS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTSxDQUFDRSxhQUFhQyxjQUFjLElBQUl6USxTQUFTO0FBQUEsSUFDN0MwUSxZQUFZO0FBQUEsSUFDWjVQLFNBQVM7QUFBQSxJQUNUNlAsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJN1EsU0FBUztBQUFBLElBQ3ZDa1AsVUFBVTtBQUFBLElBQ1ZNLGFBQWE7QUFBQSxJQUNic0IsWUFBWTtBQUFBLElBQ1pDLFFBQVE7QUFBQSxJQUNSQyxpQkFBaUI7QUFBQSxJQUNqQkMsa0JBQWtCO0FBQUEsSUFDbEJDLHNCQUFzQjtBQUFBLElBQ3RCQyxNQUFNO0FBQUEsSUFDTkMsbUJBQW1CO0FBQUEsSUFDbkJDLG1CQUFtQjtBQUFBLElBQ25CQyxnQkFBZ0I7QUFBQSxJQUNoQkMsZUFBZTtBQUFBLElBQ2ZDLHVCQUF1QjtBQUFBLElBQ3ZCekIsaUJBQWlCO0FBQUEsSUFDakIwQixRQUFRO0FBQUEsRUFDVixDQUFDO0FBRUQsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUkzUixTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUM0UixnQkFBZ0JDLGlCQUFpQixJQUFJN1IsU0FBUztBQUFBLElBQ25Ea1AsVUFBVTtBQUFBLElBQ1ZNLGFBQWE7QUFBQSxJQUNic0IsWUFBWTtBQUFBLElBQ1pDLFFBQVE7QUFBQSxJQUNSQyxpQkFBaUI7QUFBQSxJQUNqQkMsa0JBQWtCO0FBQUEsSUFDbEJDLHNCQUFzQjtBQUFBLElBQ3RCQyxNQUFNO0FBQUEsSUFDTkMsbUJBQW1CO0FBQUEsSUFDbkJDLG1CQUFtQjtBQUFBLElBQ25CQyxnQkFBZ0I7QUFBQSxJQUNoQkMsZUFBZTtBQUFBLElBQ2Z4QixpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTStCLHdCQUF3QixPQUFPQyxlQUFlO0FBQ2xELFFBQUk7QUFDRixZQUFNQyxXQUFXLE1BQU03UixJQUFJOFIsSUFBSSx1QkFBdUJGLFVBQVUsRUFBRTtBQUNsRWhNLHlCQUFtQmlNLFNBQVNFLElBQUk7QUFDaEN2TCxzQkFBZ0IsRUFBRTtBQUNsQkYseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTMkcsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDRCQUE0QkEsS0FBSztBQUMvQ3FELHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1o1UCxTQUFTO0FBQUEsUUFDVDZQLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU13Qix1QkFBdUIsWUFBWTtBQUN2QyxRQUNFLENBQUN6TCxnQkFDQUEsaUJBQWlCLFdBQVcsQ0FBQ0UsbUJBQW1CeUgsS0FBSyxHQUN0RDtBQUNBb0MscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWjVQLFNBQVM7QUFBQSxRQUNUNlAsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUNBLFFBQUk7QUFDRixZQUFNeFEsSUFBSTJQLE1BQU0sVUFBVWhLLGdCQUFnQitHLEdBQUcsV0FBVztBQUFBLFFBQ3REdUYsZ0JBQ0UxTCxpQkFBaUIsVUFBVUUscUJBQXFCRjtBQUFBQSxNQUNwRCxDQUFDO0FBQ0QrSixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaNVAsU0FBUztBQUFBLFFBQ1Q2UCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0RsSyx5QkFBbUIsS0FBSztBQUN4QkUsc0JBQWdCLEVBQUU7QUFDbEJFLDRCQUFzQixFQUFFO0FBQ3hCZCx5QkFBbUIsSUFBSTtBQUN2QkUsdUJBQWlCLENBQUNzSCxTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNyQyxTQUFTSCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQzNDcUQscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWjVQLFNBQVM7QUFBQSxRQUNUNlAsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTTBCLDBCQUEwQixPQUFPTixZQUFZN0IsV0FBVztBQUM1RCxRQUFJO0FBQ0YsWUFBTThCLFdBQVcsTUFBTTdSLElBQUk4UixJQUFJLG1CQUFtQkYsVUFBVSxFQUFFO0FBQzlEaE0seUJBQW1CaU0sU0FBU0UsSUFBSTtBQUNoQ2pLLHdCQUFrQmlJLE1BQU07QUFDeEIvSCxzQkFBZ0IsRUFBRTtBQUNsQkosMkJBQXFCLElBQUk7QUFBQSxJQUMzQixTQUFTcUYsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDRCQUE0QkEsS0FBSztBQUMvQ3FELHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1o1UCxTQUFTO0FBQUEsUUFDVDZQLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU0yQiw2QkFBNkIsT0FBT3RLLG9CQUFtQjtBQUMzRCxVQUFNaUksU0FBUzlHLGdCQUFnQmpELHVCQUF1QmdNLE1BQU1yRixNQUFNL0csaUJBQWlCb00sTUFBTXJGO0FBRXpGLFFBQUksQ0FBQzdFLGlCQUFnQjtBQUNuQnlJLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1o1UCxTQUFTO0FBQUEsUUFDVDZQLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFDQSxRQUFJO0FBQ0YsWUFBTXhRLElBQUkyUCxNQUFNLG1DQUFtQztBQUFBLFFBQ2pEaEQsSUFBSW1EO0FBQUFBLFFBQVFGLGlCQUFpQi9IO0FBQUFBLFFBQzdCaUYsWUFBWVYsV0FBVztBQUFBLE1BQ3pCLENBQUM7QUFDRHpMLGNBQVFxTSxRQUFRLHNEQUFzRDtBQUN0RXNELHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1o1UCxTQUFTLDBCQUEwQmtILGVBQWM7QUFBQSxRQUNqRDJJLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRCxVQUFJeEgsZUFBZTtBQUNqQkMseUJBQWlCLEtBQUs7QUFDdEJ2RCwyQkFBbUIsS0FBSztBQUN4QkkseUJBQWlCLENBQUNzSCxTQUFTQSxPQUFPLENBQUM7QUFBQSxNQUNyQztBQUNBeEYsMkJBQXFCLEtBQUs7QUFDMUJFLHdCQUFrQixFQUFFO0FBQ3BCRSxzQkFBZ0IsRUFBRTtBQUNsQnBDLHlCQUFtQixJQUFJO0FBQ3ZCRSx1QkFBaUIsQ0FBQ3NILFNBQVNBLE9BQU8sQ0FBQztBQUFBLElBQ3JDLFNBQVNILE9BQU87QUFDZEMsY0FBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdERxRCxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaNVAsU0FBUztBQUFBLFFBQ1Q2UCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEIscUJBQXFCQSxDQUFDQyxlQUFlLE9BQU9DLGFBQWE7QUFDN0QsVUFBTUMsU0FBUztBQUFBLE1BQ2JDLFNBQVMsQ0FBQyxHQUFHLElBQUksR0FBRztBQUFBLE1BQ3BCQyxVQUFVLENBQUMsSUFBSSxJQUFJLEVBQUU7QUFBQSxJQUN2QjtBQUNBLFVBQU1DLFdBQVc7QUFBQSxNQUNmO0FBQUEsUUFDRWxELE9BQU87QUFBQSxRQUNQbUQsUUFBUTtBQUFBLFVBQ04sRUFBRUMsT0FBTyxhQUFhekMsT0FBT21DLFVBQVV2RCxVQUFVRCxVQUFVO0FBQUEsVUFDM0QsRUFBRThELE9BQU8sZ0JBQWdCekMsT0FBT21DLFVBQVV2RCxVQUFVakIsYUFBYTtBQUFBLFVBQ2pFLEVBQUU4RSxPQUFPLGlCQUFpQnpDLE9BQU9tQyxVQUFVdkQsVUFBVThELE1BQU07QUFBQSxVQUMzRCxFQUFFRCxPQUFPLFdBQVd6QyxPQUFPbUMsVUFBVXZELFVBQVUrRCxRQUFRO0FBQUEsUUFBQztBQUFBLE1BRTVEO0FBQUEsTUFDQTtBQUFBLFFBQ0V0RCxPQUFPO0FBQUEsUUFDUG1ELFFBQVE7QUFBQSxVQUNOLEVBQUVDLE9BQU8sV0FBV3pDLE9BQU9tQyxVQUFVUyxRQUFRO0FBQUEsVUFDN0MsRUFBRUgsT0FBTyxlQUFlekMsT0FBT21DLFVBQVVqRCxZQUFZO0FBQUEsVUFDckQ7QUFBQSxZQUNFdUQsT0FBTztBQUFBLFlBQ1B6QyxPQUFPbUMsVUFBVVUsYUFDYnZQLE9BQU82TyxTQUFTVSxVQUFVLEVBQUU3RyxPQUFPLFlBQVksSUFDL0M7QUFBQSxVQUNOO0FBQUEsVUFDQSxFQUFFeUcsT0FBTyxtQkFBbUJ6QyxPQUFPbUMsVUFBVXpCLGdCQUFnQjtBQUFBLFVBQzdEO0FBQUEsWUFDRStCLE9BQU87QUFBQSxZQUNQekMsT0FBT21DLFVBQVVXLFdBQ2J4UCxPQUFPNk8sU0FBU1csUUFBUSxFQUFFOUcsT0FBTyxZQUFZLElBQzdDO0FBQUEsVUFDTjtBQUFBLFVBQ0EsRUFBRXlHLE9BQU8seUJBQXlCekMsT0FBT21DLFVBQVV4QixpQkFBaUI7QUFBQSxVQUNwRTtBQUFBLFlBQ0U4QixPQUFPO0FBQUEsWUFDUHpDLE9BQU9tQyxVQUFVWSxxQkFDYnpQLE9BQU82TyxTQUFTWSxrQkFBa0IsRUFBRS9HLE9BQU8sWUFBWSxJQUN2RDtBQUFBLFVBQ047QUFBQSxVQUNBLEVBQUV5RyxPQUFPLGlCQUFpQnpDLE9BQU9tQyxVQUFVdkIscUJBQXFCO0FBQUEsVUFDaEUsRUFBRTZCLE9BQU8saUJBQWlCekMsT0FBT21DLFVBQVUxQixPQUFPO0FBQUEsVUFDbEQ7QUFBQSxZQUNFZ0MsT0FBTztBQUFBLFlBQ1B6QyxRQUNHZ0QsT0FBT2IsVUFBVWpELFdBQVcsS0FBSyxNQUNqQzhELE9BQU9iLFVBQVV6QixlQUFlLEtBQUssTUFDckNzQyxPQUFPYixVQUFVeEIsZ0JBQWdCLEtBQUs7QUFBQSxVQUUzQztBQUFBLFFBQUM7QUFBQSxNQUdMO0FBQUEsTUFDQTtBQUFBLFFBQ0V0QixPQUFPO0FBQUEsUUFDUG1ELFFBQVE7QUFBQSxVQUNOLEVBQUVDLE9BQU8saUJBQWlCekMsT0FBT21DLFVBQVVsQixjQUFjO0FBQUEsVUFDekQsRUFBRXdCLE9BQU8sZUFBZXpDLE9BQU9tQyxVQUFVcEIsbUJBQW1CdkQsUUFBUTJFLFVBQVVuQixnQkFBZ0J4RCxRQUFRMkUsVUFBVXJCLG1CQUFtQm5DLGFBQWEsTUFBTTtBQUFBLFFBQUM7QUFBQSxNQUUzSjtBQUFBLElBQUM7QUFHSCxVQUFNc0UsTUFBTSxJQUFJOVEsTUFBTSxLQUFLLE1BQU0sSUFBSTtBQUNyQyxVQUFNK1EsV0FBV0EsQ0FBQ0MsTUFBT0EsSUFBSUMsT0FBT0QsQ0FBQyxJQUFJO0FBQ3pDLFFBQUlFLElBQUk7QUFHUixRQUFJalIsWUFBWTtBQUNkNlEsVUFBSUssU0FBU2xSLFlBQVksT0FBTyxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQUEsSUFDL0M7QUFHQSxVQUFNdU4sU0FBU3dDLFVBQVVTLFdBQVc7QUFDcENLLFFBQUlNLFFBQVEsYUFBYSxNQUFNO0FBQy9CTixRQUFJTyxZQUFZLEVBQUU7QUFDbEIsVUFBTUMsYUFBYVIsSUFBSVMsYUFBYS9ELE1BQU07QUFDMUNzRCxRQUFJTSxRQUFRLGFBQWEsUUFBUTtBQUNqQ04sUUFBSU8sWUFBWSxDQUFDO0FBQ2pCLFVBQU1HLGFBQWFWLElBQUlTLGFBQWEsV0FBVztBQUMvQyxVQUFNRSxNQUFNO0FBQ1osVUFBTUMsU0FBUyxNQUFNSixhQUFhRyxNQUFNRDtBQUN4Q1YsUUFBSWEsS0FBSyxhQUFhRCxRQUFRLElBQUksRUFBRUUsT0FBTyxPQUFPLENBQUM7QUFDbkRkLFFBQUlNLFFBQVEsYUFBYSxNQUFNO0FBQy9CTixRQUFJTyxZQUFZLEVBQUU7QUFDbEJQLFFBQUllLGFBQWEsR0FBRzVCLE9BQU9DLE9BQU87QUFDbENZLFFBQUlhLEtBQUtuRSxRQUFRa0UsU0FBU0YsYUFBYUMsS0FBSyxJQUFJLEVBQUVHLE9BQU8sT0FBTyxDQUFDO0FBR2pFZCxRQUFJZ0IsYUFBYSxHQUFHLElBQUksR0FBRztBQUMzQmhCLFFBQUlpQixLQUFLLEdBQUcsSUFBSSxLQUFLLElBQUksR0FBRztBQUM1QmpCLFFBQUllLGFBQWEsS0FBSyxLQUFLLEdBQUc7QUFDOUJmLFFBQUlPLFlBQVksRUFBRTtBQUNsQlAsUUFBSWEsS0FBSyw2QkFBNkIsS0FBSyxJQUFJLEVBQUVDLE9BQU8sU0FBUyxDQUFDO0FBRWxFLFVBQU1JLFlBQVlBLENBQUMxQixPQUFPekMsT0FBT29FLEdBQUdmLE9BQU07QUFDeEMsWUFBTWdCLFdBQVc7QUFDakIsWUFBTVYsY0FBYTtBQUNuQixZQUFNRixjQUFhWSxXQUFXVixjQUFhO0FBRTNDLFlBQU1XLFdBQVdwQixTQUFTbEQsS0FBSztBQUUvQixZQUFNdUUsUUFBUXRCLElBQUl1QixnQkFBZ0JGLFVBQVViLFdBQVU7QUFDdEQsWUFBTWdCLGFBQWE7QUFDbkIsWUFBTUMsYUFBYUgsTUFBTXJILFNBQVN1SDtBQUNsQyxZQUFNRSxZQUFZQyxLQUFLQyxJQUFJLEdBQUdILGFBQWEsQ0FBQztBQUc1Q3pCLFVBQUk2QixhQUFhLEtBQUssS0FBSyxHQUFHO0FBQzlCN0IsVUFBSWlCLEtBQUtFLEdBQUdmLElBQUdnQixVQUFVTSxTQUFTO0FBR2xDMUIsVUFBSWUsYUFBYSxHQUFHLElBQUksR0FBRztBQUMzQmYsVUFBSU8sWUFBWSxDQUFDO0FBQ2pCUCxVQUFJYSxLQUFLckIsUUFBUSxLQUFLMkIsSUFBSSxHQUFHZixLQUFJLENBQUM7QUFHbENKLFVBQUllLGFBQWEsSUFBSSxJQUFJLEVBQUU7QUFDM0IsVUFBSWUsUUFBUTFCLEtBQUk7QUFDaEJrQixZQUFNUyxRQUFRLENBQUFDLFNBQVE7QUFDcEJoQyxZQUFJYSxLQUFLbUIsTUFBTWIsSUFBSVQsY0FBYSxHQUFHb0IsS0FBSztBQUN4Q0EsaUJBQVNOO0FBQUFBLE1BQ1gsQ0FBQztBQUVELGFBQU9wQixLQUFJc0IsWUFBWTtBQUFBLElBQ3pCO0FBRUFwQyxhQUFTeUMsUUFBUSxDQUFDRSxRQUFRO0FBRXhCakMsVUFBSWdCLGFBQWEsR0FBRyxJQUFJLEdBQUc7QUFDM0JoQixVQUFJaUIsS0FBSyxJQUFJYixHQUFHLEtBQUssSUFBSSxHQUFHO0FBQzVCSixVQUFJZSxhQUFhLEtBQUssS0FBSyxHQUFHO0FBQzlCZixVQUFJTyxZQUFZLEVBQUU7QUFDbEJQLFVBQUlhLEtBQUtvQixJQUFJN0YsT0FBTyxLQUFLZ0UsSUFBSSxHQUFHLEVBQUVVLE9BQU8sU0FBUyxDQUFDO0FBQ25EVixXQUFLO0FBR0wsZUFBUzhCLElBQUksR0FBR0EsSUFBSUQsSUFBSTFDLE9BQU90RixRQUFRaUksS0FBSyxHQUFHO0FBQzdDLGNBQU1DLFlBQVlGLElBQUkxQyxPQUFPMkMsQ0FBQztBQUM5QixjQUFNRSxhQUFhSCxJQUFJMUMsT0FBTzJDLElBQUksQ0FBQztBQUNuQyxjQUFNRyxTQUFTakM7QUFDZixjQUFNa0MsUUFBUXBCLFVBQVVpQixVQUFVM0MsT0FBTzJDLFVBQVVwRixPQUFPLElBQUlzRixNQUFNO0FBQ3BFLFlBQUlFLFNBQVNGO0FBQ2IsWUFBSUQsWUFBWTtBQUNkRyxtQkFBU3JCLFVBQVVrQixXQUFXNUMsT0FBTzRDLFdBQVdyRixPQUFPLEtBQUtzRixNQUFNO0FBQUEsUUFDcEU7QUFDQWpDLFlBQUl1QixLQUFLQyxJQUFJVSxPQUFPQyxNQUFNO0FBQUEsTUFDNUI7QUFDQW5DLFdBQUs7QUFBQSxJQUNQLENBQUM7QUFFREosUUFBSU8sWUFBWSxFQUFFO0FBQ2xCUCxRQUFJYSxLQUFLLHlFQUF5RSxLQUFLVCxJQUFJLElBQUksRUFBRVUsT0FBTyxTQUFTLENBQUM7QUFDbEhkLFFBQUlpQixLQUFLLElBQUliLElBQUksSUFBSSxJQUFJLEVBQUU7QUFDM0JKLFFBQUlhLEtBQUssc0JBQXNCLEtBQUtULElBQUksSUFBSSxFQUFFVSxPQUFPLFNBQVMsQ0FBQztBQUcvRCxVQUFNMEIsYUFBYXhDLElBQUl5QyxTQUFTQyxTQUFTQyxVQUFVO0FBQ25ELFVBQU1DLFVBQVVKLGFBQWE7QUFDN0J4QyxRQUFJZ0IsYUFBYSxHQUFHLElBQUksR0FBRztBQUMzQmhCLFFBQUlpQixLQUFLLEdBQUcyQixTQUFTLEtBQUssSUFBSSxHQUFHO0FBQ2pDNUMsUUFBSWUsYUFBYSxLQUFLLEtBQUssR0FBRztBQUM5QmYsUUFBSU8sWUFBWSxDQUFDO0FBQ2pCUCxRQUFJYSxLQUFLLDZDQUE2QyxLQUFLK0IsVUFBVSxHQUFHLEVBQUU5QixPQUFPLFNBQVMsQ0FBQztBQUMzRmQsUUFBSWEsS0FBSyxtR0FBbUcsS0FBSytCLFVBQVUsR0FBRyxFQUFFOUIsT0FBTyxTQUFTLENBQUM7QUFDakpkLFFBQUlhLEtBQUssMkZBQTJGLEtBQUsrQixVQUFVLElBQUksRUFBRTlCLE9BQU8sU0FBUyxDQUFDO0FBRTFJLFFBQUk3QixjQUFjO0FBQ2hCZSxVQUFJNkMsS0FBSyxHQUFHM0QsVUFBVXZELFVBQVVELGFBQWEsTUFBTSxlQUFlO0FBQUEsSUFDcEUsT0FBTztBQUNMLFlBQU1vSCxVQUFVOUMsSUFBSStDLE9BQU8sTUFBTTtBQUNqQyxZQUFNQyxTQUFTQyxJQUFJQyxnQkFBZ0JKLE9BQU87QUFDMUNLLGFBQU9DLEtBQUtKLFFBQVEsUUFBUTtBQUFBLElBQzlCO0FBQUEsRUFDRjtBQVdBelcsWUFBVSxNQUFNO0FBQ2QsVUFBTWlTLGFBQWFILGVBQWUxQztBQUNsQyxRQUFJLENBQUM2QyxXQUFZO0FBRWpCLFVBQU0zSixnQkFBZXRELE1BQU1nSyxLQUFLLENBQUN0QyxTQUFTQSxLQUFLSyxRQUFRa0YsVUFBVTtBQUNqRSxRQUFJLENBQUMzSixjQUFjO0FBRW5CLFVBQU13TyxVQUFVeE8sY0FBYXlPLGlCQUFpQjtBQUU5Q2hGLHNCQUFrQixDQUFDdEUsVUFBVTtBQUFBLE1BQzNCLEdBQUdBO0FBQUFBLE1BQ0hnRSxlQUFlcUY7QUFBQUEsTUFDZnZGLG1CQUFtQjtBQUFBLE1BQ25CQyxnQkFBZ0I7QUFBQSxNQUNoQkYsbUJBQW1CO0FBQUEsSUFDckIsRUFBRTtBQUVGLFFBQUl3RixZQUFZLGNBQWN4TyxjQUFhaUosbUJBQW1CeEUsS0FBSztBQUNqRWdGLHdCQUFrQixDQUFDdEUsVUFBVTtBQUFBLFFBQzNCLEdBQUdBO0FBQUFBLFFBQ0g4RCxtQkFBbUJqSixjQUFhaUosa0JBQWtCeEU7QUFBQUEsTUFDcEQsRUFBRTtBQUFBLElBQ0osV0FBVytKLFlBQVksV0FBV3hPLGNBQWFrSixnQkFBZ0J6RSxLQUFLO0FBQ2xFZ0Ysd0JBQWtCLENBQUN0RSxVQUFVO0FBQUEsUUFDM0IsR0FBR0E7QUFBQUEsUUFDSCtELGdCQUFnQmxKLGNBQWFrSixlQUFlekU7QUFBQUEsTUFDOUMsRUFBRTtBQUFBLElBQ0osV0FBVytKLFlBQVksY0FBY3hPLGNBQWFnSixtQkFBbUJ2RSxLQUFLO0FBQ3hFZ0Ysd0JBQWtCLENBQUN0RSxVQUFVO0FBQUEsUUFDM0IsR0FBR0E7QUFBQUEsUUFDSDZELG1CQUFtQmhKLGNBQWFnSixrQkFBa0J2RTtBQUFBQSxNQUNwRCxFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0YsR0FBRyxDQUFDK0UsZUFBZTFDLFVBQVVwSyxLQUFLLENBQUM7QUFFbkNoRixZQUFVLE1BQU07QUFDZCxVQUFNZ1gsZ0JBQWdCLFlBQVk7QUFDaEMsVUFBSTtBQUNGLGNBQU1DLFdBQVcsQ0FBQyxhQUFhLFlBQVksV0FBVyxZQUFZLFlBQVksYUFBYSxTQUFTO0FBQ3BHLGNBQU1DLFdBQVdELFNBQVNFLElBQUksQ0FBQS9HLFdBQVUvUCxJQUFJOFIsSUFBSSxtQ0FBbUMvQixNQUFNLEVBQUUsQ0FBQztBQUM1RixjQUFNZ0gsWUFBWSxNQUFNQyxRQUFRQyxJQUFJSixRQUFRO0FBQzVDLGNBQU1LLFNBQVMsQ0FBQztBQUNoQk4saUJBQVN6QixRQUFRLENBQUNwRixRQUFRb0gsUUFBUTtBQUNoQyxnQkFBTUMsTUFBTXJILE9BQU94QyxZQUFZO0FBQy9CMkosaUJBQU9FLEdBQUcsSUFBSUwsVUFBVUksR0FBRyxFQUFFcEYsS0FBS0EsUUFBUTtBQUFBLFFBQzVDLENBQUM7QUFFRCxjQUFNc0YsWUFBWSxNQUFNclgsSUFBSThSLElBQUksd0JBQXdCO0FBQ3hEb0YsZUFBT3BOLFNBQVN1TixVQUFVdEYsS0FBS0EsUUFBUTtBQUN2Q3hJLG9CQUFZMk4sTUFBTTtBQUNsQmpOLDBCQUFrQixJQUFJO0FBQUEsTUFDeEIsU0FBU2dELE9BQU87QUFDZEMsZ0JBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQUEsTUFDdEQ7QUFBQSxJQUNGO0FBQ0EwSixrQkFBYztBQUFBLEVBQ2hCLEdBQUcsRUFBRTtBQUdMaFgsWUFBVSxNQUFNO0FBQ2QsVUFBTTJYLGlCQUFpQixZQUFZO0FBQ2pDLFVBQUk7QUFDRixjQUFNekYsV0FBVyxNQUFNN1IsSUFBSThSLElBQUksZ0JBQWdCO0FBQy9DLFlBQUlELFNBQVM5QixVQUFVLElBQUssT0FBTSxJQUFJd0gsTUFBTSwyQkFBMkI7QUFDdkUzUyxpQkFBU2lOLFNBQVNFLElBQUk7QUFBQSxNQUN4QixTQUFTOUUsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx1Q0FBdUNBLEtBQUs7QUFBQSxNQUM1RDtBQUFBLElBQ0Y7QUFDQXFLLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxDQUFDelIsYUFBYSxDQUFDO0FBRWxCbEcsWUFBVSxNQUFNO0FBQ2QsVUFBTTZYLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTTNGLFdBQVcsTUFBTTdSLElBQUk4UixJQUFJLFlBQVk7QUFDM0NoTixrQkFBVStNLFNBQVNFLE1BQU0wRixLQUFLO0FBQUEsTUFDaEMsU0FBU0MsS0FBSztBQUNaeEssZ0JBQVFELE1BQU0seUJBQXlCeUssR0FBRztBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUNBRixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUw3WCxZQUFVLE1BQU07QUFDZCxVQUFNZ1ksaUJBQWlCLFlBQVk7QUFDakMsVUFBSTtBQUNGLGNBQU05RixXQUFXLE1BQU03UixJQUFJOFIsSUFBSSxxQkFBcUI7QUFDcEQ5TSxxQkFBYTZNLFVBQVVFLE1BQU02RixZQUFZLEVBQUU7QUFBQSxNQUM3QyxTQUFTM0ssT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFBQSxNQUNsRDtBQUFBLElBQ0Y7QUFDQTBLLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBRUwsUUFBTUUsY0FBYyxPQUFPQyxnQkFBZ0I7QUFDekMsUUFBSTtBQUNGLFlBQU1DLE1BQU0sTUFBTS9YLElBQUk4UixJQUFJLHVCQUF1QmdHLFdBQVcsRUFBRTtBQUM5RDFGLHlCQUFtQixPQUFPMkYsSUFBSWhHLElBQUk7QUFBQSxJQUNwQyxTQUFTOUUsT0FBTztBQUNkcUQscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWjVQLFNBQVM7QUFBQSxRQUNUNlAsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTXdILHlCQUF5QkEsQ0FBQ2pKLGFBQWE7QUFDM0M1RCxtQkFBZTRELFFBQVE7QUFDdkIxRCxzQkFBa0IsQ0FBQyxFQUFFQyxRQUFRLElBQUlDLFFBQVEsR0FBRyxDQUFDLENBQUM7QUFDOUNOLHdCQUFvQixJQUFJO0FBQUEsRUFDMUI7QUFFQSxRQUFNZ04sc0JBQXNCQSxNQUFNO0FBQ2hDNU0sc0JBQWtCLENBQUErQixTQUFRLENBQUMsR0FBR0EsTUFBTSxFQUFFOUIsUUFBUSxJQUFJQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO0FBQUEsRUFDakU7QUFFQSxRQUFNMk0seUJBQXlCQSxDQUFDQyxVQUFVO0FBQ3hDOU0sc0JBQWtCLENBQUErQixTQUFRQSxLQUFLSyxPQUFPLENBQUMySyxHQUFHOUMsTUFBTUEsTUFBTTZDLEtBQUssQ0FBQztBQUFBLEVBQzlEO0FBRUEsUUFBTUUsc0JBQXNCQSxDQUFDRixPQUFPRyxPQUFPbkksVUFBVTtBQUNuRDlFO0FBQUFBLE1BQWtCLENBQUErQixTQUNoQkEsS0FBSzBKLElBQUksQ0FBQ3BKLEtBQUs0SCxNQUFNQSxNQUFNNkMsUUFBUSxFQUFFLEdBQUd6SyxLQUFLLENBQUM0SyxLQUFLLEdBQUduSSxNQUFNLElBQUl6QyxHQUFHO0FBQUEsSUFDckU7QUFBQSxFQUNGO0FBRUEsUUFBTTZLLHNCQUFzQixZQUFZO0FBRXRDLFVBQU1DLFVBQVVwTixlQUFlcU4sS0FBSyxDQUFBQyxNQUFLLENBQUNBLEVBQUVwTixVQUFVLENBQUNvTixFQUFFbk4sT0FBTzJDLEtBQUssQ0FBQztBQUN0RSxRQUFJc0ssU0FBUztBQUNYN1gsY0FBUWdZLFFBQVEsNkNBQTZDO0FBQzdEO0FBQUEsSUFDRjtBQUVBbE4sc0JBQWtCLElBQUk7QUFDdEIsUUFBSTtBQUNGLFlBQU1tTixrQkFBa0IxTixhQUFhMk4saUJBQWlCO0FBQ3RELFlBQU1DLGFBQWExTixlQUFlMEwsSUFBSSxDQUFBNEIsT0FBTTtBQUFBLFFBQzFDcE4sUUFBUTZILE9BQU91RixFQUFFcE4sTUFBTTtBQUFBLFFBQ3ZCQyxRQUFRbU4sRUFBRW5OLE9BQU8yQyxLQUFLO0FBQUEsUUFDdEI2SyxNQUFNO0FBQUEsTUFDUixFQUFFO0FBRUYsWUFBTS9ZLElBQUkrTSxJQUFJLHdCQUF3QjdCLGFBQWF3QixHQUFHLElBQUk7QUFBQSxRQUN4RG1NLGVBQWUsQ0FBQyxHQUFHRCxpQkFBaUIsR0FBR0UsVUFBVTtBQUFBO0FBQUEsTUFFbkQsQ0FBQztBQUVEblksY0FBUXFNLFFBQVEsb0NBQW9DO0FBQ3BEL0IsMEJBQW9CLEtBQUs7QUFDekJFLHFCQUFlLElBQUk7QUFDbkJFLHdCQUFrQixDQUFDLEVBQUVDLFFBQVEsSUFBSUMsUUFBUSxHQUFHLENBQUMsQ0FBQztBQUM5Q3pGLHVCQUFpQixDQUFBc0gsU0FBUUEsT0FBTyxDQUFDO0FBQUEsSUFDbkMsU0FBU0gsT0FBTztBQUNkQyxjQUFRRCxNQUFNQSxLQUFLO0FBQ25CdE0sY0FBUXNNLE1BQU0sK0JBQStCO0FBQUEsSUFDL0MsVUFBQztBQUNDeEIsd0JBQWtCLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFFQTlMLFlBQVUsTUFBTTtBQUNkLFVBQU1xWixrQkFBa0IsWUFBWTtBQUNsQzNQLHdCQUFrQixJQUFJO0FBQ3RCLFVBQUk7QUFDRixjQUFNLENBQUM0UCxhQUFhQyxjQUFjLElBQUksTUFBTWxDLFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUN0RGpYLElBQUk4UixJQUFJLDBCQUEwQjtBQUFBLFlBQ2xDOVIsSUFBSThSLElBQUksd0JBQXdCO0FBQUEsVUFBQztBQUFBLFFBQ2xDO0FBQ0QsY0FBTUMsT0FBT2tILFlBQVlsSCxNQUFNQSxRQUFRO0FBQ3ZDLGNBQU1vSCxZQUFZcEgsS0FBS3FILE9BQU8sQ0FBQ0MsS0FBS0MsU0FBUztBQUMzQ0QsY0FBSUMsS0FBS3ZKLE1BQU0sSUFBSXVKLEtBQUtDO0FBQ3hCLGlCQUFPRjtBQUFBQSxRQUNULEdBQUcsQ0FBQyxDQUFDO0FBQ0xsUSx1QkFBZTRJLElBQUk7QUFDbkJ6SixrQkFBVTtBQUFBLFVBQ1JDLGVBQWU0USxVQUFVSyxhQUFhO0FBQUEsVUFDdENoUixlQUFlMlEsVUFBVU0sWUFBWTtBQUFBLFVBQ3JDaFIsY0FBYzBRLFVBQVVPLFdBQVc7QUFBQSxVQUNuQ2hSLGVBQWV5USxVQUFVUSxZQUFZO0FBQUEsVUFDckNoUixlQUFld1EsVUFBVVMsWUFBWTtBQUFBLFVBQ3JDaFIsZ0JBQWdCdVEsVUFBVVUsYUFBYTtBQUFBLFVBQ3ZDaFIsYUFBYXFRLGdCQUFnQm5ILE1BQU1BLE1BQU0xRSxVQUFVO0FBQUEsVUFDbkR2RSxjQUFjcVEsVUFBVVcsV0FBVztBQUFBLFFBQ3JDLENBQUM7QUFBQSxNQUNILFNBQVM3TSxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLCtCQUErQkEsS0FBSztBQUFBLE1BQ3BELFVBQUM7QUFFQzVELDBCQUFrQixLQUFLO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQ0EyUCxvQkFBZ0I7QUFBQSxFQUNsQixHQUFHLENBQUNuVCxhQUFhLENBQUM7QUFDbEIsUUFBTWtVLHlCQUF5QkEsQ0FBQ0MsUUFBUTtBQUN0QyxVQUFNQyxnQkFBZ0I7QUFBQSxNQUNwQlIsVUFBVSxFQUFFN0csT0FBTyxVQUFVekMsT0FBTyxZQUFZK0osTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CLEdBQUtDLFdBQVcsNkNBQTZDO0FBQUEsTUFDdklULFNBQVMsRUFBRTlHLE9BQU8sV0FBV3pDLE9BQU8sV0FBVytKLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQixHQUFLQyxXQUFXLHVEQUF1RDtBQUFBLE1BQ2hKUCxVQUFVLEVBQUVoSCxPQUFPLFVBQVV6QyxPQUFPLFlBQVkrSixNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0IsR0FBS0MsV0FBVyw4Q0FBOEM7QUFBQSxNQUN4SUwsU0FBUyxFQUFFbEgsT0FBTyxXQUFXekMsT0FBTyxXQUFXK0osTUFBTSx1QkFBQyw0QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVCLEdBQUtDLFdBQVcsdURBQXVEO0FBQUEsTUFDbkpYLFdBQVcsRUFBRTVHLE9BQU8sYUFBYXpDLE9BQU8sYUFBYStKLE1BQU0sdUJBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQixHQUFLQyxXQUFXLGlEQUFpRDtBQUFBLE1BQ3RKUixVQUFVLEVBQUUvRyxPQUFPLFdBQVd6QyxPQUFPLFlBQVkrSixNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0IsR0FBS0MsV0FBVywrQ0FBK0M7QUFBQSxJQUM1STtBQUVBLFVBQU1DLGFBQWE7QUFBQSxNQUNqQjVRLFVBQVUsQ0FBQyxZQUFZLFdBQVcsWUFBWSxTQUFTO0FBQUEsTUFDdkRDLFVBQVUsQ0FBQyxhQUFhLFdBQVcsWUFBWSxXQUFXLFVBQVU7QUFBQSxNQUNwRUMsU0FBUztBQUFBO0FBQUEsUUFFUDtBQUFBLFFBQVk7QUFBQSxRQUFZO0FBQUEsTUFBUztBQUFBLE1BQ25DQyxVQUFVLENBQUMsYUFBYSxZQUFZLFdBQVcsWUFBWSxTQUFTO0FBQUEsTUFDcEVDLFVBQVUsQ0FBQyxhQUFhLFlBQVksV0FBVyxTQUFTO0FBQUEsTUFDeERHLFNBQVMsQ0FBQyxhQUFhLFlBQVksV0FBVyxVQUFVO0FBQUEsSUFDMUQ7QUFFQSxVQUFNc1EsT0FBT0QsV0FBV0osR0FBRyxLQUFLSSxXQUFXMVE7QUFDM0MsV0FBTzJRLEtBQUt2RCxJQUFJLENBQUFNLFFBQU82QyxjQUFjN0MsR0FBRyxDQUFDO0FBQUEsRUFDM0M7QUFHQXpYLFlBQVUsTUFBTTtBQUNkLFVBQU0yYSxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0ZsVSxxQkFBYSxJQUFJO0FBQ2pCc0Isc0JBQWMsS0FBSztBQUNuQixZQUFJbUs7QUFDSixjQUFNMEksV0FBVztBQUFBLFVBQ2YvUSxVQUFVO0FBQUEsVUFDVkMsVUFBVTtBQUFBLFVBQ1ZDLFNBQVM7QUFBQSxVQUNUQyxVQUFVO0FBQUEsVUFDVkMsVUFBVTtBQUFBLFVBQ1ZDLFdBQVc7QUFBQSxVQUNYQyxRQUFRO0FBQUEsVUFDUkMsU0FBUztBQUFBLFFBQ1g7QUFDQSxjQUFNeVEsUUFBUUQsU0FBU3BULFNBQVMsS0FBSztBQUNyQzBLLG1CQUFXLE1BQU03UixJQUFJOFIsSUFBSSxrQkFBa0IwSSxLQUFLLEVBQUU7QUFDbEQsY0FBTUMsVUFBVTVJLFNBQVNFLE1BQU1BLFFBQVE7QUFDdkM3TSxxQkFBYXVWLE9BQU87QUFDcEIsWUFBSUMsWUFBWTdJLFNBQVNFLE1BQU1BLFFBQVE7QUFDdkMsWUFBSTVLLGNBQWMsWUFBWTtBQUM1QnVULHNCQUFZQSxVQUFVQyxNQUFNLEVBQUVDLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTSxJQUFJQyxLQUFLRCxFQUFFRSxTQUFTLElBQUksSUFBSUQsS0FBS0YsRUFBRUcsU0FBUyxDQUFDO0FBQUEsUUFDNUY7QUFDQSxjQUFNQyxxQkFBcUJBLENBQUNDLGdCQUFnQkMsZUFBZTtBQUV6RCxjQUFJLENBQUNELGVBQWdCLFFBQU87QUFFNUIsZ0JBQU14TSxRQUFRd00sZUFBZXhNLE1BQU0sS0FBSztBQUN4QyxnQkFBTTBNLGFBQWExTSxRQUFRQSxNQUFNLENBQUMsSUFBSTtBQUV0QyxnQkFBTTJNLGVBQWUsQ0FBQyxZQUFZLFlBQVksV0FBVyxXQUFXLFVBQVU7QUFDOUUsZ0JBQU1DLFNBQVNELGFBQWF0TixTQUFTb04sVUFBVSxJQUFJLFNBQVM7QUFFNUQsaUJBQU9DLGFBQWEsR0FBR0UsTUFBTSxHQUFHRixVQUFVLEtBQUtGO0FBQUFBLFFBQ2pEO0FBQ0EsY0FBTUssZ0JBQWdCYixXQUFXNUQsSUFBSSxDQUFDL0gsVUFBVW9KLFVBQVU7QUFDeEQsZ0JBQU1xRCxZQUFZQSxDQUFDNU0sU0FBUztBQUMxQixtQkFBT0EsS0FBS0MsU0FBU25DLE9BQU9rQyxLQUFLRyxVQUFVckMsT0FBTztBQUFBLFVBQ3BEO0FBRUEsZ0JBQU0rTyxrQkFBa0JBLENBQUNDLGFBQWE7QUFDcEMsa0JBQU1DLGVBQWVELFVBQVUzTSxZQUFZLENBQUM7QUFFNUMsa0JBQU0wSCxVQUFVaUYsVUFBVXRLLGlCQUFpQnVLLGNBQWNqRixpQkFBaUI7QUFDMUV4SixvQkFBUUMsSUFBSSxXQUFXc0osT0FBTztBQUM5QnZKLG9CQUFRQyxJQUFJLGtCQUFrQnVPLFFBQVE7QUFFdEMsa0JBQU1FLGFBQWFBLENBQUNDLGFBQ2xCLHVCQUFDLFNBQUksV0FBVSxtQ0FDWkEsWUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBSUYsa0JBQU1DLGtCQUFrQkEsQ0FBQ3RMLFNBQVM7QUFFaEMsb0JBQU11TCxVQUFVTCxTQUFTLFlBQVlsTCxJQUFJLEVBQUU7QUFFM0Msb0JBQU13TCxjQUFjTCxhQUFhLFlBQVluTCxJQUFJLEVBQUU7QUFHbkQscUJBQU91TCxXQUFXQyxlQUFlO0FBQUEsWUFDbkM7QUFFQSxnQkFBSXZGLFlBQVksU0FBUztBQUN2QixvQkFBTWdCLFFBQVFxRSxnQkFBZ0IsT0FBTztBQUNyQyxvQkFBTW5PLE9BQU84SixPQUFPOUosUUFBUTtBQUM1QixvQkFBTUUsUUFBUTRKLE9BQU8zSixnQkFBZ0IySixPQUFPNUosU0FBUztBQUNyRCxxQkFBTytOO0FBQUFBLGdCQUNMLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSw2QkFBNEIscUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlEO0FBQUEsa0JBQ2pELHVCQUFDLFVBQUssV0FBVSxpQkFBaUJqTyxrQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxrQkFDdEMsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QkUsbUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStDO0FBQUEscUJBSGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxjQUNGO0FBQUEsWUFDRixXQUNTNEksWUFBWSxZQUFZO0FBQy9CLG9CQUFNd0YsV0FBV0gsZ0JBQWdCLFVBQVU7QUFDM0Msb0JBQU1uTyxPQUFPc08sVUFBVW5OLGFBQWE7QUFDcEMsb0JBQU1qQixRQUFRb08sVUFBVW5PLGdCQUFnQm1PLFVBQVVwTyxTQUFTO0FBQzNELHFCQUFPK047QUFBQUEsZ0JBQ0wsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLDZCQUE0Qix3QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0Q7QUFBQSxrQkFDcEQsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQmpPLGtCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzQztBQUFBLGtCQUN0Qyx1QkFBQyxVQUFLLFdBQVUseUJBQXlCRSxtQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQSxxQkFIakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLGNBQ0Y7QUFBQSxZQUNGLFdBQ1M0SSxZQUFZLFlBQVk7QUFDL0Isb0JBQU1tQixXQUFXa0UsZ0JBQWdCLFVBQVU7QUFDM0M1TyxzQkFBUUMsSUFBSSx3QkFBd0J5SyxRQUFRO0FBRTVDLG9CQUFNakssT0FBT2lLLFVBQVVqSyxRQUFRO0FBQy9CLG9CQUFNRSxRQUFRK0osVUFBVTlKLGdCQUFnQjhKLFVBQVUvSixTQUFTO0FBQzNELG9CQUFNcU8sVUFBVXRFLFVBQVV1RSxnQkFBZ0J2RSxVQUFVd0UsZUFBZTtBQUVuRSxxQkFBT1I7QUFBQUEsZ0JBQ0wsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLDZCQUE0Qix3QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0Q7QUFBQSxrQkFDcEQsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQmpPLGtCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzQztBQUFBLGtCQUN0Qyx1QkFBQyxVQUFLLFdBQVUseUJBQ2JFO0FBQUFBLDhCQUFVLE1BQU1BLFFBQVE7QUFBQSxvQkFDeEJxTyxXQUFXck8sVUFBVSxNQUFNLFFBQVE7QUFBQSxvQkFDbkNxTyxXQUFXO0FBQUEsdUJBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLHFCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxjQUNGO0FBQUEsWUFDRixXQUNTekYsWUFBWSxnQkFBZ0I7QUFDbkMscUJBQU9tRjtBQUFBQSxnQkFDTCx1QkFBQyxTQUFJLFdBQVUseUJBQ2IsaUNBQUMsVUFBSyxXQUFVLGVBQWMsNEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUdBLGtCQUFNUyxtQkFBbUJQLGdCQUFnQixVQUFVO0FBQ25ELGdCQUFJTyxrQkFBa0I7QUFDcEIsb0JBQU0xTyxPQUFPME8sa0JBQWtCMU8sUUFBUTtBQUN2QyxvQkFBTUUsUUFBUXdPLGtCQUFrQnZPLGdCQUFnQnVPLGtCQUFrQnhPLFNBQVM7QUFDM0UscUJBQU8rTjtBQUFBQSxnQkFDTCx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsNkJBQTRCLGlDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RDtBQUFBLGtCQUM3RCx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCak8sa0JBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNDO0FBQUEsa0JBQ3RDLHVCQUFDLFVBQUssV0FBVSx5QkFBeUJFLG1CQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQztBQUFBLHFCQUhqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFFQSxtQkFBTytOLFdBQVcsdUJBQUMsVUFBSyxXQUFVLHlCQUF3QixtQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkMsQ0FBTztBQUFBLFVBQ3RFO0FBRUEsZ0JBQU1VLGlCQUFnQnZDLHVCQUF1QjVTLFNBQVM7QUFDdEQsZ0JBQU1vVixpQkFDSix1QkFBQyxTQUFJLFdBQVUsb0RBQ1pELHlCQUFjeEY7QUFBQUEsWUFBSSxDQUFBMEYsUUFDakI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxNQUFNQSxJQUFJdEM7QUFBQUEsZ0JBQ1YsV0FBVywwQ0FBMENzQyxJQUFJckMsU0FBUztBQUFBLGdCQUNsRSxTQUFTLE1BQU03SyxpQkFBaUJQLFVBQVV5TixJQUFJck0sS0FBSztBQUFBLGdCQUVsRHFNLGNBQUk1SjtBQUFBQTtBQUFBQSxjQUxBNEosSUFBSXJNO0FBQUFBLGNBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsVUFDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFFRixnQkFBTXNNLGlCQUNKLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxDQUFDLE9BQU87QUFBQSxjQUNqQixNQUFNO0FBQUEsZ0JBQ0pDLE9BQU87QUFBQSxrQkFDTCxHQUFJdlYsY0FBYyxlQUFlQSxjQUFjLFdBQzNDO0FBQUEsb0JBQUMsRUFBRWlRLEtBQUssS0FBS3hFLE9BQU8sdUJBQUMsU0FBSSxXQUFVLGtCQUFpQixTQUFTLE1BQU0rSixzQkFBc0I1TixTQUFTckMsR0FBRyxHQUFHLG9CQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3RixFQUFPO0FBQUEsb0JBQ3JIO0FBQUEsc0JBQ0UwSyxLQUFLO0FBQUEsc0JBQUt4RSxPQUNSO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixTQUFTLE1BQU07QUFDYixrQ0FBTWdLLFNBQVM3TixTQUFTRixTQUFTbkMsT0FBT3FDLFNBQVNBLFVBQVVyQztBQUMzRCxnQ0FBSWtRLFFBQVE7QUFDVkMscURBQXVCRCxNQUFNO0FBQUEsNEJBQy9CLE9BQU87QUFDTGpjLHNDQUFRZ1ksUUFBUSxvQ0FBb0M7QUFBQSw0QkFDdEQ7QUFBQSwwQkFDRjtBQUFBLDBCQUFFO0FBQUE7QUFBQSx3QkFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBWUE7QUFBQSxvQkFFSjtBQUFBLGtCQUFDLElBRUM7QUFBQSxrQkFDSixHQUFJeFIsY0FBYyxlQUFlQSxjQUFjLFdBQzNDLENBQUMsRUFBRWlRLEtBQUssS0FBS3hFLE9BQU8sdUJBQUMsV0FBUSxXQUFVLFlBQVcsU0FBUSxTQUFRLFNBQVMySixnQkFBZ0IsaUNBQUMsU0FBSSxXQUFVLGdDQUErQiw2QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkQsS0FBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0ksRUFBVyxDQUFDLElBQ3hLO0FBQUEsa0JBQ0osR0FBSXBWLGNBQWMsYUFFaEIsQ0FBQztBQUFBLG9CQUNDaVEsS0FBSztBQUFBLG9CQUNMeEUsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNO0FBQ2IsOEJBQUk3RCxVQUFVc0MsMEJBQTBCLGFBQWF0QyxVQUFVc0MsMEJBQTBCLFlBQVk7QUFDbkcxUSxvQ0FBUWdZLFFBQVEsdUVBQXVFO0FBQUEsMEJBQ3pGLE9BQU87QUFDTHZKLGdEQUFvQkwsUUFBUTtBQUFBLDBCQUM5QjtBQUFBLHdCQUNGO0FBQUEsd0JBRUE7QUFBQSxpREFBQyxVQUFPLFdBQVUsaUJBQWdCLE9BQU0sc0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTBEO0FBQUEsMEJBQzFELHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsMkJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXVEO0FBQUE7QUFBQTtBQUFBLHNCQVh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBWUE7QUFBQSxrQkFFSixDQUFDLElBQ0M7QUFBQSxrQkFDSixHQUFJNUgsY0FBYyxjQUFjQSxjQUFjLGVBQWVBLGNBQWMsV0FDdkUsQ0FBQyxFQUFFaVEsS0FBSyxLQUFLeEUsT0FBTyx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCLFNBQVMsTUFBTWlGLFlBQVk5SSxTQUFTckMsR0FBRyxHQUFHLHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRixFQUFPLENBQUMsSUFDNUc7QUFBQSxrQkFDSixHQUFJdkYsY0FBYyxjQUNkLENBQUMsRUFBRWlRLEtBQUssS0FBS3hFLE9BQU8sdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixTQUFTLE1BQU1vRix1QkFBdUJqSixRQUFRLEdBQUcsNEJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThGLEVBQU8sQ0FBQyxJQUMxSDtBQUFBLGtCQUVKLEdBQUk1SCxjQUFjLGFBQ2Q7QUFBQSxvQkFDQTtBQUFBLHNCQUNFaVEsS0FBSztBQUFBLHNCQUNMeEUsT0FDRSx1QkFBQyxVQUFLLFdBQVUsMENBQ2Q7QUFBQSwrQ0FBQyxXQUFRLFdBQVUsZUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBOEI7QUFBQSx3QkFBRztBQUFBLDJCQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBRUZrSyxTQUFTQSxNQUFNO0FBQ2JwWTtBQUFBQSwwQkFDRSxxRUFBcUVxSyxTQUFTckMsR0FBRztBQUFBLHdCQUNuRjtBQUFBLHNCQUNGO0FBQUEsb0JBQ0Y7QUFBQSxrQkFBQyxJQUVEO0FBQUEsZ0JBQUc7QUFBQSxjQUVYO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FJVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQTtBQUFBLFlBaEZqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpRkEsS0FsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtRkE7QUFHRixnQkFBTXFRLGNBQWNoTyxVQUFVc0M7QUFDOUIsY0FBSTJMLGFBQWE7QUFFakIsY0FBSUMsZUFBZWxPLFVBQVVtTyxtQ0FDekIsSUFBSW5DLEtBQUtoTSxTQUFTbU8sZ0NBQWdDLEVBQUVDLG1CQUFtQixPQUFPLElBQzlFO0FBQ0osZ0JBQU1DLGlCQUFpQnJPLFVBQVVoRSx1QkFDN0IsSUFBS2dFLFNBQVNoRSxxQkFBc0JzUyxlQUFlLENBQUMsS0FDcEQ7QUFDSixnQkFBTUMsU0FBU3ZPLFVBQVV3TyxtQkFBbUI7QUFDNUMsZ0JBQU1DLGlCQUFpQnpPLFVBQVVGLFNBQVNuQyxPQUFPcUMsVUFBVUEsVUFBVXJDO0FBRXJFLGdCQUFNK1EsaUJBQ0osdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsbUNBQUMsU0FBSTtBQUFBO0FBQUEsY0FBVTFPLFVBQVVBLFVBQVVtQyxtQkFBbUJ2RCxRQUFRb0IsVUFBVUEsVUFBVWtDLG1CQUFtQm5DLGFBQWFDLFVBQVVBLFVBQVVvQyxnQkFBZ0J4RCxRQUFRO0FBQUEsaUJBQTlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZLO0FBQUEsWUFDN0ssdUJBQUMsU0FBSTtBQUFBO0FBQUEsY0FBcUJzUDtBQUFBQSxpQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUM7QUFBQSxZQUN0Q0csa0JBQWtCLHVCQUFDLFNBQUk7QUFBQTtBQUFBLGNBQXFCQTtBQUFBQSxpQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUM1RCx1QkFBQyxTQUFJO0FBQUE7QUFBQSxjQUFZRTtBQUFBQSxpQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQSxlQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBR0YsY0FBSVAsZ0JBQWdCLFlBQVk7QUFDOUJDLHlCQUNFLHVCQUFDLFdBQVEsT0FBT1MsZ0JBQWdCLGtCQUFpQixZQUMvQyxpQ0FBQyxVQUFLLFdBQVUsc0xBQ2Q7QUFBQSxxQ0FBQyxjQUFXLFdBQVUsaUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DO0FBQUEsY0FBRztBQUFBLGNBQ3RDLHVCQUFDLHNCQUFtQixXQUFVLHNDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRTtBQUFBLGlCQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFVBRUosV0FBV1YsZ0JBQWdCLFlBQVk7QUFDckNDLHlCQUNFLHVCQUFDLFdBQVEsT0FBT1MsZ0JBQWdCLGtCQUFpQixZQUMvQyxpQ0FBQyxVQUFLLFdBQVUsa0xBQ2Q7QUFBQSxxQ0FBQyxpQkFBYyxXQUFVLGlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQztBQUFBLGNBQUc7QUFBQSxjQUN6Qyx1QkFBQyxzQkFBbUIsV0FBVSxzQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxpQkFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxVQUVKLFdBQVdWLGdCQUFnQixXQUFXO0FBQ3BDQyx5QkFDRSx1QkFBQyxXQUFRLE9BQU9TLGdCQUFnQixrQkFBaUIsWUFDL0MsaUNBQUMsVUFBSyxXQUFVLHNMQUNkO0FBQUEscUNBQUMsbUJBQWdCLFdBQVUsaUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdDO0FBQUEsY0FBRztBQUFBLGNBQzNDLHVCQUFDLHNCQUFtQixXQUFVLHNDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRTtBQUFBLGlCQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFVBRUo7QUFFQSxjQUFJQyxlQUNGLHVCQUFDLFVBQUssV0FBVSwrQ0FDZDtBQUFBLG1DQUFDLFVBQUssV0FBVSwrQkFDYjNPLG9CQUFVRixTQUFTQyxhQUFhQyxVQUFVMUMsTUFBTXlDLGFBQWFDLFVBQVVBLFVBQVVELGFBQWEsYUFEakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxPQUFPb0IsTUFBTTtBQUNwQkEsb0JBQUV5TixnQkFBZ0I7QUFDbEIsc0JBQUksQ0FBQ0gsZ0JBQWdCO0FBQ25CN2MsNEJBQVFnWSxRQUFRLG9DQUFvQztBQUNwRDtBQUFBLGtCQUNGO0FBQ0FoTix1Q0FBcUI2UixjQUFjO0FBQ25DLHNCQUFJO0FBQ0YsMEJBQU1JLE9BQU9qZCxRQUFRNEcsUUFBUSwyQkFBMkIsQ0FBQztBQUN6RCwwQkFBTXNWLHVCQUF1QlcsY0FBYztBQUMzQ0kseUJBQUs7QUFBQSxrQkFDUCxTQUFTbEcsS0FBSztBQUFBLGtCQUNaLFVBQ0Q7QUFDQy9MLHlDQUFxQixJQUFJO0FBQUEsa0JBQzNCO0FBQUEsZ0JBQ0Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQ1YsT0FBTTtBQUFBLGdCQUNOLFVBQVVELHNCQUFzQjhSO0FBQUFBLGdCQUUvQjlSLGdDQUFzQjhSLGlCQUNyQix1QkFBQyw2QkFBMEIsV0FBVSx3Q0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUUsSUFFekUsdUJBQUMsU0FBTSxXQUFVLDJCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QztBQUFBO0FBQUEsY0ExQjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTRCQTtBQUFBLFlBRUNSLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLDJCQUEyQkEsd0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFHdEQsQ0FBQ0EsY0FDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcsb0ZBQW9Gak8sVUFBVUYsU0FBUzZILGtCQUFrQixpQkFDaEksa0dBQ0Esd0ZBQXdGO0FBQUEsZ0JBRTVGLE9BQ0UzSCxVQUFVRixTQUFTNkgsa0JBQWtCLGlCQUNqQyw2Q0FDQTtBQUFBLGdCQUdMM0gsb0JBQVVGLFNBQVM2SCxrQkFBa0IsaUJBQWlCLFFBQVE7QUFBQTtBQUFBLGNBWGpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsZUFwREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzREE7QUFFRixjQUFJbUgsYUFDRix1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsK0JBQ2IxVyx3QkFBYyxjQUFjNEgsVUFBVWpFLHdCQUF3QmlFLFVBQVVNLGVBRDNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBSWJELHNDQUFvQkwsUUFBUTtBQUFBLGdCQUU5QjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFDVixPQUFNO0FBQUE7QUFBQSxjQVRSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVMwQjtBQUFBLGVBZDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBRUYsY0FBSStPLGdCQUNGLHVCQUFDLFNBQUksV0FBVSwyQkFFYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxtRUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Y7QUFBQSxjQUNoRix1QkFBQyxVQUFLLFdBQVUsMkRBQTBEO0FBQUE7QUFBQSxnQkFDdEUvTyxVQUFVaEUsc0JBQXNCc1MsZUFBZSxPQUFPLEtBQUs7QUFBQSxtQkFEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUdDdE8sVUFBVWhFLHdCQUF3QmdFLFVBQVVnUCwrQkFDM0MsdUJBQUMsVUFBSyxXQUFXO0FBQUE7QUFBQTtBQUFBLFVBR3ZCaFAsVUFBVWdQLGdDQUFnQyxhQUM5QiwyRUFDQWhQLFVBQVVnUCxnQ0FBZ0MsYUFDeEMsMkRBQ0EsZ0VBQWdFO0FBQUEsU0FHckVoUDtBQUFBQSx3QkFBVWdQLGdDQUFnQyxjQUFjLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQ3ZGaFAsVUFBVWdQLGdDQUFnQyxjQUFjLHVCQUFDLGlCQUFjLFdBQVUsYUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUMxRmhQLFVBQVVnUCxnQ0FBZ0MsYUFBYSx1QkFBQyxtQkFBZ0IsV0FBVSxhQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLGNBQzNGaFAsVUFBVWdQLGdDQUFnQyxhQUN2QyxzQkFDQWhQLFVBQVVnUCxnQ0FBZ0MsYUFDeEMsc0JBQ0E7QUFBQSxpQkFqQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxlQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdDQTtBQUlGLGNBQUk1VyxjQUFjLFlBQVk7QUFJNUIsbUJBQU87QUFBQSxjQUNMdUYsS0FBS3FDLFNBQVNyQztBQUFBQSxjQUNkQyxJQUFJd0wsUUFBUTtBQUFBLGNBQ1p2SyxhQUFhbUIsVUFBVUYsU0FBU0MsYUFBYUMsVUFBVTFDLE1BQU15QyxhQUFhQyxVQUFVQSxVQUFVRCxhQUFhO0FBQUEsY0FDM0dpRSxTQUFTa0ksbUJBQW1CbE0sVUFBVWdFLFNBQVM1TCxTQUFTO0FBQUEsY0FDeEQ2VyxlQUFlTjtBQUFBQSxjQUNmNVAsY0FBY2lCLFVBQVVGLFNBQVNmLGdCQUFnQmlCLFVBQVVBLFVBQVVqQixnQkFBZ0I7QUFBQSxjQUNyRm1RLGFBQWF4QyxnQkFBZ0IxTSxRQUFRO0FBQUEsY0FDckNtUCx1QkFBdUJKO0FBQUFBLGNBQ3ZCSywwQkFBMEJwUCxVQUFVb1AsNEJBQTRCO0FBQUEsY0FDaEVaLGlCQUFpQnhPLFVBQVV3TyxtQkFBbUI7QUFBQSxjQUM5Q3pLLFNBQVMvRCxVQUFVRixTQUFTaUUsV0FBVztBQUFBLGNBQ3ZDekQsYUFBYXdPO0FBQUFBLGNBQ2JPLGNBQWNyUCxVQUFVcVA7QUFBQUEsY0FDeEJwRCxXQUFXak0sVUFBVWlNLFlBQVksSUFBSUQsS0FBS2hNLFNBQVNpTSxTQUFTLEVBQUVtQyxtQkFBbUIsT0FBTyxJQUFJO0FBQUEsY0FDNUZrQixXQUFXO0FBQUEsZ0JBQ1R0UCxVQUFVdVAsYUFDTixHQUFHdlAsU0FBU3VQLFdBQVczUSxJQUFJLEtBQzNCO0FBQUEsZ0JBRUpvQixVQUFVakMsYUFDTixZQUFZaUMsU0FBU2pDLFdBQVdhLElBQUksS0FDcEM7QUFBQSxnQkFDSm9CLFVBQVV1QztBQUFBQSxjQUFNLEVBQ2hCN0QsT0FBTzhRLE9BQU8sRUFBRUMsS0FBSyxLQUFLLEtBQUs7QUFBQSxjQUNqQzVPLGlCQUFpQix1QkFBQyxVQUFLLFdBQVUseUZBQXdGLHlCQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpSDtBQUFBLGNBQ2xJNk8sUUFBUWhDO0FBQUFBLFlBQ1Y7QUFBQSxVQUNGO0FBR0EsY0FBSXRWLGNBQWMsV0FBVztBQUMzQixtQkFBTztBQUFBLGNBQ0x3RixJQUFJd0wsUUFBUTtBQUFBLGNBQ1p2SyxhQUFhbUIsVUFBVUYsU0FBU0MsYUFBYUMsVUFBVTFDLE1BQU15QyxhQUFhQyxVQUFVQSxVQUFVRCxhQUFhO0FBQUEsY0FDM0dwQyxLQUFLcUMsU0FBU3JDO0FBQUFBLGNBQ2RxRyxTQUFTa0ksbUJBQW1CbE0sVUFBVWdFLFNBQVM1TCxTQUFTO0FBQUEsY0FDeEQ4VyxhQUFheEMsZ0JBQWdCMU0sUUFBUTtBQUFBLGNBQ3JDd08saUJBQWlCeE8sVUFBVXdPLG1CQUFtQjtBQUFBLGNBQzlDek8sV0FBVzRPLGdCQUFnQjtBQUFBLGNBQzNCNVAsY0FBY2lCLFVBQVVGLFNBQVNmLGdCQUFnQmlCLFVBQVVBLFVBQVVqQixnQkFBZ0I7QUFBQSxjQUNyRmdGLFNBQVMvRCxVQUFVRixTQUFTaUUsV0FBVy9ELFVBQVVBLFVBQVUrRCxXQUFXO0FBQUE7QUFBQSxjQUV0RXpELGFBQWF3TztBQUFBQSxjQUNiSyx1QkFBdUJKO0FBQUFBLGNBQ3ZCSywwQkFBMEJwUCxVQUFVb1AsNEJBQTRCO0FBQUEsY0FDaEVDLGNBQWNyUCxVQUFVcVA7QUFBQUEsY0FDeEJDLFdBQVd0UCxVQUFVdVAsYUFDakI7QUFBQSxnQkFDQXZQLFNBQVN1UCxXQUFXM1E7QUFBQUEsZ0JBQ3BCb0IsU0FBU3VQLFdBQVdJLGNBQWMsSUFBSTNQLFNBQVN1UCxXQUFXSSxVQUFVO0FBQUEsY0FBRyxFQUV0RWpSLE9BQU84USxPQUFPLEVBQ2RDLEtBQUssR0FBRyxJQUNUO0FBQUEsY0FDSnhELFdBQVdqTSxVQUFVaU0sWUFBWSxJQUFJRCxLQUFLaE0sU0FBU2lNLFNBQVMsRUFBRW1DLG1CQUFtQixPQUFPLElBQUk7QUFBQSxjQUM1RnNCLFFBQVFoQztBQUFBQSxZQUNWO0FBQUEsVUFDRjtBQUdBLGlCQUFPO0FBQUEsWUFDTC9QLEtBQUtxQyxTQUFTckM7QUFBQUEsWUFDZEMsSUFBSXdMLFFBQVE7QUFBQSxZQUNacEYsU0FBU2tJLG1CQUFtQmxNLFVBQVVnRSxTQUFTNUwsU0FBUztBQUFBLFlBQ3hEeUcsYUFBYW1CLFVBQVVGLFNBQVNDLGFBQWFDLFVBQVUxQyxNQUFNeUMsYUFBYUMsVUFBVUEsVUFBVUQsYUFBYTtBQUFBLFlBQzNHa00sV0FBV2pNLFVBQVVpTSxZQUFZLElBQUlELEtBQUtoTSxTQUFTaU0sU0FBUyxFQUFFbUMsbUJBQW1CLE9BQU8sSUFBSTtBQUFBLFlBQzVGa0IsV0FBV3RQLFVBQVV1UCxhQUNqQjtBQUFBLGNBQ0F2UCxTQUFTdVAsV0FBVzNRO0FBQUFBLGNBQ3BCb0IsU0FBU3VQLFdBQVdJLGNBQWMsSUFBSTNQLFNBQVN1UCxXQUFXSSxVQUFVO0FBQUEsWUFBRyxFQUV0RWpSLE9BQU84USxPQUFPLEVBQ2RDLEtBQUssR0FBRyxJQUNUO0FBQUEsWUFDSkcsZUFBZXhYLGNBQWMsZUFBZUEsY0FBYyxXQUFXNEgsVUFBVUEsVUFBVUQsWUFBWTRPO0FBQUFBLFlBQ3JHa0IsTUFBTTdQLFVBQVVpTTtBQUFBQSxZQUNoQmxOLGNBQWNpQixVQUFVRixTQUFTZixnQkFBZ0JpQixVQUFVQSxVQUFVakIsZ0JBQWdCO0FBQUEsWUFDckZ1QixhQUFhbEksY0FBYyxlQUFlQSxjQUFjLFdBQVc0SCxVQUFVTSxjQUFjd087QUFBQUEsWUFDM0ZqTixRQUFRN0IsVUFBVTZCO0FBQUFBLFlBQ2xCQyxpQkFBaUI5QixVQUFVOEI7QUFBQUEsWUFDM0JxQyxvQkFBb0JuRSxVQUFVbUUsb0JBQW9CMkwsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFlBQzlEL04sa0JBQWtCL0IsVUFBVStCO0FBQUFBLFlBQzVCQyxzQkFBc0JoQyxVQUFVZ0M7QUFBQUEsWUFDaENpQyxZQUFZakUsVUFBVWlFLFlBQVk2TCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsWUFDOUM1TCxVQUFVbEUsVUFBVWtFLFVBQVU0TCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsWUFDMUM3TixNQUFNakMsVUFBVWlDO0FBQUFBLFlBQ2hCSSxlQUFlckMsVUFBVXFDO0FBQUFBLFlBQ3pCOE0sdUJBQXVCSjtBQUFBQSxZQUN2QkssMEJBQTBCcFAsVUFBVW9QLDRCQUE0QjtBQUFBLFlBQ2hFWixpQkFBaUJ4TyxVQUFVd08sbUJBQW1CO0FBQUEsWUFDOUMzTixpQkFBaUJiLFVBQVVhLG1CQUFtQjtBQUFBLFlBQzlDa1Asd0JBQXdCLE1BQU07QUFDNUIsb0JBQU1DLFVBQVVoUSxVQUFVOEosaUJBQWlCO0FBQzNDLGtCQUFJa0csUUFBUTFSLFdBQVcsRUFBRyxRQUFPLHVCQUFDLFVBQUssV0FBVSx5QkFBd0Isb0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQzdFLG9CQUFNMlIsbUJBQW1CRCxRQUFRM0YsT0FBTyxDQUFDNkYsS0FBS3ZHLE1BQU07QUFDbEQsb0JBQUlBLEVBQUVLLFNBQVMsS0FBTSxRQUFPa0c7QUFDNUIsb0JBQUl2RyxFQUFFd0csbUJBQW1CclQsT0FBVyxRQUFPb1QsTUFBTTlMLE9BQU91RixFQUFFd0csY0FBYztBQUN4RSxzQkFBTW5HLE9BQU81RixPQUFPdUYsRUFBRXlHLGVBQWUsQ0FBQztBQUN0QyxzQkFBTTdULFNBQVM2SCxPQUFPdUYsRUFBRXBOLFVBQVUsQ0FBQztBQUNuQyx1QkFBTzJULE9BQU8zVCxTQUFTeU47QUFBQUEsY0FDekIsR0FBRyxDQUFDO0FBRUoscUJBQ0UsdUJBQUMsU0FBSSxXQUFVLHVCQUFzQjtBQUFBO0FBQUEsZ0JBQ3BCaUcsaUJBQWlCM0IsZUFBZSxPQUFPO0FBQUEsbUJBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxZQUVKLEdBQUc7QUFBQSxZQUNIWSxhQUFheEMsZ0JBQWdCMU0sUUFBUTtBQUFBLFlBQ3JDMFAsUUFBUWhDO0FBQUFBLFVBQ1Y7QUFBQSxRQUNGLENBQUM7QUFDRHJYLDBCQUFrQm1XLGFBQWE7QUFDL0IsWUFBSSxDQUFDMUosU0FBU0UsTUFBTUEsUUFBUUYsU0FBU0UsTUFBTUEsS0FBSzFFLFdBQVcsRUFBRzNGLGVBQWMsSUFBSTtBQUFBLE1BQ2xGLFNBQVN1RixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUNoRHZGLHNCQUFjLElBQUk7QUFDbEJ0QywwQkFBa0IsRUFBRTtBQUNwQmtMLHVCQUFlLEVBQUVDLFlBQVksTUFBTTVQLFNBQVMsZ0RBQWdENlAsTUFBTSxRQUFRLENBQUM7QUFBQSxNQUM3RyxVQUFDO0FBQ0NwSyxxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0FrVSxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQ3pVLGVBQWVzQixTQUFTLENBQUM7QUFjN0IsUUFBTWlZLG1CQUFtQkEsQ0FBQzlHLE9BQU9uSSxVQUFVO0FBQ3pDTyxnQkFBWSxDQUFDMk8sY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQy9HLEtBQUssR0FBR25JO0FBQUFBLElBQ1gsRUFBRTtBQUNGcUIsY0FBVSxDQUFDOE4sZ0JBQWdCO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDaEgsS0FBSyxHQUFHO0FBQUEsSUFDWCxFQUFFO0FBR0YsUUFBSUEsVUFBVSxjQUFjbkksT0FBTztBQUNqQyxZQUFNbEksZ0JBQWV0RCxNQUFNZ0ssS0FBSyxDQUFDdEMsU0FBU0EsS0FBS0ssUUFBUXlELEtBQUs7QUFDNUQsVUFBSWxJLGVBQWM7QUFDaEIsY0FBTXdPLFVBQVV4TyxjQUFheU8saUJBQWlCO0FBRTlDaEcsb0JBQVksQ0FBQ3RELFVBQVU7QUFBQSxVQUNyQixHQUFHQTtBQUFBQSxVQUNIZ0UsZUFBZXFGO0FBQUFBO0FBQUFBLFVBRWZ2RixtQkFBbUI7QUFBQSxVQUNuQkMsZ0JBQWdCO0FBQUEsVUFDaEJGLG1CQUFtQjtBQUFBLFFBQ3JCLEVBQUU7QUFHRixZQUFJd0YsWUFBWSxjQUFjeE8sY0FBYWlKLG1CQUFtQnhFLEtBQUs7QUFDakVnRSxzQkFBWSxDQUFDdEQsVUFBVTtBQUFBLFlBQ3JCLEdBQUdBO0FBQUFBLFlBQ0g4RCxtQkFBbUJqSixjQUFhaUosa0JBQWtCeEU7QUFBQUEsVUFDcEQsRUFBRTtBQUFBLFFBQ0osV0FBVytKLFlBQVksV0FBV3hPLGNBQWFrSixnQkFBZ0J6RSxLQUFLO0FBQ2xFZ0Usc0JBQVksQ0FBQ3RELFVBQVU7QUFBQSxZQUNyQixHQUFHQTtBQUFBQSxZQUNIK0QsZ0JBQWdCbEosY0FBYWtKLGVBQWV6RTtBQUFBQSxVQUM5QyxFQUFFO0FBQUEsUUFDSixXQUFXK0osWUFBWSxjQUFjeE8sY0FBYWdKLG1CQUFtQnZFLEtBQUs7QUFDeEVnRSxzQkFBWSxDQUFDdEQsVUFBVTtBQUFBLFlBQ3JCLEdBQUdBO0FBQUFBLFlBQ0g2RCxtQkFBbUJoSixjQUFhZ0osa0JBQWtCdkU7QUFBQUEsVUFDcEQsRUFBRTtBQUFBLFFBQ0o7QUFBQSxNQUVGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNlMsd0JBQXdCQSxDQUFDakgsT0FBT25JLFVBQVU7QUFDOUN1QixzQkFBa0IsQ0FBQzJOLGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUMvRyxLQUFLLEdBQUduSTtBQUFBQSxJQUNYLEVBQUU7QUFDRnFCLGNBQVUsQ0FBQzhOLGdCQUFnQixFQUFFLEdBQUdBLFlBQVksQ0FBQ2hILEtBQUssR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUM1RDtBQUVBLFFBQU1rSCxlQUFlQSxDQUFDdFAsTUFBTTtBQUMxQixVQUFNLEVBQUV2QyxNQUFNd0MsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQixVQUFNcVAsY0FBYyxFQUFFLEdBQUdoUCxVQUFVLENBQUM5QyxJQUFJLEdBQUd3QyxNQUFNO0FBQ2pETyxnQkFBWStPLFdBQVc7QUFDdkJqTyxjQUFVLENBQUNwRSxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDTyxJQUFJLEdBQUcsR0FBRyxFQUFFO0FBQzdDLFVBQU0rUixlQUFlLElBQUkzRSxLQUFLMEUsWUFBWXZNLGtCQUFrQjtBQUM1RCxVQUFNeU0sWUFBWSxJQUFJNUUsS0FBSzBFLFlBQVl6TSxVQUFVO0FBQ2pELFFBQ0V5TSxZQUFZdk0sc0JBQ1p1TSxZQUFZek0sY0FDWjJNLFlBQVlELGNBQ1o7QUFDQXBQLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1o1UCxTQUFTO0FBQUEsUUFDVDZQLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1vUCxlQUFlQSxDQUFDcFAsU0FBUztBQUM3QixVQUFNcVAsWUFBWSxDQUFDO0FBQ25CLFVBQU05TixPQUFPdkIsU0FBUyxnQkFBZ0JDLFdBQVdnQjtBQUNqRCxRQUFJLENBQUNNLEtBQUtoRCxTQUFVOFEsV0FBVTlRLFdBQVc7QUFDekMsUUFBSSxDQUFDZ0QsS0FBSzFDLGVBQWV5USxNQUFNL04sS0FBSzFDLFdBQVcsS0FBSzBDLEtBQUsxQyxlQUFlO0FBQ3RFd1EsZ0JBQVV4USxjQUFjO0FBQzFCLFFBQUksQ0FBQzBDLEtBQUtuQixVQUFVa1AsTUFBTS9OLEtBQUtuQixNQUFNLEtBQUttQixLQUFLbkIsVUFBVTtBQUN2RGlQLGdCQUFValAsU0FBUztBQUNyQixRQUFJLENBQUNtQixLQUFLbEIsZ0JBQWlCZ1AsV0FBVWhQLGtCQUFrQjtBQUN2RCxRQUFJLENBQUNrQixLQUFLaEIscUJBQXNCOE8sV0FBVTlPLHVCQUF1QjtBQUNqRSxRQUFJLENBQUNnQixLQUFLakIsaUJBQWtCK08sV0FBVS9PLG1CQUFtQjtBQUN6RFUsY0FBVXFPLFNBQVM7QUFDbkIsV0FBT3JSLE9BQU82TCxLQUFLd0YsU0FBUyxFQUFFeFMsV0FBVztBQUFBLEVBQzNDO0FBR0ExTixZQUFVLE1BQU07QUFDZCxRQUFJOFEsU0FBU3BCLGFBQWE7QUFDeEIsWUFBTS9ELFNBQVM2SCxPQUFPMUMsU0FBU3BCLFdBQVc7QUFDMUMsWUFBTXVCLFNBQVN1QyxPQUFPMUMsU0FBU0csTUFBTTtBQUNyQ0Ysa0JBQVksQ0FBQXRELFVBQVM7QUFBQSxRQUNuQixHQUFHQTtBQUFBQSxRQUNIeUQsa0JBQWtCdkYsU0FBUyxLQUFLeVUsUUFBUSxDQUFDO0FBQUEsUUFDekNqUCxtQkFBbUJ4RixTQUFTLE1BQU15VSxRQUFRLENBQUM7QUFBQSxRQUMzQyxHQUFJblAsU0FBUyxLQUFLLEVBQUVHLHVCQUF1QnpGLFNBQVNzRixRQUFRbVAsUUFBUSxDQUFDLEVBQUU7QUFBQSxNQUN6RSxFQUFFO0FBQUEsSUFDSixPQUFPO0FBQ0xyUCxrQkFBWSxDQUFBdEQsVUFBUyxFQUFFLEdBQUdBLE1BQU15RCxpQkFBaUIsSUFBSUMsa0JBQWtCLElBQUlDLHNCQUFzQixHQUFJLEVBQUU7QUFBQSxJQUN6RztBQUFBLEVBQ0YsR0FBRyxDQUFDTixTQUFTcEIsYUFBYW9CLFNBQVNHLE1BQU0sQ0FBQztBQUcxQ2pSLFlBQVUsTUFBTTtBQUNkLFFBQUk4UixlQUFlcEMsYUFBYTtBQUM5QixZQUFNL0QsU0FBUzZILE9BQU8xQixlQUFlcEMsV0FBVztBQUNoRCxZQUFNdUIsU0FBU3VDLE9BQU8xQixlQUFlYixNQUFNO0FBQzNDYyx3QkFBa0IsQ0FBQXRFLFVBQVM7QUFBQSxRQUN6QixHQUFHQTtBQUFBQSxRQUNIeUQsa0JBQWtCdkYsU0FBUyxLQUFLeVUsUUFBUSxDQUFDO0FBQUEsUUFDekNqUCxtQkFBbUJ4RixTQUFTLE1BQU15VSxRQUFRLENBQUM7QUFBQSxRQUMzQyxHQUFJblAsU0FBUyxLQUFLLEVBQUVHLHVCQUF1QnpGLFNBQVNzRixRQUFRbVAsUUFBUSxDQUFDLEVBQUU7QUFBQSxNQUN6RSxFQUFFO0FBQUEsSUFDSixPQUFPO0FBQ0xyTyx3QkFBa0IsQ0FBQXRFLFVBQVMsRUFBRSxHQUFHQSxNQUFNeUQsaUJBQWlCLElBQUlDLGtCQUFrQixJQUFJQyxzQkFBc0IsR0FBSSxFQUFFO0FBQUEsSUFDL0c7QUFBQSxFQUNGLEdBQUcsQ0FBQ1UsZUFBZXBDLGFBQWFvQyxlQUFlYixNQUFNLENBQUM7QUFFdEQsUUFBTW9QLGVBQWUsT0FBTzlQLE1BQU07QUFDaENBLE1BQUUrUCxlQUFlO0FBRWpCLFVBQU1DLFVBQVVOLGFBQWEsYUFBYTtBQUUxQyxRQUFJLENBQUNNLFFBQVM7QUFFZCxRQUFJO0FBRUYsWUFBTXJPLFdBQVcsTUFBTTdSLElBQUk2UDtBQUFBQSxRQUN6QjtBQUFBLFFBQ0E7QUFBQSxVQUNFLEdBQUdZO0FBQUFBLFVBQ0g2TixZQUFZbFMsV0FBVztBQUFBLFFBQ3pCO0FBQUEsUUFDQTtBQUFBLFVBQ0U0RCxTQUFTO0FBQUEsWUFDUCxnQkFBZ0I7QUFBQSxVQUNsQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBR0EsWUFBTUYsU0FDSitCLFVBQVVFLE1BQU1BLE1BQU1yRixPQUN0Qm1GLFVBQVVFLE1BQU1uRCxNQUFNbEMsT0FDdEJtRixVQUFVRSxNQUFNckY7QUFHbEIsVUFBSW9ELFFBQVE7QUFDVixjQUFNOVAsSUFBSTZQO0FBQUFBLFVBQ1I7QUFBQSxVQUNBO0FBQUEsWUFDRUM7QUFBQUEsWUFDQUMsUUFBUTtBQUFBLFVBQ1Y7QUFBQSxVQUNBO0FBQUEsWUFDRUMsU0FBUztBQUFBLGNBQ1AsZ0JBQWdCO0FBQUEsWUFDbEI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQWxLLHVCQUFpQixDQUFDc0gsU0FBU0EsT0FBTyxDQUFDO0FBRW5Da0QscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWjVQLFNBQVM7QUFBQSxRQUNUNlAsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUVEbEwsbUJBQWEsS0FBSztBQUVsQm9MLGtCQUFZO0FBQUEsUUFDVjNCLFVBQVU7QUFBQSxRQUNWTSxhQUFhO0FBQUEsUUFDYnVCLFFBQVE7QUFBQSxRQUNSQyxpQkFBaUI7QUFBQSxRQUNqQkMsa0JBQWtCO0FBQUEsUUFDbEJDLHNCQUFzQjtBQUFBLFFBQ3RCQyxNQUFNO0FBQUEsUUFDTkMsbUJBQW1CO0FBQUEsUUFDbkJDLG1CQUFtQjtBQUFBLFFBQ25CQyxnQkFBZ0I7QUFBQSxRQUNoQkMsZUFBZTtBQUFBLE1BQ2pCLENBQUM7QUFBQSxJQUNILFNBQVNuRSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBRTdDcUQscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWjVQLFNBQVM7QUFBQSxRQUNUNlAsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTTJQLHdCQUF3QixPQUFPdk8sZUFBZTtBQUNsRCxRQUFJO0FBQ0YsWUFBTUMsV0FBVyxNQUFNN1IsSUFBSThSLElBQUksc0JBQXNCRixVQUFVLEVBQUU7QUFDakVoTSx5QkFBbUJpTSxTQUFTRSxJQUFJO0FBQ2hDdk0seUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTeUgsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUNoRHFELHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1o1UCxTQUFTO0FBQUEsUUFDVDZQLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1tTSx3QkFBd0IsT0FBTy9LLGVBQWU7QUFDbEQsUUFBSTtBQUNGLFlBQU1DLFdBQVcsTUFBTTdSLElBQUk4UixJQUFJLHVCQUF1QkYsVUFBVSxFQUFFO0FBQ2xFLFlBQU0rSixlQUFlOUosU0FBU0U7QUFDOUIsWUFBTXFPLHFCQUFxQnpFLGNBQWMzSSxZQUFZNkwsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNqRSxZQUFNd0IsbUJBQW1CMUUsY0FBYzFJLFVBQVU0TCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzdELFlBQU15Qix3QkFBd0IzRSxjQUFjekksb0JBQW9CMkwsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUM1RTdZLCtCQUF5QjZMLFNBQVNFLElBQUk7QUFDdENMLHdCQUFrQjtBQUFBLFFBQ2hCM0MsVUFBVThDLFVBQVVFLE1BQU1oRCxTQUFTckM7QUFBQUEsUUFDbkMyQyxhQUFhd0MsVUFBVUUsTUFBTTFDO0FBQUFBLFFBQzdCc0IsWUFBWWtCLFVBQVVFLE1BQU1pSjtBQUFBQSxRQUM1QnBLLFFBQVFpQixVQUFVRSxNQUFNbkI7QUFBQUEsUUFDeEJDLGlCQUFpQmdCLFVBQVVFLE1BQU1sQjtBQUFBQSxRQUNqQ0Msa0JBQWtCZSxVQUFVRSxNQUFNakI7QUFBQUEsUUFDbENvQyxvQkFBb0JvTjtBQUFBQSxRQUNwQnZQLHNCQUFzQmMsVUFBVUUsTUFBTWhCO0FBQUFBLFFBQ3RDaUMsWUFBWW9OO0FBQUFBLFFBQ1puTixVQUFVb047QUFBQUEsUUFDVnJQLE1BQU1hLFVBQVVFLE1BQU1mO0FBQUFBLFFBQ3RCRSxtQkFBbUJXLFVBQVVFLE1BQU1iLG1CQUFtQnhFLE9BQU87QUFBQSxRQUM3RHVFLG1CQUFtQlksVUFBVUUsTUFBTWQsbUJBQW1CdkUsT0FBTztBQUFBLFFBQzdEeUUsZ0JBQWdCVSxVQUFVRSxNQUFNWixnQkFBZ0J6RSxPQUFPO0FBQUEsUUFDdkQwRSxlQUFlUyxVQUFVRSxNQUFNWCxpQkFBaUI7QUFBQSxRQUNoRHhCLGlCQUFpQmlDLFVBQVVFLE1BQU1uQyxtQkFBbUI7QUFBQSxNQUN0RCxDQUFDO0FBQ0RsSyx5QkFBbUIsSUFBSTtBQUN2QjhMLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU3ZFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUNxRCxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaNVAsU0FBUztBQUFBLFFBQ1Q2UCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNK1Asb0JBQW9CQSxDQUFDclEsTUFBTTtBQUMvQixVQUFNLEVBQUV2QyxNQUFNd0MsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQnNCLHNCQUFrQixDQUFDMk4sY0FBYyxFQUFFLEdBQUdBLFVBQVUsQ0FBQzFSLElBQUksR0FBR3dDLE1BQU0sRUFBRTtBQUNoRXFCLGNBQVUsQ0FBQ3BFLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNPLElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUMvQztBQUVBLFFBQU02Uyx1QkFBdUIsWUFBWTtBQUN2QyxRQUFJN2EsaUJBQWlCO0FBQ25CLFVBQUk7QUFDRixjQUFNM0YsSUFBSXlnQixPQUFPLDBCQUEwQjlhLGdCQUFnQitHLEdBQUcsRUFBRTtBQUNoRTRELHVCQUFlO0FBQUEsVUFDYjNQLFNBQVM7QUFBQSxVQUNUNlAsTUFBTTtBQUFBLFVBQ05ELFlBQVk7QUFBQSxRQUNkLENBQUM7QUFDRHpLLHlCQUFpQixDQUFDc0gsU0FBU0EsT0FBTyxDQUFDO0FBQ25DNUgsMkJBQW1CLEtBQUs7QUFDeEJJLDJCQUFtQixJQUFJO0FBQUEsTUFDekIsU0FBU3FILE9BQU87QUFDZEMsZ0JBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQ3BEcUQsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWjVQLFNBQVM7QUFBQSxVQUNUNlAsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1rUSxlQUFlLE9BQU94USxNQUFNO0FBQ2hDQSxNQUFFK1AsZUFBZTtBQUNqQixVQUFNQyxVQUFVTixhQUFhO0FBQzdCLFFBQUksQ0FBQ00sU0FBUztBQUVaO0FBQUEsSUFDRjtBQUNBLFFBQUk7QUFDRixZQUFNbGdCLElBQUkrTSxJQUFJLG1CQUFtQmhILHNCQUFzQjJHLEdBQUcsSUFBSTtBQUFBLFFBQzVELEdBQUcrRTtBQUFBQSxRQUNIM0UsWUFBWVYsV0FBVztBQUFBO0FBQUEsTUFDekIsQ0FBQztBQUNEa0UscUJBQWU7QUFBQSxRQUNiM1AsU0FBUztBQUFBLFFBQ1Q2UCxNQUFNO0FBQUEsUUFDTkQsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUNEdEgsdUJBQWlCLElBQUk7QUFDckJ2RCx5QkFBbUIsS0FBSztBQUN4QkksdUJBQWlCLENBQUNzSCxTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNyQyxTQUFTSCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sNEJBQTRCQSxLQUFLO0FBQy9DcUQscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWjVQLFNBQVM7QUFBQSxRQUNUNlAsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTW1RLGlCQUFpQjtBQUFBLElBQ3JCLEVBQUV2SixLQUFLLE1BQU13SixRQUFRLFFBQVE7QUFBQSxJQUM3QixFQUFFeEosS0FBSyxhQUFhd0osUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRXhKLEtBQUssaUJBQWlCd0osUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFeEosS0FBSyxnQkFBZ0J3SixRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFeEosS0FBSyxlQUFld0osUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRXhKLEtBQUssZUFBZXdKLFFBQVEsd0JBQXdCO0FBQUEsSUFDdEQsRUFBRXhKLEtBQUssNEJBQTRCd0osUUFBUSx3QkFBd0I7QUFBQSxJQUNuRSxFQUFFeEosS0FBSyx5QkFBeUJ3SixRQUFRLHdCQUF3QjtBQUFBLElBQ2hFLEVBQUV4SixLQUFLLG1CQUFtQndKLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRXhKLEtBQUssZ0JBQWdCd0osUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRXhKLEtBQUssV0FBV3dKLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUV4SixLQUFLLG1CQUFtQndKLFFBQVEsU0FBUztBQUFBLElBQzNDLEVBQUV4SixLQUFLLGFBQWF3SixRQUFRLHNCQUFzQkMsT0FBTyxJQUFJO0FBQUEsSUFDN0QsRUFBRXpKLEtBQUssVUFBVXdKLFFBQVEsVUFBVTtBQUFBLEVBQUM7QUFHdEMsUUFBTUUsaUJBQWlCO0FBQUEsSUFDckIsRUFBRTFKLEtBQUssTUFBTXdKLFFBQVEsUUFBUTtBQUFBLElBQzdCLEVBQUV4SixLQUFLLGFBQWF3SixRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFeEosS0FBSyxhQUFhd0osUUFBUSxnQkFBZ0I7QUFBQSxJQUM1QyxFQUFFeEosS0FBSyxnQkFBZ0J3SixRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFeEosS0FBSyxlQUFld0osUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRXhKLEtBQUssZUFBZXdKLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUV4SixLQUFLLDRCQUE0QndKLFFBQVEsd0JBQXdCO0FBQUEsSUFDbkUsRUFBRXhKLEtBQUsseUJBQXlCd0osUUFBUSx3QkFBd0I7QUFBQSxJQUNoRSxFQUFFeEosS0FBSyxtQkFBbUJ3SixRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUV4SixLQUFLLGdCQUFnQndKLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUV4SixLQUFLLFdBQVd3SixRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFeEosS0FBSyxhQUFhd0osUUFBUSxzQkFBc0JDLE9BQU8sSUFBSTtBQUFBLElBQzdELEVBQUV6SixLQUFLLG1CQUFtQndKLFFBQVEsU0FBUztBQUFBLElBQzNDLEVBQUV4SixLQUFLLFVBQVV3SixRQUFRLFVBQVU7QUFBQSxFQUFDO0FBRXRDLFFBQU1HLGVBQWU7QUFBQSxJQUNuQixFQUFFM0osS0FBSyxNQUFNd0osUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRXhKLEtBQUssYUFBYXdKLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUV4SixLQUFLLGlCQUFpQndKLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRXhKLEtBQUssZ0JBQWdCd0osUUFBUSxlQUFlO0FBQUEsSUFDOUMsR0FBSXpaLGNBQWMsY0FBY0EsY0FBYyxlQUFlQSxjQUFjLFdBQ3ZFLENBQUMsRUFBRWlRLEtBQUssV0FBV3dKLFFBQVEsVUFBVSxDQUFDLElBQ3RDO0FBQUEsSUFDSixFQUFFeEosS0FBSyxlQUFld0osUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRXhKLEtBQUssNEJBQTRCd0osUUFBUSx3QkFBd0I7QUFBQSxJQUNuRSxFQUFFeEosS0FBSyx5QkFBeUJ3SixRQUFRLHdCQUF3QjtBQUFBLElBQ2hFLEVBQUV4SixLQUFLLFVBQVV3SixRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFeEosS0FBSyxlQUFld0osUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRXhKLEtBQUssbUJBQW1Cd0osUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFeEosS0FBSyxvQkFBb0J3SixRQUFRLHdCQUF3QjtBQUFBLElBQzNELEVBQUV4SixLQUFLLHlCQUF5QndKLFFBQVEsZ0JBQWdCO0FBQUEsSUFDeEQsRUFBRXhKLEtBQUssc0JBQXNCd0osUUFBUSxnQkFBZ0I7QUFBQSxJQUNyRCxFQUFFeEosS0FBSyxjQUFjd0osUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRXhKLEtBQUssWUFBWXdKLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUV4SixLQUFLLG1CQUFtQndKLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRXhKLEtBQUssYUFBYXdKLFFBQVEsc0JBQXNCQyxPQUFPLElBQUk7QUFBQSxJQUM3RCxFQUFFekosS0FBSyxRQUFRd0osUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRXhKLEtBQUssVUFBVXdKLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFTckMsUUFBTUksVUFBVXBoQixRQUFRLE1BQU07QUFDNUIsUUFBSXVILGNBQWMsV0FBWSxRQUFPd1o7QUFDckMsUUFBSXhaLGNBQWMsVUFBVyxRQUFPMlo7QUFDcEMsUUFBSTNaLGNBQWMsZUFBZUEsY0FBYyxVQUFVO0FBQ3ZELGFBQU80WixhQUFhdFQ7QUFBQUEsUUFBTyxDQUFBd1QsUUFDekJBLElBQUk3SixRQUFRLDhCQUE4QjZKLElBQUk3SixRQUFRO0FBQUEsTUFDeEQ7QUFBQSxJQUNGO0FBQ0EsV0FBTzJKO0FBQUFBLEVBQ1QsR0FBRyxDQUFDNVosU0FBUyxDQUFDO0FBRWQsUUFBTStaLGNBQWNBLE1BQ2xCLHVCQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxnQ0FBK0IsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUN0RixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLDBIQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJMLEtBRDdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsUUFBRyxXQUFVLDBDQUF5Qyw2QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRTtBQUFBLElBQ3BFLHVCQUFDLE9BQUUsV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLE1BQWMvWjtBQUFBQSxNQUFVO0FBQUEsU0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRztBQUFBLElBQ3JHQSxjQUFjLGFBQ2IsdUJBQUMsWUFBTyxTQUFTLE1BQU03QixhQUFhLElBQUksR0FBRyxXQUFVLHFHQUFvRyw4QkFBeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFHRixRQUFNNmIsYUFBYTtBQUFBLElBQ2pCLEVBQUUvSixLQUFLLFlBQVl4RSxPQUFPLFlBQVl3TyxTQUFTLGlCQUFpQkMsVUFBVSxnQkFBZ0I7QUFBQSxJQUMxRixFQUFFakssS0FBSyxZQUFZeEUsT0FBTyxZQUFZd08sU0FBUyxnQkFBZ0JDLFVBQVUsZ0JBQWdCO0FBQUEsSUFDekYsRUFBRWpLLEtBQUssV0FBV3hFLE9BQU8sV0FBV3dPLFNBQVMsaUJBQWlCQyxVQUFVLGVBQWU7QUFBQSxJQUN2RixFQUFFakssS0FBSyxZQUFZeEUsT0FBTyxZQUFZd08sU0FBUyxnQkFBZ0JDLFVBQVUsZ0JBQWdCO0FBQUEsSUFDekYsRUFBRWpLLEtBQUssV0FBV3hFLE9BQU8sV0FBV3dPLFNBQVMsaUJBQWlCQyxVQUFVLGVBQWU7QUFBQSxJQUN2RixFQUFFakssS0FBSyxZQUFZeEUsT0FBTyxZQUFZd08sU0FBUyxjQUFjQyxVQUFVLGdCQUFnQjtBQUFBLElBQ3ZGLEVBQUVqSyxLQUFLLGFBQWF4RSxPQUFPLGFBQWF3TyxTQUFTLGdCQUFnQkMsVUFBVSxpQkFBaUI7QUFBQSxJQUM1RixFQUFFakssS0FBSyxVQUFVeEUsT0FBTyxVQUFVd08sU0FBUyxnQkFBZ0JDLFVBQVUsY0FBYztBQUFBLEVBQUM7QUFHdEYsUUFBTUMsV0FBVzFoQjtBQUFBQSxJQUFRLE1BQU07QUFDN0IsYUFBT3VoQixXQUFXckssSUFBSSxDQUFDa0QsUUFBUTtBQUM3QixjQUFNVCxRQUFRbFIsT0FBTzJSLElBQUlxSCxRQUFRLEtBQUs7QUFDdEMsY0FBTUUsY0FBYyxDQUFDcGIsYUFBYSxDQUFDc0IsZUFDakMyQyxvQkFBb0JFLDBCQUEwQjBQLElBQUk1QyxNQUM3Q2xOLHdCQUF3QixRQUFRQSxvQkFBb0JtRCxTQUFTLElBQzlEbEksZUFBZWtJLFNBQVM7QUFHOUIsWUFBSXFOO0FBQ0osWUFBSXRRLG9CQUFvQkUsMEJBQTBCMFAsSUFBSTVDLEtBQUs7QUFDekRzRCxzQkFBWXhRLHVCQUF1QjtBQUFBLFFBQ3JDLE9BQU87QUFDTHdRLHNCQUFZdlosYUFBYWdFLGdCQUFnQmMsVUFBVTtBQUFBLFFBQ3JEO0FBR0EsY0FBTXViLGNBQWNyYSxjQUFjLGVBQWVBLGNBQWM7QUFDL0QsY0FBTXNhLGdCQUFnQkQsY0FBYzdFLHdCQUF3QjlRO0FBRTVELGVBQU87QUFBQSxVQUNMdUwsS0FBSzRDLElBQUk1QztBQUFBQSxVQUNUeEUsT0FDRSx1QkFBQyxVQUFLLFdBQVUseUNBQ2JvSDtBQUFBQSxnQkFBSXBIO0FBQUFBLFlBQU87QUFBQSxZQUNaLHVCQUFDLFVBQUssV0FBVyxHQUFHb0gsSUFBSW9ILE9BQU8sb0RBQzVCN0gsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBRUZzQyxVQUNFLG1DQUNHMVYsc0JBQ0MsdUJBQUMsa0JBQWUsV0FBVyxNQUFNLE1BQUssZUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQsSUFDL0NzQixjQUFjdEMsZUFBZWtJLFdBQVcsSUFDMUMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWSxJQUVaO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUjtBQUFBLGNBQ0Esa0JBQWtCO0FBQUEsY0FDbEIsTUFBTXFOO0FBQUFBLGNBQ047QUFBQSxjQUNBLGlCQUFnQjtBQUFBLGNBQ2hCLGtCQUFrQjtBQUFBO0FBQUEsWUFQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT2dDLEtBYnBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsUUFFSjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQSxJQUFHO0FBQUEsTUFDRHZVO0FBQUFBLE1BQVdzQjtBQUFBQSxNQUFZdEM7QUFBQUEsTUFBZ0JpRjtBQUFBQSxNQUN2Q0U7QUFBQUEsTUFBdUJKO0FBQUFBLE1BQXFCakU7QUFBQUEsTUFDNUMrYTtBQUFBQSxNQUFTM1k7QUFBQUEsTUFBUWxCO0FBQUFBLE1BQVd3VjtBQUFBQSxJQUFxQjtBQUFBLEVBQ2xEO0FBRUQsUUFBTUUseUJBQXlCLE9BQU82RSxlQUFlO0FBQ25EOWEscUJBQWlCLElBQUk7QUFDckIsUUFBSTtBQUNGLFlBQU0sSUFBSW9RLFFBQVEsQ0FBQzJLLFlBQVlDLFdBQVdELFNBQVMsR0FBSSxDQUFDO0FBQ3hEM2EsMEJBQW9CMGEsVUFBVTtBQUM5QjVhLDBCQUFvQixJQUFJO0FBQUEsSUFDMUIsU0FBU21HLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFBQSxJQUNyRCxVQUFDO0FBQ0NyRyx1QkFBaUIsS0FBSztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUVBLFFBQU0wVixnQkFBZ0I7QUFBQSxJQUNwQixFQUFFbk0sT0FBTyxhQUFheUMsT0FBTyxhQUFhc0gsTUFBTSx1QkFBQywrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCLEdBQUsySCxPQUFPLE9BQU87QUFBQSxJQUM3RixFQUFFMVIsT0FBTyxXQUFXeUMsT0FBTyxXQUFXc0gsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CLEdBQUsySCxPQUFPLFNBQVM7QUFBQSxJQUNyRixFQUFFMVIsT0FBTyxZQUFZeUMsT0FBTyxVQUFVc0gsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CLEdBQUsySCxPQUFPLE1BQU07QUFBQSxJQUNsRixFQUFFMVIsT0FBTyxXQUFXeUMsT0FBTyxXQUFXc0gsTUFBTSx1QkFBQyw0QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCLEdBQUsySCxPQUFPLFNBQVM7QUFBQSxJQUN4RixFQUFFMVIsT0FBTyxZQUFZeUMsT0FBTyxZQUFZc0gsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CLEdBQUsySCxPQUFPLFFBQVE7QUFBQSxJQUN0RixFQUFFMVIsT0FBTyxZQUFZeUMsT0FBTyxZQUFZc0gsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CLEdBQUsySCxPQUFPLE9BQU87QUFBQSxFQUFDO0FBR3hGLFFBQU1DLDZCQUE2QkEsQ0FBQzNSLFVBQVU7QUFDNUNpUCxxQkFBaUIsbUJBQW1CalAsS0FBSztBQUN6Q08sZ0JBQVksQ0FBQ3RELFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNId0MsaUJBQWlCTztBQUFBQSxJQUNuQixFQUFFO0FBQUEsRUFDSjtBQUVBLFNBQ0UsbUNBQ0UsaUNBQUMsU0FDQztBQUFBLDJCQUFDLFVBQU8sWUFBWSxNQUFNLCtCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1GO0FBQUEsSUFDbkY7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1FLFlBQVlHO0FBQUFBLFFBQ2xCLFdBQVdILFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVkxUDtBQUFBQSxRQUNyQixTQUFTLE1BQU0yUCxlQUFlLENBQUNsRCxVQUFVLEVBQUUsR0FBR0EsTUFBTW1ELFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUoxRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJNEU7QUFBQSxJQUU1RSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFDWCx1QkFBQyxTQUFJLFdBQVUsdURBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNENBQTJDLHFCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxhQUFZO0FBQUEsa0JBQ1osT0FBTzdGO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3dGLE1BQU12RixlQUFldUYsRUFBRUUsT0FBT0QsS0FBSztBQUFBLGtCQUM5QyxjQUFjLE1BQU1uQyxhQUFhdEQsV0FBVztBQUFBLGtCQUM1QztBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxRQUFRLHVCQUFDLGtCQUFlLE9BQU8sRUFBRW1YLE9BQU8sVUFBVSxLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QztBQUFBLGtCQUNwRCxXQUFVO0FBQUE7QUFBQSxnQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNkw7QUFBQSxjQUU3TDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFlO0FBQUEsa0JBQ3JCLFNBQVMsTUFBTTdULGFBQWF0RCxXQUFXO0FBQUEsa0JBQ3ZDLFdBQVU7QUFBQSxrQkFBMEc7QUFBQTtBQUFBLGdCQUp0SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGlCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsSUFBRztBQUFBLGtCQUNILFdBQVU7QUFBQSxrQkFFZ0I7QUFBQTtBQUFBLGdCQUo1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsSUFBRztBQUFBLGtCQUNILFdBQVU7QUFBQSxrQkFFZ0I7QUFBQTtBQUFBLGdCQUo1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNO0FBQ2JwRixpQ0FBYSxJQUFJO0FBQ2pCa00sOEJBQVUsQ0FBQyxDQUFDO0FBQUEsa0JBQ2Q7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBQThGO0FBQUE7QUFBQSxnQkFMMUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUE7QUFBQSxpQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkE7QUFBQSxlQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVEQTtBQUFBLGFBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwREE7QUFBQSxRQUVDcEksaUJBQ0MsdUJBQUMsa0JBQWUsV0FBVyxNQUFNLE1BQUssa0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0QsSUFFcEQsdUJBQUMsU0FBSSxXQUFVLDZEQUNaTCwyQkFBaUIrTixJQUFJLENBQUMvRyxXQUFXO0FBQ2hDLGdCQUFNZ1MsUUFBUTdZLFlBQVl5RixLQUFLLENBQUEySyxTQUFRQSxLQUFLdkosV0FBV0EsTUFBTTtBQUM3RCxnQkFBTXdKLFFBQVF3SSxPQUFPeEksU0FBUztBQUM5QixnQkFBTXlJLGNBQWNELE9BQU9FLGdCQUFnQjtBQUczQyxnQkFBTUMsZUFBZTtBQUFBLFlBQ25CMUksV0FBVztBQUFBLGNBQ1QySSxJQUFJO0FBQUEsY0FDSkMsUUFBUTtBQUFBLGNBQ1JuTyxNQUFNO0FBQUEsY0FDTmlHLE1BQU0sdUJBQUMsYUFBVSxXQUFVLG1CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLFlBQzVDO0FBQUEsWUFDQVQsVUFBVTtBQUFBLGNBQ1IwSSxJQUFJO0FBQUEsY0FDSkMsUUFBUTtBQUFBLGNBQ1JuTyxNQUFNO0FBQUEsY0FDTmlHLE1BQU0sdUJBQUMsaUJBQWMsV0FBVSxvQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUM7QUFBQSxZQUNqRDtBQUFBLFlBQ0FSLFNBQVM7QUFBQSxjQUNQeUksSUFBSTtBQUFBLGNBQ0pDLFFBQVE7QUFBQSxjQUNSbk8sTUFBTTtBQUFBLGNBQ05pRyxNQUFNLHVCQUFDLG1CQUFnQixXQUFVLHFCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QztBQUFBLFlBQ3BEO0FBQUEsWUFDQVAsVUFBVTtBQUFBLGNBQ1J3SSxJQUFJO0FBQUEsY0FDSkMsUUFBUTtBQUFBLGNBQ1JuTyxNQUFNO0FBQUEsY0FDTmlHLE1BQU0sdUJBQUMsY0FBVyxXQUFVLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLFlBQy9DO0FBQUEsWUFDQUosU0FBUztBQUFBLGNBQ1BxSSxJQUFJO0FBQUEsY0FDSkMsUUFBUTtBQUFBLGNBQ1JuTyxNQUFNO0FBQUEsY0FDTmlHLE1BQU0sdUJBQUMsb0JBQWlCLFdBQVUscUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDO0FBQUEsWUFDckQ7QUFBQSxZQUNBTixVQUFVO0FBQUEsY0FDUnVJLElBQUk7QUFBQSxjQUNKQyxRQUFRO0FBQUEsY0FDUm5PLE1BQU07QUFBQSxjQUNOaUcsTUFBTSx1QkFBQyxpQkFBYyxXQUFVLGtCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLFlBQy9DO0FBQUEsWUFDQUwsV0FBVztBQUFBLGNBQ1RzSSxJQUFJO0FBQUEsY0FDSkMsUUFBUTtBQUFBLGNBQ1JuTyxNQUFNO0FBQUEsY0FDTmlHLE1BQU0sdUJBQUMsbUJBQWdCLFdBQVUsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBDO0FBQUEsWUFDbEQ7QUFBQSxVQUNGO0FBRUEsZ0JBQU1tSSxTQUFTSCxhQUFhblMsTUFBTTtBQUVsQyxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVyxxQkFBcUJzUyxPQUFPRixFQUFFLHNCQUFzQkUsT0FBT0QsTUFBTTtBQUFBLGNBRTVFO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFXLHNEQUFzREMsT0FBT3BPLElBQUksSUFDL0VsRSxvQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLFdBQVdzUyxpQkFBT25JLFFBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUEscUJBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsbUNBQW1DWCxtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUQ7QUFBQSxrQkFDekQsdUJBQUMsVUFBSyxXQUFVLDZCQUE0QixxQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUQ7QUFBQSxxQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiLGlDQUFDLE9BQUUsV0FBVSwrREFBOEQ7QUFBQTtBQUFBLGtCQUV6RSx1QkFBQyxvQkFBaUIsV0FBVSxjQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzQztBQUFBLGtCQUNyQzNOLHFCQUFxQm9XLFdBQVc7QUFBQSxxQkFIbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQTtBQUFBO0FBQUEsWUFuQktqUztBQUFBQSxZQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFxQkE7QUFBQSxRQUVKLENBQUMsS0E5RUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStFQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXNUk7QUFBQUEsWUFDWCxVQUFVLENBQUNpUSxRQUFRO0FBQ2pCaFEsMkJBQWFnUSxHQUFHO0FBRWhCL00sa0NBQW9CLEVBQUU7QUFDdEJGLHFDQUF1QixJQUFJO0FBQzNCSSx1Q0FBeUIsSUFBSTtBQUM3QkksNkJBQWUsRUFBRTtBQUFBLFlBQ25CO0FBQUEsWUFDQSxPQUFPMlc7QUFBQUEsWUFDUCx3QkFBd0I7QUFBQTtBQUFBLFVBWDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVcrQixLQVpqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxXQWhLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUtBO0FBQUEsU0FuS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9LQTtBQUFBLElBR0EsdUJBQUMsU0FBTSxXQUFXamMsV0FBVyxTQUFTLE1BQU1DLGFBQWEsS0FBSyxHQUM1RCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLHdCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsTUFDN0QsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVTBhLGNBQWMsWUFBVSxNQUM1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQWU7QUFBQTtBQUFBLGdCQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUE7QUFBQTtBQUFBLFlBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyxxQ0FBcUM5ZCxVQUFVb2dCLE1BQU07QUFBQSxjQUNoRSxhQUFZO0FBQUEsY0FDWix1QkFBdUI7QUFBQSxjQUN2QjtBQUFBLGNBQ0EsTUFBSztBQUFBLGNBQ0wsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBTzNHLFNBQ0o0RyxTQUFTLEVBQ1RsVixZQUFZLEVBQ1pRLFNBQVN3VSxNQUFNaFYsWUFBWSxDQUFDO0FBQUEsY0FFakMsT0FBT2tELFVBQVUxQixZQUFZbEQ7QUFBQUEsY0FDN0IsVUFBVSxDQUFDc0UsVUFBVWlQLGlCQUFpQixZQUFZalAsS0FBSztBQUFBLGNBRXREeEwsZ0JBQU1tUztBQUFBQSxnQkFBSSxDQUFDekssU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS0ssS0FDdkNMO0FBQUFBLHVCQUFLcVc7QUFBQUEsa0JBQVk7QUFBQSxrQkFBSXJXLEtBQUt5QztBQUFBQSxrQkFBVTtBQUFBLGtCQUFHO0FBQUEsa0JBQ3ZDekMsS0FBS3lCO0FBQUFBLHFCQUZZekIsS0FBS0ssS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBLFlBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXFCQTtBQUFBLFVBQ0M2RSxPQUFPeEMsWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCd0MsaUJBQU94QyxZQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLGFBOUI5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTThOLHVCQUF1QnBNLFNBQVMxQixRQUFRO0FBQUEsWUFDdkQsVUFBVSxDQUFDMEIsVUFBVTFCLFlBQVlwSTtBQUFBQSxZQUNqQyxXQUFVO0FBQUEsWUFFVEEsMEJBQ0MsbUNBQ0U7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsaUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThCO0FBQUEsY0FBTztBQUFBLGlCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLElBRUE7QUFBQTtBQUFBLFVBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFhO0FBQUE7QUFBQSxrQkFFVCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBO0FBQUE7QUFBQSxjQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU84SixTQUFTcEI7QUFBQUEsZ0JBQ2hCLFVBQVVtUTtBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUN0ZCxVQUFVb2dCLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVE2SjtBQUFBLFlBRTVKL1EsT0FBT2xDLGVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWa0MsaUJBQU9sQyxlQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVGLHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLE9BQUUsV0FBVSw2REFDVmpMLDhCQUFvQnFNLFVBQVVwQixXQUFXLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFRO0FBQUE7QUFBQSxrQkFFRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBO0FBQUE7QUFBQSxjQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9vQixTQUFTRztBQUFBQSxnQkFDaEIsVUFBVTRPO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3RkLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsWUFFNUovUSxPQUFPWCxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJXLGlCQUFPWCxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLFlBRTFELHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLE9BQUUsV0FBVSw2REFDVnhNLDhCQUFvQnFNLFVBQVVHLE1BQU0sS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLGFBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1REE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFpQjtBQUFBO0FBQUEsa0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FKbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPSCxTQUFTSTtBQUFBQSxnQkFDaEIsVUFBVTJPO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3RkLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsWUFFNUovUSxPQUFPVixtQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZVLGlCQUFPVixtQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFRix1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxPQUFFLFdBQVUsNkRBQ1Z6TSw4QkFBb0JxTSxVQUFVSSxlQUFlLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFrQjtBQUFBO0FBQUEsa0JBRUo7QUFBQSxrQkFDdEIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPSixTQUFTSztBQUFBQSxnQkFDaEIsVUFBVTBPO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3RkLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsWUFFNUovUSxPQUFPVCxvQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZTLGlCQUFPVCxvQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFRix1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxPQUFFLFdBQVUsNkRBQ1YxTSw4QkFBb0JxTSxVQUFVSyxnQkFBZ0IsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRCQTtBQUFBLGFBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyREE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFzQjtBQUFBO0FBQUEsa0JBRVQ7QUFBQSxrQkFDckIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixNQUFLO0FBQUEsZ0JBQ0wsT0FBT0wsU0FBU007QUFBQUEsZ0JBQ2hCLFVBQVV5TztBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0g7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3RkLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsWUFFNUovUSxPQUFPUix3QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZRLGlCQUFPUix3QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFRix1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxPQUFFLFdBQVUsNkRBQ1YzTSw4QkFBb0JxTSxVQUFVTSxvQkFBb0IsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQWlCO0FBQUE7QUFBQSxjQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1osT0FDR29DLE9BQU8xQyxVQUFVcEIsZUFBZSxDQUFDLElBQ2hDOEQsT0FBTzFDLFVBQVVJLG1CQUFtQixDQUFDLElBQ3JDc0MsT0FBTzFDLFVBQVVLLG9CQUFvQixDQUFDLEtBQU07QUFBQSxnQkFFaEQ7QUFBQSxnQkFDQSxXQUFXLHNDQUFzQzVPLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUEsY0FYbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV29IO0FBQUEsWUFFcEgsdUJBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsT0FBRSxXQUFVLDZEQUNWbGUsOEJBQXFCK08sT0FBTzFDLFVBQVVwQixXQUFXLElBQ2hEOEQsT0FBTzFDLFVBQVVJLGVBQWUsSUFDaENzQyxPQUFPMUMsVUFBVUssZ0JBQWdCLENBQUUsS0FIdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJCQTtBQUFBLGFBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyREE7QUFBQSxRQTRFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGNBQ2xELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLHFDQUFxQzVPLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUE7QUFBQSxnQkFHaEUsYUFBWTtBQUFBLGdCQUNaLHVCQUF1QjtBQUFBLGdCQUV2QjtBQUFBLGdCQUNBLE1BQUs7QUFBQSxnQkFDTCxjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQSxPQUFPM0csU0FDSnRPLFlBQVksRUFDWlEsU0FBU3dVLE1BQU1oVixZQUFZLENBQUM7QUFBQSxnQkFFakMsT0FBT2tELFVBQVVXLGlCQUFpQnZGO0FBQUFBLGdCQUNsQyxVQUFVLENBQUNzRSxVQUNUaVAsaUJBQWlCLGlCQUFpQmpQLEtBQUs7QUFBQSxnQkFHeEM7QUFBQSxrQkFDQztBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsZ0JBQVEsRUFDUjJHO0FBQUFBLGtCQUFJLENBQUNMLFlBQ0wsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLFNBQ2pDQSxxQkFEaUJBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0E3Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBOEJBO0FBQUEsZUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQ0E7QUFBQSxVQUNDaEcsU0FBU1csa0JBQWtCLGNBQzFCLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFVO0FBQUE7QUFBQSxrQkFFTztBQUFBLGtCQUN6Qix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBO0FBQUE7QUFBQSxjQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLHFDQUFxQ2xQLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUE7QUFBQSxnQkFHaEUsYUFBWTtBQUFBLGdCQUNaLHVCQUF1QjtBQUFBLGdCQUN2QjtBQUFBLGdCQUVBLE1BQUs7QUFBQSxnQkFDTCxjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQSxPQUFPM0csU0FDSjRHLFNBQVMsRUFDVGxWLFlBQVksRUFDWlEsU0FBU3dVLE1BQU1oVixZQUFZLENBQUM7QUFBQSxnQkFFakMsT0FBT2tELFVBQVVRLHFCQUFxQnBGO0FBQUFBLGdCQUN0QyxVQUFVLENBQUNzRSxVQUNUaVAsaUJBQWlCLHFCQUFxQmpQLEtBQUs7QUFBQSxnQkFHNUN4TCxnQkFBTW1TO0FBQUFBLGtCQUFJLENBQUN6SyxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLSyxLQUN2Q0w7QUFBQUEseUJBQUt5QztBQUFBQSxvQkFBVTtBQUFBLG9CQUFHO0FBQUEsb0JBQ2xCekMsS0FBS3lCLGVBQWV6QixLQUFLeUIsZUFBZTtBQUFBLHVCQUZ2QnpCLEtBQUtLLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0F6Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBMEJBO0FBQUEsZUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQ0E7QUFBQSxVQUVEK0QsU0FBU1csa0JBQWtCLFdBQzFCLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsY0FDeEM7QUFBQSxjQUN0Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyxxQ0FBcUNsUCxVQUFVb2dCLE1BQU07QUFBQSxnQkFDaEUsYUFBWTtBQUFBLGdCQUNaLHVCQUF1QjtBQUFBLGdCQUN2QjtBQUFBLGdCQUVBLE1BQUs7QUFBQSxnQkFDTCxjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQSxPQUFPM0csU0FDSjRHLFNBQVMsRUFDVGxWLFlBQVksRUFDWlEsU0FBU3dVLE1BQU1oVixZQUFZLENBQUM7QUFBQSxnQkFFakMsT0FBT2tELFNBQVNVLGtCQUFrQnRGO0FBQUFBLGdCQUNsQyxVQUFVLENBQUNzRSxVQUNUaVAsaUJBQWlCLGtCQUFrQmpQLEtBQUs7QUFBQSxnQkFHekN0TCxpQkFBT2lTO0FBQUFBLGtCQUFJLENBQUNXLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU0vSyxLQUN6QytLO0FBQUFBLDBCQUFNOUo7QUFBQUEsb0JBQUs7QUFBQSxvQkFBSThKLE1BQU0zSjtBQUFBQSx1QkFESjJKLE1BQU0vSyxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXVCQTtBQUFBLGVBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkJBO0FBQUEsVUFFRCtELFNBQVNXLGtCQUFrQixjQUMxQix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBVTtBQUFBO0FBQUEsa0JBRU87QUFBQSxrQkFDekIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyxxQ0FBcUNsUCxVQUFVb2dCLE1BQU07QUFBQTtBQUFBO0FBQUEsZ0JBR2hFLGFBQVk7QUFBQSxnQkFDWix1QkFBdUI7QUFBQSxnQkFDdkI7QUFBQSxnQkFDQSxrQkFBaUI7QUFBQSxnQkFDakIsTUFBSztBQUFBLGdCQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLFFBQVE1UCxPQUNKckYsWUFBWSxFQUNiUSxTQUFTd1UsTUFBTWhWLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxPQUFPa0QsVUFBVVMscUJBQXFCckY7QUFBQUEsZ0JBQ3RDLFVBQVUsQ0FBQ3NFLFVBQ1RpUCxpQkFBaUIscUJBQXFCalAsS0FBSztBQUFBLGdCQUc1Q3BMLG9CQUFVK1I7QUFBQUEsa0JBQUksQ0FBQ2MsYUFDZDtBQUFBLG9CQUFDLE9BQU87QUFBQSxvQkFBUDtBQUFBLHNCQUVDLE9BQU9BLFNBQVNsTDtBQUFBQSxzQkFDaEIsT0FBTyxHQUFHa0wsU0FBU2pLLElBQUksTUFBTWlLLFNBQVM5SixZQUFZO0FBQUEsc0JBRWpEOEo7QUFBQUEsaUNBQVNqSztBQUFBQSx3QkFBSztBQUFBLHdCQUFJaUssU0FBUzlKO0FBQUFBO0FBQUFBO0FBQUFBLG9CQUp2QjhKLFNBQVNsTDtBQUFBQSxvQkFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQTNCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE0QkE7QUFBQSxlQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFDQTtBQUFBLGFBakpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvSkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0Msb0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPK0QsU0FBU087QUFBQUEsa0JBQ2hCLFVBQVV3TztBQUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osV0FBVyxxQ0FBcUN0ZCxVQUFVb2dCLE1BQU07QUFBQTtBQUFBLGdCQU5sRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNNko7QUFBQSxjQUU3SjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNL0wsT0FBT0MsS0FBSyxnQkFBZ0I7QUFBQSxrQkFFM0MsaUNBQUMsZ0JBQWEsT0FBTSxXQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQjtBQUFBO0FBQUEsZ0JBSjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLGVBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxjQUN2RCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTy9GLFNBQVNiO0FBQUFBLGdCQUNoQixVQUFVLENBQUNPLFVBQVVpUCxpQkFBaUIsbUJBQW1CalAsS0FBSztBQUFBLGdCQUM5RCxXQUFXLHFDQUFxQ2pPLFVBQVVvZ0IsTUFBTTtBQUFBLGdCQUNoRSx1QkFBdUI7QUFBQSxnQkFDdkIsaUJBQWdCO0FBQUEsZ0JBRWZoRyx3QkFBY3hGO0FBQUFBLGtCQUFJLENBQUMwRixRQUNsQix1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsSUFBSXJNLE9BQU8sT0FBT3FNLElBQUk1SixPQUMxRCxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwyQ0FBQyxVQUFLLE9BQU8sRUFBRWlQLE9BQU9yRixJQUFJcUYsTUFBTSxHQUFJckYsY0FBSXRDLFFBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZDO0FBQUEsb0JBQzdDLHVCQUFDLFVBQUssV0FBVSxlQUFlc0MsY0FBSTVKLFNBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlDO0FBQUEsdUJBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0EsS0FKa0I0SixJQUFJck0sT0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWVBO0FBQUEsZUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxhQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOENBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNxRztBQUFBO0FBQUEsVUFIakg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQTFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMmZBO0FBQUEsU0E3ZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThmQSxLQS9mRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ2dCQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVc5STtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQywrQkFBcUIsS0FBSztBQUMxQkosMEJBQWdCLElBQUk7QUFBQSxRQUN0QjtBQUFBLFFBQ0EsTUFBSztBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBRVYsaUNBQUMsU0FBSSxXQUFVLGlJQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtDQUNiLGlDQUFDLFFBQUcsV0FBVSx5RUFBd0UsaUNBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVHLEtBRHpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHNDQUViO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsT0FBT2dKLE1BQU07QUFDcEIsd0JBQU15UyxNQUFNelMsRUFBRTBTO0FBQ2Qsd0JBQU1DLGVBQWVGLElBQUlHO0FBQ3pCSCxzQkFBSUksV0FBVztBQUNmSixzQkFBSUcsWUFBWTtBQUVoQixzQkFBSTtBQUNGLDBCQUFNakcsdUJBQXVCNVYsY0FBYzhILFVBQVVyQyxPQUFPekYsY0FBYzhILFVBQVVGLFNBQVNuQyxHQUFHO0FBQUEsa0JBQ2xHLFNBQVNnTCxLQUFLO0FBQ1p4Syw0QkFBUUQsTUFBTXlLLEdBQUc7QUFBQSxrQkFDbkIsVUFBQztBQUNDaUwsd0JBQUlHLFlBQVlEO0FBQ2hCRix3QkFBSUksV0FBVztBQUFBLGtCQUNqQjtBQUFBLGdCQUNGO0FBQUEsZ0JBQ0EsVUFBVSxDQUFDOWIsY0FBYzhILFVBQVVyQztBQUFBQSxnQkFDbkMsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsU0FBTSxXQUFVLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVCO0FBQUEsa0JBQUc7QUFBQTtBQUFBO0FBQUEsY0FwQjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXNCQSxLQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLGFBR0V6RixjQUFjb0YsUUFBUXBGLGNBQWM0SCxZQUNwQyx1QkFBQyxTQUFJLFdBQVUsZ0hBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUViO0FBQUEscUNBQUMsU0FBSSxXQUFVLDhKQUNYNUgsd0JBQWE0SCxTQUFTQyxXQUFXa1UsT0FBTyxDQUFDLEtBQ3pDL2IsYUFBYW9GLE1BQU15QyxXQUFXa1UsT0FBTyxDQUFDLEtBQ3RDLEtBQ0FDLFlBQVksS0FKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJDQUViO0FBQUEseUNBQUMsUUFBRyxXQUFVLHdEQUNYaGMsdUJBQWE0SCxTQUFTQyxhQUFhN0gsYUFBYW9GLE1BQU15QyxhQUFhLGFBRHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFHQSx1QkFBQyxVQUFLLFdBQVUsaUdBQ2Q7QUFBQSwyQ0FBQyxVQUFPLFdBQVUsVUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0I7QUFBQSxvQkFBRztBQUFBLHVCQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGdCQUdBLHVCQUFDLE9BQUUsV0FBVSxzREFDWDtBQUFBLHlDQUFDLFdBQVEsV0FBVSwyQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEM7QUFBQSxrQkFDekM3SCxhQUFhNEgsU0FBU2YsZ0JBQWdCN0csYUFBYW9GLE1BQU15QixnQkFBZ0I7QUFBQSxxQkFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGlCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQSxLQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdDQTtBQUFBLFlBSUYsdUJBQUMsU0FBSSxXQUFVLDhDQUVaN0c7QUFBQUEsNEJBQWNvSSxlQUFlLFFBQzVCLHVCQUFDLFNBQUksV0FBVSxrS0FDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsK0hBQ2IsaUNBQUMsZUFBWSxXQUFVLHdCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLCtCQUE4QiwyQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFFQSx1QkFBQyxVQUFLLFdBQVUsc0RBQXFEO0FBQUE7QUFBQSxrQkFDakVwSSxjQUFjb0ksWUFBWWdPLGVBQWUsT0FBTztBQUFBLHFCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxjQUlEcFcsY0FBY21YLGdCQUNiLHVCQUFDLFNBQUksV0FBVSwrSkFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsNkhBQ2IsaUNBQUMsY0FBVyxXQUFVLHdCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLCtCQUE4Qix1QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFFQSx1QkFBQyxVQUFLLFdBQVUsK0RBQ2JuWCx3QkFBY21YLGdCQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxjQUlEblgsY0FBYytULGFBQ2IsdUJBQUMsU0FBSSxXQUFVLHFLQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxtSEFDYixpQ0FBQyxXQUFRLFdBQVUsd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUsK0JBQThCLDBCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUVBLHVCQUFDLFVBQUssV0FBVSxzRUFDYixjQUFJRCxLQUFLOVQsY0FBYytULFNBQVMsRUFBRW1DLG1CQUFtQixTQUFTO0FBQUEsa0JBQzdEK0YsS0FBSztBQUFBLGtCQUNMQyxPQUFPO0FBQUEsa0JBQ1BDLE1BQU07QUFBQSxrQkFDTkMsTUFBTTtBQUFBLGtCQUNOQyxRQUFRO0FBQUEsZ0JBQ1YsQ0FBQyxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxlQUlBcmMsY0FBYzRILFNBQVMwVSxvQkFBb0J0YyxjQUFjNEgsU0FBU3FDLHNCQUNsRSx1QkFBQyxTQUFJLFdBQVUsa0tBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLGlIQUNiLGlDQUFDLGNBQVcsV0FBVSx3QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSwrQkFBOEIsMkJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDZEQUNiakssd0JBQWM0SCxTQUFTcUMsbUJBQW1CdkQsUUFDekMxRyxjQUFjNEgsU0FBU3FDLG1CQUFtQnBELGVBRXhDLHVCQUFDLFNBQUksV0FBVSwyQkFFYjtBQUFBLHlDQUFDLFVBQUs7QUFBQTtBQUFBLG9CQUFrQjdHLGNBQWM0SCxTQUFTcUMsa0JBQWtCdkQ7QUFBQUEsdUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNFO0FBQUEsa0JBQ3RFLHVCQUFDLFVBQU0xRyx3QkFBYzRILFNBQVNxQyxtQkFBbUJwRCxnQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEQ7QUFBQSxxQkFIaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQSxJQUVBN0csY0FBYzRILFNBQVNzQyxnQkFBZ0J4RCxPQUVyQyx1QkFBQyxTQUFJLFdBQVUsMkJBRWI7QUFBQSx5Q0FBQyxVQUFLO0FBQUE7QUFBQSxvQkFBVzFHLGNBQWM0SCxTQUFTc0MsZUFBZXhEO0FBQUFBLHVCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RDtBQUFBLGtCQUM1RCx1QkFBQyxVQUFNMUcsd0JBQWM0SCxTQUFTc0MsZUFBZXJELGdCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRDtBQUFBLHFCQUg1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBLElBRUE3RyxjQUFjNEgsU0FBU29DLG1CQUFtQm5DLGFBQzFDN0gsY0FBYzRILFNBQVNvQyxtQkFBbUJuRCxlQUV4Qyx1QkFBQyxTQUFJLFdBQVUsMkJBRWI7QUFBQSx5Q0FBQyxVQUFLO0FBQUE7QUFBQSxvQkFBZ0I3RyxjQUFjNEgsU0FBU29DLGtCQUFrQm5DO0FBQUFBLHVCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RTtBQUFBLGtCQUN6RSx1QkFBQyxVQUFNN0gsd0JBQWM0SCxTQUFTb0MsbUJBQW1CbkQsZ0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThEO0FBQUEscUJBSGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUEsSUFFQSxTQTNCVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTZCQTtBQUFBLG1CQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVDQSxLQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXlDQTtBQUFBLGlCQTlHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtIQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDBEQUNaO0FBQUEsdUNBQUMsY0FBVyxXQUFVLFVBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRCO0FBQUEsZ0JBQUc7QUFBQSxtQkFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUNWLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0I7QUFBQSxvQkFDMUIsVUFBVTdHLGNBQWNvRyxXQUFXO0FBQUEsb0JBRW5DLFNBQVMsTUFBTTtBQUNiM0osa0NBQVk7QUFBQSx3QkFDVjhMLE9BQU87QUFBQSx3QkFDUEMsU0FBUztBQUFBLHdCQUNUQyxXQUFXQSxNQUFNSixpQkFBaUJySSxjQUFjLFNBQVM7QUFBQSxzQkFDM0QsQ0FBQztBQUFBLG9CQUNIO0FBQUEsb0JBQ0EsT0FBSztBQUFBO0FBQUE7QUFBQSxrQkFkUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBaUJBO0FBQUEsZ0JBS0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMO0FBQUEsb0JBQ0EsVUFBVUEsY0FBY29HLFdBQVc7QUFBQSxvQkFDbkMsV0FBVTtBQUFBLG9CQUNWLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0I7QUFBQSxvQkFDMUI7QUFBQSxvQkFDQSxTQUFTLE1BQU07QUFDYjNKLGtDQUFZO0FBQUEsd0JBQ1Y4TCxPQUFPO0FBQUEsd0JBQ1BDLFNBQVM7QUFBQSx3QkFDVEMsV0FBV0EsTUFBTUosaUJBQWlCckksY0FBYyxVQUFVO0FBQUEsc0JBQzVELENBQUM7QUFBQSxvQkFDSDtBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFiSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZ0JBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBQ1YsTUFBTSx1QkFBQyw0QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1QjtBQUFBLG9CQUM3QixVQUFVQSxjQUFjb0csV0FBVztBQUFBLG9CQUNuQztBQUFBLG9CQUNBLFNBQVMsTUFBTTtBQUNiM0osa0NBQVk7QUFBQSx3QkFDVjhMLE9BQU87QUFBQSx3QkFDUEMsU0FBUztBQUFBLHdCQUNUQyxXQUFXQSxNQUFNSixpQkFBaUJySSxjQUFjLFNBQVM7QUFBQSxzQkFDM0QsQ0FBQztBQUFBLG9CQUNIO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFpQkE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0w7QUFBQSxvQkFDQTtBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFDVixNQUFNLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWM7QUFBQSxvQkFDcEIsVUFBVUEsY0FBY29HLFdBQVc7QUFBQSxvQkFDbkMsU0FBUyxNQUFNO0FBQ2IzSixrQ0FBWTtBQUFBLHdCQUNWOEwsT0FBTztBQUFBLHdCQUNQQyxTQUFTO0FBQUEsd0JBQ1RDLFdBQVdBLE1BQU1KLGlCQUFpQnJJLGNBQWMsVUFBVTtBQUFBLHNCQUM1RCxDQUFDO0FBQUEsb0JBQ0g7QUFBQSxvQkFDQSxPQUFLO0FBQUE7QUFBQTtBQUFBLGtCQWRQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFpQkE7QUFBQSxnQkFLQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFDYkssMkNBQXFCLEtBQUs7QUFDMUJKLHNDQUFnQixJQUFJO0FBQUEsb0JBQ3RCO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUNWLE9BQUs7QUFBQTtBQUFBO0FBQUEsa0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUEsbUJBM0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNEZBO0FBQUEsaUJBakdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0dBO0FBQUEsZUF6UkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwUkE7QUFBQSxhQWhTRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaVNBO0FBQUE7QUFBQSxNQTFTRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUEyU0E7QUFBQSxJQUNDTCxvQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsWUFBWUU7QUFBQUEsUUFDWixTQUFTRjtBQUFBQSxRQUNULFNBQVMsTUFBTUMsb0JBQW9CLEtBQUs7QUFBQTtBQUFBLE1BSDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUc0QztBQUFBLElBSzlDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXckI7QUFBQUEsUUFDWCxTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFFdkMsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG1DQUFrQywyQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDRHQUNiO0FBQUEscUNBQUMsaUJBQWMsV0FBVSwrQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxjQUNwRCx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLDJCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RDtBQUFBLGNBQ3ZELHVCQUFDLFVBQUssV0FBVSwrQkFDYitMLDBCQUFnQmQsY0FBY2MsZ0JBQWdCdUosWUFDM0MsSUFBSUQsS0FBS3RKLGVBQWVkLGNBQWNjLGVBQWV1SixTQUFTLEVBQUVtQyxtQkFBbUIsT0FBTyxJQUMxRixPQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQSx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVV1RCxjQUFjLFlBQVUsTUFDNUQ7QUFBQSxtQ0FBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBZTtBQUFBO0FBQUEsb0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQ3hlLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUE7QUFBQSxrQkFHaEUsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU8zRyxTQUNKNEcsU0FBUyxFQUNUbFYsWUFBWSxFQUNaUSxTQUFTd1UsTUFBTWhWLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPa0UsZ0JBQWdCMUMsWUFBWWxEO0FBQUFBLGtCQUNuQyxVQUFVLENBQUNzRSxVQUFVb1Asc0JBQXNCLFlBQVlwUCxLQUFLO0FBQUEsa0JBRTNEeEwsaUJBQU9tUztBQUFBQSxvQkFBSSxDQUFDekssU0FDWCx1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS0ssS0FDdkNMLGVBQUt5QyxhQURZekMsS0FBS0ssS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkF0Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdUJBO0FBQUEsY0FDQzZFLE9BQU94QyxZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ3QyxpQkFBT3hDLFlBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBEO0FBQUEsaUJBaEM5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLG9CQWViO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsT0FBT21CLE1BQU07QUFDcEIsd0JBQU15UyxNQUFNelMsRUFBRTBTO0FBQ2Qsd0JBQU1DLGVBQWVGLElBQUlHO0FBQ3pCSCxzQkFBSUksV0FBVztBQUNmSixzQkFBSUcsWUFBWTtBQUVoQixzQkFBSTtBQUNGLDBCQUFNakcsdUJBQXVCcEwsZ0JBQWdCMUMsUUFBUTtBQUFBLGtCQUN2RCxTQUFTMkksS0FBSztBQUNaeEssNEJBQVFELE1BQU15SyxHQUFHO0FBQUEsa0JBQ25CLFVBQUM7QUFDQ2lMLHdCQUFJRyxZQUFZRDtBQUNoQkYsd0JBQUlJLFdBQVc7QUFBQSxrQkFDakI7QUFBQSxnQkFDRjtBQUFBLGdCQUNBLFVBQVUsQ0FBQ3RSLGdCQUFnQjFDO0FBQUFBLGdCQUMzQixXQUFVO0FBQUEsZ0JBQTRMO0FBQUE7QUFBQSxjQWxCeE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBcUJBLEtBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsbUdBQ2IsaUNBQUMsU0FBSSxXQUFVLHlFQUdiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9IQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHNEQUNiLGlDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsd0VBQXVFLHlCQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RjtBQUFBLGtCQUM3Rix1QkFBQyxPQUFFLFdBQVUsaURBQWdEO0FBQUE7QUFBQSxxQkFDdkRoSix1QkFBdUIrRSx5QkFBeUIsR0FBR3VTLGVBQWUsT0FBTztBQUFBLHVCQUQvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxpSUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwwREFDYixpQ0FBQyxhQUFVLFdBQVUsYUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEIsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHdFQUF1RSw4QkFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0c7QUFBQSxrQkFDbEcsdUJBQUMsT0FBRSxXQUFVLGlEQUFnRDtBQUFBO0FBQUEscUJBQ3ZEdFgsdUJBQXVCb1ksNEJBQTRCLEdBQUdkLGVBQWUsT0FBTztBQUFBLHVCQURsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw0REFDYixpQ0FBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtDLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx3RUFBdUUsOEJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtHO0FBQUEsa0JBQ2xHLHVCQUFDLE9BQUUsV0FBVSxpREFBZ0Q7QUFBQTtBQUFBLHFCQUN2RHRYLHVCQUF1QmdGLHdCQUF3QixHQUFHc1MsZUFBZSxPQUFPO0FBQUEsdUJBRDlFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGlCQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlDQSxLQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFhO0FBQUE7QUFBQSxzQkFFVCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGtCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFrQztBQUFBO0FBQUE7QUFBQSxrQkFKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPNUwsZUFBZXBDO0FBQUFBLG9CQUN0QixVQUFVa1I7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDcmUsVUFBVW9nQixNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2SjtBQUFBLGdCQUU1Si9RLE9BQU9sQyxlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmtDLGlCQUFPbEMsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUYsdUJBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsT0FBRSxXQUFVLDZEQUNWakwsOEJBQW9CcU4sZ0JBQWdCcEMsV0FBVyxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFRO0FBQUE7QUFBQSxzQkFFRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPb0MsZ0JBQWdCYjtBQUFBQSxvQkFDdkIsVUFBVTJQO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3JlLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNko7QUFBQSxnQkFFNUovUSxPQUFPWCxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJXLGlCQUFPWCxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RDtBQUFBLGdCQUV6RGEsZ0JBQWdCYixVQUNmLHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLE9BQUUsV0FBVSw2REFDVnhNLDhCQUFvQnFOLGdCQUFnQmIsTUFBTSxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJCQTtBQUFBLGlCQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlEQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFpQjtBQUFBO0FBQUEsc0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT2EsZ0JBQWdCWjtBQUFBQSxvQkFDdkIsVUFBVTBQO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3JlLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNko7QUFBQSxnQkFFNUovUSxPQUFPVixtQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZVLGlCQUFPVixtQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRURZLGdCQUFnQlosbUJBQ2YsdUJBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsT0FBRSxXQUFVLDZEQUNWek0sOEJBQW9CcU4sZ0JBQWdCWixlQUFlLEtBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNkJBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWtCO0FBQUE7QUFBQSxzQkFFSjtBQUFBLHNCQUN0Qix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPWSxnQkFBZ0JYO0FBQUFBLG9CQUN2QixVQUFVeVA7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDcmUsVUFBVW9nQixNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2SjtBQUFBLGdCQUU1Si9RLE9BQU9ULG9CQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlMsaUJBQU9ULG9CQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFRFcsZ0JBQWdCWCxvQkFDZix1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxPQUFFLFdBQVUsNkRBQ1YxTSw4QkFBb0JxTixnQkFBZ0JYLGdCQUFnQixLQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQThCQTtBQUFBLGlCQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStEQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUViO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFzQjtBQUFBO0FBQUEsc0JBRVQ7QUFBQSxzQkFDckIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osTUFBSztBQUFBLG9CQUNMLE9BQU9XLGdCQUFnQlY7QUFBQUEsb0JBQ3ZCLFVBQVV3UDtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0g7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3JlLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNko7QUFBQSxnQkFFNUovUSxRQUFRUix3QkFDUCx1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZRLGtCQUFRUix3QkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRURVLGdCQUFnQlYsd0JBQ2YsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsT0FBRSxXQUFVLDZEQUNWM00sOEJBQW9CcU4sZ0JBQWdCVixvQkFBb0IsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE4QkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBaUI7QUFBQTtBQUFBLGtCQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1osT0FDR29DLE9BQU8xQixnQkFBZ0JwQyxlQUFlLENBQUMsSUFDdEM4RCxPQUFPMUIsZ0JBQWdCWixtQkFBbUIsQ0FBQyxJQUMzQ3NDLE9BQU8xQixnQkFBZ0JYLG9CQUFvQixDQUFDLEtBQU07QUFBQSxvQkFFdEQ7QUFBQSxvQkFDQSxXQUFXLHNDQUFzQzVPLFVBQVVvZ0IsTUFBTTtBQUFBO0FBQUEsa0JBWG5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXb0g7QUFBQSxnQkFFcEgsdUJBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsT0FBRSxXQUFVLDZEQUNWbGU7QUFBQUEsa0JBQXFCK08sT0FBTzFCLGdCQUFnQnBDLGVBQWUsQ0FBQyxJQUMxRDhELE9BQU8xQixnQkFBZ0JaLG1CQUFtQixDQUFDLElBQzNDc0MsT0FBTzFCLGdCQUFnQlgsb0JBQW9CLENBQUMsS0FBTTtBQUFBLGdCQUNwRCxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNEJBO0FBQUEsaUJBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0RBO0FBQUEsWUE0RUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxrQkFDbEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyxxQ0FBcUM1TyxVQUFVb2dCLE1BQU07QUFBQTtBQUFBO0FBQUEsb0JBR2hFLGFBQVk7QUFBQSxvQkFDWix1QkFBdUI7QUFBQSxvQkFDdkI7QUFBQSxvQkFFQSxRQUFRO0FBQUEsc0JBQ05rQixVQUFVO0FBQUEsd0JBQ1JDLGlCQUFpQjtBQUFBLHdCQUNqQjVCLE9BQU87QUFBQSx3QkFDUDZCLFNBQVM7QUFBQSx3QkFDVHRCLFFBQVE7QUFBQSxzQkFDVjtBQUFBLG9CQUNGO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUNMLGNBQWMsQ0FBQ0csT0FBT0MsV0FDcEJBLE9BQU8zRyxTQUNKdE8sWUFBWSxFQUNaUSxTQUFTd1UsTUFBTWhWLFlBQVksQ0FBQztBQUFBLG9CQUVqQyxPQUFPa0UsZ0JBQWdCTCxpQkFBaUJ2RjtBQUFBQSxvQkFDeEMsVUFBVSxDQUFDc0UsVUFDVG9QLHNCQUFzQixpQkFBaUJwUCxLQUFLO0FBQUEsb0JBRzdDO0FBQUEsc0JBQ0M7QUFBQSxzQkFDQTtBQUFBLHNCQUNBO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQTtBQUFBLG9CQUFRLEVBQ1IyRztBQUFBQSxzQkFBSSxDQUFDTCxZQUNMLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxTQUNqQ0EscUJBRGlCQSxTQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQXJDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBc0NBO0FBQUEsbUJBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkNBO0FBQUEsY0FDQ2hGLGVBQWVMLGtCQUFrQixjQUNoQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVU7QUFBQTtBQUFBLHNCQUVPO0FBQUEsc0JBQ3pCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFDQUFxQ2xQLFVBQVVvZ0IsTUFBTTtBQUFBLG9CQUNoRSxhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU8zRyxTQUNKNEcsU0FBUyxFQUNUbFYsWUFBWSxFQUNaUSxTQUFTd1UsTUFBTWhWLFlBQVksQ0FBQztBQUFBLG9CQUVqQyxPQUFPa0UsZ0JBQWdCUixxQkFBcUJwRjtBQUFBQSxvQkFFNUMsVUFBVSxDQUFDc0UsVUFDVG9QLHNCQUFzQixxQkFBcUJwUCxLQUFLO0FBQUEsb0JBR2pEeEwsZ0JBQU1tUztBQUFBQSxzQkFBSSxDQUFDekssU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS0ssS0FDdkNMO0FBQUFBLDZCQUFLeUM7QUFBQUEsd0JBQVU7QUFBQSx3QkFBRztBQUFBLHdCQUNsQnpDLEtBQUt5QixlQUFlekIsS0FBS3lCLGVBQWU7QUFBQSwyQkFGdkJ6QixLQUFLSyxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBd0JBO0FBQUEsbUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUNBO0FBQUEsY0FFRCtFLGVBQWVMLGtCQUFrQixXQUNoQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUN4QztBQUFBLGtCQUN0Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFDQUFxQ2xQLFVBQVVvZ0IsTUFBTTtBQUFBLG9CQUNoRSxhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUVMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU8zRyxTQUNKNEcsU0FBUyxFQUNUbFYsWUFBWSxFQUNaUSxTQUFTd1UsTUFBTWhWLFlBQVksQ0FBQztBQUFBLG9CQUVqQyxPQUFPa0UsZUFBZU4sa0JBQWtCdEY7QUFBQUEsb0JBQ3hDLFVBQVUsQ0FBQ3NFLFVBQ1RvUCxzQkFBc0Isa0JBQWtCcFAsS0FBSztBQUFBLG9CQUc5Q3RMLGlCQUFPaVM7QUFBQUEsc0JBQUksQ0FBQ1csVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTS9LLEtBQ3pDK0s7QUFBQUEsOEJBQU05SjtBQUFBQSx3QkFBSztBQUFBLHdCQUFJOEosTUFBTTNKO0FBQUFBLDJCQURKMkosTUFBTS9LLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUEsa0JBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF1QkE7QUFBQSxtQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2QkE7QUFBQSxjQUVEK0UsZUFBZUwsa0JBQWtCLGNBQ2hDLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBVTtBQUFBO0FBQUEsc0JBRU87QUFBQSxzQkFDekIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcscUNBQXFDbFAsVUFBVW9nQixNQUFNO0FBQUE7QUFBQTtBQUFBLG9CQUdoRSxhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBRUEsTUFBSztBQUFBLG9CQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FBVztBQUMvQiwwQkFBSSxDQUFDQSxVQUFVLENBQUNBLE9BQU8zRyxTQUFVLFFBQU87QUFDeEMsNkJBQU8yRyxPQUFPM0csU0FDWDRHLFNBQVMsRUFDVGxWLFlBQVksRUFDWlEsU0FBU3dVLE1BQU1oVixZQUFZLENBQUM7QUFBQSxvQkFDakM7QUFBQSxvQkFDQSxPQUFPa0UsZ0JBQWdCUCxxQkFBcUJyRjtBQUFBQSxvQkFDNUMsVUFBVSxDQUFDc0UsVUFDVG9QLHNCQUFzQixxQkFBcUJwUCxLQUFLO0FBQUEsb0JBR2pEcEwsb0JBQVUrUjtBQUFBQSxzQkFBSSxDQUFDYyxhQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUFpQyxPQUFPQSxTQUFTbEwsS0FDL0NrTDtBQUFBQSxpQ0FBU2pLO0FBQUFBLHdCQUFLO0FBQUEsd0JBQUlpSyxTQUFTOUo7QUFBQUEsMkJBRFY4SixTQUFTbEwsS0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkF6Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTBCQTtBQUFBLG1CQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1DQTtBQUFBLGlCQXJKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVKQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDBDQUViO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyxvQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxPQUFPK0UsZUFBZVQ7QUFBQUEsc0JBQ3RCLFVBQVV1UDtBQUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osV0FBVyxxQ0FBcUNyZSxVQUFVb2dCLE1BQU07QUFBQTtBQUFBLG9CQU5sRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTTZKO0FBQUEsa0JBRTdKO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFTLE1BQU0vTCxPQUFPQyxLQUFLLGdCQUFnQjtBQUFBLHNCQUUzQyxpQ0FBQyxnQkFBYSxPQUFNLFdBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJCO0FBQUE7QUFBQSxvQkFKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEscUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFlQTtBQUFBLG1CQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQ3ZELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU8vRSxlQUFlN0I7QUFBQUEsb0JBQ3RCLFVBQVUsQ0FBQ08sVUFBVW9QLHNCQUFzQixtQkFBbUJwUCxLQUFLO0FBQUEsb0JBQ25FLFdBQVcscUNBQXFDak8sVUFBVW9nQixNQUFNO0FBQUEsb0JBQ2hFLHVCQUF1QjtBQUFBLG9CQUN2QixpQkFBZ0I7QUFBQSxvQkFFZmhHLHdCQUFjeEY7QUFBQUEsc0JBQUksQ0FBQzBGLFFBQ2xCLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxJQUFJck0sT0FBTyxPQUFPcU0sSUFBSTVKLE9BQzFELGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtDQUFDLFVBQUssT0FBTyxFQUFFaVAsT0FBT3JGLElBQUlxRixNQUFNLEdBQUlyRixjQUFJdEMsUUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkM7QUFBQSx3QkFDN0MsdUJBQUMsVUFBSyxXQUFVLGVBQWVzQyxjQUFJNUosU0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUM7QUFBQSwyQkFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQSxLQUprQjRKLElBQUlyTSxPQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFlQTtBQUFBLG1CQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGlCQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFFd0Q7QUFBQTtBQUFBLGNBSnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLGVBNWtCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZrQkE7QUFBQSxhQWhtQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWltQkE7QUFBQTtBQUFBLE1Bcm1CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFzbUJBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVzVLO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCSSw2QkFBbUIsSUFBSTtBQUFBLFFBQ3pCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0QsbUJBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVUsQ0FBQ3VLLE1BQU07QUFDZkEsa0JBQUUrUCxlQUFlO0FBQ2pCTyxxQ0FBcUI7QUFBQSxjQUN2QjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVztBQUFBO0FBQUEsd0JBRU47QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2I3YSwyQkFBaUJvSixVQUFVRCxhQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUNBQXFDNU0sVUFBVW9nQixNQUFNO0FBQUE7QUFBQSxvQkFMbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUs2SjtBQUFBLHFCQWpCL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQkE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUMrRTtBQUFBO0FBQUEsa0JBSDNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBO0FBQUE7QUFBQSxZQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrQ0E7QUFBQSxhQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBO0FBQUE7QUFBQSxNQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFpREE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXamM7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNkJBQW1CLEtBQUs7QUFDeEJWLDZCQUFtQixJQUFJO0FBQUEsUUFDekI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsMkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsMERBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsY0FDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLGFBQVk7QUFBQSxnQkFDWixPQUFPVyxnQkFBZ0JzRjtBQUFBQSxnQkFDdkIsVUFBVSxDQUFDc0UsVUFBVTtBQUNuQjNKLGtDQUFnQjJKLEtBQUs7QUFDckJ6Six3Q0FBc0IsRUFBRTtBQUFBLGdCQUMxQjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFFVDtBQUFBLGtCQUNDO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGdCQUFPLEVBQ1BvUTtBQUFBQSxrQkFBSSxDQUFDdkwsV0FDTCx1QkFBQyxPQUFPLFFBQVAsRUFBMkIsT0FBT0EsUUFDaENBLG9CQURpQkEsUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF3QkE7QUFBQSxZQUNDaEYsaUJBQWlCLFdBQ2hCLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsZ0JBQy9DLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsYUFBWTtBQUFBLGtCQUNaLE9BQU9FO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3lKLE1BQU14SixzQkFBc0J3SixFQUFFRSxPQUFPRCxLQUFLO0FBQUE7QUFBQSxnQkFIdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBR3lEO0FBQUEsaUJBUDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxlQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlDQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU03SixtQkFBbUIsS0FBSztBQUFBLGdCQUN2QyxXQUFVO0FBQUEsZ0JBQTZCO0FBQUE7QUFBQSxjQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTMEw7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUFtRTtBQUFBO0FBQUEsY0FGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQTlERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0RBO0FBQUE7QUFBQSxNQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1RUE7QUFBQSxJQThRQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3JLO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLCtCQUFxQixLQUFLO0FBQzFCaEMsNkJBQW1CLElBQUk7QUFDdkJrQyw0QkFBa0IsRUFBRTtBQUNwQkUsMEJBQWdCLEVBQUU7QUFBQSxRQUNwQjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxvQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUNWckM7QUFBQUEsNkJBQWlCb0osVUFBVUQ7QUFBQUEsWUFBVTtBQUFBLFlBQVk7QUFBQSxZQUNqRG5KLGlCQUFpQm9OO0FBQUFBLGVBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUNFO0FBQUE7QUFBQSxjQUVWLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFIekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osT0FBT2xMLGtCQUFrQmdFO0FBQUFBLGdCQUN6QixVQUFVLENBQUNzRSxVQUFVckksa0JBQWtCcUksS0FBSztBQUFBLGdCQUM1QyxXQUFVO0FBQUEsZ0JBS1Y7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFdBQ25CLGlDQUFDLFVBQUssV0FBVSx1REFDZDtBQUFBLDJDQUFDLDBCQUF1QixXQUFVLHFCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRDtBQUFBLG9CQUFHO0FBQUEsdUJBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBRUEsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUNuQixpQ0FBQyxVQUFLLFdBQVUsc0RBQ2Q7QUFBQSwyQ0FBQyx1QkFBb0IsV0FBVSxvQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSxvQkFBRztBQUFBLHVCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUVBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sWUFDbkIsaUNBQUMsVUFBSyxXQUFVLHFEQUNkO0FBQUEsMkNBQUMsNkJBQTBCLFdBQVUsbUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9EO0FBQUEsb0JBQUc7QUFBQSx1QkFEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFFQSx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFlBQ25CLGlDQUFDLFVBQUssV0FBVSxvREFDZDtBQUFBLDJDQUFDLHVCQUFvQixXQUFVLGtCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QztBQUFBLG9CQUFHO0FBQUEsdUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBRUEsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUNuQixpQ0FBQyxVQUFLLFdBQVUscURBQ2Q7QUFBQSwyQ0FBQyxrQkFBZSxXQUFVLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5QztBQUFBLG9CQUFHO0FBQUEsdUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUE7QUFBQTtBQUFBLGNBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTJDQTtBQUFBLGVBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0RBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MsK0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQyxNQUFNO0FBQUEsY0FBTjtBQUFBLGdCQUNDLGFBQVk7QUFBQSxnQkFDWixPQUFPcEk7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDbUksTUFBTWxJLGdCQUFnQmtJLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxnQkFDL0MsTUFBTTtBQUFBLGdCQUNOLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS29CO0FBQUEsZUFUdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU07QUFDYnZJLHVDQUFxQixLQUFLO0FBQzFCaEMscUNBQW1CLElBQUk7QUFDdkJrQyxvQ0FBa0IsRUFBRTtBQUNwQkUsa0NBQWdCLEVBQUU7QUFBQSxnQkFDcEI7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQTZCO0FBQUE7QUFBQSxjQVB6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1tSywyQkFBMkJ0SyxjQUFjO0FBQUEsZ0JBQ3hELFdBQVU7QUFBQSxnQkFBK0Q7QUFBQTtBQUFBLGNBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQTVGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkZBO0FBQUE7QUFBQSxNQXRHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1R0E7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNMkM7QUFBQUEsUUFDTixVQUFVLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFDeEMsUUFBUTtBQUFBLFFBQ1I7QUFBQSxRQUNBLE9BQU87QUFBQSxRQUVQLGlDQUFDLFNBQUksV0FBVSxPQUdiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsb0NBQW1DLGtDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHlEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQscUNBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFFBQVEsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxnQkFDekMsYUFBWTtBQUFBLGdCQUNaLE9BQU9HLFlBQVlFO0FBQUFBLGdCQUNuQixXQUFVO0FBQUEsZ0JBQ1YsVUFBVSxDQUFDb0YsTUFDVHJGLGVBQWU7QUFBQSxrQkFDYixHQUFHRDtBQUFBQSxrQkFDSEUsdUJBQXVCb0YsRUFBRUUsT0FBT0Q7QUFBQUEsZ0JBQ2xDLENBQUM7QUFBQTtBQUFBLGNBVkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0c7QUFBQSxZQUVILHVCQUFDLE9BQUUsV0FBVSw2REFDVi9MLDhCQUFvQndHLGFBQWFFLHFCQUFxQixLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCxvQ0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsUUFBUSx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBLGdCQUN6QyxhQUFZO0FBQUEsZ0JBQ1osT0FBT0YsWUFBWUc7QUFBQUEsZ0JBQ25CLFdBQVU7QUFBQSxnQkFDVixVQUFVLENBQUNtRixNQUNUckYsZUFBZTtBQUFBLGtCQUNiLEdBQUdEO0FBQUFBLGtCQUNIRyxzQkFBc0JtRixFQUFFRSxPQUFPRDtBQUFBQSxnQkFDakMsQ0FBQztBQUFBO0FBQUEsY0FWTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXRztBQUFBLFlBRUgsdUJBQUMsT0FBRSxXQUFVLDZEQUNWL0wsOEJBQW9Cd0csYUFBYUcsb0JBQW9CLEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1OLG1CQUFtQixLQUFLO0FBQUEsZ0JBQ3ZDLFdBQVU7QUFBQSxnQkFBdUg7QUFBQTtBQUFBLGNBRm5JO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNtQztBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQXVLO0FBQUE7QUFBQSxjQUZuTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLGFBNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2RUE7QUFBQTtBQUFBLE1BcEZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXFGQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU01QjtBQUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkQyw4QkFBb0IsS0FBSztBQUN6QkUseUJBQWUsSUFBSTtBQUNuQkUsNEJBQWtCLENBQUMsRUFBRUMsUUFBUSxJQUFJQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO0FBQUEsUUFDaEQ7QUFBQSxRQUNBLFFBQVE7QUFBQSxRQUNSO0FBQUEsUUFDQSxPQUFPO0FBQUEsUUFDUCxPQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYixpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLG9DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFLEtBRDFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0YsaUNBQUMsU0FBSSxXQUFVLE9BRVpMO0FBQUFBLHlCQUNDLHVCQUFDLFNBQUksV0FBVSw2REFDYixpQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLGlEQUFnRCx3QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxjQUNyRSx1QkFBQyxPQUFFLFdBQVUsdUNBQ1ZBLHVCQUFhNkQsVUFBVUQsYUFBYTVELGFBQWF5VCxpQkFBaUIsT0FEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaURBQWdELHVCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRTtBQUFBLGNBQ3BFLHVCQUFDLE9BQUUsV0FBVSx1Q0FBdUN6VCx1QkFBYTZILFdBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlFO0FBQUEsaUJBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaURBQWdELDJCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RTtBQUFBLGNBQ3hFLHVCQUFDLE9BQUUsV0FBVSxvQ0FBbUM7QUFBQTtBQUFBLGdCQUFFN0gsYUFBYW1FO0FBQUFBLG1CQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRTtBQUFBLGlCQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLGlEQUFnRCx3QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxjQUNyRSx1QkFBQyxPQUFFLFdBQVUsa0NBQ1ZuRSx1QkFBYStILFVBQVU0TCxNQUFNLEdBQUcsRUFBRSxDQUFDLEdBQUdBLE1BQU0sR0FBRyxHQUFHOEUsUUFBUSxHQUFHbkYsS0FBSyxHQUFHLEtBQUssT0FEN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLFVBSUR0VCxhQUFhMk4sZUFBZXhMLFNBQVMsS0FDcEMsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsa0RBQWlELGdDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RTtBQUFBLFlBQzlFLHVCQUFDLFNBQUksV0FBVSxnREFDYixpQ0FBQyxXQUFNLFdBQVUsc0JBQ2Y7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsbURBQ2YsaUNBQUMsUUFDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSx1QkFBc0Isc0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsZ0JBQzFDLHVCQUFDLFFBQUcsV0FBVSx1QkFBc0Isc0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsZ0JBQzFDLHVCQUFDLFFBQUcsV0FBVSx3QkFBdUIsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDO0FBQUEsZ0JBQy9DLHVCQUFDLFFBQUcsV0FBVSx3QkFBdUIsd0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDO0FBQUEsZ0JBQzdDLHVCQUFDLFFBQUcsV0FBVSx3QkFBdUIsMkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdEO0FBQUEsbUJBTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsNEJBQ2RuQyxzQkFBWTJOLGNBQWMvQixJQUFJLENBQUM4TSxRQUFRek0sUUFBUTtBQUM5QyxzQkFBTTBNLFNBQVNELE9BQU83SyxTQUFTO0FBQy9CLHNCQUFNK0ssYUFBYUYsT0FBT3pFLGdCQUFnQjBFLFNBQVNELE9BQU90WSxTQUFTO0FBQ25FLHNCQUFNeVksZ0JBQWdCSCxPQUFPMUUsbUJBQW1CMkUsU0FBUyxJQUFJRCxPQUFPdFksU0FBU3dZO0FBQzdFLG9CQUFJRSxhQUFhO0FBQ2pCLG9CQUFJQyxjQUFjO0FBQ2xCLG9CQUFJSixRQUFRO0FBQ1ZHLCtCQUFhO0FBQ2JDLGdDQUFjO0FBQUEsZ0JBQ2hCLFdBQVdILGFBQWEsS0FBS0EsYUFBYUYsT0FBT3RZLFFBQVE7QUFDdkQwWSwrQkFBYTtBQUNiQyxnQ0FBYztBQUFBLGdCQUNoQjtBQUNBLHVCQUNFLHVCQUFDLFFBQTJCLFdBQVUscUJBQ3BDO0FBQUEseUNBQUMsUUFBRyxXQUFVLGFBQ1osaUNBQUMsVUFBSyxXQUFXLGtEQUFrREEsV0FBVyxJQUMzRUQsd0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsMkJBQTJCSixpQkFBT3JZLFVBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVEO0FBQUEsa0JBQ3ZELHVCQUFDLFFBQUcsV0FBVSxrREFBaUQ7QUFBQTtBQUFBLG9CQUMzRDRILE9BQU95USxPQUFPdFksVUFBVSxDQUFDLEVBQUUrUixlQUFlLE9BQU87QUFBQSx1QkFEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxxREFDWHlHLHVCQUFhLElBQUksSUFBSUEsV0FBV3pHLGVBQWUsT0FBTyxDQUFDLEtBQUssT0FEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxtREFDWDBHLDBCQUFnQixJQUFJLElBQUlBLGNBQWMxRyxlQUFlLE9BQU8sQ0FBQyxLQUFLLE9BRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFmT3VHLE9BQU9sWCxPQUFPeUssS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQkE7QUFBQSxjQUVKLENBQUMsS0FqQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQ0E7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSwwQ0FDZixpQ0FBQyxRQUNDO0FBQUEsdUNBQUMsUUFBRyxTQUFRLEtBQUksV0FBVSxxQkFBb0Isc0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9EO0FBQUEsZ0JBQ3BELHVCQUFDLFFBQUcsV0FBVSx3QkFBdUI7QUFBQTtBQUFBLGtCQUNqQ2pNLFlBQVkyTixjQUFjTyxPQUFPLENBQUM4SyxHQUFHeEwsTUFBTXdMLElBQUkvUSxPQUFPdUYsRUFBRXBOLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRStSLGVBQWUsT0FBTztBQUFBLHFCQURuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHdCQUF1QjtBQUFBO0FBQUEsa0JBQ2pDblMsWUFBWTJOLGNBQWNPLE9BQU8sQ0FBQzhLLEdBQUd4TCxNQUFNd0wsSUFBSS9RLE9BQU91RixFQUFFeUcsZ0JBQWdCekcsRUFBRUssT0FBT0wsRUFBRXBOLFNBQVMsRUFBRSxHQUFHLENBQUMsRUFBRStSLGVBQWUsT0FBTztBQUFBLHFCQUQ5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHdCQUF1QjtBQUFBO0FBQUEsa0JBQ2pDblMsWUFBWTJOLGNBQWNPLE9BQU8sQ0FBQzhLLEdBQUd4TCxNQUFNd0wsSUFBSS9RLE9BQU91RixFQUFFd0csbUJBQW1CeEcsRUFBRUssT0FBTyxJQUFJTCxFQUFFcE4sVUFBVW9OLEVBQUV5RyxlQUFlLEdBQUcsR0FBRyxDQUFDLEVBQUU5QixlQUFlLE9BQU87QUFBQSxxQkFEeEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkRBLEtBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkRBO0FBQUEsZUEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnRUE7QUFBQSxVQXdDRGpTLGVBQWVxTixLQUFLLENBQUFDLE1BQUtBLEVBQUVwTixNQUFNLEtBQ2hDLHVCQUFDLFNBQUksV0FBVSxxREFBb0Q7QUFBQTtBQUFBLFlBQzVDRixlQUFlZ08sT0FBTyxDQUFDOEssR0FBR3hMLE1BQU13TCxJQUFJL1EsT0FBT3VGLEVBQUVwTixVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUUrUixlQUFlLE9BQU87QUFBQSxlQUQzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFZRix1QkFBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTtBQUNicFMsb0NBQW9CLEtBQUs7QUFDekJFLCtCQUFlLElBQUk7QUFDbkJFLGtDQUFrQixDQUFDLEVBQUVDLFFBQVEsSUFBSUMsUUFBUSxHQUFHLENBQUMsQ0FBQztBQUFBLGNBQ2hEO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBd0Y7QUFBQTtBQUFBLFlBTnBHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQXhLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUtBO0FBQUE7QUFBQSxNQXpMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUEwTEE7QUFBQSxPQW4xRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW8xRUEsS0FyMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzMUVBO0FBRUo7QUFBRTlHLEdBcHZJSUQsTUFBSTtBQUFBLFVBQ1NwQyxhQTZCRnhCLEtBQUt3SCxPQUFPO0FBQUE7QUFBQStiLEtBOUJ2QjNmO0FBcXZJTixlQUFlQTtBQUFLLElBQUEyZjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiU2lkZWJhciIsIk1vZGFsIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJJbnB1dCIsIlNlbGVjdCIsIkFudE1vZGFsIiwiRHJvcGRvd24iLCJUYWJzIiwiRHJhd2VyIiwiTWVudSIsIkJ1dHRvbiIsIm1lc3NhZ2UiLCJGb3JtIiwiRGF0ZVBpY2tlciIsIlBvcGNvbmZpcm0iLCJQb3BvdmVyIiwiVG9vbHRpcCIsIklvTWRNb3JlIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiRmFDYWxjdWxhdG9yIiwiRmFDYWxlbmRhckFsdCIsIkZhQ2hlY2tDaXJjbGUiLCJGYUVkaXQiLCJGYUV5ZSIsIkZhRmxhZ0NoZWNrZXJlZCIsIkZhSG91cmdsYXNzSGFsZiIsIkZhUXVlc3Rpb25DaXJjbGUiLCJGYVJlZ0VkaXQiLCJGYVRodW1ic1VwIiwiRmFUaW1lc0NpcmNsZSIsIkZhVXNlciIsIkZhVXNlclRpZSIsIkNpcmN1bGFyTG9hZGVyIiwiZmllbGRTaXplIiwiTGluayIsInVzZU5hdmlnYXRlIiwiTG9hblJlcXVlc3RQcmludCIsImpzUERGIiwiaW1hZ2VJbnB1dCIsIkFpT3V0bGluZUxvYWRpbmczUXVhcnRlcnMiLCJWaWV3Q3VzdG9tZXJUcmFuc2FjdGlvbnMiLCJNb3JlT3V0bGluZWQiLCJVc2VyT3V0bGluZWQiLCJDaGVja0NpcmNsZU91dGxpbmVkIiwiRWRpdE91dGxpbmVkIiwiQ2xvc2VPdXRsaW5lZCIsIkRvbGxhck91dGxpbmVkIiwiQ2FsZW5kYXJPdXRsaW5lZCIsIkNsb2NrQ2lyY2xlT3V0bGluZWQiLCJDbG9zZUNpcmNsZU91dGxpbmVkIiwiVHJvcGh5T3V0bGluZWQiLCJTdG9wT3V0bGluZWQiLCJFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIiwiRGVsZXRlT3V0bGluZWQiLCJTZWFyY2hPdXRsaW5lZCIsIkluZm9DaXJjbGVPdXRsaW5lZCIsIm1vbWVudCIsInNob3dDb25maXJtIiwiRmlQaG9uZSIsIkZpRmlsZVRleHQiLCJGaUNsb2NrIiwiRmlFeWUiLCJGaVNldHRpbmdzIiwiRmlVc2VyIiwiRmlVc2VyUGx1cyIsIkZhUnVwZWVTaWduIiwiUXVlc3Rpb25DaXJjbGVPdXRsaW5lZCIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJSaUFycm93UmlnaHRGaWxsIiwiQnJlYWRjcnVtYiIsIkJpUnVwZWUiLCJMb2FuIiwiX3MiLCJuYXZpZ2F0ZSIsInVzZXJzIiwic2V0VXNlcnMiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJib3Jyb3dlcnMiLCJzZXRCb3Jyb3dlcnMiLCJ0YWJsZUJvcnJvd2VycyIsInNldFRhYmxlQm9ycm93ZXJzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudEJvcnJvd2VyIiwic2V0Q3VycmVudEJvcnJvd2VyIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJjdXJyZW50VXBkYXRlQm9ycm93ZXIiLCJzZXRDdXJyZW50VXBkYXRlQm9ycm93ZXIiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNob3dSZW1vdmVNb2RhbCIsInNldFNob3dSZW1vdmVNb2RhbCIsInJlbW92ZVJlYXNvbiIsInNldFJlbW92ZVJlYXNvbiIsImN1c3RvbVJlbW92ZVJlYXNvbiIsInNldEN1c3RvbVJlbW92ZVJlYXNvbiIsImJ1dHRvbkxvYWRpbmciLCJzZXRCdXR0b25Mb2FkaW5nIiwic2hvd1RyYW5zYWN0aW9ucyIsInNldFNob3dUcmFuc2FjdGlvbnMiLCJzZWxlY3RlZEN1c3RvbWVyIiwic2V0U2VsZWN0ZWRDdXN0b21lciIsInNlbGVjdGVkTG9hbiIsInNldFNlbGVjdGVkTG9hbiIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImlzQWNjZXB0TW9kYWxPcGVuIiwic2V0SXNBY2NlcHRNb2RhbE9wZW4iLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImZldGNoRXJyb3IiLCJzZXRGZXRjaEVycm9yIiwic2hvd0FwcHJvdmFsTW9kYWwiLCJzZXRTaG93QXBwcm92YWxNb2RhbCIsImFwcHJvdmFsU3RhdHVzIiwic2V0QXBwcm92YWxTdGF0dXMiLCJhcHByb3ZhbE5vdGUiLCJzZXRBcHByb3ZhbE5vdGUiLCJzZWxlY3RlZFVzZXIiLCJzZXRTZWxlY3RlZFVzZXIiLCJmb3JtIiwidXNlRm9ybSIsInRvdGFscyIsInNldFRvdGFscyIsInRvdGFsUmVxdWVzdHMiLCJ0b3RhbEFjY2VwdGVkIiwidG90YWxQZW5kaW5nIiwidG90YWxBcHByb3ZlZCIsInRvdGFsUmVqZWN0ZWQiLCJ0b3RhbENvbXBsZXRlZCIsInRvdGFsQ2xvc2VkIiwidG90YWxVbmtub3duIiwiT1JERVJFRF9TVEFUVVNFUyIsImlzTG9hblVwZGF0ZWQiLCJzZXRJc0xvYW5VcGRhdGVkIiwic3VtbWFyeURhdGEiLCJzZXRTdW1tYXJ5RGF0YSIsInN1bW1hcnlMb2FkaW5nIiwic2V0U3VtbWFyeUxvYWRpbmciLCJhbGxMb2FucyIsInNldEFsbExvYW5zIiwicmVxdWVzdHMiLCJhY2NlcHRlZCIsInBlbmRpbmciLCJhcHByb3ZlZCIsInJlamVjdGVkIiwiY29tcGxldGVkIiwiY2xvc2VkIiwidW5rbm93biIsImFsbExvYW5zTG9hZGVkIiwic2V0QWxsTG9hbnNMb2FkZWQiLCJnbG9iYWxTZWFyY2hSZXN1bHRzIiwic2V0R2xvYmFsU2VhcmNoUmVzdWx0cyIsImdsb2JhbFNlYXJjaFRlcm0iLCJzZXRHbG9iYWxTZWFyY2hUZXJtIiwiZ2xvYmFsU2VhcmNoVGFyZ2V0VGFiIiwic2V0R2xvYmFsU2VhcmNoVGFyZ2V0VGFiIiwiaXNMb2FuTW9kYWxPcGVuIiwic2V0SXNMb2FuTW9kYWxPcGVuIiwic2VhcmNoSW5wdXQiLCJzZXRTZWFyY2hJbnB1dCIsImxvYW5BbW91bnRzIiwic2V0TG9hbkFtb3VudHMiLCJyZXF1ZXN0ZWRfbG9hbl9hbW91bnQiLCJhcHByb3ZlZF9sb2FuX2Ftb3VudCIsInNob3dQZW5hbHR5TW9kYWwiLCJzZXRTaG93UGVuYWx0eU1vZGFsIiwicGVuYWx0eUxvYW4iLCJzZXRQZW5hbHR5TG9hbiIsInBlbmFsdHlDaGFyZ2VzIiwic2V0UGVuYWx0eUNoYXJnZXMiLCJhbW91bnQiLCJyZWFzb24iLCJwZW5hbHR5TG9hZGluZyIsInNldFBlbmFsdHlMb2FkaW5nIiwibG9hZGluZ0N1c3RvbWVySWQiLCJzZXRMb2FkaW5nQ3VzdG9tZXJJZCIsImZvcm1hdEluZGlhbkN1cnJlbmN5IiwidW5kZWZpbmVkIiwiSW50bCIsIk51bWJlckZvcm1hdCIsInN0eWxlIiwiY3VycmVuY3kiLCJtYXhpbXVtRnJhY3Rpb25EaWdpdHMiLCJmb3JtYXQiLCJnZXRBZG1pbklkIiwidXNlciIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJfaWQiLCJpZCIsImhhbmRsZVN1Ym1pdExvYW5BbW91bnRzIiwicGF5bG9hZCIsInVwZGF0ZWRfYnkiLCJwdXQiLCJzdWNjZXNzIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIiwicHJldiIsImxlbmd0aCIsInRlcm0iLCJ0b0xvd2VyQ2FzZSIsIm1hdGNoZWQiLCJmaWx0ZXIiLCJyb3ciLCJuYW1lIiwiX3NlYXJjaE5hbWUiLCJwaG9uZSIsInBob25lX251bWJlciIsImluY2x1ZGVzIiwiaGFuZGxlU2VhcmNoIiwidHJpbW1lZCIsInRyaW0iLCJ0ZXJtTG93ZXIiLCJmb3VuZExvYW4iLCJmb3VuZFN0YXR1c0tleSIsInN0YXR1c0tleSIsImxvYW5zIiwiT2JqZWN0IiwiZW50cmllcyIsIm1hdGNoIiwiZmluZCIsImxvYW4iLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwiYm9ycm93ZXIiLCJ0YWJNYXAiLCJyZXF1ZXN0ZWQiLCJ0YXJnZXRUYWIiLCJhbGVydCIsImhhbmRsZU9wZW5Mb2FuTW9kYWwiLCJsb2FuX2Ftb3VudCIsInVwZGF0ZUxvYW5TdGF0dXMiLCJuZXdTdGF0dXMiLCJ0aXRsZSIsImNvbnRlbnQiLCJvbkNvbmZpcm0iLCJwYXRjaCIsImFwcHJvdmFsX3N0YXR1cyIsInBvc3QiLCJsb2FuSWQiLCJzdGF0dXMiLCJoZWFkZXJzIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJ0eXBlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImFwcGxpZWRfb24iLCJ0ZW51cmUiLCJzZXJ2aWNlX2NoYXJnZXMiLCJkb2N1bWVudF9jaGFyZ2VzIiwiZGFpbHlfcGF5bWVudF9hbW91bnQiLCJub3RlIiwicmVmZXJyZWRfY3VzdG9tZXIiLCJyZWZlcnJlZF9lbXBsb3llZSIsInJlZmVycmVkX2FnZW50IiwicmVmZXJyZWRfdHlwZSIsImFnZW50X2FwcHJvdmFsX3N0YXR1cyIsInNvdXJjZSIsImVycm9ycyIsInNldEVycm9ycyIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJoYW5kbGVSZW1vdmVNb2RhbE9wZW4iLCJib3Jyb3dlcklkIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiaGFuZGxlUmVtb3ZlQm9ycm93ZXIiLCJyZW1vdmFsX3JlYXNvbiIsImhhbmRsZUFwcHJvdmFsTW9kYWxPcGVuIiwiaGFuZGxlVXBkYXRlQXBwcm92YWxTdGF0dXMiLCJnZW5lcmF0ZUFuZE9wZW5QREYiLCJkb3dubG9hZE9ubHkiLCJsb2FuRGF0YSIsImNvbG9ycyIsInByaW1hcnkiLCJ0ZXh0TWFpbiIsInNlY3Rpb25zIiwiZmllbGRzIiwibGFiZWwiLCJlbWFpbCIsImFkZHJlc3MiLCJsb2FuX2lkIiwic3RhcnRfZGF0ZSIsImVuZF9kYXRlIiwibG9hbl9zYW5jdGlvbl9kYXRlIiwiTnVtYmVyIiwiZG9jIiwic2FmZVRleHQiLCJ2IiwiU3RyaW5nIiwieSIsImFkZEltYWdlIiwic2V0Rm9udCIsInNldEZvbnRTaXplIiwidmFsdWVXaWR0aCIsImdldFRleHRXaWR0aCIsImxhYmVsV2lkdGgiLCJnYXAiLCJzdGFydFgiLCJ0ZXh0IiwiYWxpZ24iLCJzZXRUZXh0Q29sb3IiLCJzZXRGaWxsQ29sb3IiLCJyZWN0IiwiZHJhd0ZpZWxkIiwieCIsImJveFdpZHRoIiwidmFsdWVTdHIiLCJsaW5lcyIsInNwbGl0VGV4dFRvU2l6ZSIsImxpbmVIZWlnaHQiLCJ0ZXh0SGVpZ2h0IiwiYm94SGVpZ2h0IiwiTWF0aCIsIm1heCIsInNldERyYXdDb2xvciIsInRleHRZIiwiZm9yRWFjaCIsImxpbmUiLCJzZWMiLCJpIiwibGVmdEZpZWxkIiwicmlnaHRGaWVsZCIsInN0YXJ0WSIsImxlZnRZIiwicmlnaHRZIiwicGFnZUhlaWdodCIsImludGVybmFsIiwicGFnZVNpemUiLCJnZXRIZWlnaHQiLCJmb290ZXJZIiwic2F2ZSIsInBkZkJsb2IiLCJvdXRwdXQiLCJwZGZVcmwiLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJ3aW5kb3ciLCJvcGVuIiwicmVmVHlwZSIsInJlZmVycmFsX3R5cGUiLCJmZXRjaEFsbExvYW5zIiwic3RhdHVzZXMiLCJwcm9taXNlcyIsIm1hcCIsInJlc3BvbnNlcyIsIlByb21pc2UiLCJhbGwiLCJyZXN1bHQiLCJpZHgiLCJrZXkiLCJjbG9zZWRSZXMiLCJmZXRjaEN1c3RvbWVycyIsIkVycm9yIiwiZmV0Y2hBZ2VudHMiLCJhZ2VudCIsImVyciIsImZldGNoRW1wbG95ZWVzIiwiZW1wbG95ZWUiLCJoYW5kbGVQcmludCIsImxvYW5QcmludElkIiwicmVzIiwiaGFuZGxlUGVuYWx0eU1vZGFsT3BlbiIsImhhbmRsZUFkZFBlbmFsdHlSb3ciLCJoYW5kbGVSZW1vdmVQZW5hbHR5Um93IiwiaW5kZXgiLCJfIiwiaGFuZGxlUGVuYWx0eUNoYW5nZSIsImZpZWxkIiwiaGFuZGxlUGVuYWx0eVN1Ym1pdCIsImludmFsaWQiLCJzb21lIiwiYyIsIndhcm5pbmciLCJleGlzdGluZ0NoYXJnZXMiLCJleHRyYV9jaGFyZ2VzIiwibmV3Q2hhcmdlcyIsInBhaWQiLCJmZXRjaExvYW5Db3VudHMiLCJyZXF1ZXN0c1JlcyIsImNsb3NlZExvYW5zUmVzIiwiZm9ybWF0dGVkIiwicmVkdWNlIiwiYWNjIiwiaXRlbSIsImNvdW50IiwiUkVRVUVTVEVEIiwiQUNDRVBURUQiLCJQRU5ESU5HIiwiQVBQUk9WRUQiLCJSRUpFQ1RFRCIsIkNPTVBMRVRFRCIsIlVOS05PV04iLCJnZXRTdGF0dXNPcHRpb25zRm9yVGFiIiwidGFiIiwiY29tbW9uT3B0aW9ucyIsImljb24iLCJjbGFzc05hbWUiLCJvcHRpb25zTWFwIiwia2V5cyIsImZldGNoQm9ycm93ZXJzIiwicm91dGVNYXAiLCJyb3V0ZSIsImFwaURhdGEiLCJ0YWJsZURhdGEiLCJzbGljZSIsInNvcnQiLCJhIiwiYiIsIkRhdGUiLCJjcmVhdGVkQXQiLCJnZXRGb3JtYXR0ZWRMb2FuSWQiLCJvcmlnaW5hbExvYW5JZCIsImN1cnJlbnRUYWIiLCJudW1iZXJQYXJ0IiwidGFic1dpdGhSUUxOIiwicHJlZml4IiwiZm9ybWF0dGVkRGF0YSIsImdldFVzZXJJZCIsImJ1aWxkUmVmZXJyZWRCeSIsImxvYW5JdGVtIiwiYm9ycm93ZXJEYXRhIiwicmVuZGVyQ2VsbCIsImNoaWxkcmVuIiwiZ2V0UmVmZXJyZWREYXRhIiwicm9vdFJlZiIsImJvcnJvd2VyUmVmIiwiY3VzdG9tZXIiLCJlbXBDb2RlIiwiZW1wbG95ZWVDb2RlIiwidW5pcXVlX2NvZGUiLCJmYWxsYmFja0VtcGxveWVlIiwic3RhdHVzT3B0aW9ucyIsInBvcG92ZXJDb250ZW50Iiwib3B0IiwiYWN0aW9uRHJvcGRvd24iLCJpdGVtcyIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsInVzZXJJZCIsImhhbmRsZVZpZXdUcmFuc2FjdGlvbnMiLCJvbkNsaWNrIiwiYWdlbnRTdGF0dXMiLCJhZ2VudEJhZGdlIiwiYXBwcm92ZWREYXRlIiwiYWdlbnRfYXBwcm92YWxfc3RhdHVzX3VwZGF0ZWRfYXQiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJhcHByb3ZlZEFtb3VudCIsInRvTG9jYWxlU3RyaW5nIiwicmVtYXJrIiwiZW1wbG95ZWVfcmVtYXJrIiwiYm9ycm93ZXJVc2VySWQiLCJ0b29sdGlwQ29udGVudCIsImN1c3RvbWVyTmFtZSIsInN0b3BQcm9wYWdhdGlvbiIsImhpZGUiLCJMb2FuQW1vdW50IiwiYWRtaW5BcHByb3ZlZCIsImFwcHJvdmVkX2xvYW5fYW1vdW50X3N0YXR1cyIsImN1c3RvbWVyX25hbWUiLCJyZWZlcnJlZF9ieSIsImFkbWluX2FwcHJvdmVkX2Ftb3VudCIsImVtcGxveWVlX2FwcHJvdmVkX2Ftb3VudCIsImxvYW5fcHVycG9zZSIsImNyZWF0ZWRCeSIsImNyZWF0ZWRfYnkiLCJCb29sZWFuIiwiam9pbiIsImFjdGlvbiIsImFkbWluX25hbWUiLCJib3Jyb3dlcl9uYW1lIiwiZGF0ZSIsInNwbGl0IiwiZXh0cmFfY2hhcmdlc19kaXNwbGF5IiwiY2hhcmdlcyIsInRvdGFsT3V0c3RhbmRpbmciLCJzdW0iLCJiYWxhbmNlX2Ftb3VudCIsInBhaWRfYW1vdW50IiwiaGFuZGxlQW50RFNlbGVjdCIsInByZXZEYXRhIiwicHJldkVycm9ycyIsImhhbmRsZUFudElucHV0RFNlbGVjdCIsImhhbmRsZUNoYW5nZSIsInVwZGF0ZWRGb3JtIiwic2FuY3Rpb25EYXRlIiwic3RhcnREYXRlIiwidmFsaWRhdGVGb3JtIiwibmV3RXJyb3JzIiwiaXNOYU4iLCJ0b0ZpeGVkIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiZm9ybWF0dGVkU3RhcnREYXRlIiwiZm9ybWF0dGVkRW5kRGF0ZSIsImZvcm1hdHRlZFNhbmN0aW9uRGF0ZSIsImhhbmRsZUlucHV0Q2hhbmdlIiwiaGFuZGxlRGVsZXRlQm9ycm93ZXIiLCJkZWxldGUiLCJoYW5kbGVVcGRhdGUiLCJyZXF1ZXN0Q29sdW1ucyIsImhlYWRlciIsIndpZHRoIiwidW5rbm93bkNvbHVtbnMiLCJvdGhlckNvbHVtbnMiLCJjb2x1bW5zIiwiY29sIiwiTm9EYXRhRm91bmQiLCJUQUJfQ09ORklHIiwiYmdDb2xvciIsImNvdW50S2V5IiwidGFiSXRlbXMiLCJpc0RhdGFSZWFkeSIsImFsbG93VXBkYXRlIiwidXBkYXRlSGFuZGxlciIsImN1c3RvbWVySWQiLCJyZXNvbHZlIiwic2V0VGltZW91dCIsImNvbG9yIiwiaGFuZGxlQXBwcm92YWxTdGF0dXNDaGFuZ2UiLCJmb3VuZCIsInRvdGFsQW1vdW50IiwidG90YWxfYW1vdW50Iiwic3RhdHVzQ29uZmlnIiwiYmciLCJib3JkZXIiLCJjb25maWciLCJoZWlnaHQiLCJpbnB1dCIsIm9wdGlvbiIsInRvU3RyaW5nIiwiY3VzdG9tZXJfaWQiLCJidG4iLCJjdXJyZW50VGFyZ2V0Iiwib3JpZ2luYWxUZXh0IiwiaW5uZXJIVE1MIiwiZGlzYWJsZWQiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsImRheSIsIm1vbnRoIiwieWVhciIsImhvdXIiLCJtaW51dGUiLCJyZWZlcnJlZF9ieV9uYW1lIiwic2VsZWN0b3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJvcGFjaXR5IiwicmV2ZXJzZSIsImNoYXJnZSIsImlzUGFpZCIsInBhaWRBbW91bnQiLCJiYWxhbmNlQW1vdW50Iiwic3RhdHVzVGV4dCIsInN0YXR1c0NvbG9yIiwicyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxvYW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgSW5wdXQsIFNlbGVjdCwgTW9kYWwgYXMgQW50TW9kYWwsIERyb3Bkb3duLCBUYWJzLCBEcmF3ZXIsIE1lbnUsIEJ1dHRvbiwgbWVzc2FnZSwgRm9ybSwgRGF0ZVBpY2tlciwgUG9wY29uZmlybSwgUG9wb3ZlciwgVG9vbHRpcCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHsgRmFDYWxjdWxhdG9yLCBGYUNhbGVuZGFyQWx0LCBGYUNoZWNrQ2lyY2xlLCBGYUVkaXQsIEZhRXllLCBGYUZsYWdDaGVja2VyZWQsIEZhSG91cmdsYXNzSGFsZiwgRmFRdWVzdGlvbkNpcmNsZSwgRmFSZWdFZGl0LCBGYVRodW1ic1VwLCBGYVRpbWVzQ2lyY2xlLCBGYVVzZXIsIEZhVXNlclRpZSB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTG9hblJlcXVlc3RQcmludCBmcm9tIFwiLi4vY29tcG9uZW50cy9wcmludEZvcm1hdHMvTG9hblJlcXVlc3RQcmludFwiO1xyXG5pbXBvcnQganNQREYgZnJvbSBcImpzcGRmXCI7XHJcbmltcG9ydCBpbWFnZUlucHV0IGZyb20gXCIuLi9hc3NldHMvaW1hZ2VzL0FnZW50LnBuZ1wiO1xyXG5pbXBvcnQgeyBBaU91dGxpbmVMb2FkaW5nM1F1YXJ0ZXJzIH0gZnJvbSBcInJlYWN0LWljb25zL2FpXCI7XHJcbmltcG9ydCBWaWV3Q3VzdG9tZXJUcmFuc2FjdGlvbnMgZnJvbSBcIi4vVmlld0N1c3RvbWVyVHJhbnNhY3Rpb25zXCI7XHJcbmltcG9ydCB7XHJcbiAgTW9yZU91dGxpbmVkLFxyXG4gIFVzZXJPdXRsaW5lZCxcclxuICBDaGVja0NpcmNsZU91dGxpbmVkLFxyXG4gIEVkaXRPdXRsaW5lZCxcclxuICBDbG9zZU91dGxpbmVkLFxyXG4gIERvbGxhck91dGxpbmVkLFxyXG4gIENhbGVuZGFyT3V0bGluZWQsXHJcbiAgQ2xvY2tDaXJjbGVPdXRsaW5lZCxcclxuICBDbG9zZUNpcmNsZU91dGxpbmVkLFxyXG4gIFRyb3BoeU91dGxpbmVkLFxyXG4gIFN0b3BPdXRsaW5lZCxcclxuICBFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkLFxyXG4gIERlbGV0ZU91dGxpbmVkLFxyXG4gIFNlYXJjaE91dGxpbmVkLFxyXG4gIEluZm9DaXJjbGVPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IG1vbWVudCBmcm9tIFwibW9tZW50XCI7XHJcbmltcG9ydCB7IHNob3dDb25maXJtIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL1Nob3dDb25maXJtXCI7XHJcbmltcG9ydCB7IEZpUGhvbmUsIEZpRmlsZVRleHQsIEZpQ2xvY2ssIEZpRXllLCBGaVNldHRpbmdzLCBGaVVzZXIsIEZpVXNlclBsdXMgfSBmcm9tICdyZWFjdC1pY29ucy9maSc7XHJcbmltcG9ydCB7IEZhUnVwZWVTaWduIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IFF1ZXN0aW9uQ2lyY2xlT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuaW1wb3J0IHsgUmlBcnJvd1JpZ2h0RmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9yaVwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcbmltcG9ydCB7IEJpUnVwZWUgfSBmcm9tIFwicmVhY3QtaWNvbnMvYmlcIjtcclxuXHJcbmNvbnN0IExvYW4gPSAoKSA9PiB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYm9ycm93ZXJzLCBzZXRCb3Jyb3dlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZUJvcnJvd2Vycywgc2V0VGFibGVCb3Jyb3dlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Qm9ycm93ZXIsIHNldEN1cnJlbnRCb3Jyb3dlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUJvcnJvd2VyLCBzZXRDdXJyZW50VXBkYXRlQm9ycm93ZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd1JlbW92ZU1vZGFsLCBzZXRTaG93UmVtb3ZlTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtyZW1vdmVSZWFzb24sIHNldFJlbW92ZVJlYXNvbl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY3VzdG9tUmVtb3ZlUmVhc29uLCBzZXRDdXN0b21SZW1vdmVSZWFzb25dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2J1dHRvbkxvYWRpbmcsIHNldEJ1dHRvbkxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93VHJhbnNhY3Rpb25zLCBzZXRTaG93VHJhbnNhY3Rpb25zXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRDdXN0b21lciwgc2V0U2VsZWN0ZWRDdXN0b21lcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRMb2FuLCBzZXRTZWxlY3RlZExvYW5dID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwicmVxdWVzdHNcIik7XHJcbiAgY29uc3QgW2lzQWNjZXB0TW9kYWxPcGVuLCBzZXRJc0FjY2VwdE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtmZXRjaEVycm9yLCBzZXRGZXRjaEVycm9yXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd0FwcHJvdmFsTW9kYWwsIHNldFNob3dBcHByb3ZhbE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYXBwcm92YWxTdGF0dXMsIHNldEFwcHJvdmFsU3RhdHVzXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthcHByb3ZhbE5vdGUsIHNldEFwcHJvdmFsTm90ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRVc2VyLCBzZXRTZWxlY3RlZFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2Zvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcbiAgY29uc3QgW3RvdGFscywgc2V0VG90YWxzXSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsUmVxdWVzdHM6IDAsXHJcbiAgICB0b3RhbEFjY2VwdGVkOiAwLFxyXG4gICAgdG90YWxQZW5kaW5nOiAwLFxyXG4gICAgdG90YWxBcHByb3ZlZDogMCxcclxuICAgIHRvdGFsUmVqZWN0ZWQ6IDAsXHJcbiAgICB0b3RhbENvbXBsZXRlZDogMCxcclxuICAgIHRvdGFsQ2xvc2VkOiAwLFxyXG4gICAgdG90YWxVbmtub3duOiAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IE9SREVSRURfU1RBVFVTRVMgPSBbXHJcbiAgICBcIlJFUVVFU1RFRFwiLFxyXG4gICAgXCJBQ0NFUFRFRFwiLFxyXG4gICAgXCJQRU5ESU5HXCIsXHJcbiAgICBcIkFQUFJPVkVEXCIsXHJcbiAgICBcIlVOS05PV05cIixcclxuICAgIFwiUkVKRUNURURcIixcclxuICAgIFwiQ09NUExFVEVEXCJcclxuICBdO1xyXG4gIGNvbnN0IFtpc0xvYW5VcGRhdGVkLCBzZXRJc0xvYW5VcGRhdGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAvLyBBZGQgdGhlc2UgbGluZXMgd2l0aCB5b3VyIG90aGVyIHVzZVN0YXRlIGRlY2xhcmF0aW9uc1xyXG4gIGNvbnN0IFtzdW1tYXJ5RGF0YSwgc2V0U3VtbWFyeURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzdW1tYXJ5TG9hZGluZywgc2V0U3VtbWFyeUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbYWxsTG9hbnMsIHNldEFsbExvYW5zXSA9IHVzZVN0YXRlKHtcclxuICAgIHJlcXVlc3RzOiBbXSwgYWNjZXB0ZWQ6IFtdLCBwZW5kaW5nOiBbXSwgYXBwcm92ZWQ6IFtdLFxyXG4gICAgcmVqZWN0ZWQ6IFtdLCBjb21wbGV0ZWQ6IFtdLCBjbG9zZWQ6IFtdLCB1bmtub3duOiBbXVxyXG4gIH0pO1xyXG4gIGNvbnN0IFthbGxMb2Fuc0xvYWRlZCwgc2V0QWxsTG9hbnNMb2FkZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtnbG9iYWxTZWFyY2hSZXN1bHRzLCBzZXRHbG9iYWxTZWFyY2hSZXN1bHRzXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtnbG9iYWxTZWFyY2hUZXJtLCBzZXRHbG9iYWxTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtnbG9iYWxTZWFyY2hUYXJnZXRUYWIsIHNldEdsb2JhbFNlYXJjaFRhcmdldFRhYl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNMb2FuTW9kYWxPcGVuLCBzZXRJc0xvYW5Nb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hJbnB1dCwgc2V0U2VhcmNoSW5wdXRdID0gdXNlU3RhdGUoJycpO1xyXG5cclxuICBjb25zdCBbbG9hbkFtb3VudHMsIHNldExvYW5BbW91bnRzXSA9IHVzZVN0YXRlKHtcclxuICAgIHJlcXVlc3RlZF9sb2FuX2Ftb3VudDogXCJcIixcclxuICAgIGFwcHJvdmVkX2xvYW5fYW1vdW50OiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICAvLyBhZGQgcGVuYWx0eSBzdGF0ZXNcclxuICBjb25zdCBbc2hvd1BlbmFsdHlNb2RhbCwgc2V0U2hvd1BlbmFsdHlNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3BlbmFsdHlMb2FuLCBzZXRQZW5hbHR5TG9hbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcGVuYWx0eUNoYXJnZXMsIHNldFBlbmFsdHlDaGFyZ2VzXSA9IHVzZVN0YXRlKFtcclxuICAgIHsgYW1vdW50OiBcIlwiLCByZWFzb246IFwiXCIgfVxyXG4gIF0pO1xyXG4gIGNvbnN0IFtwZW5hbHR5TG9hZGluZywgc2V0UGVuYWx0eUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsb2FkaW5nQ3VzdG9tZXJJZCwgc2V0TG9hZGluZ0N1c3RvbWVySWRdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIC8vIC0tLSBIZWxwZXI6IGZvcm1hdCBJbmRpYW4gY3VycmVuY3kgKGlmIG5lZWRlZCBlbHNld2hlcmUpIC0tLVxyXG4gIGNvbnN0IGZvcm1hdEluZGlhbkN1cnJlbmN5ID0gKGFtb3VudCkgPT4ge1xyXG4gICAgaWYgKGFtb3VudCA9PT0gdW5kZWZpbmVkIHx8IGFtb3VudCA9PT0gbnVsbCkgcmV0dXJuICfigrkwJztcclxuICAgIHJldHVybiBuZXcgSW50bC5OdW1iZXJGb3JtYXQoJ2VuLUlOJywge1xyXG4gICAgICBzdHlsZTogJ2N1cnJlbmN5JyxcclxuICAgICAgY3VycmVuY3k6ICdJTlInLFxyXG4gICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDAsXHJcbiAgICB9KS5mb3JtYXQoYW1vdW50KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRBZG1pbklkID0gKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpKTsgLy8gYWRqdXN0IGtleSBpZiBkaWZmZXJlbnRcclxuICAgICAgcmV0dXJuIHVzZXI/Ll9pZCB8fCB1c2VyPy5pZCB8fCBudWxsO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC8vIEhlbHBlciB0byBmb3JtYXQgYSBzaW5nbGUgbG9hbiBvYmplY3QgZm9yIGEgZ2l2ZW4gdGFiXHJcbiAgLy8gY29uc3QgZm9ybWF0TG9hbkZvclRhYiA9IChsb2FuLCB0YWIpID0+IHtcclxuICAvLyAgIGNvbnN0IGJ1aWxkUmVmZXJyZWRCeSA9IChib3Jyb3dlcikgPT4ge1xyXG4gIC8vICAgICBjb25zdCByZWZUeXBlID0gYm9ycm93ZXI/LnVzZXJfaWQ/LnJlZmVycmFsX3R5cGUgfHwgYm9ycm93ZXI/LnJlZmVycmVkX3R5cGU7XHJcbiAgLy8gICAgIGlmIChyZWZUeXBlID09PSBcIkFnZW50XCIpIHtcclxuICAvLyAgICAgICBjb25zdCBhZ2VudCA9IGJvcnJvd2VyPy51c2VyX2lkPy5yZWZlcnJlZF9hZ2VudCB8fCBib3Jyb3dlcj8ucmVmZXJyZWRfYWdlbnQ7XHJcbiAgLy8gICAgICAgcmV0dXJuIGFnZW50Py5uYW1lID8gYEFnZW50IC0gJHthZ2VudC5uYW1lfSAoJHthZ2VudC5waG9uZV9udW1iZXIgfHwgXCItXCJ9KWAgOiBcIkFnZW50IC0gTi9BXCI7XHJcbiAgLy8gICAgIH0gZWxzZSBpZiAocmVmVHlwZSA9PT0gXCJDdXN0b21lclwiKSB7XHJcbiAgLy8gICAgICAgY29uc3QgY3VzdG9tZXIgPSBib3Jyb3dlcj8udXNlcl9pZD8ucmVmZXJyZWRfY3VzdG9tZXIgfHwgYm9ycm93ZXI/LnJlZmVycmVkX2N1c3RvbWVyO1xyXG4gIC8vICAgICAgIHJldHVybiBjdXN0b21lcj8uZnVsbF9uYW1lID8gYEN1c3RvbWVyIC0gJHtjdXN0b21lci5mdWxsX25hbWV9ICgke2N1c3RvbWVyLnBob25lX251bWJlciB8fCBcIi1cIn0pYCA6IFwiQ3VzdG9tZXIgLSBOL0FcIjtcclxuICAvLyAgICAgfSBlbHNlIGlmIChyZWZUeXBlID09PSBcIkVtcGxveWVlXCIpIHtcclxuICAvLyAgICAgICBjb25zdCBlbXBsb3llZSA9IGJvcnJvd2VyPy51c2VyX2lkPy5yZWZlcnJlZF9lbXBsb3llZSB8fCBib3Jyb3dlcj8ucmVmZXJyZWRfZW1wbG95ZWU7XHJcbiAgLy8gICAgICAgcmV0dXJuIGVtcGxveWVlPy5uYW1lID8gYEVtcGxveWVlIC0gJHtlbXBsb3llZS5uYW1lfSAoJHtlbXBsb3llZS5waG9uZV9udW1iZXIgfHwgXCItXCJ9KWAgOiBcIkVtcGxveWVlIC0gTi9BXCI7XHJcbiAgLy8gICAgIH0gZWxzZSBpZiAocmVmVHlwZSA9PT0gXCJTZWxmIEpvaW5pbmdcIikge1xyXG4gIC8vICAgICAgIHJldHVybiBcIlNlbGYgSm9pbmluZ1wiO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICAgIHJldHVybiBcIk4vQVwiO1xyXG4gIC8vICAgfTtcclxuXHJcbiAgLy8gICBpZiAodGFiID09PSBcInJlcXVlc3RzXCIpIHtcclxuICAvLyAgICAgY29uc3QgaXNBZ2VudEFwcHJvdmVkID0gbG9hbj8uYWdlbnRfYXBwcm92YWxfc3RhdHVzID09PSBcIkFQUFJPVkVEXCI7XHJcbiAgLy8gICAgIGNvbnN0IGN1c3RvbWVyTmFtZSA9IChcclxuICAvLyAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBncm91cFwiPlxyXG4gIC8vICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgLy8gICAgICAgICAgIHtsb2FuPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgbG9hbj8udXNlcj8uZnVsbF9uYW1lIHx8IGxvYW4/LmJvcnJvd2VyPy5mdWxsX25hbWUgfHwgXCJVbmtub3duXCJ9XHJcbiAgLy8gICAgICAgICA8L3NwYW4+XHJcbiAgLy8gICAgICAgICB7aXNBZ2VudEFwcHJvdmVkID8gKFxyXG4gIC8vICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTUwMCB0by10ZWFsLTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy1zbVwiPlxyXG4gIC8vICAgICAgICAgICAgIDxGYVRodW1ic1VwIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPiBBZ2VudCBBcHByb3ZlZFxyXG4gIC8vICAgICAgICAgICA8L3NwYW4+XHJcbiAgLy8gICAgICAgICApIDogKFxyXG4gIC8vICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXhzIGZvbnQtYm9sZCBweC0xLjUgcHktMSByb3VuZGVkLWZ1bGwgc2hhZG93LXNtICR7bG9hbj8udXNlcl9pZD8ucmVmZXJyYWxfdHlwZSA9PT0gXCJTZWxmIEpvaW5pbmdcIlxyXG4gIC8vICAgICAgICAgICAgID8gXCJiZy1lbWVyYWxkLTEwMCB0ZXh0LWVtZXJhbGQtNzAwIHJpbmctMSByaW5nLWVtZXJhbGQtMjAwXCJcclxuICAvLyAgICAgICAgICAgICA6IFwiYmctc2xhdGUtMTAwIHRleHQtdmlvbGV0LTgwMCByaW5nLTEgcmluZy1zbGF0ZS0yMDBcIlxyXG4gIC8vICAgICAgICAgICAgIH1gfT5cclxuICAvLyAgICAgICAgICAgICB7bG9hbj8udXNlcl9pZD8ucmVmZXJyYWxfdHlwZSA9PT0gXCJTZWxmIEpvaW5pbmdcIiA/IFwiTmV3XCIgOiBcIkV4aXN0aW5nXCJ9XHJcbiAgLy8gICAgICAgICAgIDwvc3Bhbj5cclxuICAvLyAgICAgICAgICl9XHJcbiAgLy8gICAgICAgPC9zcGFuPlxyXG4gIC8vICAgICApO1xyXG4gIC8vICAgICByZXR1cm4ge1xyXG4gIC8vICAgICAgIF9pZDogbG9hbi5faWQsXHJcbiAgLy8gICAgICAgaWQ6IDEsXHJcbiAgLy8gICAgICAgbG9hbklkOiBsb2FuLl9pZCxcclxuICAvLyAgICAgICBjdXN0b21lcl9uYW1lOiBjdXN0b21lck5hbWUsXHJcbiAgLy8gICAgICAgcGhvbmVfbnVtYmVyOiBsb2FuPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgbG9hbj8uYm9ycm93ZXI/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAvLyAgICAgICByZWZlcnJlZF9ieTogYnVpbGRSZWZlcnJlZEJ5KGxvYW4pLFxyXG4gIC8vICAgICAgIGFkZHJlc3M6IGxvYW4/LnVzZXJfaWQ/LmFkZHJlc3MgfHwgXCItXCIsXHJcbiAgLy8gICAgICAgbG9hbl9hbW91bnQ6IGxvYW4/LmxvYW5fYW1vdW50LFxyXG4gIC8vICAgICAgIGxvYW5fcHVycG9zZTogbG9hbj8ubG9hbl9wdXJwb3NlLFxyXG4gIC8vICAgICAgIGNyZWF0ZWRBdDogbG9hbj8uY3JlYXRlZEF0ID8gbmV3IERhdGUobG9hbi5jcmVhdGVkQXQpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIpIDogXCItXCIsXHJcbiAgLy8gICAgICAgYXBwcm92YWxfc3RhdHVzOiA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcHgtMyBweS0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC15ZWxsb3ctODAwIGJnLXllbGxvdy0xMDAgcm91bmRlZC1mdWxsXCI+UmVxdWVzdGVkPC9zcGFuPixcclxuICAvLyAgICAgICBhY3Rpb246IDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj4uLi48L2Rpdj4sIC8vIE9wdGlvbmFsIOKAkyB5b3UgY2FuIGNvcHkgdGhlIGZ1bGwgYWN0aW9uIGRyb3Bkb3duIGlmIG5lZWRlZFxyXG4gIC8vICAgICB9O1xyXG4gIC8vICAgfVxyXG5cclxuICAvLyAgIGlmICh0YWIgPT09IFwidW5rbm93blwiKSB7XHJcbiAgLy8gICAgIHJldHVybiB7XHJcbiAgLy8gICAgICAgaWQ6IDEsXHJcbiAgLy8gICAgICAgbG9hbklkOiBsb2FuLl9pZCxcclxuICAvLyAgICAgICBmdWxsX25hbWU6IGxvYW4/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBsb2FuPy5ib3Jyb3dlcj8uZnVsbF9uYW1lIHx8IFwiVW5rbm93blwiLFxyXG4gIC8vICAgICAgIHBob25lX251bWJlcjogbG9hbj8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IGxvYW4/LmJvcnJvd2VyPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgLy8gICAgICAgYWRkcmVzczogbG9hbj8udXNlcl9pZD8uYWRkcmVzcyB8fCBsb2FuPy5ib3Jyb3dlcj8uYWRkcmVzcyB8fCBcIi1cIixcclxuICAvLyAgICAgICBsb2FuX2Ftb3VudDogbG9hbj8ubG9hbl9hbW91bnQsXHJcbiAgLy8gICAgICAgbG9hbl9wdXJwb3NlOiBsb2FuPy5sb2FuX3B1cnBvc2UsXHJcbiAgLy8gICAgICAgY3JlYXRlZEF0OiBsb2FuPy5jcmVhdGVkQXQgPyBuZXcgRGF0ZShsb2FuLmNyZWF0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tSU5cIikgOiBcIi1cIixcclxuICAvLyAgICAgICBhY3Rpb246IDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj4uLi48L2Rpdj4sXHJcbiAgLy8gICAgIH07XHJcbiAgLy8gICB9XHJcblxyXG4gIC8vICAgLy8gRm9yIG90aGVyIHRhYnMgKGFjY2VwdGVkLCBwZW5kaW5nLCBhcHByb3ZlZCwgcmVqZWN0ZWQsIGNvbXBsZXRlZCwgY2xvc2VkKVxyXG4gIC8vICAgcmV0dXJuIHtcclxuICAvLyAgICAgX2lkOiBsb2FuLl9pZCxcclxuICAvLyAgICAgaWQ6IDEsXHJcbiAgLy8gICAgIGxvYW5faWQ6IGxvYW4ubG9hbl9pZCB8fCBsb2FuLl9pZCxcclxuICAvLyAgICAgYm9ycm93ZXJfbmFtZTogbG9hbi51c2VyX2lkPy5mdWxsX25hbWUgfHwgbG9hbi51c2VyPy5mdWxsX25hbWUgfHwgbG9hbi5ib3Jyb3dlcj8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgLy8gICAgIGRhdGU6IGxvYW4/LmNyZWF0ZWRBdCxcclxuICAvLyAgICAgbG9hbl9hbW91bnQ6IGxvYW4/LmxvYW5fYW1vdW50LFxyXG4gIC8vICAgICB0ZW51cmU6IGxvYW4/LnRlbnVyZSxcclxuICAvLyAgICAgc2VydmljZV9jaGFyZ2VzOiBsb2FuPy5zZXJ2aWNlX2NoYXJnZXMsXHJcbiAgLy8gICAgIGxvYW5fc2FuY3Rpb25fZGF0ZTogbG9hbj8ubG9hbl9zYW5jdGlvbl9kYXRlPy5zcGxpdChcIlRcIilbMF0sXHJcbiAgLy8gICAgIGRvY3VtZW50X2NoYXJnZXM6IGxvYW4/LmRvY3VtZW50X2NoYXJnZXMsXHJcbiAgLy8gICAgIGRhaWx5X3BheW1lbnRfYW1vdW50OiBsb2FuPy5kYWlseV9wYXltZW50X2Ftb3VudCxcclxuICAvLyAgICAgc3RhcnRfZGF0ZTogbG9hbj8uc3RhcnRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gIC8vICAgICBlbmRfZGF0ZTogbG9hbj8uZW5kX2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAvLyAgICAgbm90ZTogbG9hbj8ubm90ZSxcclxuICAvLyAgICAgcmVmZXJyZWRfdHlwZTogbG9hbj8ucmVmZXJyZWRfdHlwZSxcclxuICAvLyAgICAgYXBwcm92YWxfc3RhdHVzOiBsb2FuPy5hcHByb3ZhbF9zdGF0dXMgfHwgXCJQRU5ESU5HXCIsXHJcbiAgLy8gICAgIHJlZmVycmVkX2J5OiBidWlsZFJlZmVycmVkQnkobG9hbiksXHJcbiAgLy8gICAgIGFjdGlvbjogPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPi4uLjwvZGl2PixcclxuICAvLyAgIH07XHJcbiAgLy8gfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0TG9hbkFtb3VudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIGFwcHJvdmVkX2xvYW5fYW1vdW50OiBsb2FuQW1vdW50cy5hcHByb3ZlZF9sb2FuX2Ftb3VudCxcclxuICAgICAgICB1cGRhdGVkX2J5OiBnZXRBZG1pbklkKCksXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhd2FpdCBhcGkucHV0KGAvdjEvYWRtaW4vbG9hbnMvYXBwcm92ZWQtYW1vdW50LyR7c2VsZWN0ZWRMb2FuPy5faWR9YCwgcGF5bG9hZCk7XHJcblxyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJMb2FuIGFtb3VudHMgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcblxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBsb2FuIGFtb3VudHNcIik7XHJcbiAgICB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FuTW9kYWxPcGVuKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEFkZCB0aGlzIGVmZmVjdCB0byBhcHBseSBzZWFyY2ggZmlsdGVyIGFmdGVyIHRhYiBkYXRhIGxvYWRzXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChnbG9iYWxTZWFyY2hUZXJtICYmIGdsb2JhbFNlYXJjaFRhcmdldFRhYiA9PT0gYWN0aXZlVGFiICYmIHRhYmxlQm9ycm93ZXJzLmxlbmd0aCA+IDApIHtcclxuICAgICAgY29uc3QgdGVybSA9IGdsb2JhbFNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKTtcclxuICAgICAgY29uc3QgbWF0Y2hlZCA9IHRhYmxlQm9ycm93ZXJzLmZpbHRlcihyb3cgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5hbWUgPSAocm93Ll9zZWFyY2hOYW1lIHx8IFwiXCIpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgY29uc3QgcGhvbmUgPSAocm93LnBob25lX251bWJlciB8fCBcIlwiKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIHJldHVybiBuYW1lLmluY2x1ZGVzKHRlcm0pIHx8IHBob25lLmluY2x1ZGVzKHRlcm0pO1xyXG4gICAgICB9KTtcclxuICAgICAgaWYgKG1hdGNoZWQubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNldEdsb2JhbFNlYXJjaFJlc3VsdHMobWF0Y2hlZCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gSWYgbm8gbWF0Y2hlcyAoc2hvdWxkbid0IGhhcHBlbiBpZiBsb2FuIGZvdW5kKSwgc2hvdyBlbXB0eVxyXG4gICAgICAgIHNldEdsb2JhbFNlYXJjaFJlc3VsdHMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSwgW3RhYmxlQm9ycm93ZXJzLCBnbG9iYWxTZWFyY2hUZXJtLCBnbG9iYWxTZWFyY2hUYXJnZXRUYWIsIGFjdGl2ZVRhYl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWFyY2ggPSAodGVybSkgPT4ge1xyXG4gICAgY29uc3QgdHJpbW1lZCA9IHRlcm0udHJpbSgpO1xyXG4gICAgaWYgKCF0cmltbWVkKSB7XHJcbiAgICAgIC8vIENsZWFyIHNlYXJjaFxyXG4gICAgICBzZXRHbG9iYWxTZWFyY2hUZXJtKCcnKTtcclxuICAgICAgc2V0R2xvYmFsU2VhcmNoUmVzdWx0cyhudWxsKTtcclxuICAgICAgc2V0R2xvYmFsU2VhcmNoVGFyZ2V0VGFiKG51bGwpO1xyXG4gICAgICBzZXRTZWFyY2hJbnB1dCgnJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB0ZXJtTG93ZXIgPSB0cmltbWVkLnRvTG93ZXJDYXNlKCk7XHJcbiAgICBsZXQgZm91bmRMb2FuID0gbnVsbDtcclxuICAgIGxldCBmb3VuZFN0YXR1c0tleSA9IG51bGw7XHJcblxyXG4gICAgZm9yIChjb25zdCBbc3RhdHVzS2V5LCBsb2Fuc10gb2YgT2JqZWN0LmVudHJpZXMoYWxsTG9hbnMpKSB7XHJcbiAgICAgIGNvbnN0IG1hdGNoID0gbG9hbnMuZmluZChsb2FuID0+IHtcclxuICAgICAgICBjb25zdCBuYW1lID0gKGxvYW4udXNlcl9pZD8uZnVsbF9uYW1lIHx8IGxvYW4uYm9ycm93ZXI/LmZ1bGxfbmFtZSB8fCBsb2FuLnVzZXI/LmZ1bGxfbmFtZSB8fCBcIlwiKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIGNvbnN0IHBob25lID0gKGxvYW4udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IGxvYW4uYm9ycm93ZXI/LnBob25lX251bWJlciB8fCBsb2FuLnVzZXI/LnBob25lX251bWJlciB8fCBcIlwiKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIHJldHVybiBuYW1lLmluY2x1ZGVzKHRlcm1Mb3dlcikgfHwgcGhvbmUuaW5jbHVkZXModGVybUxvd2VyKTtcclxuICAgICAgfSk7XHJcbiAgICAgIGlmIChtYXRjaCkge1xyXG4gICAgICAgIGZvdW5kTG9hbiA9IG1hdGNoO1xyXG4gICAgICAgIGZvdW5kU3RhdHVzS2V5ID0gc3RhdHVzS2V5O1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGZvdW5kTG9hbiAmJiBmb3VuZFN0YXR1c0tleSkge1xyXG4gICAgICBjb25zdCB0YWJNYXAgPSB7XHJcbiAgICAgICAgcmVxdWVzdGVkOiBcInJlcXVlc3RzXCIsXHJcbiAgICAgICAgYWNjZXB0ZWQ6IFwiYWNjZXB0ZWRcIixcclxuICAgICAgICBwZW5kaW5nOiBcInBlbmRpbmdcIixcclxuICAgICAgICBhcHByb3ZlZDogXCJhcHByb3ZlZFwiLFxyXG4gICAgICAgIHJlamVjdGVkOiBcInJlamVjdGVkXCIsXHJcbiAgICAgICAgY29tcGxldGVkOiBcImNvbXBsZXRlZFwiLFxyXG4gICAgICAgIGNsb3NlZDogXCJjbG9zZWRcIixcclxuICAgICAgICB1bmtub3duOiBcInVua25vd25cIixcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgdGFyZ2V0VGFiID0gdGFiTWFwW2ZvdW5kU3RhdHVzS2V5XSB8fCBmb3VuZFN0YXR1c0tleTtcclxuICAgICAgc2V0QWN0aXZlVGFiKHRhcmdldFRhYik7XHJcbiAgICAgIHNldEdsb2JhbFNlYXJjaFRhcmdldFRhYih0YXJnZXRUYWIpO1xyXG4gICAgICBzZXRHbG9iYWxTZWFyY2hUZXJtKHRyaW1tZWQpO1xyXG4gICAgICAvLyBSZXNldCByZXN1bHRzIOKAkyB0aGUgdXNlRWZmZWN0IHdpbGwgcG9wdWxhdGUgYWZ0ZXIgZGF0YSBsb2Fkc1xyXG4gICAgICBzZXRHbG9iYWxTZWFyY2hSZXN1bHRzKG51bGwpO1xyXG4gICAgICAvLyBLZWVwIHNlYXJjaElucHV0IGZvciBkaXNwbGF5XHJcbiAgICAgIHNldFNlYXJjaElucHV0KHRyaW1tZWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgLy8gTm8gbWF0Y2ggZm91bmRcclxuICAgICAgc2V0R2xvYmFsU2VhcmNoUmVzdWx0cyhbXSk7XHJcbiAgICAgIHNldEdsb2JhbFNlYXJjaFRhcmdldFRhYihudWxsKTtcclxuICAgICAgc2V0R2xvYmFsU2VhcmNoVGVybSh0cmltbWVkKTtcclxuICAgICAgYWxlcnQoXCJObyB1c2VyIGZvdW5kIHdpdGggdGhhdCBuYW1lIG9yIHBob25lIG51bWJlclwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPcGVuTG9hbk1vZGFsID0gKGxvYW4pID0+IHtcclxuICAgIHNldFNlbGVjdGVkTG9hbihsb2FuKTtcclxuXHJcbiAgICBzZXRMb2FuQW1vdW50cyh7XHJcbiAgICAgIHJlcXVlc3RlZF9sb2FuX2Ftb3VudDogbG9hbj8ubG9hbl9hbW91bnQgfHwgXCJcIixcclxuICAgICAgYXBwcm92ZWRfbG9hbl9hbW91bnQ6IGxvYW4/LmFwcHJvdmVkX2xvYW5fYW1vdW50IHx8IFwiXCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRJc0xvYW5Nb2RhbE9wZW4odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gLS0tIENvbW1vbiBmdW5jdGlvbiB0byB1cGRhdGUgbG9hbiBzdGF0dXMgKHVuaWZpZWQpIC0tLVxyXG4gIGNvbnN0IHVwZGF0ZUxvYW5TdGF0dXMgPSBhc3luYyAobG9hbiwgbmV3U3RhdHVzKSA9PiB7XHJcblxyXG4gICAgc2hvd0NvbmZpcm0oe1xyXG4gICAgICB0aXRsZTogYCR7bmV3U3RhdHVzfSBMb2FuIFJlcXVlc3RgLFxyXG4gICAgICBjb250ZW50OiBgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGNoYW5nZSB0aGUgc3RhdHVzIG9mIHRoaXMgbG9hbiB0byAke25ld1N0YXR1c30/YCxcclxuICAgICAgb25Db25maXJtOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIC8vIFVwZGF0ZSBsb2FuIGFwcHJvdmFsIHN0YXR1c1xyXG4gICAgICAgICAgYXdhaXQgYXBpLnBhdGNoKFwiL3YxL2FkbWluL2xvYW5zL2FwcHJvdmFsLXN0YXR1c1wiLCB7XHJcbiAgICAgICAgICAgIGlkOiBsb2FuLl9pZCxcclxuICAgICAgICAgICAgYXBwcm92YWxfc3RhdHVzOiBuZXdTdGF0dXMsXHJcbiAgICAgICAgICAgIHVwZGF0ZWRfYnk6IGdldEFkbWluSWQoKSxcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIC8vIElmIGFwcHJvdmVkLCBjcmVhdGUvdXBkYXRlIGxvYW4gZG9jdW1lbnRcclxuICAgICAgICAgIGlmIChuZXdTdGF0dXMgPT09IFwiQVBQUk9WRURcIikge1xyXG4gICAgICAgICAgICBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICAgICAgICBcIi92MS9hZG1pbi9sb2FuLWRvY3VtZW50c1wiLFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGxvYW5JZDogbG9hbi5faWQsXHJcbiAgICAgICAgICAgICAgICBzdGF0dXM6IFwiUGVuZGluZ1wiLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhgTG9hbiBzdGF0dXMgdXBkYXRlZCB0byAke25ld1N0YXR1c30gc3VjY2Vzc2Z1bGx5YCk7XHJcbiAgICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBsb2FuIHN0YXR1czpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgbG9hbiBzdGF0dXNcIik7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBib3Jyb3dlcjogXCJcIixcclxuICAgIGxvYW5fYW1vdW50OiBcIlwiLFxyXG4gICAgYXBwbGllZF9vbjogXCJcIixcclxuICAgIHRlbnVyZTogXCJcIixcclxuICAgIHNlcnZpY2VfY2hhcmdlczogXCJcIixcclxuICAgIGRvY3VtZW50X2NoYXJnZXM6IFwiXCIsXHJcbiAgICBkYWlseV9wYXltZW50X2Ftb3VudDogXCJcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAgIHJlZmVycmVkX2VtcGxveWVlOiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfYWdlbnQ6IFwiXCIsXHJcbiAgICByZWZlcnJlZF90eXBlOiBcIlwiLFxyXG4gICAgYWdlbnRfYXBwcm92YWxfc3RhdHVzOiBcImFwcHJvdmVkXCIsXHJcbiAgICBhcHByb3ZhbF9zdGF0dXM6IFwiYXBwcm92ZWRcIixcclxuICAgIHNvdXJjZTogXCJDaGl0LUFkbWluXCJcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGJvcnJvd2VyOiBcIlwiLFxyXG4gICAgbG9hbl9hbW91bnQ6IFwiXCIsXHJcbiAgICBhcHBsaWVkX29uOiBcIlwiLFxyXG4gICAgdGVudXJlOiBcIlwiLFxyXG4gICAgc2VydmljZV9jaGFyZ2VzOiBcIlwiLFxyXG4gICAgZG9jdW1lbnRfY2hhcmdlczogXCJcIixcclxuICAgIGRhaWx5X3BheW1lbnRfYW1vdW50OiBcIlwiLFxyXG4gICAgbm90ZTogXCJcIixcclxuICAgIHJlZmVycmVkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfZW1wbG95ZWU6IFwiXCIsXHJcbiAgICByZWZlcnJlZF9hZ2VudDogXCJcIixcclxuICAgIHJlZmVycmVkX3R5cGU6IFwiXCIsXHJcbiAgICBhcHByb3ZhbF9zdGF0dXM6IFwiQVBQUk9WRURcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVtb3ZlTW9kYWxPcGVuID0gYXN5bmMgKGJvcnJvd2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2xvYW5zL2dldC1ib3Jyb3dlci8ke2JvcnJvd2VySWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRCb3Jyb3dlcihyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0UmVtb3ZlUmVhc29uKFwiXCIpO1xyXG4gICAgICBzZXRTaG93UmVtb3ZlTW9kYWwodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYm9ycm93ZXI6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gZmV0Y2ggYm9ycm93ZXIgZGV0YWlsc1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVtb3ZlQm9ycm93ZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoXHJcbiAgICAgICFyZW1vdmVSZWFzb24gfHxcclxuICAgICAgKHJlbW92ZVJlYXNvbiA9PT0gXCJPdGhlclwiICYmICFjdXN0b21SZW1vdmVSZWFzb24udHJpbSgpKVxyXG4gICAgKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhbmQgc3BlY2lmeSByZW1vdmFsIHJlYXNvblwiLFxyXG4gICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnBhdGNoKGAvbG9hbnMvJHtjdXJyZW50Qm9ycm93ZXIuX2lkfS9yZW1vdmVgLCB7XHJcbiAgICAgICAgcmVtb3ZhbF9yZWFzb246XHJcbiAgICAgICAgICByZW1vdmVSZWFzb24gPT09IFwiT3RoZXJcIiA/IGN1c3RvbVJlbW92ZVJlYXNvbiA6IHJlbW92ZVJlYXNvbixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiTG9hbiByZW1vdmVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0U2hvd1JlbW92ZU1vZGFsKGZhbHNlKTtcclxuICAgICAgc2V0UmVtb3ZlUmVhc29uKFwiXCIpO1xyXG4gICAgICBzZXRDdXN0b21SZW1vdmVSZWFzb24oXCJcIik7XHJcbiAgICAgIHNldEN1cnJlbnRCb3Jyb3dlcihudWxsKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHJlbW92aW5nIGxvYW46XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gcmVtb3ZlIGxvYW5cIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFwcHJvdmFsTW9kYWxPcGVuID0gYXN5bmMgKGJvcnJvd2VySWQsIHN0YXR1cykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vbG9hbnMvJHtib3Jyb3dlcklkfWApO1xyXG4gICAgICBzZXRDdXJyZW50Qm9ycm93ZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldEFwcHJvdmFsU3RhdHVzKHN0YXR1cyk7XHJcbiAgICAgIHNldEFwcHJvdmFsTm90ZShcIlwiKTtcclxuICAgICAgc2V0U2hvd0FwcHJvdmFsTW9kYWwodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYm9ycm93ZXI6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gZmV0Y2ggYm9ycm93ZXIgZGV0YWlsc1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlQXBwcm92YWxTdGF0dXMgPSBhc3luYyAoYXBwcm92YWxTdGF0dXMpID0+IHtcclxuICAgIGNvbnN0IGxvYW5JZCA9IGlzTG9hblVwZGF0ZWQgPyBjdXJyZW50VXBkYXRlQm9ycm93ZXI/LmRhdGE/Ll9pZCA6IGN1cnJlbnRCb3Jyb3dlcj8uZGF0YT8uX2lkO1xyXG5cclxuICAgIGlmICghYXBwcm92YWxTdGF0dXMpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGFuIGFwcHJvdmFsIHN0YXR1c1wiLFxyXG4gICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnBhdGNoKGAvdjEvYWRtaW4vbG9hbnMvYXBwcm92YWwtc3RhdHVzYCwge1xyXG4gICAgICAgIGlkOiBsb2FuSWQsIGFwcHJvdmFsX3N0YXR1czogYXBwcm92YWxTdGF0dXMsXHJcbiAgICAgICAgdXBkYXRlZF9ieTogZ2V0QWRtaW5JZCgpLFxyXG4gICAgICB9KTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiTG9hbiByZXF1ZXN0IHN0YXR1cyBjaGFuZ2VkIHRvIEFwcHJvdmVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogYExvYW4gc3RhdHVzIHVwZGF0ZWQgdG8gJHthcHByb3ZhbFN0YXR1c31gLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgaWYgKGlzTG9hblVwZGF0ZWQpIHtcclxuICAgICAgICBzZXRJc0xvYW5VcGRhdGVkKGZhbHNlKTtcclxuICAgICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgfVxyXG4gICAgICBzZXRTaG93QXBwcm92YWxNb2RhbChmYWxzZSk7XHJcbiAgICAgIHNldEFwcHJvdmFsU3RhdHVzKFwiXCIpO1xyXG4gICAgICBzZXRBcHByb3ZhbE5vdGUoXCJcIik7XHJcbiAgICAgIHNldEN1cnJlbnRCb3Jyb3dlcihudWxsKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGFwcHJvdmFsIHN0YXR1czpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byB1cGRhdGUgYXBwcm92YWwgc3RhdHVzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBnZW5lcmF0ZUFuZE9wZW5QREYgPSAoZG93bmxvYWRPbmx5ID0gZmFsc2UsIGxvYW5EYXRhKSA9PiB7XHJcbiAgICBjb25zdCBjb2xvcnMgPSB7XHJcbiAgICAgIHByaW1hcnk6IFswLCAzOCwgMTI0XSxcclxuICAgICAgdGV4dE1haW46IFszMywgMzMsIDMzXSxcclxuICAgIH07XHJcbiAgICBjb25zdCBzZWN0aW9ucyA9IFtcclxuICAgICAge1xyXG4gICAgICAgIHRpdGxlOiBcIkNVU1RPTUVSIERFVEFJTFNcIixcclxuICAgICAgICBmaWVsZHM6IFtcclxuICAgICAgICAgIHsgbGFiZWw6IFwiRnVsbCBOYW1lXCIsIHZhbHVlOiBsb2FuRGF0YT8uYm9ycm93ZXI/LmZ1bGxfbmFtZSB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogXCJQaG9uZSBOdW1iZXJcIiwgdmFsdWU6IGxvYW5EYXRhPy5ib3Jyb3dlcj8ucGhvbmVfbnVtYmVyIH0sXHJcbiAgICAgICAgICB7IGxhYmVsOiBcIkVtYWlsIEFkZHJlc3NcIiwgdmFsdWU6IGxvYW5EYXRhPy5ib3Jyb3dlcj8uZW1haWwgfSxcclxuICAgICAgICAgIHsgbGFiZWw6IFwiQWRkcmVzc1wiLCB2YWx1ZTogbG9hbkRhdGE/LmJvcnJvd2VyPy5hZGRyZXNzIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIHRpdGxlOiBcIkxPQU4gU1VNTUFSWVwiLFxyXG4gICAgICAgIGZpZWxkczogW1xyXG4gICAgICAgICAgeyBsYWJlbDogXCJMb2FuIElEXCIsIHZhbHVlOiBsb2FuRGF0YT8ubG9hbl9pZCB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogXCJMb2FuIEFtb3VudFwiLCB2YWx1ZTogbG9hbkRhdGE/LmxvYW5fYW1vdW50IH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIlN0YXJ0IERhdGVcIixcclxuICAgICAgICAgICAgdmFsdWU6IGxvYW5EYXRhPy5zdGFydF9kYXRlXHJcbiAgICAgICAgICAgICAgPyBtb21lbnQobG9hbkRhdGEuc3RhcnRfZGF0ZSkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKVxyXG4gICAgICAgICAgICAgIDogXCJOL0FcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHsgbGFiZWw6IFwiU2VydmljZSBDaGFyZ2VzXCIsIHZhbHVlOiBsb2FuRGF0YT8uc2VydmljZV9jaGFyZ2VzIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIkVuZCBEYXRlXCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBsb2FuRGF0YT8uZW5kX2RhdGVcclxuICAgICAgICAgICAgICA/IG1vbWVudChsb2FuRGF0YS5lbmRfZGF0ZSkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKVxyXG4gICAgICAgICAgICAgIDogXCJOL0FcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHsgbGFiZWw6IFwiRG9jdW1lbnRhdGlvbiBDaGFyZ2VzXCIsIHZhbHVlOiBsb2FuRGF0YT8uZG9jdW1lbnRfY2hhcmdlcyB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBsYWJlbDogXCJTYW5jdGlvbiBEYXRlXCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBsb2FuRGF0YT8ubG9hbl9zYW5jdGlvbl9kYXRlXHJcbiAgICAgICAgICAgICAgPyBtb21lbnQobG9hbkRhdGEubG9hbl9zYW5jdGlvbl9kYXRlKS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpXHJcbiAgICAgICAgICAgICAgOiBcIk4vQVwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogXCJEYWlseSBQYXltZW50XCIsIHZhbHVlOiBsb2FuRGF0YT8uZGFpbHlfcGF5bWVudF9hbW91bnQgfSxcclxuICAgICAgICAgIHsgbGFiZWw6IFwiVGVudXJlIChEYXlzKVwiLCB2YWx1ZTogbG9hbkRhdGE/LnRlbnVyZSB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBsYWJlbDogXCJEaXNidXJzZW1lbnQgQW1vdW50XCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiAoXHJcbiAgICAgICAgICAgICAgKE51bWJlcihsb2FuRGF0YT8ubG9hbl9hbW91bnQpIHx8IDApIC1cclxuICAgICAgICAgICAgICAoTnVtYmVyKGxvYW5EYXRhPy5zZXJ2aWNlX2NoYXJnZXMpIHx8IDApIC1cclxuICAgICAgICAgICAgICAoTnVtYmVyKGxvYW5EYXRhPy5kb2N1bWVudF9jaGFyZ2VzKSB8fCAwKVxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgdGl0bGU6IFwiUkVGRVJSQUwgSU5GT1JNQVRJT05cIixcclxuICAgICAgICBmaWVsZHM6IFtcclxuICAgICAgICAgIHsgbGFiZWw6IFwiUmVmZXJyZWQgVHlwZVwiLCB2YWx1ZTogbG9hbkRhdGE/LnJlZmVycmVkX3R5cGUgfSxcclxuICAgICAgICAgIHsgbGFiZWw6IFwiUmVmZXJyZWQgQnlcIiwgdmFsdWU6IGxvYW5EYXRhPy5yZWZlcnJlZF9lbXBsb3llZT8ubmFtZSB8fCBsb2FuRGF0YT8ucmVmZXJyZWRfYWdlbnQ/Lm5hbWUgfHwgbG9hbkRhdGE/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgfHwgXCJOL0FcIiB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgIH0sXHJcbiAgICBdO1xyXG5cclxuICAgIGNvbnN0IGRvYyA9IG5ldyBqc1BERihcInBcIiwgXCJtbVwiLCBcImE0XCIpO1xyXG4gICAgY29uc3Qgc2FmZVRleHQgPSAodikgPT4gKHYgPyBTdHJpbmcodikgOiBcIk4vQVwiKTtcclxuICAgIGxldCB5ID0gNjU7XHJcblxyXG4gICAgLy8gTG9nb1xyXG4gICAgaWYgKGltYWdlSW5wdXQpIHtcclxuICAgICAgZG9jLmFkZEltYWdlKGltYWdlSW5wdXQsIFwiUE5HXCIsIDkwLCA4LCAzMCwgMzApO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIExvYW4gSUQgKHRvcCByaWdodCwgbGFyZ2VyIGZvbnQpXHJcbiAgICBjb25zdCBsb2FuSWQgPSBsb2FuRGF0YT8ubG9hbl9pZCB8fCBcIk4vQVwiO1xyXG4gICAgZG9jLnNldEZvbnQoXCJoZWx2ZXRpY2FcIiwgXCJib2xkXCIpO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDE2KTtcclxuICAgIGNvbnN0IHZhbHVlV2lkdGggPSBkb2MuZ2V0VGV4dFdpZHRoKGxvYW5JZCk7XHJcbiAgICBkb2Muc2V0Rm9udChcImhlbHZldGljYVwiLCBcIm5vcm1hbFwiKTtcclxuICAgIGRvYy5zZXRGb250U2l6ZSg5KTtcclxuICAgIGNvbnN0IGxhYmVsV2lkdGggPSBkb2MuZ2V0VGV4dFdpZHRoKFwiTG9hbiBJRDogXCIpO1xyXG4gICAgY29uc3QgZ2FwID0gNDsgLy8gc21hbGwgZ2FwIGJldHdlZW4gbGFiZWwgYW5kIHZhbHVlXHJcbiAgICBjb25zdCBzdGFydFggPSAxOTUgLSB2YWx1ZVdpZHRoIC0gZ2FwIC0gbGFiZWxXaWR0aDtcclxuICAgIGRvYy50ZXh0KFwiTG9hbiBJRDogXCIsIHN0YXJ0WCwgMjAsIHsgYWxpZ246IFwibGVmdFwiIH0pO1xyXG4gICAgZG9jLnNldEZvbnQoXCJoZWx2ZXRpY2FcIiwgXCJib2xkXCIpO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDE2KTtcclxuICAgIGRvYy5zZXRUZXh0Q29sb3IoLi4uY29sb3JzLnByaW1hcnkpO1xyXG4gICAgZG9jLnRleHQobG9hbklkLCBzdGFydFggKyBsYWJlbFdpZHRoICsgZ2FwLCAyMCwgeyBhbGlnbjogXCJsZWZ0XCIgfSk7XHJcblxyXG4gICAgLy8gSGVhZGVyIEJhbm5lclxyXG4gICAgZG9jLnNldEZpbGxDb2xvcigwLCAzOCwgMTI0KTtcclxuICAgIGRvYy5yZWN0KDAsIDQwLCAyMTAsIDE1LCBcIkZcIik7XHJcbiAgICBkb2Muc2V0VGV4dENvbG9yKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDE2KTtcclxuICAgIGRvYy50ZXh0KFwiTE9BTiBTQU5DVElPTiBDRVJUSUZJQ0FURVwiLCAxMDUsIDQ5LCB7IGFsaWduOiBcImNlbnRlclwiIH0pO1xyXG5cclxuICAgIGNvbnN0IGRyYXdGaWVsZCA9IChsYWJlbCwgdmFsdWUsIHgsIHkpID0+IHtcclxuICAgICAgY29uc3QgYm94V2lkdGggPSA4NTsgLy8gbW1cclxuICAgICAgY29uc3QgbGFiZWxXaWR0aCA9IDM4OyAvLyBtbSAoc3BhY2UgZm9yIGxhYmVsKVxyXG4gICAgICBjb25zdCB2YWx1ZVdpZHRoID0gYm94V2lkdGggLSBsYWJlbFdpZHRoIC0gNDsgLy8gfjQzbW0gZm9yIHZhbHVlIHRleHRcclxuXHJcbiAgICAgIGNvbnN0IHZhbHVlU3RyID0gc2FmZVRleHQodmFsdWUpO1xyXG4gICAgICAvLyBTcGxpdCB0ZXh0IHRvIGZpdCB3aXRoaW4gdmFsdWVXaWR0aFxyXG4gICAgICBjb25zdCBsaW5lcyA9IGRvYy5zcGxpdFRleHRUb1NpemUodmFsdWVTdHIsIHZhbHVlV2lkdGgpO1xyXG4gICAgICBjb25zdCBsaW5lSGVpZ2h0ID0gNDtcclxuICAgICAgY29uc3QgdGV4dEhlaWdodCA9IGxpbmVzLmxlbmd0aCAqIGxpbmVIZWlnaHQ7XHJcbiAgICAgIGNvbnN0IGJveEhlaWdodCA9IE1hdGgubWF4KDgsIHRleHRIZWlnaHQgKyA0KTsgLy8gYXQgbGVhc3QgOG1tLCBwbHVzIHBhZGRpbmdcclxuXHJcbiAgICAgIC8vIERyYXcgYm94XHJcbiAgICAgIGRvYy5zZXREcmF3Q29sb3IoMjIwLCAyMjQsIDIzMCk7XHJcbiAgICAgIGRvYy5yZWN0KHgsIHksIGJveFdpZHRoLCBib3hIZWlnaHQpO1xyXG5cclxuICAgICAgLy8gRHJhdyBsYWJlbFxyXG4gICAgICBkb2Muc2V0VGV4dENvbG9yKDAsIDM4LCAxMjQpO1xyXG4gICAgICBkb2Muc2V0Rm9udFNpemUoOSk7XHJcbiAgICAgIGRvYy50ZXh0KGxhYmVsICsgXCI6XCIsIHggKyAyLCB5ICsgNSk7XHJcblxyXG4gICAgICAvLyBEcmF3IHdyYXBwZWQgdmFsdWVcclxuICAgICAgZG9jLnNldFRleHRDb2xvcigzMywgMzMsIDMzKTtcclxuICAgICAgbGV0IHRleHRZID0geSArIDU7XHJcbiAgICAgIGxpbmVzLmZvckVhY2gobGluZSA9PiB7XHJcbiAgICAgICAgZG9jLnRleHQobGluZSwgeCArIGxhYmVsV2lkdGggKyAyLCB0ZXh0WSk7XHJcbiAgICAgICAgdGV4dFkgKz0gbGluZUhlaWdodDtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICByZXR1cm4geSArIGJveEhlaWdodCArIDU7IC8vIGFkZCBzbWFsbCBnYXAgYmV0d2VlbiByb3dzXHJcbiAgICB9O1xyXG5cclxuICAgIHNlY3Rpb25zLmZvckVhY2goKHNlYykgPT4ge1xyXG4gICAgICAvLyBTZWN0aW9uIGhlYWRlclxyXG4gICAgICBkb2Muc2V0RmlsbENvbG9yKDAsIDM4LCAxMjQpO1xyXG4gICAgICBkb2MucmVjdCgxNSwgeSwgMTgwLCAxMCwgXCJGXCIpO1xyXG4gICAgICBkb2Muc2V0VGV4dENvbG9yKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgICBkb2Muc2V0Rm9udFNpemUoMTQpO1xyXG4gICAgICBkb2MudGV4dChzZWMudGl0bGUsIDEwNSwgeSArIDcsIHsgYWxpZ246IFwiY2VudGVyXCIgfSk7XHJcbiAgICAgIHkgKz0gMTU7XHJcblxyXG4gICAgICAvLyBQcm9jZXNzIGZpZWxkcyBpbiBwYWlycyAodHdvIGNvbHVtbnMpXHJcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VjLmZpZWxkcy5sZW5ndGg7IGkgKz0gMikge1xyXG4gICAgICAgIGNvbnN0IGxlZnRGaWVsZCA9IHNlYy5maWVsZHNbaV07XHJcbiAgICAgICAgY29uc3QgcmlnaHRGaWVsZCA9IHNlYy5maWVsZHNbaSArIDFdO1xyXG4gICAgICAgIGNvbnN0IHN0YXJ0WSA9IHk7XHJcbiAgICAgICAgY29uc3QgbGVmdFkgPSBkcmF3RmllbGQobGVmdEZpZWxkLmxhYmVsLCBsZWZ0RmllbGQudmFsdWUsIDE1LCBzdGFydFkpO1xyXG4gICAgICAgIGxldCByaWdodFkgPSBzdGFydFk7XHJcbiAgICAgICAgaWYgKHJpZ2h0RmllbGQpIHtcclxuICAgICAgICAgIHJpZ2h0WSA9IGRyYXdGaWVsZChyaWdodEZpZWxkLmxhYmVsLCByaWdodEZpZWxkLnZhbHVlLCAxMTAsIHN0YXJ0WSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHkgPSBNYXRoLm1heChsZWZ0WSwgcmlnaHRZKTtcclxuICAgICAgfVxyXG4gICAgICB5ICs9IDU7IC8vIGV4dHJhIGdhcCBhZnRlciBzZWN0aW9uXHJcbiAgICB9KTtcclxuICAgIC8vIERlY2xhcmF0aW9uICYgc2lnbmF0dXJlc1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDEwKTtcclxuICAgIGRvYy50ZXh0KFwiSSBoZXJlYnkgZGVjbGFyZSB0aGF0IHRoZSBhYm92ZSBsb2FuIGluZm9ybWF0aW9uIGlzIHRydWUgYW5kIGNvcnJlY3QuXCIsIDEwNSwgeSArIDEwLCB7IGFsaWduOiBcImNlbnRlclwiIH0pO1xyXG4gICAgZG9jLnJlY3QoODAsIHkgKyAyMCwgNTAsIDIwKTtcclxuICAgIGRvYy50ZXh0KFwiQ3VzdG9tZXIgU2lnbmF0dXJlXCIsIDEwNSwgeSArIDMzLCB7IGFsaWduOiBcImNlbnRlclwiIH0pO1xyXG5cclxuICAgIC8vIEZvb3RlclxyXG4gICAgY29uc3QgcGFnZUhlaWdodCA9IGRvYy5pbnRlcm5hbC5wYWdlU2l6ZS5nZXRIZWlnaHQoKTtcclxuICAgIGNvbnN0IGZvb3RlclkgPSBwYWdlSGVpZ2h0IC0gMTc7XHJcbiAgICBkb2Muc2V0RmlsbENvbG9yKDAsIDM4LCAxMjQpO1xyXG4gICAgZG9jLnJlY3QoMCwgZm9vdGVyWSwgMjEwLCAyMCwgXCJGXCIpO1xyXG4gICAgZG9jLnNldFRleHRDb2xvcigyNTUsIDI1NSwgMjU1KTtcclxuICAgIGRvYy5zZXRGb250U2l6ZSg4KTtcclxuICAgIGRvYy50ZXh0KFwiVklKQVlBIFZJTkFZQUsgQ0hJVCBGVU5EUyBQUklWQVRFIExJTUlURURcIiwgMTA1LCBmb290ZXJZICsgNSwgeyBhbGlnbjogXCJjZW50ZXJcIiB9KTtcclxuICAgIGRvYy50ZXh0KFwiIzExLzM2LTI1LCAzcmQgRmxvb3IsIDJuZCBNYWluLCBLYXRocmlndXBwZSBNYWluIFJvYWQsIEJhbmFzaGFua2FyaSAzcmQgU3RhZ2UsIEJlbmdhbHVydS01NjAwODVcIiwgMTA1LCBmb290ZXJZICsgOSwgeyBhbGlnbjogXCJjZW50ZXJcIiB9KTtcclxuICAgIGRvYy50ZXh0KFwiTW9iOiA5NDgzOTAwNzc3IHwgUGg6IDA4MC00OTc5IDg3NjMgfCBFbWFpbDogaW5mby5teWNoaXRzQGdtYWlsLmNvbSB8IHd3dy5teWNoaXRzLmNvLmluXCIsIDEwNSwgZm9vdGVyWSArIDEzLCB7IGFsaWduOiBcImNlbnRlclwiIH0pO1xyXG5cclxuICAgIGlmIChkb3dubG9hZE9ubHkpIHtcclxuICAgICAgZG9jLnNhdmUoYCR7bG9hbkRhdGE/LmJvcnJvd2VyPy5mdWxsX25hbWUgfHwgXCJMb2FuXCJ9X1NhbmN0aW9uLnBkZmApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3QgcGRmQmxvYiA9IGRvYy5vdXRwdXQoXCJibG9iXCIpO1xyXG4gICAgICBjb25zdCBwZGZVcmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKHBkZkJsb2IpO1xyXG4gICAgICB3aW5kb3cub3BlbihwZGZVcmwsIFwiX2JsYW5rXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIC8vIENsZWFyIHRoZSBzZWFyY2ggaW5wdXQgYW5kIHJlc3VsdHMgd2hlbiB0YWIgY2hhbmdlcyBtYW51YWxseVxyXG4gIC8vICAgaWYgKGdsb2JhbFNlYXJjaFRlcm0pIHtcclxuICAvLyAgICAgc2V0R2xvYmFsU2VhcmNoVGVybSgnJyk7XHJcbiAgLy8gICAgIHNldEdsb2JhbFNlYXJjaFJlc3VsdHMobnVsbCk7XHJcbiAgLy8gICAgIHNldEdsb2JhbFNlYXJjaFRhcmdldFRhYihudWxsKTtcclxuICAvLyAgICAgc2V0U2VhcmNoSW5wdXQoJycpO1xyXG4gIC8vICAgfVxyXG4gIC8vIH0sIFthY3RpdmVUYWJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGJvcnJvd2VySWQgPSB1cGRhdGVGb3JtRGF0YS5ib3Jyb3dlcjtcclxuICAgIGlmICghYm9ycm93ZXJJZCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IHNlbGVjdGVkVXNlciA9IHVzZXJzLmZpbmQoKHVzZXIpID0+IHVzZXIuX2lkID09PSBib3Jyb3dlcklkKTtcclxuICAgIGlmICghc2VsZWN0ZWRVc2VyKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgcmVmVHlwZSA9IHNlbGVjdGVkVXNlci5yZWZlcnJhbF90eXBlIHx8IFwiU2VsZiBKb2luaW5nXCI7XHJcblxyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIHJlZmVycmVkX3R5cGU6IHJlZlR5cGUsXHJcbiAgICAgIHJlZmVycmVkX2VtcGxveWVlOiBcIlwiLFxyXG4gICAgICByZWZlcnJlZF9hZ2VudDogXCJcIixcclxuICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgaWYgKHJlZlR5cGUgPT09IFwiRW1wbG95ZWVcIiAmJiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfZW1wbG95ZWU/Ll9pZCkge1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHJlZmVycmVkX2VtcGxveWVlOiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfZW1wbG95ZWUuX2lkLFxyXG4gICAgICB9KSk7XHJcbiAgICB9IGVsc2UgaWYgKHJlZlR5cGUgPT09IFwiQWdlbnRcIiAmJiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfYWdlbnQ/Ll9pZCkge1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHJlZmVycmVkX2FnZW50OiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfYWdlbnQuX2lkLFxyXG4gICAgICB9KSk7XHJcbiAgICB9IGVsc2UgaWYgKHJlZlR5cGUgPT09IFwiQ3VzdG9tZXJcIiAmJiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfY3VzdG9tZXI/Ll9pZCkge1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHJlZmVycmVkX2N1c3RvbWVyOiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfY3VzdG9tZXIuX2lkLFxyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfSwgW3VwZGF0ZUZvcm1EYXRhLmJvcnJvd2VyLCB1c2Vyc10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hBbGxMb2FucyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBzdGF0dXNlcyA9IFtcIlJFUVVFU1RFRFwiLCBcIkFDQ0VQVEVEXCIsIFwiUEVORElOR1wiLCBcIkFQUFJPVkVEXCIsIFwiUkVKRUNURURcIiwgXCJDT01QTEVURURcIiwgXCJVTktOT1dOXCJdO1xyXG4gICAgICAgIGNvbnN0IHByb21pc2VzID0gc3RhdHVzZXMubWFwKHN0YXR1cyA9PiBhcGkuZ2V0KGAvdjEvYWRtaW4vbG9hbnM/YXBwcm92YWxfc3RhdHVzPSR7c3RhdHVzfWApKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZXMgPSBhd2FpdCBQcm9taXNlLmFsbChwcm9taXNlcyk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0ge307XHJcbiAgICAgICAgc3RhdHVzZXMuZm9yRWFjaCgoc3RhdHVzLCBpZHgpID0+IHtcclxuICAgICAgICAgIGNvbnN0IGtleSA9IHN0YXR1cy50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgICAgcmVzdWx0W2tleV0gPSByZXNwb25zZXNbaWR4XS5kYXRhLmRhdGEgfHwgW107XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gQWxzbyBmZXRjaCBjbG9zZWQgbG9hbnNcclxuICAgICAgICBjb25zdCBjbG9zZWRSZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL2xvYW5zL2Nsb3NlZFwiKTtcclxuICAgICAgICByZXN1bHQuY2xvc2VkID0gY2xvc2VkUmVzLmRhdGEuZGF0YSB8fCBbXTtcclxuICAgICAgICBzZXRBbGxMb2FucyhyZXN1bHQpO1xyXG4gICAgICAgIHNldEFsbExvYW5zTG9hZGVkKHRydWUpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gcHJl4oCRZmV0Y2ggYWxsIGxvYW5zXCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQWxsTG9hbnMoKTtcclxuICB9LCBbXSk7XHJcblxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hDdXN0b21lcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBib3Jyb3dlcnNcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIExvYW5zIEJvcnJvd2VyIERhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQ3VzdG9tZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXRcIik7XHJcbiAgICAgICAgc2V0QWdlbnRzKHJlc3BvbnNlLmRhdGE/LmFnZW50KTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBMZWFkc1wiLCBlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWVtcGxveWVlXCIpO1xyXG4gICAgICAgIHNldEVtcGxveWVlcyhyZXNwb25zZT8uZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJmYWlsZWQgdG8gZmV0Y2ggZW1wbG95ZWVzXCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVQcmludCA9IGFzeW5jIChsb2FuUHJpbnRJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL2xvYW5zL2dldC1ib3Jyb3dlci8ke2xvYW5QcmludElkfWApO1xyXG4gICAgICBnZW5lcmF0ZUFuZE9wZW5QREYoZmFsc2UsIHJlcy5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGdlbmVyYXRlIFBERlwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICAvLyBmdW5jdGlvbiBmb3IgYWRkIHBlbmFsdHkgY2hhcmdlc1xyXG4gIGNvbnN0IGhhbmRsZVBlbmFsdHlNb2RhbE9wZW4gPSAoYm9ycm93ZXIpID0+IHtcclxuICAgIHNldFBlbmFsdHlMb2FuKGJvcnJvd2VyKTtcclxuICAgIHNldFBlbmFsdHlDaGFyZ2VzKFt7IGFtb3VudDogXCJcIiwgcmVhc29uOiBcIlwiIH1dKTtcclxuICAgIHNldFNob3dQZW5hbHR5TW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQWRkUGVuYWx0eVJvdyA9ICgpID0+IHtcclxuICAgIHNldFBlbmFsdHlDaGFyZ2VzKHByZXYgPT4gWy4uLnByZXYsIHsgYW1vdW50OiBcIlwiLCByZWFzb246IFwiXCIgfV0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlbW92ZVBlbmFsdHlSb3cgPSAoaW5kZXgpID0+IHtcclxuICAgIHNldFBlbmFsdHlDaGFyZ2VzKHByZXYgPT4gcHJldi5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGVuYWx0eUNoYW5nZSA9IChpbmRleCwgZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRQZW5hbHR5Q2hhcmdlcyhwcmV2ID0+XHJcbiAgICAgIHByZXYubWFwKChyb3csIGkpID0+IGkgPT09IGluZGV4ID8geyAuLi5yb3csIFtmaWVsZF06IHZhbHVlIH0gOiByb3cpXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBlbmFsdHlTdWJtaXQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyBWYWxpZGF0ZVxyXG4gICAgY29uc3QgaW52YWxpZCA9IHBlbmFsdHlDaGFyZ2VzLnNvbWUoYyA9PiAhYy5hbW91bnQgfHwgIWMucmVhc29uLnRyaW0oKSk7XHJcbiAgICBpZiAoaW52YWxpZCkge1xyXG4gICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2UgZmlsbCBpbiBhbGwgYW1vdW50IGFuZCByZWFzb24gZmllbGRzXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0UGVuYWx0eUxvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBleGlzdGluZ0NoYXJnZXMgPSBwZW5hbHR5TG9hbj8uZXh0cmFfY2hhcmdlcyB8fCBbXTtcclxuICAgICAgY29uc3QgbmV3Q2hhcmdlcyA9IHBlbmFsdHlDaGFyZ2VzLm1hcChjID0+ICh7XHJcbiAgICAgICAgYW1vdW50OiBOdW1iZXIoYy5hbW91bnQpLFxyXG4gICAgICAgIHJlYXNvbjogYy5yZWFzb24udHJpbSgpLFxyXG4gICAgICAgIHBhaWQ6IGZhbHNlLFxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICBhd2FpdCBhcGkucHV0KGAvdjEvYWRtaW4vbG9hbnMvbG9hbi8ke3BlbmFsdHlMb2FuPy5faWR9YCwge1xyXG4gICAgICAgIGV4dHJhX2NoYXJnZXM6IFsuLi5leGlzdGluZ0NoYXJnZXMsIC4uLm5ld0NoYXJnZXNdLFxyXG4gICAgICAgIC8vIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIlBlbmFsdHkgY2hhcmdlcyBhZGRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgIHNldFNob3dQZW5hbHR5TW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRQZW5hbHR5TG9hbihudWxsKTtcclxuICAgICAgc2V0UGVuYWx0eUNoYXJnZXMoW3sgYW1vdW50OiBcIlwiLCByZWFzb246IFwiXCIgfV0pO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKHByZXYgPT4gcHJldiArIDEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gYWRkIHBlbmFsdHkgY2hhcmdlc1wiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFBlbmFsdHlMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hMb2FuQ291bnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRTdW1tYXJ5TG9hZGluZyh0cnVlKVxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IFtyZXF1ZXN0c1JlcywgY2xvc2VkTG9hbnNSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgYXBpLmdldChcIi92MS9hZG1pbi9sb2Fucy9vdmVydmlld1wiKSxcclxuICAgICAgICAgIGFwaS5nZXQoXCIvdjEvYWRtaW4vbG9hbnMvY2xvc2VkXCIpLFxyXG4gICAgICAgIF0pO1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSByZXF1ZXN0c1Jlcy5kYXRhPy5kYXRhIHx8IFtdO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGRhdGEucmVkdWNlKChhY2MsIGl0ZW0pID0+IHtcclxuICAgICAgICAgIGFjY1tpdGVtLnN0YXR1c10gPSBpdGVtLmNvdW50O1xyXG4gICAgICAgICAgcmV0dXJuIGFjYztcclxuICAgICAgICB9LCB7fSk7XHJcbiAgICAgICAgc2V0U3VtbWFyeURhdGEoZGF0YSk7XHJcbiAgICAgICAgc2V0VG90YWxzKHtcclxuICAgICAgICAgIHRvdGFsUmVxdWVzdHM6IGZvcm1hdHRlZC5SRVFVRVNURUQgfHwgMCxcclxuICAgICAgICAgIHRvdGFsQWNjZXB0ZWQ6IGZvcm1hdHRlZC5BQ0NFUFRFRCB8fCAwLFxyXG4gICAgICAgICAgdG90YWxQZW5kaW5nOiBmb3JtYXR0ZWQuUEVORElORyB8fCAwLFxyXG4gICAgICAgICAgdG90YWxBcHByb3ZlZDogZm9ybWF0dGVkLkFQUFJPVkVEIHx8IDAsXHJcbiAgICAgICAgICB0b3RhbFJlamVjdGVkOiBmb3JtYXR0ZWQuUkVKRUNURUQgfHwgMCxcclxuICAgICAgICAgIHRvdGFsQ29tcGxldGVkOiBmb3JtYXR0ZWQuQ09NUExFVEVEIHx8IDAsXHJcbiAgICAgICAgICB0b3RhbENsb3NlZDogY2xvc2VkTG9hbnNSZXM/LmRhdGE/LmRhdGE/Lmxlbmd0aCB8fCAwLFxyXG4gICAgICAgICAgdG90YWxVbmtub3duOiBmb3JtYXR0ZWQuVU5LTk9XTiB8fCAwLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBsb2FuIGNvdW50czpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICAgIGZpbmFsbHkge1xyXG4gICAgICAgIHNldFN1bW1hcnlMb2FkaW5nKGZhbHNlKVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hMb2FuQ291bnRzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuICBjb25zdCBnZXRTdGF0dXNPcHRpb25zRm9yVGFiID0gKHRhYikgPT4ge1xyXG4gICAgY29uc3QgY29tbW9uT3B0aW9ucyA9IHtcclxuICAgICAgQUNDRVBURUQ6IHsgbGFiZWw6IFwiQWNjZXB0XCIsIHZhbHVlOiBcIkFDQ0VQVEVEXCIsIGljb246IDxDaGVja0NpcmNsZU91dGxpbmVkIC8+LCBjbGFzc05hbWU6IFwiYmctZ3JlZW4tNzAwIHRleHQtd2hpdGUgaG92ZXI6YmctZ3JlZW4tODAwXCIgfSxcclxuICAgICAgUEVORElORzogeyBsYWJlbDogXCJQZW5kaW5nXCIsIHZhbHVlOiBcIlBFTkRJTkdcIiwgaWNvbjogPENsb2NrQ2lyY2xlT3V0bGluZWQgLz4sIGNsYXNzTmFtZTogXCJib3JkZXIteWVsbG93LTQwMCB0ZXh0LXllbGxvdy02MDAgaG92ZXI6YmcteWVsbG93LTUwXCIgfSxcclxuICAgICAgUkVKRUNURUQ6IHsgbGFiZWw6IFwiUmVqZWN0XCIsIHZhbHVlOiBcIlJFSkVDVEVEXCIsIGljb246IDxDbG9zZUNpcmNsZU91dGxpbmVkIC8+LCBjbGFzc05hbWU6IFwiYm9yZGVyLXJlZC00MDAgdGV4dC1yZWQtNjAwIGhvdmVyOmJnLXJlZC01MFwiIH0sXHJcbiAgICAgIFVOS05PV046IHsgbGFiZWw6IFwiVW5rbm93blwiLCB2YWx1ZTogXCJVTktOT1dOXCIsIGljb246IDxRdWVzdGlvbkNpcmNsZU91dGxpbmVkIC8+LCBjbGFzc05hbWU6IFwiYm9yZGVyLXllbGxvdy00MDAgdGV4dC15ZWxsb3ctNjAwIGhvdmVyOmJnLXllbGxvdy01MFwiIH0sXHJcbiAgICAgIFJFUVVFU1RFRDogeyBsYWJlbDogXCJSZXF1ZXN0ZWRcIiwgdmFsdWU6IFwiUkVRVUVTVEVEXCIsIGljb246IDxFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIC8+LCBjbGFzc05hbWU6IFwiYm9yZGVyLWJsdWUtNDAwIHRleHQtYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MFwiIH0sXHJcbiAgICAgIEFQUFJPVkVEOiB7IGxhYmVsOiBcIkFwcHJvdmVcIiwgdmFsdWU6IFwiQVBQUk9WRURcIiwgaWNvbjogPENoZWNrQ2lyY2xlT3V0bGluZWQgLz4sIGNsYXNzTmFtZTogXCJiZy1pbmRpZ28tNjAwIHRleHQtd2hpdGUgaG92ZXI6YmctaW5kaWdvLTcwMFwiIH0sXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IG9wdGlvbnNNYXAgPSB7XHJcbiAgICAgIHJlcXVlc3RzOiBbXCJBQ0NFUFRFRFwiLCBcIlBFTkRJTkdcIiwgXCJSRUpFQ1RFRFwiLCBcIlVOS05PV05cIl0sXHJcbiAgICAgIGFjY2VwdGVkOiBbXCJSRVFVRVNURURcIiwgXCJQRU5ESU5HXCIsIFwiUkVKRUNURURcIiwgXCJVTktOT1dOXCIsIFwiQVBQUk9WRURcIixdLFxyXG4gICAgICBwZW5kaW5nOiBbXHJcbiAgICAgICAgLy8gXCJSRVFVRVNURURcIiwgXCJBQ0NFUFRFRFwiLCBcclxuICAgICAgICBcIlJFSkVDVEVEXCIsIFwiQVBQUk9WRURcIiwgXCJVTktOT1dOXCJdLFxyXG4gICAgICBhcHByb3ZlZDogW1wiUkVRVUVTVEVEXCIsIFwiQUNDRVBURURcIiwgXCJQRU5ESU5HXCIsIFwiUkVKRUNURURcIiwgXCJVTktOT1dOXCJdLFxyXG4gICAgICByZWplY3RlZDogW1wiUkVRVUVTVEVEXCIsIFwiQUNDRVBURURcIiwgXCJQRU5ESU5HXCIsIFwiVU5LTk9XTlwiXSxcclxuICAgICAgdW5rbm93bjogW1wiUkVRVUVTVEVEXCIsIFwiQUNDRVBURURcIiwgXCJQRU5ESU5HXCIsIFwiUkVKRUNURURcIl0sXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGtleXMgPSBvcHRpb25zTWFwW3RhYl0gfHwgb3B0aW9uc01hcC5wZW5kaW5nO1xyXG4gICAgcmV0dXJuIGtleXMubWFwKGtleSA9PiBjb21tb25PcHRpb25zW2tleV0pO1xyXG4gIH07XHJcblxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hCb3Jyb3dlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIHNldEZldGNoRXJyb3IoZmFsc2UpO1xyXG4gICAgICAgIGxldCByZXNwb25zZTtcclxuICAgICAgICBjb25zdCByb3V0ZU1hcCA9IHtcclxuICAgICAgICAgIHJlcXVlc3RzOiBcIi8/YXBwcm92YWxfc3RhdHVzPVJFUVVFU1RFRFwiLFxyXG4gICAgICAgICAgYWNjZXB0ZWQ6IFwiLz9hcHByb3ZhbF9zdGF0dXM9QUNDRVBURURcIixcclxuICAgICAgICAgIHBlbmRpbmc6IFwiLz9hcHByb3ZhbF9zdGF0dXM9UEVORElOR1wiLFxyXG4gICAgICAgICAgYXBwcm92ZWQ6IFwiLz9hcHByb3ZhbF9zdGF0dXM9QVBQUk9WRURcIixcclxuICAgICAgICAgIHJlamVjdGVkOiBcIi8/YXBwcm92YWxfc3RhdHVzPVJFSkVDVEVEXCIsXHJcbiAgICAgICAgICBjb21wbGV0ZWQ6IFwiLz9hcHByb3ZhbF9zdGF0dXM9Q09NUExFVEVEXCIsXHJcbiAgICAgICAgICBjbG9zZWQ6IFwiL2Nsb3NlZFwiLFxyXG4gICAgICAgICAgdW5rbm93bjogXCIvP2FwcHJvdmFsX3N0YXR1cz1VTktOT1dOXCIsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCByb3V0ZSA9IHJvdXRlTWFwW2FjdGl2ZVRhYl0gfHwgXCJQRU5ESU5HXCI7XHJcbiAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vbG9hbnMke3JvdXRlfWApO1xyXG4gICAgICAgIGNvbnN0IGFwaURhdGEgPSByZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG4gICAgICAgIHNldEJvcnJvd2VycyhhcGlEYXRhKTtcclxuICAgICAgICBsZXQgdGFibGVEYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCBbXTtcclxuICAgICAgICBpZiAoYWN0aXZlVGFiID09PSBcInJlcXVlc3RzXCIpIHtcclxuICAgICAgICAgIHRhYmxlRGF0YSA9IHRhYmxlRGF0YS5zbGljZSgpLnNvcnQoKGEsIGIpID0+IG5ldyBEYXRlKGIuY3JlYXRlZEF0KSAtIG5ldyBEYXRlKGEuY3JlYXRlZEF0KSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGdldEZvcm1hdHRlZExvYW5JZCA9IChvcmlnaW5hbExvYW5JZCwgY3VycmVudFRhYikgPT4ge1xyXG4gICAgICAgICAgLy8gRmFsbGJhY2sgaWYgb3JpZ2luYWxMb2FuSWQgaXMgbWlzc2luZ1xyXG4gICAgICAgICAgaWYgKCFvcmlnaW5hbExvYW5JZCkgcmV0dXJuIFwiTi9BXCI7XHJcblxyXG4gICAgICAgICAgY29uc3QgbWF0Y2ggPSBvcmlnaW5hbExvYW5JZC5tYXRjaCgvXFxkKy8pO1xyXG4gICAgICAgICAgY29uc3QgbnVtYmVyUGFydCA9IG1hdGNoID8gbWF0Y2hbMF0gOiBcIlwiO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHRhYnNXaXRoUlFMTiA9IFtcInJlcXVlc3RzXCIsIFwiYWNjZXB0ZWRcIiwgXCJwZW5kaW5nXCIsIFwidW5rbm93blwiLCBcInJlamVjdGVkXCJdO1xyXG4gICAgICAgICAgY29uc3QgcHJlZml4ID0gdGFic1dpdGhSUUxOLmluY2x1ZGVzKGN1cnJlbnRUYWIpID8gXCJSUUxOXCIgOiBcIkxOXCI7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIG51bWJlclBhcnQgPyBgJHtwcmVmaXh9JHtudW1iZXJQYXJ0fWAgOiBvcmlnaW5hbExvYW5JZDtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSB0YWJsZURhdGE/Lm1hcCgoYm9ycm93ZXIsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBnZXRVc2VySWQgPSAobG9hbikgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gbG9hbi51c2VyX2lkPy5faWQgfHwgbG9hbi5ib3Jyb3dlcj8uX2lkIHx8IG51bGw7XHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgLy8gLS0tIEhlbHBlciB0byBidWlsZCByZWZlcnJlZF9ieSBzdHJpbmcgKHNhbWUgZm9yIGFsbCB0YWJzKSAtLS1cclxuICAgICAgICAgIGNvbnN0IGJ1aWxkUmVmZXJyZWRCeSA9IChsb2FuSXRlbSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBib3Jyb3dlckRhdGEgPSBsb2FuSXRlbT8uYm9ycm93ZXIgfHwge307XHJcbiAgICAgICAgICAgIC8vIFByaW9yaXR5OiBDaGVjayByb290IGxldmVsIHJlZmVycmVkX3R5cGUgZmlyc3QsIHRoZW4gYm9ycm93ZXIucmVmZXJyYWxfdHlwZVxyXG4gICAgICAgICAgICBjb25zdCByZWZUeXBlID0gbG9hbkl0ZW0/LnJlZmVycmVkX3R5cGUgfHwgYm9ycm93ZXJEYXRhPy5yZWZlcnJhbF90eXBlIHx8IFwiXCI7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVmVHlwZVwiLCByZWZUeXBlKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJGdWxsIGxvYW5JdGVtOlwiLCBsb2FuSXRlbSk7XHJcblxyXG4gICAgICAgICAgICBjb25zdCByZW5kZXJDZWxsID0gKGNoaWxkcmVuKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMTgwcHhdIHdoaXRlc3BhY2Utbm9ybWFsXCI+XHJcbiAgICAgICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAvLyBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IHJlZmVycmVkIGRhdGEgZnJvbSByb290IGxldmVsIGZpcnN0LCB0aGVuIGJvcnJvd2VyIGxldmVsXHJcbiAgICAgICAgICAgIGNvbnN0IGdldFJlZmVycmVkRGF0YSA9ICh0eXBlKSA9PiB7XHJcbiAgICAgICAgICAgICAgLy8gQ2hlY2sgcm9vdCBsZXZlbCBmaXJzdFxyXG4gICAgICAgICAgICAgIGNvbnN0IHJvb3RSZWYgPSBsb2FuSXRlbVtgcmVmZXJyZWRfJHt0eXBlfWBdO1xyXG4gICAgICAgICAgICAgIC8vIFRoZW4gY2hlY2sgYm9ycm93ZXIgbGV2ZWxcclxuICAgICAgICAgICAgICBjb25zdCBib3Jyb3dlclJlZiA9IGJvcnJvd2VyRGF0YVtgcmVmZXJyZWRfJHt0eXBlfWBdO1xyXG5cclxuICAgICAgICAgICAgICAvLyBSZXR1cm4gdGhlIGZpcnN0IG5vbi1udWxsIHZhbHVlXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHJvb3RSZWYgfHwgYm9ycm93ZXJSZWYgfHwgbnVsbDtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIGlmIChyZWZUeXBlID09PSBcIkFnZW50XCIpIHtcclxuICAgICAgICAgICAgICBjb25zdCBhZ2VudCA9IGdldFJlZmVycmVkRGF0YSgnYWdlbnQnKTtcclxuICAgICAgICAgICAgICBjb25zdCBuYW1lID0gYWdlbnQ/Lm5hbWUgfHwgXCJOL0FcIjtcclxuICAgICAgICAgICAgICBjb25zdCBwaG9uZSA9IGFnZW50Py5waG9uZV9udW1iZXIgfHwgYWdlbnQ/LnBob25lIHx8IFwiLVwiO1xyXG4gICAgICAgICAgICAgIHJldHVybiByZW5kZXJDZWxsKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkFnZW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwXCI+e25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHNcIj57cGhvbmV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmIChyZWZUeXBlID09PSBcIkN1c3RvbWVyXCIpIHtcclxuICAgICAgICAgICAgICBjb25zdCBjdXN0b21lciA9IGdldFJlZmVycmVkRGF0YSgnY3VzdG9tZXInKTtcclxuICAgICAgICAgICAgICBjb25zdCBuYW1lID0gY3VzdG9tZXI/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHBob25lID0gY3VzdG9tZXI/LnBob25lX251bWJlciB8fCBjdXN0b21lcj8ucGhvbmUgfHwgXCItXCI7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHJlbmRlckNlbGwoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+Q3VzdG9tZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDBcIj57bmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC14c1wiPntwaG9uZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHJlZlR5cGUgPT09IFwiRW1wbG95ZWVcIikge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGVtcGxveWVlID0gZ2V0UmVmZXJyZWREYXRhKCdlbXBsb3llZScpO1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRW1wbG95ZWUgZGF0YSBmb3VuZDpcIiwgZW1wbG95ZWUpO1xyXG5cclxuICAgICAgICAgICAgICBjb25zdCBuYW1lID0gZW1wbG95ZWU/Lm5hbWUgfHwgXCJOL0FcIjtcclxuICAgICAgICAgICAgICBjb25zdCBwaG9uZSA9IGVtcGxveWVlPy5waG9uZV9udW1iZXIgfHwgZW1wbG95ZWU/LnBob25lIHx8IFwiLVwiO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGVtcENvZGUgPSBlbXBsb3llZT8uZW1wbG95ZWVDb2RlIHx8IGVtcGxveWVlPy51bmlxdWVfY29kZSB8fCBcIlwiO1xyXG5cclxuICAgICAgICAgICAgICByZXR1cm4gcmVuZGVyQ2VsbChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5FbXBsb3llZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMFwiPntuYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3Bob25lICE9PSBcIi1cIiA/IHBob25lIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICB7ZW1wQ29kZSAmJiBwaG9uZSAhPT0gXCItXCIgPyBcIiB8IFwiIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICB7ZW1wQ29kZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHJlZlR5cGUgPT09IFwiU2VsZiBKb2luaW5nXCIpIHtcclxuICAgICAgICAgICAgICByZXR1cm4gcmVuZGVyQ2VsbChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+U2VsZiBKb2luaW5nPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gRmFsbGJhY2s6IElmIG5vIHJlZmVycmFsIHR5cGUgYnV0IGhhcyByZWZlcnJlZF9lbXBsb3llZSBkYXRhXHJcbiAgICAgICAgICAgIGNvbnN0IGZhbGxiYWNrRW1wbG95ZWUgPSBnZXRSZWZlcnJlZERhdGEoJ2VtcGxveWVlJyk7XHJcbiAgICAgICAgICAgIGlmIChmYWxsYmFja0VtcGxveWVlKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgbmFtZSA9IGZhbGxiYWNrRW1wbG95ZWU/Lm5hbWUgfHwgXCJOL0FcIjtcclxuICAgICAgICAgICAgICBjb25zdCBwaG9uZSA9IGZhbGxiYWNrRW1wbG95ZWU/LnBob25lX251bWJlciB8fCBmYWxsYmFja0VtcGxveWVlPy5waG9uZSB8fCBcIi1cIjtcclxuICAgICAgICAgICAgICByZXR1cm4gcmVuZGVyQ2VsbChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5FbXBsb3llZSAoRGlyZWN0KTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMFwiPntuYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXhzXCI+e3Bob25lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiByZW5kZXJDZWxsKDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMFwiPk4vQTwvc3Bhbj4pO1xyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIC8vIENvbW1vbiBhY3Rpb24gZHJvcGRvd24gKEVkaXQsIFVwZGF0ZSBTdGF0dXMsIFJlbW92ZSwgUHJpbnQpXHJcbiAgICAgICAgICBjb25zdCBzdGF0dXNPcHRpb25zID0gZ2V0U3RhdHVzT3B0aW9uc0ZvclRhYihhY3RpdmVUYWIpO1xyXG4gICAgICAgICAgY29uc3QgcG9wb3ZlckNvbnRlbnQgPSAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy00MCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBwLTIgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAge3N0YXR1c09wdGlvbnMubWFwKG9wdCA9PiAoXHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIGtleT17b3B0LnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtvcHQuaWNvbn1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1zdGFydCB3LWZ1bGwgJHtvcHQuY2xhc3NOYW1lfWB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUxvYW5TdGF0dXMoYm9ycm93ZXIsIG9wdC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtvcHQubGFiZWx9XHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgY29uc3QgYWN0aW9uRHJvcGRvd24gPSAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgLi4uKGFjdGl2ZVRhYiAhPT0gXCJjb21wbGV0ZWRcIiAmJiBhY3RpdmVUYWIgIT09IFwiY2xvc2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gW3sga2V5OiBcIjFcIiwgbGFiZWw6IDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oYm9ycm93ZXIuX2lkKX0+RWRpdDwvZGl2PiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiNVwiLCBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY3lhbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSBib3Jyb3dlci51c2VyX2lkPy5faWQgfHwgYm9ycm93ZXIuYm9ycm93ZXI/Ll9pZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVzZXJJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVZpZXdUcmFuc2FjdGlvbnModXNlcklkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLndhcm5pbmcoXCJObyBjdXN0b21lciBJRCBmb3VuZCBmb3IgdGhpcyBsb2FuXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgVHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgICAgICAgIDogW10pLFxyXG4gICAgICAgICAgICAgICAgICAgIC4uLihhY3RpdmVUYWIgIT09IFwiY29tcGxldGVkXCIgJiYgYWN0aXZlVGFiICE9PSBcImNsb3NlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFt7IGtleTogXCIyXCIsIGxhYmVsOiA8UG9wb3ZlciBwbGFjZW1lbnQ9XCJyaWdodFRvcFwiIHRyaWdnZXI9XCJob3ZlclwiIGNvbnRlbnQ9e3BvcG92ZXJDb250ZW50fT48ZGl2IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgY3Vyc29yLXBvaW50ZXJcIj5VcGRhdGUgU3RhdHVzPC9kaXY+PC9Qb3BvdmVyPiB9XVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBbXSksXHJcbiAgICAgICAgICAgICAgICAgICAgLi4uKGFjdGl2ZVRhYiA9PT0gXCJyZXF1ZXN0c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/XHJcbiAgICAgICAgICAgICAgICAgICAgICBbe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJvcnJvd2VyPy5hZ2VudF9hcHByb3ZhbF9zdGF0dXMgPT09IFwiUEVORElOR1wiIHx8IGJvcnJvd2VyPy5hZ2VudF9hcHByb3ZhbF9zdGF0dXMgPT09IFwiUkVKRUNURURcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2Uud2FybmluZyhcIkxvYW4gYW1vdW50IGNhbm5vdCBiZSBlZGl0ZWQgYXMgYWdlbnQgYXBwcm92YWwgaXMgcGVuZGluZyBvciByZWplY3RlZFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVPcGVuTG9hbk1vZGFsKGJvcnJvd2VyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFFZGl0IGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiB0aXRsZT1cIkVkaXQgTG9hbiBBbW91bnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCB0ZXh0LVsxMXB4XVwiPkxvYW4gQW1vdW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBbXSksXHJcbiAgICAgICAgICAgICAgICAgICAgLi4uKGFjdGl2ZVRhYiA9PT0gXCJhcHByb3ZlZFwiIHx8IGFjdGl2ZVRhYiA9PT0gXCJjb21wbGV0ZWRcIiB8fCBhY3RpdmVUYWIgPT09IFwiY2xvc2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gW3sga2V5OiBcIjZcIiwgbGFiZWw6IDxkaXYgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNjAwXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUHJpbnQoYm9ycm93ZXIuX2lkKX0+UHJpbnQ8L2Rpdj4gfV1cclxuICAgICAgICAgICAgICAgICAgICAgIDogW10pLFxyXG4gICAgICAgICAgICAgICAgICAgIC4uLihhY3RpdmVUYWIgPT09IFwiY29tcGxldGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gW3sga2V5OiBcIjdcIiwgbGFiZWw6IDxkaXYgY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUGVuYWx0eU1vZGFsT3Blbihib3Jyb3dlcil9PlZpZXcgUGVuYWx0eTwvZGl2PiB9XVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBbXSksXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC4uLihhY3RpdmVUYWIgPT09IFwiYXBwcm92ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwicGF5bWVudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmlSdXBlZSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2VcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNYWtlIFBheW1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9sb2FuLXBheW91dD9sb2FuSWQ9JHtib3Jyb3dlci5faWR9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBbXSksXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgPlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgY29uc3QgYWdlbnRTdGF0dXMgPSBib3Jyb3dlcj8uYWdlbnRfYXBwcm92YWxfc3RhdHVzO1xyXG4gICAgICAgICAgbGV0IGFnZW50QmFkZ2UgPSBudWxsO1xyXG5cclxuICAgICAgICAgIGxldCBhcHByb3ZlZERhdGUgPSBib3Jyb3dlcj8uYWdlbnRfYXBwcm92YWxfc3RhdHVzX3VwZGF0ZWRfYXRcclxuICAgICAgICAgICAgPyBuZXcgRGF0ZShib3Jyb3dlci5hZ2VudF9hcHByb3ZhbF9zdGF0dXNfdXBkYXRlZF9hdCkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tSU5cIilcclxuICAgICAgICAgICAgOiBcIiBcIjtcclxuICAgICAgICAgIGNvbnN0IGFwcHJvdmVkQW1vdW50ID0gYm9ycm93ZXI/LmFwcHJvdmVkX2xvYW5fYW1vdW50XHJcbiAgICAgICAgICAgID8gYOKCuSR7KGJvcnJvd2VyLmFwcHJvdmVkX2xvYW5fYW1vdW50KS50b0xvY2FsZVN0cmluZygpfWBcclxuICAgICAgICAgICAgOiBudWxsO1xyXG4gICAgICAgICAgY29uc3QgcmVtYXJrID0gYm9ycm93ZXI/LmVtcGxveWVlX3JlbWFyayB8fCBcIk5vIHJlbWFyayBwcm92aWRlZFwiO1xyXG4gICAgICAgICAgY29uc3QgYm9ycm93ZXJVc2VySWQgPSBib3Jyb3dlcj8udXNlcl9pZD8uX2lkIHx8IGJvcnJvd2VyPy5ib3Jyb3dlcj8uX2lkO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHRvb2x0aXBDb250ZW50ID0gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj7inIUgQWdlbnQ6IHtib3Jyb3dlcj8uYm9ycm93ZXI/LnJlZmVycmVkX2VtcGxveWVlPy5uYW1lIHx8IGJvcnJvd2VyPy5ib3Jyb3dlcj8ucmVmZXJyZWRfY3VzdG9tZXI/LmZ1bGxfbmFtZSB8fCBib3Jyb3dlcj8uYm9ycm93ZXI/LnJlZmVycmVkX2FnZW50Py5uYW1lIHx8IFwiU2VsZiBKb2luaW5nXCJ9PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj7inIUgQWdlbnQgUmVwbGllZCBvbjoge2FwcHJvdmVkRGF0ZX08L2Rpdj5cclxuICAgICAgICAgICAgICB7YXBwcm92ZWRBbW91bnQgJiYgPGRpdj7wn5KwIEFwcHJvdmVkIEFtb3VudDoge2FwcHJvdmVkQW1vdW50fTwvZGl2Pn1cclxuICAgICAgICAgICAgICA8ZGl2PvCfk50gUmVtYXJrOiB7cmVtYXJrfTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICAvLyBJbnNpZGUgdGhlIGFnZW50IHN0YXR1cyBjaGVja3MgKEFQUFJPVkVELCBSRUpFQ1RFRCwgUEVORElORylcclxuICAgICAgICAgIGlmIChhZ2VudFN0YXR1cyA9PT0gXCJBUFBST1ZFRFwiKSB7XHJcbiAgICAgICAgICAgIGFnZW50QmFkZ2UgPSAoXHJcbiAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9e3Rvb2x0aXBDb250ZW50fSBvdmVybGF5Q2xhc3NOYW1lPVwibWF4LXcteHNcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0xLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNTAwIHRvLXRlYWwtNTAwIHRleHQtd2hpdGUgc2hhZG93LXNtIHdoaXRlc3BhY2Utbm93cmFwIGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgICAgPEZhVGh1bWJzVXAgY2xhc3NOYW1lPVwidy0yLjUgaC0yLjVcIiAvPiBBZ2VudCBBcHByb3ZlZFxyXG4gICAgICAgICAgICAgICAgICA8SW5mb0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC1bOHB4XSBvcGFjaXR5LTgwXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9IGVsc2UgaWYgKGFnZW50U3RhdHVzID09PSBcIlJFSkVDVEVEXCIpIHtcclxuICAgICAgICAgICAgYWdlbnRCYWRnZSA9IChcclxuICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT17dG9vbHRpcENvbnRlbnR9IG92ZXJsYXlDbGFzc05hbWU9XCJtYXgtdy14c1wiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTEuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBiZy1ncmFkaWVudC10by1yIGZyb20tcmVkLTUwMCB0by1yb3NlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1zbSB3aGl0ZXNwYWNlLW5vd3JhcCBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGYVRpbWVzQ2lyY2xlIGNsYXNzTmFtZT1cInctMi41IGgtMi41XCIgLz4gQWdlbnQgUmVqZWN0ZWRcclxuICAgICAgICAgICAgICAgICAgPEluZm9DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtWzhweF0gb3BhY2l0eS04MFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfSBlbHNlIGlmIChhZ2VudFN0YXR1cyA9PT0gXCJQRU5ESU5HXCIpIHtcclxuICAgICAgICAgICAgYWdlbnRCYWRnZSA9IChcclxuICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT17dG9vbHRpcENvbnRlbnR9IG92ZXJsYXlDbGFzc05hbWU9XCJtYXgtdy14c1wiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTEuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBiZy1ncmFkaWVudC10by1yIGZyb20tYW1iZXItNDAwIHRvLW9yYW5nZS01MDAgdGV4dC13aGl0ZSBzaGFkb3ctc20gd2hpdGVzcGFjZS1ub3dyYXAgZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8RmFIb3VyZ2xhc3NIYWxmIGNsYXNzTmFtZT1cInctMi41IGgtMi41XCIgLz4gQWdlbnQgUGVuZGluZ1xyXG4gICAgICAgICAgICAgICAgICA8SW5mb0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC1bOHB4XSBvcGFjaXR5LTgwXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgbGV0IGN1c3RvbWVyTmFtZSA9IChcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZ3JvdXAgbWluLXctWzIyMHB4XVwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAge2JvcnJvd2VyPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgYm9ycm93ZXI/LnVzZXI/LmZ1bGxfbmFtZSB8fCBib3Jyb3dlcj8uYm9ycm93ZXI/LmZ1bGxfbmFtZSB8fCBcIlVua25vd25cIn1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgey8qIFZpZXcgVHJhbnNhY3Rpb25zIGJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgIGlmICghYm9ycm93ZXJVc2VySWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLndhcm5pbmcoXCJObyBjdXN0b21lciBJRCBmb3VuZCBmb3IgdGhpcyBsb2FuXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBzZXRMb2FkaW5nQ3VzdG9tZXJJZChib3Jyb3dlclVzZXJJZCk7XHJcbiAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaGlkZSA9IG1lc3NhZ2UubG9hZGluZyhcIkxvYWRpbmcgdHJhbnNhY3Rpb25zLi4uXCIsIDApO1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGhhbmRsZVZpZXdUcmFuc2FjdGlvbnMoYm9ycm93ZXJVc2VySWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGhpZGUoKTtcclxuICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gT3B0aW9uYWw6IGhhbmRsZSBlcnJvciAoYWxyZWFkeSBoYW5kbGVkIGluc2lkZSBoYW5kbGVWaWV3VHJhbnNhY3Rpb25zKVxyXG4gICAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldExvYWRpbmdDdXN0b21lcklkKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1ncmF5LTIwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVmlldyBUcmFuc2FjdGlvbnNcIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmdDdXN0b21lcklkID09PSBib3Jyb3dlclVzZXJJZH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7bG9hZGluZ0N1c3RvbWVySWQgPT09IGJvcnJvd2VyVXNlcklkID8gKFxyXG4gICAgICAgICAgICAgICAgICA8QWlPdXRsaW5lTG9hZGluZzNRdWFydGVycyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS01MDAgYW5pbWF0ZS1zcGluXCIgLz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxGaUV5ZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICB7LyogQWdlbnQgc3RhdHVzIGJhZGdlICovfVxyXG4gICAgICAgICAgICAgIHthZ2VudEJhZGdlICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj57YWdlbnRCYWRnZX08L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHsvKiBSZWZlcnJhbCBiYWRnZSAoaGlkZGVuIGlmIGFnZW50IGJhZGdlIGV4aXN0cykgKi99XHJcbiAgICAgICAgICAgICAgeyFhZ2VudEJhZGdlICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQteHMgZm9udC1ib2xkIHB4LTEuNSBweS0xIHJvdW5kZWQtZnVsbCBzaGFkb3ctc20gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7Ym9ycm93ZXI/LnVzZXJfaWQ/LnJlZmVycmFsX3R5cGUgPT09IFwiU2VsZiBKb2luaW5nXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctZW1lcmFsZC0xMDAgdGV4dC1lbWVyYWxkLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWVtZXJhbGQtMjAwIGdyb3VwLWhvdmVyOmJnLWVtZXJhbGQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwiYmctc2xhdGUtMTAwIHRleHQtdmlvbGV0LTgwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLXNsYXRlLTIwMCBncm91cC1ob3ZlcjpiZy1zbGF0ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgYm9ycm93ZXI/LnVzZXJfaWQ/LnJlZmVycmFsX3R5cGUgPT09IFwiU2VsZiBKb2luaW5nXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJUaGlzIGN1c3RvbWVyIGpvaW5lZCB3aXRob3V0IGEgcmVmZXJyYWwuXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJUaGlzIGN1c3RvbWVyIHdhcyByZWZlcnJlZCBieSBhbiBleGlzdGluZyBzb3VyY2UuXCJcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7Ym9ycm93ZXI/LnVzZXJfaWQ/LnJlZmVycmFsX3R5cGUgPT09IFwiU2VsZiBKb2luaW5nXCIgPyBcIk5ld1wiIDogXCJFeGlzdGluZ1wifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBsZXQgTG9hbkFtb3VudCA9IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBncm91cFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3JlcXVlc3RlZCcgPyBib3Jyb3dlcj8ucmVxdWVzdGVkX2xvYW5fYW1vdW50IDogYm9ycm93ZXI/LmxvYW5fYW1vdW50fVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgPEZhRWRpdFxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAvLyBpZiAoYm9ycm93ZXI/LmFnZW50X2FwcHJvdmFsX3N0YXR1cyA9PT0gXCJQRU5ESU5HXCIgfHwgYm9ycm93ZXI/LmFnZW50X2FwcHJvdmFsX3N0YXR1cyA9PT0gXCJSRUpFQ1RFRFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgbWVzc2FnZS53YXJuaW5nKFwiTG9hbiBhbW91bnQgY2Fubm90IGJlIGVkaXRlZCBhcyBhZ2VudCBhcHByb3ZhbCBpcyBwZW5kaW5nIG9yIHJlamVjdGVkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAvLyB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVPcGVuTG9hbk1vZGFsKGJvcnJvd2VyKVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkVkaXQgTG9hbiBBbW91bnRcIlxyXG5cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBsZXQgYWRtaW5BcHByb3ZlZCA9IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgIHsvKiBBbW91bnQgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgdGV4dC1zbSBzbTp0ZXh0LWJhc2UgZm9udC1tb25vXCI+XHJcbiAgICAgICAgICAgICAgICAgIOKCuXtib3Jyb3dlcj8uYXBwcm92ZWRfbG9hbl9hbW91bnQ/LnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogU3RhdHVzIEJhZGdlIC0gb25seSBzaG93IGlmIGFwcHJvdmVkX2xvYW5fYW1vdW50IGV4aXN0cyAqL31cclxuICAgICAgICAgICAgICB7Ym9ycm93ZXI/LmFwcHJvdmVkX2xvYW5fYW1vdW50ICYmIGJvcnJvd2VyPy5hcHByb3ZlZF9sb2FuX2Ftb3VudF9zdGF0dXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgXHJcbiAgICAgICAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMiBweS0wLjUgcm91bmRlZC1tZCB0ZXh0LVs5cHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBib3JkZXIgc2hhZG93LXNtIHdoaXRlc3BhY2Utbm93cmFwXHJcbiAgICAgICAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwXHJcbiAgICAgICAgJHtib3Jyb3dlcj8uYXBwcm92ZWRfbG9hbl9hbW91bnRfc3RhdHVzID09PSBcIkFQUFJPVkVEXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlci1lbWVyYWxkLTIwMCBob3ZlcjpiZy1lbWVyYWxkLTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBib3Jyb3dlcj8uYXBwcm92ZWRfbG9hbl9hbW91bnRfc3RhdHVzID09PSBcIlJFSkVDVEVEXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgdGV4dC1yZWQtNzAwIGJvcmRlci1yZWQtMjAwIGhvdmVyOmJnLXJlZC0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWFtYmVyLTUwIHRleHQtYW1iZXItNzAwIGJvcmRlci1hbWJlci0yMDAgaG92ZXI6YmctYW1iZXItMTAwXCJcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICBgfT5cclxuICAgICAgICAgICAgICAgICAge2JvcnJvd2VyPy5hcHByb3ZlZF9sb2FuX2Ftb3VudF9zdGF0dXMgPT09IFwiQVBQUk9WRURcIiAmJiA8RmFUaHVtYnNVcCBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz59XHJcbiAgICAgICAgICAgICAgICAgIHtib3Jyb3dlcj8uYXBwcm92ZWRfbG9hbl9hbW91bnRfc3RhdHVzID09PSBcIlJFSkVDVEVEXCIgJiYgPEZhVGltZXNDaXJjbGUgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+fVxyXG4gICAgICAgICAgICAgICAgICB7Ym9ycm93ZXI/LmFwcHJvdmVkX2xvYW5fYW1vdW50X3N0YXR1cyA9PT0gXCJQRU5ESU5HXCIgJiYgPEZhSG91cmdsYXNzSGFsZiBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz59XHJcbiAgICAgICAgICAgICAgICAgIHtib3Jyb3dlcj8uYXBwcm92ZWRfbG9hbl9hbW91bnRfc3RhdHVzID09PSBcIkFQUFJPVkVEXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwiQ3VzdG9tZXIgQWNjZXB0ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogYm9ycm93ZXI/LmFwcHJvdmVkX2xvYW5fYW1vdW50X3N0YXR1cyA9PT0gXCJSRUpFQ1RFRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiQ3VzdG9tZXIgUmVqZWN0ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIkN1c3RvbWVyIFNpZGUgUGVuZGluZ1wiXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgLy8gLS0tIFJlcXVlc3RzIFRhYiAtLS1cclxuICAgICAgICAgIGlmIChhY3RpdmVUYWIgPT09IFwicmVxdWVzdHNcIikge1xyXG4gICAgICAgICAgICAvLyAtLS0gSW5zaWRlIHRoZSBcInJlcXVlc3RzXCIgdGFiIG1hcHBpbmcgLS0tXHJcblxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IGJvcnJvd2VyLl9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIF9zZWFyY2hOYW1lOiBib3Jyb3dlcj8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IGJvcnJvd2VyPy51c2VyPy5mdWxsX25hbWUgfHwgYm9ycm93ZXI/LmJvcnJvd2VyPy5mdWxsX25hbWUgfHwgXCJVbmtub3duXCIsXHJcbiAgICAgICAgICAgICAgbG9hbl9pZDogZ2V0Rm9ybWF0dGVkTG9hbklkKGJvcnJvd2VyPy5sb2FuX2lkLCBhY3RpdmVUYWIpLFxyXG4gICAgICAgICAgICAgIGN1c3RvbWVyX25hbWU6IGN1c3RvbWVyTmFtZSxcclxuICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGJvcnJvd2VyPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgYm9ycm93ZXI/LmJvcnJvd2VyPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgcmVmZXJyZWRfYnk6IGJ1aWxkUmVmZXJyZWRCeShib3Jyb3dlciksXHJcbiAgICAgICAgICAgICAgYWRtaW5fYXBwcm92ZWRfYW1vdW50OiBhZG1pbkFwcHJvdmVkLFxyXG4gICAgICAgICAgICAgIGVtcGxveWVlX2FwcHJvdmVkX2Ftb3VudDogYm9ycm93ZXI/LmVtcGxveWVlX2FwcHJvdmVkX2Ftb3VudCB8fCBcIi1cIixcclxuICAgICAgICAgICAgICBlbXBsb3llZV9yZW1hcms6IGJvcnJvd2VyPy5lbXBsb3llZV9yZW1hcmsgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgYWRkcmVzczogYm9ycm93ZXI/LnVzZXJfaWQ/LmFkZHJlc3MgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgbG9hbl9hbW91bnQ6IExvYW5BbW91bnQsXHJcbiAgICAgICAgICAgICAgbG9hbl9wdXJwb3NlOiBib3Jyb3dlcj8ubG9hbl9wdXJwb3NlLFxyXG4gICAgICAgICAgICAgIGNyZWF0ZWRBdDogYm9ycm93ZXI/LmNyZWF0ZWRBdCA/IG5ldyBEYXRlKGJvcnJvd2VyLmNyZWF0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tSU5cIikgOiBcIi1cIixcclxuICAgICAgICAgICAgICBjcmVhdGVkQnk6IFtcclxuICAgICAgICAgICAgICAgIGJvcnJvd2VyPy5jcmVhdGVkX2J5XHJcbiAgICAgICAgICAgICAgICAgID8gYCR7Ym9ycm93ZXIuY3JlYXRlZF9ieS5uYW1lfWBcclxuICAgICAgICAgICAgICAgICAgOiBudWxsLFxyXG5cclxuICAgICAgICAgICAgICAgIGJvcnJvd2VyPy51cGRhdGVkX2J5XHJcbiAgICAgICAgICAgICAgICAgID8gYFVwZGF0ZWQ6ICR7Ym9ycm93ZXIudXBkYXRlZF9ieS5uYW1lfWBcclxuICAgICAgICAgICAgICAgICAgOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgYm9ycm93ZXI/LnNvdXJjZVxyXG4gICAgICAgICAgICAgIF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgfCBcIikgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgYXBwcm92YWxfc3RhdHVzOiA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcHgtMyBweS0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC15ZWxsb3ctODAwIGJnLXllbGxvdy0xMDAgcm91bmRlZC1mdWxsXCI+UmVxdWVzdGVkPC9zcGFuPixcclxuICAgICAgICAgICAgICBhY3Rpb246IGFjdGlvbkRyb3Bkb3duLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIC8vIC0tLSBVbmtub3duIFRhYiAtLS1cclxuICAgICAgICAgIGlmIChhY3RpdmVUYWIgPT09IFwidW5rbm93blwiKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBfc2VhcmNoTmFtZTogYm9ycm93ZXI/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBib3Jyb3dlcj8udXNlcj8uZnVsbF9uYW1lIHx8IGJvcnJvd2VyPy5ib3Jyb3dlcj8uZnVsbF9uYW1lIHx8IFwiVW5rbm93blwiLFxyXG4gICAgICAgICAgICAgIF9pZDogYm9ycm93ZXIuX2lkLFxyXG4gICAgICAgICAgICAgIGxvYW5faWQ6IGdldEZvcm1hdHRlZExvYW5JZChib3Jyb3dlcj8ubG9hbl9pZCwgYWN0aXZlVGFiKSxcclxuICAgICAgICAgICAgICByZWZlcnJlZF9ieTogYnVpbGRSZWZlcnJlZEJ5KGJvcnJvd2VyKSxcclxuICAgICAgICAgICAgICBlbXBsb3llZV9yZW1hcms6IGJvcnJvd2VyPy5lbXBsb3llZV9yZW1hcmsgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgZnVsbF9uYW1lOiBjdXN0b21lck5hbWUgfHwgXCJVbmtub3duXCIsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBib3Jyb3dlcj8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IGJvcnJvd2VyPy5ib3Jyb3dlcj8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgIGFkZHJlc3M6IGJvcnJvd2VyPy51c2VyX2lkPy5hZGRyZXNzIHx8IGJvcnJvd2VyPy5ib3Jyb3dlcj8uYWRkcmVzcyB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAvLyBsb2FuX2Ftb3VudDogYm9ycm93ZXI/LmxvYW5fYW1vdW50LFxyXG4gICAgICAgICAgICAgIGxvYW5fYW1vdW50OiBMb2FuQW1vdW50LFxyXG4gICAgICAgICAgICAgIGFkbWluX2FwcHJvdmVkX2Ftb3VudDogYWRtaW5BcHByb3ZlZCxcclxuICAgICAgICAgICAgICBlbXBsb3llZV9hcHByb3ZlZF9hbW91bnQ6IGJvcnJvd2VyPy5lbXBsb3llZV9hcHByb3ZlZF9hbW91bnQgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgbG9hbl9wdXJwb3NlOiBib3Jyb3dlcj8ubG9hbl9wdXJwb3NlLFxyXG4gICAgICAgICAgICAgIGNyZWF0ZWRCeTogYm9ycm93ZXI/LmNyZWF0ZWRfYnlcclxuICAgICAgICAgICAgICAgID8gW1xyXG4gICAgICAgICAgICAgICAgICBib3Jyb3dlci5jcmVhdGVkX2J5Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIGJvcnJvd2VyLmNyZWF0ZWRfYnkuYWRtaW5fbmFtZSAmJiBgKCR7Ym9ycm93ZXIuY3JlYXRlZF9ieS5hZG1pbl9uYW1lfSlgLFxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXHJcbiAgICAgICAgICAgICAgICAgIC5qb2luKFwiIFwiKVxyXG4gICAgICAgICAgICAgICAgOiBcIi1cIixcclxuICAgICAgICAgICAgICBjcmVhdGVkQXQ6IGJvcnJvd2VyPy5jcmVhdGVkQXQgPyBuZXcgRGF0ZShib3Jyb3dlci5jcmVhdGVkQXQpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIpIDogXCItXCIsXHJcbiAgICAgICAgICAgICAgYWN0aW9uOiBhY3Rpb25Ecm9wZG93bixcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAvLyAtLS0gT3RoZXIgVGFicyAoYWNjZXB0ZWQsIHBlbmRpbmcsIGFwcHJvdmVkLCByZWplY3RlZCwgY29tcGxldGVkLCBjbG9zZWQpIC0tLVxyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgX2lkOiBib3Jyb3dlci5faWQsXHJcbiAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIGxvYW5faWQ6IGdldEZvcm1hdHRlZExvYW5JZChib3Jyb3dlcj8ubG9hbl9pZCwgYWN0aXZlVGFiKSxcclxuICAgICAgICAgICAgX3NlYXJjaE5hbWU6IGJvcnJvd2VyPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgYm9ycm93ZXI/LnVzZXI/LmZ1bGxfbmFtZSB8fCBib3Jyb3dlcj8uYm9ycm93ZXI/LmZ1bGxfbmFtZSB8fCBcIlVua25vd25cIixcclxuICAgICAgICAgICAgY3JlYXRlZEF0OiBib3Jyb3dlcj8uY3JlYXRlZEF0ID8gbmV3IERhdGUoYm9ycm93ZXIuY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1JTlwiKSA6IFwiLVwiLFxyXG4gICAgICAgICAgICBjcmVhdGVkQnk6IGJvcnJvd2VyPy5jcmVhdGVkX2J5XHJcbiAgICAgICAgICAgICAgPyBbXHJcbiAgICAgICAgICAgICAgICBib3Jyb3dlci5jcmVhdGVkX2J5Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICBib3Jyb3dlci5jcmVhdGVkX2J5LmFkbWluX25hbWUgJiYgYCgke2JvcnJvd2VyLmNyZWF0ZWRfYnkuYWRtaW5fbmFtZX0pYCxcclxuICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXHJcbiAgICAgICAgICAgICAgICAuam9pbihcIiBcIilcclxuICAgICAgICAgICAgICA6IFwiLVwiLFxyXG4gICAgICAgICAgICBib3Jyb3dlcl9uYW1lOiBhY3RpdmVUYWIgPT09ICdjb21wbGV0ZWQnIHx8IGFjdGl2ZVRhYiA9PT0gJ2Nsb3NlZCcgPyBib3Jyb3dlcj8uYm9ycm93ZXI/LmZ1bGxfbmFtZSA6IGN1c3RvbWVyTmFtZSxcclxuICAgICAgICAgICAgZGF0ZTogYm9ycm93ZXI/LmNyZWF0ZWRBdCxcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBib3Jyb3dlcj8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IGJvcnJvd2VyPy5ib3Jyb3dlcj8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICBsb2FuX2Ftb3VudDogYWN0aXZlVGFiID09PSAnY29tcGxldGVkJyB8fCBhY3RpdmVUYWIgPT09ICdjbG9zZWQnID8gYm9ycm93ZXI/LmxvYW5fYW1vdW50IDogTG9hbkFtb3VudCxcclxuICAgICAgICAgICAgdGVudXJlOiBib3Jyb3dlcj8udGVudXJlLFxyXG4gICAgICAgICAgICBzZXJ2aWNlX2NoYXJnZXM6IGJvcnJvd2VyPy5zZXJ2aWNlX2NoYXJnZXMsXHJcbiAgICAgICAgICAgIGxvYW5fc2FuY3Rpb25fZGF0ZTogYm9ycm93ZXI/LmxvYW5fc2FuY3Rpb25fZGF0ZT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgICBkb2N1bWVudF9jaGFyZ2VzOiBib3Jyb3dlcj8uZG9jdW1lbnRfY2hhcmdlcyxcclxuICAgICAgICAgICAgZGFpbHlfcGF5bWVudF9hbW91bnQ6IGJvcnJvd2VyPy5kYWlseV9wYXltZW50X2Ftb3VudCxcclxuICAgICAgICAgICAgc3RhcnRfZGF0ZTogYm9ycm93ZXI/LnN0YXJ0X2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgZW5kX2RhdGU6IGJvcnJvd2VyPy5lbmRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgICBub3RlOiBib3Jyb3dlcj8ubm90ZSxcclxuICAgICAgICAgICAgcmVmZXJyZWRfdHlwZTogYm9ycm93ZXI/LnJlZmVycmVkX3R5cGUsXHJcbiAgICAgICAgICAgIGFkbWluX2FwcHJvdmVkX2Ftb3VudDogYWRtaW5BcHByb3ZlZCxcclxuICAgICAgICAgICAgZW1wbG95ZWVfYXBwcm92ZWRfYW1vdW50OiBib3Jyb3dlcj8uZW1wbG95ZWVfYXBwcm92ZWRfYW1vdW50IHx8IFwiLVwiLFxyXG4gICAgICAgICAgICBlbXBsb3llZV9yZW1hcms6IGJvcnJvd2VyPy5lbXBsb3llZV9yZW1hcmsgfHwgXCItXCIsXHJcbiAgICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czogYm9ycm93ZXI/LmFwcHJvdmFsX3N0YXR1cyB8fCBcIlBFTkRJTkdcIixcclxuICAgICAgICAgICAgZXh0cmFfY2hhcmdlc19kaXNwbGF5OiAoKCkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGNoYXJnZXMgPSBib3Jyb3dlcj8uZXh0cmFfY2hhcmdlcyB8fCBbXTtcclxuICAgICAgICAgICAgICBpZiAoY2hhcmdlcy5sZW5ndGggPT09IDApIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQteHNcIj5Ob25lPC9zcGFuPjtcclxuICAgICAgICAgICAgICBjb25zdCB0b3RhbE91dHN0YW5kaW5nID0gY2hhcmdlcy5yZWR1Y2UoKHN1bSwgYykgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKGMucGFpZCA9PT0gdHJ1ZSkgcmV0dXJuIHN1bTsgICAgICAgICAgICAgICAgICAgIC8vIEZ1bGx5IHBhaWQg4oaSIDBcclxuICAgICAgICAgICAgICAgIGlmIChjLmJhbGFuY2VfYW1vdW50ICE9PSB1bmRlZmluZWQpIHJldHVybiBzdW0gKyBOdW1iZXIoYy5iYWxhbmNlX2Ftb3VudCk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwYWlkID0gTnVtYmVyKGMucGFpZF9hbW91bnQgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBhbW91bnQgPSBOdW1iZXIoYy5hbW91bnQgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gc3VtICsgKGFtb3VudCAtIHBhaWQpO1xyXG4gICAgICAgICAgICAgIH0sIDApO1xyXG5cclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIE91dHN0YW5kaW5nOiDigrl7dG90YWxPdXRzdGFuZGluZy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSkoKSxcclxuICAgICAgICAgICAgcmVmZXJyZWRfYnk6IGJ1aWxkUmVmZXJyZWRCeShib3Jyb3dlciksXHJcbiAgICAgICAgICAgIGFjdGlvbjogYWN0aW9uRHJvcGRvd24sXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFRhYmxlQm9ycm93ZXJzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIGlmICghcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMCkgc2V0RmV0Y2hFcnJvcih0cnVlKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbG9hbiBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmV0Y2hFcnJvcih0cnVlKTtcclxuICAgICAgICBzZXRUYWJsZUJvcnJvd2VycyhbXSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoeyB2aXNpYmlsaXR5OiB0cnVlLCBtZXNzYWdlOiBcIkZhaWxlZCB0byBmZXRjaCBsb2FuIGRhdGEuIFBsZWFzZSB0cnkgYWdhaW4uXCIsIHR5cGU6IFwiZXJyb3JcIiB9KTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hCb3Jyb3dlcnMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlciwgYWN0aXZlVGFiXSk7XHJcblxyXG4gIC8vIC0tLSBGb3JtIGhhbmRsZXJzICAtLS1cclxuICAvLyBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gIC8vICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gIC8vICAgICAuLi5wcmV2RGF0YSxcclxuICAvLyAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgLy8gICB9KSk7XHJcbiAgLy8gICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7XHJcbiAgLy8gICAgIC4uLnByZXZFcnJvcnMsXHJcbiAgLy8gICAgIFtmaWVsZF06IFwiXCIsXHJcbiAgLy8gICB9KSk7XHJcbiAgLy8gfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICBbZmllbGRdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIC8vIPCfn6IgQXV0by1maWxsIHJlZmVycmFsIGRldGFpbHMgd2hlbiBib3Jyb3dlciBpcyBzZWxlY3RlZFxyXG4gICAgaWYgKGZpZWxkID09PSBcImJvcnJvd2VyXCIgJiYgdmFsdWUpIHtcclxuICAgICAgY29uc3Qgc2VsZWN0ZWRVc2VyID0gdXNlcnMuZmluZCgodXNlcikgPT4gdXNlci5faWQgPT09IHZhbHVlKTtcclxuICAgICAgaWYgKHNlbGVjdGVkVXNlcikge1xyXG4gICAgICAgIGNvbnN0IHJlZlR5cGUgPSBzZWxlY3RlZFVzZXIucmVmZXJyYWxfdHlwZSB8fCBcIlNlbGYgSm9pbmluZ1wiO1xyXG4gICAgICAgIC8vIFVwZGF0ZSByZWZlcnJhbCB0eXBlXHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgcmVmZXJyZWRfdHlwZTogcmVmVHlwZSxcclxuICAgICAgICAgIC8vIFJlc2V0IHJlZmVycmFsIHNwZWNpZmljIGZpZWxkc1xyXG4gICAgICAgICAgcmVmZXJyZWRfZW1wbG95ZWU6IFwiXCIsXHJcbiAgICAgICAgICByZWZlcnJlZF9hZ2VudDogXCJcIixcclxuICAgICAgICAgIHJlZmVycmVkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgLy8gU2V0IHRoZSBzcGVjaWZpYyByZWZlcnJhbCBmaWVsZCBiYXNlZCBvbiB0eXBlXHJcbiAgICAgICAgaWYgKHJlZlR5cGUgPT09IFwiRW1wbG95ZWVcIiAmJiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfZW1wbG95ZWU/Ll9pZCkge1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIHJlZmVycmVkX2VtcGxveWVlOiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfZW1wbG95ZWUuX2lkLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocmVmVHlwZSA9PT0gXCJBZ2VudFwiICYmIHNlbGVjdGVkVXNlci5yZWZlcnJlZF9hZ2VudD8uX2lkKSB7XHJcbiAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgcmVmZXJyZWRfYWdlbnQ6IHNlbGVjdGVkVXNlci5yZWZlcnJlZF9hZ2VudC5faWQsXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChyZWZUeXBlID09PSBcIkN1c3RvbWVyXCIgJiYgc2VsZWN0ZWRVc2VyLnJlZmVycmVkX2N1c3RvbWVyPy5faWQpIHtcclxuICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICByZWZlcnJlZF9jdXN0b21lcjogc2VsZWN0ZWRVc2VyLnJlZmVycmVkX2N1c3RvbWVyLl9pZCxcclxuICAgICAgICAgIH0pKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gRm9yIFwiU2VsZiBKb2luaW5nXCIgb3IgXCJPdGhlcnNcIiwgdGhlIHNwZWNpZmljIGZpZWxkcyBzdGF5IG51bGwvZW1wdHlcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudElucHV0RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoeyAuLi5wcmV2RXJyb3JzLCBbZmllbGRdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBjb25zdCB1cGRhdGVkRm9ybSA9IHsgLi4uZm9ybURhdGEsIFtuYW1lXTogdmFsdWUgfTtcclxuICAgIHNldEZvcm1EYXRhKHVwZGF0ZWRGb3JtKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiBcIlwiIH0pKTtcclxuICAgIGNvbnN0IHNhbmN0aW9uRGF0ZSA9IG5ldyBEYXRlKHVwZGF0ZWRGb3JtLmxvYW5fc2FuY3Rpb25fZGF0ZSk7XHJcbiAgICBjb25zdCBzdGFydERhdGUgPSBuZXcgRGF0ZSh1cGRhdGVkRm9ybS5zdGFydF9kYXRlKTtcclxuICAgIGlmIChcclxuICAgICAgdXBkYXRlZEZvcm0ubG9hbl9zYW5jdGlvbl9kYXRlICYmXHJcbiAgICAgIHVwZGF0ZWRGb3JtLnN0YXJ0X2RhdGUgJiZcclxuICAgICAgc3RhcnREYXRlIDwgc2FuY3Rpb25EYXRlXHJcbiAgICApIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJTdGFydCBkYXRlIHNob3VsZCBiZSBncmVhdGVyIHRoYW4gc2FuY3Rpb24gZGF0ZVwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkQm9ycm93ZXJcIiA/IGZvcm1EYXRhIDogdXBkYXRlRm9ybURhdGE7XHJcbiAgICBpZiAoIWRhdGEuYm9ycm93ZXIpIG5ld0Vycm9ycy5ib3Jyb3dlciA9IFwiQm9ycm93ZXIgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFkYXRhLmxvYW5fYW1vdW50IHx8IGlzTmFOKGRhdGEubG9hbl9hbW91bnQpIHx8IGRhdGEubG9hbl9hbW91bnQgPD0gMClcclxuICAgICAgbmV3RXJyb3JzLmxvYW5fYW1vdW50ID0gXCJMb2FuIEFtb3VudCBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyXCI7XHJcbiAgICBpZiAoIWRhdGEudGVudXJlIHx8IGlzTmFOKGRhdGEudGVudXJlKSB8fCBkYXRhLnRlbnVyZSA8PSAwKVxyXG4gICAgICBuZXdFcnJvcnMudGVudXJlID0gXCJUZW51cmUgbXVzdCBiZSBhIHBvc2l0aXZlIG51bWJlclwiO1xyXG4gICAgaWYgKCFkYXRhLnNlcnZpY2VfY2hhcmdlcykgbmV3RXJyb3JzLnNlcnZpY2VfY2hhcmdlcyA9IFwic2VydmljZSBjaGFyZ2VzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBpZiAoIWRhdGEuZGFpbHlfcGF5bWVudF9hbW91bnQpIG5ld0Vycm9ycy5kYWlseV9wYXltZW50X2Ftb3VudCA9IFwiRGFpbHkgcGF5bWVudCBhbW91bnQgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZGF0YS5kb2N1bWVudF9jaGFyZ2VzKSBuZXdFcnJvcnMuZG9jdW1lbnRfY2hhcmdlcyA9IFwiRG9jdW1lbnQgQ2hhcmdlcyBpcyBSZXF1aXJlZFwiO1xyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgLy8gRm9yIEFkZCBMb2FuIG1vZGFsXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChmb3JtRGF0YS5sb2FuX2Ftb3VudCkge1xyXG4gICAgICBjb25zdCBhbW91bnQgPSBOdW1iZXIoZm9ybURhdGEubG9hbl9hbW91bnQpO1xyXG4gICAgICBjb25zdCB0ZW51cmUgPSBOdW1iZXIoZm9ybURhdGEudGVudXJlKTtcclxuICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgc2VydmljZV9jaGFyZ2VzOiAoYW1vdW50ICogMC4xKS50b0ZpeGVkKDApLFxyXG4gICAgICAgIGRvY3VtZW50X2NoYXJnZXM6IChhbW91bnQgKiAwLjAxKS50b0ZpeGVkKDApLFxyXG4gICAgICAgIC4uLih0ZW51cmUgPiAwICYmIHsgZGFpbHlfcGF5bWVudF9hbW91bnQ6IChhbW91bnQgLyB0ZW51cmUpLnRvRml4ZWQoMCkgfSksXHJcbiAgICAgIH0pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgc2VydmljZV9jaGFyZ2VzOiBcIlwiLCBkb2N1bWVudF9jaGFyZ2VzOiBcIlwiLCBkYWlseV9wYXltZW50X2Ftb3VudDogXCJcIiwgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtmb3JtRGF0YS5sb2FuX2Ftb3VudCwgZm9ybURhdGEudGVudXJlXSk7XHJcblxyXG4gIC8vIEZvciBVcGRhdGUgTG9hbiBtb2RhbFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAodXBkYXRlRm9ybURhdGEubG9hbl9hbW91bnQpIHtcclxuICAgICAgY29uc3QgYW1vdW50ID0gTnVtYmVyKHVwZGF0ZUZvcm1EYXRhLmxvYW5fYW1vdW50KTtcclxuICAgICAgY29uc3QgdGVudXJlID0gTnVtYmVyKHVwZGF0ZUZvcm1EYXRhLnRlbnVyZSk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHNlcnZpY2VfY2hhcmdlczogKGFtb3VudCAqIDAuMSkudG9GaXhlZCgwKSxcclxuICAgICAgICBkb2N1bWVudF9jaGFyZ2VzOiAoYW1vdW50ICogMC4wMSkudG9GaXhlZCgwKSxcclxuICAgICAgICAuLi4odGVudXJlID4gMCAmJiB7IGRhaWx5X3BheW1lbnRfYW1vdW50OiAoYW1vdW50IC8gdGVudXJlKS50b0ZpeGVkKDApIH0pLFxyXG4gICAgICB9KSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHNlcnZpY2VfY2hhcmdlczogXCJcIiwgZG9jdW1lbnRfY2hhcmdlczogXCJcIiwgZGFpbHlfcGF5bWVudF9hbW91bnQ6IFwiXCIsIH0pKTtcclxuICAgIH1cclxuICB9LCBbdXBkYXRlRm9ybURhdGEubG9hbl9hbW91bnQsIHVwZGF0ZUZvcm1EYXRhLnRlbnVyZV0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJhZGRCb3Jyb3dlclwiKTtcclxuXHJcbiAgICBpZiAoIWlzVmFsaWQpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBGaXJzdCBBUEkgLSBDcmVhdGUgTG9hblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFxyXG4gICAgICAgIFwiL3YxL2FkbWluL2xvYW5zXCIsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICBjcmVhdGVkX2J5OiBnZXRBZG1pbklkKCksXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9XHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBHZXQgTG9hbiBJRCBmcm9tIHJlc3BvbnNlXHJcbiAgICAgIGNvbnN0IGxvYW5JZCA9XHJcbiAgICAgICAgcmVzcG9uc2U/LmRhdGE/LmRhdGE/Ll9pZCB8fFxyXG4gICAgICAgIHJlc3BvbnNlPy5kYXRhPy5sb2FuPy5faWQgfHxcclxuICAgICAgICByZXNwb25zZT8uZGF0YT8uX2lkO1xyXG5cclxuICAgICAgLy8gU2Vjb25kIEFQSSAtIENyZWF0ZSBMb2FuIERvY3VtZW50XHJcbiAgICAgIGlmIChsb2FuSWQpIHtcclxuICAgICAgICBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICAgIFwiL3YxL2FkbWluL2xvYW4tZG9jdW1lbnRzXCIsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxvYW5JZCxcclxuICAgICAgICAgICAgc3RhdHVzOiBcIlBlbmRpbmdcIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcblxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkJvcnJvd2VyIEFkZGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcblxyXG4gICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgYm9ycm93ZXI6IFwiXCIsXHJcbiAgICAgICAgbG9hbl9hbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgdGVudXJlOiBcIlwiLFxyXG4gICAgICAgIHNlcnZpY2VfY2hhcmdlczogXCJcIixcclxuICAgICAgICBkb2N1bWVudF9jaGFyZ2VzOiBcIlwiLFxyXG4gICAgICAgIGRhaWx5X3BheW1lbnRfYW1vdW50OiBcIlwiLFxyXG4gICAgICAgIG5vdGU6IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfZW1wbG95ZWU6IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfYWdlbnQ6IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfdHlwZTogXCJcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIEJvcnJvd2VyOlwiLCBlcnJvcik7XHJcblxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBhZGQgYm9ycm93ZXJcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jIChib3Jyb3dlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYGxvYW5zL2dldC1ib3Jyb3dlci8ke2JvcnJvd2VySWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRCb3Jyb3dlcihyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIEJvcnJvd2VyczpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBmZXRjaCBib3Jyb3dlciBkZXRhaWxzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAoYm9ycm93ZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvbG9hbnMvZ2V0LWJvcnJvd2VyLyR7Ym9ycm93ZXJJZH1gKTtcclxuICAgICAgY29uc3QgYm9ycm93ZXJEYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkU3RhcnREYXRlID0gYm9ycm93ZXJEYXRhPy5zdGFydF9kYXRlPy5zcGxpdChcIlRcIilbMF07XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZEVuZERhdGUgPSBib3Jyb3dlckRhdGE/LmVuZF9kYXRlPy5zcGxpdChcIlRcIilbMF07XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZFNhbmN0aW9uRGF0ZSA9IGJvcnJvd2VyRGF0YT8ubG9hbl9zYW5jdGlvbl9kYXRlPy5zcGxpdChcIlRcIilbMF07XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVCb3Jyb3dlcihyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIGJvcnJvd2VyOiByZXNwb25zZT8uZGF0YT8uYm9ycm93ZXIuX2lkLFxyXG4gICAgICAgIGxvYW5fYW1vdW50OiByZXNwb25zZT8uZGF0YT8ubG9hbl9hbW91bnQsXHJcbiAgICAgICAgYXBwbGllZF9vbjogcmVzcG9uc2U/LmRhdGE/LmNyZWF0ZWRBdCxcclxuICAgICAgICB0ZW51cmU6IHJlc3BvbnNlPy5kYXRhPy50ZW51cmUsXHJcbiAgICAgICAgc2VydmljZV9jaGFyZ2VzOiByZXNwb25zZT8uZGF0YT8uc2VydmljZV9jaGFyZ2VzLFxyXG4gICAgICAgIGRvY3VtZW50X2NoYXJnZXM6IHJlc3BvbnNlPy5kYXRhPy5kb2N1bWVudF9jaGFyZ2VzLFxyXG4gICAgICAgIGxvYW5fc2FuY3Rpb25fZGF0ZTogZm9ybWF0dGVkU2FuY3Rpb25EYXRlLFxyXG4gICAgICAgIGRhaWx5X3BheW1lbnRfYW1vdW50OiByZXNwb25zZT8uZGF0YT8uZGFpbHlfcGF5bWVudF9hbW91bnQsXHJcbiAgICAgICAgc3RhcnRfZGF0ZTogZm9ybWF0dGVkU3RhcnREYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlOiBmb3JtYXR0ZWRFbmREYXRlLFxyXG4gICAgICAgIG5vdGU6IHJlc3BvbnNlPy5kYXRhPy5ub3RlLFxyXG4gICAgICAgIHJlZmVycmVkX2VtcGxveWVlOiByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfZW1wbG95ZWU/Ll9pZCB8fCBcIlwiLFxyXG4gICAgICAgIHJlZmVycmVkX2N1c3RvbWVyOiByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfY3VzdG9tZXI/Ll9pZCB8fCBcIlwiLFxyXG4gICAgICAgIHJlZmVycmVkX2FnZW50OiByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfYWdlbnQ/Ll9pZCB8fCBcIlwiLFxyXG4gICAgICAgIHJlZmVycmVkX3R5cGU6IHJlc3BvbnNlPy5kYXRhPy5yZWZlcnJlZF90eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgYXBwcm92YWxfc3RhdHVzOiByZXNwb25zZT8uZGF0YT8uYXBwcm92YWxfc3RhdHVzIHx8IFwiQVBQUk9WRURcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cDpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBmZXRjaCBib3Jyb3dlciBkZXRhaWxzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHsgLi4ucHJldkRhdGEsIFtuYW1lXTogdmFsdWUgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IFwiXCIgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUJvcnJvd2VyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRCb3Jyb3dlcikge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9sb2Fucy9kZWxldGUtYm9ycm93ZXIvJHtjdXJyZW50Qm9ycm93ZXIuX2lkfWApO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiQm9ycm93ZXIgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50Qm9ycm93ZXIobnVsbCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIExvYW4gQm9ycm93ZXI6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gZGVsZXRlIGJvcnJvd2VyXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG4gICAgaWYgKCFpc1ZhbGlkKSB7XHJcbiAgICAgIC8vIFNob3cgdmFsaWRhdGlvbiBlcnJvcnMgYW5kIHN0YXkgb24gbW9kYWxcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnB1dChgL3YxL2FkbWluL2xvYW5zLyR7Y3VycmVudFVwZGF0ZUJvcnJvd2VyLl9pZH1gLCB7XHJcbiAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgdXBkYXRlZF9ieTogZ2V0QWRtaW5JZCgpLCAvLyDinIVcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICBtZXNzYWdlOiBcIkJvcnJvd2VyIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldElzTG9hblVwZGF0ZWQodHJ1ZSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBCb3Jyb3dlcjpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byB1cGRhdGUgYm9ycm93ZXJcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgLy8gLS0tIENvbHVtbiBkZWZpbml0aW9ucyAodW5jaGFuZ2VkKSAtLS1cclxuICBjb25zdCByZXF1ZXN0Q29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC5OT1wiIH0sXHJcbiAgICB7IGtleTogXCJjcmVhdGVkQXRcIiwgaGVhZGVyOiBcIkFwcGxpZWQgT25cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZF9ieVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbl9hbW91bnRcIiwgaGVhZGVyOiBcIkxvYW4gQW1vdW50IFJlcXVlc3RlZFwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZV9hcHByb3ZlZF9hbW91bnRcIiwgaGVhZGVyOiBcIkFnZW50IEFwcHJvdmVkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJhZG1pbl9hcHByb3ZlZF9hbW91bnRcIiwgaGVhZGVyOiBcIkFkbWluIEFwcHJvdmVkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZV9yZW1hcmtcIiwgaGVhZGVyOiBcIkVtcGxveWVlIFJlbWFya1wiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuX3B1cnBvc2VcIiwgaGVhZGVyOiBcIkxvYW4gUHVycG9zZVwiIH0sXHJcbiAgICB7IGtleTogXCJhZGRyZXNzXCIsIGhlYWRlcjogXCJBZGRyZXNzXCIgfSxcclxuICAgIHsga2V5OiBcImFwcHJvdmFsX3N0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcImNyZWF0ZWRCeVwiLCBoZWFkZXI6IFwiQ3JlYXRlZC9VcGRhdGVkIEJ5XCIsIHdpZHRoOiAxMjAgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uc1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdW5rbm93bkNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3JlYXRlZEF0XCIsIGhlYWRlcjogXCJBcHBsaWVkIE9uXCIgfSxcclxuICAgIHsga2V5OiBcImZ1bGxfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZF9ieVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbl9hbW91bnRcIiwgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlX2FwcHJvdmVkX2Ftb3VudFwiLCBoZWFkZXI6IFwiQWdlbnQgQXBwcm92ZWQgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImFkbWluX2FwcHJvdmVkX2Ftb3VudFwiLCBoZWFkZXI6IFwiQWRtaW4gQXBwcm92ZWQgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlX3JlbWFya1wiLCBoZWFkZXI6IFwiRW1wbG95ZWUgUmVtYXJrXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5fcHVycG9zZVwiLCBoZWFkZXI6IFwiTG9hbiBQdXJwb3NlXCIgfSxcclxuICAgIHsga2V5OiBcImFkZHJlc3NcIiwgaGVhZGVyOiBcIkFkZHJlc3NcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3JlYXRlZEJ5XCIsIGhlYWRlcjogXCJDcmVhdGVkL1VwZGF0ZWQgQnlcIiwgd2lkdGg6IDEyMCB9LFxyXG4gICAgeyBrZXk6IFwiYXBwcm92YWxfc3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25zXCIgfSxcclxuICBdO1xyXG4gIGNvbnN0IG90aGVyQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3JlYXRlZEF0XCIsIGhlYWRlcjogXCJBcHBsaWVkIE9uXCIgfSxcclxuICAgIHsga2V5OiBcImJvcnJvd2VyX25hbWVcIiwgaGVhZGVyOiBcIkJvcnJvd2VyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgLi4uKGFjdGl2ZVRhYiA9PT0gXCJhcHByb3ZlZFwiIHx8IGFjdGl2ZVRhYiA9PT0gXCJjb21wbGV0ZWRcIiB8fCBhY3RpdmVUYWIgPT09IFwiY2xvc2VkXCJcclxuICAgICAgPyBbeyBrZXk6IFwibG9hbl9pZFwiLCBoZWFkZXI6IFwiTG9hbiBJZFwiIH1dXHJcbiAgICAgIDogW10pLFxyXG4gICAgeyBrZXk6IFwibG9hbl9hbW91bnRcIiwgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlX2FwcHJvdmVkX2Ftb3VudFwiLCBoZWFkZXI6IFwiQWdlbnQgQXBwcm92ZWQgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImFkbWluX2FwcHJvdmVkX2Ftb3VudFwiLCBoZWFkZXI6IFwiQWRtaW4gQXBwcm92ZWQgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInRlbnVyZVwiLCBoZWFkZXI6IFwiVGVudXJlXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkX2J5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJzZXJ2aWNlX2NoYXJnZXNcIiwgaGVhZGVyOiBcIlNlcnZpY2UgQ2hhcmdlc1wiIH0sXHJcbiAgICB7IGtleTogXCJkb2N1bWVudF9jaGFyZ2VzXCIsIGhlYWRlcjogXCJEb2N1bWVudGF0aW9uIENoYXJnZXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiZXh0cmFfY2hhcmdlc19kaXNwbGF5XCIsIGhlYWRlcjogXCJFeHRyYSBDaGFyZ2VzXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5fc2FuY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiU2FuY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJzdGFydF9kYXRlXCIsIGhlYWRlcjogXCJTdGFydCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImVuZF9kYXRlXCIsIGhlYWRlcjogXCJEdWUgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZV9yZW1hcmtcIiwgaGVhZGVyOiBcIkVtcGxveWVlIFJlbWFya1wiIH0sXHJcbiAgICB7IGtleTogXCJjcmVhdGVkQnlcIiwgaGVhZGVyOiBcIkNyZWF0ZWQvVXBkYXRlZCBCeVwiLCB3aWR0aDogMTIwIH0sXHJcbiAgICB7IGtleTogXCJub3RlXCIsIGhlYWRlcjogXCJOb3RlXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdXHJcbiAgLy8gLmZpbHRlcihjb2wgPT4ge1xyXG4gIC8vICAgaWYgKGNvbC5rZXkgPT09IFwiYWN0aW9uXCIpIHtcclxuICAvLyAgICAgcmV0dXJuICEoYWN0aXZlVGFiID09PSBcImNvbXBsZXRlZFwiIHx8IGFjdGl2ZVRhYiA9PT0gXCJjbG9zZWRcIik7XHJcbiAgLy8gICB9XHJcbiAgLy8gICByZXR1cm4gdHJ1ZTtcclxuICAvLyB9KTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJyZXF1ZXN0c1wiKSByZXR1cm4gcmVxdWVzdENvbHVtbnM7XHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSBcInVua25vd25cIikgcmV0dXJuIHVua25vd25Db2x1bW5zO1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJjb21wbGV0ZWRcIiB8fCBhY3RpdmVUYWIgPT09IFwiY2xvc2VkXCIpIHtcclxuICAgICAgcmV0dXJuIG90aGVyQ29sdW1ucy5maWx0ZXIoY29sID0+XHJcbiAgICAgICAgY29sLmtleSAhPT0gXCJlbXBsb3llZV9hcHByb3ZlZF9hbW91bnRcIiAmJiBjb2wua2V5ICE9PSBcImFkbWluX2FwcHJvdmVkX2Ftb3VudFwiXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gb3RoZXJDb2x1bW5zO1xyXG4gIH0sIFthY3RpdmVUYWJdKTtcclxuXHJcbiAgY29uc3QgTm9EYXRhRm91bmQgPSAoKSA9PiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTEyXCI+XHJcbiAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHRleHQtZ3JheS00MDAgbWItNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk05IDEyaDZtLTYgNGg2bTIgNUg3YTIgMiAwIDAxLTItMlY1YTIgMiAwIDAxMi0yaDUuNTg2YTEgMSAwIDAxLjcwNy4yOTNsNS40MTQgNS40MTRhMSAxIDAgMDEuMjkzLjcwN1YxOWEyIDIgMCAwMS0yIDJ6XCIgLz5cclxuICAgICAgPC9zdmc+XHJcbiAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItMlwiPk5vIERhdGEgRm91bmQ8L2gzPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdGV4dC1jZW50ZXJcIj5UaGVyZSBhcmUgbm8ge2FjdGl2ZVRhYn0gbG9hbiByZXF1ZXN0cyBhdCB0aGUgbW9tZW50LjwvcD5cclxuICAgICAge2FjdGl2ZVRhYiA9PT0gXCJwZW5kaW5nXCIgJiYgKFxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsKHRydWUpfSBjbGFzc05hbWU9XCJtdC00IGJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICArIEFkZCBOZXcgTG9hblxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxuXHJcbiAgY29uc3QgVEFCX0NPTkZJRyA9IFtcclxuICAgIHsga2V5OiBcInJlcXVlc3RzXCIsIGxhYmVsOiBcIlJlcXVlc3RzXCIsIGJnQ29sb3I6IFwiYmctb3JhbmdlLTUwMFwiLCBjb3VudEtleTogXCJ0b3RhbFJlcXVlc3RzXCIgfSxcclxuICAgIHsga2V5OiBcImFjY2VwdGVkXCIsIGxhYmVsOiBcIkFjY2VwdGVkXCIsIGJnQ29sb3I6IFwiYmctWyMwMEFDQzFdXCIsIGNvdW50S2V5OiBcInRvdGFsQWNjZXB0ZWRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGVuZGluZ1wiLCBsYWJlbDogXCJQZW5kaW5nXCIsIGJnQ29sb3I6IFwiYmcteWVsbG93LTUwMFwiLCBjb3VudEtleTogXCJ0b3RhbFBlbmRpbmdcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXBwcm92ZWRcIiwgbGFiZWw6IFwiQXBwcm92ZWRcIiwgYmdDb2xvcjogXCJiZy1ncmVlbi01MDBcIiwgY291bnRLZXk6IFwidG90YWxBcHByb3ZlZFwiIH0sXHJcbiAgICB7IGtleTogXCJ1bmtub3duXCIsIGxhYmVsOiBcIlVua25vd25cIiwgYmdDb2xvcjogXCJiZy15ZWxsb3ctOTAwXCIsIGNvdW50S2V5OiBcInRvdGFsVW5rbm93blwiIH0sXHJcbiAgICB7IGtleTogXCJyZWplY3RlZFwiLCBsYWJlbDogXCJSZWplY3RlZFwiLCBiZ0NvbG9yOiBcImJnLXJlZC01MDBcIiwgY291bnRLZXk6IFwidG90YWxSZWplY3RlZFwiIH0sXHJcbiAgICB7IGtleTogXCJjb21wbGV0ZWRcIiwgbGFiZWw6IFwiQ29tcGxldGVkXCIsIGJnQ29sb3I6IFwiYmctZ3JlZW4tOTAwXCIsIGNvdW50S2V5OiBcInRvdGFsQ29tcGxldGVkXCIgfSxcclxuICAgIHsga2V5OiBcImNsb3NlZFwiLCBsYWJlbDogXCJDbG9zZWRcIiwgYmdDb2xvcjogXCJiZy1bIzAwODk3Ql1cIiwgY291bnRLZXk6IFwidG90YWxDbG9zZWRcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHRhYkl0ZW1zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gVEFCX0NPTkZJRy5tYXAoKHRhYikgPT4ge1xyXG4gICAgICBjb25zdCBjb3VudCA9IHRvdGFsc1t0YWIuY291bnRLZXldIHx8IDA7XHJcbiAgICAgIGNvbnN0IGlzRGF0YVJlYWR5ID0gIWlzTG9hZGluZyAmJiAhZmV0Y2hFcnJvciAmJiAoXHJcbiAgICAgICAgZ2xvYmFsU2VhcmNoVGVybSAmJiBnbG9iYWxTZWFyY2hUYXJnZXRUYWIgPT09IHRhYi5rZXlcclxuICAgICAgICAgID8gKGdsb2JhbFNlYXJjaFJlc3VsdHMgIT09IG51bGwgJiYgZ2xvYmFsU2VhcmNoUmVzdWx0cy5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgOiB0YWJsZUJvcnJvd2Vycy5sZW5ndGggPiAwXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBsZXQgdGFibGVEYXRhO1xyXG4gICAgICBpZiAoZ2xvYmFsU2VhcmNoVGVybSAmJiBnbG9iYWxTZWFyY2hUYXJnZXRUYWIgPT09IHRhYi5rZXkpIHtcclxuICAgICAgICB0YWJsZURhdGEgPSBnbG9iYWxTZWFyY2hSZXN1bHRzID8/IFtdO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRhYmxlRGF0YSA9IGZpbHRlck9wdGlvbih0YWJsZUJvcnJvd2Vycywgc2VhcmNoVGV4dCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIE9ubHkgcGFzcyB1cGRhdGVIYW5kbGVyIGZvciBub27igJFjb21wbGV0ZWQvY2xvc2VkIHRhYnNcclxuICAgICAgY29uc3QgYWxsb3dVcGRhdGUgPSBhY3RpdmVUYWIgIT09IFwiY29tcGxldGVkXCIgJiYgYWN0aXZlVGFiICE9PSBcImNsb3NlZFwiO1xyXG4gICAgICBjb25zdCB1cGRhdGVIYW5kbGVyID0gYWxsb3dVcGRhdGUgPyBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gOiB1bmRlZmluZWQ7XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGtleTogdGFiLmtleSxcclxuICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICB7dGFiLmxhYmVsfXtcIiBcIn1cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0YWIuYmdDb2xvcn0gdGV4dC13aGl0ZSB0ZXh0LVsxMnB4XSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGxgfT5cclxuICAgICAgICAgICAgICB7Y291bnR9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApLFxyXG4gICAgICAgIGNoaWxkcmVuOiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IGRhdGE9XCJMb2FuIERhdGFcIiAvPlxyXG4gICAgICAgICAgICApIDogZmV0Y2hFcnJvciB8fCB0YWJsZUJvcnJvd2Vycy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgPE5vRGF0YUZvdW5kIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXt1cGRhdGVIYW5kbGVyfVxyXG4gICAgICAgICAgICAgICAgaXNTZWFyY2hSZXF1aXJlZD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICBkYXRhPXt0YWJsZURhdGF9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiTG9hbnNcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YExvYW5zLmNzdmB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICksXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICB9LCBbXHJcbiAgICBpc0xvYWRpbmcsIGZldGNoRXJyb3IsIHRhYmxlQm9ycm93ZXJzLCBnbG9iYWxTZWFyY2hUZXJtLFxyXG4gICAgZ2xvYmFsU2VhcmNoVGFyZ2V0VGFiLCBnbG9iYWxTZWFyY2hSZXN1bHRzLCBzZWFyY2hUZXh0LFxyXG4gICAgY29sdW1ucywgdG90YWxzLCBhY3RpdmVUYWIsIGhhbmRsZVVwZGF0ZU1vZGFsT3BlblxyXG4gIF0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVWaWV3VHJhbnNhY3Rpb25zID0gYXN5bmMgKGN1c3RvbWVySWQpID0+IHtcclxuICAgIHNldEJ1dHRvbkxvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCAyMDAwKSk7XHJcbiAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXIoY3VzdG9tZXJJZCk7XHJcbiAgICAgIHNldFNob3dUcmFuc2FjdGlvbnModHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRyYW5zYWN0aW9uc1wiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRCdXR0b25Mb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBzdGF0dXNPcHRpb25zID0gW1xyXG4gICAgeyB2YWx1ZTogXCJSRVFVRVNURURcIiwgbGFiZWw6IFwiUmVxdWVzdGVkXCIsIGljb246IDxFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIC8+LCBjb2xvcjogXCJibHVlXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiUEVORElOR1wiLCBsYWJlbDogXCJQZW5kaW5nXCIsIGljb246IDxDbG9ja0NpcmNsZU91dGxpbmVkIC8+LCBjb2xvcjogXCJvcmFuZ2VcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJSRUpFQ1RFRFwiLCBsYWJlbDogXCJSZWplY3RcIiwgaWNvbjogPENsb3NlQ2lyY2xlT3V0bGluZWQgLz4sIGNvbG9yOiBcInJlZFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlVOS05PV05cIiwgbGFiZWw6IFwiVW5rbm93blwiLCBpY29uOiA8UXVlc3Rpb25DaXJjbGVPdXRsaW5lZCAvPiwgY29sb3I6IFwicHVycGxlXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiQUNDRVBURURcIiwgbGFiZWw6IFwiQWNjZXB0ZWRcIiwgaWNvbjogPENoZWNrQ2lyY2xlT3V0bGluZWQgLz4sIGNvbG9yOiBcImdyZWVuXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiQVBQUk9WRURcIiwgbGFiZWw6IFwiQXBwcm92ZWRcIiwgaWNvbjogPENoZWNrQ2lyY2xlT3V0bGluZWQgLz4sIGNvbG9yOiBcInRlYWxcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFwcHJvdmFsU3RhdHVzQ2hhbmdlID0gKHZhbHVlKSA9PiB7XHJcbiAgICBoYW5kbGVBbnREU2VsZWN0KFwiYXBwcm92YWxfc3RhdHVzXCIsIHZhbHVlKTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBhcHByb3ZhbF9zdGF0dXM6IHZhbHVlXHJcbiAgICB9KSlcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfSAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03IG92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItMiBtaW4tdy1tYXhcIj5cclxuICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1iLTggZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICBMb2Fuc1xyXG4gICAgICAgICAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtYXgtdy0yeGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgY3VzdG9tZXIgbmFtZSBvciBwaG9uZSBudW1iZXIuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hJbnB1dH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaElucHV0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBvblByZXNzRW50ZXI9eygpID0+IGhhbmRsZVNlYXJjaChzZWFyY2hJbnB1dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcHJlZml4PXs8U2VhcmNoT3V0bGluZWQgc3R5bGU9e3sgY29sb3I6IFwiIzZiNzI4MFwiIH19IC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXItMiBib3JkZXItYmx1ZS0xMDAgaG92ZXI6Ym9yZGVyLWJsdWUtMzAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nIGZvY3VzOnJpbmctYmx1ZS0yMDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHB4LTQgcHktMiB0ZXh0LWJhc2VcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIGljb249ezxTZWFyY2hPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWFyY2goc2VhcmNoSW5wdXQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTAgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgYm9yZGVyLWJsdWUtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgc2hhZG93LW1kXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlYXJjaFxyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICB0bz1cIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvbG9hbi1wYXlvdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTEuNSB0ZXh0LXNtIGJvcmRlciBib3JkZXItYmx1ZS01MDAgdGV4dC1ibHVlLTYwMCByb3VuZGVkLWxnXHJcbiAgICAgIGhvdmVyOmJnLWJsdWUtNTAgaG92ZXI6dGV4dC1ibHVlLTcwMCBob3Zlcjpib3JkZXItYmx1ZS02MDBcclxuICAgICAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIExvYW4gUGF5bWVudCBPdXRcclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL2xvYW4tcGF5b3V0LXJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMS41IHRleHQtc20gYm9yZGVyIGJvcmRlci1ncmVlbi01MDAgdGV4dC1ncmVlbi02MDAgcm91bmRlZC1sZ1xyXG4gICAgICBob3ZlcjpiZy1ncmVlbi01MCBob3Zlcjp0ZXh0LWdyZWVuLTcwMCBob3Zlcjpib3JkZXItZ3JlZW4tNjAwXHJcbiAgICAgIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQYXltZW50IE91dCBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICArIEFkZCBMb2FuXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7LyogU3RhdHVzIFN1bW1hcnkgQ2FyZHMgKi99XHJcbiAgICAgICAgICAgIHtzdW1tYXJ5TG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSBkYXRhPVwiTG9hbiBTdW1tYXJ5XCIgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTcgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAge09SREVSRURfU1RBVFVTRVMubWFwKChzdGF0dXMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgZm91bmQgPSBzdW1tYXJ5RGF0YS5maW5kKGl0ZW0gPT4gaXRlbS5zdGF0dXMgPT09IHN0YXR1cyk7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGNvdW50ID0gZm91bmQ/LmNvdW50IHx8IDA7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHRvdGFsQW1vdW50ID0gZm91bmQ/LnRvdGFsX2Ftb3VudCB8fCAwO1xyXG5cclxuICAgICAgICAgICAgICAgICAgLy8gU3RhdHVzIGNvbmZpZyAoYWRkIGNvbG9ycy9pY29ucyBhcyB5b3UgaGF2ZSlcclxuICAgICAgICAgICAgICAgICAgY29uc3Qgc3RhdHVzQ29uZmlnID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIFJFUVVFU1RFRDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgYmc6IFwiZnJvbS1ibHVlLTUwIHRvLWJsdWUtMTAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiYm9yZGVyLWJsdWUtMjAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBcInRleHQtYmx1ZS03MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGljb246IDxGYVJlZ0VkaXQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiIC8+LFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgQUNDRVBURUQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGJnOiBcImZyb20tZ3JlZW4tNTAgdG8tZ3JlZW4tMTAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiYm9yZGVyLWdyZWVuLTIwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGV4dDogXCJ0ZXh0LWdyZWVuLTcwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgaWNvbjogPEZhQ2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIiAvPixcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIFBFTkRJTkc6IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGJnOiBcImZyb20teWVsbG93LTUwIHRvLXllbGxvdy0xMDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCJib3JkZXIteWVsbG93LTIwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGV4dDogXCJ0ZXh0LXllbGxvdy03MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGljb246IDxGYUhvdXJnbGFzc0hhbGYgY2xhc3NOYW1lPVwidGV4dC15ZWxsb3ctNTAwXCIgLz4sXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBBUFBST1ZFRDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgYmc6IFwiZnJvbS1pbmRpZ28tNTAgdG8taW5kaWdvLTEwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcImJvcmRlci1pbmRpZ28tMjAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBcInRleHQtaW5kaWdvLTcwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgaWNvbjogPEZhVGh1bWJzVXAgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwXCIgLz4sXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBVTktOT1dOOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBiZzogXCJmcm9tLXB1cnBsZS01MCB0by1wdXJwbGUtMTAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiYm9yZGVyLXB1cnBsZS0yMDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IFwidGV4dC1wdXJwbGUtNzAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8RmFRdWVzdGlvbkNpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDBcIiAvPixcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIFJFSkVDVEVEOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBiZzogXCJmcm9tLXJlZC01MCB0by1yZWQtMTAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiYm9yZGVyLXJlZC0yMDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IFwidGV4dC1yZWQtNzAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8RmFUaW1lc0NpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIiAvPixcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIENPTVBMRVRFRDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgYmc6IFwiZnJvbS10ZWFsLTUwIHRvLXRlYWwtMTAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiYm9yZGVyLXRlYWwtMjAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBcInRleHQtdGVhbC03MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGljb246IDxGYUZsYWdDaGVja2VyZWQgY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMFwiIC8+LFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICBjb25zdCBjb25maWcgPSBzdGF0dXNDb25maWdbc3RhdHVzXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtzdGF0dXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmFkaWVudC10by1iciAke2NvbmZpZy5iZ30gcm91bmRlZC1sZyBib3JkZXIgJHtjb25maWcuYm9yZGVyfSBwLTEgc2hhZG93LXNtIGhvdmVyOnNoYWRvdyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDBgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyICR7Y29uZmlnLnRleHR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+e2NvbmZpZy5pY29ufTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGp1c3RpZnktYmV0d2VlbiBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57Y291bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWdyYXktNTAwXCI+bG9hbnM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgTG9hbiBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8UmlBcnJvd1JpZ2h0RmlsbCBjbGFzc05hbWU9XCJzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEluZGlhbkN1cnJlbmN5KHRvdGFsQW1vdW50KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgey8qIFRhYiBWaWV3IEltcGxlbWVudGF0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNCByb3VuZGVkIHNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxUYWJzXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVLZXk9e2FjdGl2ZVRhYn1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoa2V5KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYihrZXkpO1xyXG4gICAgICAgICAgICAgICAgICAvLyBDbGVhciBzZWFyY2ggb25seSB3aGVuIHVzZXIgY2xpY2tzIG9uIGEgdGFiXHJcbiAgICAgICAgICAgICAgICAgIHNldEdsb2JhbFNlYXJjaFRlcm0oJycpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRHbG9iYWxTZWFyY2hSZXN1bHRzKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRHbG9iYWxTZWFyY2hUYXJnZXRUYWIobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgIHNldFNlYXJjaElucHV0KCcnKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBpdGVtcz17dGFiSXRlbXN9XHJcbiAgICAgICAgICAgICAgICBkZXN0cm95SW5hY3RpdmVUYWJQYW5lPXt0cnVlfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBBZGQgTG9hbiBNb2RhbCAqL31cclxuICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93TW9kYWx9IG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPkFkZCBMb2FuPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS01XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImJvcnJvd2VyX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBCb3Jyb3dlciBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoICBCb3Jyb3dlciBOYW1lIFwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImJvcnJvd2VyXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5ib3Jyb3dlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJib3Jyb3dlclwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIuY3VzdG9tZXJfaWR9IHwge3VzZXIuZnVsbF9uYW1lfSB8e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuYm9ycm93ZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5ib3Jyb3dlcn08L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVmlld1RyYW5zYWN0aW9ucyhmb3JtRGF0YS5ib3Jyb3dlcil9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshZm9ybURhdGE/LmJvcnJvd2VyIHx8IGJ1dHRvbkxvYWRpbmd9IC8vIGRpc2FibGUgd2hpbGUgbG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6YmctYmx1ZS03MDAgYm9yZGVyIGJvcmRlci1ibHVlLTcwMCBmb250LW1lZGl1bSByb3VuZGVkIHB4LTMgcHktMSB0ZXh0LXNtIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7YnV0dG9uTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibG9hZGVyIG1yLTJcIj48L3NwYW4+IExvYWRpbmcuLi5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICBcIlZpZXcgVHJhbnNhY3Rpb25zXCJcclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwibG9hbl9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTG9hbiBBbW91bnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsb2FuX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmxvYW5fYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJsb2FuX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBMb2FuIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxvYW5fYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxvYW5fYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhPy5sb2FuX2Ftb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInRlbnVyZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBUZW51cmUgaW4gRGF5cyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRlbnVyZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRlbnVyZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGVudXJlXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRlbnVyZSBpbiBEYXlzXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMudGVudXJlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy50ZW51cmV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmx1ZS03MDAgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGE/LnRlbnVyZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic2VydmljZV9jaGFyZ2VzXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlcnZpY2UgQ2hhcmdlcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInNlcnZpY2VfY2hhcmdlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnNlcnZpY2VfY2hhcmdlc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwic2VydmljZV9jaGFyZ2VzXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFNlcnZpY2UgQ2hhcmdlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnNlcnZpY2VfY2hhcmdlcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5zZXJ2aWNlX2NoYXJnZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmx1ZS03MDAgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGE/LnNlcnZpY2VfY2hhcmdlcyl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkb2N1bWVudF9jaGFyZ2VzXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIERvY3VtZW50YXRpb24gQ2hhcmdlc3tcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRvY3VtZW50X2NoYXJnZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5kb2N1bWVudF9jaGFyZ2VzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJkb2N1bWVudF9jaGFyZ2VzXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIERvY3VtZW50YXRpb24gQ2hhcmdlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRvY3VtZW50X2NoYXJnZXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZG9jdW1lbnRfY2hhcmdlc31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YT8uZG9jdW1lbnRfY2hhcmdlcyl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGFpbHlfcGF5bWVudF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRGFpbHkgUGF5bWVudCBBbW91bnR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGFpbHkgUGF5bWVudCBBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkYWlseV9wYXltZW50X2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmRhaWx5X3BheW1lbnRfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJkYWlseV9wYXltZW50X2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRhaWx5X3BheW1lbnRfYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRhaWx5X3BheW1lbnRfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhPy5kYWlseV9wYXltZW50X2Ftb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRpc3Bvc2FsX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBEaXNidXJzZW1lbnQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkaXNwb3NhbF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGlzcG9zYWxfYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkF1dG9tYXRpY2FsbHkgY2FsY3VsYXRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgKE51bWJlcihmb3JtRGF0YT8ubG9hbl9hbW91bnQgfHwgMCkgLVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoZm9ybURhdGE/LnNlcnZpY2VfY2hhcmdlcyB8fCAwKSAtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE51bWJlcihmb3JtRGF0YT8uZG9jdW1lbnRfY2hhcmdlcyB8fCAwKSkgfHwgXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktMTAwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmx1ZS03MDAgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoKE51bWJlcihmb3JtRGF0YT8ubG9hbl9hbW91bnQpIC1cclxuICAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyKGZvcm1EYXRhPy5zZXJ2aWNlX2NoYXJnZXMpIC1cclxuICAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyKGZvcm1EYXRhPy5kb2N1bWVudF9jaGFyZ2VzKSkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+ICovfVxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInctMS8zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGFpbHlfcGF5bWVudF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU2FuY3Rpb24gRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsb2FuX3NhbmN0aW9uX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5sb2FuX3NhbmN0aW9uX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImxvYW5fc2FuY3Rpb25fZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxvYW5fc2FuY3Rpb25fZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sb2FuX3NhbmN0aW9uX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInctMS8zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic3RhcnRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBTdGFydCBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN0YXJ0X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5zdGFydF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJzdGFydF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc3RhcnRfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdGFydF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVuZF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICBFbmQgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LXB1cnBsZS01MDAgbWItMiBtbC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAoQXV0b21hdGljYWxseSBjYWxjdWxhdGVkIGZyb20gU3RhcnQgRGF0ZSArIFRlbnVyZSlcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW5kX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbmRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZW5kX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW5kIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbmRfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbmRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgey8qIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBSZWZlcnJlZCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBcclxuICAgICAgICAgICAgICAgICAgICAgWyYuYW50LXNlbGVjdC1kaXNhYmxlZF8uYW50LXNlbGVjdC1zZWxlY3Rpb24taXRlbV06IXRleHQtZ3JheS04MDBcclxuICBbJi5hbnQtc2VsZWN0LWRpc2FibGVkXy5hbnQtc2VsZWN0LXNlbGVjdGlvbi1pdGVtXTohb3BhY2l0eS0xMDBgfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ucmVmZXJyZWRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJyZWZlcnJlZF90eXBlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlNlbGYgSm9pbmluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJBZ2VudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJPdGhlcnNcIixcclxuICAgICAgICAgICAgICAgICAgICBdLm1hcCgocmVmVHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWZUeXBlfSB2YWx1ZT17cmVmVHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZWZUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge2Zvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBDdXN0b21lcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgIFsmLmFudC1zZWxlY3QtZGlzYWJsZWRfLmFudC1zZWxlY3Qtc2VsZWN0aW9uLWl0ZW1dOiF0ZXh0LWdyYXktODAwXHJcbiAgWyYuYW50LXNlbGVjdC1kaXNhYmxlZF8uYW50LXNlbGVjdC1zZWxlY3Rpb24taXRlbV06IW9wYWNpdHktMTAwYH1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9jdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnJlZmVycmVkX2N1c3RvbWVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJyZWZlcnJlZF9jdXN0b21lclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfSB8e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnBob25lX251bWJlciA/IHVzZXIucGhvbmVfbnVtYmVyIDogXCJObyBOdW1iZXJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkFnZW50XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEFnZW50e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3IgU2VhcmNoIFJlZmVycmVkIEFnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX2FnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5yZWZlcnJlZF9hZ2VudCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfYWdlbnRcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQubmFtZX0gfCB7YWdlbnQucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge2Zvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiRW1wbG95ZWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBFbXBsb3llZXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIFxyXG4gIFsmLmFudC1zZWxlY3QtZGlzYWJsZWRfLmFudC1zZWxlY3Qtc2VsZWN0aW9uLWl0ZW1dOiF0ZXh0LWdyYXktODAwXHJcbiAgWyYuYW50LXNlbGVjdC1kaXNhYmxlZF8uYW50LXNlbGVjdC1zZWxlY3Rpb24taXRlbV06IW9wYWNpdHktMTAwYH1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9lbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnJlZmVycmVkX2VtcGxveWVlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJyZWZlcnJlZF9lbXBsb3llZVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wbG95ZWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2VtcGxveWVlLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1wbG95ZWUuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtgJHtlbXBsb3llZS5uYW1lfSB8ICR7ZW1wbG95ZWUucGhvbmVfbnVtYmVyfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWUubmFtZX0gfCB7ZW1wbG95ZWUucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogTm90ZSBGaWVsZCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE5vdGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubm90ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNwZWNpZnkgTm90ZSBpZiBhbnkhXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCB3LTEwIGgtMTAgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcm91bmRlZC1tZCBjdXJzb3ItcG9pbnRlciBmbGV4LXNocmluay0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5vcGVuKFwiQ2FsY3VsYXRvcjovLy9cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZhQ2FsY3VsYXRvciBjb2xvcj1cIndoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQXBwcm92YWwgU3RhdHVzIEZpZWxkICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWQ6dy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU3RhdHVzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYXBwcm92YWxfc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJhcHByb3ZhbF9zdGF0dXNcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb25MYWJlbFByb3A9XCJsYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7c3RhdHVzT3B0aW9ucy5tYXAoKG9wdCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtvcHQudmFsdWV9IHZhbHVlPXtvcHQudmFsdWV9IGxhYmVsPXtvcHQubGFiZWx9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IG9wdC5jb2xvciB9fT57b3B0Lmljb259PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e29wdC5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwXHJcbmZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBMb2FuXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgey8qIEVkaXQgTW9kYWwgKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e2lzQWNjZXB0TW9kYWxPcGVufVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRJc0FjY2VwdE1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldFNlbGVjdGVkTG9hbihudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBzaXplPVwiMnhsXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlblwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctNnhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUgdG8tYmx1ZS01MCBzaGFkb3cteGwgZm9udC1zYW5zIHRleHQtc20gdGV4dC1ncmF5LTgwMCByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICB7LyogSGVhZGVyIHdpdGggZ3JhZGllbnQgYmFja2dyb3VuZCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYi0yIGJvcmRlci1ibHVlLTkwMCBwLTRcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtYmx1ZS05MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+RWRpdCBMb2FuIFJlcXVlc3Q8L2gyPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogVmlldyBUcmFuc2FjdGlvbnMgQnV0dG9uICovfVxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBidG4gPSBlLmN1cnJlbnRUYXJnZXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgb3JpZ2luYWxUZXh0ID0gYnRuLmlubmVySFRNTDtcclxuICAgICAgICAgICAgICAgICAgICBidG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJ0bi5pbm5lckhUTUwgPSBgPHNwYW4gY2xhc3M9XCJsb2FkZXIgbXItMlwiPjwvc3Bhbj4gTG9hZGluZy4uLmA7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBoYW5kbGVWaWV3VHJhbnNhY3Rpb25zKHNlbGVjdGVkTG9hbj8uYm9ycm93ZXI/Ll9pZCB8fCBzZWxlY3RlZExvYW4/LmJvcnJvd2VyPy51c2VyX2lkPy5faWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBidG4uaW5uZXJIVE1MID0gb3JpZ2luYWxUZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXNlbGVjdGVkTG9hbj8uYm9ycm93ZXI/Ll9pZH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLWJsdWUtNzAwIGJvcmRlciBib3JkZXItYmx1ZS03MDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1zbSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxGaUV5ZSBjbGFzc05hbWU9XCJtci0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgVmlldyBUcmFuc2FjdGlvbnNcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogVXNlciBJbmZvIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgeyhzZWxlY3RlZExvYW4/LnVzZXIgfHwgc2VsZWN0ZWRMb2FuPy51c2VyX2lkKSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LW1kIHAtNSBtYi02IGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tc2hhZG93IGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEF2YXRhciB3aXRoIGdyYWRpZW50ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IGZsZXgtc2hyaW5rLTAgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwMCB0by1pbmRpZ28tNjAwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LWxnIHNoYWRvdy1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgeyhzZWxlY3RlZExvYW4udXNlcl9pZD8uZnVsbF9uYW1lPy5jaGFyQXQoMCkgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRMb2FuLnVzZXI/LmZ1bGxfbmFtZT8uY2hhckF0KDApIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiVVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICApLnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBOYW1lICsgUGhvbmUgKyBTb3VyY2UgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE5hbWUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWxnIHRydW5jYXRlIG1heC13LVs2MCVdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkTG9hbi51c2VyX2lkPy5mdWxsX25hbWUgfHwgc2VsZWN0ZWRMb2FuLnVzZXI/LmZ1bGxfbmFtZSB8fCBcIlVua25vd25cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTb3VyY2UgQmFkZ2UgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1tZWRpdW0gYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGaVVzZXIgY2xhc3NOYW1lPVwibXItMVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU291cmNlIDogU2VsZlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogUGhvbmUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RmlQaG9uZSBjbGFzc05hbWU9XCJ3LTQgaC00IGZsZXgtc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRMb2FuLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBzZWxlY3RlZExvYW4udXNlcj8ucGhvbmVfbnVtYmVyIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBMb2FuIERldGFpbHMgQ2FyZHMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBMb2FuIEFtb3VudCBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkTG9hbj8ubG9hbl9hbW91bnQgIT0gbnVsbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmVlbi01MCB0by1ncmVlbi0xMDAgcm91bmRlZC14bCBwLTQgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDAgaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCB0cmFuc2Zvcm0gaG92ZXI6LXRyYW5zbGF0ZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiBiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwMCB0by1ncmVlbi02MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LXNocmluay0wIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTG9hbiBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmVlbi03MDAgZm9udC1ib2xkIHRleHQteGwgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAg4oK5e3NlbGVjdGVkTG9hbj8ubG9hbl9hbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBMb2FuIFB1cnBvc2UgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZExvYW4/LmxvYW5fcHVycG9zZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwIHRvLWJsdWUtMTAwIHJvdW5kZWQteGwgcC00IGJvcmRlciBib3JkZXItYmx1ZS0yMDAgaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCB0cmFuc2Zvcm0gaG92ZXI6LXRyYW5zbGF0ZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiBiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMCBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUHVycG9zZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIGZvbnQtc2VtaWJvbGQgbWF4LXctWzUwJV0gdHJ1bmNhdGUgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRMb2FuPy5sb2FuX3B1cnBvc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQXBwbGllZCBEYXRlIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRMb2FuPy5jcmVhdGVkQXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwIHRvLXB1cnBsZS0xMDAgcm91bmRlZC14bCBwLTQgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgdHJhbnNmb3JtIGhvdmVyOi10cmFuc2xhdGUteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1wdXJwbGUtNTAwIHRvLXB1cnBsZS02MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlDbG9jayBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQXBwbGllZCBPblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS03MDAgZm9udC1zZW1pYm9sZCB0ZXh0LXNtIHRleHQtcmlnaHQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKHNlbGVjdGVkTG9hbj8uY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF5OiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJzaG9ydFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHllYXI6IFwibnVtZXJpY1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhvdXI6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1pbnV0ZTogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFJlZmVycmVkIEJ5IENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICB7KHNlbGVjdGVkTG9hbj8udXNlcl9pZD8ucmVmZXJyZWRfYnlfbmFtZSB8fCBzZWxlY3RlZExvYW4/LnVzZXJfaWQ/LnJlZmVycmVkX2VtcGxveWVlKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1hbWJlci01MCB0by1hbWJlci0xMDAgcm91bmRlZC14bCBwLTQgYm9yZGVyIGJvcmRlci1hbWJlci0yMDAgaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCB0cmFuc2Zvcm0gaG92ZXI6LXRyYW5zbGF0ZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiBiZy1ncmFkaWVudC10by1iciBmcm9tLWFtYmVyLTUwMCB0by1hbWJlci02MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlVc2VyUGx1cyBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUmVmZXJyZWQgQnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTcwMCBmb250LXNlbWlib2xkIHRleHQtcmlnaHQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkTG9hbj8udXNlcl9pZD8ucmVmZXJyZWRfZW1wbG95ZWU/Lm5hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZExvYW4/LnVzZXJfaWQ/LnJlZmVycmVkX2VtcGxveWVlPy5waG9uZV9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1lbmRcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiAgICAgRW1wbG95ZWUgOi0ge3NlbGVjdGVkTG9hbj8udXNlcl9pZD8ucmVmZXJyZWRfZW1wbG95ZWUubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntzZWxlY3RlZExvYW4/LnVzZXJfaWQ/LnJlZmVycmVkX2VtcGxveWVlPy5waG9uZV9udW1iZXJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogc2VsZWN0ZWRMb2FuPy51c2VyX2lkPy5yZWZlcnJlZF9hZ2VudD8ubmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1lbmRcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+ICBBZ2VudDotIHtzZWxlY3RlZExvYW4/LnVzZXJfaWQ/LnJlZmVycmVkX2FnZW50Lm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntzZWxlY3RlZExvYW4/LnVzZXJfaWQ/LnJlZmVycmVkX2FnZW50LnBob25lX251bWJlcn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBzZWxlY3RlZExvYW4/LnVzZXJfaWQ/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRMb2FuPy51c2VyX2lkPy5yZWZlcnJlZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1lbmRcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4gICAgIEN1c3RvbWVyOi17c2VsZWN0ZWRMb2FuPy51c2VyX2lkPy5yZWZlcnJlZF9jdXN0b21lci5mdWxsX25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3NlbGVjdGVkTG9hbj8udXNlcl9pZD8ucmVmZXJyZWRfY3VzdG9tZXI/LnBob25lX251bWJlcn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBTdGF0dXMgVXBkYXRlIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQteGwgcC01IGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ibHVlLTkwMCBtYi00IHRleHQtbGcgZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPEZpU2V0dGluZ3MgY2xhc3NOYW1lPVwibXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIFVwZGF0ZSBTdGF0dXNcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTUgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkZWZhdWx0XCJcclxuICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTQgZm9udC1ib2xkIGJvcmRlci15ZWxsb3ctNTAwIHRleHQteWVsbG93LTYwMCBob3ZlcjpiZy15ZWxsb3ctNTAgaG92ZXI6Ym9yZGVyLXllbGxvdy02MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGljb249ezxDbG9ja0NpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZWxlY3RlZExvYW4/Lmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICAvLyBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQZW5kaW5nQ2xpY2soc2VsZWN0ZWRMb2FuKX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93Q29uZmlybSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlBlbmRpbmcgTG9hbiBSZXF1ZXN0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gUGVuZGluZyB0aGlzIGxvYW4gcmVxdWVzdD9gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvbmZpcm06ICgpID0+IHVwZGF0ZUxvYW5TdGF0dXMoc2VsZWN0ZWRMb2FuLCBcIlBFTkRJTkdcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQZW5kaW5nXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZWxlY3RlZExvYW4/Lmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTE0IGZvbnQtYm9sZCBiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwIGJvcmRlci1ncmVlbi02MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGljb249ezxDaGVja0NpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd0NvbmZpcm0oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJBY2NlcHQgTG9hbiBSZXF1ZXN0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gQWNjZXB0IHRoaXMgbG9hbiByZXF1ZXN0P2AsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybTogKCkgPT4gdXBkYXRlTG9hblN0YXR1cyhzZWxlY3RlZExvYW4sIFwiQUNDRVBURURcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQWNjZXB0XHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ3YXJuaW5nXCJcclxuICAgICAgICAgICAgICAgICAgICBkYW5nZXJcclxuICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTQgZm9udC1ib2xkIHRleHQtZ3JheS03MDAgYmcteWVsbG93LTEwMCBob3ZlcjpiZy15ZWxsb3ctMjAwIGJvcmRlci15ZWxsb3ctMzAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICBpY29uPXs8UXVlc3Rpb25DaXJjbGVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2VsZWN0ZWRMb2FuPy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93Q29uZmlybSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlVua25vd24gTG9hbiBSZXF1ZXN0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gbWFyayB0aGlzIGxvYW4gcmVxdWVzdCBhcyB1bmtub3duP2AsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybTogKCkgPT4gdXBkYXRlTG9hblN0YXR1cyhzZWxlY3RlZExvYW4sIFwiVU5LTk9XTlwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBVbmtub3duXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYW5nZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCBmb250LWJvbGQgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCAhdGV4dC13aGl0ZSAhYmctcmVkLTUwMCAhYm9yZGVyLXJlZC01MDAgaG92ZXI6IWJnLXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGljb249ezxDbG9zZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZWxlY3RlZExvYW4/Lmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93Q29uZmlybSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlJlamVjdCBMb2FuIFJlcXVlc3RcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGVudDogYEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byByZWplY3QgdGhpcyBsb2FuIHJlcXVlc3Q/YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25Db25maXJtOiAoKSA9PiB1cGRhdGVMb2FuU3RhdHVzKHNlbGVjdGVkTG9hbiwgXCJSRUpFQ1RFRFwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlamVjdFxyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuXHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRJc0FjY2VwdE1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZExvYW4obnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTE0IGZvbnQtc2VtaWJvbGQgYm9yZGVyLWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICB7c2hvd1RyYW5zYWN0aW9ucyAmJiAoXHJcbiAgICAgICAgICA8Vmlld0N1c3RvbWVyVHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgIGN1c3RvbWVySWQ9e3NlbGVjdGVkQ3VzdG9tZXJ9XHJcbiAgICAgICAgICAgIHZpc2libGU9e3Nob3dUcmFuc2FjdGlvbnN9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dUcmFuc2FjdGlvbnMoZmFsc2UpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7LyogVXBkYXRlIExvYW4gTW9kYWwgKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS00IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgVXBkYXRlIExvYW5cclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBiZy1ibHVlLTUwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgcm91bmRlZC1mdWxsIHB4LTMgcHktMSB3LWZpdCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxGYUNhbGVuZGFyQWx0IGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgdy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBmb250LW1lZGl1bVwiPkFwcGxpZWQgb246PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YT8uYXBwbGllZF9vbiB8fCB1cGRhdGVGb3JtRGF0YT8uY3JlYXRlZEF0XHJcbiAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZSh1cGRhdGVGb3JtRGF0YS5hcHBsaWVkX29uIHx8IHVwZGF0ZUZvcm1EYXRhLmNyZWF0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1JTicpXHJcbiAgICAgICAgICAgICAgICAgICAgOiAn4oCUJ31cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJib3Jyb3dlcl9uYW1lXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQm9ycm93ZXIgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVxyXG4gICAgICAgICAgICAgICAgICAgWyYuYW50LXNlbGVjdC1kaXNhYmxlZF8uYW50LXNlbGVjdC1zZWxlY3Rpb24taXRlbV06IXRleHQtZ3JheS04MDBcclxuICBbJi5hbnQtc2VsZWN0LWRpc2FibGVkXy5hbnQtc2VsZWN0LXNlbGVjdGlvbi1pdGVtXTohb3BhY2l0eS0xMDBgfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggQm9ycm93ZXIgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImJvcnJvd2VyXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5ib3Jyb3dlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudElucHV0RFNlbGVjdChcImJvcnJvd2VyXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3VzZXJzPy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuYm9ycm93ZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5ib3Jyb3dlcn08L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdUcmFuc2FjdGlvbnMoZm9ybURhdGEuYm9ycm93ZXIpfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWZvcm1EYXRhPy5ib3Jyb3dlciB8fCBidXR0b25Mb2FkaW5nfSAvLyBkaXNhYmxlIHdoaWxlIGxvYWRpbmdcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLWJsdWUtNzAwIGJvcmRlciBib3JkZXItYmx1ZS03MDAgZm9udC1tZWRpdW0gcm91bmRlZCBweC0zIHB5LTEgdGV4dC1zbSB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2J1dHRvbkxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxvYWRlciBtci0yXCI+PC9zcGFuPiBMb2FkaW5nLi4uXHJcbiAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgXCJWaWV3IFRyYW5zYWN0aW9uc1wiXHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ0biA9IGUuY3VycmVudFRhcmdldDtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBvcmlnaW5hbFRleHQgPSBidG4uaW5uZXJIVE1MO1xyXG4gICAgICAgICAgICAgICAgICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgYnRuLmlubmVySFRNTCA9IGA8c3BhbiBjbGFzcz1cImxvYWRlciBtci0yXCI+PC9zcGFuPiBMb2FkaW5nLi4uYDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGhhbmRsZVZpZXdUcmFuc2FjdGlvbnModXBkYXRlRm9ybURhdGE/LmJvcnJvd2VyKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgYnRuLmlubmVySFRNTCA9IG9yaWdpbmFsVGV4dDtcclxuICAgICAgICAgICAgICAgICAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF1cGRhdGVGb3JtRGF0YT8uYm9ycm93ZXJ9IC8vIGJ1dHRvbkxvYWRpbmcgaXMgbm90IHVzZWQgaGVyZVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6YmctYmx1ZS03MDAgYm9yZGVyIGJvcmRlci1ibHVlLTcwMCBmb250LW1lZGl1bSByb3VuZGVkIHB4LTMgcHktMSB0ZXh0LXNtIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgd2hpdGVzcGFjZS1ub3dyYXBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IFRyYW5zYWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgey8qIC0tLSBORVc6IE9uZSBMaW5lIFN1bW1hcnkgU2VjdGlvbiAtLS0gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tc2xhdGUtNTAgdG8tYmx1ZS01MCBwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBtYi02IHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgZ2FwLTQgbWQ6Z2FwLTBcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciBSZXF1ZXN0ZWQgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdy1mdWxsIG1kOnctMS8zIGJvcmRlci1iIG1kOmJvcmRlci1iLTAgbWQ6Ym9yZGVyLXIgYm9yZGVyLXNsYXRlLTIwMCBwYi0zIG1kOnBiLTAgbWQ6cHItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWJsdWUtMTAwIHJvdW5kZWQtbGcgdGV4dC1ibHVlLTYwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGYVVzZXIgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGQgdHJhY2tpbmctd2lkZXIgbWItMC41XCI+UmVxdWVzdGVkPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgbGVhZGluZy1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7KGN1cnJlbnRVcGRhdGVCb3Jyb3dlcj8ucmVxdWVzdGVkX2xvYW5fYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBBZ2VudCBBcHByb3ZlZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB3LWZ1bGwgbWQ6dy0xLzMgYm9yZGVyLWIgbWQ6Ym9yZGVyLWItMCBtZDpib3JkZXItciBib3JkZXItc2xhdGUtMjAwIHBiLTMgbWQ6cGItMCBtZDpwci00IHBsLTAgbWQ6cGwtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLW9yYW5nZS0xMDAgcm91bmRlZC1sZyB0ZXh0LW9yYW5nZS02MDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8RmFVc2VyVGllIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIHRyYWNraW5nLXdpZGVyIG1iLTAuNVwiPkFnZW50IEFwcHJvdmVkPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgbGVhZGluZy1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7KGN1cnJlbnRVcGRhdGVCb3Jyb3dlcj8uZW1wbG95ZWVfYXBwcm92ZWRfYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBBZG1pbiBBcHByb3ZlZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB3LWZ1bGwgbWQ6dy0xLzMgcGwtMCBtZDpwbC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctZW1lcmFsZC0xMDAgcm91bmRlZC1sZyB0ZXh0LWVtZXJhbGQtNjAwIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZhQ2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGQgdHJhY2tpbmctd2lkZXIgbWItMC41XCI+QWRtaW4gQXBwcm92ZWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBsZWFkaW5nLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAg4oK5IHsoY3VycmVudFVwZGF0ZUJvcnJvd2VyPy5hcHByb3ZlZF9sb2FuX2Ftb3VudCB8fCAwKS50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJsb2FuX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBMb2FuIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+ICo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsb2FuX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmxvYW5fYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImxvYW5fYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIExvYW4gQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubG9hbl9hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubG9hbl9hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmx1ZS03MDAgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModXBkYXRlRm9ybURhdGE/LmxvYW5fYW1vdW50KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidGVudXJlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFRlbnVyZSBpbiBEYXlzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwidGVudXJlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnRlbnVyZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZW51cmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgVGVudXJlIGluIERheXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy50ZW51cmUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj57ZXJyb3JzLnRlbnVyZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YT8udGVudXJlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHVwZGF0ZUZvcm1EYXRhPy50ZW51cmUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJzZXJ2aWNlX2NoYXJnZXNcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VydmljZSBDaGFyZ2VzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2VydmljZV9jaGFyZ2VzXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnNlcnZpY2VfY2hhcmdlc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJzZXJ2aWNlX2NoYXJnZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgU2VydmljZSBDaGFyZ2VzXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc2VydmljZV9jaGFyZ2VzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnNlcnZpY2VfY2hhcmdlc31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YT8uc2VydmljZV9jaGFyZ2VzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHVwZGF0ZUZvcm1EYXRhPy5zZXJ2aWNlX2NoYXJnZXMpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZG9jdW1lbnRfY2hhcmdlc1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBEb2N1bWVudGF0aW9uIENoYXJnZXN7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkb2N1bWVudF9jaGFyZ2VzXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmRvY3VtZW50X2NoYXJnZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZG9jdW1lbnRfY2hhcmdlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBEb2N1bWVudGF0aW9uIENoYXJnZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5kb2N1bWVudF9jaGFyZ2VzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRvY3VtZW50X2NoYXJnZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGE/LmRvY3VtZW50X2NoYXJnZXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModXBkYXRlRm9ybURhdGE/LmRvY3VtZW50X2NoYXJnZXMpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhaWx5X3BheW1lbnRfYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIERhaWx5IFBheW1lbnQgQW1vdW50e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRhaWx5IFBheW1lbnQgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGFpbHlfcGF5bWVudF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZGFpbHlfcGF5bWVudF9hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGFpbHlfcGF5bWVudF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycz8uZGFpbHlfcGF5bWVudF9hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnM/LmRhaWx5X3BheW1lbnRfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhPy5kYWlseV9wYXltZW50X2Ftb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCIgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModXBkYXRlRm9ybURhdGE/LmRhaWx5X3BheW1lbnRfYW1vdW50KX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRpc3Bvc2FsX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBEaXNidXJzZW1lbnQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkaXNwb3NhbF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGlzcG9zYWxfYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkF1dG9tYXRpY2FsbHkgY2FsY3VsYXRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgKE51bWJlcih1cGRhdGVGb3JtRGF0YT8ubG9hbl9hbW91bnQgfHwgMCkgLVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIodXBkYXRlRm9ybURhdGE/LnNlcnZpY2VfY2hhcmdlcyB8fCAwKSAtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE51bWJlcih1cGRhdGVGb3JtRGF0YT8uZG9jdW1lbnRfY2hhcmdlcyB8fCAwKSkgfHwgXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktMTAwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmx1ZS03MDAgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoKE51bWJlcih1cGRhdGVGb3JtRGF0YT8ubG9hbl9hbW91bnQgfHwgMCkgLVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoTnVtYmVyKHVwZGF0ZUZvcm1EYXRhPy5zZXJ2aWNlX2NoYXJnZXMgfHwgMCkpIC1cclxuICAgICAgICAgICAgICAgICAgICAgICAgKE51bWJlcih1cGRhdGVGb3JtRGF0YT8uZG9jdW1lbnRfY2hhcmdlcyB8fCAwKSkgfHwgXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzNcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJsb2FuX3NhbmN0aW9uX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU2FuY3Rpb24gRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsb2FuX3NhbmN0aW9uX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5sb2FuX3NhbmN0aW9uX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibG9hbl9zYW5jdGlvbl9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubG9hbl9zYW5jdGlvbl9kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxvYW5fc2FuY3Rpb25fZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzNcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJzdGFydF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFN0YXJ0IERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3RhcnRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnN0YXJ0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwic3RhcnRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnN0YXJ0X2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc3RhcnRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbmRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBFbmQgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LXB1cnBsZS01MDAgbWItMiBtbC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAoQXV0b21hdGljYWxseSBjYWxjdWxhdGVkIGZyb20gU3RhcnQgRGF0ZSArIFRlbnVyZSlcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW5kX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5zdGFydF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5lbmRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAvLyBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJlbmRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbmQgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVuZF9kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVuZF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBSZWZlcnJlZCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICBbJi5hbnQtc2VsZWN0LWRpc2FibGVkXy5hbnQtc2VsZWN0LXNlbGVjdGlvbi1pdGVtXTohdGV4dC1ncmF5LTgwMFxyXG4gIFsmLmFudC1zZWxlY3QtZGlzYWJsZWRfLmFudC1zZWxlY3Qtc2VsZWN0aW9uLWl0ZW1dOiFvcGFjaXR5LTEwMGB9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUmVmZXJyZWQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdG9yOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZjlmYWZiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMxMTE4MjdcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3BhY2l0eTogMSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZDFkNWRiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucmVmZXJyZWRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcInJlZmVycmVkX3R5cGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgIFwiU2VsZiBKb2luaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkVtcGxveWVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkFnZW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIk90aGVyc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgIF0ubWFwKChyZWZUeXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlZlR5cGV9IHZhbHVlPXtyZWZUeXBlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3JlZlR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEN1c3RvbWVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgYH1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX2N1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucmVmZXJyZWRfY3VzdG9tZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcInJlZmVycmVkX2N1c3RvbWVyXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9IHx7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIucGhvbmVfbnVtYmVyID8gdXNlci5waG9uZV9udW1iZXIgOiBcIk5vIE51bWJlclwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiQWdlbnRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgQWdlbnR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggUmVmZXJyZWQgQWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9hZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnJlZmVycmVkX2FnZW50IHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcInJlZmVycmVkX2FnZW50XCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2FnZW50Ll9pZH0gdmFsdWU9e2FnZW50Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHwge2FnZW50LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkVtcGxveWVlXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgRW1wbG95ZWV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgIFsmLmFudC1zZWxlY3QtZGlzYWJsZWRfLmFudC1zZWxlY3Qtc2VsZWN0aW9uLWl0ZW1dOiF0ZXh0LWdyYXktODAwXHJcbiAgWyYuYW50LXNlbGVjdC1kaXNhYmxlZF8uYW50LXNlbGVjdC1zZWxlY3Rpb24taXRlbV06IW9wYWNpdHktMTAwIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggUmVmZXJyZWQgRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIC8vIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfZW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIW9wdGlvbiB8fCAhb3B0aW9uLmNoaWxkcmVuKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucmVmZXJyZWRfZW1wbG95ZWUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwicmVmZXJyZWRfZW1wbG95ZWVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcGxveWVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wbG95ZWUuX2lkfSB2YWx1ZT17ZW1wbG95ZWUuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWUubmFtZX0gfCB7ZW1wbG95ZWUucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBOb3RlIEZpZWxkICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWQ6dy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTm90ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub3RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTcGVjaWZ5IE5vdGUgaWYgYW55IVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS03MDAgaG92ZXI6YmctYmx1ZS04MDAgdy0xMCBoLTEwIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHJvdW5kZWQtbWQgY3Vyc29yLXBvaW50ZXIgZmxleC1zaHJpbmstMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cub3BlbihcIkNhbGN1bGF0b3I6Ly8vXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGYUNhbGN1bGF0b3IgY29sb3I9XCJ3aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEFwcHJvdmFsIFN0YXR1cyBGaWVsZCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFN0YXR1cyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmFwcHJvdmFsX3N0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJhcHByb3ZhbF9zdGF0dXNcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb25MYWJlbFByb3A9XCJsYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7c3RhdHVzT3B0aW9ucy5tYXAoKG9wdCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtvcHQudmFsdWV9IHZhbHVlPXtvcHQudmFsdWV9IGxhYmVsPXtvcHQubGFiZWx9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IG9wdC5jb2xvciB9fT57b3B0Lmljb259PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e29wdC5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmQgZ2FwLTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zNiB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwXHJcbiAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnXHJcbiAgICAgIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWJsYWNrIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlIExvYW5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICB7LyogRGVsZXRlIE1vZGFsICovfVxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRCb3Jyb3dlcihudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIERlbGV0ZSBCb3Jyb3dlclxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICB7Y3VycmVudEJvcnJvd2VyICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlQm9ycm93ZXIoKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEJvcnJvd2VyPy5ib3Jyb3dlcj8uZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBpZD1cImJvcnJvd2VyTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQm9ycm93ZXIgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDBcclxuZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgey8qIFJlbW92ZSBNb2RhbCAqL31cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd1JlbW92ZU1vZGFsfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTaG93UmVtb3ZlTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRDdXJyZW50Qm9ycm93ZXIobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMiB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgUmVtb3ZlIExvYW5cclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gcmVtb3ZlIHRoaXMgbG9hbj9cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgIFJlbW92YWwgUmVhc29uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCByZWFzb25cIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3JlbW92ZVJlYXNvbiB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHNldFJlbW92ZVJlYXNvbih2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIHNldEN1c3RvbVJlbW92ZVJlYXNvbihcIlwiKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgIFwiTG9hbiBDb21wbGV0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiQWxsIEVNSXMgUGFpZFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIkxvYW4gQ2xvc2VkIEVhcmx5XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiQ3VzdG9tZXIgUmVxdWVzdFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIkR1cGxpY2F0ZSBMb2FuIEVudHJ5XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVmVyaWZpY2F0aW9uIEZhaWxlZFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIkxvYW4gUmVwbGFjZWQgV2l0aCBOZXcgTG9hblwiLFxyXG4gICAgICAgICAgICAgICAgICBcIldyaXR0ZW4gT2ZmXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICAgIF0ubWFwKChyZWFzb24pID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWFzb259IHZhbHVlPXtyZWFzb259PlxyXG4gICAgICAgICAgICAgICAgICAgIHtyZWFzb259XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIHtyZW1vdmVSZWFzb24gPT09IFwiT3RoZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU3BlY2lmeSBSZWFzb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByZW1vdmFsIHJlYXNvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbVJlbW92ZVJlYXNvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEN1c3RvbVJlbW92ZVJlYXNvbihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1JlbW92ZU1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZC1tZFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUmVtb3ZlQm9ycm93ZXJ9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctb3JhbmdlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgaG92ZXI6Ymctb3JhbmdlLTcwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ29uZmlybSBSZW1vdmVcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuXHJcbiAgICAgICAgey8qIGFjY2VwdCBvciByZWplY3QgdXNlciAgKi99XHJcbiAgICAgICAgey8qIDxNb2RhbFxyXG4gICAgICAgIHRpdGxlPVwiQXBwcm92ZSBMb2FuIFJlcXVlc3RcIlxyXG4gICAgICAgIGlzVmlzaWJsZT17c2hvd2xvYW5BY2NlcHRNb2RhbH1cclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICBzZXRTaG93TG9hbkFjY2VwdE1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgIGZvcm0ucmVzZXRGaWVsZHMoKTtcclxuICAgICAgICB9fVxyXG4gICAgICAgIGZvb3Rlcj17bnVsbH1cclxuICAgICAgICB3aWR0aD17ODAwfVxyXG4gICAgICA+XHJcbiAgICAgICAgPEZvcm0gZm9ybT17Zm9ybX0gbGF5b3V0PVwidmVydGljYWxcIiBvbkZpbmlzaD17aGFuZGxlQXBwcm92ZUxvYW59PlxyXG4gICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICBuYW1lPVwiYm9ycm93ZXJcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xMFwiXHJcbiAgICAgICAgICAgIGxhYmVsPVwiQm9ycm93ZXIgTmFtZVwiXHJcbiAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGJvcnJvd2VyXCIgfV19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggQm9ycm93ZXIgTmFtZVwiXHJcbiAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB0ZXh0ID0gb3B0aW9uPy5jaGlsZHJlbj8udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpIHx8IFwiXCI7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGV4dC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAge3VzZXIuY3VzdG9tZXJfaWR9IHwge3VzZXIuZnVsbF9uYW1lfSB8IHt1c2VyLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgbmFtZT1cImxvYW5fYW1vdW50XCJcclxuICAgICAgICAgICAgICBsYWJlbD1cIkxvYW4gQW1vdW50XCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvMlwiXHJcbiAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIkVudGVyIGxvYW4gYW1vdW50XCIgfV19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBMb2FuIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICBuYW1lPVwidGVudXJlXCJcclxuICAgICAgICAgICAgICBsYWJlbD1cIlRlbnVyZSAoRGF5cylcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS8yXCJcclxuICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiRW50ZXIgdGVudXJlXCIgfV19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBUZW51cmUgaW4gRGF5c1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgbmFtZT1cInNlcnZpY2VfY2hhcmdlc1wiXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJTZXJ2aWNlIENoYXJnZXNcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS8yXCJcclxuICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiRW50ZXIgc2VydmljZSBjaGFyZ2VzXCIgfV19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBTZXJ2aWNlIENoYXJnZXNcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcblxyXG4gICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgbmFtZT1cImRhaWx5X3BheW1lbnRfYW1vdW50XCJcclxuICAgICAgICAgICAgICBsYWJlbD1cIkRhaWx5IFBheW1lbnQgQW1vdW50XCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvMlwiXHJcbiAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiRW50ZXIgZGFpbHkgcGF5bWVudCBhbW91bnRcIiB9LFxyXG4gICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBEYWlseSBQYXltZW50XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICBuYW1lPVwic3RhcnRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJTdGFydCBEYXRlXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvMlwiXHJcbiAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlNlbGVjdCBzdGFydCBkYXRlXCIgfV19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICBmb3JtYXQ9XCJERC9NTS9ZWVlZXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICBuYW1lPVwiZW5kX2RhdGVcIlxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiRW5kIERhdGVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS8yXCJcclxuICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiU2VsZWN0IGVuZCBkYXRlXCIgfV19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICBmb3JtYXQ9XCJERC9NTS9ZWVlZXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICBcclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfdHlwZVwiXHJcbiAgICAgICAgICAgIGxhYmVsPVwiUmVmZXJyZWQgVHlwZVwiXHJcbiAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJTZWxlY3QgcmVmZXJyZWQgdHlwZVwiIH1dfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUmVmZXJyZWQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB0ZXh0ID0gb3B0aW9uPy5jaGlsZHJlbj8udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpIHx8IFwiXCI7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGV4dC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge1tcIlNlbGYgSm9pbmluZ1wiLCBcIkN1c3RvbWVyXCIsIFwiRW1wbG95ZWVcIiwgXCJBZ2VudFwiLCBcIk90aGVyc1wiXS5tYXAoXHJcbiAgICAgICAgICAgICAgICAodHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3R5cGV9IHZhbHVlPXt0eXBlfT5cclxuICAgICAgICAgICAgICAgICAgICB7dHlwZX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgIDwvRm9ybS5JdGVtPiBcclxuPEZvcm0uSXRlbSBub1N0eWxlIHNob3VsZFVwZGF0ZT17KHByZXYsIGN1cnIpID0+IHByZXYucmVmZXJyZWRfdHlwZSAhPT0gY3Vyci5yZWZlcnJlZF90eXBlfT5cclxuICB7KHsgZ2V0RmllbGRWYWx1ZSB9KSA9PiB7XHJcbiAgICBjb25zdCB0eXBlID0gZ2V0RmllbGRWYWx1ZShcInJlZmVycmVkX3R5cGVcIik7XHJcblxyXG4gICAgaWYgKHR5cGUgPT09IFwiQ3VzdG9tZXJcIikge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9jdXN0b21lclwiXHJcbiAgICAgICAgICBsYWJlbD1cIlJlZmVycmVkIEN1c3RvbWVyXCJcclxuICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJTZWxlY3QgY3VzdG9tZXJcIiB9XX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfSB8IHt1c2VyLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHR5cGUgPT09IFwiRW1wbG95ZWVcIikge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9lbXBsb3llZVwiXHJcbiAgICAgICAgICBsYWJlbD1cIlJlZmVycmVkIEVtcGxveWVlXCJcclxuICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJTZWxlY3QgZW1wbG95ZWVcIiB9XX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEVtcGxveWVlXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuICAgICAgICAgICAgICAgIHtlbXAubmFtZX0gfCB7ZW1wLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHR5cGUgPT09IFwiQWdlbnRcIikge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9hZ2VudFwiXHJcbiAgICAgICAgICBsYWJlbD1cIlJlZmVycmVkIEFnZW50XCJcclxuICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJTZWxlY3QgYWdlbnRcIiB9XX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEFnZW50XCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfSB8IHthZ2VudC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh0eXBlID09PSBcIk90aGVyc1wiKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgbmFtZT1cInJlZmVycmVkX290aGVyc1wiXHJcbiAgICAgICAgICBsYWJlbD1cIlJlZmVycmVkIEJ5XCJcclxuICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJFbnRlciByZWZlcmVuY2UgbmFtZVwiIH1dfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHJlZmVyZW5jZSBuYW1lXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfX1cclxuPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICBcclxuXHJcbiAgICAgIFxyXG4gICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwibm90ZVwiIGxhYmVsPVwiTm90ZVwiPlxyXG4gICAgICAgICAgICA8SW5wdXQuVGV4dEFyZWEgcm93cz17M30gcGxhY2Vob2xkZXI9XCJTcGVjaWZ5IG5vdGUgaWYgYW55XCIgLz5cclxuICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dBcHByb3ZhbE1vZGFsKGZhbHNlKX0+Q2FuY2VsPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgaHRtbFR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgIGljb249ezxDaGVja0NpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQXBwcm92ZSBMb2FuXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Gb3JtPlxyXG4gICAgICA8L01vZGFsPiAqL31cclxuXHJcbiAgICAgICAgey8qIE5FVzogQXBwcm92YWwgU3RhdHVzIFVwZGF0ZSBNb2RhbCAqL31cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd0FwcHJvdmFsTW9kYWx9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dBcHByb3ZhbE1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudEJvcnJvd2VyKG51bGwpO1xyXG4gICAgICAgICAgICBzZXRBcHByb3ZhbFN0YXR1cyhcIlwiKTtcclxuICAgICAgICAgICAgc2V0QXBwcm92YWxOb3RlKFwiXCIpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTIgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIFVwZGF0ZSAgTG9hbiAgU3RhdHVzXHJcbiAgICAgICAgICAgICAgey8qIEFwcHJvdmFsICovfVxyXG5cclxuXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAge2N1cnJlbnRCb3Jyb3dlcj8uYm9ycm93ZXI/LmZ1bGxfbmFtZX0gLSBMb2FuIElEOntcIiBcIn1cclxuICAgICAgICAgICAgICB7Y3VycmVudEJvcnJvd2VyPy5sb2FuX2lkfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIEFwcHJvdmFsICAqL31cclxuICAgICAgICAgICAgICAgIExvYW5cclxuICAgICAgICAgICAgICAgIFN0YXR1cyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgYXBwcm92YWwgc3RhdHVzXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXthcHByb3ZhbFN0YXR1cyB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRBcHByb3ZhbFN0YXR1cyh2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHsvKiA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlBFTkRJTkdcIj5QZW5kaW5nPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJBUFBST1ZFRFwiPkFwcHJvdmVkPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJSRUpFQ1RFRFwiPlJlamVjdGVkPC9TZWxlY3QuT3B0aW9uPiAqL31cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwidW5rbm93blwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXllbGxvdy02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8UXVlc3Rpb25DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXllbGxvdy01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFVua25vd25cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiYWNjZXB0XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZ3JlZW4tNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIEFjY2VwdGVkXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkFQUFJPVkVEXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtYmx1ZS02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8RXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICBBcHByb3ZlZFxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJSRUpFQ1RFRFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXJlZC02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2xvc2VDaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlamVjdGVkXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImRlbGV0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWdyYXktNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPERlbGV0ZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIERlbGV0ZWRcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBOb3RlIChPcHRpb25hbClcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxJbnB1dC5UZXh0QXJlYVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBZGQgYW55IG5vdGVzIHJlZ2FyZGluZyB0aGlzIHN0YXR1cyBjaGFuZ2VcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2FwcHJvdmFsTm90ZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QXBwcm92YWxOb3RlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIHJvd3M9ezR9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHNldFNob3dBcHByb3ZhbE1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgc2V0Q3VycmVudEJvcnJvd2VyKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRBcHByb3ZhbFN0YXR1cyhcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgc2V0QXBwcm92YWxOb3RlKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZC1tZFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlQXBwcm92YWxTdGF0dXMoYXBwcm92YWxTdGF0dXMpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCBob3ZlcjpiZy1ibHVlLTcwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgVXBkYXRlIFN0YXR1c1xyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPEFudE1vZGFsXHJcbiAgICAgICAgICBvcGVuPXtpc0xvYW5Nb2RhbE9wZW59XHJcbiAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0SXNMb2FuTW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAgIGZvb3Rlcj17bnVsbH1cclxuICAgICAgICAgIGNlbnRlcmVkXHJcbiAgICAgICAgICB3aWR0aD17NDIwfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xXCI+XHJcblxyXG4gICAgICAgICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIFVwZGF0ZSBMb2FuIEFtb3VudFxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICBNb2RpZnkgcmVxdWVzdGVkIGFuZCBhcHByb3ZlZCBsb2FuIGFtb3VudFxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogUmVxdWVzdGVkIEFtb3VudCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01XCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIFJlcXVlc3RlZCBMb2FuIEFtb3VudFxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIHByZWZpeD17PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPuKCuTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHJlcXVlc3RlZCBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2xvYW5BbW91bnRzLnJlcXVlc3RlZF9sb2FuX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldExvYW5BbW91bnRzKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5sb2FuQW1vdW50cyxcclxuICAgICAgICAgICAgICAgICAgICByZXF1ZXN0ZWRfbG9hbl9hbW91bnQ6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhsb2FuQW1vdW50cz8ucmVxdWVzdGVkX2xvYW5fYW1vdW50KX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEFwcHJvdmVkIEFtb3VudCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIEFwcHJvdmVkIExvYW4gQW1vdW50XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgcHJlZml4PXs8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+4oK5PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYXBwcm92ZWQgYW1vdW50XCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtsb2FuQW1vdW50cy5hcHByb3ZlZF9sb2FuX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldExvYW5BbW91bnRzKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5sb2FuQW1vdW50cyxcclxuICAgICAgICAgICAgICAgICAgICBhcHByb3ZlZF9sb2FuX2Ftb3VudDogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGxvYW5BbW91bnRzPy5hcHByb3ZlZF9sb2FuX2Ftb3VudCl9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBCdXR0b25zICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0zIHB0LTJcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0xvYW5Nb2RhbE9wZW4oZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS03MDAgZm9udC1tZWRpdW0gaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3VibWl0TG9hbkFtb3VudHN9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTIuNSByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNjYWxlLVsxLjAyXSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFN1Ym1pdFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQW50TW9kYWw+XHJcbiAgICAgICAgey8qIFBlbmFsdHkgLyBFeHRyYSBDaGFyZ2VzIE1vZGFsICovfVxyXG5cclxuICAgICAgICA8QW50TW9kYWxcclxuICAgICAgICAgIG9wZW49e3Nob3dQZW5hbHR5TW9kYWx9XHJcbiAgICAgICAgICBvbkNhbmNlbD17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTaG93UGVuYWx0eU1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0UGVuYWx0eUxvYW4obnVsbCk7XHJcbiAgICAgICAgICAgIHNldFBlbmFsdHlDaGFyZ2VzKFt7IGFtb3VudDogXCJcIiwgcmVhc29uOiBcIlwiIH1dKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgICBjZW50ZXJlZFxyXG4gICAgICAgICAgd2lkdGg9ezcwMH1cclxuICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMCBmb250LWJvbGQgdGV4dC1sZ1wiPlZpZXcgUGVuYWx0eSBDaGFyZ2VzPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxyXG4gICAgICAgICAgICB7LyogTG9hbiBTdW1tYXJ5ICovfVxyXG4gICAgICAgICAgICB7cGVuYWx0eUxvYW4gJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwIGJvcmRlciBib3JkZXItb3JhbmdlLTIwMCByb3VuZGVkLXhsIHAtNCBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdGV4dC1ncmF5LTUwMCBmb250LWJvbGRcIj5Cb3Jyb3dlcjwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BlbmFsdHlMb2FuPy5ib3Jyb3dlcj8uZnVsbF9uYW1lIHx8IHBlbmFsdHlMb2FuPy5ib3Jyb3dlcl9uYW1lIHx8IFwi4oCUXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdGV4dC1ncmF5LTUwMCBmb250LWJvbGRcIj5Mb2FuIElEPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+e3BlbmFsdHlMb2FuPy5sb2FuX2lkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+TG9hbiBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmVlbi02MDBcIj7igrl7cGVuYWx0eUxvYW4/LmxvYW5fYW1vdW50fTwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+RHVlIERhdGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGVuYWx0eUxvYW4/LmVuZF9kYXRlPy5zcGxpdChcIlRcIilbMF0/LnNwbGl0KFwiLVwiKT8ucmV2ZXJzZSgpPy5qb2luKFwiLVwiKSB8fCBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBFeGlzdGluZyBFeHRyYSBDaGFyZ2VzICovfVxyXG4gICAgICAgICAgICB7cGVuYWx0eUxvYW4/LmV4dHJhX2NoYXJnZXM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNVwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2UgbWItMlwiPkV4aXN0aW5nIENoYXJnZXM8L3A+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBib3JkZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgdGV4dC1ncmF5LTYwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWxlZnRcIj5TdGF0dXM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtbGVmdFwiPlJlYXNvbjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodFwiPkNoYXJnZSAo4oK5KTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodFwiPlBhaWQgKOKCuSk8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHRcIj5CYWxhbmNlICjigrkpPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGVuYWx0eUxvYW4uZXh0cmFfY2hhcmdlcy5tYXAoKGNoYXJnZSwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzUGFpZCA9IGNoYXJnZS5wYWlkID09PSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYWlkQW1vdW50ID0gY2hhcmdlLnBhaWRfYW1vdW50IHx8IChpc1BhaWQgPyBjaGFyZ2UuYW1vdW50IDogMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJhbGFuY2VBbW91bnQgPSBjaGFyZ2UuYmFsYW5jZV9hbW91bnQgfHwgKGlzUGFpZCA/IDAgOiBjaGFyZ2UuYW1vdW50IC0gcGFpZEFtb3VudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGF0dXNUZXh0ID0gXCJVbnBhaWRcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXR1c0NvbG9yID0gXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNQYWlkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzVGV4dCA9IFwiUGFpZFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c0NvbG9yID0gXCJiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDBcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChwYWlkQW1vdW50ID4gMCAmJiBwYWlkQW1vdW50IDwgY2hhcmdlLmFtb3VudCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c1RleHQgPSBcIlBhcnRpYWxseSBQYWlkXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzQ29sb3IgPSBcImJnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctNzAwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtjaGFyZ2UuX2lkIHx8IGlkeH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCAke3N0YXR1c0NvbG9yfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0dXNUZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWdyYXktNzAwXCI+e2NoYXJnZS5yZWFzb259PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodCBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtOdW1iZXIoY2hhcmdlLmFtb3VudCB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodCB0ZXh0LWdyZWVuLTYwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYWlkQW1vdW50ID4gMCA/IGDigrkke3BhaWRBbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gIDogXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHQgdGV4dC1yZWQtNjAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JhbGFuY2VBbW91bnQgPiAwID8gYOKCuSR7YmFsYW5jZUFtb3VudC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAgOiBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICA8dGZvb3QgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwIHRleHQtb3JhbmdlLTgwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49XCIyXCIgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc21cIj5Ub3RhbHM8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7cGVuYWx0eUxvYW4uZXh0cmFfY2hhcmdlcy5yZWR1Y2UoKHMsIGMpID0+IHMgKyBOdW1iZXIoYy5hbW91bnQgfHwgMCksIDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtwZW5hbHR5TG9hbi5leHRyYV9jaGFyZ2VzLnJlZHVjZSgocywgYykgPT4gcyArIE51bWJlcihjLnBhaWRfYW1vdW50IHx8IChjLnBhaWQgPyBjLmFtb3VudCA6IDApKSwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e3BlbmFsdHlMb2FuLmV4dHJhX2NoYXJnZXMucmVkdWNlKChzLCBjKSA9PiBzICsgTnVtYmVyKGMuYmFsYW5jZV9hbW91bnQgfHwgKGMucGFpZCA/IDAgOiBjLmFtb3VudCAtIChjLnBhaWRfYW1vdW50IHx8IDApKSksIDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGZvb3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBOZXcgQ2hhcmdlcyBJbnB1dCAqL31cclxuICAgICAgICAgICAgey8qIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlIG1iLTNcIj5BZGQgTmV3IENoYXJnZXM8L3A+ICovfVxyXG4gICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICB7cGVuYWx0eUNoYXJnZXMubWFwKChjaGFyZ2UsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgaXRlbXMtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTMyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQW1vdW50IOKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2hhcmdlLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlUGVuYWx0eUNoYW5nZShpbmRleCwgXCJhbW91bnRcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJlZml4PVwi4oK5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZWFzb24gKGUuZy4gTGF0ZSBmZWUsIFBlbmFsdHkpXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjaGFyZ2UucmVhc29ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVQZW5hbHR5Q2hhbmdlKGluZGV4LCBcInJlYXNvblwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAge3BlbmFsdHlDaGFyZ2VzLmxlbmd0aCA+IDEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlUGVuYWx0eVJvdyhpbmRleCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwIHRleHQtbGcgZm9udC1ib2xkIHB4LTIgcHktMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgw5dcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICB7LyogTmV3IENoYXJnZXMgVG90YWwgUHJldmlldyAqL31cclxuICAgICAgICAgICAge3BlbmFsdHlDaGFyZ2VzLnNvbWUoYyA9PiBjLmFtb3VudCkgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkIHRleHQtb3JhbmdlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgTmV3IENoYXJnZXMgVG90YWw6IOKCuXtwZW5hbHR5Q2hhcmdlcy5yZWR1Y2UoKHMsIGMpID0+IHMgKyBOdW1iZXIoYy5hbW91bnQgfHwgMCksIDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7LyogPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZFBlbmFsdHlSb3d9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LWJsdWUtNjAwIHRleHQtc20gZm9udC1tZWRpdW0gaG92ZXI6dW5kZXJsaW5lIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICsgQWRkIEFub3RoZXIgQ2hhcmdlXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPiAqL31cclxuXHJcbiAgICAgICAgICAgIHsvKiBGb290ZXIgQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIG10LTYgcHQtNCBib3JkZXItdFwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0U2hvd1BlbmFsdHlNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgIHNldFBlbmFsdHlMb2FuKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRQZW5hbHR5Q2hhcmdlcyhbeyBhbW91bnQ6IFwiXCIsIHJlYXNvbjogXCJcIiB9XSk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIHsvKiA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQZW5hbHR5U3VibWl0fVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BlbmFsdHlMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yIHJvdW5kZWQtbGcgYmctb3JhbmdlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCBob3ZlcjpiZy1vcmFuZ2UtNjAwIGRpc2FibGVkOm9wYWNpdHktNjAgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtwZW5hbHR5TG9hZGluZyA/IFwiU2F2aW5nLi4uXCIgOiBcIlNhdmUgUGVuYWx0eSBDaGFyZ2VzXCJ9XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+ICovfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQW50TW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgTG9hbjtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0xvYW4uanN4In0=