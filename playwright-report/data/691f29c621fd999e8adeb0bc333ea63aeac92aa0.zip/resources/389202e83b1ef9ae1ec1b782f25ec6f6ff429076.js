import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/WhatsappMarketingMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, Briefcase, ChevronRight, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { MdEmail } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { RiMoneyRupeeCircleLine } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const WhatsappMarketingMenu = () => {
  const whatsappmarketingCategories = [
    {
      id: 1,
      title: "Login",
      description: "Login to Interakt",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 19,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "https://app.interakt.ai/login",
      target: "_blank",
      stats: "Login"
    },
    {
      id: 2,
      title: "Outstanding Whatsapp Management",
      description: "Manage Outstanding Whatsapp Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 31,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/due-whatsapp-marketing",
      target: "_self",
      stats: "Active Outstanding Message"
    },
    {
      id: 3,
      title: "Lead Whatsapp Management",
      description: "Manage Lead Whatsapp Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 44,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/lead-whatsapp-marketing",
      target: "_self",
      stats: "Active Lead Message"
    },
    {
      id: 4,
      title: "Customer Whatsapp Management",
      description: "Manage Customer Whatsapp Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 56,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/customer-whatsapp-marketing",
      target: "_self",
      stats: "Active Customer Message"
    },
    {
      id: 5,
      title: "Auction Whatsapp Management",
      description: "Manage Auction Whatsapp Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 68,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing",
      target: "_self",
      stats: "Active Auction Message"
    },
    {
      id: 7,
      title: "Promotion Whatsapp Management",
      description: "Manage promotion  Whatsapp Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 80,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/promo-whatsapp-marketing",
      target: "_self",
      stats: "Active Promotion Message"
    },
    {
      id: 8,
      title: "Loan Whatsapp Management",
      description: "Manage Loan  Whatsapp Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 92,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/loan-whatsapp-marketing",
      target: "_self",
      stats: "Active Promotion Message"
    },
    {
      id: 6,
      title: "Penalty Whatsapp Management",
      description: "Manage penalty  Whatsapp Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 104,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/penalty-whatsapp-marketing",
      target: "_self",
      stats: "Active Penalty Message"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
      lineNumber: 119,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 121,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
          lineNumber: 123,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-gray-900", children: "Whatsapp Marketing Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
            lineNumber: 125,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Manage and organize your Whatsapp Marketing" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
            lineNumber: 128,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
          lineNumber: 124,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 lg:grid-cols-4 gap-6", children: whatsappmarketingCategories.map(
          (category) => /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", target: category.target, children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `relative h-full overflow-hidden rounded-xl bg-white border ${category.borderColor} shadow-md hover:shadow-lg transition-all duration-300`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${category.color} opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 transition-all duration-300 blur-xl`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                    lineNumber: 139,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "relative p-7", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `inline-flex items-center justify-center w-14 h-14 ${category.lightColor} rounded-lg mb-5 group-hover:scale-105 transition-transform duration-300`,
                      children: /* @__PURE__ */ jsxDEV("div", { children: category.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                        lineNumber: 147,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                      lineNumber: 144,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-950 transition-colors", children: category.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                      lineNumber: 151,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 leading-relaxed", children: category.description }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                      lineNumber: 154,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                    lineNumber: 150,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-gray-100 group-hover:border-gray-200 transition-colors", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                      lineNumber: 160,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `p-1.5 rounded-lg bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-100 transform translate-x-1 group-hover:translate-x-0 transition-all duration-300`,
                        children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-white" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                          lineNumber: 166,
                          columnNumber: 27
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                        lineNumber: 163,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                    lineNumber: 159,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                  lineNumber: 143,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
                    lineNumber: 171,
                    columnNumber: 21
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
              lineNumber: 136,
              columnNumber: 19
            },
            this
          ) }, category.id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
            lineNumber: 135,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
          lineNumber: 133,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-16 p-8 bg-gradient-to-br from-violet-50 to-indigo-50 rounded-2xl border border-violet-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-violet-600 mt-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
            lineNumber: 181,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
            lineNumber: 180,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900 mb-2", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
              lineNumber: 184,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: "Manage whatsapp and more with Marketing Management—everything in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
              lineNumber: 185,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
            lineNumber: 183,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
          lineNumber: 179,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
          lineNumber: 178,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
        lineNumber: 122,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
      lineNumber: 120,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
    lineNumber: 118,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx",
    lineNumber: 117,
    columnNumber: 5
  }, this);
};
_c = WhatsappMarketingMenu;
export default WhatsappMarketingMenu;
var _c;
$RefreshReg$(_c, "WhatsappMarketingMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappMarketingMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JZO0FBbEJaLDJCQUFxQjtBQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdkMsT0FBT0EsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLE9BQU9DLFdBQVdDLGNBQWFDLFdBQVk7QUFDcEQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsOEJBQThCO0FBQ3ZDLE9BQU9DLGdCQUFnQjtBQUl2QixNQUFNQyx3QkFBd0JBLE1BQU07QUFDbEMsUUFBTUMsOEJBQThCO0FBQUEsSUFFbEM7QUFBQSxNQUNFQyxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDckNDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQSxNQUNOQyxRQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNDO0FBQUEsTUFDQ1QsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQ3JDQyxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLGFBQWE7QUFBQSxNQUNiQyxNQUFNO0FBQUEsTUFDTkMsUUFBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFFRTtBQUFBLE1BQ0FULElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0I7QUFBQSxNQUNyQ0MsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBLE1BQ05DLFFBQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0k7QUFBQSxNQUNGVCxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDckNDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQSxNQUNOQyxRQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNHO0FBQUEsTUFDRFQsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQ3JDQyxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLGFBQWE7QUFBQSxNQUNiQyxNQUFNO0FBQUEsTUFDTkMsUUFBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDSztBQUFBLE1BQ0hULElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0I7QUFBQSxNQUNyQ0MsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBLE1BQ05DLFFBQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ2dCO0FBQUEsTUFDZFQsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQ3JDQyxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLGFBQWE7QUFBQSxNQUNiQyxNQUFNO0FBQUEsTUFDTkMsUUFBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDSztBQUFBLE1BQ0hULElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0I7QUFBQSxNQUNyQ0MsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBLE1BQ05DLFFBQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQUM7QUFLSCxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLDJCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFDUix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsU0FBSSxXQUFVLE9BQ0w7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNuQix1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxvQ0FBbUMsNkNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsMkRBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNaVixzQ0FBNEJXO0FBQUFBLFVBQUksQ0FBQ0MsYUFDaEMsdUJBQUMsUUFBdUIsSUFBSUEsU0FBU0osTUFBTSxXQUFVLFNBQVEsUUFBUUksU0FBU0gsUUFDNUU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsOERBQThERyxTQUFTTCxXQUFXO0FBQUEsY0FFN0Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHNEQUFzREssU0FBU1AsS0FBSztBQUFBO0FBQUEsa0JBRGpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDb0w7QUFBQSxnQkFHcEwsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyxxREFBcURPLFNBQVNOLFVBQVU7QUFBQSxzQkFFbkYsaUNBQUMsU0FBS00sbUJBQVNSLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0I7QUFBQTtBQUFBLG9CQUh0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDJDQUFDLFFBQUcsV0FBVSxvRkFDWFEsbUJBQVNWLFNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FDVlUsbUJBQVNULGVBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsaUhBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUseUdBQ2JTLG1CQUFTRixTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLHNDQUFzQ0UsU0FBU1AsS0FBSztBQUFBLHdCQUUvRCxpQ0FBQyxnQkFBYSxXQUFVLHdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE0QztBQUFBO0FBQUEsc0JBSDlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJQTtBQUFBLHVCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxxQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEwQkE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHdEQUF3RE8sU0FBU1AsS0FBSztBQUFBO0FBQUEsa0JBRG5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDd0o7QUFBQTtBQUFBO0FBQUEsWUFwQzFKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXNDQSxLQXZDU08sU0FBU1gsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3Q0E7QUFBQSxRQUNELEtBM0NIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxRQUNFLHVCQUFDLFNBQUksV0FBVSxnR0FDakIsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsT0FBSSxXQUFVLGtDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNkNBQTRDLDBCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFLHVCQUFDLE9BQUUsV0FBVSxrQkFBaUIsMkZBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlHO0FBQUEsZUFGM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLEtBVEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVKO0FBQUEsV0FsRUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1FQTtBQUFBLFNBckVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzRUE7QUFBQSxPQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUVBLEtBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyRUE7QUFFSjtBQUFFWSxLQXRMSWQ7QUF3TE4sZUFBZUE7QUFBc0IsSUFBQWM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5hdmJhciIsIlNpZGViYXIiLCJVc2VycyIsIkJyaWVmY2FzZSIsIkNoZXZyb25SaWdodCIsIlphcCIsIk1kRW1haWwiLCJGYVdoYXRzYXBwIiwiUmlNb25leVJ1cGVlQ2lyY2xlTGluZSIsIkJyZWFkY3J1bWIiLCJXaGF0c2FwcE1hcmtldGluZ01lbnUiLCJ3aGF0c2FwcG1hcmtldGluZ0NhdGVnb3JpZXMiLCJpZCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJpY29uIiwiY29sb3IiLCJsaWdodENvbG9yIiwiYm9yZGVyQ29sb3IiLCJocmVmIiwidGFyZ2V0Iiwic3RhdHMiLCJtYXAiLCJjYXRlZ29yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIldoYXRzYXBwTWFya2V0aW5nTWVudS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IFVzZXJzLCBCcmllZmNhc2UsIENoZXZyb25SaWdodCxaYXAgIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBNZEVtYWlsIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHAgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgUmlNb25leVJ1cGVlQ2lyY2xlTGluZSB9IGZyb20gXCJyZWFjdC1pY29ucy9yaVwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5cclxuXHJcbmNvbnN0IFdoYXRzYXBwTWFya2V0aW5nTWVudSA9ICgpID0+IHtcclxuICBjb25zdCB3aGF0c2FwcG1hcmtldGluZ0NhdGVnb3JpZXMgPSBbXHJcbiAgXHJcbiAgICB7XHJcbiAgICAgIGlkOiAxLFxyXG4gICAgICB0aXRsZTogXCJMb2dpblwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2dpbiB0byBJbnRlcmFrdFwiLFxyXG4gICAgICBpY29uOiA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz4sXHJcbiAgICAgIGNvbG9yOiBcImZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNzAwXCIsXHJcbiAgICAgIGxpZ2h0Q29sb3I6IFwiYmctdmlvbGV0LTUwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci12aW9sZXQtMjAwXCIsXHJcbiAgICAgIGhyZWY6IFwiaHR0cHM6Ly9hcHAuaW50ZXJha3QuYWkvbG9naW5cIiwgXHJcbiAgICAgIHRhcmdldDpcIl9ibGFua1wiLFxyXG4gICAgICBzdGF0czogXCJMb2dpblwiLFxyXG4gICAgfSxcclxuICAgICB7XHJcbiAgICAgIGlkOiAyLFxyXG4gICAgICB0aXRsZTogXCJPdXRzdGFuZGluZyBXaGF0c2FwcCBNYW5hZ2VtZW50XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBPdXRzdGFuZGluZyBXaGF0c2FwcCBNZXNzYWdlXCIsXHJcbiAgICAgIGljb246IDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPixcclxuICAgICAgY29sb3I6IFwiZnJvbS12aW9sZXQtNjAwIHRvLXZpb2xldC03MDBcIixcclxuICAgICAgbGlnaHRDb2xvcjogXCJiZy12aW9sZXQtNTBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLXZpb2xldC0yMDBcIixcclxuICAgICAgaHJlZjogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2R1ZS13aGF0c2FwcC1tYXJrZXRpbmdcIixcclxuICAgICAgdGFyZ2V0OlwiX3NlbGZcIixcclxuICAgICAgc3RhdHM6IFwiQWN0aXZlIE91dHN0YW5kaW5nIE1lc3NhZ2VcIixcclxuICAgIH0sXHJcblxyXG4gICAgICB7XHJcbiAgICAgIGlkOiAzLFxyXG4gICAgICB0aXRsZTogXCJMZWFkIFdoYXRzYXBwIE1hbmFnZW1lbnRcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIExlYWQgV2hhdHNhcHAgTWVzc2FnZVwiLFxyXG4gICAgICBpY29uOiA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz4sXHJcbiAgICAgIGNvbG9yOiBcImZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNzAwXCIsXHJcbiAgICAgIGxpZ2h0Q29sb3I6IFwiYmctdmlvbGV0LTUwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci12aW9sZXQtMjAwXCIsXHJcbiAgICAgIGhyZWY6IFwiL21hcmtldC1tZW51L3doYXRzYXBwLW1hcmtldGluZy9sZWFkLXdoYXRzYXBwLW1hcmtldGluZ1wiLFxyXG4gICAgICB0YXJnZXQ6XCJfc2VsZlwiLFxyXG4gICAgICBzdGF0czogXCJBY3RpdmUgTGVhZCBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgaWQ6IDQsXHJcbiAgICAgIHRpdGxlOiBcIkN1c3RvbWVyIFdoYXRzYXBwIE1hbmFnZW1lbnRcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIEN1c3RvbWVyIFdoYXRzYXBwIE1lc3NhZ2VcIixcclxuICAgICAgaWNvbjogPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLXZpb2xldC01MFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItdmlvbGV0LTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvY3VzdG9tZXItd2hhdHNhcHAtbWFya2V0aW5nXCIsXHJcbiAgICAgIHRhcmdldDpcIl9zZWxmXCIsXHJcbiAgICAgIHN0YXRzOiBcIkFjdGl2ZSBDdXN0b21lciBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG4gICAgICAge1xyXG4gICAgICBpZDogNSxcclxuICAgICAgdGl0bGU6IFwiQXVjdGlvbiBXaGF0c2FwcCBNYW5hZ2VtZW50XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBBdWN0aW9uIFdoYXRzYXBwIE1lc3NhZ2VcIixcclxuICAgICAgaWNvbjogPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLXZpb2xldC01MFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItdmlvbGV0LTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvYXVjdGlvbi13aGF0c2FwcC1tYXJrZXRpbmdcIixcclxuICAgICAgdGFyZ2V0OlwiX3NlbGZcIixcclxuICAgICAgc3RhdHM6IFwiQWN0aXZlIEF1Y3Rpb24gTWVzc2FnZVwiLFxyXG4gICAgfSxcclxuICAgICAgICAge1xyXG4gICAgICBpZDogNyxcclxuICAgICAgdGl0bGU6IFwiUHJvbW90aW9uIFdoYXRzYXBwIE1hbmFnZW1lbnRcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIHByb21vdGlvbiAgV2hhdHNhcHAgTWVzc2FnZVwiLFxyXG4gICAgICBpY29uOiA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz4sXHJcbiAgICAgIGNvbG9yOiBcImZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNzAwXCIsXHJcbiAgICAgIGxpZ2h0Q29sb3I6IFwiYmctdmlvbGV0LTUwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci12aW9sZXQtMjAwXCIsXHJcbiAgICAgIGhyZWY6IFwiL21hcmtldC1tZW51L3doYXRzYXBwLW1hcmtldGluZy9wcm9tby13aGF0c2FwcC1tYXJrZXRpbmdcIixcclxuICAgICAgdGFyZ2V0OlwiX3NlbGZcIixcclxuICAgICAgc3RhdHM6IFwiQWN0aXZlIFByb21vdGlvbiBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgaWQ6IDgsXHJcbiAgICAgIHRpdGxlOiBcIkxvYW4gV2hhdHNhcHAgTWFuYWdlbWVudFwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgTG9hbiAgV2hhdHNhcHAgTWVzc2FnZVwiLFxyXG4gICAgICBpY29uOiA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz4sXHJcbiAgICAgIGNvbG9yOiBcImZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNzAwXCIsXHJcbiAgICAgIGxpZ2h0Q29sb3I6IFwiYmctdmlvbGV0LTUwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci12aW9sZXQtMjAwXCIsXHJcbiAgICAgIGhyZWY6IFwiL21hcmtldC1tZW51L3doYXRzYXBwLW1hcmtldGluZy9sb2FuLXdoYXRzYXBwLW1hcmtldGluZ1wiLFxyXG4gICAgICB0YXJnZXQ6XCJfc2VsZlwiLFxyXG4gICAgICBzdGF0czogXCJBY3RpdmUgUHJvbW90aW9uIE1lc3NhZ2VcIixcclxuICAgIH0sXHJcbiAgICAgICAgIHtcclxuICAgICAgaWQ6IDYsXHJcbiAgICAgIHRpdGxlOiBcIlBlbmFsdHkgV2hhdHNhcHAgTWFuYWdlbWVudFwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgcGVuYWx0eSAgV2hhdHNhcHAgTWVzc2FnZVwiLFxyXG4gICAgICBpY29uOiA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz4sXHJcbiAgICAgIGNvbG9yOiBcImZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNzAwXCIsXHJcbiAgICAgIGxpZ2h0Q29sb3I6IFwiYmctdmlvbGV0LTUwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci12aW9sZXQtMjAwXCIsXHJcbiAgICAgIGhyZWY6IFwiL21hcmtldC1tZW51L3doYXRzYXBwLW1hcmtldGluZy9wZW5hbHR5LXdoYXRzYXBwLW1hcmtldGluZ1wiLFxyXG4gICAgICB0YXJnZXQ6XCJfc2VsZlwiLFxyXG4gICAgICBzdGF0czogXCJBY3RpdmUgUGVuYWx0eSBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG4gICBcclxuICAgICBcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gdy1mdWxsIGJnLWdyYXktNTBcIj5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICBXaGF0c2FwcCBNYXJrZXRpbmcgTWFuYWdlbWVudFxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICBNYW5hZ2UgYW5kIG9yZ2FuaXplIHlvdXIgV2hhdHNhcHAgTWFya2V0aW5nXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBsZzpncmlkLWNvbHMtNCBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgIHt3aGF0c2FwcG1hcmtldGluZ0NhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPExpbmsga2V5PXtjYXRlZ29yeS5pZH0gdG89e2NhdGVnb3J5LmhyZWZ9IGNsYXNzTmFtZT1cImdyb3VwXCIgdGFyZ2V0PXtjYXRlZ29yeS50YXJnZXR9PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgaC1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJnLXdoaXRlIGJvcmRlciAke2NhdGVnb3J5LmJvcmRlckNvbG9yfSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctMzIgaC0zMiBiZy1ncmFkaWVudC10by1iciAke2NhdGVnb3J5LmNvbG9yfSBvcGFjaXR5LTUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMCByb3VuZGVkLWZ1bGwgLW1yLTE2IC1tdC0xNiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYmx1ci14bGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwLTdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTQgaC0xNCAke2NhdGVnb3J5LmxpZ2h0Q29sb3J9IHJvdW5kZWQtbGcgbWItNSBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj57Y2F0ZWdvcnkuaWNvbn08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi0yIGdyb3VwLWhvdmVyOnRleHQtZ3JheS05NTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGdyb3VwLWhvdmVyOmJvcmRlci1ncmF5LTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZ3JvdXAtaG92ZXI6dGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5zdGF0c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1sZyBiZy1ncmFkaWVudC10by1iciAke2NhdGVnb3J5LmNvbG9yfSBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNmb3JtIHRyYW5zbGF0ZS14LTEgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgcmlnaHQtMCBoLTAuNSBiZy1ncmFkaWVudC10by1yICR7Y2F0ZWdvcnkuY29sb3J9IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xNiBwLTggYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdG8taW5kaWdvLTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItdmlvbGV0LTEwMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXZpb2xldC02MDAgbXQtMVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMlwiPlF1aWNrIFRpcHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDBcIj5NYW5hZ2Ugd2hhdHNhcHAgYW5kIG1vcmUgd2l0aCBNYXJrZXRpbmcgTWFuYWdlbWVudOKAlGV2ZXJ5dGhpbmcgaW4gb25lIHBsYWNlLjwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBXaGF0c2FwcE1hcmtldGluZ01lbnU7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9XaGF0c2FwcE1hcmtldGluZ01lbnUuanN4In0=