import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/alerts/CustomAlert.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import {
  FaCheckCircle,
  FaTimesCircle,
  FaExclamationTriangle,
  FaInfoCircle,
  FaTimes
} from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const memo = __vite__cjsImport4_react["memo"]; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
const CustomAlert = _s(memo(_c = _s(({ isVisible, type = "info", message, noReload = false }) => {
  _s();
  const [isClosing, setIsClosing] = useState(false);
  const alertConfig = {
    success: {
      bg: "bg-green-50",
      text: "text-green-800",
      border: "border-green-300",
      icon: /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "h-5 w-5 text-green-400" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx",
        lineNumber: 18,
        columnNumber: 13
      }, this)
    },
    error: {
      bg: "bg-red-50",
      text: "text-red-800",
      border: "border-red-300",
      icon: /* @__PURE__ */ jsxDEV(FaTimesCircle, { className: "h-5 w-5 text-red-400" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx",
        lineNumber: 24,
        columnNumber: 13
      }, this)
    },
    warning: {
      bg: "bg-yellow-50",
      text: "text-yellow-800",
      border: "border-yellow-300",
      icon: /* @__PURE__ */ jsxDEV(FaExclamationTriangle, { className: "h-5 w-5 text-yellow-400" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx",
        lineNumber: 30,
        columnNumber: 13
      }, this)
    },
    info: {
      bg: "bg-violet-50",
      text: "text-violet-800",
      border: "border-violet-300",
      icon: /* @__PURE__ */ jsxDEV(FaInfoCircle, { className: "h-5 w-5 text-violet-400" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx",
        lineNumber: 36,
        columnNumber: 13
      }, this)
    }
  };
  useEffect(() => {
    if (isVisible) {
      setIsClosing(false);
      const timer = setTimeout(() => {
        setIsClosing(true);
        if (!noReload)
          window.location.reload();
      }, 2e3);
      return () => clearTimeout(timer);
    }
  }, [isVisible]);
  if (!isVisible && !isClosing) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed top-4 left-1/2 z-[100] -translate-x-1/2 transform", children: /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `${alertConfig[type].bg} ${alertConfig[type].border} ${alertConfig[type].text} flex w-full max-w-xs items-center rounded-lg p-4 shadow-lg transition-all duration-300 md:max-w-md ${isClosing ? "translate-y-[-100%] opacity-0" : "translate-y-0 opacity-100"}`,
      role: "alert",
      "aria-live": "assertive",
      children: [
        alertConfig[type].icon,
        /* @__PURE__ */ jsxDEV("span", { className: "ml-3 flex-1 break-words text-sm font-medium", children: message }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx",
          lineNumber: 71,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setIsClosing(true);
            },
            className: `ml-auto -mx-1.5 -my-1.5 rounded-full p-1.5 hover:bg-gray-200 hover:bg-opacity-90`,
            "aria-label": "Close",
            children: /* @__PURE__ */ jsxDEV(FaTimes, { className: "h-5 w-5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx",
              lineNumber: 81,
              columnNumber: 11
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx",
            lineNumber: 74,
            columnNumber: 9
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx",
      lineNumber: 59,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
}, "ipWZdoaKtkla/sNXeWUi9+m3qRw=")), "ipWZdoaKtkla/sNXeWUi9+m3qRw=");
_c2 = CustomAlert;
export default CustomAlert;
var _c, _c2;
$RefreshReg$(_c, "CustomAlert$memo");
$RefreshReg$(_c2, "CustomAlert");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlert.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJZOzJCQWpCWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLE1BQU1DLFdBQVdDLGdCQUFnQjtBQUUxQyxNQUFNQyxjQUFXQyxHQUFHSixLQUFJSyxLQUFBRCxHQUFDLENBQUMsRUFBRUUsV0FBV0MsT0FBTyxRQUFRQyxTQUFTQyxXQUFVLE1BQUssTUFBTTtBQUFBTCxLQUFBO0FBQ2xGLFFBQU0sQ0FBQ00sV0FBV0MsWUFBWSxJQUFJVCxTQUFTLEtBQUs7QUFFaEQsUUFBTVUsY0FBYztBQUFBLElBQ2xCQyxTQUFTO0FBQUEsTUFDUEMsSUFBSTtBQUFBLE1BQ0pDLE1BQU07QUFBQSxNQUNOQyxRQUFRO0FBQUEsTUFDUkMsTUFBTSx1QkFBQyxpQkFBYyxXQUFVLDRCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsSUFDekQ7QUFBQSxJQUNBQyxPQUFPO0FBQUEsTUFDTEosSUFBSTtBQUFBLE1BQ0pDLE1BQU07QUFBQSxNQUNOQyxRQUFRO0FBQUEsTUFDUkMsTUFBTSx1QkFBQyxpQkFBYyxXQUFVLDBCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStDO0FBQUEsSUFDdkQ7QUFBQSxJQUNBRSxTQUFTO0FBQUEsTUFDUEwsSUFBSTtBQUFBLE1BQ0pDLE1BQU07QUFBQSxNQUNOQyxRQUFRO0FBQUEsTUFDUkMsTUFBTSx1QkFBQyx5QkFBc0IsV0FBVSw2QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRDtBQUFBLElBQ2xFO0FBQUEsSUFDQUcsTUFBTTtBQUFBLE1BQ0pOLElBQUk7QUFBQSxNQUNKQyxNQUFNO0FBQUEsTUFDTkMsUUFBUTtBQUFBLE1BQ1JDLE1BQU0sdUJBQUMsZ0JBQWEsV0FBVSw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLElBQ3pEO0FBQUEsRUFDRjtBQUVBaEIsWUFBVSxNQUFNO0FBQ2QsUUFBSUssV0FBVztBQUNiSyxtQkFBYSxLQUFLO0FBRWxCLFlBQU1VLFFBQVFDLFdBQVcsTUFBTTtBQUM3QlgscUJBQWEsSUFBSTtBQUNqQixZQUFHLENBQUNGO0FBQ0pjLGlCQUFPQyxTQUFTQyxPQUFPO0FBQUEsTUFFekIsR0FBRyxHQUFJO0FBRVAsYUFBTyxNQUFNQyxhQUFhTCxLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsQ0FBQ2YsU0FBUyxDQUFDO0FBRWQsTUFBSSxDQUFDQSxhQUFhLENBQUNJLFVBQVcsUUFBTztBQUVyQyxTQUNFLHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVyxHQUFHRSxZQUFZTCxJQUFJLEVBQUVPLEVBQUUsSUFBSUYsWUFBWUwsSUFBSSxFQUFFUyxNQUFNLElBQzVESixZQUFZTCxJQUFJLEVBQUVRLElBQUksdUdBRXRCTCxZQUNJLGtDQUNBLDJCQUEyQjtBQUFBLE1BRWpDLE1BQUs7QUFBQSxNQUNMLGFBQVU7QUFBQSxNQUVURTtBQUFBQSxvQkFBWUwsSUFBSSxFQUFFVTtBQUFBQSxRQUNuQix1QkFBQyxVQUFLLFdBQVUsK0NBQ2JULHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTtBQUNiRywyQkFBYSxJQUFJO0FBQUEsWUFDbkI7QUFBQSxZQUNBLFdBQVc7QUFBQSxZQUNYLGNBQVc7QUFBQSxZQUVYLGlDQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QjtBQUFBO0FBQUEsVUFQOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQTtBQUFBO0FBQUEsSUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBd0JBLEtBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFFSixHQUFDLGtDQUFDO0FBQUNnQixNQTVFR3hCO0FBOEVOLGVBQWVBO0FBQVksSUFBQUUsSUFBQXNCO0FBQUFDLGFBQUF2QixJQUFBO0FBQUF1QixhQUFBRCxLQUFBIiwibmFtZXMiOlsiRmFDaGVja0NpcmNsZSIsIkZhVGltZXNDaXJjbGUiLCJGYUV4Y2xhbWF0aW9uVHJpYW5nbGUiLCJGYUluZm9DaXJjbGUiLCJGYVRpbWVzIiwibWVtbyIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQ3VzdG9tQWxlcnQiLCJfcyIsIl9jIiwiaXNWaXNpYmxlIiwidHlwZSIsIm1lc3NhZ2UiLCJub1JlbG9hZCIsImlzQ2xvc2luZyIsInNldElzQ2xvc2luZyIsImFsZXJ0Q29uZmlnIiwic3VjY2VzcyIsImJnIiwidGV4dCIsImJvcmRlciIsImljb24iLCJlcnJvciIsIndhcm5pbmciLCJpbmZvIiwidGltZXIiLCJzZXRUaW1lb3V0Iiwid2luZG93IiwibG9jYXRpb24iLCJyZWxvYWQiLCJjbGVhclRpbWVvdXQiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ3VzdG9tQWxlcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgRmFDaGVja0NpcmNsZSxcclxuICBGYVRpbWVzQ2lyY2xlLFxyXG4gIEZhRXhjbGFtYXRpb25UcmlhbmdsZSxcclxuICBGYUluZm9DaXJjbGUsXHJcbiAgRmFUaW1lcyxcclxufSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgbWVtbywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuY29uc3QgQ3VzdG9tQWxlcnQgPSBtZW1vKCh7IGlzVmlzaWJsZSwgdHlwZSA9IFwiaW5mb1wiLCBtZXNzYWdlICxub1JlbG9hZCA9ZmFsc2V9KSA9PiB7XHJcbiAgY29uc3QgW2lzQ2xvc2luZywgc2V0SXNDbG9zaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgYWxlcnRDb25maWcgPSB7XHJcbiAgICBzdWNjZXNzOiB7XHJcbiAgICAgIGJnOiBcImJnLWdyZWVuLTUwXCIsXHJcbiAgICAgIHRleHQ6IFwidGV4dC1ncmVlbi04MDBcIixcclxuICAgICAgYm9yZGVyOiBcImJvcmRlci1ncmVlbi0zMDBcIixcclxuICAgICAgaWNvbjogPEZhQ2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LWdyZWVuLTQwMFwiIC8+LFxyXG4gICAgfSxcclxuICAgIGVycm9yOiB7XHJcbiAgICAgIGJnOiBcImJnLXJlZC01MFwiLFxyXG4gICAgICB0ZXh0OiBcInRleHQtcmVkLTgwMFwiLFxyXG4gICAgICBib3JkZXI6IFwiYm9yZGVyLXJlZC0zMDBcIixcclxuICAgICAgaWNvbjogPEZhVGltZXNDaXJjbGUgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LXJlZC00MDBcIiAvPixcclxuICAgIH0sXHJcbiAgICB3YXJuaW5nOiB7XHJcbiAgICAgIGJnOiBcImJnLXllbGxvdy01MFwiLFxyXG4gICAgICB0ZXh0OiBcInRleHQteWVsbG93LTgwMFwiLFxyXG4gICAgICBib3JkZXI6IFwiYm9yZGVyLXllbGxvdy0zMDBcIixcclxuICAgICAgaWNvbjogPEZhRXhjbGFtYXRpb25UcmlhbmdsZSBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQteWVsbG93LTQwMFwiIC8+LFxyXG4gICAgfSxcclxuICAgIGluZm86IHtcclxuICAgICAgYmc6IFwiYmctdmlvbGV0LTUwXCIsXHJcbiAgICAgIHRleHQ6IFwidGV4dC12aW9sZXQtODAwXCIsXHJcbiAgICAgIGJvcmRlcjogXCJib3JkZXItdmlvbGV0LTMwMFwiLFxyXG4gICAgICBpY29uOiA8RmFJbmZvQ2lyY2xlIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC12aW9sZXQtNDAwXCIgLz4sXHJcbiAgICB9LFxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNWaXNpYmxlKSB7XHJcbiAgICAgIHNldElzQ2xvc2luZyhmYWxzZSk7XHJcblxyXG4gICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldElzQ2xvc2luZyh0cnVlKTtcclxuICAgICAgICBpZighbm9SZWxvYWQpXHJcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xyXG4gICAgICAgIC8vIHNldFRpbWVvdXQob25DbG9zZSwgMzAwKTtcclxuICAgICAgfSwgMjAwMCk7XHJcblxyXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH1cclxuICB9LCBbaXNWaXNpYmxlXSk7XHJcblxyXG4gIGlmICghaXNWaXNpYmxlICYmICFpc0Nsb3NpbmcpIHJldHVybiBudWxsO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtNCBsZWZ0LTEvMiB6LVsxMDBdIC10cmFuc2xhdGUteC0xLzIgdHJhbnNmb3JtXCI+XHJcbiAgICAgIDxkaXZcclxuICAgICAgICBjbGFzc05hbWU9e2Ake2FsZXJ0Q29uZmlnW3R5cGVdLmJnfSAke2FsZXJ0Q29uZmlnW3R5cGVdLmJvcmRlcn0gJHtcclxuICAgICAgICAgIGFsZXJ0Q29uZmlnW3R5cGVdLnRleHRcclxuICAgICAgICB9IGZsZXggdy1mdWxsIG1heC13LXhzIGl0ZW1zLWNlbnRlciByb3VuZGVkLWxnIHAtNCBzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG1kOm1heC13LW1kICR7XHJcbiAgICAgICAgICBpc0Nsb3NpbmdcclxuICAgICAgICAgICAgPyBcInRyYW5zbGF0ZS15LVstMTAwJV0gb3BhY2l0eS0wXCJcclxuICAgICAgICAgICAgOiBcInRyYW5zbGF0ZS15LTAgb3BhY2l0eS0xMDBcIlxyXG4gICAgICAgIH1gfVxyXG4gICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgYXJpYS1saXZlPVwiYXNzZXJ0aXZlXCJcclxuICAgICAgPlxyXG4gICAgICAgIHthbGVydENvbmZpZ1t0eXBlXS5pY29ufVxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgZmxleC0xIGJyZWFrLXdvcmRzIHRleHQtc20gZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgIHttZXNzYWdlfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldElzQ2xvc2luZyh0cnVlKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BtbC1hdXRvIC1teC0xLjUgLW15LTEuNSByb3VuZGVkLWZ1bGwgcC0xLjUgaG92ZXI6YmctZ3JheS0yMDAgaG92ZXI6Ymctb3BhY2l0eS05MGB9XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2VcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxGYVRpbWVzIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn0pO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ3VzdG9tQWxlcnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydC5qc3gifQ==