import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UnApprovedEmployee.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Input, Select, Dropdown, Modal as madal } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { fieldSize } from "/src/data/fieldSize.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const { confirm } = madal;
const UnApprovedEmployee = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [TableEmployees, setTableEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [currentUpdateUser, setCurrentUpdateUser] = useState(null);
  const [unVerifiedUser, setUnVerifiedUser] = useState(null);
  const [errors, setErrors] = useState({});
  const [searchText, setSearchText] = useState("");
  const [selectedManagerId, setSelectedManagerId] = useState("");
  const [selectedReportingManagerId, setSelectedReportingManagerId] = useState("");
  const [managers, setManagers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [selectedManagerTitle, setSelectedManagerTitle] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone_number: "",
    password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    designation_id: "",
    pan_no: "",
    agent_type: "employee",
    joining_date: "",
    status: "",
    dob: "",
    gender: "",
    alternate_number: "",
    salary: "",
    leaving_date: "",
    emergency_contact_person: "",
    emergency_contact_number: [""],
    total_allocated_leaves: "2",
    isVerified: false
  });
  const [updateFormData, setUpdateFormData] = useState({
    name: "",
    email: "",
    phone_number: "",
    password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    designation_id: "",
    pan_no: "",
    joining_date: "",
    status: "",
    dob: "",
    gender: "",
    alternate_number: "",
    salary: "",
    leaving_date: "",
    emergency_contact_person: "",
    emergency_contact_number: [""],
    total_allocated_leaves: "2",
    isVerified: ""
  });
  useEffect(() => {
    const fetchEmployeeProfile = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/agent/get-additional-employee-info");
        const employeeData = response.data?.employee || [];
        setUsers(employeeData);
        const formattedData = employeeData.filter((emp) => emp.isVerified === false).map((group, index) => ({
          _id: group?._id,
          id: index + 1,
          name: group?.name || "N/A",
          employeeCode: group?.unique_code || "N/A",
          phone_number: group?.phone_number || "N/A",
          password: group?.password || "N/A",
          designation: group?.designation_id?.title || "N/A",
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 113,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-blue-600",
                        onClick: () => handleUnverifyEmployee(group._id),
                        children: "Verify"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 124,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 135,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 147,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 106,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 105,
            columnNumber: 11
          }, this)
        }));
        console.info(formattedData, "test check");
        setTableEmployees(formattedData);
      } catch (error) {
        console.error("Error fetching user data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchEmployeeProfile();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchManagers = async () => {
      try {
        const response = await api.get("/designation/get-designation");
        setManagers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchManagers();
  }, [reloadTrigger]);
  const handleAntDSelectManager = (managerId) => {
    setSelectedManagerId(managerId);
    const selected = managers.find((mgr) => mgr._id === managerId);
    const title = selected?.title || "";
    setSelectedManagerTitle(title);
    setFormData((prev) => ({
      ...prev,
      managerId,
      managerTitle: title
    }));
    setErrors((prev) => ({
      ...prev,
      managerId: "",
      managerTitle: ""
    }));
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [field]: "" }));
  };
  const handleAntDSelectReportingManager = (reportingId) => {
    setSelectedReportingManagerId(reportingId);
    setFormData((prev) => ({
      ...prev,
      reportingManagerId: reportingId
    }));
    setErrors((prev) => ({
      ...prev,
      reportingManagerId: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addEmployee" ? formData : updateFormData;
    const regex = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[6-9]\d{9}$/,
      password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{5,}$/,
      pincode: /^\d{6}$/,
      aadhaar: /^\d{12}$/,
      pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/,
      alternate_number: /^[6-9]\d{9}$/
    };
    if (!data.name || !data.name.trim()) {
      newErrors.name = "Full Name is required";
    }
    if (!data.email) {
      newErrors.email = "Email is required";
    } else if (!regex.email.test(data.email)) {
      newErrors.email = "Invalid email format";
    }
    if (!data.phone_number) {
      newErrors.phone_number = "Phone number is required";
    } else if (!regex.phone.test(data.phone_number)) {
      newErrors.phone_number = "Invalid  phone number";
    }
    if (!data.alternate_number) {
      newErrors.alternate_number = "Alternate Phone number is required";
    } else if (!regex.alternate_number.test(data.alternate_number)) {
      newErrors.alternate_number = "Invalid Alternate  phone number";
    }
    if (!data.password) {
      newErrors.password = "Password is required";
    } else if (!regex.password.test(data.password)) {
      newErrors.password = "Password must contain at least 5 characters, one uppercase, one lowercase, one number, and one special character";
    }
    if (!data.status) {
      newErrors.status = "Status is required";
    }
    if (!data.dob) {
      newErrors.dob = "Date of Birth is required";
    }
    if (!data.joining_date) {
      newErrors.joining_date = "Joining Date is required";
    }
    if (!data.gender) {
      newErrors.gender = "Please Select Gender";
    }
    if (!data.salary) {
      newErrors.salary = "Salary is required";
    }
    if (!data.pincode) {
      newErrors.pincode = "Pincode is required";
    } else if (!regex.pincode.test(data.pincode)) {
      newErrors.pincode = "Invalid pincode (6 digits required)";
    }
    if (!data.adhaar_no) {
      newErrors.adhaar_no = "Aadhaar number is required";
    } else if (!regex.aadhaar.test(data.adhaar_no)) {
      newErrors.adhaar_no = "Invalid Aadhaar number (12 digits required)";
    }
    if (!data.pan_no) {
      newErrors.pan_no = "PAN number is required";
    } else if (!regex.pan.test(data.pan_no.toUpperCase())) {
      newErrors.pan_no = "Invalid PAN format (e.g., ABCDE1234F)";
    }
    if (!data.address || !data.address.trim()) {
      newErrors.address = "Address is required";
    } else if (data.address.trim().length < 10) {
      newErrors.address = "Address should be at least 10 characters";
    }
    if (!data.emergency_contact_person) {
      newErrors.emergency_contact_person = "Contact Person Name is Required";
    }
    if (!data.total_allocated_leaves) {
      newErrors.total_allocated_leaves = "Please Provide Total Allocated Leaves";
    }
    if (!selectedManagerId) {
      newErrors.designation_id = "Please Enter Designation";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const addPhoneField = (formState, setFormState) => {
    const phones = [...formState.emergency_contact_number || []];
    const lastPhone = phones[phones.length - 1];
    if (phones.length > 0 && (!lastPhone || lastPhone.trim() === "")) {
      alert(
        "Please fill in the last emergency contact number before adding a new one."
      );
      return;
    }
    setFormState({
      ...formState,
      emergency_contact_number: [...phones, ""]
    });
  };
  const handlePhoneChange = (formState, setFormState, index, e) => {
    const value = e.target.value;
    let phones = formState.emergency_contact_number && formState.emergency_contact_number.length > 0 ? [...formState.emergency_contact_number] : [""];
    while (phones.length <= index) {
      phones.push("");
    }
    phones[index] = value;
    const lastIndex = phones.reduceRight((lastNonEmpty, phone, i) => {
      return lastNonEmpty !== -1 ? lastNonEmpty : phone.trim() !== "" ? i : -1;
    }, -1);
    phones = lastIndex === -1 ? [""] : phones.slice(0, lastIndex + 1);
    setFormState({
      ...formState,
      emergency_contact_number: phones
    });
  };
  const removePhoneField = (formState, setFormState, index) => {
    const phones = Array.isArray(formState.emergency_contact_number) ? [...formState.emergency_contact_number] : [];
    const updatedPhones = phones.filter((_, i) => i !== index);
    setFormState({
      ...formState,
      emergency_contact_number: updatedPhones
    });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValidate = validateForm("addEmployee");
    try {
      if (isValidate) {
        const dataToSend = {
          ...formData,
          designation_id: selectedManagerId,
          reporting_manager_id: selectedReportingManagerId,
          agent_type: "employee"
        };
        const response = await api.post(
          "/agent/add-addtional-employee-info",
          dataToSend,
          {
            headers: {
              "Content-Type": "application/json"
            }
          }
        );
        setShowModal(false);
        setFormData({
          name: "",
          email: "",
          phone_number: "",
          password: "",
          address: "",
          pincode: "",
          adhaar_no: "",
          pan_no: "",
          joining_date: "",
          status: "",
          dob: "",
          gender: "",
          alternate_number: "",
          salary: "",
          leaving_date: "",
          emergency_contact_person: "",
          emergency_contact_number: [""],
          total_allocated_leaves: "2",
          isVerified: false
        });
        setSelectedManagerId("");
        setSelectedReportingManagerId("");
        setReloadTrigger((prev) => prev + 1);
      }
    } catch (error) {
      console.error("Error adding Employee:", error);
      if (error.response && error.response.data && error.response.data.message) {
        const errMsg = error.response.data.message.toLowerCase();
        if (errMsg.includes("phone number")) {
          setErrors((prevErrors) => ({
            ...prevErrors,
            phone_number: "Phone number already exists"
          }));
        } else {
          setAlertConfig({
            visibility: true,
            message: error.response.data.message,
            type: "error"
          });
        }
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "name", header: "Employee Name" },
    { key: "employeeCode", header: "Employee ID" },
    { key: "phone_number", header: "Employee Phone Number" },
    { key: "designation", header: "Designation" },
    // { key: "password", header: "Employee Password" },
    { key: "action", header: "Action" }
  ];
  const filteredUsers = users.filter(
    (user) => user.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/agent/get-additional-employee-info-by-id/${userId}`
      );
      setCurrentUser(response.data?.employee);
      setShowModalDelete(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/agent/get-additional-employee-info-by-id/${userId}`
      );
      setCurrentUpdateUser(response.data?.employee);
      setUnVerifiedUser(response.data?.employee);
      setUpdateFormData({
        name: response?.data?.employee?.name,
        email: response?.data?.employee?.email,
        phone_number: response?.data?.employee?.phone_number,
        password: response?.data?.employee?.password,
        pincode: response?.data?.employee?.pincode,
        adhaar_no: response?.data?.employee?.adhaar_no,
        pan_no: response?.data?.employee?.pan_no,
        address: response?.data?.employee?.address,
        joining_date: response?.data?.employee?.joining_date?.split("T")[0],
        status: response?.data?.employee?.status,
        dob: response?.data?.employee?.dob?.split("T")[0],
        gender: response?.data?.employee?.gender,
        alternate_number: response?.data?.employee?.alternate_number,
        salary: response?.data?.employee?.salary,
        leaving_date: response?.data?.employee?.leaving_date?.split("T")[0],
        emergency_contact_number: response?.data?.employee?.emergency_contact_number || [""],
        emergency_contact_person: response?.data?.employee?.emergency_contact_person,
        total_allocated_leaves: response?.data?.employee?.total_allocated_leaves?.toString() || "2"
      });
      setSelectedManagerId(response.data?.employee?.designation_id?._id || "");
      setSelectedReportingManagerId(
        response.data?.employee?.reporting_manager_id || ""
      );
      setSelectedManagerTitle(response.data?.employee?.designation_id?.title);
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleDeleteUser = async () => {
    if (currentUser) {
      try {
        await api.delete(
          `/agent/delete-additional-employee-info-by-id/${currentUser._id}`
        );
        setShowModalDelete(false);
        setCurrentUser(null);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Agent deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    }
  };
  const handleUnverifyEmployee = async (id) => {
    confirm({
      title: "Are you sure you want to Verify this Employee?",
      content: "This action will mark the Employee as Verified.",
      okText: "Yes, Verify",
      cancelText: "Cancel",
      async onOk() {
        try {
          console.log(id, " thhis is unverfied use");
          const response = await api.put(
            `/agent/un-approve-employee/${id}`,
            {
              isVerified: true
            }
          );
          setReloadTrigger((prev) => prev + 1);
          setAlertConfig({
            visibility: true,
            message: "Employee Un-Verified Successfully",
            type: "success"
          });
        } catch (error) {
          setAlertConfig({
            visibility: true,
            message: error?.response?.data?.message || "Failed to verify agent",
            type: "error"
          });
        }
      }
    });
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        const dataToSend = {
          ...updateFormData,
          designation_id: selectedManagerId,
          reporting_manager_id: selectedReportingManagerId
        };
        console.log(currentUpdateUser, "this isi yy");
        const response = await api.put(
          `/agent/update-additional-employee-info/${currentUpdateUser._id}`,
          dataToSend
        );
        setShowModalUpdate(false);
        setSelectedManagerId("");
        setSelectedReportingManagerId("");
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Employee Details Updated Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error updating agent:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error.response.data.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const handleManager = async (event) => {
    const groupId = event.target.value;
    setSelectedManagerId(groupId);
    const selected = managers.find((mgr) => mgr._id === groupId);
    setSelectedManagerTitle(selected?.title || "");
  };
  const handleReportingManager = async (event) => {
    const reportingId = event.target.value;
    setSelectedReportingManagerId(reportingId);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 627,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
        lineNumber: 631,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 632,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 641,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Un-verified Employees" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 644,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 643,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 642,
          columnNumber: 13
        }, this),
        TableEmployees?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableEmployees, searchText),
            columns,
            exportedPdfName: "Employee",
            exportedFileName: `Employees.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 657,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableEmployees?.length <= 0,
            data: "Employee Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 665,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
        lineNumber: 640,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
      lineNumber: 626,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Employee" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
        lineNumber: 675,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Full Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 684,
                  columnNumber: 29
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 680,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "name",
              value: formData.name,
              onChange: handleChange,
              id: "name",
              placeholder: "Enter the Full Name",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 686,
              columnNumber: 17
            },
            this
          ),
          errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 697,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 679,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Email ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 706,
                    columnNumber: 27
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 702,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "email",
                name: "email",
                value: formData.email,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Email",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 708,
                columnNumber: 19
              },
              this
            ),
            errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 719,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 701,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Phone Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 727,
                    columnNumber: 34
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 723,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "phone_number",
                value: formData.phone_number,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Phone Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 729,
                columnNumber: 19
              },
              this
            ),
            errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 740,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 722,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 700,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "pass",
                children: [
                  "Password ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 752,
                    columnNumber: 30
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 748,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "pass",
                name: "password",
                value: formData.password,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Password",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 754,
                columnNumber: 19
              },
              this
            ),
            errors.password && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.password }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 765,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 747,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Pincode ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 775,
                    columnNumber: 29
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 771,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "pincode",
                value: formData.pincode,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Pincode",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 777,
                columnNumber: 19
              },
              this
            ),
            errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 788,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 770,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 746,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Adhaar Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 800,
                    columnNumber: 35
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 796,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "adhaar_no",
                value: formData.adhaar_no,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Adhaar Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 802,
                columnNumber: 19
              },
              this
            ),
            errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 813,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 795,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Pan Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 823,
                    columnNumber: 32
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 819,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                name: "pan_no",
                value: formData.pan_no,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Pan Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 825,
                columnNumber: 19
              },
              this
            ),
            errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 836,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 818,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 794,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Address ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 845,
                  columnNumber: 27
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 841,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "address",
              value: formData.address,
              onChange: handleChange,
              id: "name",
              placeholder: "Enter the Address",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 847,
              columnNumber: 17
            },
            this
          ),
          errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 858,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 840,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "category",
                children: [
                  "Designation ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 867,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 863,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                id: "designation_id",
                name: "designation_id",
                value: selectedManagerId || void 0,
                onChange: handleAntDSelectManager,
                placeholder: "Select Designation",
                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                showSearch: true,
                popupMatchSelectWidth: false,
                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                children: managers.map(
                  (mgr) => /* @__PURE__ */ jsxDEV(Select.Option, { value: mgr._id, children: mgr.title }, mgr._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 885,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 869,
                columnNumber: 19
              },
              this
            ),
            errors.designation_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.designation_id }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 891,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 862,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "status",
                children: [
                  "Status ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 901,
                    columnNumber: 28
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 897,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                placeholder: "Select Status",
                popupMatchSelectWidth: false,
                showSearch: true,
                name: "status",
                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                value: formData?.status || void 0,
                onChange: (value) => handleAntDSelect("status", value),
                children: ["Active", "Inactive", "Terminated"].map(
                  (stype) => /* @__PURE__ */ jsxDEV(Select.Option, { value: stype.toLowerCase(), children: stype }, stype, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 929,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 914,
                columnNumber: 19
              },
              this
            ),
            errors.status && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.status }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 935,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 896,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 861,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "joiningdate",
                children: [
                  "Joining Date ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 945,
                    columnNumber: 34
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 941,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                name: "joining_date",
                value: formData.joining_date,
                onChange: handleChange,
                id: "joiningdate",
                placeholder: "Enter Employee Joining Date",
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 947,
                columnNumber: 19
              },
              this
            ),
            errors.joining_date && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.joining_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 957,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 940,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "ld",
                children: [
                  "Leaving Date ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 967,
                    columnNumber: 34
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 963,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                name: "leaving_date",
                value: formData.leaving_date,
                onChange: handleChange,
                id: "ld",
                placeholder: "Enter Leaving Date",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 969,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 962,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 939,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "dob",
                children: [
                  "Date of Birth ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 987,
                    columnNumber: 35
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 983,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                name: "dob",
                value: formData.dob,
                onChange: handleChange,
                id: "dob",
                placeholder: "Enter Employee Date of Birth",
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 989,
                columnNumber: 19
              },
              this
            ),
            errors.dob && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.dob }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 999,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 982,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "gender",
                children: [
                  "Gender ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1007,
                    columnNumber: 28
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1003,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                placeholder: "Select Gender",
                popupMatchSelectWidth: false,
                showSearch: true,
                name: "gender",
                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                value: formData?.gender || void 0,
                onChange: (value) => handleAntDSelect("gender", value),
                children: ["Male", "Female", "Others"].map(
                  (gender) => /* @__PURE__ */ jsxDEV(Select.Option, { value: gender.toLowerCase(), children: gender }, gender, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1034,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1019,
                columnNumber: 19
              },
              this
            ),
            errors.gender && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.gender }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1040,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1002,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 981,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "sal",
                children: [
                  "Salary ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1050,
                    columnNumber: 28
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1046,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "salary",
                value: formData.salary,
                onChange: handleChange,
                id: "sal",
                placeholder: "Enter Your Salary",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1052,
                columnNumber: 19
              },
              this
            ),
            errors.salary && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.salary }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1063,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1045,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "alternate",
                children: [
                  "Alternate Phone Number",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1072,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1067,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "alternate_number",
                value: formData.alternate_number,
                onChange: handleChange,
                id: "alternate",
                placeholder: "Enter Alternate Phone Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1074,
                columnNumber: 19
              },
              this
            ),
            errors.alternate_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.alternate_number }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1085,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1066,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 1044,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "total_allocated_leaves",
                children: [
                  "Total Allocated Leaves",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1098,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1093,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "total_allocated_leaves",
                value: formData.total_allocated_leaves,
                onChange: handleChange,
                id: "total_allocated_leaves",
                placeholder: "Enter total allocated leaves",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1100,
                columnNumber: 19
              },
              this
            ),
            errors.total_allocated_leaves && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.total_allocated_leaves }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1111,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1092,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "cp",
                children: [
                  "Emergency Contact Person",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1122,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1117,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                name: "emergency_contact_person",
                value: formData.emergency_contact_person,
                onChange: handleChange,
                id: "cp",
                placeholder: "Enter Emergency Contact Person Name",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1124,
                columnNumber: 19
              },
              this
            ),
            errors.emergency_contact_person && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.emergency_contact_person }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1135,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1116,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 1091,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "emergency",
              children: [
                "Emergency Phone Number",
                " "
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1143,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-2 gap-2", children: /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "tel",
              name: "emergency_contact_number",
              value: formData.emergency_contact_number?.[0] || "",
              onChange: (e) => handlePhoneChange(formData, setFormData, 0, e),
              id: "emergency_0",
              placeholder: "Enter Default Emergency Phone Number",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1150,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1149,
            columnNumber: 19
          }, this),
          formData.emergency_contact_number?.slice(1).map(
            (phone, index) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-2 gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "tel",
                  name: `emergency_phone_${index + 1}`,
                  value: phone,
                  onChange: (e) => handlePhoneChange(
                    formData,
                    setFormData,
                    index + 1,
                    e
                  ),
                  id: `emergency_${index + 1}`,
                  placeholder: "Enter Additional Emergency Phone Number",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1167,
                  columnNumber: 25
                },
                this
              ),
              index > 0 && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => removePhoneField(formData, setFormData, index + 1),
                  className: "text-red-600 text-sm",
                  children: "Remove"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1184,
                  columnNumber: 21
                },
                this
              )
            ] }, index, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1166,
              columnNumber: 19
            }, this)
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => addPhoneField(formData, setFormData),
              className: "mt-2 text-blue-600 text-sm",
              children: "+ Add Another"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1196,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 1142,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 1141,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
            children: "Save Un-verified Employee"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1207,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 1206,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
        lineNumber: 678,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
      lineNumber: 674,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
      lineNumber: 673,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Un-verified Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1223,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Full Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                      lineNumber: 1232,
                      columnNumber: 29
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1228,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "name",
                  value: updateFormData.name,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Full Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1234,
                  columnNumber: 17
                },
                this
              ),
              errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1245,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1227,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Email ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1254,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1250,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "email",
                    name: "email",
                    value: updateFormData.email,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Email",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1256,
                    columnNumber: 19
                  },
                  this
                ),
                errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1267,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1249,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1275,
                        columnNumber: 34
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1271,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "phone_number",
                    value: updateFormData.phone_number,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1277,
                    columnNumber: 19
                  },
                  this
                ),
                errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1288,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1270,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1248,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Adhaar Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1301,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1297,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "adhaar_no",
                    value: updateFormData.adhaar_no,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Adhaar Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1303,
                    columnNumber: 19
                  },
                  this
                ),
                errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1314,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1296,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Pan Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1324,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1320,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "pan_no",
                    value: updateFormData.pan_no,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Pan Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1326,
                    columnNumber: 19
                  },
                  this
                ),
                errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1337,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1319,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1295,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Address ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                      lineNumber: 1346,
                      columnNumber: 27
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1342,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "address",
                  value: updateFormData.address,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Address",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1348,
                  columnNumber: 17
                },
                this
              ),
              errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1359,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1341,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "date",
                  children: [
                    "Pincode ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                      lineNumber: 1369,
                      columnNumber: 29
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1365,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "pincode",
                  value: updateFormData.pincode,
                  onChange: handleInputChange,
                  id: "text",
                  placeholder: "Enter Pincode",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1371,
                  columnNumber: 19
                },
                this
              ),
              errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1382,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1364,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1362,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Designation ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1394,
                        columnNumber: 33
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1390,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    id: "designation_id",
                    name: "designation_id",
                    value: selectedManagerId || void 0,
                    onChange: handleAntDSelectManager,
                    placeholder: "Select Designation",
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    showSearch: true,
                    popupMatchSelectWidth: false,
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    children: managers.map(
                      (manager) => /* @__PURE__ */ jsxDEV(Select.Option, { value: manager._id, children: manager.title }, manager._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1413,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1397,
                    columnNumber: 19
                  },
                  this
                ),
                errors.designation_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.designation_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1419,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1389,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "status",
                    children: [
                      "Status ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1429,
                        columnNumber: 28
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1425,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    placeholder: "Select Status",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "status",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.status || void 0,
                    onChange: (value) => handleAntInputDSelect("status", value),
                    children: ["Active", "Inactive", "Terminated"].map(
                      (status) => /* @__PURE__ */ jsxDEV(Select.Option, { value: status.toLowerCase(), children: status }, status, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1457,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1442,
                    columnNumber: 19
                  },
                  this
                ),
                errors.status && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.status }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1463,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1424,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1388,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "joiningdate",
                    children: [
                      "Joining Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1473,
                        columnNumber: 34
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1469,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "joining_date",
                    value: updateFormData.joining_date,
                    onChange: handleInputChange,
                    id: "joiningdate",
                    placeholder: "Enter Employee Joining Date",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1475,
                    columnNumber: 19
                  },
                  this
                ),
                errors.joining_date && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.joining_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1485,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1468,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "ld",
                    children: [
                      "Leaving Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1495,
                        columnNumber: 34
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1491,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "leaving_date",
                    value: updateFormData?.leaving_date ? new Date(updateFormData?.leaving_date || "").toISOString().split("T")[0] : "",
                    onChange: handleInputChange,
                    id: "ld",
                    placeholder: "Enter Leaving Date",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1497,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1490,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1467,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "doB",
                    children: [
                      "Date of Birth ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1521,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1517,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "dob",
                    value: updateFormData?.dob ? new Date(updateFormData?.dob || "").toISOString().split("T")[0] : "",
                    onChange: handleInputChange,
                    id: "doB",
                    placeholder: "Enter Employee Date of Birth",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1523,
                    columnNumber: 19
                  },
                  this
                ),
                errors.dob && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.dob }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1539,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1516,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "gender",
                    children: [
                      "Gender ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1547,
                        columnNumber: 28
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1543,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    placeholder: "Select Gender",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "gender",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.gender || void 0,
                    onChange: (value) => handleAntInputDSelect("gender", value),
                    children: ["Male", "Female", "Others"].map(
                      (gender) => /* @__PURE__ */ jsxDEV(Select.Option, { value: gender.toLowerCase(), children: gender }, gender, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1574,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1559,
                    columnNumber: 19
                  },
                  this
                ),
                errors.gender && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.gender }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1580,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1542,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1515,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "sal",
                    children: [
                      "Salary ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1590,
                        columnNumber: 28
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1586,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "salary",
                    value: updateFormData.salary,
                    onChange: handleInputChange,
                    id: "sal",
                    placeholder: "Enter Salary",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1592,
                    columnNumber: 19
                  },
                  this
                ),
                errors.salary && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.salary }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1603,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1585,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "alternate",
                    children: [
                      "Alternate Phone Number",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1612,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1607,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "alternate_number",
                    value: updateFormData.alternate_number,
                    onChange: handleInputChange,
                    id: "alternate",
                    placeholder: "Enter Alternate Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1614,
                    columnNumber: 19
                  },
                  this
                ),
                errors.alternate_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.alternate_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1625,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1606,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1584,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "total_allocated_leaves",
                    children: [
                      "Total No. of Leaves ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1637,
                        columnNumber: 41
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1633,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "total_allocated_leaves",
                    value: updateFormData.total_allocated_leaves,
                    onChange: handleInputChange,
                    id: "total_allocated_leaves",
                    placeholder: "Enter total leaves",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1639,
                    columnNumber: 19
                  },
                  this
                ),
                errors.total_allocated_leaves && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.total_allocated_leaves }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1650,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1632,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "cp",
                    children: [
                      "Emergency Contact Person",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                        lineNumber: 1661,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1656,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "emergency_contact_person",
                    value: updateFormData?.emergency_contact_person,
                    onChange: handleInputChange,
                    id: "ld",
                    placeholder: "Enter Emergency Contact Person Name",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1663,
                    columnNumber: 19
                  },
                  this
                ),
                errors.emergency_contact_person && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.emergency_contact_person }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1674,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1655,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1631,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "emergency",
                  children: [
                    "Emergency Phone Number",
                    " "
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1682,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-2 gap-2", children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "tel",
                  name: "emergency_contact_number",
                  value: updateFormData.emergency_contact_number?.[0] || "",
                  onChange: (e) => handlePhoneChange(
                    updateFormData,
                    setUpdateFormData,
                    0,
                    e
                  ),
                  id: "emergency_0",
                  placeholder: "Enter Default Emergency Phone Number",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1689,
                  columnNumber: 21
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1688,
                columnNumber: 19
              }, this),
              updateFormData.emergency_contact_number?.slice(1).map(
                (phone, index) => /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "flex items-center mb-2 gap-2",
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "tel",
                          name: `emergency_phone_${index + 1}`,
                          value: phone,
                          onChange: (e) => handlePhoneChange(
                            updateFormData,
                            setUpdateFormData,
                            index + 1,
                            e
                          ),
                          id: `emergency_${index + 1}`,
                          placeholder: "Enter Additional Emergency Phone Number",
                          className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                          lineNumber: 1714,
                          columnNumber: 25
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          onClick: () => removePhoneField(
                            updateFormData,
                            setUpdateFormData,
                            index + 1
                          ),
                          className: "text-red-600 text-sm",
                          children: "Remove"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                          lineNumber: 1730,
                          columnNumber: 25
                        },
                        this
                      )
                    ]
                  },
                  index + 1,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1710,
                    columnNumber: 19
                  },
                  this
                )
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => addPhoneField(updateFormData, setUpdateFormData),
                  className: "mt-2 text-blue-600 text-sm",
                  children: "+ Add Another"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1745,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1681,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1680,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update Un-verified Employee"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                lineNumber: 1758,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1757,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1226,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 1222,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
        lineNumber: 1218,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentUser(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Un-verified Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
            lineNumber: 1777,
            columnNumber: 13
          }, this),
          currentUser && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteUser();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentUser.name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                          lineNumber: 1794,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                          lineNumber: 1798,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                      lineNumber: 1789,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the employee Full Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                      lineNumber: 1800,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                  lineNumber: 1788,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
                    lineNumber: 1808,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
              lineNumber: 1781,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
          lineNumber: 1776,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
        lineNumber: 1769,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
    lineNumber: 625,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx",
    lineNumber: 624,
    columnNumber: 5
  }, this);
};
_s(UnApprovedEmployee, "NSUUGBKYRc75iGe2f5LnkyzjHIw=");
_c = UnApprovedEmployee;
export default UnApprovedEmployee;
var _c;
$RefreshReg$(_c, "UnApprovedEmployee");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedEmployee.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0h3QixTQStmcEIsVUEvZm9COzJCQWhIeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsT0FBT0MsUUFBUUMsVUFBVUMsU0FBU0MsYUFBYTtBQUN4RCxPQUFPRCxXQUFXO0FBQ2xCLE9BQU9FLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxnQkFBZ0I7QUFDdkIsTUFBTSxFQUFFQyxRQUFRLElBQUlUO0FBQ3BCLE1BQU1VLHFCQUFxQkEsTUFBTTtBQUFBQyxLQUFBO0FBQy9CLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJcEIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3FCLGdCQUFnQkMsaUJBQWlCLElBQUl0QixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDdUIsWUFBWUMsYUFBYSxJQUFJeEIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3lCLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyQixpQkFBaUJDLGtCQUFrQixJQUFJNUIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzZCLGlCQUFpQkMsa0JBQWtCLElBQUk5QixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDK0IsYUFBYUMsY0FBYyxJQUFJaEMsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQ2lDLG1CQUFtQkMsb0JBQW9CLElBQUlsQyxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDbUMsZ0JBQWdCQyxpQkFBaUIsSUFBSXBDLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUNxQyxRQUFRQyxTQUFTLElBQUl0QyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUN1QyxZQUFZQyxhQUFhLElBQUl4QyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDeUMsbUJBQW1CQyxvQkFBb0IsSUFBSTFDLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUMyQyw0QkFBNEJDLDZCQUE2QixJQUM5RDVDLFNBQVMsRUFBRTtBQUNiLFFBQU0sQ0FBQzZDLFVBQVVDLFdBQVcsSUFBSTlDLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUMrQyxXQUFXQyxZQUFZLElBQUloRCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDaUQsZUFBZUMsZ0JBQWdCLElBQUlsRCxTQUFTLENBQUM7QUFDcEQsUUFBTW1ELDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJkLGtCQUFjYSxLQUFLO0FBQUEsRUFDckI7QUFDQSxRQUFNLENBQUNFLHNCQUFzQkMsdUJBQXVCLElBQUl4RCxTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDeUQsYUFBYUMsY0FBYyxJQUFJMUQsU0FBUztBQUFBLElBQzdDMkQsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUkvRCxTQUFTO0FBQUEsSUFDdkNnRSxNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLGNBQWM7QUFBQSxJQUNkQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsZ0JBQWdCO0FBQUEsSUFDaEJDLFFBQVE7QUFBQSxJQUNSQyxZQUFZO0FBQUEsSUFDWkMsY0FBYztBQUFBLElBQ2RDLFFBQVE7QUFBQSxJQUNSQyxLQUFLO0FBQUEsSUFDTEMsUUFBUTtBQUFBLElBQ1JDLGtCQUFrQjtBQUFBLElBQ2xCQyxRQUFRO0FBQUEsSUFDUkMsY0FBYztBQUFBLElBQ2RDLDBCQUEwQjtBQUFBLElBQzFCQywwQkFBMEIsQ0FBQyxFQUFFO0FBQUEsSUFDN0JDLHdCQUF3QjtBQUFBLElBQ3hCQyxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJdEYsU0FBUztBQUFBLElBQ25EZ0UsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUEsSUFDZEMsVUFBVTtBQUFBLElBQ1ZDLFNBQVM7QUFBQSxJQUNUQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLGdCQUFnQjtBQUFBLElBQ2hCQyxRQUFRO0FBQUEsSUFDUkUsY0FBYztBQUFBLElBQ2RDLFFBQVE7QUFBQSxJQUNSQyxLQUFLO0FBQUEsSUFDTEMsUUFBUTtBQUFBLElBQ1JDLGtCQUFrQjtBQUFBLElBQ2xCQyxRQUFRO0FBQUEsSUFDUkMsY0FBYztBQUFBLElBQ2RDLDBCQUEwQjtBQUFBLElBQzFCQywwQkFBMEIsQ0FBQyxFQUFFO0FBQUEsSUFDN0JDLHdCQUF3QjtBQUFBLElBQ3hCQyxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBQ0RyRixZQUFVLE1BQU07QUFDZCxVQUFNd0YsdUJBQXVCLFlBQVk7QUFDdkMsVUFBSTtBQUNGdkMscUJBQWEsSUFBSTtBQUNqQixjQUFNd0MsV0FBVyxNQUFNaEYsSUFBSWlGLElBQUkscUNBQXFDO0FBQ3BFLGNBQU1DLGVBQWVGLFNBQVNHLE1BQU1DLFlBQVk7QUFDaER4RSxpQkFBU3NFLFlBQVk7QUFDckIsY0FBTUcsZ0JBQWdCSCxhQUFhSSxPQUFPLENBQUNDLFFBQVFBLElBQUlYLGVBQWUsS0FBSyxFQUFFWSxJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxVQUNsR0MsS0FBS0YsT0FBT0U7QUFBQUEsVUFDWkMsSUFBSUYsUUFBUTtBQUFBLFVBQ1psQyxNQUFNaUMsT0FBT2pDLFFBQVE7QUFBQSxVQUNyQnFDLGNBQWNKLE9BQU9LLGVBQWU7QUFBQSxVQUNwQ3BDLGNBQWMrQixPQUFPL0IsZ0JBQWdCO0FBQUEsVUFDckNDLFVBQVU4QixPQUFPOUIsWUFBWTtBQUFBLFVBQzdCb0MsYUFBYU4sT0FBTzFCLGdCQUFnQmlDLFNBQVM7QUFBQSxVQUM3Q0MsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsY0FDakIsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU1DLHNCQUFzQlosTUFBTUUsR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFUSxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTUUsdUJBQXVCYixNQUFNRSxHQUFHO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGtCQUNBO0FBQUEsb0JBQ0VRLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNRyxzQkFBc0JkLE1BQU1FLEdBQUc7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKO0FBQUEsZ0JBQUM7QUFBQSxjQUVMO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQTtBQUFBLFlBekNqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUEwQ0EsS0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0Q0E7QUFBQSxRQUVKLEVBQUU7QUFDRmEsZ0JBQVFDLEtBQUtwQixlQUFlLFlBQVk7QUFDeEN2RSwwQkFBa0J1RSxhQUFhO0FBQUEsTUFDakMsU0FBU3FCLE9BQU87QUFDZEYsZ0JBQVFFLE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFDbEQsVUFBQztBQUNDbEUscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBdUMseUJBQXFCO0FBQUEsRUFDdkIsR0FBRyxDQUFDdEMsYUFBYSxDQUFDO0FBQ2xCbEQsWUFBVSxNQUFNO0FBQ2QsVUFBTW9ILGdCQUFnQixZQUFZO0FBQ2hDLFVBQUk7QUFDRixjQUFNM0IsV0FBVyxNQUFNaEYsSUFBSWlGLElBQUksOEJBQThCO0FBQzdEM0Msb0JBQVkwQyxTQUFTRyxJQUFJO0FBQUEsTUFDM0IsU0FBU3VCLE9BQU87QUFDZEYsZ0JBQVFFLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FDLGtCQUFjO0FBQUEsRUFDaEIsR0FBRyxDQUFDbEUsYUFBYSxDQUFDO0FBRWxCLFFBQU1tRSwwQkFBMEJBLENBQUNDLGNBQWM7QUFDN0MzRSx5QkFBcUIyRSxTQUFTO0FBQzlCLFVBQU1DLFdBQVd6RSxTQUFTMEUsS0FBSyxDQUFDQyxRQUFRQSxJQUFJckIsUUFBUWtCLFNBQVM7QUFDN0QsVUFBTWIsUUFBUWMsVUFBVWQsU0FBUztBQUNqQ2hELDRCQUF3QmdELEtBQUs7QUFDN0J6QyxnQkFBWSxDQUFDMEQsVUFBVTtBQUFBLE1BQ3JCLEdBQUdBO0FBQUFBLE1BQ0hKO0FBQUFBLE1BQ0FLLGNBQWNsQjtBQUFBQSxJQUNoQixFQUFFO0FBQ0ZsRSxjQUFVLENBQUNtRixVQUFVO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSEosV0FBVztBQUFBLE1BQ1hLLGNBQWM7QUFBQSxJQUNoQixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1DLG1CQUFtQkEsQ0FBQ0MsT0FBT3ZFLFVBQVU7QUFDekNVLGdCQUFZLENBQUM4RCxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUd2RTtBQUFBQSxJQUNYLEVBQUU7QUFDRmYsY0FBVSxDQUFDd0YsZ0JBQWdCO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRixLQUFLLEdBQUc7QUFBQSxJQUNYLEVBQUU7QUFBQSxFQUNKO0FBQ0EsUUFBTUcsZUFBZUEsQ0FBQzNFLE1BQU07QUFDMUIsVUFBTSxFQUFFWSxNQUFNWCxNQUFNLElBQUlELEVBQUVFO0FBQzFCUyxnQkFBWSxDQUFDOEQsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQzdELElBQUksR0FBR1g7QUFBQUEsSUFDVixFQUFFO0FBQ0ZmLGNBQVUsQ0FBQ3VGLGNBQWM7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNILENBQUM3RCxJQUFJLEdBQUc7QUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBQ0EsUUFBTWdFLHdCQUF3QkEsQ0FBQ0osT0FBT3ZFLFVBQVU7QUFDOUNpQyxzQkFBa0IsQ0FBQ3VDLGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUNELEtBQUssR0FBR3ZFO0FBQUFBLElBQ1gsRUFBRTtBQUNGZixjQUFVLENBQUN3RixnQkFBZ0IsRUFBRSxHQUFHQSxZQUFZLENBQUNGLEtBQUssR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUM1RDtBQUNBLFFBQU1LLG1DQUFtQ0EsQ0FBQ0MsZ0JBQWdCO0FBQ3hEdEYsa0NBQThCc0YsV0FBVztBQUN6Q25FLGdCQUFZLENBQUMwRCxVQUFVO0FBQUEsTUFDckIsR0FBR0E7QUFBQUEsTUFDSFUsb0JBQW9CRDtBQUFBQSxJQUN0QixFQUFFO0FBQ0Y1RixjQUFVLENBQUNtRixVQUFVO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSFUsb0JBQW9CO0FBQUEsSUFDdEIsRUFBRTtBQUFBLEVBQ0o7QUFDQSxRQUFNQyxlQUFlQSxDQUFDdkUsU0FBUztBQUM3QixVQUFNd0UsWUFBWSxDQUFDO0FBQ25CLFVBQU0xQyxPQUFPOUIsU0FBUyxnQkFBZ0JDLFdBQVd1QjtBQUNqRCxVQUFNaUQsUUFBUTtBQUFBLE1BQ1pyRSxPQUFPO0FBQUEsTUFDUHNFLE9BQU87QUFBQSxNQUNQcEUsVUFDRTtBQUFBLE1BQ0ZFLFNBQVM7QUFBQSxNQUNUbUUsU0FBUztBQUFBLE1BQ1RDLEtBQUs7QUFBQSxNQUNMM0Qsa0JBQWtCO0FBQUEsSUFDcEI7QUFDQSxRQUFJLENBQUNhLEtBQUszQixRQUFRLENBQUMyQixLQUFLM0IsS0FBSzBFLEtBQUssR0FBRztBQUNuQ0wsZ0JBQVVyRSxPQUFPO0FBQUEsSUFDbkI7QUFDQSxRQUFJLENBQUMyQixLQUFLMUIsT0FBTztBQUNmb0UsZ0JBQVVwRSxRQUFRO0FBQUEsSUFDcEIsV0FBVyxDQUFDcUUsTUFBTXJFLE1BQU0wRSxLQUFLaEQsS0FBSzFCLEtBQUssR0FBRztBQUN4Q29FLGdCQUFVcEUsUUFBUTtBQUFBLElBQ3BCO0FBQ0EsUUFBSSxDQUFDMEIsS0FBS3pCLGNBQWM7QUFDdEJtRSxnQkFBVW5FLGVBQWU7QUFBQSxJQUMzQixXQUFXLENBQUNvRSxNQUFNQyxNQUFNSSxLQUFLaEQsS0FBS3pCLFlBQVksR0FBRztBQUMvQ21FLGdCQUFVbkUsZUFBZTtBQUFBLElBQzNCO0FBQ0EsUUFBSSxDQUFDeUIsS0FBS2Isa0JBQWtCO0FBQzFCdUQsZ0JBQVV2RCxtQkFBbUI7QUFBQSxJQUMvQixXQUFXLENBQUN3RCxNQUFNeEQsaUJBQWlCNkQsS0FBS2hELEtBQUtiLGdCQUFnQixHQUFHO0FBQzlEdUQsZ0JBQVV2RCxtQkFBbUI7QUFBQSxJQUMvQjtBQUNBLFFBQUksQ0FBQ2EsS0FBS3hCLFVBQVU7QUFDbEJrRSxnQkFBVWxFLFdBQVc7QUFBQSxJQUN2QixXQUFXLENBQUNtRSxNQUFNbkUsU0FBU3dFLEtBQUtoRCxLQUFLeEIsUUFBUSxHQUFHO0FBQzlDa0UsZ0JBQVVsRSxXQUNSO0FBQUEsSUFDSjtBQUNBLFFBQUksQ0FBQ3dCLEtBQUtoQixRQUFRO0FBQ2hCMEQsZ0JBQVUxRCxTQUFTO0FBQUEsSUFDckI7QUFDQSxRQUFJLENBQUNnQixLQUFLZixLQUFLO0FBQ2J5RCxnQkFBVXpELE1BQU07QUFBQSxJQUNsQjtBQUNBLFFBQUksQ0FBQ2UsS0FBS2pCLGNBQWM7QUFDdEIyRCxnQkFBVTNELGVBQWU7QUFBQSxJQUMzQjtBQUNBLFFBQUksQ0FBQ2lCLEtBQUtkLFFBQVE7QUFDaEJ3RCxnQkFBVXhELFNBQVM7QUFBQSxJQUNyQjtBQUNBLFFBQUksQ0FBQ2MsS0FBS1osUUFBUTtBQUNoQnNELGdCQUFVdEQsU0FBUztBQUFBLElBQ3JCO0FBQ0EsUUFBSSxDQUFDWSxLQUFLdEIsU0FBUztBQUNqQmdFLGdCQUFVaEUsVUFBVTtBQUFBLElBQ3RCLFdBQVcsQ0FBQ2lFLE1BQU1qRSxRQUFRc0UsS0FBS2hELEtBQUt0QixPQUFPLEdBQUc7QUFDNUNnRSxnQkFBVWhFLFVBQVU7QUFBQSxJQUN0QjtBQUNBLFFBQUksQ0FBQ3NCLEtBQUtyQixXQUFXO0FBQ25CK0QsZ0JBQVUvRCxZQUFZO0FBQUEsSUFDeEIsV0FBVyxDQUFDZ0UsTUFBTUUsUUFBUUcsS0FBS2hELEtBQUtyQixTQUFTLEdBQUc7QUFDOUMrRCxnQkFBVS9ELFlBQVk7QUFBQSxJQUN4QjtBQUVBLFFBQUksQ0FBQ3FCLEtBQUtuQixRQUFRO0FBQ2hCNkQsZ0JBQVU3RCxTQUFTO0FBQUEsSUFDckIsV0FBVyxDQUFDOEQsTUFBTUcsSUFBSUUsS0FBS2hELEtBQUtuQixPQUFPb0UsWUFBWSxDQUFDLEdBQUc7QUFDckRQLGdCQUFVN0QsU0FBUztBQUFBLElBQ3JCO0FBQ0EsUUFBSSxDQUFDbUIsS0FBS3ZCLFdBQVcsQ0FBQ3VCLEtBQUt2QixRQUFRc0UsS0FBSyxHQUFHO0FBQ3pDTCxnQkFBVWpFLFVBQVU7QUFBQSxJQUN0QixXQUFXdUIsS0FBS3ZCLFFBQVFzRSxLQUFLLEVBQUVHLFNBQVMsSUFBSTtBQUMxQ1IsZ0JBQVVqRSxVQUFVO0FBQUEsSUFDdEI7QUFDQSxRQUFJLENBQUN1QixLQUFLViwwQkFBMEI7QUFDbENvRCxnQkFBVXBELDJCQUEyQjtBQUFBLElBQ3ZDO0FBQ0EsUUFBSSxDQUFDVSxLQUFLUix3QkFBd0I7QUFDaENrRCxnQkFBVWxELHlCQUNSO0FBQUEsSUFDSjtBQUNBLFFBQUksQ0FBQzFDLG1CQUFtQjtBQUN0QjRGLGdCQUFVOUQsaUJBQWlCO0FBQUEsSUFDN0I7QUFFQWpDLGNBQVUrRixTQUFTO0FBQ25CLFdBQU9TLE9BQU9DLEtBQUtWLFNBQVMsRUFBRVEsV0FBVztBQUFBLEVBQzNDO0FBQ0EsUUFBTUcsZ0JBQWdCQSxDQUFDQyxXQUFXQyxpQkFBaUI7QUFDakQsVUFBTUMsU0FBUyxDQUFDLEdBQUlGLFVBQVUvRCw0QkFBNEIsRUFBRztBQUM3RCxVQUFNa0UsWUFBWUQsT0FBT0EsT0FBT04sU0FBUyxDQUFDO0FBQzFDLFFBQUlNLE9BQU9OLFNBQVMsTUFBTSxDQUFDTyxhQUFhQSxVQUFVVixLQUFLLE1BQU0sS0FBSztBQUNoRVc7QUFBQUEsUUFDRTtBQUFBLE1BQ0Y7QUFDQTtBQUFBLElBQ0Y7QUFDQUgsaUJBQWE7QUFBQSxNQUNYLEdBQUdEO0FBQUFBLE1BQ0gvRCwwQkFBMEIsQ0FBQyxHQUFHaUUsUUFBUSxFQUFFO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNRyxvQkFBb0JBLENBQUNMLFdBQVdDLGNBQWNoRCxPQUFPOUMsTUFBTTtBQUMvRCxVQUFNQyxRQUFRRCxFQUFFRSxPQUFPRDtBQUN2QixRQUFJOEYsU0FDRkYsVUFBVS9ELDRCQUNWK0QsVUFBVS9ELHlCQUF5QjJELFNBQVMsSUFDeEMsQ0FBQyxHQUFHSSxVQUFVL0Qsd0JBQXdCLElBQ3RDLENBQUMsRUFBRTtBQUNULFdBQU9pRSxPQUFPTixVQUFVM0MsT0FBTztBQUM3QmlELGFBQU9JLEtBQUssRUFBRTtBQUFBLElBQ2hCO0FBQ0FKLFdBQU9qRCxLQUFLLElBQUk3QztBQUNoQixVQUFNbUcsWUFBWUwsT0FBT00sWUFBWSxDQUFDQyxjQUFjbkIsT0FBT29CLE1BQU07QUFDL0QsYUFBT0QsaUJBQWlCLEtBQUtBLGVBQWVuQixNQUFNRyxLQUFLLE1BQU0sS0FBS2lCLElBQUk7QUFBQSxJQUN4RSxHQUFHLEVBQUU7QUFDTFIsYUFBU0ssY0FBYyxLQUFLLENBQUMsRUFBRSxJQUFJTCxPQUFPUyxNQUFNLEdBQUdKLFlBQVksQ0FBQztBQUNoRU4saUJBQWE7QUFBQSxNQUNYLEdBQUdEO0FBQUFBLE1BQ0gvRCwwQkFBMEJpRTtBQUFBQSxJQUM1QixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU1VLG1CQUFtQkEsQ0FBQ1osV0FBV0MsY0FBY2hELFVBQVU7QUFDM0QsVUFBTWlELFNBQVNXLE1BQU1DLFFBQVFkLFVBQVUvRCx3QkFBd0IsSUFDM0QsQ0FBQyxHQUFHK0QsVUFBVS9ELHdCQUF3QixJQUN0QztBQUNKLFVBQU04RSxnQkFBZ0JiLE9BQU9yRCxPQUFPLENBQUNtRSxHQUFHTixNQUFNQSxNQUFNekQsS0FBSztBQUN6RGdELGlCQUFhO0FBQUEsTUFDWCxHQUFHRDtBQUFBQSxNQUNIL0QsMEJBQTBCOEU7QUFBQUEsSUFDNUIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNRSxlQUFlLE9BQU85RyxNQUFNO0FBQ2hDQSxNQUFFK0csZUFBZTtBQUNqQixVQUFNQyxhQUFhaEMsYUFBYSxhQUFhO0FBQzdDLFFBQUk7QUFDRixVQUFJZ0MsWUFBWTtBQUNkLGNBQU1DLGFBQWE7QUFBQSxVQUNqQixHQUFHdkc7QUFBQUEsVUFDSFMsZ0JBQWdCOUI7QUFBQUEsVUFDaEI2SCxzQkFBc0IzSDtBQUFBQSxVQUN0QjhCLFlBQVk7QUFBQSxRQUNkO0FBQ0EsY0FBTWUsV0FBVyxNQUFNaEYsSUFBSStKO0FBQUFBLFVBQ3pCO0FBQUEsVUFDQUY7QUFBQUEsVUFDQTtBQUFBLFlBQ0VHLFNBQVM7QUFBQSxjQUNQLGdCQUFnQjtBQUFBLFlBQ2xCO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQTlJLHFCQUFhLEtBQUs7QUFDbEJxQyxvQkFBWTtBQUFBLFVBQ1ZDLE1BQU07QUFBQSxVQUNOQyxPQUFPO0FBQUEsVUFDUEMsY0FBYztBQUFBLFVBQ2RDLFVBQVU7QUFBQSxVQUNWQyxTQUFTO0FBQUEsVUFDVEMsU0FBUztBQUFBLFVBQ1RDLFdBQVc7QUFBQSxVQUNYRSxRQUFRO0FBQUEsVUFDUkUsY0FBYztBQUFBLFVBQ2RDLFFBQVE7QUFBQSxVQUNSQyxLQUFLO0FBQUEsVUFDTEMsUUFBUTtBQUFBLFVBQ1JDLGtCQUFrQjtBQUFBLFVBQ2xCQyxRQUFRO0FBQUEsVUFDUkMsY0FBYztBQUFBLFVBQ2RDLDBCQUEwQjtBQUFBLFVBQzFCQywwQkFBMEIsQ0FBQyxFQUFFO0FBQUEsVUFDN0JDLHdCQUF3QjtBQUFBLFVBQ3hCQyxZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQ0QxQyw2QkFBcUIsRUFBRTtBQUN2QkUsc0NBQThCLEVBQUU7QUFDaENNLHlCQUFpQixDQUFDdUUsU0FBU0EsT0FBTyxDQUFDO0FBQUEsTUFNckM7QUFBQSxJQUNGLFNBQVNQLE9BQU87QUFDZEYsY0FBUUUsTUFBTSwwQkFBMEJBLEtBQUs7QUFDN0MsVUFDRUEsTUFBTTFCLFlBQ04wQixNQUFNMUIsU0FBU0csUUFDZnVCLE1BQU0xQixTQUFTRyxLQUFLL0IsU0FDcEI7QUFDQSxjQUFNNkcsU0FBU3ZELE1BQU0xQixTQUFTRyxLQUFLL0IsUUFBUThHLFlBQVk7QUFDdkQsWUFBSUQsT0FBT0UsU0FBUyxjQUFjLEdBQUc7QUFDbkNySSxvQkFBVSxDQUFDd0YsZ0JBQWdCO0FBQUEsWUFDekIsR0FBR0E7QUFBQUEsWUFDSDVELGNBQWM7QUFBQSxVQUNoQixFQUFFO0FBQUEsUUFDSixPQUFPO0FBQ0xSLHlCQUFlO0FBQUEsWUFDYkMsWUFBWTtBQUFBLFlBQ1pDLFNBQVNzRCxNQUFNMUIsU0FBU0csS0FBSy9CO0FBQUFBLFlBQzdCQyxNQUFNO0FBQUEsVUFDUixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0YsT0FBTztBQUNMSCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU0rRyxVQUFVO0FBQUEsSUFDZCxFQUFFakUsS0FBSyxNQUFNa0UsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRWxFLEtBQUssUUFBUWtFLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRWxFLEtBQUssZ0JBQWdCa0UsUUFBUSxjQUFjO0FBQUEsSUFDN0MsRUFBRWxFLEtBQUssZ0JBQWdCa0UsUUFBUSx3QkFBd0I7QUFBQSxJQUN2RCxFQUFFbEUsS0FBSyxlQUFla0UsUUFBUSxjQUFjO0FBQUE7QUFBQSxJQUU1QyxFQUFFbEUsS0FBSyxVQUFVa0UsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUVyQyxRQUFNQyxnQkFBZ0IzSixNQUFNMkU7QUFBQUEsSUFBTyxDQUFDaUYsU0FDbENBLEtBQUsvRyxLQUFLMEcsWUFBWSxFQUFFQyxTQUFTcEosV0FBV21KLFlBQVksQ0FBQztBQUFBLEVBQzNEO0FBQ0EsUUFBTTNELHdCQUF3QixPQUFPaUUsV0FBVztBQUM5QyxRQUFJO0FBQ0YsWUFBTXhGLFdBQVcsTUFBTWhGLElBQUlpRjtBQUFBQSxRQUN6Qiw2Q0FBNkN1RixNQUFNO0FBQUEsTUFDckQ7QUFDQWhKLHFCQUFld0QsU0FBU0csTUFBTUMsUUFBUTtBQUN0Q2hFLHlCQUFtQixJQUFJO0FBQ3ZCVSxnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkLFNBQVM0RSxPQUFPO0FBQ2RGLGNBQVFFLE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBQ0EsUUFBTUwsd0JBQXdCLE9BQU9tRSxXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNeEYsV0FBVyxNQUFNaEYsSUFBSWlGO0FBQUFBLFFBQ3pCLDZDQUE2Q3VGLE1BQU07QUFBQSxNQUNyRDtBQUNBOUksMkJBQXFCc0QsU0FBU0csTUFBTUMsUUFBUTtBQUM1Q3hELHdCQUFrQm9ELFNBQVNHLE1BQU1DLFFBQVE7QUFDekNOLHdCQUFrQjtBQUFBLFFBQ2hCdEIsTUFBTXdCLFVBQVVHLE1BQU1DLFVBQVU1QjtBQUFBQSxRQUNoQ0MsT0FBT3VCLFVBQVVHLE1BQU1DLFVBQVUzQjtBQUFBQSxRQUNqQ0MsY0FBY3NCLFVBQVVHLE1BQU1DLFVBQVUxQjtBQUFBQSxRQUN4Q0MsVUFBVXFCLFVBQVVHLE1BQU1DLFVBQVV6QjtBQUFBQSxRQUNwQ0UsU0FBU21CLFVBQVVHLE1BQU1DLFVBQVV2QjtBQUFBQSxRQUNuQ0MsV0FBV2tCLFVBQVVHLE1BQU1DLFVBQVV0QjtBQUFBQSxRQUNyQ0UsUUFBUWdCLFVBQVVHLE1BQU1DLFVBQVVwQjtBQUFBQSxRQUNsQ0osU0FBU29CLFVBQVVHLE1BQU1DLFVBQVV4QjtBQUFBQSxRQUNuQ00sY0FBY2MsVUFBVUcsTUFBTUMsVUFBVWxCLGNBQWN1RyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDbEV0RyxRQUFRYSxVQUFVRyxNQUFNQyxVQUFVakI7QUFBQUEsUUFDbENDLEtBQUtZLFVBQVVHLE1BQU1DLFVBQVVoQixLQUFLcUcsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQ2hEcEcsUUFBUVcsVUFBVUcsTUFBTUMsVUFBVWY7QUFBQUEsUUFDbENDLGtCQUFrQlUsVUFBVUcsTUFBTUMsVUFBVWQ7QUFBQUEsUUFDNUNDLFFBQVFTLFVBQVVHLE1BQU1DLFVBQVViO0FBQUFBLFFBQ2xDQyxjQUFjUSxVQUFVRyxNQUFNQyxVQUFVWixjQUFjaUcsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQ2xFL0YsMEJBQTBCTSxVQUFVRyxNQUFNQyxVQUN0Q1YsNEJBQTRCLENBQUMsRUFBRTtBQUFBLFFBQ25DRCwwQkFDRU8sVUFBVUcsTUFBTUMsVUFBVVg7QUFBQUEsUUFDNUJFLHdCQUNFSyxVQUFVRyxNQUFNQyxVQUFVVCx3QkFBd0IrRixTQUFTLEtBQUs7QUFBQSxNQUNwRSxDQUFDO0FBQ0R4SSwyQkFBcUI4QyxTQUFTRyxNQUFNQyxVQUFVckIsZ0JBQWdCNEIsT0FBTyxFQUFFO0FBQ3ZFdkQ7QUFBQUEsUUFDRTRDLFNBQVNHLE1BQU1DLFVBQVUwRSx3QkFBd0I7QUFBQSxNQUNuRDtBQUNBOUcsOEJBQXdCZ0MsU0FBU0csTUFBTUMsVUFBVXJCLGdCQUFnQmlDLEtBQUs7QUFDdEUxRSx5QkFBbUIsSUFBSTtBQUN2QlEsZ0JBQVUsQ0FBQyxDQUFDO0FBQUEsSUFDZCxTQUFTNEUsT0FBTztBQUNkRixjQUFRRSxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUNBLFFBQU1pRSxvQkFBb0JBLENBQUMvSCxNQUFNO0FBQy9CLFVBQU0sRUFBRVksTUFBTVgsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQmdDLHNCQUFrQixDQUFDdUMsY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQzdELElBQUksR0FBR1g7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUNBLFFBQU0rSCxtQkFBbUIsWUFBWTtBQUNuQyxRQUFJckosYUFBYTtBQUNmLFVBQUk7QUFDRixjQUFNdkIsSUFBSTZLO0FBQUFBLFVBQ1IsZ0RBQWdEdEosWUFBWW9FLEdBQUc7QUFBQSxRQUNqRTtBQUNBdkUsMkJBQW1CLEtBQUs7QUFDeEJJLHVCQUFlLElBQUk7QUFDbkJrQix5QkFBaUIsQ0FBQ3VFLFNBQVNBLE9BQU8sQ0FBQztBQUNuQy9ELHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxTQUFTcUQsT0FBTztBQUNkRixnQkFBUUUsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxNQUM3QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTUoseUJBQXlCLE9BQU9WLE9BQU87QUFDM0NwRixZQUFRO0FBQUEsTUFDTndGLE9BQU87QUFBQSxNQUNQOEUsU0FBUztBQUFBLE1BQ1RDLFFBQVE7QUFBQSxNQUNSQyxZQUFZO0FBQUEsTUFFWixNQUFNQyxPQUFPO0FBQ1gsWUFBSTtBQUNGekUsa0JBQVEwRSxJQUFJdEYsSUFBSSx5QkFBeUI7QUFDekMsZ0JBQU1aLFdBQVcsTUFBTWhGLElBQUltTDtBQUFBQSxZQUN6Qiw4QkFBOEJ2RixFQUFFO0FBQUEsWUFDaEM7QUFBQSxjQUNFaEIsWUFBWTtBQUFBLFlBQ2Q7QUFBQSxVQUNGO0FBRUFsQywyQkFBaUIsQ0FBQ3VFLFNBQVNBLE9BQU8sQ0FBQztBQUVuQy9ELHlCQUFlO0FBQUEsWUFDYkMsWUFBWTtBQUFBLFlBQ1pDLFNBQVM7QUFBQSxZQUNUQyxNQUFNO0FBQUEsVUFDUixDQUFDO0FBQUEsUUFDSCxTQUFTcUQsT0FBTztBQUNkeEQseUJBQWU7QUFBQSxZQUNiQyxZQUFZO0FBQUEsWUFDWkMsU0FBU3NELE9BQU8xQixVQUFVRyxNQUFNL0IsV0FBVztBQUFBLFlBQzNDQyxNQUFNO0FBQUEsVUFDUixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTStILGVBQWUsT0FBT3hJLE1BQU07QUFDaENBLE1BQUUrRyxlQUFlO0FBQ2pCLFVBQU0wQixVQUFVekQsYUFBYTtBQUM3QixRQUFJO0FBQ0YsVUFBSXlELFNBQVM7QUFDWCxjQUFNeEIsYUFBYTtBQUFBLFVBQ2pCLEdBQUdoRjtBQUFBQSxVQUNIZCxnQkFBZ0I5QjtBQUFBQSxVQUNoQjZILHNCQUFzQjNIO0FBQUFBLFFBQ3hCO0FBQ0FxRSxnQkFBUTBFLElBQUl6SixtQkFBa0IsYUFBYTtBQUMzQyxjQUFNdUQsV0FBVyxNQUFNaEYsSUFBSW1MO0FBQUFBLFVBQ3pCLDBDQUEwQzFKLGtCQUFrQmtFLEdBQUc7QUFBQSxVQUMvRGtFO0FBQUFBLFFBQ0Y7QUFDQXZJLDJCQUFtQixLQUFLO0FBQ3hCWSw2QkFBcUIsRUFBRTtBQUN2QkUsc0NBQThCLEVBQUU7QUFDaENNLHlCQUFpQixDQUFDdUUsU0FBU0EsT0FBTyxDQUFDO0FBQ25DL0QsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTcUQsT0FBTztBQUNkRixjQUFRRSxNQUFNLHlCQUF5QkEsS0FBSztBQUM1QyxVQUNFQSxNQUFNMUIsWUFDTjBCLE1BQU0xQixTQUFTRyxRQUNmdUIsTUFBTTFCLFNBQVNHLEtBQUsvQixTQUNwQjtBQUNBRix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTLEdBQUdzRCxNQUFNMUIsU0FBU0csS0FBSy9CLE9BQU87QUFBQSxVQUN2Q0MsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMSCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU1pSSxnQkFBZ0IsT0FBT0MsVUFBVTtBQUNyQyxVQUFNQyxVQUFVRCxNQUFNekksT0FBT0Q7QUFDN0JYLHlCQUFxQnNKLE9BQU87QUFDNUIsVUFBTTFFLFdBQVd6RSxTQUFTMEUsS0FBSyxDQUFDQyxRQUFRQSxJQUFJckIsUUFBUTZGLE9BQU87QUFDM0R4SSw0QkFBd0I4RCxVQUFVZCxTQUFTLEVBQUU7QUFBQSxFQUMvQztBQUNBLFFBQU15Rix5QkFBeUIsT0FBT0YsVUFBVTtBQUM5QyxVQUFNN0QsY0FBYzZELE1BQU16SSxPQUFPRDtBQUNqQ1Qsa0NBQThCc0YsV0FBVztBQUFBLEVBQzNDO0FBRUEsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNekUsWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUMrRCxVQUFVLEVBQUUsR0FBR0EsTUFBTTlELFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNRztBQUFBLE1BRUgsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDWCx1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsNENBQ2IsaUNBQUMsUUFBRyxXQUFVLDBCQUF5QixxQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RCxLQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUNDdEMsZ0JBQWdCd0gsU0FBUyxLQUFLLENBQUM5RixZQUM5QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsZUFBZThEO0FBQUFBLFlBQ2YsTUFBTWxHLGFBQWFVLGdCQUFnQmtCLFVBQVU7QUFBQSxZQUM3QztBQUFBLFlBQ0EsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWtCO0FBQUE7QUFBQSxVQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLb0MsSUFHcEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTbEIsZ0JBQWdCd0gsVUFBVTtBQUFBLFlBQ25DLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3NCO0FBQUEsV0E1QjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQkE7QUFBQSxTQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOENBO0FBQUEsSUFDQSx1QkFBQyxTQUFNLFdBQVdwSCxXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVXdJLGNBQWMsWUFBVSxNQUM1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQU87QUFBQTtBQUFBLGdCQUVMLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQTtBQUFBO0FBQUEsWUFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPcEcsU0FBU0U7QUFBQUEsY0FDaEIsVUFBVStEO0FBQUFBLGNBQ1YsSUFBRztBQUFBLGNBQ0gsYUFBWTtBQUFBLGNBQ1o7QUFBQSxjQUNBLFdBQVcscUNBQXFDbkgsVUFBVXNMLE1BQU07QUFBQTtBQUFBLFlBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVE2SjtBQUFBLFVBRTVKN0osT0FBTzJCLFFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjNCLGlCQUFPMkIsUUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Q7QUFBQSxhQWxCMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGtCQUVSLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPRixTQUFTRztBQUFBQSxnQkFDaEIsVUFBVThEO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ25ILFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRNko7QUFBQSxZQUU1SjdKLE9BQU80QixTQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI1QixpQkFBTzRCLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsZUFsQjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRUQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9ILFNBQVNJO0FBQUFBLGdCQUNoQixVQUFVNkQ7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDbkgsVUFBVXNMLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVE2SjtBQUFBLFlBRTVKN0osT0FBTzZCLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsYUE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZDQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGtCQUVMLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPSixTQUFTSztBQUFBQSxnQkFDaEIsVUFBVTREO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ25ILFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRNko7QUFBQSxZQUU1SjdKLE9BQU84QixZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlCLGlCQUFPOEIsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFNO0FBQUE7QUFBQSxrQkFFTix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUE7QUFBQTtBQUFBLGNBSjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0wsU0FBU087QUFBQUEsZ0JBQ2hCLFVBQVUwRDtBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUNuSCxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsWUFFNUo3SixPQUFPZ0MsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZoQyxpQkFBT2dDLFdBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsYUE5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStDQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGtCQUVBLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPUCxTQUFTUTtBQUFBQSxnQkFDaEIsVUFBVXlEO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ25ILFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRNko7QUFBQSxZQUU1SjdKLE9BQU9pQyxhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmpDLGlCQUFPaUMsYUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFNO0FBQUE7QUFBQSxrQkFFSCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUE7QUFBQTtBQUFBLGNBSjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT1IsU0FBU1U7QUFBQUEsZ0JBQ2hCLFVBQVV1RDtBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUNuSCxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsWUFFNUo3SixPQUFPbUMsVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCbkMsaUJBQU9tQyxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLGVBbEI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLGFBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2Q0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQU87QUFBQTtBQUFBLGdCQUVQLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQTtBQUFBO0FBQUEsWUFKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPVixTQUFTTTtBQUFBQSxjQUNoQixVQUFVMkQ7QUFBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVyxxQ0FBcUNuSCxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsWUFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUTZKO0FBQUEsVUFFNUo3SixPQUFPK0IsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCL0IsaUJBQU8rQixXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLGFBbEI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBVTtBQUFBO0FBQUEsa0JBRU4sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTCxPQUFPM0IscUJBQXFCMEo7QUFBQUEsZ0JBQzVCLFVBQVUvRTtBQUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLGNBQWMsQ0FBQ2dGLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKNUIsWUFBWSxFQUNaQyxTQUFTeUIsTUFBTTFCLFlBQVksQ0FBQztBQUFBLGdCQUdoQzdILG1CQUFTbUQ7QUFBQUEsa0JBQUksQ0FBQ3dCLFFBQ2IsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUlyQixLQUNyQ3FCLGNBQUloQixTQURhZ0IsSUFBSXJCLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsWUFDQzlELE9BQU9rQyxrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZsQyxpQkFBT2tDLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlDQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQVE7QUFBQTtBQUFBLGtCQUVULHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQVlBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWix1QkFBdUI7QUFBQSxnQkFDdkI7QUFBQSxnQkFDQSxNQUFLO0FBQUEsZ0JBQ0wsY0FBYyxDQUFDNkgsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0o1QixZQUFZLEVBQ1pDLFNBQVN5QixNQUFNMUIsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU81RyxVQUFVYSxVQUFVd0g7QUFBQUEsZ0JBQzNCLFVBQVUsQ0FBQzlJLFVBQVVzRSxpQkFBaUIsVUFBVXRFLEtBQUs7QUFBQSxnQkFFcEQsV0FBQyxVQUFVLFlBQVksWUFBWSxFQUFFMkM7QUFBQUEsa0JBQUksQ0FBQ3VHLFVBQ3pDLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxNQUFNN0IsWUFBWSxHQUNqRDZCLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtQkE7QUFBQSxZQUNDbEssT0FBT3NDLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnRDLGlCQUFPc0MsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxlQXZDNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5Q0E7QUFBQSxhQTVFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBYTtBQUFBO0FBQUEsa0JBRVIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9iLFNBQVNZO0FBQUFBLGdCQUNoQixVQUFVcUQ7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWixXQUFXLHFDQUFxQ25ILFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxjQVBsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPNko7QUFBQSxZQUU1SjdKLE9BQU9xQyxnQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZyQyxpQkFBT3FDLGdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQUk7QUFBQTtBQUFBLGtCQUVDLHVCQUFDLFVBQUssV0FBVSxrQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBO0FBQUEsY0FKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPWixTQUFTa0I7QUFBQUEsZ0JBQ2hCLFVBQVUrQztBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUNuSCxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsZUFmL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxhQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBSztBQUFBO0FBQUEsa0JBRUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9wSSxTQUFTYztBQUFBQSxnQkFDaEIsVUFBVW1EO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1osV0FBVyxxQ0FBcUNuSCxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsY0FQbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTzZKO0FBQUEsWUFFNUo3SixPQUFPdUMsT0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCdkMsaUJBQU91QyxPQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRDtBQUFBLGVBakJ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQVE7QUFBQTtBQUFBLGtCQUVULHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQVdBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWix1QkFBdUI7QUFBQSxnQkFDdkI7QUFBQSxnQkFDQSxNQUFLO0FBQUEsZ0JBQ0wsY0FBYyxDQUFDd0gsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0o1QixZQUFZLEVBQ1pDLFNBQVN5QixNQUFNMUIsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU81RyxVQUFVZSxVQUFVc0g7QUFBQUEsZ0JBQzNCLFVBQVUsQ0FBQzlJLFVBQVVzRSxpQkFBaUIsVUFBVXRFLEtBQUs7QUFBQSxnQkFFcEQsV0FBQyxRQUFRLFVBQVUsUUFBUSxFQUFFMkM7QUFBQUEsa0JBQUksQ0FBQ25CLFdBQ2pDLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxPQUFPNkYsWUFBWSxHQUNuRDdGLG9CQURpQkEsUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtQkE7QUFBQSxZQUNDeEMsT0FBT3dDLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnhDLGlCQUFPd0MsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxlQXRDNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3Q0E7QUFBQSxhQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOERBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBSztBQUFBO0FBQUEsa0JBRU4sdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9mLFNBQVNpQjtBQUFBQSxnQkFDaEIsVUFBVWdEO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ25ILFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRNko7QUFBQSxZQUU1SjdKLE9BQU8wQyxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkIxQyxpQkFBTzBDLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsZUFsQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBVztBQUFBO0FBQUEsa0JBRUk7QUFBQSxrQkFDdkIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9qQixTQUFTZ0I7QUFBQUEsZ0JBQ2hCLFVBQVVpRDtBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUNuSCxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsWUFFNUo3SixPQUFPeUMsb0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWekMsaUJBQU95QyxvQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOENBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBd0I7QUFBQTtBQUFBLGtCQUVUO0FBQUEsa0JBQ3ZCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPaEIsU0FBU3FCO0FBQUFBLGdCQUNoQixVQUFVNEM7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDbkgsVUFBVXNMLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVE2SjtBQUFBLFlBRTVKN0osT0FBTzhDLDBCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsMEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBSTtBQUFBO0FBQUEsa0JBR1osdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9yQixTQUFTbUI7QUFBQUEsZ0JBQ2hCLFVBQVU4QztBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUNuSCxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsWUFFNUo3SixPQUFPNEMsNEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWNUMsaUJBQU80Qyw0QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaURBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQVc7QUFBQTtBQUFBLGdCQUVJO0FBQUE7QUFBQTtBQUFBLFlBSnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9uQixTQUFTb0IsMkJBQTJCLENBQUMsS0FBSztBQUFBLGNBQ2pELFVBQVUsQ0FBQzlCLE1BQ1RrRyxrQkFBa0J4RixVQUFVQyxhQUFhLEdBQUdYLENBQUM7QUFBQSxjQUUvQyxJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVyxxQ0FBcUN4QyxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsWUFWbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVTZKLEtBWC9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUNDcEksU0FBU29CLDBCQUNOMEUsTUFBTSxDQUFDLEVBQ1I1RDtBQUFBQSxZQUFJLENBQUN1QyxPQUFPckMsVUFDWCx1QkFBQyxTQUFnQixXQUFVLGdDQUN6QjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFNLG1CQUFtQkEsUUFBUSxDQUFDO0FBQUEsa0JBQ2xDLE9BQU9xQztBQUFBQSxrQkFDUCxVQUFVLENBQUNuRixNQUNUa0c7QUFBQUEsb0JBQ0V4RjtBQUFBQSxvQkFDQUM7QUFBQUEsb0JBQ0FtQyxRQUFRO0FBQUEsb0JBQ1I5QztBQUFBQSxrQkFDRjtBQUFBLGtCQUVGLElBQUksYUFBYThDLFFBQVEsQ0FBQztBQUFBLGtCQUMxQixhQUFZO0FBQUEsa0JBQ1osV0FBVyxxQ0FBcUN0RixVQUFVc0wsTUFBTTtBQUFBO0FBQUEsZ0JBZGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWM2SjtBQUFBLGNBRTVKaEcsUUFBUSxLQUNQO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQ1AyRCxpQkFBaUIvRixVQUFVQyxhQUFhbUMsUUFBUSxDQUFDO0FBQUEsa0JBRW5ELFdBQVU7QUFBQSxrQkFBc0I7QUFBQTtBQUFBLGdCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGlCQTFCTUEsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLFVBQ0Q7QUFBQSxVQUNIO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU04QyxjQUFjbEYsVUFBVUMsV0FBVztBQUFBLGNBQ2xELFdBQVU7QUFBQSxjQUE0QjtBQUFBO0FBQUEsWUFIeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkRBLEtBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErREE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ21IO0FBQUE7QUFBQSxVQUgvSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBeGhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeWhCQTtBQUFBLFNBN2hCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOGhCQSxLQS9oQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdpQkE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXbEM7QUFBQUEsUUFDWCxTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFFdkMsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QywyQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVThKLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFPO0FBQUE7QUFBQSxvQkFFTCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBO0FBQUE7QUFBQSxnQkFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT3ZHLGVBQWVyQjtBQUFBQSxrQkFDdEIsVUFBVW1IO0FBQUFBLGtCQUNWLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ3ZLLFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxnQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUTZKO0FBQUEsY0FFNUo3SixPQUFPMkIsUUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCM0IsaUJBQU8yQixRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBLGlCQWxCMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRVIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3FCLGVBQWVwQjtBQUFBQSxvQkFDdEIsVUFBVWtIO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3ZLLFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2SjtBQUFBLGdCQUU1SjdKLE9BQU80QixTQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI1QixpQkFBTzRCLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsbUJBbEIzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPb0IsZUFBZW5CO0FBQUFBLG9CQUN0QixVQUFVaUg7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDdkssVUFBVXNMLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZKO0FBQUEsZ0JBRTVKN0osT0FBTzZCLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGlCQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFQSx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPbUIsZUFBZWY7QUFBQUEsb0JBQ3RCLFVBQVU2RztBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUN2SyxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNko7QUFBQSxnQkFFNUo3SixPQUFPaUMsYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZqQyxpQkFBT2lDLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFSCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPZSxlQUFlYjtBQUFBQSxvQkFDdEIsVUFBVTJHO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3ZLLFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2SjtBQUFBLGdCQUU1SjdKLE9BQU9tQyxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJuQyxpQkFBT21DLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsbUJBbEI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGlCQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZDQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLG9CQUVQLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPYSxlQUFlakI7QUFBQUEsa0JBQ3RCLFVBQVUrRztBQUFBQSxrQkFDVixJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsV0FBVyxxQ0FBcUN2SyxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsZ0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVE2SjtBQUFBLGNBRTVKN0osT0FBTytCLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qi9CLGlCQUFPK0IsV0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxpQkFsQjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBRWIsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFNO0FBQUE7QUFBQSxvQkFFTix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBO0FBQUE7QUFBQSxnQkFKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT2lCLGVBQWVoQjtBQUFBQSxrQkFDdEIsVUFBVThHO0FBQUFBLGtCQUNWLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ3ZLLFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxnQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUTZKO0FBQUEsY0FFNUo3SixPQUFPZ0MsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZoQyxpQkFBT2dDLFdBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNCQSxLQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFVO0FBQUE7QUFBQSxzQkFFTix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsSUFBRztBQUFBLG9CQUNILE1BQUs7QUFBQSxvQkFDTCxPQUFPNUIscUJBQXFCMEo7QUFBQUEsb0JBQzVCLFVBQVUvRTtBQUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osV0FBVTtBQUFBLG9CQUNWO0FBQUEsb0JBQ0EsdUJBQXVCO0FBQUEsb0JBQ3ZCLGNBQWMsQ0FBQ2dGLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKNUIsWUFBWSxFQUNaQyxTQUFTeUIsTUFBTTFCLFlBQVksQ0FBQztBQUFBLG9CQUdoQzdILG1CQUFTbUQ7QUFBQUEsc0JBQUksQ0FBQ3dHLFlBQ2IsdUJBQUMsT0FBTyxRQUFQLEVBQWdDLE9BQU9BLFFBQVFyRyxLQUM3Q3FHLGtCQUFRaEcsU0FEU2dHLFFBQVFyRyxLQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBb0JBO0FBQUEsZ0JBQ0M5RCxPQUFPa0Msa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWbEMsaUJBQU9rQyxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0NBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVE7QUFBQTtBQUFBLHNCQUVULHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQVlBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUNMLGNBQWMsQ0FBQzZILE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKNUIsWUFBWSxFQUNaQyxTQUFTeUIsTUFBTTFCLFlBQVksQ0FBQztBQUFBLG9CQUVqQyxPQUFPckYsZ0JBQWdCVixVQUFVd0g7QUFBQUEsb0JBQ2pDLFVBQVUsQ0FBQzlJLFVBQVUyRSxzQkFBc0IsVUFBVTNFLEtBQUs7QUFBQSxvQkFFekQsV0FBQyxVQUFVLFlBQVksWUFBWSxFQUFFMkM7QUFBQUEsc0JBQUksQ0FBQ3JCLFdBQ3pDLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxPQUFPK0YsWUFBWSxHQUNuRC9GLG9CQURpQkEsUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQW1CQTtBQUFBLGdCQUNDdEMsT0FBT3NDLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnRDLGlCQUFPc0MsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxtQkF2QzVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUNBO0FBQUEsaUJBN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWE7QUFBQTtBQUFBLHNCQUVSLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT1UsZUFBZVg7QUFBQUEsb0JBQ3RCLFVBQVV5RztBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaLFdBQVcscUNBQXFDdkssVUFBVXNMLE1BQU07QUFBQTtBQUFBLGtCQVBsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTzZKO0FBQUEsZ0JBRTVKN0osT0FBT3FDLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnJDLGlCQUFPcUMsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFJO0FBQUE7QUFBQSxzQkFFQyx1QkFBQyxVQUFLLFdBQVUsa0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStCO0FBQUE7QUFBQTtBQUFBLGtCQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQ0VXLGdCQUFnQkwsZUFDWixJQUFJeUgsS0FBS3BILGdCQUFnQkwsZ0JBQWdCLEVBQUUsRUFDeEMwSCxZQUFZLEVBQ1p6QixNQUFNLEdBQUcsRUFBRSxDQUFDLElBQ2Y7QUFBQSxvQkFFTixVQUFVRTtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUN2SyxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsa0JBZGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFjNko7QUFBQSxtQkFyQi9KO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0NBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQUs7QUFBQTtBQUFBLHNCQUVDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FDRTdHLGdCQUFnQlQsTUFDWixJQUFJNkgsS0FBS3BILGdCQUFnQlQsT0FBTyxFQUFFLEVBQy9COEgsWUFBWSxFQUNaekIsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNmO0FBQUEsb0JBRU4sVUFBVUU7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWixXQUFXLHFDQUFxQ3ZLLFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxrQkFibEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWE2SjtBQUFBLGdCQUU1SjdKLE9BQU91QyxPQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ2QyxpQkFBT3VDLE9BQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsbUJBdkJ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXlCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFRO0FBQUE7QUFBQSxzQkFFVCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUE7QUFBQTtBQUFBLGtCQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFXQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLHVCQUF1QjtBQUFBLG9CQUN2QjtBQUFBLG9CQUNBLE1BQUs7QUFBQSxvQkFDTCxjQUFjLENBQUN3SCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSjVCLFlBQVksRUFDWkMsU0FBU3lCLE1BQU0xQixZQUFZLENBQUM7QUFBQSxvQkFFakMsT0FBT3JGLGdCQUFnQlIsVUFBVXNIO0FBQUFBLG9CQUNqQyxVQUFVLENBQUM5SSxVQUFVMkUsc0JBQXNCLFVBQVUzRSxLQUFLO0FBQUEsb0JBRXpELFdBQUMsUUFBUSxVQUFVLFFBQVEsRUFBRTJDO0FBQUFBLHNCQUFJLENBQUNuQixXQUNqQyx1QkFBQyxPQUFPLFFBQVAsRUFBMkIsT0FBT0EsT0FBTzZGLFlBQVksR0FDbkQ3RixvQkFEaUJBLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUEsa0JBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFtQkE7QUFBQSxnQkFDQ3hDLE9BQU93QyxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ4QyxpQkFBT3dDLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsbUJBdEM1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdDQTtBQUFBLGlCQW5FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9FQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFLO0FBQUE7QUFBQSxzQkFFTix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUE7QUFBQTtBQUFBLGtCQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9RLGVBQWVOO0FBQUFBLG9CQUN0QixVQUFVb0c7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDdkssVUFBVXNMLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZKO0FBQUEsZ0JBRTVKN0osT0FBTzBDLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjFDLGlCQUFPMEMsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxtQkFsQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVc7QUFBQTtBQUFBLHNCQUVJO0FBQUEsc0JBQ3ZCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT00sZUFBZVA7QUFBQUEsb0JBQ3RCLFVBQVVxRztBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUN2SyxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNko7QUFBQSxnQkFFNUo3SixPQUFPeUMsb0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWekMsaUJBQU95QyxvQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOENBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQXdCO0FBQUE7QUFBQSxzQkFFWix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUE7QUFBQTtBQUFBLGtCQUp0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9PLGVBQWVGO0FBQUFBLG9CQUN0QixVQUFVZ0c7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDdkssVUFBVXNMLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZKO0FBQUEsZ0JBRTVKN0osT0FBTzhDLDBCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsMEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFJO0FBQUE7QUFBQSxzQkFFYTtBQUFBLHNCQUN6Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUE7QUFBQTtBQUFBLGtCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9FLGdCQUFnQko7QUFBQUEsb0JBQ3ZCLFVBQVVrRztBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUN2SyxVQUFVc0wsTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNko7QUFBQSxnQkFFNUo3SixPQUFPNEMsNEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWNUMsaUJBQU80Qyw0QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0RBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFXO0FBQUE7QUFBQSxvQkFFSTtBQUFBO0FBQUE7QUFBQSxnQkFKekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9JLGVBQWVILDJCQUEyQixDQUFDLEtBQUs7QUFBQSxrQkFDdkQsVUFBVSxDQUFDOUIsTUFDVGtHO0FBQUFBLG9CQUNFakU7QUFBQUEsb0JBQ0FDO0FBQUFBLG9CQUNBO0FBQUEsb0JBQ0FsQztBQUFBQSxrQkFDRjtBQUFBLGtCQUVGLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ3hDLFVBQVVzTCxNQUFNO0FBQUE7QUFBQSxnQkFmbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZTZKLEtBaEIvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtCQTtBQUFBLGNBQ0M3RyxlQUFlSCwwQkFDWjBFLE1BQU0sQ0FBQyxFQUNSNUQ7QUFBQUEsZ0JBQUksQ0FBQ3VDLE9BQU9yQyxVQUNYO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLFdBQVU7QUFBQSxvQkFFVjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFNLG1CQUFtQkEsUUFBUSxDQUFDO0FBQUEsMEJBQ2xDLE9BQU9xQztBQUFBQSwwQkFDUCxVQUFVLENBQUNuRixNQUNUa0c7QUFBQUEsNEJBQ0VqRTtBQUFBQSw0QkFDQUM7QUFBQUEsNEJBQ0FZLFFBQVE7QUFBQSw0QkFDUjlDO0FBQUFBLDBCQUNGO0FBQUEsMEJBRUYsSUFBSSxhQUFhOEMsUUFBUSxDQUFDO0FBQUEsMEJBQzFCLGFBQVk7QUFBQSwwQkFDWixXQUFXLHFDQUFxQ3RGLFVBQVVzTCxNQUFNO0FBQUE7QUFBQSx3QkFkbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWM2SjtBQUFBLHNCQUU3SjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsU0FBUyxNQUNQckM7QUFBQUEsNEJBQ0V4RTtBQUFBQSw0QkFDQUM7QUFBQUEsNEJBQ0FZLFFBQVE7QUFBQSwwQkFDVjtBQUFBLDBCQUVGLFdBQVU7QUFBQSwwQkFBc0I7QUFBQTtBQUFBLHdCQVRsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBWUE7QUFBQTtBQUFBO0FBQUEsa0JBL0JLQSxRQUFRO0FBQUEsa0JBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFpQ0E7QUFBQSxjQUNEO0FBQUEsY0FDSDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUNQOEMsY0FBYzNELGdCQUFnQkMsaUJBQWlCO0FBQUEsa0JBRWpELFdBQVU7QUFBQSxrQkFBNEI7QUFBQTtBQUFBLGdCQUx4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGlCQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlFQSxLQTFFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJFQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDNkY7QUFBQTtBQUFBLGNBSHpHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBM2hCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRoQkE7QUFBQSxhQWhpQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlpQkE7QUFBQTtBQUFBLE1BcmlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFzaUJBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVzNEO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCSSx5QkFBZSxJQUFJO0FBQUEsUUFDckI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsMkNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDRCxlQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUNxQixNQUFNO0FBQ2ZBLGtCQUFFK0csZUFBZTtBQUNqQmlCLGlDQUFpQjtBQUFBLGNBQ25CO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFXO0FBQUE7QUFBQSx3QkFFTjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYnJKLHNCQUFZaUMsUUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUNBQXFDcEQsVUFBVXNMLE1BQU07QUFBQTtBQUFBLG9CQUxsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSzZKO0FBQUEscUJBakIvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ3lGO0FBQUE7QUFBQSxrQkFIckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUE7QUFBQTtBQUFBLFlBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtDQTtBQUFBLGFBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0E7QUFBQTtBQUFBLE1BaERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlEQTtBQUFBLE9BenFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMHFDQSxLQTNxQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRxQ0E7QUFFSjtBQUFFaEwsR0E5d0RJRCxvQkFBa0I7QUFBQTBMLEtBQWxCMUw7QUErd0ROLGVBQWVBO0FBQW1CLElBQUEwTDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTaWRlYmFyIiwiSW9NZE1vcmUiLCJJbnB1dCIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiTW9kYWwiLCJtYWRhbCIsImFwaSIsIkRhdGFUYWJsZSIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsImZpZWxkU2l6ZSIsIkNpcmN1bGFyTG9hZGVyIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJCcmVhZGNydW1iIiwiY29uZmlybSIsIlVuQXBwcm92ZWRFbXBsb3llZSIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsIlRhYmxlRW1wbG95ZWVzIiwic2V0VGFibGVFbXBsb3llZXMiLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRVc2VyIiwic2V0Q3VycmVudFVzZXIiLCJjdXJyZW50VXBkYXRlVXNlciIsInNldEN1cnJlbnRVcGRhdGVVc2VyIiwidW5WZXJpZmllZFVzZXIiLCJzZXRVblZlcmlmaWVkVXNlciIsImVycm9ycyIsInNldEVycm9ycyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0Iiwic2VsZWN0ZWRNYW5hZ2VySWQiLCJzZXRTZWxlY3RlZE1hbmFnZXJJZCIsInNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkIiwic2V0U2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQiLCJtYW5hZ2VycyIsInNldE1hbmFnZXJzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJzZWxlY3RlZE1hbmFnZXJUaXRsZSIsInNldFNlbGVjdGVkTWFuYWdlclRpdGxlIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJuYW1lIiwiZW1haWwiLCJwaG9uZV9udW1iZXIiLCJwYXNzd29yZCIsImFkZHJlc3MiLCJwaW5jb2RlIiwiYWRoYWFyX25vIiwiZGVzaWduYXRpb25faWQiLCJwYW5fbm8iLCJhZ2VudF90eXBlIiwiam9pbmluZ19kYXRlIiwic3RhdHVzIiwiZG9iIiwiZ2VuZGVyIiwiYWx0ZXJuYXRlX251bWJlciIsInNhbGFyeSIsImxlYXZpbmdfZGF0ZSIsImVtZXJnZW5jeV9jb250YWN0X3BlcnNvbiIsImVtZXJnZW5jeV9jb250YWN0X251bWJlciIsInRvdGFsX2FsbG9jYXRlZF9sZWF2ZXMiLCJpc1ZlcmlmaWVkIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsImZldGNoRW1wbG95ZWVQcm9maWxlIiwicmVzcG9uc2UiLCJnZXQiLCJlbXBsb3llZURhdGEiLCJkYXRhIiwiZW1wbG95ZWUiLCJmb3JtYXR0ZWREYXRhIiwiZmlsdGVyIiwiZW1wIiwibWFwIiwiZ3JvdXAiLCJpbmRleCIsIl9pZCIsImlkIiwiZW1wbG95ZWVDb2RlIiwidW5pcXVlX2NvZGUiLCJkZXNpZ25hdGlvbiIsInRpdGxlIiwiYWN0aW9uIiwiaXRlbXMiLCJrZXkiLCJsYWJlbCIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZVVudmVyaWZ5RW1wbG95ZWUiLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJjb25zb2xlIiwiaW5mbyIsImVycm9yIiwiZmV0Y2hNYW5hZ2VycyIsImhhbmRsZUFudERTZWxlY3RNYW5hZ2VyIiwibWFuYWdlcklkIiwic2VsZWN0ZWQiLCJmaW5kIiwibWdyIiwicHJldiIsIm1hbmFnZXJUaXRsZSIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInByZXZEYXRhIiwicHJldkVycm9ycyIsImhhbmRsZUNoYW5nZSIsImhhbmRsZUFudElucHV0RFNlbGVjdCIsImhhbmRsZUFudERTZWxlY3RSZXBvcnRpbmdNYW5hZ2VyIiwicmVwb3J0aW5nSWQiLCJyZXBvcnRpbmdNYW5hZ2VySWQiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJyZWdleCIsInBob25lIiwiYWFkaGFhciIsInBhbiIsInRyaW0iLCJ0ZXN0IiwidG9VcHBlckNhc2UiLCJsZW5ndGgiLCJPYmplY3QiLCJrZXlzIiwiYWRkUGhvbmVGaWVsZCIsImZvcm1TdGF0ZSIsInNldEZvcm1TdGF0ZSIsInBob25lcyIsImxhc3RQaG9uZSIsImFsZXJ0IiwiaGFuZGxlUGhvbmVDaGFuZ2UiLCJwdXNoIiwibGFzdEluZGV4IiwicmVkdWNlUmlnaHQiLCJsYXN0Tm9uRW1wdHkiLCJpIiwic2xpY2UiLCJyZW1vdmVQaG9uZUZpZWxkIiwiQXJyYXkiLCJpc0FycmF5IiwidXBkYXRlZFBob25lcyIsIl8iLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImlzVmFsaWRhdGUiLCJkYXRhVG9TZW5kIiwicmVwb3J0aW5nX21hbmFnZXJfaWQiLCJwb3N0IiwiaGVhZGVycyIsImVyck1zZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJjb2x1bW5zIiwiaGVhZGVyIiwiZmlsdGVyZWRVc2VycyIsInVzZXIiLCJ1c2VySWQiLCJzcGxpdCIsInRvU3RyaW5nIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJoYW5kbGVEZWxldGVVc2VyIiwiZGVsZXRlIiwiY29udGVudCIsIm9rVGV4dCIsImNhbmNlbFRleHQiLCJvbk9rIiwibG9nIiwicHV0IiwiaGFuZGxlVXBkYXRlIiwiaXNWYWxpZCIsImhhbmRsZU1hbmFnZXIiLCJldmVudCIsImdyb3VwSWQiLCJoYW5kbGVSZXBvcnRpbmdNYW5hZ2VyIiwiaGVpZ2h0IiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInN0eXBlIiwibWFuYWdlciIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlVuQXBwcm92ZWRFbXBsb3llZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgSW5wdXQsIFNlbGVjdCwgRHJvcGRvd24sIE1vZGFsIGFzIG1hZGFsIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcbmNvbnN0IHsgY29uZmlybSB9ID0gbWFkYWw7XHJcbmNvbnN0IFVuQXBwcm92ZWRFbXBsb3llZSA9ICgpID0+IHtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVFbXBsb3llZXMsIHNldFRhYmxlRW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxEZWxldGUsIHNldFNob3dNb2RhbERlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFVzZXIsIHNldEN1cnJlbnRVc2VyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlVXNlciwgc2V0Q3VycmVudFVwZGF0ZVVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3VuVmVyaWZpZWRVc2VyLCBzZXRVblZlcmlmaWVkVXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZE1hbmFnZXJJZCwgc2V0U2VsZWN0ZWRNYW5hZ2VySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkLCBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZF0gPVxyXG4gICAgdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21hbmFnZXJzLCBzZXRNYW5hZ2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IFtzZWxlY3RlZE1hbmFnZXJUaXRsZSwgc2V0U2VsZWN0ZWRNYW5hZ2VyVGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIG5hbWU6IFwiXCIsXHJcbiAgICBlbWFpbDogXCJcIixcclxuICAgIHBob25lX251bWJlcjogXCJcIixcclxuICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgYWRkcmVzczogXCJcIixcclxuICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICBhZGhhYXJfbm86IFwiXCIsXHJcbiAgICBkZXNpZ25hdGlvbl9pZDogXCJcIixcclxuICAgIHBhbl9ubzogXCJcIixcclxuICAgIGFnZW50X3R5cGU6IFwiZW1wbG95ZWVcIixcclxuICAgIGpvaW5pbmdfZGF0ZTogXCJcIixcclxuICAgIHN0YXR1czogXCJcIixcclxuICAgIGRvYjogXCJcIixcclxuICAgIGdlbmRlcjogXCJcIixcclxuICAgIGFsdGVybmF0ZV9udW1iZXI6IFwiXCIsXHJcbiAgICBzYWxhcnk6IFwiXCIsXHJcbiAgICBsZWF2aW5nX2RhdGU6IFwiXCIsXHJcbiAgICBlbWVyZ2VuY3lfY29udGFjdF9wZXJzb246IFwiXCIsXHJcbiAgICBlbWVyZ2VuY3lfY29udGFjdF9udW1iZXI6IFtcIlwiXSxcclxuICAgIHRvdGFsX2FsbG9jYXRlZF9sZWF2ZXM6IFwiMlwiLFxyXG4gICAgaXNWZXJpZmllZDogZmFsc2UsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBuYW1lOiBcIlwiLFxyXG4gICAgZW1haWw6IFwiXCIsXHJcbiAgICBwaG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICBwYXNzd29yZDogXCJcIixcclxuICAgIGFkZHJlc3M6IFwiXCIsXHJcbiAgICBwaW5jb2RlOiBcIlwiLFxyXG4gICAgYWRoYWFyX25vOiBcIlwiLFxyXG4gICAgZGVzaWduYXRpb25faWQ6IFwiXCIsXHJcbiAgICBwYW5fbm86IFwiXCIsXHJcbiAgICBqb2luaW5nX2RhdGU6IFwiXCIsXHJcbiAgICBzdGF0dXM6IFwiXCIsXHJcbiAgICBkb2I6IFwiXCIsXHJcbiAgICBnZW5kZXI6IFwiXCIsXHJcbiAgICBhbHRlcm5hdGVfbnVtYmVyOiBcIlwiLFxyXG4gICAgc2FsYXJ5OiBcIlwiLFxyXG4gICAgbGVhdmluZ19kYXRlOiBcIlwiLFxyXG4gICAgZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uOiBcIlwiLFxyXG4gICAgZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyOiBbXCJcIl0sXHJcbiAgICB0b3RhbF9hbGxvY2F0ZWRfbGVhdmVzOiBcIjJcIixcclxuICAgIGlzVmVyaWZpZWQ6IFwiXCIsXHJcbiAgfSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRW1wbG95ZWVQcm9maWxlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFkZGl0aW9uYWwtZW1wbG95ZWUtaW5mb1wiKTtcclxuICAgICAgICBjb25zdCBlbXBsb3llZURhdGEgPSByZXNwb25zZS5kYXRhPy5lbXBsb3llZSB8fCBbXTtcclxuICAgICAgICBzZXRVc2VycyhlbXBsb3llZURhdGEpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBlbXBsb3llZURhdGEuZmlsdGVyKChlbXApID0+IGVtcC5pc1ZlcmlmaWVkID09PSBmYWxzZSkubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGdyb3VwPy5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgbmFtZTogZ3JvdXA/Lm5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGVtcGxveWVlQ29kZTogZ3JvdXA/LnVuaXF1ZV9jb2RlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHBhc3N3b3JkOiBncm91cD8ucGFzc3dvcmQgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBncm91cD8uZGVzaWduYXRpb25faWQ/LnRpdGxlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVbnZlcmlmeUVtcGxveWVlKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBWZXJpZnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjNcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKGZvcm1hdHRlZERhdGEsIFwidGVzdCBjaGVja1wiKTtcclxuICAgICAgICBzZXRUYWJsZUVtcGxveWVlcyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW1wbG95ZWVQcm9maWxlKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hNYW5hZ2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZGVzaWduYXRpb24vZ2V0LWRlc2lnbmF0aW9uXCIpO1xyXG4gICAgICAgIHNldE1hbmFnZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaE1hbmFnZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdE1hbmFnZXIgPSAobWFuYWdlcklkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZE1hbmFnZXJJZChtYW5hZ2VySWQpO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWQgPSBtYW5hZ2Vycy5maW5kKChtZ3IpID0+IG1nci5faWQgPT09IG1hbmFnZXJJZCk7XHJcbiAgICBjb25zdCB0aXRsZSA9IHNlbGVjdGVkPy50aXRsZSB8fCBcIlwiO1xyXG4gICAgc2V0U2VsZWN0ZWRNYW5hZ2VyVGl0bGUodGl0bGUpO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIG1hbmFnZXJJZCxcclxuICAgICAgbWFuYWdlclRpdGxlOiB0aXRsZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgbWFuYWdlcklkOiBcIlwiLFxyXG4gICAgICBtYW5hZ2VyVGl0bGU6IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICBbZmllbGRdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVBbnRJbnB1dERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHsgLi4ucHJldkVycm9ycywgW2ZpZWxkXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVBbnREU2VsZWN0UmVwb3J0aW5nTWFuYWdlciA9IChyZXBvcnRpbmdJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQocmVwb3J0aW5nSWQpO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIHJlcG9ydGluZ01hbmFnZXJJZDogcmVwb3J0aW5nSWQsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIHJlcG9ydGluZ01hbmFnZXJJZDogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICh0eXBlKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGNvbnN0IGRhdGEgPSB0eXBlID09PSBcImFkZEVtcGxveWVlXCIgPyBmb3JtRGF0YSA6IHVwZGF0ZUZvcm1EYXRhO1xyXG4gICAgY29uc3QgcmVnZXggPSB7XHJcbiAgICAgIGVtYWlsOiAvXlteXFxzQF0rQFteXFxzQF0rXFwuW15cXHNAXSskLyxcclxuICAgICAgcGhvbmU6IC9eWzYtOV1cXGR7OX0kLyxcclxuICAgICAgcGFzc3dvcmQ6XHJcbiAgICAgICAgL14oPz0uKlthLXpdKSg/PS4qW0EtWl0pKD89LipcXGQpKD89LipbQCQhJSo/Jl0pW0EtWmEtelxcZEAkISUqPyZdezUsfSQvLFxyXG4gICAgICBwaW5jb2RlOiAvXlxcZHs2fSQvLFxyXG4gICAgICBhYWRoYWFyOiAvXlxcZHsxMn0kLyxcclxuICAgICAgcGFuOiAvXltBLVpdezV9WzAtOV17NH1bQS1aXXsxfSQvLFxyXG4gICAgICBhbHRlcm5hdGVfbnVtYmVyOiAvXls2LTldXFxkezl9JC8sXHJcbiAgICB9O1xyXG4gICAgaWYgKCFkYXRhLm5hbWUgfHwgIWRhdGEubmFtZS50cmltKCkpIHtcclxuICAgICAgbmV3RXJyb3JzLm5hbWUgPSBcIkZ1bGwgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLmVtYWlsKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5lbWFpbCA9IFwiRW1haWwgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoIXJlZ2V4LmVtYWlsLnRlc3QoZGF0YS5lbWFpbCkpIHtcclxuICAgICAgbmV3RXJyb3JzLmVtYWlsID0gXCJJbnZhbGlkIGVtYWlsIGZvcm1hdFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLnBob25lX251bWJlcikge1xyXG4gICAgICBuZXdFcnJvcnMucGhvbmVfbnVtYmVyID0gXCJQaG9uZSBudW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoIXJlZ2V4LnBob25lLnRlc3QoZGF0YS5waG9uZV9udW1iZXIpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5waG9uZV9udW1iZXIgPSBcIkludmFsaWQgIHBob25lIG51bWJlclwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLmFsdGVybmF0ZV9udW1iZXIpIHtcclxuICAgICAgbmV3RXJyb3JzLmFsdGVybmF0ZV9udW1iZXIgPSBcIkFsdGVybmF0ZSBQaG9uZSBudW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoIXJlZ2V4LmFsdGVybmF0ZV9udW1iZXIudGVzdChkYXRhLmFsdGVybmF0ZV9udW1iZXIpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbHRlcm5hdGVfbnVtYmVyID0gXCJJbnZhbGlkIEFsdGVybmF0ZSAgcGhvbmUgbnVtYmVyXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEucGFzc3dvcmQpIHtcclxuICAgICAgbmV3RXJyb3JzLnBhc3N3b3JkID0gXCJQYXNzd29yZCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGFzc3dvcmQudGVzdChkYXRhLnBhc3N3b3JkKSkge1xyXG4gICAgICBuZXdFcnJvcnMucGFzc3dvcmQgPVxyXG4gICAgICAgIFwiUGFzc3dvcmQgbXVzdCBjb250YWluIGF0IGxlYXN0IDUgY2hhcmFjdGVycywgb25lIHVwcGVyY2FzZSwgb25lIGxvd2VyY2FzZSwgb25lIG51bWJlciwgYW5kIG9uZSBzcGVjaWFsIGNoYXJhY3RlclwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLnN0YXR1cykge1xyXG4gICAgICBuZXdFcnJvcnMuc3RhdHVzID0gXCJTdGF0dXMgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5kb2IpIHtcclxuICAgICAgbmV3RXJyb3JzLmRvYiA9IFwiRGF0ZSBvZiBCaXJ0aCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLmpvaW5pbmdfZGF0ZSkge1xyXG4gICAgICBuZXdFcnJvcnMuam9pbmluZ19kYXRlID0gXCJKb2luaW5nIERhdGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5nZW5kZXIpIHtcclxuICAgICAgbmV3RXJyb3JzLmdlbmRlciA9IFwiUGxlYXNlIFNlbGVjdCBHZW5kZXJcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5zYWxhcnkpIHtcclxuICAgICAgbmV3RXJyb3JzLnNhbGFyeSA9IFwiU2FsYXJ5IGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEucGluY29kZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGluY29kZSA9IFwiUGluY29kZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGluY29kZS50ZXN0KGRhdGEucGluY29kZSkpIHtcclxuICAgICAgbmV3RXJyb3JzLnBpbmNvZGUgPSBcIkludmFsaWQgcGluY29kZSAoNiBkaWdpdHMgcmVxdWlyZWQpXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEuYWRoYWFyX25vKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hZGhhYXJfbm8gPSBcIkFhZGhhYXIgbnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFyZWdleC5hYWRoYWFyLnRlc3QoZGF0YS5hZGhhYXJfbm8pKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hZGhhYXJfbm8gPSBcIkludmFsaWQgQWFkaGFhciBudW1iZXIgKDEyIGRpZ2l0cyByZXF1aXJlZClcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEucGFuX25vKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wYW5fbm8gPSBcIlBBTiBudW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoIXJlZ2V4LnBhbi50ZXN0KGRhdGEucGFuX25vLnRvVXBwZXJDYXNlKCkpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wYW5fbm8gPSBcIkludmFsaWQgUEFOIGZvcm1hdCAoZS5nLiwgQUJDREUxMjM0RilcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5hZGRyZXNzIHx8ICFkYXRhLmFkZHJlc3MudHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hZGRyZXNzID0gXCJBZGRyZXNzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKGRhdGEuYWRkcmVzcy50cmltKCkubGVuZ3RoIDwgMTApIHtcclxuICAgICAgbmV3RXJyb3JzLmFkZHJlc3MgPSBcIkFkZHJlc3Mgc2hvdWxkIGJlIGF0IGxlYXN0IDEwIGNoYXJhY3RlcnNcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5lbWVyZ2VuY3lfY29udGFjdF9wZXJzb24pIHtcclxuICAgICAgbmV3RXJyb3JzLmVtZXJnZW5jeV9jb250YWN0X3BlcnNvbiA9IFwiQ29udGFjdCBQZXJzb24gTmFtZSBpcyBSZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLnRvdGFsX2FsbG9jYXRlZF9sZWF2ZXMpIHtcclxuICAgICAgbmV3RXJyb3JzLnRvdGFsX2FsbG9jYXRlZF9sZWF2ZXMgPVxyXG4gICAgICAgIFwiUGxlYXNlIFByb3ZpZGUgVG90YWwgQWxsb2NhdGVkIExlYXZlc1wiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFzZWxlY3RlZE1hbmFnZXJJZCkge1xyXG4gICAgICBuZXdFcnJvcnMuZGVzaWduYXRpb25faWQgPSBcIlBsZWFzZSBFbnRlciBEZXNpZ25hdGlvblwiO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcbiAgY29uc3QgYWRkUGhvbmVGaWVsZCA9IChmb3JtU3RhdGUsIHNldEZvcm1TdGF0ZSkgPT4ge1xyXG4gICAgY29uc3QgcGhvbmVzID0gWy4uLihmb3JtU3RhdGUuZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyIHx8IFtdKV07XHJcbiAgICBjb25zdCBsYXN0UGhvbmUgPSBwaG9uZXNbcGhvbmVzLmxlbmd0aCAtIDFdO1xyXG4gICAgaWYgKHBob25lcy5sZW5ndGggPiAwICYmICghbGFzdFBob25lIHx8IGxhc3RQaG9uZS50cmltKCkgPT09IFwiXCIpKSB7XHJcbiAgICAgIGFsZXJ0KFxyXG4gICAgICAgIFwiUGxlYXNlIGZpbGwgaW4gdGhlIGxhc3QgZW1lcmdlbmN5IGNvbnRhY3QgbnVtYmVyIGJlZm9yZSBhZGRpbmcgYSBuZXcgb25lLlwiLFxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBzZXRGb3JtU3RhdGUoe1xyXG4gICAgICAuLi5mb3JtU3RhdGUsXHJcbiAgICAgIGVtZXJnZW5jeV9jb250YWN0X251bWJlcjogWy4uLnBob25lcywgXCJcIl0sXHJcbiAgICB9KTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVBob25lQ2hhbmdlID0gKGZvcm1TdGF0ZSwgc2V0Rm9ybVN0YXRlLCBpbmRleCwgZSkgPT4ge1xyXG4gICAgY29uc3QgdmFsdWUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIGxldCBwaG9uZXMgPVxyXG4gICAgICBmb3JtU3RhdGUuZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyICYmXHJcbiAgICAgIGZvcm1TdGF0ZS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXIubGVuZ3RoID4gMFxyXG4gICAgICAgID8gWy4uLmZvcm1TdGF0ZS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXJdXHJcbiAgICAgICAgOiBbXCJcIl07XHJcbiAgICB3aGlsZSAocGhvbmVzLmxlbmd0aCA8PSBpbmRleCkge1xyXG4gICAgICBwaG9uZXMucHVzaChcIlwiKTtcclxuICAgIH1cclxuICAgIHBob25lc1tpbmRleF0gPSB2YWx1ZTtcclxuICAgIGNvbnN0IGxhc3RJbmRleCA9IHBob25lcy5yZWR1Y2VSaWdodCgobGFzdE5vbkVtcHR5LCBwaG9uZSwgaSkgPT4ge1xyXG4gICAgICByZXR1cm4gbGFzdE5vbkVtcHR5ICE9PSAtMSA/IGxhc3ROb25FbXB0eSA6IHBob25lLnRyaW0oKSAhPT0gXCJcIiA/IGkgOiAtMTtcclxuICAgIH0sIC0xKTtcclxuICAgIHBob25lcyA9IGxhc3RJbmRleCA9PT0gLTEgPyBbXCJcIl0gOiBwaG9uZXMuc2xpY2UoMCwgbGFzdEluZGV4ICsgMSk7XHJcbiAgICBzZXRGb3JtU3RhdGUoe1xyXG4gICAgICAuLi5mb3JtU3RhdGUsXHJcbiAgICAgIGVtZXJnZW5jeV9jb250YWN0X251bWJlcjogcGhvbmVzLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICBjb25zdCByZW1vdmVQaG9uZUZpZWxkID0gKGZvcm1TdGF0ZSwgc2V0Rm9ybVN0YXRlLCBpbmRleCkgPT4ge1xyXG4gICAgY29uc3QgcGhvbmVzID0gQXJyYXkuaXNBcnJheShmb3JtU3RhdGUuZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyKVxyXG4gICAgICA/IFsuLi5mb3JtU3RhdGUuZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyXVxyXG4gICAgICA6IFtdO1xyXG4gICAgY29uc3QgdXBkYXRlZFBob25lcyA9IHBob25lcy5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KTtcclxuICAgIHNldEZvcm1TdGF0ZSh7XHJcbiAgICAgIC4uLmZvcm1TdGF0ZSxcclxuICAgICAgZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyOiB1cGRhdGVkUGhvbmVzLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZGF0ZSA9IHZhbGlkYXRlRm9ybShcImFkZEVtcGxveWVlXCIpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGlzVmFsaWRhdGUpIHtcclxuICAgICAgICBjb25zdCBkYXRhVG9TZW5kID0ge1xyXG4gICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbl9pZDogc2VsZWN0ZWRNYW5hZ2VySWQsXHJcbiAgICAgICAgICByZXBvcnRpbmdfbWFuYWdlcl9pZDogc2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQsXHJcbiAgICAgICAgICBhZ2VudF90eXBlOiBcImVtcGxveWVlXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgICBcIi9hZ2VudC9hZGQtYWRkdGlvbmFsLWVtcGxveWVlLWluZm9cIixcclxuICAgICAgICAgIGRhdGFUb1NlbmQsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgIG5hbWU6IFwiXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogXCJcIixcclxuICAgICAgICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgICAgICAgYWRkcmVzczogXCJcIixcclxuICAgICAgICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICAgICAgICBhZGhhYXJfbm86IFwiXCIsXHJcbiAgICAgICAgICBwYW5fbm86IFwiXCIsXHJcbiAgICAgICAgICBqb2luaW5nX2RhdGU6IFwiXCIsXHJcbiAgICAgICAgICBzdGF0dXM6IFwiXCIsXHJcbiAgICAgICAgICBkb2I6IFwiXCIsXHJcbiAgICAgICAgICBnZW5kZXI6IFwiXCIsXHJcbiAgICAgICAgICBhbHRlcm5hdGVfbnVtYmVyOiBcIlwiLFxyXG4gICAgICAgICAgc2FsYXJ5OiBcIlwiLFxyXG4gICAgICAgICAgbGVhdmluZ19kYXRlOiBcIlwiLFxyXG4gICAgICAgICAgZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uOiBcIlwiLFxyXG4gICAgICAgICAgZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyOiBbXCJcIl0sXHJcbiAgICAgICAgICB0b3RhbF9hbGxvY2F0ZWRfbGVhdmVzOiBcIjJcIixcclxuICAgICAgICAgIGlzVmVyaWZpZWQ6IGZhbHNlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNlbGVjdGVkTWFuYWdlcklkKFwiXCIpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkKFwiXCIpO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICAvLyBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgLy8gICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIC8vICAgbWVzc2FnZTogXCJFbXBsb3llZSBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAvLyAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIC8vIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIEVtcGxveWVlOlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBlcnJvci5yZXNwb25zZSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2VcclxuICAgICAgKSB7XHJcbiAgICAgICAgY29uc3QgZXJyTXNnID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgaWYgKGVyck1zZy5pbmNsdWRlcyhcInBob25lIG51bWJlclwiKSkge1xyXG4gICAgICAgICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IFwiUGhvbmUgbnVtYmVyIGFscmVhZHkgZXhpc3RzXCIsXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlLFxyXG4gICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZUNvZGVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIElEXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImRlc2lnbmF0aW9uXCIsIGhlYWRlcjogXCJEZXNpZ25hdGlvblwiIH0sXHJcbiAgIC8vIHsga2V5OiBcInBhc3N3b3JkXCIsIGhlYWRlcjogXCJFbXBsb3llZSBQYXNzd29yZFwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlcnMuZmlsdGVyKCh1c2VyKSA9PlxyXG4gICAgdXNlci5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSxcclxuICApO1xyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2FnZW50L2dldC1hZGRpdGlvbmFsLWVtcGxveWVlLWluZm8tYnktaWQvJHt1c2VySWR9YCxcclxuICAgICAgKTtcclxuICAgICAgc2V0Q3VycmVudFVzZXIocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvYWdlbnQvZ2V0LWFkZGl0aW9uYWwtZW1wbG95ZWUtaW5mby1ieS1pZC8ke3VzZXJJZH1gLFxyXG4gICAgICApO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlVXNlcihyZXNwb25zZS5kYXRhPy5lbXBsb3llZSk7XHJcbiAgICAgIHNldFVuVmVyaWZpZWRVc2VyKHJlc3BvbnNlLmRhdGE/LmVtcGxveWVlKTtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIG5hbWU6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8ubmFtZSxcclxuICAgICAgICBlbWFpbDogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5lbWFpbCxcclxuICAgICAgICBwaG9uZV9udW1iZXI6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgIHBhc3N3b3JkOiByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LnBhc3N3b3JkLFxyXG4gICAgICAgIHBpbmNvZGU6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8ucGluY29kZSxcclxuICAgICAgICBhZGhhYXJfbm86IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uYWRoYWFyX25vLFxyXG4gICAgICAgIHBhbl9ubzogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5wYW5fbm8sXHJcbiAgICAgICAgYWRkcmVzczogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5hZGRyZXNzLFxyXG4gICAgICAgIGpvaW5pbmdfZGF0ZTogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5qb2luaW5nX2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICBzdGF0dXM6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uc3RhdHVzLFxyXG4gICAgICAgIGRvYjogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5kb2I/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICBnZW5kZXI6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uZ2VuZGVyLFxyXG4gICAgICAgIGFsdGVybmF0ZV9udW1iZXI6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uYWx0ZXJuYXRlX251bWJlcixcclxuICAgICAgICBzYWxhcnk6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uc2FsYXJ5LFxyXG4gICAgICAgIGxlYXZpbmdfZGF0ZTogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5sZWF2aW5nX2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICBlbWVyZ2VuY3lfY29udGFjdF9udW1iZXI6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZVxyXG4gICAgICAgICAgPy5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXIgfHwgW1wiXCJdLFxyXG4gICAgICAgIGVtZXJnZW5jeV9jb250YWN0X3BlcnNvbjpcclxuICAgICAgICAgIHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uLFxyXG4gICAgICAgIHRvdGFsX2FsbG9jYXRlZF9sZWF2ZXM6XHJcbiAgICAgICAgICByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LnRvdGFsX2FsbG9jYXRlZF9sZWF2ZXM/LnRvU3RyaW5nKCkgfHwgXCIyXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTZWxlY3RlZE1hbmFnZXJJZChyZXNwb25zZS5kYXRhPy5lbXBsb3llZT8uZGVzaWduYXRpb25faWQ/Ll9pZCB8fCBcIlwiKTtcclxuICAgICAgc2V0U2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQoXHJcbiAgICAgICAgcmVzcG9uc2UuZGF0YT8uZW1wbG95ZWU/LnJlcG9ydGluZ19tYW5hZ2VyX2lkIHx8IFwiXCIsXHJcbiAgICAgICk7XHJcbiAgICAgIHNldFNlbGVjdGVkTWFuYWdlclRpdGxlKHJlc3BvbnNlLmRhdGE/LmVtcGxveWVlPy5kZXNpZ25hdGlvbl9pZD8udGl0bGUpO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlVXNlciA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50VXNlcikge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoXHJcbiAgICAgICAgICBgL2FnZW50L2RlbGV0ZS1hZGRpdGlvbmFsLWVtcGxveWVlLWluZm8tYnktaWQvJHtjdXJyZW50VXNlci5faWR9YCxcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFnZW50IGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVVbnZlcmlmeUVtcGxveWVlID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICBjb25maXJtKHtcclxuICAgICAgdGl0bGU6IFwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIFZlcmlmeSB0aGlzIEVtcGxveWVlP1wiLFxyXG4gICAgICBjb250ZW50OiBcIlRoaXMgYWN0aW9uIHdpbGwgbWFyayB0aGUgRW1wbG95ZWUgYXMgVmVyaWZpZWQuXCIsXHJcbiAgICAgIG9rVGV4dDogXCJZZXMsIFZlcmlmeVwiLFxyXG4gICAgICBjYW5jZWxUZXh0OiBcIkNhbmNlbFwiLFxyXG5cclxuICAgICAgYXN5bmMgb25PaygpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coaWQgLFwiIHRoaGlzIGlzIHVudmVyZmllZCB1c2VcIilcclxuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnB1dChcclxuICAgICAgICAgICAgYC9hZ2VudC91bi1hcHByb3ZlLWVtcGxveWVlLyR7aWR9YCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIGlzVmVyaWZpZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICBcclxuICAgICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuXHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiRW1wbG95ZWUgVW4tVmVyaWZpZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHZlcmlmeSBhZ2VudFwiLFxyXG4gICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgIGNvbnN0IGRhdGFUb1NlbmQgPSB7XHJcbiAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgIGRlc2lnbmF0aW9uX2lkOiBzZWxlY3RlZE1hbmFnZXJJZCxcclxuICAgICAgICAgIHJlcG9ydGluZ19tYW5hZ2VyX2lkOiBzZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGN1cnJlbnRVcGRhdGVVc2VyLFwidGhpcyBpc2kgeXlcIilcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgICBgL2FnZW50L3VwZGF0ZS1hZGRpdGlvbmFsLWVtcGxveWVlLWluZm8vJHtjdXJyZW50VXBkYXRlVXNlci5faWR9YCxcclxuICAgICAgICAgIGRhdGFUb1NlbmQsXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkTWFuYWdlcklkKFwiXCIpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkKFwiXCIpO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJFbXBsb3llZSBEZXRhaWxzIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGFnZW50OlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBlcnJvci5yZXNwb25zZSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2VcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGAke2Vycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZX1gLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZU1hbmFnZXIgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGNvbnN0IGdyb3VwSWQgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRTZWxlY3RlZE1hbmFnZXJJZChncm91cElkKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkID0gbWFuYWdlcnMuZmluZCgobWdyKSA9PiBtZ3IuX2lkID09PSBncm91cElkKTtcclxuICAgIHNldFNlbGVjdGVkTWFuYWdlclRpdGxlKHNlbGVjdGVkPy50aXRsZSB8fCBcIlwiKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVJlcG9ydGluZ01hbmFnZXIgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGNvbnN0IHJlcG9ydGluZ0lkID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0U2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQocmVwb3J0aW5nSWQpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgPEJyZWFkY3J1bWIvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5Vbi12ZXJpZmllZCBFbXBsb3llZXM8L2gxPlxyXG4gICAgICAgICAgICAgICAgey8qIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgKyBBZGQgRW1wbG95ZWVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPiAqL31cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtUYWJsZUVtcGxveWVlcz8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZUVtcGxveWVlcywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEVtcGxveWVlcy5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e1RhYmxlRW1wbG95ZWVzPy5sZW5ndGggPD0gMH1cclxuICAgICAgICAgICAgICAgIGRhdGE9XCJFbXBsb3llZSBEYXRhXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd01vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBBZGQgRW1wbG95ZWVcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRnVsbCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRnVsbCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5uYW1lfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVtYWlsIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbWFpbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZW1haWx9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5waG9uZV9udW1iZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGFzc1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQYXNzd29yZCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBpbmNvZGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5waW5jb2RlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEFkaGFhciBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFkaGFhcl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGhhYXIgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRoYWFyX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBhbiBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYW5fbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYW5fbm99XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFuIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhbl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMucGFuX25vfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBZGRyZXNzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuYWRkcmVzc308L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRGVzaWduYXRpb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cImRlc2lnbmF0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGVzaWduYXRpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZE1hbmFnZXJJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUFudERTZWxlY3RNYW5hZ2VyfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IERlc2lnbmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge21hbmFnZXJzLm1hcCgobWdyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e21nci5faWR9IHZhbHVlPXttZ3IuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge21nci50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb25faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFN0YXR1cyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IFN0YXR1czwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhY3RpdmVcIj5BY3RpdmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiaW5hY3RpdmVcIj5JbmFjdGl2ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0ZXJtaW5hdGVkXCI+VGVybWluYXRlZDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5zdGF0dXMgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJzdGF0dXNcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcIkFjdGl2ZVwiLCBcIkluYWN0aXZlXCIsIFwiVGVybWluYXRlZFwiXS5tYXAoKHN0eXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3N0eXBlfSB2YWx1ZT17c3R5cGUudG9Mb3dlckNhc2UoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc3RhdHVzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5zdGF0dXN9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJqb2luaW5nZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBKb2luaW5nIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJqb2luaW5nX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5qb2luaW5nX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImpvaW5pbmdkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEVtcGxveWVlIEpvaW5pbmcgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5qb2luaW5nX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuam9pbmluZ19kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImxkXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIExlYXZpbmcgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhdmluZ19kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubGVhdmluZ19kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBMZWF2aW5nIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZG9iXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIERhdGUgb2YgQmlydGggPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkb2JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5kb2J9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImRvYlwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbXBsb3llZSBEYXRlIG9mIEJpcnRoXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRvYiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZG9ifTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdlbmRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBHZW5kZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgey8qIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmdlbmRlcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBHZW5kZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibWFsZVwiPk1hbGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZmVtYWxlXCI+RmVtYWxlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmdlbmRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcImdlbmRlclwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7W1wiTWFsZVwiLCBcIkZlbWFsZVwiLCBcIk90aGVyc1wiXS5tYXAoKGdlbmRlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtnZW5kZXJ9IHZhbHVlPXtnZW5kZXIudG9Mb3dlckNhc2UoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtnZW5kZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdlbmRlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZ2VuZGVyfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic2FsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNhbGFyeSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2FsYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2FsYXJ5fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJzYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgWW91ciBTYWxhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5zYWxhcnkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnNhbGFyeX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJhbHRlcm5hdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQWx0ZXJuYXRlIFBob25lIE51bWJlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWx0ZXJuYXRlX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFsdGVybmF0ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImFsdGVybmF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBbHRlcm5hdGUgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWx0ZXJuYXRlX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbHRlcm5hdGVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidG90YWxfYWxsb2NhdGVkX2xlYXZlc1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBUb3RhbCBBbGxvY2F0ZWQgTGVhdmVze1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0b3RhbF9hbGxvY2F0ZWRfbGVhdmVzXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudG90YWxfYWxsb2NhdGVkX2xlYXZlc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidG90YWxfYWxsb2NhdGVkX2xlYXZlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0b3RhbCBhbGxvY2F0ZWQgbGVhdmVzXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMudG90YWxfYWxsb2NhdGVkX2xlYXZlcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50b3RhbF9hbGxvY2F0ZWRfbGVhdmVzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVtZXJnZW5jeSBDb250YWN0IFBlcnNvblxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJjcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbWVyZ2VuY3kgQ29udGFjdCBQZXJzb24gTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtZXJnZW5jeV9jb250YWN0X3BlcnNvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbWVyZ2VuY3lfY29udGFjdF9wZXJzb259XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWVyZ2VuY3lcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRW1lcmdlbmN5IFBob25lIE51bWJlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYi0yIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWVyZ2VuY3lfY29udGFjdF9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVtZXJnZW5jeV9jb250YWN0X251bWJlcj8uWzBdIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVBob25lQ2hhbmdlKGZvcm1EYXRhLCBzZXRGb3JtRGF0YSwgMCwgZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZW1lcmdlbmN5XzBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBEZWZhdWx0IEVtZXJnZW5jeSBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICA/LnNsaWNlKDEpXHJcbiAgICAgICAgICAgICAgICAgICAgLm1hcCgocGhvbmUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG1iLTIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17YGVtZXJnZW5jeV9waG9uZV8ke2luZGV4ICsgMX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVQaG9uZUNoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgZW1lcmdlbmN5XyR7aW5kZXggKyAxfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGRpdGlvbmFsIEVtZXJnZW5jeSBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpbmRleCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3ZlUGhvbmVGaWVsZChmb3JtRGF0YSwgc2V0Rm9ybURhdGEsIGluZGV4ICsgMSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZW1vdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYWRkUGhvbmVGaWVsZChmb3JtRGF0YSwgc2V0Rm9ybURhdGEpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1ibHVlLTYwMCB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICsgQWRkIEFub3RoZXJcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMFxyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBVbi12ZXJpZmllZCBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIFVwZGF0ZSBVbi12ZXJpZmllZCBFbXBsb3llZVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBGdWxsIE5hbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEubmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBGdWxsIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMubmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLm5hbWV9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRW1haWwgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtYWlsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5lbWFpbH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEFkaGFhciBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWRoYWFyX25vXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWRoYWFyIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkaGFhcl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQYW4gTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhbl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBhbiBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYW5fbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnBhbl9ub308L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmFkZHJlc3N9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQaW5jb2RlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBpbmNvZGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIERlc2lnbmF0aW9uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGVzaWduYXRpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkZXNpZ25hdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTWFuYWdlcklkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQW50RFNlbGVjdE1hbmFnZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRGVzaWduYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7bWFuYWdlcnMubWFwKChtYW5hZ2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e21hbmFnZXIuX2lkfSB2YWx1ZT17bWFuYWdlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bWFuYWdlci50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb25faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFN0YXR1cyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgU3RhdHVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFjdGl2ZVwiPkFjdGl2ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJpbmFjdGl2ZVwiPkluYWN0aXZlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInRlcm1pbmF0ZWRcIj5UZXJtaW5hdGVkPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgU3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnN0YXR1cyB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50SW5wdXREU2VsZWN0KFwic3RhdHVzXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCJBY3RpdmVcIiwgXCJJbmFjdGl2ZVwiLCBcIlRlcm1pbmF0ZWRcIl0ubWFwKChzdGF0dXMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3RhdHVzfSB2YWx1ZT17c3RhdHVzLnRvTG93ZXJDYXNlKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdGF0dXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnN0YXR1c308L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImpvaW5pbmdkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEpvaW5pbmcgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImpvaW5pbmdfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmpvaW5pbmdfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJqb2luaW5nZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbXBsb3llZSBKb2luaW5nIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuam9pbmluZ19kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmpvaW5pbmdfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJsZFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBMZWF2aW5nIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYXZpbmdfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LmxlYXZpbmdfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKHVwZGF0ZUZvcm1EYXRhPy5sZWF2aW5nX2RhdGUgfHwgXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBMZWF2aW5nIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZG9CXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIERhdGUgb2YgQmlydGggPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkb2JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5kb2JcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZSh1cGRhdGVGb3JtRGF0YT8uZG9iIHx8IFwiXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9JU09TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZG9CXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEVtcGxveWVlIERhdGUgb2YgQmlydGhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZG9iICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5kb2J9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdlbmRlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJnZW5kZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZ2VuZGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgR2VuZGVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm1hbGVcIj5NYWxlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImZlbWFsZVwiPkZlbWFsZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdlbmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdlbmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5nZW5kZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudElucHV0RFNlbGVjdChcImdlbmRlclwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7W1wiTWFsZVwiLCBcIkZlbWFsZVwiLCBcIk90aGVyc1wiXS5tYXAoKGdlbmRlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtnZW5kZXJ9IHZhbHVlPXtnZW5kZXIudG9Mb3dlckNhc2UoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtnZW5kZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdlbmRlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZ2VuZGVyfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic2FsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNhbGFyeSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2FsYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuc2FsYXJ5fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInNhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBTYWxhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5zYWxhcnkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnNhbGFyeX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJhbHRlcm5hdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQWx0ZXJuYXRlIFBob25lIE51bWJlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWx0ZXJuYXRlX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmFsdGVybmF0ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYWx0ZXJuYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFsdGVybmF0ZSBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbHRlcm5hdGVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFsdGVybmF0ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ0b3RhbF9hbGxvY2F0ZWRfbGVhdmVzXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFRvdGFsIE5vLiBvZiBMZWF2ZXMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRvdGFsX2FsbG9jYXRlZF9sZWF2ZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS50b3RhbF9hbGxvY2F0ZWRfbGVhdmVzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRvdGFsX2FsbG9jYXRlZF9sZWF2ZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdG90YWwgbGVhdmVzXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMudG90YWxfYWxsb2NhdGVkX2xlYXZlcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50b3RhbF9hbGxvY2F0ZWRfbGVhdmVzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVtZXJnZW5jeSBDb250YWN0IFBlcnNvbntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVtZXJnZW5jeV9jb250YWN0X3BlcnNvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5lbWVyZ2VuY3lfY29udGFjdF9wZXJzb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1lcmdlbmN5IENvbnRhY3QgUGVyc29uIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbWVyZ2VuY3lfY29udGFjdF9wZXJzb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29ufVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1lcmdlbmN5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVtZXJnZW5jeSBQaG9uZSBOdW1iZXJ7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbWItMiBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXI/LlswXSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVQaG9uZUNoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZW1lcmdlbmN5XzBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBEZWZhdWx0IEVtZXJnZW5jeSBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICA/LnNsaWNlKDEpXHJcbiAgICAgICAgICAgICAgICAgICAgLm1hcCgocGhvbmUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXggKyAxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYi0yIGdhcC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17YGVtZXJnZW5jeV9waG9uZV8ke2luZGV4ICsgMX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVQaG9uZUNoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgZW1lcmdlbmN5XyR7aW5kZXggKyAxfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGRpdGlvbmFsIEVtZXJnZW5jeSBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3ZlUGhvbmVGaWVsZChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJlbW92ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGFkZFBob25lRmllbGQodXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHRleHQtYmx1ZS02MDAgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICArIEFkZCBBbm90aGVyXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctYmx1ZS03MDAgaG92ZXI6YmctYmx1ZS04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFVwZGF0ZSBVbi12ZXJpZmllZCBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBEZWxldGUgVW4tdmVyaWZpZWQgRW1wbG95ZWVcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAge2N1cnJlbnRVc2VyICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlVXNlcigpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBpZD1cImdyb3VwTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgZW1wbG95ZWUgRnVsbCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXJlZC03MDAgaG92ZXI6YmctcmVkLTgwMFxyXG4gICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5leHBvcnQgZGVmYXVsdCBVbkFwcHJvdmVkRW1wbG95ZWU7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9VbkFwcHJvdmVkRW1wbG95ZWUuanN4In0=