import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LeadReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
const LeadReport = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableGroups, setTableGroups] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [loader, setLoader] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [leads, setLeads] = useState([]);
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [errors, setErrors] = useState({});
  const [showFilterField, setShowFilterField] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [filteredLeads, setFilteredLeads] = useState([]);
  const [leadSourceOptions, setLeadSourceOptions] = useState([]);
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const handleGroupChange = async (groupId) => {
    setSelectedGroup(groupId);
  };
  const [formData, setFormData] = useState({
    lead_name: "",
    lead_phone: "",
    lead_profession: "",
    group_id: "",
    lead_type: "",
    lead_customer: "",
    lead_needs: "",
    note: ""
  });
  const [showContextMenu, setShowContextMenu] = useState({});
  const [updateFormData, setUpdateFormData] = useState({
    lead_name: "",
    lead_phone: "",
    lead_profession: "",
    group_id: "",
    lead_type: "",
    lead_customer: "",
    lead_agent: "",
    lead_needs: "",
    note: ""
  });
  const groupTime = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const now = /* @__PURE__ */ new Date();
  const formatToday = (date) => now.toLocaleDateString("en-CA");
  const formatString = formatToday(now);
  const [selectedFromDate, setSelectedFromDate] = useState(formatString);
  const [selectedToDate, setSelectedToDate] = useState(formatString);
  const [selectedLeadSourceName, setSelectedLeadSourceName] = useState("");
  const [selectedNote, setSelectedNote] = useState("");
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addLead" ? formData : updateFormData;
    if (!data.lead_name.trim()) {
      newErrors.lead_name = "Lead Name is required";
    }
    if (!data.lead_phone) {
      newErrors.lead_phone = "Phone Number is required";
    } else if (!/^[6-9]\d{9}$/.test(data.lead_phone)) {
      newErrors.lead_phone = "Invalid phone number (must be 10 digits)";
    }
    if (!data.lead_profession) {
      newErrors.lead_profession = "Profession is required";
    }
    if (!data.lead_type) {
      newErrors.lead_type = "Lead Source Type is required";
    }
    if (data.lead_type === "customer" && !data.lead_customer) {
      newErrors.lead_customer = "Customer selection is required";
    }
    if (data.lead_type === "agent" && !data.lead_agent) {
      newErrors.lead_agent = "Agent selection is required";
    }
    if (!data.lead_needs.trim()) {
      newErrors.lead_needs = "Lead Needs and Goals is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const uniqueLeadSources = () => {
    const sourceMap = /* @__PURE__ */ new Map();
    leads.forEach((lead) => {
      if (lead.lead_agent?._id && lead.lead_agent?.name) {
        sourceMap.set(`agent-${lead.lead_agent._id}`, {
          id: lead?.lead_agent?._id,
          name: lead?.lead_agent?.name,
          type: "Agent"
        });
      }
    });
    return Array.from(sourceMap.values());
  };
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  const onContextMenuPressed = (id) => {
    setShowContextMenu((prev) => ({ ...prev, [id]: true }));
    console.log(showContextMenu);
  };
  const filteredGroups = groups.filter(
    (group) => group.group_name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/lead/get-lead-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching lead:", error);
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/lead/get-lead-by-id/${groupId}`);
      const groupData = response.data;
      setCurrentUpdateGroup(response.data);
      setUpdateFormData({
        lead_name: response.data.lead_name,
        lead_phone: response.data.lead_phone,
        lead_profession: response.data.lead_profession,
        group_id: response.data.group_id,
        lead_type: response.data.lead_type,
        lead_customer: response.data.lead_customer,
        lead_agent: response.data.lead_agent,
        lead_needs: response.data?.lead_needs,
        note: response.data.note
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching group:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };
  const handleDeleteGroup = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/lead/delete-lead/${currentGroup._id}`);
        setShowModalDelete(false);
        setCurrentGroup(null);
        setAlertConfig({
          visibility: true,
          message: "Lead deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting lead:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        await api.put(
          `/lead/update-lead/${currentUpdateGroup._id}`,
          updateFormData
        );
        setShowModalUpdate(false);
        setAlertConfig({
          visibility: true,
          message: "Lead Updated Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error updating group:", error);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "name", header: "Lead Name" },
    { key: "phone", header: "Lead Phone Number" },
    { key: "profession", header: "Lead Profession" },
    { key: "date", header: "Date" },
    { key: "group_id", header: "Group Name" },
    { key: "lead_type", header: "Lead Source Type" },
    { key: "lead_needs", header: "Lead Needs And Goals" },
    { key: "lead_type_name", header: "Lead Source Name" },
    { key: "note", header: "Note" },
    { key: "action", header: "Action" }
  ];
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get("/agent/get-agent");
        setAgents(response.data);
      } catch (error) {
        console.error("Error fetching agent data:", error);
      }
    };
    fetchAgents();
  }, []);
  useEffect(
    () => {
      const fetchFilteredLead = async () => {
        setLoader(true);
        try {
          console.info("fromdate", selectedFromDate, selectedToDate);
          const response = await api.get("/lead-report/get-lead-report", {
            params: {
              from_date: selectedFromDate,
              to_date: selectedToDate,
              lead_source_name: selectedLeadSourceName,
              group_id: selectedGroup,
              note: selectedNote
            }
          });
          const rawData = response.data;
          const uniqueSources = [
            ...new Map(
              rawData.map((lead) => {
                const source = lead.lead_type === "customer" ? lead.lead_customer : lead.lead_type === "agent" ? lead.lead_agent : null;
                if (!source || !source._id) return null;
                return {
                  id: source._id,
                  name: source.full_name || source.name || "Unnamed"
                };
              }).filter(Boolean).map((item) => [item.id, item])
            ).values()
          ];
          setLeadSourceOptions(uniqueSources);
          const formattedData = rawData.map((group, index) => ({
            _id: group._id,
            id: index + 1,
            name: group.lead_name,
            phone: group.lead_phone,
            profession: group.lead_profession,
            lead_needs: group?.lead_needs,
            group_id: group?.group_id?.group_name,
            date: group?.createdAt?.split("T")[0],
            lead_type: group.lead_type === "agent" ? "employee" : group.lead_type,
            note: group?.note,
            lead_type_name: group.lead_type === "customer" ? group?.lead_customer?.full_name : group.lead_type === "agent" ? group?.lead_agent?.name : "",
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2 relative", children: /* @__PURE__ */ jsxDEV(
              Dropdown,
              {
                menu: {
                  items: [
                    {
                      key: "1",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-green-600",
                          onClick: () => handleUpdateModalOpen(group._id),
                          children: "Edit"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                          lineNumber: 439,
                          columnNumber: 19
                        },
                        this
                      )
                    },
                    {
                      key: "2",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-red-600",
                          onClick: () => handleDeleteModalOpen(group._id),
                          children: "Delete"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                          lineNumber: 450,
                          columnNumber: 19
                        },
                        this
                      )
                    }
                  ]
                },
                placement: "bottomLeft",
                children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 462,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 433,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 432,
              columnNumber: 11
            }, this)
          }));
          setTableGroups(formattedData);
        } catch (err) {
          setTableGroups([]);
          console.error("Failed to fetch Data", err.message);
        } finally {
          setLoader(false);
        }
      };
      fetchFilteredLead();
    },
    [
      selectedFromDate,
      selectedToDate,
      selectedLeadSourceName,
      selectedGroup,
      selectedNote
    ]
  );
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-hidden", children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
        lineNumber: 526,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: " flex-1 mt-30", children: [
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
          lineNumber: 531,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-7", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "font-bold text-2xl", children: "Reports - Lead " }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
          lineNumber: 537,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start items-center w-screen gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Filter Option" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 542,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                onChange: handleSelectFilter,
                placeholder: "Search Or Select Filter",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full max-w-xs h-11",
                value: selectedLabel || void 0,
                children: groupTime.map(
                  (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                    lineNumber: 558,
                    columnNumber: 23
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 543,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 541,
            columnNumber: 19
          }, this),
          showFilterField && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "From Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 567,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedFromDate,
                  onChange: (e) => setSelectedFromDate(e.target.value),
                  className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full max-w-xs"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 568,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 566,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "To Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 576,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedToDate,
                  onChange: (e) => setSelectedToDate(e.target.value),
                  className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full max-w-xs"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 577,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 575,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 565,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 587,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedGroup,
                onChange: handleGroupChange,
                placeholder: "Search Or Select Group",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full max-w-xs h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                    lineNumber: 614,
                    columnNumber: 23
                  }, this),
                  groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 616,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 600,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 586,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Lead Source Name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 623,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedLeadSourceName,
                onChange: (value) => setSelectedLeadSourceName(value),
                placeholder: "Search Or Select Lead Source Name",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full max-w-xs h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                    lineNumber: 653,
                    columnNumber: 23
                  }, this),
                  leadSourceOptions.map(
                    (source) => /* @__PURE__ */ jsxDEV(Select.Option, { value: source.id, children: source.name }, source.id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 655,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 639,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 622,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Note" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 663,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                value: selectedNote,
                popupMatchSelectWidth: false,
                onChange: (value) => setSelectedNote(value),
                placeholder: "Search Or Select Note",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full max-w-xs h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                    lineNumber: 692,
                    columnNumber: 23
                  }, this),
                  leads.filter((lead) => lead?.note).map(
                    (lead) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lead?.note, children: lead.note }, lead?._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 696,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 678,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 662,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
          lineNumber: 540,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
          lineNumber: 539,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
          lineNumber: 538,
          columnNumber: 13
        }, this),
        loader ? /* @__PURE__ */ jsxDEV("div", { className: "flex w-full justify-center items-center", children: [
          /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 707,
            columnNumber: 17
          }, this),
          ";"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
          lineNumber: 706,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableGroups, searchText),
            columns,
            exportedPdfName: "Lead Report",
            exportedFileName: `Lead Report.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 710,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
          lineNumber: 719,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
        lineNumber: 536,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
      lineNumber: 530,
      columnNumber: 10
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => {
          setShowModalUpdate(false);
          setErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 731,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "Lead Name"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 737,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "lead_name",
                  value: updateFormData.lead_name,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Group Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 743,
                  columnNumber: 17
                },
                this
              ),
              errors.lead_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 754,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 736,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Lead Phone Number"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                    lineNumber: 761,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "lead_phone",
                    value: updateFormData.lead_phone,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Lead Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                    lineNumber: 767,
                    columnNumber: 19
                  },
                  this
                ),
                errors.lead_phone && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_phone }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 778,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 760,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Lead Work/Profession"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                    lineNumber: 784,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    placeholder: "Select Lead Work/Profession ",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "lead_profession",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.lead_profession || void 0,
                    onChange: (value) => handleAntInputDSelect("lead_profession", value),
                    children: ["Employed", "Self Employed"].map(
                      (lProf) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lProf.toLowerCase(), children: lProf }, lProf, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                        lineNumber: 819,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                    lineNumber: 802,
                    columnNumber: 19
                  },
                  this
                ),
                errors.lead_profession && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_profession }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 825,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 783,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 759,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Group"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 832,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Group ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "group_id",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.group_id || void 0,
                  onChange: (value) => handleAntInputDSelect("group_id", value),
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 866,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 853,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 831,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Lead Source Type"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 873,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select or Search Lead Source Type ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.lead_type || void 0,
                  onChange: (value) => handleAntInputDSelect("lead_type", value),
                  children: [
                    "Social Media",
                    "Customer",
                    "Agent",
                    "Employee",
                    "Walkin"
                  ].map(
                    (type) => /* @__PURE__ */ jsxDEV(Select.Option, { value: type.toLowerCase(), children: type }, type, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 914,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 893,
                  columnNumber: 17
                },
                this
              ),
              errors.lead_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 920,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 872,
              columnNumber: 15
            }, this),
            updateFormData.lead_type === "customer" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Customers"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 928,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customers",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_customer",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.lead_customer || void 0,
                  onChange: (value) => handleAntInputDSelect("lead_customer", value),
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 967,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 949,
                  columnNumber: 21
                },
                this
              ),
              errors.lead_customer && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 973,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 927,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 926,
              columnNumber: 15
            }, this),
            " ",
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: "Note"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 980,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "note",
                value: updateFormData.note,
                onChange: handleInputChange,
                id: "text",
                placeholder: "Specify note if any!",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 986,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Lead Needs and Goals"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 997,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select or Search Lead Needs and Goals ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_needs",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.lead_needs || void 0,
                  onChange: (value) => handleAntInputDSelect("lead_needs", value),
                  children: ["Savings", "Borrowings"].map(
                    (type) => /* @__PURE__ */ jsxDEV(Select.Option, { value: type.toLowerCase(), children: type }, type, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 1030,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 1015,
                  columnNumber: 17
                },
                this
              ),
              errors.lead_needs && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_needs }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 1036,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 996,
              columnNumber: 15
            }, this),
            updateFormData.lead_type === "agent" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Agents"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 1044,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "lead_agent",
                  id: "category",
                  value: updateFormData.lead_agent,
                  onChange: handleInputChange,
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Agent" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 1058,
                      columnNumber: 23
                    }, this),
                    agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV("option", { value: agent._id, children: agent.name }, agent._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                        lineNumber: 1060,
                        columnNumber: 21
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 1050,
                  columnNumber: 21
                },
                this
              ),
              errors.lead_agent && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_agent }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 1066,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 1043,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 1042,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                lineNumber: 1074,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 1073,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 735,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
          lineNumber: 730,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
        lineNumber: 723,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
            lineNumber: 1093,
            columnNumber: 13
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteGroup();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentGroup.lead_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                          lineNumber: 1110,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion."
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 1105,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the Lead Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                      lineNumber: 1115,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                  lineNumber: 1104,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
                    lineNumber: 1123,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
              lineNumber: 1097,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
          lineNumber: 1092,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
        lineNumber: 1085,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
    lineNumber: 525,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx",
    lineNumber: 524,
    columnNumber: 5
  }, this);
};
_s(LeadReport, "3j1oKx7gci305BlhM1zB+vmR5Qg=");
_c = LeadReport;
export default LeadReport;
var _c;
$RefreshReg$(_c, "LeadReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc2J3QixTQXVlUixVQXZlUTsyQkF0YnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUNqQyxTQUFTQyxpQkFBaUI7QUFDMUIsTUFBTUMsYUFBYUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJZixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDZ0IsYUFBYUMsY0FBYyxJQUFJakIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ2tCLFlBQVlDLGFBQWEsSUFBSW5CLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNvQixpQkFBaUJDLGtCQUFrQixJQUFJckIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3NCLGlCQUFpQkMsa0JBQWtCLElBQUl2QixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDd0IsY0FBY0MsZUFBZSxJQUFJekIsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQzBCLG9CQUFvQkMscUJBQXFCLElBQUkzQixTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDNEIsUUFBUUMsU0FBUyxJQUFJN0IsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQzhCLGVBQWVDLGdCQUFnQixJQUFJL0IsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ2dDLE9BQU9DLFFBQVEsSUFBSWpDLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNrQyxPQUFPQyxRQUFRLElBQUluQyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDb0MsUUFBUUMsU0FBUyxJQUFJckMsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3NDLFFBQVFDLFNBQVMsSUFBSXZDLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ3dDLGlCQUFpQkMsa0JBQWtCLElBQUl6QyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDMEMsWUFBWUMsYUFBYSxJQUFJM0MsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzRDLGVBQWVDLGdCQUFnQixJQUFJN0MsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzhDLG1CQUFtQkMsb0JBQW9CLElBQUkvQyxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDZ0QsZUFBY0MsZ0JBQWdCLElBQUlqRCxTQUFTLE9BQU87QUFDekQsUUFBTWtELDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6Q1Isa0JBQWNRLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxFQUM5QjtBQUNBLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJdkQsU0FBUztBQUFBLElBQzdDd0QsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTUMsb0JBQW9CLE9BQU9DLFlBQVk7QUFFM0M3QixxQkFBaUI2QixPQUFPO0FBQUEsRUFDMUI7QUFDQSxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSTlELFNBQVM7QUFBQSxJQUN2QytELFdBQVc7QUFBQSxJQUNYQyxZQUFZO0FBQUEsSUFDWkMsaUJBQWlCO0FBQUEsSUFDakJDLFVBQVU7QUFBQSxJQUNWQyxXQUFXO0FBQUEsSUFDWEMsZUFBZTtBQUFBLElBQ2ZDLFlBQVk7QUFBQSxJQUNaQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxpQkFBaUJDLGtCQUFrQixJQUFJeEUsU0FBUyxDQUFDLENBQUM7QUFDekQsUUFBTSxDQUFDeUUsZ0JBQWdCQyxpQkFBaUIsSUFBSTFFLFNBQVM7QUFBQSxJQUNuRCtELFdBQVc7QUFBQSxJQUNYQyxZQUFZO0FBQUEsSUFDWkMsaUJBQWlCO0FBQUEsSUFDakJDLFVBQVU7QUFBQSxJQUNWQyxXQUFXO0FBQUEsSUFDWEMsZUFBZTtBQUFBLElBQ2ZPLFlBQVk7QUFBQSxJQUNaTixZQUFZO0FBQUEsSUFDWkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU1NLFlBQVk7QUFBQSxJQUNoQixFQUFFdkIsT0FBTyxTQUFTd0IsT0FBTyxRQUFRO0FBQUEsSUFDakMsRUFBRXhCLE9BQU8sYUFBYXdCLE9BQU8sWUFBWTtBQUFBLElBQ3pDLEVBQUV4QixPQUFPLGFBQWF3QixPQUFPLGFBQWE7QUFBQSxJQUMxQyxFQUFFeEIsT0FBTyxhQUFhd0IsT0FBTyxhQUFhO0FBQUEsSUFDMUMsRUFBRXhCLE9BQU8sWUFBWXdCLE9BQU8sWUFBWTtBQUFBLElBQ3hDLEVBQUV4QixPQUFPLFVBQVV3QixPQUFPLFNBQVM7QUFBQSxFQUFDO0FBRXRDLFFBQU1DLE1BQU0sb0JBQUlDLEtBQUs7QUFDckIsUUFBTUMsY0FBY0EsQ0FBQ0MsU0FBU0gsSUFBSUksbUJBQW1CLE9BQU87QUFDNUQsUUFBTUMsZUFBZUgsWUFBWUYsR0FBRztBQUVwQyxRQUFNLENBQUNNLGtCQUFrQkMsbUJBQW1CLElBQUlyRixTQUFTbUYsWUFBWTtBQUNyRSxRQUFNLENBQUNHLGdCQUFnQkMsaUJBQWlCLElBQUl2RixTQUFTbUYsWUFBWTtBQUVqRSxRQUFNLENBQUNLLHdCQUF3QkMseUJBQXlCLElBQUl6RixTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDMEYsY0FBY0MsZUFBZSxJQUFJM0YsU0FBUyxFQUFFO0FBRW5ELFFBQU00RixlQUFlQSxDQUFDbEMsU0FBUztBQUM3QixVQUFNbUMsWUFBWSxDQUFDO0FBQ25CLFVBQU1DLE9BQU9wQyxTQUFTLFlBQVlHLFdBQVdZO0FBQzdDLFFBQUksQ0FBQ3FCLEtBQUsvQixVQUFVZ0MsS0FBSyxHQUFHO0FBQzFCRixnQkFBVTlCLFlBQVk7QUFBQSxJQUN4QjtBQUVBLFFBQUksQ0FBQytCLEtBQUs5QixZQUFZO0FBQ3BCNkIsZ0JBQVU3QixhQUFhO0FBQUEsSUFDekIsV0FBVyxDQUFDLGVBQWVnQyxLQUFLRixLQUFLOUIsVUFBVSxHQUFHO0FBQ2hENkIsZ0JBQVU3QixhQUFhO0FBQUEsSUFDekI7QUFFQSxRQUFJLENBQUM4QixLQUFLN0IsaUJBQWlCO0FBQ3pCNEIsZ0JBQVU1QixrQkFBa0I7QUFBQSxJQUM5QjtBQUVBLFFBQUksQ0FBQzZCLEtBQUszQixXQUFXO0FBQ25CMEIsZ0JBQVUxQixZQUFZO0FBQUEsSUFDeEI7QUFFQSxRQUFJMkIsS0FBSzNCLGNBQWMsY0FBYyxDQUFDMkIsS0FBSzFCLGVBQWU7QUFDeER5QixnQkFBVXpCLGdCQUFnQjtBQUFBLElBQzVCO0FBRUEsUUFBSTBCLEtBQUszQixjQUFjLFdBQVcsQ0FBQzJCLEtBQUtuQixZQUFZO0FBQ2xEa0IsZ0JBQVVsQixhQUFhO0FBQUEsSUFDekI7QUFDQSxRQUFJLENBQUNtQixLQUFLekIsV0FBVzBCLEtBQUssR0FBRztBQUMzQkYsZ0JBQVV4QixhQUFhO0FBQUEsSUFDekI7QUFFQTlCLGNBQVVzRCxTQUFTO0FBQ25CLFdBQU9JLE9BQU9DLEtBQUtMLFNBQVMsRUFBRU0sV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTUMsb0JBQW9CQSxNQUFNO0FBQzlCLFVBQU1DLFlBQVksb0JBQUlDLElBQUk7QUFFMUJ0RSxVQUFNdUUsUUFBUSxDQUFDQyxTQUFTO0FBRXRCLFVBQUlBLEtBQUs3QixZQUFZOEIsT0FBT0QsS0FBSzdCLFlBQVkrQixNQUFNO0FBQ2pETCxrQkFBVU0sSUFBSSxTQUFTSCxLQUFLN0IsV0FBVzhCLEdBQUcsSUFBSTtBQUFBLFVBQzVDRyxJQUFJSixNQUFNN0IsWUFBWThCO0FBQUFBLFVBQ3RCQyxNQUFNRixNQUFNN0IsWUFBWStCO0FBQUFBLFVBQ3hCaEQsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQVNGLENBQUM7QUFFRCxXQUFPbUQsTUFBTUMsS0FBS1QsVUFBVVUsT0FBTyxDQUFDO0FBQUEsRUFDdEM7QUFFQWhILFlBQVUsTUFBTTtBQUNkLFVBQU1pSCxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTS9HLElBQUlnSCxJQUFJLHdCQUF3QjtBQUV2RG5HLGtCQUFVa0csU0FBU25CLElBQUk7QUFBQSxNQUN6QixTQUFTcUIsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUgsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUNMLFFBQU1LLHVCQUF1QkEsQ0FBQ1QsT0FBTztBQUNuQ3BDLHVCQUFtQixDQUFDOEMsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ1YsRUFBRSxHQUFHLEtBQUssRUFBRTtBQUN0RFEsWUFBUUcsSUFBSWhELGVBQWU7QUFBQSxFQUM3QjtBQUVBLFFBQU1pRCxpQkFBaUIxRyxPQUFPMkc7QUFBQUEsSUFBTyxDQUFDQyxVQUNwQ0EsTUFBTUMsV0FBV0MsWUFBWSxFQUFFQyxTQUFTM0csV0FBVzBHLFlBQVksQ0FBQztBQUFBLEVBQ2xFO0FBRUEsUUFBTUUsd0JBQXdCLE9BQU9sRSxZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNcUQsV0FBVyxNQUFNL0csSUFBSWdILElBQUksd0JBQXdCdEQsT0FBTyxFQUFFO0FBQ2hFbkMsc0JBQWdCd0YsU0FBU25CLElBQUk7QUFDN0J6RSx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVM4RixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBRUEsUUFBTVksd0JBQXdCLE9BQU9uRSxZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNcUQsV0FBVyxNQUFNL0csSUFBSWdILElBQUksd0JBQXdCdEQsT0FBTyxFQUFFO0FBQ2hFLFlBQU1vRSxZQUFZZixTQUFTbkI7QUFDM0JuRSw0QkFBc0JzRixTQUFTbkIsSUFBSTtBQUNuQ3BCLHdCQUFrQjtBQUFBLFFBQ2hCWCxXQUFXa0QsU0FBU25CLEtBQUsvQjtBQUFBQSxRQUN6QkMsWUFBWWlELFNBQVNuQixLQUFLOUI7QUFBQUEsUUFDMUJDLGlCQUFpQmdELFNBQVNuQixLQUFLN0I7QUFBQUEsUUFDL0JDLFVBQVUrQyxTQUFTbkIsS0FBSzVCO0FBQUFBLFFBQ3hCQyxXQUFXOEMsU0FBU25CLEtBQUszQjtBQUFBQSxRQUN6QkMsZUFBZTZDLFNBQVNuQixLQUFLMUI7QUFBQUEsUUFDN0JPLFlBQVlzQyxTQUFTbkIsS0FBS25CO0FBQUFBLFFBQzFCTixZQUFZNEMsU0FBU25CLE1BQU16QjtBQUFBQSxRQUMzQkMsTUFBTTJDLFNBQVNuQixLQUFLeEI7QUFBQUEsTUFDdEIsQ0FBQztBQUNEL0MseUJBQW1CLElBQUk7QUFDdkJnQixnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkLFNBQVM0RSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTWMsb0JBQW9CQSxDQUFDOUUsTUFBTTtBQUMvQixVQUFNLEVBQUV1RCxNQUFNckQsTUFBTSxJQUFJRixFQUFFQztBQUMxQnNCLHNCQUFrQixDQUFDd0QsY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ3hCLElBQUksR0FBR3JEO0FBQUFBLElBQ1YsRUFBRTtBQUNGZCxjQUFVLENBQUM0RixnQkFBZ0IsRUFBRSxHQUFHQSxZQUFZLENBQUN6QixJQUFJLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDM0Q7QUFFQSxRQUFNMEIsb0JBQW9CLFlBQVk7QUFDcEMsUUFBSTVHLGNBQWM7QUFDaEIsVUFBSTtBQUNGLGNBQU10QixJQUFJbUksT0FBTyxxQkFBcUI3RyxhQUFhaUYsR0FBRyxFQUFFO0FBQ3hEcEYsMkJBQW1CLEtBQUs7QUFDeEJJLHdCQUFnQixJQUFJO0FBRXBCOEIsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILFNBQVN5RCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLE1BQzdDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUIsZUFBZSxPQUFPbkYsTUFBTTtBQUNoQ0EsTUFBRW9GLGVBQWU7QUFDakIsVUFBTUMsVUFBVTVDLGFBQWE7QUFFN0IsUUFBSTtBQUNGLFVBQUk0QyxTQUFTO0FBQ1gsY0FBTXRJLElBQUl1STtBQUFBQSxVQUNSLHFCQUFxQi9HLG1CQUFtQitFLEdBQUc7QUFBQSxVQUMzQ2hDO0FBQUFBLFFBQ0Y7QUFDQWxELDJCQUFtQixLQUFLO0FBQ3hCZ0MsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTeUQsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLFFBQU11QixVQUFVO0FBQUEsSUFDZCxFQUFFQyxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssUUFBUUMsUUFBUSxZQUFZO0FBQUEsSUFDbkMsRUFBRUQsS0FBSyxTQUFTQyxRQUFRLG9CQUFvQjtBQUFBLElBQzVDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxrQkFBa0I7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUVELEtBQUssWUFBWUMsUUFBUSxhQUFhO0FBQUEsSUFDeEMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLG1CQUFtQjtBQUFBLElBQy9DLEVBQUVELEtBQUssY0FBY0MsUUFBUSx1QkFBdUI7QUFBQSxJQUNwRCxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxtQkFBbUI7QUFBQSxJQUNwRCxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQzdJLFlBQVUsTUFBTTtBQUNkLFVBQU04SSxhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGLGNBQU01QixXQUFXLE1BQU0vRyxJQUFJZ0gsSUFBSSxnQkFBZ0I7QUFDL0MvRSxpQkFBUzhFLFNBQVNuQixJQUFJO0FBQUEsTUFDeEIsU0FBU3FCLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBQ0EwQixlQUFXO0FBQUEsRUFDYixHQUFHLEVBQUU7QUFFTDlJLFlBQVUsTUFBTTtBQUNkLFVBQU0rSSxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU03QixXQUFXLE1BQU0vRyxJQUFJZ0gsSUFBSSxrQkFBa0I7QUFDakQ3RSxrQkFBVTRFLFNBQVNuQixJQUFJO0FBQUEsTUFDekIsU0FBU3FCLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0EyQixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBdUZML0k7QUFBQUEsSUFBVSxNQUFNO0FBQ2QsWUFBTWdKLG9CQUFvQixZQUFZO0FBQ3BDbEgsa0JBQVUsSUFBSTtBQUNkLFlBQUk7QUFDRnVGLGtCQUFRNEIsS0FBSyxZQUFZNUQsa0JBQWtCRSxjQUFjO0FBRXpELGdCQUFNMkIsV0FBVyxNQUFNL0csSUFBSWdILElBQUksZ0NBQWdDO0FBQUEsWUFDN0QrQixRQUFRO0FBQUEsY0FDTkMsV0FBVzlEO0FBQUFBLGNBQ1grRCxTQUFTN0Q7QUFBQUEsY0FDVDhELGtCQUFrQjVEO0FBQUFBLGNBQ2xCdEIsVUFBVXBDO0FBQUFBLGNBQ1Z3QyxNQUFNb0I7QUFBQUEsWUFDUjtBQUFBLFVBQ0YsQ0FBQztBQUVELGdCQUFNMkQsVUFBVXBDLFNBQVNuQjtBQUV6QixnQkFBTXdELGdCQUFnQjtBQUFBLFlBQ3BCLEdBQUcsSUFBSWhEO0FBQUFBLGNBQ0wrQyxRQUNHRSxJQUFJLENBQUMvQyxTQUFTO0FBQ2Isc0JBQU1nRCxTQUNKaEQsS0FBS3JDLGNBQWMsYUFDZnFDLEtBQUtwQyxnQkFDTG9DLEtBQUtyQyxjQUFjLFVBQ25CcUMsS0FBSzdCLGFBQ0w7QUFDTixvQkFBSSxDQUFDNkUsVUFBVSxDQUFDQSxPQUFPL0MsSUFBSyxRQUFPO0FBRW5DLHVCQUFPO0FBQUEsa0JBQ0xHLElBQUk0QyxPQUFPL0M7QUFBQUEsa0JBQ1hDLE1BQU04QyxPQUFPQyxhQUFhRCxPQUFPOUMsUUFBUTtBQUFBLGdCQUMzQztBQUFBLGNBQ0YsQ0FBQyxFQUNBZSxPQUFPaUMsT0FBTyxFQUNkSCxJQUFJLENBQUNJLFNBQVMsQ0FBQ0EsS0FBSy9DLElBQUkrQyxJQUFJLENBQUM7QUFBQSxZQUNsQyxFQUFFNUMsT0FBTztBQUFBLFVBQUM7QUFHWmhFLCtCQUFxQnVHLGFBQWE7QUFFbEMsZ0JBQU1NLGdCQUFnQlAsUUFBUUUsSUFBSSxDQUFDN0IsT0FBT21DLFdBQVc7QUFBQSxZQUNuRHBELEtBQUtpQixNQUFNakI7QUFBQUEsWUFDWEcsSUFBSWlELFFBQVE7QUFBQSxZQUNabkQsTUFBTWdCLE1BQU0zRDtBQUFBQSxZQUNaK0YsT0FBT3BDLE1BQU0xRDtBQUFBQSxZQUNiK0YsWUFBWXJDLE1BQU16RDtBQUFBQSxZQUNsQkksWUFBWXFELE9BQU9yRDtBQUFBQSxZQUNuQkgsVUFBVXdELE9BQU94RCxVQUFVeUQ7QUFBQUEsWUFDM0IxQyxNQUFNeUMsT0FBT3NDLFdBQVdDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxZQUNwQzlGLFdBQVd1RCxNQUFNdkQsY0FBYyxVQUFVLGFBQWF1RCxNQUFNdkQ7QUFBQUEsWUFDNURHLE1BQU1vRCxPQUFPcEQ7QUFBQUEsWUFDYjRGLGdCQUNFeEMsTUFBTXZELGNBQWMsYUFDaEJ1RCxPQUFPdEQsZUFBZXFGLFlBQ3RCL0IsTUFBTXZELGNBQWMsVUFDcEJ1RCxPQUFPL0MsWUFBWStCLE9BQ25CO0FBQUEsWUFDTnlELFFBQ0UsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTTtBQUFBLGtCQUNKQyxPQUFPO0FBQUEsb0JBQ0w7QUFBQSxzQkFDRXpCLEtBQUs7QUFBQSxzQkFDTDlELE9BQ0U7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLFNBQVMsTUFBTWtELHNCQUFzQkwsTUFBTWpCLEdBQUc7QUFBQSwwQkFBRTtBQUFBO0FBQUEsd0JBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUVKO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRWtDLEtBQUs7QUFBQSxzQkFDTDlELE9BQ0U7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLFNBQVMsTUFBTWlELHNCQUFzQkosTUFBTWpCLEdBQUc7QUFBQSwwQkFBRTtBQUFBO0FBQUEsd0JBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUVKO0FBQUEsa0JBQUM7QUFBQSxnQkFFTDtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0I7QUFBQTtBQUFBLGNBN0JqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE4QkEsS0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQ0E7QUFBQSxVQUVKLEVBQUU7QUFFRnhGLHlCQUFlMkksYUFBYTtBQUFBLFFBQzlCLFNBQVNTLEtBQUs7QUFDWnBKLHlCQUFlLEVBQUU7QUFDakJtRyxrQkFBUUQsTUFBTSx3QkFBd0JrRCxJQUFJNUcsT0FBTztBQUFBLFFBQ25ELFVBQUM7QUFDQzVCLG9CQUFVLEtBQUs7QUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFFQWtILHdCQUFrQjtBQUFBLElBQ3BCO0FBQUEsSUFBRztBQUFBLE1BQ0QzRDtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBMUQ7QUFBQUEsTUFDQTREO0FBQUFBLElBQVk7QUFBQSxFQUNiO0FBRUQsUUFBTTRFLHFCQUFxQkEsQ0FBQ2pILFVBQVU7QUFFcENKLHFCQUFpQkksS0FBSztBQUN0QlosdUJBQW1CLEtBQUs7QUFFeEIsVUFBTThILFFBQVEsb0JBQUl4RixLQUFLO0FBQ3ZCLFVBQU15RixhQUFhQSxDQUFDdkYsU0FBU0EsS0FBS0MsbUJBQW1CLE9BQU87QUFFNUQsUUFBSTdCLFVBQVUsU0FBUztBQUNyQixZQUFNb0gsWUFBWUQsV0FBV0QsS0FBSztBQUNsQ2xGLDBCQUFvQm9GLFNBQVM7QUFDN0JsRix3QkFBa0JrRixTQUFTO0FBQUEsSUFDN0IsV0FBV3BILFVBQVUsYUFBYTtBQUNoQyxZQUFNcUgsWUFBWSxJQUFJM0YsS0FBS3dGLEtBQUs7QUFDaENHLGdCQUFVQyxRQUFRRCxVQUFVRSxRQUFRLElBQUksQ0FBQztBQUN6QyxZQUFNSCxZQUFZRCxXQUFXRSxTQUFTO0FBQ3RDckYsMEJBQW9Cb0YsU0FBUztBQUM3QmxGLHdCQUFrQmtGLFNBQVM7QUFBQSxJQUM3QixXQUFXcEgsVUFBVSxhQUFhO0FBQ2hDLFlBQU13SCxRQUFRLElBQUk5RixLQUFLd0YsTUFBTU8sWUFBWSxHQUFHUCxNQUFNUSxTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUlqRyxLQUFLd0YsTUFBTU8sWUFBWSxHQUFHUCxNQUFNUSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFMUYsMEJBQW9CbUYsV0FBV0ssS0FBSyxDQUFDO0FBQ3JDdEYsd0JBQWtCaUYsV0FBV1EsR0FBRyxDQUFDO0FBQUEsSUFDbkMsV0FBVzNILFVBQVUsYUFBYTtBQUNoQyxZQUFNd0gsUUFBUSxJQUFJOUYsS0FBS3dGLE1BQU1PLFlBQVksR0FBR1AsTUFBTVEsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNuRSxZQUFNQyxNQUFNLElBQUlqRyxLQUFLd0YsTUFBTU8sWUFBWSxHQUFHUCxNQUFNUSxTQUFTLEdBQUcsQ0FBQztBQUM3RDFGLDBCQUFvQm1GLFdBQVdLLEtBQUssQ0FBQztBQUNyQ3RGLHdCQUFrQmlGLFdBQVdRLEdBQUcsQ0FBQztBQUFBLElBQ25DLFdBQVczSCxVQUFVLFlBQVk7QUFDL0IsWUFBTXdILFFBQVEsSUFBSTlGLEtBQUt3RixNQUFNTyxZQUFZLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQU1FLE1BQU0sSUFBSWpHLEtBQUt3RixNQUFNTyxZQUFZLEdBQUcsSUFBSSxFQUFFO0FBQ2hEekYsMEJBQW9CbUYsV0FBV0ssS0FBSyxDQUFDO0FBQ3JDdEYsd0JBQWtCaUYsV0FBV1EsR0FBRyxDQUFDO0FBQUEsSUFDbkMsV0FBVzNILFVBQVUsVUFBVTtBQUM3QloseUJBQW1CLElBQUk7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFDQSxTQUNFLHVCQUFDLFNBQUksV0FBVSw0QkFDYixpQ0FBQyxTQUNDO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRWxCLHVCQUFDLFNBQUksV0FBVSxpQkFDZDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNYSxZQUFZSTtBQUFBQSxVQUNsQixXQUFXSixZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQTtBQUFBQSxRQUh2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHK0I7QUFBQSxNQUUvQix1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxzQkFBcUIsK0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Q7QUFBQSxRQUNsRCx1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFdBQU0sNkJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0I7QUFBQSxZQUNwQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLFVBQVU2RztBQUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osY0FBYyxDQUFDVyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUeEQsWUFBWSxFQUNaQyxTQUFTb0QsTUFBTXJELFlBQVksQ0FBQztBQUFBLGdCQUVqQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTzVFLGlCQUFpQnFJO0FBQUFBLGdCQUV2QnpHLG9CQUFVMkU7QUFBQUEsa0JBQUksQ0FBQytCLFNBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQStCLE9BQU9BLEtBQUtqSSxPQUN6Q2lJLGVBQUt6RyxTQURZeUcsS0FBS2pJLE9BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbUJBO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUNDYixtQkFDQyx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEscUNBQUMsV0FBTSx5QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBLGNBQ2hCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPNEM7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDakMsTUFBTWtDLG9CQUFvQmxDLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxrQkFDbkQsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTZGO0FBQUEsaUJBTi9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEscUNBQUMsV0FBTSx1QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjO0FBQUEsY0FDZDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2lDO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ25DLE1BQU1vQyxrQkFBa0JwQyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsa0JBQ2pELFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUk2RjtBQUFBLGlCQU4vRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxVQUVGLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsV0FBTSxxQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFZO0FBQUEsWUFhWjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLE9BQU92QjtBQUFBQSxnQkFDUCxVQUFVNkI7QUFBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLGNBQWMsQ0FBQ3NILE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1R4RCxZQUFZLEVBQ1pDLFNBQVNvRCxNQUFNckQsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQSxrQkFDMUI5RyxPQUFPeUk7QUFBQUEsb0JBQUksQ0FBQzdCLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1qQixLQUN6Q2lCLGdCQUFNQyxjQURXRCxNQUFNakIsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW9CQTtBQUFBLGVBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUNBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFdBQU0sZ0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUI7QUFBQSxZQWdCdkI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLHVCQUF1QjtBQUFBLGdCQUN2QixPQUFPakI7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDbkMsVUFBVW9DLDBCQUEwQnBDLEtBQUs7QUFBQSxnQkFDcEQsYUFBWTtBQUFBLGdCQUNaLGNBQWMsQ0FBQzRILE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1R4RCxZQUFZLEVBQ1pDLFNBQVNvRCxNQUFNckQsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQSxrQkFDMUI5RSxrQkFBa0J5RztBQUFBQSxvQkFBSSxDQUFDQyxXQUN0Qix1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsT0FBTzVDLElBQzFDNEMsaUJBQU85QyxRQURVOEMsT0FBTzVDLElBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFvQkE7QUFBQSxlQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNDQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxXQUFNLG9CQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVc7QUFBQSxZQWVYO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxPQUFPbEI7QUFBQUEsZ0JBQ1AsdUJBQXVCO0FBQUEsZ0JBQ3ZCLFVBQVUsQ0FBQ3JDLFVBQVVzQyxnQkFBZ0J0QyxLQUFLO0FBQUEsZ0JBQzFDLGFBQVk7QUFBQSxnQkFDWixjQUFjLENBQUM0SCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUeEQsWUFBWSxFQUNaQyxTQUFTb0QsTUFBTXJELFlBQVksQ0FBQztBQUFBLGdCQUVqQyxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCO0FBQUEsa0JBQzFCNUYsTUFDRXlGLE9BQU8sQ0FBQ2pCLFNBQVNBLE1BQU1sQyxJQUFJLEVBQzNCaUY7QUFBQUEsb0JBQUksQ0FBQy9DLFNBQ0osdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1sQyxNQUN6Q2tDLGVBQUtsQyxRQURZa0MsTUFBTUMsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBckJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXNCQTtBQUFBLGVBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUNBO0FBQUEsYUFqS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtLQSxLQW5LRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0tBLEtBcktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzS0E7QUFBQSxRQUNDN0UsU0FDQyx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsVUFBRztBQUFBLGFBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxlQUFlbUc7QUFBQUEsWUFDZixNQUFNdkgsYUFBYVEsYUFBYTBCLFVBQVU7QUFBQSxZQUMxQztBQUFBLFlBQ0EsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWtCO0FBQUE7QUFBQSxVQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLc0M7QUFBQSxRQUl4Qyx1QkFBQyxTQUFJLFdBQVUseUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFdBdkx2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0xBO0FBQUEsU0E5TEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStMRDtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdwQjtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QmdCLG9CQUFVLENBQUMsQ0FBQztBQUFBLFFBQ2Q7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsMkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVUrRixjQUFjLFlBQVUsTUFDNUQ7QUFBQSxtQ0FBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBTztBQUFBO0FBQUEsZ0JBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU83RCxlQUFlVjtBQUFBQSxrQkFDdEIsVUFBVWtFO0FBQUFBLGtCQUNWLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ3RILFVBQVU0SyxNQUFNO0FBQUE7QUFBQSxnQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUWlLO0FBQUEsY0FFaEtqSixPQUFPeUIsYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z6QixpQkFBT3lCLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPVSxlQUFlVDtBQUFBQSxvQkFDdEIsVUFBVWlFO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3RILFVBQVU0SyxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFpSztBQUFBLGdCQUVoS2pKLE9BQU8wQixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjFCLGlCQUFPMEIsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLGtCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFhQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLHVCQUF1QjtBQUFBLG9CQUN2QjtBQUFBLG9CQUNBLE1BQUs7QUFBQSxvQkFDTCxjQUFjLENBQUNpSCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSnZELFlBQVksRUFDWkMsU0FBU29ELE1BQU1yRCxZQUFZLENBQUM7QUFBQSxvQkFFakMsT0FBT25ELGdCQUFnQlIsbUJBQW1Cb0g7QUFBQUEsb0JBQzFDLFVBQVUsQ0FBQ2hJLFVBQ1RtSSxzQkFBc0IsbUJBQW1CbkksS0FBSztBQUFBLG9CQUcvQyxXQUFDLFlBQVksZUFBZSxFQUFFa0c7QUFBQUEsc0JBQUksQ0FBQ2tDLFVBQ2xDLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxNQUFNN0QsWUFBWSxHQUNqRDZELG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkFwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXFCQTtBQUFBLGdCQUNDbkosT0FBTzJCLG1CQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjNCLGlCQUFPMkIsbUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQThDQTtBQUFBLGlCQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxnQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQWdCQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUNnSCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU3ZELFlBQVksRUFBRUMsU0FBU29ELE1BQU1yRCxZQUFZLENBQUM7QUFBQSxrQkFFNUQsT0FBT25ELGdCQUFnQlAsWUFBWW1IO0FBQUFBLGtCQUNuQyxVQUFVLENBQUNoSSxVQUFVbUksc0JBQXNCLFlBQVluSSxLQUFLO0FBQUEsa0JBRTNEdkMsaUJBQU95STtBQUFBQSxvQkFBSSxDQUFDN0IsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTWpCLEtBQ3pDaUIsZ0JBQU1DLGNBRFdELE1BQU1qQixLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQkE7QUFBQSxpQkF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3Q0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsZ0JBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FlQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUN3RSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU3ZELFlBQVksRUFBRUMsU0FBU29ELE1BQU1yRCxZQUFZLENBQUM7QUFBQSxrQkFFNUQsT0FBT25ELGdCQUFnQk4sYUFBYWtIO0FBQUFBLGtCQUNwQyxVQUFVLENBQUNoSSxVQUNUbUksc0JBQXNCLGFBQWFuSSxLQUFLO0FBQUEsa0JBR3pDO0FBQUEsb0JBQ0M7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLGtCQUFRLEVBQ1JrRztBQUFBQSxvQkFBSSxDQUFDN0YsU0FDTCx1QkFBQyxPQUFPLFFBQVAsRUFBeUIsT0FBT0EsS0FBS2tFLFlBQVksR0FDL0NsRSxrQkFEaUJBLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXlCQTtBQUFBLGNBQ0NwQixPQUFPNkIsYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y3QixpQkFBTzZCLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWxESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9EQTtBQUFBLFlBQ0NNLGVBQWVOLGNBQWMsY0FDNUIsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxnQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQWdCQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQ3hELFVBQVU0SyxNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDTixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUeEQsWUFBWSxFQUNaQyxTQUFTb0QsTUFBTXJELFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPbkQsZ0JBQWdCTCxpQkFBaUJpSDtBQUFBQSxrQkFDeEMsVUFBVSxDQUFDaEksVUFDVG1JLHNCQUFzQixpQkFBaUJuSSxLQUFLO0FBQUEsa0JBRzdDbkIsZ0JBQU1xSDtBQUFBQSxvQkFBSSxDQUFDbUMsU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS2pGLEtBQ3ZDaUYsZUFBS2pDLGFBRFlpQyxLQUFLakYsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBc0JBO0FBQUEsY0FDQ25FLE9BQU84QixpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y5QixpQkFBTzhCLGlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFoREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrREEsS0FuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvREE7QUFBQSxZQUNDO0FBQUEsWUFDSDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGNBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0ssZUFBZUg7QUFBQUEsZ0JBQ3RCLFVBQVUyRDtBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUN0SCxVQUFVNEssTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUWlLO0FBQUEsWUFFakssdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxnQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQWFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ04sT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVN2RCxZQUFZLEVBQUVDLFNBQVNvRCxNQUFNckQsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU9uRCxnQkFBZ0JKLGNBQWNnSDtBQUFBQSxrQkFDckMsVUFBVSxDQUFDaEksVUFDVG1JLHNCQUFzQixjQUFjbkksS0FBSztBQUFBLGtCQUcxQyxXQUFDLFdBQVcsWUFBWSxFQUFFa0c7QUFBQUEsb0JBQUksQ0FBQzdGLFNBQzlCLHVCQUFDLE9BQU8sUUFBUCxFQUF5QixPQUFPQSxLQUFLa0UsWUFBWSxHQUMvQ2xFLGtCQURpQkEsTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUJBO0FBQUEsY0FDQ3BCLE9BQU8rQixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVi9CLGlCQUFPK0IsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNENBO0FBQUEsWUFDQ0ksZUFBZU4sY0FBYyxXQUM1QixtQ0FDRSxpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLGdCQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLElBQUc7QUFBQSxrQkFDSCxPQUFPTSxlQUFlRTtBQUFBQSxrQkFDdEIsVUFBVXNEO0FBQUFBLGtCQUNWO0FBQUEsa0JBQ0EsV0FBVyxxQ0FBcUN0SCxVQUFVNEssTUFBTTtBQUFBLGtCQUVoRTtBQUFBLDJDQUFDLFlBQU8sT0FBTSxJQUFHLDRCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QjtBQUFBLG9CQUM1Qm5KLE9BQU9tSDtBQUFBQSxzQkFBSSxDQUFDb0MsVUFDWCx1QkFBQyxZQUF1QixPQUFPQSxNQUFNbEYsS0FDbENrRixnQkFBTWpGLFFBRElpRixNQUFNbEYsS0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWNBO0FBQUEsY0FDQ25FLE9BQU9xQyxjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnJDLGlCQUFPcUMsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsWUFFRix1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUMrRjtBQUFBO0FBQUEsY0FIM0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUExVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyVkE7QUFBQSxhQWhXRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaVdBO0FBQUE7QUFBQSxNQXhXRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF5V0E7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXdkQ7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNkJBQW1CLEtBQUs7QUFDeEJJLDBCQUFnQixJQUFJO0FBQUEsUUFDdEI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsMkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDRCxnQkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsVUFBVSxDQUFDMkIsTUFBTTtBQUNmQSxrQkFBRW9GLGVBQWU7QUFDakJILGtDQUFrQjtBQUFBLGNBQ3BCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFXO0FBQUE7QUFBQSx3QkFFTjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYjVHLHVCQUFhdUMsYUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUFRO0FBQUEsd0JBQUk7QUFBQTtBQUFBO0FBQUEsb0JBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxhQUFZO0FBQUEsc0JBQ1o7QUFBQSxzQkFDQSxXQUFXLHFDQUFxQ3BELFVBQVU0SyxNQUFNO0FBQUE7QUFBQSxvQkFMbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtpSztBQUFBLHFCQWhCbks7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQkE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUMyRjtBQUFBO0FBQUEsa0JBSHZHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBO0FBQUE7QUFBQSxZQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQ0E7QUFBQSxhQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0NBO0FBQUE7QUFBQSxNQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnREE7QUFBQSxPQWhtQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWltQkEsS0FsbUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtbUJBO0FBRUo7QUFBRTFLLEdBcG1DSUQsWUFBVTtBQUFBZ0wsS0FBVmhMO0FBc21DTixlQUFlQTtBQUFXLElBQUFnTDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIkN1c3RvbUFsZXJ0IiwiSW9NZE1vcmUiLCJDaXJjdWxhckxvYWRlciIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiZmllbGRTaXplIiwiTGVhZFJlcG9ydCIsIl9zIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiVGFibGVHcm91cHMiLCJzZXRUYWJsZUdyb3VwcyIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudEdyb3VwIiwic2V0Q3VycmVudEdyb3VwIiwiY3VycmVudFVwZGF0ZUdyb3VwIiwic2V0Q3VycmVudFVwZGF0ZUdyb3VwIiwibG9hZGVyIiwic2V0TG9hZGVyIiwic2VsZWN0ZWRHcm91cCIsInNldFNlbGVjdGVkR3JvdXAiLCJsZWFkcyIsInNldExlYWRzIiwidXNlcnMiLCJzZXRVc2VycyIsImFnZW50cyIsInNldEFnZW50cyIsImVycm9ycyIsInNldEVycm9ycyIsInNob3dGaWx0ZXJGaWVsZCIsInNldFNob3dGaWx0ZXJGaWVsZCIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiZmlsdGVyZWRMZWFkcyIsInNldEZpbHRlcmVkTGVhZHMiLCJsZWFkU291cmNlT3B0aW9ucyIsInNldExlYWRTb3VyY2VPcHRpb25zIiwic2VsZWN0ZWRMYWJlbCIsInNldFNlbGVjdGVkTGFiZWwiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiaGFuZGxlR3JvdXBDaGFuZ2UiLCJncm91cElkIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImxlYWRfbmFtZSIsImxlYWRfcGhvbmUiLCJsZWFkX3Byb2Zlc3Npb24iLCJncm91cF9pZCIsImxlYWRfdHlwZSIsImxlYWRfY3VzdG9tZXIiLCJsZWFkX25lZWRzIiwibm90ZSIsInNob3dDb250ZXh0TWVudSIsInNldFNob3dDb250ZXh0TWVudSIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJsZWFkX2FnZW50IiwiZ3JvdXBUaW1lIiwibGFiZWwiLCJub3ciLCJEYXRlIiwiZm9ybWF0VG9kYXkiLCJkYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZm9ybWF0U3RyaW5nIiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZFRvRGF0ZSIsInNldFNlbGVjdGVkVG9EYXRlIiwic2VsZWN0ZWRMZWFkU291cmNlTmFtZSIsInNldFNlbGVjdGVkTGVhZFNvdXJjZU5hbWUiLCJzZWxlY3RlZE5vdGUiLCJzZXRTZWxlY3RlZE5vdGUiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJkYXRhIiwidHJpbSIsInRlc3QiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwidW5pcXVlTGVhZFNvdXJjZXMiLCJzb3VyY2VNYXAiLCJNYXAiLCJmb3JFYWNoIiwibGVhZCIsIl9pZCIsIm5hbWUiLCJzZXQiLCJpZCIsIkFycmF5IiwiZnJvbSIsInZhbHVlcyIsImZldGNoR3JvdXBzIiwicmVzcG9uc2UiLCJnZXQiLCJlcnJvciIsImNvbnNvbGUiLCJvbkNvbnRleHRNZW51UHJlc3NlZCIsInByZXYiLCJsb2ciLCJmaWx0ZXJlZEdyb3VwcyIsImZpbHRlciIsImdyb3VwIiwiZ3JvdXBfbmFtZSIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJncm91cERhdGEiLCJoYW5kbGVJbnB1dENoYW5nZSIsInByZXZEYXRhIiwicHJldkVycm9ycyIsImhhbmRsZURlbGV0ZUdyb3VwIiwiZGVsZXRlIiwiaGFuZGxlVXBkYXRlIiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwicHV0IiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsImZldGNoVXNlcnMiLCJmZXRjaEFnZW50cyIsImZldGNoRmlsdGVyZWRMZWFkIiwiaW5mbyIsInBhcmFtcyIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJsZWFkX3NvdXJjZV9uYW1lIiwicmF3RGF0YSIsInVuaXF1ZVNvdXJjZXMiLCJtYXAiLCJzb3VyY2UiLCJmdWxsX25hbWUiLCJCb29sZWFuIiwiaXRlbSIsImZvcm1hdHRlZERhdGEiLCJpbmRleCIsInBob25lIiwicHJvZmVzc2lvbiIsImNyZWF0ZWRBdCIsInNwbGl0IiwibGVhZF90eXBlX25hbWUiLCJhY3Rpb24iLCJpdGVtcyIsImVyciIsImhhbmRsZVNlbGVjdEZpbHRlciIsInRvZGF5IiwiZm9ybWF0RGF0ZSIsImZvcm1hdHRlZCIsInllc3RlcmRheSIsInNldERhdGUiLCJnZXREYXRlIiwic3RhcnQiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZW5kIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidW5kZWZpbmVkIiwidGltZSIsImhlaWdodCIsImhhbmRsZUFudElucHV0RFNlbGVjdCIsImxQcm9mIiwidXNlciIsImFnZW50IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGVhZFJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5jb25zdCBMZWFkUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlR3JvdXBzLCBzZXRUYWJsZUdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50R3JvdXAsIHNldEN1cnJlbnRHcm91cF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xvYWRlciwgc2V0TG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cCwgc2V0U2VsZWN0ZWRHcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbGVhZHMsIHNldExlYWRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3Nob3dGaWx0ZXJGaWVsZCwgc2V0U2hvd0ZpbHRlckZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZmlsdGVyZWRMZWFkcywgc2V0RmlsdGVyZWRMZWFkc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xlYWRTb3VyY2VPcHRpb25zLCBzZXRMZWFkU291cmNlT3B0aW9uc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkTGFiZWwsc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIlRvZGF5XCIpXHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICBjb25zdCBoYW5kbGVHcm91cENoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICAvL2NvbnN0IGdyb3VwSWQgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwKGdyb3VwSWQpO1xyXG4gIH07XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBsZWFkX25hbWU6IFwiXCIsXHJcbiAgICBsZWFkX3Bob25lOiBcIlwiLFxyXG4gICAgbGVhZF9wcm9mZXNzaW9uOiBcIlwiLFxyXG4gICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbiAgICBsZWFkX3R5cGU6IFwiXCIsXHJcbiAgICBsZWFkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgbGVhZF9uZWVkczogXCJcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3Nob3dDb250ZXh0TWVudSwgc2V0U2hvd0NvbnRleHRNZW51XSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGxlYWRfbmFtZTogXCJcIixcclxuICAgIGxlYWRfcGhvbmU6IFwiXCIsXHJcbiAgICBsZWFkX3Byb2Zlc3Npb246IFwiXCIsXHJcbiAgICBncm91cF9pZDogXCJcIixcclxuICAgIGxlYWRfdHlwZTogXCJcIixcclxuICAgIGxlYWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICBsZWFkX2FnZW50OiBcIlwiLFxyXG4gICAgbGVhZF9uZWVkczogXCJcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGdyb3VwVGltZSA9IFtcclxuICAgIHsgdmFsdWU6IFwiVG9kYXlcIiwgbGFiZWw6IFwiVG9kYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4gIF07XHJcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICBjb25zdCBmb3JtYXRUb2RheSA9IChkYXRlKSA9PiBub3cudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcbiAgY29uc3QgZm9ybWF0U3RyaW5nID0gZm9ybWF0VG9kYXkobm93KTtcclxuXHJcbiAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUoZm9ybWF0U3RyaW5nKTtcclxuICBjb25zdCBbc2VsZWN0ZWRUb0RhdGUsIHNldFNlbGVjdGVkVG9EYXRlXSA9IHVzZVN0YXRlKGZvcm1hdFN0cmluZyk7XHJcblxyXG4gIGNvbnN0IFtzZWxlY3RlZExlYWRTb3VyY2VOYW1lLCBzZXRTZWxlY3RlZExlYWRTb3VyY2VOYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZE5vdGUsIHNldFNlbGVjdGVkTm90ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkTGVhZFwiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuICAgIGlmICghZGF0YS5sZWFkX25hbWUudHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5sZWFkX25hbWUgPSBcIkxlYWQgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5sZWFkX3Bob25lKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5sZWFkX3Bob25lID0gXCJQaG9uZSBOdW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoIS9eWzYtOV1cXGR7OX0kLy50ZXN0KGRhdGEubGVhZF9waG9uZSkpIHtcclxuICAgICAgbmV3RXJyb3JzLmxlYWRfcGhvbmUgPSBcIkludmFsaWQgcGhvbmUgbnVtYmVyIChtdXN0IGJlIDEwIGRpZ2l0cylcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEubGVhZF9wcm9mZXNzaW9uKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5sZWFkX3Byb2Zlc3Npb24gPSBcIlByb2Zlc3Npb24gaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEubGVhZF90eXBlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5sZWFkX3R5cGUgPSBcIkxlYWQgU291cmNlIFR5cGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZGF0YS5sZWFkX3R5cGUgPT09IFwiY3VzdG9tZXJcIiAmJiAhZGF0YS5sZWFkX2N1c3RvbWVyKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5sZWFkX2N1c3RvbWVyID0gXCJDdXN0b21lciBzZWxlY3Rpb24gaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZGF0YS5sZWFkX3R5cGUgPT09IFwiYWdlbnRcIiAmJiAhZGF0YS5sZWFkX2FnZW50KSB7XHJcbiAgICAgIG5ld0Vycm9ycy5sZWFkX2FnZW50ID0gXCJBZ2VudCBzZWxlY3Rpb24gaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5sZWFkX25lZWRzLnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMubGVhZF9uZWVkcyA9IFwiTGVhZCBOZWVkcyBhbmQgR29hbHMgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCB1bmlxdWVMZWFkU291cmNlcyA9ICgpID0+IHtcclxuICAgIGNvbnN0IHNvdXJjZU1hcCA9IG5ldyBNYXAoKTtcclxuXHJcbiAgICBsZWFkcy5mb3JFYWNoKChsZWFkKSA9PiB7XHJcbiAgICAgIC8vIEFnZW50XHJcbiAgICAgIGlmIChsZWFkLmxlYWRfYWdlbnQ/Ll9pZCAmJiBsZWFkLmxlYWRfYWdlbnQ/Lm5hbWUpIHtcclxuICAgICAgICBzb3VyY2VNYXAuc2V0KGBhZ2VudC0ke2xlYWQubGVhZF9hZ2VudC5faWR9YCwge1xyXG4gICAgICAgICAgaWQ6IGxlYWQ/LmxlYWRfYWdlbnQ/Ll9pZCxcclxuICAgICAgICAgIG5hbWU6IGxlYWQ/LmxlYWRfYWdlbnQ/Lm5hbWUsXHJcbiAgICAgICAgICB0eXBlOiBcIkFnZW50XCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIGlmIChsZWFkLmxlYWRfY3VzdG9tZXI/Ll9pZCAmJiBsZWFkLmxlYWRfY3VzdG9tZXI/LmZ1bGxfbmFtZSkge1xyXG4gICAgICAvLyAgIHNvdXJjZU1hcC5zZXQoYGN1c3RvbWVyLSR7bGVhZD8ubGVhZF9jdXN0b21lcj8uX2lkfWAsIHtcclxuICAgICAgLy8gICAgIGlkOiBsZWFkPy5sZWFkX2N1c3RvbWVyPy5faWQsXHJcbiAgICAgIC8vICAgICBuYW1lOiBsZWFkPy5sZWFkX2N1c3RvbWVyPy5mdWxsX25hbWUsXHJcbiAgICAgIC8vICAgICB0eXBlOiBcIkN1c3RvbWVyXCIsXHJcbiAgICAgIC8vICAgfSk7XHJcbiAgICAgIC8vIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBBcnJheS5mcm9tKHNvdXJjZU1hcC52YWx1ZXMoKSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcblxyXG4gICAgICAgIHNldEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcbiAgY29uc3Qgb25Db250ZXh0TWVudVByZXNzZWQgPSAoaWQpID0+IHtcclxuICAgIHNldFNob3dDb250ZXh0TWVudSgocHJldikgPT4gKHsgLi4ucHJldiwgW2lkXTogdHJ1ZSB9KSk7XHJcbiAgICBjb25zb2xlLmxvZyhzaG93Q29udGV4dE1lbnUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkR3JvdXBzID0gZ3JvdXBzLmZpbHRlcigoZ3JvdXApID0+XHJcbiAgICBncm91cC5ncm91cF9uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKVxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9sZWFkL2dldC1sZWFkLWJ5LWlkLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbGVhZDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9sZWFkL2dldC1sZWFkLWJ5LWlkLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgY29uc3QgZ3JvdXBEYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgc2V0Q3VycmVudFVwZGF0ZUdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgbGVhZF9uYW1lOiByZXNwb25zZS5kYXRhLmxlYWRfbmFtZSxcclxuICAgICAgICBsZWFkX3Bob25lOiByZXNwb25zZS5kYXRhLmxlYWRfcGhvbmUsXHJcbiAgICAgICAgbGVhZF9wcm9mZXNzaW9uOiByZXNwb25zZS5kYXRhLmxlYWRfcHJvZmVzc2lvbixcclxuICAgICAgICBncm91cF9pZDogcmVzcG9uc2UuZGF0YS5ncm91cF9pZCxcclxuICAgICAgICBsZWFkX3R5cGU6IHJlc3BvbnNlLmRhdGEubGVhZF90eXBlLFxyXG4gICAgICAgIGxlYWRfY3VzdG9tZXI6IHJlc3BvbnNlLmRhdGEubGVhZF9jdXN0b21lcixcclxuICAgICAgICBsZWFkX2FnZW50OiByZXNwb25zZS5kYXRhLmxlYWRfYWdlbnQsXHJcbiAgICAgICAgbGVhZF9uZWVkczogcmVzcG9uc2UuZGF0YT8ubGVhZF9uZWVkcyxcclxuICAgICAgICBub3RlOiByZXNwb25zZS5kYXRhLm5vdGUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXA6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7IC4uLnByZXZFcnJvcnMsIFtuYW1lXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlR3JvdXAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudEdyb3VwKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL2xlYWQvZGVsZXRlLWxlYWQvJHtjdXJyZW50R3JvdXAuX2lkfWApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG5cclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJMZWFkIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgbGVhZDpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgICBgL2xlYWQvdXBkYXRlLWxlYWQvJHtjdXJyZW50VXBkYXRlR3JvdXAuX2lkfWAsXHJcbiAgICAgICAgICB1cGRhdGVGb3JtRGF0YVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJMZWFkIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGdyb3VwOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiTGVhZCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lXCIsIGhlYWRlcjogXCJMZWFkIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJwcm9mZXNzaW9uXCIsIGhlYWRlcjogXCJMZWFkIFByb2Zlc3Npb25cIiB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9pZFwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJsZWFkX3R5cGVcIiwgaGVhZGVyOiBcIkxlYWQgU291cmNlIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibGVhZF9uZWVkc1wiLCBoZWFkZXI6IFwiTGVhZCBOZWVkcyBBbmQgR29hbHNcIiB9LFxyXG4gICAgeyBrZXk6IFwibGVhZF90eXBlX25hbWVcIiwgaGVhZGVyOiBcIkxlYWQgU291cmNlIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwibm90ZVwiLCBoZWFkZXI6IFwiTm90ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hVc2VycygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXQtYWdlbnRcIik7XHJcbiAgICAgICAgc2V0QWdlbnRzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhZ2VudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEFnZW50cygpO1xyXG4gIH0sIFtdKTtcclxuICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gIC8vICAgY29uc3QgZmV0Y2hGaWx0ZXJlZExlYWQgPSBhc3luYyAoKSA9PiB7XHJcbiAgLy8gICAgIHNldExvYWRlcih0cnVlKTtcclxuICAvLyAgICAgdHJ5IHtcclxuICAvLyAgICAgICBjb25zb2xlLmluZm8oXCJmcm9tZGF0ZVwiLCBzZWxlY3RlZEZyb21EYXRlLCBzZWxlY3RlZFRvRGF0ZSk7XHJcbiAgLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2xlYWQtcmVwb3J0L2dldC1sZWFkLXJlcG9ydFwiLCB7XHJcbiAgLy8gICAgICAgICBwYXJhbXM6IHtcclxuICAvLyAgICAgICAgICAgZnJvbV9kYXRlOiBzZWxlY3RlZEZyb21EYXRlLFxyXG4gIC8vICAgICAgICAgICB0b19kYXRlOiBzZWxlY3RlZFRvRGF0ZSxcclxuICAvLyAgICAgICAgICAgbGVhZF9zb3VyY2VfbmFtZTogc2VsZWN0ZWRMZWFkU291cmNlTmFtZSxcclxuICAvLyAgICAgICAgICAgZ3JvdXBfaWQ6IHNlbGVjdGVkR3JvdXAsXHJcbiAgLy8gICAgICAgICAgIG5vdGU6IHNlbGVjdGVkTm90ZSxcclxuICAvLyAgICAgICAgIH0sXHJcbiAgLy8gICAgICAgfSk7XHJcbiAgLy8gICAgICAgc2V0TG9hZGVyKGZhbHNlKTtcclxuXHJcbiAgLy8gICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgLy8gICAgICAgICBfaWQ6IGdyb3VwLl9pZCxcclxuICAvLyAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgLy8gICAgICAgICBuYW1lOiBncm91cC5sZWFkX25hbWUsXHJcbiAgLy8gICAgICAgICBwaG9uZTogZ3JvdXAubGVhZF9waG9uZSxcclxuICAvLyAgICAgICAgIHByb2Zlc3Npb246IGdyb3VwLmxlYWRfcHJvZmVzc2lvbixcclxuICAvLyAgICAgICAgIGxlYWRfbmVlZHM6IGdyb3VwPy5sZWFkX25lZWRzLFxyXG4gIC8vICAgICAgICAgZ3JvdXBfaWQ6IGdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSxcclxuICAvLyAgICAgICAgIGRhdGU6IGdyb3VwPy5jcmVhdGVkQXQuc3BsaXQoXCJUXCIpWzBdLFxyXG4gIC8vICAgICAgICAgbGVhZF90eXBlOiBncm91cC5sZWFkX3R5cGUgPT09IFwiYWdlbnRcIiA/IFwiZW1wbG95ZWVcIiA6IGdyb3VwLmxlYWRfdHlwZSxcclxuICAvLyAgICAgICAgIG5vdGU6IGdyb3VwPy5ub3RlLFxyXG4gIC8vICAgICAgICAgbGVhZF90eXBlX25hbWU6XHJcbiAgLy8gICAgICAgICAgIGdyb3VwLmxlYWRfdHlwZSA9PT0gXCJjdXN0b21lclwiXHJcbiAgLy8gICAgICAgICAgICAgPyBncm91cD8ubGVhZF9jdXN0b21lcj8uZnVsbF9uYW1lXHJcbiAgLy8gICAgICAgICAgICAgOiBncm91cC5sZWFkX3R5cGUgPT09IFwiYWdlbnRcIlxyXG4gIC8vICAgICAgICAgICAgID8gZ3JvdXA/LmxlYWRfYWdlbnQ/Lm5hbWVcclxuICAvLyAgICAgICAgICAgICA6IFwiXCIsXHJcbiAgLy8gICAgICAgICBhY3Rpb246IChcclxuICAvLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yIHJlbGF0aXZlXCI+XHJcbiAgLy8gICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgLy8gICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgLy8gICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgLy8gICAgICAgICAgICAgICAgICAge1xyXG4gIC8vICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAvLyAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAvLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwLl9pZCl9XHJcbiAgLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuICAvLyAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gIC8vICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAvLyAgICAgICAgICAgICAgICAgICB9LFxyXG4gIC8vICAgICAgICAgICAgICAgICAgIHtcclxuICAvLyAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgLy8gICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gIC8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAvLyAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAvLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gIC8vICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gIC8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAvLyAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgLy8gICAgICAgICAgICAgICAgICAgfSxcclxuICAvLyAgICAgICAgICAgICAgICAgXSxcclxuICAvLyAgICAgICAgICAgICAgIH19XHJcbiAgLy8gICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAvLyAgICAgICAgICAgICA+XHJcbiAgLy8gICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAvLyAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gIC8vICAgICAgICAgICA8L2Rpdj5cclxuICAvLyAgICAgICAgICksXHJcbiAgLy8gICAgICAgfSkpO1xyXG4gIC8vICAgICAgIHNldFRhYmxlR3JvdXBzKGZvcm1hdHRlZERhdGEpO1xyXG4gIC8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAvLyAgICAgICBzZXRUYWJsZUdyb3VwcyhbXSk7XHJcbiAgLy8gICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBEYXRhXCIsIGVyci5tZXNzYWdlKTtcclxuICAvLyAgICAgfSBmaW5hbGx5IHtcclxuICAvLyAgICAgICBzZXRMb2FkZXIoZmFsc2UpO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9O1xyXG5cclxuICAvLyAgIGZldGNoRmlsdGVyZWRMZWFkKCk7XHJcbiAgLy8gfSwgW1xyXG4gIC8vICAgc2VsZWN0ZWRGcm9tRGF0ZSxcclxuICAvLyAgIHNlbGVjdGVkVG9EYXRlLFxyXG4gIC8vICAgc2VsZWN0ZWRMZWFkU291cmNlTmFtZSxcclxuICAvLyAgIHNlbGVjdGVkR3JvdXAsXHJcbiAgLy8gICBzZWxlY3RlZE5vdGUsXHJcbiAgLy8gXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRmlsdGVyZWRMZWFkID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRMb2FkZXIodHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKFwiZnJvbWRhdGVcIiwgc2VsZWN0ZWRGcm9tRGF0ZSwgc2VsZWN0ZWRUb0RhdGUpO1xyXG5cclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvbGVhZC1yZXBvcnQvZ2V0LWxlYWQtcmVwb3J0XCIsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICBmcm9tX2RhdGU6IHNlbGVjdGVkRnJvbURhdGUsXHJcbiAgICAgICAgICAgIHRvX2RhdGU6IHNlbGVjdGVkVG9EYXRlLFxyXG4gICAgICAgICAgICBsZWFkX3NvdXJjZV9uYW1lOiBzZWxlY3RlZExlYWRTb3VyY2VOYW1lLFxyXG4gICAgICAgICAgICBncm91cF9pZDogc2VsZWN0ZWRHcm91cCxcclxuICAgICAgICAgICAgbm90ZTogc2VsZWN0ZWROb3RlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgcmF3RGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcblxyXG4gICAgICAgIGNvbnN0IHVuaXF1ZVNvdXJjZXMgPSBbXHJcbiAgICAgICAgICAuLi5uZXcgTWFwKFxyXG4gICAgICAgICAgICByYXdEYXRhXHJcbiAgICAgICAgICAgICAgLm1hcCgobGVhZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgc291cmNlID1cclxuICAgICAgICAgICAgICAgICAgbGVhZC5sZWFkX3R5cGUgPT09IFwiY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgID8gbGVhZC5sZWFkX2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgOiBsZWFkLmxlYWRfdHlwZSA9PT0gXCJhZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBsZWFkLmxlYWRfYWdlbnRcclxuICAgICAgICAgICAgICAgICAgICA6IG51bGw7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXNvdXJjZSB8fCAhc291cmNlLl9pZCkgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgaWQ6IHNvdXJjZS5faWQsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU6IHNvdXJjZS5mdWxsX25hbWUgfHwgc291cmNlLm5hbWUgfHwgXCJVbm5hbWVkXCIsXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKVxyXG4gICAgICAgICAgICAgIC5tYXAoKGl0ZW0pID0+IFtpdGVtLmlkLCBpdGVtXSlcclxuICAgICAgICAgICkudmFsdWVzKCksXHJcbiAgICAgICAgXTtcclxuXHJcbiAgICAgICAgc2V0TGVhZFNvdXJjZU9wdGlvbnModW5pcXVlU291cmNlcyk7XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByYXdEYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgbmFtZTogZ3JvdXAubGVhZF9uYW1lLFxyXG4gICAgICAgICAgcGhvbmU6IGdyb3VwLmxlYWRfcGhvbmUsXHJcbiAgICAgICAgICBwcm9mZXNzaW9uOiBncm91cC5sZWFkX3Byb2Zlc3Npb24sXHJcbiAgICAgICAgICBsZWFkX25lZWRzOiBncm91cD8ubGVhZF9uZWVkcyxcclxuICAgICAgICAgIGdyb3VwX2lkOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICBkYXRlOiBncm91cD8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgICBsZWFkX3R5cGU6IGdyb3VwLmxlYWRfdHlwZSA9PT0gXCJhZ2VudFwiID8gXCJlbXBsb3llZVwiIDogZ3JvdXAubGVhZF90eXBlLFxyXG4gICAgICAgICAgbm90ZTogZ3JvdXA/Lm5vdGUsXHJcbiAgICAgICAgICBsZWFkX3R5cGVfbmFtZTpcclxuICAgICAgICAgICAgZ3JvdXAubGVhZF90eXBlID09PSBcImN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICA/IGdyb3VwPy5sZWFkX2N1c3RvbWVyPy5mdWxsX25hbWVcclxuICAgICAgICAgICAgICA6IGdyb3VwLmxlYWRfdHlwZSA9PT0gXCJhZ2VudFwiXHJcbiAgICAgICAgICAgICAgPyBncm91cD8ubGVhZF9hZ2VudD8ubmFtZVxyXG4gICAgICAgICAgICAgIDogXCJcIixcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTIgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIHNldFRhYmxlR3JvdXBzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBzZXRUYWJsZUdyb3VwcyhbXSk7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBEYXRhXCIsIGVyci5tZXNzYWdlKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRMb2FkZXIoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoRmlsdGVyZWRMZWFkKCk7XHJcbiAgfSwgW1xyXG4gICAgc2VsZWN0ZWRGcm9tRGF0ZSxcclxuICAgIHNlbGVjdGVkVG9EYXRlLFxyXG4gICAgc2VsZWN0ZWRMZWFkU291cmNlTmFtZSxcclxuICAgIHNlbGVjdGVkR3JvdXAsXHJcbiAgICBzZWxlY3RlZE5vdGUsXHJcbiAgXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgLy9jb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlbGVjdGVkTGFiZWwodmFsdWUpXHJcbiAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHllc3RlcmRheS5zZXREYXRlKHllc3RlcmRheS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAwLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMTEsIDMxKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuICAgIH1cclxuICB9O1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBvdmVyZmxvdy14LWhpZGRlblwiPlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIiBmbGV4LTEgbXQtMzBcIj5cclxuICAgICAgICAgIDxDdXN0b21BbGVydFxyXG4gICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC03XCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC0yeGxcIj5SZXBvcnRzIC0gTGVhZCA8L2gxPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktc3RhcnQgaXRlbXMtY2VudGVyIHctc2NyZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbD5GaWx0ZXIgT3B0aW9uPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNlbGVjdEZpbHRlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIE9yIFNlbGVjdCBGaWx0ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGFiZWwgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cFRpbWUubWFwKCh0aW1lKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dGltZS52YWx1ZX0gdmFsdWU9e3RpbWUudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0aW1lLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtzaG93RmlsdGVyRmllbGQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5Gcm9tIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LXhzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5UbyBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFRvRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkVG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LXhzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+R3JvdXA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC02IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGwgbWF4LXctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IEdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14cyBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkxlYWQgU291cmNlIE5hbWU8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGVhZFNvdXJjZU5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkTGVhZFNvdXJjZU5hbWUoZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNiBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bGVhZFNvdXJjZU9wdGlvbnMubWFwKChzb3VyY2UpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3NvdXJjZS5pZH0gdmFsdWU9e3NvdXJjZS5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NvdXJjZS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGVhZFNvdXJjZU5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRTZWxlY3RlZExlYWRTb3VyY2VOYW1lKHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIE9yIFNlbGVjdCBMZWFkIFNvdXJjZSBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14cyBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtsZWFkU291cmNlT3B0aW9ucy5tYXAoKHNvdXJjZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3NvdXJjZS5pZH0gdmFsdWU9e3NvdXJjZS5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NvdXJjZS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+Tm90ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZE5vdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkTm90ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNiBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bGVhZHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigobGVhZCkgPT4gbGVhZD8ubm90ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgLm1hcCgobGVhZCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtsZWFkPy5faWR9IHZhbHVlPXtsZWFkPy5ub3RlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsZWFkLm5vdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWROb3RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldFNlbGVjdGVkTm90ZSh2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBPciBTZWxlY3QgTm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bGVhZHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigobGVhZCkgPT4gbGVhZD8ubm90ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgLm1hcCgobGVhZCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bGVhZD8uX2lkfSB2YWx1ZT17bGVhZD8ubm90ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGVhZC5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7bG9hZGVyID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz47XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgdXBkYXRlSGFuZGxlcj17aGFuZGxlVXBkYXRlTW9kYWxPcGVufVxyXG4gICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlR3JvdXBzLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJMZWFkIFJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgTGVhZCBSZXBvcnQuY3N2YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy0zIGxnOmdyaWQtY29scy00IGdhcC04XCI+PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIFVwZGF0ZSBMZWFkXHJcbiAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBMZWFkIE5hbWVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmxlYWRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBHcm91cCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIExlYWQgUGhvbmUgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9waG9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmxlYWRfcGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBMZWFkIFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX3Bob25lICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfcGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBMZWFkIFdvcmsvUHJvZmVzc2lvblxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX3Byb2Zlc3Npb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5sZWFkX3Byb2Zlc3Npb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IFdvcmsvUHJvZmVzc2lvbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJlbXBsb3llZFwiPkVtcGxveWVkPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInNlbGZfZW1wbG95ZWRcIj5TZWxmIEVtcGxveWVkPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTGVhZCBXb3JrL1Byb2Zlc3Npb24gXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9wcm9mZXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmxlYWRfcHJvZmVzc2lvbiB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcImxlYWRfcHJvZmVzc2lvblwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7W1wiRW1wbG95ZWRcIiwgXCJTZWxmIEVtcGxveWVkXCJdLm1hcCgobFByb2YpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bFByb2Z9IHZhbHVlPXtsUHJvZi50b0xvd2VyQ2FzZSgpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xQcm9mfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX3Byb2Zlc3Npb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9wcm9mZXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBHcm91cFxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIHsvKiA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfaWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgR3JvdXA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwIFwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZ3JvdXBfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJncm91cF9pZFwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgTGVhZCBTb3VyY2UgVHlwZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIHsvKiA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBpZD1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmxlYWRfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBMZWFkIFNvdXJjZSBUeXBlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJzb2NpYWxcIj5Tb2NpYWwgTWVkaWE8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImN1c3RvbWVyXCI+Q3VzdG9tZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFnZW50XCI+RW1wbG95ZWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIndhbGtpblwiPldhbGtpbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+ICovfVxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggTGVhZCBTb3VyY2UgVHlwZSBcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5sZWFkX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcImxlYWRfdHlwZVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgIFwiU29jaWFsIE1lZGlhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiQWdlbnRcIixcclxuICAgICAgICAgICAgICAgICAgICBcIkVtcGxveWVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJXYWxraW5cIixcclxuICAgICAgICAgICAgICAgICAgXS5tYXAoKHR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3R5cGV9IHZhbHVlPXt0eXBlLnRvTG93ZXJDYXNlKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmxlYWRfdHlwZSA9PT0gXCJjdXN0b21lclwiICYmIChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX2N1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmxlYWRfY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBDdXN0b21lcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX2N1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ubGVhZF9jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJsZWFkX2N1c3RvbWVyXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9jdXN0b21lciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9jdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICl9e1wiIFwifVxyXG4gICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIE5vdGVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cIm5vdGVcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLm5vdGV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTcGVjaWZ5IG5vdGUgaWYgYW55IVwiXHJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgTGVhZCBOZWVkcyBhbmQgR29hbHNcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9uZWVkc1wiXHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEubGVhZF9uZWVkc31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBMZWFkIE5lZWRzIGFuZCBHb2Fsczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwic2F2aW5nc1wiPlNhdmluZ3M8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImJvcnJvd2luZ3NcIj5Cb3Jyb3dpbmdzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9yIFNlYXJjaCBMZWFkIE5lZWRzIGFuZCBHb2FscyBcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX25lZWRzXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ubGVhZF9uZWVkcyB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwibGVhZF9uZWVkc1wiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1wiU2F2aW5nc1wiLCBcIkJvcnJvd2luZ3NcIl0ubWFwKCh0eXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt0eXBlfSB2YWx1ZT17dHlwZS50b0xvd2VyQ2FzZSgpfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHt0eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9uZWVkcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfbmVlZHN9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmxlYWRfdHlwZSA9PT0gXCJhZ2VudFwiICYmIChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEFnZW50c1xyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfYWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEubGVhZF9hZ2VudH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEFnZW50PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2FnZW50Ll9pZH0gdmFsdWU9e2FnZW50Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX2FnZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX2FnZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIERlbGV0ZSBMZWFkXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50R3JvdXAgJiYgKFxyXG4gICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVHcm91cCgpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXAubGVhZF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBMZWFkIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXJlZC03MDAgaG92ZXI6YmctcmVkLTgwMFxyXG4gICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMZWFkUmVwb3J0OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9MZWFkUmVwb3J0LmpzeCJ9