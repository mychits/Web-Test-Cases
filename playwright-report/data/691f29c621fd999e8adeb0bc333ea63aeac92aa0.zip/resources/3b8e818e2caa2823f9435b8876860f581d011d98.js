import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AuctionBidStatus.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const AuctionBidStatus = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const [selectAll, setSelectAll] = useState(false);
  const [auctionData, setAuctionData] = useState([]);
  const groupOptions = [
    ...new Set(
      usersData.filter(
        (u) => u.groupName !== void 0 && u.groupName !== "" && u.groupName !== "   "
      ).map((u) => u.groupName)
    )
  ];
  const filteredUsers = useMemo(() => {
    const filtered = filterOption(
      usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
        const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
        return matchGroup && matchFromDate && matchToDate;
      }),
      searchText
    );
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    userPhone: user.userPhone,
                    groupName: user.groupName,
                    userName: user.userName,
                    groupMembers: user.groupMembers,
                    groupId: user.groupId?._id
                    // userId: user.userId,
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
            lineNumber: 61,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, searchText, activeUserData]);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp..",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/whatsapp/auction-bid-status", {
        receivers: visibleActiveUsers
      });
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete newActiveUserData[user._id];
        }
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Has Been Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  useEffect(() => {
    const allChecked = filteredUsers.length > 0 && filteredUsers.every((user) => activeUserData[user._id]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredUsers, activeUserData]);
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/auction/get-auction");
      const usersList = [];
      const tempActive = {};
      const data = reportResponse.data?.auction.map((auction, index) => {
        const id = auction._id;
        const groupId = auction?.group_id;
        const userName = auction?.user_id?.full_name;
        const userPhone = auction?.user_id?.phone_number;
        const groupMembers = auction?.group_id?.group_members;
        const groupName = auction?.group_id?.group_name;
        tempActive[id] = {
          info: {
            status: false
          }
        };
        const tempUsr = {
          _id: id,
          userName,
          userPhone,
          groupMembers,
          groupName,
          groupId,
          enrollmentDate: auction?.group_id?.createdAt
        };
        usersList.push(tempUsr);
        return {
          slNo: index + 1,
          groupName,
          userName,
          userPhone,
          groupId,
          groupMembers
        };
      });
      console.info(data, "jkgnsdkgjsbng");
      setAuctionData(data);
      setUsersData(usersList);
      setActiveUserData(tempActive);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "checkBoxs", header: "Select User" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    // { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" }
    //  {key: "paymentsTicket", header: "Ticket"},
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
        lineNumber: 216,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
      lineNumber: 220,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
        lineNumber: 223,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Auction Bid Status" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
        lineNumber: 224,
        columnNumber: 13
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
          lineNumber: 232,
          columnNumber: 15
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
          lineNumber: 235,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
          lineNumber: 234,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                  lineNumber: 242,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                  lineNumber: 243,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                lineNumber: 241,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                lineNumber: 247,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
              lineNumber: 240,
              columnNumber: 3
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                  lineNumber: 252,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                  lineNumber: 253,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                lineNumber: 251,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                lineNumber: 257,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
              lineNumber: 250,
              columnNumber: 3
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
            lineNumber: 239,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Select Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                lineNumber: 262,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  style: { width: 200 },
                  allowClear: true,
                  placeholder: "--All groups--",
                  onChange: (value) => setGroupFilter(value),
                  value: groupFilter || void 0,
                  className: "w-full max-w-xs h-11 ",
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                      lineNumber: 274,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                  lineNumber: 265,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
              lineNumber: 261,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-5", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                lineNumber: 282,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  className: "ml-4 w-4 h-4 mb-3",
                  checked: selectAll,
                  onChange: (e) => {
                    const checked = e.target.checked;
                    setSelectAll(checked);
                    const updatedData = { ...activeUserData };
                    filteredUsers.forEach((user) => {
                      updatedData[user._id] = {
                        info: {
                          status: checked,
                          userPhone: user.userPhone,
                          groupName: user.groupName,
                          userName: user.userName,
                          groupMembers: user.groupMembers,
                          groupId: user.groupId?._id
                        }
                      };
                    });
                    setActiveUserData(updatedData);
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                  lineNumber: 285,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
              lineNumber: 281,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
            lineNumber: 260,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                      lineNumber: 324,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                    lineNumber: 320,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
                  lineNumber: 327,
                  columnNumber: 21
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
              lineNumber: 315,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
            lineNumber: 314,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Auction Bid Status",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Auction Bid Status.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
              lineNumber: 331,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
          lineNumber: 238,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
        lineNumber: 231,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
      lineNumber: 222,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
    lineNumber: 215,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx",
    lineNumber: 214,
    columnNumber: 5
  }, this);
};
_s(AuctionBidStatus, "dnqT5GpkUh6a2lVfloJw0nfr/G0=", false, function() {
  return [notification.useNotification];
});
_c = AuctionBidStatus;
export default AuctionBidStatus;
var _c;
$RefreshReg$(_c, "AuctionBidStatus");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionBidStatus.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNERVOzJCQTVEVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFHdkIsTUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlqQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDa0IsV0FBV0MsWUFBWSxJQUFJbkIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ29CLGFBQWFDLGNBQWMsSUFBSXJCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNzQixVQUFVQyxXQUFXLElBQUl2QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDd0IsUUFBUUMsU0FBUyxJQUFJekIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzBCLGdCQUFnQkMsaUJBQWlCLElBQUkzQixTQUFTLENBQUMsQ0FBQztBQUN2RCxRQUFNLENBQUM0QixXQUFXQyxZQUFZLElBQUk3QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDOEIsWUFBWUMsYUFBYSxJQUFJL0IsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ2dDLFVBQVVDLGFBQWEsSUFBSXhCLGFBQWF5QixnQkFBZ0I7QUFDL0QsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlwQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDcUMsYUFBYUMsY0FBYyxJQUFJdEMsU0FBUyxFQUFFO0FBRWpELFFBQU11QyxlQUFlO0FBQUEsSUFDbkIsR0FBRyxJQUFJQztBQUFBQSxNQUNMdEIsVUFDR3VCO0FBQUFBLFFBQ0MsQ0FBQ0MsTUFDQ0EsRUFBRUMsY0FBY0MsVUFDaEJGLEVBQUVDLGNBQWMsTUFDaEJELEVBQUVDLGNBQWM7QUFBQSxNQUNwQixFQUNDRSxJQUFJLENBQUNILE1BQU1BLEVBQUVDLFNBQVM7QUFBQSxJQUMzQjtBQUFBLEVBQUM7QUFFSCxRQUFNRyxnQkFBZ0I3QyxRQUFRLE1BQU07QUFDbEMsVUFBTThDLFdBQVd4QztBQUFBQSxNQUNmVyxVQUFVdUIsT0FBTyxDQUFDQyxNQUFNO0FBQ3RCLGNBQU1NLGFBQWE1QixjQUFjc0IsRUFBRUMsY0FBY3ZCLGNBQWM7QUFDL0QsY0FBTTZCLGlCQUFpQixJQUFJQyxLQUFLUixFQUFFTyxjQUFjO0FBQ2hELGNBQU1FLGdCQUFnQjdCLFdBQ2xCMkIsa0JBQWtCLElBQUlDLEtBQUs1QixRQUFRLElBQ25DO0FBQ0osY0FBTThCLGNBQWM1QixTQUFTeUIsa0JBQWtCLElBQUlDLEtBQUsxQixNQUFNLElBQUk7QUFDbEUsZUFBT3dCLGNBQWNHLGlCQUFpQkM7QUFBQUEsTUFDeEMsQ0FBQztBQUFBLE1BQ0RwQztBQUFBQSxJQUNGO0FBRUEsV0FBTytCLFNBQVNGLElBQUksQ0FBQ1EsTUFBTUMsVUFBVTtBQUNuQyxZQUFNQyxhQUFhLENBQUMsQ0FBQzdCLGVBQWUyQixLQUFLRyxHQUFHLEdBQUdDLE1BQU1DO0FBRXJELGFBQU87QUFBQSxRQUNMLEdBQUdMO0FBQUFBLFFBQ0hNLE9BQU9MLFFBQVE7QUFBQSxRQUNmTSxXQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTTDtBQUFBQSxZQUNULFVBQVUsQ0FBQ00sTUFBTTtBQUNmbEMsZ0NBQWtCLENBQUNtQyxVQUFVO0FBQUEsZ0JBQzNCLEdBQUdBO0FBQUFBLGdCQUNILENBQUNULEtBQUtHLEdBQUcsR0FBRztBQUFBLGtCQUNWQyxNQUFNO0FBQUEsb0JBQ0pDLFFBQVFHLEVBQUVFLE9BQU9DO0FBQUFBLG9CQUNqQkMsV0FBV1osS0FBS1k7QUFBQUEsb0JBQ2hCdEIsV0FBV1UsS0FBS1Y7QUFBQUEsb0JBQ2hCdUIsVUFBVWIsS0FBS2E7QUFBQUEsb0JBQ2ZDLGNBQWNkLEtBQUtjO0FBQUFBLG9CQUNuQkMsU0FBU2YsS0FBS2UsU0FBU1o7QUFBQUE7QUFBQUEsa0JBRXpCO0FBQUEsZ0JBQ0Y7QUFBQSxjQUNGLEVBQUU7QUFBQSxZQUNKO0FBQUE7QUFBQSxVQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFrQkk7QUFBQSxRQUdORDtBQUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNyQyxXQUFXRSxhQUFhRSxVQUFVRSxRQUFRUixZQUFZVSxjQUFjLENBQUM7QUFFekUsUUFBTTJDLHVCQUF1QnBFLFFBQVEsTUFBTTtBQUN6QyxXQUFPNkMsY0FBY0wsT0FBTyxDQUFDWSxTQUFTQSxLQUFLRSxVQUFVLEVBQUVlO0FBQUFBLEVBQ3pELEdBQUcsQ0FBQ3hCLGFBQWEsQ0FBQztBQUVsQixRQUFNeUIsZUFBZSxZQUFZO0FBQy9CLFVBQU1DLE1BQU07QUFDWixRQUFJO0FBQ0Z4QyxlQUFTeUMsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFFRCxZQUFNQyxxQkFBcUIsQ0FBQztBQUM1QmhDLG9CQUFjaUMsUUFBUSxDQUFDMUIsU0FBUztBQUM5QixZQUFJQSxLQUFLRSxjQUFjN0IsZUFBZTJCLEtBQUtHLEdBQUcsR0FBRztBQUMvQ3NCLDZCQUFtQnpCLEtBQUtHLEdBQUcsSUFBSTlCLGVBQWUyQixLQUFLRyxHQUFHO0FBQUEsUUFDeEQ7QUFBQSxNQUNGLENBQUM7QUFFRCxZQUFNdEQsSUFBSThFLEtBQUssZ0NBQWdDO0FBQUEsUUFDN0NDLFdBQVdIO0FBQUFBLE1BQ2IsQ0FBQztBQUVELFlBQU1JLG9CQUFvQixFQUFFLEdBQUd4RCxlQUFlO0FBQzlDb0Isb0JBQWNpQyxRQUFRLENBQUMxQixTQUFTO0FBQzlCLFlBQUlBLEtBQUtFLFlBQVk7QUFDbkIsaUJBQU8yQixrQkFBa0I3QixLQUFLRyxHQUFHO0FBQUEsUUFDbkM7QUFBQSxNQUNGLENBQUM7QUFDRDdCLHdCQUFrQnVELGlCQUFpQjtBQUVuQ2xELGVBQVN5QyxLQUFLO0FBQUEsUUFDWkQ7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RDLGFBQWE7QUFBQSxRQUNiQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsU0FBU00sS0FBSztBQUNabkQsZUFBU3lDLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYVEsSUFBSVQsV0FBVztBQUFBLFFBQzVCRSxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0E5RSxZQUFVLE1BQU07QUFFZCxVQUFNcUYsYUFDSnRDLGNBQWN3QixTQUFTLEtBQ3ZCeEIsY0FBY3VDLE1BQU0sQ0FBQ2hDLFNBQVMzQixlQUFlMkIsS0FBS0csR0FBRyxHQUFHQyxNQUFNQyxNQUFNO0FBQ3RFdEIsaUJBQWFnRCxVQUFVO0FBQUEsRUFDekIsR0FBRyxDQUFDdEMsZUFBZXBCLGNBQWMsQ0FBQztBQUVsQyxRQUFNNEQsWUFBWSxZQUFZO0FBQzVCLFFBQUk7QUFDRnpELG1CQUFhLElBQUk7QUFDakIsWUFBTTBELGlCQUFpQixNQUFNckYsSUFBSXNGLElBQUksc0JBQXNCO0FBRTNELFlBQU1DLFlBQVk7QUFDbEIsWUFBTUMsYUFBYSxDQUFDO0FBQ3BCLFlBQU1DLE9BQU9KLGVBQWVJLE1BQU1DLFFBQVEvQyxJQUFJLENBQUMrQyxTQUFTdEMsVUFBVTtBQUNoRSxjQUFNdUMsS0FBS0QsUUFBUXBDO0FBQ25CLGNBQU1ZLFVBQVV3QixTQUFTRTtBQUN6QixjQUFNNUIsV0FBVzBCLFNBQVNHLFNBQVNDO0FBQ25DLGNBQU0vQixZQUFZMkIsU0FBU0csU0FBU0U7QUFDcEMsY0FBTTlCLGVBQWV5QixTQUFTRSxVQUFVSTtBQUN4QyxjQUFNdkQsWUFBWWlELFNBQVNFLFVBQVVLO0FBRXJDVCxtQkFBV0csRUFBRSxJQUFJO0FBQUEsVUFDZnBDLE1BQU07QUFBQSxZQUNKQyxRQUFRO0FBQUEsVUFDVjtBQUFBLFFBQ0Y7QUFFQSxjQUFNMEMsVUFBVTtBQUFBLFVBQ2Q1QyxLQUFLcUM7QUFBQUEsVUFDTDNCO0FBQUFBLFVBQ0FEO0FBQUFBLFVBQ0FFO0FBQUFBLFVBQ0F4QjtBQUFBQSxVQUNBeUI7QUFBQUEsVUFDQW5CLGdCQUFnQjJDLFNBQVNFLFVBQVVPO0FBQUFBLFFBQ3JDO0FBQ0FaLGtCQUFVYSxLQUFLRixPQUFPO0FBRXRCLGVBQU87QUFBQSxVQUNMRyxNQUFNakQsUUFBUTtBQUFBLFVBQ2RYO0FBQUFBLFVBQ0F1QjtBQUFBQSxVQUNBRDtBQUFBQSxVQUNBRztBQUFBQSxVQUNBRDtBQUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQ0RxQyxjQUFRL0MsS0FBS2tDLE1BQU0sZUFBZTtBQUVsQ3JELHFCQUFlcUQsSUFBSTtBQUNuQnhFLG1CQUFhc0UsU0FBUztBQUN0QjlELHdCQUFrQitELFVBQVU7QUFBQSxJQUM5QixTQUFTZSxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0MsVUFBQztBQUNDNUUsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBOUIsWUFBVSxNQUFNO0FBQ2R1RixjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFFTCxRQUFNb0IsaUJBQWlCO0FBQUEsSUFDckIsRUFBRWxDLEtBQUssU0FBU21DLFFBQVEsU0FBUztBQUFBLElBQ2pDLEVBQUVuQyxLQUFLLGFBQWFtQyxRQUFRLGNBQWM7QUFBQSxJQUMxQyxFQUFFbkMsS0FBSyxZQUFZbUMsUUFBUSxnQkFBZ0I7QUFBQSxJQUMzQyxFQUFFbkMsS0FBSyxhQUFhbUMsUUFBUSxlQUFlO0FBQUE7QUFBQSxJQUUzQyxFQUFFbkMsS0FBSyxhQUFhbUMsUUFBUSxhQUFhO0FBQUE7QUFBQSxFQUN6QztBQUdGLFNBQ0QsdUJBQUMsU0FBSSxXQUFVLFVBQ1YsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsNkJBQTZCLENBQUM5QyxNQUFNNUMsY0FBYzRDLEVBQUVFLE9BQU82QyxLQUFLO0FBQUEsUUFDaEUsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBRU4sdUJBQUMsU0FBSSxXQUFVLGlCQUNWO0FBQUEsNkJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFDZCx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLGtDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUlDM0U7QUFBQUEsTUFDRCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFDaEVMLFlBQ04sdUJBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsa0JBQWUsT0FBTSxvQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFSSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtREFDN0I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Q7QUFBQSxnQkFDcEQsdUJBQUMsT0FBRSxXQUFVLHNDQUNWa0Isd0JBQWN3QixVQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsV0FBUSxXQUFVLDhCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBLGlCQVAvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUF3QixrQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxnQkFDdkQsdUJBQUMsT0FBRSxXQUFVLHFDQUNWRCxrQ0FESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsaUJBQWMsV0FBVSw2QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Q7QUFBQSxpQkFQcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBbkJjO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JoQjtBQUFBLFVBQ2dCLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPLEVBQUV3QyxPQUFPLElBQUk7QUFBQSxrQkFDcEI7QUFBQSxrQkFDQSxhQUFZO0FBQUEsa0JBQ1osVUFBVSxDQUFDRCxVQUFVdkYsZUFBZXVGLEtBQUs7QUFBQSxrQkFDekMsT0FBT3hGLGVBQWV3QjtBQUFBQSxrQkFDdEIsV0FBVTtBQUFBLGtCQUVUTCx1QkFBYU07QUFBQUEsb0JBQUksQ0FBQ2lFLFVBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsWUFFQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTM0U7QUFBQUEsa0JBQ1QsVUFBVSxDQUFDMEIsTUFBTTtBQUNmLDBCQUFNRyxVQUFVSCxFQUFFRSxPQUFPQztBQUN6QjVCLGlDQUFhNEIsT0FBTztBQUVwQiwwQkFBTStDLGNBQWMsRUFBRSxHQUFHckYsZUFBZTtBQUd4Q29CLGtDQUFjaUMsUUFBUSxDQUFDMUIsU0FBUztBQUM5QjBELGtDQUFZMUQsS0FBS0csR0FBRyxJQUFJO0FBQUEsd0JBQ3RCQyxNQUFNO0FBQUEsMEJBQ0pDLFFBQVFNO0FBQUFBLDBCQUNSQyxXQUFXWixLQUFLWTtBQUFBQSwwQkFDaEJ0QixXQUFXVSxLQUFLVjtBQUFBQSwwQkFDaEJ1QixVQUFVYixLQUFLYTtBQUFBQSwwQkFDZkMsY0FBY2QsS0FBS2M7QUFBQUEsMEJBQ25CQyxTQUFTZixLQUFLZSxTQUFTWjtBQUFBQSx3QkFDekI7QUFBQSxzQkFDRjtBQUFBLG9CQUNGLENBQUM7QUFFRDdCLHNDQUFrQm9GLFdBQVc7QUFBQSxrQkFDL0I7QUFBQTtBQUFBLGdCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F5Qkk7QUFBQSxpQkE3Qk47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQkE7QUFBQSxlQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFEQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTeEM7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVEY7QUFBQUEsdUNBQXVCLEtBQ3RCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPLGlDQUFpQ0Esb0JBQW9CO0FBQUEsb0JBRTVELGlDQUFDLFVBQU1BLGtDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRCO0FBQUE7QUFBQSxrQkFKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUYsdUJBQUMsY0FBVyxXQUFVLFFBQU8sTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBWjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNdkI7QUFBQUEsY0FDTixTQUFTNEQ7QUFBQUEsY0FDVCxTQUFRO0FBQUEsY0FDUixpQkFBZ0I7QUFBQSxjQUNoQixpQkFBaUIsQ0FBQyxZQUFZO0FBQUEsY0FDOUIsbUJBQW1CLENBQUN0RixXQUFXO0FBQUEsY0FDL0Isa0JBQWtCO0FBQUE7QUFBQSxZQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPNkM7QUFBQSxhQXBHL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNHQTtBQUFBLFdBN0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErR0E7QUFBQSxTQXhIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUhBO0FBQUEsT0FoSUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtJQSxLQW5JTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0lHO0FBRUo7QUFBRUwsR0E3VUlELGtCQUFnQjtBQUFBLFVBU2NMLGFBQWF5QixlQUFlO0FBQUE7QUFBQThFLEtBVDFEbEc7QUErVU4sZUFBZUE7QUFBaUIsSUFBQWtHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIlNlbGVjdCIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkZhV2hhdHNhcHAiLCJub3RpZmljYXRpb24iLCJTaWRlYmFyIiwiRmFVc2VycyIsIkZhQ2hlY2tDaXJjbGUiLCJCcmVhZGNydW1iIiwiQXVjdGlvbkJpZFN0YXR1cyIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ0b3RhbFVzZXJzIiwic2V0VG90YWxVc2VycyIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsImF1Y3Rpb25EYXRhIiwic2V0QXVjdGlvbkRhdGEiLCJncm91cE9wdGlvbnMiLCJTZXQiLCJmaWx0ZXIiLCJ1IiwiZ3JvdXBOYW1lIiwidW5kZWZpbmVkIiwibWFwIiwiZmlsdGVyZWRVc2VycyIsImZpbHRlcmVkIiwibWF0Y2hHcm91cCIsImVucm9sbG1lbnREYXRlIiwiRGF0ZSIsIm1hdGNoRnJvbURhdGUiLCJtYXRjaFRvRGF0ZSIsInVzZXIiLCJpbmRleCIsImlzU2VsZWN0ZWQiLCJfaWQiLCJpbmZvIiwic3RhdHVzIiwic2xfbm8iLCJjaGVja0JveHMiLCJlIiwicHJldiIsInRhcmdldCIsImNoZWNrZWQiLCJ1c2VyUGhvbmUiLCJ1c2VyTmFtZSIsImdyb3VwTWVtYmVycyIsImdyb3VwSWQiLCJ2aXNpYmxlU2VsZWN0ZWRDb3VudCIsImxlbmd0aCIsInNlbmRXaGF0c2FwcCIsImtleSIsIm9wZW4iLCJtZXNzYWdlIiwiZGVzY3JpcHRpb24iLCJjbGFzc05hbWUiLCJkdXJhdGlvbiIsInZpc2libGVBY3RpdmVVc2VycyIsImZvckVhY2giLCJwb3N0IiwicmVjZWl2ZXJzIiwibmV3QWN0aXZlVXNlckRhdGEiLCJlcnIiLCJhbGxDaGVja2VkIiwiZXZlcnkiLCJmZXRjaERhdGEiLCJyZXBvcnRSZXNwb25zZSIsImdldCIsInVzZXJzTGlzdCIsInRlbXBBY3RpdmUiLCJkYXRhIiwiYXVjdGlvbiIsImlkIiwiZ3JvdXBfaWQiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBfbWVtYmVycyIsImdyb3VwX25hbWUiLCJ0ZW1wVXNyIiwiY3JlYXRlZEF0IiwicHVzaCIsInNsTm8iLCJjb25zb2xlIiwiZXJyb3IiLCJBdWN0aW9uY29sdW1ucyIsImhlYWRlciIsInZhbHVlIiwid2lkdGgiLCJncm91cCIsInVwZGF0ZWREYXRhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXVjdGlvbkJpZFN0YXR1cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHsgRmFXaGF0c2FwcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgRmFVc2VycywgRmFDaGVja0NpcmNsZSB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5cclxuY29uc3QgQXVjdGlvbkJpZFN0YXR1cyA9ICgpID0+IHtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG90YWxVc2Vycywgc2V0VG90YWxVc2Vyc10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2F1Y3Rpb25EYXRhLCBzZXRBdWN0aW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgLy9jb25zdCBncm91cE9wdGlvbnMgPSBbLi4ubmV3IFNldCh1c2Vyc0RhdGEubWFwKCh1KSA9PiB1Lmdyb3VwTmFtZSkpXTtcclxuICBjb25zdCBncm91cE9wdGlvbnMgPSBbXHJcbiAgICAuLi5uZXcgU2V0KFxyXG4gICAgICB1c2Vyc0RhdGFcclxuICAgICAgICAuZmlsdGVyKFxyXG4gICAgICAgICAgKHUpID0+XHJcbiAgICAgICAgICAgIHUuZ3JvdXBOYW1lICE9PSB1bmRlZmluZWQgJiZcclxuICAgICAgICAgICAgdS5ncm91cE5hbWUgIT09IFwiXCIgJiZcclxuICAgICAgICAgICAgdS5ncm91cE5hbWUgIT09IFwiICAgXCJcclxuICAgICAgICApIC8vIEZpbHRlciBvdXQgdW5kZWZpbmVkLCBlbXB0eSwgYW5kIHdoaXRlc3BhY2Utb25seSB2YWx1ZXNcclxuICAgICAgICAubWFwKCh1KSA9PiB1Lmdyb3VwTmFtZSlcclxuICAgICksXHJcbiAgXTtcclxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGZpbHRlck9wdGlvbihcclxuICAgICAgdXNlcnNEYXRhLmZpbHRlcigodSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoR3JvdXAgPSBncm91cEZpbHRlciA/IHUuZ3JvdXBOYW1lID09PSBncm91cEZpbHRlciA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSBuZXcgRGF0ZSh1LmVucm9sbG1lbnREYXRlKTtcclxuICAgICAgICBjb25zdCBtYXRjaEZyb21EYXRlID0gZnJvbURhdGVcclxuICAgICAgICAgID8gZW5yb2xsbWVudERhdGUgPj0gbmV3IERhdGUoZnJvbURhdGUpXHJcbiAgICAgICAgICA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hUb0RhdGUgPSB0b0RhdGUgPyBlbnJvbGxtZW50RGF0ZSA8PSBuZXcgRGF0ZSh0b0RhdGUpIDogdHJ1ZTtcclxuICAgICAgICByZXR1cm4gbWF0Y2hHcm91cCAmJiBtYXRjaEZyb21EYXRlICYmIG1hdGNoVG9EYXRlO1xyXG4gICAgICB9KSxcclxuICAgICAgc2VhcmNoVGV4dFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZmlsdGVyZWQubWFwKCh1c2VyLCBpbmRleCkgPT4ge1xyXG4gICAgICBjb25zdCBpc1NlbGVjdGVkID0gISFhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cztcclxuXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4udXNlcixcclxuICAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4gICAgICAgIGNoZWNrQm94czogKFxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgIFt1c2VyLl9pZF06IHtcclxuICAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXIudXNlclBob25lLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBNZW1iZXJzOiB1c2VyLmdyb3VwTWVtYmVycyxcclxuICAgICAgICAgICAgICAgICAgICBncm91cElkOiB1c2VyLmdyb3VwSWQ/Ll9pZCxcclxuICAgICAgICAgICAgICAgICAgICAvLyB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICksXHJcbiAgICAgICAgaXNTZWxlY3RlZCxcclxuICAgICAgfTtcclxuICAgIH0pO1xyXG4gIH0sIFt1c2Vyc0RhdGEsIGdyb3VwRmlsdGVyLCBmcm9tRGF0ZSwgdG9EYXRlLCBzZWFyY2hUZXh0LCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuICBjb25zdCB2aXNpYmxlU2VsZWN0ZWRDb3VudCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGZpbHRlcmVkVXNlcnMuZmlsdGVyKCh1c2VyKSA9PiB1c2VyLmlzU2VsZWN0ZWQpLmxlbmd0aDtcclxuICB9LCBbZmlsdGVyZWRVc2Vyc10pO1xyXG5cclxuICBjb25zdCBzZW5kV2hhdHNhcHAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBrZXkgPSBcInVwZGF0YWJsZVwiO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU2VuZGluZyBNZXNzYWdlcyBWaWEgV2hhdHNhcHAuLlwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2Nlc3NpbmcuLi5cIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgdmlzaWJsZUFjdGl2ZVVzZXJzID0ge307XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQgJiYgYWN0aXZlVXNlckRhdGFbdXNlci5faWRdKSB7XHJcbiAgICAgICAgICB2aXNpYmxlQWN0aXZlVXNlcnNbdXNlci5faWRdID0gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi93aGF0c2FwcC9hdWN0aW9uLWJpZC1zdGF0dXNcIiwge1xyXG4gICAgICAgIHJlY2VpdmVyczogdmlzaWJsZUFjdGl2ZVVzZXJzLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IG5ld0FjdGl2ZVVzZXJEYXRhID0geyAuLi5hY3RpdmVVc2VyRGF0YSB9O1xyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgICBpZiAodXNlci5pc1NlbGVjdGVkKSB7XHJcbiAgICAgICAgICBkZWxldGUgbmV3QWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKG5ld0FjdGl2ZVVzZXJEYXRhKTtcclxuXHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwIE1lc3NhZ2VzIEhhcyBCZWVuIFNlbnQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiU3VjY2Vzc1wiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIFNlbmQgV2hhdHNhcHBcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogZXJyLm1lc3NhZ2UgfHwgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1yZWQtMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIEF1dG9tYXRpY2FsbHkgdXBkYXRlIHNlbGVjdEFsbCBiYXNlZCBvbiBmaWx0ZXJlZFVzZXJzXHJcbiAgICBjb25zdCBhbGxDaGVja2VkID1cclxuICAgICAgZmlsdGVyZWRVc2Vycy5sZW5ndGggPiAwICYmXHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZXZlcnkoKHVzZXIpID0+IGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXT8uaW5mbz8uc3RhdHVzKTtcclxuICAgIHNldFNlbGVjdEFsbChhbGxDaGVja2VkKTtcclxuICB9LCBbZmlsdGVyZWRVc2VycywgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXBvcnRSZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYXVjdGlvbi9nZXQtYXVjdGlvblwiKTtcclxuXHJcbiAgICAgIGNvbnN0IHVzZXJzTGlzdCA9IFtdO1xyXG4gICAgICBjb25zdCB0ZW1wQWN0aXZlID0ge307XHJcbiAgICAgIGNvbnN0IGRhdGEgPSByZXBvcnRSZXNwb25zZS5kYXRhPy5hdWN0aW9uLm1hcCgoYXVjdGlvbiwgaW5kZXgpID0+IHtcclxuICAgICAgICBjb25zdCBpZCA9IGF1Y3Rpb24uX2lkO1xyXG4gICAgICAgIGNvbnN0IGdyb3VwSWQgPSBhdWN0aW9uPy5ncm91cF9pZDtcclxuICAgICAgICBjb25zdCB1c2VyTmFtZSA9IGF1Y3Rpb24/LnVzZXJfaWQ/LmZ1bGxfbmFtZTtcclxuICAgICAgICBjb25zdCB1c2VyUGhvbmUgPSBhdWN0aW9uPy51c2VyX2lkPy5waG9uZV9udW1iZXI7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBNZW1iZXJzID0gYXVjdGlvbj8uZ3JvdXBfaWQ/Lmdyb3VwX21lbWJlcnM7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBOYW1lID0gYXVjdGlvbj8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWU7XHJcblxyXG4gICAgICAgIHRlbXBBY3RpdmVbaWRdID0ge1xyXG4gICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBjb25zdCB0ZW1wVXNyID0ge1xyXG4gICAgICAgICAgX2lkOiBpZCxcclxuICAgICAgICAgIHVzZXJOYW1lLFxyXG4gICAgICAgICAgdXNlclBob25lLFxyXG4gICAgICAgICAgZ3JvdXBNZW1iZXJzLFxyXG4gICAgICAgICAgZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgZ3JvdXBJZCxcclxuICAgICAgICAgIGVucm9sbG1lbnREYXRlOiBhdWN0aW9uPy5ncm91cF9pZD8uY3JlYXRlZEF0LFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdXNlcnNMaXN0LnB1c2godGVtcFVzcik7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBncm91cE5hbWUsXHJcbiAgICAgICAgICB1c2VyTmFtZSxcclxuICAgICAgICAgIHVzZXJQaG9uZSxcclxuICAgICAgICAgIGdyb3VwSWQsXHJcbiAgICAgICAgICBncm91cE1lbWJlcnMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcbiAgICAgIGNvbnNvbGUuaW5mbyhkYXRhLCBcImprZ25zZGtnanNibmdcIik7XHJcblxyXG4gICAgICBzZXRBdWN0aW9uRGF0YShkYXRhKTtcclxuICAgICAgc2V0VXNlcnNEYXRhKHVzZXJzTGlzdCk7IC8vIOKchSB1cGRhdGUgdXNlcnNEYXRhIGZvciBmaWx0ZXJpbmcgKyBjaGVja2JveGVzXHJcbiAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHRlbXBBY3RpdmUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgQXVjdGlvbmNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImNoZWNrQm94c1wiLCBoZWFkZXI6IFwiU2VsZWN0IFVzZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIC8vICB7a2V5OiBcInBheW1lbnRzVGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIn0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyLz5cclxuICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyIG10LTJcIj5cclxuICAgICAgICAgICAgICBBdWN0aW9uIEJpZCBTdGF0dXNcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgey8qID09PT09IFNVTU1BUlkgU0VDVElPTiA9PT09PSAqL31cclxuXHJcblxyXG4gICAgICAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1zdGFydCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgbWItNFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGNvbG9yPVwidGV4dC1ncmVlbi02MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTYgbXQtOCBtYi02XCI+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtMTAwIHJvdW5kZWQteGwgcC02IHNoYWRvdyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlRvdGFsIEN1c3RvbWVyczwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4gICAgICAgIHtmaWx0ZXJlZFVzZXJzLmxlbmd0aH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFVc2VycyBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgdGV4dC00eGxcIiAvPlxyXG4gIDwvZGl2PlxyXG5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5TZWxlY3RlZCBDdXN0b21lcnM8L3A+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgIHt2aXNpYmxlU2VsZWN0ZWRDb3VudH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB0ZXh0LTR4bFwiIC8+XHJcbiAgPC9kaXY+XHJcbjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tQWxsIGdyb3Vwcy0tXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEdyb3VwRmlsdGVyKHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cEZpbHRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMSBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBBbGxcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgdy00IGgtNCBtYi0zXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdEFsbH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGVja2VkID0gZS50YXJnZXQuY2hlY2tlZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0QWxsKGNoZWNrZWQpOyAvLyBTZXQgZ2xvYmFsIGNoZWNrYm94IHN0YXRlXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkRGF0YSA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIExvb3AgdGhyb3VnaCBhbGwgZmlsdGVyZWQgdXNlcnMgYW5kIGFwcGx5IHRoZSBzZWxlY3Rpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGFbdXNlci5faWRdID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJQaG9uZTogdXNlci51c2VyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE1lbWJlcnM6IHVzZXIuZ3JvdXBNZW1iZXJzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cElkOiB1c2VyLmdyb3VwSWQ/Ll9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSh1cGRhdGVkRGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17c2VuZFdoYXRzYXBwfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ncmVlbi03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi13LTYgaC02IGFic29sdXRlIC1yaWdodC0zIC10b3AtMiBzaGFkb3ctbGcgaG92ZXI6YmctcmVkLTYwMCBiZy1yZWQtNDAwIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YE1lc3NhZ2Ugd2lsbCBiZSBzZW50IHRvIHRvdGFsICR7dmlzaWJsZVNlbGVjdGVkQ291bnR9IGN1c3RvbWVyc2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt2aXNpYmxlU2VsZWN0ZWRDb3VudH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cIm1yLTJcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjb2x1bW5zPXtBdWN0aW9uY29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkF1Y3Rpb24gQmlkIFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1wiR3JvdXAgTmFtZVwiXX1cclxuICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tncm91cEZpbHRlcl19XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BBdWN0aW9uIEJpZCBTdGF0dXMuY3N2YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICBcclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXVjdGlvbkJpZFN0YXR1cztcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0F1Y3Rpb25CaWRTdGF0dXMuanN4In0=