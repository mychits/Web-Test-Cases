import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeIncentivePayment.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Drawer, Modal, Empty, Alert } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { FiCalendar, FiCreditCard, FiHash } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const AllEmployeeIncentives = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [tablePayments, setTablePayments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [editId, setEditId] = useState(null);
  const today = /* @__PURE__ */ new Date();
  const currentMonth = today.toISOString().slice(0, 7);
  const initialForm = {
    employee_id: "",
    incentive_month: currentMonth,
    pay_date: today,
    month: "",
    year: "",
    pay_type: "cash",
    transaction_id: "",
    amount: 0
  };
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info",
    noReload: true
  });
  useEffect(() => {
    if (alertConfig.visibility) {
      const timer = setTimeout(() => {
        setAlertConfig((prev) => ({ ...prev, visibility: false }));
      }, 3e3);
      return () => clearTimeout(timer);
    }
  }, [alertConfig.visibility]);
  useEffect(() => {
    fetchEmployees();
    fetchIncentiveHistory();
  }, []);
  const fetchEmployees = async () => {
    const res = await api.get("/employee");
    if (res.data.status) setEmployees(res.data.employee);
  };
  const fetchEmployeeIncentive = async (employeeId) => {
    try {
      const res = await api.get(
        `/salary-payment/get-salary-incentive/${employeeId}`
      );
      if (res.data.status && res.data.data.length > 0) {
        const latest = res.data.data[0];
        setFormData((prev) => ({
          ...prev,
          employee_id: employeeId,
          month: latest.salary_month,
          year: latest.salary_year,
          amount: latest.calculated_incentive
        }));
      } else {
        setAlertConfig({
          visibility: true,
          message: "No pending incentives found",
          type: "warning"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };
  const fetchIncentiveHistory = async () => {
    try {
      setIsLoading(true);
      const response = await api.get("/employee-incentive-payment/get-all-employee-incentive");
      const formatted = response.data?.data?.map((item, index) => ({
        ...item,
        id: index + 1,
        date: item.pay_date?.split("T")[0],
        incentive_month: item.incentive_month,
        employeeName: item.employee_id?.name || "N/A",
        month: item.salary_month || "N/A",
        year: item.salary_year || "N/A",
        amount: item.calculated_incentive,
        action: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            menu: {
              items: [
                { key: "1", label: "Edit", onClick: () => handleEdit(item) },
                {
                  key: "2",
                  label: /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "Delete" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                    lineNumber: 112,
                    columnNumber: 22
                  }, this),
                  onClick: () => showDeleteConfirm(item._id)
                }
              ]
            },
            trigger: ["click"],
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 119,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
            lineNumber: 106,
            columnNumber: 9
          },
          this
        )
      }));
      setTablePayments(formatted);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  const showDeleteConfirm = (id) => {
    Modal.confirm({
      title: "Are you sure you want to delete this record?",
      content: "This action cannot be undone.",
      okText: "Yes, Delete",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete(id);
      }
    });
  };
  const handleEdit = (item) => {
    const employeeId = typeof item.employee_id === "object" ? item.employee_id._id : item.employee_id;
    setEditId(item._id);
    setFormData({
      employee_id: employeeId,
      pay_date: item.pay_date?.split("T")[0],
      incentive_month: item.incentive_month,
      month: item.salary_month,
      year: item.salary_year,
      amount: item.calculated_incentive,
      pay_type: item.pay_type,
      transaction_id: item.transaction_id || ""
    });
    setShowModal(true);
  };
  const handleDelete = async (id) => {
    try {
      setOpenBackdropLoader(true);
      await api.delete(`/employee-incentive-payment/delete-employee-incentive/${id}`);
      setAlertConfig({
        visibility: true,
        message: "Data Deleted Successfully!",
        type: "success",
        noReload: true
      });
      fetchIncentiveHistory();
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Delete failed",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    console.log(editId, "this is editId", formData);
    try {
      setOpenBackdropLoader(true);
      if (editId) {
        await api.put(
          `/employee-incentive-payment/update-employee-incentive/${editId}`,
          formData
        );
      } else {
        await api.post("/employee-incentive-payment/add-incentive", formData);
      }
      setAlertConfig({
        visibility: true,
        message: editId ? "Data Updated Successfully!" : "Data Added Successfully!",
        type: "success",
        noReload: true
      });
      closeDrawer();
      fetchIncentiveHistory();
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Error saving data",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  const validateForm = () => {
    const errs = {};
    if (!formData.employee_id) errs.employee = "Required";
    if (!formData.amount || formData.amount <= 0)
      errs.amount = "Enter valid amount";
    if (!formData.month) errs.month = "Required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };
  const closeDrawer = () => {
    setShowModal(false);
    setEditId(null);
    setFormData(initialForm);
    setErrors({});
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    // { key: "date", header: "Paid Date" },
    { key: "employeeName", header: "Employee" },
    // { key: "incentive_month", header: "Month" },
    { key: "month", header: "Month" },
    { key: "year", header: "Year" },
    { key: "amount", header: "Amount" },
    // { key: "pay_type", header: "Mode" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    openBackdropLoader && /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "Processing..." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
      lineNumber: 255,
      columnNumber: 30
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
          lineNumber: 257,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
        lineNumber: 261,
        columnNumber: 9
      }, this),
      alertConfig.visibility && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-5 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-md px-4", children: /* @__PURE__ */ jsxDEV(
        Alert,
        {
          message: alertConfig.message,
          type: alertConfig.type,
          showIcon: true,
          closable: true,
          onClose: () => setAlertConfig({ ...alertConfig, visibility: false })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
          lineNumber: 264,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
        lineNumber: 263,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
          lineNumber: 277,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Employee Incentive" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
          lineNumber: 279,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
          lineNumber: 278,
          columnNumber: 11
        }, this),
        tablePayments.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Incentive Payment Data Found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
          lineNumber: 293,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: tablePayments.filter(
              (item) => item.employeeName?.toLowerCase().includes(searchText.toLowerCase())
            ),
            columns
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
            lineNumber: 295,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
        lineNumber: 276,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Drawer,
        {
          title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 310,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 309,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: editId ? "Edit Incentive Payment" : "New Incentive Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 312,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
            lineNumber: 308,
            columnNumber: 11
          }, this),
          open: showModal,
          onClose: closeDrawer,
          width: 480,
          children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6 p-1", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                "Employee ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 325,
                  columnNumber: 26
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 324,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  size: "large",
                  className: "w-full",
                  placeholder: "Search and select employee",
                  value: formData.employee_id || void 0,
                  optionFilterProp: "label",
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  onChange: (val) => (
                    // setFormData({ ...formData, employee_id: val })
                    fetchEmployeeIncentive(val)
                  ),
                  children: employees.map(
                    (emp) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: emp._id,
                        label: `${emp.name} ${emp.employeeCode}`,
                        children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-medium text-blue-700", children: emp.name.charAt(0).toUpperCase() }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                            lineNumber: 349,
                            columnNumber: 23
                          }, this),
                          emp.name,
                          " | ",
                          emp.employeeCode
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                          lineNumber: 348,
                          columnNumber: 21
                        }, this)
                      },
                      emp._id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                        lineNumber: 343,
                        columnNumber: 17
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 327,
                  columnNumber: 15
                },
                this
              ),
              errors.employee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 360,
                  columnNumber: 19
                }, this),
                errors.employee
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 359,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 323,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 369,
                  columnNumber: 17
                }, this),
                "Incentive Month"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 368,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "month",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                  value: formData.incentive_month,
                  onChange: (e) => setFormData({
                    ...formData,
                    incentive_month: e.target.value
                    // YYYY-MM ✅
                  })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 373,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 372,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 367,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 389,
                  columnNumber: 17
                }, this),
                "Amount ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 390,
                  columnNumber: 24
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 388,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-medium", children: "₹" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 393,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    step: "0.01",
                    className: "w-full border border-gray-300 rounded-lg pl-8 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                    placeholder: "0.00",
                    value: formData.amount,
                    onChange: (e) => setFormData({ ...formData, amount: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                    lineNumber: 396,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 392,
                columnNumber: 15
              }, this),
              formData.amount && /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 border border-blue-200 rounded-lg px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(formData.amount) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 409,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 408,
                columnNumber: 15
              }, this),
              errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 416,
                  columnNumber: 19
                }, this),
                errors.amount
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 415,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 387,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 424,
                  columnNumber: 17
                }, this),
                "Payment Date"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 423,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                  value: formData.pay_date,
                  onChange: (e) => setFormData({ ...formData, pay_date: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 428,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 427,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 422,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCreditCard, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 442,
                  columnNumber: 17
                }, this),
                "Payment Mode"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 441,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  className: "w-full",
                  value: formData.pay_type,
                  onChange: (val) => setFormData({ ...formData, pay_type: val }),
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cash" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                      lineNumber: 452,
                      columnNumber: 19
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                      lineNumber: 451,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Online/UPI" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                      lineNumber: 455,
                      columnNumber: 19
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                      lineNumber: 454,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cheque", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cheque" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                      lineNumber: 458,
                      columnNumber: 19
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                      lineNumber: 457,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 445,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 440,
              columnNumber: 13
            }, this),
            formData.pay_type !== "cash" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 animate-fadeIn", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiHash, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 467,
                  columnNumber: 19
                }, this),
                formData.pay_type === "cheque" ? "Cheque Number" : "Transaction ID"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 466,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                  placeholder: formData.pay_type === "cheque" ? "Enter cheque number" : "Enter transaction/UPI ID",
                  value: formData.transaction_id,
                  onChange: (e) => setFormData({ ...formData, transaction_id: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                  lineNumber: 472,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 465,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-200 font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5 flex items-center justify-center gap-2",
                children: editId ? "Update Incentive Payment" : "Save Incentive Payment"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
                lineNumber: 490,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
              lineNumber: 489,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
            lineNumber: 321,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
          lineNumber: 306,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
      lineNumber: 256,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx",
    lineNumber: 254,
    columnNumber: 5
  }, this);
};
_s(AllEmployeeIncentives, "looicvpxDTbLb4dl+zT5a8dmxuU=");
_c = AllEmployeeIncentives;
export default AllEmployeeIncentives;
var _c;
$RefreshReg$(_c, "AllEmployeeIncentives");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeIncentivePayment.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0d5QixTQThJckIsVUE5SXFCOzJCQS9HekI7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFVBQVVDLFFBQVFDLE9BQU9DLE9BQU9DLGFBQWE7QUFDOUQsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsWUFBWUMsY0FBY0MsY0FBYztBQUNqRCxTQUFTQyxtQkFBbUI7QUFDNUIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE1BQU1DLHdCQUF3QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xDLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJdkIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3dCLGVBQWVDLGdCQUFnQixJQUFJekIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzBCLFdBQVdDLFlBQVksSUFBSTNCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM0QixXQUFXQyxZQUFZLElBQUk3QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDOEIsWUFBWUMsYUFBYSxJQUFJL0IsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2dDLG9CQUFvQkMscUJBQXFCLElBQUlqQyxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDa0MsUUFBUUMsU0FBUyxJQUFJbkMsU0FBUyxJQUFJO0FBRXpDLFFBQU1vQyxRQUFRLG9CQUFJQyxLQUFLO0FBRXZCLFFBQU1DLGVBQWVGLE1BQU1HLFlBQVksRUFBRUMsTUFBTSxHQUFHLENBQUM7QUFFbkQsUUFBTUMsY0FBYztBQUFBLElBQ2xCQyxhQUFhO0FBQUEsSUFDYkMsaUJBQWlCTDtBQUFBQSxJQUNqQk0sVUFBVVI7QUFBQUEsSUFDVlMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLFFBQVE7QUFBQSxFQUNWO0FBRUEsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUluRCxTQUFTeUMsV0FBVztBQUNwRCxRQUFNLENBQUNXLFFBQVFDLFNBQVMsSUFBSXJELFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ3NELGFBQWFDLGNBQWMsSUFBSXZELFNBQVM7QUFBQSxJQUM3Q3dELFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLElBQ05DLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDREMsWUFBVSxNQUFNO0FBQ2QsUUFBSU4sWUFBWUUsWUFBWTtBQUMxQixZQUFNSyxRQUFRQyxXQUFXLE1BQU07QUFDN0JQLHVCQUFlLENBQUNRLFVBQVUsRUFBRSxHQUFHQSxNQUFNUCxZQUFZLE1BQU0sRUFBRTtBQUFBLE1BQzNELEdBQUcsR0FBSTtBQUNQLGFBQU8sTUFBTVEsYUFBYUgsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLENBQUNQLFlBQVlFLFVBQVUsQ0FBQztBQUMzQkksWUFBVSxNQUFNO0FBQ2RLLG1CQUFlO0FBQ2ZDLDBCQUFzQjtBQUFBLEVBQ3hCLEdBQUcsRUFBRTtBQUVMLFFBQU1ELGlCQUFpQixZQUFZO0FBQ2pDLFVBQU1FLE1BQU0sTUFBTWpFLElBQUlrRSxJQUFJLFdBQVc7QUFDckMsUUFBSUQsSUFBSUUsS0FBS0MsT0FBUS9DLGNBQWE0QyxJQUFJRSxLQUFLRSxRQUFRO0FBQUEsRUFDckQ7QUFFQSxRQUFNQyx5QkFBeUIsT0FBT0MsZUFBZTtBQUNuRCxRQUFJO0FBQ0YsWUFBTU4sTUFBTSxNQUFNakUsSUFBSWtFO0FBQUFBLFFBQ3BCLHdDQUF3Q0ssVUFBVTtBQUFBLE1BQ3BEO0FBRUEsVUFBSU4sSUFBSUUsS0FBS0MsVUFBVUgsSUFBSUUsS0FBS0EsS0FBS0ssU0FBUyxHQUFHO0FBQy9DLGNBQU1DLFNBQVNSLElBQUlFLEtBQUtBLEtBQUssQ0FBQztBQUU5QmxCLG9CQUFZLENBQUNZLFVBQVU7QUFBQSxVQUNyQixHQUFHQTtBQUFBQSxVQUNIckIsYUFBYStCO0FBQUFBLFVBQ2I1QixPQUFPOEIsT0FBT0M7QUFBQUEsVUFDZDlCLE1BQU02QixPQUFPRTtBQUFBQSxVQUNiNUIsUUFBUTBCLE9BQU9HO0FBQUFBLFFBQ2pCLEVBQUU7QUFBQSxNQUNKLE9BQU87QUFDTHZCLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU3FCLEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLFFBQU1iLHdCQUF3QixZQUFZO0FBQ3hDLFFBQUk7QUFDRnJDLG1CQUFhLElBQUk7QUFDakIsWUFBTXFELFdBQVcsTUFBTWhGLElBQUlrRSxJQUFJLHdEQUF3RDtBQUN2RixZQUFNZSxZQUFZRCxTQUFTYixNQUFNQSxNQUFNZSxJQUFJLENBQUNDLE1BQU1DLFdBQVc7QUFBQSxRQUMzRCxHQUFHRDtBQUFBQSxRQUNIRSxJQUFJRCxRQUFRO0FBQUEsUUFDWkUsTUFBTUgsS0FBS3pDLFVBQVU2QyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDakM5QyxpQkFBaUIwQyxLQUFLMUM7QUFBQUEsUUFDdEIrQyxjQUFjTCxLQUFLM0MsYUFBYWlELFFBQVE7QUFBQSxRQUN4QzlDLE9BQU93QyxLQUFLVCxnQkFBZ0I7QUFBQSxRQUM1QjlCLE1BQU11QyxLQUFLUixlQUFlO0FBQUEsUUFDMUI1QixRQUFRb0MsS0FBS1A7QUFBQUEsUUFDYmMsUUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTTtBQUFBLGNBQ0pDLE9BQU87QUFBQSxnQkFDTCxFQUFFQyxLQUFLLEtBQUtDLE9BQU8sUUFBUUMsU0FBU0EsTUFBTUMsV0FBV1osSUFBSSxFQUFFO0FBQUEsZ0JBQzNEO0FBQUEsa0JBQ0VTLEtBQUs7QUFBQSxrQkFDTEMsT0FBTyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsc0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQzVDQyxTQUFTQSxNQUFNRSxrQkFBa0JiLEtBQUtjLEdBQUc7QUFBQSxnQkFDM0M7QUFBQSxjQUFDO0FBQUEsWUFFTDtBQUFBLFlBQ0EsU0FBUyxDQUFDLE9BQU87QUFBQSxZQUVqQixpQ0FBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDO0FBQUE7QUFBQSxVQWI5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFjQTtBQUFBLE1BRUosRUFBRTtBQUNGMUUsdUJBQWlCMEQsU0FBUztBQUFBLElBQzVCLFNBQVNKLEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQ25CLFVBQUM7QUFDQ2xELG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNcUUsb0JBQW9CQSxDQUFDWCxPQUFPO0FBQ2hDOUUsVUFBTTJGLFFBQVE7QUFBQSxNQUNaQyxPQUFPO0FBQUEsTUFDUEMsU0FBUztBQUFBLE1BQ1RDLFFBQVE7QUFBQSxNQUNSQyxRQUFRO0FBQUEsTUFDUkMsWUFBWTtBQUFBLE1BQ1pDLE9BQU87QUFDTEMscUJBQWFwQixFQUFFO0FBQUEsTUFDakI7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTVUsYUFBYUEsQ0FBQ1osU0FBUztBQUMzQixVQUFNWixhQUNKLE9BQU9ZLEtBQUszQyxnQkFBZ0IsV0FDeEIyQyxLQUFLM0MsWUFBWXlELE1BQ2pCZCxLQUFLM0M7QUFFWFAsY0FBVWtELEtBQUtjLEdBQUc7QUFDbEJoRCxnQkFBWTtBQUFBLE1BQ1ZULGFBQWErQjtBQUFBQSxNQUNiN0IsVUFBVXlDLEtBQUt6QyxVQUFVNkMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3JDOUMsaUJBQWlCMEMsS0FBSzFDO0FBQUFBLE1BQ3RCRSxPQUFPd0MsS0FBS1Q7QUFBQUEsTUFDWjlCLE1BQU11QyxLQUFLUjtBQUFBQSxNQUNYNUIsUUFBUW9DLEtBQUtQO0FBQUFBLE1BQ2IvQixVQUFVc0MsS0FBS3RDO0FBQUFBLE1BQ2ZDLGdCQUFnQnFDLEtBQUtyQyxrQkFBa0I7QUFBQSxJQUN6QyxDQUFDO0FBQ0RyQixpQkFBYSxJQUFJO0FBQUEsRUFDbkI7QUFFQSxRQUFNZ0YsZUFBZSxPQUFPcEIsT0FBTztBQUNqQyxRQUFJO0FBQ0Z0RCw0QkFBc0IsSUFBSTtBQUMxQixZQUFNL0IsSUFBSTBHLE9BQU8seURBQXlEckIsRUFBRSxFQUFFO0FBQzlFaEMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxRQUNOQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQ0RPLDRCQUFzQjtBQUFBLElBQ3hCLFNBQVNlLE9BQU87QUFDZDFCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsUUFDTkMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDMUIsNEJBQXNCLEtBQUs7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEUsZUFBZSxPQUFPQyxNQUFNO0FBQ2hDQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ0MsYUFBYSxFQUFHO0FBQ3JCaEMsWUFBUWlDLElBQUkvRSxRQUFRLGtCQUFrQmdCLFFBQVE7QUFFOUMsUUFBSTtBQUNGakIsNEJBQXNCLElBQUk7QUFDMUIsVUFBSUMsUUFBUTtBQUNWLGNBQU1oQyxJQUFJZ0g7QUFBQUEsVUFDUix5REFBeURoRixNQUFNO0FBQUEsVUFDL0RnQjtBQUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTWhELElBQUlpSCxLQUFLLDZDQUE2Q2pFLFFBQVE7QUFBQSxNQUN0RTtBQUNBSyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTdkIsU0FDTCwrQkFDQTtBQUFBLFFBQ0p3QixNQUFNO0FBQUEsUUFDTkMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUNEeUQsa0JBQVk7QUFDWmxELDRCQUFzQjtBQUFBLElBQ3hCLFNBQVNlLE9BQU87QUFDZDFCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsUUFDTkMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDMUIsNEJBQXNCLEtBQUs7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0UsZUFBZUEsTUFBTTtBQUN6QixVQUFNSyxPQUFPLENBQUM7QUFDZCxRQUFJLENBQUNuRSxTQUFTUixZQUFhMkUsTUFBSzlDLFdBQVc7QUFDM0MsUUFBSSxDQUFDckIsU0FBU0QsVUFBVUMsU0FBU0QsVUFBVTtBQUN6Q29FLFdBQUtwRSxTQUFTO0FBQ2hCLFFBQUksQ0FBQ0MsU0FBU0wsTUFBT3dFLE1BQUt4RSxRQUFRO0FBQ2xDUSxjQUFVZ0UsSUFBSTtBQUNkLFdBQU9DLE9BQU9DLEtBQUtGLElBQUksRUFBRTNDLFdBQVc7QUFBQSxFQUN0QztBQUVBLFFBQU0wQyxjQUFjQSxNQUFNO0FBQ3hCekYsaUJBQWEsS0FBSztBQUNsQlEsY0FBVSxJQUFJO0FBQ2RnQixnQkFBWVYsV0FBVztBQUN2QlksY0FBVSxDQUFDLENBQUM7QUFBQSxFQUNkO0FBRUEsUUFBTW1FLFVBQVU7QUFBQSxJQUNkLEVBQUUxQixLQUFLLE1BQU0yQixRQUFRLFNBQVM7QUFBQTtBQUFBLElBRTlCLEVBQUUzQixLQUFLLGdCQUFnQjJCLFFBQVEsV0FBVztBQUFBO0FBQUEsSUFFMUMsRUFBRTNCLEtBQUssU0FBUzJCLFFBQVEsUUFBUTtBQUFBLElBQ2hDLEVBQUUzQixLQUFLLFFBQVEyQixRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFM0IsS0FBSyxVQUFVMkIsUUFBUSxTQUFTO0FBQUE7QUFBQSxJQUVsQyxFQUFFM0IsS0FBSyxVQUFVMkIsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxTQUNFLG1DQUNHekY7QUFBQUEsMEJBQXNCLHVCQUFDLHNCQUFtQixPQUFPLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJDO0FBQUEsSUFDbEUsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCLENBQUM4RSxNQUFNL0UsY0FBYytFLEVBQUVZLE9BQU9DLEtBQUs7QUFBQSxVQUNoRSxZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUHJFLFlBQVlFLGNBQ1gsdUJBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTRixZQUFZRztBQUFBQSxVQUNyQixNQUFNSCxZQUFZSTtBQUFBQSxVQUNsQjtBQUFBLFVBQ0E7QUFBQSxVQUNBLFNBQVMsTUFDUEgsZUFBZSxFQUFFLEdBQUdELGFBQWFFLFlBQVksTUFBTSxDQUFDO0FBQUE7QUFBQSxRQU54RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPRyxLQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BR0YsdUJBQUMsU0FBSSxXQUFVLGlCQUNIO0FBQUEsK0JBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDckIsdUJBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFFBQUcsV0FBVSwwQkFBeUIsa0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFFQ2hDLGNBQWNrRCxVQUFVLElBQ3ZCLHVCQUFDLFNBQU0sYUFBWSxxQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRCxJQUVwRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTWxELGNBQWNvRztBQUFBQSxjQUFPLENBQUN2QyxTQUMxQkEsS0FBS0ssY0FDRG1DLFlBQVksRUFDYkMsU0FBU2hHLFdBQVcrRixZQUFZLENBQUM7QUFBQSxZQUN0QztBQUFBLFlBQ0E7QUFBQTtBQUFBLFVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTW1CO0FBQUEsV0F6QnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxtRUFDYixpQ0FBQyxlQUFZLFdBQVUsbUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSx5QkFDYjNGLG1CQUFTLDJCQUEyQiwyQkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUYsTUFBTVI7QUFBQUEsVUFDTixTQUFTMEY7QUFBQUEsVUFDVCxPQUFPO0FBQUEsVUFFUCxpQ0FBQyxVQUFLLFVBQVVQLGNBQWMsV0FBVSxpQkFFdEM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2REFBNEQ7QUFBQTtBQUFBLGdCQUNsRSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osT0FBTzNELFNBQVNSLGVBQWVxRjtBQUFBQSxrQkFDL0Isa0JBQWlCO0FBQUEsa0JBQ2pCLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLFFBQVFsQyxPQUFPOEIsWUFBWSxFQUFFQyxTQUFTRSxNQUFNSCxZQUFZLENBQUM7QUFBQSxrQkFFM0QsVUFBVSxDQUFDSztBQUFBQTtBQUFBQSxvQkFFVDFELHVCQUF1QjBELEdBQUc7QUFBQTtBQUFBLGtCQUczQjVHLG9CQUFVOEQ7QUFBQUEsb0JBQUksQ0FBQytDLFFBQ2Q7QUFBQSxzQkFBQyxPQUFPO0FBQUEsc0JBQVA7QUFBQSx3QkFFQyxPQUFPQSxJQUFJaEM7QUFBQUEsd0JBQ1gsT0FBTyxHQUFHZ0MsSUFBSXhDLElBQUksSUFBSXdDLElBQUlDLFlBQVk7QUFBQSx3QkFFdEMsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaURBQUMsU0FBSSxXQUFVLHVHQUNaRCxjQUFJeEMsS0FBSzBDLE9BQU8sQ0FBQyxFQUFFQyxZQUFZLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQ0gsSUFBSXhDO0FBQUFBLDBCQUFLO0FBQUEsMEJBQUl3QyxJQUFJQztBQUFBQSw2QkFKcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBO0FBQUEsc0JBVEtELElBQUloQztBQUFBQSxzQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVdBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0E2QkE7QUFBQSxjQUVDL0MsT0FBT21CLFlBQ04sdUJBQUMsT0FBRSxXQUFVLHFEQUNYO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHFDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRDtBQUFBLGdCQUNqRG5CLE9BQU9tQjtBQUFBQSxtQkFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUNBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2REFDZjtBQUFBLHVDQUFDLGNBQVcsV0FBVSwyQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxnQkFBRztBQUFBLG1CQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLE9BQU9yQixTQUFTUDtBQUFBQSxrQkFDaEIsVUFBVSxDQUFDbUUsTUFDVDNELFlBQVk7QUFBQSxvQkFDVixHQUFHRDtBQUFBQSxvQkFDSFAsaUJBQWlCbUUsRUFBRVksT0FBT0M7QUFBQUE7QUFBQUEsa0JBQzVCLENBQUM7QUFBQTtBQUFBLGdCQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVNHLEtBVkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx1Q0FBQyxlQUFZLFdBQVUsMkJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThDO0FBQUEsZ0JBQUc7QUFBQSxnQkFDMUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxzRUFBcUUsaUJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osT0FBT3pFLFNBQVNEO0FBQUFBLG9CQUNoQixVQUFVLENBQUM2RCxNQUNUM0QsWUFBWSxFQUFFLEdBQUdELFVBQVVELFFBQVE2RCxFQUFFWSxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGtCQVB2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUc7QUFBQSxtQkFaTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsY0FDQ3pFLFNBQVNELFVBQ1IsdUJBQUMsU0FBSSxXQUFVLDBEQUNiLGlDQUFDLE9BQUUsV0FBVSw2REFDVm5DLDhCQUFvQm9DLFNBQVNELE1BQU0sS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUVERyxPQUFPSCxVQUNOLHVCQUFDLE9BQUUsV0FBVSxnREFDWDtBQUFBLHVDQUFDLFVBQUssV0FBVSxxQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0Q7QUFBQSxnQkFDakRHLE9BQU9IO0FBQUFBLG1CQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkEvQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQ0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDZEQUNmO0FBQUEsdUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QztBQUFBLGdCQUFHO0FBQUEsbUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT0MsU0FBU047QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQ2tFLE1BQ1QzRCxZQUFZLEVBQUUsR0FBR0QsVUFBVU4sVUFBVWtFLEVBQUVZLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsZ0JBTHpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1HLEtBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDZEQUNmO0FBQUEsdUNBQUMsZ0JBQWEsV0FBVSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0M7QUFBQSxnQkFBRztBQUFBLG1CQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLE9BQU96RSxTQUFTSDtBQUFBQSxrQkFDaEIsVUFBVSxDQUFDbUYsUUFBUS9FLFlBQVksRUFBRSxHQUFHRCxVQUFVSCxVQUFVbUYsSUFBSSxDQUFDO0FBQUEsa0JBRTdEO0FBQUEsMkNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxRQUNuQixpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCLG9CQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUNuQixpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCLDBCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUNuQixpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCLHNCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQyxLQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUE7QUFBQTtBQUFBLGdCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWVBO0FBQUEsaUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsWUFHQ2hGLFNBQVNILGFBQWEsVUFDckIsdUJBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDZEQUNmO0FBQUEsdUNBQUMsVUFBTyxXQUFVLDJCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QztBQUFBLGdCQUN4Q0csU0FBU0gsYUFBYSxXQUNuQixrQkFDQTtBQUFBLG1CQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsYUFDRUcsU0FBU0gsYUFBYSxXQUNsQix3QkFDQTtBQUFBLGtCQUVOLE9BQU9HLFNBQVNGO0FBQUFBLGtCQUNoQixVQUFVLENBQUM4RCxNQUNUM0QsWUFBWSxFQUFFLEdBQUdELFVBQVVGLGdCQUFnQjhELEVBQUVZLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsZ0JBVi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdHO0FBQUEsaUJBbEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFJRix1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUVUekYsbUJBQVMsNkJBQTZCO0FBQUE7QUFBQSxjQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQS9LRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdMQTtBQUFBO0FBQUEsUUEvTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZ01BO0FBQUEsU0FsUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1QQTtBQUFBLE9BclBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzUEE7QUFFSjtBQUFFYixHQXhlSUQsdUJBQXFCO0FBQUFtSCxLQUFyQm5IO0FBMGVOLGVBQWVBO0FBQXNCLElBQUFtSDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJTaWRlYmFyIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJOYXZiYXIiLCJTZWxlY3QiLCJEcm9wZG93biIsIkRyYXdlciIsIk1vZGFsIiwiRW1wdHkiLCJBbGVydCIsIklvTWRNb3JlIiwiQmFja2Ryb3BCbHVyTG9hZGVyIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIkZpQ2FsZW5kYXIiLCJGaUNyZWRpdENhcmQiLCJGaUhhc2giLCJGYVJ1cGVlU2lnbiIsIkJyZWFkY3J1bWIiLCJBbGxFbXBsb3llZUluY2VudGl2ZXMiLCJfcyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInRhYmxlUGF5bWVudHMiLCJzZXRUYWJsZVBheW1lbnRzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJvcGVuQmFja2Ryb3BMb2FkZXIiLCJzZXRPcGVuQmFja2Ryb3BMb2FkZXIiLCJlZGl0SWQiLCJzZXRFZGl0SWQiLCJ0b2RheSIsIkRhdGUiLCJjdXJyZW50TW9udGgiLCJ0b0lTT1N0cmluZyIsInNsaWNlIiwiaW5pdGlhbEZvcm0iLCJlbXBsb3llZV9pZCIsImluY2VudGl2ZV9tb250aCIsInBheV9kYXRlIiwibW9udGgiLCJ5ZWFyIiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsImFtb3VudCIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwibm9SZWxvYWQiLCJ1c2VFZmZlY3QiLCJ0aW1lciIsInNldFRpbWVvdXQiLCJwcmV2IiwiY2xlYXJUaW1lb3V0IiwiZmV0Y2hFbXBsb3llZXMiLCJmZXRjaEluY2VudGl2ZUhpc3RvcnkiLCJyZXMiLCJnZXQiLCJkYXRhIiwic3RhdHVzIiwiZW1wbG95ZWUiLCJmZXRjaEVtcGxveWVlSW5jZW50aXZlIiwiZW1wbG95ZWVJZCIsImxlbmd0aCIsImxhdGVzdCIsInNhbGFyeV9tb250aCIsInNhbGFyeV95ZWFyIiwiY2FsY3VsYXRlZF9pbmNlbnRpdmUiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJyZXNwb25zZSIsImZvcm1hdHRlZCIsIm1hcCIsIml0ZW0iLCJpbmRleCIsImlkIiwiZGF0ZSIsInNwbGl0IiwiZW1wbG95ZWVOYW1lIiwibmFtZSIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJvbkNsaWNrIiwiaGFuZGxlRWRpdCIsInNob3dEZWxldGVDb25maXJtIiwiX2lkIiwiY29uZmlybSIsInRpdGxlIiwiY29udGVudCIsIm9rVGV4dCIsIm9rVHlwZSIsImNhbmNlbFRleHQiLCJvbk9rIiwiaGFuZGxlRGVsZXRlIiwiZGVsZXRlIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwidmFsaWRhdGVGb3JtIiwibG9nIiwicHV0IiwicG9zdCIsImNsb3NlRHJhd2VyIiwiZXJycyIsIk9iamVjdCIsImtleXMiLCJjb2x1bW5zIiwiaGVhZGVyIiwidGFyZ2V0IiwidmFsdWUiLCJmaWx0ZXIiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJ2YWwiLCJlbXAiLCJlbXBsb3llZUNvZGUiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVtcGxveWVlSW5jZW50aXZlUGF5bWVudC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIERyb3Bkb3duLCBEcmF3ZXIsIE1vZGFsLCBFbXB0eSwgQWxlcnQgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgQmFja2Ryb3BCbHVyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQmFja2Ryb3BCbHVyTG9hZGVyXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcbmltcG9ydCB7IEZpQ2FsZW5kYXIsIEZpQ3JlZGl0Q2FyZCwgRmlIYXNoIH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbmltcG9ydCB7IEZhUnVwZWVTaWduIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuY29uc3QgQWxsRW1wbG95ZWVJbmNlbnRpdmVzID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RhYmxlUGF5bWVudHMsIHNldFRhYmxlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbb3BlbkJhY2tkcm9wTG9hZGVyLCBzZXRPcGVuQmFja2Ryb3BMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0SWQsIHNldEVkaXRJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG5cclxuICBjb25zdCBjdXJyZW50TW9udGggPSB0b2RheS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDcpO1xyXG5cclxuICBjb25zdCBpbml0aWFsRm9ybSA9IHtcclxuICAgIGVtcGxveWVlX2lkOiBcIlwiLFxyXG4gICAgaW5jZW50aXZlX21vbnRoOiBjdXJyZW50TW9udGgsXHJcbiAgICBwYXlfZGF0ZTogdG9kYXksXHJcbiAgICBtb250aDogXCJcIixcclxuICAgIHllYXI6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgIGFtb3VudDogMCxcclxuICB9O1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKGluaXRpYWxGb3JtKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgICBub1JlbG9hZDogdHJ1ZSxcclxuICB9KTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGFsZXJ0Q29uZmlnLnZpc2liaWxpdHkpIHtcclxuICAgICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpO1xyXG4gICAgICB9LCAzMDAwKTtcclxuICAgICAgcmV0dXJuICgpID0+IGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICB9XHJcbiAgfSwgW2FsZXJ0Q29uZmlnLnZpc2liaWxpdHldKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuICAgIGZldGNoSW5jZW50aXZlSGlzdG9yeSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgaWYgKHJlcy5kYXRhLnN0YXR1cykgc2V0RW1wbG95ZWVzKHJlcy5kYXRhLmVtcGxveWVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEVtcGxveWVlSW5jZW50aXZlID0gYXN5bmMgKGVtcGxveWVlSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9zYWxhcnktcGF5bWVudC9nZXQtc2FsYXJ5LWluY2VudGl2ZS8ke2VtcGxveWVlSWR9YCxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXMuZGF0YS5zdGF0dXMgJiYgcmVzLmRhdGEuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgY29uc3QgbGF0ZXN0ID0gcmVzLmRhdGEuZGF0YVswXTtcclxuXHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXHJcbiAgICAgICAgICBtb250aDogbGF0ZXN0LnNhbGFyeV9tb250aCxcclxuICAgICAgICAgIHllYXI6IGxhdGVzdC5zYWxhcnlfeWVhcixcclxuICAgICAgICAgIGFtb3VudDogbGF0ZXN0LmNhbGN1bGF0ZWRfaW5jZW50aXZlLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJObyBwZW5kaW5nIGluY2VudGl2ZXMgZm91bmRcIixcclxuICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoSW5jZW50aXZlSGlzdG9yeSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlLWluY2VudGl2ZS1wYXltZW50L2dldC1hbGwtZW1wbG95ZWUtaW5jZW50aXZlXCIpO1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSByZXNwb25zZS5kYXRhPy5kYXRhPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICBkYXRlOiBpdGVtLnBheV9kYXRlPy5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgaW5jZW50aXZlX21vbnRoOiBpdGVtLmluY2VudGl2ZV9tb250aCxcclxuICAgICAgICBlbXBsb3llZU5hbWU6IGl0ZW0uZW1wbG95ZWVfaWQ/Lm5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICBtb250aDogaXRlbS5zYWxhcnlfbW9udGggfHwgXCJOL0FcIixcclxuICAgICAgICB5ZWFyOiBpdGVtLnNhbGFyeV95ZWFyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgYW1vdW50OiBpdGVtLmNhbGN1bGF0ZWRfaW5jZW50aXZlLFxyXG4gICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgeyBrZXk6IFwiMVwiLCBsYWJlbDogXCJFZGl0XCIsIG9uQ2xpY2s6ICgpID0+IGhhbmRsZUVkaXQoaXRlbSkgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgbGFiZWw6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPkRlbGV0ZTwvc3Bhbj4sXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IHNob3dEZWxldGVDb25maXJtKGl0ZW0uX2lkKSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRUYWJsZVBheW1lbnRzKGZvcm1hdHRlZCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBzaG93RGVsZXRlQ29uZmlybSA9IChpZCkgPT4ge1xyXG4gICAgTW9kYWwuY29uZmlybSh7XHJcbiAgICAgIHRpdGxlOiBcIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyByZWNvcmQ/XCIsXHJcbiAgICAgIGNvbnRlbnQ6IFwiVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS5cIixcclxuICAgICAgb2tUZXh0OiBcIlllcywgRGVsZXRlXCIsXHJcbiAgICAgIG9rVHlwZTogXCJkYW5nZXJcIixcclxuICAgICAgY2FuY2VsVGV4dDogXCJOb1wiLFxyXG4gICAgICBvbk9rKCkge1xyXG4gICAgICAgIGhhbmRsZURlbGV0ZShpZCk7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFZGl0ID0gKGl0ZW0pID0+IHtcclxuICAgIGNvbnN0IGVtcGxveWVlSWQgPVxyXG4gICAgICB0eXBlb2YgaXRlbS5lbXBsb3llZV9pZCA9PT0gXCJvYmplY3RcIlxyXG4gICAgICAgID8gaXRlbS5lbXBsb3llZV9pZC5faWRcclxuICAgICAgICA6IGl0ZW0uZW1wbG95ZWVfaWQ7XHJcblxyXG4gICAgc2V0RWRpdElkKGl0ZW0uX2lkKTtcclxuICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXHJcbiAgICAgIHBheV9kYXRlOiBpdGVtLnBheV9kYXRlPy5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgIGluY2VudGl2ZV9tb250aDogaXRlbS5pbmNlbnRpdmVfbW9udGgsXHJcbiAgICAgIG1vbnRoOiBpdGVtLnNhbGFyeV9tb250aCxcclxuICAgICAgeWVhcjogaXRlbS5zYWxhcnlfeWVhcixcclxuICAgICAgYW1vdW50OiBpdGVtLmNhbGN1bGF0ZWRfaW5jZW50aXZlLFxyXG4gICAgICBwYXlfdHlwZTogaXRlbS5wYXlfdHlwZSxcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IGl0ZW0udHJhbnNhY3Rpb25faWQgfHwgXCJcIixcclxuICAgIH0pO1xyXG4gICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG4gICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvZW1wbG95ZWUtaW5jZW50aXZlLXBheW1lbnQvZGVsZXRlLWVtcGxveWVlLWluY2VudGl2ZS8ke2lkfWApO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkRhdGEgRGVsZXRlZCBTdWNjZXNzZnVsbHkhXCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBmZXRjaEluY2VudGl2ZUhpc3RvcnkoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRGVsZXRlIGZhaWxlZFwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAoIXZhbGlkYXRlRm9ybSgpKSByZXR1cm47XHJcbiAgICBjb25zb2xlLmxvZyhlZGl0SWQsIFwidGhpcyBpcyBlZGl0SWRcIiwgZm9ybURhdGEpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcih0cnVlKTtcclxuICAgICAgaWYgKGVkaXRJZCkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgICBgL2VtcGxveWVlLWluY2VudGl2ZS1wYXltZW50L3VwZGF0ZS1lbXBsb3llZS1pbmNlbnRpdmUvJHtlZGl0SWR9YCxcclxuICAgICAgICAgIGZvcm1EYXRhLFxyXG4gICAgICAgICk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvZW1wbG95ZWUtaW5jZW50aXZlLXBheW1lbnQvYWRkLWluY2VudGl2ZVwiLCBmb3JtRGF0YSk7XHJcbiAgICAgIH1cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogZWRpdElkXHJcbiAgICAgICAgICA/IFwiRGF0YSBVcGRhdGVkIFN1Y2Nlc3NmdWxseSFcIlxyXG4gICAgICAgICAgOiBcIkRhdGEgQWRkZWQgU3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgY2xvc2VEcmF3ZXIoKTtcclxuICAgICAgZmV0Y2hJbmNlbnRpdmVIaXN0b3J5KCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkVycm9yIHNhdmluZyBkYXRhXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZXJycyA9IHt9O1xyXG4gICAgaWYgKCFmb3JtRGF0YS5lbXBsb3llZV9pZCkgZXJycy5lbXBsb3llZSA9IFwiUmVxdWlyZWRcIjtcclxuICAgIGlmICghZm9ybURhdGEuYW1vdW50IHx8IGZvcm1EYXRhLmFtb3VudCA8PSAwKVxyXG4gICAgICBlcnJzLmFtb3VudCA9IFwiRW50ZXIgdmFsaWQgYW1vdW50XCI7XHJcbiAgICBpZiAoIWZvcm1EYXRhLm1vbnRoKSBlcnJzLm1vbnRoID0gXCJSZXF1aXJlZFwiO1xyXG4gICAgc2V0RXJyb3JzKGVycnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKGVycnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBjbG9zZURyYXdlciA9ICgpID0+IHtcclxuICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICBzZXRFZGl0SWQobnVsbCk7XHJcbiAgICBzZXRGb3JtRGF0YShpbml0aWFsRm9ybSk7XHJcbiAgICBzZXRFcnJvcnMoe30pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgLy8geyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiUGFpZCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlTmFtZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWVcIiB9LFxyXG4gICAvLyB7IGtleTogXCJpbmNlbnRpdmVfbW9udGhcIiwgaGVhZGVyOiBcIk1vbnRoXCIgfSxcclxuICAgIHsga2V5OiBcIm1vbnRoXCIsIGhlYWRlcjogXCJNb250aFwiIH0sXHJcbiAgICB7IGtleTogXCJ5ZWFyXCIsIGhlYWRlcjogXCJZZWFyXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgLy8geyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIk1vZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7b3BlbkJhY2tkcm9wTG9hZGVyICYmIDxCYWNrZHJvcEJsdXJMb2FkZXIgdGl0bGU9e1wiUHJvY2Vzc2luZy4uLlwifSAvPn1cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICB7YWxlcnRDb25maWcudmlzaWJpbGl0eSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIHRvcC01IGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgei1bMTAwMF0gdy1mdWxsIG1heC13LW1kIHB4LTRcIj5cclxuICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfSAvLyBzdWNjZXNzLCBpbmZvLCB3YXJuaW5nLCBlcnJvclxyXG4gICAgICAgICAgICAgIHNob3dJY29uXHJcbiAgICAgICAgICAgICAgY2xvc2FibGVcclxuICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoeyAuLi5hbGVydENvbmZpZywgdmlzaWJpbGl0eTogZmFsc2UgfSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8QnJlYWRjcnVtYi8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+RW1wbG95ZWUgSW5jZW50aXZlPC9oMT5cclxuICAgICAgICAgICAgey8qIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRFZGl0SWQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShpbml0aWFsRm9ybSk7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICsgQWRkIEluY2VudGl2ZVxyXG4gICAgICAgICAgICA8L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7dGFibGVQYXltZW50cy5sZW5ndGggPD0gMCA/IChcclxuICAgICAgICAgICAgPEVtcHR5IGRlc2NyaXB0aW9uPVwiTm8gSW5jZW50aXZlIFBheW1lbnQgRGF0YSBGb3VuZFwiIC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgZGF0YT17dGFibGVQYXltZW50cy5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgICBpdGVtLmVtcGxveWVlTmFtZVxyXG4gICAgICAgICAgICAgICAgICA/LnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSksXHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPERyYXdlclxyXG4gICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJnLWJsdWUtMTAwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIHtlZGl0SWQgPyBcIkVkaXQgSW5jZW50aXZlIFBheW1lbnRcIiA6IFwiTmV3IEluY2VudGl2ZSBQYXltZW50XCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIG9wZW49e3Nob3dNb2RhbH1cclxuICAgICAgICAgIG9uQ2xvc2U9e2Nsb3NlRHJhd2VyfVxyXG4gICAgICAgICAgd2lkdGg9ezQ4MH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTYgcC0xXCI+XHJcbiAgICAgICAgICAgIHsvKiBFbXBsb3llZSBTZWxlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgRW1wbG95ZWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYW5kIHNlbGVjdCBlbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1wbG95ZWVfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImxhYmVsXCJcclxuICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbj8ubGFiZWw/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PlxyXG4gICAgICAgICAgICAgICAgICAvLyBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBlbXBsb3llZV9pZDogdmFsIH0pXHJcbiAgICAgICAgICAgICAgICAgIGZldGNoRW1wbG95ZWVJbmNlbnRpdmUodmFsKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2VtcC5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtcC5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9e2Ake2VtcC5uYW1lfSAke2VtcC5lbXBsb3llZUNvZGV9YH0gLy8g8J+UkSBzZWFyY2hhYmxlIHRleHRcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02IGgtNiBiZy1ibHVlLTEwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWJsdWUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2VtcC5uYW1lfSB8IHtlbXAuZW1wbG95ZWVDb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAge2Vycm9ycy5lbXBsb3llZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTEgYmctcmVkLTUwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1wbG95ZWV9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogUGF5bWVudCBEYXRlICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIDxGaUNhbGVuZGFyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBJbmNlbnRpdmUgTW9udGhcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmluY2VudGl2ZV9tb250aH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgaW5jZW50aXZlX21vbnRoOiBlLnRhcmdldC52YWx1ZSwgLy8gWVlZWS1NTSDinIVcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBBbW91bnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtNCB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHBsLTggcHItNCBweS0yLjUgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgYW1vdW50OiBlLnRhcmdldC52YWx1ZSB9KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHtmb3JtRGF0YS5hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgcm91bmRlZC1sZyBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGEuYW1vdW50KX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC0xIGJnLXJlZC01MDAgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudH1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgPEZpQ2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHBheV9kYXRlOiBlLnRhcmdldC52YWx1ZSB9KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBQYXltZW50IE1vZGUgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgPEZpQ3JlZGl0Q2FyZCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYXlfdHlwZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBwYXlfdHlwZTogdmFsIH0pfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY2FzaFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+Q2FzaDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJvbmxpbmVcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPk9ubGluZS9VUEk8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY2hlcXVlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5DaGVxdWU8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogVHJhbnNhY3Rpb24vQ2hlcXVlIElEICovfVxyXG4gICAgICAgICAgICB7Zm9ybURhdGEucGF5X3R5cGUgIT09IFwiY2FzaFwiICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiBhbmltYXRlLWZhZGVJblwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8RmlIYXNoIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5wYXlfdHlwZSA9PT0gXCJjaGVxdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJDaGVxdWUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwiVHJhbnNhY3Rpb24gSURcIn1cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1xyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLnBheV90eXBlID09PSBcImNoZXF1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiRW50ZXIgY2hlcXVlIG51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiRW50ZXIgdHJhbnNhY3Rpb24vVVBJIElEXCJcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCB0cmFuc2FjdGlvbl9pZDogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdWJtaXQgQnV0dG9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWJsdWUtNzAwIHRleHQtd2hpdGUgcHktMyByb3VuZGVkLWxnIGhvdmVyOmZyb20tYmx1ZS03MDAgaG92ZXI6dG8tYmx1ZS04MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGZvbnQtc2VtaWJvbGQgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2Zvcm0gaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2VkaXRJZCA/IFwiVXBkYXRlIEluY2VudGl2ZSBQYXltZW50XCIgOiBcIlNhdmUgSW5jZW50aXZlIFBheW1lbnRcIn1cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgPC9EcmF3ZXI+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFsbEVtcGxveWVlSW5jZW50aXZlczsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRW1wbG95ZWVJbmNlbnRpdmVQYXltZW50LmpzeCJ9