import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UnlinkEnrollment.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Select, Modal as AntModal, Input } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const { confirm } = AntModal;
const UnlinkEnrollment = () => {
  _s();
  const [activeTab, setActiveTab] = useState("linked");
  const [enrollments, setEnrollments] = useState([]);
  const [linkedEnrollments, setLinkedEnrollments] = useState([]);
  const [unlinkedEnrollments, setUnlinkedEnrollments] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [groups, setGroups] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [customerSearch, setCustomerSearch] = useState("");
  const [modifyPayment, setModifyPayment] = useState(false);
  const [selectedEnrollmentIds, setSelectedEnrollmentIds] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [linkedTotal, setLinkedTotal] = useState(0);
  const [unlinkedTotal, setUnlinkedTotal] = useState(0);
  const [users, setUsers] = useState([]);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info"
  });
  const currentData = activeTab === "linked" ? linkedEnrollments : unlinkedEnrollments;
  const getLoggedInUser = () => {
    try {
      return JSON.parse(localStorage.getItem("user") || "{}");
    } catch (error) {
      return {};
    }
  };
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        const userData = Array.isArray(response?.data?.data) ? response.data.data : Array.isArray(response?.data) ? response.data : [];
        setUsers(userData);
      } catch (error) {
        console.error("Error fetching user data:", error);
        setUsers([]);
      }
    };
    fetchUsers();
  }, [reloadTrigger]);
  const fetchEmployees = async () => {
    try {
      const response = await api.get("/agent/get-agent");
      const employeeData = Array.isArray(response?.data) ? response.data : response?.data?.data || [];
      setEmployees(employeeData);
    } catch (error) {
      console.error("Error fetching employees:", error);
      setEmployees([]);
    }
  };
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        const groupData = Array.isArray(response?.data?.data) ? response.data.data : Array.isArray(response?.data) ? response.data : [];
        setGroups(groupData);
      } catch (error) {
        console.error("Error fetching group data:", error);
        setGroups([]);
      }
    };
    fetchGroups();
  }, []);
  const fetchTotals = async () => {
    try {
      const [linkedResponse, unlinkedResponse] = await Promise.all(
        [
          api.get("/v1/admin/enrolls/link-enroll"),
          api.get("/v1/admin/enrolls/unlink-enroll")
        ]
      );
      let linkedData = Array.isArray(linkedResponse?.data?.data) ? linkedResponse.data.data : Array.isArray(linkedResponse?.data) ? linkedResponse.data : [];
      let unlinkedData = Array.isArray(unlinkedResponse?.data?.data) ? unlinkedResponse.data.data : Array.isArray(unlinkedResponse?.data) ? unlinkedResponse.data : [];
      setLinkedTotal(linkedData.length);
      setUnlinkedTotal(unlinkedData.length);
    } catch (error) {
      console.error("Error fetching totals:", error);
      setLinkedTotal(0);
      setUnlinkedTotal(0);
    }
  };
  const fetchEnrollments = async () => {
    try {
      setIsLoading(true);
      const endpoint = activeTab === "linked" ? "/v1/admin/enrolls/link-enroll" : "/v1/admin/enrolls/unlink-enroll";
      const params = new URLSearchParams();
      if (selectedEmployeeId) {
        params.append("empId", selectedEmployeeId);
      }
      if (selectedGroupId) {
        params.append("groupId", selectedGroupId);
      }
      if (selectedCustomerId) {
        params.append("customerId", selectedCustomerId);
      }
      const url = params.toString() ? `${endpoint}?${params.toString()}` : endpoint;
      const response = await api.get(url);
      const responseData = response?.data?.data ?? response?.data ?? [];
      const enrollmentList = Array.isArray(responseData) ? responseData : [];
      setEnrollments(enrollmentList);
      if (activeTab === "linked") {
        setLinkedEnrollments(enrollmentList);
      } else {
        setUnlinkedEnrollments(enrollmentList);
      }
    } catch (error) {
      console.error(`Error fetching ${activeTab} enrollments:`, error);
      setEnrollments([]);
      if (activeTab === "linked") {
        setLinkedEnrollments([]);
      } else {
        setUnlinkedEnrollments([]);
      }
    } finally {
      setIsLoading(false);
    }
  };
  const customerOptions = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    currentData.forEach((enrollment) => {
      const user = enrollment?.user_id;
      if (user?._id) {
        map.set(user._id, {
          id: user._id,
          name: user.full_name || "N/A",
          phone: user.phone_number || ""
        });
      }
    });
    users.forEach((user) => {
      const id = user?._id;
      if (id && !map.has(id)) {
        map.set(id, {
          id,
          name: user?.full_name || "N/A",
          phone: user?.phone_number || ""
        });
      }
    });
    return Array.from(map.values()).sort(
      (a, b) => `${a.name} ${a.phone}`.localeCompare(`${b.name} ${b.phone}`)
    );
  }, [currentData, users]);
  useEffect(() => {
    fetchEmployees();
    fetchTotals();
  }, [reloadTrigger]);
  useEffect(
    () => {
      fetchEnrollments();
    },
    [
      activeTab,
      selectedEmployeeId,
      selectedGroupId,
      selectedCustomerId,
      reloadTrigger
    ]
  );
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj) {
      const adminAccessPermissions = userObj.admin_access_right_id?.access_permissions;
      if (adminAccessPermissions?.unlink_enrollment === "true") {
        setModifyPayment(true);
      }
    }
  }, []);
  const employeeOptions = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    currentData.forEach((enrollment) => {
      const agent = enrollment?.agent;
      if (agent?._id) {
        map.set(agent._id, {
          id: agent._id,
          name: agent.name || "N/A",
          phone: agent.phone_number || ""
        });
      }
    });
    employees.forEach((employee) => {
      const id = employee?._id;
      if (id && !map.has(id)) {
        map.set(id, {
          id,
          name: employee?.name || "N/A",
          phone: employee?.phone_number || ""
        });
      }
    });
    return Array.from(map.values()).sort(
      (a, b) => `${a.name} ${a.phone}`.localeCompare(`${b.name} ${b.phone}`)
    );
  }, [currentData, employees]);
  const groupOptions = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    currentData.forEach((enrollment) => {
      const group = enrollment?.group_id;
      if (group?._id) {
        map.set(group._id, {
          id: group._id,
          name: group.group_name || "N/A"
        });
      }
    });
    groups.forEach((group) => {
      const id = group?._id;
      if (id && !map.has(id)) {
        map.set(id, {
          id,
          name: group?.group_name || "N/A"
        });
      }
    });
    return Array.from(map.values()).sort(
      (a, b) => a.name.localeCompare(b.name)
    );
  }, [currentData, groups]);
  const filteredData = useMemo(
    () => {
      let data = currentData;
      if (selectedEmployeeId) {
        data = data.filter((item) => item?.agent?._id === selectedEmployeeId);
      }
      if (selectedGroupId) {
        data = data.filter((item) => item?.group_id?._id === selectedGroupId);
      }
      if (selectedCustomerId) {
        data = data.filter((item) => item?.user_id?._id === selectedCustomerId);
      }
      if (customerSearch.trim()) {
        const searchTerm = customerSearch.trim().toLowerCase();
        data = data.filter((item) => {
          const name = (item?.user_id?.full_name || "").toLowerCase();
          const phone = (item?.user_id?.phone_number || "").toLowerCase();
          return name.includes(searchTerm) || phone.includes(searchTerm);
        });
      }
      return data;
    },
    [
      currentData,
      selectedEmployeeId,
      selectedGroupId,
      selectedCustomerId,
      customerSearch
    ]
  );
  const selectedEmployee = useMemo(() => {
    return employeeOptions.find(
      (employee) => employee.id === selectedEmployeeId
    );
  }, [employeeOptions, selectedEmployeeId]);
  const selectedGroup = useMemo(() => {
    return groupOptions.find((group) => group.id === selectedGroupId);
  }, [groupOptions, selectedGroupId]);
  const selectedCustomer = useMemo(() => {
    return customerOptions.find(
      (customer) => customer.id === selectedCustomerId
    );
  }, [customerOptions, selectedCustomerId]);
  const handleCheckboxChange = (item) => {
    const enrollmentId = item?._id;
    if (!enrollmentId) {
      return;
    }
    setSelectedEnrollmentIds((previousIds) => {
      if (previousIds.includes(enrollmentId)) {
        return previousIds.filter((id) => id !== enrollmentId);
      }
      return [...previousIds, enrollmentId];
    });
  };
  const handleSelectAllChange = (e) => {
    const checked = e.target.checked;
    if (checked) {
      const allIds = filteredData.map((item) => item?._id).filter(Boolean);
      setSelectedEnrollmentIds(allIds);
      setSelectAll(true);
    } else {
      setSelectedEnrollmentIds([]);
      setSelectAll(false);
    }
  };
  useEffect(() => {
    if (filteredData.length === 0) {
      setSelectAll(false);
      return;
    }
    const allSelected = filteredData.every(
      (item) => selectedEnrollmentIds.includes(item._id)
    );
    setSelectAll(allSelected);
  }, [filteredData, selectedEnrollmentIds]);
  useEffect(() => {
    setSelectedEnrollmentIds([]);
    setSelectAll(false);
  }, [activeTab, selectedEmployeeId, selectedGroupId, selectedCustomerId]);
  const tableData = useMemo(() => {
    const formatted = filteredData.map((enrollment, index) => {
      const enrollmentId = enrollment?._id;
      const isChecked = selectedEnrollmentIds.includes(enrollmentId);
      const checkbox = /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "checkbox",
          checked: isChecked,
          onChange: () => handleCheckboxChange(enrollment),
          className: "w-4 h-4 cursor-pointer accent-blue-600"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 451,
          columnNumber: 7
        },
        this
      );
      const linkStatus = activeTab === "linked" ? "Linked" : "Unlinked";
      return {
        ...enrollment,
        _id: enrollmentId,
        checkbox,
        id: index + 1,
        enroll_code: enrollment?.enroll_code || "N/A",
        customerName: enrollment?.user_id?.full_name || "N/A",
        customerMobile: enrollment?.user_id?.phone_number || "N/A",
        groupName: enrollment?.group_id?.group_name || "N/A",
        tickets: enrollment?.tickets ?? 0,
        prized: /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: `inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold ${enrollment?.is_prized ? "bg-amber-100 text-amber-800" : "bg-slate-100 text-slate-600"}`,
            children: enrollment?.is_prized ? "✓ Prized" : "Not Prized"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 478,
            columnNumber: 9
          },
          this
        ),
        employeeName: enrollment?.referred_agent?.name ? `${enrollment?.referred_agent?.name || "N/A"} | ${enrollment?.referred_agent?.phone_number || "N/A"}` : "N/A",
        totalPayable: enrollment?.total_payable || "0",
        totalInvestment: enrollment?.total_investment || "0",
        totalProfit: enrollment?.total_profit || "0",
        totalLateFee: enrollment?.total_late_fee || "0",
        totalPenalty: enrollment?.total_penalty || "0",
        relationshipManager: enrollment?.group_id?.relationship_manager?.name || "0",
        totalBalance: enrollment?.total_balance || "0",
        status: enrollment?.customer_status || "N/A",
        branchStatus: linkStatus,
        originalData: enrollment
      };
    }).filter(Boolean);
    return formatted;
  }, [filteredData, selectedEnrollmentIds, activeTab]);
  const unlinkEnrollColumns = [
    { key: "checkbox", header: "Select" },
    { key: "id", header: "SL. NO" },
    // { key: "enroll_code", header: "Enrollment Code" },
    { key: "customerName", header: "Customer Name" },
    { key: "customerMobile", header: "Customer Mobile" },
    { key: "groupName", header: "Group Name" },
    { key: "tickets", header: "Tickets" },
    { key: "prized", header: "Prized" },
    { key: "employeeName", header: "Employee | Mobile" },
    { key: "relationshipManager", header: "Relationship Manager" },
    { key: "totalLateFee", header: "Total Late Fee" },
    { key: "totalPenalty", header: "Total Penalty" },
    { key: "totalPayable", header: "Total Payable" },
    { key: "totalInvestment", header: "Total Paid" },
    { key: "totalBalance", header: "Total Balance" },
    { key: "status", header: "Status" },
    { key: "branchStatus", header: "Link Status" }
  ];
  const handleBulkAction = () => {
    if (!selectedEnrollmentIds.length) {
      setAlertConfig({
        visibility: true,
        message: `Please select at least one enrollment to ${activeTab === "linked" ? "unlink" : "link"}.`,
        type: "error"
      });
      return;
    }
    const action = activeTab === "linked" ? "unlink" : "link";
    confirm({
      title: action === "link" ? "Link Enrollments" : "Unlink Enrollments",
      content: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { className: "mb-2", children: [
          "Are you sure you want to ",
          /* @__PURE__ */ jsxDEV("strong", { children: action }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 552,
            columnNumber: 38
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("strong", { children: selectedEnrollmentIds.length }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 553,
            columnNumber: 13
          }, this),
          " enrollment(s)?"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 551,
          columnNumber: 11
        }, this),
        selectedEmployee && /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600", children: [
          "Employee: ",
          /* @__PURE__ */ jsxDEV("strong", { children: selectedEmployee.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 558,
            columnNumber: 25
          }, this),
          selectedEmployee.phone ? ` | ${selectedEmployee.phone}` : ""
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 557,
          columnNumber: 9
        }, this),
        selectedGroup && /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600", children: [
          "Group: ",
          /* @__PURE__ */ jsxDEV("strong", { children: selectedGroup.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 565,
            columnNumber: 22
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 564,
          columnNumber: 9
        }, this),
        selectedCustomer && /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600", children: [
          "Customer: ",
          /* @__PURE__ */ jsxDEV("strong", { children: selectedCustomer.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 571,
            columnNumber: 25
          }, this),
          selectedCustomer.phone ? ` | ${selectedCustomer.phone}` : ""
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 570,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
        lineNumber: 550,
        columnNumber: 7
      }, this),
      okText: action === "link" ? "Yes, Link" : "Yes, Unlink",
      cancelText: "Cancel",
      centered: true,
      okButtonProps: {
        danger: action === "unlink"
      },
      onOk: async () => {
        await performBulkAction(action);
      }
    });
  };
  const performBulkAction = async (action) => {
    setIsSubmitting(true);
    try {
      const payload = {
        enrollIds: selectedEnrollmentIds
      };
      const endpoint = action === "unlink" ? "/v1/admin/enrolls/unlink-branch" : "/v1/admin/enrolls/link-branch";
      await api.patch(endpoint, payload);
      setAlertConfig({
        visibility: true,
        message: action === "link" ? `${selectedEnrollmentIds.length} enrollment(s) linked successfully.` : `${selectedEnrollmentIds.length} enrollment(s) unlinked successfully.`,
        type: "success"
      });
      setSelectedEnrollmentIds([]);
      setSelectAll(false);
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      console.error(`Failed to ${action} enrollments:`, error);
      setAlertConfig({
        visibility: true,
        message: error?.response?.data?.message || `Failed to ${action} enrollments.`,
        type: "error"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setSelectedEmployeeId("");
    setSelectedGroupId("");
    setSelectedCustomerId("");
    setCustomerSearch("");
    setSelectedEnrollmentIds([]);
    setSelectAll(false);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
      lineNumber: 649,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
      lineNumber: 651,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({
          ...prev,
          visibility: false
        }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
        lineNumber: 653,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold text-gray-800", children: "Enrollment Link / Unlink" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 669,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Manage linked and unlinked enrollments in bulk." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 673,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
        lineNumber: 668,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
        lineNumber: 667,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
        lineNumber: 666,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 mb-5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex border-b border-gray-200", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => handleTabChange("linked"),
            className: `px-6 py-4 text-sm font-semibold transition-all flex items-center gap-2 ${activeTab === "linked" ? "text-blue-700 border-b-2 border-blue-700 bg-blue-50" : "text-gray-600 hover:text-blue-600"}`,
            children: [
              "Linked Enrollments",
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `px-2 py-0.5 text-xs rounded-full ${activeTab === "linked" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-600"}`,
                  children: linkedTotal
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                  lineNumber: 692,
                  columnNumber: 17
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 682,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => handleTabChange("unlinked"),
            className: `px-6 py-4 text-sm font-semibold transition-all flex items-center gap-2 ${activeTab === "unlinked" ? "text-red-700 border-b-2 border-red-700 bg-red-50" : "text-gray-600 hover:text-red-600"}`,
            children: [
              "Unlinked Enrollments",
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `px-2 py-0.5 text-xs rounded-full ${activeTab === "unlinked" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-600"}`,
                  children: unlinkedTotal
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                  lineNumber: 713,
                  columnNumber: 17
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 703,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
        lineNumber: 681,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
        lineNumber: 680,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-5 mb-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
              lineNumber: 730,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                allowClear: true,
                placeholder: "Select Group",
                className: "w-full",
                size: "large",
                value: selectedGroupId || void 0,
                onChange: (value) => {
                  setSelectedGroupId(value || "");
                },
                optionFilterProp: "children",
                filterOption: (input, option) => String(option?.children || "").toLowerCase().includes(input.toLowerCase()),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Groups" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                    lineNumber: 751,
                    columnNumber: 19
                  }, this),
                  groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group.id, children: group.name }, group.id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                      lineNumber: 754,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                lineNumber: 734,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 729,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
              lineNumber: 763,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                allowClear: true,
                placeholder: "Select Customer",
                className: "w-full",
                size: "large",
                value: selectedCustomerId || void 0,
                onChange: (value) => {
                  setSelectedCustomerId(value || "");
                },
                optionFilterProp: "children",
                filterOption: (input, option) => String(option?.children || "").toLowerCase().includes(input.toLowerCase()),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                    lineNumber: 783,
                    columnNumber: 19
                  }, this),
                  customerOptions.map(
                    (customer) => /* @__PURE__ */ jsxDEV(Select.Option, { value: customer.id, children: [
                      customer.name,
                      " ",
                      customer.phone ? `| ${customer.phone}` : ""
                    ] }, customer.id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                      lineNumber: 785,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                lineNumber: 766,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 762,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Employee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
              lineNumber: 795,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                allowClear: true,
                placeholder: "Select Employee",
                className: "w-full",
                size: "large",
                value: selectedEmployeeId || void 0,
                onChange: (value) => {
                  setSelectedEmployeeId(value || "");
                },
                optionFilterProp: "children",
                filterOption: (input, option) => String(option?.children || "").toLowerCase().includes(input.toLowerCase()),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Employees" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                    lineNumber: 816,
                    columnNumber: 19
                  }, this),
                  employeeOptions.map(
                    (employee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: employee.id, children: [
                      employee.name,
                      employee.phone ? ` | ${employee.phone}` : ""
                    ] }, employee.id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                      lineNumber: 819,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                lineNumber: 799,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 794,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-end justify-end gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: [
              "Selected:",
              " ",
              /* @__PURE__ */ jsxDEV("strong", { className: "text-gray-900", children: selectedEnrollmentIds.length }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                lineNumber: 831,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
              lineNumber: 829,
              columnNumber: 17
            }, this),
            modifyPayment && (activeTab === "linked" ? /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                disabled: isSubmitting || selectedEnrollmentIds.length === 0,
                onClick: handleBulkAction,
                className: "px-5 py-2.5 rounded-lg bg-red-600 text-white font-semibold hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition",
                children: isSubmitting ? "Processing..." : "Unlink Selected"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                lineNumber: 837,
                columnNumber: 17
              },
              this
            ) : /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                disabled: isSubmitting || selectedEnrollmentIds.length === 0,
                onClick: handleBulkAction,
                className: "px-5 py-2.5 rounded-lg bg-green-600 text-white font-semibold hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition",
                children: isSubmitting ? "Processing..." : "Link Selected"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
                lineNumber: 848,
                columnNumber: 17
              },
              this
            ))
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 828,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 727,
          columnNumber: 13
        }, this),
        (selectedEmployeeId || selectedGroupId || selectedCustomerId) && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 px-4 py-3 rounded-lg bg-blue-50 border border-blue-100 text-sm text-blue-800 flex flex-wrap gap-3", children: [
          selectedEmployeeId && /* @__PURE__ */ jsxDEV("span", { children: [
            "Employee:",
            " ",
            /* @__PURE__ */ jsxDEV("strong", { children: selectedEmployee?.name || "Selected Employee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
              lineNumber: 868,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 866,
            columnNumber: 15
          }, this),
          selectedGroupId && /* @__PURE__ */ jsxDEV("span", { children: [
            "Group:",
            " ",
            /* @__PURE__ */ jsxDEV("strong", { children: selectedGroup?.name || "Selected Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
              lineNumber: 876,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 874,
            columnNumber: 15
          }, this),
          selectedCustomerId && /* @__PURE__ */ jsxDEV("span", { children: [
            "Customer:",
            " ",
            /* @__PURE__ */ jsxDEV("strong", { children: selectedCustomer?.name || "Selected Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
              lineNumber: 882,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 880,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 864,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
        lineNumber: 726,
        columnNumber: 11
      }, this),
      !isLoading && tableData.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              className: "w-4 h-4 cursor-pointer accent-blue-600",
              checked: selectAll,
              onChange: handleSelectAllChange
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
              lineNumber: 895,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: selectAll ? "Deselect All" : "Select All" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
            lineNumber: 902,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 894,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500", children: [
          selectedEnrollmentIds.length,
          " of ",
          tableData.length,
          " selected"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 907,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
        lineNumber: 893,
        columnNumber: 11
      }, this),
      isLoading ? /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading: true,
          failure: false,
          data: "Enrollment Data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 915,
          columnNumber: 11
        },
        this
      ) : tableData.length > 0 ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: tableData,
          columns: unlinkEnrollColumns,
          catcher: "_id",
          isExportEnabled: true,
          isSearchRequired: true,
          exportedPdfName: activeTab === "linked" ? "Linked Enrollments" : "Unlinked Enrollments",
          exportedFileName: activeTab === "linked" ? "LinkedEnrollments.csv" : "UnlinkedEnrollments.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 921,
          columnNumber: 11
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading: false,
          failure: true,
          data: activeTab === "linked" ? "Linked Enrollments" : "Unlinked Enrollments"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
          lineNumber: 939,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
      lineNumber: 665,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
    lineNumber: 648,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx",
    lineNumber: 647,
    columnNumber: 5
  }, this);
};
_s(UnlinkEnrollment, "5eDKYhm/IIZjtTcCCPUdOmckHYI=");
_c = UnlinkEnrollment;
export default UnlinkEnrollment;
var _c;
$RefreshReg$(_c, "UnlinkEnrollment");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnlinkEnrollment.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa2NVLFNBb01OLFVBcE1NOzJCQWxjVjtBQUFnQkEsTUFBV0MsY0FBU0MsT0FBUSxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MsUUFBUUMsU0FBU0MsVUFBVUMsYUFBYTtBQUVqRCxNQUFNLEVBQUVDLFFBQVEsSUFBSUY7QUFFcEIsTUFBTUcsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlmLFNBQVMsUUFBUTtBQUNuRCxRQUFNLENBQUNnQixhQUFhQyxjQUFjLElBQUlqQixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDa0IsbUJBQW1CQyxvQkFBb0IsSUFBSW5CLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNvQixxQkFBcUJDLHNCQUFzQixJQUFJckIsU0FBUyxFQUFFO0FBRWpFLFFBQU0sQ0FBQ3NCLFdBQVdDLFlBQVksSUFBSXZCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUN3QixRQUFRQyxTQUFTLElBQUl6QixTQUFTLEVBQUU7QUFFdkMsUUFBTSxDQUFDMEIsb0JBQW9CQyxxQkFBcUIsSUFBSTNCLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUM0QixpQkFBaUJDLGtCQUFrQixJQUFJN0IsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQzhCLG9CQUFvQkMscUJBQXFCLElBQUkvQixTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDZ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSWpDLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNrQyxlQUFlQyxnQkFBZ0IsSUFBSW5DLFNBQVMsS0FBSztBQUd4RCxRQUFNLENBQUNvQyx1QkFBdUJDLHdCQUF3QixJQUFJckMsU0FBUyxFQUFFO0FBR3JFLFFBQU0sQ0FBQ3NDLFdBQVdDLFlBQVksSUFBSXZDLFNBQVMsS0FBSztBQUVoRCxRQUFNLENBQUN3QyxXQUFXQyxZQUFZLElBQUl6QyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDMEMsY0FBY0MsZUFBZSxJQUFJM0MsU0FBUyxLQUFLO0FBRXRELFFBQU0sQ0FBQzRDLGVBQWVDLGdCQUFnQixJQUFJN0MsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQzhDLGFBQWFDLGNBQWMsSUFBSS9DLFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUNnRCxlQUFlQyxnQkFBZ0IsSUFBSWpELFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUNrRCxPQUFPQyxRQUFRLElBQUluRCxTQUFTLEVBQUU7QUFFckMsUUFBTSxDQUFDb0QsYUFBYUMsY0FBYyxJQUFJckQsU0FBUztBQUFBLElBQzdDc0QsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBR0QsUUFBTUMsY0FDSjNDLGNBQWMsV0FBV0ksb0JBQW9CRTtBQUcvQyxRQUFNc0Msa0JBQWtCQSxNQUFNO0FBQzVCLFFBQUk7QUFDRixhQUFPQyxLQUFLQyxNQUFNQyxhQUFhQyxRQUFRLE1BQU0sS0FBSyxJQUFJO0FBQUEsSUFDeEQsU0FBU0MsT0FBTztBQUNkLGFBQU8sQ0FBQztBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBR0FqRSxZQUFVLE1BQU07QUFDZCxVQUFNa0UsYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU03RCxJQUFJOEQsSUFBSSxnQkFBZ0I7QUFDL0MsY0FBTUMsV0FBV0MsTUFBTUMsUUFBUUosVUFBVUssTUFBTUEsSUFBSSxJQUMvQ0wsU0FBU0ssS0FBS0EsT0FDZEYsTUFBTUMsUUFBUUosVUFBVUssSUFBSSxJQUMxQkwsU0FBU0ssT0FDVDtBQUNObkIsaUJBQVNnQixRQUFRO0FBQUEsTUFDbkIsU0FBU0osT0FBTztBQUNkUSxnQkFBUVIsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaERaLGlCQUFTLEVBQUU7QUFBQSxNQUNiO0FBQUEsSUFDRjtBQUNBYSxlQUFXO0FBQUEsRUFDYixHQUFHLENBQUNwQixhQUFhLENBQUM7QUFHbEIsUUFBTTRCLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRixZQUFNUCxXQUFXLE1BQU03RCxJQUFJOEQsSUFBSSxrQkFBa0I7QUFFakQsWUFBTU8sZUFBZUwsTUFBTUMsUUFBUUosVUFBVUssSUFBSSxJQUM3Q0wsU0FBU0ssT0FDVEwsVUFBVUssTUFBTUEsUUFBUTtBQUU1Qi9DLG1CQUFha0QsWUFBWTtBQUFBLElBQzNCLFNBQVNWLE9BQU87QUFDZFEsY0FBUVIsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaER4QyxtQkFBYSxFQUFFO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBR0F6QixZQUFVLE1BQU07QUFDZCxVQUFNNEUsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNVCxXQUFXLE1BQU03RCxJQUFJOEQsSUFBSSx3QkFBd0I7QUFDdkQsY0FBTVMsWUFBWVAsTUFBTUMsUUFBUUosVUFBVUssTUFBTUEsSUFBSSxJQUNoREwsU0FBU0ssS0FBS0EsT0FDZEYsTUFBTUMsUUFBUUosVUFBVUssSUFBSSxJQUMxQkwsU0FBU0ssT0FDVDtBQUNON0Msa0JBQVVrRCxTQUFTO0FBQUEsTUFDckIsU0FBU1osT0FBTztBQUNkUSxnQkFBUVIsTUFBTSw4QkFBOEJBLEtBQUs7QUFDakR0QyxrQkFBVSxFQUFFO0FBQUEsTUFDZDtBQUFBLElBQ0Y7QUFDQWlELGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFHTCxRQUFNRSxjQUFjLFlBQVk7QUFDOUIsUUFBSTtBQUNGLFlBQU0sQ0FBQ0MsZ0JBQWdCQyxnQkFBZ0IsSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDM0Q1RSxJQUFJOEQsSUFBSSwrQkFBK0I7QUFBQSxVQUN2QzlELElBQUk4RCxJQUFJLGlDQUFpQztBQUFBLFFBQUM7QUFBQSxNQUMzQztBQUVELFVBQUllLGFBQWFiLE1BQU1DLFFBQVFRLGdCQUFnQlAsTUFBTUEsSUFBSSxJQUNyRE8sZUFBZVAsS0FBS0EsT0FDcEJGLE1BQU1DLFFBQVFRLGdCQUFnQlAsSUFBSSxJQUNoQ08sZUFBZVAsT0FDZjtBQUVOLFVBQUlZLGVBQWVkLE1BQU1DLFFBQVFTLGtCQUFrQlIsTUFBTUEsSUFBSSxJQUN6RFEsaUJBQWlCUixLQUFLQSxPQUN0QkYsTUFBTUMsUUFBUVMsa0JBQWtCUixJQUFJLElBQ2xDUSxpQkFBaUJSLE9BQ2pCO0FBT052QixxQkFBZWtDLFdBQVdFLE1BQU07QUFDaENsQyx1QkFBaUJpQyxhQUFhQyxNQUFNO0FBQUEsSUFDdEMsU0FBU3BCLE9BQU87QUFDZFEsY0FBUVIsTUFBTSwwQkFBMEJBLEtBQUs7QUFDN0NoQixxQkFBZSxDQUFDO0FBQ2hCRSx1QkFBaUIsQ0FBQztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBLFFBQU1tQyxtQkFBbUIsWUFBWTtBQUNuQyxRQUFJO0FBQ0YzQyxtQkFBYSxJQUFJO0FBR2pCLFlBQU00QyxXQUNKdkUsY0FBYyxXQUNWLGtDQUNBO0FBR04sWUFBTXdFLFNBQVMsSUFBSUMsZ0JBQWdCO0FBQ25DLFVBQUk3RCxvQkFBb0I7QUFDdEI0RCxlQUFPRSxPQUFPLFNBQVM5RCxrQkFBa0I7QUFBQSxNQUMzQztBQUNBLFVBQUlFLGlCQUFpQjtBQUNuQjBELGVBQU9FLE9BQU8sV0FBVzVELGVBQWU7QUFBQSxNQUMxQztBQUNBLFVBQUlFLG9CQUFvQjtBQUN0QndELGVBQU9FLE9BQU8sY0FBYzFELGtCQUFrQjtBQUFBLE1BQ2hEO0FBRUEsWUFBTTJELE1BQU1ILE9BQU9JLFNBQVMsSUFDeEIsR0FBR0wsUUFBUSxJQUFJQyxPQUFPSSxTQUFTLENBQUMsS0FDaENMO0FBRUosWUFBTXBCLFdBQVcsTUFBTTdELElBQUk4RCxJQUFJdUIsR0FBRztBQUVsQyxZQUFNRSxlQUFlMUIsVUFBVUssTUFBTUEsUUFBUUwsVUFBVUssUUFBUTtBQUUvRCxZQUFNc0IsaUJBQWlCeEIsTUFBTUMsUUFBUXNCLFlBQVksSUFBSUEsZUFBZTtBQUVwRTFFLHFCQUFlMkUsY0FBYztBQUc3QixVQUFJOUUsY0FBYyxVQUFVO0FBQzFCSyw2QkFBcUJ5RSxjQUFjO0FBQUEsTUFDckMsT0FBTztBQUNMdkUsK0JBQXVCdUUsY0FBYztBQUFBLE1BQ3ZDO0FBQUEsSUFDRixTQUFTN0IsT0FBTztBQUNkUSxjQUFRUixNQUFNLGtCQUFrQmpELFNBQVMsaUJBQWlCaUQsS0FBSztBQUMvRDlDLHFCQUFlLEVBQUU7QUFDakIsVUFBSUgsY0FBYyxVQUFVO0FBQzFCSyw2QkFBcUIsRUFBRTtBQUFBLE1BQ3pCLE9BQU87QUFDTEUsK0JBQXVCLEVBQUU7QUFBQSxNQUMzQjtBQUFBLElBQ0YsVUFBQztBQUNDb0IsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBLFFBQU1vRCxrQkFBa0I5RixRQUFRLE1BQU07QUFDcEMsVUFBTStGLE1BQU0sb0JBQUlDLElBQUk7QUFHcEJ0QyxnQkFBWXVDLFFBQVEsQ0FBQ0MsZUFBZTtBQUNsQyxZQUFNQyxPQUFPRCxZQUFZRTtBQUN6QixVQUFJRCxNQUFNRSxLQUFLO0FBQ2JOLFlBQUlPLElBQUlILEtBQUtFLEtBQUs7QUFBQSxVQUNoQkUsSUFBSUosS0FBS0U7QUFBQUEsVUFDVEcsTUFBTUwsS0FBS00sYUFBYTtBQUFBLFVBQ3hCQyxPQUFPUCxLQUFLUSxnQkFBZ0I7QUFBQSxRQUM5QixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsQ0FBQztBQUdEeEQsVUFBTThDLFFBQVEsQ0FBQ0UsU0FBUztBQUN0QixZQUFNSSxLQUFLSixNQUFNRTtBQUNqQixVQUFJRSxNQUFNLENBQUNSLElBQUlhLElBQUlMLEVBQUUsR0FBRztBQUN0QlIsWUFBSU8sSUFBSUMsSUFBSTtBQUFBLFVBQ1ZBO0FBQUFBLFVBQ0FDLE1BQU1MLE1BQU1NLGFBQWE7QUFBQSxVQUN6QkMsT0FBT1AsTUFBTVEsZ0JBQWdCO0FBQUEsUUFDL0IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLENBQUM7QUFFRCxXQUFPdEMsTUFBTXdDLEtBQUtkLElBQUllLE9BQU8sQ0FBQyxFQUFFQztBQUFBQSxNQUFLLENBQUNDLEdBQUdDLE1BQ3ZDLEdBQUdELEVBQUVSLElBQUksSUFBSVEsRUFBRU4sS0FBSyxHQUFHUSxjQUFjLEdBQUdELEVBQUVULElBQUksSUFBSVMsRUFBRVAsS0FBSyxFQUFFO0FBQUEsSUFDN0Q7QUFBQSxFQUNGLEdBQUcsQ0FBQ2hELGFBQWFQLEtBQUssQ0FBQztBQUd2QnBELFlBQVUsTUFBTTtBQUNkMEUsbUJBQWU7QUFDZkksZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQ2hDLGFBQWEsQ0FBQztBQUdsQjlDO0FBQUFBLElBQVUsTUFBTTtBQUNkc0YsdUJBQWlCO0FBQUEsSUFDbkI7QUFBQSxJQUFHO0FBQUEsTUFDRHRFO0FBQUFBLE1BQ0FZO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FjO0FBQUFBLElBQWE7QUFBQSxFQUNkO0FBRUQ5QyxZQUFVLE1BQU07QUFDZCxVQUFNb0csT0FBT3JDLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNb0QsVUFBVXZELEtBQUtDLE1BQU1zQyxJQUFJO0FBRS9CLFFBQUlnQixTQUFTO0FBQ1gsWUFBTUMseUJBQ0pELFFBQVFFLHVCQUF1QkM7QUFFakMsVUFBSUYsd0JBQXdCRyxzQkFBc0IsUUFBUTtBQUN4RG5GLHlCQUFpQixJQUFJO0FBQUEsTUFDdkI7QUFBQSxJQU1GO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFHTCxRQUFNb0Ysa0JBQWtCeEgsUUFBUSxNQUFNO0FBQ3BDLFVBQU0rRixNQUFNLG9CQUFJQyxJQUFJO0FBRXBCdEMsZ0JBQVl1QyxRQUFRLENBQUNDLGVBQWU7QUFDbEMsWUFBTXVCLFFBQVF2QixZQUFZdUI7QUFFMUIsVUFBSUEsT0FBT3BCLEtBQUs7QUFDZE4sWUFBSU8sSUFBSW1CLE1BQU1wQixLQUFLO0FBQUEsVUFDakJFLElBQUlrQixNQUFNcEI7QUFBQUEsVUFDVkcsTUFBTWlCLE1BQU1qQixRQUFRO0FBQUEsVUFDcEJFLE9BQU9lLE1BQU1kLGdCQUFnQjtBQUFBLFFBQy9CLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixDQUFDO0FBR0RwRixjQUFVMEUsUUFBUSxDQUFDeUIsYUFBYTtBQUM5QixZQUFNbkIsS0FBS21CLFVBQVVyQjtBQUVyQixVQUFJRSxNQUFNLENBQUNSLElBQUlhLElBQUlMLEVBQUUsR0FBRztBQUN0QlIsWUFBSU8sSUFBSUMsSUFBSTtBQUFBLFVBQ1ZBO0FBQUFBLFVBQ0FDLE1BQU1rQixVQUFVbEIsUUFBUTtBQUFBLFVBQ3hCRSxPQUFPZ0IsVUFBVWYsZ0JBQWdCO0FBQUEsUUFDbkMsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLENBQUM7QUFFRCxXQUFPdEMsTUFBTXdDLEtBQUtkLElBQUllLE9BQU8sQ0FBQyxFQUFFQztBQUFBQSxNQUFLLENBQUNDLEdBQUdDLE1BQ3ZDLEdBQUdELEVBQUVSLElBQUksSUFBSVEsRUFBRU4sS0FBSyxHQUFHUSxjQUFjLEdBQUdELEVBQUVULElBQUksSUFBSVMsRUFBRVAsS0FBSyxFQUFFO0FBQUEsSUFDN0Q7QUFBQSxFQUNGLEdBQUcsQ0FBQ2hELGFBQWFuQyxTQUFTLENBQUM7QUFHM0IsUUFBTW9HLGVBQWUzSCxRQUFRLE1BQU07QUFDakMsVUFBTStGLE1BQU0sb0JBQUlDLElBQUk7QUFFcEJ0QyxnQkFBWXVDLFFBQVEsQ0FBQ0MsZUFBZTtBQUNsQyxZQUFNMEIsUUFBUTFCLFlBQVkyQjtBQUUxQixVQUFJRCxPQUFPdkIsS0FBSztBQUNkTixZQUFJTyxJQUFJc0IsTUFBTXZCLEtBQUs7QUFBQSxVQUNqQkUsSUFBSXFCLE1BQU12QjtBQUFBQSxVQUNWRyxNQUFNb0IsTUFBTUUsY0FBYztBQUFBLFFBQzVCLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixDQUFDO0FBR0RyRyxXQUFPd0UsUUFBUSxDQUFDMkIsVUFBVTtBQUN4QixZQUFNckIsS0FBS3FCLE9BQU92QjtBQUVsQixVQUFJRSxNQUFNLENBQUNSLElBQUlhLElBQUlMLEVBQUUsR0FBRztBQUN0QlIsWUFBSU8sSUFBSUMsSUFBSTtBQUFBLFVBQ1ZBO0FBQUFBLFVBQ0FDLE1BQU1vQixPQUFPRSxjQUFjO0FBQUEsUUFDN0IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLENBQUM7QUFFRCxXQUFPekQsTUFBTXdDLEtBQUtkLElBQUllLE9BQU8sQ0FBQyxFQUFFQztBQUFBQSxNQUFLLENBQUNDLEdBQUdDLE1BQ3ZDRCxFQUFFUixLQUFLVSxjQUFjRCxFQUFFVCxJQUFJO0FBQUEsSUFDN0I7QUFBQSxFQUNGLEdBQUcsQ0FBQzlDLGFBQWFqQyxNQUFNLENBQUM7QUFHeEIsUUFBTXNHLGVBQWUvSDtBQUFBQSxJQUFRLE1BQU07QUFDakMsVUFBSXVFLE9BQU9iO0FBRVgsVUFBSS9CLG9CQUFvQjtBQUN0QjRDLGVBQU9BLEtBQUt5RCxPQUFPLENBQUNDLFNBQVNBLE1BQU1SLE9BQU9wQixRQUFRMUUsa0JBQWtCO0FBQUEsTUFDdEU7QUFFQSxVQUFJRSxpQkFBaUI7QUFDbkIwQyxlQUFPQSxLQUFLeUQsT0FBTyxDQUFDQyxTQUFTQSxNQUFNSixVQUFVeEIsUUFBUXhFLGVBQWU7QUFBQSxNQUN0RTtBQUVBLFVBQUlFLG9CQUFvQjtBQUN0QndDLGVBQU9BLEtBQUt5RCxPQUFPLENBQUNDLFNBQVNBLE1BQU03QixTQUFTQyxRQUFRdEUsa0JBQWtCO0FBQUEsTUFDeEU7QUFHQSxVQUFJRSxlQUFlaUcsS0FBSyxHQUFHO0FBQ3pCLGNBQU1DLGFBQWFsRyxlQUFlaUcsS0FBSyxFQUFFRSxZQUFZO0FBQ3JEN0QsZUFBT0EsS0FBS3lELE9BQU8sQ0FBQ0MsU0FBUztBQUMzQixnQkFBTXpCLFFBQVF5QixNQUFNN0IsU0FBU0ssYUFBYSxJQUFJMkIsWUFBWTtBQUMxRCxnQkFBTTFCLFNBQVN1QixNQUFNN0IsU0FBU08sZ0JBQWdCLElBQUl5QixZQUFZO0FBQzlELGlCQUFPNUIsS0FBSzZCLFNBQVNGLFVBQVUsS0FBS3pCLE1BQU0yQixTQUFTRixVQUFVO0FBQUEsUUFDL0QsQ0FBQztBQUFBLE1BQ0g7QUFFQSxhQUFPNUQ7QUFBQUEsSUFDVDtBQUFBLElBQUc7QUFBQSxNQUNEYjtBQUFBQSxNQUNBL0I7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsSUFBYztBQUFBLEVBQ2Y7QUFHRCxRQUFNcUcsbUJBQW1CdEksUUFBUSxNQUFNO0FBQ3JDLFdBQU93SCxnQkFBZ0JlO0FBQUFBLE1BQ3JCLENBQUNiLGFBQWFBLFNBQVNuQixPQUFPNUU7QUFBQUEsSUFDaEM7QUFBQSxFQUNGLEdBQUcsQ0FBQzZGLGlCQUFpQjdGLGtCQUFrQixDQUFDO0FBR3hDLFFBQU02RyxnQkFBZ0J4SSxRQUFRLE1BQU07QUFDbEMsV0FBTzJILGFBQWFZLEtBQUssQ0FBQ1gsVUFBVUEsTUFBTXJCLE9BQU8xRSxlQUFlO0FBQUEsRUFDbEUsR0FBRyxDQUFDOEYsY0FBYzlGLGVBQWUsQ0FBQztBQUdsQyxRQUFNNEcsbUJBQW1CekksUUFBUSxNQUFNO0FBQ3JDLFdBQU84RixnQkFBZ0J5QztBQUFBQSxNQUNyQixDQUFDRyxhQUFhQSxTQUFTbkMsT0FBT3hFO0FBQUFBLElBQ2hDO0FBQUEsRUFDRixHQUFHLENBQUMrRCxpQkFBaUIvRCxrQkFBa0IsQ0FBQztBQUd4QyxRQUFNNEcsdUJBQXVCQSxDQUFDVixTQUFTO0FBQ3JDLFVBQU1XLGVBQWVYLE1BQU01QjtBQUUzQixRQUFJLENBQUN1QyxjQUFjO0FBQ2pCO0FBQUEsSUFDRjtBQUVBdEcsNkJBQXlCLENBQUN1RyxnQkFBZ0I7QUFDeEMsVUFBSUEsWUFBWVIsU0FBU08sWUFBWSxHQUFHO0FBQ3RDLGVBQU9DLFlBQVliLE9BQU8sQ0FBQ3pCLE9BQU9BLE9BQU9xQyxZQUFZO0FBQUEsTUFDdkQ7QUFFQSxhQUFPLENBQUMsR0FBR0MsYUFBYUQsWUFBWTtBQUFBLElBQ3RDLENBQUM7QUFBQSxFQUNIO0FBR0EsUUFBTUUsd0JBQXdCQSxDQUFDQyxNQUFNO0FBQ25DLFVBQU1DLFVBQVVELEVBQUVFLE9BQU9EO0FBRXpCLFFBQUlBLFNBQVM7QUFDWCxZQUFNRSxTQUFTbkIsYUFBYWhDLElBQUksQ0FBQ2tDLFNBQVNBLE1BQU01QixHQUFHLEVBQUUyQixPQUFPbUIsT0FBTztBQUVuRTdHLCtCQUF5QjRHLE1BQU07QUFDL0IxRyxtQkFBYSxJQUFJO0FBQUEsSUFDbkIsT0FBTztBQUNMRiwrQkFBeUIsRUFBRTtBQUMzQkUsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBekMsWUFBVSxNQUFNO0FBQ2QsUUFBSWdJLGFBQWEzQyxXQUFXLEdBQUc7QUFDN0I1QyxtQkFBYSxLQUFLO0FBQ2xCO0FBQUEsSUFDRjtBQUVBLFVBQU00RyxjQUFjckIsYUFBYXNCO0FBQUFBLE1BQU0sQ0FBQ3BCLFNBQ3RDNUYsc0JBQXNCZ0csU0FBU0osS0FBSzVCLEdBQUc7QUFBQSxJQUN6QztBQUVBN0QsaUJBQWE0RyxXQUFXO0FBQUEsRUFDMUIsR0FBRyxDQUFDckIsY0FBYzFGLHFCQUFxQixDQUFDO0FBR3hDdEMsWUFBVSxNQUFNO0FBQ2R1Qyw2QkFBeUIsRUFBRTtBQUMzQkUsaUJBQWEsS0FBSztBQUFBLEVBQ3BCLEdBQUcsQ0FBQ3pCLFdBQVdZLG9CQUFvQkUsaUJBQWlCRSxrQkFBa0IsQ0FBQztBQUd2RSxRQUFNdUgsWUFBWXRKLFFBQVEsTUFBTTtBQUM5QixVQUFNdUosWUFBWXhCLGFBQ2ZoQyxJQUFJLENBQUNHLFlBQVlzRCxVQUFVO0FBQzFCLFlBQU1aLGVBQWUxQyxZQUFZRztBQUNqQyxZQUFNb0QsWUFBWXBILHNCQUFzQmdHLFNBQVNPLFlBQVk7QUFFN0QsWUFBTWMsV0FDSjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBU0Q7QUFBQUEsVUFDVCxVQUFVLE1BQU1kLHFCQUFxQnpDLFVBQVU7QUFBQSxVQUMvQyxXQUFVO0FBQUE7QUFBQSxRQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlvRDtBQUt0RCxZQUFNeUQsYUFBYTVJLGNBQWMsV0FBVyxXQUFXO0FBT3ZELGFBQU87QUFBQSxRQUNMLEdBQUdtRjtBQUFBQSxRQUNIRyxLQUFLdUM7QUFBQUEsUUFDTGM7QUFBQUEsUUFDQW5ELElBQUlpRCxRQUFRO0FBQUEsUUFDWkksYUFBYTFELFlBQVkwRCxlQUFlO0FBQUEsUUFDeENDLGNBQWMzRCxZQUFZRSxTQUFTSyxhQUFhO0FBQUEsUUFDaERxRCxnQkFBZ0I1RCxZQUFZRSxTQUFTTyxnQkFBZ0I7QUFBQSxRQUNyRG9ELFdBQVc3RCxZQUFZMkIsVUFBVUMsY0FBYztBQUFBLFFBQy9Da0MsU0FBUzlELFlBQVk4RCxXQUFXO0FBQUEsUUFDaENDLFFBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVcsK0VBQ1QvRCxZQUFZZ0UsWUFDUixnQ0FDQSw2QkFBNkI7QUFBQSxZQUdsQ2hFLHNCQUFZZ0UsWUFBWSxhQUFhO0FBQUE7QUFBQSxVQVB4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBRUZDLGNBQWNqRSxZQUFZa0UsZ0JBQWdCNUQsT0FDdEMsR0FBR04sWUFBWWtFLGdCQUFnQjVELFFBQVEsS0FBSyxNQUFNTixZQUFZa0UsZ0JBQWdCekQsZ0JBQWUsS0FBSyxLQUNsRztBQUFBLFFBQ0owRCxjQUFjbkUsWUFBWW9FLGlCQUFpQjtBQUFBLFFBQzNDQyxpQkFBaUJyRSxZQUFZc0Usb0JBQW9CO0FBQUEsUUFDakRDLGFBQWF2RSxZQUFZd0UsZ0JBQWdCO0FBQUEsUUFDekNDLGNBQWN6RSxZQUFZMEUsa0JBQWtCO0FBQUEsUUFDNUNDLGNBQWMzRSxZQUFZNEUsaUJBQWlCO0FBQUEsUUFDM0NDLHFCQUFxQjdFLFlBQVkyQixVQUFVbUQsc0JBQXNCeEUsUUFBUTtBQUFBLFFBQ3pFeUUsY0FBYy9FLFlBQVlnRixpQkFBaUI7QUFBQSxRQUMzQ0MsUUFBUWpGLFlBQVlrRixtQkFBbUI7QUFBQSxRQUN2Q0MsY0FBYzFCO0FBQUFBLFFBQ2QyQixjQUFjcEY7QUFBQUEsTUFDaEI7QUFBQSxJQUNGLENBQUMsRUFDQThCLE9BQU9tQixPQUFPO0FBRWpCLFdBQU9JO0FBQUFBLEVBQ1QsR0FBRyxDQUFDeEIsY0FBYzFGLHVCQUF1QnRCLFNBQVMsQ0FBQztBQUduRCxRQUFNd0ssc0JBQXNCO0FBQUEsSUFDMUIsRUFBRUMsS0FBSyxZQUFZQyxRQUFRLFNBQVM7QUFBQSxJQUNwQyxFQUFFRCxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBO0FBQUEsSUFFOUIsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEsa0JBQWtCO0FBQUEsSUFDbkQsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsb0JBQW9CO0FBQUEsSUFDbkQsRUFBRUQsS0FBSyx1QkFBdUJDLFFBQVEsdUJBQXVCO0FBQUEsSUFDN0QsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsaUJBQWlCO0FBQUEsSUFDaEQsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsYUFBYTtBQUFBLElBQy9DLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGdCQUFnQjtBQUFBLElBRS9DLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsY0FBYztBQUFBLEVBQUM7QUFJaEQsUUFBTUMsbUJBQW1CQSxNQUFNO0FBQzdCLFFBQUksQ0FBQ3JKLHNCQUFzQitDLFFBQVE7QUFDakM5QixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTLDRDQUNQekMsY0FBYyxXQUFXLFdBQVcsTUFBTTtBQUFBLFFBRTVDMEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUVEO0FBQUEsSUFDRjtBQUVBLFVBQU1rSSxTQUFTNUssY0FBYyxXQUFXLFdBQVc7QUFFbkRILFlBQVE7QUFBQSxNQUNOZ0wsT0FBT0QsV0FBVyxTQUFTLHFCQUFxQjtBQUFBLE1BRWhERSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxPQUFFLFdBQVUsUUFBTztBQUFBO0FBQUEsVUFDTyx1QkFBQyxZQUFRRixvQkFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLFVBQVU7QUFBQSxVQUNuRCx1QkFBQyxZQUFRdEosZ0NBQXNCK0MsVUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUFTO0FBQUEsYUFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQ2tELG9CQUNDLHVCQUFDLE9BQUUsV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLFVBQ2pCLHVCQUFDLFlBQVFBLDJCQUFpQjlCLFFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsVUFDeEM4QixpQkFBaUI1QixRQUFRLE1BQU00QixpQkFBaUI1QixLQUFLLEtBQUs7QUFBQSxhQUY3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUdEOEIsaUJBQ0MsdUJBQUMsT0FBRSxXQUFVLGlCQUFnQjtBQUFBO0FBQUEsVUFDcEIsdUJBQUMsWUFBUUEsd0JBQWNoQyxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLGFBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0RpQyxvQkFDQyx1QkFBQyxPQUFFLFdBQVUsaUJBQWdCO0FBQUE7QUFBQSxVQUNqQix1QkFBQyxZQUFRQSwyQkFBaUJqQyxRQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQjtBQUFBLFVBQ3hDaUMsaUJBQWlCL0IsUUFBUSxNQUFNK0IsaUJBQWlCL0IsS0FBSyxLQUFLO0FBQUEsYUFGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0F2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLE1BR0ZvRixRQUFRSCxXQUFXLFNBQVMsY0FBYztBQUFBLE1BQzFDSSxZQUFZO0FBQUEsTUFFWkMsVUFBVTtBQUFBLE1BRVZDLGVBQWU7QUFBQSxRQUNiQyxRQUFRUCxXQUFXO0FBQUEsTUFDckI7QUFBQSxNQUVBUSxNQUFNLFlBQVk7QUFDaEIsY0FBTUMsa0JBQWtCVCxNQUFNO0FBQUEsTUFDaEM7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBR0EsUUFBTVMsb0JBQW9CLE9BQU9ULFdBQVc7QUFDMUMvSSxvQkFBZ0IsSUFBSTtBQUVwQixRQUFJO0FBQ0YsWUFBTXlKLFVBQVU7QUFBQSxRQUNkQyxXQUFXaks7QUFBQUEsTUFDYjtBQUVBLFlBQU1pRCxXQUNKcUcsV0FBVyxXQUNQLG9DQUNBO0FBRU4sWUFBTXRMLElBQUlrTSxNQUFNakgsVUFBVStHLE9BQU87QUFFakMvSSxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUNFbUksV0FBVyxTQUNQLEdBQUd0SixzQkFBc0IrQyxNQUFNLHdDQUMvQixHQUFHL0Msc0JBQXNCK0MsTUFBTTtBQUFBLFFBQ3JDM0IsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUVEbkIsK0JBQXlCLEVBQUU7QUFDM0JFLG1CQUFhLEtBQUs7QUFDbEJNLHVCQUFpQixDQUFDMEosU0FBU0EsT0FBTyxDQUFDO0FBQUEsSUFDckMsU0FBU3hJLE9BQU87QUFDZFEsY0FBUVIsTUFBTSxhQUFhMkgsTUFBTSxpQkFBaUIzSCxLQUFLO0FBRXZEVixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUNFUSxPQUFPRSxVQUFVSyxNQUFNZixXQUFXLGFBQWFtSSxNQUFNO0FBQUEsUUFDdkRsSSxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0NiLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBR0EsUUFBTTZKLGtCQUFrQkEsQ0FBQ0MsUUFBUTtBQUMvQjFMLGlCQUFhMEwsR0FBRztBQUNoQjlLLDBCQUFzQixFQUFFO0FBQ3hCRSx1QkFBbUIsRUFBRTtBQUNyQkUsMEJBQXNCLEVBQUU7QUFDeEJFLHNCQUFrQixFQUFFO0FBQ3BCSSw2QkFBeUIsRUFBRTtBQUMzQkUsaUJBQWEsS0FBSztBQUFBLEVBQ3BCO0FBRUEsU0FDRSxtQ0FDRSxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFFekIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUVSO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNYSxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQ2tKLFVBQVU7QUFBQSxVQUN4QixHQUFHQTtBQUFBQSxVQUNIakosWUFBWTtBQUFBLFFBQ2QsRUFBRTtBQUFBO0FBQUEsTUFSTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTRztBQUFBLElBR0gsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiLGlDQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsd0NBQXVDLHdDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsK0RBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2IsaUNBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTWtKLGdCQUFnQixRQUFRO0FBQUEsWUFDdkMsV0FBVywwRUFDVDFMLGNBQWMsV0FDVix3REFDQSxtQ0FBbUM7QUFBQSxZQUN0QztBQUFBO0FBQUEsY0FHSDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLG9DQUNUQSxjQUFjLFdBQ1YsOEJBQ0EsMkJBQTJCO0FBQUEsa0JBR2hDZ0M7QUFBQUE7QUFBQUEsZ0JBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUE7QUFBQTtBQUFBO0FBQUEsVUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUJBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNMEosZ0JBQWdCLFVBQVU7QUFBQSxZQUN6QyxXQUFXLDBFQUNUMUwsY0FBYyxhQUNWLHFEQUNBLGtDQUFrQztBQUFBLFlBQ3JDO0FBQUE7QUFBQSxjQUdIO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcsb0NBQ1RBLGNBQWMsYUFDViw0QkFDQSwyQkFBMkI7QUFBQSxrQkFHaENrQztBQUFBQTtBQUFBQSxnQkFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBO0FBQUE7QUFBQSxVQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFtQkE7QUFBQSxXQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMENBLEtBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0Q0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3REFFYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlELHFCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxPQUFPcEIsbUJBQW1COEs7QUFBQUEsZ0JBQzFCLFVBQVUsQ0FBQ0MsVUFBVTtBQUNuQjlLLHFDQUFtQjhLLFNBQVMsRUFBRTtBQUFBLGdCQUNoQztBQUFBLGdCQUNBLGtCQUFpQjtBQUFBLGdCQUNqQixjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQyxPQUFPRCxRQUFRRSxZQUFZLEVBQUUsRUFDMUI1RSxZQUFZLEVBQ1pDLFNBQVN3RSxNQUFNekUsWUFBWSxDQUFDO0FBQUEsZ0JBR2pDO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLDBCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQztBQUFBLGtCQUVqQ1QsYUFBYTVCO0FBQUFBLG9CQUFJLENBQUM2QixVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsTUFBTXJCLElBQ3hDcUIsZ0JBQU1wQixRQURXb0IsTUFBTXJCLElBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF3QkE7QUFBQSxlQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThCQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsd0JBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQTtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUEsZ0JBQ1YsTUFBSztBQUFBLGdCQUNMLE9BQU94RSxzQkFBc0I0SztBQUFBQSxnQkFDN0IsVUFBVSxDQUFDQyxVQUFVO0FBQ25CNUssd0NBQXNCNEssU0FBUyxFQUFFO0FBQUEsZ0JBQ25DO0FBQUEsZ0JBQ0Esa0JBQWlCO0FBQUEsZ0JBQ2pCLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJDLE9BQU9ELFFBQVFFLFlBQVksRUFBRSxFQUMxQjVFLFlBQVksRUFDWkMsU0FBU3dFLE1BQU16RSxZQUFZLENBQUM7QUFBQSxnQkFHakM7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsNkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQ3BDdEMsZ0JBQWdCQztBQUFBQSxvQkFBSSxDQUFDMkMsYUFDcEIsdUJBQUMsT0FBTyxRQUFQLEVBQWdDLE9BQU9BLFNBQVNuQyxJQUM5Q21DO0FBQUFBLCtCQUFTbEM7QUFBQUEsc0JBQU07QUFBQSxzQkFDZmtDLFNBQVNoQyxRQUFRLEtBQUtnQyxTQUFTaEMsS0FBSyxLQUFLO0FBQUEseUJBRnhCZ0MsU0FBU25DLElBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF3QkE7QUFBQSxlQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsd0JBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQTtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUEsZ0JBQ1YsTUFBSztBQUFBLGdCQUNMLE9BQU81RSxzQkFBc0JnTDtBQUFBQSxnQkFDN0IsVUFBVSxDQUFDQyxVQUFVO0FBQ25CaEwsd0NBQXNCZ0wsU0FBUyxFQUFFO0FBQUEsZ0JBQ25DO0FBQUEsZ0JBQ0Esa0JBQWlCO0FBQUEsZ0JBQ2pCLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJDLE9BQU9ELFFBQVFFLFlBQVksRUFBRSxFQUMxQjVFLFlBQVksRUFDWkMsU0FBU3dFLE1BQU16RSxZQUFZLENBQUM7QUFBQSxnQkFHakM7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsNkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBRXBDWixnQkFBZ0J6QjtBQUFBQSxvQkFBSSxDQUFDMkIsYUFDcEIsdUJBQUMsT0FBTyxRQUFQLEVBQWdDLE9BQU9BLFNBQVNuQixJQUM5Q21CO0FBQUFBLCtCQUFTbEI7QUFBQUEsc0JBQ1RrQixTQUFTaEIsUUFBUSxNQUFNZ0IsU0FBU2hCLEtBQUssS0FBSztBQUFBLHlCQUZ6QmdCLFNBQVNuQixJQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0F4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBeUJBO0FBQUEsZUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGNBQzNCO0FBQUEsY0FDVix1QkFBQyxZQUFPLFdBQVUsaUJBQ2ZsRSxnQ0FBc0IrQyxVQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0NqRCxrQkFDRXBCLGNBQWMsV0FDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxVQUNFNEIsZ0JBQWdCTixzQkFBc0IrQyxXQUFXO0FBQUEsZ0JBRW5ELFNBQVNzRztBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBRVQvSSx5QkFBZSxrQkFBa0I7QUFBQTtBQUFBLGNBUnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBLElBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsVUFDRUEsZ0JBQWdCTixzQkFBc0IrQyxXQUFXO0FBQUEsZ0JBRW5ELFNBQVNzRztBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBRVQvSSx5QkFBZSxrQkFBa0I7QUFBQTtBQUFBLGNBUnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsZUE3Qk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkE7QUFBQSxhQXBJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUlBO0FBQUEsU0FHRWhCLHNCQUFzQkUsbUJBQW1CRSx1QkFDekMsdUJBQUMsU0FBSSxXQUFVLDBHQUNaSjtBQUFBQSxnQ0FDQyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxZQUNNO0FBQUEsWUFDVix1QkFBQyxZQUNFMkcsNEJBQWtCOUIsUUFBUSx1QkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBRUQzRSxtQkFDQyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxZQUNHO0FBQUEsWUFDUCx1QkFBQyxZQUFRMkcseUJBQWVoQyxRQUFRLG9CQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLGVBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVEekUsc0JBQ0MsdUJBQUMsVUFBSztBQUFBO0FBQUEsWUFDTTtBQUFBLFlBQ1YsdUJBQUMsWUFDRTBHLDRCQUFrQmpDLFFBQVEsdUJBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsV0FqS0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1LQTtBQUFBLE1BR0MsQ0FBQy9ELGFBQWE2RyxVQUFVbEUsU0FBUyxLQUNoQyx1QkFBQyxTQUFJLFdBQVUsMkZBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUzdDO0FBQUFBLGNBQ1QsVUFBVXVHO0FBQUFBO0FBQUFBLFlBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSWtDO0FBQUEsVUFHbEMsdUJBQUMsVUFBSyxXQUFVLHlCQUNidkcsc0JBQVksaUJBQWlCLGdCQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLFVBQUssV0FBVSx5QkFDYkY7QUFBQUEsZ0NBQXNCK0M7QUFBQUEsVUFBTztBQUFBLFVBQUtrRSxVQUFVbEU7QUFBQUEsVUFBTztBQUFBLGFBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUlEM0MsWUFDQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVztBQUFBLFVBQ1gsU0FBUztBQUFBLFVBQ1QsTUFBSztBQUFBO0FBQUEsUUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHd0IsSUFFdEI2RyxVQUFVbEUsU0FBUyxJQUNyQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTWtFO0FBQUFBLFVBQ04sU0FBU2lDO0FBQUFBLFVBQ1QsU0FBUTtBQUFBLFVBQ1IsaUJBQWlCO0FBQUEsVUFDakIsa0JBQWtCO0FBQUEsVUFDbEIsaUJBQ0V4SyxjQUFjLFdBQ1YsdUJBQ0E7QUFBQSxVQUVOLGtCQUNFQSxjQUFjLFdBQ1YsMEJBQ0E7QUFBQTtBQUFBLFFBZFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZUcsSUFHSDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVztBQUFBLFVBQ1gsU0FBUztBQUFBLFVBQ1QsTUFDRUEsY0FBYyxXQUNWLHVCQUNBO0FBQUE7QUFBQSxRQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9HO0FBQUEsU0F6UlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRSQTtBQUFBLE9BN1NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4U0EsS0EvU0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdUQTtBQUVKO0FBQUVELEdBNzZCSUQsa0JBQWdCO0FBQUFvTSxLQUFoQnBNO0FBKzZCTixlQUFlQTtBQUFpQixJQUFBb007QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJOYXZiYXIiLCJEYXRhVGFibGUiLCJhcGkiLCJDaXJjdWxhckxvYWRlciIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiU2VsZWN0IiwiTW9kYWwiLCJBbnRNb2RhbCIsIklucHV0IiwiY29uZmlybSIsIlVubGlua0Vucm9sbG1lbnQiLCJfcyIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImVucm9sbG1lbnRzIiwic2V0RW5yb2xsbWVudHMiLCJsaW5rZWRFbnJvbGxtZW50cyIsInNldExpbmtlZEVucm9sbG1lbnRzIiwidW5saW5rZWRFbnJvbGxtZW50cyIsInNldFVubGlua2VkRW5yb2xsbWVudHMiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJncm91cHMiLCJzZXRHcm91cHMiLCJzZWxlY3RlZEVtcGxveWVlSWQiLCJzZXRTZWxlY3RlZEVtcGxveWVlSWQiLCJzZWxlY3RlZEdyb3VwSWQiLCJzZXRTZWxlY3RlZEdyb3VwSWQiLCJzZWxlY3RlZEN1c3RvbWVySWQiLCJzZXRTZWxlY3RlZEN1c3RvbWVySWQiLCJjdXN0b21lclNlYXJjaCIsInNldEN1c3RvbWVyU2VhcmNoIiwibW9kaWZ5UGF5bWVudCIsInNldE1vZGlmeVBheW1lbnQiLCJzZWxlY3RlZEVucm9sbG1lbnRJZHMiLCJzZXRTZWxlY3RlZEVucm9sbG1lbnRJZHMiLCJzZWxlY3RBbGwiLCJzZXRTZWxlY3RBbGwiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsImxpbmtlZFRvdGFsIiwic2V0TGlua2VkVG90YWwiLCJ1bmxpbmtlZFRvdGFsIiwic2V0VW5saW5rZWRUb3RhbCIsInVzZXJzIiwic2V0VXNlcnMiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiY3VycmVudERhdGEiLCJnZXRMb2dnZWRJblVzZXIiLCJKU09OIiwicGFyc2UiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiZXJyb3IiLCJmZXRjaFVzZXJzIiwicmVzcG9uc2UiLCJnZXQiLCJ1c2VyRGF0YSIsIkFycmF5IiwiaXNBcnJheSIsImRhdGEiLCJjb25zb2xlIiwiZmV0Y2hFbXBsb3llZXMiLCJlbXBsb3llZURhdGEiLCJmZXRjaEdyb3VwcyIsImdyb3VwRGF0YSIsImZldGNoVG90YWxzIiwibGlua2VkUmVzcG9uc2UiLCJ1bmxpbmtlZFJlc3BvbnNlIiwiUHJvbWlzZSIsImFsbCIsImxpbmtlZERhdGEiLCJ1bmxpbmtlZERhdGEiLCJsZW5ndGgiLCJmZXRjaEVucm9sbG1lbnRzIiwiZW5kcG9pbnQiLCJwYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJhcHBlbmQiLCJ1cmwiLCJ0b1N0cmluZyIsInJlc3BvbnNlRGF0YSIsImVucm9sbG1lbnRMaXN0IiwiY3VzdG9tZXJPcHRpb25zIiwibWFwIiwiTWFwIiwiZm9yRWFjaCIsImVucm9sbG1lbnQiLCJ1c2VyIiwidXNlcl9pZCIsIl9pZCIsInNldCIsImlkIiwibmFtZSIsImZ1bGxfbmFtZSIsInBob25lIiwicGhvbmVfbnVtYmVyIiwiaGFzIiwiZnJvbSIsInZhbHVlcyIsInNvcnQiLCJhIiwiYiIsImxvY2FsZUNvbXBhcmUiLCJ1c2VyT2JqIiwiYWRtaW5BY2Nlc3NQZXJtaXNzaW9ucyIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsImFjY2Vzc19wZXJtaXNzaW9ucyIsInVubGlua19lbnJvbGxtZW50IiwiZW1wbG95ZWVPcHRpb25zIiwiYWdlbnQiLCJlbXBsb3llZSIsImdyb3VwT3B0aW9ucyIsImdyb3VwIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwiZmlsdGVyZWREYXRhIiwiZmlsdGVyIiwiaXRlbSIsInRyaW0iLCJzZWFyY2hUZXJtIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInNlbGVjdGVkRW1wbG95ZWUiLCJmaW5kIiwic2VsZWN0ZWRHcm91cCIsInNlbGVjdGVkQ3VzdG9tZXIiLCJjdXN0b21lciIsImhhbmRsZUNoZWNrYm94Q2hhbmdlIiwiZW5yb2xsbWVudElkIiwicHJldmlvdXNJZHMiLCJoYW5kbGVTZWxlY3RBbGxDaGFuZ2UiLCJlIiwiY2hlY2tlZCIsInRhcmdldCIsImFsbElkcyIsIkJvb2xlYW4iLCJhbGxTZWxlY3RlZCIsImV2ZXJ5IiwidGFibGVEYXRhIiwiZm9ybWF0dGVkIiwiaW5kZXgiLCJpc0NoZWNrZWQiLCJjaGVja2JveCIsImxpbmtTdGF0dXMiLCJlbnJvbGxfY29kZSIsImN1c3RvbWVyTmFtZSIsImN1c3RvbWVyTW9iaWxlIiwiZ3JvdXBOYW1lIiwidGlja2V0cyIsInByaXplZCIsImlzX3ByaXplZCIsImVtcGxveWVlTmFtZSIsInJlZmVycmVkX2FnZW50IiwidG90YWxQYXlhYmxlIiwidG90YWxfcGF5YWJsZSIsInRvdGFsSW52ZXN0bWVudCIsInRvdGFsX2ludmVzdG1lbnQiLCJ0b3RhbFByb2ZpdCIsInRvdGFsX3Byb2ZpdCIsInRvdGFsTGF0ZUZlZSIsInRvdGFsX2xhdGVfZmVlIiwidG90YWxQZW5hbHR5IiwidG90YWxfcGVuYWx0eSIsInJlbGF0aW9uc2hpcE1hbmFnZXIiLCJyZWxhdGlvbnNoaXBfbWFuYWdlciIsInRvdGFsQmFsYW5jZSIsInRvdGFsX2JhbGFuY2UiLCJzdGF0dXMiLCJjdXN0b21lcl9zdGF0dXMiLCJicmFuY2hTdGF0dXMiLCJvcmlnaW5hbERhdGEiLCJ1bmxpbmtFbnJvbGxDb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwiaGFuZGxlQnVsa0FjdGlvbiIsImFjdGlvbiIsInRpdGxlIiwiY29udGVudCIsIm9rVGV4dCIsImNhbmNlbFRleHQiLCJjZW50ZXJlZCIsIm9rQnV0dG9uUHJvcHMiLCJkYW5nZXIiLCJvbk9rIiwicGVyZm9ybUJ1bGtBY3Rpb24iLCJwYXlsb2FkIiwiZW5yb2xsSWRzIiwicGF0Y2giLCJwcmV2IiwiaGFuZGxlVGFiQ2hhbmdlIiwidGFiIiwidW5kZWZpbmVkIiwidmFsdWUiLCJpbnB1dCIsIm9wdGlvbiIsIlN0cmluZyIsImNoaWxkcmVuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVW5saW5rRW5yb2xsbWVudC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBNb2RhbCBhcyBBbnRNb2RhbCwgSW5wdXQgfSBmcm9tIFwiYW50ZFwiO1xyXG5cclxuY29uc3QgeyBjb25maXJtIH0gPSBBbnRNb2RhbDtcclxuXHJcbmNvbnN0IFVubGlua0Vucm9sbG1lbnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwibGlua2VkXCIpO1xyXG4gIGNvbnN0IFtlbnJvbGxtZW50cywgc2V0RW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsaW5rZWRFbnJvbGxtZW50cywgc2V0TGlua2VkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt1bmxpbmtlZEVucm9sbG1lbnRzLCBzZXRVbmxpbmtlZEVucm9sbG1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZUlkLCBzZXRTZWxlY3RlZEVtcGxveWVlSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVySWQsIHNldFNlbGVjdGVkQ3VzdG9tZXJJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY3VzdG9tZXJTZWFyY2gsIHNldEN1c3RvbWVyU2VhcmNoXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgLy8gU2VsZWN0ZWQgZW5yb2xsbWVudCBJRHNcclxuICBjb25zdCBbc2VsZWN0ZWRFbnJvbGxtZW50SWRzLCBzZXRTZWxlY3RlZEVucm9sbG1lbnRJZHNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICAvLyBTZWxlY3QgQWxsIGNoZWNrYm94XHJcbiAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbGlua2VkVG90YWwsIHNldExpbmtlZFRvdGFsXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFt1bmxpbmtlZFRvdGFsLCBzZXRVbmxpbmtlZFRvdGFsXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICAvLyBDVVJSRU5UIFRBQiBEQVRBXHJcbiAgY29uc3QgY3VycmVudERhdGEgPVxyXG4gICAgYWN0aXZlVGFiID09PSBcImxpbmtlZFwiID8gbGlua2VkRW5yb2xsbWVudHMgOiB1bmxpbmtlZEVucm9sbG1lbnRzO1xyXG5cclxuICAvLyBHRVQgTE9HR0VEIElOIFVTRVJcclxuICBjb25zdCBnZXRMb2dnZWRJblVzZXIgPSAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIikgfHwgXCJ7fVwiKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiB7fTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBmZXRjaCB1c2VyXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgY29uc3QgdXNlckRhdGEgPSBBcnJheS5pc0FycmF5KHJlc3BvbnNlPy5kYXRhPy5kYXRhKVxyXG4gICAgICAgICAgPyByZXNwb25zZS5kYXRhLmRhdGFcclxuICAgICAgICAgIDogQXJyYXkuaXNBcnJheShyZXNwb25zZT8uZGF0YSlcclxuICAgICAgICAgICAgPyByZXNwb25zZS5kYXRhXHJcbiAgICAgICAgICAgIDogW107XHJcbiAgICAgICAgc2V0VXNlcnModXNlckRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRVc2VycyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgLy8gRkVUQ0ggRU1QTE9ZRUVTXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpO1xyXG5cclxuICAgICAgY29uc3QgZW1wbG95ZWVEYXRhID0gQXJyYXkuaXNBcnJheShyZXNwb25zZT8uZGF0YSlcclxuICAgICAgICA/IHJlc3BvbnNlLmRhdGFcclxuICAgICAgICA6IHJlc3BvbnNlPy5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgc2V0RW1wbG95ZWVzKGVtcGxveWVlRGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWVzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEVtcGxveWVlcyhbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gRkVUQ0ggR1JPVVBTXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBEYXRhID0gQXJyYXkuaXNBcnJheShyZXNwb25zZT8uZGF0YT8uZGF0YSlcclxuICAgICAgICAgID8gcmVzcG9uc2UuZGF0YS5kYXRhXHJcbiAgICAgICAgICA6IEFycmF5LmlzQXJyYXkocmVzcG9uc2U/LmRhdGEpXHJcbiAgICAgICAgICAgID8gcmVzcG9uc2UuZGF0YVxyXG4gICAgICAgICAgICA6IFtdO1xyXG4gICAgICAgIHNldEdyb3Vwcyhncm91cERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0R3JvdXBzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBGRVRDSCBPTkxZIFRPVEFMUyAod2l0aG91dCBzdG9yaW5nIGZ1bGwgZGF0YSlcclxuICBjb25zdCBmZXRjaFRvdGFscyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IFtsaW5rZWRSZXNwb25zZSwgdW5saW5rZWRSZXNwb25zZV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgYXBpLmdldChcIi92MS9hZG1pbi9lbnJvbGxzL2xpbmstZW5yb2xsXCIpLFxyXG4gICAgICAgIGFwaS5nZXQoXCIvdjEvYWRtaW4vZW5yb2xscy91bmxpbmstZW5yb2xsXCIpLFxyXG4gICAgICBdKTtcclxuXHJcbiAgICAgIGxldCBsaW5rZWREYXRhID0gQXJyYXkuaXNBcnJheShsaW5rZWRSZXNwb25zZT8uZGF0YT8uZGF0YSlcclxuICAgICAgICA/IGxpbmtlZFJlc3BvbnNlLmRhdGEuZGF0YVxyXG4gICAgICAgIDogQXJyYXkuaXNBcnJheShsaW5rZWRSZXNwb25zZT8uZGF0YSlcclxuICAgICAgICAgID8gbGlua2VkUmVzcG9uc2UuZGF0YVxyXG4gICAgICAgICAgOiBbXTtcclxuXHJcbiAgICAgIGxldCB1bmxpbmtlZERhdGEgPSBBcnJheS5pc0FycmF5KHVubGlua2VkUmVzcG9uc2U/LmRhdGE/LmRhdGEpXHJcbiAgICAgICAgPyB1bmxpbmtlZFJlc3BvbnNlLmRhdGEuZGF0YVxyXG4gICAgICAgIDogQXJyYXkuaXNBcnJheSh1bmxpbmtlZFJlc3BvbnNlPy5kYXRhKVxyXG4gICAgICAgICAgPyB1bmxpbmtlZFJlc3BvbnNlLmRhdGFcclxuICAgICAgICAgIDogW107XHJcblxyXG4gICAgICAvLyBGaWx0ZXIgb3V0IGludmFsaWQgZW5yb2xsbWVudHMgKG1pc3NpbmcgZ3JvdXBfaWQgb3IgdXNlcl9pZClcclxuICAgICAgLy8gbGlua2VkRGF0YSA9IGxpbmtlZERhdGEuZmlsdGVyKGl0ZW0gPT4gaXRlbT8uZ3JvdXBfaWQgJiYgaXRlbT8udXNlcl9pZCk7XHJcbiAgICAgIC8vIHVubGlua2VkRGF0YSA9IHVubGlua2VkRGF0YS5maWx0ZXIoaXRlbSA9PiBpdGVtPy5ncm91cF9pZCAmJiBpdGVtPy51c2VyX2lkKTtcclxuXHJcbiAgICAgIC8vIFN0b3JlIG9ubHkgdGhlIGNvdW50cyAtIEZJWEVEIHRoZSBzd2FwcGVkIHZhbHVlc1xyXG4gICAgICBzZXRMaW5rZWRUb3RhbChsaW5rZWREYXRhLmxlbmd0aCk7XHJcbiAgICAgIHNldFVubGlua2VkVG90YWwodW5saW5rZWREYXRhLmxlbmd0aCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdG90YWxzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldExpbmtlZFRvdGFsKDApO1xyXG4gICAgICBzZXRVbmxpbmtlZFRvdGFsKDApO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEZFVENIIExJTktFRCAvIFVOTElOS0VEIERBVEFcclxuICBjb25zdCBmZXRjaEVucm9sbG1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgLy8gVXNlIGRpZmZlcmVudCBlbmRwb2ludHMgZm9yIGRpZmZlcmVudCB0YWJzXHJcbiAgICAgIGNvbnN0IGVuZHBvaW50ID1cclxuICAgICAgICBhY3RpdmVUYWIgPT09IFwibGlua2VkXCJcclxuICAgICAgICAgID8gXCIvdjEvYWRtaW4vZW5yb2xscy9saW5rLWVucm9sbFwiIC8vIFJldHVybnMgbGlua2VkIGVucm9sbG1lbnRzXHJcbiAgICAgICAgICA6IFwiL3YxL2FkbWluL2Vucm9sbHMvdW5saW5rLWVucm9sbFwiOyAvLyBSZXR1cm5zIHVubGlua2VkIGVucm9sbG1lbnRzXHJcblxyXG4gICAgICAvLyBCdWlsZCBxdWVyeSBwYXJhbWV0ZXJzXHJcbiAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcclxuICAgICAgaWYgKHNlbGVjdGVkRW1wbG95ZWVJZCkge1xyXG4gICAgICAgIHBhcmFtcy5hcHBlbmQoXCJlbXBJZFwiLCBzZWxlY3RlZEVtcGxveWVlSWQpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChzZWxlY3RlZEdyb3VwSWQpIHtcclxuICAgICAgICBwYXJhbXMuYXBwZW5kKFwiZ3JvdXBJZFwiLCBzZWxlY3RlZEdyb3VwSWQpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChzZWxlY3RlZEN1c3RvbWVySWQpIHtcclxuICAgICAgICBwYXJhbXMuYXBwZW5kKFwiY3VzdG9tZXJJZFwiLCBzZWxlY3RlZEN1c3RvbWVySWQpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCB1cmwgPSBwYXJhbXMudG9TdHJpbmcoKVxyXG4gICAgICAgID8gYCR7ZW5kcG9pbnR9PyR7cGFyYW1zLnRvU3RyaW5nKCl9YFxyXG4gICAgICAgIDogZW5kcG9pbnQ7XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQodXJsKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHJlc3BvbnNlPy5kYXRhPy5kYXRhID8/IHJlc3BvbnNlPy5kYXRhID8/IFtdO1xyXG5cclxuICAgICAgY29uc3QgZW5yb2xsbWVudExpc3QgPSBBcnJheS5pc0FycmF5KHJlc3BvbnNlRGF0YSkgPyByZXNwb25zZURhdGEgOiBbXTtcclxuXHJcbiAgICAgIHNldEVucm9sbG1lbnRzKGVucm9sbG1lbnRMaXN0KTtcclxuXHJcbiAgICAgIC8vIFN0b3JlIGRhdGEgYWNjb3JkaW5nIHRvIGFjdGl2ZSB0YWJcclxuICAgICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJsaW5rZWRcIikge1xyXG4gICAgICAgIHNldExpbmtlZEVucm9sbG1lbnRzKGVucm9sbG1lbnRMaXN0KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRVbmxpbmtlZEVucm9sbG1lbnRzKGVucm9sbG1lbnRMaXN0KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgJHthY3RpdmVUYWJ9IGVucm9sbG1lbnRzOmAsIGVycm9yKTtcclxuICAgICAgc2V0RW5yb2xsbWVudHMoW10pO1xyXG4gICAgICBpZiAoYWN0aXZlVGFiID09PSBcImxpbmtlZFwiKSB7XHJcbiAgICAgICAgc2V0TGlua2VkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldFVubGlua2VkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIENVU1RPTUVSIE9QVElPTlNcclxuICBjb25zdCBjdXN0b21lck9wdGlvbnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IG1hcCA9IG5ldyBNYXAoKTtcclxuXHJcbiAgICAvLyBHZXQgY3VzdG9tZXJzIGZyb20gY3VycmVudCBlbnJvbGxtZW50IGRhdGFcclxuICAgIGN1cnJlbnREYXRhLmZvckVhY2goKGVucm9sbG1lbnQpID0+IHtcclxuICAgICAgY29uc3QgdXNlciA9IGVucm9sbG1lbnQ/LnVzZXJfaWQ7XHJcbiAgICAgIGlmICh1c2VyPy5faWQpIHtcclxuICAgICAgICBtYXAuc2V0KHVzZXIuX2lkLCB7XHJcbiAgICAgICAgICBpZDogdXNlci5faWQsXHJcbiAgICAgICAgICBuYW1lOiB1c2VyLmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgcGhvbmU6IHVzZXIucGhvbmVfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIC8vIEFsc28gaW5jbHVkZSB1c2VycyBmcm9tIHRoZSB1c2VycyBBUElcclxuICAgIHVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgY29uc3QgaWQgPSB1c2VyPy5faWQ7XHJcbiAgICAgIGlmIChpZCAmJiAhbWFwLmhhcyhpZCkpIHtcclxuICAgICAgICBtYXAuc2V0KGlkLCB7XHJcbiAgICAgICAgICBpZCxcclxuICAgICAgICAgIG5hbWU6IHVzZXI/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgcGhvbmU6IHVzZXI/LnBob25lX251bWJlciB8fCBcIlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gQXJyYXkuZnJvbShtYXAudmFsdWVzKCkpLnNvcnQoKGEsIGIpID0+XHJcbiAgICAgIGAke2EubmFtZX0gJHthLnBob25lfWAubG9jYWxlQ29tcGFyZShgJHtiLm5hbWV9ICR7Yi5waG9uZX1gKSxcclxuICAgICk7XHJcbiAgfSwgW2N1cnJlbnREYXRhLCB1c2Vyc10pO1xyXG5cclxuICAvLyBJTklUSUFMIEZFVENIXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgICBmZXRjaFRvdGFscygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIC8vIEZFVENIIEVOUk9MTE1FTlRTIE9OIERFUEVOREVOQ1kgQ0hBTkdFXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRW5yb2xsbWVudHMoKTtcclxuICB9LCBbXHJcbiAgICBhY3RpdmVUYWIsXHJcbiAgICBzZWxlY3RlZEVtcGxveWVlSWQsXHJcbiAgICBzZWxlY3RlZEdyb3VwSWQsXHJcbiAgICBzZWxlY3RlZEN1c3RvbWVySWQsXHJcbiAgICByZWxvYWRUcmlnZ2VyLFxyXG4gIF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG5cclxuICAgIGlmICh1c2VyT2JqKSB7XHJcbiAgICAgIGNvbnN0IGFkbWluQWNjZXNzUGVybWlzc2lvbnMgPVxyXG4gICAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM7XHJcblxyXG4gICAgICBpZiAoYWRtaW5BY2Nlc3NQZXJtaXNzaW9ucz8udW5saW5rX2Vucm9sbG1lbnQgPT09IFwidHJ1ZVwiKSB7XHJcbiAgICAgICAgc2V0TW9kaWZ5UGF5bWVudCh0cnVlKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gaWYgKGFkbWluQWNjZXNzUGVybWlzc2lvbnM/LmVkaXRfbGltaXRlZF9wYXltZW50ID09PSBcInRydWVcIikge1xyXG4gICAgICAvLyAgIHNldE1vZGlmeVBheW1lbnQodHJ1ZSk7XHJcbiAgICAgIC8vICAgLy8gc2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGUodHJ1ZSk7XHJcbiAgICAgIC8vIH1cclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIEVNUExPWUVFIE9QVElPTlNcclxuICBjb25zdCBlbXBsb3llZU9wdGlvbnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IG1hcCA9IG5ldyBNYXAoKTtcclxuXHJcbiAgICBjdXJyZW50RGF0YS5mb3JFYWNoKChlbnJvbGxtZW50KSA9PiB7XHJcbiAgICAgIGNvbnN0IGFnZW50ID0gZW5yb2xsbWVudD8uYWdlbnQ7XHJcblxyXG4gICAgICBpZiAoYWdlbnQ/Ll9pZCkge1xyXG4gICAgICAgIG1hcC5zZXQoYWdlbnQuX2lkLCB7XHJcbiAgICAgICAgICBpZDogYWdlbnQuX2lkLFxyXG4gICAgICAgICAgbmFtZTogYWdlbnQubmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgcGhvbmU6IGFnZW50LnBob25lX251bWJlciB8fCBcIlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBBbHNvIGluY2x1ZGUgZW1wbG95ZWVzIGZyb20gZW1wbG95ZWUgQVBJXHJcbiAgICBlbXBsb3llZXMuZm9yRWFjaCgoZW1wbG95ZWUpID0+IHtcclxuICAgICAgY29uc3QgaWQgPSBlbXBsb3llZT8uX2lkO1xyXG5cclxuICAgICAgaWYgKGlkICYmICFtYXAuaGFzKGlkKSkge1xyXG4gICAgICAgIG1hcC5zZXQoaWQsIHtcclxuICAgICAgICAgIGlkLFxyXG4gICAgICAgICAgbmFtZTogZW1wbG95ZWU/Lm5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHBob25lOiBlbXBsb3llZT8ucGhvbmVfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBBcnJheS5mcm9tKG1hcC52YWx1ZXMoKSkuc29ydCgoYSwgYikgPT5cclxuICAgICAgYCR7YS5uYW1lfSAke2EucGhvbmV9YC5sb2NhbGVDb21wYXJlKGAke2IubmFtZX0gJHtiLnBob25lfWApLFxyXG4gICAgKTtcclxuICB9LCBbY3VycmVudERhdGEsIGVtcGxveWVlc10pO1xyXG5cclxuICAvLyBHUk9VUCBPUFRJT05TXHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XHJcblxyXG4gICAgY3VycmVudERhdGEuZm9yRWFjaCgoZW5yb2xsbWVudCkgPT4ge1xyXG4gICAgICBjb25zdCBncm91cCA9IGVucm9sbG1lbnQ/Lmdyb3VwX2lkO1xyXG5cclxuICAgICAgaWYgKGdyb3VwPy5faWQpIHtcclxuICAgICAgICBtYXAuc2V0KGdyb3VwLl9pZCwge1xyXG4gICAgICAgICAgaWQ6IGdyb3VwLl9pZCxcclxuICAgICAgICAgIG5hbWU6IGdyb3VwLmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gQWxzbyBpbmNsdWRlIGdyb3VwcyBmcm9tIGdyb3VwcyBBUElcclxuICAgIGdyb3Vwcy5mb3JFYWNoKChncm91cCkgPT4ge1xyXG4gICAgICBjb25zdCBpZCA9IGdyb3VwPy5faWQ7XHJcblxyXG4gICAgICBpZiAoaWQgJiYgIW1hcC5oYXMoaWQpKSB7XHJcbiAgICAgICAgbWFwLnNldChpZCwge1xyXG4gICAgICAgICAgaWQsXHJcbiAgICAgICAgICBuYW1lOiBncm91cD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gQXJyYXkuZnJvbShtYXAudmFsdWVzKCkpLnNvcnQoKGEsIGIpID0+XHJcbiAgICAgIGEubmFtZS5sb2NhbGVDb21wYXJlKGIubmFtZSksXHJcbiAgICApO1xyXG4gIH0sIFtjdXJyZW50RGF0YSwgZ3JvdXBzXSk7XHJcblxyXG4gIC8vIEZJTFRFUiBEQVRBIEJZIEVNUExPWUVFLCBHUk9VUCwgQU5EIENVU1RPTUVSXHJcbiAgY29uc3QgZmlsdGVyZWREYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBsZXQgZGF0YSA9IGN1cnJlbnREYXRhO1xyXG5cclxuICAgIGlmIChzZWxlY3RlZEVtcGxveWVlSWQpIHtcclxuICAgICAgZGF0YSA9IGRhdGEuZmlsdGVyKChpdGVtKSA9PiBpdGVtPy5hZ2VudD8uX2lkID09PSBzZWxlY3RlZEVtcGxveWVlSWQpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChzZWxlY3RlZEdyb3VwSWQpIHtcclxuICAgICAgZGF0YSA9IGRhdGEuZmlsdGVyKChpdGVtKSA9PiBpdGVtPy5ncm91cF9pZD8uX2lkID09PSBzZWxlY3RlZEdyb3VwSWQpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChzZWxlY3RlZEN1c3RvbWVySWQpIHtcclxuICAgICAgZGF0YSA9IGRhdGEuZmlsdGVyKChpdGVtKSA9PiBpdGVtPy51c2VyX2lkPy5faWQgPT09IHNlbGVjdGVkQ3VzdG9tZXJJZCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gQ3VzdG9tZXIgc2VhcmNoIGZpbHRlclxyXG4gICAgaWYgKGN1c3RvbWVyU2VhcmNoLnRyaW0oKSkge1xyXG4gICAgICBjb25zdCBzZWFyY2hUZXJtID0gY3VzdG9tZXJTZWFyY2gudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGRhdGEgPSBkYXRhLmZpbHRlcigoaXRlbSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5hbWUgPSAoaXRlbT8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiXCIpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgY29uc3QgcGhvbmUgPSAoaXRlbT8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiXCIpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgcmV0dXJuIG5hbWUuaW5jbHVkZXMoc2VhcmNoVGVybSkgfHwgcGhvbmUuaW5jbHVkZXMoc2VhcmNoVGVybSk7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBkYXRhO1xyXG4gIH0sIFtcclxuICAgIGN1cnJlbnREYXRhLFxyXG4gICAgc2VsZWN0ZWRFbXBsb3llZUlkLFxyXG4gICAgc2VsZWN0ZWRHcm91cElkLFxyXG4gICAgc2VsZWN0ZWRDdXN0b21lcklkLFxyXG4gICAgY3VzdG9tZXJTZWFyY2gsXHJcbiAgXSk7XHJcblxyXG4gIC8vIFNFTEVDVEVEIEVNUExPWUVFXHJcbiAgY29uc3Qgc2VsZWN0ZWRFbXBsb3llZSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGVtcGxveWVlT3B0aW9ucy5maW5kKFxyXG4gICAgICAoZW1wbG95ZWUpID0+IGVtcGxveWVlLmlkID09PSBzZWxlY3RlZEVtcGxveWVlSWQsXHJcbiAgICApO1xyXG4gIH0sIFtlbXBsb3llZU9wdGlvbnMsIHNlbGVjdGVkRW1wbG95ZWVJZF0pO1xyXG5cclxuICAvLyBTRUxFQ1RFRCBHUk9VUFxyXG4gIGNvbnN0IHNlbGVjdGVkR3JvdXAgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBncm91cE9wdGlvbnMuZmluZCgoZ3JvdXApID0+IGdyb3VwLmlkID09PSBzZWxlY3RlZEdyb3VwSWQpO1xyXG4gIH0sIFtncm91cE9wdGlvbnMsIHNlbGVjdGVkR3JvdXBJZF0pO1xyXG5cclxuICAvLyBTRUxFQ1RFRCBDVVNUT01FUlxyXG4gIGNvbnN0IHNlbGVjdGVkQ3VzdG9tZXIgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBjdXN0b21lck9wdGlvbnMuZmluZChcclxuICAgICAgKGN1c3RvbWVyKSA9PiBjdXN0b21lci5pZCA9PT0gc2VsZWN0ZWRDdXN0b21lcklkLFxyXG4gICAgKTtcclxuICB9LCBbY3VzdG9tZXJPcHRpb25zLCBzZWxlY3RlZEN1c3RvbWVySWRdKTtcclxuXHJcbiAgLy8gSU5ESVZJRFVBTCBDSEVDS0JPWCBDSEFOR0VcclxuICBjb25zdCBoYW5kbGVDaGVja2JveENoYW5nZSA9IChpdGVtKSA9PiB7XHJcbiAgICBjb25zdCBlbnJvbGxtZW50SWQgPSBpdGVtPy5faWQ7XHJcblxyXG4gICAgaWYgKCFlbnJvbGxtZW50SWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudElkcygocHJldmlvdXNJZHMpID0+IHtcclxuICAgICAgaWYgKHByZXZpb3VzSWRzLmluY2x1ZGVzKGVucm9sbG1lbnRJZCkpIHtcclxuICAgICAgICByZXR1cm4gcHJldmlvdXNJZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IGVucm9sbG1lbnRJZCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiBbLi4ucHJldmlvdXNJZHMsIGVucm9sbG1lbnRJZF07XHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICAvLyBTRUxFQ1QgQUxMIC8gREVTRUxFQ1QgQUxMXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0QWxsQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IGNoZWNrZWQgPSBlLnRhcmdldC5jaGVja2VkO1xyXG5cclxuICAgIGlmIChjaGVja2VkKSB7XHJcbiAgICAgIGNvbnN0IGFsbElkcyA9IGZpbHRlcmVkRGF0YS5tYXAoKGl0ZW0pID0+IGl0ZW0/Ll9pZCkuZmlsdGVyKEJvb2xlYW4pO1xyXG5cclxuICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50SWRzKGFsbElkcyk7XHJcbiAgICAgIHNldFNlbGVjdEFsbCh0cnVlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudElkcyhbXSk7XHJcbiAgICAgIHNldFNlbGVjdEFsbChmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gVVBEQVRFIFNFTEVDVCBBTEwgU1RBVEVcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGZpbHRlcmVkRGF0YS5sZW5ndGggPT09IDApIHtcclxuICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGFsbFNlbGVjdGVkID0gZmlsdGVyZWREYXRhLmV2ZXJ5KChpdGVtKSA9PlxyXG4gICAgICBzZWxlY3RlZEVucm9sbG1lbnRJZHMuaW5jbHVkZXMoaXRlbS5faWQpLFxyXG4gICAgKTtcclxuXHJcbiAgICBzZXRTZWxlY3RBbGwoYWxsU2VsZWN0ZWQpO1xyXG4gIH0sIFtmaWx0ZXJlZERhdGEsIHNlbGVjdGVkRW5yb2xsbWVudElkc10pO1xyXG5cclxuICAvLyBSRVNFVCBTRUxFQ1RJT05TIE9OIEZJTFRFUiBDSEFOR0VcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50SWRzKFtdKTtcclxuICAgIHNldFNlbGVjdEFsbChmYWxzZSk7XHJcbiAgfSwgW2FjdGl2ZVRhYiwgc2VsZWN0ZWRFbXBsb3llZUlkLCBzZWxlY3RlZEdyb3VwSWQsIHNlbGVjdGVkQ3VzdG9tZXJJZF0pO1xyXG5cclxuICAvLyBUQUJMRSBEQVRBXHJcbiAgY29uc3QgdGFibGVEYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmb3JtYXR0ZWQgPSBmaWx0ZXJlZERhdGFcclxuICAgICAgLm1hcCgoZW5yb2xsbWVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICBjb25zdCBlbnJvbGxtZW50SWQgPSBlbnJvbGxtZW50Py5faWQ7XHJcbiAgICAgICAgY29uc3QgaXNDaGVja2VkID0gc2VsZWN0ZWRFbnJvbGxtZW50SWRzLmluY2x1ZGVzKGVucm9sbG1lbnRJZCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGNoZWNrYm94ID0gKFxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2lzQ2hlY2tlZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IGhhbmRsZUNoZWNrYm94Q2hhbmdlKGVucm9sbG1lbnQpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IGN1cnNvci1wb2ludGVyIGFjY2VudC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIFNpbmNlIGRhdGEgaXMgYWxyZWFkeSBmaWx0ZXJlZCBieSB0YWIsIHNldCBzdGF0dXMgYmFzZWQgb24gYWN0aXZlVGFiXHJcbiAgICAgICAgY29uc3QgbGlua1N0YXR1cyA9IGFjdGl2ZVRhYiA9PT0gXCJsaW5rZWRcIiA/IFwiTGlua2VkXCIgOiBcIlVubGlua2VkXCI7XHJcblxyXG4gICAgICAgIC8vIFNraXAgcmVuZGVyaW5nIGlmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xyXG4gICAgICAgIC8vIGlmICghZW5yb2xsbWVudD8uZ3JvdXBfaWQgfHwgIWVucm9sbG1lbnQ/LnVzZXJfaWQpIHtcclxuICAgICAgICAvLyAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgLi4uZW5yb2xsbWVudCxcclxuICAgICAgICAgIF9pZDogZW5yb2xsbWVudElkLFxyXG4gICAgICAgICAgY2hlY2tib3g6IGNoZWNrYm94LFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgIGVucm9sbF9jb2RlOiBlbnJvbGxtZW50Py5lbnJvbGxfY29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJOYW1lOiBlbnJvbGxtZW50Py51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGN1c3RvbWVyTW9iaWxlOiBlbnJvbGxtZW50Py51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGdyb3VwTmFtZTogZW5yb2xsbWVudD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHRpY2tldHM6IGVucm9sbG1lbnQ/LnRpY2tldHMgPz8gMCxcclxuICAgICAgICAgIHByaXplZDogKFxyXG4gICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSByb3VuZGVkLWZ1bGwgcHgtMyBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZCAke1xyXG4gICAgICAgICAgICAgICAgZW5yb2xsbWVudD8uaXNfcHJpemVkXHJcbiAgICAgICAgICAgICAgICAgID8gXCJiZy1hbWJlci0xMDAgdGV4dC1hbWJlci04MDBcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNjAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtlbnJvbGxtZW50Py5pc19wcml6ZWQgPyBcIuKckyBQcml6ZWRcIiA6IFwiTm90IFByaXplZFwifVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICAgZW1wbG95ZWVOYW1lOiBlbnJvbGxtZW50Py5yZWZlcnJlZF9hZ2VudD8ubmFtZVxyXG4gICAgICAgICAgICA/IGAke2Vucm9sbG1lbnQ/LnJlZmVycmVkX2FnZW50Py5uYW1lIHx8IFwiTi9BXCJ9IHwgJHtlbnJvbGxtZW50Py5yZWZlcnJlZF9hZ2VudD8ucGhvbmVfbnVtYmVyfHwgXCJOL0FcIn1gXHJcbiAgICAgICAgICAgIDogXCJOL0FcIixcclxuICAgICAgICAgIHRvdGFsUGF5YWJsZTogZW5yb2xsbWVudD8udG90YWxfcGF5YWJsZSB8fCBcIjBcIixcclxuICAgICAgICAgIHRvdGFsSW52ZXN0bWVudDogZW5yb2xsbWVudD8udG90YWxfaW52ZXN0bWVudCB8fCBcIjBcIixcclxuICAgICAgICAgIHRvdGFsUHJvZml0OiBlbnJvbGxtZW50Py50b3RhbF9wcm9maXQgfHwgXCIwXCIsXHJcbiAgICAgICAgICB0b3RhbExhdGVGZWU6IGVucm9sbG1lbnQ/LnRvdGFsX2xhdGVfZmVlIHx8IFwiMFwiLFxyXG4gICAgICAgICAgdG90YWxQZW5hbHR5OiBlbnJvbGxtZW50Py50b3RhbF9wZW5hbHR5IHx8IFwiMFwiLFxyXG4gICAgICAgICAgcmVsYXRpb25zaGlwTWFuYWdlcjogZW5yb2xsbWVudD8uZ3JvdXBfaWQ/LnJlbGF0aW9uc2hpcF9tYW5hZ2VyPy5uYW1lIHx8IFwiMFwiLFxyXG4gICAgICAgICAgdG90YWxCYWxhbmNlOiBlbnJvbGxtZW50Py50b3RhbF9iYWxhbmNlIHx8IFwiMFwiLFxyXG4gICAgICAgICAgc3RhdHVzOiBlbnJvbGxtZW50Py5jdXN0b21lcl9zdGF0dXMgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGJyYW5jaFN0YXR1czogbGlua1N0YXR1cyxcclxuICAgICAgICAgIG9yaWdpbmFsRGF0YTogZW5yb2xsbWVudCxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG4gICAgICAuZmlsdGVyKEJvb2xlYW4pOyAvLyBSZW1vdmUgYW55IG51bGwgZW50cmllc1xyXG5cclxuICAgIHJldHVybiBmb3JtYXR0ZWQ7XHJcbiAgfSwgW2ZpbHRlcmVkRGF0YSwgc2VsZWN0ZWRFbnJvbGxtZW50SWRzLCBhY3RpdmVUYWJdKTtcclxuXHJcbiAgLy8gVEFCTEUgQ09MVU1OU1xyXG4gIGNvbnN0IHVubGlua0Vucm9sbENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJjaGVja2JveFwiLCBoZWFkZXI6IFwiU2VsZWN0XCIgfSxcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgLy8geyBrZXk6IFwiZW5yb2xsX2NvZGVcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJNb2JpbGVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE1vYmlsZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0c1wiLCBoZWFkZXI6IFwiVGlja2V0c1wiIH0sXHJcbiAgICB7IGtleTogXCJwcml6ZWRcIiwgaGVhZGVyOiBcIlByaXplZFwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZU5hbWVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIHwgTW9iaWxlXCIgfSxcclxuICAgIHsga2V5OiBcInJlbGF0aW9uc2hpcE1hbmFnZXJcIiwgaGVhZGVyOiBcIlJlbGF0aW9uc2hpcCBNYW5hZ2VyXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsTGF0ZUZlZVwiLCBoZWFkZXI6IFwiVG90YWwgTGF0ZSBGZWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxQZW5hbHR5XCIsIGhlYWRlcjogXCJUb3RhbCBQZW5hbHR5XCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsUGF5YWJsZVwiLCBoZWFkZXI6IFwiVG90YWwgUGF5YWJsZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbEludmVzdG1lbnRcIiwgaGVhZGVyOiBcIlRvdGFsIFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxCYWxhbmNlXCIsIGhlYWRlcjogXCJUb3RhbCBCYWxhbmNlXCIgfSxcclxuIFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYnJhbmNoU3RhdHVzXCIsIGhlYWRlcjogXCJMaW5rIFN0YXR1c1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgLy8gQlVMSyBMSU5LIC8gVU5MSU5LXHJcbiAgY29uc3QgaGFuZGxlQnVsa0FjdGlvbiA9ICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRFbnJvbGxtZW50SWRzLmxlbmd0aCkge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBgUGxlYXNlIHNlbGVjdCBhdCBsZWFzdCBvbmUgZW5yb2xsbWVudCB0byAke1xyXG4gICAgICAgICAgYWN0aXZlVGFiID09PSBcImxpbmtlZFwiID8gXCJ1bmxpbmtcIiA6IFwibGlua1wiXHJcbiAgICAgICAgfS5gLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYWN0aW9uID0gYWN0aXZlVGFiID09PSBcImxpbmtlZFwiID8gXCJ1bmxpbmtcIiA6IFwibGlua1wiO1xyXG5cclxuICAgIGNvbmZpcm0oe1xyXG4gICAgICB0aXRsZTogYWN0aW9uID09PSBcImxpbmtcIiA/IFwiTGluayBFbnJvbGxtZW50c1wiIDogXCJVbmxpbmsgRW5yb2xsbWVudHNcIixcclxuXHJcbiAgICAgIGNvbnRlbnQ6IChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gPHN0cm9uZz57YWN0aW9ufTwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgPHN0cm9uZz57c2VsZWN0ZWRFbnJvbGxtZW50SWRzLmxlbmd0aH08L3N0cm9uZz4gZW5yb2xsbWVudChzKT9cclxuICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZSAmJiAoXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICBFbXBsb3llZTogPHN0cm9uZz57c2VsZWN0ZWRFbXBsb3llZS5uYW1lfTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlLnBob25lID8gYCB8ICR7c2VsZWN0ZWRFbXBsb3llZS5waG9uZX1gIDogXCJcIn1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7c2VsZWN0ZWRHcm91cCAmJiAoXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICBHcm91cDogPHN0cm9uZz57c2VsZWN0ZWRHcm91cC5uYW1lfTwvc3Ryb25nPlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHtzZWxlY3RlZEN1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgIEN1c3RvbWVyOiA8c3Ryb25nPntzZWxlY3RlZEN1c3RvbWVyLm5hbWV9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkQ3VzdG9tZXIucGhvbmUgPyBgIHwgJHtzZWxlY3RlZEN1c3RvbWVyLnBob25lfWAgOiBcIlwifVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApLFxyXG5cclxuICAgICAgb2tUZXh0OiBhY3Rpb24gPT09IFwibGlua1wiID8gXCJZZXMsIExpbmtcIiA6IFwiWWVzLCBVbmxpbmtcIixcclxuICAgICAgY2FuY2VsVGV4dDogXCJDYW5jZWxcIixcclxuXHJcbiAgICAgIGNlbnRlcmVkOiB0cnVlLFxyXG5cclxuICAgICAgb2tCdXR0b25Qcm9wczoge1xyXG4gICAgICAgIGRhbmdlcjogYWN0aW9uID09PSBcInVubGlua1wiLFxyXG4gICAgICB9LFxyXG5cclxuICAgICAgb25PazogYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGF3YWl0IHBlcmZvcm1CdWxrQWN0aW9uKGFjdGlvbik7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICAvLyBBUEkgQ0FMTCBGT1IgQlVMSyBBQ1RJT05cclxuICBjb25zdCBwZXJmb3JtQnVsa0FjdGlvbiA9IGFzeW5jIChhY3Rpb24pID0+IHtcclxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIGVucm9sbElkczogc2VsZWN0ZWRFbnJvbGxtZW50SWRzLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgZW5kcG9pbnQgPVxyXG4gICAgICAgIGFjdGlvbiA9PT0gXCJ1bmxpbmtcIlxyXG4gICAgICAgICAgPyBcIi92MS9hZG1pbi9lbnJvbGxzL3VubGluay1icmFuY2hcIlxyXG4gICAgICAgICAgOiBcIi92MS9hZG1pbi9lbnJvbGxzL2xpbmstYnJhbmNoXCI7XHJcblxyXG4gICAgICBhd2FpdCBhcGkucGF0Y2goZW5kcG9pbnQsIHBheWxvYWQpO1xyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTpcclxuICAgICAgICAgIGFjdGlvbiA9PT0gXCJsaW5rXCJcclxuICAgICAgICAgICAgPyBgJHtzZWxlY3RlZEVucm9sbG1lbnRJZHMubGVuZ3RofSBlbnJvbGxtZW50KHMpIGxpbmtlZCBzdWNjZXNzZnVsbHkuYFxyXG4gICAgICAgICAgICA6IGAke3NlbGVjdGVkRW5yb2xsbWVudElkcy5sZW5ndGh9IGVucm9sbG1lbnQocykgdW5saW5rZWQgc3VjY2Vzc2Z1bGx5LmAsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50SWRzKFtdKTtcclxuICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihgRmFpbGVkIHRvICR7YWN0aW9ufSBlbnJvbGxtZW50czpgLCBlcnJvcik7XHJcblxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IGBGYWlsZWQgdG8gJHthY3Rpb259IGVucm9sbG1lbnRzLmAsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gSEFORExFIFRBQiBDSEFOR0VcclxuICBjb25zdCBoYW5kbGVUYWJDaGFuZ2UgPSAodGFiKSA9PiB7XHJcbiAgICBzZXRBY3RpdmVUYWIodGFiKTtcclxuICAgIHNldFNlbGVjdGVkRW1wbG95ZWVJZChcIlwiKTtcclxuICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgIHNldFNlbGVjdGVkQ3VzdG9tZXJJZChcIlwiKTtcclxuICAgIHNldEN1c3RvbWVyU2VhcmNoKFwiXCIpO1xyXG4gICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50SWRzKFtdKTtcclxuICAgIHNldFNlbGVjdEFsbChmYWxzZSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuXHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcbiAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNyBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRW5yb2xsbWVudCBMaW5rIC8gVW5saW5rXHJcbiAgICAgICAgICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIE1hbmFnZSBsaW5rZWQgYW5kIHVubGlua2VkIGVucm9sbG1lbnRzIGluIGJ1bGsuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIG1iLTVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVGFiQ2hhbmdlKFwibGlua2VkXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNiBweS00IHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiAke1xyXG4gICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwibGlua2VkXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ibHVlLTcwMCBib3JkZXItYi0yIGJvcmRlci1ibHVlLTcwMCBiZy1ibHVlLTUwXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIExpbmtlZCBFbnJvbGxtZW50c1xyXG4gICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgdGV4dC14cyByb3VuZGVkLWZ1bGwgJHtcclxuICAgICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwibGlua2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNjAwXCJcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtsaW5rZWRUb3RhbH1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUYWJDaGFuZ2UoXCJ1bmxpbmtlZFwiKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTYgcHktNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgJHtcclxuICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcInVubGlua2VkXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1yZWQtNzAwIGJvcmRlci1iLTIgYm9yZGVyLXJlZC03MDAgYmctcmVkLTUwXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgVW5saW5rZWQgRW5yb2xsbWVudHNcclxuICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIgcHktMC41IHRleHQteHMgcm91bmRlZC1mdWxsICR7XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcInVubGlua2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS0xMDAgdGV4dC1ncmF5LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7dW5saW5rZWRUb3RhbH1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC01IG1iLTVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgey8qIEdyb3VwIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgR3JvdXBcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cElkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZCh2YWx1ZSB8fCBcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBTdHJpbmcob3B0aW9uPy5jaGlsZHJlbiB8fCBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsIEdyb3VwczwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuaWR9IHZhbHVlPXtncm91cC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBDdXN0b21lciBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDdXN0b21lcklkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXJJZCh2YWx1ZSB8fCBcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBTdHJpbmcob3B0aW9uPy5jaGlsZHJlbiB8fCBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsIEN1c3RvbWVyczwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAge2N1c3RvbWVyT3B0aW9ucy5tYXAoKGN1c3RvbWVyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtjdXN0b21lci5pZH0gdmFsdWU9e2N1c3RvbWVyLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lci5uYW1lfXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lci5waG9uZSA/IGB8ICR7Y3VzdG9tZXIucGhvbmV9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRW1wbG95ZWUgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRFbXBsb3llZUlkKHZhbHVlIHx8IFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIFN0cmluZyhvcHRpb24/LmNoaWxkcmVuIHx8IFwiXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgRW1wbG95ZWVzPC9TZWxlY3QuT3B0aW9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2VtcGxveWVlT3B0aW9ucy5tYXAoKGVtcGxveWVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXBsb3llZS5pZH0gdmFsdWU9e2VtcGxveWVlLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlLnBob25lID8gYCB8ICR7ZW1wbG95ZWUucGhvbmV9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogQnVsayBBY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBqdXN0aWZ5LWVuZCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0ZWQ6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbnJvbGxtZW50SWRzLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgPC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHttb2RpZnlQYXltZW50ICYmXHJcbiAgICAgICAgICAgICAgICAgIChhY3RpdmVUYWIgPT09IFwibGlua2VkXCIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzU3VibWl0dGluZyB8fCBzZWxlY3RlZEVucm9sbG1lbnRJZHMubGVuZ3RoID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVCdWxrQWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgcm91bmRlZC1sZyBiZy1yZWQtNjAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1yZWQtNzAwIGRpc2FibGVkOmJnLWdyYXktMzAwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCJQcm9jZXNzaW5nLi4uXCIgOiBcIlVubGluayBTZWxlY3RlZFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc1N1Ym1pdHRpbmcgfHwgc2VsZWN0ZWRFbnJvbGxtZW50SWRzLmxlbmd0aCA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQnVsa0FjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMi41IHJvdW5kZWQtbGcgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1ncmVlbi03MDAgZGlzYWJsZWQ6YmctZ3JheS0zMDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyBcIlByb2Nlc3NpbmcuLi5cIiA6IFwiTGluayBTZWxlY3RlZFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogU2VsZWN0ZWQgZmlsdGVycyBpbmZvICovfVxyXG4gICAgICAgICAgICB7KHNlbGVjdGVkRW1wbG95ZWVJZCB8fCBzZWxlY3RlZEdyb3VwSWQgfHwgc2VsZWN0ZWRDdXN0b21lcklkKSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB4LTQgcHktMyByb3VuZGVkLWxnIGJnLWJsdWUtNTAgYm9yZGVyIGJvcmRlci1ibHVlLTEwMCB0ZXh0LXNtIHRleHQtYmx1ZS04MDAgZmxleCBmbGV4LXdyYXAgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlSWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICBFbXBsb3llZTp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlPy5uYW1lIHx8IFwiU2VsZWN0ZWQgRW1wbG95ZWVcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEdyb3VwSWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cDp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57c2VsZWN0ZWRHcm91cD8ubmFtZSB8fCBcIlNlbGVjdGVkIEdyb3VwXCJ9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDdXN0b21lcklkICYmIChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXI6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDdXN0b21lcj8ubmFtZSB8fCBcIlNlbGVjdGVkIEN1c3RvbWVyXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU0VMRUNUIEFMTCAqL31cclxuICAgICAgICAgIHshaXNMb2FkaW5nICYmIHRhYmxlRGF0YS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHAtMyBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCBjdXJzb3ItcG9pbnRlciBhY2NlbnQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTZWxlY3RBbGxDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0QWxsID8gXCJEZXNlbGVjdCBBbGxcIiA6IFwiU2VsZWN0IEFsbFwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVucm9sbG1lbnRJZHMubGVuZ3RofSBvZiB7dGFibGVEYXRhLmxlbmd0aH0gc2VsZWN0ZWRcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogVEFCTEUgKi99XHJcbiAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICBpc0xvYWRpbmc9e3RydWV9XHJcbiAgICAgICAgICAgICAgZmFpbHVyZT17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgZGF0YT1cIkVucm9sbG1lbnQgRGF0YVwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApIDogdGFibGVEYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICBkYXRhPXt0YWJsZURhdGF9XHJcbiAgICAgICAgICAgICAgY29sdW1ucz17dW5saW5rRW5yb2xsQ29sdW1uc31cclxuICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICBpc0V4cG9ydEVuYWJsZWQ9e3RydWV9XHJcbiAgICAgICAgICAgICAgaXNTZWFyY2hSZXF1aXJlZD17dHJ1ZX1cclxuICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e1xyXG4gICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcImxpbmtlZFwiXHJcbiAgICAgICAgICAgICAgICAgID8gXCJMaW5rZWQgRW5yb2xsbWVudHNcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiVW5saW5rZWQgRW5yb2xsbWVudHNcIlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJsaW5rZWRcIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiTGlua2VkRW5yb2xsbWVudHMuY3N2XCJcclxuICAgICAgICAgICAgICAgICAgOiBcIlVubGlua2VkRW5yb2xsbWVudHMuY3N2XCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICBpc0xvYWRpbmc9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgIGZhaWx1cmU9e3RydWV9XHJcbiAgICAgICAgICAgICAgZGF0YT17XHJcbiAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwibGlua2VkXCJcclxuICAgICAgICAgICAgICAgICAgPyBcIkxpbmtlZCBFbnJvbGxtZW50c1wiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJVbmxpbmtlZCBFbnJvbGxtZW50c1wiXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVW5saW5rRW5yb2xsbWVudDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1VubGlua0Vucm9sbG1lbnQuanN4In0=