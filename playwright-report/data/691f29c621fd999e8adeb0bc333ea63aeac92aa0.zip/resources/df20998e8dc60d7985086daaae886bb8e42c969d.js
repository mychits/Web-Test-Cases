import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EnrollmentReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { Dropdown, Select, Row, Col, Card } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  UserOutlined,
  TeamOutlined,
  AppstoreOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const EnrollmentReport = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableGroups, setTableGroups] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [referredType, selectedreferredBy] = useState("All");
  const [leads, setLeads] = useState([]);
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [showFilterField, setShowFilterField] = useState(false);
  const [selectedLabel, setSelectedLabel] = useState("OneWeek");
  const [searchText, setSearchText] = useState("");
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const handleGroupChange = (value) => {
    setSelectedGroup(value);
  };
  const handleReferredBy = (value) => {
    selectedreferredBy(value);
  };
  const now = /* @__PURE__ */ new Date();
  const todayString = now.toISOString().split("T")[0];
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedToDate, setSelectedToDate] = useState(todayString);
  const [selectedLeadSourceName, setSelectedLeadSourceName] = useState("");
  const [selectedPaymentType, setSelectedPaymentType] = useState("");
  const [selectedNote, setSelectedNote] = useState("");
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  const referredByOptions = useMemo(
    () => [...new Set(TableGroups.map((u) => u.referred_by))].filter(Boolean),
    [TableGroups]
  );
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get("/agent/get-agent");
        setAgents(response.data);
      } catch (error) {
        console.error("Error fetching agent data:", error);
      }
    };
    fetchAgents();
  }, []);
  const filteredTableData = useMemo(() => {
    return TableGroups.filter((row) => {
      const matchReferredBy = referredType === "All" || !referredType ? true : row.referred_by === referredType;
      return matchReferredBy;
    });
  }, [TableGroups, referredType]);
  useEffect(() => {
    handleSelectFilter(selectedLabel);
  }, []);
  const overview = useMemo(() => {
    const customerSet = new Set(
      filteredTableData.map((row) => row.customer_id)
    );
    const enrollmentSet = new Set(
      filteredTableData.map(
        (row) => `${row.customer_id}_${row.group_name}_${row.ticket}`
      )
    );
    const groupSet = new Set(
      filteredTableData.map((row) => row.group_name)
    );
    const totalBusiness = filteredTableData.reduce(
      (sum, row) => sum + (Number(row.group_value) || 0),
      0
    );
    const totalPaid = filteredTableData.reduce(
      (sum, row) => sum + (Number(row.total_paid) || 0),
      0
    );
    const totalPayable = filteredTableData.reduce(
      (sum, row) => sum + (Number(row.total_payable) || 0),
      0
    );
    const totalBalance = filteredTableData.reduce(
      (sum, row) => sum + (Number(row.balance) || 0),
      0
    );
    return {
      totalCustomers: customerSet.size,
      totalEnrollments: enrollmentSet.size,
      totalGroups: groupSet.size,
      totalBusiness,
      totalPaid,
      totalPayable,
      totalBalance
    };
  }, [filteredTableData]);
  useEffect(() => {
    const fetchEnrollmentData = async () => {
      setIsLoading(true);
      try {
        const response = await api.get(
          `/v1/admin/enrolls?from_date=${selectedFromDate}&to_date=${selectedToDate}&group_id=${selectedGroup}`
        );
        if (response.data) {
          setLeads(response.data?.data);
          const formattedData = response.data?.data?.map((group, index) => {
            if (!group.group_id || !group.user_id) return null;
            return {
              _id: group?._id,
              id: index + 1,
              // Customer Details
              customer_id: group?.user_id?.customer_id,
              name: group?.user_id?.full_name || "N/A",
              phone_number: group?.user_id?.phone_number || "N/A",
              // Group Details
              group_name: group?.group_id?.group_name || "N/A",
              group_type: group?.group_id?.group_type || "N/A",
              group_value: group?.group_id?.group_value || 0,
              group_install: group?.group_id?.group_install || 0,
              monthly_installment: group?.group_id?.monthly_installment || 0,
              // Chit Details
              ticket: group?.tickets || 0,
              payment_type: group?.payment_type || "N/A",
              chit_asking_month: group?.chit_asking_month || "",
              customer_status: group?.customer_status || "N/A",
              // Payment Details
              total_payable: group?.total_payable || 0,
              total_paid: group?.total_investment || 0,
              balance: group?.total_balance || 0,
              total_profit: group?.total_profit || 0,
              total_penalty: group?.total_penalty || 0,
              total_late_fee: group?.total_late_fee || 0,
              // Dates
              enrollment_date: group?.createdAt ? group.createdAt.split("T")[0] : "",
              // Referred Details FIXED
              referred_type: group?.referred_type || "",
              referred_by: group?.referred_agent?.name && group?.referred_agent?.phone_number ? `${group.referred_agent.name} | ${group.referred_agent.phone_number}` : group?.referred_customer?.full_name && group?.referred_customer?.phone_number ? `${group.referred_customer.full_name} | ${group.referred_customer.phone_number}` : group?.referred_lead?.lead_name && group?.referred_lead?.agent_number ? `${group.referred_lead.lead_name} | ${group.referred_lead.agent_number}` : "",
              // Collection Area Details
              collection_area: group?.user_id?.collection_area?.route_name || "N/A",
              route_pincode: group?.user_id?.collection_area?.route_pincode || "N/A",
              // Relationship Manager
              relationship_manager: group?.group_id?.relationship_manager?.name && group?.group_id?.relationship_manager?.phone_number ? `${group.group_id.relationship_manager.name} | ${group.group_id.relationship_manager.phone_number}` : "N/A",
              // Auction Details if available
              next_auction_date: group?.next_auction_date || "N/A",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(group._id),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                            lineNumber: 256,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleDeleteModalOpen(group._id),
                            children: "Delete"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                            lineNumber: 267,
                            columnNumber: 23
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                    lineNumber: 279,
                    columnNumber: 21
                  }, this)
                },
                group?._id,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                  lineNumber: 249,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                lineNumber: 248,
                columnNumber: 15
              }, this)
            };
          }).filter(Boolean);
          setTableGroups(formattedData);
        }
      } catch (error) {
        console.error("Error fetching Enrollment data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchEnrollmentData();
  }, [selectedFromDate, selectedToDate, selectedGroup]);
  const groupOptions = [
    { value: "All", label: "All" },
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "OneWeek", label: "One Week" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "OneWeek") {
      const today2 = /* @__PURE__ */ new Date();
      const fromDate = /* @__PURE__ */ new Date();
      fromDate.setDate(today2.getDate() - 7);
      const toDate = /* @__PURE__ */ new Date();
      setSelectedFromDate(formatDate(fromDate));
      setSelectedToDate(formatDate(toDate));
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "All") {
      const start = new Date(2e3, 0, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "customer_id", header: "Customer ID" },
    { key: "name", header: "Customer Name" },
    { key: "enrollment_date", header: "Enrollment Date" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "group_type", header: "Group Type" },
    { key: "ticket", header: "Ticket" },
    { key: "group_value", header: "Group Value" },
    { key: "group_install", header: "Group Installment" },
    { key: "monthly_installment", header: "Monthly Installment" },
    { key: "total_paid", header: "Amount Paid" },
    { key: "total_penalty", header: "Total Penalty" },
    { key: "total_late_fee", header: "Total Late Fee" },
    { key: "total_payable", header: "Payable Amount" },
    { key: "balance", header: "Balance" },
    { key: "total_profit", header: "Total Profit" },
    { key: "payment_type", header: "Payment Type" },
    { key: "customer_status", header: "Customer Status" },
    { key: "chit_asking_month", header: "Chit Asking Month" },
    { key: "referred_type", header: "Referred Type" },
    { key: "referred_by", header: "Referred By" },
    { key: "collection_area", header: "Collection Area" },
    { key: "route_pincode", header: "Route Pincode" },
    { key: "relationship_manager", header: "Relationship Manager" },
    { key: "next_auction_date", header: "Next Auction Date" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-hidden", children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
        lineNumber: 397,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: " flex-1 mt-30", children: [
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
          lineNumber: 402,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-7", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "font-bold text-2xl", children: " Reports - Enrollment " }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
          lineNumber: 408,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-6 w-full", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2", children: "Filter Option" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
              lineNumber: 414,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                onChange: handleSelectFilter,
                value: selectedLabel || void 0,
                placeholder: "Search Or Select Filter",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-64 h-11",
                children: groupOptions.map(
                  (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                    lineNumber: 427,
                    columnNumber: 23
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                lineNumber: 415,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
            lineNumber: 413,
            columnNumber: 19
          }, this),
          showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2", children: "From Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                lineNumber: 437,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedFromDate,
                  onChange: (e) => setSelectedFromDate(e.target.value),
                  className: "border border-gray-300 rounded px-4 py-2 h-11 w-64 shadow-sm outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                  lineNumber: 438,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
              lineNumber: 436,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2", children: "To Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                lineNumber: 447,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedToDate,
                  onChange: (e) => setSelectedToDate(e.target.value),
                  className: "border border-gray-300 rounded px-4 py-2 h-11 w-64 shadow-sm outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                  lineNumber: 448,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
              lineNumber: 446,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
            lineNumber: 435,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2", children: "Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
              lineNumber: 460,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                placeholder: "Search Or Select Group",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-64 h-11",
                value: selectedGroup,
                onChange: handleGroupChange,
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                    lineNumber: 472,
                    columnNumber: 23
                  }, this),
                  groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                      lineNumber: 474,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                lineNumber: 461,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
            lineNumber: 459,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2 min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Referred By" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
              lineNumber: 483,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                allowClear: false,
                className: "w-64 h-11",
                placeholder: "Select Referred By",
                optionFilterProp: "children",
                filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
                value: referredType,
                onChange: handleReferredBy,
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                    lineNumber: 502,
                    columnNumber: 23
                  }, this),
                  referredByOptions.map(
                    (referrer) => /* @__PURE__ */ jsxDEV(Select.Option, { value: referrer, children: referrer }, referrer, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                      lineNumber: 505,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                lineNumber: 486,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
            lineNumber: 482,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
          lineNumber: 411,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
          lineNumber: 410,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
          lineNumber: 409,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Row, { gutter: [20, 20], className: "mb-6", children: [
          {
            title: "Total Customers",
            value: overview.totalCustomers,
            color: "text-blue-600"
          },
          {
            title: "Total Enrollments",
            value: overview.totalEnrollments,
            color: "text-green-600"
          },
          {
            title: "Total Groups",
            value: overview.totalGroups,
            color: "text-purple-600"
          },
          {
            title: "Total Business",
            value: `₹${overview.totalBusiness.toLocaleString("en-IN")}`,
            color: "text-orange-600"
          },
          {
            title: "Total Paid",
            value: `₹${overview.totalPaid.toLocaleString("en-IN")}`,
            color: "text-green-600"
          },
          {
            title: "Total Payable",
            value: `₹${overview.totalPayable.toLocaleString("en-IN")}`,
            color: "text-red-600"
          },
          {
            title: "Total Balance",
            value: `₹${overview.totalBalance.toLocaleString("en-IN")}`,
            color: "text-indigo-600"
          }
        ].map(
          (item, index) => /* @__PURE__ */ jsxDEV(
            Col,
            {
              xs: 24,
              sm: 12,
              md: 8,
              lg: 6,
              xl: 24 / 7,
              children: /* @__PURE__ */ jsxDEV(
                Card,
                {
                  bordered: false,
                  className: "rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 w-full",
                  bodyStyle: { padding: 20 },
                  children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm font-medium truncate", children: item.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                      lineNumber: 566,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("h2", { className: `text-lg xl:text-xl font-bold mt-1 ${item.color} break-words`, children: item.value }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                      lineNumber: 570,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                    lineNumber: 565,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
                  lineNumber: 560,
                  columnNumber: 19
                },
                this
              )
            },
            index,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
              lineNumber: 552,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
          lineNumber: 514,
          columnNumber: 13
        }, this),
        TableGroups && TableGroups.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-auto scrollbar-thin", children: /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(filteredTableData, searchText),
            columns,
            exportedPdfName: `Enrollment Report`,
            exportedFileName: `Enrollment Report.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
            lineNumber: 580,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
          lineNumber: 579,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex w-full justify-center items-center", children: [
          /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading,
              failure: TableGroups.length <= 0,
              data: "Enrollment Data"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
              lineNumber: 589,
              columnNumber: 17
            },
            this
          ),
          ";"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
          lineNumber: 588,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
        lineNumber: 407,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
      lineNumber: 401,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
    lineNumber: 396,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx",
    lineNumber: 395,
    columnNumber: 5
  }, this);
};
_s(EnrollmentReport, "XyRmOevGTxdqhQGPsf6czc/3ykU=");
_c = EnrollmentReport;
export default EnrollmentReport;
var _c;
$RefreshReg$(_c, "EnrollmentReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK1A0QixTQW1MUixVQW5MUTsyQkEvUDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsU0FBU0MsZ0JBQWdCO0FBQzdDLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxVQUFVQyxRQUFRQyxLQUFLQyxLQUFLQyxZQUFZO0FBQ2pEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLE1BQU1DLG1CQUFtQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzdCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJbkIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ29CLGFBQWFDLGNBQWMsSUFBSXJCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNzQixXQUFXQyxZQUFZLElBQUl2QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDd0IsZUFBZUMsZ0JBQWdCLElBQUl6QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDMEIsY0FBY0Msa0JBQWtCLElBQUkzQixTQUFTLEtBQUs7QUFDekQsUUFBTSxDQUFDNEIsT0FBT0MsUUFBUSxJQUFJN0IsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzhCLE9BQU9DLFFBQVEsSUFBSS9CLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNnQyxRQUFRQyxTQUFTLElBQUlqQyxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDa0MsaUJBQWlCQyxrQkFBa0IsSUFBSW5DLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNvQyxlQUFlQyxnQkFBZ0IsSUFBSXJDLFNBQVMsU0FBUztBQUM1RCxRQUFNLENBQUNzQyxZQUFZQyxhQUFhLElBQUl2QyxTQUFTLEVBQUU7QUFDL0MsUUFBTXdDLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6Q0Ysa0JBQWNFLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxFQUM5QjtBQUNBLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJN0MsU0FBUztBQUFBLElBQzdDOEMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBS0QsUUFBTUMsb0JBQW9CQSxDQUFDTixVQUFVO0FBQ25DbEIscUJBQWlCa0IsS0FBSztBQUFBLEVBQ3hCO0FBRUEsUUFBTU8sbUJBQW1CQSxDQUFDUCxVQUFVO0FBQ2xDaEIsdUJBQW1CZ0IsS0FBSztBQUFBLEVBQzFCO0FBR0EsUUFBTVEsTUFBTSxvQkFBSUMsS0FBSztBQUNyQixRQUFNQyxjQUFjRixJQUFJRyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbEQsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJekQsU0FBU3FELFdBQVc7QUFDcEUsUUFBTSxDQUFDSyxnQkFBZ0JDLGlCQUFpQixJQUFJM0QsU0FBU3FELFdBQVc7QUFDaEUsUUFBTSxDQUFDTyx3QkFBd0JDLHlCQUF5QixJQUFJN0QsU0FBUyxFQUFFO0FBQ3ZFLFFBQU0sQ0FBQzhELHFCQUFxQkMsc0JBQXNCLElBQUkvRCxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDZ0UsY0FBY0MsZUFBZSxJQUFJakUsU0FBUyxFQUFFO0FBRW5ERixZQUFVLE1BQU07QUFDZCxVQUFNb0UsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU1sRSxJQUFJbUUsSUFBSSx3QkFBd0I7QUFDdkRqRCxrQkFBVWdELFNBQVNFLElBQUk7QUFBQSxNQUN6QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBSixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBZUwsUUFBTU0sb0JBQW9CekU7QUFBQUEsSUFDeEIsTUFBTSxDQUFDLEdBQUcsSUFBSTBFLElBQUlyRCxZQUFZc0QsSUFBSSxDQUFDQyxNQUFNQSxFQUFFQyxXQUFXLENBQUMsQ0FBQyxFQUFFQyxPQUFPQyxPQUFPO0FBQUEsSUFDeEUsQ0FBQzFELFdBQVc7QUFBQSxFQUNkO0FBRUF0QixZQUFVLE1BQU07QUFDZCxVQUFNaUYsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNWixXQUFXLE1BQU1sRSxJQUFJbUUsSUFBSSxrQkFBa0I7QUFDakRuQyxrQkFBVWtDLFNBQVNFLElBQUk7QUFBQSxNQUN6QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBUyxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUwsUUFBTUMsb0JBQW9CakYsUUFBUSxNQUFNO0FBQ3RDLFdBQU9xQixZQUFZeUQsT0FBTyxDQUFDSSxRQUFRO0FBQ2pDLFlBQU1DLGtCQUNKeEQsaUJBQWlCLFNBQVMsQ0FBQ0EsZUFDdkIsT0FDQXVELElBQUlMLGdCQUFnQmxEO0FBRTFCLGFBQU93RDtBQUFBQSxJQUNULENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQzlELGFBQWFNLFlBQVksQ0FBQztBQUU5QjVCLFlBQVUsTUFBTTtBQUNkcUYsdUJBQW1CL0MsYUFBYTtBQUFBLEVBQ2xDLEdBQUcsRUFBRTtBQUVMLFFBQU1nRCxXQUFXckYsUUFBUSxNQUFNO0FBQzdCLFVBQU1zRixjQUFjLElBQUlaO0FBQUFBLE1BQ3RCTyxrQkFBa0JOLElBQUksQ0FBQ08sUUFBUUEsSUFBSUssV0FBVztBQUFBLElBQ2hEO0FBRUEsVUFBTUMsZ0JBQWdCLElBQUlkO0FBQUFBLE1BQ3hCTyxrQkFBa0JOO0FBQUFBLFFBQ2hCLENBQUNPLFFBQVEsR0FBR0EsSUFBSUssV0FBVyxJQUFJTCxJQUFJTyxVQUFVLElBQUlQLElBQUlRLE1BQU07QUFBQSxNQUM3RDtBQUFBLElBQ0Y7QUFFQSxVQUFNQyxXQUFXLElBQUlqQjtBQUFBQSxNQUNuQk8sa0JBQWtCTixJQUFJLENBQUNPLFFBQVFBLElBQUlPLFVBQVU7QUFBQSxJQUMvQztBQUVBLFVBQU1HLGdCQUFnQlgsa0JBQWtCWTtBQUFBQSxNQUN0QyxDQUFDQyxLQUFLWixRQUFRWSxPQUFPQyxPQUFPYixJQUFJYyxXQUFXLEtBQUs7QUFBQSxNQUNoRDtBQUFBLElBQ0Y7QUFFQSxVQUFNQyxZQUFZaEIsa0JBQWtCWTtBQUFBQSxNQUNsQyxDQUFDQyxLQUFLWixRQUFRWSxPQUFPQyxPQUFPYixJQUFJZ0IsVUFBVSxLQUFLO0FBQUEsTUFDL0M7QUFBQSxJQUNGO0FBRUEsVUFBTUMsZUFBZWxCLGtCQUFrQlk7QUFBQUEsTUFDckMsQ0FBQ0MsS0FBS1osUUFBUVksT0FBT0MsT0FBT2IsSUFBSWtCLGFBQWEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUVBLFVBQU1DLGVBQWVwQixrQkFBa0JZO0FBQUFBLE1BQ3JDLENBQUNDLEtBQUtaLFFBQVFZLE9BQU9DLE9BQU9iLElBQUlvQixPQUFPLEtBQUs7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsTUFDTEMsZ0JBQWdCakIsWUFBWWtCO0FBQUFBLE1BQzVCQyxrQkFBa0JqQixjQUFjZ0I7QUFBQUEsTUFDaENFLGFBQWFmLFNBQVNhO0FBQUFBLE1BQ3RCWjtBQUFBQSxNQUNBSztBQUFBQSxNQUNBRTtBQUFBQSxNQUNBRTtBQUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUNwQixpQkFBaUIsQ0FBQztBQUd0QmxGLFlBQVUsTUFBTTtBQUNkLFVBQU00RyxzQkFBc0IsWUFBWTtBQUN0Q25GLG1CQUFhLElBQUk7QUFDakIsVUFBSTtBQUNGLGNBQU00QyxXQUFXLE1BQU1sRSxJQUFJbUU7QUFBQUEsVUFDekIsK0JBQStCWixnQkFBZ0IsWUFBWUUsY0FBYyxhQUFhbEMsYUFBYTtBQUFBLFFBQ3JHO0FBQ0EsWUFBSTJDLFNBQVNFLE1BQU07QUFDakJ4QyxtQkFBU3NDLFNBQVNFLE1BQU1BLElBQUk7QUFFNUIsZ0JBQU1zQyxnQkFBZ0J4QyxTQUFTRSxNQUFNQSxNQUFNSyxJQUFJLENBQUNrQyxPQUFPQyxVQUFVO0FBQy9ELGdCQUFJLENBQUNELE1BQU1FLFlBQVksQ0FBQ0YsTUFBTUcsUUFBUyxRQUFPO0FBRTlDLG1CQUFPO0FBQUEsY0FDTEMsS0FBS0osT0FBT0k7QUFBQUEsY0FDWkMsSUFBSUosUUFBUTtBQUFBO0FBQUEsY0FHWnZCLGFBQWFzQixPQUFPRyxTQUFTekI7QUFBQUEsY0FDN0I0QixNQUFNTixPQUFPRyxTQUFTSSxhQUFhO0FBQUEsY0FDbkNDLGNBQWNSLE9BQU9HLFNBQVNLLGdCQUFnQjtBQUFBO0FBQUEsY0FHOUM1QixZQUFZb0IsT0FBT0UsVUFBVXRCLGNBQWM7QUFBQSxjQUMzQzZCLFlBQVlULE9BQU9FLFVBQVVPLGNBQWM7QUFBQSxjQUMzQ3RCLGFBQWFhLE9BQU9FLFVBQVVmLGVBQWU7QUFBQSxjQUM3Q3VCLGVBQWVWLE9BQU9FLFVBQVVRLGlCQUFpQjtBQUFBLGNBQ2pEQyxxQkFBcUJYLE9BQU9FLFVBQVVTLHVCQUF1QjtBQUFBO0FBQUEsY0FHN0Q5QixRQUFRbUIsT0FBT1ksV0FBVztBQUFBLGNBQzFCQyxjQUFjYixPQUFPYSxnQkFBZ0I7QUFBQSxjQUNyQ0MsbUJBQW1CZCxPQUFPYyxxQkFBcUI7QUFBQSxjQUMvQ0MsaUJBQWlCZixPQUFPZSxtQkFBbUI7QUFBQTtBQUFBLGNBRzNDeEIsZUFBZVMsT0FBT1QsaUJBQWlCO0FBQUEsY0FDdkNGLFlBQVlXLE9BQU9nQixvQkFBb0I7QUFBQSxjQUN2Q3ZCLFNBQVNPLE9BQU9pQixpQkFBaUI7QUFBQSxjQUNqQ0MsY0FBY2xCLE9BQU9rQixnQkFBZ0I7QUFBQSxjQUNyQ0MsZUFBZW5CLE9BQU9tQixpQkFBaUI7QUFBQSxjQUN2Q0MsZ0JBQWdCcEIsT0FBT29CLGtCQUFrQjtBQUFBO0FBQUEsY0FHekNDLGlCQUFpQnJCLE9BQU9zQixZQUNwQnRCLE1BQU1zQixVQUFVM0UsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUM1QjtBQUFBO0FBQUEsY0FJSjRFLGVBQWV2QixPQUFPdUIsaUJBQWlCO0FBQUEsY0FFdkN2RCxhQUNFZ0MsT0FBT3dCLGdCQUFnQmxCLFFBQVFOLE9BQU93QixnQkFBZ0JoQixlQUNsRCxHQUFHUixNQUFNd0IsZUFBZWxCLElBQUksTUFBTU4sTUFBTXdCLGVBQWVoQixZQUFZLEtBQ25FUixPQUFPeUIsbUJBQW1CbEIsYUFDMUJQLE9BQU95QixtQkFBbUJqQixlQUN4QixHQUFHUixNQUFNeUIsa0JBQWtCbEIsU0FBUyxNQUFNUCxNQUFNeUIsa0JBQWtCakIsWUFBWSxLQUM5RVIsT0FBTzBCLGVBQWVDLGFBQ3RCM0IsT0FBTzBCLGVBQWVFLGVBQ3BCLEdBQUc1QixNQUFNMEIsY0FBY0MsU0FBUyxNQUFNM0IsTUFBTTBCLGNBQWNFLFlBQVksS0FDdEU7QUFBQTtBQUFBLGNBSVZDLGlCQUNFN0IsT0FBT0csU0FBUzBCLGlCQUFpQkMsY0FBYztBQUFBLGNBRWpEQyxlQUNFL0IsT0FBT0csU0FBUzBCLGlCQUFpQkUsaUJBQWlCO0FBQUE7QUFBQSxjQUlwREMsc0JBQ0VoQyxPQUFPRSxVQUFVOEIsc0JBQXNCMUIsUUFDckNOLE9BQU9FLFVBQVU4QixzQkFBc0J4QixlQUNyQyxHQUFHUixNQUFNRSxTQUFTOEIscUJBQXFCMUIsSUFBSSxNQUFNTixNQUFNRSxTQUFTOEIscUJBQXFCeEIsWUFBWSxLQUNqRztBQUFBO0FBQUEsY0FJTnlCLG1CQUNFakMsT0FBT2lDLHFCQUFxQjtBQUFBLGNBRzlCQyxRQUNFLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxNQUFNO0FBQUEsb0JBQ0pDLE9BQU87QUFBQSxzQkFDTDtBQUFBLHdCQUNFQyxLQUFLO0FBQUEsd0JBQ0xDLE9BQ0U7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVMsTUFBTUMsc0JBQXNCdEMsTUFBTUksR0FBRztBQUFBLDRCQUFFO0FBQUE7QUFBQSwwQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsc0JBRUo7QUFBQSxzQkFDQTtBQUFBLHdCQUNFZ0MsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQU1FLHNCQUFzQnZDLE1BQU1JLEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUM7QUFBQSxrQkFFTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQVM7QUFBQTtBQUFBLGdCQTdCSkosT0FBT0k7QUFBQUEsZ0JBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQStCQSxLQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlDQTtBQUFBLFlBRUo7QUFBQSxVQUNGLENBQUMsRUFBRW5DLE9BQU9DLE9BQU87QUFDakJ6RCx5QkFBZXNGLGFBQWE7QUFBQSxRQUM5QjtBQUFBLE1BQ0YsU0FBU3JDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQUEsTUFDeEQsVUFBQztBQUNDL0MscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBbUYsd0JBQW9CO0FBQUEsRUFDdEIsR0FBRyxDQUFDbEQsa0JBQWtCRSxnQkFBZ0JsQyxhQUFhLENBQUM7QUFJcEQsUUFBTTRILGVBQWU7QUFBQSxJQUNuQixFQUFFekcsT0FBTyxPQUFPc0csT0FBTyxNQUFNO0FBQUEsSUFDN0IsRUFBRXRHLE9BQU8sU0FBU3NHLE9BQU8sUUFBUTtBQUFBLElBQ2pDLEVBQUV0RyxPQUFPLGFBQWFzRyxPQUFPLFlBQVk7QUFBQSxJQUN6QyxFQUFFdEcsT0FBTyxXQUFXc0csT0FBTyxXQUFXO0FBQUEsSUFDdEMsRUFBRXRHLE9BQU8sYUFBYXNHLE9BQU8sYUFBYTtBQUFBLElBQzFDLEVBQUV0RyxPQUFPLGFBQWFzRyxPQUFPLGFBQWE7QUFBQSxJQUMxQyxFQUFFdEcsT0FBTyxZQUFZc0csT0FBTyxZQUFZO0FBQUEsSUFDeEMsRUFBRXRHLE9BQU8sVUFBVXNHLE9BQU8sU0FBUztBQUFBLEVBQUM7QUFHdEMsUUFBTTlELHFCQUFxQkEsQ0FBQ3hDLFVBQVU7QUFFcENOLHFCQUFpQk0sS0FBSztBQUN0QlIsdUJBQW1CLEtBQUs7QUFFeEIsVUFBTWtILFFBQVEsb0JBQUlqRyxLQUFLO0FBQ3ZCLFVBQU1rRyxhQUFhQSxDQUFDQyxTQUFTQSxLQUFLQyxtQkFBbUIsT0FBTztBQUU1RCxRQUFJN0csVUFBVSxTQUFTO0FBQ3JCLFlBQU04RyxZQUFZSCxXQUFXRCxLQUFLO0FBQ2xDNUYsMEJBQW9CZ0csU0FBUztBQUM3QjlGLHdCQUFrQjhGLFNBQVM7QUFBQSxJQUU3QixXQUFXOUcsVUFBVSxhQUFhO0FBQ2hDLFlBQU0rRyxZQUFZLElBQUl0RyxLQUFLaUcsS0FBSztBQUNoQ0ssZ0JBQVVDLFFBQVFELFVBQVVFLFFBQVEsSUFBSSxDQUFDO0FBQ3pDLFlBQU1ILFlBQVlILFdBQVdJLFNBQVM7QUFDdENqRywwQkFBb0JnRyxTQUFTO0FBQzdCOUYsd0JBQWtCOEYsU0FBUztBQUFBLElBRTdCLFdBQ1M5RyxVQUFVLFdBQVc7QUFDNUIsWUFBTTBHLFNBQVEsb0JBQUlqRyxLQUFLO0FBQ3ZCLFlBQU15RyxXQUFXLG9CQUFJekcsS0FBSztBQUMxQnlHLGVBQVNGLFFBQVFOLE9BQU1PLFFBQVEsSUFBSSxDQUFDO0FBQ3BDLFlBQU1FLFNBQVMsb0JBQUkxRyxLQUFLO0FBQ3hCSywwQkFBb0I2RixXQUFXTyxRQUFRLENBQUM7QUFDeENsRyx3QkFBa0IyRixXQUFXUSxNQUFNLENBQUM7QUFBQSxJQUN0QyxXQUFXbkgsVUFBVSxhQUFhO0FBQ2hDLFlBQU1vSCxRQUFRLElBQUkzRyxLQUFLaUcsTUFBTVcsWUFBWSxHQUFHWCxNQUFNWSxTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUk5RyxLQUFLaUcsTUFBTVcsWUFBWSxHQUFHWCxNQUFNWSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFeEcsMEJBQW9CNkYsV0FBV1MsS0FBSyxDQUFDO0FBQ3JDcEcsd0JBQWtCMkYsV0FBV1ksR0FBRyxDQUFDO0FBQUEsSUFFbkMsV0FBV3ZILFVBQVUsYUFBYTtBQUNoQyxZQUFNb0gsUUFBUSxJQUFJM0csS0FBS2lHLE1BQU1XLFlBQVksR0FBR1gsTUFBTVksU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNuRSxZQUFNQyxNQUFNLElBQUk5RyxLQUFLaUcsTUFBTVcsWUFBWSxHQUFHWCxNQUFNWSxTQUFTLEdBQUcsQ0FBQztBQUM3RHhHLDBCQUFvQjZGLFdBQVdTLEtBQUssQ0FBQztBQUNyQ3BHLHdCQUFrQjJGLFdBQVdZLEdBQUcsQ0FBQztBQUFBLElBRW5DLFdBQVd2SCxVQUFVLFlBQVk7QUFDL0IsWUFBTW9ILFFBQVEsSUFBSTNHLEtBQUtpRyxNQUFNVyxZQUFZLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQU1FLE1BQU0sSUFBSTlHLEtBQUtpRyxNQUFNVyxZQUFZLEdBQUcsSUFBSSxFQUFFO0FBQ2hEdkcsMEJBQW9CNkYsV0FBV1MsS0FBSyxDQUFDO0FBQ3JDcEcsd0JBQWtCMkYsV0FBV1ksR0FBRyxDQUFDO0FBQUEsSUFDbkMsV0FBV3ZILFVBQVUsT0FBTztBQUMxQixZQUFNb0gsUUFBUSxJQUFJM0csS0FBSyxLQUFNLEdBQUcsQ0FBQztBQUNqQyxZQUFNOEcsTUFBTSxJQUFJOUcsS0FBS2lHLE1BQU1XLFlBQVksR0FBR1gsTUFBTVksU0FBUyxHQUFHWixNQUFNTyxRQUFRLENBQUM7QUFDM0VuRywwQkFBb0I2RixXQUFXUyxLQUFLLENBQUM7QUFDckNwRyx3QkFBa0IyRixXQUFXWSxHQUFHLENBQUM7QUFBQSxJQUNuQyxXQUFXdkgsVUFBVSxVQUFVO0FBQzdCUix5QkFBbUIsSUFBSTtBQUFBLElBQ3pCO0FBQUEsRUFFRjtBQUNBLFFBQU1nSSxVQUFVO0FBQUEsSUFDZCxFQUFFbkIsS0FBSyxNQUFNb0IsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRXBCLEtBQUssZUFBZW9CLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVwQixLQUFLLFFBQVFvQixRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUVwQixLQUFLLG1CQUFtQm9CLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRXBCLEtBQUssZ0JBQWdCb0IsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRXBCLEtBQUssY0FBY29CLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVwQixLQUFLLGNBQWNvQixRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFcEIsS0FBSyxVQUFVb0IsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRXBCLEtBQUssZUFBZW9CLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVwQixLQUFLLGlCQUFpQm9CLFFBQVEsb0JBQW9CO0FBQUEsSUFDcEQsRUFBRXBCLEtBQUssdUJBQXVCb0IsUUFBUSxzQkFBc0I7QUFBQSxJQUM1RCxFQUFFcEIsS0FBSyxjQUFjb0IsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRXBCLEtBQUssaUJBQWlCb0IsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFcEIsS0FBSyxrQkFBa0JvQixRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUVwQixLQUFLLGlCQUFpQm9CLFFBQVEsaUJBQWlCO0FBQUEsSUFDakQsRUFBRXBCLEtBQUssV0FBV29CLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVwQixLQUFLLGdCQUFnQm9CLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVwQixLQUFLLGdCQUFnQm9CLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVwQixLQUFLLG1CQUFtQm9CLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRXBCLEtBQUsscUJBQXFCb0IsUUFBUSxvQkFBb0I7QUFBQSxJQUN4RCxFQUFFcEIsS0FBSyxpQkFBaUJvQixRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUVwQixLQUFLLGVBQWVvQixRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFcEIsS0FBSyxtQkFBbUJvQixRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVwQixLQUFLLGlCQUFpQm9CLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRXBCLEtBQUssd0JBQXdCb0IsUUFBUSx1QkFBdUI7QUFBQSxJQUM5RCxFQUFFcEIsS0FBSyxxQkFBcUJvQixRQUFRLG9CQUFvQjtBQUFBLEVBQUM7QUFJM0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsU0FDQztBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTXhILFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBO0FBQUFBLFFBSHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUcrQjtBQUFBLE1BRS9CLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHNCQUFxQixzQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RDtBQUFBLFFBQ3pELHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGNBQWEsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDO0FBQUEsWUFDM0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLHVCQUF1QjtBQUFBLGdCQUN2QixVQUFVb0M7QUFBQUEsZ0JBQ1YsT0FBTy9DLGlCQUFpQmlJO0FBQUFBLGdCQUN4QixhQUFZO0FBQUEsZ0JBQ1osY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0MsU0FBUyxFQUFFQyxZQUFZLEVBQUVDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGdCQUV2RSxXQUFVO0FBQUEsZ0JBRVR0Qix1QkFBYTFFO0FBQUFBLGtCQUFJLENBQUNrRyxTQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBK0IsT0FBT0EsS0FBS2pJLE9BQ3pDaUksZUFBSzNCLFNBRFkyQixLQUFLakksT0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdCQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFFQ1QsbUJBQ0MsbUNBQ0U7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxjQUFhLHlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBQ3ZDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPc0I7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDZixNQUFNZ0Isb0JBQW9CaEIsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGtCQUNuRCxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJdUY7QUFBQSxpQkFOekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsY0FBYSx1QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUNyQztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2U7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDakIsTUFBTWtCLGtCQUFrQmxCLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxrQkFDakQsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXVGO0FBQUEsaUJBTnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBSUYsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYSxxQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUM7QUFBQSxZQUNuQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLGFBQVk7QUFBQSxnQkFDWixjQUFjLENBQUMySCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0MsU0FBUyxFQUFFQyxZQUFZLEVBQUVDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGdCQUV2RSxXQUFVO0FBQUEsZ0JBQ1YsT0FBT2xKO0FBQUFBLGdCQUNQLFVBQVV5QjtBQUFBQSxnQkFFVjtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQSxrQkFDMUIvQixPQUFPd0Q7QUFBQUEsb0JBQUksQ0FBQ2tDLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1JLEtBQ3pDSixnQkFBTXBCLGNBRFdvQixNQUFNSSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBaUJBO0FBQUEsZUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBR0M7QUFBQSxnQkFDQSxZQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixrQkFBaUI7QUFBQSxnQkFDakIsY0FBYyxDQUFDc0QsT0FBT0MsWUFDbkJBLFFBQVFDLFlBQVksSUFDbEJFLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU9oSjtBQUFBQSxnQkFDUCxVQUFVd0I7QUFBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLE9BQU0sbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEsa0JBRTdCc0Isa0JBQWtCRTtBQUFBQSxvQkFBSSxDQUFDbUcsYUFDdEIsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLFVBQ2xDQSxzQkFEaUJBLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF1QkE7QUFBQSxlQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRCQTtBQUFBLGFBbkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvR0EsS0FyR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNHQSxLQXZHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0dBO0FBQUEsUUFDQSx1QkFBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FBRyxXQUFVLFFBQzlCO0FBQUEsVUFDQztBQUFBLFlBQ0VDLE9BQU87QUFBQSxZQUNQbkksT0FBT3lDLFNBQVNrQjtBQUFBQSxZQUNoQnlFLE9BQU87QUFBQSxVQUNUO0FBQUEsVUFDQTtBQUFBLFlBQ0VELE9BQU87QUFBQSxZQUNQbkksT0FBT3lDLFNBQVNvQjtBQUFBQSxZQUNoQnVFLE9BQU87QUFBQSxVQUNUO0FBQUEsVUFDQTtBQUFBLFlBQ0VELE9BQU87QUFBQSxZQUNQbkksT0FBT3lDLFNBQVNxQjtBQUFBQSxZQUNoQnNFLE9BQU87QUFBQSxVQUNUO0FBQUEsVUFDQTtBQUFBLFlBQ0VELE9BQU87QUFBQSxZQUNQbkksT0FBTyxJQUFJeUMsU0FBU08sY0FBY3FGLGVBQWUsT0FBTyxDQUFDO0FBQUEsWUFDekRELE9BQU87QUFBQSxVQUNUO0FBQUEsVUFDQTtBQUFBLFlBQ0VELE9BQU87QUFBQSxZQUNQbkksT0FBTyxJQUFJeUMsU0FBU1ksVUFBVWdGLGVBQWUsT0FBTyxDQUFDO0FBQUEsWUFDckRELE9BQU87QUFBQSxVQUNUO0FBQUEsVUFDQTtBQUFBLFlBQ0VELE9BQU87QUFBQSxZQUNQbkksT0FBTyxJQUFJeUMsU0FBU2MsYUFBYThFLGVBQWUsT0FBTyxDQUFDO0FBQUEsWUFDeERELE9BQU87QUFBQSxVQUNUO0FBQUEsVUFDQTtBQUFBLFlBQ0VELE9BQU87QUFBQSxZQUNQbkksT0FBTyxJQUFJeUMsU0FBU2dCLGFBQWE0RSxlQUFlLE9BQU8sQ0FBQztBQUFBLFlBQ3hERCxPQUFPO0FBQUEsVUFDVDtBQUFBLFFBQUMsRUFDRHJHO0FBQUFBLFVBQUksQ0FBQ3VHLE1BQU1wRSxVQUNYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxJQUFJO0FBQUEsY0FDSixJQUFJO0FBQUEsY0FDSixJQUFJO0FBQUEsY0FDSixJQUFJO0FBQUEsY0FDSixJQUFJLEtBQUs7QUFBQSxjQUVUO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFVBQVU7QUFBQSxrQkFDVixXQUFVO0FBQUEsa0JBQ1YsV0FBVyxFQUFFcUUsU0FBUyxHQUFHO0FBQUEsa0JBRXpCLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLDhDQUNWRCxlQUFLSCxTQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxRQUFHLFdBQVcscUNBQXFDRyxLQUFLRixLQUFLLGdCQUMzREUsZUFBS3RJLFNBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQTtBQUFBLGdCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWNBO0FBQUE7QUFBQSxZQXJCS2tFO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXVCQTtBQUFBLFFBQ0QsS0E5REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStEQTtBQUFBLFFBQ0N6RixlQUFlQSxZQUFZK0osU0FBUyxLQUFLLENBQUM3SixZQUN6Qyx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU1mLGFBQWF5RSxtQkFBbUIxQyxVQUFVO0FBQUEsWUFDaEQ7QUFBQSxZQUNBLGlCQUFpQjtBQUFBLFlBQ2pCLGtCQUFrQjtBQUFBO0FBQUEsVUFKcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSTRDLEtBTDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsU0FBU2xCLFlBQVkrSixVQUFVO0FBQUEsY0FDL0IsTUFBSztBQUFBO0FBQUEsWUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHd0I7QUFBQSxVQUFHO0FBQUEsYUFKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0ExTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRMQTtBQUFBLFNBbE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtTUE7QUFBQSxPQXhNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeU1BLEtBMU1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyTUE7QUFFSjtBQUFFbEssR0F2a0JJRCxrQkFBZ0I7QUFBQW9LLEtBQWhCcEs7QUF5a0JOLGVBQWVBO0FBQWlCLElBQUFvSztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJJb01kTW9yZSIsIkNpcmN1bGFyTG9hZGVyIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiRHJvcGRvd24iLCJTZWxlY3QiLCJSb3ciLCJDb2wiLCJDYXJkIiwiVXNlck91dGxpbmVkIiwiVGVhbU91dGxpbmVkIiwiQXBwc3RvcmVPdXRsaW5lZCIsIkVucm9sbG1lbnRSZXBvcnQiLCJfcyIsImdyb3VwcyIsInNldEdyb3VwcyIsIlRhYmxlR3JvdXBzIiwic2V0VGFibGVHcm91cHMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsInJlZmVycmVkVHlwZSIsInNlbGVjdGVkcmVmZXJyZWRCeSIsImxlYWRzIiwic2V0TGVhZHMiLCJ1c2VycyIsInNldFVzZXJzIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwic2VsZWN0ZWRMYWJlbCIsInNldFNlbGVjdGVkTGFiZWwiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJoYW5kbGVHcm91cENoYW5nZSIsImhhbmRsZVJlZmVycmVkQnkiLCJub3ciLCJEYXRlIiwidG9kYXlTdHJpbmciLCJ0b0lTT1N0cmluZyIsInNwbGl0Iiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZFRvRGF0ZSIsInNldFNlbGVjdGVkVG9EYXRlIiwic2VsZWN0ZWRMZWFkU291cmNlTmFtZSIsInNldFNlbGVjdGVkTGVhZFNvdXJjZU5hbWUiLCJzZWxlY3RlZFBheW1lbnRUeXBlIiwic2V0U2VsZWN0ZWRQYXltZW50VHlwZSIsInNlbGVjdGVkTm90ZSIsInNldFNlbGVjdGVkTm90ZSIsImZldGNoR3JvdXBzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwicmVmZXJyZWRCeU9wdGlvbnMiLCJTZXQiLCJtYXAiLCJ1IiwicmVmZXJyZWRfYnkiLCJmaWx0ZXIiLCJCb29sZWFuIiwiZmV0Y2hBZ2VudHMiLCJmaWx0ZXJlZFRhYmxlRGF0YSIsInJvdyIsIm1hdGNoUmVmZXJyZWRCeSIsImhhbmRsZVNlbGVjdEZpbHRlciIsIm92ZXJ2aWV3IiwiY3VzdG9tZXJTZXQiLCJjdXN0b21lcl9pZCIsImVucm9sbG1lbnRTZXQiLCJncm91cF9uYW1lIiwidGlja2V0IiwiZ3JvdXBTZXQiLCJ0b3RhbEJ1c2luZXNzIiwicmVkdWNlIiwic3VtIiwiTnVtYmVyIiwiZ3JvdXBfdmFsdWUiLCJ0b3RhbFBhaWQiLCJ0b3RhbF9wYWlkIiwidG90YWxQYXlhYmxlIiwidG90YWxfcGF5YWJsZSIsInRvdGFsQmFsYW5jZSIsImJhbGFuY2UiLCJ0b3RhbEN1c3RvbWVycyIsInNpemUiLCJ0b3RhbEVucm9sbG1lbnRzIiwidG90YWxHcm91cHMiLCJmZXRjaEVucm9sbG1lbnREYXRhIiwiZm9ybWF0dGVkRGF0YSIsImdyb3VwIiwiaW5kZXgiLCJncm91cF9pZCIsInVzZXJfaWQiLCJfaWQiLCJpZCIsIm5hbWUiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJncm91cF90eXBlIiwiZ3JvdXBfaW5zdGFsbCIsIm1vbnRobHlfaW5zdGFsbG1lbnQiLCJ0aWNrZXRzIiwicGF5bWVudF90eXBlIiwiY2hpdF9hc2tpbmdfbW9udGgiLCJjdXN0b21lcl9zdGF0dXMiLCJ0b3RhbF9pbnZlc3RtZW50IiwidG90YWxfYmFsYW5jZSIsInRvdGFsX3Byb2ZpdCIsInRvdGFsX3BlbmFsdHkiLCJ0b3RhbF9sYXRlX2ZlZSIsImVucm9sbG1lbnRfZGF0ZSIsImNyZWF0ZWRBdCIsInJlZmVycmVkX3R5cGUiLCJyZWZlcnJlZF9hZ2VudCIsInJlZmVycmVkX2N1c3RvbWVyIiwicmVmZXJyZWRfbGVhZCIsImxlYWRfbmFtZSIsImFnZW50X251bWJlciIsImNvbGxlY3Rpb25fYXJlYSIsInJvdXRlX25hbWUiLCJyb3V0ZV9waW5jb2RlIiwicmVsYXRpb25zaGlwX21hbmFnZXIiLCJuZXh0X2F1Y3Rpb25fZGF0ZSIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJncm91cE9wdGlvbnMiLCJ0b2RheSIsImZvcm1hdERhdGUiLCJkYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZm9ybWF0dGVkIiwieWVzdGVyZGF5Iiwic2V0RGF0ZSIsImdldERhdGUiLCJmcm9tRGF0ZSIsInRvRGF0ZSIsInN0YXJ0IiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImVuZCIsImNvbHVtbnMiLCJoZWFkZXIiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidGltZSIsInJlZmVycmVyIiwidGl0bGUiLCJjb2xvciIsInRvTG9jYWxlU3RyaW5nIiwiaXRlbSIsInBhZGRpbmciLCJsZW5ndGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJFbnJvbGxtZW50UmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHsgRHJvcGRvd24sIFNlbGVjdCwgUm93LCBDb2wsIENhcmQgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQge1xyXG4gIFVzZXJPdXRsaW5lZCxcclxuICBUZWFtT3V0bGluZWQsXHJcbiAgQXBwc3RvcmVPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmNvbnN0IEVucm9sbG1lbnRSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVHcm91cHMsIHNldFRhYmxlR3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyZWZlcnJlZFR5cGUsIHNlbGVjdGVkcmVmZXJyZWRCeV0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuICBjb25zdCBbbGVhZHMsIHNldExlYWRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93RmlsdGVyRmllbGQsIHNldFNob3dGaWx0ZXJGaWVsZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkTGFiZWwsIHNldFNlbGVjdGVkTGFiZWxdID0gdXNlU3RhdGUoXCJPbmVXZWVrXCIpXHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICAvLyBjb25zdCBoYW5kbGVHcm91cENoYW5nZSA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gIC8vICAgY29uc3QgZ3JvdXBJZCA9IGV2ZW50LnRhcmdldC52YWx1ZTtcclxuICAvLyAgIHNldFNlbGVjdGVkR3JvdXAoZ3JvdXBJZCk7XHJcbiAgLy8gfTtcclxuICBjb25zdCBoYW5kbGVHcm91cENoYW5nZSA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVmZXJyZWRCeSA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2VsZWN0ZWRyZWZlcnJlZEJ5KHZhbHVlKTtcclxuICB9O1xyXG5cclxuXHJcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKVxyXG4gIGNvbnN0IHRvZGF5U3RyaW5nID0gbm93LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXHJcbiAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUodG9kYXlTdHJpbmcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFRvRGF0ZSwgc2V0U2VsZWN0ZWRUb0RhdGVdID0gdXNlU3RhdGUodG9kYXlTdHJpbmcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExlYWRTb3VyY2VOYW1lLCBzZXRTZWxlY3RlZExlYWRTb3VyY2VOYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBheW1lbnRUeXBlLCBzZXRTZWxlY3RlZFBheW1lbnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZE5vdGUsIHNldFNlbGVjdGVkTm90ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgLy8gICAgIHRyeSB7XHJcbiAgLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgLy8gICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgZGF0YTpcIiwgZXJyb3IpO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9O1xyXG4gIC8vICAgZmV0Y2hVc2VycygpO1xyXG4gIC8vIH0sIFtdKTtcclxuXHJcbiAgLy8gR2V0IHVuaXF1ZSByZWZlcnJlZCBieSBvcHRpb25zXHJcbiAgY29uc3QgcmVmZXJyZWRCeU9wdGlvbnMgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gWy4uLm5ldyBTZXQoVGFibGVHcm91cHMubWFwKCh1KSA9PiB1LnJlZmVycmVkX2J5KSldLmZpbHRlcihCb29sZWFuKSxcclxuICAgIFtUYWJsZUdyb3Vwc10sXHJcbiAgKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXQtYWdlbnRcIik7XHJcbiAgICAgICAgc2V0QWdlbnRzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhZ2VudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEFnZW50cygpO1xyXG4gIH0sIFtdKTtcclxuICAvLyBDcmVhdGUgYSBmaWx0ZXJlZCBhcnJheSBiYXNlZCBvbiB0aGUgc2VsZWN0ZWQgcmVmZXJyZWRfYnlcclxuICBjb25zdCBmaWx0ZXJlZFRhYmxlRGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIFRhYmxlR3JvdXBzLmZpbHRlcigocm93KSA9PiB7XHJcbiAgICAgIGNvbnN0IG1hdGNoUmVmZXJyZWRCeSA9XHJcbiAgICAgICAgcmVmZXJyZWRUeXBlID09PSBcIkFsbFwiIHx8ICFyZWZlcnJlZFR5cGVcclxuICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgOiByb3cucmVmZXJyZWRfYnkgPT09IHJlZmVycmVkVHlwZTtcclxuXHJcbiAgICAgIHJldHVybiBtYXRjaFJlZmVycmVkQnk7XHJcbiAgICB9KTtcclxuICB9LCBbVGFibGVHcm91cHMsIHJlZmVycmVkVHlwZV0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaGFuZGxlU2VsZWN0RmlsdGVyKHNlbGVjdGVkTGFiZWwpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3Qgb3ZlcnZpZXcgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGN1c3RvbWVyU2V0ID0gbmV3IFNldChcclxuICAgICAgZmlsdGVyZWRUYWJsZURhdGEubWFwKChyb3cpID0+IHJvdy5jdXN0b21lcl9pZClcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgZW5yb2xsbWVudFNldCA9IG5ldyBTZXQoXHJcbiAgICAgIGZpbHRlcmVkVGFibGVEYXRhLm1hcChcclxuICAgICAgICAocm93KSA9PiBgJHtyb3cuY3VzdG9tZXJfaWR9XyR7cm93Lmdyb3VwX25hbWV9XyR7cm93LnRpY2tldH1gXHJcbiAgICAgIClcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgZ3JvdXBTZXQgPSBuZXcgU2V0KFxyXG4gICAgICBmaWx0ZXJlZFRhYmxlRGF0YS5tYXAoKHJvdykgPT4gcm93Lmdyb3VwX25hbWUpXHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsQnVzaW5lc3MgPSBmaWx0ZXJlZFRhYmxlRGF0YS5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHJvdykgPT4gc3VtICsgKE51bWJlcihyb3cuZ3JvdXBfdmFsdWUpIHx8IDApLFxyXG4gICAgICAwXHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsUGFpZCA9IGZpbHRlcmVkVGFibGVEYXRhLnJlZHVjZShcclxuICAgICAgKHN1bSwgcm93KSA9PiBzdW0gKyAoTnVtYmVyKHJvdy50b3RhbF9wYWlkKSB8fCAwKSxcclxuICAgICAgMFxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCB0b3RhbFBheWFibGUgPSBmaWx0ZXJlZFRhYmxlRGF0YS5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHJvdykgPT4gc3VtICsgKE51bWJlcihyb3cudG90YWxfcGF5YWJsZSkgfHwgMCksXHJcbiAgICAgIDBcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgdG90YWxCYWxhbmNlID0gZmlsdGVyZWRUYWJsZURhdGEucmVkdWNlKFxyXG4gICAgICAoc3VtLCByb3cpID0+IHN1bSArIChOdW1iZXIocm93LmJhbGFuY2UpIHx8IDApLFxyXG4gICAgICAwXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsQ3VzdG9tZXJzOiBjdXN0b21lclNldC5zaXplLFxyXG4gICAgICB0b3RhbEVucm9sbG1lbnRzOiBlbnJvbGxtZW50U2V0LnNpemUsXHJcbiAgICAgIHRvdGFsR3JvdXBzOiBncm91cFNldC5zaXplLFxyXG4gICAgICB0b3RhbEJ1c2luZXNzLFxyXG4gICAgICB0b3RhbFBhaWQsXHJcbiAgICAgIHRvdGFsUGF5YWJsZSxcclxuICAgICAgdG90YWxCYWxhbmNlLFxyXG4gICAgfTtcclxuICB9LCBbZmlsdGVyZWRUYWJsZURhdGFdKTtcclxuXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVucm9sbG1lbnREYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgYC92MS9hZG1pbi9lbnJvbGxzP2Zyb21fZGF0ZT0ke3NlbGVjdGVkRnJvbURhdGV9JnRvX2RhdGU9JHtzZWxlY3RlZFRvRGF0ZX0mZ3JvdXBfaWQ9JHtzZWxlY3RlZEdyb3VwfWBcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgICBzZXRMZWFkcyhyZXNwb25zZS5kYXRhPy5kYXRhKTtcclxuXHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YT8ubWFwKChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFncm91cC5ncm91cF9pZCB8fCAhZ3JvdXAudXNlcl9pZCkgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIF9pZDogZ3JvdXA/Ll9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG5cclxuICAgICAgICAgICAgICAvLyBDdXN0b21lciBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IGdyb3VwPy51c2VyX2lkPy5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcblxyXG4gICAgICAgICAgICAgIC8vIEdyb3VwIERldGFpbHNcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICBncm91cF90eXBlOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX3R5cGUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICBncm91cF92YWx1ZTogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSB8fCAwLFxyXG4gICAgICAgICAgICAgIGdyb3VwX2luc3RhbGw6IGdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfaW5zdGFsbCB8fCAwLFxyXG4gICAgICAgICAgICAgIG1vbnRobHlfaW5zdGFsbG1lbnQ6IGdyb3VwPy5ncm91cF9pZD8ubW9udGhseV9pbnN0YWxsbWVudCB8fCAwLFxyXG5cclxuICAgICAgICAgICAgICAvLyBDaGl0IERldGFpbHNcclxuICAgICAgICAgICAgICB0aWNrZXQ6IGdyb3VwPy50aWNrZXRzIHx8IDAsXHJcbiAgICAgICAgICAgICAgcGF5bWVudF90eXBlOiBncm91cD8ucGF5bWVudF90eXBlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IGdyb3VwPy5jaGl0X2Fza2luZ19tb250aCB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgIGN1c3RvbWVyX3N0YXR1czogZ3JvdXA/LmN1c3RvbWVyX3N0YXR1cyB8fCBcIk4vQVwiLFxyXG5cclxuICAgICAgICAgICAgICAvLyBQYXltZW50IERldGFpbHNcclxuICAgICAgICAgICAgICB0b3RhbF9wYXlhYmxlOiBncm91cD8udG90YWxfcGF5YWJsZSB8fCAwLFxyXG4gICAgICAgICAgICAgIHRvdGFsX3BhaWQ6IGdyb3VwPy50b3RhbF9pbnZlc3RtZW50IHx8IDAsXHJcbiAgICAgICAgICAgICAgYmFsYW5jZTogZ3JvdXA/LnRvdGFsX2JhbGFuY2UgfHwgMCxcclxuICAgICAgICAgICAgICB0b3RhbF9wcm9maXQ6IGdyb3VwPy50b3RhbF9wcm9maXQgfHwgMCxcclxuICAgICAgICAgICAgICB0b3RhbF9wZW5hbHR5OiBncm91cD8udG90YWxfcGVuYWx0eSB8fCAwLFxyXG4gICAgICAgICAgICAgIHRvdGFsX2xhdGVfZmVlOiBncm91cD8udG90YWxfbGF0ZV9mZWUgfHwgMCxcclxuXHJcbiAgICAgICAgICAgICAgLy8gRGF0ZXNcclxuICAgICAgICAgICAgICBlbnJvbGxtZW50X2RhdGU6IGdyb3VwPy5jcmVhdGVkQXRcclxuICAgICAgICAgICAgICAgID8gZ3JvdXAuY3JlYXRlZEF0LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgOiBcIlwiLFxyXG5cclxuXHJcbiAgICAgICAgICAgICAgLy8gUmVmZXJyZWQgRGV0YWlscyBGSVhFRFxyXG4gICAgICAgICAgICAgIHJlZmVycmVkX3R5cGU6IGdyb3VwPy5yZWZlcnJlZF90eXBlIHx8IFwiXCIsXHJcblxyXG4gICAgICAgICAgICAgIHJlZmVycmVkX2J5OlxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LnJlZmVycmVkX2FnZW50Py5uYW1lICYmIGdyb3VwPy5yZWZlcnJlZF9hZ2VudD8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAucmVmZXJyZWRfYWdlbnQubmFtZX0gfCAke2dyb3VwLnJlZmVycmVkX2FnZW50LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgIDogZ3JvdXA/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICBncm91cD8ucmVmZXJyZWRfY3VzdG9tZXI/LnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAucmVmZXJyZWRfY3VzdG9tZXIuZnVsbF9uYW1lfSB8ICR7Z3JvdXAucmVmZXJyZWRfY3VzdG9tZXIucGhvbmVfbnVtYmVyfWBcclxuICAgICAgICAgICAgICAgICAgICA6IGdyb3VwPy5yZWZlcnJlZF9sZWFkPy5sZWFkX25hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5yZWZlcnJlZF9sZWFkPy5hZ2VudF9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAucmVmZXJyZWRfbGVhZC5sZWFkX25hbWV9IHwgJHtncm91cC5yZWZlcnJlZF9sZWFkLmFnZW50X251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiXCIsXHJcblxyXG5cclxuICAgICAgICAgICAgICAvLyBDb2xsZWN0aW9uIEFyZWEgRGV0YWlsc1xyXG4gICAgICAgICAgICAgIGNvbGxlY3Rpb25fYXJlYTpcclxuICAgICAgICAgICAgICAgIGdyb3VwPy51c2VyX2lkPy5jb2xsZWN0aW9uX2FyZWE/LnJvdXRlX25hbWUgfHwgXCJOL0FcIixcclxuXHJcbiAgICAgICAgICAgICAgcm91dGVfcGluY29kZTpcclxuICAgICAgICAgICAgICAgIGdyb3VwPy51c2VyX2lkPy5jb2xsZWN0aW9uX2FyZWE/LnJvdXRlX3BpbmNvZGUgfHwgXCJOL0FcIixcclxuXHJcblxyXG4gICAgICAgICAgICAgIC8vIFJlbGF0aW9uc2hpcCBNYW5hZ2VyXHJcbiAgICAgICAgICAgICAgcmVsYXRpb25zaGlwX21hbmFnZXI6XHJcbiAgICAgICAgICAgICAgICBncm91cD8uZ3JvdXBfaWQ/LnJlbGF0aW9uc2hpcF9tYW5hZ2VyPy5uYW1lICYmXHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwPy5ncm91cF9pZD8ucmVsYXRpb25zaGlwX21hbmFnZXI/LnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgICAgICA/IGAke2dyb3VwLmdyb3VwX2lkLnJlbGF0aW9uc2hpcF9tYW5hZ2VyLm5hbWV9IHwgJHtncm91cC5ncm91cF9pZC5yZWxhdGlvbnNoaXBfbWFuYWdlci5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcblxyXG5cclxuICAgICAgICAgICAgICAvLyBBdWN0aW9uIERldGFpbHMgaWYgYXZhaWxhYmxlXHJcbiAgICAgICAgICAgICAgbmV4dF9hdWN0aW9uX2RhdGU6XHJcbiAgICAgICAgICAgICAgICBncm91cD8ubmV4dF9hdWN0aW9uX2RhdGUgfHwgXCJOL0FcIixcclxuXHJcblxyXG4gICAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2dyb3VwPy5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pLmZpbHRlcihCb29sZWFuKTtcclxuICAgICAgICAgIHNldFRhYmxlR3JvdXBzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgRW5yb2xsbWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW5yb2xsbWVudERhdGEoKTtcclxuICB9LCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2VsZWN0ZWRUb0RhdGUsIHNlbGVjdGVkR3JvdXBdKTtcclxuXHJcblxyXG5cclxuICBjb25zdCBncm91cE9wdGlvbnMgPSBbXHJcbiAgICB7IHZhbHVlOiBcIkFsbFwiLCBsYWJlbDogXCJBbGxcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJUb2RheVwiLCBsYWJlbDogXCJUb2RheVwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlllc3RlcmRheVwiLCBsYWJlbDogXCJZZXN0ZXJkYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJPbmVXZWVrXCIsIGxhYmVsOiBcIk9uZSBXZWVrXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgLy8gY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWxlY3RlZExhYmVsKHZhbHVlKVxyXG4gICAgc2V0U2hvd0ZpbHRlckZpZWxkKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1DQScpO1xyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdHRlZCk7XHJcblxyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHllc3RlcmRheS5zZXREYXRlKHllc3RlcmRheS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdHRlZCk7XHJcblxyXG4gICAgfVxyXG4gICAgZWxzZSBpZiAodmFsdWUgPT09IFwiT25lV2Vla1wiKSB7XHJcbiAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgICAgY29uc3QgZnJvbURhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICBmcm9tRGF0ZS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIDcpO1xyXG4gICAgICBjb25zdCB0b0RhdGUgPSBuZXcgRGF0ZSgpOyAvLyB0b2RheVxyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoZnJvbURhdGUpKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZm9ybWF0RGF0ZSh0b0RhdGUpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuXHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcblxyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJBbGxcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKDIwMDAsIDAsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCB0b2RheS5nZXREYXRlKCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuICAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKHRydWUpXHJcbiAgICB9XHJcblxyXG4gIH07XHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfaWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElEXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW5yb2xsbWVudF9kYXRlXCIsIGhlYWRlcjogXCJFbnJvbGxtZW50IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF90eXBlXCIsIGhlYWRlcjogXCJHcm91cCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX3ZhbHVlXCIsIGhlYWRlcjogXCJHcm91cCBWYWx1ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9pbnN0YWxsXCIsIGhlYWRlcjogXCJHcm91cCBJbnN0YWxsbWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJtb250aGx5X2luc3RhbGxtZW50XCIsIGhlYWRlcjogXCJNb250aGx5IEluc3RhbGxtZW50XCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX3BhaWRcIiwgaGVhZGVyOiBcIkFtb3VudCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX3BlbmFsdHlcIiwgaGVhZGVyOiBcIlRvdGFsIFBlbmFsdHlcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxfbGF0ZV9mZWVcIiwgaGVhZGVyOiBcIlRvdGFsIExhdGUgRmVlXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX3BheWFibGVcIiwgaGVhZGVyOiBcIlBheWFibGUgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxfcHJvZml0XCIsIGhlYWRlcjogXCJUb3RhbCBQcm9maXRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudF90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfc3RhdHVzXCIsIGhlYWRlcjogXCJDdXN0b21lciBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiY2hpdF9hc2tpbmdfbW9udGhcIiwgaGVhZGVyOiBcIkNoaXQgQXNraW5nIE1vbnRoXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkX3R5cGVcIiwgaGVhZGVyOiBcIlJlZmVycmVkIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRfYnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25fYXJlYVwiLCBoZWFkZXI6IFwiQ29sbGVjdGlvbiBBcmVhXCIgfSxcclxuICAgIHsga2V5OiBcInJvdXRlX3BpbmNvZGVcIiwgaGVhZGVyOiBcIlJvdXRlIFBpbmNvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVsYXRpb25zaGlwX21hbmFnZXJcIiwgaGVhZGVyOiBcIlJlbGF0aW9uc2hpcCBNYW5hZ2VyXCIgfSxcclxuICAgIHsga2V5OiBcIm5leHRfYXVjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJOZXh0IEF1Y3Rpb24gRGF0ZVwiIH0sXHJcbiAgXTtcclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBvdmVyZmxvdy14LWhpZGRlblwiPlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiIGZsZXgtMSBtdC0zMFwiPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0XHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBwLTdcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LTJ4bFwiPiBSZXBvcnRzIC0gRW5yb2xsbWVudCA8L2gxPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1lbmQgZ2FwLTYgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBGaWx0ZXIgT3B0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMlwiPkZpbHRlciBPcHRpb248L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0RmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGFiZWwgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IEZpbHRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTY0IGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKCh0aW1lKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dGltZS52YWx1ZX0gdmFsdWU9e3RpbWUudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0aW1lLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yXCI+RnJvbSBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEZyb21EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBoLTExIHctNjQgc2hhZG93LXNtIG91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTJcIj5UbyBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFRvRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkVG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGgtMTEgdy02NCBzaGFkb3ctc20gb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEdyb3VwICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMlwiPkdyb3VwPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IEdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNjQgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBSZWZlcnJlZCBCeSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yIG1pbi13LVsyMDBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUmVmZXJyZWQgQnlcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIC8vIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXI9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy02NCBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIEJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAob3B0aW9uPy5jaGlsZHJlbiA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cmVmZXJyZWRUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVJlZmVycmVkQnl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJBbGxcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAge3JlZmVycmVkQnlPcHRpb25zLm1hcCgocmVmZXJyZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWZlcnJlcn0gdmFsdWU9e3JlZmVycmVyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVmZXJyZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1syMCwgMjBdfSBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiVG90YWwgQ3VzdG9tZXJzXCIsXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlOiBvdmVydmlldy50b3RhbEN1c3RvbWVycyxcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IFwidGV4dC1ibHVlLTYwMFwiLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiVG90YWwgRW5yb2xsbWVudHNcIixcclxuICAgICAgICAgICAgICAgICAgdmFsdWU6IG92ZXJ2aWV3LnRvdGFsRW5yb2xsbWVudHMsXHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiBcInRleHQtZ3JlZW4tNjAwXCIsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJUb3RhbCBHcm91cHNcIixcclxuICAgICAgICAgICAgICAgICAgdmFsdWU6IG92ZXJ2aWV3LnRvdGFsR3JvdXBzLFxyXG4gICAgICAgICAgICAgICAgICBjb2xvcjogXCJ0ZXh0LXB1cnBsZS02MDBcIixcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlRvdGFsIEJ1c2luZXNzXCIsXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlOiBg4oK5JHtvdmVydmlldy50b3RhbEJ1c2luZXNzLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IFwidGV4dC1vcmFuZ2UtNjAwXCIsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJUb3RhbCBQYWlkXCIsXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlOiBg4oK5JHtvdmVydmlldy50b3RhbFBhaWQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICAgICAgICAgICAgICBjb2xvcjogXCJ0ZXh0LWdyZWVuLTYwMFwiLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiVG90YWwgUGF5YWJsZVwiLFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZTogYOKCuSR7b3ZlcnZpZXcudG90YWxQYXlhYmxlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IFwidGV4dC1yZWQtNjAwXCIsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJUb3RhbCBCYWxhbmNlXCIsXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlOiBg4oK5JHtvdmVydmlldy50b3RhbEJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICAgICAgICAgICAgICBjb2xvcjogXCJ0ZXh0LWluZGlnby02MDBcIixcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgXS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8Q29sXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgIHhzPXsyNH1cclxuICAgICAgICAgICAgICAgICAgc209ezEyfVxyXG4gICAgICAgICAgICAgICAgICBtZD17OH1cclxuICAgICAgICAgICAgICAgICAgbGc9ezZ9XHJcbiAgICAgICAgICAgICAgICAgIHhsPXsyNCAvIDd9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyZWQ9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIHNoYWRvdy1sZyBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgYm9keVN0eWxlPXt7IHBhZGRpbmc6IDIwIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9e2B0ZXh0LWxnIHhsOnRleHQteGwgZm9udC1ib2xkIG10LTEgJHtpdGVtLmNvbG9yfSBicmVhay13b3Jkc2B9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS52YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAge1RhYmxlR3JvdXBzICYmIFRhYmxlR3JvdXBzLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBvdmVyZmxvdy14LWF1dG8gc2Nyb2xsYmFyLXRoaW5cIj5cclxuICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGZpbHRlcmVkVGFibGVEYXRhLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgRW5yb2xsbWVudCBSZXBvcnRgfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgRW5yb2xsbWVudCBSZXBvcnQuY3N2YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgZmFpbHVyZT17VGFibGVHcm91cHMubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9XCJFbnJvbGxtZW50IERhdGFcIiAvPjtcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFbnJvbGxtZW50UmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRW5yb2xsbWVudFJlcG9ydC5qc3gifQ==