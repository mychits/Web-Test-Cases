import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AIChat.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"]




;
import __vite__cjsImport4_reactDom from "/node_modules/.vite/deps/react-dom.js?v=819e0a34"; const createPortal = __vite__cjsImport4_reactDom["createPortal"];
import {
  Bot,
  MessageCircle,
  Send,
  X,
  User,
  Trash2,
  Sparkles,
  Clock3
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { Input, Button } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import mainRoutes from "/src/routes/mainRoutes.jsx?t=1792822406834";
const formatRouteName = (path) => {
  if (!path || path === "/") {
    return "Dashboard";
  }
  const parts = path.split("/").filter(Boolean).filter((item) => item !== "*");
  if (!parts.length) {
    return "Dashboard";
  }
  const name = parts[parts.length - 1].replace(/[-_]/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
  return name;
};
const normalizeText = (text = "") => {
  return text.toLowerCase().replace(/[-_/]/g, " ").replace(/[^\w\s]/g, " ").replace(/\s+/g, " ").trim();
};
const getRouteArray = (routes) => {
  if (Array.isArray(routes)) {
    return routes;
  }
  if (routes?.routes && Array.isArray(routes.routes)) {
    return routes.routes;
  }
  if (routes?.children && Array.isArray(routes.children)) {
    return routes.children;
  }
  if (routes?.default && Array.isArray(routes.default)) {
    return routes.default;
  }
  return [];
};
const getAllRoutes = (routes, parentPath = "") => {
  const routeArray = getRouteArray(routes);
  if (!routeArray.length) {
    return [];
  }
  let result = [];
  routeArray.forEach((route) => {
    if (!route || typeof route !== "object") {
      return;
    }
    if (!route.path) {
      if (route.children) {
        result = [
          ...result,
          ...getAllRoutes(route.children, parentPath)
        ];
      }
      return;
    }
    let currentPath = route.path;
    if (parentPath && route.path !== "*" && !route.path.startsWith("/")) {
      currentPath = `${parentPath}/${route.path}`.replace(
        /\/+/g,
        "/"
      );
    }
    if (route.path === "*") {
      currentPath = parentPath;
    }
    if (currentPath && currentPath !== "*") {
      result.push({
        path: currentPath,
        name: formatRouteName(currentPath)
      });
    }
    if (route.children) {
      result = [
        ...result,
        ...getAllRoutes(route.children, currentPath)
      ];
    }
  });
  return result;
};
const INITIAL_MESSAGE = {
  id: 1,
  type: "ai",
  text: "Hello! 👋 I can help you find pages in MyChits. Ask me where you want to go."
};
const QUICK_ACTIONS = [
  "Dashboard",
  "Customer",
  "Payment",
  "Group",
  "Report",
  "Approval"
];
const AIChat = () => {
  _s();
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState(
    [
      INITIAL_MESSAGE
    ]
  );
  const [recentSearches, setRecentSearches] = useState(() => {
    try {
      const saved = localStorage.getItem("mychits_ai_recent_searches");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const inputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const allRoutes = useMemo(() => {
    return getAllRoutes(mainRoutes);
  }, []);
  const currentPageName = useMemo(() => {
    return formatRouteName(location.pathname);
  }, [location.pathname]);
  useEffect(() => {
    if (open) {
      const timer = setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [open]);
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth"
    });
  }, [messages, isTyping]);
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === "Escape" && open) {
        setOpen(false);
      }
    };
    window.addEventListener("keydown", handleEscape);
    return () => {
      window.removeEventListener("keydown", handleEscape);
    };
  }, [open]);
  const saveRecentSearch = (search) => {
    const cleanedSearch = search.trim();
    if (!cleanedSearch) {
      return;
    }
    setRecentSearches((prev) => {
      const updated = [
        cleanedSearch,
        ...prev.filter(
          (item) => item.toLowerCase() !== cleanedSearch.toLowerCase()
        )
      ].slice(0, 5);
      localStorage.setItem(
        "mychits_ai_recent_searches",
        JSON.stringify(updated)
      );
      return updated;
    });
  };
  const findMatchingRoutes = (input) => {
    const normalizedInput = normalizeText(input);
    if (!normalizedInput) {
      return [];
    }
    const inputWords = normalizedInput.split(" ");
    const results = allRoutes.map((route) => {
      const normalizedPath = normalizeText(route.path);
      const normalizedName = normalizeText(route.name);
      let score = 0;
      if (normalizedInput === normalizedName) {
        score += 200;
      }
      if (normalizedInput.includes(normalizedName)) {
        score += 100;
      }
      if (normalizedInput.includes(normalizedPath)) {
        score += 100;
      }
      inputWords.forEach((word) => {
        if (word.length < 3) {
          return;
        }
        if (normalizedName.includes(word)) {
          score += 20;
        }
        if (normalizedPath.includes(word)) {
          score += 10;
        }
      });
      return {
        ...route,
        score
      };
    }).filter((route) => route.score > 0).sort((a, b) => b.score - a.score);
    const uniqueRoutes = [];
    results.forEach((route) => {
      if (!uniqueRoutes.some(
        (item) => item.path === route.path
      )) {
        uniqueRoutes.push(route);
      }
    });
    return uniqueRoutes.slice(0, 3);
  };
  const getAIResponse = (input) => {
    const matchedRoutes = findMatchingRoutes(input);
    if (matchedRoutes.length > 0) {
      return {
        text: `I found ${matchedRoutes[0].name} for you.`,
        routes: matchedRoutes
      };
    }
    const suggestions = allRoutes.filter((route) => {
      const normalizedInput = normalizeText(input);
      const normalizedName = normalizeText(route.name);
      return normalizedName.includes(
        normalizedInput.split(" ")[0]
      ) || normalizedInput.split(" ").some(
        (word) => word.length >= 3 && normalizedName.includes(word)
      );
    }).slice(0, 3);
    return {
      text: suggestions.length > 0 ? "I couldn't find an exact match. Did you mean one of these?" : "I couldn't find a matching page. Try asking with a page name such as customer, payment, report, dashboard, group, approval, or another page.",
      routes: suggestions
    };
  };
  const handleSend = (customMessage = null) => {
    const textToSend = customMessage !== null ? customMessage : message;
    if (!textToSend.trim() || isTyping) {
      return;
    }
    const currentMessage = textToSend.trim();
    const userMessage = {
      id: Date.now(),
      type: "user",
      text: currentMessage
    };
    setMessages((prev) => [...prev, userMessage]);
    setMessage("");
    setIsTyping(true);
    saveRecentSearch(currentMessage);
    setTimeout(() => {
      const response = getAIResponse(currentMessage);
      setMessages(
        (prev) => [
          ...prev,
          {
            id: Date.now() + 1,
            type: "ai",
            text: response.text,
            routes: response.routes
          }
        ]
      );
      setIsTyping(false);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    }, 500);
  };
  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
  const handleNavigate = (path) => {
    setOpen(false);
    navigate(path);
  };
  const handleClearChat = () => {
    setMessages([INITIAL_MESSAGE]);
    setMessage("");
    setIsTyping(false);
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);
  };
  const handleRecentSearch = (search) => {
    setMessage(search);
    setTimeout(() => {
      inputRef.current?.focus();
    }, 50);
  };
  return createPortal(
    /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("style", { children: `
          @keyframes aiFloat {
            0%, 100% {
              transform: translateY(0);
            }

            50% {
              transform: translateY(-8px);
            }
          }

          @keyframes aiGlow {
            0%, 100% {
              box-shadow:
                0 8px 25px rgba(124, 58, 237, 0.35),
                0 0 0 0 rgba(124, 58, 237, 0.25);
            }

            50% {
              box-shadow:
                0 12px 35px rgba(124, 58, 237, 0.55),
                0 0 0 8px rgba(124, 58, 237, 0.08);
            }
          }

          @keyframes aiPulse {
            0% {
              transform: scale(0.95);
              opacity: 0.7;
            }

            70% {
              transform: scale(1.35);
              opacity: 0;
            }

            100% {
              transform: scale(1.35);
              opacity: 0;
            }
          }

          @keyframes aiTyping {
            0%, 80%, 100% {
              transform: translateY(0);
              opacity: 0.4;
            }

            40% {
              transform: translateY(-4px);
              opacity: 1;
            }
          }
        ` }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
        lineNumber: 414,
        columnNumber: 7
      }, this),
      open && /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-20 right-6 z-[9999] flex h-[560px] w-[390px] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-2xl", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between bg-gradient-to-r from-violet-600 to-blue-600 px-4 py-3 text-white", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex h-9 w-9 items-center justify-center rounded-full bg-white/20", children: /* @__PURE__ */ jsxDEV(Bot, { size: 21 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 476,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 475,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold", children: "MyChits Helper" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 480,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-white/80", children: "Chat Assistant" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 484,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 479,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 474,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: handleClearChat,
                title: "Clear chat",
                className: "rounded-lg p-1.5 transition hover:bg-white/20",
                children: /* @__PURE__ */ jsxDEV(Trash2, { size: 17 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                  lineNumber: 497,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 491,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setOpen(false),
                title: "Close",
                className: "rounded-lg p-1.5 transition hover:bg-white/20",
                children: /* @__PURE__ */ jsxDEV(X, { size: 19 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                  lineNumber: 506,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 500,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 490,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
          lineNumber: 473,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200 bg-white px-3 py-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold text-gray-500", children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { size: 12, className: "text-violet-500" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 513,
              columnNumber: 15
            }, this),
            "Quick Actions"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 512,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5 overflow-x-auto pb-1", children: QUICK_ACTIONS.map(
            (action) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => handleSend(action),
                className: "shrink-0 rounded-full border border-violet-200 bg-violet-50 px-2.5 py-1 text-[10px] font-medium text-violet-700 transition hover:bg-violet-100",
                children: action
              },
              action,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 519,
                columnNumber: 13
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 517,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
          lineNumber: 511,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 space-y-3 overflow-y-auto bg-gray-50 p-4", children: [
          messages.map(
            (item) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `flex ${item.type === "user" ? "justify-end" : "justify-start"}`,
                children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `flex max-w-[90%] items-end gap-2 ${item.type === "user" ? "flex-row-reverse" : ""}`,
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${item.type === "user" ? "bg-blue-100 text-blue-600" : "bg-violet-100 text-violet-600"}`,
                          children: item.type === "user" ? /* @__PURE__ */ jsxDEV(User, { size: 15 }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                            lineNumber: 556,
                            columnNumber: 17
                          }, this) : /* @__PURE__ */ jsxDEV(Bot, { size: 15 }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                            lineNumber: 558,
                            columnNumber: 17
                          }, this)
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                          lineNumber: 548,
                          columnNumber: 19
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `rounded-2xl px-3 py-2 text-sm ${item.type === "user" ? "rounded-br-sm bg-blue-600 text-white" : "rounded-bl-sm border border-gray-200 bg-white text-gray-700"}`,
                          children: [
                            /* @__PURE__ */ jsxDEV("div", { children: item.text }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                              lineNumber: 569,
                              columnNumber: 21
                            }, this),
                            item.routes?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-2 space-y-2", children: item.routes.map(
                              (route) => /* @__PURE__ */ jsxDEV(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => handleNavigate(route.path),
                                  className: "block w-full rounded-lg bg-violet-600 px-3 py-2 text-left text-xs font-medium text-white transition hover:bg-violet-700",
                                  children: [
                                    /* @__PURE__ */ jsxDEV("div", { children: route.name }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                                      lineNumber: 582,
                                      columnNumber: 29
                                    }, this),
                                    /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 text-[10px] text-violet-200", children: route.path }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                                      lineNumber: 584,
                                      columnNumber: 29
                                    }, this)
                                  ]
                                },
                                route.path,
                                true,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                                  lineNumber: 574,
                                  columnNumber: 19
                                },
                                this
                              )
                            ) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                              lineNumber: 572,
                              columnNumber: 17
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                          lineNumber: 562,
                          columnNumber: 19
                        },
                        this
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                    lineNumber: 541,
                    columnNumber: 17
                  },
                  this
                )
              },
              item.id,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 533,
                columnNumber: 11
              },
              this
            )
          ),
          isTyping && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-end gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex h-7 w-7 items-center justify-center rounded-full bg-violet-100 text-violet-600", children: /* @__PURE__ */ jsxDEV(Bot, { size: 15 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 600,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 599,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl rounded-bl-sm border border-gray-200 bg-white px-4 py-2.5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "h-1.5 w-1.5 rounded-full bg-violet-500",
                  style: {
                    animation: "aiTyping 1.2s infinite"
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                  lineNumber: 605,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "h-1.5 w-1.5 rounded-full bg-violet-500",
                  style: {
                    animation: "aiTyping 1.2s infinite 0.15s"
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                  lineNumber: 613,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "h-1.5 w-1.5 rounded-full bg-violet-500",
                  style: {
                    animation: "aiTyping 1.2s infinite 0.3s"
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                  lineNumber: 621,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 604,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 603,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 598,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 597,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { ref: messagesEndRef }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 634,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
          lineNumber: 531,
          columnNumber: 11
        }, this),
        recentSearches.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "border-t border-gray-100 bg-white px-3 py-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-1 flex items-center gap-1.5 text-[10px] font-semibold text-gray-500", children: [
            /* @__PURE__ */ jsxDEV(Clock3, { size: 11 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 640,
              columnNumber: 17
            }, this),
            "Recent"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 639,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5 overflow-x-auto", children: recentSearches.map(
            (search) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => handleRecentSearch(search),
                className: "shrink-0 rounded-full border border-gray-200 bg-gray-50 px-2.5 py-1 text-[10px] text-gray-600 transition hover:border-violet-200 hover:bg-violet-50 hover:text-violet-600",
                children: search
              },
              search,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 646,
                columnNumber: 13
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 644,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
          lineNumber: 638,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "border-t border-gray-200 bg-white p-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-1 text-[10px] text-gray-400", children: [
            "Current page: ",
            currentPageName
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 660,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                ref: inputRef,
                value: message,
                onChange: (e) => setMessage(e.target.value),
                onKeyDown: handleKeyDown,
                placeholder: "Ask where you want to go...",
                className: "rounded-xl",
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 665,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                onClick: () => handleSend(),
                disabled: !message.trim() || isTyping,
                icon: /* @__PURE__ */ jsxDEV(Send, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                  lineNumber: 681,
                  columnNumber: 21
                }, this),
                className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 677,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 664,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-[9px] text-gray-400", children: "Press Enter to search • Esc to close" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
            lineNumber: 686,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
          lineNumber: 659,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
        lineNumber: 472,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setOpen((prev) => !prev),
          className: "group fixed bottom-6 right-6 flex h-14 w-14 cursor-pointer items-center justify-center rounded-full bg-gradient-to-br from-violet-600 via-purple-600 to-blue-600 text-white shadow-[0_8px_30px_rgba(124,58,237,0.45)] transition-all duration-300 hover:scale-110 hover:shadow-[0_12px_35px_rgba(124,58,237,0.6)] active:scale-95",
          style: {
            animation: open ? "none" : "aiFloat 3s ease-in-out infinite, aiGlow 3s ease-in-out infinite"
          },
          children: [
            !open && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "absolute inset-0 rounded-full border border-violet-300/40",
                  style: {
                    animation: "aiPulse 2.2s ease-out infinite"
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                  lineNumber: 705,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "absolute inset-[3px] rounded-full bg-white/10" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
                lineNumber: 712,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 704,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "relative z-10 transition-transform duration-300 group-hover:rotate-12", children: open ? /* @__PURE__ */ jsxDEV(X, { size: 23 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 718,
              columnNumber: 11
            }, this) : /* @__PURE__ */ jsxDEV(MessageCircle, { size: 26 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 720,
              columnNumber: 11
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
              lineNumber: 716,
              columnNumber: 9
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
          lineNumber: 693,
          columnNumber: 7
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx",
      lineNumber: 413,
      columnNumber: 5
    }, this),
    document.body
  );
};
_s(AIChat, "JTofWWtqWidEauAJ89OGh3mBxXo=", false, function() {
  return [useNavigate, useLocation];
});
_c = AIChat;
export default AIChat;
var _c;
$RefreshReg$(_c, "AIChat");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AIChat.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNlpNLFNBa1NJLFVBbFNKOzJCQTdaTjtBQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFDVkE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLG9CQUFvQjtBQUM3QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxPQUFPQyxjQUFjO0FBQzlCLFNBQVNDLGFBQWFDLG1CQUFtQjtBQUN6QyxPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsa0JBQWtCQSxDQUFDQyxTQUFTO0FBQ2hDLE1BQUksQ0FBQ0EsUUFBUUEsU0FBUyxLQUFLO0FBQ3pCLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTUMsUUFBUUQsS0FDWEUsTUFBTSxHQUFHLEVBQ1RDLE9BQU9DLE9BQU8sRUFDZEQsT0FBTyxDQUFDRSxTQUFTQSxTQUFTLEdBQUc7QUFFaEMsTUFBSSxDQUFDSixNQUFNSyxRQUFRO0FBQ2pCLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTUMsT0FBT04sTUFBTUEsTUFBTUssU0FBUyxDQUFDLEVBQ2hDRSxRQUFRLFNBQVMsR0FBRyxFQUNwQkEsUUFBUSxTQUFTLENBQUNDLFNBQVNBLEtBQUtDLFlBQVksQ0FBQztBQUVoRCxTQUFPSDtBQUNUO0FBRUEsTUFBTUksZ0JBQWdCQSxDQUFDQyxPQUFPLE9BQU87QUFDbkMsU0FBT0EsS0FDSkMsWUFBWSxFQUNaTCxRQUFRLFVBQVUsR0FBRyxFQUNyQkEsUUFBUSxZQUFZLEdBQUcsRUFDdkJBLFFBQVEsUUFBUSxHQUFHLEVBQ25CTSxLQUFLO0FBQ1Y7QUFFQSxNQUFNQyxnQkFBZ0JBLENBQUNDLFdBQVc7QUFDaEMsTUFBSUMsTUFBTUMsUUFBUUYsTUFBTSxHQUFHO0FBQ3pCLFdBQU9BO0FBQUFBLEVBQ1Q7QUFFQSxNQUFJQSxRQUFRQSxVQUFVQyxNQUFNQyxRQUFRRixPQUFPQSxNQUFNLEdBQUc7QUFDbEQsV0FBT0EsT0FBT0E7QUFBQUEsRUFDaEI7QUFFQSxNQUFJQSxRQUFRRyxZQUFZRixNQUFNQyxRQUFRRixPQUFPRyxRQUFRLEdBQUc7QUFDdEQsV0FBT0gsT0FBT0c7QUFBQUEsRUFDaEI7QUFFQSxNQUFJSCxRQUFRSSxXQUFXSCxNQUFNQyxRQUFRRixPQUFPSSxPQUFPLEdBQUc7QUFDcEQsV0FBT0osT0FBT0k7QUFBQUEsRUFDaEI7QUFFQSxTQUFPO0FBQ1Q7QUFFQSxNQUFNQyxlQUFlQSxDQUFDTCxRQUFRTSxhQUFhLE9BQU87QUFDaEQsUUFBTUMsYUFBYVIsY0FBY0MsTUFBTTtBQUV2QyxNQUFJLENBQUNPLFdBQVdqQixRQUFRO0FBQ3RCLFdBQU87QUFBQSxFQUNUO0FBRUEsTUFBSWtCLFNBQVM7QUFFYkQsYUFBV0UsUUFBUSxDQUFDQyxVQUFVO0FBQzVCLFFBQUksQ0FBQ0EsU0FBUyxPQUFPQSxVQUFVLFVBQVU7QUFDdkM7QUFBQSxJQUNGO0FBRUEsUUFBSSxDQUFDQSxNQUFNMUIsTUFBTTtBQUNmLFVBQUkwQixNQUFNUCxVQUFVO0FBQ2xCSyxpQkFBUztBQUFBLFVBQ1AsR0FBR0E7QUFBQUEsVUFDSCxHQUFHSCxhQUFhSyxNQUFNUCxVQUFVRyxVQUFVO0FBQUEsUUFBQztBQUFBLE1BRS9DO0FBRUE7QUFBQSxJQUNGO0FBRUEsUUFBSUssY0FBY0QsTUFBTTFCO0FBRXhCLFFBQ0VzQixjQUNBSSxNQUFNMUIsU0FBUyxPQUNmLENBQUMwQixNQUFNMUIsS0FBSzRCLFdBQVcsR0FBRyxHQUMxQjtBQUNBRCxvQkFBYyxHQUFHTCxVQUFVLElBQUlJLE1BQU0xQixJQUFJLEdBQUdRO0FBQUFBLFFBQzFDO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsUUFBSWtCLE1BQU0xQixTQUFTLEtBQUs7QUFDdEIyQixvQkFBY0w7QUFBQUEsSUFDaEI7QUFFQSxRQUFJSyxlQUFlQSxnQkFBZ0IsS0FBSztBQUN0Q0gsYUFBT0ssS0FBSztBQUFBLFFBQ1Y3QixNQUFNMkI7QUFBQUEsUUFDTnBCLE1BQU1SLGdCQUFnQjRCLFdBQVc7QUFBQSxNQUNuQyxDQUFDO0FBQUEsSUFDSDtBQUVBLFFBQUlELE1BQU1QLFVBQVU7QUFDbEJLLGVBQVM7QUFBQSxRQUNQLEdBQUdBO0FBQUFBLFFBQ0gsR0FBR0gsYUFBYUssTUFBTVAsVUFBVVEsV0FBVztBQUFBLE1BQUM7QUFBQSxJQUVoRDtBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQU9IO0FBQ1Q7QUFFQSxNQUFNTSxrQkFBa0I7QUFBQSxFQUN0QkMsSUFBSTtBQUFBLEVBQ0pDLE1BQU07QUFBQSxFQUNOcEIsTUFBTTtBQUNSO0FBRUEsTUFBTXFCLGdCQUFnQjtBQUFBLEVBQ3BCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBVTtBQUdaLE1BQU1DLFNBQVNBLE1BQU07QUFBQUMsS0FBQTtBQUNuQixRQUFNQyxXQUFXdkMsWUFBWTtBQUM3QixRQUFNd0MsV0FBV3pDLFlBQVk7QUFFN0IsUUFBTSxDQUFDMEMsTUFBTUMsT0FBTyxJQUFJdkQsU0FBUyxLQUFLO0FBQ3RDLFFBQU0sQ0FBQ3dELFNBQVNDLFVBQVUsSUFBSXpELFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUMwRCxVQUFVQyxXQUFXLElBQUkzRCxTQUFTLEtBQUs7QUFFOUMsUUFBTSxDQUFDNEQsVUFBVUMsV0FBVyxJQUFJN0Q7QUFBQUEsSUFBUztBQUFBLE1BQ3ZDOEM7QUFBQUEsSUFBZTtBQUFBLEVBQ2hCO0FBRUQsUUFBTSxDQUFDZ0IsZ0JBQWdCQyxpQkFBaUIsSUFBSS9ELFNBQVMsTUFBTTtBQUN6RCxRQUFJO0FBQ0YsWUFBTWdFLFFBQVFDLGFBQWFDLFFBQVEsNEJBQTRCO0FBRS9ELGFBQU9GLFFBQVFHLEtBQUtDLE1BQU1KLEtBQUssSUFBSTtBQUFBLElBQ3JDLFFBQVE7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0YsQ0FBQztBQUVELFFBQU1LLFdBQVd0RSxPQUFPLElBQUk7QUFDNUIsUUFBTXVFLGlCQUFpQnZFLE9BQU8sSUFBSTtBQUVsQyxRQUFNd0UsWUFBWXpFLFFBQVEsTUFBTTtBQUM5QixXQUFPdUMsYUFBYXZCLFVBQVU7QUFBQSxFQUNoQyxHQUFHLEVBQUU7QUFFTCxRQUFNMEQsa0JBQWtCMUUsUUFBUSxNQUFNO0FBQ3BDLFdBQU9pQixnQkFBZ0JzQyxTQUFTb0IsUUFBUTtBQUFBLEVBQzFDLEdBQUcsQ0FBQ3BCLFNBQVNvQixRQUFRLENBQUM7QUFFdEI1RSxZQUFVLE1BQU07QUFDZCxRQUFJeUQsTUFBTTtBQUNSLFlBQU1vQixRQUFRQyxXQUFXLE1BQU07QUFDN0JOLGlCQUFTTyxTQUFTQyxNQUFNO0FBQUEsTUFDMUIsR0FBRyxHQUFHO0FBRU4sYUFBTyxNQUFNQyxhQUFhSixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsQ0FBQ3BCLElBQUksQ0FBQztBQUVUekQsWUFBVSxNQUFNO0FBQ2R5RSxtQkFBZU0sU0FBU0csZUFBZTtBQUFBLE1BQ3JDQyxVQUFVO0FBQUEsSUFDWixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNwQixVQUFVRixRQUFRLENBQUM7QUFFdkI3RCxZQUFVLE1BQU07QUFDZCxVQUFNb0YsZUFBZUEsQ0FBQ0MsVUFBVTtBQUM5QixVQUFJQSxNQUFNQyxRQUFRLFlBQVk3QixNQUFNO0FBQ2xDQyxnQkFBUSxLQUFLO0FBQUEsTUFDZjtBQUFBLElBQ0Y7QUFFQTZCLFdBQU9DLGlCQUFpQixXQUFXSixZQUFZO0FBRS9DLFdBQU8sTUFBTTtBQUNYRyxhQUFPRSxvQkFBb0IsV0FBV0wsWUFBWTtBQUFBLElBQ3BEO0FBQUEsRUFDRixHQUFHLENBQUMzQixJQUFJLENBQUM7QUFFVCxRQUFNaUMsbUJBQW1CQSxDQUFDQyxXQUFXO0FBQ25DLFVBQU1DLGdCQUFnQkQsT0FBTzFELEtBQUs7QUFFbEMsUUFBSSxDQUFDMkQsZUFBZTtBQUNsQjtBQUFBLElBQ0Y7QUFFQTFCLHNCQUFrQixDQUFDMkIsU0FBUztBQUMxQixZQUFNQyxVQUFVO0FBQUEsUUFDZEY7QUFBQUEsUUFDQSxHQUFHQyxLQUFLdkU7QUFBQUEsVUFDTixDQUFDRSxTQUNDQSxLQUFLUSxZQUFZLE1BQU00RCxjQUFjNUQsWUFBWTtBQUFBLFFBQ3JEO0FBQUEsTUFBQyxFQUNEK0QsTUFBTSxHQUFHLENBQUM7QUFFWjNCLG1CQUFhNEI7QUFBQUEsUUFDWDtBQUFBLFFBQ0ExQixLQUFLMkIsVUFBVUgsT0FBTztBQUFBLE1BQ3hCO0FBRUEsYUFBT0E7QUFBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1JLHFCQUFxQkEsQ0FBQ0MsVUFBVTtBQUNwQyxVQUFNQyxrQkFBa0J0RSxjQUFjcUUsS0FBSztBQUUzQyxRQUFJLENBQUNDLGlCQUFpQjtBQUNwQixhQUFPO0FBQUEsSUFDVDtBQUVBLFVBQU1DLGFBQWFELGdCQUFnQi9FLE1BQU0sR0FBRztBQUU1QyxVQUFNaUYsVUFBVTVCLFVBQ2I2QixJQUFJLENBQUMxRCxVQUFVO0FBQ2QsWUFBTTJELGlCQUFpQjFFLGNBQWNlLE1BQU0xQixJQUFJO0FBQy9DLFlBQU1zRixpQkFBaUIzRSxjQUFjZSxNQUFNbkIsSUFBSTtBQUUvQyxVQUFJZ0YsUUFBUTtBQUVaLFVBQUlOLG9CQUFvQkssZ0JBQWdCO0FBQ3RDQyxpQkFBUztBQUFBLE1BQ1g7QUFFQSxVQUFJTixnQkFBZ0JPLFNBQVNGLGNBQWMsR0FBRztBQUM1Q0MsaUJBQVM7QUFBQSxNQUNYO0FBRUEsVUFBSU4sZ0JBQWdCTyxTQUFTSCxjQUFjLEdBQUc7QUFDNUNFLGlCQUFTO0FBQUEsTUFDWDtBQUVBTCxpQkFBV3pELFFBQVEsQ0FBQ2dFLFNBQVM7QUFDM0IsWUFBSUEsS0FBS25GLFNBQVMsR0FBRztBQUNuQjtBQUFBLFFBQ0Y7QUFFQSxZQUFJZ0YsZUFBZUUsU0FBU0MsSUFBSSxHQUFHO0FBQ2pDRixtQkFBUztBQUFBLFFBQ1g7QUFFQSxZQUFJRixlQUFlRyxTQUFTQyxJQUFJLEdBQUc7QUFDakNGLG1CQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0YsQ0FBQztBQUVELGFBQU87QUFBQSxRQUNMLEdBQUc3RDtBQUFBQSxRQUNINkQ7QUFBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQyxFQUNBcEYsT0FBTyxDQUFDdUIsVUFBVUEsTUFBTTZELFFBQVEsQ0FBQyxFQUNqQ0csS0FBSyxDQUFDQyxHQUFHQyxNQUFNQSxFQUFFTCxRQUFRSSxFQUFFSixLQUFLO0FBRW5DLFVBQU1NLGVBQWU7QUFFckJWLFlBQVExRCxRQUFRLENBQUNDLFVBQVU7QUFDekIsVUFDRSxDQUFDbUUsYUFBYUM7QUFBQUEsUUFDWixDQUFDekYsU0FBU0EsS0FBS0wsU0FBUzBCLE1BQU0xQjtBQUFBQSxNQUNoQyxHQUNBO0FBQ0E2RixxQkFBYWhFLEtBQUtILEtBQUs7QUFBQSxNQUN6QjtBQUFBLElBQ0YsQ0FBQztBQUVELFdBQU9tRSxhQUFhakIsTUFBTSxHQUFHLENBQUM7QUFBQSxFQUNoQztBQUVBLFFBQU1tQixnQkFBZ0JBLENBQUNmLFVBQVU7QUFDL0IsVUFBTWdCLGdCQUFnQmpCLG1CQUFtQkMsS0FBSztBQUU5QyxRQUFJZ0IsY0FBYzFGLFNBQVMsR0FBRztBQUM1QixhQUFPO0FBQUEsUUFDTE0sTUFBTSxXQUFXb0YsY0FBYyxDQUFDLEVBQUV6RixJQUFJO0FBQUEsUUFDdENTLFFBQVFnRjtBQUFBQSxNQUNWO0FBQUEsSUFDRjtBQUVBLFVBQU1DLGNBQWMxQyxVQUNqQnBELE9BQU8sQ0FBQ3VCLFVBQVU7QUFDakIsWUFBTXVELGtCQUFrQnRFLGNBQWNxRSxLQUFLO0FBQzNDLFlBQU1NLGlCQUFpQjNFLGNBQWNlLE1BQU1uQixJQUFJO0FBRS9DLGFBQ0UrRSxlQUFlRTtBQUFBQSxRQUNiUCxnQkFBZ0IvRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDOUIsS0FDQStFLGdCQUNHL0UsTUFBTSxHQUFHLEVBQ1Q0RjtBQUFBQSxRQUNDLENBQUNMLFNBQ0NBLEtBQUtuRixVQUFVLEtBQ2ZnRixlQUFlRSxTQUFTQyxJQUFJO0FBQUEsTUFDaEM7QUFBQSxJQUVOLENBQUMsRUFDQWIsTUFBTSxHQUFHLENBQUM7QUFFYixXQUFPO0FBQUEsTUFDTGhFLE1BQ0VxRixZQUFZM0YsU0FBUyxJQUNqQiwrREFDQTtBQUFBLE1BQ05VLFFBQVFpRjtBQUFBQSxJQUNWO0FBQUEsRUFDRjtBQUVBLFFBQU1DLGFBQWFBLENBQUNDLGdCQUFnQixTQUFTO0FBQzNDLFVBQU1DLGFBQ0pELGtCQUFrQixPQUFPQSxnQkFBZ0IzRDtBQUUzQyxRQUFJLENBQUM0RCxXQUFXdEYsS0FBSyxLQUFLNEIsVUFBVTtBQUNsQztBQUFBLElBQ0Y7QUFFQSxVQUFNMkQsaUJBQWlCRCxXQUFXdEYsS0FBSztBQUV2QyxVQUFNd0YsY0FBYztBQUFBLE1BQ2xCdkUsSUFBSXdFLEtBQUtDLElBQUk7QUFBQSxNQUNieEUsTUFBTTtBQUFBLE1BQ05wQixNQUFNeUY7QUFBQUEsSUFDUjtBQUVBeEQsZ0JBQVksQ0FBQzZCLFNBQVMsQ0FBQyxHQUFHQSxNQUFNNEIsV0FBVyxDQUFDO0FBQzVDN0QsZUFBVyxFQUFFO0FBQ2JFLGdCQUFZLElBQUk7QUFFaEI0QixxQkFBaUI4QixjQUFjO0FBRS9CMUMsZUFBVyxNQUFNO0FBQ2YsWUFBTThDLFdBQVdWLGNBQWNNLGNBQWM7QUFFN0N4RDtBQUFBQSxRQUFZLENBQUM2QixTQUFTO0FBQUEsVUFDcEIsR0FBR0E7QUFBQUEsVUFDSDtBQUFBLFlBQ0UzQyxJQUFJd0UsS0FBS0MsSUFBSSxJQUFJO0FBQUEsWUFDakJ4RSxNQUFNO0FBQUEsWUFDTnBCLE1BQU02RixTQUFTN0Y7QUFBQUEsWUFDZkksUUFBUXlGLFNBQVN6RjtBQUFBQSxVQUNuQjtBQUFBLFFBQUM7QUFBQSxNQUNGO0FBRUQyQixrQkFBWSxLQUFLO0FBRWpCZ0IsaUJBQVcsTUFBTTtBQUNmTixpQkFBU08sU0FBU0MsTUFBTTtBQUFBLE1BQzFCLEdBQUcsRUFBRTtBQUFBLElBQ1AsR0FBRyxHQUFHO0FBQUEsRUFDUjtBQUVBLFFBQU02QyxnQkFBZ0JBLENBQUNDLE1BQU07QUFDM0IsUUFBSUEsRUFBRXhDLFFBQVEsV0FBVyxDQUFDd0MsRUFBRUMsVUFBVTtBQUNwQ0QsUUFBRUUsZUFBZTtBQUNqQlgsaUJBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUVBLFFBQU1ZLGlCQUFpQkEsQ0FBQzlHLFNBQVM7QUFDL0J1QyxZQUFRLEtBQUs7QUFDYkgsYUFBU3BDLElBQUk7QUFBQSxFQUNmO0FBRUEsUUFBTStHLGtCQUFrQkEsTUFBTTtBQUM1QmxFLGdCQUFZLENBQUNmLGVBQWUsQ0FBQztBQUM3QlcsZUFBVyxFQUFFO0FBQ2JFLGdCQUFZLEtBQUs7QUFFakJnQixlQUFXLE1BQU07QUFDZk4sZUFBU08sU0FBU0MsTUFBTTtBQUFBLElBQzFCLEdBQUcsR0FBRztBQUFBLEVBQ1I7QUFFQSxRQUFNbUQscUJBQXFCQSxDQUFDeEMsV0FBVztBQUNyQy9CLGVBQVcrQixNQUFNO0FBRWpCYixlQUFXLE1BQU07QUFDZk4sZUFBU08sU0FBU0MsTUFBTTtBQUFBLElBQzFCLEdBQUcsRUFBRTtBQUFBLEVBQ1A7QUFFQSxTQUFPNUU7QUFBQUEsSUFDTCxtQ0FDRTtBQUFBLDZCQUFDLFdBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVEQTtBQUFBLE1BRUNxRCxRQUNDLHVCQUFDLFNBQUksV0FBVSxzS0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx1R0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxxRUFDYixpQ0FBQyxPQUFJLE1BQU0sTUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjLEtBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUJBQXdCLDhCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUseUJBQXdCLDhCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3lFO0FBQUFBLGdCQUNULE9BQU07QUFBQSxnQkFDTixXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUI7QUFBQTtBQUFBLGNBTm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU14RSxRQUFRLEtBQUs7QUFBQSxnQkFDNUIsT0FBTTtBQUFBLGdCQUNOLFdBQVU7QUFBQSxnQkFFVixpQ0FBQyxLQUFFLE1BQU0sTUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFZO0FBQUE7QUFBQSxjQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0NBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsK0NBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNEVBQ2I7QUFBQSxtQ0FBQyxZQUFTLE1BQU0sSUFBSSxXQUFVLHFCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQztBQUFBLFlBQUc7QUFBQSxlQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1pOLHdCQUFjbUQ7QUFBQUEsWUFBSSxDQUFDNkIsV0FDbEI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNZixXQUFXZSxNQUFNO0FBQUEsZ0JBQ2hDLFdBQVU7QUFBQSxnQkFFVEE7QUFBQUE7QUFBQUEsY0FMSUE7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxVQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxtREFDWnJFO0FBQUFBLG1CQUFTd0M7QUFBQUEsWUFBSSxDQUFDL0UsU0FDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLFdBQVcsUUFDVEEsS0FBSzJCLFNBQVMsU0FDVixnQkFDQSxlQUFlO0FBQUEsZ0JBR3JCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsb0NBQ1QzQixLQUFLMkIsU0FBUyxTQUNWLHFCQUNBLEVBQUU7QUFBQSxvQkFHUjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVcsa0VBQ1QzQixLQUFLMkIsU0FBUyxTQUNWLDhCQUNBLCtCQUErQjtBQUFBLDBCQUdwQzNCLGVBQUsyQixTQUFTLFNBQ2IsdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBZSxJQUVmLHVCQUFDLE9BQUksTUFBTSxNQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWM7QUFBQTtBQUFBLHdCQVZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBWUE7QUFBQSxzQkFFQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFXLGlDQUNUM0IsS0FBSzJCLFNBQVMsU0FDVix5Q0FDQSw2REFBNkQ7QUFBQSwwQkFHbkU7QUFBQSxtREFBQyxTQUFLM0IsZUFBS08sUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFnQjtBQUFBLDRCQUVmUCxLQUFLVyxRQUFRVixTQUFTLEtBQ3JCLHVCQUFDLFNBQUksV0FBVSxrQkFDWkQsZUFBS1csT0FBT29FO0FBQUFBLDhCQUFJLENBQUMxRCxVQUNoQjtBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FFQyxNQUFLO0FBQUEsa0NBQ0wsU0FBUyxNQUNQb0YsZUFBZXBGLE1BQU0xQixJQUFJO0FBQUEsa0NBRTNCLFdBQVU7QUFBQSxrQ0FFVjtBQUFBLDJEQUFDLFNBQUswQixnQkFBTW5CLFFBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FBaUI7QUFBQSxvQ0FFakIsdUJBQUMsU0FBSSxXQUFVLHNDQUNabUIsZ0JBQU0xQixRQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBRUE7QUFBQTtBQUFBO0FBQUEsZ0NBWEswQixNQUFNMUI7QUFBQUEsZ0NBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFhQTtBQUFBLDRCQUNELEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBaUJBO0FBQUE7QUFBQTtBQUFBLHdCQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBNkJBO0FBQUE7QUFBQTtBQUFBLGtCQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBbURBO0FBQUE7QUFBQSxjQTFES0ssS0FBSzBCO0FBQUFBLGNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTREQTtBQUFBLFVBQ0Q7QUFBQSxVQUVBVyxZQUNDLHVCQUFDLFNBQUksV0FBVSxzQkFDYixpQ0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsdUZBQ2IsaUNBQUMsT0FBSSxNQUFNLE1BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYyxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUseUVBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE9BQU87QUFBQSxvQkFDTHdFLFdBQ0U7QUFBQSxrQkFDSjtBQUFBO0FBQUEsZ0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0k7QUFBQSxjQUdKO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPO0FBQUEsb0JBQ0xBLFdBQ0U7QUFBQSxrQkFDSjtBQUFBO0FBQUEsZ0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0k7QUFBQSxjQUdKO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPO0FBQUEsb0JBQ0xBLFdBQ0U7QUFBQSxrQkFDSjtBQUFBO0FBQUEsZ0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0k7QUFBQSxpQkF0Qk47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxlQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdDQSxLQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtDQTtBQUFBLFVBR0YsdUJBQUMsU0FBSSxLQUFLNUQsa0JBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUI7QUFBQSxhQXZHM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdHQTtBQUFBLFFBRUNSLGVBQWV4QyxTQUFTLEtBQ3ZCLHVCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwRUFDYjtBQUFBLG1DQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlCO0FBQUEsWUFBRztBQUFBLGVBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxnQ0FDWndDLHlCQUFlc0M7QUFBQUEsWUFBSSxDQUFDWixXQUNuQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU13QyxtQkFBbUJ4QyxNQUFNO0FBQUEsZ0JBQ3hDLFdBQVU7QUFBQSxnQkFFVEE7QUFBQUE7QUFBQUEsY0FMSUE7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxVQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUdGLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxrQ0FBaUM7QUFBQTtBQUFBLFlBQy9CaEI7QUFBQUEsZUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxLQUFLSDtBQUFBQSxnQkFDTCxPQUFPYjtBQUFBQSxnQkFDUCxVQUFVLENBQUNtRSxNQUNUbEUsV0FBV2tFLEVBQUVRLE9BQU9DLEtBQUs7QUFBQSxnQkFFM0IsV0FBV1Y7QUFBQUEsZ0JBQ1gsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQSxnQkFDVixjQUFhO0FBQUE7QUFBQSxjQVRmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNvQjtBQUFBLFlBR3BCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTVIsV0FBVztBQUFBLGdCQUMxQixVQUFVLENBQUMxRCxRQUFRMUIsS0FBSyxLQUFLNEI7QUFBQUEsZ0JBQzdCLE1BQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLGdCQUNyQixXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUs0RTtBQUFBLGVBbEI5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyxvREFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4QkE7QUFBQSxXQXpORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBME5BO0FBQUEsTUFHRjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNSCxRQUFRLENBQUNtQyxTQUFTLENBQUNBLElBQUk7QUFBQSxVQUN0QyxXQUFVO0FBQUEsVUFDVixPQUFPO0FBQUEsWUFDTHdDLFdBQVc1RSxPQUNQLFNBQ0E7QUFBQSxVQUNOO0FBQUEsVUFFQztBQUFBLGFBQUNBLFFBQ0EsbUNBQ0U7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTztBQUFBLG9CQUNMNEUsV0FBVztBQUFBLGtCQUNiO0FBQUE7QUFBQSxnQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJSTtBQUFBLGNBR0osdUJBQUMsVUFBSyxXQUFVLG1EQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBLGlCQVJqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFHRix1QkFBQyxVQUFLLFdBQVUseUVBQ2I1RSxpQkFDQyx1QkFBQyxLQUFFLE1BQU0sTUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFZLElBRVosdUJBQUMsaUJBQWMsTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QixLQUo1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUE7QUFBQTtBQUFBLFFBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQThCQTtBQUFBLFNBdFRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1VEE7QUFBQSxJQUNBK0UsU0FBU0M7QUFBQUEsRUFDWDtBQUNGO0FBQUVuRixHQXBrQklELFFBQU07QUFBQSxVQUNPckMsYUFDQUQsV0FBVztBQUFBO0FBQUEySCxLQUZ4QnJGO0FBc2tCTixlQUFlQTtBQUFPLElBQUFxRjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVJlZiIsInVzZVN0YXRlIiwiY3JlYXRlUG9ydGFsIiwiQm90IiwiTWVzc2FnZUNpcmNsZSIsIlNlbmQiLCJYIiwiVXNlciIsIlRyYXNoMiIsIlNwYXJrbGVzIiwiQ2xvY2szIiwiSW5wdXQiLCJCdXR0b24iLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwibWFpblJvdXRlcyIsImZvcm1hdFJvdXRlTmFtZSIsInBhdGgiLCJwYXJ0cyIsInNwbGl0IiwiZmlsdGVyIiwiQm9vbGVhbiIsIml0ZW0iLCJsZW5ndGgiLCJuYW1lIiwicmVwbGFjZSIsImNoYXIiLCJ0b1VwcGVyQ2FzZSIsIm5vcm1hbGl6ZVRleHQiLCJ0ZXh0IiwidG9Mb3dlckNhc2UiLCJ0cmltIiwiZ2V0Um91dGVBcnJheSIsInJvdXRlcyIsIkFycmF5IiwiaXNBcnJheSIsImNoaWxkcmVuIiwiZGVmYXVsdCIsImdldEFsbFJvdXRlcyIsInBhcmVudFBhdGgiLCJyb3V0ZUFycmF5IiwicmVzdWx0IiwiZm9yRWFjaCIsInJvdXRlIiwiY3VycmVudFBhdGgiLCJzdGFydHNXaXRoIiwicHVzaCIsIklOSVRJQUxfTUVTU0FHRSIsImlkIiwidHlwZSIsIlFVSUNLX0FDVElPTlMiLCJBSUNoYXQiLCJfcyIsIm5hdmlnYXRlIiwibG9jYXRpb24iLCJvcGVuIiwic2V0T3BlbiIsIm1lc3NhZ2UiLCJzZXRNZXNzYWdlIiwiaXNUeXBpbmciLCJzZXRJc1R5cGluZyIsIm1lc3NhZ2VzIiwic2V0TWVzc2FnZXMiLCJyZWNlbnRTZWFyY2hlcyIsInNldFJlY2VudFNlYXJjaGVzIiwic2F2ZWQiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwiaW5wdXRSZWYiLCJtZXNzYWdlc0VuZFJlZiIsImFsbFJvdXRlcyIsImN1cnJlbnRQYWdlTmFtZSIsInBhdGhuYW1lIiwidGltZXIiLCJzZXRUaW1lb3V0IiwiY3VycmVudCIsImZvY3VzIiwiY2xlYXJUaW1lb3V0Iiwic2Nyb2xsSW50b1ZpZXciLCJiZWhhdmlvciIsImhhbmRsZUVzY2FwZSIsImV2ZW50Iiwia2V5Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJzYXZlUmVjZW50U2VhcmNoIiwic2VhcmNoIiwiY2xlYW5lZFNlYXJjaCIsInByZXYiLCJ1cGRhdGVkIiwic2xpY2UiLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiZmluZE1hdGNoaW5nUm91dGVzIiwiaW5wdXQiLCJub3JtYWxpemVkSW5wdXQiLCJpbnB1dFdvcmRzIiwicmVzdWx0cyIsIm1hcCIsIm5vcm1hbGl6ZWRQYXRoIiwibm9ybWFsaXplZE5hbWUiLCJzY29yZSIsImluY2x1ZGVzIiwid29yZCIsInNvcnQiLCJhIiwiYiIsInVuaXF1ZVJvdXRlcyIsInNvbWUiLCJnZXRBSVJlc3BvbnNlIiwibWF0Y2hlZFJvdXRlcyIsInN1Z2dlc3Rpb25zIiwiaGFuZGxlU2VuZCIsImN1c3RvbU1lc3NhZ2UiLCJ0ZXh0VG9TZW5kIiwiY3VycmVudE1lc3NhZ2UiLCJ1c2VyTWVzc2FnZSIsIkRhdGUiLCJub3ciLCJyZXNwb25zZSIsImhhbmRsZUtleURvd24iLCJlIiwic2hpZnRLZXkiLCJwcmV2ZW50RGVmYXVsdCIsImhhbmRsZU5hdmlnYXRlIiwiaGFuZGxlQ2xlYXJDaGF0IiwiaGFuZGxlUmVjZW50U2VhcmNoIiwiYWN0aW9uIiwiYW5pbWF0aW9uIiwidGFyZ2V0IiwidmFsdWUiLCJkb2N1bWVudCIsImJvZHkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBSUNoYXQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwge1xyXG4gIHVzZUVmZmVjdCxcclxuICB1c2VNZW1vLFxyXG4gIHVzZVJlZixcclxuICB1c2VTdGF0ZSxcclxufSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgY3JlYXRlUG9ydGFsIH0gZnJvbSBcInJlYWN0LWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIEJvdCxcclxuICBNZXNzYWdlQ2lyY2xlLFxyXG4gIFNlbmQsXHJcbiAgWCxcclxuICBVc2VyLFxyXG4gIFRyYXNoMixcclxuICBTcGFya2xlcyxcclxuICBDbG9jazMsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBJbnB1dCwgQnV0dG9uIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IG1haW5Sb3V0ZXMgZnJvbSBcIi4uL3JvdXRlcy9tYWluUm91dGVzXCI7XHJcblxyXG5jb25zdCBmb3JtYXRSb3V0ZU5hbWUgPSAocGF0aCkgPT4ge1xyXG4gIGlmICghcGF0aCB8fCBwYXRoID09PSBcIi9cIikge1xyXG4gICAgcmV0dXJuIFwiRGFzaGJvYXJkXCI7XHJcbiAgfVxyXG5cclxuICBjb25zdCBwYXJ0cyA9IHBhdGhcclxuICAgIC5zcGxpdChcIi9cIilcclxuICAgIC5maWx0ZXIoQm9vbGVhbilcclxuICAgIC5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0gIT09IFwiKlwiKTtcclxuXHJcbiAgaWYgKCFwYXJ0cy5sZW5ndGgpIHtcclxuICAgIHJldHVybiBcIkRhc2hib2FyZFwiO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgbmFtZSA9IHBhcnRzW3BhcnRzLmxlbmd0aCAtIDFdXHJcbiAgICAucmVwbGFjZSgvWy1fXS9nLCBcIiBcIilcclxuICAgIC5yZXBsYWNlKC9cXGJcXHcvZywgKGNoYXIpID0+IGNoYXIudG9VcHBlckNhc2UoKSk7XHJcblxyXG4gIHJldHVybiBuYW1lO1xyXG59O1xyXG5cclxuY29uc3Qgbm9ybWFsaXplVGV4dCA9ICh0ZXh0ID0gXCJcIikgPT4ge1xyXG4gIHJldHVybiB0ZXh0XHJcbiAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgLnJlcGxhY2UoL1stXy9dL2csIFwiIFwiKVxyXG4gICAgLnJlcGxhY2UoL1teXFx3XFxzXS9nLCBcIiBcIilcclxuICAgIC5yZXBsYWNlKC9cXHMrL2csIFwiIFwiKVxyXG4gICAgLnRyaW0oKTtcclxufTtcclxuXHJcbmNvbnN0IGdldFJvdXRlQXJyYXkgPSAocm91dGVzKSA9PiB7XHJcbiAgaWYgKEFycmF5LmlzQXJyYXkocm91dGVzKSkge1xyXG4gICAgcmV0dXJuIHJvdXRlcztcclxuICB9XHJcblxyXG4gIGlmIChyb3V0ZXM/LnJvdXRlcyAmJiBBcnJheS5pc0FycmF5KHJvdXRlcy5yb3V0ZXMpKSB7XHJcbiAgICByZXR1cm4gcm91dGVzLnJvdXRlcztcclxuICB9XHJcblxyXG4gIGlmIChyb3V0ZXM/LmNoaWxkcmVuICYmIEFycmF5LmlzQXJyYXkocm91dGVzLmNoaWxkcmVuKSkge1xyXG4gICAgcmV0dXJuIHJvdXRlcy5jaGlsZHJlbjtcclxuICB9XHJcblxyXG4gIGlmIChyb3V0ZXM/LmRlZmF1bHQgJiYgQXJyYXkuaXNBcnJheShyb3V0ZXMuZGVmYXVsdCkpIHtcclxuICAgIHJldHVybiByb3V0ZXMuZGVmYXVsdDtcclxuICB9XHJcblxyXG4gIHJldHVybiBbXTtcclxufTtcclxuXHJcbmNvbnN0IGdldEFsbFJvdXRlcyA9IChyb3V0ZXMsIHBhcmVudFBhdGggPSBcIlwiKSA9PiB7XHJcbiAgY29uc3Qgcm91dGVBcnJheSA9IGdldFJvdXRlQXJyYXkocm91dGVzKTtcclxuXHJcbiAgaWYgKCFyb3V0ZUFycmF5Lmxlbmd0aCkge1xyXG4gICAgcmV0dXJuIFtdO1xyXG4gIH1cclxuXHJcbiAgbGV0IHJlc3VsdCA9IFtdO1xyXG5cclxuICByb3V0ZUFycmF5LmZvckVhY2goKHJvdXRlKSA9PiB7XHJcbiAgICBpZiAoIXJvdXRlIHx8IHR5cGVvZiByb3V0ZSAhPT0gXCJvYmplY3RcIikge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFyb3V0ZS5wYXRoKSB7XHJcbiAgICAgIGlmIChyb3V0ZS5jaGlsZHJlbikge1xyXG4gICAgICAgIHJlc3VsdCA9IFtcclxuICAgICAgICAgIC4uLnJlc3VsdCxcclxuICAgICAgICAgIC4uLmdldEFsbFJvdXRlcyhyb3V0ZS5jaGlsZHJlbiwgcGFyZW50UGF0aCksXHJcbiAgICAgICAgXTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBjdXJyZW50UGF0aCA9IHJvdXRlLnBhdGg7XHJcblxyXG4gICAgaWYgKFxyXG4gICAgICBwYXJlbnRQYXRoICYmXHJcbiAgICAgIHJvdXRlLnBhdGggIT09IFwiKlwiICYmXHJcbiAgICAgICFyb3V0ZS5wYXRoLnN0YXJ0c1dpdGgoXCIvXCIpXHJcbiAgICApIHtcclxuICAgICAgY3VycmVudFBhdGggPSBgJHtwYXJlbnRQYXRofS8ke3JvdXRlLnBhdGh9YC5yZXBsYWNlKFxyXG4gICAgICAgIC9cXC8rL2csXHJcbiAgICAgICAgXCIvXCJcclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAocm91dGUucGF0aCA9PT0gXCIqXCIpIHtcclxuICAgICAgY3VycmVudFBhdGggPSBwYXJlbnRQYXRoO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChjdXJyZW50UGF0aCAmJiBjdXJyZW50UGF0aCAhPT0gXCIqXCIpIHtcclxuICAgICAgcmVzdWx0LnB1c2goe1xyXG4gICAgICAgIHBhdGg6IGN1cnJlbnRQYXRoLFxyXG4gICAgICAgIG5hbWU6IGZvcm1hdFJvdXRlTmFtZShjdXJyZW50UGF0aCksXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChyb3V0ZS5jaGlsZHJlbikge1xyXG4gICAgICByZXN1bHQgPSBbXHJcbiAgICAgICAgLi4ucmVzdWx0LFxyXG4gICAgICAgIC4uLmdldEFsbFJvdXRlcyhyb3V0ZS5jaGlsZHJlbiwgY3VycmVudFBhdGgpLFxyXG4gICAgICBdO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gcmVzdWx0O1xyXG59O1xyXG5cclxuY29uc3QgSU5JVElBTF9NRVNTQUdFID0ge1xyXG4gIGlkOiAxLFxyXG4gIHR5cGU6IFwiYWlcIixcclxuICB0ZXh0OiBcIkhlbGxvISDwn5GLIEkgY2FuIGhlbHAgeW91IGZpbmQgcGFnZXMgaW4gTXlDaGl0cy4gQXNrIG1lIHdoZXJlIHlvdSB3YW50IHRvIGdvLlwiLFxyXG59O1xyXG5cclxuY29uc3QgUVVJQ0tfQUNUSU9OUyA9IFtcclxuICBcIkRhc2hib2FyZFwiLFxyXG4gIFwiQ3VzdG9tZXJcIixcclxuICBcIlBheW1lbnRcIixcclxuICBcIkdyb3VwXCIsXHJcbiAgXCJSZXBvcnRcIixcclxuICBcIkFwcHJvdmFsXCIsXHJcbl07XHJcblxyXG5jb25zdCBBSUNoYXQgPSAoKSA9PiB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuXHJcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc1R5cGluZywgc2V0SXNUeXBpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbbWVzc2FnZXMsIHNldE1lc3NhZ2VzXSA9IHVzZVN0YXRlKFtcclxuICAgIElOSVRJQUxfTUVTU0FHRSxcclxuICBdKTtcclxuXHJcbiAgY29uc3QgW3JlY2VudFNlYXJjaGVzLCBzZXRSZWNlbnRTZWFyY2hlc10gPSB1c2VTdGF0ZSgoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibXljaGl0c19haV9yZWNlbnRfc2VhcmNoZXNcIik7XHJcblxyXG4gICAgICByZXR1cm4gc2F2ZWQgPyBKU09OLnBhcnNlKHNhdmVkKSA6IFtdO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHJldHVybiBbXTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgY29uc3QgaW5wdXRSZWYgPSB1c2VSZWYobnVsbCk7XHJcbiAgY29uc3QgbWVzc2FnZXNFbmRSZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4gIGNvbnN0IGFsbFJvdXRlcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGdldEFsbFJvdXRlcyhtYWluUm91dGVzKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGN1cnJlbnRQYWdlTmFtZSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGZvcm1hdFJvdXRlTmFtZShsb2NhdGlvbi5wYXRobmFtZSk7XHJcbiAgfSwgW2xvY2F0aW9uLnBhdGhuYW1lXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAob3Blbikge1xyXG4gICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGlucHV0UmVmLmN1cnJlbnQ/LmZvY3VzKCk7XHJcbiAgICAgIH0sIDEwMCk7XHJcblxyXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH1cclxuICB9LCBbb3Blbl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbWVzc2FnZXNFbmRSZWYuY3VycmVudD8uc2Nyb2xsSW50b1ZpZXcoe1xyXG4gICAgICBiZWhhdmlvcjogXCJzbW9vdGhcIixcclxuICAgIH0pO1xyXG4gIH0sIFttZXNzYWdlcywgaXNUeXBpbmddKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGhhbmRsZUVzY2FwZSA9IChldmVudCkgPT4ge1xyXG4gICAgICBpZiAoZXZlbnQua2V5ID09PSBcIkVzY2FwZVwiICYmIG9wZW4pIHtcclxuICAgICAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlRXNjYXBlKTtcclxuXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlRXNjYXBlKTtcclxuICAgIH07XHJcbiAgfSwgW29wZW5dKTtcclxuXHJcbiAgY29uc3Qgc2F2ZVJlY2VudFNlYXJjaCA9IChzZWFyY2gpID0+IHtcclxuICAgIGNvbnN0IGNsZWFuZWRTZWFyY2ggPSBzZWFyY2gudHJpbSgpO1xyXG5cclxuICAgIGlmICghY2xlYW5lZFNlYXJjaCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0UmVjZW50U2VhcmNoZXMoKHByZXYpID0+IHtcclxuICAgICAgY29uc3QgdXBkYXRlZCA9IFtcclxuICAgICAgICBjbGVhbmVkU2VhcmNoLFxyXG4gICAgICAgIC4uLnByZXYuZmlsdGVyKFxyXG4gICAgICAgICAgKGl0ZW0pID0+XHJcbiAgICAgICAgICAgIGl0ZW0udG9Mb3dlckNhc2UoKSAhPT0gY2xlYW5lZFNlYXJjaC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgKSxcclxuICAgICAgXS5zbGljZSgwLCA1KTtcclxuXHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFxyXG4gICAgICAgIFwibXljaGl0c19haV9yZWNlbnRfc2VhcmNoZXNcIixcclxuICAgICAgICBKU09OLnN0cmluZ2lmeSh1cGRhdGVkKVxyXG4gICAgICApO1xyXG5cclxuICAgICAgcmV0dXJuIHVwZGF0ZWQ7XHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmaW5kTWF0Y2hpbmdSb3V0ZXMgPSAoaW5wdXQpID0+IHtcclxuICAgIGNvbnN0IG5vcm1hbGl6ZWRJbnB1dCA9IG5vcm1hbGl6ZVRleHQoaW5wdXQpO1xyXG5cclxuICAgIGlmICghbm9ybWFsaXplZElucHV0KSB7XHJcbiAgICAgIHJldHVybiBbXTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBpbnB1dFdvcmRzID0gbm9ybWFsaXplZElucHV0LnNwbGl0KFwiIFwiKTtcclxuXHJcbiAgICBjb25zdCByZXN1bHRzID0gYWxsUm91dGVzXHJcbiAgICAgIC5tYXAoKHJvdXRlKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgbm9ybWFsaXplZFBhdGggPSBub3JtYWxpemVUZXh0KHJvdXRlLnBhdGgpO1xyXG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWROYW1lID0gbm9ybWFsaXplVGV4dChyb3V0ZS5uYW1lKTtcclxuXHJcbiAgICAgICAgbGV0IHNjb3JlID0gMDtcclxuXHJcbiAgICAgICAgaWYgKG5vcm1hbGl6ZWRJbnB1dCA9PT0gbm9ybWFsaXplZE5hbWUpIHtcclxuICAgICAgICAgIHNjb3JlICs9IDIwMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChub3JtYWxpemVkSW5wdXQuaW5jbHVkZXMobm9ybWFsaXplZE5hbWUpKSB7XHJcbiAgICAgICAgICBzY29yZSArPSAxMDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAobm9ybWFsaXplZElucHV0LmluY2x1ZGVzKG5vcm1hbGl6ZWRQYXRoKSkge1xyXG4gICAgICAgICAgc2NvcmUgKz0gMTAwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaW5wdXRXb3Jkcy5mb3JFYWNoKCh3b3JkKSA9PiB7XHJcbiAgICAgICAgICBpZiAod29yZC5sZW5ndGggPCAzKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAobm9ybWFsaXplZE5hbWUuaW5jbHVkZXMod29yZCkpIHtcclxuICAgICAgICAgICAgc2NvcmUgKz0gMjA7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKG5vcm1hbGl6ZWRQYXRoLmluY2x1ZGVzKHdvcmQpKSB7XHJcbiAgICAgICAgICAgIHNjb3JlICs9IDEwO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgLi4ucm91dGUsXHJcbiAgICAgICAgICBzY29yZSxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG4gICAgICAuZmlsdGVyKChyb3V0ZSkgPT4gcm91dGUuc2NvcmUgPiAwKVxyXG4gICAgICAuc29ydCgoYSwgYikgPT4gYi5zY29yZSAtIGEuc2NvcmUpO1xyXG5cclxuICAgIGNvbnN0IHVuaXF1ZVJvdXRlcyA9IFtdO1xyXG5cclxuICAgIHJlc3VsdHMuZm9yRWFjaCgocm91dGUpID0+IHtcclxuICAgICAgaWYgKFxyXG4gICAgICAgICF1bmlxdWVSb3V0ZXMuc29tZShcclxuICAgICAgICAgIChpdGVtKSA9PiBpdGVtLnBhdGggPT09IHJvdXRlLnBhdGhcclxuICAgICAgICApXHJcbiAgICAgICkge1xyXG4gICAgICAgIHVuaXF1ZVJvdXRlcy5wdXNoKHJvdXRlKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIHVuaXF1ZVJvdXRlcy5zbGljZSgwLCAzKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRBSVJlc3BvbnNlID0gKGlucHV0KSA9PiB7XHJcbiAgICBjb25zdCBtYXRjaGVkUm91dGVzID0gZmluZE1hdGNoaW5nUm91dGVzKGlucHV0KTtcclxuXHJcbiAgICBpZiAobWF0Y2hlZFJvdXRlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdGV4dDogYEkgZm91bmQgJHttYXRjaGVkUm91dGVzWzBdLm5hbWV9IGZvciB5b3UuYCxcclxuICAgICAgICByb3V0ZXM6IG1hdGNoZWRSb3V0ZXMsXHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3Qgc3VnZ2VzdGlvbnMgPSBhbGxSb3V0ZXNcclxuICAgICAgLmZpbHRlcigocm91dGUpID0+IHtcclxuICAgICAgICBjb25zdCBub3JtYWxpemVkSW5wdXQgPSBub3JtYWxpemVUZXh0KGlucHV0KTtcclxuICAgICAgICBjb25zdCBub3JtYWxpemVkTmFtZSA9IG5vcm1hbGl6ZVRleHQocm91dGUubmFtZSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICBub3JtYWxpemVkTmFtZS5pbmNsdWRlcyhcclxuICAgICAgICAgICAgbm9ybWFsaXplZElucHV0LnNwbGl0KFwiIFwiKVswXVxyXG4gICAgICAgICAgKSB8fFxyXG4gICAgICAgICAgbm9ybWFsaXplZElucHV0XHJcbiAgICAgICAgICAgIC5zcGxpdChcIiBcIilcclxuICAgICAgICAgICAgLnNvbWUoXHJcbiAgICAgICAgICAgICAgKHdvcmQpID0+XHJcbiAgICAgICAgICAgICAgICB3b3JkLmxlbmd0aCA+PSAzICYmXHJcbiAgICAgICAgICAgICAgICBub3JtYWxpemVkTmFtZS5pbmNsdWRlcyh3b3JkKVxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgKTtcclxuICAgICAgfSlcclxuICAgICAgLnNsaWNlKDAsIDMpO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRleHQ6XHJcbiAgICAgICAgc3VnZ2VzdGlvbnMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgPyBcIkkgY291bGRuJ3QgZmluZCBhbiBleGFjdCBtYXRjaC4gRGlkIHlvdSBtZWFuIG9uZSBvZiB0aGVzZT9cIlxyXG4gICAgICAgICAgOiBcIkkgY291bGRuJ3QgZmluZCBhIG1hdGNoaW5nIHBhZ2UuIFRyeSBhc2tpbmcgd2l0aCBhIHBhZ2UgbmFtZSBzdWNoIGFzIGN1c3RvbWVyLCBwYXltZW50LCByZXBvcnQsIGRhc2hib2FyZCwgZ3JvdXAsIGFwcHJvdmFsLCBvciBhbm90aGVyIHBhZ2UuXCIsXHJcbiAgICAgIHJvdXRlczogc3VnZ2VzdGlvbnMsXHJcbiAgICB9O1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbmQgPSAoY3VzdG9tTWVzc2FnZSA9IG51bGwpID0+IHtcclxuICAgIGNvbnN0IHRleHRUb1NlbmQgPVxyXG4gICAgICBjdXN0b21NZXNzYWdlICE9PSBudWxsID8gY3VzdG9tTWVzc2FnZSA6IG1lc3NhZ2U7XHJcblxyXG4gICAgaWYgKCF0ZXh0VG9TZW5kLnRyaW0oKSB8fCBpc1R5cGluZykge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgY3VycmVudE1lc3NhZ2UgPSB0ZXh0VG9TZW5kLnRyaW0oKTtcclxuXHJcbiAgICBjb25zdCB1c2VyTWVzc2FnZSA9IHtcclxuICAgICAgaWQ6IERhdGUubm93KCksXHJcbiAgICAgIHR5cGU6IFwidXNlclwiLFxyXG4gICAgICB0ZXh0OiBjdXJyZW50TWVzc2FnZSxcclxuICAgIH07XHJcblxyXG4gICAgc2V0TWVzc2FnZXMoKHByZXYpID0+IFsuLi5wcmV2LCB1c2VyTWVzc2FnZV0pO1xyXG4gICAgc2V0TWVzc2FnZShcIlwiKTtcclxuICAgIHNldElzVHlwaW5nKHRydWUpO1xyXG5cclxuICAgIHNhdmVSZWNlbnRTZWFyY2goY3VycmVudE1lc3NhZ2UpO1xyXG5cclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGdldEFJUmVzcG9uc2UoY3VycmVudE1lc3NhZ2UpO1xyXG5cclxuICAgICAgc2V0TWVzc2FnZXMoKHByZXYpID0+IFtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiBEYXRlLm5vdygpICsgMSxcclxuICAgICAgICAgIHR5cGU6IFwiYWlcIixcclxuICAgICAgICAgIHRleHQ6IHJlc3BvbnNlLnRleHQsXHJcbiAgICAgICAgICByb3V0ZXM6IHJlc3BvbnNlLnJvdXRlcyxcclxuICAgICAgICB9LFxyXG4gICAgICBdKTtcclxuXHJcbiAgICAgIHNldElzVHlwaW5nKGZhbHNlKTtcclxuXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGlucHV0UmVmLmN1cnJlbnQ/LmZvY3VzKCk7XHJcbiAgICAgIH0sIDUwKTtcclxuICAgIH0sIDUwMCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlKSA9PiB7XHJcbiAgICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIiAmJiAhZS5zaGlmdEtleSkge1xyXG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgIGhhbmRsZVNlbmQoKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVOYXZpZ2F0ZSA9IChwYXRoKSA9PiB7XHJcbiAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgIG5hdmlnYXRlKHBhdGgpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsZWFyQ2hhdCA9ICgpID0+IHtcclxuICAgIHNldE1lc3NhZ2VzKFtJTklUSUFMX01FU1NBR0VdKTtcclxuICAgIHNldE1lc3NhZ2UoXCJcIik7XHJcbiAgICBzZXRJc1R5cGluZyhmYWxzZSk7XHJcblxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIGlucHV0UmVmLmN1cnJlbnQ/LmZvY3VzKCk7XHJcbiAgICB9LCAxMDApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlY2VudFNlYXJjaCA9IChzZWFyY2gpID0+IHtcclxuICAgIHNldE1lc3NhZ2Uoc2VhcmNoKTtcclxuXHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgaW5wdXRSZWYuY3VycmVudD8uZm9jdXMoKTtcclxuICAgIH0sIDUwKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gY3JlYXRlUG9ydGFsKFxyXG4gICAgPD5cclxuICAgICAgPHN0eWxlPlxyXG4gICAgICAgIHtgXHJcbiAgICAgICAgICBAa2V5ZnJhbWVzIGFpRmxvYXQge1xyXG4gICAgICAgICAgICAwJSwgMTAwJSB7XHJcbiAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICA1MCUge1xyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtOHB4KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIEBrZXlmcmFtZXMgYWlHbG93IHtcclxuICAgICAgICAgICAgMCUsIDEwMCUge1xyXG4gICAgICAgICAgICAgIGJveC1zaGFkb3c6XHJcbiAgICAgICAgICAgICAgICAwIDhweCAyNXB4IHJnYmEoMTI0LCA1OCwgMjM3LCAwLjM1KSxcclxuICAgICAgICAgICAgICAgIDAgMCAwIDAgcmdiYSgxMjQsIDU4LCAyMzcsIDAuMjUpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICA1MCUge1xyXG4gICAgICAgICAgICAgIGJveC1zaGFkb3c6XHJcbiAgICAgICAgICAgICAgICAwIDEycHggMzVweCByZ2JhKDEyNCwgNTgsIDIzNywgMC41NSksXHJcbiAgICAgICAgICAgICAgICAwIDAgMCA4cHggcmdiYSgxMjQsIDU4LCAyMzcsIDAuMDgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgQGtleWZyYW1lcyBhaVB1bHNlIHtcclxuICAgICAgICAgICAgMCUge1xyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC45NSk7XHJcbiAgICAgICAgICAgICAgb3BhY2l0eTogMC43O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICA3MCUge1xyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMS4zNSk7XHJcbiAgICAgICAgICAgICAgb3BhY2l0eTogMDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgMTAwJSB7XHJcbiAgICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjM1KTtcclxuICAgICAgICAgICAgICBvcGFjaXR5OiAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgQGtleWZyYW1lcyBhaVR5cGluZyB7XHJcbiAgICAgICAgICAgIDAlLCA4MCUsIDEwMCUge1xyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTtcclxuICAgICAgICAgICAgICBvcGFjaXR5OiAwLjQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIDQwJSB7XHJcbiAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC00cHgpO1xyXG4gICAgICAgICAgICAgIG9wYWNpdHk6IDE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICBgfVxyXG4gICAgICA8L3N0eWxlPlxyXG5cclxuICAgICAge29wZW4gJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgYm90dG9tLTIwIHJpZ2h0LTYgei1bOTk5OV0gZmxleCBoLVs1NjBweF0gdy1bMzkwcHhdIG1heC13LVtjYWxjKDEwMHZ3LTJyZW0pXSBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctMnhsXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1ncmFkaWVudC10by1yIGZyb20tdmlvbGV0LTYwMCB0by1ibHVlLTYwMCBweC00IHB5LTMgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtOSB3LTkgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy13aGl0ZS8yMFwiPlxyXG4gICAgICAgICAgICAgICAgPEJvdCBzaXplPXsyMX0gLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIE15Q2hpdHMgSGVscGVyXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC13aGl0ZS84MFwiPlxyXG4gICAgICAgICAgICAgICAgICBDaGF0IEFzc2lzdGFudFxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJDaGF0fVxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJDbGVhciBjaGF0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdHJhbnNpdGlvbiBob3ZlcjpiZy13aGl0ZS8yMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxN30gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiQ2xvc2VcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBwLTEuNSB0cmFuc2l0aW9uIGhvdmVyOmJnLXdoaXRlLzIwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8WCBzaXplPXsxOX0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MTJ9IGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgUXVpY2sgQWN0aW9uc1xyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMS41IG92ZXJmbG93LXgtYXV0byBwYi0xXCI+XHJcbiAgICAgICAgICAgICAge1FVSUNLX0FDVElPTlMubWFwKChhY3Rpb24pID0+IChcclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAga2V5PXthY3Rpb259XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZW5kKGFjdGlvbil9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNocmluay0wIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXZpb2xldC0yMDAgYmctdmlvbGV0LTUwIHB4LTIuNSBweS0xIHRleHQtWzEwcHhdIGZvbnQtbWVkaXVtIHRleHQtdmlvbGV0LTcwMCB0cmFuc2l0aW9uIGhvdmVyOmJnLXZpb2xldC0xMDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7YWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgc3BhY2UteS0zIG92ZXJmbG93LXktYXV0byBiZy1ncmF5LTUwIHAtNFwiPlxyXG4gICAgICAgICAgICB7bWVzc2FnZXMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCAke1xyXG4gICAgICAgICAgICAgICAgICBpdGVtLnR5cGUgPT09IFwidXNlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcImp1c3RpZnktZW5kXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwianVzdGlmeS1zdGFydFwiXHJcbiAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggbWF4LXctWzkwJV0gaXRlbXMtZW5kIGdhcC0yICR7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbS50eXBlID09PSBcInVzZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImZsZXgtcm93LXJldmVyc2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBoLTcgdy03IHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgJHtcclxuICAgICAgICAgICAgICAgICAgICAgIGl0ZW0udHlwZSA9PT0gXCJ1c2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtMTAwIHRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctdmlvbGV0LTEwMCB0ZXh0LXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2l0ZW0udHlwZSA9PT0gXCJ1c2VyXCIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8VXNlciBzaXplPXsxNX0gLz5cclxuICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJvdCBzaXplPXsxNX0gLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLTJ4bCBweC0zIHB5LTIgdGV4dC1zbSAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgaXRlbS50eXBlID09PSBcInVzZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwicm91bmRlZC1ici1zbSBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcInJvdW5kZWQtYmwtc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+e2l0ZW0udGV4dH08L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2l0ZW0ucm91dGVzPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucm91dGVzLm1hcCgocm91dGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3JvdXRlLnBhdGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZU5hdmlnYXRlKHJvdXRlLnBhdGgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcm91bmRlZC1sZyBiZy12aW9sZXQtNjAwIHB4LTMgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIHRyYW5zaXRpb24gaG92ZXI6YmctdmlvbGV0LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj57cm91dGUubmFtZX08L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LVsxMHB4XSB0ZXh0LXZpb2xldC0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JvdXRlLnBhdGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApKX1cclxuXHJcbiAgICAgICAgICAgIHtpc1R5cGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtNyB3LTcgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy12aW9sZXQtMTAwIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3Qgc2l6ZT17MTV9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCByb3VuZGVkLWJsLXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcHgtNCBweS0yLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEuNSB3LTEuNSByb3VuZGVkLWZ1bGwgYmctdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYW5pbWF0aW9uOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhaVR5cGluZyAxLjJzIGluZmluaXRlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMS41IHctMS41IHJvdW5kZWQtZnVsbCBiZy12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbmltYXRpb246XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFpVHlwaW5nIDEuMnMgaW5maW5pdGUgMC4xNXNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xLjUgdy0xLjUgcm91bmRlZC1mdWxsIGJnLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFuaW1hdGlvbjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWlUeXBpbmcgMS4ycyBpbmZpbml0ZSAwLjNzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiByZWY9e21lc3NhZ2VzRW5kUmVmfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge3JlY2VudFNlYXJjaGVzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBiZy13aGl0ZSBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgIDxDbG9jazMgc2l6ZT17MTF9IC8+XHJcbiAgICAgICAgICAgICAgICBSZWNlbnRcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xLjUgb3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICB7cmVjZW50U2VhcmNoZXMubWFwKChzZWFyY2gpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17c2VhcmNofVxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlY2VudFNlYXJjaChzZWFyY2gpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNocmluay0wIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktNTAgcHgtMi41IHB5LTEgdGV4dC1bMTBweF0gdGV4dC1ncmF5LTYwMCB0cmFuc2l0aW9uIGhvdmVyOmJvcmRlci12aW9sZXQtMjAwIGhvdmVyOmJnLXZpb2xldC01MCBob3Zlcjp0ZXh0LXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3NlYXJjaH1cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1bMTBweF0gdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgIEN1cnJlbnQgcGFnZToge2N1cnJlbnRQYWdlTmFtZX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICByZWY9e2lucHV0UmVmfVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e21lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldE1lc3NhZ2UoZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBvbktleURvd249e2hhbmRsZUtleURvd259XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFzayB3aGVyZSB5b3Ugd2FudCB0byBnby4uLlwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsXCJcclxuICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXHJcbiAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VuZCgpfVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFtZXNzYWdlLnRyaW0oKSB8fCBpc1R5cGluZ31cclxuICAgICAgICAgICAgICAgIGljb249ezxTZW5kIHNpemU9ezE2fSAvPn1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LTEwIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVs5cHhdIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICBQcmVzcyBFbnRlciB0byBzZWFyY2gg4oCiIEVzYyB0byBjbG9zZVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oKHByZXYpID0+ICFwcmV2KX1cclxuICAgICAgICBjbGFzc05hbWU9XCJncm91cCBmaXhlZCBib3R0b20tNiByaWdodC02IGZsZXggaC0xNCB3LTE0IGN1cnNvci1wb2ludGVyIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNjAwIHZpYS1wdXJwbGUtNjAwIHRvLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LVswXzhweF8zMHB4X3JnYmEoMTI0LDU4LDIzNywwLjQ1KV0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOnNjYWxlLTExMCBob3ZlcjpzaGFkb3ctWzBfMTJweF8zNXB4X3JnYmEoMTI0LDU4LDIzNywwLjYpXSBhY3RpdmU6c2NhbGUtOTVcIlxyXG4gICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICBhbmltYXRpb246IG9wZW5cclxuICAgICAgICAgICAgPyBcIm5vbmVcIlxyXG4gICAgICAgICAgICA6IFwiYWlGbG9hdCAzcyBlYXNlLWluLW91dCBpbmZpbml0ZSwgYWlHbG93IDNzIGVhc2UtaW4tb3V0IGluZmluaXRlXCIsXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIHshb3BlbiAmJiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItdmlvbGV0LTMwMC80MFwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIGFuaW1hdGlvbjogXCJhaVB1bHNlIDIuMnMgZWFzZS1vdXQgaW5maW5pdGVcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtWzNweF0gcm91bmRlZC1mdWxsIGJnLXdoaXRlLzEwXCIgLz5cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGdyb3VwLWhvdmVyOnJvdGF0ZS0xMlwiPlxyXG4gICAgICAgICAge29wZW4gPyAoXHJcbiAgICAgICAgICAgIDxYIHNpemU9ezIzfSAvPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPE1lc3NhZ2VDaXJjbGUgc2l6ZT17MjZ9IC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8Lz4sXHJcbiAgICBkb2N1bWVudC5ib2R5XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFJQ2hhdDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQUlDaGF0LmpzeCJ9