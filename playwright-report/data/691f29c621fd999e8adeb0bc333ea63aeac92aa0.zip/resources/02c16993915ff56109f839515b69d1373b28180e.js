import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerAreaReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import {
  SearchOutlined,
  FilterOutlined,
  ReloadOutlined,
  CalendarOutlined,
  UserOutlined,
  EnvironmentOutlined,
  CloseCircleOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  DownloadOutlined,
  EyeOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import {
  Select,
  Input,
  Space,
  Tag,
  Button,
  Badge,
  Tooltip,
  Card,
  Row,
  Col
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import filterOption from "/src/helpers/filterOption.js";
const { Option } = Select;
const useDebounce = (value, delay) => {
  _s();
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
};
_s(useDebounce, "KDuPAtDOgxm8PU6legVJOb3oOmA=");
const CustomerAreaReport = () => {
  _s2();
  const [selectedGroup, setSelectedGroup] = useState("All");
  const [selectedCustomerArea, setSelectedCustomerArea] = useState(null);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [showCustomDate, setShowCustomDate] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [reportData, setReportData] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [customerAreas, setCustomerAreas] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info"
  });
  const formatDateDisplay = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };
  const debouncedSearch = useDebounce(searchInput, 300);
  useEffect(() => {
    setSearchText(debouncedSearch);
  }, [debouncedSearch]);
  const groupOptions = [
    { value: "All", label: "All", icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 516,
      columnNumber: 39
    }, this) },
    { value: "Today", label: "Today", icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 517,
      columnNumber: 43
    }, this) },
    { value: "Yesterday", label: "Yesterday", icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 518,
      columnNumber: 51
    }, this) },
    { value: "OneWeek", label: "One Week", icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 519,
      columnNumber: 48
    }, this) },
    { value: "ThisMonth", label: "This Month", icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 520,
      columnNumber: 52
    }, this) },
    { value: "LastMonth", label: "Last Month", icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 521,
      columnNumber: 52
    }, this) },
    { value: "ThisYear", label: "This Year", icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 522,
      columnNumber: 50
    }, this) },
    { value: "Custom", label: "Custom", icon: /* @__PURE__ */ jsxDEV(CalendarOutlined, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 523,
      columnNumber: 45
    }, this) }
  ];
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "customer_id", header: "Customer ID" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "area_name", header: "Customer Area" },
    { key: "area_code", header: "Area Code" },
    { key: "area_type", header: "Area Type" },
    { key: "pincode", header: "Pincode" }
  ];
  useEffect(() => {
    const fetchDropdownData = async () => {
      try {
        const [areasResponse, customersResponse] = await Promise.all(
          [
            api.get("/v1/admin/customer-area"),
            api.get("/user/get-user")
          ]
        );
        setCustomerAreas(areasResponse.data?.data || []);
        setCustomers(customersResponse.data || []);
      } catch (error) {
        console.error("Error fetching dropdown data:", error);
      }
    };
    fetchDropdownData();
  }, []);
  const handleSelectFilter = (value) => {
    setSelectedGroup(value);
    setShowCustomDate(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setFromDate(formatted);
      setToDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setFromDate(formatted);
      setToDate(formatted);
    } else if (value === "OneWeek") {
      const fromDate2 = /* @__PURE__ */ new Date();
      fromDate2.setDate(today.getDate() - 7);
      setFromDate(formatDate(fromDate2));
      setToDate(formatDate(today));
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
    } else if (value === "All") {
      setFromDate(null);
      setToDate(null);
    } else if (value === "Custom") {
      setShowCustomDate(true);
      setFromDate(null);
      setToDate(null);
    }
  };
  const transformDataForTable = (data) => {
    return data.map((customer, index) => ({
      id: index + 1,
      customer_id: customer.customer_id || customer.id || "N/A",
      name: customer.full_name || customer.name || "N/A",
      email: customer.email || "N/A",
      phone_number: customer.phone_number || customer.phone || "N/A",
      area_name: customer.customer_area?.area_name || "N/A",
      area_code: customer.customer_area?.area_code || "N/A",
      area_type: customer.customer_area?.area_type || "N/A",
      pincode: customer.customer_area?.pincode || "N/A",
      enrollment_date: customer.enrollment_date ? new Date(customer.enrollment_date).toLocaleDateString() : "N/A",
      created_at: customer.createdAt ? new Date(customer.createdAt).toLocaleString() : "N/A",
      _original: customer
    }));
  };
  const fetchReport = async () => {
    try {
      setIsLoading(true);
      const params = new URLSearchParams();
      if (selectedCustomerArea) {
        params.append("customerAreaId", selectedCustomerArea);
      }
      if (selectedCustomer) {
        params.append("customer", selectedCustomer);
      }
      if (fromDate && fromDate !== "Invalid Date") {
        params.append("from_date", fromDate);
      }
      if (toDate && toDate !== "Invalid Date") {
        params.append("to_date", toDate);
      }
      const response = await api.get(
        `/v1/admin/customer-area/report?${params.toString()}`
      );
      const transformedData = transformDataForTable(response.data?.data || []);
      setReportData(transformedData);
      setTableData(transformedData);
      if (transformedData.length === 0) {
        setAlertConfig({
          visibility: true,
          message: "No data found for the selected filters",
          type: "info"
        });
      }
    } catch (error) {
      console.error("Error fetching report:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to fetch report data",
        type: "error"
      });
      setReportData([]);
      setTableData([]);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(
    () => {
      if (!showCustomDate || fromDate && toDate) {
        fetchReport();
      }
    },
    [
      selectedCustomerArea,
      selectedCustomer,
      fromDate,
      toDate,
      showCustomDate
    ]
  );
  const filteredData = useMemo(() => {
    if (!searchText) return tableData;
    const searchLower = searchText.toLowerCase();
    return tableData.filter(
      (item) => Object.values(item).some(
        (value) => String(value).toLowerCase().includes(searchLower)
      )
    );
  }, [tableData, searchText]);
  const handleApplyFilters = () => {
    fetchReport();
  };
  const handleResetFilters = () => {
    setSelectedCustomerArea(null);
    setSelectedCustomer(null);
    setSelectedGroup("All");
    setFromDate(null);
    setToDate(null);
    setShowCustomDate(false);
    setSearchText("");
    setSearchInput("");
    setAlertConfig({ visibility: false, message: "", type: "info" });
  };
  const getActiveFiltersCount = () => {
    let count = 0;
    if (selectedCustomerArea) count++;
    if (selectedCustomer) count++;
    if (fromDate && toDate) count++;
    if (searchText) count++;
    return count;
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 min-h-screen p-4 md:p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm p-4 md:p-6 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-start md:items-center gap-4", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl md:text-3xl font-bold text-gray-800 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-3xl", children: "📊" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 738,
        columnNumber: 13
      }, this),
      "Customer Area Report"
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 737,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 736,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 735,
      columnNumber: 7
    }, this),
    alertConfig.visibility && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `mb-6 rounded-xl p-4 ${alertConfig.type === "error" ? "bg-red-50 border-l-4 border-red-500" : "bg-blue-50 border-l-4 border-blue-500"}`,
        children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xl", children: alertConfig.type === "error" ? "❌" : "ℹ️" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 756,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700", children: alertConfig.message }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 759,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 755,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "text-gray-400 hover:text-gray-600 text-2xl",
              onClick: () => setAlertConfig({ ...alertConfig, visibility: false }),
              children: "×"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 761,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 754,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 747,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Card, { className: "rounded-xl shadow-sm mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-gray-700 font-semibold", children: [
          /* @__PURE__ */ jsxDEV(FilterOutlined, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 777,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Filter Options" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 778,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 776,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              icon: /* @__PURE__ */ jsxDEV(ReloadOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                lineNumber: 783,
                columnNumber: 21
              }, this),
              onClick: handleApplyFilters,
              loading: isLoading,
              className: "rounded-lg bg-gray-900 hover:bg-gray-800",
              children: "Apply Filters"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 781,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "default",
              onClick: handleResetFilters,
              className: "rounded-lg",
              children: "Reset"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 790,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 780,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 775,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
            /* @__PURE__ */ jsxDEV(EnvironmentOutlined, { className: "mr-1" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 804,
              columnNumber: 15
            }, this),
            "Customer Area"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 803,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              placeholder: "All Areas",
              value: selectedCustomerArea,
              onChange: (value) => setSelectedCustomerArea(value),
              className: "w-full h-11 rounded-lg",
              allowClear: true,
              suffixIcon: /* @__PURE__ */ jsxDEV(EnvironmentOutlined, { className: "text-gray-400" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                lineNumber: 814,
                columnNumber: 27
              }, this),
              filterOption: (input, option) => {
                if (!option) return false;
                const searchText2 = option.label || "";
                return searchText2.toLowerCase().includes(input.toLowerCase());
              },
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Areas" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                  lineNumber: 821,
                  columnNumber: 15
                }, this),
                customerAreas.map(
                  (area) => /* @__PURE__ */ jsxDEV(
                    Select.Option,
                    {
                      value: area._id,
                      label: `${area.area_name} ${area.pincode || ""}`,
                      children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                        /* @__PURE__ */ jsxDEV("span", { children: area.area_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                          lineNumber: 829,
                          columnNumber: 21
                        }, this),
                        /* @__PURE__ */ jsxDEV(Tag, { color: "blue", className: "ml-2", children: area.pincode }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                          lineNumber: 830,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                        lineNumber: 828,
                        columnNumber: 19
                      }, this)
                    },
                    area._id,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                      lineNumber: 823,
                      columnNumber: 15
                    },
                    this
                  )
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 807,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 802,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
            /* @__PURE__ */ jsxDEV(UserOutlined, { className: "mr-1" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 842,
              columnNumber: 15
            }, this),
            "Customer"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 841,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              placeholder: "All Customers",
              value: selectedCustomer,
              onChange: (value) => setSelectedCustomer(value),
              className: "w-full h-11 rounded-lg",
              allowClear: true,
              suffixIcon: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-gray-400" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                lineNumber: 852,
                columnNumber: 27
              }, this),
              filterOption: (input, option) => {
                if (!option) return false;
                const searchText2 = option.label || "";
                return searchText2.toLowerCase().includes(input.toLowerCase());
              },
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                  lineNumber: 859,
                  columnNumber: 15
                }, this),
                customers.map((customer) => {
                  const displayName = customer.full_name || customer.name || "Unknown";
                  const displayPhone = customer.phone_number || "";
                  const label = `${displayName} ${displayPhone}`.trim();
                  return /* @__PURE__ */ jsxDEV(
                    Select.Option,
                    {
                      value: customer._id,
                      label,
                      children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between w-full", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: displayName }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                          lineNumber: 872,
                          columnNumber: 23
                        }, this),
                        displayPhone && /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 ml-2", children: displayPhone }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                          lineNumber: 876,
                          columnNumber: 23
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                        lineNumber: 871,
                        columnNumber: 21
                      }, this)
                    },
                    customer._id,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                      lineNumber: 866,
                      columnNumber: 19
                    },
                    this
                  );
                })
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 845,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 840,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
            /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { className: "mr-1" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 890,
              columnNumber: 15
            }, this),
            "Date Range"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 889,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              popupMatchSelectWidth: false,
              onChange: handleSelectFilter,
              value: selectedGroup,
              placeholder: "Select Date Range",
              filterOption: (input, option) => {
                if (!option) return false;
                const searchText2 = option.label || "";
                return searchText2.toLowerCase().includes(input.toLowerCase());
              },
              className: "w-full h-11 rounded-lg",
              suffixIcon: /* @__PURE__ */ jsxDEV(Badge, { dot: selectedGroup !== "All", children: /* @__PURE__ */ jsxDEV(FilterOutlined, { className: "text-gray-400" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                lineNumber: 907,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                lineNumber: 906,
                columnNumber: 15
              }, this),
              optionLabelProp: "label",
              children: groupOptions.map(
                (time) => /* @__PURE__ */ jsxDEV(
                  Select.Option,
                  {
                    value: time.value,
                    label: time.label,
                    children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 py-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: time.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                        lineNumber: 919,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "flex-1", children: time.label }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                        lineNumber: 920,
                        columnNumber: 21
                      }, this),
                      time.value === selectedGroup && /* @__PURE__ */ jsxDEV(CheckCircleOutlined, { className: "text-blue-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                        lineNumber: 922,
                        columnNumber: 19
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                      lineNumber: 918,
                      columnNumber: 19
                    }, this)
                  },
                  time.value,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                    lineNumber: 913,
                    columnNumber: 15
                  },
                  this
                )
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 893,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 888,
          columnNumber: 11
        }, this),
        showCustomDate && /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
            /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "mr-1" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 934,
              columnNumber: 17
            }, this),
            "Custom Date Range"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 933,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "flex-1 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition",
                value: fromDate || "",
                onChange: (e) => setFromDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                lineNumber: 938,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:flex items-center text-gray-400", children: "to" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 944,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "flex-1 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition",
                value: toDate || "",
                onChange: (e) => setToDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                lineNumber: 947,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 937,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 932,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 800,
        columnNumber: 9
      }, this),
      getActiveFiltersCount() > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-600", children: "Active Filters:" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 962,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
          selectedCustomerArea && /* @__PURE__ */ jsxDEV(
            Tag,
            {
              closable: true,
              onClose: () => setSelectedCustomerArea(null),
              className: "rounded-full px-3 py-1",
              color: "blue",
              children: [
                /* @__PURE__ */ jsxDEV(EnvironmentOutlined, { className: "mr-1" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                  lineNumber: 973,
                  columnNumber: 21
                }, this),
                customerAreas.find((a) => a._id === selectedCustomerArea)?.area_name
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 967,
              columnNumber: 15
            },
            this
          ),
          selectedCustomer && /* @__PURE__ */ jsxDEV(
            Tag,
            {
              closable: true,
              onClose: () => setSelectedCustomer(null),
              className: "rounded-full px-3 py-1",
              color: "green",
              children: [
                /* @__PURE__ */ jsxDEV(UserOutlined, { className: "mr-1" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                  lineNumber: 987,
                  columnNumber: 21
                }, this),
                customers.find((c) => c._id === selectedCustomer)?.full_name
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 981,
              columnNumber: 15
            },
            this
          ),
          fromDate && toDate && /* @__PURE__ */ jsxDEV(
            Tag,
            {
              closable: true,
              onClose: () => {
                setFromDate(null);
                setToDate(null);
              },
              className: "rounded-full px-3 py-1",
              color: "purple",
              children: [
                /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "mr-1" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                  lineNumber: 1004,
                  columnNumber: 21
                }, this),
                formatDateDisplay(fromDate),
                " → ",
                formatDateDisplay(toDate)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 995,
              columnNumber: 15
            },
            this
          ),
          searchText && /* @__PURE__ */ jsxDEV(
            Tag,
            {
              closable: true,
              onClose: () => {
                setSearchText("");
                setSearchInput("");
              },
              className: "rounded-full px-3 py-1",
              color: "orange",
              children: [
                /* @__PURE__ */ jsxDEV(SearchOutlined, { className: "mr-1" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                  lineNumber: 1018,
                  columnNumber: 21
                }, this),
                '"',
                searchText,
                '"'
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 1009,
              columnNumber: 15
            },
            this
          ),
          selectedGroup !== "All" && !fromDate && !toDate && /* @__PURE__ */ jsxDEV(
            Tag,
            {
              closable: true,
              onClose: () => {
                setSelectedGroup("All");
                setFromDate(null);
                setToDate(null);
              },
              className: "rounded-full px-3 py-1",
              color: "cyan",
              children: [
                /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { className: "mr-1" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
                  lineNumber: 1032,
                  columnNumber: 21
                }, this),
                selectedGroup
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 1022,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 965,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 961,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 960,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 774,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "rounded-xl shadow-sm hover:shadow-md transition-shadow", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center text-2xl", children: "👥" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 1046,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Total Customers" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 1050,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: reportData.length }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 1051,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 1049,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 1045,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 1044,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "rounded-xl shadow-sm hover:shadow-md transition-shadow", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-xl bg-purple-50 flex items-center justify-center text-2xl", children: "📅" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 1062,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Date Range" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 1066,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-800", children: fromDate && toDate ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            formatDateDisplay(fromDate),
            /* @__PURE__ */ jsxDEV("span", { className: "mx-1", children: "→" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
              lineNumber: 1071,
              columnNumber: 21
            }, this),
            formatDateDisplay(toDate)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 1069,
            columnNumber: 17
          }, this) : "All Time" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
            lineNumber: 1067,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
          lineNumber: 1065,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 1061,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 1060,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 1043,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "rounded-xl shadow-sm", children: filteredData?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        catcher: "_id",
        data: filteredData,
        columns,
        exportedPdfName: "Customer Area Report",
        exportedFileName: "Customer Area Report.csv"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 1086,
        columnNumber: 9
      },
      this
    ) : /* @__PURE__ */ jsxDEV(
      CircularLoader,
      {
        isLoading,
        failure: filteredData.length <= 0,
        data: "Customer Area Report Data"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
        lineNumber: 1094,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
      lineNumber: 1084,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx",
    lineNumber: 733,
    columnNumber: 5
  }, this);
};
_s2(CustomerAreaReport, "LpmYMsuND6nlNj5+XNPbdwg2a24=", false, function() {
  return [useDebounce];
});
_c = CustomerAreaReport;
export default CustomerAreaReport;
var _c;
$RefreshReg$(_c, "CustomerAreaReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAreaReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbWdCd0MsU0F5aUJ0QixVQXppQnNCOztBQW5nQnhDLG9CQUFnQkEsT0FBVUMsc0JBQWtCLGVBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFM0QsT0FBT0MsZUFBZTtBQUV0QixPQUFPQyx1QkFBdUI7QUFFOUIsT0FBT0Msb0JBQW9CO0FBRTNCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLE9BQU9DLFdBQVc7QUFFbEIsT0FBT0MsU0FBUztBQUNoQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxPQUFPQyxrQkFBa0I7QUFFekIsTUFBTSxFQUFFQyxPQUFPLElBQUlYO0FBZ2FuQixNQUFNWSxjQUFjQSxDQUFDQyxPQUFPQyxVQUFVO0FBQUFDLEtBQUE7QUFDcEMsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJbkMsU0FBUytCLEtBQUs7QUFFMUQ5QixZQUFVLE1BQU07QUFDZCxVQUFNbUMsVUFBVUMsV0FBVyxNQUFNO0FBQy9CRix3QkFBa0JKLEtBQUs7QUFBQSxJQUN6QixHQUFHQyxLQUFLO0FBRVIsV0FBTyxNQUFNO0FBQ1hNLG1CQUFhRixPQUFPO0FBQUEsSUFDdEI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0wsT0FBT0MsS0FBSyxDQUFDO0FBRWpCLFNBQU9FO0FBQ1Q7QUFBRUQsR0FkSUgsYUFBVztBQWdCakIsTUFBTVMscUJBQXFCQSxNQUFNO0FBQUFDLE1BQUE7QUFFL0IsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSTFDLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUMyQyxzQkFBc0JDLHVCQUF1QixJQUFJNUMsU0FBUyxJQUFJO0FBQ3JFLFFBQU0sQ0FBQzZDLGtCQUFrQkMsbUJBQW1CLElBQUk5QyxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDK0MsVUFBVUMsV0FBVyxJQUFJaEQsU0FBUyxJQUFJO0FBQzdDLFFBQU0sQ0FBQ2lELFFBQVFDLFNBQVMsSUFBSWxELFNBQVMsSUFBSTtBQUN6QyxRQUFNLENBQUNtRCxnQkFBZ0JDLGlCQUFpQixJQUFJcEQsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ3FELFlBQVlDLGFBQWEsSUFBSXRELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN1RCxhQUFhQyxjQUFjLElBQUl4RCxTQUFTLEVBQUU7QUFHakQsUUFBTSxDQUFDeUQsV0FBV0MsWUFBWSxJQUFJMUQsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzJELFlBQVlDLGFBQWEsSUFBSTVELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM2RCxXQUFXQyxZQUFZLElBQUk5RCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDK0QsZUFBZUMsZ0JBQWdCLElBQUloRSxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDaUUsV0FBV0MsWUFBWSxJQUFJbEUsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ21FLGFBQWFDLGNBQWMsSUFBSXBFLFNBQVM7QUFBQSxJQUM3Q3FFLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUdELFFBQU1DLG9CQUFvQkEsQ0FBQ0MsZUFBZTtBQUN4QyxRQUFJLENBQUNBLFdBQVksUUFBTztBQUN4QixVQUFNQyxPQUFPLElBQUlDLEtBQUtGLFVBQVU7QUFDaEMsVUFBTUcsTUFBTUMsT0FBT0gsS0FBS0ksUUFBUSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQ2xELFVBQU1DLFFBQVFILE9BQU9ILEtBQUtPLFNBQVMsSUFBSSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQ3pELFVBQU1HLE9BQU9SLEtBQUtTLFlBQVk7QUFDOUIsV0FBTyxHQUFHUCxHQUFHLElBQUlJLEtBQUssSUFBSUUsSUFBSTtBQUFBLEVBQ2hDO0FBR0EsUUFBTUUsa0JBQWtCdEQsWUFBWXlCLGFBQWEsR0FBRztBQUdwRHRELFlBQVUsTUFBTTtBQUNkcUQsa0JBQWM4QixlQUFlO0FBQUEsRUFDL0IsR0FBRyxDQUFDQSxlQUFlLENBQUM7QUFHcEIsUUFBTUMsZUFBZTtBQUFBLElBQ25CLEVBQUV0RCxPQUFPLE9BQU91RCxPQUFPLE9BQU9DLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQixFQUFJO0FBQUEsSUFDNUQsRUFBRXhELE9BQU8sU0FBU3VELE9BQU8sU0FBU0MsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CLEVBQUk7QUFBQSxJQUNoRSxFQUFFeEQsT0FBTyxhQUFhdUQsT0FBTyxhQUFhQyxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0IsRUFBSTtBQUFBLElBQ3hFLEVBQUV4RCxPQUFPLFdBQVd1RCxPQUFPLFlBQVlDLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQixFQUFJO0FBQUEsSUFDckUsRUFBRXhELE9BQU8sYUFBYXVELE9BQU8sY0FBY0MsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CLEVBQUk7QUFBQSxJQUN6RSxFQUFFeEQsT0FBTyxhQUFhdUQsT0FBTyxjQUFjQyxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0IsRUFBSTtBQUFBLElBQ3pFLEVBQUV4RCxPQUFPLFlBQVl1RCxPQUFPLGFBQWFDLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQixFQUFJO0FBQUEsSUFDdkUsRUFBRXhELE9BQU8sVUFBVXVELE9BQU8sVUFBVUMsTUFBTSx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCLEVBQUk7QUFBQSxFQUFDO0FBSWxFLFFBQU1DLFVBQVU7QUFBQSxJQUNkLEVBQUVDLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxnQkFBZ0I7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxZQUFZO0FBQUEsSUFDeEMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxFQUFDO0FBSXZDekYsWUFBVSxNQUFNO0FBQ2QsVUFBTTBGLG9CQUFvQixZQUFZO0FBQ3BDLFVBQUk7QUFDRixjQUFNLENBQUNDLGVBQWVDLGlCQUFpQixJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUMzRDlFLElBQUkrRSxJQUFJLHlCQUF5QjtBQUFBLFlBQ2pDL0UsSUFBSStFLElBQUksZ0JBQWdCO0FBQUEsVUFBQztBQUFBLFFBQzFCO0FBRURoQyx5QkFBaUI0QixjQUFjSyxNQUFNQSxRQUFRLEVBQUU7QUFDL0MvQixxQkFBYTJCLGtCQUFrQkksUUFBUSxFQUFFO0FBQUEsTUFDM0MsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxpQ0FBaUNBLEtBQUs7QUFBQSxNQUN0RDtBQUFBLElBQ0Y7QUFDQVAsc0JBQWtCO0FBQUEsRUFDcEIsR0FBRyxFQUFFO0FBR0wsUUFBTVMscUJBQXFCQSxDQUFDckUsVUFBVTtBQUNwQ1cscUJBQWlCWCxLQUFLO0FBQ3RCcUIsc0JBQWtCLEtBQUs7QUFFdkIsVUFBTWlELFFBQVEsb0JBQUkxQixLQUFLO0FBQ3ZCLFVBQU0yQixhQUFhQSxDQUFDNUIsU0FBU0EsS0FBSzZCLG1CQUFtQixPQUFPO0FBRTVELFFBQUl4RSxVQUFVLFNBQVM7QUFDckIsWUFBTXlFLFlBQVlGLFdBQVdELEtBQUs7QUFDbENyRCxrQkFBWXdELFNBQVM7QUFDckJ0RCxnQkFBVXNELFNBQVM7QUFBQSxJQUNyQixXQUFXekUsVUFBVSxhQUFhO0FBQ2hDLFlBQU0wRSxZQUFZLElBQUk5QixLQUFLMEIsS0FBSztBQUNoQ0ksZ0JBQVVDLFFBQVFELFVBQVUzQixRQUFRLElBQUksQ0FBQztBQUN6QyxZQUFNMEIsWUFBWUYsV0FBV0csU0FBUztBQUN0Q3pELGtCQUFZd0QsU0FBUztBQUNyQnRELGdCQUFVc0QsU0FBUztBQUFBLElBQ3JCLFdBQVd6RSxVQUFVLFdBQVc7QUFDOUIsWUFBTWdCLFlBQVcsb0JBQUk0QixLQUFLO0FBQzFCNUIsZ0JBQVMyRCxRQUFRTCxNQUFNdkIsUUFBUSxJQUFJLENBQUM7QUFDcEM5QixrQkFBWXNELFdBQVd2RCxTQUFRLENBQUM7QUFDaENHLGdCQUFVb0QsV0FBV0QsS0FBSyxDQUFDO0FBQUEsSUFDN0IsV0FBV3RFLFVBQVUsYUFBYTtBQUNoQyxZQUFNNEUsUUFBUSxJQUFJaEMsS0FBSzBCLE1BQU1sQixZQUFZLEdBQUdrQixNQUFNcEIsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTTJCLE1BQU0sSUFBSWpDLEtBQUswQixNQUFNbEIsWUFBWSxHQUFHa0IsTUFBTXBCLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakVqQyxrQkFBWXNELFdBQVdLLEtBQUssQ0FBQztBQUM3QnpELGdCQUFVb0QsV0FBV00sR0FBRyxDQUFDO0FBQUEsSUFDM0IsV0FBVzdFLFVBQVUsYUFBYTtBQUNoQyxZQUFNNEUsUUFBUSxJQUFJaEMsS0FBSzBCLE1BQU1sQixZQUFZLEdBQUdrQixNQUFNcEIsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNuRSxZQUFNMkIsTUFBTSxJQUFJakMsS0FBSzBCLE1BQU1sQixZQUFZLEdBQUdrQixNQUFNcEIsU0FBUyxHQUFHLENBQUM7QUFDN0RqQyxrQkFBWXNELFdBQVdLLEtBQUssQ0FBQztBQUM3QnpELGdCQUFVb0QsV0FBV00sR0FBRyxDQUFDO0FBQUEsSUFDM0IsV0FBVzdFLFVBQVUsWUFBWTtBQUMvQixZQUFNNEUsUUFBUSxJQUFJaEMsS0FBSzBCLE1BQU1sQixZQUFZLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQU15QixNQUFNLElBQUlqQyxLQUFLMEIsTUFBTWxCLFlBQVksR0FBRyxJQUFJLEVBQUU7QUFDaERuQyxrQkFBWXNELFdBQVdLLEtBQUssQ0FBQztBQUM3QnpELGdCQUFVb0QsV0FBV00sR0FBRyxDQUFDO0FBQUEsSUFDM0IsV0FBVzdFLFVBQVUsT0FBTztBQUMxQmlCLGtCQUFZLElBQUk7QUFDaEJFLGdCQUFVLElBQUk7QUFBQSxJQUNoQixXQUFXbkIsVUFBVSxVQUFVO0FBQzdCcUIsd0JBQWtCLElBQUk7QUFDdEJKLGtCQUFZLElBQUk7QUFDaEJFLGdCQUFVLElBQUk7QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNMkQsd0JBQXdCQSxDQUFDWixTQUFTO0FBQ3RDLFdBQU9BLEtBQUthLElBQUksQ0FBQ0MsVUFBVUMsV0FBVztBQUFBLE1BQ3BDQyxJQUFJRCxRQUFRO0FBQUEsTUFDWkUsYUFBYUgsU0FBU0csZUFBZUgsU0FBU0UsTUFBTTtBQUFBLE1BQ3BERSxNQUFNSixTQUFTSyxhQUFhTCxTQUFTSSxRQUFRO0FBQUEsTUFDN0NFLE9BQU9OLFNBQVNNLFNBQVM7QUFBQSxNQUN6QkMsY0FBY1AsU0FBU08sZ0JBQWdCUCxTQUFTUSxTQUFTO0FBQUEsTUFDekRDLFdBQVdULFNBQVNVLGVBQWVELGFBQWE7QUFBQSxNQUNoREUsV0FBV1gsU0FBU1UsZUFBZUMsYUFBYTtBQUFBLE1BQ2hEQyxXQUFXWixTQUFTVSxlQUFlRSxhQUFhO0FBQUEsTUFDaERDLFNBQVNiLFNBQVNVLGVBQWVHLFdBQVc7QUFBQSxNQUM1Q0MsaUJBQWlCZCxTQUFTYyxrQkFDdEIsSUFBSWxELEtBQUtvQyxTQUFTYyxlQUFlLEVBQUV0QixtQkFBbUIsSUFDdEQ7QUFBQSxNQUNKdUIsWUFBWWYsU0FBU2dCLFlBQ2pCLElBQUlwRCxLQUFLb0MsU0FBU2dCLFNBQVMsRUFBRUMsZUFBZSxJQUM1QztBQUFBLE1BRUpDLFdBQVdsQjtBQUFBQSxJQUNiLEVBQUU7QUFBQSxFQUNKO0FBR0EsUUFBTW1CLGNBQWMsWUFBWTtBQUM5QixRQUFJO0FBQ0Z4RSxtQkFBYSxJQUFJO0FBRWpCLFlBQU15RSxTQUFTLElBQUlDLGdCQUFnQjtBQUVuQyxVQUFJekYsc0JBQXNCO0FBQ3hCd0YsZUFBT0UsT0FBTyxrQkFBa0IxRixvQkFBb0I7QUFBQSxNQUN0RDtBQUVBLFVBQUlFLGtCQUFrQjtBQUNwQnNGLGVBQU9FLE9BQU8sWUFBWXhGLGdCQUFnQjtBQUFBLE1BQzVDO0FBRUEsVUFBSUUsWUFBWUEsYUFBYSxnQkFBZ0I7QUFDM0NvRixlQUFPRSxPQUFPLGFBQWF0RixRQUFRO0FBQUEsTUFDckM7QUFFQSxVQUFJRSxVQUFVQSxXQUFXLGdCQUFnQjtBQUN2Q2tGLGVBQU9FLE9BQU8sV0FBV3BGLE1BQU07QUFBQSxNQUNqQztBQUVBLFlBQU1xRixXQUFXLE1BQU1ySCxJQUFJK0U7QUFBQUEsUUFDekIsa0NBQWtDbUMsT0FBT0ksU0FBUyxDQUFDO0FBQUEsTUFDckQ7QUFFQSxZQUFNQyxrQkFBa0IzQixzQkFBc0J5QixTQUFTckMsTUFBTUEsUUFBUSxFQUFFO0FBQ3ZFckMsb0JBQWM0RSxlQUFlO0FBQzdCMUUsbUJBQWEwRSxlQUFlO0FBRTVCLFVBQUlBLGdCQUFnQkMsV0FBVyxHQUFHO0FBQ2hDckUsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTMkIsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUM3QzlCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM0QixNQUFNb0MsVUFBVXJDLE1BQU0zQixXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRFgsb0JBQWMsRUFBRTtBQUNoQkUsbUJBQWEsRUFBRTtBQUFBLElBQ2pCLFVBQUM7QUFDQ0osbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBekQ7QUFBQUEsSUFBVSxNQUFNO0FBQ2QsVUFBSSxDQUFDa0Qsa0JBQW1CSixZQUFZRSxRQUFTO0FBQzNDaUYsb0JBQVk7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUFBLElBQUc7QUFBQSxNQUNEdkY7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsSUFBYztBQUFBLEVBQ2Y7QUFHRCxRQUFNdUYsZUFBZUMsUUFBUSxNQUFNO0FBQ2pDLFFBQUksQ0FBQ3RGLFdBQVksUUFBT1E7QUFFeEIsVUFBTStFLGNBQWN2RixXQUFXd0YsWUFBWTtBQUMzQyxXQUFPaEYsVUFBVWlGO0FBQUFBLE1BQU8sQ0FBQ0MsU0FDdkJDLE9BQU9DLE9BQU9GLElBQUksRUFBRUc7QUFBQUEsUUFBSyxDQUFDbkgsVUFDeEI4QyxPQUFPOUMsS0FBSyxFQUFFOEcsWUFBWSxFQUFFTSxTQUFTUCxXQUFXO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUMvRSxXQUFXUixVQUFVLENBQUM7QUFHMUIsUUFBTStGLHFCQUFxQkEsTUFBTTtBQUMvQmxCLGdCQUFZO0FBQUEsRUFDZDtBQUdBLFFBQU1tQixxQkFBcUJBLE1BQU07QUFDL0J6Ryw0QkFBd0IsSUFBSTtBQUM1QkUsd0JBQW9CLElBQUk7QUFDeEJKLHFCQUFpQixLQUFLO0FBQ3RCTSxnQkFBWSxJQUFJO0FBQ2hCRSxjQUFVLElBQUk7QUFDZEUsc0JBQWtCLEtBQUs7QUFDdkJFLGtCQUFjLEVBQUU7QUFDaEJFLG1CQUFlLEVBQUU7QUFDakJZLG1CQUFlLEVBQUVDLFlBQVksT0FBT0MsU0FBUyxJQUFJQyxNQUFNLE9BQU8sQ0FBQztBQUFBLEVBQ2pFO0FBR0EsUUFBTStFLHdCQUF3QkEsTUFBTTtBQUNsQyxRQUFJQyxRQUFRO0FBQ1osUUFBSTVHLHFCQUFzQjRHO0FBQzFCLFFBQUkxRyxpQkFBa0IwRztBQUN0QixRQUFJeEcsWUFBWUUsT0FBUXNHO0FBQ3hCLFFBQUlsRyxXQUFZa0c7QUFDaEIsV0FBT0E7QUFBQUEsRUFDVDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHNDQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlEQUNiLGlDQUFDLFNBQUksV0FBVSwrRUFDYixpQ0FBQyxRQUFHLFdBQVUsd0VBQ1o7QUFBQSw2QkFBQyxVQUFLLFdBQVUsWUFBVyxrQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLE1BQU87QUFBQSxTQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUdDcEYsWUFBWUUsY0FDWDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVyx1QkFDVEYsWUFBWUksU0FBUyxVQUNqQix3Q0FDQSx1Q0FBdUM7QUFBQSxRQUc3QyxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsV0FDYkosc0JBQVlJLFNBQVMsVUFBVSxNQUFNLFFBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxpQkFBaUJKLHNCQUFZRyxXQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRDtBQUFBLGVBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQ1BGLGVBQWUsRUFBRSxHQUFHRCxhQUFhRSxZQUFZLE1BQU0sQ0FBQztBQUFBLGNBQ3JEO0FBQUE7QUFBQSxZQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQTtBQUFBLE1BdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXVCQTtBQUFBLElBSUYsdUJBQUMsUUFBSyxXQUFVLDZCQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9GQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLFVBQ2YsdUJBQUMsVUFBSyw4QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLGFBRnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQU0sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZTtBQUFBLGNBQ3JCLFNBQVMrRTtBQUFBQSxjQUNULFNBQVMzRjtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUEwQztBQUFBO0FBQUEsWUFMdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTNEY7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBWTtBQUFBO0FBQUEsWUFIeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsV0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUViO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnREFDZjtBQUFBLG1DQUFDLHVCQUFvQixXQUFVLFVBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFDO0FBQUEsWUFBRztBQUFBLGVBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsYUFBWTtBQUFBLGNBQ1osT0FBTzFHO0FBQUFBLGNBQ1AsVUFBVSxDQUFDWixVQUFVYSx3QkFBd0JiLEtBQUs7QUFBQSxjQUNsRCxXQUFVO0FBQUEsY0FDVjtBQUFBLGNBQ0EsWUFBWSx1QkFBQyx1QkFBb0IsV0FBVSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQSxjQUMxRCxjQUFjLENBQUN5SCxPQUFPQyxXQUFXO0FBQy9CLG9CQUFJLENBQUNBLE9BQVEsUUFBTztBQUNwQixzQkFBTXBHLGNBQWFvRyxPQUFPbkUsU0FBUztBQUNuQyx1QkFBT2pDLFlBQVd3RixZQUFZLEVBQUVNLFNBQVNLLE1BQU1YLFlBQVksQ0FBQztBQUFBLGNBQzlEO0FBQUEsY0FFQTtBQUFBLHVDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyx5QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxnQkFDaEM5RSxjQUFjK0M7QUFBQUEsa0JBQUksQ0FBQzRDLFNBQ2xCO0FBQUEsb0JBQUMsT0FBTztBQUFBLG9CQUFQO0FBQUEsc0JBRUMsT0FBT0EsS0FBS0M7QUFBQUEsc0JBQ1osT0FBTyxHQUFHRCxLQUFLbEMsU0FBUyxJQUFJa0MsS0FBSzlCLFdBQVcsRUFBRTtBQUFBLHNCQUU5QyxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwrQ0FBQyxVQUFNOEIsZUFBS2xDLGFBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBc0I7QUFBQSx3QkFDdEIsdUJBQUMsT0FBSSxPQUFNLFFBQU8sV0FBVSxRQUN6QmtDLGVBQUs5QixXQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSwyQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUE7QUFBQSxvQkFUSzhCLEtBQUtDO0FBQUFBLG9CQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV0E7QUFBQSxnQkFDRDtBQUFBO0FBQUE7QUFBQSxZQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUE2QkE7QUFBQSxhQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGdEQUNmO0FBQUEsbUNBQUMsZ0JBQWEsV0FBVSxVQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBLFlBQUc7QUFBQSxlQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLE9BQU85RztBQUFBQSxjQUNQLFVBQVUsQ0FBQ2QsVUFBVWUsb0JBQW9CZixLQUFLO0FBQUEsY0FDOUMsV0FBVTtBQUFBLGNBQ1Y7QUFBQSxjQUNBLFlBQVksdUJBQUMsZ0JBQWEsV0FBVSxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUNuRCxjQUFjLENBQUN5SCxPQUFPQyxXQUFXO0FBQy9CLG9CQUFJLENBQUNBLE9BQVEsUUFBTztBQUNwQixzQkFBTXBHLGNBQWFvRyxPQUFPbkUsU0FBUztBQUNuQyx1QkFBT2pDLFlBQVd3RixZQUFZLEVBQUVNLFNBQVNLLE1BQU1YLFlBQVksQ0FBQztBQUFBLGNBQzlEO0FBQUEsY0FFQTtBQUFBLHVDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUM7QUFBQSxnQkFDcEM1RSxVQUFVNkMsSUFBSSxDQUFDQyxhQUFhO0FBQzNCLHdCQUFNNkMsY0FBYzdDLFNBQVNLLGFBQWFMLFNBQVNJLFFBQVE7QUFDM0Qsd0JBQU0wQyxlQUFlOUMsU0FBU08sZ0JBQWdCO0FBQzlDLHdCQUFNaEMsUUFBUSxHQUFHc0UsV0FBVyxJQUFJQyxZQUFZLEdBQUdDLEtBQUs7QUFFcEQseUJBQ0U7QUFBQSxvQkFBQyxPQUFPO0FBQUEsb0JBQVA7QUFBQSxzQkFFQyxPQUFPL0MsU0FBUzRDO0FBQUFBLHNCQUNoQjtBQUFBLHNCQUVBLGlDQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSxlQUNiQyx5QkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0NDLGdCQUNDLHVCQUFDLFVBQUssV0FBVSw4QkFDYkEsMEJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBU0E7QUFBQTtBQUFBLG9CQWJLOUMsU0FBUzRDO0FBQUFBLG9CQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWVBO0FBQUEsZ0JBRUosQ0FBQztBQUFBO0FBQUE7QUFBQSxZQXRDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUF1Q0E7QUFBQSxhQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkNBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGdEQUNmO0FBQUEsbUNBQUMsdUJBQW9CLFdBQVUsVUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxZQUFHO0FBQUEsZUFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSx1QkFBdUI7QUFBQSxjQUN2QixVQUFVdkQ7QUFBQUEsY0FDVixPQUFPM0Q7QUFBQUEsY0FDUCxhQUFZO0FBQUEsY0FDWixjQUFjLENBQUMrRyxPQUFPQyxXQUFXO0FBQy9CLG9CQUFJLENBQUNBLE9BQVEsUUFBTztBQUNwQixzQkFBTXBHLGNBQWFvRyxPQUFPbkUsU0FBUztBQUNuQyx1QkFBT2pDLFlBQVd3RixZQUFZLEVBQUVNLFNBQVNLLE1BQU1YLFlBQVksQ0FBQztBQUFBLGNBQzlEO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FDVixZQUNFLHVCQUFDLFNBQU0sS0FBS3BHLGtCQUFrQixPQUM1QixpQ0FBQyxrQkFBZSxXQUFVLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFRixpQkFBZ0I7QUFBQSxjQUVmNEMsdUJBQWF5QjtBQUFBQSxnQkFBSSxDQUFDaUQsU0FDakI7QUFBQSxrQkFBQyxPQUFPO0FBQUEsa0JBQVA7QUFBQSxvQkFFQyxPQUFPQSxLQUFLaEk7QUFBQUEsb0JBQ1osT0FBT2dJLEtBQUt6RTtBQUFBQSxvQkFFWixpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUsaUJBQWlCeUUsZUFBS3hFLFFBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJDO0FBQUEsc0JBQzNDLHVCQUFDLFVBQUssV0FBVSxVQUFVd0UsZUFBS3pFLFNBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXFDO0FBQUEsc0JBQ3BDeUUsS0FBS2hJLFVBQVVVLGlCQUNkLHVCQUFDLHVCQUFvQixXQUFVLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4QztBQUFBLHlCQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUE7QUFBQSxrQkFWS3NILEtBQUtoSTtBQUFBQSxrQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFqQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0NBO0FBQUEsYUF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdDQTtBQUFBLFFBR0NvQixrQkFDQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0RBQ2Y7QUFBQSxtQ0FBQyxvQkFBaUIsV0FBVSxVQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLFlBQUc7QUFBQSxlQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsT0FBT0osWUFBWTtBQUFBLGdCQUNuQixVQUFVLENBQUNpSCxNQUFNaEgsWUFBWWdILEVBQUVDLE9BQU9sSSxLQUFLO0FBQUE7QUFBQSxjQUo3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJK0M7QUFBQSxZQUUvQyx1QkFBQyxVQUFLLFdBQVUsNkNBQTRDLGtCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsT0FBT2tCLFVBQVU7QUFBQSxnQkFDakIsVUFBVSxDQUFDK0csTUFBTTlHLFVBQVU4RyxFQUFFQyxPQUFPbEksS0FBSztBQUFBO0FBQUEsY0FKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTZDO0FBQUEsZUFkL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxhQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsV0ExSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRKQTtBQUFBLE1BR0N1SCxzQkFBc0IsSUFBSSxLQUN6Qix1QkFBQyxTQUFJLFdBQVUsc0NBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHFDQUFvQywrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1ozRztBQUFBQSxrQ0FDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLFNBQVMsTUFBTUMsd0JBQXdCLElBQUk7QUFBQSxjQUMzQyxXQUFVO0FBQUEsY0FDVixPQUFNO0FBQUEsY0FFTjtBQUFBLHVDQUFDLHVCQUFvQixXQUFVLFVBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUEsZ0JBRW5DbUIsY0FBY21HLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRVIsUUFBUWhILG9CQUFvQixHQUNwRDZFO0FBQUFBO0FBQUFBO0FBQUFBLFlBVFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUVEM0Usb0JBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxTQUFTLE1BQU1DLG9CQUFvQixJQUFJO0FBQUEsY0FDdkMsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBRU47QUFBQSx1Q0FBQyxnQkFBYSxXQUFVLFVBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThCO0FBQUEsZ0JBRTVCbUIsVUFBVWlHLEtBQUssQ0FBQ0UsTUFBTUEsRUFBRVQsUUFBUTlHLGdCQUFnQixHQUM1Q3VFO0FBQUFBO0FBQUFBO0FBQUFBLFlBVFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUVEckUsWUFBWUUsVUFDWDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLFNBQVMsTUFBTTtBQUNiRCw0QkFBWSxJQUFJO0FBQ2hCRSwwQkFBVSxJQUFJO0FBQUEsY0FDaEI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUVOO0FBQUEsdUNBQUMsb0JBQWlCLFdBQVUsVUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQSxnQkFDakNzQixrQkFBa0J6QixRQUFRO0FBQUEsZ0JBQUU7QUFBQSxnQkFBSXlCLGtCQUFrQnZCLE1BQU07QUFBQTtBQUFBO0FBQUEsWUFWM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUVESSxjQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsU0FBUyxNQUFNO0FBQ2JDLDhCQUFjLEVBQUU7QUFDaEJFLCtCQUFlLEVBQUU7QUFBQSxjQUNuQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBRU47QUFBQSx1Q0FBQyxrQkFBZSxXQUFVLFVBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsZ0JBQUc7QUFBQSxnQkFBRUg7QUFBQUEsZ0JBQVc7QUFBQTtBQUFBO0FBQUEsWUFUbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxVQUVEWixrQkFBa0IsU0FBUyxDQUFDTSxZQUFZLENBQUNFLFVBQ3hDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsU0FBUyxNQUFNO0FBQ2JQLGlDQUFpQixLQUFLO0FBQ3RCTSw0QkFBWSxJQUFJO0FBQ2hCRSwwQkFBVSxJQUFJO0FBQUEsY0FDaEI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUVOO0FBQUEsdUNBQUMsdUJBQW9CLFdBQVUsVUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUM7QUFBQSxnQkFDcENUO0FBQUFBO0FBQUFBO0FBQUFBLFlBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUE7QUFBQSxhQXJFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUVBO0FBQUEsV0EzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRFQSxLQTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEVBO0FBQUEsU0F4UUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBRQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsNkJBQUMsUUFBSyxXQUFVLDBEQUNkLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSw2RUFBNEUsa0JBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLE9BQUUsV0FBVSx5QkFBd0IsK0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFDcEQsdUJBQUMsT0FBRSxXQUFVLG9DQUNWa0IscUJBQVc4RSxVQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFJQSx1QkFBQyxRQUFLLFdBQVUsMERBQ2QsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtFQUE4RSxrQkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxVQUMvQyx1QkFBQyxPQUFFLFdBQVUscUNBQ1YxRixzQkFBWUUsU0FDWCxtQ0FDR3VCO0FBQUFBLDhCQUFrQnpCLFFBQVE7QUFBQSxZQUMzQix1QkFBQyxVQUFLLFdBQVUsUUFBTyxpQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQSxZQUN2QnlCLGtCQUFrQnZCLE1BQU07QUFBQSxlQUgzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBLElBRUEsY0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0NBO0FBQUEsSUFHQSx1QkFBQyxRQUFLLFdBQVUsd0JBQ2J5Rix3QkFBY0QsU0FBUyxLQUFLLENBQUNoRixZQUM1QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUTtBQUFBLFFBQ1IsTUFBTWlGO0FBQUFBLFFBQ047QUFBQSxRQUNBLGlCQUFnQjtBQUFBLFFBQ2hCLGtCQUFpQjtBQUFBO0FBQUEsTUFMbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSzZDLElBRzdDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsU0FBU0EsYUFBYUQsVUFBVTtBQUFBLFFBQ2hDLE1BQUs7QUFBQTtBQUFBLE1BSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR2tDLEtBYnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQS9XRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ1hBO0FBRUo7QUFBRWpHLElBdG5CSUQsb0JBQWtCO0FBQUEsVUFrQ0VULFdBQVc7QUFBQTtBQUFBdUksS0FsQy9COUg7QUF3bkJOLGVBQWVBO0FBQW1CLElBQUE4SDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydERpYWxvZyIsIkNpcmN1bGFyTG9hZGVyIiwiU2VhcmNoT3V0bGluZWQiLCJGaWx0ZXJPdXRsaW5lZCIsIlJlbG9hZE91dGxpbmVkIiwiQ2FsZW5kYXJPdXRsaW5lZCIsIlVzZXJPdXRsaW5lZCIsIkVudmlyb25tZW50T3V0bGluZWQiLCJDbG9zZUNpcmNsZU91dGxpbmVkIiwiQ2hlY2tDaXJjbGVPdXRsaW5lZCIsIkNsb2NrQ2lyY2xlT3V0bGluZWQiLCJEb3dubG9hZE91dGxpbmVkIiwiRXllT3V0bGluZWQiLCJNb2RhbCIsImFwaSIsIlNlbGVjdCIsIklucHV0IiwiU3BhY2UiLCJUYWciLCJCdXR0b24iLCJCYWRnZSIsIlRvb2x0aXAiLCJDYXJkIiwiUm93IiwiQ29sIiwiZmlsdGVyT3B0aW9uIiwiT3B0aW9uIiwidXNlRGVib3VuY2UiLCJ2YWx1ZSIsImRlbGF5IiwiX3MiLCJkZWJvdW5jZWRWYWx1ZSIsInNldERlYm91bmNlZFZhbHVlIiwiaGFuZGxlciIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJDdXN0b21lckFyZWFSZXBvcnQiLCJfczIiLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsInNlbGVjdGVkQ3VzdG9tZXJBcmVhIiwic2V0U2VsZWN0ZWRDdXN0b21lckFyZWEiLCJzZWxlY3RlZEN1c3RvbWVyIiwic2V0U2VsZWN0ZWRDdXN0b21lciIsImZyb21EYXRlIiwic2V0RnJvbURhdGUiLCJ0b0RhdGUiLCJzZXRUb0RhdGUiLCJzaG93Q3VzdG9tRGF0ZSIsInNldFNob3dDdXN0b21EYXRlIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJzZWFyY2hJbnB1dCIsInNldFNlYXJjaElucHV0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicmVwb3J0RGF0YSIsInNldFJlcG9ydERhdGEiLCJ0YWJsZURhdGEiLCJzZXRUYWJsZURhdGEiLCJjdXN0b21lckFyZWFzIiwic2V0Q3VzdG9tZXJBcmVhcyIsImN1c3RvbWVycyIsInNldEN1c3RvbWVycyIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJmb3JtYXREYXRlRGlzcGxheSIsImRhdGVTdHJpbmciLCJkYXRlIiwiRGF0ZSIsImRheSIsIlN0cmluZyIsImdldERhdGUiLCJwYWRTdGFydCIsIm1vbnRoIiwiZ2V0TW9udGgiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJkZWJvdW5jZWRTZWFyY2giLCJncm91cE9wdGlvbnMiLCJsYWJlbCIsImljb24iLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwiZmV0Y2hEcm9wZG93bkRhdGEiLCJhcmVhc1Jlc3BvbnNlIiwiY3VzdG9tZXJzUmVzcG9uc2UiLCJQcm9taXNlIiwiYWxsIiwiZ2V0IiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImhhbmRsZVNlbGVjdEZpbHRlciIsInRvZGF5IiwiZm9ybWF0RGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImZvcm1hdHRlZCIsInllc3RlcmRheSIsInNldERhdGUiLCJzdGFydCIsImVuZCIsInRyYW5zZm9ybURhdGFGb3JUYWJsZSIsIm1hcCIsImN1c3RvbWVyIiwiaW5kZXgiLCJpZCIsImN1c3RvbWVyX2lkIiwibmFtZSIsImZ1bGxfbmFtZSIsImVtYWlsIiwicGhvbmVfbnVtYmVyIiwicGhvbmUiLCJhcmVhX25hbWUiLCJjdXN0b21lcl9hcmVhIiwiYXJlYV9jb2RlIiwiYXJlYV90eXBlIiwicGluY29kZSIsImVucm9sbG1lbnRfZGF0ZSIsImNyZWF0ZWRfYXQiLCJjcmVhdGVkQXQiLCJ0b0xvY2FsZVN0cmluZyIsIl9vcmlnaW5hbCIsImZldGNoUmVwb3J0IiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwiYXBwZW5kIiwicmVzcG9uc2UiLCJ0b1N0cmluZyIsInRyYW5zZm9ybWVkRGF0YSIsImxlbmd0aCIsImZpbHRlcmVkRGF0YSIsInVzZU1lbW8iLCJzZWFyY2hMb3dlciIsInRvTG93ZXJDYXNlIiwiZmlsdGVyIiwiaXRlbSIsIk9iamVjdCIsInZhbHVlcyIsInNvbWUiLCJpbmNsdWRlcyIsImhhbmRsZUFwcGx5RmlsdGVycyIsImhhbmRsZVJlc2V0RmlsdGVycyIsImdldEFjdGl2ZUZpbHRlcnNDb3VudCIsImNvdW50IiwiaW5wdXQiLCJvcHRpb24iLCJhcmVhIiwiX2lkIiwiZGlzcGxheU5hbWUiLCJkaXNwbGF5UGhvbmUiLCJ0cmltIiwidGltZSIsImUiLCJ0YXJnZXQiLCJmaW5kIiwiYSIsImMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDdXN0b21lckFyZWFSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcblxyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcblxyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5cclxuaW1wb3J0IHtcclxuICBTZWFyY2hPdXRsaW5lZCxcclxuICBGaWx0ZXJPdXRsaW5lZCxcclxuICBSZWxvYWRPdXRsaW5lZCxcclxuICBDYWxlbmRhck91dGxpbmVkLFxyXG4gIFVzZXJPdXRsaW5lZCxcclxuICBFbnZpcm9ubWVudE91dGxpbmVkLFxyXG4gIENsb3NlQ2lyY2xlT3V0bGluZWQsXHJcbiAgQ2hlY2tDaXJjbGVPdXRsaW5lZCxcclxuICBDbG9ja0NpcmNsZU91dGxpbmVkLFxyXG4gIERvd25sb2FkT3V0bGluZWQsXHJcbiAgRXllT3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcblxyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcblxyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCB7XHJcbiAgU2VsZWN0LFxyXG4gIElucHV0LFxyXG4gIFNwYWNlLFxyXG4gIFRhZyxcclxuICBCdXR0b24sXHJcbiAgQmFkZ2UsXHJcbiAgVG9vbHRpcCxcclxuICBDYXJkLFxyXG4gIFJvdyxcclxuICBDb2wsXHJcbn0gZnJvbSBcImFudGRcIjtcclxuXHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcblxyXG5jb25zdCB7IE9wdGlvbiB9ID0gU2VsZWN0O1xyXG5cclxuLy8gY29uc3QgQ3VzdG9tZXJBcmVhUmVwb3J0ID0gKCkgPT4ge1xyXG4vLyAgIC8vIFN0YXRlIGZvciBmaWx0ZXJzXHJcbi8vICAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoJ0FsbCcpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVyQXJlYSwgc2V0U2VsZWN0ZWRDdXN0b21lckFyZWFdID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkQ3VzdG9tZXIsIHNldFNlbGVjdGVkQ3VzdG9tZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW3Nob3dDdXN0b21EYXRlLCBzZXRTaG93Q3VzdG9tRGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4vLyAgIC8vIFN0YXRlIGZvciBkYXRhXHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbcmVwb3J0RGF0YSwgc2V0UmVwb3J0RGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW3RhYmxlRGF0YSwgc2V0VGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbY3VzdG9tZXJBcmVhcywgc2V0Q3VzdG9tZXJBcmVhc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2N1c3RvbWVycywgc2V0Q3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZSgnJyk7XHJcbi8vICAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuLy8gICAgIG1lc3NhZ2U6ICcnLFxyXG4vLyAgICAgdHlwZTogJ2luZm8nLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICAvLyBGaWx0ZXIgb3B0aW9uc1xyXG4vLyAgIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuLy8gICAgIHsgdmFsdWU6IFwiQWxsXCIsIGxhYmVsOiBcIkFsbFwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIlRvZGF5XCIsIGxhYmVsOiBcIlRvZGF5XCIgfSxcclxuLy8gICAgIHsgdmFsdWU6IFwiWWVzdGVyZGF5XCIsIGxhYmVsOiBcIlllc3RlcmRheVwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIk9uZVdlZWtcIiwgbGFiZWw6IFwiT25lIFdlZWtcIiB9LFxyXG4vLyAgICAgeyB2YWx1ZTogXCJUaGlzTW9udGhcIiwgbGFiZWw6IFwiVGhpcyBNb250aFwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIkxhc3RNb250aFwiLCBsYWJlbDogXCJMYXN0IE1vbnRoXCIgfSxcclxuLy8gICAgIHsgdmFsdWU6IFwiVGhpc1llYXJcIiwgbGFiZWw6IFwiVGhpcyBZZWFyXCIgfSxcclxuLy8gICAgIHsgdmFsdWU6IFwiQ3VzdG9tXCIsIGxhYmVsOiBcIkN1c3RvbVwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgLy8gQ29sdW1ucyBkZWZpbml0aW9uIG1hdGNoaW5nIHlvdXIgRGF0YVRhYmxlIGZvcm1hdFxyXG4vLyAgIGNvbnN0IGNvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImN1c3RvbWVyX2lkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJRFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImFyZWFfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgQXJlYVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhcmVhX2NvZGVcIiwgaGVhZGVyOiBcIkFyZWEgQ29kZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhcmVhX3R5cGVcIiwgaGVhZGVyOiBcIkFyZWEgVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJwaW5jb2RlXCIsIGhlYWRlcjogXCJQaW5jb2RlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICAvLyBGZXRjaCBjdXN0b21lciBhcmVhcyBhbmQgY3VzdG9tZXJzIGZvciBkcm9wZG93bnNcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hEcm9wZG93bkRhdGEgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgY29uc3QgW2FyZWFzUmVzcG9uc2UsIGN1c3RvbWVyc1Jlc3BvbnNlXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuLy8gICAgICAgICAgIGFwaS5nZXQoJy92MS9hZG1pbi9jdXN0b21lci1hcmVhJyksXHJcbi8vICAgICAgICAgICBhcGkuZ2V0KCcvdXNlci9nZXQtdXNlcicpXHJcbi8vICAgICAgICAgXSk7XHJcblxyXG4vLyAgICAgICAgIHNldEN1c3RvbWVyQXJlYXMoYXJlYXNSZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdKTtcclxuLy8gICAgICAgICBzZXRDdXN0b21lcnMoY3VzdG9tZXJzUmVzcG9uc2UuZGF0YSB8fCBbXSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgZHJvcGRvd24gZGF0YTonLCBlcnJvcik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaERyb3Bkb3duRGF0YSgpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgLy8gSGFuZGxlIGRhdGUgZmlsdGVyIHNlbGVjdGlvblxyXG4vLyAgIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRHcm91cCh2YWx1ZSk7XHJcbi8vICAgICBzZXRTaG93Q3VzdG9tRGF0ZShmYWxzZSk7XHJcblxyXG4vLyAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tQ0EnKTtcclxuXHJcbi8vICAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4vLyAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgICAgc2V0RnJvbURhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgICAgc2V0VG9EYXRlKGZvcm1hdHRlZCk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuLy8gICAgICAgeWVzdGVyZGF5LnNldERhdGUoeWVzdGVyZGF5LmdldERhdGUoKSAtIDEpO1xyXG4vLyAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHllc3RlcmRheSk7XHJcbi8vICAgICAgIHNldEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbi8vICAgICAgIHNldFRvRGF0ZShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJPbmVXZWVrXCIpIHtcclxuLy8gICAgICAgY29uc3QgZnJvbURhdGUgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgICAgICBmcm9tRGF0ZS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIDcpO1xyXG4vLyAgICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKGZyb21EYXRlKSk7XHJcbi8vICAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKHRvZGF5KSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuLy8gICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdE1vbnRoXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpIC0gMSwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDApO1xyXG4vLyAgICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbi8vICAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbi8vICAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkFsbFwiKSB7XHJcbi8vICAgICAgIHNldEZyb21EYXRlKG51bGwpO1xyXG4vLyAgICAgICBzZXRUb0RhdGUobnVsbCk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbi8vICAgICAgIHNldFNob3dDdXN0b21EYXRlKHRydWUpO1xyXG4vLyAgICAgICBzZXRGcm9tRGF0ZShudWxsKTtcclxuLy8gICAgICAgc2V0VG9EYXRlKG51bGwpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIEhhbmRsZSBzZWFyY2hcclxuLy8gICBjb25zdCBHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuLy8gICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4vLyAgICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gVHJhbnNmb3JtIGRhdGEgZm9yIERhdGFUYWJsZVxyXG4vLyAgIGNvbnN0IHRyYW5zZm9ybURhdGFGb3JUYWJsZSA9IChkYXRhKSA9PiB7XHJcbi8vICAgICByZXR1cm4gZGF0YS5tYXAoKGN1c3RvbWVyLCBpbmRleCkgPT4gKHtcclxuLy8gICAgICAgaWQ6IGluZGV4ICsgMSxcclxuLy8gICAgICAgY3VzdG9tZXJfaWQ6IGN1c3RvbWVyLmN1c3RvbWVyX2lkIHx8IGN1c3RvbWVyLmlkIHx8ICdOL0EnLFxyXG4vLyAgICAgICBuYW1lOiBjdXN0b21lci5mdWxsX25hbWUgfHwgY3VzdG9tZXIubmFtZSB8fCAnTi9BJyxcclxuLy8gICAgICAgZW1haWw6IGN1c3RvbWVyLmVtYWlsIHx8ICdOL0EnLFxyXG4vLyAgICAgICBwaG9uZV9udW1iZXI6IGN1c3RvbWVyLnBob25lX251bWJlciB8fCBjdXN0b21lci5waG9uZSB8fCAnTi9BJyxcclxuLy8gICAgICAgYXJlYV9uYW1lOiBjdXN0b21lci5jdXN0b21lcl9hcmVhPy5hcmVhX25hbWUgfHwgJ04vQScsXHJcbi8vICAgICAgIGFyZWFfY29kZTogY3VzdG9tZXIuY3VzdG9tZXJfYXJlYT8uYXJlYV9jb2RlIHx8ICdOL0EnLFxyXG4vLyAgICAgICBhcmVhX3R5cGU6IGN1c3RvbWVyLmN1c3RvbWVyX2FyZWE/LmFyZWFfdHlwZSB8fCAnTi9BJyxcclxuLy8gICAgICAgcGluY29kZTogY3VzdG9tZXIuY3VzdG9tZXJfYXJlYT8ucGluY29kZSB8fCAnTi9BJyxcclxuLy8gICAgICAgZW5yb2xsbWVudF9kYXRlOiBjdXN0b21lci5lbnJvbGxtZW50X2RhdGVcclxuLy8gICAgICAgICA/IG5ldyBEYXRlKGN1c3RvbWVyLmVucm9sbG1lbnRfZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKClcclxuLy8gICAgICAgICA6ICdOL0EnLFxyXG4vLyAgICAgICBjcmVhdGVkX2F0OiBjdXN0b21lci5jcmVhdGVkQXRcclxuLy8gICAgICAgICA/IG5ldyBEYXRlKGN1c3RvbWVyLmNyZWF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoKVxyXG4vLyAgICAgICAgIDogJ04vQScsXHJcbi8vICAgICAgIHN0YXR1czogY3VzdG9tZXIuc3RhdHVzIHx8IChjdXN0b21lci5pc0FjdGl2ZSA/ICdBY3RpdmUnIDogJ0luYWN0aXZlJyksXHJcbi8vICAgICAgIC8vIEtlZXAgb3JpZ2luYWwgZm9yIHJlZmVyZW5jZVxyXG4vLyAgICAgICBfb3JpZ2luYWw6IGN1c3RvbWVyXHJcbi8vICAgICB9KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gRmV0Y2ggcmVwb3J0IGRhdGFcclxuLy8gICBjb25zdCBmZXRjaFJlcG9ydCA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcclxuXHJcbi8vICAgICAgIGlmIChzZWxlY3RlZEN1c3RvbWVyQXJlYSkge1xyXG4vLyAgICAgICAgIHBhcmFtcy5hcHBlbmQoJ2N1c3RvbWVyQXJlYUlkJywgc2VsZWN0ZWRDdXN0b21lckFyZWEpO1xyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBpZiAoc2VsZWN0ZWRDdXN0b21lcikge1xyXG4vLyAgICAgICAgIHBhcmFtcy5hcHBlbmQoJ2N1c3RvbWVyJywgc2VsZWN0ZWRDdXN0b21lcik7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIGlmIChmcm9tRGF0ZSAmJiBmcm9tRGF0ZSAhPT0gJ0ludmFsaWQgRGF0ZScpIHtcclxuLy8gICAgICAgICBwYXJhbXMuYXBwZW5kKCdmcm9tX2RhdGUnLCBmcm9tRGF0ZSk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIGlmICh0b0RhdGUgJiYgdG9EYXRlICE9PSAnSW52YWxpZCBEYXRlJykge1xyXG4vLyAgICAgICAgIHBhcmFtcy5hcHBlbmQoJ3RvX2RhdGUnLCB0b0RhdGUpO1xyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9jdXN0b21lci1hcmVhL3JlcG9ydD8ke3BhcmFtcy50b1N0cmluZygpfWApO1xyXG5cclxuLy8gICAgICAgY29uc3QgdHJhbnNmb3JtZWREYXRhID0gdHJhbnNmb3JtRGF0YUZvclRhYmxlKHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICBzZXRSZXBvcnREYXRhKHRyYW5zZm9ybWVkRGF0YSk7XHJcbi8vICAgICAgIHNldFRhYmxlRGF0YSh0cmFuc2Zvcm1lZERhdGEpO1xyXG5cclxuLy8gICAgICAgaWYgKHRyYW5zZm9ybWVkRGF0YS5sZW5ndGggPT09IDApIHtcclxuLy8gICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbi8vICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4vLyAgICAgICAgICAgbWVzc2FnZTogJ05vIGRhdGEgZm91bmQgZm9yIHRoZSBzZWxlY3RlZCBmaWx0ZXJzJyxcclxuLy8gICAgICAgICAgIHR5cGU6ICdpbmZvJyxcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgcmVwb3J0OicsIGVycm9yKTtcclxuLy8gICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4vLyAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbi8vICAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBmZXRjaCByZXBvcnQgZGF0YScsXHJcbi8vICAgICAgICAgdHlwZTogJ2Vycm9yJyxcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIHNldFJlcG9ydERhdGEoW10pO1xyXG4vLyAgICAgICBzZXRUYWJsZURhdGEoW10pO1xyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBMb2FkIHJlcG9ydCBvbiBmaWx0ZXIgY2hhbmdlXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGlmICghc2hvd0N1c3RvbURhdGUgfHwgKGZyb21EYXRlICYmIHRvRGF0ZSkpIHtcclxuLy8gICAgICAgZmV0Y2hSZXBvcnQoKTtcclxuLy8gICAgIH1cclxuLy8gICB9LCBbc2VsZWN0ZWRDdXN0b21lckFyZWEsIHNlbGVjdGVkQ3VzdG9tZXIsIGZyb21EYXRlLCB0b0RhdGUsIHNob3dDdXN0b21EYXRlXSk7XHJcblxyXG4vLyAgIC8vIEhhbmRsZSBhcHBseSBmaWx0ZXJzXHJcbi8vICAgY29uc3QgaGFuZGxlQXBwbHlGaWx0ZXJzID0gKCkgPT4ge1xyXG4vLyAgICAgZmV0Y2hSZXBvcnQoKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBIYW5kbGUgcmVzZXQgZmlsdGVyc1xyXG4vLyAgIGNvbnN0IGhhbmRsZVJlc2V0RmlsdGVycyA9ICgpID0+IHtcclxuLy8gICAgIHNldFNlbGVjdGVkQ3VzdG9tZXJBcmVhKG51bGwpO1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcihudWxsKTtcclxuLy8gICAgIHNldFNlbGVjdGVkR3JvdXAoJ0FsbCcpO1xyXG4vLyAgICAgc2V0RnJvbURhdGUobnVsbCk7XHJcbi8vICAgICBzZXRUb0RhdGUobnVsbCk7XHJcbi8vICAgICBzZXRTaG93Q3VzdG9tRGF0ZShmYWxzZSk7XHJcbi8vICAgICBzZXRTZWFyY2hUZXh0KCcnKTtcclxuLy8gICAgIHNldEFsZXJ0Q29uZmlnKHsgdmlzaWJpbGl0eTogZmFsc2UsIG1lc3NhZ2U6ICcnLCB0eXBlOiAnaW5mbycgfSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDw+XHJcbi8vICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcblxyXG4vLyAgICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbi8vICAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbi8vICAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuLy8gICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuLy8gICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuLy8gICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbi8vICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgIC8+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03IG92ZXJmbG93LXgtYXV0b1wiPlxyXG4vLyAgICAgICAgICAgICB7LyogSGVhZGVyICovfVxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOCBtaW4tdy1tYXhcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+Q3VzdG9tZXIgQXJlYSBSZXBvcnQ8L2gxPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBGaWx0ZXJzIFNlY3Rpb24gKi99XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQtbGcgc2hhZG93LW1kIG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgIHsvKiBUaW1lIEZpbHRlciAqL31cclxuLy8gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBBcmVhXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ3VzdG9tZXJBcmVhIHx8ICcnfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRDdXN0b21lckFyZWEoZS50YXJnZXQudmFsdWUgfHwgbnVsbCl9XHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsIEFyZWFzPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyQXJlYXMubWFwKGFyZWEgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2FyZWEuX2lkfSB2YWx1ZT17YXJlYS5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7YXJlYS5hcmVhX25hbWV9ICh7YXJlYS5waW5jb2RlfSlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgRGF0ZSBSYW5nZVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VsZWN0RmlsdGVyKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKG9wdGlvbiA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17b3B0aW9uLnZhbHVlfSB2YWx1ZT17b3B0aW9uLnZhbHVlfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHsvKiBDdXN0b20gRGF0ZSBSYW5nZSAqL31cclxuLy8gICAgICAgICAgICAgICAgIHtzaG93Q3VzdG9tRGF0ZSAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMSBtZDpjb2wtc3Bhbi0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBDdXN0b20gRGF0ZSBSYW5nZVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmcm9tRGF0ZSB8fCAnJ31cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dG9EYXRlIHx8ICcnfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIEFyZWEgRmlsdGVyICovfVxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciBGaWx0ZXIgKi99XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBDdXN0b21lclxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEN1c3RvbWVyIHx8ICcnfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRDdXN0b21lcihlLnRhcmdldC52YWx1ZSB8fCBudWxsKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGwgQ3VzdG9tZXJzPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVycy5tYXAoY3VzdG9tZXIgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2N1c3RvbWVyLl9pZH0gdmFsdWU9e2N1c3RvbWVyLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lci5mdWxsX25hbWUgfHwgY3VzdG9tZXIubmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zIG10LTRcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQXBwbHlGaWx0ZXJzfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTYgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIEFwcGx5IEZpbHRlcnNcclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZXNldEZpbHRlcnN9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAwIHRleHQtd2hpdGUgcHgtNiBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyYXktNjAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgUmVzZXRcclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBTdW1tYXJ5IENhcmRzICovfVxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgc2hhZG93LW1kXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5Ub3RhbCBDdXN0b21lcnM8L3A+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGRcIj57cmVwb3J0RGF0YS5sZW5ndGh9PC9wPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgc2hhZG93LW1kXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5BY3RpdmUgRmlsdGVyczwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDdXN0b21lckFyZWEgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTEgYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTgwMCB0ZXh0LXhzIHJvdW5kZWRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIEFyZWE6IHtjdXN0b21lckFyZWFzLmZpbmQoYSA9PiBhLl9pZCA9PT0gc2VsZWN0ZWRDdXN0b21lckFyZWEpPy5hcmVhX25hbWUgfHwgJ1Vua25vd24nfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgICAge3NlbGVjdGVkQ3VzdG9tZXIgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTEgYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwIHRleHQteHMgcm91bmRlZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXI6IHtjdXN0b21lcnMuZmluZChjID0+IGMuX2lkID09PSBzZWxlY3RlZEN1c3RvbWVyKT8uZnVsbF9uYW1lIHx8ICdVbmtub3duJ31cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgIHtmcm9tRGF0ZSAmJiB0b0RhdGUgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTEgYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS04MDAgdGV4dC14cyByb3VuZGVkXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7ZnJvbURhdGV9IHRvIHt0b0RhdGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICB7IWZyb21EYXRlICYmICF0b0RhdGUgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTEgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCB0ZXh0LXhzIHJvdW5kZWRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEdyb3VwfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgc2hhZG93LW1kXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5EYXRlIFJhbmdlPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7ZnJvbURhdGUgJiYgdG9EYXRlID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGAke25ldyBEYXRlKGZyb21EYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKX0gLSAke25ldyBEYXRlKHRvRGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9YFxyXG4vLyAgICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICdBbGwgVGltZSdcclxuLy8gICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNCByb3VuZGVkLWxnIHNoYWRvdy1tZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+U3RhdHVzPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7cmVwb3J0RGF0YS5maWx0ZXIoZCA9PiBkLnN0YXR1cyA9PT0gJ0FjdGl2ZScpLmxlbmd0aH0gQWN0aXZlXHJcbi8vICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcmVkLTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7cmVwb3J0RGF0YS5maWx0ZXIoZCA9PiBkLnN0YXR1cyA9PT0gJ0luYWN0aXZlJykubGVuZ3RofSBJbmFjdGl2ZVxyXG4vLyAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBEYXRhIFRhYmxlICovfVxyXG4vLyAgICAgICAgICAgICB7dGFibGVEYXRhPy5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbi8vICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24odGFibGVEYXRhLCBzZWFyY2hUZXh0KX1cclxuLy8gICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDdXN0b21lciBBcmVhIFJlcG9ydFwiXHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ3VzdG9tZXIgQXJlYSBSZXBvcnQuY3N2XCJcclxuLy8gICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4vLyAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbi8vICAgICAgICAgICAgICAgICBmYWlsdXJlPXt0YWJsZURhdGEubGVuZ3RoIDw9IDB9XHJcbi8vICAgICAgICAgICAgICAgICBkYXRhPVwiQ3VzdG9tZXIgQXJlYSBSZXBvcnQgRGF0YVwiXHJcbi8vICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvPlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG5jb25zdCB1c2VEZWJvdW5jZSA9ICh2YWx1ZSwgZGVsYXkpID0+IHtcclxuICBjb25zdCBbZGVib3VuY2VkVmFsdWUsIHNldERlYm91bmNlZFZhbHVlXSA9IHVzZVN0YXRlKHZhbHVlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGhhbmRsZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0RGVib3VuY2VkVmFsdWUodmFsdWUpO1xyXG4gICAgfSwgZGVsYXkpO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNsZWFyVGltZW91dChoYW5kbGVyKTtcclxuICAgIH07XHJcbiAgfSwgW3ZhbHVlLCBkZWxheV0pO1xyXG5cclxuICByZXR1cm4gZGVib3VuY2VkVmFsdWU7XHJcbn07XHJcblxyXG5jb25zdCBDdXN0b21lckFyZWFSZXBvcnQgPSAoKSA9PiB7XHJcbiAgLy8gU3RhdGUgZm9yIGZpbHRlcnNcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cCwgc2V0U2VsZWN0ZWRHcm91cF0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRDdXN0b21lckFyZWEsIHNldFNlbGVjdGVkQ3VzdG9tZXJBcmVhXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVyLCBzZXRTZWxlY3RlZEN1c3RvbWVyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtmcm9tRGF0ZSwgc2V0RnJvbURhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RvRGF0ZSwgc2V0VG9EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93Q3VzdG9tRGF0ZSwgc2V0U2hvd0N1c3RvbURhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWFyY2hJbnB1dCwgc2V0U2VhcmNoSW5wdXRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIC8vIFN0YXRlIGZvciBkYXRhXHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVwb3J0RGF0YSwgc2V0UmVwb3J0RGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RhYmxlRGF0YSwgc2V0VGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY3VzdG9tZXJBcmVhcywgc2V0Q3VzdG9tZXJBcmVhc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2N1c3RvbWVycywgc2V0Q3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICAvLyBIZWxwZXIgZnVuY3Rpb24gdG8gZm9ybWF0IGRhdGUgYXMgZGQvbW0veXl5eVxyXG4gIGNvbnN0IGZvcm1hdERhdGVEaXNwbGF5ID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGlmICghZGF0ZVN0cmluZykgcmV0dXJuICcnO1xyXG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgY29uc3QgZGF5ID0gU3RyaW5nKGRhdGUuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgY29uc3QgbW9udGggPSBTdHJpbmcoZGF0ZS5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICAgIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgICByZXR1cm4gYCR7ZGF5fS8ke21vbnRofS8ke3llYXJ9YDtcclxuICB9O1xyXG5cclxuICAvLyBEZWJvdW5jZSBzZWFyY2ggaW5wdXRcclxuICBjb25zdCBkZWJvdW5jZWRTZWFyY2ggPSB1c2VEZWJvdW5jZShzZWFyY2hJbnB1dCwgMzAwKTtcclxuXHJcbiAgLy8gVXBkYXRlIHNlYXJjaCB0ZXh0IHdoZW4gZGVib3VuY2VkIHZhbHVlIGNoYW5nZXNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0U2VhcmNoVGV4dChkZWJvdW5jZWRTZWFyY2gpO1xyXG4gIH0sIFtkZWJvdW5jZWRTZWFyY2hdKTtcclxuXHJcbiAgLy8gRmlsdGVyIG9wdGlvbnMgd2l0aCBpY29uc1xyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIHsgdmFsdWU6IFwiQWxsXCIsIGxhYmVsOiBcIkFsbFwiLCBpY29uOiA8Q2xvY2tDaXJjbGVPdXRsaW5lZCAvPiB9LFxyXG4gICAgeyB2YWx1ZTogXCJUb2RheVwiLCBsYWJlbDogXCJUb2RheVwiLCBpY29uOiA8Q2xvY2tDaXJjbGVPdXRsaW5lZCAvPiB9LFxyXG4gICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIsIGljb246IDxDbG9ja0NpcmNsZU91dGxpbmVkIC8+IH0sXHJcbiAgICB7IHZhbHVlOiBcIk9uZVdlZWtcIiwgbGFiZWw6IFwiT25lIFdlZWtcIiwgaWNvbjogPENsb2NrQ2lyY2xlT3V0bGluZWQgLz4gfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiwgaWNvbjogPENsb2NrQ2lyY2xlT3V0bGluZWQgLz4gfSxcclxuICAgIHsgdmFsdWU6IFwiTGFzdE1vbnRoXCIsIGxhYmVsOiBcIkxhc3QgTW9udGhcIiwgaWNvbjogPENsb2NrQ2lyY2xlT3V0bGluZWQgLz4gfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc1llYXJcIiwgbGFiZWw6IFwiVGhpcyBZZWFyXCIsIGljb246IDxDbG9ja0NpcmNsZU91dGxpbmVkIC8+IH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiwgaWNvbjogPENhbGVuZGFyT3V0bGluZWQgLz4gfSxcclxuICBdO1xyXG5cclxuICAvLyBDb2x1bW5zIGRlZmluaXRpb25cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9pZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSURcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJhcmVhX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIEFyZWFcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXJlYV9jb2RlXCIsIGhlYWRlcjogXCJBcmVhIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXJlYV90eXBlXCIsIGhlYWRlcjogXCJBcmVhIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGluY29kZVwiLCBoZWFkZXI6IFwiUGluY29kZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgLy8gRmV0Y2ggZHJvcGRvd24gZGF0YVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaERyb3Bkb3duRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBbYXJlYXNSZXNwb25zZSwgY3VzdG9tZXJzUmVzcG9uc2VdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgYXBpLmdldChcIi92MS9hZG1pbi9jdXN0b21lci1hcmVhXCIpLFxyXG4gICAgICAgICAgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpLFxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBzZXRDdXN0b21lckFyZWFzKGFyZWFzUmVzcG9uc2UuZGF0YT8uZGF0YSB8fCBbXSk7XHJcbiAgICAgICAgc2V0Q3VzdG9tZXJzKGN1c3RvbWVyc1Jlc3BvbnNlLmRhdGEgfHwgW10pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkcm9wZG93biBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaERyb3Bkb3duRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gSGFuZGxlIGRhdGUgZmlsdGVyIHNlbGVjdGlvblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cCh2YWx1ZSk7XHJcbiAgICBzZXRTaG93Q3VzdG9tRGF0ZShmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0dGVkKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuICAgICAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4gICAgICB5ZXN0ZXJkYXkuc2V0RGF0ZSh5ZXN0ZXJkYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUoeWVzdGVyZGF5KTtcclxuICAgICAgc2V0RnJvbURhdGUoZm9ybWF0dGVkKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIk9uZVdlZWtcIikge1xyXG4gICAgICBjb25zdCBmcm9tRGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgIGZyb21EYXRlLnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gNyk7XHJcbiAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoZnJvbURhdGUpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUodG9kYXkpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbiAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAwLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMTEsIDMxKTtcclxuICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQWxsXCIpIHtcclxuICAgICAgc2V0RnJvbURhdGUobnVsbCk7XHJcbiAgICAgIHNldFRvRGF0ZShudWxsKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuICAgICAgc2V0U2hvd0N1c3RvbURhdGUodHJ1ZSk7XHJcbiAgICAgIHNldEZyb21EYXRlKG51bGwpO1xyXG4gICAgICBzZXRUb0RhdGUobnVsbCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gVHJhbnNmb3JtIGRhdGEgZm9yIERhdGFUYWJsZVxyXG4gIGNvbnN0IHRyYW5zZm9ybURhdGFGb3JUYWJsZSA9IChkYXRhKSA9PiB7XHJcbiAgICByZXR1cm4gZGF0YS5tYXAoKGN1c3RvbWVyLCBpbmRleCkgPT4gKHtcclxuICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgY3VzdG9tZXJfaWQ6IGN1c3RvbWVyLmN1c3RvbWVyX2lkIHx8IGN1c3RvbWVyLmlkIHx8IFwiTi9BXCIsXHJcbiAgICAgIG5hbWU6IGN1c3RvbWVyLmZ1bGxfbmFtZSB8fCBjdXN0b21lci5uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgIGVtYWlsOiBjdXN0b21lci5lbWFpbCB8fCBcIk4vQVwiLFxyXG4gICAgICBwaG9uZV9udW1iZXI6IGN1c3RvbWVyLnBob25lX251bWJlciB8fCBjdXN0b21lci5waG9uZSB8fCBcIk4vQVwiLFxyXG4gICAgICBhcmVhX25hbWU6IGN1c3RvbWVyLmN1c3RvbWVyX2FyZWE/LmFyZWFfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICBhcmVhX2NvZGU6IGN1c3RvbWVyLmN1c3RvbWVyX2FyZWE/LmFyZWFfY29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICBhcmVhX3R5cGU6IGN1c3RvbWVyLmN1c3RvbWVyX2FyZWE/LmFyZWFfdHlwZSB8fCBcIk4vQVwiLFxyXG4gICAgICBwaW5jb2RlOiBjdXN0b21lci5jdXN0b21lcl9hcmVhPy5waW5jb2RlIHx8IFwiTi9BXCIsXHJcbiAgICAgIGVucm9sbG1lbnRfZGF0ZTogY3VzdG9tZXIuZW5yb2xsbWVudF9kYXRlXHJcbiAgICAgICAgPyBuZXcgRGF0ZShjdXN0b21lci5lbnJvbGxtZW50X2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygpXHJcbiAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICBjcmVhdGVkX2F0OiBjdXN0b21lci5jcmVhdGVkQXRcclxuICAgICAgICA/IG5ldyBEYXRlKGN1c3RvbWVyLmNyZWF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoKVxyXG4gICAgICAgIDogXCJOL0FcIixcclxuXHJcbiAgICAgIF9vcmlnaW5hbDogY3VzdG9tZXIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gRmV0Y2ggcmVwb3J0IGRhdGFcclxuICBjb25zdCBmZXRjaFJlcG9ydCA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcclxuXHJcbiAgICAgIGlmIChzZWxlY3RlZEN1c3RvbWVyQXJlYSkge1xyXG4gICAgICAgIHBhcmFtcy5hcHBlbmQoXCJjdXN0b21lckFyZWFJZFwiLCBzZWxlY3RlZEN1c3RvbWVyQXJlYSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChzZWxlY3RlZEN1c3RvbWVyKSB7XHJcbiAgICAgICAgcGFyYW1zLmFwcGVuZChcImN1c3RvbWVyXCIsIHNlbGVjdGVkQ3VzdG9tZXIpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoZnJvbURhdGUgJiYgZnJvbURhdGUgIT09IFwiSW52YWxpZCBEYXRlXCIpIHtcclxuICAgICAgICBwYXJhbXMuYXBwZW5kKFwiZnJvbV9kYXRlXCIsIGZyb21EYXRlKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHRvRGF0ZSAmJiB0b0RhdGUgIT09IFwiSW52YWxpZCBEYXRlXCIpIHtcclxuICAgICAgICBwYXJhbXMuYXBwZW5kKFwidG9fZGF0ZVwiLCB0b0RhdGUpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC92MS9hZG1pbi9jdXN0b21lci1hcmVhL3JlcG9ydD8ke3BhcmFtcy50b1N0cmluZygpfWAsXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCB0cmFuc2Zvcm1lZERhdGEgPSB0cmFuc2Zvcm1EYXRhRm9yVGFibGUocmVzcG9uc2UuZGF0YT8uZGF0YSB8fCBbXSk7XHJcbiAgICAgIHNldFJlcG9ydERhdGEodHJhbnNmb3JtZWREYXRhKTtcclxuICAgICAgc2V0VGFibGVEYXRhKHRyYW5zZm9ybWVkRGF0YSk7XHJcblxyXG4gICAgICBpZiAodHJhbnNmb3JtZWREYXRhLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIk5vIGRhdGEgZm91bmQgZm9yIHRoZSBzZWxlY3RlZCBmaWx0ZXJzXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImluZm9cIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHJlcG9ydDpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBmZXRjaCByZXBvcnQgZGF0YVwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFJlcG9ydERhdGEoW10pO1xyXG4gICAgICBzZXRUYWJsZURhdGEoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBMb2FkIHJlcG9ydCBvbiBmaWx0ZXIgY2hhbmdlXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghc2hvd0N1c3RvbURhdGUgfHwgKGZyb21EYXRlICYmIHRvRGF0ZSkpIHtcclxuICAgICAgZmV0Y2hSZXBvcnQoKTtcclxuICAgIH1cclxuICB9LCBbXHJcbiAgICBzZWxlY3RlZEN1c3RvbWVyQXJlYSxcclxuICAgIHNlbGVjdGVkQ3VzdG9tZXIsXHJcbiAgICBmcm9tRGF0ZSxcclxuICAgIHRvRGF0ZSxcclxuICAgIHNob3dDdXN0b21EYXRlLFxyXG4gIF0pO1xyXG5cclxuICAvLyBGaWx0ZXIgZGF0YSBiYXNlZCBvbiBzZWFyY2hcclxuICBjb25zdCBmaWx0ZXJlZERhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGlmICghc2VhcmNoVGV4dCkgcmV0dXJuIHRhYmxlRGF0YTtcclxuXHJcbiAgICBjb25zdCBzZWFyY2hMb3dlciA9IHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKTtcclxuICAgIHJldHVybiB0YWJsZURhdGEuZmlsdGVyKChpdGVtKSA9PlxyXG4gICAgICBPYmplY3QudmFsdWVzKGl0ZW0pLnNvbWUoKHZhbHVlKSA9PlxyXG4gICAgICAgIFN0cmluZyh2YWx1ZSkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hMb3dlciksXHJcbiAgICAgICksXHJcbiAgICApO1xyXG4gIH0sIFt0YWJsZURhdGEsIHNlYXJjaFRleHRdKTtcclxuXHJcbiAgLy8gSGFuZGxlIGFwcGx5IGZpbHRlcnNcclxuICBjb25zdCBoYW5kbGVBcHBseUZpbHRlcnMgPSAoKSA9PiB7XHJcbiAgICBmZXRjaFJlcG9ydCgpO1xyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSByZXNldCBmaWx0ZXJzXHJcbiAgY29uc3QgaGFuZGxlUmVzZXRGaWx0ZXJzID0gKCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRDdXN0b21lckFyZWEobnVsbCk7XHJcbiAgICBzZXRTZWxlY3RlZEN1c3RvbWVyKG51bGwpO1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cChcIkFsbFwiKTtcclxuICAgIHNldEZyb21EYXRlKG51bGwpO1xyXG4gICAgc2V0VG9EYXRlKG51bGwpO1xyXG4gICAgc2V0U2hvd0N1c3RvbURhdGUoZmFsc2UpO1xyXG4gICAgc2V0U2VhcmNoVGV4dChcIlwiKTtcclxuICAgIHNldFNlYXJjaElucHV0KFwiXCIpO1xyXG4gICAgc2V0QWxlcnRDb25maWcoeyB2aXNpYmlsaXR5OiBmYWxzZSwgbWVzc2FnZTogXCJcIiwgdHlwZTogXCJpbmZvXCIgfSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gR2V0IGFjdGl2ZSBmaWx0ZXJzIGNvdW50XHJcbiAgY29uc3QgZ2V0QWN0aXZlRmlsdGVyc0NvdW50ID0gKCkgPT4ge1xyXG4gICAgbGV0IGNvdW50ID0gMDtcclxuICAgIGlmIChzZWxlY3RlZEN1c3RvbWVyQXJlYSkgY291bnQrKztcclxuICAgIGlmIChzZWxlY3RlZEN1c3RvbWVyKSBjb3VudCsrO1xyXG4gICAgaWYgKGZyb21EYXRlICYmIHRvRGF0ZSkgY291bnQrKztcclxuICAgIGlmIChzZWFyY2hUZXh0KSBjb3VudCsrO1xyXG4gICAgcmV0dXJuIGNvdW50O1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgbWluLWgtc2NyZWVuIHAtNCBtZDpwLTZcIj5cclxuICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBwLTQgbWQ6cC02IG1iLTZcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1kOml0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIG1kOnRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsXCI+8J+Tijwvc3Bhbj5cclxuICAgICAgICAgICAgQ3VzdG9tZXIgQXJlYSBSZXBvcnRcclxuICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICBcclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQWxlcnQgKi99XHJcbiAgICAgIHthbGVydENvbmZpZy52aXNpYmlsaXR5ICYmIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BtYi02IHJvdW5kZWQteGwgcC00ICR7XHJcbiAgICAgICAgICAgIGFsZXJ0Q29uZmlnLnR5cGUgPT09IFwiZXJyb3JcIlxyXG4gICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLWwtNCBib3JkZXItcmVkLTUwMFwiXHJcbiAgICAgICAgICAgICAgOiBcImJnLWJsdWUtNTAgYm9yZGVyLWwtNCBib3JkZXItYmx1ZS01MDBcIlxyXG4gICAgICAgICAgfWB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGxcIj5cclxuICAgICAgICAgICAgICAgIHthbGVydENvbmZpZy50eXBlID09PSBcImVycm9yXCIgPyBcIuKdjFwiIDogXCLihLnvuI9cIn1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMFwiPnthbGVydENvbmZpZy5tZXNzYWdlfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDAgdGV4dC0yeGxcIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7IC4uLmFsZXJ0Q29uZmlnLCB2aXNpYmlsaXR5OiBmYWxzZSB9KVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIMOXXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogTWFpbiBGaWx0ZXJzIENhcmQgKi99XHJcbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgc2hhZG93LXNtIG1iLTZcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1kOml0ZW1zLWNlbnRlciBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZ3JheS03MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICA8RmlsdGVyT3V0bGluZWQgLz5cclxuICAgICAgICAgICAgPHNwYW4+RmlsdGVyIE9wdGlvbnM8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBpY29uPXs8UmVsb2FkT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQXBwbHlGaWx0ZXJzfVxyXG4gICAgICAgICAgICAgIGxvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJnLWdyYXktOTAwIGhvdmVyOmJnLWdyYXktODAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEFwcGx5IEZpbHRlcnNcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiZGVmYXVsdFwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUmVzZXRGaWx0ZXJzfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgUmVzZXRcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICB7LyogQ3VzdG9tZXIgQXJlYSAqL31cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgIDxFbnZpcm9ubWVudE91dGxpbmVkIGNsYXNzTmFtZT1cIm1yLTFcIiAvPlxyXG4gICAgICAgICAgICAgIEN1c3RvbWVyIEFyZWFcclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBBcmVhc1wiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ3VzdG9tZXJBcmVhfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldFNlbGVjdGVkQ3VzdG9tZXJBcmVhKHZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMSByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgc3VmZml4SWNvbj17PEVudmlyb25tZW50T3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+fVxyXG4gICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICghb3B0aW9uKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBzZWFyY2hUZXh0ID0gb3B0aW9uLmxhYmVsIHx8ICcnO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgQXJlYXM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAge2N1c3RvbWVyQXJlYXMubWFwKChhcmVhKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBcclxuICAgICAgICAgICAgICAgICAga2V5PXthcmVhLl9pZH0gXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXthcmVhLl9pZH1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e2Ake2FyZWEuYXJlYV9uYW1lfSAke2FyZWEucGluY29kZSB8fCAnJ31gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnthcmVhLmFyZWFfbmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRhZyBjb2xvcj1cImJsdWVcIiBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YXJlYS5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGFnPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ3VzdG9tZXIgKi99XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cIm1yLTFcIiAvPlxyXG4gICAgICAgICAgICAgIEN1c3RvbWVyXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbGwgQ3VzdG9tZXJzXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDdXN0b21lcn1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRTZWxlY3RlZEN1c3RvbWVyKHZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMSByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgc3VmZml4SWNvbj17PFVzZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz59XHJcbiAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFvcHRpb24pIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHNlYXJjaFRleHQgPSBvcHRpb24ubGFiZWwgfHwgJyc7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBDdXN0b21lcnM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAge2N1c3RvbWVycy5tYXAoKGN1c3RvbWVyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBkaXNwbGF5TmFtZSA9IGN1c3RvbWVyLmZ1bGxfbmFtZSB8fCBjdXN0b21lci5uYW1lIHx8ICdVbmtub3duJztcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRpc3BsYXlQaG9uZSA9IGN1c3RvbWVyLnBob25lX251bWJlciB8fCAnJztcclxuICAgICAgICAgICAgICAgIGNvbnN0IGxhYmVsID0gYCR7ZGlzcGxheU5hbWV9ICR7ZGlzcGxheVBob25lfWAudHJpbSgpO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2N1c3RvbWVyLl9pZH0gXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbWVyLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD17bGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkaXNwbGF5TmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtkaXNwbGF5UGhvbmUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbWwtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkaXNwbGF5UGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIERhdGUgUmFuZ2UgKi99XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICA8Q2xvY2tDaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJtci0xXCIgLz5cclxuICAgICAgICAgICAgICBEYXRlIFJhbmdlXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0RmlsdGVyfVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwfVxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IERhdGUgUmFuZ2VcIlxyXG4gICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICghb3B0aW9uKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBzZWFyY2hUZXh0ID0gb3B0aW9uLmxhYmVsIHx8ICcnO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgIHN1ZmZpeEljb249e1xyXG4gICAgICAgICAgICAgICAgPEJhZGdlIGRvdD17c2VsZWN0ZWRHcm91cCAhPT0gXCJBbGxcIn0+XHJcbiAgICAgICAgICAgICAgICAgIDxGaWx0ZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvQmFkZ2U+XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIG9wdGlvbkxhYmVsUHJvcD1cImxhYmVsXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKCh0aW1lKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICBrZXk9e3RpbWUudmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aW1lLnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD17dGltZS5sYWJlbH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPnt0aW1lLmljb259PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMVwiPnt0aW1lLmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB7dGltZS52YWx1ZSA9PT0gc2VsZWN0ZWRHcm91cCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ3VzdG9tIERhdGUgUmFuZ2UgKi99XHJcbiAgICAgICAgICB7c2hvd0N1c3RvbURhdGUgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTNcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cIm1yLTFcIiAvPlxyXG4gICAgICAgICAgICAgICAgQ3VzdG9tIERhdGUgUmFuZ2VcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTQgcHktMi41IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgb3V0bGluZS1ub25lIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZnJvbURhdGUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmZsZXggaXRlbXMtY2VudGVyIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgdG9cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC00IHB5LTIuNSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RvRGF0ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBBY3RpdmUgRmlsdGVycyAqL31cclxuICAgICAgICB7Z2V0QWN0aXZlRmlsdGVyc0NvdW50KCkgPiAwICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgQWN0aXZlIEZpbHRlcnM6XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEN1c3RvbWVyQXJlYSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxUYWdcclxuICAgICAgICAgICAgICAgICAgICBjbG9zYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNlbGVjdGVkQ3VzdG9tZXJBcmVhKG51bGwpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBweC0zIHB5LTFcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiYmx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8RW52aXJvbm1lbnRPdXRsaW5lZCBjbGFzc05hbWU9XCJtci0xXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjdXN0b21lckFyZWFzLmZpbmQoKGEpID0+IGEuX2lkID09PSBzZWxlY3RlZEN1c3RvbWVyQXJlYSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPy5hcmVhX25hbWVcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIDwvVGFnPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEN1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgICAgICAgPFRhZ1xyXG4gICAgICAgICAgICAgICAgICAgIGNsb3NhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWRDdXN0b21lcihudWxsKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgcHgtMyBweS0xXCJcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImdyZWVuXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxVc2VyT3V0bGluZWQgY2xhc3NOYW1lPVwibXItMVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJzLmZpbmQoKGMpID0+IGMuX2lkID09PSBzZWxlY3RlZEN1c3RvbWVyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/LmZ1bGxfbmFtZVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPC9UYWc+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge2Zyb21EYXRlICYmIHRvRGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxUYWdcclxuICAgICAgICAgICAgICAgICAgICBjbG9zYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZyb21EYXRlKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VG9EYXRlKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIHB4LTMgcHktMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwdXJwbGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyT3V0bGluZWQgY2xhc3NOYW1lPVwibXItMVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGVEaXNwbGF5KGZyb21EYXRlKX0g4oaSIHtmb3JtYXREYXRlRGlzcGxheSh0b0RhdGUpfVxyXG4gICAgICAgICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7c2VhcmNoVGV4dCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxUYWdcclxuICAgICAgICAgICAgICAgICAgICBjbG9zYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNlYXJjaFRleHQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWFyY2hJbnB1dChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBweC0zIHB5LTFcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yPVwib3JhbmdlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWFyY2hPdXRsaW5lZCBjbGFzc05hbWU9XCJtci0xXCIgLz5cIntzZWFyY2hUZXh0fVwiXHJcbiAgICAgICAgICAgICAgICAgIDwvVGFnPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEdyb3VwICE9PSBcIkFsbFwiICYmICFmcm9tRGF0ZSAmJiAhdG9EYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgPFRhZ1xyXG4gICAgICAgICAgICAgICAgICAgIGNsb3NhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cChcIkFsbFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZyb21EYXRlKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VG9EYXRlKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIHB4LTMgcHktMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJjeWFuXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDbG9ja0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cIm1yLTFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEdyb3VwfVxyXG4gICAgICAgICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgey8qIFN1bW1hcnkgQ2FyZHMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNCBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicm91bmRlZC14bCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQteGwgYmctYmx1ZS01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LTJ4bFwiPlxyXG4gICAgICAgICAgICAgIPCfkaVcclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+VG90YWwgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICB7cmVwb3J0RGF0YS5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICBcclxuXHJcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicm91bmRlZC14bCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQteGwgYmctcHVycGxlLTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtMnhsXCI+XHJcbiAgICAgICAgICAgICAg8J+ThVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5EYXRlIFJhbmdlPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge2Zyb21EYXRlICYmIHRvRGF0ZSA/IChcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZURpc3BsYXkoZnJvbURhdGUpfVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm14LTFcIj7ihpI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGVEaXNwbGF5KHRvRGF0ZSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgXCJBbGwgVGltZVwiXHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0NhcmQ+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIERhdGEgVGFibGUgKi99XHJcbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgc2hhZG93LXNtXCI+XHJcbiAgICAgICAge2ZpbHRlcmVkRGF0YT8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWREYXRhfVxyXG4gICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDdXN0b21lciBBcmVhIFJlcG9ydFwiXHJcbiAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDdXN0b21lciBBcmVhIFJlcG9ydC5jc3ZcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICBmYWlsdXJlPXtmaWx0ZXJlZERhdGEubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgIGRhdGE9XCJDdXN0b21lciBBcmVhIFJlcG9ydCBEYXRhXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9DYXJkPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEN1c3RvbWVyQXJlYVJlcG9ydDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0N1c3RvbWVyQXJlYVJlcG9ydC5qc3gifQ==