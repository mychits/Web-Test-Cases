import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Designation.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Input, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const Designation = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [TableAgents, setTableAgents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [currentUpdateUser, setCurrentUpdateUser] = useState(null);
  const [errors, setErrors] = useState({});
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [manager, setManagers] = useState([]);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    title: "",
    permission: {
      collection: true,
      daybook: true,
      targets: true,
      leads: true,
      commission: true,
      reports: true,
      modify_payments: true,
      chit_collection: true,
      loan_collection: true,
      pigme_collection: true
    }
  });
  const [updateFormData, setUpdateFormData] = useState({
    title: "",
    permission: {
      collection: true,
      daybook: true,
      targets: true,
      leads: true,
      commission: true,
      reports: true,
      modify_payments: true,
      chit_collection: true,
      loan_collection: true,
      pigme_collection: true
    }
  });
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/designation/get-designation");
        setUsers(response.data);
        const formattedData = response.data.map((group, index) => ({
          _id: group._id,
          id: index + 1,
          designation_code: group?.designation_code,
          title: group.title,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center  gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                        lineNumber: 101,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                        lineNumber: 112,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 124,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 94,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 87,
            columnNumber: 11
          }, this)
        }));
        setTableAgents(formattedData);
      } catch (error) {
        console.error("Error fetching user data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUsers();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addDesignation" ? formData : updateFormData;
    const regex = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[6-9]\d{9}$/
    };
    if (!data.title.trim()) {
      newErrors.name = "Title is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValidate = validateForm("addDesignation");
    try {
      if (isValidate) {
        const response = await api.post(
          "/designation/add-designation",
          formData,
          {
            headers: {
              "Content-Type": "application/json"
            }
          }
        );
        setShowModal(false);
        setFormData({
          title: "",
          permission: {
            collection: true,
            daybook: true,
            targets: true,
            leads: true,
            commission: true,
            reports: true,
            modify_payments: true,
            chit_collection: true,
            loan_collection: true,
            pigme_collection: true
          }
        });
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Designation Added Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error adding Designation:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error.response.data.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "designation_code", header: "Designation Code" },
    { key: "title", header: "Designation Title" },
    { key: "action", header: "Action" }
  ];
  const filteredUsers = users.filter(
    (user) => user.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/designation/get-designation-by-id/${userId}`
      );
      setCurrentUser(response.data);
      setShowModalDelete(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/designation/get-designation-by-id/${userId}`
      );
      setCurrentUpdateUser(response.data);
      setUpdateFormData({
        title: response.data.title,
        permission: {
          collection: response.data?.permission?.collection === true || response.data?.permission?.collection === "true",
          daybook: response.data?.permission?.daybook === true || response.data?.permission?.daybook === "true",
          targets: response.data?.permission?.targets === true || response.data?.permission?.targets === "true",
          leads: response.data?.permission?.leads === true || response.data?.permission?.leads === "true",
          commission: response.data?.permission?.commission === true || response.data?.permission?.commission === "true",
          reports: response.data?.permission?.reports === true || response.data?.permission?.reports === "true",
          modify_payments: response.data?.permission?.modify_payments === true || response.data?.permission?.modify_payments === "true",
          chit_collection: response.data?.permission?.chit_collection === true || response.data?.permission?.chit_collection === "true",
          loan_collection: response.data?.permission?.loan_collection === true || response.data?.permission?.loan_collection === "true",
          pigme_collection: response.data?.permission?.pigme_collection === true || response.data?.permission?.pigme_collection === "true"
        }
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleDeleteUser = async () => {
    if (currentUser) {
      try {
        await api.delete(`/designation/delete-designation/${currentUser._id}`);
        setShowModalDelete(false);
        setCurrentUser(null);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Manager deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting manager:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        const response = await api.put(
          `/designation/update-designation/${currentUpdateUser._id}`,
          updateFormData
        );
        setShowModalUpdate(false);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Designation Updated Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error updating Designation:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error.response.data.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 374,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(SettingSidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
        lineNumber: 378,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 379,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Designations" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 391,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
                setErrors({});
              },
              className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
              children: "+ Add designation"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 392,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 390,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 389,
          columnNumber: 13
        }, this),
        TableAgents.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableAgents, searchText),
            columns,
            exportedPdfName: "Designation",
            exportedFileName: `Employees-${TableAgents.length > 0 ? TableAgents[0].name + " to " + TableAgents[TableAgents.length - 1].name : "empty"}.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 404,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableAgents.length <= 0,
            data: "Designation Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 418,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
        lineNumber: 388,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
      lineNumber: 373,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add designation" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
        lineNumber: 429,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Title ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 438,
                  columnNumber: 25
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 434,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "title",
              value: formData.title,
              onChange: handleChange,
              id: "title",
              placeholder: "Enter the title",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 440,
              columnNumber: 17
            },
            this
          ),
          errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.title }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 451,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 433,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV("label", { className: "text-lg font-bold", children: "Permissions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 455,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 454,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 458,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.collection,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    collection: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 462,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 476,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.collection ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 484,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 461,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 457,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Daybook" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 490,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.daybook,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    daybook: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 494,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 508,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.daybook ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 516,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 493,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 489,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Targets" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 522,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.targets,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    targets: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 526,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 540,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.targets ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 548,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 525,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 521,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Leads" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 554,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.leads,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    leads: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 556,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 570,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.leads ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 578,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 555,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 553,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Commission" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 584,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.commission,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    commission: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 588,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 602,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.commission ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 610,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 587,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 583,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Modify Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 616,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.modify_payments,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    modify_payments: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 620,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 634,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.modify_payments ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 642,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 619,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 615,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Reports" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 648,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.reports,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    reports: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 652,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 666,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.reports ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 674,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 651,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 647,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Chit Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 680,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.chit_collection,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    chit_collection: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 684,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 698,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.chit_collection ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 706,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 683,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 679,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Loan Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 712,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.loan_collection,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    loan_collection: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 716,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 730,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.loan_collection ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 738,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 715,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 711,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Pigmy Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 744,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.permission.pigme_collection,
                onChange: (e) => setFormData({
                  ...formData,
                  permission: {
                    ...formData.permission,
                    pigme_collection: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 748,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 762,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.permission.pigme_collection ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 770,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 747,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 743,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
            children: "Save designation"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 776,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 775,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
        lineNumber: 432,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
      lineNumber: 428,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
      lineNumber: 427,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update designation" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 793,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Title ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                      lineNumber: 802,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 798,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "title",
                  value: updateFormData.title,
                  onChange: handleInputChange,
                  id: "title",
                  placeholder: "Enter the Title",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 804,
                  columnNumber: 17
                },
                this
              ),
              errors.title && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.title }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 815,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 797,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV("label", { className: "text-lg font-bold", children: "Permissions" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 819,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 818,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Collection" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 822,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.collection,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        collection: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 826,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 840,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.collection ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 848,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 825,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 821,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Daybook" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 854,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.daybook,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        daybook: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 858,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 872,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.daybook ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 880,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 857,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 853,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Targets" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 886,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.targets,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        targets: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 890,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 904,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.targets ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 912,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 889,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 885,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Leads" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 918,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.leads,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        leads: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 920,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 934,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.leads ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 942,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 919,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 917,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Commission" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 948,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.commission,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        commission: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 952,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 966,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.commission ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 974,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 951,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 947,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Reports" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 980,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.reports,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        reports: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 984,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 998,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.reports ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 1006,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 983,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 979,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Modify Payments" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 1012,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.modify_payments,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        modify_payments: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 1016,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 1030,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.modify_payments ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 1038,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 1015,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 1011,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Chit Collection" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 1044,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.chit_collection,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        chit_collection: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 1048,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 1062,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.chit_collection ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 1070,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 1047,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 1043,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Loan Collection" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 1076,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.loan_collection,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        loan_collection: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 1080,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 1094,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.loan_collection ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 1102,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 1079,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 1075,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Pigmy Collection" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 1108,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.permission.pigme_collection,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      permission: {
                        ...updateFormData.permission,
                        pigme_collection: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 1112,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4\r\n                              peer-focus:ring-violet-300 dark:peer-focus:ring-violet-800 \r\n                              peer-checked:after:translate-x-full peer-checked:after:border-white \r\n                              after:content-[''] after:absolute after:top-[2px] after:left-[2px] \r\n                              after:bg-white after:border-gray-300 after:border after:rounded-full \r\n                              after:h-5 after:w-5 after:transition-all peer-checked:bg-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 1126,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.permission.pigme_collection ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 1134,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 1111,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 1107,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                lineNumber: 1140,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 1139,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 796,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 792,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
        lineNumber: 788,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentUser(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete designation" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
            lineNumber: 1160,
            columnNumber: 13
          }, this),
          currentUser && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteUser();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentUser.title }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                          lineNumber: 1177,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                          lineNumber: 1181,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                      lineNumber: 1172,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the designation",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                      lineNumber: 1183,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                  lineNumber: 1171,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
                    lineNumber: 1191,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
              lineNumber: 1164,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
          lineNumber: 1159,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
        lineNumber: 1152,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
    lineNumber: 372,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx",
    lineNumber: 371,
    columnNumber: 5
  }, this);
};
_s(Designation, "tk42h/sJHFdDHOst8r7yTTeLwEw=");
_c = Designation;
export default Designation;
var _c;
$RefreshReg$(_c, "Designation");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Designation.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0d3QixTQThRcEIsVUE5UW9COzJCQXBHeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFPQyxnQkFBZ0I7QUFDaEMsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MsaUJBQWlCO0FBRTFCLE1BQU1DLGNBQWNBLE1BQU07QUFBQUMsS0FBQTtBQUN4QixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSWpCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNrQixhQUFhQyxjQUFjLElBQUluQixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDb0IsWUFBWUMsYUFBYSxJQUFJckIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3NCLFdBQVdDLFlBQVksSUFBSXZCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN3QixpQkFBaUJDLGtCQUFrQixJQUFJekIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzBCLGlCQUFpQkMsa0JBQWtCLElBQUkzQixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNEIsYUFBYUMsY0FBYyxJQUFJN0IsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQzhCLG1CQUFtQkMsb0JBQW9CLElBQUkvQixTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDZ0MsUUFBUUMsU0FBUyxJQUFJakMsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDa0MsWUFBWUMsYUFBYSxJQUFJbkMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ29DLFdBQVdDLFlBQVksSUFBSXJDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNzQyxTQUFTQyxXQUFXLElBQUl2QyxTQUFTLEVBQUU7QUFDMUMsUUFBTSxDQUFDd0MsZUFBZUMsZ0JBQWdCLElBQUl6QyxTQUFTLENBQUM7QUFFcEQsUUFBTTBDLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJWLGtCQUFjUyxLQUFLO0FBQUEsRUFDckI7QUFFQSxRQUFNLENBQUNFLGFBQWFDLGNBQWMsSUFBSS9DLFNBQVM7QUFBQSxJQUM3Q2dELFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJcEQsU0FBUztBQUFBLElBQ3ZDcUQsT0FBTztBQUFBLElBQ1BDLFlBQVk7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsU0FBUztBQUFBLE1BQ1RDLFNBQVM7QUFBQSxNQUNUQyxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLFNBQVM7QUFBQSxNQUNUQyxpQkFBaUI7QUFBQSxNQUNqQkMsaUJBQWlCO0FBQUEsTUFDakJDLGlCQUFpQjtBQUFBLE1BQ2pCQyxrQkFBa0I7QUFBQSxJQUNwQjtBQUFBLEVBQ0YsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSWxFLFNBQVM7QUFBQSxJQUNuRHFELE9BQU87QUFBQSxJQUNQQyxZQUFZO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLFNBQVM7QUFBQSxNQUNUQyxTQUFTO0FBQUEsTUFDVEMsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxTQUFTO0FBQUEsTUFDVEMsaUJBQWlCO0FBQUEsTUFDakJDLGlCQUFpQjtBQUFBLE1BQ2pCQyxpQkFBaUI7QUFBQSxNQUNqQkMsa0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxFQUNGLENBQUM7QUFFQ2pFLFlBQVUsTUFBTTtBQUNoQixVQUFNb0UsYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRjlCLHFCQUFhLElBQUk7QUFDakIsY0FBTStCLFdBQVcsTUFBTTlELElBQUkrRCxJQUFJLDhCQUE4QjtBQUU3RHBELGlCQUFTbUQsU0FBU0UsSUFBSTtBQUN0QixjQUFNQyxnQkFBZ0JILFNBQVNFLEtBQUtFLElBQUksQ0FBQ0MsT0FBT0MsV0FBVztBQUFBLFVBQ3pEQyxLQUFLRixNQUFNRTtBQUFBQSxVQUNYQyxJQUFJRixRQUFRO0FBQUEsVUFDWEcsa0JBQWtCSixPQUFPSTtBQUFBQSxVQUMxQnhCLE9BQU9vQixNQUFNcEI7QUFBQUEsVUFDYnlCLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDhCQU9iO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQSxTQUFTLENBQUMsT0FBTztBQUFBLGNBQ2hCLE1BQU07QUFBQSxnQkFDSkMsT0FBTztBQUFBLGtCQUNMO0FBQUEsb0JBQ0VDLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNQyxzQkFBc0JULE1BQU1FLEdBQUc7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRUssS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU1FLHNCQUFzQlYsTUFBTUUsR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxnQkFBQztBQUFBLGNBRUw7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBO0FBQUEsWUE5QmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQStCQSxLQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVDQTtBQUFBLFFBRUosRUFBRTtBQUNGeEQsdUJBQWVvRCxhQUFhO0FBQUEsTUFDOUIsU0FBU2EsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFBQSxNQUNsRCxVQUFDO0FBQ0MvQyxxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0E4QixlQUFXO0FBQUEsRUFDYixHQUFHLENBQUMzQixhQUFhLENBQUM7QUFFbEIsUUFBTThDLGVBQWVBLENBQUMzQyxNQUFNO0FBQzFCLFVBQU0sRUFBRTRDLE1BQU0zQyxNQUFNLElBQUlELEVBQUVFO0FBQzFCTyxnQkFBWSxDQUFDb0MsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsSUFBSSxHQUFHM0M7QUFBQUEsSUFDVixFQUFFO0FBQ0ZYLGNBQVUsQ0FBQ3VELGNBQWM7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNILENBQUNELElBQUksR0FBRztBQUFBLElBQ1YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNRSxlQUFlQSxDQUFDdkMsU0FBUztBQUM3QixVQUFNd0MsWUFBWSxDQUFDO0FBQ25CLFVBQU1wQixPQUFPcEIsU0FBUyxtQkFBbUJDLFdBQVdjO0FBQ3BELFVBQU0wQixRQUFRO0FBQUEsTUFDWkMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBRUEsUUFBSSxDQUFDdkIsS0FBS2pCLE1BQU15QyxLQUFLLEdBQUc7QUFDdEJKLGdCQUFVSCxPQUFPO0FBQUEsSUFDbkI7QUFDQXRELGNBQVV5RCxTQUFTO0FBQ25CLFdBQU9LLE9BQU9DLEtBQUtOLFNBQVMsRUFBRU8sV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTUMsZUFBZSxPQUFPdkQsTUFBTTtBQUNoQ0EsTUFBRXdELGVBQWU7QUFDakIsVUFBTUMsYUFBYVgsYUFBYSxnQkFBZ0I7QUFFaEQsUUFBSTtBQUNGLFVBQUlXLFlBQVk7QUFDZCxjQUFNaEMsV0FBVyxNQUFNOUQsSUFBSStGO0FBQUFBLFVBQ3pCO0FBQUEsVUFDQWxEO0FBQUFBLFVBQ0E7QUFBQSxZQUNFbUQsU0FBUztBQUFBLGNBQ1AsZ0JBQWdCO0FBQUEsWUFDbEI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUVBL0UscUJBQWEsS0FBSztBQUNsQjZCLG9CQUFZO0FBQUEsVUFDVkMsT0FBTztBQUFBLFVBQ1BDLFlBQVk7QUFBQSxZQUNWQyxZQUFZO0FBQUEsWUFDWkMsU0FBUztBQUFBLFlBQ1RDLFNBQVM7QUFBQSxZQUNUQyxPQUFPO0FBQUEsWUFDUEMsWUFBWTtBQUFBLFlBQ1pDLFNBQVM7QUFBQSxZQUNUQyxpQkFBaUI7QUFBQSxZQUNqQkMsaUJBQWlCO0FBQUEsWUFDdkJDLGlCQUFpQjtBQUFBLFlBQ2pCQyxrQkFBa0I7QUFBQSxVQUNkO0FBQUEsUUFDRixDQUFDO0FBQ0R2Qix5QkFBaUIsQ0FBQzhELFNBQVNBLE9BQU8sQ0FBQztBQUNuQ3hELHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU2tDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaEQsVUFDRUEsTUFBTWhCLFlBQ05nQixNQUFNaEIsU0FBU0UsUUFDZmMsTUFBTWhCLFNBQVNFLEtBQUtyQixTQUNwQjtBQUNBRix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTLEdBQUdtQyxNQUFNaEIsU0FBU0UsS0FBS3JCLE9BQU87QUFBQSxVQUN2Q0MsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMSCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUlBLFFBQU1zRCxVQUFVO0FBQUEsSUFDZCxFQUFFeEIsS0FBSyxNQUFNeUIsUUFBUSxTQUFTO0FBQUEsSUFDM0IsRUFBQ3pCLEtBQUssb0JBQW9CeUIsUUFBUSxtQkFBa0I7QUFBQSxJQUN2RCxFQUFFekIsS0FBSyxTQUFTeUIsUUFBUSxvQkFBb0I7QUFBQSxJQUM1QyxFQUFFekIsS0FBSyxVQUFVeUIsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyxnQkFBZ0IxRixNQUFNMkY7QUFBQUEsSUFBTyxDQUFDQyxTQUNsQ0EsS0FBS3ZELE1BQU13RCxZQUFZLEVBQUVDLFNBQVMxRixXQUFXeUYsWUFBWSxDQUFDO0FBQUEsRUFDNUQ7QUFFQSxRQUFNMUIsd0JBQXdCLE9BQU80QixXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNM0MsV0FBVyxNQUFNOUQsSUFBSStEO0FBQUFBLFFBQ3pCLHNDQUFzQzBDLE1BQU07QUFBQSxNQUM5QztBQUNBbEYscUJBQWV1QyxTQUFTRSxJQUFJO0FBQzVCN0MseUJBQW1CLElBQUk7QUFDdkJRLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU21ELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxJQUM3QztBQUFBLEVBQ0Y7QUFFQSxRQUFNRix3QkFBd0IsT0FBTzZCLFdBQVc7QUFDOUMsUUFBSTtBQUNGLFlBQU0zQyxXQUFXLE1BQU05RCxJQUFJK0Q7QUFBQUEsUUFDekIsc0NBQXNDMEMsTUFBTTtBQUFBLE1BQzlDO0FBQ0FoRiwyQkFBcUJxQyxTQUFTRSxJQUFJO0FBQ2xDSix3QkFBa0I7QUFBQSxRQUNoQmIsT0FBT2UsU0FBU0UsS0FBS2pCO0FBQUFBLFFBQ3JCQyxZQUFZO0FBQUEsVUFDVkMsWUFDRWEsU0FBU0UsTUFBTWhCLFlBQVlDLGVBQWUsUUFDMUNhLFNBQVNFLE1BQU1oQixZQUFZQyxlQUFlO0FBQUEsVUFDNUNDLFNBQ0VZLFNBQVNFLE1BQU1oQixZQUFZRSxZQUFZLFFBQ3ZDWSxTQUFTRSxNQUFNaEIsWUFBWUUsWUFBWTtBQUFBLFVBQ3pDQyxTQUNFVyxTQUFTRSxNQUFNaEIsWUFBWUcsWUFBWSxRQUN2Q1csU0FBU0UsTUFBTWhCLFlBQVlHLFlBQVk7QUFBQSxVQUN6Q0MsT0FDRVUsU0FBU0UsTUFBTWhCLFlBQVlJLFVBQVUsUUFDckNVLFNBQVNFLE1BQU1oQixZQUFZSSxVQUFVO0FBQUEsVUFDdkNDLFlBQ0VTLFNBQVNFLE1BQU1oQixZQUFZSyxlQUFlLFFBQzFDUyxTQUFTRSxNQUFNaEIsWUFBWUssZUFBZTtBQUFBLFVBQzVDQyxTQUNFUSxTQUFTRSxNQUFNaEIsWUFBWU0sWUFBWSxRQUN2Q1EsU0FBU0UsTUFBTWhCLFlBQVlNLFlBQVk7QUFBQSxVQUN6Q0MsaUJBQ0VPLFNBQVNFLE1BQU1oQixZQUFZTyxvQkFBb0IsUUFDL0NPLFNBQVNFLE1BQU1oQixZQUFZTyxvQkFBb0I7QUFBQSxVQUNqREMsaUJBQ0VNLFNBQVNFLE1BQU1oQixZQUFZUSxvQkFBb0IsUUFDL0NNLFNBQVNFLE1BQU1oQixZQUFZUSxvQkFBb0I7QUFBQSxVQUNyREMsaUJBQ01LLFNBQVNFLE1BQU1oQixZQUFZUyxvQkFBb0IsUUFDL0NLLFNBQVNFLE1BQU1oQixZQUFZUyxvQkFBb0I7QUFBQSxVQUNyREMsa0JBQ01JLFNBQVNFLE1BQU1oQixZQUFZVSxxQkFBcUIsUUFDaERJLFNBQVNFLE1BQU1oQixZQUFZVSxxQkFBcUI7QUFBQSxRQUNwRDtBQUFBLE1BQ0YsQ0FBQztBQUNEckMseUJBQW1CLElBQUk7QUFDdkJNLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU21ELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxJQUM3QztBQUFBLEVBQ0Y7QUFHQSxRQUFNNEIsb0JBQW9CQSxDQUFDckUsTUFBTTtBQUMvQixVQUFNLEVBQUU0QyxNQUFNM0MsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQnFCLHNCQUFrQixDQUFDc0IsY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsSUFBSSxHQUFHM0M7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1xRSxtQkFBbUIsWUFBWTtBQUNuQyxRQUFJckYsYUFBYTtBQUVmLFVBQUk7QUFDRixjQUFNdEIsSUFBSTRHLE9BQU8sbUNBQW1DdEYsWUFBWStDLEdBQUcsRUFBRTtBQUNyRWxELDJCQUFtQixLQUFLO0FBQ3hCSSx1QkFBZSxJQUFJO0FBQ25CWSx5QkFBaUIsQ0FBQzhELFNBQVNBLE9BQU8sQ0FBQztBQUNuQ3hELHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxTQUFTa0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSwyQkFBMkJBLEtBQUs7QUFBQSxNQUNoRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTStCLGVBQWUsT0FBT3hFLE1BQU07QUFDaENBLE1BQUV3RCxlQUFlO0FBQ2pCLFVBQU1pQixVQUFVM0IsYUFBYTtBQUM3QixRQUFJO0FBQ0YsVUFBSTJCLFNBQVM7QUFDWCxjQUFNaEQsV0FBVyxNQUFNOUQsSUFBSStHO0FBQUFBLFVBQ3pCLG1DQUFtQ3ZGLGtCQUFrQjZDLEdBQUc7QUFBQSxVQUN4RFY7QUFBQUEsUUFDRjtBQUNBdEMsMkJBQW1CLEtBQUs7QUFDeEJjLHlCQUFpQixDQUFDOEQsU0FBU0EsT0FBTyxDQUFDO0FBQ25DeEQsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTa0MsT0FBTztBQUNkQyxjQUFRRCxNQUFNLCtCQUErQkEsS0FBSztBQUNsRCxVQUNFQSxNQUFNaEIsWUFDTmdCLE1BQU1oQixTQUFTRSxRQUNmYyxNQUFNaEIsU0FBU0UsS0FBS3JCLFNBQ3BCO0FBQ0FGLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVMsR0FBR21DLE1BQU1oQixTQUFTRSxLQUFLckIsT0FBTztBQUFBLFVBQ3ZDQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0xILHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBSUEsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkIsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDZjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTUosWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUN3RCxVQUFVLEVBQUUsR0FBR0EsTUFBTXZELFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNRztBQUFBLE1BR0gsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBCQUF5Qiw0QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUNuRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2J6Qiw2QkFBYSxJQUFJO0FBQ2pCVSwwQkFBVSxDQUFDLENBQUM7QUFBQSxjQUNkO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBdUc7QUFBQTtBQUFBLFlBTG5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUNFZixZQUFZK0UsU0FBUyxLQUFLLENBQUM3RCxZQUMzQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsZUFBZThDO0FBQUFBLFlBQ2YsTUFBTXhFLGFBQWFRLGFBQWFnQixVQUFVO0FBQUEsWUFDMUM7QUFBQSxZQUNBLGlCQUFnQjtBQUFBLFlBQ2hCLGtCQUFrQixhQUNoQmhCLFlBQVkrRSxTQUFTLElBQ2pCL0UsWUFBWSxDQUFDLEVBQUVxRSxPQUNmLFNBQ0FyRSxZQUFZQSxZQUFZK0UsU0FBUyxDQUFDLEVBQUVWLE9BQ3BDLE9BQU87QUFBQTtBQUFBLFVBVmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV1MsSUFHVDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFNBQVNyRSxZQUFZK0UsVUFBVTtBQUFBLFlBQy9CLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3lCO0FBQUEsV0FqQzdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQ0E7QUFBQSxTQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0RBO0FBQUEsSUFFQSx1QkFBQyxTQUFNLFdBQVczRSxXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsK0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVTJFLGNBQWMsWUFBVSxNQUM1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQU87QUFBQTtBQUFBLGdCQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUE7QUFBQTtBQUFBLFlBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBTy9DLFNBQVNFO0FBQUFBLGNBQ2hCLFVBQVVpQztBQUFBQSxjQUNWLElBQUc7QUFBQSxjQUNILGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxXQUFXLHFDQUFxQ3pFLFVBQVV5RyxNQUFNO0FBQUE7QUFBQSxZQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRaUs7QUFBQSxVQUVoS3RGLE9BQU91RCxRQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ2RCxpQkFBT3FCLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsYUFsQjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiLGlDQUFDLFdBQU0sV0FBVSxxQkFBb0IsMkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0QsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDBCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTRixTQUFTRyxXQUFXQztBQUFBQSxnQkFDN0IsVUFBVSxDQUFDWixNQUNUUyxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLFlBQVk7QUFBQSxvQkFDVixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWkMsWUFBWVosRUFBRUUsT0FBTzBFO0FBQUFBLGtCQUN2QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBO0FBQUEsY0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQztBQUFBLFlBQ0QsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEUsbUJBQVNHLFdBQVdDLGFBQWEsUUFBUSxRQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHVCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTSixTQUFTRyxXQUFXRTtBQUFBQSxnQkFDN0IsVUFBVSxDQUFDYixNQUNUUyxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLFlBQVk7QUFBQSxvQkFDVixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWkUsU0FBU2IsRUFBRUUsT0FBTzBFO0FBQUFBLGtCQUNwQjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBO0FBQUEsY0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQztBQUFBLFlBQ0QsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEUsbUJBQVNHLFdBQVdFLFVBQVUsUUFBUSxRQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHVCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTTCxTQUFTRyxXQUFXRztBQUFBQSxnQkFDN0IsVUFBVSxDQUFDZCxNQUNUUyxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLFlBQVk7QUFBQSxvQkFDVixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWkcsU0FBU2QsRUFBRUUsT0FBTzBFO0FBQUFBLGtCQUNwQjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBO0FBQUEsY0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQztBQUFBLFlBQ0QsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEUsbUJBQVNHLFdBQVdHLFVBQVUsUUFBUSxRQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHFCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLFVBQ3pELHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNOLFNBQVNHLFdBQVdJO0FBQUFBLGdCQUM3QixVQUFVLENBQUNmLE1BQ1RTLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsWUFBWTtBQUFBLG9CQUNWLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaSSxPQUFPZixFQUFFRSxPQUFPMEU7QUFBQUEsa0JBQ2xCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUE7QUFBQSxjQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9DO0FBQUEsWUFDRCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRSxtQkFBU0csV0FBV0ksUUFBUSxRQUFRLFFBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLGFBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2QkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsMEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNQLFNBQVNHLFdBQVdLO0FBQUFBLGdCQUM3QixVQUFVLENBQUNoQixNQUNUUyxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLFlBQVk7QUFBQSxvQkFDVixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWkssWUFBWWhCLEVBQUVFLE9BQU8wRTtBQUFBQSxrQkFDdkI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQTtBQUFBLGNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0M7QUFBQSxZQUNELHVCQUFDLFVBQUssV0FBVSw4QkFDYnBFLG1CQUFTRyxXQUFXSyxhQUFhLFFBQVEsUUFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMEJBO0FBQUEsYUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQywrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU1IsU0FBU0csV0FBV087QUFBQUEsZ0JBQzdCLFVBQVUsQ0FBQ2xCLE1BQ1RTLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsWUFBWTtBQUFBLG9CQUNWLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaTyxpQkFBaUJsQixFQUFFRSxPQUFPMEU7QUFBQUEsa0JBQzVCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUE7QUFBQSxjQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9DO0FBQUEsWUFDRCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRSxtQkFBU0csV0FBV08sa0JBQWtCLFFBQVEsUUFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMEJBO0FBQUEsYUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyx1QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU1YsU0FBU0csV0FBV007QUFBQUEsZ0JBQzdCLFVBQVUsQ0FBQ2pCLE1BQ1RTLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsWUFBWTtBQUFBLG9CQUNWLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaTSxTQUFTakIsRUFBRUUsT0FBTzBFO0FBQUFBLGtCQUNwQjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBO0FBQUEsY0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQztBQUFBLFlBQ0QsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEUsbUJBQVNHLFdBQVdNLFVBQVUsUUFBUSxRQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTVCxTQUFTRyxXQUFXUTtBQUFBQSxnQkFDN0IsVUFBVSxDQUFDbkIsTUFDVFMsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxZQUFZO0FBQUEsb0JBQ1YsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pRLGlCQUFpQm5CLEVBQUVFLE9BQU8wRTtBQUFBQSxrQkFDNUI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQTtBQUFBLGNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0M7QUFBQSxZQUNELHVCQUFDLFVBQUssV0FBVSw4QkFDYnBFLG1CQUFTRyxXQUFXUSxrQkFBa0IsUUFBUSxRQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTWCxTQUFTRyxXQUFXUztBQUFBQSxnQkFDN0IsVUFBVSxDQUFDcEIsTUFDVFMsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxZQUFZO0FBQUEsb0JBQ1YsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pTLGlCQUFpQnBCLEVBQUVFLE9BQU8wRTtBQUFBQSxrQkFDNUI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQTtBQUFBLGNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0M7QUFBQSxZQUNELHVCQUFDLFVBQUssV0FBVSw4QkFDYnBFLG1CQUFTRyxXQUFXUyxrQkFBa0IsUUFBUSxRQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLGdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTWixTQUFTRyxXQUFXVTtBQUFBQSxnQkFDN0IsVUFBVSxDQUFDckIsTUFDVFMsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxZQUFZO0FBQUEsb0JBQ1YsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pVLGtCQUFrQnJCLEVBQUVFLE9BQU8wRTtBQUFBQSxrQkFDN0I7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQTtBQUFBLGNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0M7QUFBQSxZQUNELHVCQUFDLFVBQUssV0FBVSw4QkFDYnBFLG1CQUFTRyxXQUFXVSxtQkFBbUIsUUFBUSxRQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNxSDtBQUFBO0FBQUEsVUFIakk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQS9WRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ1dBO0FBQUEsU0FwV0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFXQSxLQXRXRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdVdBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3RDO0FBQUFBLFFBQ1gsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBRXZDLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsa0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVV3RixjQUFjLFlBQVUsTUFDNUQ7QUFBQSxtQ0FBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBTztBQUFBO0FBQUEsb0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9sRCxlQUFlWjtBQUFBQSxrQkFDdEIsVUFBVTJEO0FBQUFBLGtCQUNWLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ25HLFVBQVV5RyxNQUFNO0FBQUE7QUFBQSxnQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUWlLO0FBQUEsY0FFaEt0RixPQUFPcUIsU0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCckIsaUJBQU9xQixTQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RDtBQUFBLGlCQWxCM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiLGlDQUFDLFdBQU0sV0FBVSxxQkFBb0IsMkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdELEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsMEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTWSxlQUFlWCxXQUFXQztBQUFBQSxvQkFDbkMsVUFBVSxDQUFDWixNQUNUdUIsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIWCxZQUFZO0FBQUEsd0JBQ1YsR0FBR1csZUFBZVg7QUFBQUEsd0JBQ2xCQyxZQUFZWixFQUFFRSxPQUFPMEU7QUFBQUEsc0JBQ3ZCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBO0FBQUEsa0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9DO0FBQUEsZ0JBQ0QsdUJBQUMsVUFBSyxXQUFVLDhCQUNidEQseUJBQWVYLFdBQVdDLGFBQWEsUUFBUSxRQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEJBO0FBQUEsaUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHVCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU1UsZUFBZVgsV0FBV0U7QUFBQUEsb0JBQ25DLFVBQVUsQ0FBQ2IsTUFDVHVCLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSFgsWUFBWTtBQUFBLHdCQUNWLEdBQUdXLGVBQWVYO0FBQUFBLHdCQUNsQkUsU0FBU2IsRUFBRUUsT0FBTzBFO0FBQUFBLHNCQUNwQjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQTtBQUFBLGtCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQztBQUFBLGdCQUNELHVCQUFDLFVBQUssV0FBVSw4QkFDYnRELHlCQUFlWCxXQUFXRSxVQUFVLFFBQVEsUUFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBCQTtBQUFBLGlCQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyx1QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNTLGVBQWVYLFdBQVdHO0FBQUFBLG9CQUNuQyxVQUFVLENBQUNkLE1BQ1R1QixrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0hYLFlBQVk7QUFBQSx3QkFDVixHQUFHVyxlQUFlWDtBQUFBQSx3QkFDbEJHLFNBQVNkLEVBQUVFLE9BQU8wRTtBQUFBQSxzQkFDcEI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUE7QUFBQSxrQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0M7QUFBQSxnQkFDRCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2J0RCx5QkFBZVgsV0FBV0csVUFBVSxRQUFRLFFBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwQkE7QUFBQSxpQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MscUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsY0FDekQsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNRLGVBQWVYLFdBQVdJO0FBQUFBLG9CQUNuQyxVQUFVLENBQUNmLE1BQ1R1QixrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0hYLFlBQVk7QUFBQSx3QkFDVixHQUFHVyxlQUFlWDtBQUFBQSx3QkFDbEJJLE9BQU9mLEVBQUVFLE9BQU8wRTtBQUFBQSxzQkFDbEI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUE7QUFBQSxrQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0M7QUFBQSxnQkFDRCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2J0RCx5QkFBZVgsV0FBV0ksUUFBUSxRQUFRLFFBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwQkE7QUFBQSxpQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2QkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsMEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTTyxlQUFlWCxXQUFXSztBQUFBQSxvQkFDbkMsVUFBVSxDQUFDaEIsTUFDVHVCLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSFgsWUFBWTtBQUFBLHdCQUNWLEdBQUdXLGVBQWVYO0FBQUFBLHdCQUNsQkssWUFBWWhCLEVBQUVFLE9BQU8wRTtBQUFBQSxzQkFDdkI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUE7QUFBQSxrQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0M7QUFBQSxnQkFDRCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2J0RCx5QkFBZVgsV0FBV0ssYUFBYSxRQUFRLFFBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwQkE7QUFBQSxpQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsdUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTTSxlQUFlWCxXQUFXTTtBQUFBQSxvQkFDbkMsVUFBVSxDQUFDakIsTUFDVHVCLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSFgsWUFBWTtBQUFBLHdCQUNWLEdBQUdXLGVBQWVYO0FBQUFBLHdCQUNsQk0sU0FBU2pCLEVBQUVFLE9BQU8wRTtBQUFBQSxzQkFDcEI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUE7QUFBQSxrQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0M7QUFBQSxnQkFDRCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2J0RCx5QkFBZVgsV0FBV00sVUFBVSxRQUFRLFFBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwQkE7QUFBQSxpQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsK0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTSyxlQUFlWCxXQUFXTztBQUFBQSxvQkFDbkMsVUFBVSxDQUFDbEIsTUFDVHVCLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSFgsWUFBWTtBQUFBLHdCQUNWLEdBQUdXLGVBQWVYO0FBQUFBLHdCQUNsQk8saUJBQWlCbEIsRUFBRUUsT0FBTzBFO0FBQUFBLHNCQUM1QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQTtBQUFBLGtCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQztBQUFBLGdCQUNELHVCQUFDLFVBQUssV0FBVSw4QkFDYnRELHlCQUFlWCxXQUFXTyxrQkFBa0IsUUFBUSxRQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEJBO0FBQUEsaUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU0ksZUFBZVgsV0FBV1E7QUFBQUEsb0JBQ25DLFVBQVUsQ0FBQ25CLE1BQ1R1QixrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0hYLFlBQVk7QUFBQSx3QkFDVixHQUFHVyxlQUFlWDtBQUFBQSx3QkFDbEJRLGlCQUFpQm5CLEVBQUVFLE9BQU8wRTtBQUFBQSxzQkFDNUI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUE7QUFBQSxrQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0M7QUFBQSxnQkFDRCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2J0RCx5QkFBZVgsV0FBV1Esa0JBQWtCLFFBQVEsUUFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBCQTtBQUFBLGlCQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQywrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNHLGVBQWVYLFdBQVdTO0FBQUFBLG9CQUNuQyxVQUFVLENBQUNwQixNQUNUdUIsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIWCxZQUFZO0FBQUEsd0JBQ1YsR0FBR1csZUFBZVg7QUFBQUEsd0JBQ2xCUyxpQkFBaUJwQixFQUFFRSxPQUFPMEU7QUFBQUEsc0JBQzVCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBO0FBQUEsa0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9DO0FBQUEsZ0JBQ0QsdUJBQUMsVUFBSyxXQUFVLDhCQUNidEQseUJBQWVYLFdBQVdTLGtCQUFrQixRQUFRLFFBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwQkE7QUFBQSxpQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsZ0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTRSxlQUFlWCxXQUFXVTtBQUFBQSxvQkFDbkMsVUFBVSxDQUFDckIsTUFDVHVCLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSFgsWUFBWTtBQUFBLHdCQUNWLEdBQUdXLGVBQWVYO0FBQUFBLHdCQUNsQlUsa0JBQWtCckIsRUFBRUUsT0FBTzBFO0FBQUFBLHNCQUM3QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQTtBQUFBLGtCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQztBQUFBLGdCQUNELHVCQUFDLFVBQUssV0FBVSw4QkFDYnRELHlCQUFlWCxXQUFXVSxtQkFBbUIsUUFBUSxRQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEJBO0FBQUEsaUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUMrRjtBQUFBO0FBQUEsY0FIM0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUEvVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnV0E7QUFBQSxhQXBXRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcVdBO0FBQUE7QUFBQSxNQXpXRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUEwV0E7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXeEM7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNkJBQW1CLEtBQUs7QUFDeEJJLHlCQUFlLElBQUk7QUFBQSxRQUNyQjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxrQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NELGVBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVUsQ0FBQ2UsTUFBTTtBQUNmQSxrQkFBRXdELGVBQWU7QUFDakJjLGlDQUFpQjtBQUFBLGNBQ25CO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFXO0FBQUE7QUFBQSx3QkFFTjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYnJGLHNCQUFZeUIsU0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUNBQXFDeEMsVUFBVXlHLE1BQU07QUFBQTtBQUFBLG9CQUxsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS2lLO0FBQUEscUJBakJuSztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQzJGO0FBQUE7QUFBQSxrQkFIdkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUE7QUFBQTtBQUFBLFlBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtDQTtBQUFBLGFBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0E7QUFBQTtBQUFBLE1BaERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlEQTtBQUFBLE9BN3pCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOHpCQSxLQS96QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWcwQkE7QUFFSjtBQUFFdkcsR0FycUNJRCxhQUFXO0FBQUEwRyxLQUFYMUc7QUF1cUNOLGVBQWVBO0FBQVksSUFBQTBHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNldHRpbmdTaWRlYmFyIiwiSW9NZE1vcmUiLCJJbnB1dCIsIkRyb3Bkb3duIiwiTW9kYWwiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJmaWVsZFNpemUiLCJEZXNpZ25hdGlvbiIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsIlRhYmxlQWdlbnRzIiwic2V0VGFibGVBZ2VudHMiLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRVc2VyIiwic2V0Q3VycmVudFVzZXIiLCJjdXJyZW50VXBkYXRlVXNlciIsInNldEN1cnJlbnRVcGRhdGVVc2VyIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJtYW5hZ2VyIiwic2V0TWFuYWdlcnMiLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwidGl0bGUiLCJwZXJtaXNzaW9uIiwiY29sbGVjdGlvbiIsImRheWJvb2siLCJ0YXJnZXRzIiwibGVhZHMiLCJjb21taXNzaW9uIiwicmVwb3J0cyIsIm1vZGlmeV9wYXltZW50cyIsImNoaXRfY29sbGVjdGlvbiIsImxvYW5fY29sbGVjdGlvbiIsInBpZ21lX2NvbGxlY3Rpb24iLCJ1cGRhdGVGb3JtRGF0YSIsInNldFVwZGF0ZUZvcm1EYXRhIiwiZmV0Y2hVc2VycyIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJncm91cCIsImluZGV4IiwiX2lkIiwiaWQiLCJkZXNpZ25hdGlvbl9jb2RlIiwiYWN0aW9uIiwiaXRlbXMiLCJrZXkiLCJsYWJlbCIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImVycm9yIiwiY29uc29sZSIsImhhbmRsZUNoYW5nZSIsIm5hbWUiLCJwcmV2RGF0YSIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsInJlZ2V4IiwiZW1haWwiLCJwaG9uZSIsInRyaW0iLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkYXRlIiwicG9zdCIsImhlYWRlcnMiLCJwcmV2IiwiY29sdW1ucyIsImhlYWRlciIsImZpbHRlcmVkVXNlcnMiLCJmaWx0ZXIiLCJ1c2VyIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInVzZXJJZCIsImhhbmRsZUlucHV0Q2hhbmdlIiwiaGFuZGxlRGVsZXRlVXNlciIsImRlbGV0ZSIsImhhbmRsZVVwZGF0ZSIsImlzVmFsaWQiLCJwdXQiLCJoZWlnaHQiLCJjaGVja2VkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGVzaWduYXRpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNldHRpbmdTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2V0dGluZ1NpZGViYXJcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgSW5wdXQsIERyb3Bkb3duIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0IGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcblxyXG5jb25zdCBEZXNpZ25hdGlvbiA9ICgpID0+IHtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVBZ2VudHMsIHNldFRhYmxlQWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxEZWxldGUsIHNldFNob3dNb2RhbERlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFVzZXIsIHNldEN1cnJlbnRVc2VyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlVXNlciwgc2V0Q3VycmVudFVwZGF0ZVVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttYW5hZ2VyLCBzZXRNYW5hZ2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdGl0bGU6IFwiXCIsXHJcbiAgICBwZXJtaXNzaW9uOiB7XHJcbiAgICAgIGNvbGxlY3Rpb246IHRydWUsXHJcbiAgICAgIGRheWJvb2s6IHRydWUsXHJcbiAgICAgIHRhcmdldHM6IHRydWUsXHJcbiAgICAgIGxlYWRzOiB0cnVlLFxyXG4gICAgICBjb21taXNzaW9uOiB0cnVlLFxyXG4gICAgICByZXBvcnRzOiB0cnVlLFxyXG4gICAgICBtb2RpZnlfcGF5bWVudHM6IHRydWUsXHJcbiAgICAgIGNoaXRfY29sbGVjdGlvbjogdHJ1ZSxcclxuICAgICAgbG9hbl9jb2xsZWN0aW9uOiB0cnVlLFxyXG4gICAgICBwaWdtZV9jb2xsZWN0aW9uOiB0cnVlLFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0aXRsZTogXCJcIixcclxuICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgY29sbGVjdGlvbjogdHJ1ZSxcclxuICAgICAgZGF5Ym9vazogdHJ1ZSxcclxuICAgICAgdGFyZ2V0czogdHJ1ZSxcclxuICAgICAgbGVhZHM6IHRydWUsXHJcbiAgICAgIGNvbW1pc3Npb246IHRydWUsXHJcbiAgICAgIHJlcG9ydHM6IHRydWUsXHJcbiAgICAgIG1vZGlmeV9wYXltZW50czogdHJ1ZSxcclxuICAgICAgY2hpdF9jb2xsZWN0aW9uOiB0cnVlLFxyXG4gICAgICBsb2FuX2NvbGxlY3Rpb246IHRydWUsXHJcbiAgICAgIHBpZ21lX2NvbGxlY3Rpb246IHRydWUsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZGVzaWduYXRpb24vZ2V0LWRlc2lnbmF0aW9uXCIpO1xyXG4gICAgICBcclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICBkZXNpZ25hdGlvbl9jb2RlOiBncm91cD8uZGVzaWduYXRpb25fY29kZSxcclxuICAgICAgICAgIHRpdGxlOiBncm91cC50aXRsZSxcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgey8qIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmVlbi00MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1tZCBzaGFkb3cgaG92ZXI6Ym9yZGVyLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPENpRWRpdCBjb2xvcj1cImdyZWVuXCIgLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgIHRyaWdnZXI9e1snY2xpY2snXX1cclxuICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVBZ2VudHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkRGVzaWduYXRpb25cIiA/IGZvcm1EYXRhIDogdXBkYXRlRm9ybURhdGE7XHJcbiAgICBjb25zdCByZWdleCA9IHtcclxuICAgICAgZW1haWw6IC9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLFxyXG4gICAgICBwaG9uZTogL15bNi05XVxcZHs5fSQvLFxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoIWRhdGEudGl0bGUudHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5uYW1lID0gXCJUaXRsZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWRhdGUgPSB2YWxpZGF0ZUZvcm0oXCJhZGREZXNpZ25hdGlvblwiKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZGF0ZSkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgICBcIi9kZXNpZ25hdGlvbi9hZGQtZGVzaWduYXRpb25cIixcclxuICAgICAgICAgIGZvcm1EYXRhLFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICB0aXRsZTogXCJcIixcclxuICAgICAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICAgICAgY29sbGVjdGlvbjogdHJ1ZSxcclxuICAgICAgICAgICAgZGF5Ym9vazogdHJ1ZSxcclxuICAgICAgICAgICAgdGFyZ2V0czogdHJ1ZSxcclxuICAgICAgICAgICAgbGVhZHM6IHRydWUsXHJcbiAgICAgICAgICAgIGNvbW1pc3Npb246IHRydWUsXHJcbiAgICAgICAgICAgIHJlcG9ydHM6IHRydWUsXHJcbiAgICAgICAgICAgIG1vZGlmeV9wYXltZW50czogdHJ1ZSxcclxuICAgICAgICAgICAgY2hpdF9jb2xsZWN0aW9uOiB0cnVlLFxyXG4gICAgICBsb2FuX2NvbGxlY3Rpb246IHRydWUsXHJcbiAgICAgIHBpZ21lX2NvbGxlY3Rpb246IHRydWUsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJEZXNpZ25hdGlvbiBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIERlc2lnbmF0aW9uOlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBlcnJvci5yZXNwb25zZSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2VcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGAke2Vycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZX1gLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuXHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgICAgIHtrZXk6IFwiZGVzaWduYXRpb25fY29kZVwiLCBoZWFkZXI6IFwiRGVzaWduYXRpb24gQ29kZVwifSxcclxuICAgIHsga2V5OiBcInRpdGxlXCIsIGhlYWRlcjogXCJEZXNpZ25hdGlvbiBUaXRsZVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZXJzLmZpbHRlcigodXNlcikgPT5cclxuICAgIHVzZXIudGl0bGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvZGVzaWduYXRpb24vZ2V0LWRlc2lnbmF0aW9uLWJ5LWlkLyR7dXNlcklkfWBcclxuICAgICAgKTtcclxuICAgICAgc2V0Q3VycmVudFVzZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvZGVzaWduYXRpb24vZ2V0LWRlc2lnbmF0aW9uLWJ5LWlkLyR7dXNlcklkfWBcclxuICAgICAgKTtcclxuICAgICAgc2V0Q3VycmVudFVwZGF0ZVVzZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICB0aXRsZTogcmVzcG9uc2UuZGF0YS50aXRsZSxcclxuICAgICAgICBwZXJtaXNzaW9uOiB7XHJcbiAgICAgICAgICBjb2xsZWN0aW9uOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5wZXJtaXNzaW9uPy5jb2xsZWN0aW9uID09PSB0cnVlIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LnBlcm1pc3Npb24/LmNvbGxlY3Rpb24gPT09IFwidHJ1ZVwiLFxyXG4gICAgICAgICAgZGF5Ym9vazpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8ucGVybWlzc2lvbj8uZGF5Ym9vayA9PT0gdHJ1ZSB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5wZXJtaXNzaW9uPy5kYXlib29rID09PSBcInRydWVcIixcclxuICAgICAgICAgIHRhcmdldHM6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LnBlcm1pc3Npb24/LnRhcmdldHMgPT09IHRydWUgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8ucGVybWlzc2lvbj8udGFyZ2V0cyA9PT0gXCJ0cnVlXCIsXHJcbiAgICAgICAgICBsZWFkczpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8ucGVybWlzc2lvbj8ubGVhZHMgPT09IHRydWUgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8ucGVybWlzc2lvbj8ubGVhZHMgPT09IFwidHJ1ZVwiLFxyXG4gICAgICAgICAgY29tbWlzc2lvbjpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8ucGVybWlzc2lvbj8uY29tbWlzc2lvbiA9PT0gdHJ1ZSB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5wZXJtaXNzaW9uPy5jb21taXNzaW9uID09PSBcInRydWVcIixcclxuICAgICAgICAgIHJlcG9ydHM6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LnBlcm1pc3Npb24/LnJlcG9ydHMgPT09IHRydWUgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8ucGVybWlzc2lvbj8ucmVwb3J0cyA9PT0gXCJ0cnVlXCIsXHJcbiAgICAgICAgICBtb2RpZnlfcGF5bWVudHM6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LnBlcm1pc3Npb24/Lm1vZGlmeV9wYXltZW50cyA9PT0gdHJ1ZSB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5wZXJtaXNzaW9uPy5tb2RpZnlfcGF5bWVudHMgPT09IFwidHJ1ZVwiLFxyXG4gICAgICAgICAgY2hpdF9jb2xsZWN0aW9uOiBcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8ucGVybWlzc2lvbj8uY2hpdF9jb2xsZWN0aW9uID09PSB0cnVlIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LnBlcm1pc3Npb24/LmNoaXRfY29sbGVjdGlvbiA9PT0gXCJ0cnVlXCIsXHJcbiAgICAgIGxvYW5fY29sbGVjdGlvbjogXHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LnBlcm1pc3Npb24/LmxvYW5fY29sbGVjdGlvbiA9PT0gdHJ1ZSB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5wZXJtaXNzaW9uPy5sb2FuX2NvbGxlY3Rpb24gPT09IFwidHJ1ZVwiLFxyXG4gICAgICBwaWdtZV9jb2xsZWN0aW9uOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5wZXJtaXNzaW9uPy5waWdtZV9jb2xsZWN0aW9uID09PSB0cnVlIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LnBlcm1pc3Npb24/LnBpZ21lX2NvbGxlY3Rpb24gPT09IFwidHJ1ZVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIFxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVVc2VyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRVc2VyKSB7XHJcbiAgICAgICBcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvZGVzaWduYXRpb24vZGVsZXRlLWRlc2lnbmF0aW9uLyR7Y3VycmVudFVzZXIuX2lkfWApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIk1hbmFnZXIgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBtYW5hZ2VyOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgICBgL2Rlc2lnbmF0aW9uL3VwZGF0ZS1kZXNpZ25hdGlvbi8ke2N1cnJlbnRVcGRhdGVVc2VyLl9pZH1gLFxyXG4gICAgICAgICAgdXBkYXRlRm9ybURhdGFcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkRlc2lnbmF0aW9uIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIERlc2lnbmF0aW9uOlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBlcnJvci5yZXNwb25zZSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2VcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGAke2Vycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZX1gLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8U2V0dGluZ1NpZGViYXIgLz5cclxuICAgICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5EZXNpZ25hdGlvbnM8L2gxPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgKyBBZGQgZGVzaWduYXRpb25cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgeyhUYWJsZUFnZW50cy5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcpID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZUFnZW50cywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiRGVzaWduYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEVtcGxveWVlcy0ke1xyXG4gICAgICAgICAgICAgICAgICBUYWJsZUFnZW50cy5sZW5ndGggPiAwXHJcbiAgICAgICAgICAgICAgICAgICAgPyBUYWJsZUFnZW50c1swXS5uYW1lICtcclxuICAgICAgICAgICAgICAgICAgICAgIFwiIHRvIFwiICtcclxuICAgICAgICAgICAgICAgICAgICAgIFRhYmxlQWdlbnRzW1RhYmxlQWdlbnRzLmxlbmd0aCAtIDFdLm5hbWVcclxuICAgICAgICAgICAgICAgICAgICA6IFwiZW1wdHlcIlxyXG4gICAgICAgICAgICAgICAgfS5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e1RhYmxlQWdlbnRzLmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgZGF0YT1cIkRlc2lnbmF0aW9uIERhdGFcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd01vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBBZGQgZGVzaWduYXRpb25cclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVGl0bGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInRpdGxlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cInRpdGxlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgdGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy50aXRsZX08L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZFwiPlBlcm1pc3Npb25zPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIENvbGxlY3Rpb25cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5wZXJtaXNzaW9uLmNvbGxlY3Rpb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLnBlcm1pc3Npb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sbGVjdGlvbjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy12aW9sZXQtODAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5wZXJtaXNzaW9uLmNvbGxlY3Rpb24gPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRGF5Ym9va1xyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLnBlcm1pc3Npb24uZGF5Ym9va31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEucGVybWlzc2lvbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXlib29rOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItZm9jdXM6cmluZy12aW9sZXQtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLXZpb2xldC04MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBlcm1pc3Npb24uZGF5Ym9vayA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBUYXJnZXRzXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEucGVybWlzc2lvbi50YXJnZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5wZXJtaXNzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldHM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1mb2N1czpyaW5nLXZpb2xldC0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTgwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEucGVybWlzc2lvbi50YXJnZXRzID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+TGVhZHM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEucGVybWlzc2lvbi5sZWFkc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEucGVybWlzc2lvbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsZWFkczogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy12aW9sZXQtODAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5wZXJtaXNzaW9uLmxlYWRzID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIENvbW1pc3Npb25cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5wZXJtaXNzaW9uLmNvbW1pc3Npb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLnBlcm1pc3Npb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29tbWlzc2lvbjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy12aW9sZXQtODAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5wZXJtaXNzaW9uLmNvbW1pc3Npb24gPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgTW9kaWZ5IFBheW1lbnRzXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEucGVybWlzc2lvbi5tb2RpZnlfcGF5bWVudHN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLnBlcm1pc3Npb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kaWZ5X3BheW1lbnRzOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItZm9jdXM6cmluZy12aW9sZXQtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLXZpb2xldC04MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBlcm1pc3Npb24ubW9kaWZ5X3BheW1lbnRzID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJlcG9ydHNcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5wZXJtaXNzaW9uLnJlcG9ydHN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLnBlcm1pc3Npb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVwb3J0czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy12aW9sZXQtODAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5wZXJtaXNzaW9uLnJlcG9ydHMgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQ2hpdCBDb2xsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEucGVybWlzc2lvbi5jaGl0X2NvbGxlY3Rpb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLnBlcm1pc3Npb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2hpdF9jb2xsZWN0aW9uOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItZm9jdXM6cmluZy12aW9sZXQtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLXZpb2xldC04MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBlcm1pc3Npb24uY2hpdF9jb2xsZWN0aW9uID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIExvYW4gQ29sbGVjdGlvblxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLnBlcm1pc3Npb24ubG9hbl9jb2xsZWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5wZXJtaXNzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxvYW5fY29sbGVjdGlvbjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy12aW9sZXQtODAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5wZXJtaXNzaW9uLmxvYW5fY29sbGVjdGlvbiA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBQaWdteSBDb2xsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEucGVybWlzc2lvbi5waWdtZV9jb2xsZWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5wZXJtaXNzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBpZ21lX2NvbGxlY3Rpb246IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1mb2N1czpyaW5nLXZpb2xldC0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTgwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEucGVybWlzc2lvbi5waWdtZV9jb2xsZWN0aW9uID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMFxyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlciBib3JkZXItMiBib3JkZXItYmxhY2tcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTYXZlIGRlc2lnbmF0aW9uXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIFVwZGF0ZSBkZXNpZ25hdGlvblxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBUaXRsZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwidGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJ0aXRsZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIFRpdGxlXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy50aXRsZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnRpdGxlfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkXCI+UGVybWlzc2lvbnM8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQ29sbGVjdGlvblxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24uY29sbGVjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEucGVybWlzc2lvbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xsZWN0aW9uOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItZm9jdXM6cmluZy12aW9sZXQtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLXZpb2xldC04MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24uY29sbGVjdGlvbiA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBEYXlib29rXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEucGVybWlzc2lvbi5kYXlib29rfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRheWJvb2s6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1mb2N1czpyaW5nLXZpb2xldC0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTgwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEucGVybWlzc2lvbi5kYXlib29rID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRhcmdldHNcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLnRhcmdldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy12aW9sZXQtODAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLnRhcmdldHMgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5MZWFkczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLmxlYWRzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxlYWRzOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItZm9jdXM6cmluZy12aW9sZXQtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLXZpb2xldC04MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24ubGVhZHMgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQ29tbWlzc2lvblxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24uY29tbWlzc2lvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEucGVybWlzc2lvbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItZm9jdXM6cmluZy12aW9sZXQtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLXZpb2xldC04MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24uY29tbWlzc2lvbiA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBSZXBvcnRzXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEucGVybWlzc2lvbi5yZXBvcnRzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcG9ydHM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1mb2N1czpyaW5nLXZpb2xldC0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTgwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEucGVybWlzc2lvbi5yZXBvcnRzID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIE1vZGlmeSBQYXltZW50c1xyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24ubW9kaWZ5X3BheW1lbnRzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGlmeV9wYXltZW50czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy12aW9sZXQtODAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLm1vZGlmeV9wYXltZW50cyA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBDaGl0IENvbGxlY3Rpb25cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLmNoaXRfY29sbGVjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEucGVybWlzc2lvbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjaGl0X2NvbGxlY3Rpb246IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1mb2N1czpyaW5nLXZpb2xldC0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTgwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEucGVybWlzc2lvbi5jaGl0X2NvbGxlY3Rpb24gPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgTG9hbiBDb2xsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEucGVybWlzc2lvbi5sb2FuX2NvbGxlY3Rpb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hbl9jb2xsZWN0aW9uOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItZm9jdXM6cmluZy12aW9sZXQtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLXZpb2xldC04MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24ubG9hbl9jb2xsZWN0aW9uID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFBpZ215IENvbGxlY3Rpb25cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLnBpZ21lX2NvbGxlY3Rpb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLnBlcm1pc3Npb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGlnbWVfY29sbGVjdGlvbjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWZvY3VzOnJpbmctdmlvbGV0LTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy12aW9sZXQtODAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5wZXJtaXNzaW9uLnBpZ21lX2NvbGxlY3Rpb24gPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFVwZGF0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRVc2VyKG51bGwpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgRGVsZXRlIGRlc2lnbmF0aW9uXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50VXNlciAmJiAoXHJcbiAgICAgICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZVVzZXIoKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFVzZXIudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB0byBjb25maXJtIGRlbGV0aW9uLntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBkZXNpZ25hdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IERlc2lnbmF0aW9uO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRGVzaWduYXRpb24uanN4In0=