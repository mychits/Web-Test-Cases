import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PayInMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Banknote, ChevronRight, Zap, Shield, UserCheck, Sparkles, CreditCard, Link as LinkIcon, IndianRupee, FileText, BarChart3, Eye, X, Lock, AlertCircle, ArrowLeftRight, Calendar } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { Link, Link as RouterLink } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import api from "/src/instance/TokenInstance.js";
import { FiXCircle } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { HiCurrencyRupee } from "/node_modules/.vite/deps/react-icons_hi.js?v=819e0a34";
const PayInMenu = () => {
  _s();
  const [showOverviewModal, setShowOverviewModal] = useState(false);
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [isAuthenticatedForOverview, setIsAuthenticatedForOverview] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState("thisMonth");
  const [customFromDate, setCustomFromDate] = useState("");
  const [customToDate, setCustomToDate] = useState("");
  const [showCustomDatePicker, setShowCustomDatePicker] = useState(false);
  const [overviewData, setOverviewData] = useState({
    totalPaymentIn: 0,
    categories: [],
    loading: true,
    error: null
  });
  const formatLocalDate = (date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  };
  const getDateRange = (filter) => {
    const now = /* @__PURE__ */ new Date();
    let fromDate, toDate;
    switch (filter) {
      case "today":
        fromDate = formatLocalDate(now);
        toDate = formatLocalDate(now);
        break;
      case "yesterday":
        const yesterday = new Date(now);
        yesterday.setDate(yesterday.getDate() - 1);
        fromDate = formatLocalDate(yesterday);
        toDate = formatLocalDate(yesterday);
        break;
      case "thisMonth":
        const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
        const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        fromDate = formatLocalDate(firstDay);
        toDate = formatLocalDate(lastDay);
        break;
      case "lastMonth":
        const lastMonthFirstDay = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        const lastMonthLastDay = new Date(now.getFullYear(), now.getMonth(), 0);
        fromDate = formatLocalDate(lastMonthFirstDay);
        toDate = formatLocalDate(lastMonthLastDay);
        break;
      case "custom":
        fromDate = customFromDate || formatLocalDate(/* @__PURE__ */ new Date());
        toDate = customToDate || formatLocalDate(/* @__PURE__ */ new Date());
        break;
      default:
        fromDate = formatLocalDate(/* @__PURE__ */ new Date());
        toDate = formatLocalDate(/* @__PURE__ */ new Date());
    }
    return { fromDate, toDate };
  };
  const fetchPaymentReceiptData = async (fromDate, toDate) => {
    try {
      const response = await api.get("/payment/get-receipt-report", {
        params: {
          from_date: fromDate,
          to_date: toDate,
          groupId: "",
          userId: "",
          account_type: "",
          collected_by: "",
          admin_type: "",
          pay_for: ["Chit", "Pigme", "Loan", "Registration"]
        }
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching payment receipt data:", error);
      return [];
    }
  };
  const processPaymentData = (payments) => {
    const categoryMap = /* @__PURE__ */ new Map();
    payments.forEach((payment) => {
      let category = "Other";
      if (payment.pay_for) {
        if (payment.pay_for === "Pigme") {
          category = "PIGME PAYMENT";
        } else if (payment.pay_for === "Loan") {
          category = "LOAN PAYMENT";
        } else if (payment.pay_for === "Registration") {
          category = "REGISTRATION FEE";
        } else {
          category = payment.pay_for.toUpperCase();
        }
      } else if (payment.payment_type) {
        if (payment.payment_type === "Chit Payment") {
          category = "CHIT PAYMENT";
        } else {
          category = payment.payment_type.toUpperCase();
        }
      } else if (payment.pigme && Object.keys(payment.pigme).length > 0) {
        category = "PIGME PAYMENT";
      } else if (payment.loan && Object.keys(payment.loan).length > 0) {
        category = "LOAN PAYMENT";
      } else if (payment.payment_type) {
        category = payment.payment_type.toUpperCase();
      }
      const amount = parseFloat(payment.amount || 0);
      if (categoryMap.has(category)) {
        categoryMap.set(category, categoryMap.get(category) + amount);
      } else {
        categoryMap.set(category, amount);
      }
    });
    const categories = Array.from(categoryMap.entries()).map(([name, amount]) => {
      let cleanedName = name;
      if (name.includes("REG|CHIT")) {
        cleanedName = "REGISTRATION FEE";
      } else if (name.includes("REG|")) {
        cleanedName = "REGISTRATION FEE";
      }
      return { name: cleanedName, amount };
    }).sort((a, b) => b.amount - a.amount);
    const totalPaymentIn = categories.reduce((sum, cat) => sum + cat.amount, 0);
    return { categories, totalPaymentIn };
  };
  const loadOverviewData = async (filter = selectedFilter) => {
    const { fromDate, toDate } = getDateRange(filter);
    setOverviewData((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const payments = await fetchPaymentReceiptData(fromDate, toDate);
      if (!payments || payments.length === 0) {
        setOverviewData({
          totalPaymentIn: 0,
          categories: [],
          loading: false,
          error: null
        });
        return;
      }
      const { categories, totalPaymentIn } = processPaymentData(payments);
      setOverviewData({
        totalPaymentIn,
        categories,
        loading: false,
        error: null
      });
    } catch (err) {
      setOverviewData((prev) => ({
        ...prev,
        loading: false,
        error: err.message || "Failed to load data"
      }));
    }
  };
  const userRole = localStorage.getItem("userRole") || "superadmin";
  const isSuperAdmin = userRole === "superadmin";
  const handleOverviewClick = () => {
    if (!isSuperAdmin) {
      setPasswordError("Access denied: Only superadmin can view overview");
      setShowOverviewModal(true);
      return;
    }
    setPassword("");
    setPasswordError("");
    setIsAuthenticatedForOverview(false);
    setShowOverviewModal(true);
    setSelectedFilter("thisMonth");
    setCustomFromDate("");
    setCustomToDate("");
    setShowCustomDatePicker(false);
  };
  const verifyPasswordAndShowData = () => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    const validPassword = userObj?.password;
    if (password === "12345" && isSuperAdmin) {
      setIsAuthenticatedForOverview(true);
      setPasswordError("");
      loadOverviewData("thisMonth");
    } else {
      setPasswordError("Invalid password or insufficient privileges");
    }
  };
  const closeModal = () => {
    setShowOverviewModal(false);
    setPassword("");
    setPasswordError("");
    setIsAuthenticatedForOverview(false);
  };
  const handleFilterChange = (filter) => {
    setSelectedFilter(filter);
    if (filter === "custom") {
      setShowCustomDatePicker(true);
    } else {
      setShowCustomDatePicker(false);
      loadOverviewData(filter);
    }
  };
  const handleCustomDateApply = () => {
    if (customFromDate && customToDate) {
      loadOverviewData("custom");
    }
  };
  const getDateRangeDisplay = () => {
    const { fromDate, toDate } = getDateRange(selectedFilter);
    if (selectedFilter === "today") return "Today";
    if (selectedFilter === "yesterday") return "Yesterday";
    if (selectedFilter === "thisMonth") return "This Month";
    if (selectedFilter === "lastMonth") return "Last Month";
    if (selectedFilter === "custom") {
      if (customFromDate && customToDate) {
        return `${formatDisplayDate(customFromDate)} - ${formatDisplayDate(customToDate)}`;
      }
      return "Custom Range";
    }
    return "";
  };
  const formatDisplayDate = (dateStr) => {
    if (!dateStr) return "";
    const parts = dateStr.split("-");
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  };
  useEffect(() => {
    if (showOverviewModal) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [showOverviewModal]);
  const formatIndianNumber = (num) => {
    return num.toLocaleString("en-IN");
  };
  const paymentInMenuCategories = [
    {
      id: "#1",
      title: "Registration Fee",
      description: "Manage customer registration fee for joining Chit group records",
      icon: FileText,
      gradient: "from-violet-500 via-purple-500 to-pink-500",
      bgGradient: "from-violet-50 via-purple-50 to-pink-50",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/registration-fee",
      stats: "Registration-Fee Info",
      secondaryIcon: Shield,
      iconColor: "text-violet-600",
      bgColor: "bg-violet-100",
      section: "payment"
    },
    {
      id: "#2",
      title: "Payment Receipt",
      description: "Manage customer chit payment transaction information",
      icon: IndianRupee,
      gradient: "from-purple-500 via-indigo-500 to-violet-500",
      bgGradient: "from-purple-50 via-indigo-50 to-violet-50",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/payment",
      stats: "Chit Payment Info",
      secondaryIcon: UserCheck,
      iconColor: "text-purple-600",
      bgColor: "bg-purple-100",
      section: "payment"
    },
    {
      id: "#3",
      title: "Penalty payment Receipt",
      description: "Customer payments with penalty Receipt Management.",
      icon: IndianRupee,
      gradient: "from-amber-500 via-orange-500 to-red-500",
      bgGradient: "from-amber-50 via-orange-50 to-red-50",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/penalty-payment",
      stats: "Penalty Receipt Info",
      secondaryIcon: UserCheck,
      iconColor: "text-amber-600",
      bgColor: "bg-amber-100",
      section: "payment"
    },
    {
      id: "#7",
      title: "Employee Advance Repayment",
      description: "Employee Advance Repayment Management.",
      icon: HiCurrencyRupee,
      gradient: "from-blue-500 via-blue-600 to-indigo-600",
      bgGradient: "from-blue-50 via-indigo-50 to-blue-100",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/advance-payment-in",
      stats: "Advance Repayment",
      secondaryIcon: HiCurrencyRupee,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100",
      section: "employee"
    },
    {
      id: "#4",
      title: "Suspense Payments",
      description: "Manage customer Suspense chit payment transaction.",
      icon: IndianRupee,
      gradient: "from-sky-500 via-blue-500 to-indigo-500",
      bgGradient: "from-sky-50 via-blue-50 to-indigo-50",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/suspense-payments",
      stats: "Suspense Payment Info",
      secondaryIcon: UserCheck,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100",
      section: "payment"
    },
    {
      id: "#5",
      title: "Payment Links",
      description: "Manage customer chit payment link transaction information",
      icon: LinkIcon,
      gradient: "from-indigo-500 via-violet-500 to-cyan-500",
      bgGradient: "from-indigo-50 via-violet-50 to-cyan-50",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/payment-link-menu",
      stats: "Payment Link Info",
      secondaryIcon: CreditCard,
      iconColor: "text-indigo-600",
      bgColor: "bg-indigo-100",
      section: "payment"
    },
    {
      id: "#6",
      title: "Chit Transfer",
      description: "Manage customer chit Transfer payment transaction information.",
      icon: ArrowLeftRight,
      gradient: "from-red-500 via-violet-500 to-cyan-500",
      bgGradient: "from-red-50 via-violet-50 to-cyan-50",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/chit-transfer-pay-in",
      stats: "Chit Transfer Info",
      secondaryIcon: CreditCard,
      iconColor: "text-red-600",
      bgColor: "bg-red-100",
      section: "payment"
    }
  ];
  const paymentCategories = paymentInMenuCategories.filter(
    (item) => item.section === "payment"
  );
  const employeeCategories = paymentInMenuCategories.filter(
    (item) => item.section === "employee"
  );
  const SmallCard = ({ category, onClick }) => {
    const Icon = category.icon;
    const SecondaryIcon = category.secondaryIcon;
    const content = /* @__PURE__ */ jsxDEV("div", { className: "relative h-full overflow-hidden rounded-2xl bg-white/90 backdrop-blur-sm border border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-2xl bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity duration-500 p-[1px]", children: /* @__PURE__ */ jsxDEV("div", { className: `w-full h-full rounded-2xl bg-gradient-to-r ${category.gradient}` }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 419,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 418,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative h-full bg-white rounded-2xl p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `absolute top-2 right-2 w-20 h-20 rounded-full bg-gradient-to-br ${category.bgGradient} opacity-20 blur-xl` }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 422,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: `relative w-10 h-10 rounded-xl ${category.bgColor} flex items-center justify-center shadow-md group-hover:scale-105 transition-transform duration-300`, children: /* @__PURE__ */ jsxDEV(Icon, { className: `w-5 h-5 ${category.iconColor}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 425,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 424,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-1.5 rounded-xl bg-slate-50 shadow-sm opacity-0 group-hover:opacity-100 transition-all duration-300", children: /* @__PURE__ */ jsxDEV(SecondaryIcon, { className: "w-3.5 h-3.5 text-slate-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 428,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 427,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 423,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-slate-800 mb-1 group-hover:text-purple-700 transition-colors duration-300", children: category.title }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 432,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 leading-relaxed line-clamp-2", children: category.description }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 435,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 431,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-3 border-t border-slate-100", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-medium text-slate-400 uppercase tracking-wider", children: category.stats }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 440,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 text-purple-500 opacity-0 group-hover:opacity-100 transition-all duration-300", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold", children: "Explore" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 444,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 445,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 443,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 439,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 421,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
      lineNumber: 417,
      columnNumber: 5
    }, this);
    if (onClick) {
      return /* @__PURE__ */ jsxDEV("div", { onClick, className: "group cursor-pointer", children: content }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 452,
        columnNumber: 14
      }, this);
    }
    return /* @__PURE__ */ jsxDEV(RouterLink, { to: category.href, className: "group block", children: content }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
      lineNumber: 454,
      columnNumber: 12
    }, this);
  };
  const overviewCard = {
    id: "overview",
    title: "Overview",
    description: "View complete payment summary (Superadmin only)",
    icon: BarChart3,
    gradient: "from-emerald-500 via-teal-500 to-cyan-500",
    bgGradient: "from-emerald-50 via-teal-50 to-cyan-50",
    stats: "Superadmin Protected",
    secondaryIcon: Eye,
    iconColor: "text-emerald-600",
    bgColor: "bg-emerald-100"
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full relative overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 473,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 relative", children: [
        /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 475,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-6 relative", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 477,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-1 bg-gradient-to-r from-violet-600 to-purple-600 rounded-xl blur-md opacity-75 group-hover:opacity-100 transition duration-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 481,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg", children: /* @__PURE__ */ jsxDEV(Banknote, { className: "w-6 h-6 text-white" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 483,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 482,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 480,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold bg-gradient-to-r from-slate-800 via-purple-800 to-slate-800 bg-clip-text text-transparent", children: "Payment-In Management" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 487,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500 text-sm mt-0.5", children: "Manage and view payment-in information and transactions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 490,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 486,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 479,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 478,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-12", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-900 mb-6 border-b pb-3", children: "Payment Section" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 498,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 lg:grid-cols-4 gap-4", children: [
              paymentCategories.map(
                (category) => /* @__PURE__ */ jsxDEV(SmallCard, { category }, category.id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 504,
                  columnNumber: 17
                }, this)
              ),
              /* @__PURE__ */ jsxDEV(SmallCard, { category: overviewCard, onClick: handleOverviewClick }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 506,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 502,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 497,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-12", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-900 mb-6 border-b pb-3", children: "Employee Section" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 511,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 lg:grid-cols-4 gap-4", children: employeeCategories.map(
              (category) => /* @__PURE__ */ jsxDEV(SmallCard, { category }, category.id, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 517,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 515,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 510,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative p-5 bg-gradient-to-br from-violet-50 via-purple-50 to-pink-50 rounded-2xl border border-white/40 shadow-md overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-violet-200/20 to-transparent rounded-full blur-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 523,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-purple-200/20 to-transparent rounded-full blur-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 524,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-start gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-1 bg-gradient-to-r from-violet-400 to-purple-400 rounded-xl blur-md opacity-50" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 527,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative w-10 h-10 rounded-xl bg-white shadow-md flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-5 h-5 text-violet-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 529,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 528,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 526,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-slate-800 flex items-center gap-2 mb-1", children: [
                  "Quick Tips",
                  /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-4 h-4 text-violet-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                    lineNumber: 535,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 533,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 text-sm leading-relaxed", children: "Use Registration-Fee, Payment Receipt, Penalty, Suspense & Payment Links directories." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 537,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 text-sm leading-relaxed mt-1", children: [
                  "📊 ",
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Overview card" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                    lineNumber: 541,
                    columnNumber: 24
                  }, this),
                  " is protected — only Superadmin can view real payment-in totals (fetched from live API)."
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 540,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 532,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 525,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 522,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 476,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 474,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
      lineNumber: 472,
      columnNumber: 7
    }, this),
    showOverviewModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "relative bg-white rounded-2xl w-full max-w-3xl max-h-[85vh] overflow-y-auto shadow-2xl", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-emerald-100 rounded-xl", children: /* @__PURE__ */ jsxDEV(BarChart3, { className: "w-5 h-5 text-emerald-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 557,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 556,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-slate-800", children: "Payment In Overview" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 559,
            columnNumber: 17
          }, this),
          isSuperAdmin && !isAuthenticatedForOverview && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full", children: "Superadmin required" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 561,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 555,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: closeModal, className: "p-1.5 rounded-lg hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5 text-slate-500" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 565,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 564,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 554,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-3", children: !isAuthenticatedForOverview ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 p-4 bg-amber-50 rounded-xl border border-amber-200", children: [
          /* @__PURE__ */ jsxDEV(Lock, { className: "w-5 h-5 text-amber-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 573,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-amber-800", children: "This section contains sensitive payment statistics. Only Superadmin can access." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 574,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 572,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Enter Superadmin Password" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 577,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              value: password,
              onChange: (e) => setPassword(e.target.value),
              onKeyDown: (e) => e.key === "Enter" && verifyPasswordAndShowData(),
              className: "w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none",
              placeholder: "••••••••",
              autoFocus: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 578,
              columnNumber: 21
            },
            this
          ),
          passwordError && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-sm text-red-600 bg-red-50 p-2 rounded-lg", children: [
            /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-4 h-4" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 589,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: passwordError }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 590,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 588,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: verifyPasswordAndShowData,
              className: "w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold rounded-xl hover:shadow-lg transition-all",
              children: "Unlock Overview"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 593,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400 text-center mt-2", children: [
            "Demo password: ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-mono", children: "12345" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 599,
              columnNumber: 91
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 599,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 576,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 571,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 ", children: [
              /* @__PURE__ */ jsxDEV(Calendar, { className: "w-4 h-4 text-slate-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 608,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-slate-700 ", children: "Filter by Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 609,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 607,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: selectedFilter,
                onChange: (e) => handleFilterChange(e.target.value),
                className: "ml-auto px-3 py-1 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white min-w-[140px]",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "today", children: "Today" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                    lineNumber: 617,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "yesterday", children: "Yesterday" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                    lineNumber: 618,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "thisMonth", children: "This Month" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                    lineNumber: 619,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "lastMonth", children: "Last Month" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                    lineNumber: 620,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "custom", children: "Custom Range" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                    lineNumber: 621,
                    columnNumber: 25
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 612,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 606,
            columnNumber: 21
          }, this),
          showCustomDatePicker && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-700 mb-1", children: "From Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 630,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    value: customFromDate,
                    onChange: (e) => setCustomFromDate(e.target.value),
                    className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-sm"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                    lineNumber: 631,
                    columnNumber: 29
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 629,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-700 mb-1", children: "To Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 639,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    value: customToDate,
                    onChange: (e) => setCustomToDate(e.target.value),
                    className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-sm"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                    lineNumber: 640,
                    columnNumber: 29
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 638,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 628,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleCustomDateApply,
                disabled: !customFromDate || !customToDate,
                className: `w-full py-2 text-sm font-medium rounded-lg transition-all ${customFromDate && customToDate ? "bg-emerald-600 text-white hover:bg-emerald-700" : "bg-gray-300 text-gray-500 cursor-not-allowed"}`,
                children: "Apply Custom Range"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 648,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 627,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 605,
          columnNumber: 19
        }, this),
        overviewData.loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-10", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 672,
          columnNumber: 23
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 671,
          columnNumber: 15
        }, this) : overviewData.error ? /* @__PURE__ */ jsxDEV("div", { className: "text-red-600 text-center py-4", children: [
          "Error: ",
          overviewData.error
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 675,
          columnNumber: 15
        }, this) : overviewData.categories.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8 text-slate-500", children: "No payment data found for the selected date range." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 677,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-50 to-purple-50 rounded-xl p-3 border border-violet-100", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-violet-700", children: "TOTAL PAYMENT IN" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 685,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(IndianRupee, { className: "w-4 h-4 text-violet-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 686,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 684,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-slate-800 mt-1", children: [
              "₹ ",
              formatIndianNumber(overviewData.totalPaymentIn)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 688,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 mt-1", children: "For selected date range" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 691,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 683,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-md font-bold text-slate-800 mb-3 flex items-center gap-2 mt-3", children: "Payment In Categories" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 698,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 max-h-[300px] overflow-y-auto", children: overviewData.categories.map(
              (cat, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-slate-700", children: cat.name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 702,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-slate-800", children: [
                  "₹ ",
                  formatIndianNumber(cat.amount)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                  lineNumber: 703,
                  columnNumber: 31
                }, this)
              ] }, idx, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
                lineNumber: 701,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
              lineNumber: 699,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 697,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-slate-400 italic border-t pt-3 mt-2", children: "* Data fetched from live API. Categories are grouped by payment type." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
            lineNumber: 710,
            columnNumber: 23
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
          lineNumber: 681,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 603,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
        lineNumber: 569,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
      lineNumber: 553,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
      lineNumber: 552,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("style", { jsx: true, children: `
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
      lineNumber: 722,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx",
    lineNumber: 471,
    columnNumber: 5
  }, this);
};
_s(PayInMenu, "8SQSUBl6vSS0eRSJ/mKM8966VXk=");
_c = PayInMenu;
export default PayInMenu;
var _c;
$RefreshReg$(_c, "PayInMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayInMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa2FVLFNBc1FVLFVBdFFWOzJCQWxhVjtBQUFtQkEsb0JBQWlCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFVBQVVDLGNBQWNDLEtBQUtDLFFBQVFDLFdBQVdDLFVBQVVDLFlBQVlDLFFBQVFDLFVBQVVDLGFBQWFDLFVBQVVDLFdBQVdDLEtBQUtDLEdBQUdDLE1BQU1DLGFBQWFDLGdCQUFnQkMsZ0JBQWdCO0FBQzlMLFNBQVNWLE1BQU1BLFFBQVFXLGtCQUFrQjtBQUN6QyxPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsdUJBQXVCO0FBRWhDLE1BQU1DLFlBQVlBLE1BQU07QUFBQUMsS0FBQTtBQUV0QixRQUFNLENBQUNDLG1CQUFtQkMsb0JBQW9CLElBQUlDLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSUYsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ0csZUFBZUMsZ0JBQWdCLElBQUlKLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNLLDRCQUE0QkMsNkJBQTZCLElBQUlOLFNBQVMsS0FBSztBQUdsRixRQUFNLENBQUNPLGdCQUFnQkMsaUJBQWlCLElBQUlSLFNBQVMsV0FBVztBQUNoRSxRQUFNLENBQUNTLGdCQUFnQkMsaUJBQWlCLElBQUlWLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNXLGNBQWNDLGVBQWUsSUFBSVosU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ2Esc0JBQXNCQyx1QkFBdUIsSUFBSWQsU0FBUyxLQUFLO0FBR3RFLFFBQU0sQ0FBQ2UsY0FBY0MsZUFBZSxJQUFJaEIsU0FBUztBQUFBLElBQy9DaUIsZ0JBQWdCO0FBQUEsSUFDaEJDLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsT0FBTztBQUFBLEVBQ1QsQ0FBQztBQUdELFFBQU1DLGtCQUFrQkEsQ0FBQ0MsU0FBUztBQUNoQyxVQUFNQyxJQUFJRCxLQUFLRSxZQUFZO0FBQzNCLFVBQU1DLElBQUlDLE9BQU9KLEtBQUtLLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQ3JELFVBQU1DLElBQUlILE9BQU9KLEtBQUtRLFFBQVEsQ0FBQyxFQUFFRixTQUFTLEdBQUcsR0FBRztBQUNoRCxXQUFPLEdBQUdMLENBQUMsSUFBSUUsQ0FBQyxJQUFJSSxDQUFDO0FBQUEsRUFDdkI7QUFHQSxRQUFNRSxlQUFlQSxDQUFDQyxXQUFXO0FBQy9CLFVBQU1DLE1BQU0sb0JBQUlDLEtBQUs7QUFDckIsUUFBSUMsVUFBVUM7QUFFZCxZQUFRSixRQUFNO0FBQUEsTUFDWixLQUFLO0FBQ0hHLG1CQUFXZCxnQkFBZ0JZLEdBQUc7QUFDOUJHLGlCQUFTZixnQkFBZ0JZLEdBQUc7QUFDNUI7QUFBQSxNQUNGLEtBQUs7QUFDSCxjQUFNSSxZQUFZLElBQUlILEtBQUtELEdBQUc7QUFDOUJJLGtCQUFVQyxRQUFRRCxVQUFVUCxRQUFRLElBQUksQ0FBQztBQUN6Q0ssbUJBQVdkLGdCQUFnQmdCLFNBQVM7QUFDcENELGlCQUFTZixnQkFBZ0JnQixTQUFTO0FBQ2xDO0FBQUEsTUFDRixLQUFLO0FBQ0gsY0FBTUUsV0FBVyxJQUFJTCxLQUFLRCxJQUFJVCxZQUFZLEdBQUdTLElBQUlOLFNBQVMsR0FBRyxDQUFDO0FBQzlELGNBQU1hLFVBQVUsSUFBSU4sS0FBS0QsSUFBSVQsWUFBWSxHQUFHUyxJQUFJTixTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFUSxtQkFBV2QsZ0JBQWdCa0IsUUFBUTtBQUNuQ0gsaUJBQVNmLGdCQUFnQm1CLE9BQU87QUFDaEM7QUFBQSxNQUNGLEtBQUs7QUFDSCxjQUFNQyxvQkFBb0IsSUFBSVAsS0FBS0QsSUFBSVQsWUFBWSxHQUFHUyxJQUFJTixTQUFTLElBQUksR0FBRyxDQUFDO0FBQzNFLGNBQU1lLG1CQUFtQixJQUFJUixLQUFLRCxJQUFJVCxZQUFZLEdBQUdTLElBQUlOLFNBQVMsR0FBRyxDQUFDO0FBQ3RFUSxtQkFBV2QsZ0JBQWdCb0IsaUJBQWlCO0FBQzVDTCxpQkFBU2YsZ0JBQWdCcUIsZ0JBQWdCO0FBQ3pDO0FBQUEsTUFDRixLQUFLO0FBQ0hQLG1CQUFXMUIsa0JBQWtCWSxnQkFBZ0Isb0JBQUlhLEtBQUssQ0FBQztBQUN2REUsaUJBQVN6QixnQkFBZ0JVLGdCQUFnQixvQkFBSWEsS0FBSyxDQUFDO0FBQ25EO0FBQUEsTUFDRjtBQUNFQyxtQkFBV2QsZ0JBQWdCLG9CQUFJYSxLQUFLLENBQUM7QUFDckNFLGlCQUFTZixnQkFBZ0Isb0JBQUlhLEtBQUssQ0FBQztBQUFBLElBQ3ZDO0FBRUEsV0FBTyxFQUFFQyxVQUFVQyxPQUFPO0FBQUEsRUFDNUI7QUFHQSxRQUFNTywwQkFBMEIsT0FBT1IsVUFBVUMsV0FBVztBQUMxRCxRQUFJO0FBQ0YsWUFBTVEsV0FBVyxNQUFNbkQsSUFBSW9ELElBQUksK0JBQStCO0FBQUEsUUFDNURDLFFBQVE7QUFBQSxVQUNOQyxXQUFXWjtBQUFBQSxVQUNYYSxTQUFTWjtBQUFBQSxVQUNUYSxTQUFTO0FBQUEsVUFDVEMsUUFBUTtBQUFBLFVBQ1JDLGNBQWM7QUFBQSxVQUNkQyxjQUFjO0FBQUEsVUFDZEMsWUFBWTtBQUFBLFVBQ1pDLFNBQVMsQ0FBQyxRQUFRLFNBQVMsUUFBUSxjQUFjO0FBQUEsUUFDbkQ7QUFBQSxNQUNGLENBQUM7QUFFRCxhQUFPVixTQUFTVztBQUFBQSxJQUNsQixTQUFTbkMsT0FBTztBQUNkb0MsY0FBUXBDLE1BQU0sd0NBQXdDQSxLQUFLO0FBQzNELGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUdBLFFBQU1xQyxxQkFBcUJBLENBQUNDLGFBQWE7QUFDdkMsVUFBTUMsY0FBYyxvQkFBSUMsSUFBSTtBQUU1QkYsYUFBU0csUUFBUSxDQUFBQyxZQUFXO0FBRTFCLFVBQUlDLFdBQVc7QUFHZixVQUFJRCxRQUFRUixTQUFTO0FBQ25CLFlBQUlRLFFBQVFSLFlBQVksU0FBUztBQUMvQlMscUJBQVc7QUFBQSxRQUNiLFdBQVdELFFBQVFSLFlBQVksUUFBUTtBQUNyQ1MscUJBQVc7QUFBQSxRQUNiLFdBQVdELFFBQVFSLFlBQVksZ0JBQWdCO0FBQzdDUyxxQkFBVztBQUFBLFFBQ2IsT0FBTztBQUNMQSxxQkFBV0QsUUFBUVIsUUFBUVUsWUFBWTtBQUFBLFFBQ3pDO0FBQUEsTUFDRixXQUVTRixRQUFRRyxjQUFjO0FBQzdCLFlBQUlILFFBQVFHLGlCQUFpQixnQkFBZ0I7QUFDM0NGLHFCQUFXO0FBQUEsUUFDYixPQUFPO0FBQ0xBLHFCQUFXRCxRQUFRRyxhQUFhRCxZQUFZO0FBQUEsUUFDOUM7QUFBQSxNQUNGLFdBRVNGLFFBQVFJLFNBQVNDLE9BQU9DLEtBQUtOLFFBQVFJLEtBQUssRUFBRUcsU0FBUyxHQUFHO0FBQy9ETixtQkFBVztBQUFBLE1BQ2IsV0FDU0QsUUFBUVEsUUFBUUgsT0FBT0MsS0FBS04sUUFBUVEsSUFBSSxFQUFFRCxTQUFTLEdBQUc7QUFDN0ROLG1CQUFXO0FBQUEsTUFDYixXQUVTRCxRQUFRRyxjQUFjO0FBQzdCRixtQkFBV0QsUUFBUUcsYUFBYUQsWUFBWTtBQUFBLE1BQzlDO0FBR0EsWUFBTU8sU0FBU0MsV0FBV1YsUUFBUVMsVUFBVSxDQUFDO0FBRTdDLFVBQUlaLFlBQVljLElBQUlWLFFBQVEsR0FBRztBQUM3Qkosb0JBQVllLElBQUlYLFVBQVVKLFlBQVlkLElBQUlrQixRQUFRLElBQUlRLE1BQU07QUFBQSxNQUM5RCxPQUFPO0FBQ0xaLG9CQUFZZSxJQUFJWCxVQUFVUSxNQUFNO0FBQUEsTUFDbEM7QUFBQSxJQUNGLENBQUM7QUFHRCxVQUFNckQsYUFBYXlELE1BQU1DLEtBQUtqQixZQUFZa0IsUUFBUSxDQUFDLEVBQ2hEQyxJQUFJLENBQUMsQ0FBQ0MsTUFBTVIsTUFBTSxNQUFNO0FBRXZCLFVBQUlTLGNBQWNEO0FBQ2xCLFVBQUlBLEtBQUtFLFNBQVMsVUFBVSxHQUFHO0FBQzdCRCxzQkFBYztBQUFBLE1BQ2hCLFdBQVdELEtBQUtFLFNBQVMsTUFBTSxHQUFHO0FBQ2hDRCxzQkFBYztBQUFBLE1BQ2hCO0FBQ0EsYUFBTyxFQUFFRCxNQUFNQyxhQUFhVCxPQUFPO0FBQUEsSUFDckMsQ0FBQyxFQUNBVyxLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUViLFNBQVNZLEVBQUVaLE1BQU07QUFFckMsVUFBTXRELGlCQUFpQkMsV0FBV21FLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsTUFBTUMsSUFBSWhCLFFBQVEsQ0FBQztBQUUxRSxXQUFPLEVBQUVyRCxZQUFZRCxlQUFlO0FBQUEsRUFDdEM7QUFHQSxRQUFNdUUsbUJBQW1CLE9BQU94RCxTQUFTekIsbUJBQW1CO0FBQzFELFVBQU0sRUFBRTRCLFVBQVVDLE9BQU8sSUFBSUwsYUFBYUMsTUFBTTtBQUVoRGhCLG9CQUFnQixDQUFBeUUsVUFBUyxFQUFFLEdBQUdBLE1BQU10RSxTQUFTLE1BQU1DLE9BQU8sS0FBSyxFQUFFO0FBQ2pFLFFBQUk7QUFDRixZQUFNc0MsV0FBVyxNQUFNZix3QkFBd0JSLFVBQVVDLE1BQU07QUFFL0QsVUFBSSxDQUFDc0IsWUFBWUEsU0FBU1csV0FBVyxHQUFHO0FBQ3RDckQsd0JBQWdCO0FBQUEsVUFDZEMsZ0JBQWdCO0FBQUEsVUFDaEJDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsT0FBTztBQUFBLFFBQ1QsQ0FBQztBQUNEO0FBQUEsTUFDRjtBQUVBLFlBQU0sRUFBRUYsWUFBWUQsZUFBZSxJQUFJd0MsbUJBQW1CQyxRQUFRO0FBRWxFMUMsc0JBQWdCO0FBQUEsUUFDZEM7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUMsU0FBUztBQUFBLFFBQ1RDLE9BQU87QUFBQSxNQUNULENBQUM7QUFBQSxJQUNILFNBQVNzRSxLQUFLO0FBQ1oxRSxzQkFBZ0IsQ0FBQXlFLFVBQVM7QUFBQSxRQUN2QixHQUFHQTtBQUFBQSxRQUNIdEUsU0FBUztBQUFBLFFBQ1RDLE9BQU9zRSxJQUFJQyxXQUFXO0FBQUEsTUFDeEIsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBR0EsUUFBTUMsV0FBV0MsYUFBYUMsUUFBUSxVQUFVLEtBQUs7QUFDckQsUUFBTUMsZUFBZUgsYUFBYTtBQUVsQyxRQUFNSSxzQkFBc0JBLE1BQU07QUFDaEMsUUFBSSxDQUFDRCxjQUFjO0FBQ2pCM0YsdUJBQWlCLGtEQUFrRDtBQUNuRUwsMkJBQXFCLElBQUk7QUFDekI7QUFBQSxJQUNGO0FBQ0FHLGdCQUFZLEVBQUU7QUFDZEUscUJBQWlCLEVBQUU7QUFDbkJFLGtDQUE4QixLQUFLO0FBQ25DUCx5QkFBcUIsSUFBSTtBQUN6QlMsc0JBQWtCLFdBQVc7QUFDN0JFLHNCQUFrQixFQUFFO0FBQ3BCRSxvQkFBZ0IsRUFBRTtBQUNsQkUsNEJBQXdCLEtBQUs7QUFBQSxFQUMvQjtBQUVBLFFBQU1tRiw0QkFBNEJBLE1BQU07QUFDdEMsVUFBTUMsT0FBT0wsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1LLFVBQVVDLEtBQUtDLE1BQU1ILElBQUk7QUFDL0IsVUFBTUksZ0JBQWdCSCxTQUFTbEc7QUFDL0IsUUFBSUEsYUFBYSxXQUFXOEYsY0FBYztBQUN4Q3pGLG9DQUE4QixJQUFJO0FBQ2xDRix1QkFBaUIsRUFBRTtBQUNuQm9GLHVCQUFpQixXQUFXO0FBQUEsSUFDOUIsT0FBTztBQUNMcEYsdUJBQWlCLDZDQUE2QztBQUFBLElBQ2hFO0FBQUEsRUFDRjtBQUVBLFFBQU1tRyxhQUFhQSxNQUFNO0FBQ3ZCeEcseUJBQXFCLEtBQUs7QUFDMUJHLGdCQUFZLEVBQUU7QUFDZEUscUJBQWlCLEVBQUU7QUFDbkJFLGtDQUE4QixLQUFLO0FBQUEsRUFDckM7QUFHQSxRQUFNa0cscUJBQXFCQSxDQUFDeEUsV0FBVztBQUNyQ3hCLHNCQUFrQndCLE1BQU07QUFDeEIsUUFBSUEsV0FBVyxVQUFVO0FBQ3ZCbEIsOEJBQXdCLElBQUk7QUFBQSxJQUM5QixPQUFPO0FBQ0xBLDhCQUF3QixLQUFLO0FBQzdCMEUsdUJBQWlCeEQsTUFBTTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUdBLFFBQU15RSx3QkFBd0JBLE1BQU07QUFDbEMsUUFBSWhHLGtCQUFrQkUsY0FBYztBQUNsQzZFLHVCQUFpQixRQUFRO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBR0EsUUFBTWtCLHNCQUFzQkEsTUFBTTtBQUNoQyxVQUFNLEVBQUV2RSxVQUFVQyxPQUFPLElBQUlMLGFBQWF4QixjQUFjO0FBQ3hELFFBQUlBLG1CQUFtQixRQUFTLFFBQU87QUFDdkMsUUFBSUEsbUJBQW1CLFlBQWEsUUFBTztBQUMzQyxRQUFJQSxtQkFBbUIsWUFBYSxRQUFPO0FBQzNDLFFBQUlBLG1CQUFtQixZQUFhLFFBQU87QUFDM0MsUUFBSUEsbUJBQW1CLFVBQVU7QUFDL0IsVUFBSUUsa0JBQWtCRSxjQUFjO0FBQ2xDLGVBQU8sR0FBR2dHLGtCQUFrQmxHLGNBQWMsQ0FBQyxNQUFNa0csa0JBQWtCaEcsWUFBWSxDQUFDO0FBQUEsTUFDbEY7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTWdHLG9CQUFvQkEsQ0FBQ0MsWUFBWTtBQUNyQyxRQUFJLENBQUNBLFFBQVMsUUFBTztBQUNyQixVQUFNQyxRQUFRRCxRQUFRRSxNQUFNLEdBQUc7QUFDL0IsV0FBTyxHQUFHRCxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQzVDO0FBR0EzSSxZQUFVLE1BQU07QUFDZCxRQUFJNEIsbUJBQW1CO0FBQ3JCaUgsZUFBU0MsS0FBS0MsTUFBTUMsV0FBVztBQUFBLElBQ2pDLE9BQU87QUFDTEgsZUFBU0MsS0FBS0MsTUFBTUMsV0FBVztBQUFBLElBQ2pDO0FBQ0EsV0FBTyxNQUFNO0FBQ1hILGVBQVNDLEtBQUtDLE1BQU1DLFdBQVc7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxDQUFDcEgsaUJBQWlCLENBQUM7QUFFdEIsUUFBTXFILHFCQUFxQkEsQ0FBQ0MsUUFBUTtBQUNsQyxXQUFPQSxJQUFJQyxlQUFlLE9BQU87QUFBQSxFQUNuQztBQUdBLFFBQU1DLDBCQUEwQjtBQUFBLElBQzlCO0FBQUEsTUFDRUMsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTNJO0FBQUFBLE1BQ040SSxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZXZKO0FBQUFBLE1BQ2Z3SixXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RDLFNBQVM7QUFBQSxJQUNYO0FBQUEsSUFDQTtBQUFBLE1BQ0VYLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU01STtBQUFBQSxNQUNONkksVUFBVTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxNQUNaQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLGVBQWV0SjtBQUFBQSxNQUNmdUosV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFWCxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNNUk7QUFBQUEsTUFDTjZJLFVBQVU7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxlQUFldEo7QUFBQUEsTUFDZnVKLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsTUFDVEMsU0FBUztBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsTUFDRVgsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTS9IO0FBQUFBLE1BQ05nSSxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZXBJO0FBQUFBLE1BQ2ZxSSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RDLFNBQVM7QUFBQSxJQUNYO0FBQUEsSUFDQTtBQUFBLE1BQ0VYLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU01STtBQUFBQSxNQUNONkksVUFBVTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxNQUNaQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLGVBQWV0SjtBQUFBQSxNQUNmdUosV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFWCxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNN0k7QUFBQUEsTUFDTjhJLFVBQVU7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxlQUFlcEo7QUFBQUEsTUFDZnFKLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsTUFDVEMsU0FBUztBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsTUFDRVgsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTXJJO0FBQUFBLE1BQ05zSSxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZXBKO0FBQUFBLE1BQ2ZxSixXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RDLFNBQVM7QUFBQSxJQUNYO0FBQUEsRUFBQztBQUdILFFBQU1DLG9CQUFvQmIsd0JBQXdCdEY7QUFBQUEsSUFDaEQsQ0FBQ29HLFNBQVNBLEtBQUtGLFlBQVk7QUFBQSxFQUM3QjtBQUVBLFFBQU1HLHFCQUFxQmYsd0JBQXdCdEY7QUFBQUEsSUFDakQsQ0FBQ29HLFNBQVNBLEtBQUtGLFlBQVk7QUFBQSxFQUM3QjtBQUVBLFFBQU1JLFlBQVlBLENBQUMsRUFBRXZFLFVBQVV3RSxRQUFRLE1BQU07QUFDM0MsVUFBTUMsT0FBT3pFLFNBQVMyRDtBQUN0QixVQUFNZSxnQkFBZ0IxRSxTQUFTZ0U7QUFDL0IsVUFBTVcsVUFDSix1QkFBQyxTQUFJLFdBQVUsd0xBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkhBQ2IsaUNBQUMsU0FBSSxXQUFXLDhDQUE4QzNFLFNBQVM0RCxRQUFRLE1BQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUYsS0FEckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVcsbUVBQW1FNUQsU0FBUzZELFVBQVUseUJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkg7QUFBQSxRQUM3SCx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVcsaUNBQWlDN0QsU0FBU2tFLE9BQU8sdUdBQy9ELGlDQUFDLFFBQUssV0FBVyxXQUFXbEUsU0FBU2lFLFNBQVMsTUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdHQUNiLGlDQUFDLGlCQUFjLFdBQVUsZ0NBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFELEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsc0dBQ1hqRSxtQkFBU3lELFNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHVEQUNWekQsbUJBQVMwRCxlQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLG9FQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLG1FQUNiMUQsbUJBQVMrRCxTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5R0FDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSx5QkFBd0IsdUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStDO0FBQUEsWUFDL0MsdUJBQUMsZ0JBQWEsV0FBVSxpQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxlQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsU0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdDQTtBQUVGLFFBQUlTLFNBQVM7QUFDWCxhQUFPLHVCQUFDLFNBQUksU0FBa0IsV0FBVSx3QkFBd0JHLHFCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsSUFDMUU7QUFDQSxXQUFPLHVCQUFDLGNBQVcsSUFBSTNFLFNBQVM4RCxNQUFNLFdBQVUsZUFBZWEscUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0U7QUFBQSxFQUN6RTtBQUVBLFFBQU1DLGVBQWU7QUFBQSxJQUNuQnBCLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLElBQ2JDLE1BQU0xSTtBQUFBQSxJQUNOMkksVUFBVTtBQUFBLElBQ1ZDLFlBQVk7QUFBQSxJQUNaRSxPQUFPO0FBQUEsSUFDUEMsZUFBZTlJO0FBQUFBLElBQ2YrSSxXQUFXO0FBQUEsSUFDWEMsU0FBUztBQUFBLEVBQ1g7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLCtCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsUUFDekIsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQ1gsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9KQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdLO0FBQUEsY0FDaEssdUJBQUMsU0FBSSxXQUFVLDRIQUNiLGlDQUFDLFlBQVMsV0FBVSx3QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsZ0hBQStHLHFDQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLHVFQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdURBQXNELCtCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1pFO0FBQUFBLGdDQUFrQnJEO0FBQUFBLGdCQUFJLENBQUNmLGFBQ3RCLHVCQUFDLGFBQTRCLFlBQWJBLFNBQVN3RCxJQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRDtBQUFBLGNBQ2pEO0FBQUEsY0FDRCx1QkFBQyxhQUFVLFVBQVVvQixjQUFjLFNBQVMzQyx1QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxpQkFKbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdURBQXNELGdDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1pxQyw2QkFBbUJ2RDtBQUFBQSxjQUFJLENBQUNmLGFBQ3ZCLHVCQUFDLGFBQTRCLFlBQWJBLFNBQVN3RCxJQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBLFlBQ2pELEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHVJQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGdIQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRIO0FBQUEsWUFDNUgsdUJBQUMsU0FBSSxXQUFVLGtIQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThIO0FBQUEsWUFDOUgsdUJBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLG9HQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdIO0FBQUEsZ0JBQ2hILHVCQUFDLFNBQUksV0FBVSxxRkFDYixpQ0FBQyxPQUFJLFdBQVUsNkJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLG1FQUFrRTtBQUFBO0FBQUEsa0JBRTlFLHVCQUFDLFlBQVMsV0FBVSw2QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkM7QUFBQSxxQkFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSwwQ0FBeUMscUdBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsK0NBQThDO0FBQUE7QUFBQSxrQkFDdEQsdUJBQUMsVUFBSyxXQUFVLGVBQWMsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDO0FBQUEsa0JBQU87QUFBQSxxQkFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLGFBckVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzRUE7QUFBQSxXQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUVBO0FBQUEsU0EzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRFQTtBQUFBLElBR0N6SCxxQkFDQyx1QkFBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLDBGQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDhGQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlDQUNiLGlDQUFDLGFBQVUsV0FBVSw4QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLG9DQUFtQyxtQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0U7QUFBQSxVQUNuRWlHLGdCQUFnQixDQUFDMUYsOEJBQ2hCLHVCQUFDLFVBQUssV0FBVSxxRUFBb0UsbUNBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVHO0FBQUEsYUFOM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLFNBQVNrRyxZQUFZLFdBQVUsc0NBQ3JDLGlDQUFDLEtBQUUsV0FBVSw0QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsT0FDWixXQUFDbEcsNkJBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsOEVBQ2I7QUFBQSxpQ0FBQyxRQUFLLFdBQVUsNEJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsVUFDeEMsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QiwrRkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUg7QUFBQSxhQUZ2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDRDQUEyQyx5Q0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT0o7QUFBQUEsY0FDUCxVQUFVLENBQUMySSxNQUFNMUksWUFBWTBJLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxjQUMzQyxXQUFXLENBQUNGLE1BQU1BLEVBQUVHLFFBQVEsV0FBVzlDLDBCQUEwQjtBQUFBLGNBQ2pFLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLFdBQVM7QUFBQTtBQUFBLFlBUFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT1c7QUFBQSxVQUVWOUYsaUJBQ0MsdUJBQUMsU0FBSSxXQUFVLHlFQUNiO0FBQUEsbUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsWUFDaEMsdUJBQUMsVUFBTUEsMkJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUI7QUFBQSxlQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUzhGO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQWdJO0FBQUE7QUFBQSxZQUY1STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDJDQUEwQztBQUFBO0FBQUEsWUFBZSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxxQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxlQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RztBQUFBLGFBdkJoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsV0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThCQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSxxQ0FBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsY0FDNUMsdUJBQUMsVUFBSyxXQUFVLHlDQUF3Qyw4QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0U7QUFBQSxpQkFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPMUY7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDcUksTUFBTXBDLG1CQUFtQm9DLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxnQkFDbEQsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCO0FBQUEsa0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQztBQUFBLGtCQUNuQyx1QkFBQyxZQUFPLE9BQU0sYUFBWSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0M7QUFBQSxrQkFDcEMsdUJBQUMsWUFBTyxPQUFNLGFBQVksMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUEsa0JBQ3BDLHVCQUFDLFlBQU8sT0FBTSxVQUFTLDRCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQztBQUFBO0FBQUE7QUFBQSxjQVRyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFHQ2pJLHdCQUNDLHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHlCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RTtBQUFBLGdCQUN6RTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT0o7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDbUksTUFBTWxJLGtCQUFrQmtJLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxvQkFDakQsV0FBVTtBQUFBO0FBQUEsa0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlrSjtBQUFBLG1CQU5wSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUU7QUFBQSxnQkFDdkU7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU9uSTtBQUFBQSxvQkFDUCxVQUFVLENBQUNpSSxNQUFNaEksZ0JBQWdCZ0ksRUFBRUMsT0FBT0MsS0FBSztBQUFBLG9CQUMvQyxXQUFVO0FBQUE7QUFBQSxrQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSWtKO0FBQUEsbUJBTnBKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBU3JDO0FBQUFBLGdCQUNULFVBQVUsQ0FBQ2hHLGtCQUFrQixDQUFDRTtBQUFBQSxnQkFDOUIsV0FBVyw2REFBNkRGLGtCQUFrQkUsZUFDdEYsbURBQ0EsOENBQThDO0FBQUEsZ0JBQzdDO0FBQUE7QUFBQSxjQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsZUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkE7QUFBQSxhQXJESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0RBO0FBQUEsUUFFQ0ksYUFBYUksVUFDWix1QkFBQyxTQUFJLFdBQVUsNkJBQ2IsaUNBQUMsU0FBSSxXQUFVLHFFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUYsS0FEbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBQ0VKLGFBQWFLLFFBQ2YsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQztBQUFBO0FBQUEsVUFBUUwsYUFBYUs7QUFBQUEsYUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRSxJQUN4RUwsYUFBYUcsV0FBV21ELFdBQVcsSUFDckMsdUJBQUMsU0FBSSxXQUFVLG1DQUFrQyxrRUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsbUNBRUU7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUZBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsdUNBQXNDLGdDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGNBQ3RFLHVCQUFDLGVBQVksV0FBVSw2QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Q7QUFBQSxpQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDBDQUF5QztBQUFBO0FBQUEsY0FDakQ4QyxtQkFBbUJwRyxhQUFhRSxjQUFjO0FBQUEsaUJBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsdUNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsc0VBQXFFLHFDQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RztBQUFBLFlBQ3hHLHVCQUFDLFNBQUksV0FBVSwyQ0FDWkYsdUJBQWFHLFdBQVc0RDtBQUFBQSxjQUFJLENBQUNTLEtBQUt5RCxRQUNqQyx1QkFBQyxTQUFjLFdBQVUsMEZBQ3ZCO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHNDQUFzQ3pELGNBQUlSLFFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsZ0JBQy9ELHVCQUFDLFVBQUssV0FBVSx3Q0FBdUM7QUFBQTtBQUFBLGtCQUNsRG9DLG1CQUFtQjVCLElBQUloQixNQUFNO0FBQUEscUJBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKUXlFLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLFlBQ0QsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsb0RBQW1ELHFGQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdDQTtBQUFBLFdBOUdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnSEEsS0FsSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9KQTtBQUFBLFNBcEtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxS0EsS0F0S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVLQTtBQUFBLElBR0YsdUJBQUMsV0FBTSxLQUFHLE1BQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPRTtBQUFBLE9BbFFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtUUE7QUFFSjtBQUFFbkosR0FqdEJJRCxXQUFTO0FBQUFxSixLQUFUcko7QUFtdEJOLGVBQWVBO0FBQVUsSUFBQXFKO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJOYXZiYXIiLCJTaWRlYmFyIiwiQmFua25vdGUiLCJDaGV2cm9uUmlnaHQiLCJaYXAiLCJTaGllbGQiLCJVc2VyQ2hlY2siLCJTcGFya2xlcyIsIkNyZWRpdENhcmQiLCJMaW5rIiwiTGlua0ljb24iLCJJbmRpYW5SdXBlZSIsIkZpbGVUZXh0IiwiQmFyQ2hhcnQzIiwiRXllIiwiWCIsIkxvY2siLCJBbGVydENpcmNsZSIsIkFycm93TGVmdFJpZ2h0IiwiQ2FsZW5kYXIiLCJSb3V0ZXJMaW5rIiwiQnJlYWRjcnVtYiIsImFwaSIsIkZpWENpcmNsZSIsIkhpQ3VycmVuY3lSdXBlZSIsIlBheUluTWVudSIsIl9zIiwic2hvd092ZXJ2aWV3TW9kYWwiLCJzZXRTaG93T3ZlcnZpZXdNb2RhbCIsInVzZVN0YXRlIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInBhc3N3b3JkRXJyb3IiLCJzZXRQYXNzd29yZEVycm9yIiwiaXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXciLCJzZXRJc0F1dGhlbnRpY2F0ZWRGb3JPdmVydmlldyIsInNlbGVjdGVkRmlsdGVyIiwic2V0U2VsZWN0ZWRGaWx0ZXIiLCJjdXN0b21Gcm9tRGF0ZSIsInNldEN1c3RvbUZyb21EYXRlIiwiY3VzdG9tVG9EYXRlIiwic2V0Q3VzdG9tVG9EYXRlIiwic2hvd0N1c3RvbURhdGVQaWNrZXIiLCJzZXRTaG93Q3VzdG9tRGF0ZVBpY2tlciIsIm92ZXJ2aWV3RGF0YSIsInNldE92ZXJ2aWV3RGF0YSIsInRvdGFsUGF5bWVudEluIiwiY2F0ZWdvcmllcyIsImxvYWRpbmciLCJlcnJvciIsImZvcm1hdExvY2FsRGF0ZSIsImRhdGUiLCJ5IiwiZ2V0RnVsbFllYXIiLCJtIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImQiLCJnZXREYXRlIiwiZ2V0RGF0ZVJhbmdlIiwiZmlsdGVyIiwibm93IiwiRGF0ZSIsImZyb21EYXRlIiwidG9EYXRlIiwieWVzdGVyZGF5Iiwic2V0RGF0ZSIsImZpcnN0RGF5IiwibGFzdERheSIsImxhc3RNb250aEZpcnN0RGF5IiwibGFzdE1vbnRoTGFzdERheSIsImZldGNoUGF5bWVudFJlY2VpcHREYXRhIiwicmVzcG9uc2UiLCJnZXQiLCJwYXJhbXMiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwiZ3JvdXBJZCIsInVzZXJJZCIsImFjY291bnRfdHlwZSIsImNvbGxlY3RlZF9ieSIsImFkbWluX3R5cGUiLCJwYXlfZm9yIiwiZGF0YSIsImNvbnNvbGUiLCJwcm9jZXNzUGF5bWVudERhdGEiLCJwYXltZW50cyIsImNhdGVnb3J5TWFwIiwiTWFwIiwiZm9yRWFjaCIsInBheW1lbnQiLCJjYXRlZ29yeSIsInRvVXBwZXJDYXNlIiwicGF5bWVudF90eXBlIiwicGlnbWUiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwibG9hbiIsImFtb3VudCIsInBhcnNlRmxvYXQiLCJoYXMiLCJzZXQiLCJBcnJheSIsImZyb20iLCJlbnRyaWVzIiwibWFwIiwibmFtZSIsImNsZWFuZWROYW1lIiwiaW5jbHVkZXMiLCJzb3J0IiwiYSIsImIiLCJyZWR1Y2UiLCJzdW0iLCJjYXQiLCJsb2FkT3ZlcnZpZXdEYXRhIiwicHJldiIsImVyciIsIm1lc3NhZ2UiLCJ1c2VyUm9sZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJpc1N1cGVyQWRtaW4iLCJoYW5kbGVPdmVydmlld0NsaWNrIiwidmVyaWZ5UGFzc3dvcmRBbmRTaG93RGF0YSIsInVzZXIiLCJ1c2VyT2JqIiwiSlNPTiIsInBhcnNlIiwidmFsaWRQYXNzd29yZCIsImNsb3NlTW9kYWwiLCJoYW5kbGVGaWx0ZXJDaGFuZ2UiLCJoYW5kbGVDdXN0b21EYXRlQXBwbHkiLCJnZXREYXRlUmFuZ2VEaXNwbGF5IiwiZm9ybWF0RGlzcGxheURhdGUiLCJkYXRlU3RyIiwicGFydHMiLCJzcGxpdCIsImRvY3VtZW50IiwiYm9keSIsInN0eWxlIiwib3ZlcmZsb3ciLCJmb3JtYXRJbmRpYW5OdW1iZXIiLCJudW0iLCJ0b0xvY2FsZVN0cmluZyIsInBheW1lbnRJbk1lbnVDYXRlZ29yaWVzIiwiaWQiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiaWNvbiIsImdyYWRpZW50IiwiYmdHcmFkaWVudCIsImhyZWYiLCJzdGF0cyIsInNlY29uZGFyeUljb24iLCJpY29uQ29sb3IiLCJiZ0NvbG9yIiwic2VjdGlvbiIsInBheW1lbnRDYXRlZ29yaWVzIiwiaXRlbSIsImVtcGxveWVlQ2F0ZWdvcmllcyIsIlNtYWxsQ2FyZCIsIm9uQ2xpY2siLCJJY29uIiwiU2Vjb25kYXJ5SWNvbiIsImNvbnRlbnQiLCJvdmVydmlld0NhcmQiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJrZXkiLCJpZHgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYXlJbk1lbnUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgQmFua25vdGUsIENoZXZyb25SaWdodCwgWmFwLCBTaGllbGQsIFVzZXJDaGVjaywgU3BhcmtsZXMsIENyZWRpdENhcmQsIExpbmsgYXMgTGlua0ljb24sIEluZGlhblJ1cGVlLCBGaWxlVGV4dCwgQmFyQ2hhcnQzLCBFeWUsIFgsIExvY2ssIEFsZXJ0Q2lyY2xlLCBBcnJvd0xlZnRSaWdodCwgQ2FsZW5kYXIgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmssIExpbmsgYXMgUm91dGVyTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBGaVhDaXJjbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgSGlDdXJyZW5jeVJ1cGVlIH0gZnJvbSBcInJlYWN0LWljb25zL2hpXCI7XHJcblxyXG5jb25zdCBQYXlJbk1lbnUgPSAoKSA9PiB7XHJcbiAgLy8gLS0tLS0tLS0tLSBPdmVydmlldyBNb2RhbCBTdGF0ZSAtLS0tLS0tLS0tXHJcbiAgY29uc3QgW3Nob3dPdmVydmlld01vZGFsLCBzZXRTaG93T3ZlcnZpZXdNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcGFzc3dvcmRFcnJvciwgc2V0UGFzc3dvcmRFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXcsIHNldElzQXV0aGVudGljYXRlZEZvck92ZXJ2aWV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgLy8gLS0tLS0tLS0tLSBEYXRlIEZpbHRlciBTdGF0ZSAtLS0tLS0tLS0tXHJcbiAgY29uc3QgW3NlbGVjdGVkRmlsdGVyLCBzZXRTZWxlY3RlZEZpbHRlcl0gPSB1c2VTdGF0ZShcInRoaXNNb250aFwiKTtcclxuICBjb25zdCBbY3VzdG9tRnJvbURhdGUsIHNldEN1c3RvbUZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjdXN0b21Ub0RhdGUsIHNldEN1c3RvbVRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd0N1c3RvbURhdGVQaWNrZXIsIHNldFNob3dDdXN0b21EYXRlUGlja2VyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgLy8gLS0tLS0tLS0tLSBQYXltZW50IE92ZXJ2aWV3IERhdGEgKGZyb20gQVBJKSAtLS0tLS0tLS0tXHJcbiAgY29uc3QgW292ZXJ2aWV3RGF0YSwgc2V0T3ZlcnZpZXdEYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsUGF5bWVudEluOiAwLFxyXG4gICAgY2F0ZWdvcmllczogW10sXHJcbiAgICBsb2FkaW5nOiB0cnVlLFxyXG4gICAgZXJyb3I6IG51bGwsXHJcbiAgfSk7XHJcblxyXG4gIC8vIEhlbHBlcjogZm9ybWF0IGRhdGUgYXMgWVlZWS1NTS1ERCBpbiBsb2NhbCB0aW1lXHJcbiAgY29uc3QgZm9ybWF0TG9jYWxEYXRlID0gKGRhdGUpID0+IHtcclxuICAgIGNvbnN0IHkgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICBjb25zdCBkID0gU3RyaW5nKGRhdGUuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgcmV0dXJuIGAke3l9LSR7bX0tJHtkfWA7XHJcbiAgfTtcclxuXHJcbiAgLy8gSGVscGVyOiBnZXQgZGF0ZSByYW5nZSBiYXNlZCBvbiBmaWx0ZXJcclxuICBjb25zdCBnZXREYXRlUmFuZ2UgPSAoZmlsdGVyKSA9PiB7XHJcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gICAgbGV0IGZyb21EYXRlLCB0b0RhdGU7XHJcblxyXG4gICAgc3dpdGNoIChmaWx0ZXIpIHtcclxuICAgICAgY2FzZSBcInRvZGF5XCI6XHJcbiAgICAgICAgZnJvbURhdGUgPSBmb3JtYXRMb2NhbERhdGUobm93KTtcclxuICAgICAgICB0b0RhdGUgPSBmb3JtYXRMb2NhbERhdGUobm93KTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSBcInllc3RlcmRheVwiOlxyXG4gICAgICAgIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKG5vdyk7XHJcbiAgICAgICAgeWVzdGVyZGF5LnNldERhdGUoeWVzdGVyZGF5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICAgIGZyb21EYXRlID0gZm9ybWF0TG9jYWxEYXRlKHllc3RlcmRheSk7XHJcbiAgICAgICAgdG9EYXRlID0gZm9ybWF0TG9jYWxEYXRlKHllc3RlcmRheSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJ0aGlzTW9udGhcIjpcclxuICAgICAgICBjb25zdCBmaXJzdERheSA9IG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCBub3cuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCBub3cuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICAgIGZyb21EYXRlID0gZm9ybWF0TG9jYWxEYXRlKGZpcnN0RGF5KTtcclxuICAgICAgICB0b0RhdGUgPSBmb3JtYXRMb2NhbERhdGUobGFzdERheSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJsYXN0TW9udGhcIjpcclxuICAgICAgICBjb25zdCBsYXN0TW9udGhGaXJzdERheSA9IG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCBub3cuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4gICAgICAgIGNvbnN0IGxhc3RNb250aExhc3REYXkgPSBuZXcgRGF0ZShub3cuZ2V0RnVsbFllYXIoKSwgbm93LmdldE1vbnRoKCksIDApO1xyXG4gICAgICAgIGZyb21EYXRlID0gZm9ybWF0TG9jYWxEYXRlKGxhc3RNb250aEZpcnN0RGF5KTtcclxuICAgICAgICB0b0RhdGUgPSBmb3JtYXRMb2NhbERhdGUobGFzdE1vbnRoTGFzdERheSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJjdXN0b21cIjpcclxuICAgICAgICBmcm9tRGF0ZSA9IGN1c3RvbUZyb21EYXRlIHx8IGZvcm1hdExvY2FsRGF0ZShuZXcgRGF0ZSgpKTtcclxuICAgICAgICB0b0RhdGUgPSBjdXN0b21Ub0RhdGUgfHwgZm9ybWF0TG9jYWxEYXRlKG5ldyBEYXRlKCkpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIGZyb21EYXRlID0gZm9ybWF0TG9jYWxEYXRlKG5ldyBEYXRlKCkpO1xyXG4gICAgICAgIHRvRGF0ZSA9IGZvcm1hdExvY2FsRGF0ZShuZXcgRGF0ZSgpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4geyBmcm9tRGF0ZSwgdG9EYXRlIH07XHJcbiAgfTtcclxuXHJcbiAgLy8gRmV0Y2ggcGF5bWVudCByZWNlaXB0IGRhdGEgZnJvbSBBUElcclxuICBjb25zdCBmZXRjaFBheW1lbnRSZWNlaXB0RGF0YSA9IGFzeW5jIChmcm9tRGF0ZSwgdG9EYXRlKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoJy9wYXltZW50L2dldC1yZWNlaXB0LXJlcG9ydCcsIHtcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGZyb21fZGF0ZTogZnJvbURhdGUsXHJcbiAgICAgICAgICB0b19kYXRlOiB0b0RhdGUsXHJcbiAgICAgICAgICBncm91cElkOiAnJyxcclxuICAgICAgICAgIHVzZXJJZDogJycsXHJcbiAgICAgICAgICBhY2NvdW50X3R5cGU6ICcnLFxyXG4gICAgICAgICAgY29sbGVjdGVkX2J5OiAnJyxcclxuICAgICAgICAgIGFkbWluX3R5cGU6ICcnLFxyXG4gICAgICAgICAgcGF5X2ZvcjogWydDaGl0JywgJ1BpZ21lJywgJ0xvYW4nLCAnUmVnaXN0cmF0aW9uJ11cclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgcmVjZWlwdCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBbXTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBQcm9jZXNzIHBheW1lbnQgZGF0YSBhbmQgY2FsY3VsYXRlIHRvdGFscyBieSBjYXRlZ29yeVxyXG4gIGNvbnN0IHByb2Nlc3NQYXltZW50RGF0YSA9IChwYXltZW50cykgPT4ge1xyXG4gICAgY29uc3QgY2F0ZWdvcnlNYXAgPSBuZXcgTWFwKCk7XHJcblxyXG4gICAgcGF5bWVudHMuZm9yRWFjaChwYXltZW50ID0+IHtcclxuICAgICAgLy8gRGV0ZXJtaW5lIGNhdGVnb3J5IGJhc2VkIG9uIGF2YWlsYWJsZSBmaWVsZHNcclxuICAgICAgbGV0IGNhdGVnb3J5ID0gJ090aGVyJztcclxuXHJcbiAgICAgIC8vIENoZWNrIHBheV9mb3IgZmlyc3QgKG1vc3Qgc3BlY2lmaWMpXHJcbiAgICAgIGlmIChwYXltZW50LnBheV9mb3IpIHtcclxuICAgICAgICBpZiAocGF5bWVudC5wYXlfZm9yID09PSAnUGlnbWUnKSB7XHJcbiAgICAgICAgICBjYXRlZ29yeSA9ICdQSUdNRSBQQVlNRU5UJztcclxuICAgICAgICB9IGVsc2UgaWYgKHBheW1lbnQucGF5X2ZvciA9PT0gJ0xvYW4nKSB7XHJcbiAgICAgICAgICBjYXRlZ29yeSA9ICdMT0FOIFBBWU1FTlQnO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocGF5bWVudC5wYXlfZm9yID09PSAnUmVnaXN0cmF0aW9uJykge1xyXG4gICAgICAgICAgY2F0ZWdvcnkgPSAnUkVHSVNUUkFUSU9OIEZFRSc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGNhdGVnb3J5ID0gcGF5bWVudC5wYXlfZm9yLnRvVXBwZXJDYXNlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC8vIFRoZW4gY2hlY2sgcGF5bWVudF90eXBlXHJcbiAgICAgIGVsc2UgaWYgKHBheW1lbnQucGF5bWVudF90eXBlKSB7XHJcbiAgICAgICAgaWYgKHBheW1lbnQucGF5bWVudF90eXBlID09PSAnQ2hpdCBQYXltZW50Jykge1xyXG4gICAgICAgICAgY2F0ZWdvcnkgPSAnQ0hJVCBQQVlNRU5UJztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgY2F0ZWdvcnkgPSBwYXltZW50LnBheW1lbnRfdHlwZS50b1VwcGVyQ2FzZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAvLyBUaGVuIGNoZWNrIGlmIGl0J3MgYSBwaWdtZSBvciBsb2FuIHBheW1lbnQgZnJvbSB0aGUgb2JqZWN0c1xyXG4gICAgICBlbHNlIGlmIChwYXltZW50LnBpZ21lICYmIE9iamVjdC5rZXlzKHBheW1lbnQucGlnbWUpLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjYXRlZ29yeSA9ICdQSUdNRSBQQVlNRU5UJztcclxuICAgICAgfVxyXG4gICAgICBlbHNlIGlmIChwYXltZW50LmxvYW4gJiYgT2JqZWN0LmtleXMocGF5bWVudC5sb2FuKS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgY2F0ZWdvcnkgPSAnTE9BTiBQQVlNRU5UJztcclxuICAgICAgfVxyXG4gICAgICAvLyBDaGVjayBwYXltZW50X3R5cGUgZmllbGQgYWdhaW5cclxuICAgICAgZWxzZSBpZiAocGF5bWVudC5wYXltZW50X3R5cGUpIHtcclxuICAgICAgICBjYXRlZ29yeSA9IHBheW1lbnQucGF5bWVudF90eXBlLnRvVXBwZXJDYXNlKCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIEdldCBhbW91bnQgZnJvbSB2YXJpb3VzIHBvc3NpYmxlIGZpZWxkc1xyXG4gICAgICBjb25zdCBhbW91bnQgPSBwYXJzZUZsb2F0KHBheW1lbnQuYW1vdW50IHx8IDApO1xyXG5cclxuICAgICAgaWYgKGNhdGVnb3J5TWFwLmhhcyhjYXRlZ29yeSkpIHtcclxuICAgICAgICBjYXRlZ29yeU1hcC5zZXQoY2F0ZWdvcnksIGNhdGVnb3J5TWFwLmdldChjYXRlZ29yeSkgKyBhbW91bnQpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNhdGVnb3J5TWFwLnNldChjYXRlZ29yeSwgYW1vdW50KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gQ29udmVydCB0byBhcnJheSBhbmQgc29ydCBieSBhbW91bnQgZGVzY2VuZGluZ1xyXG4gICAgY29uc3QgY2F0ZWdvcmllcyA9IEFycmF5LmZyb20oY2F0ZWdvcnlNYXAuZW50cmllcygpKVxyXG4gICAgICAubWFwKChbbmFtZSwgYW1vdW50XSkgPT4ge1xyXG4gICAgICAgIC8vIEZpeCBhbnkgcmVtYWluaW5nIFwiUkVHfENISVRcIiBvciBzaW1pbGFyIGlzc3Vlc1xyXG4gICAgICAgIGxldCBjbGVhbmVkTmFtZSA9IG5hbWU7XHJcbiAgICAgICAgaWYgKG5hbWUuaW5jbHVkZXMoJ1JFR3xDSElUJykpIHtcclxuICAgICAgICAgIGNsZWFuZWROYW1lID0gJ1JFR0lTVFJBVElPTiBGRUUnO1xyXG4gICAgICAgIH0gZWxzZSBpZiAobmFtZS5pbmNsdWRlcygnUkVHfCcpKSB7XHJcbiAgICAgICAgICBjbGVhbmVkTmFtZSA9ICdSRUdJU1RSQVRJT04gRkVFJztcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHsgbmFtZTogY2xlYW5lZE5hbWUsIGFtb3VudCB9O1xyXG4gICAgICB9KVxyXG4gICAgICAuc29ydCgoYSwgYikgPT4gYi5hbW91bnQgLSBhLmFtb3VudCk7XHJcblxyXG4gICAgY29uc3QgdG90YWxQYXltZW50SW4gPSBjYXRlZ29yaWVzLnJlZHVjZSgoc3VtLCBjYXQpID0+IHN1bSArIGNhdC5hbW91bnQsIDApO1xyXG5cclxuICAgIHJldHVybiB7IGNhdGVnb3JpZXMsIHRvdGFsUGF5bWVudEluIH07XHJcbiAgfTtcclxuXHJcbiAgLy8gTG9hZCBhbGwgZGF0YSB3aXRoIGRhdGUgZmlsdGVyXHJcbiAgY29uc3QgbG9hZE92ZXJ2aWV3RGF0YSA9IGFzeW5jIChmaWx0ZXIgPSBzZWxlY3RlZEZpbHRlcikgPT4ge1xyXG4gICAgY29uc3QgeyBmcm9tRGF0ZSwgdG9EYXRlIH0gPSBnZXREYXRlUmFuZ2UoZmlsdGVyKTtcclxuXHJcbiAgICBzZXRPdmVydmlld0RhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBsb2FkaW5nOiB0cnVlLCBlcnJvcjogbnVsbCB9KSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXltZW50cyA9IGF3YWl0IGZldGNoUGF5bWVudFJlY2VpcHREYXRhKGZyb21EYXRlLCB0b0RhdGUpO1xyXG5cclxuICAgICAgaWYgKCFwYXltZW50cyB8fCBwYXltZW50cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgICBzZXRPdmVydmlld0RhdGEoe1xyXG4gICAgICAgICAgdG90YWxQYXltZW50SW46IDAsXHJcbiAgICAgICAgICBjYXRlZ29yaWVzOiBbXSxcclxuICAgICAgICAgIGxvYWRpbmc6IGZhbHNlLFxyXG4gICAgICAgICAgZXJyb3I6IG51bGwsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCB7IGNhdGVnb3JpZXMsIHRvdGFsUGF5bWVudEluIH0gPSBwcm9jZXNzUGF5bWVudERhdGEocGF5bWVudHMpO1xyXG5cclxuICAgICAgc2V0T3ZlcnZpZXdEYXRhKHtcclxuICAgICAgICB0b3RhbFBheW1lbnRJbixcclxuICAgICAgICBjYXRlZ29yaWVzLFxyXG4gICAgICAgIGxvYWRpbmc6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiBudWxsLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRPdmVydmlld0RhdGEocHJldiA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgbG9hZGluZzogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6IGVyci5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gbG9hZCBkYXRhJ1xyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gLS0tLS0tLS0tLSBTdXBlcmFkbWluICYgUGFzc3dvcmQgTG9naWMgLS0tLS0tLS0tLVxyXG4gIGNvbnN0IHVzZXJSb2xlID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyUm9sZVwiKSB8fCBcInN1cGVyYWRtaW5cIjtcclxuICBjb25zdCBpc1N1cGVyQWRtaW4gPSB1c2VyUm9sZSA9PT0gXCJzdXBlcmFkbWluXCI7XHJcblxyXG4gIGNvbnN0IGhhbmRsZU92ZXJ2aWV3Q2xpY2sgPSAoKSA9PiB7XHJcbiAgICBpZiAoIWlzU3VwZXJBZG1pbikge1xyXG4gICAgICBzZXRQYXNzd29yZEVycm9yKFwiQWNjZXNzIGRlbmllZDogT25seSBzdXBlcmFkbWluIGNhbiB2aWV3IG92ZXJ2aWV3XCIpO1xyXG4gICAgICBzZXRTaG93T3ZlcnZpZXdNb2RhbCh0cnVlKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgc2V0UGFzc3dvcmQoXCJcIik7XHJcbiAgICBzZXRQYXNzd29yZEVycm9yKFwiXCIpO1xyXG4gICAgc2V0SXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXcoZmFsc2UpO1xyXG4gICAgc2V0U2hvd092ZXJ2aWV3TW9kYWwodHJ1ZSk7XHJcbiAgICBzZXRTZWxlY3RlZEZpbHRlcihcInRoaXNNb250aFwiKTtcclxuICAgIHNldEN1c3RvbUZyb21EYXRlKFwiXCIpO1xyXG4gICAgc2V0Q3VzdG9tVG9EYXRlKFwiXCIpO1xyXG4gICAgc2V0U2hvd0N1c3RvbURhdGVQaWNrZXIoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZlcmlmeVBhc3N3b3JkQW5kU2hvd0RhdGEgPSAoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcbiAgICBjb25zdCB2YWxpZFBhc3N3b3JkID0gdXNlck9iaj8ucGFzc3dvcmQ7XHJcbiAgICBpZiAocGFzc3dvcmQgPT09IFwiMTIzNDVcIiAmJiBpc1N1cGVyQWRtaW4pIHtcclxuICAgICAgc2V0SXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXcodHJ1ZSk7XHJcbiAgICAgIHNldFBhc3N3b3JkRXJyb3IoXCJcIik7XHJcbiAgICAgIGxvYWRPdmVydmlld0RhdGEoXCJ0aGlzTW9udGhcIik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRQYXNzd29yZEVycm9yKFwiSW52YWxpZCBwYXNzd29yZCBvciBpbnN1ZmZpY2llbnQgcHJpdmlsZWdlc1wiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjbG9zZU1vZGFsID0gKCkgPT4ge1xyXG4gICAgc2V0U2hvd092ZXJ2aWV3TW9kYWwoZmFsc2UpO1xyXG4gICAgc2V0UGFzc3dvcmQoXCJcIik7XHJcbiAgICBzZXRQYXNzd29yZEVycm9yKFwiXCIpO1xyXG4gICAgc2V0SXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXcoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBmaWx0ZXIgY2hhbmdlXHJcbiAgY29uc3QgaGFuZGxlRmlsdGVyQ2hhbmdlID0gKGZpbHRlcikgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRGaWx0ZXIoZmlsdGVyKTtcclxuICAgIGlmIChmaWx0ZXIgPT09IFwiY3VzdG9tXCIpIHtcclxuICAgICAgc2V0U2hvd0N1c3RvbURhdGVQaWNrZXIodHJ1ZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRTaG93Q3VzdG9tRGF0ZVBpY2tlcihmYWxzZSk7XHJcbiAgICAgIGxvYWRPdmVydmlld0RhdGEoZmlsdGVyKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgY3VzdG9tIGRhdGUgYXBwbHlcclxuICBjb25zdCBoYW5kbGVDdXN0b21EYXRlQXBwbHkgPSAoKSA9PiB7XHJcbiAgICBpZiAoY3VzdG9tRnJvbURhdGUgJiYgY3VzdG9tVG9EYXRlKSB7XHJcbiAgICAgIGxvYWRPdmVydmlld0RhdGEoXCJjdXN0b21cIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gR2V0IGZvcm1hdHRlZCBkYXRlIHJhbmdlIGRpc3BsYXlcclxuICBjb25zdCBnZXREYXRlUmFuZ2VEaXNwbGF5ID0gKCkgPT4ge1xyXG4gICAgY29uc3QgeyBmcm9tRGF0ZSwgdG9EYXRlIH0gPSBnZXREYXRlUmFuZ2Uoc2VsZWN0ZWRGaWx0ZXIpO1xyXG4gICAgaWYgKHNlbGVjdGVkRmlsdGVyID09PSBcInRvZGF5XCIpIHJldHVybiBcIlRvZGF5XCI7XHJcbiAgICBpZiAoc2VsZWN0ZWRGaWx0ZXIgPT09IFwieWVzdGVyZGF5XCIpIHJldHVybiBcIlllc3RlcmRheVwiO1xyXG4gICAgaWYgKHNlbGVjdGVkRmlsdGVyID09PSBcInRoaXNNb250aFwiKSByZXR1cm4gXCJUaGlzIE1vbnRoXCI7XHJcbiAgICBpZiAoc2VsZWN0ZWRGaWx0ZXIgPT09IFwibGFzdE1vbnRoXCIpIHJldHVybiBcIkxhc3QgTW9udGhcIjtcclxuICAgIGlmIChzZWxlY3RlZEZpbHRlciA9PT0gXCJjdXN0b21cIikge1xyXG4gICAgICBpZiAoY3VzdG9tRnJvbURhdGUgJiYgY3VzdG9tVG9EYXRlKSB7XHJcbiAgICAgICAgcmV0dXJuIGAke2Zvcm1hdERpc3BsYXlEYXRlKGN1c3RvbUZyb21EYXRlKX0gLSAke2Zvcm1hdERpc3BsYXlEYXRlKGN1c3RvbVRvRGF0ZSl9YDtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gXCJDdXN0b20gUmFuZ2VcIjtcclxuICAgIH1cclxuICAgIHJldHVybiBcIlwiO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdERpc3BsYXlEYXRlID0gKGRhdGVTdHIpID0+IHtcclxuICAgIGlmICghZGF0ZVN0cikgcmV0dXJuIFwiXCI7XHJcbiAgICBjb25zdCBwYXJ0cyA9IGRhdGVTdHIuc3BsaXQoJy0nKTtcclxuICAgIHJldHVybiBgJHtwYXJ0c1syXX0vJHtwYXJ0c1sxXX0vJHtwYXJ0c1swXX1gO1xyXG4gIH07XHJcblxyXG4gIC8vIExvY2sgYmFja2dyb3VuZCBzY3JvbGwgd2hlbiBtb2RhbCBvcGVuc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2hvd092ZXJ2aWV3TW9kYWwpIHtcclxuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9IFwiaGlkZGVuXCI7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gXCJ1bnNldFwiO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9IFwidW5zZXRcIjtcclxuICAgIH07XHJcbiAgfSwgW3Nob3dPdmVydmlld01vZGFsXSk7XHJcblxyXG4gIGNvbnN0IGZvcm1hdEluZGlhbk51bWJlciA9IChudW0pID0+IHtcclxuICAgIHJldHVybiBudW0udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKTtcclxuICB9O1xyXG5cclxuICAvLyBTbWFsbCBDYXJkcyBEYXRhICh1bmNoYW5nZWQpXHJcbiAgY29uc3QgcGF5bWVudEluTWVudUNhdGVnb3JpZXMgPSBbXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIiMxXCIsXHJcbiAgICAgIHRpdGxlOiBcIlJlZ2lzdHJhdGlvbiBGZWVcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIGN1c3RvbWVyIHJlZ2lzdHJhdGlvbiBmZWUgZm9yIGpvaW5pbmcgQ2hpdCBncm91cCByZWNvcmRzXCIsXHJcbiAgICAgIGljb246IEZpbGVUZXh0LFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLXZpb2xldC01MDAgdmlhLXB1cnBsZS01MDAgdG8tcGluay01MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLXZpb2xldC01MCB2aWEtcHVycGxlLTUwIHRvLXBpbmstNTBcIixcclxuICAgICAgaHJlZjogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvcmVnaXN0cmF0aW9uLWZlZVwiLFxyXG4gICAgICBzdGF0czogXCJSZWdpc3RyYXRpb24tRmVlIEluZm9cIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogU2hpZWxkLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC12aW9sZXQtNjAwXCIsXHJcbiAgICAgIGJnQ29sb3I6IFwiYmctdmlvbGV0LTEwMFwiLFxyXG4gICAgICBzZWN0aW9uOiBcInBheW1lbnRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIiMyXCIsXHJcbiAgICAgIHRpdGxlOiBcIlBheW1lbnQgUmVjZWlwdFwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgY3VzdG9tZXIgY2hpdCBwYXltZW50IHRyYW5zYWN0aW9uIGluZm9ybWF0aW9uXCIsXHJcbiAgICAgIGljb246IEluZGlhblJ1cGVlLFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLXB1cnBsZS01MDAgdmlhLWluZGlnby01MDAgdG8tdmlvbGV0LTUwMFwiLFxyXG4gICAgICBiZ0dyYWRpZW50OiBcImZyb20tcHVycGxlLTUwIHZpYS1pbmRpZ28tNTAgdG8tdmlvbGV0LTUwXCIsXHJcbiAgICAgIGhyZWY6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1pbi1tZW51L3BheW1lbnRcIixcclxuICAgICAgc3RhdHM6IFwiQ2hpdCBQYXltZW50IEluZm9cIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogVXNlckNoZWNrLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1wdXJwbGUtNjAwXCIsXHJcbiAgICAgIGJnQ29sb3I6IFwiYmctcHVycGxlLTEwMFwiLFxyXG4gICAgICBzZWN0aW9uOiBcInBheW1lbnRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIiMzXCIsXHJcbiAgICAgIHRpdGxlOiBcIlBlbmFsdHkgcGF5bWVudCBSZWNlaXB0XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkN1c3RvbWVyIHBheW1lbnRzIHdpdGggcGVuYWx0eSBSZWNlaXB0IE1hbmFnZW1lbnQuXCIsXHJcbiAgICAgIGljb246IEluZGlhblJ1cGVlLFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLWFtYmVyLTUwMCB2aWEtb3JhbmdlLTUwMCB0by1yZWQtNTAwXCIsXHJcbiAgICAgIGJnR3JhZGllbnQ6IFwiZnJvbS1hbWJlci01MCB2aWEtb3JhbmdlLTUwIHRvLXJlZC01MFwiLFxyXG4gICAgICBocmVmOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9wZW5hbHR5LXBheW1lbnRcIixcclxuICAgICAgc3RhdHM6IFwiUGVuYWx0eSBSZWNlaXB0IEluZm9cIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogVXNlckNoZWNrLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1hbWJlci02MDBcIixcclxuICAgICAgYmdDb2xvcjogXCJiZy1hbWJlci0xMDBcIixcclxuICAgICAgc2VjdGlvbjogXCJwYXltZW50XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogXCIjN1wiLFxyXG4gICAgICB0aXRsZTogXCJFbXBsb3llZSBBZHZhbmNlIFJlcGF5bWVudFwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJFbXBsb3llZSBBZHZhbmNlIFJlcGF5bWVudCBNYW5hZ2VtZW50LlwiLFxyXG4gICAgICBpY29uOiBIaUN1cnJlbmN5UnVwZWUsXHJcbiAgICAgIGdyYWRpZW50OiBcImZyb20tYmx1ZS01MDAgdmlhLWJsdWUtNjAwIHRvLWluZGlnby02MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLWJsdWUtNTAgdmlhLWluZGlnby01MCB0by1ibHVlLTEwMFwiLFxyXG4gICAgICBocmVmOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9hZHZhbmNlLXBheW1lbnQtaW5cIixcclxuICAgICAgc3RhdHM6IFwiQWR2YW5jZSBSZXBheW1lbnRcIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogSGlDdXJyZW5jeVJ1cGVlLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1ibHVlLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLWJsdWUtMTAwXCIsXHJcbiAgICAgIHNlY3Rpb246IFwiZW1wbG95ZWVcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIiM0XCIsXHJcbiAgICAgIHRpdGxlOiBcIlN1c3BlbnNlIFBheW1lbnRzXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBjdXN0b21lciBTdXNwZW5zZSBjaGl0IHBheW1lbnQgdHJhbnNhY3Rpb24uXCIsXHJcbiAgICAgIGljb246IEluZGlhblJ1cGVlLFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLXNreS01MDAgdmlhLWJsdWUtNTAwIHRvLWluZGlnby01MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLXNreS01MCB2aWEtYmx1ZS01MCB0by1pbmRpZ28tNTBcIixcclxuICAgICAgaHJlZjogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvc3VzcGVuc2UtcGF5bWVudHNcIixcclxuICAgICAgc3RhdHM6IFwiU3VzcGVuc2UgUGF5bWVudCBJbmZvXCIsXHJcbiAgICAgIHNlY29uZGFyeUljb246IFVzZXJDaGVjayxcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtYmx1ZS02MDBcIixcclxuICAgICAgYmdDb2xvcjogXCJiZy1ibHVlLTEwMFwiLFxyXG4gICAgICBzZWN0aW9uOiBcInBheW1lbnRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIiM1XCIsXHJcbiAgICAgIHRpdGxlOiBcIlBheW1lbnQgTGlua3NcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIGN1c3RvbWVyIGNoaXQgcGF5bWVudCBsaW5rIHRyYW5zYWN0aW9uIGluZm9ybWF0aW9uXCIsXHJcbiAgICAgIGljb246IExpbmtJY29uLFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLWluZGlnby01MDAgdmlhLXZpb2xldC01MDAgdG8tY3lhbi01MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLWluZGlnby01MCB2aWEtdmlvbGV0LTUwIHRvLWN5YW4tNTBcIixcclxuICAgICAgaHJlZjogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvcGF5bWVudC1saW5rLW1lbnVcIixcclxuICAgICAgc3RhdHM6IFwiUGF5bWVudCBMaW5rIEluZm9cIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogQ3JlZGl0Q2FyZCxcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtaW5kaWdvLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLWluZGlnby0xMDBcIixcclxuICAgICAgc2VjdGlvbjogXCJwYXltZW50XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogXCIjNlwiLFxyXG4gICAgICB0aXRsZTogXCJDaGl0IFRyYW5zZmVyXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBjdXN0b21lciBjaGl0IFRyYW5zZmVyIHBheW1lbnQgdHJhbnNhY3Rpb24gaW5mb3JtYXRpb24uXCIsXHJcbiAgICAgIGljb246IEFycm93TGVmdFJpZ2h0LFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLXJlZC01MDAgdmlhLXZpb2xldC01MDAgdG8tY3lhbi01MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLXJlZC01MCB2aWEtdmlvbGV0LTUwIHRvLWN5YW4tNTBcIixcclxuICAgICAgaHJlZjogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvY2hpdC10cmFuc2Zlci1wYXktaW5cIixcclxuICAgICAgc3RhdHM6IFwiQ2hpdCBUcmFuc2ZlciBJbmZvXCIsXHJcbiAgICAgIHNlY29uZGFyeUljb246IENyZWRpdENhcmQsXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LXJlZC02MDBcIixcclxuICAgICAgYmdDb2xvcjogXCJiZy1yZWQtMTAwXCIsXHJcbiAgICAgIHNlY3Rpb246IFwicGF5bWVudFwiLFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBwYXltZW50Q2F0ZWdvcmllcyA9IHBheW1lbnRJbk1lbnVDYXRlZ29yaWVzLmZpbHRlcihcclxuICAgIChpdGVtKSA9PiBpdGVtLnNlY3Rpb24gPT09IFwicGF5bWVudFwiXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgZW1wbG95ZWVDYXRlZ29yaWVzID0gcGF5bWVudEluTWVudUNhdGVnb3JpZXMuZmlsdGVyKFxyXG4gICAgKGl0ZW0pID0+IGl0ZW0uc2VjdGlvbiA9PT0gXCJlbXBsb3llZVwiXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgU21hbGxDYXJkID0gKHsgY2F0ZWdvcnksIG9uQ2xpY2sgfSkgPT4ge1xyXG4gICAgY29uc3QgSWNvbiA9IGNhdGVnb3J5Lmljb247XHJcbiAgICBjb25zdCBTZWNvbmRhcnlJY29uID0gY2F0ZWdvcnkuc2Vjb25kYXJ5SWNvbjtcclxuICAgIGNvbnN0IGNvbnRlbnQgPSAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBiZy13aGl0ZS85MCBiYWNrZHJvcC1ibHVyLXNtIGJvcmRlciBib3JkZXItd2hpdGUvMzAgc2hhZG93LWxnIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgdHJhbnNmb3JtIGhvdmVyOi10cmFuc2xhdGUteS0xXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHJvdW5kZWQtMnhsIGJnLWdyYWRpZW50LXRvLXIgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi01MDAgcC1bMXB4XVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LWZ1bGwgaC1mdWxsIHJvdW5kZWQtMnhsIGJnLWdyYWRpZW50LXRvLXIgJHtjYXRlZ29yeS5ncmFkaWVudH1gfT48L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtZnVsbCBiZy13aGl0ZSByb3VuZGVkLTJ4bCBwLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgYWJzb2x1dGUgdG9wLTIgcmlnaHQtMiB3LTIwIGgtMjAgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLWJyICR7Y2F0ZWdvcnkuYmdHcmFkaWVudH0gb3BhY2l0eS0yMCBibHVyLXhsYH0+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2ByZWxhdGl2ZSB3LTEwIGgtMTAgcm91bmRlZC14bCAke2NhdGVnb3J5LmJnQ29sb3J9IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1tZCBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwYH0+XHJcbiAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPXtgdy01IGgtNSAke2NhdGVnb3J5Lmljb25Db2xvcn1gfSAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLXhsIGJnLXNsYXRlLTUwIHNoYWRvdy1zbSBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgPFNlY29uZGFyeUljb24gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS01MDBcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zXCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIG1iLTEgZ3JvdXAtaG92ZXI6dGV4dC1wdXJwbGUtNzAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgIHtjYXRlZ29yeS50aXRsZX1cclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBsZWFkaW5nLXJlbGF4ZWQgbGluZS1jbGFtcC0yXCI+XHJcbiAgICAgICAgICAgICAge2NhdGVnb3J5LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMFwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICB7Y2F0ZWdvcnkuc3RhdHN9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LXB1cnBsZS01MDAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZFwiPkV4cGxvcmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICAgIGlmIChvbkNsaWNrKSB7XHJcbiAgICAgIHJldHVybiA8ZGl2IG9uQ2xpY2s9e29uQ2xpY2t9IGNsYXNzTmFtZT1cImdyb3VwIGN1cnNvci1wb2ludGVyXCI+e2NvbnRlbnR9PC9kaXY+O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIDxSb3V0ZXJMaW5rIHRvPXtjYXRlZ29yeS5ocmVmfSBjbGFzc05hbWU9XCJncm91cCBibG9ja1wiPntjb250ZW50fTwvUm91dGVyTGluaz47XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3ZlcnZpZXdDYXJkID0ge1xyXG4gICAgaWQ6IFwib3ZlcnZpZXdcIixcclxuICAgIHRpdGxlOiBcIk92ZXJ2aWV3XCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJWaWV3IGNvbXBsZXRlIHBheW1lbnQgc3VtbWFyeSAoU3VwZXJhZG1pbiBvbmx5KVwiLFxyXG4gICAgaWNvbjogQmFyQ2hhcnQzLFxyXG4gICAgZ3JhZGllbnQ6IFwiZnJvbS1lbWVyYWxkLTUwMCB2aWEtdGVhbC01MDAgdG8tY3lhbi01MDBcIixcclxuICAgIGJnR3JhZGllbnQ6IFwiZnJvbS1lbWVyYWxkLTUwIHZpYS10ZWFsLTUwIHRvLWN5YW4tNTBcIixcclxuICAgIHN0YXRzOiBcIlN1cGVyYWRtaW4gUHJvdGVjdGVkXCIsXHJcbiAgICBzZWNvbmRhcnlJY29uOiBFeWUsXHJcbiAgICBpY29uQ29sb3I6IFwidGV4dC1lbWVyYWxkLTYwMFwiLFxyXG4gICAgYmdDb2xvcjogXCJiZy1lbWVyYWxkLTEwMFwiLFxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1pbnNldC0xIGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNjAwIHRvLXB1cnBsZS02MDAgcm91bmRlZC14bCBibHVyLW1kIG9wYWNpdHktNzUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbiBkdXJhdGlvbi01MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTEyIGgtMTIgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MDAgdG8tcHVycGxlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8QmFua25vdGUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNsYXRlLTgwMCB2aWEtcHVycGxlLTgwMCB0by1zbGF0ZS04MDAgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICBQYXltZW50LUluIE1hbmFnZW1lbnRcclxuICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICBNYW5hZ2UgYW5kIHZpZXcgcGF5bWVudC1pbiBpbmZvcm1hdGlvbiBhbmQgdHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMTJcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItNiBib3JkZXItYiBwYi0zXCI+XHJcbiAgICAgICAgICAgICAgICBQYXltZW50IFNlY3Rpb25cclxuICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIHtwYXltZW50Q2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTbWFsbENhcmQga2V5PXtjYXRlZ29yeS5pZH0gY2F0ZWdvcnk9e2NhdGVnb3J5fSAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8U21hbGxDYXJkIGNhdGVnb3J5PXtvdmVydmlld0NhcmR9IG9uQ2xpY2s9e2hhbmRsZU92ZXJ2aWV3Q2xpY2t9IC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMlwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi02IGJvcmRlci1iIHBiLTNcIj5cclxuICAgICAgICAgICAgICAgIEVtcGxveWVlIFNlY3Rpb25cclxuICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIHtlbXBsb3llZUNhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U21hbGxDYXJkIGtleT17Y2F0ZWdvcnkuaWR9IGNhdGVnb3J5PXtjYXRlZ29yeX0gLz5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC01IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHZpYS1wdXJwbGUtNTAgdG8tcGluay01MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXdoaXRlLzQwIHNoYWRvdy1tZCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy0zMiBoLTMyIGJnLWdyYWRpZW50LXRvLWJsIGZyb20tdmlvbGV0LTIwMC8yMCB0by10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYmx1ci0yeGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIGxlZnQtMCB3LTMyIGgtMzIgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1wdXJwbGUtMjAwLzIwIHRvLXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBibHVyLTJ4bFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1pbnNldC0xIGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNDAwIHRvLXB1cnBsZS00MDAgcm91bmRlZC14bCBibHVyLW1kIG9wYWNpdHktNTBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTEwIGgtMTAgcm91bmRlZC14bCBiZy13aGl0ZSBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC12aW9sZXQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBRdWljayBUaXBzXHJcbiAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC12aW9sZXQtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICBVc2UgUmVnaXN0cmF0aW9uLUZlZSwgUGF5bWVudCBSZWNlaXB0LCBQZW5hbHR5LCBTdXNwZW5zZSAmIFBheW1lbnQgTGlua3MgZGlyZWN0b3JpZXMuXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIPCfk4ogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5PdmVydmlldyBjYXJkPC9zcGFuPiBpcyBwcm90ZWN0ZWQg4oCUIG9ubHkgU3VwZXJhZG1pbiBjYW4gdmlldyByZWFsIHBheW1lbnQtaW4gdG90YWxzIChmZXRjaGVkIGZyb20gbGl2ZSBBUEkpLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogT3ZlcnZpZXcgTW9kYWwgd2l0aCBBUEkgRGF0YSBhbmQgQ29tcGFjdCBGaWx0ZXIgKi99XHJcbiAgICAgIHtzaG93T3ZlcnZpZXdNb2RhbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJsYWNrLzUwIGJhY2tkcm9wLWJsdXItc21cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctd2hpdGUgcm91bmRlZC0yeGwgdy1mdWxsIG1heC13LTN4bCBtYXgtaC1bODV2aF0gb3ZlcmZsb3cteS1hdXRvIHNoYWRvdy0yeGxcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgYmctd2hpdGUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIHB4LTYgcHktNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1lbWVyYWxkLTEwMCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCYXJDaGFydDMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+UGF5bWVudCBJbiBPdmVydmlldzwvaDI+XHJcbiAgICAgICAgICAgICAgICB7aXNTdXBlckFkbWluICYmICFpc0F1dGhlbnRpY2F0ZWRGb3JPdmVydmlldyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC14cyBiZy1hbWJlci0xMDAgdGV4dC1hbWJlci03MDAgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsXCI+U3VwZXJhZG1pbiByZXF1aXJlZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtjbG9zZU1vZGFsfSBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtc2xhdGUtNTAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtM1wiPlxyXG4gICAgICAgICAgICAgIHshaXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXcgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtNCBiZy1hbWJlci01MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYW1iZXItMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWFtYmVyLTgwMFwiPlRoaXMgc2VjdGlvbiBjb250YWlucyBzZW5zaXRpdmUgcGF5bWVudCBzdGF0aXN0aWNzLiBPbmx5IFN1cGVyYWRtaW4gY2FuIGFjY2Vzcy48L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+RW50ZXIgU3VwZXJhZG1pbiBQYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiBlLmtleSA9PT0gXCJFbnRlclwiICYmIHZlcmlmeVBhc3N3b3JkQW5kU2hvd0RhdGEoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQteGwgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwYXNzd29yZEVycm9yICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSB0ZXh0LXJlZC02MDAgYmctcmVkLTUwIHAtMiByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Bhc3N3b3JkRXJyb3J9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXt2ZXJpZnlQYXNzd29yZEFuZFNob3dEYXRhfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSBiZy1ncmFkaWVudC10by1yIGZyb20tZW1lcmFsZC02MDAgdG8tdGVhbC02MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBVbmxvY2sgT3ZlcnZpZXdcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIHRleHQtY2VudGVyIG10LTJcIj5EZW1vIHBhc3N3b3JkOiA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj4xMjM0NTwvc3Bhbj48L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBEYXRlIEZpbHRlciBTZWN0aW9uIC0gQ29tcGFjdCBTZWxlY3QgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBcIj5GaWx0ZXIgYnkgRGF0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbHRlckNoYW5nZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLWF1dG8gcHgtMyBweS0xIHRleHQtc20gYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCBvdXRsaW5lLW5vbmUgYmctd2hpdGUgbWluLXctWzE0MHB4XVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0b2RheVwiPlRvZGF5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ5ZXN0ZXJkYXlcIj5ZZXN0ZXJkYXk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInRoaXNNb250aFwiPlRoaXMgTW9udGg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImxhc3RNb250aFwiPkxhc3QgTW9udGg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImN1c3RvbVwiPkN1c3RvbSBSYW5nZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b20gRGF0ZSBQaWNrZXIgLSBzaG93biBvbmx5IHdoZW4gXCJDdXN0b20gUmFuZ2VcIiBpcyBzZWxlY3RlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICB7c2hvd0N1c3RvbURhdGVQaWNrZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5Gcm9tIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbUZyb21EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEN1c3RvbUZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZSB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlRvIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbVRvRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21Ub0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgb3V0bGluZS1ub25lIHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDdXN0b21EYXRlQXBwbHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjdXN0b21Gcm9tRGF0ZSB8fCAhY3VzdG9tVG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke2N1c3RvbUZyb21EYXRlICYmIGN1c3RvbVRvRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWVtZXJhbGQtNjAwIHRleHQtd2hpdGUgaG92ZXI6YmctZW1lcmFsZC03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktMzAwIHRleHQtZ3JheS01MDAgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQXBwbHkgQ3VzdG9tIFJhbmdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIERhdGUgUmFuZ2UgRGlzcGxheSAqL31cclxuICAgICAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPkN1cnJlbnQgUmFuZ2U6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgcHgtMiBweS0wLjUgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z2V0RGF0ZVJhbmdlRGlzcGxheSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7b3ZlcnZpZXdEYXRhLmxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB5LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC04IHctOCBib3JkZXItYi0yIGJvcmRlci1lbWVyYWxkLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogb3ZlcnZpZXdEYXRhLmVycm9yID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIHRleHQtY2VudGVyIHB5LTRcIj5FcnJvcjoge292ZXJ2aWV3RGF0YS5lcnJvcn08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6IG92ZXJ2aWV3RGF0YS5jYXRlZ29yaWVzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTggdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE5vIHBheW1lbnQgZGF0YSBmb3VuZCBmb3IgdGhlIHNlbGVjdGVkIGRhdGUgcmFuZ2UuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBUb3RhbCBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MCB0by1wdXJwbGUtNTAgcm91bmRlZC14bCBwLTMgYm9yZGVyIGJvcmRlci12aW9sZXQtMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXZpb2xldC03MDBcIj5UT1RBTCBQQVlNRU5UIElOPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbmRpYW5SdXBlZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdmlvbGV0LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7Zm9ybWF0SW5kaWFuTnVtYmVyKG92ZXJ2aWV3RGF0YS50b3RhbFBheW1lbnRJbil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRm9yIHNlbGVjdGVkIGRhdGUgcmFuZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIENhdGVnb3JpZXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1tZCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0zXCI+UGF5bWVudCBJbiBDYXRlZ29yaWVzPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgbWF4LWgtWzMwMHB4XSBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7b3ZlcnZpZXdEYXRhLmNhdGVnb3JpZXMubWFwKChjYXQsIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMi41IGJnLXNsYXRlLTUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPntjYXQubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7Zm9ybWF0SW5kaWFuTnVtYmVyKGNhdC5hbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBpdGFsaWMgYm9yZGVyLXQgcHQtMyBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICogRGF0YSBmZXRjaGVkIGZyb20gbGl2ZSBBUEkuIENhdGVnb3JpZXMgYXJlIGdyb3VwZWQgYnkgcGF5bWVudCB0eXBlLlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPHN0eWxlIGpzeD57YFxyXG4gICAgICAgIC5saW5lLWNsYW1wLTIge1xyXG4gICAgICAgICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XHJcbiAgICAgICAgICAtd2Via2l0LWxpbmUtY2xhbXA6IDI7XHJcbiAgICAgICAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xyXG4gICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICB9XHJcbiAgICAgIGB9PC9zdHlsZT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYXlJbk1lbnU7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1BheUluTWVudS5qc3gifQ==