import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/MonthlyRevenue.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, DatePicker, Button, Card, Row, Col, Space, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  SyncOutlined,
  FilterOutlined,
  CloseCircleOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const MonthlyRevenue = () => {
  _s();
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [monthlyRevenue, setMonthlyRevenue] = useState(0);
  const [isFilterVisible, setIsFilterVisible] = useState(false);
  const [groupList, setGroupList] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [dateRange, setDateRange] = useState(null);
  const formatPayDate = (dateString) => {
    return dateString?.split("T")[0];
  };
  const fetchPayments = async (filters = {}) => {
    try {
      setLoading(true);
      const today = /* @__PURE__ */ new Date();
      const currentMonth = today.getMonth();
      const currentYear = today.getFullYear();
      let from_date, to_date;
      if (filters.dateRange && filters.dateRange.length === 2) {
        from_date = filters.dateRange[0].format("YYYY-MM-DD");
        to_date = filters.dateRange[1].format("YYYY-MM-DD");
      } else {
        from_date = `${currentYear}-${String(currentMonth + 1).padStart(2, "0")}-01`;
        to_date = new Date(currentYear, currentMonth + 1, 0).toISOString().split("T")[0];
      }
      const resMonthly = await api.get("/payment/get-current-month-payment", {
        params: { from_date, to_date }
      });
      setMonthlyRevenue(resMonthly.data?.monthlyPayment || 0);
      const resPayments = await api.get("/payment/get-payments-by-dates", {
        params: { from_date, to_date }
      });
      let data = resPayments.data || [];
      if (filters.group) {
        data = data.filter((p) => p.group_id?._id === filters.group);
      }
      const formattedData = data.map((p, i) => ({
        id: i + 1,
        customer: p?.user_id?.full_name,
        phone: p?.user_id?.phone_number,
        group: p?.group_id?.group_name,
        ticket: p.ticket,
        receipt: p.receipt_no,
        amount: p.amount,
        pay_type: p.pay_type,
        date: formatPayDate(p?.pay_date),
        collected_by: p?.collected_by?.name || p?.admin_type?.admin_name || "Super Admin"
      }));
      setPayments(formattedData);
    } catch (err) {
      console.error("Error fetching monthly revenue data:", err);
      setPayments([]);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    const init = async () => {
      try {
        const resGroups = await api.get("/group/get-group-admin");
        setGroupList(resGroups.data || []);
      } catch (err) {
        console.error("Error fetching groups:", err);
      }
      fetchPayments({});
    };
    init();
  }, []);
  const handleFilterChange = () => {
    fetchPayments({
      group: selectedGroup,
      dateRange
    });
  };
  const handleClearFilters = () => {
    setSelectedGroup(null);
    setDateRange(null);
    fetchPayments({});
  };
  const columns = [
    { key: "id", header: "SL. NO", width: 60 },
    { key: "date", header: "Paid Date" },
    { key: "customer", header: "Customer Name" },
    { key: "phone", header: "Phone" },
    { key: "group", header: "Group" },
    { key: "ticket", header: "Ticket #" },
    { key: "receipt", header: "Receipt #" },
    { key: "amount", header: "Amount", align: "right" },
    { key: "pay_type", header: "Payment Type" },
    { key: "collected_by", header: "Collected By" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen mt-20 bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
      lineNumber: 128,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-grow", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
        lineNumber: 130,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-grow p-4 md:p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6 bg-white shadow-sm rounded-lg p-4 border-b border-gray-200", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800", children: "Monthly Revenue" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                lineNumber: 138,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-3 py-1 bg-violet-50 text-violet-700 rounded-full text-sm font-medium", children: /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-2xl", children: monthlyRevenue.toLocaleString() }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                lineNumber: 140,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                lineNumber: 139,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
              lineNumber: 137,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(Tooltip, { title: "Refresh Data", children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  icon: /* @__PURE__ */ jsxDEV(SyncOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                    lineNumber: 148,
                    columnNumber: 27
                  }, this),
                  onClick: () => fetchPayments({}),
                  size: "large",
                  type: "text",
                  className: "text-gray-600 hover:text-violet-600"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                  lineNumber: 147,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                lineNumber: 146,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Tooltip, { title: isFilterVisible ? "Hide Filters" : "Show Filters", children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  icon: isFilterVisible ? /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                    lineNumber: 158,
                    columnNumber: 45
                  }, this) : /* @__PURE__ */ jsxDEV(FilterOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                    lineNumber: 158,
                    columnNumber: 71
                  }, this),
                  size: "large",
                  type: "text",
                  onClick: () => setIsFilterVisible(!isFilterVisible),
                  className: `${isFilterVisible ? "text-violet-600" : "text-gray-600"} hover:text-violet-700`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                  lineNumber: 157,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                lineNumber: 156,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
              lineNumber: 145,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
            lineNumber: 135,
            columnNumber: 13
          }, this),
          isFilterVisible && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [8, 8], className: "flex-wrap", children: [
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 4, children: /* @__PURE__ */ jsxDEV(
              Select,
              {
                allowClear: true,
                placeholder: "Group",
                className: "w-full",
                value: selectedGroup,
                onChange: setSelectedGroup,
                options: groupList.map((g) => ({
                  label: g.group_name,
                  value: g._id
                })),
                size: "small"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                lineNumber: 173,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
              lineNumber: 172,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 4, children: /* @__PURE__ */ jsxDEV(Space, { children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "small",
                  type: "text",
                  onClick: handleClearFilters,
                  className: "text-gray-500 hover:text-red-500",
                  children: "Clear All"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                  lineNumber: 190,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "small",
                  type: "primary",
                  onClick: handleFilterChange,
                  loading,
                  className: "bg-violet-600 hover:bg-violet-700",
                  children: "Apply"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
                  lineNumber: 198,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
              lineNumber: 189,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
              lineNumber: 188,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
            lineNumber: 171,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
            lineNumber: 170,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
          lineNumber: 134,
          columnNumber: 11
        }, this),
        loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Revenue Data" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
          lineNumber: 217,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
          lineNumber: 216,
          columnNumber: 11
        }, this) : payments.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: payments,
            columns,
            exportedPdfName: "Monthly Revenue",
            exportedFileName: "MonthlyRevenue.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
            lineNumber: 220,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV(Card, { className: "text-center py-12 bg-white shadow-sm rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 text-lg", children: "No payments found for this period. Try adjusting your filters." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
          lineNumber: 228,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
          lineNumber: 227,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
        lineNumber: 132,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
      lineNumber: 129,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx",
    lineNumber: 127,
    columnNumber: 5
  }, this);
};
_s(MonthlyRevenue, "rFZsSW5xs05ftTH0CI0LPm0Ihg0=");
_c = MonthlyRevenue;
export default MonthlyRevenue;
var _c;
$RefreshReg$(_c, "MonthlyRevenue");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MonthlyRevenue.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0hNOzJCQS9ITjtBQUFvQkEsb0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsUUFBUUMsWUFBWUMsUUFBUUMsTUFBTUMsS0FBS0MsS0FBS0MsT0FBT0MsZUFBZTtBQUMzRTtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQyxpQkFBaUJBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSXBCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNxQixTQUFTQyxVQUFVLElBQUl0QixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDdUIsZ0JBQWdCQyxpQkFBaUIsSUFBSXhCLFNBQVMsQ0FBQztBQUN0RCxRQUFNLENBQUN5QixpQkFBaUJDLGtCQUFrQixJQUFJMUIsU0FBUyxLQUFLO0FBRzVELFFBQU0sQ0FBQzJCLFdBQVdDLFlBQVksSUFBSTVCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM2QixlQUFlQyxnQkFBZ0IsSUFBSTlCLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUMrQixXQUFXQyxZQUFZLElBQUloQyxTQUFTLElBQUk7QUFFL0MsUUFBTWlDLGdCQUFnQkEsQ0FBQ0MsZUFBZTtBQUNwQyxXQUFPQSxZQUFZQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDakM7QUFFQSxRQUFNQyxnQkFBZ0IsT0FBT0MsVUFBVSxDQUFDLE1BQU07QUFDNUMsUUFBSTtBQUNGZixpQkFBVyxJQUFJO0FBRWYsWUFBTWdCLFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsWUFBTUMsZUFBZUYsTUFBTUcsU0FBUztBQUNwQyxZQUFNQyxjQUFjSixNQUFNSyxZQUFZO0FBQ3RDLFVBQUlDLFdBQVdDO0FBRWYsVUFBSVIsUUFBUU4sYUFBYU0sUUFBUU4sVUFBVWUsV0FBVyxHQUFHO0FBQ3ZERixvQkFBWVAsUUFBUU4sVUFBVSxDQUFDLEVBQUVnQixPQUFPLFlBQVk7QUFDcERGLGtCQUFVUixRQUFRTixVQUFVLENBQUMsRUFBRWdCLE9BQU8sWUFBWTtBQUFBLE1BQ3BELE9BQU87QUFDTEgsb0JBQVksR0FBR0YsV0FBVyxJQUFJTSxPQUFPUixlQUFlLENBQUMsRUFBRVMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUN2RUosa0JBQVUsSUFBSU4sS0FBS0csYUFBYUYsZUFBZSxHQUFHLENBQUMsRUFBRVUsWUFBWSxFQUFFZixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDakY7QUFFQSxZQUFNZ0IsYUFBYSxNQUFNaEQsSUFBSWlELElBQUksc0NBQXNDO0FBQUEsUUFDckVDLFFBQVEsRUFBRVQsV0FBV0MsUUFBUTtBQUFBLE1BQy9CLENBQUM7QUFDRHJCLHdCQUFrQjJCLFdBQVdHLE1BQU1DLGtCQUFrQixDQUFDO0FBR3RELFlBQU1DLGNBQWMsTUFBTXJELElBQUlpRCxJQUFJLGtDQUFrQztBQUFBLFFBQ2xFQyxRQUFRLEVBQUVULFdBQVdDLFFBQVE7QUFBQSxNQUMvQixDQUFDO0FBRUQsVUFBSVMsT0FBT0UsWUFBWUYsUUFBUTtBQUcvQixVQUFJakIsUUFBUW9CLE9BQU87QUFDakJILGVBQU9BLEtBQUtJLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsVUFBVUMsUUFBUXhCLFFBQVFvQixLQUFLO0FBQUEsTUFDN0Q7QUFFQSxZQUFNSyxnQkFBZ0JSLEtBQUtTLElBQUksQ0FBQ0osR0FBR0ssT0FBTztBQUFBLFFBQ3hDQyxJQUFJRCxJQUFJO0FBQUEsUUFDUkUsVUFBVVAsR0FBR1EsU0FBU0M7QUFBQUEsUUFDdEJDLE9BQU9WLEdBQUdRLFNBQVNHO0FBQUFBLFFBQ25CYixPQUFPRSxHQUFHQyxVQUFVVztBQUFBQSxRQUNwQkMsUUFBUWIsRUFBRWE7QUFBQUEsUUFDVkMsU0FBU2QsRUFBRWU7QUFBQUEsUUFDWEMsUUFBUWhCLEVBQUVnQjtBQUFBQSxRQUNWQyxVQUFVakIsRUFBRWlCO0FBQUFBLFFBQ1pDLE1BQU01QyxjQUFjMEIsR0FBR21CLFFBQVE7QUFBQSxRQUMvQkMsY0FDRXBCLEdBQUdvQixjQUFjQyxRQUFRckIsR0FBR3NCLFlBQVlDLGNBQWM7QUFBQSxNQUMxRCxFQUFFO0FBRUY5RCxrQkFBWTBDLGFBQWE7QUFBQSxJQUMzQixTQUFTcUIsS0FBSztBQUNaQyxjQUFRQyxNQUFNLHdDQUF3Q0YsR0FBRztBQUN6RC9ELGtCQUFZLEVBQUU7QUFBQSxJQUNoQixVQUFDO0FBQ0NFLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQWdFLFlBQVUsTUFBTTtBQUNkLFVBQU1DLE9BQU8sWUFBWTtBQUN2QixVQUFJO0FBRUYsY0FBTUMsWUFBWSxNQUFNckYsSUFBSWlELElBQUksd0JBQXdCO0FBQ3hEeEIscUJBQWE0RCxVQUFVbEMsUUFBUSxFQUFFO0FBQUEsTUFDbkMsU0FBUzZCLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0sMEJBQTBCRixHQUFHO0FBQUEsTUFDN0M7QUFDQS9DLG9CQUFjLENBQUMsQ0FBQztBQUFBLElBQ2xCO0FBQ0FtRCxTQUFLO0FBQUEsRUFDUCxHQUFHLEVBQUU7QUFFTCxRQUFNRSxxQkFBcUJBLE1BQU07QUFDL0JyRCxrQkFBYztBQUFBLE1BQ1pxQixPQUFPNUI7QUFBQUEsTUFDUEU7QUFBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU0yRCxxQkFBcUJBLE1BQU07QUFDL0I1RCxxQkFBaUIsSUFBSTtBQUNyQkUsaUJBQWEsSUFBSTtBQUNqQkksa0JBQWMsQ0FBQyxDQUFDO0FBQUEsRUFDbEI7QUFFQSxRQUFNdUQsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxNQUFNQyxRQUFRLFVBQVVDLE9BQU8sR0FBRztBQUFBLElBQ3pDLEVBQUVGLEtBQUssUUFBUUMsUUFBUSxZQUFZO0FBQUEsSUFDbkMsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLGdCQUFnQjtBQUFBLElBQzNDLEVBQUVELEtBQUssU0FBU0MsUUFBUSxRQUFRO0FBQUEsSUFDaEMsRUFBRUQsS0FBSyxTQUFTQyxRQUFRLFFBQVE7QUFBQSxJQUNoQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsV0FBVztBQUFBLElBQ3BDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxZQUFZO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFVBQVVFLE9BQU8sUUFBUTtBQUFBLElBQ2xELEVBQUVILEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLEVBQUM7QUFHakQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSwyQkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBQ1IsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUV6Qix1QkFBQyxVQUFLLFdBQVUsd0JBRWQ7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbUVBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsb0NBQW1DLCtCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRTtBQUFBLGNBQ2hFLHVCQUFDLFNBQUksV0FBVSxtR0FDYixpQ0FBQyxVQUFLLFdBQVUsc0JBQXNCdEUseUJBQWV5RSxlQUFlLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFLEtBRHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxXQUFRLE9BQU0sZ0JBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFhO0FBQUEsa0JBQ25CLFNBQVMsTUFBTTVELGNBQWMsQ0FBQyxDQUFDO0FBQUEsa0JBQy9CLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBO0FBQUEsZ0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS2lELEtBTm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUVBLHVCQUFDLFdBQVEsT0FBT1gsa0JBQWtCLGlCQUFpQixnQkFDakQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTUEsa0JBQWtCLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9CLElBQU0sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZTtBQUFBLGtCQUNqRSxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTUMsbUJBQW1CLENBQUNELGVBQWU7QUFBQSxrQkFDbEQsV0FBVyxHQUFHQSxrQkFBa0Isb0JBQW9CLGVBQWU7QUFBQTtBQUFBLGdCQUxyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLOEYsS0FOaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGlCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLGVBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBO0FBQUEsVUFHQ0EsbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLHNDQUNiLGlDQUFDLE9BQUksUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFdBQVUsYUFDN0I7QUFBQSxtQ0FBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksR0FDOUI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUEsZ0JBQ1YsT0FBT0k7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1YsU0FBU0gsVUFBVW9DLElBQUksQ0FBQ2tDLE9BQU87QUFBQSxrQkFDN0JDLE9BQU9ELEVBQUUxQjtBQUFBQSxrQkFDVDRCLE9BQU9GLEVBQUVwQztBQUFBQSxnQkFDWCxFQUFFO0FBQUEsZ0JBQ0YsTUFBSztBQUFBO0FBQUEsY0FWUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVYyxLQVhoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsWUFHQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksR0FDOUIsaUNBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsU0FBUzZCO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFBa0M7QUFBQTtBQUFBLGdCQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxTQUFTRDtBQUFBQSxrQkFDVDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFBbUM7QUFBQTtBQUFBLGdCQUwvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLGVBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0NBLEtBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0NBO0FBQUEsYUE1RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThFQTtBQUFBLFFBR0NwRSxVQUNDLHVCQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxrQkFBZSxXQUFXLE1BQU0sTUFBSyxrQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFDRUYsU0FBUzJCLFNBQVMsSUFDcEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU0zQjtBQUFBQSxZQUNOO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBaUI7QUFBQTtBQUFBLFVBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl1QyxJQUd2Qyx1QkFBQyxRQUFLLFdBQVUsbURBQ2QsaUNBQUMsU0FBSSxXQUFVLHlCQUF3Qiw4RUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FuR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFHQTtBQUFBLFNBeEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5R0E7QUFBQSxPQTNHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEdBO0FBRUo7QUFBRUQsR0EvTklELGdCQUFjO0FBQUFtRixLQUFkbkY7QUFpT04sZUFBZUE7QUFBZSxJQUFBbUY7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2lkZWJhciIsIk5hdmJhciIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiU2VsZWN0IiwiRGF0ZVBpY2tlciIsIkJ1dHRvbiIsIkNhcmQiLCJSb3ciLCJDb2wiLCJTcGFjZSIsIlRvb2x0aXAiLCJTeW5jT3V0bGluZWQiLCJGaWx0ZXJPdXRsaW5lZCIsIkNsb3NlQ2lyY2xlT3V0bGluZWQiLCJNb250aGx5UmV2ZW51ZSIsIl9zIiwicGF5bWVudHMiLCJzZXRQYXltZW50cyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwibW9udGhseVJldmVudWUiLCJzZXRNb250aGx5UmV2ZW51ZSIsImlzRmlsdGVyVmlzaWJsZSIsInNldElzRmlsdGVyVmlzaWJsZSIsImdyb3VwTGlzdCIsInNldEdyb3VwTGlzdCIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwiZGF0ZVJhbmdlIiwic2V0RGF0ZVJhbmdlIiwiZm9ybWF0UGF5RGF0ZSIsImRhdGVTdHJpbmciLCJzcGxpdCIsImZldGNoUGF5bWVudHMiLCJmaWx0ZXJzIiwidG9kYXkiLCJEYXRlIiwiY3VycmVudE1vbnRoIiwiZ2V0TW9udGgiLCJjdXJyZW50WWVhciIsImdldEZ1bGxZZWFyIiwiZnJvbV9kYXRlIiwidG9fZGF0ZSIsImxlbmd0aCIsImZvcm1hdCIsIlN0cmluZyIsInBhZFN0YXJ0IiwidG9JU09TdHJpbmciLCJyZXNNb250aGx5IiwiZ2V0IiwicGFyYW1zIiwiZGF0YSIsIm1vbnRobHlQYXltZW50IiwicmVzUGF5bWVudHMiLCJncm91cCIsImZpbHRlciIsInAiLCJncm91cF9pZCIsIl9pZCIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJpIiwiaWQiLCJjdXN0b21lciIsInVzZXJfaWQiLCJmdWxsX25hbWUiLCJwaG9uZSIsInBob25lX251bWJlciIsImdyb3VwX25hbWUiLCJ0aWNrZXQiLCJyZWNlaXB0IiwicmVjZWlwdF9ubyIsImFtb3VudCIsInBheV90eXBlIiwiZGF0ZSIsInBheV9kYXRlIiwiY29sbGVjdGVkX2J5IiwibmFtZSIsImFkbWluX3R5cGUiLCJhZG1pbl9uYW1lIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwidXNlRWZmZWN0IiwiaW5pdCIsInJlc0dyb3VwcyIsImhhbmRsZUZpbHRlckNoYW5nZSIsImhhbmRsZUNsZWFyRmlsdGVycyIsImNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJ3aWR0aCIsImFsaWduIiwidG9Mb2NhbGVTdHJpbmciLCJnIiwibGFiZWwiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vbnRobHlSZXZlbnVlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIERhdGVQaWNrZXIsIEJ1dHRvbiwgQ2FyZCwgUm93LCBDb2wsIFNwYWNlLCBUb29sdGlwIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHtcclxuICBTeW5jT3V0bGluZWQsXHJcbiAgRmlsdGVyT3V0bGluZWQsXHJcbiAgQ2xvc2VDaXJjbGVPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmNvbnN0IE1vbnRobHlSZXZlbnVlID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtwYXltZW50cywgc2V0UGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9udGhseVJldmVudWUsIHNldE1vbnRobHlSZXZlbnVlXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtpc0ZpbHRlclZpc2libGUsIHNldElzRmlsdGVyVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7IC8vIE9wdGlvbmFsOiBzdGFydCBoaWRkZW5cclxuXHJcbiAgLy8gRmlsdGVyc1xyXG4gIGNvbnN0IFtncm91cExpc3QsIHNldEdyb3VwTGlzdF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2RhdGVSYW5nZSwgc2V0RGF0ZVJhbmdlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICBjb25zdCBmb3JtYXRQYXlEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIHJldHVybiBkYXRlU3RyaW5nPy5zcGxpdChcIlRcIilbMF07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hQYXltZW50cyA9IGFzeW5jIChmaWx0ZXJzID0ge30pID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnRNb250aCA9IHRvZGF5LmdldE1vbnRoKCk7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnRZZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuICAgICAgbGV0IGZyb21fZGF0ZSwgdG9fZGF0ZTtcclxuXHJcbiAgICAgIGlmIChmaWx0ZXJzLmRhdGVSYW5nZSAmJiBmaWx0ZXJzLmRhdGVSYW5nZS5sZW5ndGggPT09IDIpIHtcclxuICAgICAgICBmcm9tX2RhdGUgPSBmaWx0ZXJzLmRhdGVSYW5nZVswXS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xyXG4gICAgICAgIHRvX2RhdGUgPSBmaWx0ZXJzLmRhdGVSYW5nZVsxXS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZyb21fZGF0ZSA9IGAke2N1cnJlbnRZZWFyfS0ke1N0cmluZyhjdXJyZW50TW9udGggKyAxKS5wYWRTdGFydCgyLCBcIjBcIil9LTAxYDtcclxuICAgICAgICB0b19kYXRlID0gbmV3IERhdGUoY3VycmVudFllYXIsIGN1cnJlbnRNb250aCArIDEsIDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZXNNb250aGx5ID0gYXdhaXQgYXBpLmdldChcIi9wYXltZW50L2dldC1jdXJyZW50LW1vbnRoLXBheW1lbnRcIiwge1xyXG4gICAgICAgIHBhcmFtczogeyBmcm9tX2RhdGUsIHRvX2RhdGUgfSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldE1vbnRobHlSZXZlbnVlKHJlc01vbnRobHkuZGF0YT8ubW9udGhseVBheW1lbnQgfHwgMCk7XHJcblxyXG5cclxuICAgICAgY29uc3QgcmVzUGF5bWVudHMgPSBhd2FpdCBhcGkuZ2V0KFwiL3BheW1lbnQvZ2V0LXBheW1lbnRzLWJ5LWRhdGVzXCIsIHtcclxuICAgICAgICBwYXJhbXM6IHsgZnJvbV9kYXRlLCB0b19kYXRlIH0sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgbGV0IGRhdGEgPSByZXNQYXltZW50cy5kYXRhIHx8IFtdO1xyXG5cclxuXHJcbiAgICAgIGlmIChmaWx0ZXJzLmdyb3VwKSB7XHJcbiAgICAgICAgZGF0YSA9IGRhdGEuZmlsdGVyKChwKSA9PiBwLmdyb3VwX2lkPy5faWQgPT09IGZpbHRlcnMuZ3JvdXApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gZGF0YS5tYXAoKHAsIGkpID0+ICh7XHJcbiAgICAgICAgaWQ6IGkgKyAxLFxyXG4gICAgICAgIGN1c3RvbWVyOiBwPy51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgcGhvbmU6IHA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICBncm91cDogcD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgdGlja2V0OiBwLnRpY2tldCxcclxuICAgICAgICByZWNlaXB0OiBwLnJlY2VpcHRfbm8sXHJcbiAgICAgICAgYW1vdW50OiBwLmFtb3VudCxcclxuICAgICAgICBwYXlfdHlwZTogcC5wYXlfdHlwZSxcclxuICAgICAgICBkYXRlOiBmb3JtYXRQYXlEYXRlKHA/LnBheV9kYXRlKSxcclxuICAgICAgICBjb2xsZWN0ZWRfYnk6XHJcbiAgICAgICAgICBwPy5jb2xsZWN0ZWRfYnk/Lm5hbWUgfHwgcD8uYWRtaW5fdHlwZT8uYWRtaW5fbmFtZSB8fCBcIlN1cGVyIEFkbWluXCIsXHJcbiAgICAgIH0pKTtcclxuXHJcbiAgICAgIHNldFBheW1lbnRzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBtb250aGx5IHJldmVudWUgZGF0YTpcIiwgZXJyKTtcclxuICAgICAgc2V0UGF5bWVudHMoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGluaXQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICBcclxuICAgICAgICBjb25zdCByZXNHcm91cHMgPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuICAgICAgICBzZXRHcm91cExpc3QocmVzR3JvdXBzLmRhdGEgfHwgW10pO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXBzOlwiLCBlcnIpO1xyXG4gICAgICB9XHJcbiAgICAgIGZldGNoUGF5bWVudHMoe30pO1xyXG4gICAgfTtcclxuICAgIGluaXQoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUZpbHRlckNoYW5nZSA9ICgpID0+IHtcclxuICAgIGZldGNoUGF5bWVudHMoe1xyXG4gICAgICBncm91cDogc2VsZWN0ZWRHcm91cCxcclxuICAgICAgZGF0ZVJhbmdlLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xlYXJGaWx0ZXJzID0gKCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cChudWxsKTtcclxuICAgIHNldERhdGVSYW5nZShudWxsKTtcclxuICAgIGZldGNoUGF5bWVudHMoe30pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIsIHdpZHRoOiA2MCB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiUGFpZCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lXCIsIGhlYWRlcjogXCJQaG9uZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cFwiLCBoZWFkZXI6IFwiR3JvdXBcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXQgI1wiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0XCIsIGhlYWRlcjogXCJSZWNlaXB0ICNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiwgYWxpZ246IFwicmlnaHRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJjb2xsZWN0ZWRfYnlcIiwgaGVhZGVyOiBcIkNvbGxlY3RlZCBCeVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gbXQtMjAgYmctZ3JheS01MFwiPlxyXG4gICAgICA8U2lkZWJhciAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC1ncm93XCI+XHJcbiAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG5cclxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC00IG1kOnAtNlwiPlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgYmctd2hpdGUgc2hhZG93LXNtIHJvdW5kZWQtbGcgcC00IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5Nb250aGx5IFJldmVudWU8L2gxPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTEgYmctdmlvbGV0LTUwIHRleHQtdmlvbGV0LTcwMCByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC0yeGxcIj57bW9udGhseVJldmVudWUudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIlJlZnJlc2ggRGF0YVwiPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbj17PFN5bmNPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmZXRjaFBheW1lbnRzKHt9KX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIGhvdmVyOnRleHQtdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcblxyXG4gICAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9e2lzRmlsdGVyVmlzaWJsZSA/IFwiSGlkZSBGaWx0ZXJzXCIgOiBcIlNob3cgRmlsdGVyc1wifT5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGljb249e2lzRmlsdGVyVmlzaWJsZSA/IDxDbG9zZUNpcmNsZU91dGxpbmVkIC8+IDogPEZpbHRlck91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzRmlsdGVyVmlzaWJsZSghaXNGaWx0ZXJWaXNpYmxlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Ake2lzRmlsdGVyVmlzaWJsZSA/IFwidGV4dC12aW9sZXQtNjAwXCIgOiBcInRleHQtZ3JheS02MDBcIn0gaG92ZXI6dGV4dC12aW9sZXQtNzAwYH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQ29sbGFwc2libGUgRmlsdGVycyAqL31cclxuICAgICAgICAgICAge2lzRmlsdGVyVmlzaWJsZSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8Um93IGd1dHRlcj17WzgsIDhdfSBjbGFzc05hbWU9XCJmbGV4LXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezZ9IGxnPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTZWxlY3RlZEdyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17Z3JvdXBMaXN0Lm1hcCgoZykgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGcuZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGcuX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBtZD17Nn0gbGc9ezR9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxTcGFjZT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGVhckZpbHRlcnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1yZWQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ2xlYXIgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVGaWx0ZXJDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXZpb2xldC02MDAgaG92ZXI6YmctdmlvbGV0LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFwcGx5XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1NwYWNlPlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIERhdGEgVGFibGUgKi99XHJcbiAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBoLTY0XCI+XHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gZGF0YT1cIlJldmVudWUgRGF0YVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IHBheW1lbnRzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICBkYXRhPXtwYXltZW50c31cclxuICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIk1vbnRobHkgUmV2ZW51ZVwiXHJcbiAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIk1vbnRobHlSZXZlbnVlLmNzdlwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMiBiZy13aGl0ZSBzaGFkb3ctc20gcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICBObyBwYXltZW50cyBmb3VuZCBmb3IgdGhpcyBwZXJpb2QuIFRyeSBhZGp1c3RpbmcgeW91ciBmaWx0ZXJzLlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTW9udGhseVJldmVudWU7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL01vbnRobHlSZXZlbnVlLmpzeCJ9