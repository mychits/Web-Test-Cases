import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TargetIncentive.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Select, Radio, Tabs } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import { GiPartyPopper } from "/node_modules/.vite/deps/react-icons_gi.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FileTextOutlined, DollarOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaMoneyBill } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { MdPayments } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { FiTarget } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const { TabPane } = Tabs;
const TargetIncentive = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [selectedMonth, setSelectedMonth] = useState(null);
  const [dateSelectionMode, setDateSelectionMode] = useState("month");
  const [agentLoading, setAgentLoading] = useState(false);
  const [selectedEmployeeDetails, setSelectedEmployeeDetails] = useState(null);
  const [employeeCustomerData, setEmployeeCustomerData] = useState([]);
  const [commissionTotalDetails, setCommissionTotalDetails] = useState({});
  const [loading, setLoading] = useState(false);
  const [showCommissionModal, setShowCommissionModal] = useState(false);
  const [commissionForm, setCommissionForm] = useState({
    agent_id: "",
    pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    note: "",
    pay_for: "commission",
    admin_type: ""
  });
  const [errors, setErrors] = useState({});
  const [adminId, setAdminId] = useState("");
  const [adminName, setAdminName] = useState("");
  const [targetData, setTargetData] = useState({
    target: 0,
    achieved: 0,
    remaining: 0,
    startDate: "",
    endDate: "",
    incentiveAmount: 0
  });
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [isFiltering, setIsFiltering] = useState(false);
  const [tempSelectedMonth, setTempSelectedMonth] = useState(null);
  const [tempFromDate, setTempFromDate] = useState(null);
  const [tempToDate, setTempToDate] = useState(null);
  const [activeTab, setActiveTab] = useState("commission");
  const [grossIncentiveData, setGrossIncentiveData] = useState([]);
  const [grossIncentiveSummary, setGrossIncentiveSummary] = useState({
    total_gross_incentive_value: 0,
    total_gross_group_value: 0,
    total_gross_enrollments: 0
  });
  const parseAmount = (val) => parseFloat(val?.toString().replace(/[^0-9.-]+/g, "")) || 0;
  useEffect(() => {
    const today2 = /* @__PURE__ */ new Date();
    const currentMonth2 = `${today2.getFullYear()}-${String(
      today2.getMonth() + 1
    ).padStart(2, "0")}`;
    setTempSelectedMonth(currentMonth2);
    setSelectedMonth(currentMonth2);
    const year = today2.getFullYear();
    const month = today2.getMonth() + 1;
    const firstDay = `${year}-${String(month).padStart(2, "0")}-01`;
    const lastday1 = new Date(year, month, 0).getDate();
    const lastDay = `${year}-${month}-${String(lastday1).padStart(2, "0")}`;
    setTempFromDate(firstDay);
    setTempToDate(lastDay);
    setFromDate(firstDay);
    setToDate(lastDay);
  }, []);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      setAdminId(user._id);
      setAdminName(user.name || "");
    }
  }, []);
  const fetchEmployees = async () => {
    try {
      const res = await api.get("/employee");
      setEmployees(res?.data?.employee);
    } catch (err) {
      console.error("Error fetching employees:", err);
    }
  };
  const fetchCommissionReport = async (employeeId, startDate, endDate) => {
    if (!employeeId || !startDate || !endDate) return;
    const abortController = new AbortController();
    try {
      let params = {
        start_date: startDate,
        end_date: endDate
      };
      const res = await api.get(`/enroll/employee/${employeeId}/incentive`, {
        params,
        signal: abortController.signal
      });
      setEmployeeCustomerData(res.data?.incentiveData);
      setCommissionTotalDetails({
        actual_business: res.data?.incentiveSummary?.total_group_value,
        total_actual: res.data?.incentiveSummary?.total_incentive_value,
        total_customers: res.data?.incentiveSummary?.total_enrollments,
        total_groups: res.data?.incentiveSummary?.total_enrollments,
        expected_business: res.data?.incentiveSummary?.total_group_value,
        total_estimated: res.data?.incentiveSummary?.total_incentive_value
      });
    } catch (err) {
      if (err.name !== "AbortController") {
        console.error("Error fetching employee report:", err);
        setEmployeeCustomerData([]);
        setCommissionTotalDetails({});
      }
    }
  };
  const fetchTargetData = async (employeeId, startDate, endDate) => {
    if (!employeeId || !startDate || !endDate) return;
    try {
      const res = await api.get(`/target/employees/${employeeId}`, {
        params: { start_date: startDate, end_date: endDate }
      });
      if (res.data.status && res.data.total_target !== void 0) {
        const totalTarget = Number(res.data.total_target);
        let params = {
          start_date: startDate,
          end_date: endDate
        };
        const { data: comm } = await api.get(
          `/enroll/employee/${employeeId}/incentive`,
          {
            params
          }
        );
        let achieved = comm?.incentiveSummary?.total_group_value || 0;
        if (typeof achieved === "string") {
          achieved = Number(achieved.replace(/[^0-9.-]+/g, ""));
        }
        const remaining = Math.max(totalTarget - achieved, 0);
        const difference = achieved - totalTarget;
        const incentiveAmount = difference > 0 ? difference * 0.01 : 0;
        setTargetData({
          target: Math.round(totalTarget),
          achieved: Math.round(achieved),
          remaining: Math.round(remaining),
          difference: Math.round(difference),
          startDate,
          endDate,
          incentiveAmount: parseFloat(incentiveAmount.toFixed(2))
        });
      } else {
        throw new Error("Invalid target response");
      }
    } catch (err) {
      console.error("Error fetching target data:", err);
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        difference: 0,
        startDate: "",
        endDate: "",
        incentiveAmount: 0
      });
    }
  };
  const fetchAllCommissionReport = async () => {
    if (!fromDate || !toDate) return;
    const abortController = new AbortController();
    try {
      let params = {
        start_date: fromDate,
        end_date: toDate
      };
      const res = await api.get("/enroll/incentive", {
        params,
        signal: abortController.signal
      });
      setEmployeeCustomerData(res.data?.commissionData);
      setCommissionTotalDetails({
        actual_business: res.data?.commissionSummary?.total_group_value,
        total_actual: res.data?.commissionSummary?.total_commission_value,
        total_customers: res.data?.commissionSummary?.total_enrollments,
        total_groups: res.data?.commissionSummary?.total_enrollments,
        expected_business: res.data?.commissionSummary?.total_group_value,
        total_estimated: res.data?.commissionSummary?.total_commission_value
      });
    } catch (err) {
      if (err.name !== "AbortError") {
        console.error("Error fetching all commission report:", err);
        setEmployeeCustomerData([]);
        setCommissionTotalDetails({});
      }
    }
  };
  const fetchGrossIncentiveReport = async (employeeId, startDate, endDate) => {
    if (!employeeId || !startDate || !endDate) return;
    try {
      let params = {
        start_date: startDate,
        end_date: endDate
      };
      const res = await api.get(
        `/enroll/employee/${employeeId}/gross-incentive`,
        {
          params
        }
      );
      const incentiveData = res.data?.grossIncentiveInfo?.map((enrollment) => ({
        user_name: enrollment?.user_id?.full_name || "N/A",
        phone_number: enrollment?.user_id?.phone_number || "N/A",
        group_name: enrollment?.group_id?.group_name || "N/A",
        group_value: enrollment?.group_id?.group_value || "N/A",
        group_incentive: enrollment?.group_id?.incentives || "N/A",
        group_ticket: enrollment?.tickets || "N/A",
        enrollment_date: enrollment?.createdAt?.split("T")?.[0],
        total_paid_amount: enrollment?.total_paid_amount || "0",
        group_monthly_installment: enrollment?.group_id?.monthly_installment || "N/A"
      }));
      setGrossIncentiveData(incentiveData || []);
      setGrossIncentiveSummary(
        res.data.grossIncentiveSummary || {
          total_gross_incentive_value: 0,
          total_gross_group_value: 0,
          total_gross_enrollments: 0
        }
      );
    } catch (err) {
      console.error("Error fetching gross incentive report:", err);
      setGrossIncentiveData([]);
      setGrossIncentiveSummary({
        total_gross_incentive_value: 0,
        total_gross_group_value: 0,
        total_gross_enrollments: 0
      });
    }
  };
  const fetchAllGrossIncentiveReport = async () => {
    if (!fromDate || !toDate) return;
    try {
      let params = {
        start_date: fromDate,
        end_date: toDate
      };
      const res = await api.get("/enroll/gross-incentive", {
        params
      });
      setGrossIncentiveData(res.data.grossIncentiveInfo || []);
      setGrossIncentiveSummary(
        res.data.grossIncentiveSummary || {
          total_gross_incentive_value: 0,
          total_gross_group_value: 0,
          total_gross_enrollments: 0
        }
      );
    } catch (err) {
      console.error("Error fetching all gross incentive report:", err);
      setGrossIncentiveData([]);
      setGrossIncentiveSummary({
        total_gross_incentive_value: 0,
        total_gross_group_value: 0,
        total_gross_enrollments: 0
      });
    }
  };
  const handleEmployeeChange = (value) => {
    setSelectedEmployeeId(value);
    setSelectedEmployeeDetails(null);
    setEmployeeCustomerData([]);
    setCommissionTotalDetails({});
    setTargetData({
      target: 0,
      achieved: 0,
      remaining: 0,
      startDate: "",
      endDate: "",
      incentiveAmount: 0
    });
    setGrossIncentiveData([]);
    setGrossIncentiveSummary({
      total_gross_incentive_value: 0,
      total_gross_group_value: 0,
      total_gross_enrollments: 0
    });
  };
  const handleTempMonthChange = (e) => {
    const selectedMonth2 = e.target.value;
    setTempSelectedMonth(selectedMonth2);
    if (selectedMonth2) {
      const [year, month] = selectedMonth2.split("-");
      const firstDay = `${year}-${month}-01`;
      const lastday1 = new Date(year, month, 0).getDate();
      const lastDay = `${year}-${month}-${String(lastday1).padStart(2, "0")}`;
      setTempFromDate(firstDay);
      setTempToDate(lastDay);
    }
  };
  const applyFilter = async () => {
    if (!selectedEmployeeId) {
      alert("Please select an employee.");
      return;
    }
    if (dateSelectionMode === "month" && !tempSelectedMonth) {
      alert("Please select a month.");
      return;
    }
    if (dateSelectionMode === "date-range" && (!tempFromDate || !tempToDate)) {
      alert("Please select both From and To dates.");
      return;
    }
    setIsFiltering(true);
    let startDate, endDate;
    if (dateSelectionMode === "month") {
      setSelectedMonth(tempSelectedMonth);
      const [year, month] = tempSelectedMonth.split("-");
      startDate = `${year}-${month}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      endDate = `${year}-${month}-${String(lastDay).padStart(2, "0")}`;
      setFromDate(startDate);
      setToDate(endDate);
    } else {
      startDate = tempFromDate;
      endDate = tempToDate;
      setFromDate(startDate);
      setToDate(endDate);
    }
    setLoading(true);
    setAgentLoading(true);
    try {
      if (selectedEmployeeId === "ALL") {
        setSelectedEmployeeDetails(null);
        setTargetData({
          target: 0,
          achieved: 0,
          remaining: 0,
          startDate: "",
          endDate: "",
          incentiveAmount: 0
        });
        await fetchAllCommissionReport();
        await fetchAllGrossIncentiveReport();
      } else {
        const emp = employees.find((e) => e._id === selectedEmployeeId);
        setSelectedEmployeeDetails(emp || null);
        await fetchCommissionReport(selectedEmployeeId, startDate, endDate);
        await fetchTargetData(selectedEmployeeId, startDate, endDate);
        await fetchGrossIncentiveReport(selectedEmployeeId, startDate, endDate);
      }
    } finally {
      setAgentLoading(false);
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  const handleCommissionChange = (e) => {
    const { name, value } = e.target;
    setCommissionForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!commissionForm.agent_id)
      newErrors.agent_id = "Please select an agent";
    if (!commissionForm.amount || isNaN(commissionForm.amount))
      newErrors.amount = "Please enter a valid amount";
    if (commissionForm.pay_type === "online" && !commissionForm.transaction_id)
      newErrors.transaction_id = "Transaction ID is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleCommissionSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    try {
      const payload = { ...commissionForm, admin_type: adminId };
      await api.post("/payment-out/add-commission-payment", payload);
      alert("Commission Paid Successfully!");
      setShowCommissionModal(false);
    } catch (err) {
      alert("Failed to add payment.");
    }
  };
  const processedTableData = employeeCustomerData.map((item, index) => ({
    ...item,
    group_value_digits: item.group_id?.group_value,
    group_ticket: item.ticket || "N/A",
    estimated_commission_digits: item?.estimated_commission || 0,
    net_incentive_digits: item?.incentive_value || 0,
    incentive_percentage: item?.group_id?.incentives || 0,
    total_paid_digits: item?.total_paid_amount || 0,
    required_installment_digits: item?.group_id?.monthly_installment || 0,
    incentive_released: item.incentive_released ? "Yes" : "No",
    user_name: item.user_id?.full_name || "N/A",
    phone_number: item.user_id?.phone_number || "N/A",
    group_name: item.group_id?.group_name || "N/A",
    enrollment_date: item.createdAt?.split("T")?.[0] || "N/A"
  }));
  const columns = [
    { key: "user_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "group_ticket", header: "Ticket No" },
    { key: "group_value_digits", header: "Group Value" },
    { key: "enrollment_date", header: "Enrollment Date" },
    { key: "incentive_percentage", header: "Net Incentive Percentage" },
    { key: "net_incentive_digits", header: "Net  Incentive" },
    { key: "total_paid_digits", header: "Total Paid" },
    { key: "required_installment_digits", header: "First Installment Amount" },
    { key: "incentive_released", header: "Incentive Released" }
  ];
  const grossIncentiveColumns = [
    { key: "user_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "group_value", header: "Group Value" },
    { key: "group_ticket", header: "Ticket No" },
    { key: "enrollment_date", header: "Enrollment Date" },
    { key: "group_monthly_installment", header: "First Installment Amount" },
    { key: "group_incentive", header: "Incentive Percentage" },
    { key: "total_paid_amount", header: "Total Paid" }
  ];
  const today = /* @__PURE__ */ new Date();
  const currentMonth = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}`;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-screen bg-gray-50", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
      lineNumber: 466,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold text-gray-900", children: "Incentive Reports" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
          lineNumber: 470,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Track and manage employee incentives and commissions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
          lineNumber: 473,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
        lineNumber: 469,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800 mb-6", children: "Report Filters" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
          lineNumber: 480,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "Select Employee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 486,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedEmployeeId || void 0,
                onChange: handleEmployeeChange,
                showSearch: true,
                popupMatchSelectWidth: false,
                placeholder: "Search by name or phone",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                style: { height: "44px" },
                className: "rounded",
                children: employees.map(
                  (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                    emp.name,
                    " - ",
                    emp.phone_number
                  ] }, emp._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 505,
                    columnNumber: 19
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 489,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 485,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "Date Selection" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 514,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-3 bg-gray-50 rounded-lg h-11", children: /* @__PURE__ */ jsxDEV(
              Radio.Group,
              {
                value: dateSelectionMode,
                onChange: (e) => setDateSelectionMode(e.target.value),
                children: [
                  /* @__PURE__ */ jsxDEV(Radio, { value: "month", className: "text-sm", children: "Month" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 522,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Radio, { value: "date-range", className: "text-sm", children: "Range" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 525,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 518,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 517,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 513,
            columnNumber: 15
          }, this),
          dateSelectionMode === "month" ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "Select Month" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 535,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "month",
                value: tempSelectedMonth || "",
                max: currentMonth,
                onChange: handleTempMonthChange,
                className: "border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-violet-500 h-11"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 538,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 534,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "From Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 549,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: tempFromDate || "",
                  max: tempToDate || currentMonth,
                  onChange: (e) => setTempFromDate(e.target.value),
                  className: "border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-violet-500 h-11"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 552,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 548,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "To Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 561,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: tempToDate || "",
                  min: tempFromDate || "",
                  max: currentMonth,
                  onChange: (e) => setTempToDate(e.target.value),
                  className: "border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-violet-500 h-11"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 564,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 560,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 547,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
          lineNumber: 483,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: applyFilter,
            className: "px-8 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold shadow-sm",
            children: "Continue"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 579,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
          lineNumber: 578,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
        lineNumber: 479,
        columnNumber: 11
      }, this),
      agentLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
        lineNumber: 590,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
        lineNumber: 589,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: "/target-menu/target",
              className: "flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-violet-500 hover:bg-violet-50 transition-all group",
              children: [
                /* @__PURE__ */ jsxDEV(
                  FiTarget,
                  {
                    className: "text-violet-600 group-hover:scale-110 transition-transform",
                    size: 24
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 601,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700 group-hover:text-violet-600", children: "Set Target" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 605,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 597,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: "/reports/target-commission",
              className: "flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-violet-500 hover:bg-violet-50 transition-all group",
              children: [
                /* @__PURE__ */ jsxDEV(DollarOutlined, { className: "text-violet-600 group-hover:scale-110 transition-transform text-lg" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 613,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700 group-hover:text-violet-600", children: "Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 614,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 609,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
              className: "flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-violet-500 hover:bg-violet-50 transition-all group",
              children: [
                /* @__PURE__ */ jsxDEV(
                  FaMoneyBill,
                  {
                    className: "text-violet-600 group-hover:scale-110 transition-transform",
                    size: 24
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 622,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700 group-hover:text-violet-600", children: "Salary Payout" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 626,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 618,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
          lineNumber: 596,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
          lineNumber: 595,
          columnNumber: 15
        }, this),
        isFiltering && (dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate) && (selectedEmployeeId === "ALL" || selectedEmployeeDetails) && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8", children: [
          selectedEmployeeId !== "ALL" && selectedEmployeeDetails && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Employee Information" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 644,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 650,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    value: selectedEmployeeDetails?.name || "-",
                    readOnly: true,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 653,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 649,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Email" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 660,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    value: selectedEmployeeDetails?.email || "-",
                    readOnly: true,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 663,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 659,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Phone" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 670,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    value: selectedEmployeeDetails?.phone_number || "-",
                    readOnly: true,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 673,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 669,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 648,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Adhaar" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 685,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    value: selectedEmployeeDetails?.adhaar_no || "-",
                    readOnly: true,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 688,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 684,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "PAN" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 697,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    value: selectedEmployeeDetails?.pan_no || "-",
                    readOnly: true,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 700,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 696,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Pincode" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 707,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    value: selectedEmployeeDetails?.pincode || "-",
                    readOnly: true,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 710,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 706,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 683,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Address" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 720,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    value: selectedEmployeeDetails?.address || "-",
                    readOnly: true,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 723,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 719,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Joining Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 730,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    value: selectedEmployeeDetails?.joining_date ? selectedEmployeeDetails.joining_date.split(
                      "T"
                    )[0] : "-",
                    readOnly: true,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 733,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 729,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 718,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("hr", { className: "my-6" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 746,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 643,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Commission Summary" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 751,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Net Business" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 756,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: commissionTotalDetails?.actual_business || "-",
                  readOnly: true,
                  className: "w-full bg-transparent text-2xl font-bold text-green-700 mt-2 border-0"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 759,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-green-700 mt-1 block", children: numberToIndianWords(
                parseAmount(commissionTotalDetails?.actual_business)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 764,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 755,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-50 to-violet-100 border border-violet-200 rounded-lg p-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Net Incentive (1% each)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 771,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: commissionTotalDetails?.total_actual || "-",
                  readOnly: true,
                  className: "w-full bg-transparent text-2xl font-bold text-violet-700 mt-2 border-0"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 774,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-violet-700 mt-1 block", children: numberToIndianWords(
                parseAmount(commissionTotalDetails?.total_actual)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 779,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 770,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-lg p-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Net Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 786,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: commissionTotalDetails?.total_customers || "-",
                  readOnly: true,
                  className: "w-full bg-transparent text-2xl font-bold text-purple-700 mt-2 border-0"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 789,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 785,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 754,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
          lineNumber: 640,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Tabs, { activeKey: activeTab, onChange: setActiveTab, children: [
          /* @__PURE__ */ jsxDEV(TabPane, { tab: "Net Incentive Report", children: [
            isFiltering && (dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate) && selectedEmployeeId && selectedEmployeeId !== "ALL" && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800", children: "Target Performance" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 813,
                  columnNumber: 27
                }, this),
                targetData.achieved >= targetData.target && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-4 py-2 rounded-lg bg-green-100 border border-green-300", children: [
                  /* @__PURE__ */ jsxDEV(
                    GiPartyPopper,
                    {
                      size: 24,
                      className: "text-green-600"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 818,
                      columnNumber: 31
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-green-700 font-semibold", children: [
                    "Target Achieved!",
                    " "
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 822,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 817,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 812,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-50 to-violet-100 border border-violet-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Target Set" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 830,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-violet-700 mt-2", children: `${targetData.target?.toLocaleString("en-IN")}` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 833,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-violet-700 mt-1 block", children: numberToIndianWords(targetData.target || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 836,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 829,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Achieved" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 841,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-green-700 mt-2", children: `${targetData.achieved?.toLocaleString("en-IN")}` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 844,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-green-700 mt-1 block", children: numberToIndianWords(targetData.achieved || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 847,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 840,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-amber-50 to-amber-100 border border-amber-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Difference" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 852,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-amber-700 mt-2", children: `${(targetData?.difference ?? "0")?.toLocaleString("en-IN")}` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 855,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-amber-700 mt-1 block", children: numberToIndianWords(
                    Math.abs(targetData?.difference || 0)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 860,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 851,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-emerald-50 to-emerald-100 border border-emerald-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Total Payable" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 867,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-emerald-700 mt-2", children: `${targetData.incentiveAmount.toLocaleString(
                    "en-IN",
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }
                  )}` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 870,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-emerald-700 mt-1 block", children: numberToIndianWords(
                    targetData.incentiveAmount || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 879,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 866,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 828,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 border border-violet-200 rounded-lg p-5", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-violet-800 mb-3", children: "Incentive Breakdown" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 887,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("li", { className: "text-sm text-gray-700 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 bg-violet-600 rounded-full" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 892,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: [
                      "Up to target (0%):",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "0.00" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                        lineNumber: 895,
                        columnNumber: 33
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 893,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-violet-700 ml-2", children: [
                      "(",
                      numberToIndianWords(0),
                      ")"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 897,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 891,
                    columnNumber: 29
                  }, this),
                  targetData.achieved > targetData.target && /* @__PURE__ */ jsxDEV("li", { className: "text-sm text-gray-700 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 bg-green-600 rounded-full" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 903,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: [
                      "Beyond target (1%):",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: ((targetData.achieved - targetData.target) * 0.01).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      }) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                        lineNumber: 906,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 904,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-green-700 ml-2", children: [
                      "(",
                      numberToIndianWords(
                        (targetData.achieved - targetData.target) * 0.01
                      ),
                      ")"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 917,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 902,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 890,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 886,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 811,
              columnNumber: 17
            }, this),
            loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 935,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 934,
              columnNumber: 17
            }, this) : employeeCustomerData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden", children: /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: processedTableData,
                columns,
                exportedPdfName: `Incentive Report`,
                printHeaderKeys: [
                  "Name",
                  "Phone Number",
                  "Month",
                  "Target Set",
                  "Achieved",
                  "Remaining",
                  "Total Payable Commission",
                  "Actual Business",
                  "Actual Commission",
                  "Gross Business",
                  "Gross Commission",
                  "Total Customers",
                  "Total Groups"
                ],
                printHeaderValues: [
                  selectedEmployeeId === "ALL" ? "All Employees" : selectedEmployeeDetails?.name || "-",
                  selectedEmployeeId === "ALL" ? "-" : selectedEmployeeDetails?.phone_number || "-",
                  dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate ? dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${selectedMonth}-01`)).toLocaleString(
                    "default",
                    {
                      month: "long",
                      year: "numeric"
                    }
                  ) : `${new Date(
                    fromDate
                  ).toLocaleDateString()} - ${new Date(
                    toDate
                  ).toLocaleDateString()}` : "-",
                  `₹${targetData?.target?.toLocaleString("en-IN") || "0"} (${numberToIndianWords(targetData?.target || 0)})`,
                  `₹${targetData?.achieved?.toLocaleString("en-IN") || "0"} (${numberToIndianWords(targetData?.achieved || 0)})`,
                  `₹${targetData?.remaining?.toLocaleString("en-IN") || "0"} (${numberToIndianWords(
                    targetData?.remaining || 0
                  )})`,
                  `₹${targetData?.incentiveAmount?.toLocaleString(
                    "en-IN",
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }
                  ) || "0.00"} (${numberToIndianWords(
                    targetData?.incentiveAmount || 0
                  )})`,
                  `₹${commissionTotalDetails?.actual_business?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    parseAmount(commissionTotalDetails?.actual_business)
                  )})`,
                  `₹${commissionTotalDetails?.total_actual?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    parseAmount(commissionTotalDetails?.total_actual)
                  )})`,
                  `₹${commissionTotalDetails?.expected_business?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    parseAmount(
                      commissionTotalDetails?.expected_business
                    )
                  )})`,
                  `₹${commissionTotalDetails?.total_estimated?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    parseAmount(commissionTotalDetails?.total_estimated)
                  )})`,
                  commissionTotalDetails?.total_customers || "0",
                  commissionTotalDetails?.total_groups || "0"
                ],
                exportedFileName: `IncentiveReport-${selectedEmployeeDetails?.name || "all"}-${dateSelectionMode === "month" ? selectedMonth : `${fromDate}_to_${toDate}`}.csv`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 939,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 938,
              columnNumber: 17
            }, this) : isFiltering && (dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate) && selectedEmployeeDetails?.name && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-lg font-medium", children: "No incentive data found for the selected period." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 1056,
              columnNumber: 27
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 1055,
              columnNumber: 17
            }, this)
          ] }, "commission", true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 802,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TabPane, { tab: "Gross Incentive Report", children: [
            isFiltering && (dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate) && (selectedEmployeeId === "ALL" || selectedEmployeeDetails) && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Gross Incentive Summary" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 1075,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Gross Group Value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 1080,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      value: grossIncentiveSummary.total_gross_group_value?.toLocaleString(
                        "en-IN"
                      ) || "-",
                      readOnly: true,
                      className: "w-full bg-transparent text-2xl font-bold text-green-700 mt-2 border-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 1083,
                      columnNumber: 29
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-green-700 mt-1 block", children: numberToIndianWords(
                    grossIncentiveSummary.total_gross_group_value || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 1092,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 1079,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-50 to-violet-100 border border-violet-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Gross Incentive Value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 1100,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      value: grossIncentiveSummary.total_gross_incentive_value?.toLocaleString(
                        "en-IN"
                      ) || "-",
                      readOnly: true,
                      className: "w-full bg-transparent text-2xl font-bold text-violet-700 mt-2 border-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 1103,
                      columnNumber: 29
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-violet-700 mt-1 block", children: numberToIndianWords(
                    grossIncentiveSummary.total_gross_incentive_value || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 1112,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 1099,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Gross Enrollments" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                    lineNumber: 1120,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      value: grossIncentiveSummary.total_gross_enrollments || "-",
                      readOnly: true,
                      className: "w-full bg-transparent text-2xl font-bold text-purple-700 mt-2 border-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                      lineNumber: 1123,
                      columnNumber: 29
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                  lineNumber: 1119,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 1078,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 1074,
              columnNumber: 17
            }, this),
            loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 1139,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 1138,
              columnNumber: 17
            }, this) : grossIncentiveData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden", children: /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: grossIncentiveData,
                columns: grossIncentiveColumns,
                exportedPdfName: `Gross Incentive Report`,
                printHeaderKeys: [
                  "Name",
                  "Phone Number",
                  "Period",
                  "Total Group Value",
                  "Total Incentive Value",
                  "Total Enrollments"
                ],
                printHeaderValues: [
                  selectedEmployeeId === "ALL" ? "All Employees" : selectedEmployeeDetails?.name || "-",
                  selectedEmployeeId === "ALL" ? "-" : selectedEmployeeDetails?.phone_number || "-",
                  dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate ? dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${selectedMonth}-01`)).toLocaleString(
                    "default",
                    {
                      month: "long",
                      year: "numeric"
                    }
                  ) : `${new Date(
                    fromDate
                  ).toLocaleDateString()} - ${new Date(
                    toDate
                  ).toLocaleDateString()}` : "-",
                  `₹${grossIncentiveSummary.total_gross_group_value?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    grossIncentiveSummary.total_gross_group_value || 0
                  )})`,
                  `₹${grossIncentiveSummary.total_gross_incentive_value?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    grossIncentiveSummary.total_gross_incentive_value || 0
                  )})`,
                  `${grossIncentiveSummary.total_gross_enrollments || "0"}`
                ],
                exportedFileName: `GrossIncentiveReport-${selectedEmployeeDetails?.name || "all"}-${dateSelectionMode === "month" ? selectedMonth : `${fromDate}_to_${toDate}`}.csv`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
                lineNumber: 1143,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 1142,
              columnNumber: 17
            }, this) : isFiltering && (dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate) && selectedEmployeeDetails?.name && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-lg font-medium", children: "No gross incentive data found for the selected period." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 1214,
              columnNumber: 27
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
              lineNumber: 1213,
              columnNumber: 17
            }, this)
          ] }, "gross-incentive", true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
            lineNumber: 1065,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
          lineNumber: 800,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
        lineNumber: 593,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
      lineNumber: 467,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
    lineNumber: 465,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx",
    lineNumber: 464,
    columnNumber: 5
  }, this);
};
_s(TargetIncentive, "hogtJjLUj66XZTolIThU026XbeU=");
_c = TargetIncentive;
export default TargetIncentive;
var _c;
$RefreshReg$(_c, "TargetIncentive");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentive.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaWRRLFNBaUZRLFVBakZSOzJCQWpkUjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELFNBQVNDLFFBQVFDLE9BQU9DLFlBQVk7QUFDcEMsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0Msa0JBQWtCQyxzQkFBc0I7QUFDakQsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsMkJBQTJCO0FBRXBDLE1BQU0sRUFBRUMsUUFBUSxJQUFJZDtBQUVwQixNQUFNZSxrQkFBa0JBLE1BQU07QUFBQUMsS0FBQTtBQUM1QixRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXJCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNzQixvQkFBb0JDLHFCQUFxQixJQUFJdkIsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQ3dCLGVBQWVDLGdCQUFnQixJQUFJekIsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQzBCLG1CQUFtQkMsb0JBQW9CLElBQUkzQixTQUFTLE9BQU87QUFDbEUsUUFBTSxDQUFDNEIsY0FBY0MsZUFBZSxJQUFJN0IsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQzhCLHlCQUF5QkMsMEJBQTBCLElBQUkvQixTQUFTLElBQUk7QUFDM0UsUUFBTSxDQUFDZ0Msc0JBQXNCQyx1QkFBdUIsSUFBSWpDLFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUNrQyx3QkFBd0JDLHlCQUF5QixJQUFJbkMsU0FBUyxDQUFDLENBQUM7QUFDdkUsUUFBTSxDQUFDb0MsU0FBU0MsVUFBVSxJQUFJckMsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3NDLHFCQUFxQkMsc0JBQXNCLElBQUl2QyxTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDd0MsZ0JBQWdCQyxpQkFBaUIsSUFBSXpDLFNBQVM7QUFBQSxJQUNuRDBDLFVBQVU7QUFBQSxJQUNWQyxXQUFVLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLElBQy9DQyxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLElBQ1RDLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSXRELFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ3VELFNBQVNDLFVBQVUsSUFBSXhELFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUN5RCxXQUFXQyxZQUFZLElBQUkxRCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDMkQsWUFBWUMsYUFBYSxJQUFJNUQsU0FBUztBQUFBLElBQzNDNkQsUUFBUTtBQUFBLElBQ1JDLFVBQVU7QUFBQSxJQUNWQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxJQUNUQyxpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlwRSxTQUFTLElBQUk7QUFDN0MsUUFBTSxDQUFDcUUsUUFBUUMsU0FBUyxJQUFJdEUsU0FBUyxJQUFJO0FBQ3pDLFFBQU0sQ0FBQ3VFLGFBQWFDLGNBQWMsSUFBSXhFLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN5RSxtQkFBbUJDLG9CQUFvQixJQUFJMUUsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQzJFLGNBQWNDLGVBQWUsSUFBSTVFLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUM2RSxZQUFZQyxhQUFhLElBQUk5RSxTQUFTLElBQUk7QUFDakQsUUFBTSxDQUFDK0UsV0FBV0MsWUFBWSxJQUFJaEYsU0FBUyxZQUFZO0FBQ3ZELFFBQU0sQ0FBQ2lGLG9CQUFvQkMscUJBQXFCLElBQUlsRixTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDbUYsdUJBQXVCQyx3QkFBd0IsSUFBSXBGLFNBQVM7QUFBQSxJQUNqRXFGLDZCQUE2QjtBQUFBLElBQzdCQyx5QkFBeUI7QUFBQSxJQUN6QkMseUJBQXlCO0FBQUEsRUFDM0IsQ0FBQztBQUdELFFBQU1DLGNBQWNBLENBQUNDLFFBQ25CQyxXQUFXRCxLQUFLRSxTQUFTLEVBQUVDLFFBQVEsY0FBYyxFQUFFLENBQUMsS0FBSztBQUUzRDdGLFlBQVUsTUFBTTtBQUNkLFVBQU04RixTQUFRLG9CQUFJakQsS0FBSztBQUN2QixVQUFNa0QsZ0JBQWUsR0FBR0QsT0FBTUUsWUFBWSxDQUFDLElBQUlDO0FBQUFBLE1BQzdDSCxPQUFNSSxTQUFTLElBQUk7QUFBQSxJQUNyQixFQUFFQyxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ2xCeEIseUJBQXFCb0IsYUFBWTtBQUNqQ3JFLHFCQUFpQnFFLGFBQVk7QUFDN0IsVUFBTUssT0FBT04sT0FBTUUsWUFBWTtBQUMvQixVQUFNSyxRQUFRUCxPQUFNSSxTQUFTLElBQUk7QUFDakMsVUFBTUksV0FBVyxHQUFHRixJQUFJLElBQUlILE9BQU9JLEtBQUssRUFBRUYsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUMxRCxVQUFNSSxXQUFXLElBQUkxRCxLQUFLdUQsTUFBTUMsT0FBTyxDQUFDLEVBQUVHLFFBQVE7QUFDbEQsVUFBTUMsVUFBVSxHQUFHTCxJQUFJLElBQUlDLEtBQUssSUFBSUosT0FBT00sUUFBUSxFQUFFSixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ3JFdEIsb0JBQWdCeUIsUUFBUTtBQUN4QnZCLGtCQUFjMEIsT0FBTztBQUNyQnBDLGdCQUFZaUMsUUFBUTtBQUNwQi9CLGNBQVVrQyxPQUFPO0FBQUEsRUFDbkIsR0FBRyxFQUFFO0FBRUx6RyxZQUFVLE1BQU07QUFDZCxVQUFNMEcsT0FBT0MsS0FBS0MsTUFBTUMsYUFBYUMsUUFBUSxNQUFNLENBQUM7QUFDcEQsUUFBSUosTUFBTTtBQUNSakQsaUJBQVdpRCxLQUFLSyxHQUFHO0FBQ25CcEQsbUJBQWErQyxLQUFLTSxRQUFRLEVBQUU7QUFBQSxJQUM5QjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUMsaUJBQWlCLFlBQVk7QUFDakMsUUFBSTtBQUNGLFlBQU1DLE1BQU0sTUFBTTdHLElBQUk4RyxJQUFJLFdBQVc7QUFDckM3RixtQkFBYTRGLEtBQUtFLE1BQU1DLFFBQVE7QUFBQSxJQUNsQyxTQUFTQyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sNkJBQTZCRixHQUFHO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBRUEsUUFBTUcsd0JBQXdCLE9BQU9DLFlBQVl6RCxXQUFXQyxZQUFZO0FBQ3RFLFFBQUksQ0FBQ3dELGNBQWMsQ0FBQ3pELGFBQWEsQ0FBQ0MsUUFBUztBQUMzQyxVQUFNeUQsa0JBQWtCLElBQUlDLGdCQUFnQjtBQUM1QyxRQUFJO0FBQ0YsVUFBSUMsU0FBUztBQUFBLFFBQ1hDLFlBQVk3RDtBQUFBQSxRQUNaOEQsVUFBVTdEO0FBQUFBLE1BQ1o7QUFDQSxZQUFNZ0QsTUFBTSxNQUFNN0csSUFBSThHLElBQUksb0JBQW9CTyxVQUFVLGNBQWM7QUFBQSxRQUNwRUc7QUFBQUEsUUFDQUcsUUFBUUwsZ0JBQWdCSztBQUFBQSxNQUMxQixDQUFDO0FBQ0Q5Riw4QkFBd0JnRixJQUFJRSxNQUFNYSxhQUFhO0FBQy9DN0YsZ0NBQTBCO0FBQUEsUUFDeEI4RixpQkFBaUJoQixJQUFJRSxNQUFNZSxrQkFBa0JDO0FBQUFBLFFBQzdDQyxjQUFjbkIsSUFBSUUsTUFBTWUsa0JBQWtCRztBQUFBQSxRQUMxQ0MsaUJBQWlCckIsSUFBSUUsTUFBTWUsa0JBQWtCSztBQUFBQSxRQUM3Q0MsY0FBY3ZCLElBQUlFLE1BQU1lLGtCQUFrQks7QUFBQUEsUUFDMUNFLG1CQUFtQnhCLElBQUlFLE1BQU1lLGtCQUFrQkM7QUFBQUEsUUFDL0NPLGlCQUFpQnpCLElBQUlFLE1BQU1lLGtCQUFrQkc7QUFBQUEsTUFDL0MsQ0FBQztBQUFBLElBQ0gsU0FBU2hCLEtBQUs7QUFDWixVQUFJQSxJQUFJTixTQUFTLG1CQUFtQjtBQUNsQ08sZ0JBQVFDLE1BQU0sbUNBQW1DRixHQUFHO0FBQ3BEcEYsZ0NBQXdCLEVBQUU7QUFDMUJFLGtDQUEwQixDQUFDLENBQUM7QUFBQSxNQUM5QjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTXdHLGtCQUFrQixPQUFPbEIsWUFBWXpELFdBQVdDLFlBQVk7QUFDaEUsUUFBSSxDQUFDd0QsY0FBYyxDQUFDekQsYUFBYSxDQUFDQyxRQUFTO0FBQzNDLFFBQUk7QUFDRixZQUFNZ0QsTUFBTSxNQUFNN0csSUFBSThHLElBQUkscUJBQXFCTyxVQUFVLElBQUk7QUFBQSxRQUMzREcsUUFBUSxFQUFFQyxZQUFZN0QsV0FBVzhELFVBQVU3RCxRQUFRO0FBQUEsTUFDckQsQ0FBQztBQUNELFVBQUlnRCxJQUFJRSxLQUFLeUIsVUFBVTNCLElBQUlFLEtBQUswQixpQkFBaUJDLFFBQVc7QUFDMUQsY0FBTUMsY0FBY0MsT0FBTy9CLElBQUlFLEtBQUswQixZQUFZO0FBQ2hELFlBQUlqQixTQUFTO0FBQUEsVUFDWEMsWUFBWTdEO0FBQUFBLFVBQ1o4RCxVQUFVN0Q7QUFBQUEsUUFDWjtBQUNBLGNBQU0sRUFBRWtELE1BQU04QixLQUFLLElBQUksTUFBTTdJLElBQUk4RztBQUFBQSxVQUMvQixvQkFBb0JPLFVBQVU7QUFBQSxVQUM5QjtBQUFBLFlBQ0VHO0FBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsWUFBSTlELFdBQVdtRixNQUFNZixrQkFBa0JDLHFCQUFxQjtBQUM1RCxZQUFJLE9BQU9yRSxhQUFhLFVBQVU7QUFDaENBLHFCQUFXa0YsT0FBT2xGLFNBQVM4QixRQUFRLGNBQWMsRUFBRSxDQUFDO0FBQUEsUUFDdEQ7QUFDQSxjQUFNN0IsWUFBWW1GLEtBQUtDLElBQUlKLGNBQWNqRixVQUFVLENBQUM7QUFDcEQsY0FBTXNGLGFBQWF0RixXQUFXaUY7QUFDOUIsY0FBTTdFLGtCQUFrQmtGLGFBQWEsSUFBSUEsYUFBYSxPQUFPO0FBQzdEeEYsc0JBQWM7QUFBQSxVQUNaQyxRQUFRcUYsS0FBS0csTUFBTU4sV0FBVztBQUFBLFVBQzlCakYsVUFBVW9GLEtBQUtHLE1BQU12RixRQUFRO0FBQUEsVUFDN0JDLFdBQVdtRixLQUFLRyxNQUFNdEYsU0FBUztBQUFBLFVBQy9CcUYsWUFBWUYsS0FBS0csTUFBTUQsVUFBVTtBQUFBLFVBQ2pDcEY7QUFBQUEsVUFDQUM7QUFBQUEsVUFDQUMsaUJBQWlCd0IsV0FBV3hCLGdCQUFnQm9GLFFBQVEsQ0FBQyxDQUFDO0FBQUEsUUFDeEQsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMLGNBQU0sSUFBSUMsTUFBTSx5QkFBeUI7QUFBQSxNQUMzQztBQUFBLElBQ0YsU0FBU2xDLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSwrQkFBK0JGLEdBQUc7QUFDaER6RCxvQkFBYztBQUFBLFFBQ1pDLFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkMsV0FBVztBQUFBLFFBQ1hxRixZQUFZO0FBQUEsUUFDWnBGLFdBQVc7QUFBQSxRQUNYQyxTQUFTO0FBQUEsUUFDVEMsaUJBQWlCO0FBQUEsTUFDbkIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTXNGLDJCQUEyQixZQUFZO0FBQzNDLFFBQUksQ0FBQ3JGLFlBQVksQ0FBQ0UsT0FBUTtBQUMxQixVQUFNcUQsa0JBQWtCLElBQUlDLGdCQUFnQjtBQUM1QyxRQUFJO0FBQ0YsVUFBSUMsU0FBUztBQUFBLFFBQ1hDLFlBQVkxRDtBQUFBQSxRQUNaMkQsVUFBVXpEO0FBQUFBLE1BQ1o7QUFDQSxZQUFNNEMsTUFBTSxNQUFNN0csSUFBSThHLElBQUkscUJBQXFCO0FBQUEsUUFDN0NVO0FBQUFBLFFBQ0FHLFFBQVFMLGdCQUFnQks7QUFBQUEsTUFDMUIsQ0FBQztBQUNEOUYsOEJBQXdCZ0YsSUFBSUUsTUFBTXNDLGNBQWM7QUFDaER0SCxnQ0FBMEI7QUFBQSxRQUN4QjhGLGlCQUFpQmhCLElBQUlFLE1BQU11QyxtQkFBbUJ2QjtBQUFBQSxRQUM5Q0MsY0FBY25CLElBQUlFLE1BQU11QyxtQkFBbUJDO0FBQUFBLFFBQzNDckIsaUJBQWlCckIsSUFBSUUsTUFBTXVDLG1CQUFtQm5CO0FBQUFBLFFBQzlDQyxjQUFjdkIsSUFBSUUsTUFBTXVDLG1CQUFtQm5CO0FBQUFBLFFBQzNDRSxtQkFBbUJ4QixJQUFJRSxNQUFNdUMsbUJBQW1CdkI7QUFBQUEsUUFDaERPLGlCQUFpQnpCLElBQUlFLE1BQU11QyxtQkFBbUJDO0FBQUFBLE1BQ2hELENBQUM7QUFBQSxJQUNILFNBQVN0QyxLQUFLO0FBQ1osVUFBSUEsSUFBSU4sU0FBUyxjQUFjO0FBQzdCTyxnQkFBUUMsTUFBTSx5Q0FBeUNGLEdBQUc7QUFDMURwRixnQ0FBd0IsRUFBRTtBQUMxQkUsa0NBQTBCLENBQUMsQ0FBQztBQUFBLE1BQzlCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNeUgsNEJBQTRCLE9BQU9uQyxZQUFZekQsV0FBV0MsWUFBWTtBQUMxRSxRQUFJLENBQUN3RCxjQUFjLENBQUN6RCxhQUFhLENBQUNDLFFBQVM7QUFDM0MsUUFBSTtBQUNGLFVBQUkyRCxTQUFTO0FBQUEsUUFDWEMsWUFBWTdEO0FBQUFBLFFBQ1o4RCxVQUFVN0Q7QUFBQUEsTUFDWjtBQUNBLFlBQU1nRCxNQUFNLE1BQU03RyxJQUFJOEc7QUFBQUEsUUFDcEIsb0JBQW9CTyxVQUFVO0FBQUEsUUFDOUI7QUFBQSxVQUNFRztBQUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFlBQU1JLGdCQUFnQmYsSUFBSUUsTUFBTTBDLG9CQUFvQkMsSUFBSSxDQUFDQyxnQkFBZ0I7QUFBQSxRQUN2RUMsV0FBV0QsWUFBWUUsU0FBU0MsYUFBYTtBQUFBLFFBQzdDQyxjQUFjSixZQUFZRSxTQUFTRSxnQkFBZ0I7QUFBQSxRQUNuREMsWUFBWUwsWUFBWU0sVUFBVUQsY0FBYztBQUFBLFFBQ2hERSxhQUFhUCxZQUFZTSxVQUFVQyxlQUFlO0FBQUEsUUFDbERDLGlCQUFpQlIsWUFBWU0sVUFBVUcsY0FBYztBQUFBLFFBQ3JEQyxjQUFjVixZQUFZVyxXQUFXO0FBQUEsUUFDckNDLGlCQUFpQlosWUFBWWEsV0FBVzlILE1BQU0sR0FBRyxJQUFJLENBQUM7QUFBQSxRQUN0RCtILG1CQUFtQmQsWUFBWWMscUJBQXFCO0FBQUEsUUFDcERDLDJCQUNFZixZQUFZTSxVQUFVVSx1QkFBdUI7QUFBQSxNQUNqRCxFQUFFO0FBQ0Y3Riw0QkFBc0I4QyxpQkFBaUIsRUFBRTtBQUN6QzVDO0FBQUFBLFFBQ0U2QixJQUFJRSxLQUFLaEMseUJBQXlCO0FBQUEsVUFDaENFLDZCQUE2QjtBQUFBLFVBQzdCQyx5QkFBeUI7QUFBQSxVQUN6QkMseUJBQXlCO0FBQUEsUUFDM0I7QUFBQSxNQUNGO0FBQUEsSUFDRixTQUFTOEIsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDBDQUEwQ0YsR0FBRztBQUMzRG5DLDRCQUFzQixFQUFFO0FBQ3hCRSwrQkFBeUI7QUFBQSxRQUN2QkMsNkJBQTZCO0FBQUEsUUFDN0JDLHlCQUF5QjtBQUFBLFFBQ3pCQyx5QkFBeUI7QUFBQSxNQUMzQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNeUYsK0JBQStCLFlBQVk7QUFDL0MsUUFBSSxDQUFDN0csWUFBWSxDQUFDRSxPQUFRO0FBQzFCLFFBQUk7QUFDRixVQUFJdUQsU0FBUztBQUFBLFFBQ1hDLFlBQVkxRDtBQUFBQSxRQUNaMkQsVUFBVXpEO0FBQUFBLE1BQ1o7QUFDQSxZQUFNNEMsTUFBTSxNQUFNN0csSUFBSThHLElBQUksMkJBQTJCO0FBQUEsUUFDbkRVO0FBQUFBLE1BQ0YsQ0FBQztBQUNEMUMsNEJBQXNCK0IsSUFBSUUsS0FBSzBDLHNCQUFzQixFQUFFO0FBQ3ZEekU7QUFBQUEsUUFDRTZCLElBQUlFLEtBQUtoQyx5QkFBeUI7QUFBQSxVQUNoQ0UsNkJBQTZCO0FBQUEsVUFDN0JDLHlCQUF5QjtBQUFBLFVBQ3pCQyx5QkFBeUI7QUFBQSxRQUMzQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLFNBQVM4QixLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sOENBQThDRixHQUFHO0FBQy9EbkMsNEJBQXNCLEVBQUU7QUFDeEJFLCtCQUF5QjtBQUFBLFFBQ3ZCQyw2QkFBNkI7QUFBQSxRQUM3QkMseUJBQXlCO0FBQUEsUUFDekJDLHlCQUF5QjtBQUFBLE1BQzNCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU0wRix1QkFBdUJBLENBQUNDLFVBQVU7QUFDdEMzSiwwQkFBc0IySixLQUFLO0FBQzNCbkosK0JBQTJCLElBQUk7QUFDL0JFLDRCQUF3QixFQUFFO0FBQzFCRSw4QkFBMEIsQ0FBQyxDQUFDO0FBQzVCeUIsa0JBQWM7QUFBQSxNQUNaQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLFdBQVc7QUFBQSxNQUNYQyxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RDLGlCQUFpQjtBQUFBLElBQ25CLENBQUM7QUFDRGdCLDBCQUFzQixFQUFFO0FBQ3hCRSw2QkFBeUI7QUFBQSxNQUN2QkMsNkJBQTZCO0FBQUEsTUFDN0JDLHlCQUF5QjtBQUFBLE1BQ3pCQyx5QkFBeUI7QUFBQSxJQUMzQixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU00Rix3QkFBd0JBLENBQUNDLE1BQU07QUFDbkMsVUFBTTVKLGlCQUFnQjRKLEVBQUV2SCxPQUFPcUg7QUFDL0J4Ryx5QkFBcUJsRCxjQUFhO0FBQ2xDLFFBQUlBLGdCQUFlO0FBQ2pCLFlBQU0sQ0FBQzJFLE1BQU1DLEtBQUssSUFBSTVFLGVBQWNzQixNQUFNLEdBQUc7QUFDN0MsWUFBTXVELFdBQVcsR0FBR0YsSUFBSSxJQUFJQyxLQUFLO0FBQ2pDLFlBQU1FLFdBQVcsSUFBSTFELEtBQUt1RCxNQUFNQyxPQUFPLENBQUMsRUFBRUcsUUFBUTtBQUNsRCxZQUFNQyxVQUFVLEdBQUdMLElBQUksSUFBSUMsS0FBSyxJQUFJSixPQUFPTSxRQUFRLEVBQUVKLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDckV0QixzQkFBZ0J5QixRQUFRO0FBQ3hCdkIsb0JBQWMwQixPQUFPO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTTZFLGNBQWMsWUFBWTtBQUM5QixRQUFJLENBQUMvSixvQkFBb0I7QUFDdkJnSyxZQUFNLDRCQUE0QjtBQUNsQztBQUFBLElBQ0Y7QUFDQSxRQUFJNUosc0JBQXNCLFdBQVcsQ0FBQytDLG1CQUFtQjtBQUN2RDZHLFlBQU0sd0JBQXdCO0FBQzlCO0FBQUEsSUFDRjtBQUNBLFFBQUk1SixzQkFBc0IsaUJBQWlCLENBQUNpRCxnQkFBZ0IsQ0FBQ0UsYUFBYTtBQUN4RXlHLFlBQU0sdUNBQXVDO0FBQzdDO0FBQUEsSUFDRjtBQUNBOUcsbUJBQWUsSUFBSTtBQUNuQixRQUFJUixXQUFXQztBQUNmLFFBQUl2QyxzQkFBc0IsU0FBUztBQUNqQ0QsdUJBQWlCZ0QsaUJBQWlCO0FBQ2xDLFlBQU0sQ0FBQzBCLE1BQU1DLEtBQUssSUFBSTNCLGtCQUFrQjNCLE1BQU0sR0FBRztBQUNqRGtCLGtCQUFZLEdBQUdtQyxJQUFJLElBQUlDLEtBQUs7QUFDNUIsWUFBTUksVUFBVSxJQUFJNUQsS0FBS3VELE1BQU1DLE9BQU8sQ0FBQyxFQUFFRyxRQUFRO0FBQ2pEdEMsZ0JBQVUsR0FBR2tDLElBQUksSUFBSUMsS0FBSyxJQUFJSixPQUFPUSxPQUFPLEVBQUVOLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDOUQ5QixrQkFBWUosU0FBUztBQUNyQk0sZ0JBQVVMLE9BQU87QUFBQSxJQUNuQixPQUFPO0FBQ0xELGtCQUFZVztBQUNaVixnQkFBVVk7QUFDVlQsa0JBQVlKLFNBQVM7QUFDckJNLGdCQUFVTCxPQUFPO0FBQUEsSUFDbkI7QUFDQTVCLGVBQVcsSUFBSTtBQUNmUixvQkFBZ0IsSUFBSTtBQUNwQixRQUFJO0FBQ0YsVUFBSVAsdUJBQXVCLE9BQU87QUFDaENTLG1DQUEyQixJQUFJO0FBQy9CNkIsc0JBQWM7QUFBQSxVQUNaQyxRQUFRO0FBQUEsVUFDUkMsVUFBVTtBQUFBLFVBQ1ZDLFdBQVc7QUFBQSxVQUNYQyxXQUFXO0FBQUEsVUFDWEMsU0FBUztBQUFBLFVBQ1RDLGlCQUFpQjtBQUFBLFFBQ25CLENBQUM7QUFDRCxjQUFNc0YseUJBQXlCO0FBQy9CLGNBQU13Qiw2QkFBNkI7QUFBQSxNQUNyQyxPQUFPO0FBQ0wsY0FBTU8sTUFBTW5LLFVBQVVvSyxLQUFLLENBQUNKLE1BQU1BLEVBQUV0RSxRQUFReEYsa0JBQWtCO0FBQzlEUyxtQ0FBMkJ3SixPQUFPLElBQUk7QUFDdEMsY0FBTS9ELHNCQUFzQmxHLG9CQUFvQjBDLFdBQVdDLE9BQU87QUFDbEUsY0FBTTBFLGdCQUFnQnJILG9CQUFvQjBDLFdBQVdDLE9BQU87QUFDNUQsY0FBTTJGLDBCQUEwQnRJLG9CQUFvQjBDLFdBQVdDLE9BQU87QUFBQSxNQUN4RTtBQUFBLElBQ0YsVUFBQztBQUNDcEMsc0JBQWdCLEtBQUs7QUFDckJRLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQXRDLFlBQVUsTUFBTTtBQUNkaUgsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxRQUFNeUUseUJBQXlCQSxDQUFDTCxNQUFNO0FBQ3BDLFVBQU0sRUFBRXJFLE1BQU1tRSxNQUFNLElBQUlFLEVBQUV2SDtBQUMxQnBCLHNCQUFrQixDQUFDaUosVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQzNFLElBQUksR0FBR21FLE1BQU0sRUFBRTtBQUN4RDVILGNBQVUsQ0FBQ29JLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUMzRSxJQUFJLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDL0M7QUFFQSxRQUFNNEUsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxZQUFZLENBQUM7QUFDbkIsUUFBSSxDQUFDcEosZUFBZUU7QUFDbEJrSixnQkFBVWxKLFdBQVc7QUFDdkIsUUFBSSxDQUFDRixlQUFlTyxVQUFVOEksTUFBTXJKLGVBQWVPLE1BQU07QUFDdkQ2SSxnQkFBVTdJLFNBQVM7QUFDckIsUUFDRVAsZUFBZVEsYUFBYSxZQUM1QixDQUFDUixlQUFlUztBQUVoQjJJLGdCQUFVM0ksaUJBQWlCO0FBQzdCSyxjQUFVc0ksU0FBUztBQUNuQixXQUFPRSxPQUFPQyxLQUFLSCxTQUFTLEVBQUVJLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU1DLHlCQUF5QixPQUFPYixNQUFNO0FBQzFDQSxNQUFFYyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ1AsYUFBYSxFQUFHO0FBQ3JCLFFBQUk7QUFDRixZQUFNUSxVQUFVLEVBQUUsR0FBRzNKLGdCQUFnQlksWUFBWUcsUUFBUTtBQUN6RCxZQUFNbkQsSUFBSWdNLEtBQUssdUNBQXVDRCxPQUFPO0FBQzdEYixZQUFNLCtCQUErQjtBQUNyQy9JLDZCQUF1QixLQUFLO0FBQUEsSUFDOUIsU0FBUzhFLEtBQUs7QUFDWmlFLFlBQU0sd0JBQXdCO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBRUEsUUFBTWUscUJBQXFCcksscUJBQXFCOEgsSUFBSSxDQUFDd0MsTUFBTUMsV0FBVztBQUFBLElBQ3BFLEdBQUdEO0FBQUFBLElBQ0hFLG9CQUFvQkYsS0FBS2pDLFVBQVVDO0FBQUFBLElBQ25DRyxjQUFjNkIsS0FBS0csVUFBVTtBQUFBLElBQzdCQyw2QkFBNkJKLE1BQU1LLHdCQUF3QjtBQUFBLElBQzNEQyxzQkFBc0JOLE1BQU1PLG1CQUFtQjtBQUFBLElBQy9DQyxzQkFBc0JSLE1BQU1qQyxVQUFVRyxjQUFjO0FBQUEsSUFDcER1QyxtQkFBbUJULE1BQU16QixxQkFBcUI7QUFBQSxJQUM5Q21DLDZCQUE2QlYsTUFBTWpDLFVBQVVVLHVCQUF1QjtBQUFBLElBQ3BFa0Msb0JBQW9CWCxLQUFLVyxxQkFBcUIsUUFBUTtBQUFBLElBQ3REakQsV0FBV3NDLEtBQUtyQyxTQUFTQyxhQUFhO0FBQUEsSUFDdENDLGNBQWNtQyxLQUFLckMsU0FBU0UsZ0JBQWdCO0FBQUEsSUFDNUNDLFlBQVlrQyxLQUFLakMsVUFBVUQsY0FBYztBQUFBLElBQ3pDTyxpQkFBaUIyQixLQUFLMUIsV0FBVzlILE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSztBQUFBLEVBQ3RELEVBQUU7QUFFRixRQUFNb0ssVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxhQUFhQyxRQUFRLGdCQUFnQjtBQUFBLElBQzVDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLFlBQVk7QUFBQSxJQUMzQyxFQUFFRCxLQUFLLHNCQUFzQkMsUUFBUSxjQUFjO0FBQUEsSUFDbkQsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRUQsS0FBSyx3QkFBd0JDLFFBQVEsMkJBQTJCO0FBQUEsSUFDbEUsRUFBRUQsS0FBSyx3QkFBd0JDLFFBQVEsaUJBQWlCO0FBQUEsSUFDeEQsRUFBRUQsS0FBSyxxQkFBcUJDLFFBQVEsYUFBYTtBQUFBLElBQ2pELEVBQUVELEtBQUssK0JBQStCQyxRQUFRLDJCQUEyQjtBQUFBLElBQ3pFLEVBQUVELEtBQUssc0JBQXNCQyxRQUFRLHFCQUFxQjtBQUFBLEVBQUM7QUFHN0QsUUFBTUMsd0JBQXdCO0FBQUEsSUFDNUIsRUFBRUYsS0FBSyxhQUFhQyxRQUFRLGdCQUFnQjtBQUFBLElBQzVDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsWUFBWTtBQUFBLElBQzNDLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVELEtBQUssNkJBQTZCQyxRQUFRLDJCQUEyQjtBQUFBLElBQ3ZFLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLHVCQUF1QjtBQUFBLElBQ3pELEVBQUVELEtBQUsscUJBQXFCQyxRQUFRLGFBQWE7QUFBQSxFQUFDO0FBR3BELFFBQU12SCxRQUFRLG9CQUFJakQsS0FBSztBQUN2QixRQUFNa0QsZUFBZSxHQUFHRCxNQUFNRSxZQUFZLENBQUMsSUFBSUM7QUFBQUEsSUFDN0NILE1BQU1JLFNBQVMsSUFBSTtBQUFBLEVBQ3JCLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFFbEIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2IsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSwyQkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLFNBQUksV0FBVSxpQkFFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG9DQUFtQyxpQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLG9FQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDRDQUEyQyw4QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlELCtCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU81RSxzQkFBc0J3SDtBQUFBQSxnQkFDN0IsVUFBVW1DO0FBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLGFBQVk7QUFBQSxnQkFDWixjQUFjLENBQUNxQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSjdILFNBQVMsRUFDVDhILFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU8sRUFBRUUsUUFBUSxPQUFPO0FBQUEsZ0JBQ3hCLFdBQVU7QUFBQSxnQkFFVHZNLG9CQUFVMEk7QUFBQUEsa0JBQUksQ0FBQ3lCLFFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUl6RSxLQUNyQ3lFO0FBQUFBLHdCQUFJeEU7QUFBQUEsb0JBQUs7QUFBQSxvQkFBSXdFLElBQUlwQjtBQUFBQSx1QkFEQW9CLElBQUl6RSxLQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW9CQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlELDhCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSxjQUFDLE1BQU07QUFBQSxjQUFOO0FBQUEsZ0JBQ0MsT0FBT3BGO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQzBKLE1BQU16SixxQkFBcUJ5SixFQUFFdkgsT0FBT3FILEtBQUs7QUFBQSxnQkFFcEQ7QUFBQSx5Q0FBQyxTQUFNLE9BQU0sU0FBUSxXQUFVLFdBQVUscUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFNLE9BQU0sY0FBYSxXQUFVLFdBQVUscUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBR0N4SixzQkFBc0IsVUFDckIsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCw0QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBTytDLHFCQUFxQjtBQUFBLGdCQUM1QixLQUFLcUI7QUFBQUEsZ0JBQ0wsVUFBVXFGO0FBQUFBLGdCQUNWLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS29IO0FBQUEsZUFUdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQSxJQUVBLG1DQUNFO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGtEQUFpRCx5QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU94RyxnQkFBZ0I7QUFBQSxrQkFDdkIsS0FBS0UsY0FBY2lCO0FBQUFBLGtCQUNuQixVQUFVLENBQUNzRixNQUFNeEcsZ0JBQWdCd0csRUFBRXZILE9BQU9xSCxLQUFLO0FBQUEsa0JBQy9DLFdBQVU7QUFBQTtBQUFBLGdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtvSDtBQUFBLGlCQVR0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0RBQWlELHVCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT3JHLGNBQWM7QUFBQSxrQkFDckIsS0FBS0YsZ0JBQWdCO0FBQUEsa0JBQ3JCLEtBQUttQjtBQUFBQSxrQkFDTCxVQUFVLENBQUNzRixNQUFNdEcsY0FBY3NHLEVBQUV2SCxPQUFPcUgsS0FBSztBQUFBLGtCQUM3QyxXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNb0g7QUFBQSxpQkFWdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLGVBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMEJBO0FBQUEsYUExRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRGQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTRztBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUE2RztBQUFBO0FBQUEsVUFGekg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQTFHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkdBO0FBQUEsTUFFQ3pKLGVBQ0MsdUJBQUMsU0FBSSxXQUFVLDZCQUNiLGlDQUFDLGtCQUFlLFdBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFFQSxtQ0FFRTtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxXQUFVO0FBQUEsY0FFVjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixNQUFNO0FBQUE7QUFBQSxrQkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRVc7QUFBQSxnQkFFWCx1QkFBQyxVQUFLLFdBQVUseURBQXdELDBCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUE7QUFBQTtBQUFBLFlBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLGtCQUFlLFdBQVUsd0VBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThGO0FBQUEsZ0JBQzlGLHVCQUFDLFVBQUssV0FBVSx5REFBd0QsZ0NBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILFdBQVU7QUFBQSxjQUVWO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQU07QUFBQTtBQUFBLGtCQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFFVztBQUFBLGdCQUVYLHVCQUFDLFVBQUssV0FBVSx5REFBd0QsNkJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLGFBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0EsS0FuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9DQTtBQUFBLFFBR0MyQyxnQkFDRzdDLHNCQUFzQixXQUFXRixpQkFDaENFLHNCQUFzQixnQkFDckJ5QyxZQUNBRSxZQUNIL0MsdUJBQXVCLFNBQVNRLDRCQUMvQix1QkFBQyxTQUFJLFdBQVUsaUVBQ1pSO0FBQUFBLGlDQUF1QixTQUN0QlEsMkJBQ0UsbUNBQ0U7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNENBQTJDLG9DQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGlEQUFnRCxvQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU9BLHlCQUF5QmlGLFFBQVE7QUFBQSxvQkFDeEM7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRzRHO0FBQUEsbUJBUDlHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsaURBQWdELHFCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBT2pGLHlCQUF5QjhMLFNBQVM7QUFBQSxvQkFDekM7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRzRHO0FBQUEsbUJBUDlHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsaURBQWdELHFCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FDRTlMLHlCQUF5QnFJLGdCQUFnQjtBQUFBLG9CQUUzQztBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLNEc7QUFBQSxtQkFUOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGlCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxpREFBZ0Qsc0JBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUNFckkseUJBQXlCK0wsYUFBYTtBQUFBLG9CQUV4QztBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLNEc7QUFBQSxtQkFUOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxpREFBZ0QsbUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPL0wseUJBQXlCZ00sVUFBVTtBQUFBLG9CQUMxQztBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHNEc7QUFBQSxtQkFQOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxpREFBZ0QsdUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPaE0seUJBQXlCaU0sV0FBVztBQUFBLG9CQUMzQztBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHNEc7QUFBQSxtQkFQOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxpREFBZ0QsdUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPak0seUJBQXlCa00sV0FBVztBQUFBLG9CQUMzQztBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHNEc7QUFBQSxtQkFQOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxpREFBZ0QsNEJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUNFbE0seUJBQXlCbU0sZUFDckJuTSx3QkFBd0JtTSxhQUFhbkw7QUFBQUEsc0JBQ25DO0FBQUEsb0JBQ0YsRUFBRSxDQUFDLElBQ0g7QUFBQSxvQkFFTjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFTNEc7QUFBQSxtQkFiOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGlCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLFVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0I7QUFBQSxlQXZHdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3R0E7QUFBQSxVQUlKLHVCQUFDLFFBQUcsV0FBVSw0Q0FBMkMsa0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxpREFBZ0QsNEJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU9aLHdCQUF3QitGLG1CQUFtQjtBQUFBLGtCQUNsRDtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUdtRjtBQUFBLGNBRW5GLHVCQUFDLFVBQUssV0FBVSwrQ0FDYmpIO0FBQUFBLGdCQUNDd0UsWUFBWXRELHdCQUF3QitGLGVBQWU7QUFBQSxjQUNyRCxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMEZBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsaURBQWdELHVDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPL0Ysd0JBQXdCa0csZ0JBQWdCO0FBQUEsa0JBQy9DO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBR29GO0FBQUEsY0FFcEYsdUJBQUMsVUFBSyxXQUFVLGdEQUNicEg7QUFBQUEsZ0JBQ0N3RSxZQUFZdEQsd0JBQXdCa0csWUFBWTtBQUFBLGNBQ2xELEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwwRkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxpREFBZ0QsNkJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU9sRyx3QkFBd0JvRyxtQkFBbUI7QUFBQSxrQkFDbEQ7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHb0Y7QUFBQSxpQkFQdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLGVBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUNBO0FBQUEsYUEzSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRKQTtBQUFBLFFBSUosdUJBQUMsUUFBSyxXQUFXdkQsV0FBVyxVQUFVQyxjQUVwQztBQUFBLGlDQUFDLFdBQVEsS0FBSSx3QkFFVlQ7QUFBQUEsNEJBQ0c3QyxzQkFBc0IsV0FBV0YsaUJBQ2hDRSxzQkFBc0IsZ0JBQ3JCeUMsWUFDQUUsV0FDSi9DLHNCQUNBQSx1QkFBdUIsU0FDckIsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHVDQUFzQyxrQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNDcUMsV0FBV0csWUFBWUgsV0FBV0UsVUFDakMsdUJBQUMsU0FBSSxXQUFVLHFGQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBTTtBQUFBLHNCQUNOLFdBQVU7QUFBQTtBQUFBLG9CQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFNEI7QUFBQSxrQkFFNUIsdUJBQUMsVUFBSyxXQUFVLGdDQUErQjtBQUFBO0FBQUEsb0JBQzVCO0FBQUEsdUJBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsbUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBGQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGlEQUFnRCwwQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSwyQ0FDVixhQUFHRixXQUFXRSxRQUFRcUssZUFBZSxPQUFPLENBQUMsTUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSxnREFDYmxOLDhCQUFvQjJDLFdBQVdFLFVBQVUsQ0FBQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxpREFBZ0Qsd0JBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsMENBQ1YsYUFBR0YsV0FBV0csVUFBVW9LLGVBQWUsT0FBTyxDQUFDLE1BRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUsK0NBQ2JsTiw4QkFBb0IyQyxXQUFXRyxZQUFZLENBQUMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsaURBQWdELDBCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDBDQUNWLGNBQ0NILFlBQVl5RixjQUFjLE1BQ3pCOEUsZUFBZSxPQUFPLENBQUMsTUFINUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSwrQ0FDYmxOO0FBQUFBLG9CQUNDa0ksS0FBS2lGLElBQUl4SyxZQUFZeUYsY0FBYyxDQUFDO0FBQUEsa0JBQ3RDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLHFCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBY0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkZBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsaURBQWdELDZCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDRDQUNWLGFBQUd6RixXQUFXTyxnQkFBZ0JnSztBQUFBQSxvQkFDN0I7QUFBQSxvQkFDQTtBQUFBLHNCQUNFRSx1QkFBdUI7QUFBQSxzQkFDdkJDLHVCQUF1QjtBQUFBLG9CQUN6QjtBQUFBLGtCQUNGLENBQUMsTUFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLGlEQUNick47QUFBQUEsb0JBQ0MyQyxXQUFXTyxtQkFBbUI7QUFBQSxrQkFDaEMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEscUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsbUJBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeURBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsOENBQTZDLG1DQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1o7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsaURBQ1o7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsd0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFEO0FBQUEsb0JBQ3JELHVCQUFDLFVBQUs7QUFBQTtBQUFBLHNCQUNlO0FBQUEsc0JBQ25CLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0Isb0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9DO0FBQUEseUJBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFDQSx1QkFBQyxVQUFLLFdBQVUsMENBQXlDO0FBQUE7QUFBQSxzQkFDckRsRCxvQkFBb0IsQ0FBQztBQUFBLHNCQUFFO0FBQUEseUJBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVNBO0FBQUEsa0JBQ0MyQyxXQUFXRyxXQUFXSCxXQUFXRSxVQUNoQyx1QkFBQyxRQUFHLFdBQVUsaURBQ1o7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsdUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9EO0FBQUEsb0JBQ3BELHVCQUFDLFVBQUs7QUFBQTtBQUFBLHNCQUNnQjtBQUFBLHNCQUNwQix1QkFBQyxVQUFLLFdBQVUsaUJBRVhGLHVCQUFXRyxXQUNWSCxXQUFXRSxVQUNiLE1BQ0FxSyxlQUFlLFNBQVM7QUFBQSx3QkFDeEJFLHVCQUF1QjtBQUFBLHdCQUN2QkMsdUJBQXVCO0FBQUEsc0JBQ3pCLENBQUMsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVNBO0FBQUEseUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFZQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSx5Q0FBd0M7QUFBQTtBQUFBLHNCQUVyRHJOO0FBQUFBLHlCQUNFMkMsV0FBV0csV0FBV0gsV0FBV0UsVUFDaEM7QUFBQSxzQkFDSjtBQUFBLHNCQUFFO0FBQUEseUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFPQTtBQUFBLHVCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXVCQTtBQUFBLHFCQW5DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQTtBQUFBLG1CQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBDQTtBQUFBLGlCQXJIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNIQTtBQUFBLFlBSUh6QixVQUNDLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxrQkFBZSxXQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFDRUoscUJBQXFCZ0ssU0FBUyxJQUNoQyx1QkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNSztBQUFBQSxnQkFDTjtBQUFBLGdCQUNBLGlCQUFpQjtBQUFBLGdCQUNqQixpQkFBaUI7QUFBQSxrQkFDZjtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGdCQUFjO0FBQUEsZ0JBRWhCLG1CQUFtQjtBQUFBLGtCQUNqQi9LLHVCQUF1QixRQUNuQixrQkFDQVEseUJBQXlCaUYsUUFBUTtBQUFBLGtCQUNyQ3pGLHVCQUF1QixRQUNuQixNQUNBUSx5QkFBeUJxSSxnQkFBZ0I7QUFBQSxrQkFDNUN6SSxzQkFBc0IsV0FBV0YsaUJBQ2pDRSxzQkFBc0IsZ0JBQ3JCeUMsWUFDQUUsU0FDRTNDLHNCQUFzQixXQUNwQixvQkFBSWtCLEtBQUssR0FBR3BCLGFBQWEsS0FBSyxHQUFFME07QUFBQUEsb0JBQzlCO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRTlILE9BQU87QUFBQSxzQkFDUEQsTUFBTTtBQUFBLG9CQUNSO0FBQUEsa0JBQ0YsSUFDQSxHQUFHLElBQUl2RDtBQUFBQSxvQkFDTHVCO0FBQUFBLGtCQUNGLEVBQUVtSyxtQkFBbUIsQ0FBQyxNQUFNLElBQUkxTDtBQUFBQSxvQkFDOUJ5QjtBQUFBQSxrQkFDRixFQUFFaUssbUJBQW1CLENBQUMsS0FDeEI7QUFBQSxrQkFDSixJQUNFM0ssWUFBWUUsUUFBUXFLLGVBQWUsT0FBTyxLQUFLLEdBQUcsS0FDL0NsTixvQkFBb0IyQyxZQUFZRSxVQUFVLENBQUMsQ0FBQztBQUFBLGtCQUNqRCxJQUNFRixZQUFZRyxVQUFVb0ssZUFBZSxPQUFPLEtBQUssR0FBRyxLQUNqRGxOLG9CQUFvQjJDLFlBQVlHLFlBQVksQ0FBQyxDQUFDO0FBQUEsa0JBQ25ELElBQ0VILFlBQVlJLFdBQVdtSyxlQUFlLE9BQU8sS0FDN0MsR0FBRyxLQUNBbE47QUFBQUEsb0JBQ0gyQyxZQUFZSSxhQUFhO0FBQUEsa0JBQzNCLENBQUM7QUFBQSxrQkFDRCxJQUNFSixZQUFZTyxpQkFBaUJnSztBQUFBQSxvQkFDM0I7QUFBQSxvQkFDQTtBQUFBLHNCQUNFRSx1QkFBdUI7QUFBQSxzQkFDdkJDLHVCQUF1QjtBQUFBLG9CQUN6QjtBQUFBLGtCQUNGLEtBQUssTUFBTSxLQUNSck47QUFBQUEsb0JBQ0gyQyxZQUFZTyxtQkFBbUI7QUFBQSxrQkFDakMsQ0FBQztBQUFBLGtCQUNELElBQ0VoQyx3QkFBd0IrRixpQkFBaUJpRztBQUFBQSxvQkFDdkM7QUFBQSxrQkFDRixLQUFLLEdBQUcsS0FDTGxOO0FBQUFBLG9CQUNId0UsWUFBWXRELHdCQUF3QitGLGVBQWU7QUFBQSxrQkFDckQsQ0FBQztBQUFBLGtCQUNELElBQ0UvRix3QkFBd0JrRyxjQUFjOEY7QUFBQUEsb0JBQ3BDO0FBQUEsa0JBQ0YsS0FBSyxHQUFHLEtBQ0xsTjtBQUFBQSxvQkFDSHdFLFlBQVl0RCx3QkFBd0JrRyxZQUFZO0FBQUEsa0JBQ2xELENBQUM7QUFBQSxrQkFDRCxJQUNFbEcsd0JBQXdCdUcsbUJBQW1CeUY7QUFBQUEsb0JBQ3pDO0FBQUEsa0JBQ0YsS0FBSyxHQUFHLEtBQ0xsTjtBQUFBQSxvQkFDSHdFO0FBQUFBLHNCQUNFdEQsd0JBQXdCdUc7QUFBQUEsb0JBQzFCO0FBQUEsa0JBQ0YsQ0FBQztBQUFBLGtCQUNELElBQ0V2Ryx3QkFBd0J3RyxpQkFBaUJ3RjtBQUFBQSxvQkFDdkM7QUFBQSxrQkFDRixLQUFLLEdBQUcsS0FDTGxOO0FBQUFBLG9CQUNId0UsWUFBWXRELHdCQUF3QndHLGVBQWU7QUFBQSxrQkFDckQsQ0FBQztBQUFBLGtCQUNEeEcsd0JBQXdCb0csbUJBQW1CO0FBQUEsa0JBQzNDcEcsd0JBQXdCc0csZ0JBQWdCO0FBQUEsZ0JBQUc7QUFBQSxnQkFFN0Msa0JBQWtCLG1CQUNoQjFHLHlCQUF5QmlGLFFBQVEsS0FBSyxJQUV0Q3JGLHNCQUFzQixVQUNsQkYsZ0JBQ0EsR0FBRzJDLFFBQVEsT0FBT0UsTUFBTSxFQUFFO0FBQUE7QUFBQSxjQXpHbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBMEdTLEtBM0dYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkdBLElBRUFFLGdCQUNJN0Msc0JBQXNCLFdBQVdGLGlCQUNoQ0Usc0JBQXNCLGdCQUNyQnlDLFlBQ0FFLFdBQ0p2Qyx5QkFBeUJpRixRQUN2Qix1QkFBQyxTQUFJLFdBQVUseUVBQ2IsaUNBQUMsT0FBRSxXQUFVLHFDQUFvQyxnRUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQWpRZ0MsY0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvUUE7QUFBQSxVQUdBLHVCQUFDLFdBQVEsS0FBSSwwQkFFVnhDO0FBQUFBLDRCQUNHN0Msc0JBQXNCLFdBQVdGLGlCQUNoQ0Usc0JBQXNCLGdCQUNyQnlDLFlBQ0FFLFlBQ0gvQyx1QkFBdUIsU0FDdEJRLDRCQUNBLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSw0Q0FBMkMsdUNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxpREFBZ0QsaUNBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUNFcUQsc0JBQXNCRyx5QkFBeUI0STtBQUFBQSx3QkFDN0M7QUFBQSxzQkFDRixLQUFLO0FBQUEsc0JBRVA7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT21GO0FBQUEsa0JBRW5GLHVCQUFDLFVBQUssV0FBVSwrQ0FDYmxOO0FBQUFBLG9CQUNDbUUsc0JBQXNCRywyQkFDcEI7QUFBQSxrQkFDSixLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxxQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEZBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsaURBQWdELHFDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FDRUgsc0JBQXNCRSw2QkFBNkI2STtBQUFBQSx3QkFDakQ7QUFBQSxzQkFDRixLQUFLO0FBQUEsc0JBRVA7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT29GO0FBQUEsa0JBRXBGLHVCQUFDLFVBQUssV0FBVSxnREFDYmxOO0FBQUFBLG9CQUNDbUUsc0JBQXNCRSwrQkFDcEI7QUFBQSxrQkFDSixLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxxQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEZBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsaURBQWdELGlDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FDRUYsc0JBQXNCSSwyQkFDdEI7QUFBQSxzQkFFRjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNb0Y7QUFBQSxxQkFWdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLG1CQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNEQTtBQUFBLGlCQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJEQTtBQUFBLFlBSUhuRCxVQUNDLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxrQkFBZSxXQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFDRTZDLG1CQUFtQitHLFNBQVMsSUFDOUIsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTS9HO0FBQUFBLGdCQUNOLFNBQVNvSTtBQUFBQSxnQkFDVCxpQkFBaUI7QUFBQSxnQkFDakIsaUJBQWlCO0FBQUEsa0JBQ2Y7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsZ0JBQW1CO0FBQUEsZ0JBRXJCLG1CQUFtQjtBQUFBLGtCQUNqQi9MLHVCQUF1QixRQUNuQixrQkFDQVEseUJBQXlCaUYsUUFBUTtBQUFBLGtCQUNyQ3pGLHVCQUF1QixRQUNuQixNQUNBUSx5QkFBeUJxSSxnQkFBZ0I7QUFBQSxrQkFDNUN6SSxzQkFBc0IsV0FBV0YsaUJBQ2pDRSxzQkFBc0IsZ0JBQ3JCeUMsWUFDQUUsU0FDRTNDLHNCQUFzQixXQUNwQixvQkFBSWtCLEtBQUssR0FBR3BCLGFBQWEsS0FBSyxHQUFFME07QUFBQUEsb0JBQzlCO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRTlILE9BQU87QUFBQSxzQkFDUEQsTUFBTTtBQUFBLG9CQUNSO0FBQUEsa0JBQ0YsSUFDQSxHQUFHLElBQUl2RDtBQUFBQSxvQkFDTHVCO0FBQUFBLGtCQUNGLEVBQUVtSyxtQkFBbUIsQ0FBQyxNQUFNLElBQUkxTDtBQUFBQSxvQkFDOUJ5QjtBQUFBQSxrQkFDRixFQUFFaUssbUJBQW1CLENBQUMsS0FDeEI7QUFBQSxrQkFDSixJQUNFbkosc0JBQXNCRyx5QkFBeUI0STtBQUFBQSxvQkFDN0M7QUFBQSxrQkFDRixLQUFLLEdBQUcsS0FDTGxOO0FBQUFBLG9CQUNIbUUsc0JBQXNCRywyQkFBMkI7QUFBQSxrQkFDbkQsQ0FBQztBQUFBLGtCQUNELElBQ0VILHNCQUFzQkUsNkJBQTZCNkk7QUFBQUEsb0JBQ2pEO0FBQUEsa0JBQ0YsS0FBSyxHQUFHLEtBQ0xsTjtBQUFBQSxvQkFDSG1FLHNCQUFzQkUsK0JBQ3BCO0FBQUEsa0JBQ0osQ0FBQztBQUFBLGtCQUNELEdBQUdGLHNCQUFzQkksMkJBQTJCLEdBQUc7QUFBQSxnQkFBRTtBQUFBLGdCQUUzRCxrQkFBa0Isd0JBQ2hCekQseUJBQXlCaUYsUUFBUSxLQUFLLElBRXRDckYsc0JBQXNCLFVBQ2xCRixnQkFDQSxHQUFHMkMsUUFBUSxPQUFPRSxNQUFNLEVBQUU7QUFBQTtBQUFBLGNBM0RsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE0RFMsS0E3RFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErREEsSUFFQUUsZ0JBQ0k3QyxzQkFBc0IsV0FBV0YsaUJBQ2hDRSxzQkFBc0IsZ0JBQ3JCeUMsWUFDQUUsV0FDSnZDLHlCQUF5QmlGLFFBQ3ZCLHVCQUFDLFNBQUksV0FBVSx5RUFDYixpQ0FBQyxPQUFFLFdBQVUscUNBQW9DLHNFQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBeEprQyxtQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEySkE7QUFBQSxhQXBhRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcWFBO0FBQUEsV0FwbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxbkJBO0FBQUEsU0FudkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxdkJBO0FBQUEsT0F2dkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3dkJBLEtBenZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMHZCQTtBQUVKO0FBQUU1RixHQTFyQ0lELGlCQUFlO0FBQUFxTixLQUFmck47QUE0ckNOLGVBQWVBO0FBQWdCLElBQUFxTjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTZWxlY3QiLCJSYWRpbyIsIlRhYnMiLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIk5hdmJhciIsIk1vZGFsIiwiR2lQYXJ0eVBvcHBlciIsIkxpbmsiLCJGaWxlVGV4dE91dGxpbmVkIiwiRG9sbGFyT3V0bGluZWQiLCJGYU1vbmV5QmlsbCIsIk1kUGF5bWVudHMiLCJGaVRhcmdldCIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJUYWJQYW5lIiwiVGFyZ2V0SW5jZW50aXZlIiwiX3MiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJzZWxlY3RlZEVtcGxveWVlSWQiLCJzZXRTZWxlY3RlZEVtcGxveWVlSWQiLCJzZWxlY3RlZE1vbnRoIiwic2V0U2VsZWN0ZWRNb250aCIsImRhdGVTZWxlY3Rpb25Nb2RlIiwic2V0RGF0ZVNlbGVjdGlvbk1vZGUiLCJhZ2VudExvYWRpbmciLCJzZXRBZ2VudExvYWRpbmciLCJzZWxlY3RlZEVtcGxveWVlRGV0YWlscyIsInNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzIiwiZW1wbG95ZWVDdXN0b21lckRhdGEiLCJzZXRFbXBsb3llZUN1c3RvbWVyRGF0YSIsImNvbW1pc3Npb25Ub3RhbERldGFpbHMiLCJzZXRDb21taXNzaW9uVG90YWxEZXRhaWxzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzaG93Q29tbWlzc2lvbk1vZGFsIiwic2V0U2hvd0NvbW1pc3Npb25Nb2RhbCIsImNvbW1pc3Npb25Gb3JtIiwic2V0Q29tbWlzc2lvbkZvcm0iLCJhZ2VudF9pZCIsInBheV9kYXRlIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJhbW91bnQiLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwibm90ZSIsInBheV9mb3IiLCJhZG1pbl90eXBlIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiYWRtaW5JZCIsInNldEFkbWluSWQiLCJhZG1pbk5hbWUiLCJzZXRBZG1pbk5hbWUiLCJ0YXJnZXREYXRhIiwic2V0VGFyZ2V0RGF0YSIsInRhcmdldCIsImFjaGlldmVkIiwicmVtYWluaW5nIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsImluY2VudGl2ZUFtb3VudCIsImZyb21EYXRlIiwic2V0RnJvbURhdGUiLCJ0b0RhdGUiLCJzZXRUb0RhdGUiLCJpc0ZpbHRlcmluZyIsInNldElzRmlsdGVyaW5nIiwidGVtcFNlbGVjdGVkTW9udGgiLCJzZXRUZW1wU2VsZWN0ZWRNb250aCIsInRlbXBGcm9tRGF0ZSIsInNldFRlbXBGcm9tRGF0ZSIsInRlbXBUb0RhdGUiLCJzZXRUZW1wVG9EYXRlIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwiZ3Jvc3NJbmNlbnRpdmVEYXRhIiwic2V0R3Jvc3NJbmNlbnRpdmVEYXRhIiwiZ3Jvc3NJbmNlbnRpdmVTdW1tYXJ5Iiwic2V0R3Jvc3NJbmNlbnRpdmVTdW1tYXJ5IiwidG90YWxfZ3Jvc3NfaW5jZW50aXZlX3ZhbHVlIiwidG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWUiLCJ0b3RhbF9ncm9zc19lbnJvbGxtZW50cyIsInBhcnNlQW1vdW50IiwidmFsIiwicGFyc2VGbG9hdCIsInRvU3RyaW5nIiwicmVwbGFjZSIsInRvZGF5IiwiY3VycmVudE1vbnRoIiwiZ2V0RnVsbFllYXIiLCJTdHJpbmciLCJnZXRNb250aCIsInBhZFN0YXJ0IiwieWVhciIsIm1vbnRoIiwiZmlyc3REYXkiLCJsYXN0ZGF5MSIsImdldERhdGUiLCJsYXN0RGF5IiwidXNlciIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJfaWQiLCJuYW1lIiwiZmV0Y2hFbXBsb3llZXMiLCJyZXMiLCJnZXQiLCJkYXRhIiwiZW1wbG95ZWUiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJmZXRjaENvbW1pc3Npb25SZXBvcnQiLCJlbXBsb3llZUlkIiwiYWJvcnRDb250cm9sbGVyIiwiQWJvcnRDb250cm9sbGVyIiwicGFyYW1zIiwic3RhcnRfZGF0ZSIsImVuZF9kYXRlIiwic2lnbmFsIiwiaW5jZW50aXZlRGF0YSIsImFjdHVhbF9idXNpbmVzcyIsImluY2VudGl2ZVN1bW1hcnkiLCJ0b3RhbF9ncm91cF92YWx1ZSIsInRvdGFsX2FjdHVhbCIsInRvdGFsX2luY2VudGl2ZV92YWx1ZSIsInRvdGFsX2N1c3RvbWVycyIsInRvdGFsX2Vucm9sbG1lbnRzIiwidG90YWxfZ3JvdXBzIiwiZXhwZWN0ZWRfYnVzaW5lc3MiLCJ0b3RhbF9lc3RpbWF0ZWQiLCJmZXRjaFRhcmdldERhdGEiLCJzdGF0dXMiLCJ0b3RhbF90YXJnZXQiLCJ1bmRlZmluZWQiLCJ0b3RhbFRhcmdldCIsIk51bWJlciIsImNvbW0iLCJNYXRoIiwibWF4IiwiZGlmZmVyZW5jZSIsInJvdW5kIiwidG9GaXhlZCIsIkVycm9yIiwiZmV0Y2hBbGxDb21taXNzaW9uUmVwb3J0IiwiY29tbWlzc2lvbkRhdGEiLCJjb21taXNzaW9uU3VtbWFyeSIsInRvdGFsX2NvbW1pc3Npb25fdmFsdWUiLCJmZXRjaEdyb3NzSW5jZW50aXZlUmVwb3J0IiwiZ3Jvc3NJbmNlbnRpdmVJbmZvIiwibWFwIiwiZW5yb2xsbWVudCIsInVzZXJfbmFtZSIsInVzZXJfaWQiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJncm91cF9uYW1lIiwiZ3JvdXBfaWQiLCJncm91cF92YWx1ZSIsImdyb3VwX2luY2VudGl2ZSIsImluY2VudGl2ZXMiLCJncm91cF90aWNrZXQiLCJ0aWNrZXRzIiwiZW5yb2xsbWVudF9kYXRlIiwiY3JlYXRlZEF0IiwidG90YWxfcGFpZF9hbW91bnQiLCJncm91cF9tb250aGx5X2luc3RhbGxtZW50IiwibW9udGhseV9pbnN0YWxsbWVudCIsImZldGNoQWxsR3Jvc3NJbmNlbnRpdmVSZXBvcnQiLCJoYW5kbGVFbXBsb3llZUNoYW5nZSIsInZhbHVlIiwiaGFuZGxlVGVtcE1vbnRoQ2hhbmdlIiwiZSIsImFwcGx5RmlsdGVyIiwiYWxlcnQiLCJlbXAiLCJmaW5kIiwiaGFuZGxlQ29tbWlzc2lvbkNoYW5nZSIsInByZXYiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJpc05hTiIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJoYW5kbGVDb21taXNzaW9uU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJwYXlsb2FkIiwicG9zdCIsInByb2Nlc3NlZFRhYmxlRGF0YSIsIml0ZW0iLCJpbmRleCIsImdyb3VwX3ZhbHVlX2RpZ2l0cyIsInRpY2tldCIsImVzdGltYXRlZF9jb21taXNzaW9uX2RpZ2l0cyIsImVzdGltYXRlZF9jb21taXNzaW9uIiwibmV0X2luY2VudGl2ZV9kaWdpdHMiLCJpbmNlbnRpdmVfdmFsdWUiLCJpbmNlbnRpdmVfcGVyY2VudGFnZSIsInRvdGFsX3BhaWRfZGlnaXRzIiwicmVxdWlyZWRfaW5zdGFsbG1lbnRfZGlnaXRzIiwiaW5jZW50aXZlX3JlbGVhc2VkIiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsImdyb3NzSW5jZW50aXZlQ29sdW1ucyIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiaGVpZ2h0IiwiZW1haWwiLCJhZGhhYXJfbm8iLCJwYW5fbm8iLCJwaW5jb2RlIiwiYWRkcmVzcyIsImpvaW5pbmdfZGF0ZSIsInRvTG9jYWxlU3RyaW5nIiwiYWJzIiwibWluaW11bUZyYWN0aW9uRGlnaXRzIiwibWF4aW11bUZyYWN0aW9uRGlnaXRzIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGFyZ2V0SW5jZW50aXZlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIFJhZGlvLCBUYWJzIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBHaVBhcnR5UG9wcGVyIH0gZnJvbSBcInJlYWN0LWljb25zL2dpXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBGaWxlVGV4dE91dGxpbmVkLCBEb2xsYXJPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBGYU1vbmV5QmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBNZFBheW1lbnRzIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IEZpVGFyZ2V0IH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcblxyXG5jb25zdCB7IFRhYlBhbmUgfSA9IFRhYnM7XHJcblxyXG5jb25zdCBUYXJnZXRJbmNlbnRpdmUgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZUlkLCBzZXRTZWxlY3RlZEVtcGxveWVlSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkTW9udGgsIHNldFNlbGVjdGVkTW9udGhdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2RhdGVTZWxlY3Rpb25Nb2RlLCBzZXREYXRlU2VsZWN0aW9uTW9kZV0gPSB1c2VTdGF0ZShcIm1vbnRoXCIpO1xyXG4gIGNvbnN0IFthZ2VudExvYWRpbmcsIHNldEFnZW50TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLCBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlsc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZW1wbG95ZWVDdXN0b21lckRhdGEsIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY29tbWlzc2lvblRvdGFsRGV0YWlscywgc2V0Q29tbWlzc2lvblRvdGFsRGV0YWlsc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93Q29tbWlzc2lvbk1vZGFsLCBzZXRTaG93Q29tbWlzc2lvbk1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY29tbWlzc2lvbkZvcm0sIHNldENvbW1pc3Npb25Gb3JtXSA9IHVzZVN0YXRlKHtcclxuICAgIGFnZW50X2lkOiBcIlwiLFxyXG4gICAgcGF5X2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0sXHJcbiAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgICBwYXlfZm9yOiBcImNvbW1pc3Npb25cIixcclxuICAgIGFkbWluX3R5cGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbYWRtaW5JZCwgc2V0QWRtaW5JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRtaW5OYW1lLCBzZXRBZG1pbk5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3RhcmdldERhdGEsIHNldFRhcmdldERhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdGFyZ2V0OiAwLFxyXG4gICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICByZW1haW5pbmc6IDAsXHJcbiAgICBzdGFydERhdGU6IFwiXCIsXHJcbiAgICBlbmREYXRlOiBcIlwiLFxyXG4gICAgaW5jZW50aXZlQW1vdW50OiAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtmcm9tRGF0ZSwgc2V0RnJvbURhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RvRGF0ZSwgc2V0VG9EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpc0ZpbHRlcmluZywgc2V0SXNGaWx0ZXJpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt0ZW1wU2VsZWN0ZWRNb250aCwgc2V0VGVtcFNlbGVjdGVkTW9udGhdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RlbXBGcm9tRGF0ZSwgc2V0VGVtcEZyb21EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt0ZW1wVG9EYXRlLCBzZXRUZW1wVG9EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShcImNvbW1pc3Npb25cIik7XHJcbiAgY29uc3QgW2dyb3NzSW5jZW50aXZlRGF0YSwgc2V0R3Jvc3NJbmNlbnRpdmVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3Jvc3NJbmNlbnRpdmVTdW1tYXJ5LCBzZXRHcm9zc0luY2VudGl2ZVN1bW1hcnldID0gdXNlU3RhdGUoe1xyXG4gICAgdG90YWxfZ3Jvc3NfaW5jZW50aXZlX3ZhbHVlOiAwLFxyXG4gICAgdG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWU6IDAsXHJcbiAgICB0b3RhbF9ncm9zc19lbnJvbGxtZW50czogMCxcclxuICB9KTtcclxuXHJcbiAgLy8g4pyFIEhlbHBlciB0byBzYW5pdGl6ZSBzdHJpbmcgYW1vdW50cyB0byBudW1iZXJzIGZvciB3b3JkIGNvbnZlcnNpb25cclxuICBjb25zdCBwYXJzZUFtb3VudCA9ICh2YWwpID0+XHJcbiAgICBwYXJzZUZsb2F0KHZhbD8udG9TdHJpbmcoKS5yZXBsYWNlKC9bXjAtOS4tXSsvZywgXCJcIikpIHx8IDA7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBjdXJyZW50TW9udGggPSBgJHt0b2RheS5nZXRGdWxsWWVhcigpfS0ke1N0cmluZyhcclxuICAgICAgdG9kYXkuZ2V0TW9udGgoKSArIDFcclxuICAgICkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgICBzZXRUZW1wU2VsZWN0ZWRNb250aChjdXJyZW50TW9udGgpO1xyXG4gICAgc2V0U2VsZWN0ZWRNb250aChjdXJyZW50TW9udGgpO1xyXG4gICAgY29uc3QgeWVhciA9IHRvZGF5LmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtb250aCA9IHRvZGF5LmdldE1vbnRoKCkgKyAxO1xyXG4gICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfS0wMWA7XHJcbiAgICBjb25zdCBsYXN0ZGF5MSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XHJcbiAgICBjb25zdCBsYXN0RGF5ID0gYCR7eWVhcn0tJHttb250aH0tJHtTdHJpbmcobGFzdGRheTEpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG4gICAgc2V0VGVtcEZyb21EYXRlKGZpcnN0RGF5KTtcclxuICAgIHNldFRlbXBUb0RhdGUobGFzdERheSk7XHJcbiAgICBzZXRGcm9tRGF0ZShmaXJzdERheSk7XHJcbiAgICBzZXRUb0RhdGUobGFzdERheSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpKTtcclxuICAgIGlmICh1c2VyKSB7XHJcbiAgICAgIHNldEFkbWluSWQodXNlci5faWQpO1xyXG4gICAgICBzZXRBZG1pbk5hbWUodXNlci5uYW1lIHx8IFwiXCIpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICBzZXRFbXBsb3llZXMocmVzPy5kYXRhPy5lbXBsb3llZSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlczpcIiwgZXJyKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaENvbW1pc3Npb25SZXBvcnQgPSBhc3luYyAoZW1wbG95ZWVJZCwgc3RhcnREYXRlLCBlbmREYXRlKSA9PiB7XHJcbiAgICBpZiAoIWVtcGxveWVlSWQgfHwgIXN0YXJ0RGF0ZSB8fCAhZW5kRGF0ZSkgcmV0dXJuO1xyXG4gICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICBzdGFydF9kYXRlOiBzdGFydERhdGUsXHJcbiAgICAgICAgZW5kX2RhdGU6IGVuZERhdGUsXHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoYC9lbnJvbGwvZW1wbG95ZWUvJHtlbXBsb3llZUlkfS9pbmNlbnRpdmVgLCB7XHJcbiAgICAgICAgcGFyYW1zLFxyXG4gICAgICAgIHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbCxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKHJlcy5kYXRhPy5pbmNlbnRpdmVEYXRhKTtcclxuICAgICAgc2V0Q29tbWlzc2lvblRvdGFsRGV0YWlscyh7XHJcbiAgICAgICAgYWN0dWFsX2J1c2luZXNzOiByZXMuZGF0YT8uaW5jZW50aXZlU3VtbWFyeT8udG90YWxfZ3JvdXBfdmFsdWUsXHJcbiAgICAgICAgdG90YWxfYWN0dWFsOiByZXMuZGF0YT8uaW5jZW50aXZlU3VtbWFyeT8udG90YWxfaW5jZW50aXZlX3ZhbHVlLFxyXG4gICAgICAgIHRvdGFsX2N1c3RvbWVyczogcmVzLmRhdGE/LmluY2VudGl2ZVN1bW1hcnk/LnRvdGFsX2Vucm9sbG1lbnRzLFxyXG4gICAgICAgIHRvdGFsX2dyb3VwczogcmVzLmRhdGE/LmluY2VudGl2ZVN1bW1hcnk/LnRvdGFsX2Vucm9sbG1lbnRzLFxyXG4gICAgICAgIGV4cGVjdGVkX2J1c2luZXNzOiByZXMuZGF0YT8uaW5jZW50aXZlU3VtbWFyeT8udG90YWxfZ3JvdXBfdmFsdWUsXHJcbiAgICAgICAgdG90YWxfZXN0aW1hdGVkOiByZXMuZGF0YT8uaW5jZW50aXZlU3VtbWFyeT8udG90YWxfaW5jZW50aXZlX3ZhbHVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBpZiAoZXJyLm5hbWUgIT09IFwiQWJvcnRDb250cm9sbGVyXCIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWUgcmVwb3J0OlwiLCBlcnIpO1xyXG4gICAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgICAgICBzZXRDb21taXNzaW9uVG90YWxEZXRhaWxzKHt9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoVGFyZ2V0RGF0YSA9IGFzeW5jIChlbXBsb3llZUlkLCBzdGFydERhdGUsIGVuZERhdGUpID0+IHtcclxuICAgIGlmICghZW1wbG95ZWVJZCB8fCAhc3RhcnREYXRlIHx8ICFlbmREYXRlKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KGAvdGFyZ2V0L2VtcGxveWVlcy8ke2VtcGxveWVlSWR9YCwge1xyXG4gICAgICAgIHBhcmFtczogeyBzdGFydF9kYXRlOiBzdGFydERhdGUsIGVuZF9kYXRlOiBlbmREYXRlIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgICBpZiAocmVzLmRhdGEuc3RhdHVzICYmIHJlcy5kYXRhLnRvdGFsX3RhcmdldCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgY29uc3QgdG90YWxUYXJnZXQgPSBOdW1iZXIocmVzLmRhdGEudG90YWxfdGFyZ2V0KTtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgc3RhcnRfZGF0ZTogc3RhcnREYXRlLFxyXG4gICAgICAgICAgZW5kX2RhdGU6IGVuZERhdGUsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCB7IGRhdGE6IGNvbW0gfSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL2Vucm9sbC9lbXBsb3llZS8ke2VtcGxveWVlSWR9L2luY2VudGl2ZWAsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIHBhcmFtcyxcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIGxldCBhY2hpZXZlZCA9IGNvbW0/LmluY2VudGl2ZVN1bW1hcnk/LnRvdGFsX2dyb3VwX3ZhbHVlIHx8IDA7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBhY2hpZXZlZCA9PT0gXCJzdHJpbmdcIikge1xyXG4gICAgICAgICAgYWNoaWV2ZWQgPSBOdW1iZXIoYWNoaWV2ZWQucmVwbGFjZSgvW14wLTkuLV0rL2csIFwiXCIpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgcmVtYWluaW5nID0gTWF0aC5tYXgodG90YWxUYXJnZXQgLSBhY2hpZXZlZCwgMCk7XHJcbiAgICAgICAgY29uc3QgZGlmZmVyZW5jZSA9IGFjaGlldmVkIC0gdG90YWxUYXJnZXQ7XHJcbiAgICAgICAgY29uc3QgaW5jZW50aXZlQW1vdW50ID0gZGlmZmVyZW5jZSA+IDAgPyBkaWZmZXJlbmNlICogMC4wMSA6IDA7XHJcbiAgICAgICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgICAgICAgICB0YXJnZXQ6IE1hdGgucm91bmQodG90YWxUYXJnZXQpLFxyXG4gICAgICAgICAgYWNoaWV2ZWQ6IE1hdGgucm91bmQoYWNoaWV2ZWQpLFxyXG4gICAgICAgICAgcmVtYWluaW5nOiBNYXRoLnJvdW5kKHJlbWFpbmluZyksXHJcbiAgICAgICAgICBkaWZmZXJlbmNlOiBNYXRoLnJvdW5kKGRpZmZlcmVuY2UpLFxyXG4gICAgICAgICAgc3RhcnREYXRlOiBzdGFydERhdGUsXHJcbiAgICAgICAgICBlbmREYXRlOiBlbmREYXRlLFxyXG4gICAgICAgICAgaW5jZW50aXZlQW1vdW50OiBwYXJzZUZsb2F0KGluY2VudGl2ZUFtb3VudC50b0ZpeGVkKDIpKSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHRhcmdldCByZXNwb25zZVwiKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YXJnZXQgZGF0YTpcIiwgZXJyKTtcclxuICAgICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgICAgICAgdGFyZ2V0OiAwLFxyXG4gICAgICAgIGFjaGlldmVkOiAwLFxyXG4gICAgICAgIHJlbWFpbmluZzogMCxcclxuICAgICAgICBkaWZmZXJlbmNlOiAwLFxyXG4gICAgICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuICAgICAgICBlbmREYXRlOiBcIlwiLFxyXG4gICAgICAgIGluY2VudGl2ZUFtb3VudDogMCxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBbGxDb21taXNzaW9uUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFmcm9tRGF0ZSB8fCAhdG9EYXRlKSByZXR1cm47XHJcbiAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgIHN0YXJ0X2RhdGU6IGZyb21EYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlOiB0b0RhdGUsXHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvZW5yb2xsL2luY2VudGl2ZVwiLCB7XHJcbiAgICAgICAgcGFyYW1zLFxyXG4gICAgICAgIHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbCxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKHJlcy5kYXRhPy5jb21taXNzaW9uRGF0YSk7XHJcbiAgICAgIHNldENvbW1pc3Npb25Ub3RhbERldGFpbHMoe1xyXG4gICAgICAgIGFjdHVhbF9idXNpbmVzczogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9ncm91cF92YWx1ZSxcclxuICAgICAgICB0b3RhbF9hY3R1YWw6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfY29tbWlzc2lvbl92YWx1ZSxcclxuICAgICAgICB0b3RhbF9jdXN0b21lcnM6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfZW5yb2xsbWVudHMsXHJcbiAgICAgICAgdG90YWxfZ3JvdXBzOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2Vucm9sbG1lbnRzLFxyXG4gICAgICAgIGV4cGVjdGVkX2J1c2luZXNzOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2dyb3VwX3ZhbHVlLFxyXG4gICAgICAgIHRvdGFsX2VzdGltYXRlZDogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9jb21taXNzaW9uX3ZhbHVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBpZiAoZXJyLm5hbWUgIT09IFwiQWJvcnRFcnJvclwiKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFsbCBjb21taXNzaW9uIHJlcG9ydDpcIiwgZXJyKTtcclxuICAgICAgICBzZXRFbXBsb3llZUN1c3RvbWVyRGF0YShbXSk7XHJcbiAgICAgICAgc2V0Q29tbWlzc2lvblRvdGFsRGV0YWlscyh7fSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEdyb3NzSW5jZW50aXZlUmVwb3J0ID0gYXN5bmMgKGVtcGxveWVlSWQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSkgPT4ge1xyXG4gICAgaWYgKCFlbXBsb3llZUlkIHx8ICFzdGFydERhdGUgfHwgIWVuZERhdGUpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgc3RhcnRfZGF0ZTogc3RhcnREYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlOiBlbmREYXRlLFxyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvZW5yb2xsL2VtcGxveWVlLyR7ZW1wbG95ZWVJZH0vZ3Jvc3MtaW5jZW50aXZlYCxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXJhbXMsXHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBpbmNlbnRpdmVEYXRhID0gcmVzLmRhdGE/Lmdyb3NzSW5jZW50aXZlSW5mbz8ubWFwKChlbnJvbGxtZW50KSA9PiAoe1xyXG4gICAgICAgIHVzZXJfbmFtZTogZW5yb2xsbWVudD8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgcGhvbmVfbnVtYmVyOiBlbnJvbGxtZW50Py51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICBncm91cF9uYW1lOiBlbnJvbGxtZW50Py5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIGdyb3VwX3ZhbHVlOiBlbnJvbGxtZW50Py5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgfHwgXCJOL0FcIixcclxuICAgICAgICBncm91cF9pbmNlbnRpdmU6IGVucm9sbG1lbnQ/Lmdyb3VwX2lkPy5pbmNlbnRpdmVzIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgZ3JvdXBfdGlja2V0OiBlbnJvbGxtZW50Py50aWNrZXRzIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgZW5yb2xsbWVudF9kYXRlOiBlbnJvbGxtZW50Py5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKT8uWzBdLFxyXG4gICAgICAgIHRvdGFsX3BhaWRfYW1vdW50OiBlbnJvbGxtZW50Py50b3RhbF9wYWlkX2Ftb3VudCB8fCBcIjBcIixcclxuICAgICAgICBncm91cF9tb250aGx5X2luc3RhbGxtZW50OlxyXG4gICAgICAgICAgZW5yb2xsbWVudD8uZ3JvdXBfaWQ/Lm1vbnRobHlfaW5zdGFsbG1lbnQgfHwgXCJOL0FcIixcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRHcm9zc0luY2VudGl2ZURhdGEoaW5jZW50aXZlRGF0YSB8fCBbXSk7XHJcbiAgICAgIHNldEdyb3NzSW5jZW50aXZlU3VtbWFyeShcclxuICAgICAgICByZXMuZGF0YS5ncm9zc0luY2VudGl2ZVN1bW1hcnkgfHwge1xyXG4gICAgICAgICAgdG90YWxfZ3Jvc3NfaW5jZW50aXZlX3ZhbHVlOiAwLFxyXG4gICAgICAgICAgdG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWU6IDAsXHJcbiAgICAgICAgICB0b3RhbF9ncm9zc19lbnJvbGxtZW50czogMCxcclxuICAgICAgICB9XHJcbiAgICAgICk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3NzIGluY2VudGl2ZSByZXBvcnQ6XCIsIGVycik7XHJcbiAgICAgIHNldEdyb3NzSW5jZW50aXZlRGF0YShbXSk7XHJcbiAgICAgIHNldEdyb3NzSW5jZW50aXZlU3VtbWFyeSh7XHJcbiAgICAgICAgdG90YWxfZ3Jvc3NfaW5jZW50aXZlX3ZhbHVlOiAwLFxyXG4gICAgICAgIHRvdGFsX2dyb3NzX2dyb3VwX3ZhbHVlOiAwLFxyXG4gICAgICAgIHRvdGFsX2dyb3NzX2Vucm9sbG1lbnRzOiAwLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEFsbEdyb3NzSW5jZW50aXZlUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFmcm9tRGF0ZSB8fCAhdG9EYXRlKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgIHN0YXJ0X2RhdGU6IGZyb21EYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlOiB0b0RhdGUsXHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvZW5yb2xsL2dyb3NzLWluY2VudGl2ZVwiLCB7XHJcbiAgICAgICAgcGFyYW1zLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0R3Jvc3NJbmNlbnRpdmVEYXRhKHJlcy5kYXRhLmdyb3NzSW5jZW50aXZlSW5mbyB8fCBbXSk7XHJcbiAgICAgIHNldEdyb3NzSW5jZW50aXZlU3VtbWFyeShcclxuICAgICAgICByZXMuZGF0YS5ncm9zc0luY2VudGl2ZVN1bW1hcnkgfHwge1xyXG4gICAgICAgICAgdG90YWxfZ3Jvc3NfaW5jZW50aXZlX3ZhbHVlOiAwLFxyXG4gICAgICAgICAgdG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWU6IDAsXHJcbiAgICAgICAgICB0b3RhbF9ncm9zc19lbnJvbGxtZW50czogMCxcclxuICAgICAgICB9XHJcbiAgICAgICk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFsbCBncm9zcyBpbmNlbnRpdmUgcmVwb3J0OlwiLCBlcnIpO1xyXG4gICAgICBzZXRHcm9zc0luY2VudGl2ZURhdGEoW10pO1xyXG4gICAgICBzZXRHcm9zc0luY2VudGl2ZVN1bW1hcnkoe1xyXG4gICAgICAgIHRvdGFsX2dyb3NzX2luY2VudGl2ZV92YWx1ZTogMCxcclxuICAgICAgICB0b3RhbF9ncm9zc19ncm91cF92YWx1ZTogMCxcclxuICAgICAgICB0b3RhbF9ncm9zc19lbnJvbGxtZW50czogMCxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRW1wbG95ZWVDaGFuZ2UgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkRW1wbG95ZWVJZCh2YWx1ZSk7XHJcbiAgICBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlscyhudWxsKTtcclxuICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgIHNldENvbW1pc3Npb25Ub3RhbERldGFpbHMoe30pO1xyXG4gICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgICAgIHRhcmdldDogMCxcclxuICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgIHJlbWFpbmluZzogMCxcclxuICAgICAgc3RhcnREYXRlOiBcIlwiLFxyXG4gICAgICBlbmREYXRlOiBcIlwiLFxyXG4gICAgICBpbmNlbnRpdmVBbW91bnQ6IDAsXHJcbiAgICB9KTtcclxuICAgIHNldEdyb3NzSW5jZW50aXZlRGF0YShbXSk7XHJcbiAgICBzZXRHcm9zc0luY2VudGl2ZVN1bW1hcnkoe1xyXG4gICAgICB0b3RhbF9ncm9zc19pbmNlbnRpdmVfdmFsdWU6IDAsXHJcbiAgICAgIHRvdGFsX2dyb3NzX2dyb3VwX3ZhbHVlOiAwLFxyXG4gICAgICB0b3RhbF9ncm9zc19lbnJvbGxtZW50czogMCxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVRlbXBNb250aENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZE1vbnRoID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRUZW1wU2VsZWN0ZWRNb250aChzZWxlY3RlZE1vbnRoKTtcclxuICAgIGlmIChzZWxlY3RlZE1vbnRoKSB7XHJcbiAgICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSBzZWxlY3RlZE1vbnRoLnNwbGl0KFwiLVwiKTtcclxuICAgICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke21vbnRofS0wMWA7XHJcbiAgICAgIGNvbnN0IGxhc3RkYXkxID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLmdldERhdGUoKTtcclxuICAgICAgY29uc3QgbGFzdERheSA9IGAke3llYXJ9LSR7bW9udGh9LSR7U3RyaW5nKGxhc3RkYXkxKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICAgICAgc2V0VGVtcEZyb21EYXRlKGZpcnN0RGF5KTtcclxuICAgICAgc2V0VGVtcFRvRGF0ZShsYXN0RGF5KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBhcHBseUZpbHRlciA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRFbXBsb3llZUlkKSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBhbiBlbXBsb3llZS5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGlmIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiICYmICF0ZW1wU2VsZWN0ZWRNb250aCkge1xyXG4gICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgYSBtb250aC5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGlmIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJkYXRlLXJhbmdlXCIgJiYgKCF0ZW1wRnJvbURhdGUgfHwgIXRlbXBUb0RhdGUpKSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBib3RoIEZyb20gYW5kIFRvIGRhdGVzLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgc2V0SXNGaWx0ZXJpbmcodHJ1ZSk7XHJcbiAgICBsZXQgc3RhcnREYXRlLCBlbmREYXRlO1xyXG4gICAgaWYgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIpIHtcclxuICAgICAgc2V0U2VsZWN0ZWRNb250aCh0ZW1wU2VsZWN0ZWRNb250aCk7XHJcbiAgICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSB0ZW1wU2VsZWN0ZWRNb250aC5zcGxpdChcIi1cIik7XHJcbiAgICAgIHN0YXJ0RGF0ZSA9IGAke3llYXJ9LSR7bW9udGh9LTAxYDtcclxuICAgICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XHJcbiAgICAgIGVuZERhdGUgPSBgJHt5ZWFyfS0ke21vbnRofS0ke1N0cmluZyhsYXN0RGF5KS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICAgICAgc2V0RnJvbURhdGUoc3RhcnREYXRlKTtcclxuICAgICAgc2V0VG9EYXRlKGVuZERhdGUpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc3RhcnREYXRlID0gdGVtcEZyb21EYXRlO1xyXG4gICAgICBlbmREYXRlID0gdGVtcFRvRGF0ZTtcclxuICAgICAgc2V0RnJvbURhdGUoc3RhcnREYXRlKTtcclxuICAgICAgc2V0VG9EYXRlKGVuZERhdGUpO1xyXG4gICAgfVxyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHNldEFnZW50TG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChzZWxlY3RlZEVtcGxveWVlSWQgPT09IFwiQUxMXCIpIHtcclxuICAgICAgICBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlscyhudWxsKTtcclxuICAgICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICAgIGFjaGlldmVkOiAwLFxyXG4gICAgICAgICAgcmVtYWluaW5nOiAwLFxyXG4gICAgICAgICAgc3RhcnREYXRlOiBcIlwiLFxyXG4gICAgICAgICAgZW5kRGF0ZTogXCJcIixcclxuICAgICAgICAgIGluY2VudGl2ZUFtb3VudDogMCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBhd2FpdCBmZXRjaEFsbENvbW1pc3Npb25SZXBvcnQoKTtcclxuICAgICAgICBhd2FpdCBmZXRjaEFsbEdyb3NzSW5jZW50aXZlUmVwb3J0KCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc3QgZW1wID0gZW1wbG95ZWVzLmZpbmQoKGUpID0+IGUuX2lkID09PSBzZWxlY3RlZEVtcGxveWVlSWQpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKGVtcCB8fCBudWxsKTtcclxuICAgICAgICBhd2FpdCBmZXRjaENvbW1pc3Npb25SZXBvcnQoc2VsZWN0ZWRFbXBsb3llZUlkLCBzdGFydERhdGUsIGVuZERhdGUpO1xyXG4gICAgICAgIGF3YWl0IGZldGNoVGFyZ2V0RGF0YShzZWxlY3RlZEVtcGxveWVlSWQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XHJcbiAgICAgICAgYXdhaXQgZmV0Y2hHcm9zc0luY2VudGl2ZVJlcG9ydChzZWxlY3RlZEVtcGxveWVlSWQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XHJcbiAgICAgIH1cclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldEFnZW50TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29tbWlzc2lvbkNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IHZhbHVlIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGlmICghY29tbWlzc2lvbkZvcm0uYWdlbnRfaWQpXHJcbiAgICAgIG5ld0Vycm9ycy5hZ2VudF9pZCA9IFwiUGxlYXNlIHNlbGVjdCBhbiBhZ2VudFwiO1xyXG4gICAgaWYgKCFjb21taXNzaW9uRm9ybS5hbW91bnQgfHwgaXNOYU4oY29tbWlzc2lvbkZvcm0uYW1vdW50KSlcclxuICAgICAgbmV3RXJyb3JzLmFtb3VudCA9IFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgYW1vdW50XCI7XHJcbiAgICBpZiAoXHJcbiAgICAgIGNvbW1pc3Npb25Gb3JtLnBheV90eXBlID09PSBcIm9ubGluZVwiICYmXHJcbiAgICAgICFjb21taXNzaW9uRm9ybS50cmFuc2FjdGlvbl9pZFxyXG4gICAgKVxyXG4gICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPSBcIlRyYW5zYWN0aW9uIElEIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb21taXNzaW9uU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGVGb3JtKCkpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7IC4uLmNvbW1pc3Npb25Gb3JtLCBhZG1pbl90eXBlOiBhZG1pbklkIH07XHJcbiAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL3BheW1lbnQtb3V0L2FkZC1jb21taXNzaW9uLXBheW1lbnRcIiwgcGF5bG9hZCk7XHJcbiAgICAgIGFsZXJ0KFwiQ29tbWlzc2lvbiBQYWlkIFN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICAgIHNldFNob3dDb21taXNzaW9uTW9kYWwoZmFsc2UpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGFsZXJ0KFwiRmFpbGVkIHRvIGFkZCBwYXltZW50LlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBwcm9jZXNzZWRUYWJsZURhdGEgPSBlbXBsb3llZUN1c3RvbWVyRGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgLi4uaXRlbSxcclxuICAgIGdyb3VwX3ZhbHVlX2RpZ2l0czogaXRlbS5ncm91cF9pZD8uZ3JvdXBfdmFsdWUsXHJcbiAgICBncm91cF90aWNrZXQ6IGl0ZW0udGlja2V0IHx8IFwiTi9BXCIsXHJcbiAgICBlc3RpbWF0ZWRfY29tbWlzc2lvbl9kaWdpdHM6IGl0ZW0/LmVzdGltYXRlZF9jb21taXNzaW9uIHx8IDAsXHJcbiAgICBuZXRfaW5jZW50aXZlX2RpZ2l0czogaXRlbT8uaW5jZW50aXZlX3ZhbHVlIHx8IDAsXHJcbiAgICBpbmNlbnRpdmVfcGVyY2VudGFnZTogaXRlbT8uZ3JvdXBfaWQ/LmluY2VudGl2ZXMgfHwgMCxcclxuICAgIHRvdGFsX3BhaWRfZGlnaXRzOiBpdGVtPy50b3RhbF9wYWlkX2Ftb3VudCB8fCAwLFxyXG4gICAgcmVxdWlyZWRfaW5zdGFsbG1lbnRfZGlnaXRzOiBpdGVtPy5ncm91cF9pZD8ubW9udGhseV9pbnN0YWxsbWVudCB8fCAwLFxyXG4gICAgaW5jZW50aXZlX3JlbGVhc2VkOiBpdGVtLmluY2VudGl2ZV9yZWxlYXNlZCA/IFwiWWVzXCIgOiBcIk5vXCIsXHJcbiAgICB1c2VyX25hbWU6IGl0ZW0udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICBwaG9uZV9udW1iZXI6IGl0ZW0udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICBncm91cF9uYW1lOiBpdGVtLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICBlbnJvbGxtZW50X2RhdGU6IGl0ZW0uY3JlYXRlZEF0Py5zcGxpdChcIlRcIik/LlswXSB8fCBcIk4vQVwiLFxyXG4gIH0pKTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInVzZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX3RpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0IE5vXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX3ZhbHVlX2RpZ2l0c1wiLCBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW5yb2xsbWVudF9kYXRlXCIsIGhlYWRlcjogXCJFbnJvbGxtZW50IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiaW5jZW50aXZlX3BlcmNlbnRhZ2VcIiwgaGVhZGVyOiBcIk5ldCBJbmNlbnRpdmUgUGVyY2VudGFnZVwiIH0sXHJcbiAgICB7IGtleTogXCJuZXRfaW5jZW50aXZlX2RpZ2l0c1wiLCBoZWFkZXI6IFwiTmV0ICBJbmNlbnRpdmVcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxfcGFpZF9kaWdpdHNcIiwgaGVhZGVyOiBcIlRvdGFsIFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVxdWlyZWRfaW5zdGFsbG1lbnRfZGlnaXRzXCIsIGhlYWRlcjogXCJGaXJzdCBJbnN0YWxsbWVudCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiaW5jZW50aXZlX3JlbGVhc2VkXCIsIGhlYWRlcjogXCJJbmNlbnRpdmUgUmVsZWFzZWRcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGdyb3NzSW5jZW50aXZlQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInVzZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX3ZhbHVlXCIsIGhlYWRlcjogXCJHcm91cCBWYWx1ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF90aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJlbnJvbGxtZW50X2RhdGVcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9tb250aGx5X2luc3RhbGxtZW50XCIsIGhlYWRlcjogXCJGaXJzdCBJbnN0YWxsbWVudCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfaW5jZW50aXZlXCIsIGhlYWRlcjogXCJJbmNlbnRpdmUgUGVyY2VudGFnZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbF9wYWlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgUGFpZFwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IGN1cnJlbnRNb250aCA9IGAke3RvZGF5LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKFxyXG4gICAgdG9kYXkuZ2V0TW9udGgoKSArIDFcclxuICApLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLWgtc2NyZWVuIGJnLWdyYXktNTBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC04XCI+XHJcbiAgICAgICAgICB7LyogSGVhZGVyIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgSW5jZW50aXZlIFJlcG9ydHNcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgVHJhY2sgYW5kIG1hbmFnZSBlbXBsb3llZSBpbmNlbnRpdmVzIGFuZCBjb21taXNzaW9uc1xyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRmlsdGVyIENhcmQgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC04IG1iLThcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTZcIj5cclxuICAgICAgICAgICAgICBSZXBvcnQgRmlsdGVyc1xyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTYgbWItNlwiPlxyXG4gICAgICAgICAgICAgIHsvKiBFbXBsb3llZSBTZWxlY3QgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgRW1wbG95ZWVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRW1wbG95ZWVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgbmFtZSBvciBwaG9uZVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogXCI0NHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX0gLSB7ZW1wLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBEYXRlIFNlbGVjdGlvbiBNb2RlICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgRGF0ZSBTZWxlY3Rpb25cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHAtMyBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgaC0xMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8UmFkaW8uR3JvdXBcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGF0ZVNlbGVjdGlvbk1vZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREYXRlU2VsZWN0aW9uTW9kZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8UmFkaW8gdmFsdWU9XCJtb250aFwiIGNsYXNzTmFtZT1cInRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE1vbnRoXHJcbiAgICAgICAgICAgICAgICAgICAgPC9SYWRpbz5cclxuICAgICAgICAgICAgICAgICAgICA8UmFkaW8gdmFsdWU9XCJkYXRlLXJhbmdlXCIgY2xhc3NOYW1lPVwidGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUmFuZ2VcclxuICAgICAgICAgICAgICAgICAgICA8L1JhZGlvPlxyXG4gICAgICAgICAgICAgICAgICA8L1JhZGlvLkdyb3VwPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBEYXRlIFBpY2tlciBGaWVsZHMgKi99XHJcbiAgICAgICAgICAgICAge2RhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgTW9udGhcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFNlbGVjdGVkTW9udGggfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICBtYXg9e2N1cnJlbnRNb250aH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGVtcE1vbnRoQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDAgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZyb20gRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcEZyb21EYXRlIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBtYXg9e3RlbXBUb0RhdGUgfHwgY3VycmVudE1vbnRofVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUZW1wRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMiBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFRvIERhdGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBUb0RhdGUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIG1pbj17dGVtcEZyb21EYXRlIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBtYXg9e2N1cnJlbnRNb250aH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcFRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRmlsdGVyIEJ1dHRvbiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17YXBwbHlGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC04IHB5LTIuNSBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyBmb250LXNlbWlib2xkIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ29udGludWVcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7YWdlbnRMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktMjBcIj5cclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgey8qIFF1aWNrIExpbmtzICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgdG89XCIvdGFyZ2V0LW1lbnUvdGFyZ2V0XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGhvdmVyOmJvcmRlci12aW9sZXQtNTAwIGhvdmVyOmJnLXZpb2xldC01MCB0cmFuc2l0aW9uLWFsbCBncm91cFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8RmlUYXJnZXRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MjR9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGdyb3VwLWhvdmVyOnRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2V0IFRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIHRvPVwiL3JlcG9ydHMvdGFyZ2V0LWNvbW1pc3Npb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtNCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6YmctdmlvbGV0LTUwIHRyYW5zaXRpb24tYWxsIGdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEb2xsYXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgZ3JvdXAtaG92ZXI6c2NhbGUtMTEwIHRyYW5zaXRpb24tdHJhbnNmb3JtIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZ3JvdXAtaG92ZXI6dGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBJbmNlbnRpdmUgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgdG89XCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L3NhbGFyeS1wYXltZW50XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGhvdmVyOmJvcmRlci12aW9sZXQtNTAwIGhvdmVyOmJnLXZpb2xldC01MCB0cmFuc2l0aW9uLWFsbCBncm91cFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8RmFNb25leUJpbGxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MjR9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGdyb3VwLWhvdmVyOnRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2FsYXJ5IFBheW91dFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBFbXBsb3llZSBEZXRhaWxzICovfVxyXG4gICAgICAgICAgICAgIHtpc0ZpbHRlcmluZyAmJlxyXG4gICAgICAgICAgICAgICAgKChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiICYmIHNlbGVjdGVkTW9udGgpIHx8XHJcbiAgICAgICAgICAgICAgICAgIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJkYXRlLXJhbmdlXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICBmcm9tRGF0ZSAmJlxyXG4gICAgICAgICAgICAgICAgICAgIHRvRGF0ZSkpICYmXHJcbiAgICAgICAgICAgICAgICAoc2VsZWN0ZWRFbXBsb3llZUlkID09PSBcIkFMTFwiIHx8IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlSWQgIT09IFwiQUxMXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRW1wbG95ZWUgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSb3cgMSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LmVtYWlsIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaG9uZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUm93IDIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGhhYXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LmFkaGFhcl9ubyB8fCBcIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgYmctZ3JheS01MCB0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUEFOXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ucGFuX25vIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaW5jb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ucGluY29kZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgYmctZ3JheS01MCB0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJvdyAzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LmFkZHJlc3MgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGJnLWdyYXktNTAgdGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBtdC0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEpvaW5pbmcgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8uam9pbmluZ19kYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gc2VsZWN0ZWRFbXBsb3llZURldGFpbHMuam9pbmluZ19kYXRlLnNwbGl0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCItXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGJnLWdyYXktNTAgdGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBtdC0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxociBjbGFzc05hbWU9XCJteS02XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogU3VtbWFyeSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDb21taXNzaW9uIFN1bW1hcnlcclxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwIHRvLWdyZWVuLTEwMCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTmV0IEJ1c2luZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uVG90YWxEZXRhaWxzPy5hY3R1YWxfYnVzaW5lc3MgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwIG10LTIgYm9yZGVyLTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUFtb3VudChjb21taXNzaW9uVG90YWxEZXRhaWxzPy5hY3R1YWxfYnVzaW5lc3MpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHRvLXZpb2xldC0xMDAgYm9yZGVyIGJvcmRlci12aW9sZXQtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOZXQgSW5jZW50aXZlICgxJSBlYWNoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvblRvdGFsRGV0YWlscz8udG90YWxfYWN0dWFsIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC03MDAgbXQtMiBib3JkZXItMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtdmlvbGV0LTcwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUFtb3VudChjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9hY3R1YWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwIHRvLXB1cnBsZS0xMDAgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOZXQgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9jdXN0b21lcnMgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMCBtdC0yIGJvcmRlci0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBUYWJiZWQgVmlldyBmb3IgUmVwb3J0cyAqL31cclxuICAgICAgICAgICAgICA8VGFicyBhY3RpdmVLZXk9e2FjdGl2ZVRhYn0gb25DaGFuZ2U9e3NldEFjdGl2ZVRhYn0+XHJcbiAgICAgICAgICAgICAgICB7LyogQ29tbWlzc2lvbiBSZXBvcnQgVGFiICovfVxyXG4gICAgICAgICAgICAgICAgPFRhYlBhbmUgdGFiPVwiTmV0IEluY2VudGl2ZSBSZXBvcnRcIiBrZXk9XCJjb21taXNzaW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBUYXJnZXQgRGV0YWlscyAqL31cclxuICAgICAgICAgICAgICAgICAge2lzRmlsdGVyaW5nICYmXHJcbiAgICAgICAgICAgICAgICAgICAgKChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiICYmIHNlbGVjdGVkTW9udGgpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwiZGF0ZS1yYW5nZVwiICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyb21EYXRlICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvRGF0ZSkpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZUlkICYmXHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZUlkICE9PSBcIkFMTFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYXJnZXQgUGVyZm9ybWFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLmFjaGlldmVkID49IHRhcmdldERhdGEudGFyZ2V0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIHJvdW5kZWQtbGcgYmctZ3JlZW4tMTAwIGJvcmRlciBib3JkZXItZ3JlZW4tMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxHaVBhcnR5UG9wcGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MjR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTcwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFyZ2V0IEFjaGlldmVkIXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNCBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MCB0by12aW9sZXQtMTAwIGJvcmRlciBib3JkZXItdmlvbGV0LTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYXJnZXQgU2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHt0YXJnZXREYXRhLnRhcmdldD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC12aW9sZXQtNzAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModGFyZ2V0RGF0YS50YXJnZXQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwIHRvLWdyZWVuLTEwMCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBY2hpZXZlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHt0YXJnZXREYXRhLmFjaGlldmVkPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHRhcmdldERhdGEuYWNoaWV2ZWQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWFtYmVyLTUwIHRvLWFtYmVyLTEwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEaWZmZXJlbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtYW1iZXItNzAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2AkeyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhPy5kaWZmZXJlbmNlID8/IFwiMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtYW1iZXItNzAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWF0aC5hYnModGFyZ2V0RGF0YT8uZGlmZmVyZW5jZSB8fCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1lbWVyYWxkLTUwIHRvLWVtZXJhbGQtMTAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgUGF5YWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake3RhcmdldERhdGEuaW5jZW50aXZlQW1vdW50LnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWVtZXJhbGQtNzAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0RGF0YS5pbmNlbnRpdmVBbW91bnQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtNTAgYm9yZGVyIGJvcmRlci12aW9sZXQtMjAwIHJvdW5kZWQtbGcgcC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtdmlvbGV0LTgwMCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbmNlbnRpdmUgQnJlYWtkb3duXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiBiZy12aW9sZXQtNjAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVXAgdG8gdGFyZ2V0ICgwJSk6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj4wLjAwPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtdmlvbGV0LTcwMCBtbC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHtudW1iZXJUb0luZGlhbldvcmRzKDApfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLmFjaGlldmVkID4gdGFyZ2V0RGF0YS50YXJnZXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiBiZy1ncmVlbi02MDAgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmV5b25kIHRhcmdldCAoMSUpOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAodGFyZ2V0RGF0YS5hY2hpZXZlZCAtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhLnRhcmdldCkgKlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDAuMDFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1ncmVlbi03MDAgbWwtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICh0YXJnZXREYXRhLmFjaGlldmVkIC0gdGFyZ2V0RGF0YS50YXJnZXQpICpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAwLjAxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIERhdGEgVGFibGUgKi99XHJcbiAgICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0yMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6IGVtcGxveWVlQ3VzdG9tZXJEYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtwcm9jZXNzZWRUYWJsZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT17YEluY2VudGl2ZSBSZXBvcnRgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIk5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBob25lIE51bWJlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiTW9udGhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRhcmdldCBTZXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIkFjaGlldmVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJSZW1haW5pbmdcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIFBheWFibGUgQ29tbWlzc2lvblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiQWN0dWFsIEJ1c2luZXNzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJBY3R1YWwgQ29tbWlzc2lvblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiR3Jvc3MgQnVzaW5lc3NcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIkdyb3NzIENvbW1pc3Npb25cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIEN1c3RvbWVyc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgR3JvdXBzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZUlkID09PSBcIkFMTFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiQWxsIEVtcGxveWVlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVJZCA9PT0gXCJBTExcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiICYmIHNlbGVjdGVkTW9udGgpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcImRhdGUtcmFuZ2VcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZnJvbURhdGUgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvRGF0ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGAke3NlbGVjdGVkTW9udGh9LTAxYCkudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImRlZmF1bHRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGg6IFwibG9uZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYCR7bmV3IERhdGUoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmcm9tRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9IC0gJHtuZXcgRGF0ZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldERhdGE/LnRhcmdldD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCBcIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gKCR7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh0YXJnZXREYXRhPy50YXJnZXQgfHwgMCl9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYOKCuSR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhPy5hY2hpZXZlZD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCBcIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gKCR7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh0YXJnZXREYXRhPy5hY2hpZXZlZCB8fCAwKX0pYCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldERhdGE/LnJlbWFpbmluZz8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhPy5yZW1haW5pbmcgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYOKCuSR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhPy5pbmNlbnRpdmVBbW91bnQ/LnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiMC4wMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSAoJHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0RGF0YT8uaW5jZW50aXZlQW1vdW50IHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfSlgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGDigrkke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tbWlzc2lvblRvdGFsRGV0YWlscz8uYWN0dWFsX2J1c2luZXNzPy50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSAoJHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VBbW91bnQoY29tbWlzc2lvblRvdGFsRGV0YWlscz8uYWN0dWFsX2J1c2luZXNzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYOKCuSR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9hY3R1YWw/LnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUFtb3VudChjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9hY3R1YWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX0pYCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LmV4cGVjdGVkX2J1c2luZXNzPy50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSAoJHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VBbW91bnQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LmV4cGVjdGVkX2J1c2luZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX0pYCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2VzdGltYXRlZD8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB8fCBcIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gKCR7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlQW1vdW50KGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2VzdGltYXRlZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfSlgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2N1c3RvbWVycyB8fCBcIjBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9ncm91cHMgfHwgXCIwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BJbmNlbnRpdmVSZXBvcnQtJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSB8fCBcImFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0tJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHNlbGVjdGVkTW9udGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYCR7ZnJvbURhdGV9X3RvXyR7dG9EYXRlfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgfS5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICBpc0ZpbHRlcmluZyAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgKChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiICYmIHNlbGVjdGVkTW9udGgpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJkYXRlLXJhbmdlXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmcm9tRGF0ZSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvRGF0ZSkpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTEyIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LWxnIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBpbmNlbnRpdmUgZGF0YSBmb3VuZCBmb3IgdGhlIHNlbGVjdGVkIHBlcmlvZC5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9UYWJQYW5lPlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBHcm9zcyBJbmNlbnRpdmUgUmVwb3J0IFRhYiAqL31cclxuICAgICAgICAgICAgICAgIDxUYWJQYW5lIHRhYj1cIkdyb3NzIEluY2VudGl2ZSBSZXBvcnRcIiBrZXk9XCJncm9zcy1pbmNlbnRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgey8qIEdyb3NzIEluY2VudGl2ZSBTdW1tYXJ5IFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgIHtpc0ZpbHRlcmluZyAmJlxyXG4gICAgICAgICAgICAgICAgICAgICgoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIiAmJiBzZWxlY3RlZE1vbnRoKSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcImRhdGUtcmFuZ2VcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcm9tRGF0ZSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b0RhdGUpKSAmJlxyXG4gICAgICAgICAgICAgICAgICAgIChzZWxlY3RlZEVtcGxveWVlSWQgPT09IFwiQUxMXCIgfHxcclxuICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC02IG1iLThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBHcm9zcyBJbmNlbnRpdmUgU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNTAgdG8tZ3JlZW4tMTAwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3NzIEdyb3VwIFZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm9zc0luY2VudGl2ZVN1bW1hcnkudG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWU/LnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB8fCBcIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy10cmFuc3BhcmVudCB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmVlbi03MDAgbXQtMiBib3JkZXItMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1ncmVlbi03MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm9zc0luY2VudGl2ZVN1bW1hcnkudG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHRvLXZpb2xldC0xMDAgYm9yZGVyIGJvcmRlci12aW9sZXQtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3NzIEluY2VudGl2ZSBWYWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3Jvc3NJbmNlbnRpdmVTdW1tYXJ5LnRvdGFsX2dyb3NzX2luY2VudGl2ZV92YWx1ZT8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC03MDAgbXQtMiBib3JkZXItMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC12aW9sZXQtNzAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3Jvc3NJbmNlbnRpdmVTdW1tYXJ5LnRvdGFsX2dyb3NzX2luY2VudGl2ZV92YWx1ZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1wdXJwbGUtNTAgdG8tcHVycGxlLTEwMCBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR3Jvc3MgRW5yb2xsbWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3NzSW5jZW50aXZlU3VtbWFyeS50b3RhbF9ncm9zc19lbnJvbGxtZW50cyB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS03MDAgbXQtMiBib3JkZXItMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogRGF0YSBUYWJsZSAqL31cclxuICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB5LTIwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogZ3Jvc3NJbmNlbnRpdmVEYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtncm9zc0luY2VudGl2ZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2dyb3NzSW5jZW50aXZlQ29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgR3Jvc3MgSW5jZW50aXZlIFJlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJQZXJpb2RcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIEdyb3VwIFZhbHVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUb3RhbCBJbmNlbnRpdmUgVmFsdWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIEVucm9sbG1lbnRzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZUlkID09PSBcIkFMTFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiQWxsIEVtcGxveWVlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVJZCA9PT0gXCJBTExcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiICYmIHNlbGVjdGVkTW9udGgpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcImRhdGUtcmFuZ2VcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZnJvbURhdGUgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvRGF0ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGAke3NlbGVjdGVkTW9udGh9LTAxYCkudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImRlZmF1bHRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGg6IFwibG9uZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYCR7bmV3IERhdGUoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmcm9tRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9IC0gJHtuZXcgRGF0ZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3NzSW5jZW50aXZlU3VtbWFyeS50b3RhbF9ncm9zc19ncm91cF92YWx1ZT8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB8fCBcIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gKCR7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3NzSW5jZW50aXZlU3VtbWFyeS50b3RhbF9ncm9zc19ncm91cF92YWx1ZSB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX0pYCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3NzSW5jZW50aXZlU3VtbWFyeS50b3RhbF9ncm9zc19pbmNlbnRpdmVfdmFsdWU/LnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm9zc0luY2VudGl2ZVN1bW1hcnkudG90YWxfZ3Jvc3NfaW5jZW50aXZlX3ZhbHVlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfSlgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGAke2dyb3NzSW5jZW50aXZlU3VtbWFyeS50b3RhbF9ncm9zc19lbnJvbGxtZW50cyB8fCBcIjBcIn1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgR3Jvc3NJbmNlbnRpdmVSZXBvcnQtJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSB8fCBcImFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0tJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHNlbGVjdGVkTW9udGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYCR7ZnJvbURhdGV9X3RvXyR7dG9EYXRlfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgfS5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICBpc0ZpbHRlcmluZyAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgKChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiICYmIHNlbGVjdGVkTW9udGgpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJkYXRlLXJhbmdlXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmcm9tRGF0ZSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvRGF0ZSkpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTEyIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LWxnIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBncm9zcyBpbmNlbnRpdmUgZGF0YSBmb3VuZCBmb3IgdGhlIHNlbGVjdGVkIHBlcmlvZC5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9UYWJQYW5lPlxyXG4gICAgICAgICAgICAgIDwvVGFicz5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUYXJnZXRJbmNlbnRpdmU7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1RhcmdldEluY2VudGl2ZS5qc3gifQ==