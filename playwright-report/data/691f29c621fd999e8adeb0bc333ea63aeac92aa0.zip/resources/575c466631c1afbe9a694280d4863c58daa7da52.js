import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PayoutReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Modal as AntModal, Drawer, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { FaReceipt } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
const PayOutReport = () => {
  _s();
  const { paymentType } = useParams();
  const [groups, setGroups] = useState([]);
  const [actualGroups, setActualGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [TablePayments, setTablePayments] = useState([]);
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [userName, setUserName] = useState("");
  const [viewLoader, setViewLoader] = useState(false);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentUpdateAmount, setCurrentUpdateAmount] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [showModalView, setShowModalView] = useState(false);
  const [currentViewGroup, setCurrentViewGroup] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [receiptNo, setReceiptNo] = useState("");
  const whatsappEnable = true;
  const [paymentMode, setPaymentMode] = useState("cash");
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [enableGroupColumn, setEnableGroupColumn] = useState(true);
  const [paymentGroupTickets, setPaymentGroupTickets] = useState([]);
  const [render, setRerender] = useState(0);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [currentGroupId, setCurrentGroupId] = useState(null);
  const [openAntDDrawer, setOpenAntDDrawer] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [lastThreePayments, setLastThreePayments] = useState([]);
  const [adminName, setAdminName] = useState("");
  const [showOthersField, setShowOthersField] = useState(false);
  const [disbursementType, setDisbursementType] = useState("");
  const disbursementTypes = [
    {
      key: "#1",
      title: "Chit Cancellation",
      value: "Chit Cancellation"
    },
    {
      key: "#2",
      title: "Refund to Member",
      value: "Refund to Member"
    },
    {
      key: "#3",
      title: "Foreman Commission Disbursement",
      value: "Refund to Member"
    },
    {
      key: "#4",
      title: "Reinvestment Transfer",
      value: "Reinvestment Transfer"
    },
    {
      key: "#5",
      title: "Advance Payout Before Auction",
      value: "Advance Payout Before Auction"
    },
    {
      key: "#6",
      title: "Divident Share Disbursement",
      value: "Divident Share Disbursement"
    },
    {
      key: "#7",
      title: "Group Closure Settlement",
      value: "Group Closure Settlement"
    },
    {
      key: "#8",
      title: "Emergency Withdrawal",
      value: "Emergency Withdrawal"
    },
    {
      key: "#9",
      title: "Mistaken Payment Reversal",
      value: "Mistaken Payment Reversal"
    },
    {
      key: "#10",
      title: "Others",
      value: "Others"
    }
  ];
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    user_id: "",
    pay_date: today,
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    payment_group_tickets: [],
    disbursement_type: "",
    note: ""
  });
  const [updateFormData, setUpdateFormData] = useState({
    amount: "",
    pay_date: ""
  });
  const [modifyPayment, setModifyPayment] = useState(false);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    setAdminName(userObj?.name || "");
    if (userObj && userObj?.admin_access_right_id?.access_permissions?.edit_payment) {
      const isModify = userObj?.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setModifyPayment(isModify);
    }
  }, []);
  useEffect(() => {
    const usr = localStorage.getItem("user");
    let admin_type = null;
    try {
      if (usr) {
        admin_type = JSON.parse(usr);
      }
    } catch (e) {
      console.error("Failed to parse user from localStorage:", e);
    }
    const fetchAllPaymentsReport = async (groupId = null) => {
      try {
        setTablePayments([]);
        setIsLoading(true);
        if (groupId) {
          let url = `/payment-out/get-group-payment-out/?group_id=${groupId}`;
          if (paymentType) {
            url += `&pay_for=${paymentType}`;
          }
          setEnableGroupColumn(false);
          const response = await api.get(url);
          if (response.data && response.data.length > 0) {
            const formattedData = response.data.map((group, index) => {
              if (!group?.group_id?.group_name) return {};
              return {
                _id: group._id,
                id: index + 1,
                name: group?.user_id?.full_name || "-",
                phone_number: group?.user_id?.phone_number || "-",
                group_name: group?.group_id?.group_name || "-",
                ticket: group.ticket || "-",
                receipt: group.receipt_no || "-",
                old_receipt: group.old_receipt_no || "-",
                amount: group.amount || 0,
                date: group?.pay_date ? group.pay_date.split("T")[0] : "-",
                transaction_date: group?.createdAt ? group.createdAt.split("T")[0] : "-",
                disbursed_by: group?.admin_type?.admin_name || "Super Admin",
                disbursement_type: group?.disbursement_type || "-",
                note: group.note || "-"
              };
            });
            setTablePayments(formattedData);
          } else {
            setFilteredAuction([]);
          }
        } else {
          const response = await api.get(
            "/payment-out/get-all-payment-out-report",
            {
              params: {
                pay_for: paymentType
              }
            }
          );
          if (response.data?.success) {
            const { data, summary } = response.data;
            const mergedPayments = [
              ...data.allPayments,
              ...data.commissionPayments,
              ...data.salaryPayments,
              ...data.pettyCashPayments
              // ...data.auctionWinningPayments,
            ];
            const formattedData = mergedPayments.map((group, index) => ({
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name || "-",
              phone_number: group?.user_id?.phone_number || "-",
              group_name: group?.group_id?.group_name || "-",
              ticket: group.ticket || "-",
              receipt: group.receipt_no || "-",
              old_receipt: group.old_receipt_no || "-",
              amount: group.amount || 0,
              date: formatPayDate(group.pay_date),
              transaction_date: formatPayDate(group.createdAt),
              disbursed_by: group?.admin_type?.full_name || "Super Admin",
              disbursement_type: group.disbursement_type || "-",
              note: group.note || "-"
            }));
            setTablePayments(formattedData);
            console.log("Summary:", summary);
          } else {
            setFilteredAuction([]);
          }
        }
      } catch (error) {
        console.error("Error fetching payment report:", error);
        setFilteredAuction([]);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAllPaymentsReport();
  }, [render]);
  const fetchLastThreeTransactions = async (event) => {
    event.preventDefault();
    setOpenAntDDrawer(true);
    if (formData.user_id && formData.payment_group_tickets) {
      try {
        setShowLoader(true);
        const response = await api.get("payment-out/get-last-n-transaction", {
          params: {
            user_id: formData.user_id,
            payment_group_tickets: paymentGroupTickets,
            limit: 3,
            pay_for: paymentType
          }
        });
        if (response?.data) {
          setLastThreePayments(response.data);
        } else {
          setLastThreePayments([]);
        }
      } catch (error) {
        setLastThreePayments([]);
      } finally {
        setShowLoader(false);
      }
    }
  };
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [alertConfig]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-all-group-admin");
        setActualGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [alertConfig]);
  const validateForm = () => {
    const newErrors = {};
    if (!selectedGroupId) {
      newErrors.customer = "Please select a customer";
    }
    if (!formData.payment_group_tickets) {
      newErrors.payment_group_tickets = "Please select a group and ticket";
    }
    if (!formData.pay_date) {
      newErrors.pay_date = "Payment date is required";
    }
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    }
    if (paymentMode === "online" && !formData.transaction_id?.trim()) {
      newErrors.transaction_id = "Transaction ID is required for online payments";
    }
    if (!formData.disbursement_type) {
      newErrors.disbursement_type = "Disbursement Type is Required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "disbursement_type") {
      if (value === "Others") {
        setShowOthersField(true);
        setDisbursementType("");
      } else {
        setShowOthersField(false);
      }
    }
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({ ...prevData, [name]: "" }));
  };
  const handlePaymentAntSelect = (values) => {
    setPaymentGroupTickets(values);
  };
  const handleGroupChange = async (groupId) => {
    setSelectedGroup(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/enroll/get-group-enroll/${groupId}`);
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
        } else {
          setFilteredUsers([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
      }
    } else {
      setFilteredUsers([]);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" }
  ];
  if (enableGroupColumn) {
    columns.push({ key: "group_name", header: "Group Name" });
  }
  columns.push(
    { key: "ticket", header: "Ticket Number" },
    { key: "old_receipt", header: "Old Receipt" },
    { key: "receipt", header: "Receipt" },
    { key: "amount", header: "Amount" },
    { key: "disbursed_by", header: "Disbursed By" },
    { key: "disbursement_type", header: "Disbursement Type" },
    { key: "note", header: "Note" },
    { key: "action", header: "Action" }
  );
  const handleCustomer = async (groupId) => {
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      user_id: groupId
    }));
    setErrors((prevData) => ({ ...prevData, customer: "" }));
    setPaymentGroupTickets([]);
    handleGroupChange(groupId);
    handleGroupAuctionChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
    handleGroupPaymentChange(groupId);
  };
  const formatPayDate = (dateString) => {
    return dateString?.split("T")[0];
  };
  const handleGroupPaymentChange = async (groupId) => {
    console.log(groupId, "this is groupId");
    setSelectedAuctionGroup(groupId);
    if (groupId) {
      let url;
      if (groupId === "today") {
        url = `/payment-out/get-payment-out-report-daybook/?pay_date=${today}&pay_for=${paymentType}`;
        setEnableGroupColumn(true);
      } else {
        url = `/payment-out/get-group-payment-out/?group_id=${groupId}`;
        if (paymentType) {
          url += `&pay_for=${paymentType}`;
        }
        setEnableGroupColumn(false);
      }
      try {
        setTablePayments([]);
        setIsLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id?.group_name) return {};
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              ticket: group.ticket,
              receipt: group.receipt_no,
              old_receipt: group.old_receipt_no,
              amount: group.amount,
              date: group?.pay_date.split("T")[0],
              transaction_date: group?.createdAt?.split("T")[0],
              disbursed_by: group?.admin_type?.admin_name || "Super Admin",
              disbursement_type: group?.disbursement_type,
              note: group.note
            };
          });
          setTablePayments(formattedData);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching payment data:", error);
        setFilteredAuction([]);
      } finally {
        setIsLoading(false);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" ? prevData.transaction_id : ""
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        setDisabled(true);
        setAlertConfig((prev) => ({
          ...prev,
          visibility: false
        }));
        setShowModal(false);
        let payload;
        const usr = localStorage.getItem("user");
        let admin_type = null;
        try {
          if (usr) {
            admin_type = JSON.parse(usr);
          }
        } catch (e2) {
          console.error("Failed to parse user from localStorage:", e2);
        }
        if (formData.disbursement_type === "Others") {
          formData.disbursement_type = disbursementType;
        }
        formData.payment_group_tickets = paymentGroupTickets;
        formData.admin_type = admin_type?._id;
        formData.pay_for = paymentType;
        setOpenBackdropLoader(true);
        console.log(formData, "formData this is formData");
        const response = await api.post(
          "/payment-out/add-payments-out",
          formData
        );
        if (response.status === 201) {
          setSelectedGroupId("");
          setPaymentGroupTickets([]);
          setDisabled(false);
          setFormData({
            user_id: "",
            pay_date: today,
            amount: "",
            pay_type: "cash",
            transaction_id: "",
            payment_group_tickets: [],
            disbursement_type: "",
            note: ""
          });
          setAlertConfig({
            visibility: true,
            noReload: true,
            message: "Payment Added Successfully",
            type: "success"
          });
        }
        if (response.status >= 400) {
          setShowModal(false);
          setSelectedGroupId("");
          setPaymentGroupTickets([]);
          setDisabled(false);
          setFormData({
            user_id: "",
            pay_date: today,
            amount: "",
            pay_type: "cash",
            transaction_id: "",
            payment_group_tickets: [],
            disbursement_type: "",
            note: ""
          });
          setAlertConfig({
            visibility: true,
            noReload: true,
            message: "Payment Added Failed",
            type: "error"
          });
        }
      }
    } catch (error) {
      setShowModal(false);
      setSelectedGroupId("");
      setFormData({
        user_id: "",
        pay_date: "",
        amount: "",
        pay_type: "cash",
        transaction_id: "",
        payment_group_tickets: [],
        disbursement_type: "",
        note: ""
      });
      setAlertConfig({
        visibility: true,
        noReload: true,
        message: `Error submitting payment data`,
        type: "error"
      });
      setDisabled(false);
      console.error("Error submitting payment data:", error);
    } finally {
      setOpenBackdropLoader(false);
      setRerender((prev) => prev + 1);
    }
  };
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/payment/get-payment-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleDeleteAuction = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/payment/delete-payment/${currentGroup._id}`);
        setShowModalDelete(false);
        setCurrentGroup(null);
        setAlertConfig({
          visibility: true,
          message: "Payment deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting auction:", error);
      }
    }
  };
  const handleViewModalOpen = async (groupId) => {
    try {
      setLoading(true);
      setShowModalView(true);
      setCurrentGroupId(groupId);
      setViewLoader(true);
      const response = await api.get(`/payment/get-payment-by-id/${groupId}`);
      setCurrentViewGroup(response.data);
    } catch (error) {
      console.error("Error viewing Payment:", error);
    } finally {
      setLoading(false);
      setViewLoader(false);
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/payment/get-payment-by-id/${groupId}`);
      setCurrentUpdateAmount(response.data);
      setUpdateFormData({
        amount: response?.data?.amount,
        pay_date: response?.data?.pay_date.split("T")[0]
      });
      setShowUpdateModal(true);
    } catch (error) {
      console.error("Error fetching Payment Amount data:", error);
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await api.put(
        `/payment/update-payment-amount/${currentUpdateAmount._id}`,
        updateFormData
      );
      setShowUpdateModal(false);
      setAlertConfig({
        visibility: true,
        message: "Payment Amount Updated Successfully",
        type: "success"
      });
    } catch (error) {
      console.error("Error updating Payment Amount:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error?.response?.data?.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const handleDisbursementTypeChange = (event) => {
    const { name, value } = event.target;
    setDisbursementType(value);
  };
  const handleGroupAuctionChange = async (groupId) => {
    if (groupId) {
      try {
        const response = await api.post(
          `/enroll/get-user-tickets-report/${groupId}`
        );
        if (response.data && response.data.length > 0) {
          const validAuctions = response.data.filter(
            (auction) => auction.enrollment && auction.enrollment.group
          );
          setFilteredAuction(validAuctions);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredAuction([]);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const selectednewGroup = actualGroups.find(
    (g) => g._id === selectedAuctionGroupId
  );
  return /* @__PURE__ */ jsxDEV(Fragment, { children: openBackdropLoader ? /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "payment Data processing...." }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
    lineNumber: 875,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
        lineNumber: 879,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        noReload: alertConfig.noReload
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
        lineNumber: 884,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-2xl text-red-500 font-bold", children: paymentType?.toUpperCase() }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
          lineNumber: 892,
          columnNumber: 17
        }, this),
        "  ",
        "Payments Out Report"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
        lineNumber: 891,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6  mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "font-bold", children: "Search or Select Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
            lineNumber: 900,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "Today's Payment",
              popupMatchSelectWidth: false,
              showSearch: true,
              className: "w-full  h-14 max-w-md",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              value: selectedAuctionGroupId || void 0,
              onChange: handleGroupPayment,
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "today", children: "Payments" }, "#1", false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 916,
                  columnNumber: 23
                }, this),
                actualGroups.map(
                  (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                    lineNumber: 920,
                    columnNumber: 21
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 902,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
            lineNumber: 901,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
          lineNumber: 899,
          columnNumber: 17
        }, this),
        TablePayments && TablePayments.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: TablePayments.filter(
              (item) => Object.values(item).some(
                (value) => String(value).toLowerCase().includes(searchText.toLowerCase())
              )
            ),
            columns,
            exportedPdfName: "PayOut Others",
            printHeaderKeys: ["Group Name"],
            printHeaderValues: [selectednewGroup?.group_name],
            exportedFileName: `PayOut Others.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
            lineNumber: 929,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            data: "Payments Data",
            failure: TablePayments.length <= 0 && selectedAuctionGroupId
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
            lineNumber: 945,
            columnNumber: 21
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
          lineNumber: 944,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
        lineNumber: 898,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
      lineNumber: 890,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModal,
        onClose: () => {
          setSelectedGroupId("");
          setShowModal(false);
          setErrors({});
          setPaymentGroupTickets([]);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Payment Out" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
            lineNumber: 967,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV(
              Drawer,
              {
                closable: true,
                destroyOnHidden: true,
                title: /* @__PURE__ */ jsxDEV("p", { children: "Last Three Transactions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 974,
                  columnNumber: 26
                }, this),
                placement: "right",
                open: openAntDDrawer,
                loading: showLoader,
                onClose: () => setOpenAntDDrawer(false),
                children: lastThreePayments?.length <= 0 ? /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-center text-xl", children: "No Transaction Found" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 981,
                  columnNumber: 19
                }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 ", children: lastThreePayments.map((payment, index) => {
                  return /* @__PURE__ */ jsxDEV(
                    "section",
                    {
                      className: "bg-white shadow-md rounded-lg p-4 space-y-2 border border-gray-200 ",
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Payment Date:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: payment?.pay_date }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                            lineNumber: 994,
                            columnNumber: 33
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 992,
                          columnNumber: 31
                        }, this),
                        payment.group_id && /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Group:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: payment.group_id?.group_name }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                            lineNumber: 1002,
                            columnNumber: 35
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 1e3,
                          columnNumber: 27
                        }, this),
                        payment.ticket && /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Ticket:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-normal", children: payment?.ticket }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                            lineNumber: 1010,
                            columnNumber: 35
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 1008,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "PayOut Amount:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: [
                            "₹",
                            payment?.amount
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                            lineNumber: 1017,
                            columnNumber: 33
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 1015,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Payment Type:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-normal", children: payment?.pay_type }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                            lineNumber: 1023,
                            columnNumber: 33
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 1021,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Name:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-normal", children: payment.user_id?.full_name }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                            lineNumber: 1029,
                            columnNumber: 33
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 1027,
                          columnNumber: 31
                        }, this)
                      ]
                    },
                    index,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                      lineNumber: 988,
                      columnNumber: 25
                    },
                    this
                  );
                }) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 985,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 971,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Customer ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                      lineNumber: 1044,
                      columnNumber: 32
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1040,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full ${fieldSize.height}`,
                  placeholder: "Select Or Search Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: selectedGroupId || void 0,
                  onChange: handleCustomer,
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: `${group.full_name} | ${group.phone_number}` }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                      lineNumber: 1062,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1047,
                  columnNumber: 21
                },
                this
              ),
              errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1069,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1039,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Group & Ticket ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                      lineNumber: 1080,
                      columnNumber: 38
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1076,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "multiple",
                  name: "group_id",
                  placeholder: "Select Group | Ticket",
                  onChange: handlePaymentAntSelect,
                  value: paymentGroupTickets,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  w-full h-14",
                  children: filteredAuction.map((entry, index) => {
                    const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                    const groupId = entry?.enrollment?.group?._id || `missing-${index}`;
                    const ticket = entry?.enrollment?.tickets || "Unknown";
                    return /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: `chit-${groupId}|${ticket}`,
                        children: [
                          groupName,
                          " | ",
                          ticket
                        ]
                      },
                      `chit-${groupId}|${ticket}`,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                        lineNumber: 1099,
                        columnNumber: 25
                      },
                      this
                    );
                  })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1082,
                  columnNumber: 21
                },
                this
              ),
              errors.payment_group_tickets && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.payment_group_tickets }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1109,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1075,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "group_install",
                  children: "Payment Date"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1117,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  disabled: !modifyPayment,
                  type: "date",
                  name: "pay_date",
                  value: formData.pay_date,
                  id: "pay_date",
                  onChange: handleChange,
                  placeholder: "",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full h-14"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1123,
                  columnNumber: 23
                },
                this
              ),
              errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1135,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1116,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1115,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_value",
                    children: [
                      "Amount ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                        lineNumber: 1148,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                    lineNumber: 1144,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      name: "amount",
                      value: formData.amount,
                      id: "amount",
                      onChange: handleChange,
                      placeholder: "Enter Amount",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                      lineNumber: 1151,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(Tooltip, { title: "Last 3 Transactions", children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      className: "bg-green-300 rounded-md p-2 border-2 font-semibold",
                      onClick: (e) => fetchLastThreeTransactions(e),
                      children: /* @__PURE__ */ jsxDEV(FaReceipt, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                        lineNumber: 1166,
                        columnNumber: 29
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                      lineNumber: 1162,
                      columnNumber: 27
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                    lineNumber: 1161,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1150,
                  columnNumber: 23
                }, this),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1172,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1143,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "pay_mode",
                    children: "Payment Mode"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                    lineNumber: 1178,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "pay_mode",
                    id: "pay_mode",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                    onChange: handlePaymentModeChange,
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                        lineNumber: 1190,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                        lineNumber: 1191,
                        columnNumber: 25
                      }, this),
                      modifyPayment && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "suspense", children: "Suspense" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 1194,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "credit", children: "Credit" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 1195,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "adjustment", children: "Adjustment" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 1196,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "others", children: "Others" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                          lineNumber: 1197,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                        lineNumber: 1193,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                    lineNumber: 1184,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1177,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1142,
              columnNumber: 19
            }, this),
            formData.amount && paymentGroupTickets.length > 1 && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pay_mode",
                  children: "Individual Ticket Amount"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1205,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg hover:cursor-not-allowed w-full p-2.5",
                  placeholder: "totalAmount",
                  value: Number(formData.amount) / paymentGroupTickets.length,
                  disabled: true
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1212,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1204,
              columnNumber: 17
            }, this),
            paymentMode === "online" && /* @__PURE__ */ jsxDEV("div", { className: "w-full mt-4", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "transaction_id",
                  children: [
                    "Transaction ID ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                      lineNumber: 1229,
                      columnNumber: 40
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1225,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "transaction_id",
                  id: "transaction_id",
                  value: formData.transaction_id,
                  onChange: handleChange,
                  placeholder: "Enter Transaction ID",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1231,
                  columnNumber: 23
                },
                this
              ),
              errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1241,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1224,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pay_mode",
                  children: "Disbursement Type"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1248,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "disbursement_type",
                  id: "pay_mode",
                  value: formData.disbursement_type,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                  onChange: handleChange,
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select any" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                      lineNumber: 1261,
                      columnNumber: 23
                    }, this),
                    disbursementTypes.map(
                      (dType) => /* @__PURE__ */ jsxDEV("option", { value: dType.value, children: dType.title }, dType.key, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                        lineNumber: 1263,
                        columnNumber: 21
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1254,
                  columnNumber: 21
                },
                this
              ),
              errors.disbursement_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.disbursement_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1269,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1247,
              columnNumber: 19
            }, this),
            showOthersField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "othersField",
                    children: "Others"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                    lineNumber: 1277,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: " border border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5",
                    id: "othersField",
                    name: "disbursement_type",
                    value: disbursementType,
                    placeholder: "Specify if your option is not listed above",
                    onChange: handleDisbursementTypeChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                    lineNumber: 1283,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1276,
                columnNumber: 23
              }, this),
              errors.disbursement_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.disbursement_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1294,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1275,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "note",
                  children: "Note"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1301,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  rows: 2,
                  type: "text",
                  className: "w-full p-3 border border-gray-300 rounded-lg",
                  id: "note",
                  name: "note",
                  value: formData.note,
                  placeholder: "Note if any?",
                  onChange: handleChange
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1307,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1300,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-violet-50 p-3 rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium text-gray-900", children: "Disbursed By" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1320,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "font-semibold", children: adminName }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1323,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1319,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1318,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center p-4 max-w-full bg-white rounded-lg shadow-sm space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-1", children: [
                /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { color: "green", className: "w-8 h-8" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1328,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("h2", { className: "text-md font-semibold text-gray-800", children: "WhatsApp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1329,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1327,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: whatsappEnable,
                    className: "text-green-500 checked:ring-2  checked:ring-green-700 rounded-full w-4 h-4"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                    lineNumber: 1335,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm", children: "Send Via Whatsapp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1340,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1334,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1326,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-4", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setShowModal(false),
                  className: "px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100",
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1346,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(Tooltip, { title: "Saving Payment Out", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n                              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                  children: "Save Payment Out"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                  lineNumber: 1354,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
                lineNumber: 1353,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
              lineNumber: 1345,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
            lineNumber: 970,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
          lineNumber: 966,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
        lineNumber: 957,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
    lineNumber: 878,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
    lineNumber: 877,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx",
    lineNumber: 873,
    columnNumber: 5
  }, this);
};
_s(PayOutReport, "wFGbiU21tcLuFo8HoUy4BVud8uk=", false, function() {
  return [useParams];
});
_c = PayOutReport;
export default PayOutReport;
var _c;
$RefreshReg$(_c, "PayOutReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMDJCUSxTQThUa0IsVUE5VGxCOzJCQTEyQlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLHdCQUF3QjtBQUNqQyxPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFOLFNBQVNPLFVBQVVDLFFBQVFDLGVBQWU7QUFDM0QsU0FBU0MsaUJBQWlCO0FBQzFCLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsaUJBQWlCO0FBRTFCLE1BQU1DLGVBQWVBLE1BQU07QUFBQUMsS0FBQTtBQUN6QixRQUFNLEVBQUVDLFlBQVksSUFBSU4sVUFBVTtBQUNsQyxRQUFNLENBQUNPLFFBQVFDLFNBQVMsSUFBSXJCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNzQixjQUFjQyxlQUFlLElBQUl2QixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDd0IsZUFBZUMsZ0JBQWdCLElBQUl6QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDMEIsZUFBZUMsZ0JBQWdCLElBQUkzQixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDNEIsc0JBQXNCQyx1QkFBdUIsSUFBSTdCLFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUM4QixpQkFBaUJDLGtCQUFrQixJQUFJL0IsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ2dDLHdCQUF3QkMseUJBQXlCLElBQUlqQyxTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDa0MsZUFBZUMsZ0JBQWdCLElBQUluQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDb0MsVUFBVUMsV0FBVyxJQUFJckMsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3NDLFlBQVlDLGFBQWEsSUFBSXZDLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUN3QyxpQkFBaUJDLGtCQUFrQixJQUFJekMsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQzBDLFdBQVdDLFlBQVksSUFBSTNDLFNBQVMsQ0FBQyxDQUFDO0FBQzdDLFFBQU0sQ0FBQzRDLFdBQVdDLFlBQVksSUFBSTdDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM4QyxpQkFBaUJDLGtCQUFrQixJQUFJL0MsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ2dELHFCQUFxQkMsc0JBQXNCLElBQUlqRCxTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDa0QsY0FBY0MsZUFBZSxJQUFJbkQsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ29ELGVBQWVDLGdCQUFnQixJQUFJckQsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3NELGtCQUFrQkMsbUJBQW1CLElBQUl2RCxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDd0QsaUJBQWlCQyxrQkFBa0IsSUFBSXpELFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMwRCxXQUFXQyxZQUFZLElBQUkzRCxTQUFTLEVBQUU7QUFDN0MsUUFBTTRELGlCQUFpQjtBQUN2QixRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSTlELFNBQVMsTUFBTTtBQUNyRCxRQUFNK0QsU0FBUSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbkQsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlwRSxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDcUUsU0FBU0MsVUFBVSxJQUFJdEUsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3VFLFVBQVVDLFdBQVcsSUFBSXhFLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUN5RSxZQUFZQyxhQUFhLElBQUkxRSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDMkUsaUJBQWlCQyxrQkFBa0IsSUFBSTVFLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM2RSxtQkFBbUJDLG9CQUFvQixJQUFJOUUsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQytFLHFCQUFxQkMsc0JBQXNCLElBQUloRixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDaUYsUUFBUUMsV0FBVyxJQUFJbEYsU0FBUyxDQUFDO0FBQ3hDLFFBQU0sQ0FBQ21GLG9CQUFvQkMscUJBQXFCLElBQUlwRixTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDcUYsZ0JBQWdCQyxpQkFBaUIsSUFBSXRGLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUN1RixnQkFBZ0JDLGlCQUFpQixJQUFJeEYsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ3lGLFlBQVlDLGFBQWEsSUFBSTFGLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUMyRixtQkFBbUJDLG9CQUFvQixJQUFJNUYsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQzZGLFdBQVdDLFlBQVksSUFBSTlGLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUMrRixpQkFBaUJDLGtCQUFrQixJQUFJaEcsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ2lHLGtCQUFrQkMsbUJBQW1CLElBQUlsRyxTQUFTLEVBQUU7QUFDM0QsUUFBTW1HLG9CQUFvQjtBQUFBLElBQ3hCO0FBQUEsTUFDRUMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFRixLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VGLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUVBO0FBQUEsTUFDRUYsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFRixLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VGLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRUYsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFRixLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VGLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRUYsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQUM7QUFHSCxRQUFNQyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekMsVUFBTSxFQUFFRixNQUFNLElBQUlFLEVBQUVDO0FBQ3BCL0Isa0JBQWM0QixLQUFLO0FBQUEsRUFDckI7QUFDQSxRQUFNLENBQUNJLGFBQWFDLGNBQWMsSUFBSTNHLFNBQVM7QUFBQSxJQUM3QzRHLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWpILFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ2tILFVBQVVDLFdBQVcsSUFBSW5ILFNBQVM7QUFBQSxJQUN2Q29ILFNBQVM7QUFBQSxJQUVUQyxVQUFVdEQ7QUFBQUEsSUFDVnVELFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLHVCQUF1QjtBQUFBLElBQ3ZCQyxtQkFBbUI7QUFBQSxJQUNuQkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSTdILFNBQVM7QUFBQSxJQUNuRHNILFFBQVE7QUFBQSxJQUNSRCxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsUUFBTSxDQUFDUyxlQUFlQyxnQkFBZ0IsSUFBSS9ILFNBQVMsS0FBSztBQUV4REQsWUFBVSxNQUFNO0FBQ2QsVUFBTWlJLE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBQy9CbEMsaUJBQWFxQyxTQUFTRyxRQUFRLEVBQUU7QUFFaEMsUUFDRUgsV0FDQUEsU0FBU0ksdUJBQXVCQyxvQkFBb0JDLGNBQ3BEO0FBQ0EsWUFBTUMsV0FDSlAsU0FBU0ksdUJBQXVCQyxvQkFBb0JDLGlCQUNwRCxTQUNJLE9BQ0E7QUFDTlYsdUJBQWlCVyxRQUFRO0FBQUEsSUFDM0I7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMM0ksWUFBVSxNQUFNO0FBQ2QsVUFBTTRJLE1BQU1WLGFBQWFDLFFBQVEsTUFBTTtBQUN2QyxRQUFJVSxhQUFhO0FBRWpCLFFBQUk7QUFDRixVQUFJRCxLQUFLO0FBQ1BDLHFCQUFhUixLQUFLQyxNQUFNTSxHQUFHO0FBQUEsTUFDN0I7QUFBQSxJQUNGLFNBQVNuQyxHQUFHO0FBQ1ZxQyxjQUFRQyxNQUFNLDJDQUEyQ3RDLENBQUM7QUFBQSxJQUM1RDtBQXlHQSxVQUFNdUMseUJBQXlCLE9BQU9DLFVBQVUsU0FBUztBQUN2RCxVQUFJO0FBQ0ZySCx5QkFBaUIsRUFBRTtBQUNuQnlDLHFCQUFhLElBQUk7QUFFakIsWUFBSTRFLFNBQVM7QUFHWCxjQUFJQyxNQUFNLGdEQUFnREQsT0FBTztBQUNqRSxjQUFJN0gsYUFBYTtBQUNmOEgsbUJBQU8sWUFBWTlILFdBQVc7QUFBQSxVQUNoQztBQUNBMkQsK0JBQXFCLEtBQUs7QUFFMUIsZ0JBQU1vRSxXQUFXLE1BQU1oSixJQUFJaUosSUFBSUYsR0FBRztBQUVsQyxjQUFJQyxTQUFTRSxRQUFRRixTQUFTRSxLQUFLQyxTQUFTLEdBQUc7QUFDN0Msa0JBQU1DLGdCQUFnQkosU0FBU0UsS0FBS0csSUFBSSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3hELGtCQUFJLENBQUNELE9BQU9FLFVBQVVDLFdBQVksUUFBTyxDQUFDO0FBQzFDLHFCQUFPO0FBQUEsZ0JBQ0xDLEtBQUtKLE1BQU1JO0FBQUFBLGdCQUNYQyxJQUFJSixRQUFRO0FBQUEsZ0JBQ1puQixNQUFNa0IsT0FBT3BDLFNBQVMwQyxhQUFhO0FBQUEsZ0JBQ25DQyxjQUFjUCxPQUFPcEMsU0FBUzJDLGdCQUFnQjtBQUFBLGdCQUM5Q0osWUFBWUgsT0FBT0UsVUFBVUMsY0FBYztBQUFBLGdCQUMzQ0ssUUFBUVIsTUFBTVEsVUFBVTtBQUFBLGdCQUN4QkMsU0FBU1QsTUFBTVUsY0FBYztBQUFBLGdCQUM3QkMsYUFBYVgsTUFBTVksa0JBQWtCO0FBQUEsZ0JBQ3JDOUMsUUFBUWtDLE1BQU1sQyxVQUFVO0FBQUEsZ0JBQ3hCK0MsTUFBTWIsT0FBT25DLFdBQVdtQyxNQUFNbkMsU0FBU25ELE1BQU0sR0FBRyxFQUFFLENBQUMsSUFBSTtBQUFBLGdCQUN2RG9HLGtCQUFrQmQsT0FBT2UsWUFDckJmLE1BQU1lLFVBQVVyRyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQzVCO0FBQUEsZ0JBQ0pzRyxjQUFjaEIsT0FBT1osWUFBWTZCLGNBQWM7QUFBQSxnQkFDL0MvQyxtQkFBbUI4QixPQUFPOUIscUJBQXFCO0FBQUEsZ0JBQy9DQyxNQUFNNkIsTUFBTTdCLFFBQVE7QUFBQSxjQUN0QjtBQUFBLFlBQ0YsQ0FBQztBQUNEaEcsNkJBQWlCMkgsYUFBYTtBQUFBLFVBQ2hDLE9BQU87QUFDTDdHLCtCQUFtQixFQUFFO0FBQUEsVUFDdkI7QUFBQSxRQUNGLE9BQU87QUFFTCxnQkFBTXlHLFdBQVcsTUFBTWhKLElBQUlpSjtBQUFBQSxZQUN6QjtBQUFBLFlBQ0E7QUFBQSxjQUNFdUIsUUFBUTtBQUFBLGdCQUNOQyxTQUFTeEo7QUFBQUEsY0FDWDtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBRUEsY0FBSStILFNBQVNFLE1BQU13QixTQUFTO0FBQzFCLGtCQUFNLEVBQUV4QixNQUFNeUIsUUFBUSxJQUFJM0IsU0FBU0U7QUFFbkMsa0JBQU0wQixpQkFBaUI7QUFBQSxjQUNyQixHQUFHMUIsS0FBSzJCO0FBQUFBLGNBQ1IsR0FBRzNCLEtBQUs0QjtBQUFBQSxjQUNSLEdBQUc1QixLQUFLNkI7QUFBQUEsY0FDUixHQUFHN0IsS0FBSzhCO0FBQUFBO0FBQUFBLFlBQ1I7QUFHRixrQkFBTTVCLGdCQUFnQndCLGVBQWV2QixJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxjQUMxREcsS0FBS0osTUFBTUk7QUFBQUEsY0FDWEMsSUFBSUosUUFBUTtBQUFBLGNBQ1puQixNQUFNa0IsT0FBT3BDLFNBQVMwQyxhQUFhO0FBQUEsY0FDbkNDLGNBQWNQLE9BQU9wQyxTQUFTMkMsZ0JBQWdCO0FBQUEsY0FDOUNKLFlBQVlILE9BQU9FLFVBQVVDLGNBQWM7QUFBQSxjQUMzQ0ssUUFBUVIsTUFBTVEsVUFBVTtBQUFBLGNBQ3hCQyxTQUFTVCxNQUFNVSxjQUFjO0FBQUEsY0FDN0JDLGFBQWFYLE1BQU1ZLGtCQUFrQjtBQUFBLGNBQ3JDOUMsUUFBUWtDLE1BQU1sQyxVQUFVO0FBQUEsY0FDeEIrQyxNQUFNYyxjQUFjM0IsTUFBTW5DLFFBQVE7QUFBQSxjQUNsQ2lELGtCQUFrQmEsY0FBYzNCLE1BQU1lLFNBQVM7QUFBQSxjQUMvQ0MsY0FBY2hCLE9BQU9aLFlBQVlrQixhQUFhO0FBQUEsY0FDOUNwQyxtQkFBbUI4QixNQUFNOUIscUJBQXFCO0FBQUEsY0FDOUNDLE1BQU02QixNQUFNN0IsUUFBUTtBQUFBLFlBQ3RCLEVBQUU7QUFFRmhHLDZCQUFpQjJILGFBQWE7QUFDOUJULG9CQUFRdUMsSUFBSSxZQUFZUCxPQUFPO0FBQUEsVUFDakMsT0FBTztBQUNMcEksK0JBQW1CLEVBQUU7QUFBQSxVQUN2QjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVNxRyxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLGtDQUFrQ0EsS0FBSztBQUNyRHJHLDJCQUFtQixFQUFFO0FBQUEsTUFDdkIsVUFBQztBQUNDMkIscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUVBMkUsMkJBQXVCO0FBQUEsRUFDekIsR0FBRyxDQUFDOUQsTUFBTSxDQUFDO0FBRVgsUUFBTW9HLDZCQUE2QixPQUFPQyxVQUFVO0FBQ2xEQSxVQUFNQyxlQUFlO0FBQ3JCL0Ysc0JBQWtCLElBQUk7QUFDdEIsUUFBSTBCLFNBQVNFLFdBQVdGLFNBQVNPLHVCQUF1QjtBQUN0RCxVQUFJO0FBQ0YvQixzQkFBYyxJQUFJO0FBQ2xCLGNBQU13RCxXQUFXLE1BQU1oSixJQUFJaUosSUFBSSxzQ0FBc0M7QUFBQSxVQUNuRXVCLFFBQVE7QUFBQSxZQUNOdEQsU0FBU0YsU0FBU0U7QUFBQUEsWUFDbEJLLHVCQUF1QjFDO0FBQUFBLFlBQ3ZCeUcsT0FBTztBQUFBLFlBQ1BiLFNBQVN4SjtBQUFBQSxVQUNYO0FBQUEsUUFDRixDQUFDO0FBQ0QsWUFBSStILFVBQVVFLE1BQU07QUFDbEJ4RCwrQkFBcUJzRCxTQUFTRSxJQUFJO0FBQUEsUUFDcEMsT0FBTztBQUNMeEQsK0JBQXFCLEVBQUU7QUFBQSxRQUN6QjtBQUFBLE1BQ0YsU0FBU2tELE9BQU87QUFDZGxELDZCQUFxQixFQUFFO0FBQUEsTUFDekIsVUFBQztBQUNDRixzQkFBYyxLQUFLO0FBQUEsTUFDckI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBM0YsWUFBVSxNQUFNO0FBQ2QsVUFBTTBMLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTXZDLFdBQVcsTUFBTWhKLElBQUlpSixJQUFJLGdCQUFnQjtBQUMvQzlILGtCQUFVNkgsU0FBU0UsSUFBSTtBQUFBLE1BQ3pCLFNBQVNOLE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0EyQyxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDL0UsV0FBVyxDQUFDO0FBRWhCM0csWUFBVSxNQUFNO0FBQ2QsVUFBTTBMLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTXZDLFdBQVcsTUFBTWhKLElBQUlpSixJQUFJLDRCQUE0QjtBQUMzRDVILHdCQUFnQjJILFNBQVNFLElBQUk7QUFBQSxNQUMvQixTQUFTTixPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBMkMsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQy9FLFdBQVcsQ0FBQztBQUVoQixRQUFNZ0YsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxZQUFZLENBQUM7QUFFbkIsUUFBSSxDQUFDN0osaUJBQWlCO0FBQ3BCNkosZ0JBQVVDLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFFBQUksQ0FBQzFFLFNBQVNPLHVCQUF1QjtBQUNuQ2tFLGdCQUFVbEUsd0JBQXdCO0FBQUEsSUFDcEM7QUFFQSxRQUFJLENBQUNQLFNBQVNHLFVBQVU7QUFDdEJzRSxnQkFBVXRFLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFVBQU1DLFNBQVN1RSxXQUFXM0UsU0FBU0ksTUFBTTtBQUN6QyxRQUFJd0UsTUFBTXhFLE1BQU0sS0FBS0EsVUFBVSxHQUFHO0FBQ2hDcUUsZ0JBQVVyRSxTQUFTO0FBQUEsSUFDckI7QUFFQSxRQUFJekQsZ0JBQWdCLFlBQVksQ0FBQ3FELFNBQVNNLGdCQUFnQnVFLEtBQUssR0FBRztBQUNoRUosZ0JBQVVuRSxpQkFDUjtBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUNOLFNBQVNRLG1CQUFtQjtBQUMvQmlFLGdCQUFVakUsb0JBQW9CO0FBQUEsSUFDaEM7QUFDQVQsY0FBVTBFLFNBQVM7QUFDbkIsV0FBT0ssT0FBT0MsS0FBS04sU0FBUyxFQUFFdEMsV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTTZDLGVBQWVBLENBQUMxRixNQUFNO0FBQzFCLFVBQU0sRUFBRThCLE1BQU1oQyxNQUFNLElBQUlFLEVBQUVDO0FBQzFCLFFBQUk2QixTQUFTLHFCQUFxQjtBQUNoQyxVQUFJaEMsVUFBVSxVQUFVO0FBQ3RCTiwyQkFBbUIsSUFBSTtBQUN2QkUsNEJBQW9CLEVBQUU7QUFBQSxNQUN4QixPQUFPO0FBQ0xGLDJCQUFtQixLQUFLO0FBQUEsTUFDMUI7QUFBQSxJQUNGO0FBQ0FtQixnQkFBWSxDQUFDZ0YsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQzdELElBQUksR0FBR2hDO0FBQUFBLElBQ1YsRUFBRTtBQUNGVyxjQUFVLENBQUNrRixjQUFjLEVBQUUsR0FBR0EsVUFBVSxDQUFDN0QsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQ3ZEO0FBRUEsUUFBTThELHlCQUF5QkEsQ0FBQ0MsV0FBVztBQUN6Q3JILDJCQUF1QnFILE1BQU07QUFBQSxFQUMvQjtBQUVBLFFBQU1DLG9CQUFvQixPQUFPdEQsWUFBWTtBQUMzQ3ZILHFCQUFpQnVILE9BQU87QUFFeEIsUUFBSUEsU0FBUztBQUNYLFVBQUk7QUFDRixjQUFNRSxXQUFXLE1BQU1oSixJQUFJaUosSUFBSSw0QkFBNEJILE9BQU8sRUFBRTtBQUNwRSxZQUFJRSxTQUFTRSxRQUFRRixTQUFTRSxLQUFLQyxTQUFTLEdBQUc7QUFDN0NsSCwyQkFBaUIrRyxTQUFTRSxJQUFJO0FBQUEsUUFDaEMsT0FBTztBQUNMakgsMkJBQWlCLEVBQUU7QUFBQSxRQUNyQjtBQUFBLE1BQ0YsU0FBUzJHLE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REM0cseUJBQWlCLEVBQUU7QUFBQSxNQUNyQjtBQUFBLElBQ0YsT0FBTztBQUNMQSx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU1vSyxVQUFVO0FBQUEsSUFDZCxFQUFFbkcsS0FBSyxNQUFNb0csUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRXBHLEtBQUssUUFBUW9HLFFBQVEsWUFBWTtBQUFBLElBQ25DLEVBQUVwRyxLQUFLLG9CQUFvQm9HLFFBQVEsbUJBQW1CO0FBQUEsSUFDdEQsRUFBRXBHLEtBQUssUUFBUW9HLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRXBHLEtBQUssZ0JBQWdCb0csUUFBUSx3QkFBd0I7QUFBQSxFQUFDO0FBRTFELE1BQUkzSCxtQkFBbUI7QUFDckIwSCxZQUFRRSxLQUFLLEVBQUVyRyxLQUFLLGNBQWNvRyxRQUFRLGFBQWEsQ0FBQztBQUFBLEVBQzFEO0FBQ0FELFVBQVFFO0FBQUFBLElBQ04sRUFBRXJHLEtBQUssVUFBVW9HLFFBQVEsZ0JBQWdCO0FBQUEsSUFDekMsRUFBRXBHLEtBQUssZUFBZW9HLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVwRyxLQUFLLFdBQVdvRyxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFcEcsS0FBSyxVQUFVb0csUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRXBHLEtBQUssZ0JBQWdCb0csUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRXBHLEtBQUsscUJBQXFCb0csUUFBUSxvQkFBb0I7QUFBQSxJQUN4RCxFQUFFcEcsS0FBSyxRQUFRb0csUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRXBHLEtBQUssVUFBVW9HLFFBQVEsU0FBUztBQUFBLEVBQ3BDO0FBaUNBLFFBQU1FLGlCQUFpQixPQUFPMUQsWUFBWTtBQUN4Q2pILHVCQUFtQmlILE9BQU87QUFDMUI3QixnQkFBWSxDQUFDd0Ysa0JBQWtCO0FBQUEsTUFDN0IsR0FBR0E7QUFBQUEsTUFDSHZGLFNBQVM0QjtBQUFBQSxJQUNYLEVBQUU7QUFDRi9CLGNBQVUsQ0FBQ2tGLGNBQWMsRUFBRSxHQUFHQSxVQUFVUCxVQUFVLEdBQUcsRUFBRTtBQUN2RDVHLDJCQUF1QixFQUFFO0FBQ3pCc0gsc0JBQWtCdEQsT0FBTztBQUN6QjRELDZCQUF5QjVELE9BQU87QUFFaEMsUUFBSUEsU0FBUztBQUNYLFVBQUk7QUFDRixjQUFNRSxXQUFXLE1BQU1oSixJQUFJaUosSUFBSSwwQkFBMEJILE9BQU8sRUFBRTtBQUNsRXJHLHFCQUFhdUcsU0FBU0UsUUFBUSxDQUFDLENBQUM7QUFBQSxNQUNsQyxTQUFTTixPQUFPO0FBQ2RuRyxxQkFBYSxDQUFDLENBQUM7QUFBQSxNQUNqQjtBQUFBLElBQ0YsT0FBTztBQUNMQSxtQkFBYSxDQUFDLENBQUM7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNa0sscUJBQXFCLE9BQU83RCxZQUFZO0FBQzVDL0csOEJBQTBCK0csT0FBTztBQUNqQzhELDZCQUF5QjlELE9BQU87QUFBQSxFQUNsQztBQUVBLFFBQU1tQyxnQkFBZ0JBLENBQUM0QixlQUFlO0FBQ3BDLFdBQU9BLFlBQVk3SSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDakM7QUFFQSxRQUFNNEksMkJBQTJCLE9BQU85RCxZQUFZO0FBQ2xESCxZQUFRdUMsSUFBSXBDLFNBQVEsaUJBQWlCO0FBQ3JDbkgsNEJBQXdCbUgsT0FBTztBQUMvQixRQUFJQSxTQUFTO0FBQ1gsVUFBSUM7QUFDSixVQUFJRCxZQUFZLFNBQVM7QUFDdkJDLGNBQU0seURBQXlEbEYsS0FBSyxZQUFZNUMsV0FBVztBQUMzRjJELDZCQUFxQixJQUFJO0FBQUEsTUFDM0IsT0FBTztBQUVMbUUsY0FBTSxnREFBZ0RELE9BQU87QUFDN0QsWUFBSTdILGFBQWE7QUFDZjhILGlCQUFPLFlBQVk5SCxXQUFXO0FBQUEsUUFDaEM7QUFDQTJELDZCQUFxQixLQUFLO0FBQUEsTUFDNUI7QUFDQSxVQUFJO0FBQ0ZuRCx5QkFBaUIsRUFBRTtBQUNuQnlDLHFCQUFhLElBQUk7QUFDakIsY0FBTThFLFdBQVcsTUFBTWhKLElBQUlpSixJQUFJRixHQUFHO0FBRWxDLFlBQUlDLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUtDLFNBQVMsR0FBRztBQUM3QyxnQkFBTUMsZ0JBQWdCSixTQUFTRSxLQUFLRyxJQUFJLENBQUNDLE9BQU9DLFVBQVU7QUFDeEQsZ0JBQUksQ0FBQ0QsT0FBT0UsVUFBVUMsV0FBWSxRQUFPLENBQUM7QUFDMUMsbUJBQU87QUFBQSxjQUNMQyxLQUFLSixNQUFNSTtBQUFBQSxjQUNYQyxJQUFJSixRQUFRO0FBQUEsY0FDWm5CLE1BQU1rQixPQUFPcEMsU0FBUzBDO0FBQUFBLGNBQ3RCQyxjQUFjUCxPQUFPcEMsU0FBUzJDO0FBQUFBLGNBQzlCSixZQUFZSCxPQUFPRSxVQUFVQztBQUFBQSxjQUM3QkssUUFBUVIsTUFBTVE7QUFBQUEsY0FDZEMsU0FBU1QsTUFBTVU7QUFBQUEsY0FDZkMsYUFBYVgsTUFBTVk7QUFBQUEsY0FDbkI5QyxRQUFRa0MsTUFBTWxDO0FBQUFBLGNBQ2QrQyxNQUFNYixPQUFPbkMsU0FBU25ELE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxjQUNsQ29HLGtCQUFrQmQsT0FBT2UsV0FBV3JHLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxjQUNoRHNHLGNBQWNoQixPQUFPWixZQUFZNkIsY0FBYztBQUFBLGNBQy9DL0MsbUJBQW1COEIsT0FBTzlCO0FBQUFBLGNBQzFCQyxNQUFNNkIsTUFBTTdCO0FBQUFBLFlBQ2Q7QUFBQSxVQUNGLENBQUM7QUFDRGhHLDJCQUFpQjJILGFBQWE7QUFBQSxRQUNoQyxPQUFPO0FBQ0w3Ryw2QkFBbUIsRUFBRTtBQUFBLFFBQ3ZCO0FBQUEsTUFDRixTQUFTcUcsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkRyRywyQkFBbUIsRUFBRTtBQUFBLE1BQ3ZCLFVBQUM7QUFDQzJCLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0YsT0FBTztBQUNMM0IseUJBQW1CLEVBQUU7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNdUssMEJBQTBCQSxDQUFDeEcsTUFBTTtBQUNyQyxVQUFNeUcsZUFBZXpHLEVBQUVDLE9BQU9IO0FBQzlCeEMsbUJBQWVtSixZQUFZO0FBQzNCOUYsZ0JBQVksQ0FBQ2dGLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNINUUsVUFBVTBGO0FBQUFBLE1BRVZ6RixnQkFBZ0J5RixpQkFBaUIsV0FBV2QsU0FBUzNFLGlCQUFpQjtBQUFBLElBQ3hFLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTTBGLGVBQWUsT0FBTzFHLE1BQU07QUFDaENBLE1BQUUrRSxlQUFlO0FBQ2pCLFVBQU00QixVQUFVekIsYUFBYTtBQUM3QixRQUFJO0FBQ0YsVUFBSXlCLFNBQVM7QUFDWDNJLG9CQUFZLElBQUk7QUFDaEJtQyx1QkFBZSxDQUFDeUcsVUFBVTtBQUFBLFVBQ3hCLEdBQUdBO0FBQUFBLFVBQ0h4RyxZQUFZO0FBQUEsUUFDZCxFQUFFO0FBQ0YvRCxxQkFBYSxLQUFLO0FBQ2xCLFlBQUl3SztBQUNKLGNBQU0xRSxNQUFNVixhQUFhQyxRQUFRLE1BQU07QUFDdkMsWUFBSVUsYUFBYTtBQUNqQixZQUFJO0FBQ0YsY0FBSUQsS0FBSztBQUNQQyx5QkFBYVIsS0FBS0MsTUFBTU0sR0FBRztBQUFBLFVBQzdCO0FBQUEsUUFDRixTQUFTbkMsSUFBRztBQUNWcUMsa0JBQVFDLE1BQU0sMkNBQTJDdEMsRUFBQztBQUFBLFFBQzVEO0FBQ0EsWUFBSVUsU0FBU1Esc0JBQXNCLFVBQVU7QUFDM0NSLG1CQUFTUSxvQkFBb0J6QjtBQUFBQSxRQUMvQjtBQUNBaUIsaUJBQVNPLHdCQUF3QjFDO0FBQ2pDbUMsaUJBQVMwQixhQUFhQSxZQUFZZ0I7QUFDbEMxQyxpQkFBU3lELFVBQVV4SjtBQUNuQmlFLDhCQUFzQixJQUFJO0FBQzFCeUQsZ0JBQVF1QyxJQUFJbEUsVUFBVSwyQkFBMkI7QUFDakQsY0FBTWdDLFdBQVcsTUFBTWhKLElBQUlvTjtBQUFBQSxVQUN6QjtBQUFBLFVBQ0FwRztBQUFBQSxRQUNGO0FBRUEsWUFBSWdDLFNBQVNxRSxXQUFXLEtBQUs7QUFDM0J4TCw2QkFBbUIsRUFBRTtBQUNyQmlELGlDQUF1QixFQUFFO0FBQ3pCUixzQkFBWSxLQUFLO0FBQ2pCMkMsc0JBQVk7QUFBQSxZQUNWQyxTQUFTO0FBQUEsWUFDVEMsVUFBVXREO0FBQUFBLFlBQ1Z1RCxRQUFRO0FBQUEsWUFDUkMsVUFBVTtBQUFBLFlBQ1ZDLGdCQUFnQjtBQUFBLFlBQ2hCQyx1QkFBdUI7QUFBQSxZQUN2QkMsbUJBQW1CO0FBQUEsWUFDbkJDLE1BQU07QUFBQSxVQUNSLENBQUM7QUFDRGhCLHlCQUFlO0FBQUEsWUFDYkMsWUFBWTtBQUFBLFlBQ1pFLFVBQVU7QUFBQSxZQUNWRCxTQUFTO0FBQUEsWUFDVEUsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0g7QUFFQSxZQUFJbUMsU0FBU3FFLFVBQVUsS0FBSztBQUMxQjFLLHVCQUFhLEtBQUs7QUFDbEJkLDZCQUFtQixFQUFFO0FBQ3JCaUQsaUNBQXVCLEVBQUU7QUFDekJSLHNCQUFZLEtBQUs7QUFDakIyQyxzQkFBWTtBQUFBLFlBQ1ZDLFNBQVM7QUFBQSxZQUNUQyxVQUFVdEQ7QUFBQUEsWUFDVnVELFFBQVE7QUFBQSxZQUNSQyxVQUFVO0FBQUEsWUFDVkMsZ0JBQWdCO0FBQUEsWUFDaEJDLHVCQUF1QjtBQUFBLFlBQ3ZCQyxtQkFBbUI7QUFBQSxZQUNuQkMsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUNEaEIseUJBQWU7QUFBQSxZQUNiQyxZQUFZO0FBQUEsWUFDWkUsVUFBVTtBQUFBLFlBQ1ZELFNBQVM7QUFBQSxZQUNURSxNQUFNO0FBQUEsVUFDUixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGLFNBQVMrQixPQUFPO0FBQ2RqRyxtQkFBYSxLQUFLO0FBQ2xCZCx5QkFBbUIsRUFBRTtBQUNyQm9GLGtCQUFZO0FBQUEsUUFDVkMsU0FBUztBQUFBLFFBQ1RDLFVBQVU7QUFBQSxRQUNWQyxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLGdCQUFnQjtBQUFBLFFBQ2hCQyx1QkFBdUI7QUFBQSxRQUN2QkMsbUJBQW1CO0FBQUEsUUFDbkJDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRGhCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pFLFVBQVU7QUFBQSxRQUNWRCxTQUFTO0FBQUEsUUFDVEUsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEdkMsa0JBQVksS0FBSztBQUNqQnFFLGNBQVFDLE1BQU0sa0NBQWtDQSxLQUFLO0FBQUEsSUFDdkQsVUFBQztBQUNDMUQsNEJBQXNCLEtBQUs7QUFDM0JGLGtCQUFZLENBQUNrSSxTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNoQztBQUFBLEVBQ0Y7QUFFQSxRQUFNSSx3QkFBd0IsT0FBT3hFLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1FLFdBQVcsTUFBTWhKLElBQUlpSixJQUFJLDhCQUE4QkgsT0FBTyxFQUFFO0FBQ3RFN0Ysc0JBQWdCK0YsU0FBU0UsSUFBSTtBQUM3QnJHLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBUytGLE9BQU87QUFDZEQsY0FBUUMsTUFBTSwwQkFBMEJBLEtBQUs7QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxRQUFNMkUsc0JBQXNCLFlBQVk7QUFDdEMsUUFBSXZLLGNBQWM7QUFDaEIsVUFBSTtBQUNGLGNBQU1oRCxJQUFJd04sT0FBTywyQkFBMkJ4SyxhQUFhMEcsR0FBRyxFQUFFO0FBRTlEN0csMkJBQW1CLEtBQUs7QUFDeEJJLHdCQUFnQixJQUFJO0FBQ3BCd0QsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RFLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILFNBQVMrQixPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLDJCQUEyQkEsS0FBSztBQUFBLE1BQ2hEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkUsc0JBQXNCLE9BQU8zRSxZQUFZO0FBQzdDLFFBQUk7QUFDRjFFLGlCQUFXLElBQUk7QUFDZmpCLHVCQUFpQixJQUFJO0FBQ3JCaUMsd0JBQWtCMEQsT0FBTztBQUN6QnpHLG9CQUFjLElBQUk7QUFDbEIsWUFBTTJHLFdBQVcsTUFBTWhKLElBQUlpSixJQUFJLDhCQUE4QkgsT0FBTyxFQUFFO0FBQ3RFekYsMEJBQW9CMkYsU0FBU0UsSUFBSTtBQUFBLElBQ25DLFNBQVNOLE9BQU87QUFDZEQsY0FBUUMsTUFBTSwwQkFBMEJBLEtBQUs7QUFBQSxJQUMvQyxVQUFDO0FBQ0N4RSxpQkFBVyxLQUFLO0FBQ2hCL0Isb0JBQWMsS0FBSztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU1xTCx3QkFBd0IsT0FBTzVFLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1FLFdBQVcsTUFBTWhKLElBQUlpSixJQUFJLDhCQUE4QkgsT0FBTyxFQUFFO0FBQ3RFL0YsNkJBQXVCaUcsU0FBU0UsSUFBSTtBQUNwQ3ZCLHdCQUFrQjtBQUFBLFFBQ2hCUCxRQUFRNEIsVUFBVUUsTUFBTTlCO0FBQUFBLFFBQ3hCRCxVQUFVNkIsVUFBVUUsTUFBTS9CLFNBQVNuRCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDakQsQ0FBQztBQUNEVSx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVNrRSxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sdUNBQXVDQSxLQUFLO0FBQUEsSUFDNUQ7QUFBQSxFQUNGO0FBQ0EsUUFBTStFLGVBQWUsT0FBT3JILE1BQU07QUFDaENBLE1BQUUrRSxlQUFlO0FBQ2pCLFFBQUk7QUFDRixZQUFNckwsSUFBSTROO0FBQUFBLFFBQ1Isa0NBQWtDOUssb0JBQW9CNEcsR0FBRztBQUFBLFFBQ3pEaEM7QUFBQUEsTUFDRjtBQUNBaEQseUJBQW1CLEtBQUs7QUFFeEIrQixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEUsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsU0FBUytCLE9BQU87QUFDZEQsY0FBUUMsTUFBTSxrQ0FBa0NBLEtBQUs7QUFDckQsVUFDRUEsTUFBTUksWUFDTkosTUFBTUksU0FBU0UsUUFDZk4sTUFBTUksU0FBU0UsS0FBS3ZDLFNBQ3BCO0FBQ0FGLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVMsR0FBR2lDLE9BQU9JLFVBQVVFLE1BQU12QyxPQUFPO0FBQUEsVUFDMUNFLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTEosdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RFLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNZ0gsK0JBQStCQSxDQUFDekMsVUFBVTtBQUM5QyxVQUFNLEVBQUVoRCxNQUFNaEMsTUFBTSxJQUFJZ0YsTUFBTTdFO0FBQzlCUCx3QkFBb0JJLEtBQUs7QUFBQSxFQUMzQjtBQUNBLFFBQU1zRywyQkFBMkIsT0FBTzVELFlBQVk7QUFDbEQsUUFBSUEsU0FBUztBQUNYLFVBQUk7QUFDRixjQUFNRSxXQUFXLE1BQU1oSixJQUFJb047QUFBQUEsVUFDekIsbUNBQW1DdEUsT0FBTztBQUFBLFFBQzVDO0FBQ0EsWUFBSUUsU0FBU0UsUUFBUUYsU0FBU0UsS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNMkUsZ0JBQWdCOUUsU0FBU0UsS0FBSzZFO0FBQUFBLFlBQ2xDLENBQUNDLFlBQVlBLFFBQVFDLGNBQWNELFFBQVFDLFdBQVczRTtBQUFBQSxVQUN4RDtBQUNBL0csNkJBQW1CdUwsYUFBYTtBQUFBLFFBQ2xDLE9BQU87QUFDTHZMLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVNxRyxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RHJHLDJCQUFtQixFQUFFO0FBQUEsTUFDdkI7QUFBQSxJQUNGLE9BQU87QUFDTEEseUJBQW1CLEVBQUU7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNMkwsbUJBQW1COU0sYUFBYStNO0FBQUFBLElBQ3BDLENBQUNDLE1BQU1BLEVBQUUxRSxRQUFRNUg7QUFBQUEsRUFDbkI7QUFDQSxTQUNFLG1DQUNHbUQsK0JBQ0MsdUJBQUMsc0JBQW1CLE9BQU8saUNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUQsSUFFekQsdUJBQUMsU0FDQyxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUduQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTXVCLFlBQVlLO0FBQUFBLFFBQ2xCLFdBQVdMLFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFFBQ3JCLFVBQVVILFlBQVlJO0FBQUFBO0FBQUFBLE1BSnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlpQztBQUFBLElBRWpDLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwwQkFDWjtBQUFBLCtCQUFDLFVBQUssV0FBVSxtQ0FDYjNGLHVCQUFhb04sWUFBWSxLQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDO0FBQUEsUUFBSztBQUFBLFdBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGFBQVksc0NBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxhQUFZO0FBQUEsY0FDWix1QkFBdUI7QUFBQSxjQUN2QjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQ1YsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGNBRWpDLE9BQU81TSwwQkFBMEI4TTtBQUFBQSxjQUNqQyxVQUFVakM7QUFBQUEsY0FFVjtBQUFBLHVDQUFDLE9BQU8sUUFBUCxFQUF5QixPQUFPLFNBQzlCLHdCQURpQixNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0N2TCxhQUFhaUk7QUFBQUEsa0JBQUksQ0FBQ0MsVUFDakIsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1JLEtBQ3pDSixnQkFBTUcsY0FEV0gsTUFBTUksS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQTtBQUFBLFlBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXNCQSxLQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLGFBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQkE7QUFBQSxRQUVDbEksaUJBQWlCQSxjQUFjMkgsU0FBUyxJQUN2QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTTNILGNBQWN1TTtBQUFBQSxjQUFPLENBQUNjLFNBQzFCL0MsT0FBT0ssT0FBTzBDLElBQUksRUFBRUM7QUFBQUEsZ0JBQUssQ0FBQzFJLFVBQ3hCMkksT0FBTzNJLEtBQUssRUFDVHNJLFlBQVksRUFDWkMsU0FBU3BLLFdBQVdtSyxZQUFZLENBQUM7QUFBQSxjQUN0QztBQUFBLFlBQ0Y7QUFBQSxZQUNBO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixpQkFBaUIsQ0FBQyxZQUFZO0FBQUEsWUFDOUIsbUJBQW1CLENBQUNSLGtCQUFrQnpFLFVBQVU7QUFBQSxZQUNoRCxrQkFBa0I7QUFBQTtBQUFBLFVBWnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVl3QyxJQUd4Qyx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxNQUFLO0FBQUEsWUFDTCxTQUNFakksY0FBYzJILFVBQVUsS0FBS3JIO0FBQUFBO0FBQUFBLFVBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtHLEtBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0F0REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdEQTtBQUFBLFNBaEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpRUE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXWTtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiYiw2QkFBbUIsRUFBRTtBQUNyQmMsdUJBQWEsS0FBSztBQUNsQm9FLG9CQUFVLENBQUMsQ0FBQztBQUNaakMsaUNBQXVCLEVBQUU7QUFBQSxRQUMzQjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QywrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVWtJLGNBQWMsWUFBVSxNQUM1RDtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQTtBQUFBLGdCQUNBLE9BQU8sdUJBQUMsT0FBRSx1Q0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQjtBQUFBLGdCQUNqQyxXQUFVO0FBQUEsZ0JBQ1YsTUFBTTNIO0FBQUFBLGdCQUNOLFNBQVNFO0FBQUFBLGdCQUNULFNBQVMsTUFBTUQsa0JBQWtCLEtBQUs7QUFBQSxnQkFFckNHLDZCQUFtQjBELFVBQVUsSUFDNUIsdUJBQUMsU0FBSSxXQUFVLHFDQUFvQyxvQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx3QkFDWjFELDRCQUFrQjRELElBQUksQ0FBQzJGLFNBQVN6RixVQUFVO0FBQ3pDLHlCQUNFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFHVjtBQUFBLCtDQUFDLFNBQUksV0FBVSwrQkFBOEI7QUFBQTtBQUFBLDBCQUM3QjtBQUFBLDBCQUNkLHVCQUFDLFVBQUssV0FBVSxhQUNieUYsbUJBQVM3SCxZQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUEsd0JBRUM2SCxRQUFReEYsWUFDUCx1QkFBQyxTQUFJLFdBQVUsK0JBQThCO0FBQUE7QUFBQSwwQkFDcEM7QUFBQSwwQkFDUCx1QkFBQyxVQUFLLFdBQVUsYUFDYndGLGtCQUFReEYsVUFBVUMsY0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDZCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBS0E7QUFBQSx3QkFFRHVGLFFBQVFsRixVQUNQLHVCQUFDLFNBQUksV0FBVSwrQkFBOEI7QUFBQTtBQUFBLDBCQUNuQztBQUFBLDBCQUNSLHVCQUFDLFVBQUssV0FBVSxlQUNia0YsbUJBQVNsRixVQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUEsd0JBRUYsdUJBQUMsU0FBSSxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsMEJBQzVCO0FBQUEsMEJBQ2YsdUJBQUMsVUFBSyxXQUFVLGFBQVk7QUFBQTtBQUFBLDRCQUN4QmtGLFNBQVM1SDtBQUFBQSwrQkFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsNkJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBLHdCQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFBOEI7QUFBQTtBQUFBLDBCQUM3QjtBQUFBLDBCQUNkLHVCQUFDLFVBQUssV0FBVSxlQUNiNEgsbUJBQVMzSCxZQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUEsd0JBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsMEJBQ3JDO0FBQUEsMEJBQ04sdUJBQUMsVUFBSyxXQUFVLGVBQ2IySCxrQkFBUTlILFNBQVMwQyxhQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsNkJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBO0FBQUE7QUFBQSxvQkExQ0tMO0FBQUFBLG9CQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBNkNBO0FBQUEsZ0JBRUosQ0FBQyxLQWxESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1EQTtBQUFBO0FBQUEsY0FqRUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyw2RUFBNkV6SSxVQUFVbU8sTUFBTTtBQUFBLGtCQUN4RyxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsY0FBYyxDQUFDWCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPOU0sbUJBQW1CZ047QUFBQUEsa0JBQzFCLFVBQVVwQztBQUFBQSxrQkFFVHRMLGlCQUFPbUk7QUFBQUEsb0JBQUksQ0FBQ0MsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTUksS0FDekMsYUFBR0osTUFBTU0sU0FBUyxNQUFNTixNQUFNTyxZQUFZLE1BRHpCUCxNQUFNSSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkE7QUFBQSxjQUVDNUMsT0FBTzRFLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWNUUsaUJBQU80RSxZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQ0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsb0JBRUgsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLGFBQVk7QUFBQSxrQkFDWixVQUFVUTtBQUFBQSxrQkFDVixPQUFPckg7QUFBQUEsa0JBQ1AsV0FBVTtBQUFBLGtCQUVUdkMsMEJBQWdCK0csSUFBSSxDQUFDNkYsT0FBTzNGLFVBQVU7QUFDckMsMEJBQU00RixZQUNKRCxPQUFPakIsWUFBWTNFLE9BQU9HLGNBQzFCO0FBQ0YsMEJBQU1YLFVBQ0pvRyxPQUFPakIsWUFBWTNFLE9BQU9JLE9BQU8sV0FBV0gsS0FBSztBQUNuRCwwQkFBTU8sU0FBU29GLE9BQU9qQixZQUFZbUIsV0FBVztBQUU3QywyQkFDRTtBQUFBLHNCQUFDLE9BQU87QUFBQSxzQkFBUDtBQUFBLHdCQUVDLE9BQU8sUUFBUXRHLE9BQU8sSUFBSWdCLE1BQU07QUFBQSx3QkFFL0JxRjtBQUFBQTtBQUFBQSwwQkFBVTtBQUFBLDBCQUFJckY7QUFBQUE7QUFBQUE7QUFBQUEsc0JBSFYsUUFBUWhCLE9BQU8sSUFBSWdCLE1BQU07QUFBQSxzQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKLENBQUM7QUFBQTtBQUFBLGdCQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F5QkE7QUFBQSxjQUNDaEQsT0FBT1MseUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVCxpQkFBT1MseUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXBDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBZTtBQUFBO0FBQUEsZ0JBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxVQUFVLENBQUNLO0FBQUFBLGtCQUNYLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT1osU0FBU0c7QUFBQUEsa0JBQ2hCLElBQUc7QUFBQSxrQkFDSCxVQUFVNkU7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVEwSTtBQUFBLGNBR3pJbEYsT0FBT0ssWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZMLGlCQUFPSyxZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBYTtBQUFBO0FBQUEsc0JBRWQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxPQUFPSCxTQUFTSTtBQUFBQSxzQkFDaEIsSUFBRztBQUFBLHNCQUNILFVBQVU0RTtBQUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1o7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUTJJO0FBQUEsa0JBRTNJLHVCQUFDLFdBQVEsT0FBTSx1QkFDYjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUyxDQUFDMUYsTUFBTTZFLDJCQUEyQjdFLENBQUM7QUFBQSxzQkFFNUMsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFVO0FBQUE7QUFBQSxvQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEscUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBRUNRLE9BQU9NLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWTixpQkFBT00sVUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUNBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVU7QUFBQTtBQUFBLGtCQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsSUFBRztBQUFBLG9CQUNILFdBQVU7QUFBQSxvQkFDVixVQUFVMEY7QUFBQUEsb0JBRVY7QUFBQSw2Q0FBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUI7QUFBQSxzQkFDekIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUEsc0JBQzVCbEYsaUJBQ0MsbUNBQ0U7QUFBQSwrQ0FBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUM7QUFBQSx3QkFDakMsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZCO0FBQUEsd0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxjQUFhLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxQztBQUFBLHdCQUNyQyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkI7QUFBQSwyQkFKL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQTtBQUFBO0FBQUE7QUFBQSxrQkFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZ0JBO0FBQUEsbUJBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBd0JBO0FBQUEsaUJBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNERBO0FBQUEsWUFDQ1osU0FBU0ksVUFBVXZDLG9CQUFvQnNFLFNBQVMsS0FDL0MsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLGdCQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osT0FDRWtHLE9BQU9ySSxTQUFTSSxNQUFNLElBQUl2QyxvQkFBb0JzRTtBQUFBQSxrQkFFaEQsVUFBUTtBQUFBO0FBQUEsZ0JBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT1U7QUFBQSxpQkFmWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBRUR4RixnQkFBZ0IsWUFDZix1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWdCO0FBQUE7QUFBQSxvQkFFVCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBO0FBQUE7QUFBQSxnQkFKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsSUFBRztBQUFBLGtCQUNILE9BQU9xRCxTQUFTTTtBQUFBQSxrQkFDaEIsVUFBVTBFO0FBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUE7QUFBQSxnQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPMkk7QUFBQSxjQUUxSWxGLE9BQU9RLGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlIsaUJBQU9RLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUVGLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsZ0JBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsSUFBRztBQUFBLGtCQUNILE9BQU9OLFNBQVNRO0FBQUFBLGtCQUNoQixXQUFVO0FBQUEsa0JBQ1YsVUFBVXdFO0FBQUFBLGtCQUVWO0FBQUEsMkNBQUMsWUFBTyxPQUFNLElBQUcsMEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJCO0FBQUEsb0JBQzFCL0Ysa0JBQWtCb0Q7QUFBQUEsc0JBQUksQ0FBQ2lHLFVBQ3RCLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU1sSixPQUNsQ2tKLGdCQUFNbkosU0FESW1KLE1BQU1wSixLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBO0FBQUEsZ0JBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYUE7QUFBQSxjQUNDWSxPQUFPVSxxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZWLGlCQUFPVSxxQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFDQzNCLG1CQUNDLG1DQUNFO0FBQUEscUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFhO0FBQUE7QUFBQSxrQkFGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsTUFBSztBQUFBLG9CQUNMLE9BQU9FO0FBQUFBLG9CQUNQLGFBQVk7QUFBQSxvQkFDWixVQUFVOEg7QUFBQUE7QUFBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU95QztBQUFBLG1CQWQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGNBQ0MvRyxPQUFPVSxxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZWLGlCQUFPVSxxQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUJBO0FBQUEsWUFFRix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU07QUFBQTtBQUFBLGdCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTTtBQUFBLGtCQUNOLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILE1BQUs7QUFBQSxrQkFDTCxPQUFPUixTQUFTUztBQUFBQSxrQkFDaEIsYUFBWTtBQUFBLGtCQUNaLFVBQVV1RTtBQUFBQTtBQUFBQSxnQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FReUI7QUFBQSxpQkFmM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiLGlDQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFBaUJyRyx1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEM7QUFBQSxpQkFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHVDQUFDLG9CQUFpQixPQUFNLFNBQVEsV0FBVSxhQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRDtBQUFBLGdCQUNuRCx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLHdCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNqQztBQUFBQSxvQkFDVCxXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR3dGO0FBQUEsZ0JBRXhGLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsaUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNZixhQUFhLEtBQUs7QUFBQSxrQkFDakMsV0FBVTtBQUFBLGtCQUE2RTtBQUFBO0FBQUEsZ0JBSHpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FDQSx1QkFBQyxXQUFRLE9BQU0sc0JBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDeUc7QUFBQTtBQUFBLGdCQUhySDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxlQXhZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlZQTtBQUFBLGFBN1lGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4WUE7QUFBQTtBQUFBLE1BdlpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXdaQTtBQUFBLE9BdmVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3ZUEsS0F6ZUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBlQSxLQTllSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ2ZBO0FBRUo7QUFBRTNCLEdBMTBDSUQsY0FBWTtBQUFBLFVBQ1FKLFNBQVM7QUFBQTtBQUFBNE8sS0FEN0J4TztBQTQwQ04sZUFBZUE7QUFBYSxJQUFBd087QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsImFwaSIsIk1vZGFsIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJDaXJjdWxhckxvYWRlciIsIkZhV2hhdHNhcHBTcXVhcmUiLCJOYXZiYXIiLCJTZWxlY3QiLCJBbnRNb2RhbCIsIkRyYXdlciIsIlRvb2x0aXAiLCJ1c2VQYXJhbXMiLCJCYWNrZHJvcEJsdXJMb2FkZXIiLCJGYVJlY2VpcHQiLCJmaWVsZFNpemUiLCJQYXlPdXRSZXBvcnQiLCJfcyIsInBheW1lbnRUeXBlIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiYWN0dWFsR3JvdXBzIiwic2V0QWN0dWFsR3JvdXBzIiwic2VsZWN0ZWRHcm91cCIsInNldFNlbGVjdGVkR3JvdXAiLCJUYWJsZVBheW1lbnRzIiwic2V0VGFibGVQYXltZW50cyIsInNlbGVjdGVkQXVjdGlvbkdyb3VwIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXAiLCJzZWxlY3RlZEdyb3VwSWQiLCJzZXRTZWxlY3RlZEdyb3VwSWQiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwidXNlck5hbWUiLCJzZXRVc2VyTmFtZSIsInZpZXdMb2FkZXIiLCJzZXRWaWV3TG9hZGVyIiwiZmlsdGVyZWRBdWN0aW9uIiwic2V0RmlsdGVyZWRBdWN0aW9uIiwiZ3JvdXBJbmZvIiwic2V0R3JvdXBJbmZvIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwiY3VycmVudFVwZGF0ZUFtb3VudCIsInNldEN1cnJlbnRVcGRhdGVBbW91bnQiLCJjdXJyZW50R3JvdXAiLCJzZXRDdXJyZW50R3JvdXAiLCJzaG93TW9kYWxWaWV3Iiwic2V0U2hvd01vZGFsVmlldyIsImN1cnJlbnRWaWV3R3JvdXAiLCJzZXRDdXJyZW50Vmlld0dyb3VwIiwic2hvd1VwbG9hZE1vZGFsIiwic2V0U2hvd1VwbG9hZE1vZGFsIiwicmVjZWlwdE5vIiwic2V0UmVjZWlwdE5vIiwid2hhdHNhcHBFbmFibGUiLCJwYXltZW50TW9kZSIsInNldFBheW1lbnRNb2RlIiwidG9kYXkiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZGlzYWJsZWQiLCJzZXREaXNhYmxlZCIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0Iiwic2hvd1VwZGF0ZU1vZGFsIiwic2V0U2hvd1VwZGF0ZU1vZGFsIiwiZW5hYmxlR3JvdXBDb2x1bW4iLCJzZXRFbmFibGVHcm91cENvbHVtbiIsInBheW1lbnRHcm91cFRpY2tldHMiLCJzZXRQYXltZW50R3JvdXBUaWNrZXRzIiwicmVuZGVyIiwic2V0UmVyZW5kZXIiLCJvcGVuQmFja2Ryb3BMb2FkZXIiLCJzZXRPcGVuQmFja2Ryb3BMb2FkZXIiLCJjdXJyZW50R3JvdXBJZCIsInNldEN1cnJlbnRHcm91cElkIiwib3BlbkFudEREcmF3ZXIiLCJzZXRPcGVuQW50RERyYXdlciIsInNob3dMb2FkZXIiLCJzZXRTaG93TG9hZGVyIiwibGFzdFRocmVlUGF5bWVudHMiLCJzZXRMYXN0VGhyZWVQYXltZW50cyIsImFkbWluTmFtZSIsInNldEFkbWluTmFtZSIsInNob3dPdGhlcnNGaWVsZCIsInNldFNob3dPdGhlcnNGaWVsZCIsImRpc2J1cnNlbWVudFR5cGUiLCJzZXREaXNidXJzZW1lbnRUeXBlIiwiZGlzYnVyc2VtZW50VHlwZXMiLCJrZXkiLCJ0aXRsZSIsInZhbHVlIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsIm5vUmVsb2FkIiwidHlwZSIsImVycm9ycyIsInNldEVycm9ycyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ1c2VyX2lkIiwicGF5X2RhdGUiLCJhbW91bnQiLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwicGF5bWVudF9ncm91cF90aWNrZXRzIiwiZGlzYnVyc2VtZW50X3R5cGUiLCJub3RlIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsIm1vZGlmeVBheW1lbnQiLCJzZXRNb2RpZnlQYXltZW50IiwidXNlciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyT2JqIiwiSlNPTiIsInBhcnNlIiwibmFtZSIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsImFjY2Vzc19wZXJtaXNzaW9ucyIsImVkaXRfcGF5bWVudCIsImlzTW9kaWZ5IiwidXNyIiwiYWRtaW5fdHlwZSIsImNvbnNvbGUiLCJlcnJvciIsImZldGNoQWxsUGF5bWVudHNSZXBvcnQiLCJncm91cElkIiwidXJsIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwibGVuZ3RoIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJfaWQiLCJpZCIsImZ1bGxfbmFtZSIsInBob25lX251bWJlciIsInRpY2tldCIsInJlY2VpcHQiLCJyZWNlaXB0X25vIiwib2xkX3JlY2VpcHQiLCJvbGRfcmVjZWlwdF9ubyIsImRhdGUiLCJ0cmFuc2FjdGlvbl9kYXRlIiwiY3JlYXRlZEF0IiwiZGlzYnVyc2VkX2J5IiwiYWRtaW5fbmFtZSIsInBhcmFtcyIsInBheV9mb3IiLCJzdWNjZXNzIiwic3VtbWFyeSIsIm1lcmdlZFBheW1lbnRzIiwiYWxsUGF5bWVudHMiLCJjb21taXNzaW9uUGF5bWVudHMiLCJzYWxhcnlQYXltZW50cyIsInBldHR5Q2FzaFBheW1lbnRzIiwiZm9ybWF0UGF5RGF0ZSIsImxvZyIsImZldGNoTGFzdFRocmVlVHJhbnNhY3Rpb25zIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxpbWl0IiwiZmV0Y2hHcm91cHMiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJjdXN0b21lciIsInBhcnNlRmxvYXQiLCJpc05hTiIsInRyaW0iLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlQ2hhbmdlIiwicHJldkRhdGEiLCJoYW5kbGVQYXltZW50QW50U2VsZWN0IiwidmFsdWVzIiwiaGFuZGxlR3JvdXBDaGFuZ2UiLCJjb2x1bW5zIiwiaGVhZGVyIiwicHVzaCIsImhhbmRsZUN1c3RvbWVyIiwicHJldkZvcm1EYXRhIiwiaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlIiwiaGFuZGxlR3JvdXBQYXltZW50IiwiaGFuZGxlR3JvdXBQYXltZW50Q2hhbmdlIiwiZGF0ZVN0cmluZyIsImhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlIiwic2VsZWN0ZWRNb2RlIiwiaGFuZGxlU3VibWl0IiwiaXNWYWxpZCIsInByZXYiLCJwYXlsb2FkIiwicG9zdCIsInN0YXR1cyIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZUF1Y3Rpb24iLCJkZWxldGUiLCJoYW5kbGVWaWV3TW9kYWxPcGVuIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlVXBkYXRlIiwicHV0IiwiaGFuZGxlRGlzYnVyc2VtZW50VHlwZUNoYW5nZSIsInZhbGlkQXVjdGlvbnMiLCJmaWx0ZXIiLCJhdWN0aW9uIiwiZW5yb2xsbWVudCIsInNlbGVjdGVkbmV3R3JvdXAiLCJmaW5kIiwiZyIsInRvVXBwZXJDYXNlIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInVuZGVmaW5lZCIsIml0ZW0iLCJzb21lIiwiU3RyaW5nIiwicGF5bWVudCIsImhlaWdodCIsImVudHJ5IiwiZ3JvdXBOYW1lIiwidGlja2V0cyIsIk51bWJlciIsImRUeXBlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGF5b3V0UmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHBTcXVhcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIE1vZGFsIGFzIEFudE1vZGFsLCBEcmF3ZXIsIFRvb2x0aXAgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgQmFja2Ryb3BCbHVyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQmFja2Ryb3BCbHVyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhUmVjZWlwdCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuXHJcbmNvbnN0IFBheU91dFJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCB7IHBheW1lbnRUeXBlIH0gPSB1c2VQYXJhbXMoKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthY3R1YWxHcm91cHMsIHNldEFjdHVhbEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW1RhYmxlUGF5bWVudHMsIHNldFRhYmxlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFVzZXJzLCBzZXRGaWx0ZXJlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdXNlck5hbWUsIHNldFVzZXJOYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt2aWV3TG9hZGVyLCBzZXRWaWV3TG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZmlsdGVyZWRBdWN0aW9uLCBzZXRGaWx0ZXJlZEF1Y3Rpb25dID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEluZm8sIHNldEdyb3VwSW5mb10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsRGVsZXRlLCBzZXRTaG93TW9kYWxEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlQW1vdW50LCBzZXRDdXJyZW50VXBkYXRlQW1vdW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwLCBzZXRDdXJyZW50R3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFZpZXcsIHNldFNob3dNb2RhbFZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Vmlld0dyb3VwLCBzZXRDdXJyZW50Vmlld0dyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93VXBsb2FkTW9kYWwsIHNldFNob3dVcGxvYWRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlY2VpcHRObywgc2V0UmVjZWlwdE5vXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IHdoYXRzYXBwRW5hYmxlID0gdHJ1ZTtcclxuICBjb25zdCBbcGF5bWVudE1vZGUsIHNldFBheW1lbnRNb2RlXSA9IHVzZVN0YXRlKFwiY2FzaFwiKTtcclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Rpc2FibGVkLCBzZXREaXNhYmxlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dVcGRhdGVNb2RhbCwgc2V0U2hvd1VwZGF0ZU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZW5hYmxlR3JvdXBDb2x1bW4sIHNldEVuYWJsZUdyb3VwQ29sdW1uXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtwYXltZW50R3JvdXBUaWNrZXRzLCBzZXRQYXltZW50R3JvdXBUaWNrZXRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcmVuZGVyLCBzZXRSZXJlbmRlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbb3BlbkJhY2tkcm9wTG9hZGVyLCBzZXRPcGVuQmFja2Ryb3BMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50R3JvdXBJZCwgc2V0Q3VycmVudEdyb3VwSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW29wZW5BbnRERHJhd2VyLCBzZXRPcGVuQW50RERyYXdlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dMb2FkZXIsIHNldFNob3dMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsYXN0VGhyZWVQYXltZW50cywgc2V0TGFzdFRocmVlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd090aGVyc0ZpZWxkLCBzZXRTaG93T3RoZXJzRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtkaXNidXJzZW1lbnRUeXBlLCBzZXREaXNidXJzZW1lbnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IGRpc2J1cnNlbWVudFR5cGVzID0gW1xyXG4gICAge1xyXG4gICAgICBrZXk6IFwiIzFcIixcclxuICAgICAgdGl0bGU6IFwiQ2hpdCBDYW5jZWxsYXRpb25cIixcclxuICAgICAgdmFsdWU6IFwiQ2hpdCBDYW5jZWxsYXRpb25cIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIjMlwiLFxyXG4gICAgICB0aXRsZTogXCJSZWZ1bmQgdG8gTWVtYmVyXCIsXHJcbiAgICAgIHZhbHVlOiBcIlJlZnVuZCB0byBNZW1iZXJcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIjM1wiLFxyXG4gICAgICB0aXRsZTogXCJGb3JlbWFuIENvbW1pc3Npb24gRGlzYnVyc2VtZW50XCIsXHJcbiAgICAgIHZhbHVlOiBcIlJlZnVuZCB0byBNZW1iZXJcIixcclxuICAgIH0sXHJcblxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiIzRcIixcclxuICAgICAgdGl0bGU6IFwiUmVpbnZlc3RtZW50IFRyYW5zZmVyXCIsXHJcbiAgICAgIHZhbHVlOiBcIlJlaW52ZXN0bWVudCBUcmFuc2ZlclwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiM1XCIsXHJcbiAgICAgIHRpdGxlOiBcIkFkdmFuY2UgUGF5b3V0IEJlZm9yZSBBdWN0aW9uXCIsXHJcbiAgICAgIHZhbHVlOiBcIkFkdmFuY2UgUGF5b3V0IEJlZm9yZSBBdWN0aW9uXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiIzZcIixcclxuICAgICAgdGl0bGU6IFwiRGl2aWRlbnQgU2hhcmUgRGlzYnVyc2VtZW50XCIsXHJcbiAgICAgIHZhbHVlOiBcIkRpdmlkZW50IFNoYXJlIERpc2J1cnNlbWVudFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiM3XCIsXHJcbiAgICAgIHRpdGxlOiBcIkdyb3VwIENsb3N1cmUgU2V0dGxlbWVudFwiLFxyXG4gICAgICB2YWx1ZTogXCJHcm91cCBDbG9zdXJlIFNldHRsZW1lbnRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIjOFwiLFxyXG4gICAgICB0aXRsZTogXCJFbWVyZ2VuY3kgV2l0aGRyYXdhbFwiLFxyXG4gICAgICB2YWx1ZTogXCJFbWVyZ2VuY3kgV2l0aGRyYXdhbFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiM5XCIsXHJcbiAgICAgIHRpdGxlOiBcIk1pc3Rha2VuIFBheW1lbnQgUmV2ZXJzYWxcIixcclxuICAgICAgdmFsdWU6IFwiTWlzdGFrZW4gUGF5bWVudCBSZXZlcnNhbFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiMxMFwiLFxyXG4gICAgICB0aXRsZTogXCJPdGhlcnNcIixcclxuICAgICAgdmFsdWU6IFwiT3RoZXJzXCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICBub1JlbG9hZDogZmFsc2UsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHVzZXJfaWQ6IFwiXCIsXHJcblxyXG4gICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICBwYXltZW50X2dyb3VwX3RpY2tldHM6IFtdLFxyXG4gICAgZGlzYnVyc2VtZW50X3R5cGU6IFwiXCIsXHJcbiAgICBub3RlOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X2RhdGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW21vZGlmeVBheW1lbnQsIHNldE1vZGlmeVBheW1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG4gICAgc2V0QWRtaW5OYW1lKHVzZXJPYmo/Lm5hbWUgfHwgXCJcIik7XHJcblxyXG4gICAgaWYgKFxyXG4gICAgICB1c2VyT2JqICYmXHJcbiAgICAgIHVzZXJPYmo/LmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnRcclxuICAgICkge1xyXG4gICAgICBjb25zdCBpc01vZGlmeSA9XHJcbiAgICAgICAgdXNlck9iaj8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudCA9PT1cclxuICAgICAgICBcInRydWVcIlxyXG4gICAgICAgICAgPyB0cnVlXHJcbiAgICAgICAgICA6IGZhbHNlO1xyXG4gICAgICBzZXRNb2RpZnlQYXltZW50KGlzTW9kaWZ5KTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c3IgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgYWRtaW5fdHlwZSA9IG51bGw7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKHVzcikge1xyXG4gICAgICAgIGFkbWluX3R5cGUgPSBKU09OLnBhcnNlKHVzcik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBwYXJzZSB1c2VyIGZyb20gbG9jYWxTdG9yYWdlOlwiLCBlKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBjb25zdCBmZXRjaFRvZGF5c1BheW1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgLy8gICB0cnkge1xyXG4gICAgLy8gICAgIHNldFRhYmxlUGF5bWVudHMoW10pO1xyXG4gICAgLy8gICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIC8vICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAvLyAgICAgICBcIi9wYXltZW50LW91dC9nZXQtcGF5bWVudC1vdXQtcmVwb3J0LWRheWJvb2tcIixcclxuICAgIC8vICAgICAgIHtcclxuICAgIC8vICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAvLyAgICAgICAgICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgLy8gICAgICAgICAgLy8gcGF5X2ZvcjogcGF5bWVudFR5cGUsXHJcbiAgICAvLyAgICAgICAgIH0sXHJcbiAgICAvLyAgICAgICB9XHJcbiAgICAvLyAgICAgKTtcclxuICAgIC8vICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgIC8vICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAvLyAgICAgICAgIGlmICghZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lKSByZXR1cm4ge307XHJcbiAgICAvLyAgICAgICAgIHJldHVybiB7XHJcbiAgICAvLyAgICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAvLyAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgIC8vICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgLy8gICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgIC8vICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAvLyAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXQsXHJcbiAgICAvLyAgICAgICAgICAgcmVjZWlwdDogZ3JvdXAucmVjZWlwdF9ubyxcclxuICAgIC8vICAgICAgICAgICBvbGRfcmVjZWlwdDogZ3JvdXAub2xkX3JlY2VpcHRfbm8sXHJcbiAgICAvLyAgICAgICAgICAgYW1vdW50OiBncm91cC5hbW91bnQsXHJcbiAgICAvLyAgICAgICAgICAgZGF0ZTogZm9ybWF0UGF5RGF0ZShncm91cC5wYXlfZGF0ZSksXHJcbiAgICAvLyAgICAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTogZm9ybWF0UGF5RGF0ZShncm91cC5jcmVhdGVkQXQpLFxyXG4gICAgLy8gICAgICAgICAgIGRpc2J1cnNlZF9ieTogZ3JvdXA/LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHwgXCJTdXBlciBBZG1pblwiLFxyXG4gICAgLy8gICAgICAgICAgIGRpc2J1cnNlbWVudF90eXBlOiBncm91cC5kaXNidXJzZW1lbnRfdHlwZSxcclxuICAgIC8vICAgICAgICAgICBub3RlOiBncm91cC5ub3RlLFxyXG4gICAgLy8gICAgICAgICB9O1xyXG4gICAgLy8gICAgICAgfSk7XHJcbiAgICAvLyAgICAgICBzZXRUYWJsZVBheW1lbnRzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgLy8gICAgICAgc2V0RW5hYmxlR3JvdXBDb2x1bW4odHJ1ZSk7XHJcbiAgICAvLyAgICAgfSBlbHNlIHtcclxuICAgIC8vICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgLy8gICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgIC8vICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgLy8gICB9IGZpbmFsbHkge1xyXG4gICAgLy8gICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAvLyAgIH1cclxuICAgIC8vIH07XHJcblxyXG4gICAgLy9mZXRjaFRvZGF5c1BheW1lbnRzKCk7XHJcbiAgICAvLyAgIGNvbnN0IGZldGNoQWxsUGF5bWVudHNSZXBvcnQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyAgICAgdHJ5IHtcclxuICAgIC8vICAgICAgIHNldFRhYmxlUGF5bWVudHMoW10pO1xyXG4gICAgLy8gICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIC8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9wYXltZW50LW91dC9nZXQtYWxsLXBheW1lbnQtb3V0LXJlcG9ydFwiLCB7XHJcbiAgICAvLyAgICAgICAgIHBhcmFtczoge1xyXG4gICAgLy8gICAgICAgICAgLy8gZnJvbV9kYXRlOiB0b2RheSxcclxuICAgIC8vICAgICAgICAgIC8vIHRvX2RhdGU6IHRvZGF5LFxyXG4gICAgLy8gICAgICAgICAgIHBheV9mb3I6IHBheW1lbnRUeXBlLFxyXG4gICAgLy8gICAgICAgICB9LFxyXG4gICAgLy8gICAgICAgfSk7XHJcblxyXG4gICAgLy8gICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnN1Y2Nlc3MpIHtcclxuICAgIC8vICAgICAgICAgY29uc3QgeyBkYXRhLCBzdW1tYXJ5IH0gPSByZXNwb25zZS5kYXRhO1xyXG5cclxuICAgIC8vICAgICAgICAgLy8gTWVyZ2UgYWxsIHBheW1lbnRzIGludG8gb25lIGFycmF5XHJcbiAgICAvLyAgICAgICAgIGNvbnN0IG1lcmdlZFBheW1lbnRzID0gW1xyXG4gICAgLy8gICAgICAgICAgIC4uLmRhdGEuYWxsUGF5bWVudHMsXHJcbiAgICAvLyAgICAgICAgICAgLi4uZGF0YS5jb21taXNzaW9uUGF5bWVudHMsXHJcbiAgICAvLyAgICAgICAgICAgLi4uZGF0YS5zYWxhcnlQYXltZW50cyxcclxuICAgIC8vICAgICAgICAgICAuLi5kYXRhLnBldHR5Q2FzaFBheW1lbnRzLFxyXG4gICAgLy8gICAgICAgICAgLy8gLi4uZGF0YS5hdWN0aW9uV2lubmluZ1BheW1lbnRzLFxyXG4gICAgLy8gICAgICAgICBdO1xyXG5cclxuICAgIC8vICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IG1lcmdlZFBheW1lbnRzLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4gICAgLy8gICBfaWQ6IGdyb3VwLl9pZCxcclxuICAgIC8vICAgaWQ6IGluZGV4ICsgMSxcclxuICAgIC8vICAgbmFtZTogZ3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIi1cIixcclxuICAgIC8vICAgcGhvbmVfbnVtYmVyOiBncm91cD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgLy8gICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbiAgICAvLyAgIHRpY2tldDogZ3JvdXAudGlja2V0IHx8IFwiLVwiLFxyXG4gICAgLy8gICByZWNlaXB0OiBncm91cC5yZWNlaXB0X25vIHx8IFwiLVwiLFxyXG4gICAgLy8gICBvbGRfcmVjZWlwdDogZ3JvdXAub2xkX3JlY2VpcHRfbm8gfHwgXCItXCIsXHJcbiAgICAvLyAgIGFtb3VudDogZ3JvdXAuYW1vdW50IHx8IDAsXHJcbiAgICAvLyAgIGRhdGU6IGZvcm1hdFBheURhdGUoZ3JvdXAucGF5X2RhdGUpLFxyXG4gICAgLy8gICB0cmFuc2FjdGlvbl9kYXRlOiBmb3JtYXRQYXlEYXRlKGdyb3VwLmNyZWF0ZWRBdCksXHJcbiAgICAvLyAgIGRpc2J1cnNlZF9ieTogZ3JvdXA/LmFkbWluX3R5cGU/LmZ1bGxfbmFtZSB8fCBcIlN1cGVyIEFkbWluXCIsXHJcbiAgICAvLyAgIGRpc2J1cnNlbWVudF90eXBlOiBncm91cC5kaXNidXJzZW1lbnRfdHlwZSB8fCBcIi1cIixcclxuICAgIC8vICAgbm90ZTogZ3JvdXAubm90ZSB8fCBcIi1cIixcclxuICAgIC8vIH0pKTtcclxuXHJcbiAgICAvLyAgICAgICAgIHNldFRhYmxlUGF5bWVudHMoZm9ybWF0dGVkRGF0YSk7XHJcblxyXG4gICAgLy8gICAgICAgICAvLyDinIUgT3B0aW9uYWw6IFNob3cgdG90YWxzIHNvbWV3aGVyZVxyXG4gICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIlN1bW1hcnk6XCIsIHN1bW1hcnkpO1xyXG4gICAgLy8gICAgICAgfSBlbHNlIHtcclxuICAgIC8vICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgIC8vICAgICAgIH1cclxuICAgIC8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFsbCBwYXltZW50IHJlcG9ydDpcIiwgZXJyb3IpO1xyXG4gICAgLy8gICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgIC8vICAgICB9IGZpbmFsbHkge1xyXG4gICAgLy8gICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyAgIH07XHJcbiAgICBjb25zdCBmZXRjaEFsbFBheW1lbnRzUmVwb3J0ID0gYXN5bmMgKGdyb3VwSWQgPSBudWxsKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0VGFibGVQYXltZW50cyhbXSk7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICAgICAgLy8g4pyFIEdyb3VwLXdpc2UgcGF5bWVudHNcclxuICAgICAgICAgIC8vY29uc3QgdXJsID0gYC9wYXltZW50LW91dC9nZXQtZ3JvdXAtcGF5bWVudC1vdXQvP2dyb3VwX2lkPSR7Z3JvdXBJZH0mcGF5X2Zvcj0ke3BheW1lbnRUeXBlfWA7XHJcbiAgICAgICAgICBsZXQgdXJsID0gYC9wYXltZW50LW91dC9nZXQtZ3JvdXAtcGF5bWVudC1vdXQvP2dyb3VwX2lkPSR7Z3JvdXBJZH1gO1xyXG4gICAgICAgICAgaWYgKHBheW1lbnRUeXBlKSB7XHJcbiAgICAgICAgICAgIHVybCArPSBgJnBheV9mb3I9JHtwYXltZW50VHlwZX1gO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc2V0RW5hYmxlR3JvdXBDb2x1bW4oZmFsc2UpO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG5cclxuICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmICghZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lKSByZXR1cm4ge307XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4gICAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICAgIG5hbWU6IGdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICB0aWNrZXQ6IGdyb3VwLnRpY2tldCB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgIHJlY2VpcHQ6IGdyb3VwLnJlY2VpcHRfbm8gfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICBvbGRfcmVjZWlwdDogZ3JvdXAub2xkX3JlY2VpcHRfbm8gfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICBhbW91bnQ6IGdyb3VwLmFtb3VudCB8fCAwLFxyXG4gICAgICAgICAgICAgICAgZGF0ZTogZ3JvdXA/LnBheV9kYXRlID8gZ3JvdXAucGF5X2RhdGUuc3BsaXQoXCJUXCIpWzBdIDogXCItXCIsXHJcbiAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBncm91cD8uY3JlYXRlZEF0XHJcbiAgICAgICAgICAgICAgICAgID8gZ3JvdXAuY3JlYXRlZEF0LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgICA6IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgZGlzYnVyc2VkX2J5OiBncm91cD8uYWRtaW5fdHlwZT8uYWRtaW5fbmFtZSB8fCBcIlN1cGVyIEFkbWluXCIsXHJcbiAgICAgICAgICAgICAgICBkaXNidXJzZW1lbnRfdHlwZTogZ3JvdXA/LmRpc2J1cnNlbWVudF90eXBlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgbm90ZTogZ3JvdXAubm90ZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIC8vIOKchSBBbGwgcGF5bWVudHNcclxuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgICAgXCIvcGF5bWVudC1vdXQvZ2V0LWFsbC1wYXltZW50LW91dC1yZXBvcnRcIixcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgcGF5X2ZvcjogcGF5bWVudFR5cGUsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8uc3VjY2Vzcykge1xyXG4gICAgICAgICAgICBjb25zdCB7IGRhdGEsIHN1bW1hcnkgfSA9IHJlc3BvbnNlLmRhdGE7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBtZXJnZWRQYXltZW50cyA9IFtcclxuICAgICAgICAgICAgICAuLi5kYXRhLmFsbFBheW1lbnRzLFxyXG4gICAgICAgICAgICAgIC4uLmRhdGEuY29tbWlzc2lvblBheW1lbnRzLFxyXG4gICAgICAgICAgICAgIC4uLmRhdGEuc2FsYXJ5UGF5bWVudHMsXHJcbiAgICAgICAgICAgICAgLi4uZGF0YS5wZXR0eUNhc2hQYXltZW50cyxcclxuICAgICAgICAgICAgICAvLyAuLi5kYXRhLmF1Y3Rpb25XaW5uaW5nUGF5bWVudHMsXHJcbiAgICAgICAgICAgIF07XHJcblxyXG4gICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gbWVyZ2VkUGF5bWVudHMubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXQgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdDogZ3JvdXAucmVjZWlwdF9ubyB8fCBcIi1cIixcclxuICAgICAgICAgICAgICBvbGRfcmVjZWlwdDogZ3JvdXAub2xkX3JlY2VpcHRfbm8gfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBncm91cC5hbW91bnQgfHwgMCxcclxuICAgICAgICAgICAgICBkYXRlOiBmb3JtYXRQYXlEYXRlKGdyb3VwLnBheV9kYXRlKSxcclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBmb3JtYXRQYXlEYXRlKGdyb3VwLmNyZWF0ZWRBdCksXHJcbiAgICAgICAgICAgICAgZGlzYnVyc2VkX2J5OiBncm91cD8uYWRtaW5fdHlwZT8uZnVsbF9uYW1lIHx8IFwiU3VwZXIgQWRtaW5cIixcclxuICAgICAgICAgICAgICBkaXNidXJzZW1lbnRfdHlwZTogZ3JvdXAuZGlzYnVyc2VtZW50X3R5cGUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgbm90ZTogZ3JvdXAubm90ZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJTdW1tYXJ5OlwiLCBzdW1tYXJ5KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwYXltZW50IHJlcG9ydDpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaEFsbFBheW1lbnRzUmVwb3J0KCk7XHJcbiAgfSwgW3JlbmRlcl0pO1xyXG5cclxuICBjb25zdCBmZXRjaExhc3RUaHJlZVRyYW5zYWN0aW9ucyA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNldE9wZW5BbnRERHJhd2VyKHRydWUpO1xyXG4gICAgaWYgKGZvcm1EYXRhLnVzZXJfaWQgJiYgZm9ybURhdGEucGF5bWVudF9ncm91cF90aWNrZXRzKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0U2hvd0xvYWRlcih0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCJwYXltZW50LW91dC9nZXQtbGFzdC1uLXRyYW5zYWN0aW9uXCIsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICB1c2VyX2lkOiBmb3JtRGF0YS51c2VyX2lkLFxyXG4gICAgICAgICAgICBwYXltZW50X2dyb3VwX3RpY2tldHM6IHBheW1lbnRHcm91cFRpY2tldHMsXHJcbiAgICAgICAgICAgIGxpbWl0OiAzLFxyXG4gICAgICAgICAgICBwYXlfZm9yOiBwYXltZW50VHlwZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlPy5kYXRhKSB7XHJcbiAgICAgICAgICBzZXRMYXN0VGhyZWVQYXltZW50cyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0TGFzdFRocmVlUGF5bWVudHMoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRMYXN0VGhyZWVQYXltZW50cyhbXSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0U2hvd0xvYWRlcihmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFthbGVydENvbmZpZ10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1hbGwtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0QWN0dWFsR3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFthbGVydENvbmZpZ10pO1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuXHJcbiAgICBpZiAoIXNlbGVjdGVkR3JvdXBJZCkge1xyXG4gICAgICBuZXdFcnJvcnMuY3VzdG9tZXIgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZm9ybURhdGEucGF5bWVudF9ncm91cF90aWNrZXRzKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHMgPSBcIlBsZWFzZSBzZWxlY3QgYSBncm91cCBhbmQgdGlja2V0XCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5wYXlfZGF0ZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGF5X2RhdGUgPSBcIlBheW1lbnQgZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlRmxvYXQoZm9ybURhdGEuYW1vdW50KTtcclxuICAgIGlmIChpc05hTihhbW91bnQpIHx8IGFtb3VudCA8PSAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIHBvc2l0aXZlIGFtb3VudFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJvbmxpbmVcIiAmJiAhZm9ybURhdGEudHJhbnNhY3Rpb25faWQ/LnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPVxyXG4gICAgICAgIFwiVHJhbnNhY3Rpb24gSUQgaXMgcmVxdWlyZWQgZm9yIG9ubGluZSBwYXltZW50c1wiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFmb3JtRGF0YS5kaXNidXJzZW1lbnRfdHlwZSkge1xyXG4gICAgICBuZXdFcnJvcnMuZGlzYnVyc2VtZW50X3R5cGUgPSBcIkRpc2J1cnNlbWVudCBUeXBlIGlzIFJlcXVpcmVkXCI7XHJcbiAgICB9XHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBpZiAobmFtZSA9PT0gXCJkaXNidXJzZW1lbnRfdHlwZVwiKSB7XHJcbiAgICAgIGlmICh2YWx1ZSA9PT0gXCJPdGhlcnNcIikge1xyXG4gICAgICAgIHNldFNob3dPdGhlcnNGaWVsZCh0cnVlKTtcclxuICAgICAgICBzZXREaXNidXJzZW1lbnRUeXBlKFwiXCIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldFNob3dPdGhlcnNGaWVsZChmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoeyAuLi5wcmV2RGF0YSwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50QW50U2VsZWN0ID0gKHZhbHVlcykgPT4ge1xyXG4gICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyh2YWx1ZXMpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQ2hhbmdlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkR3JvdXAoZ3JvdXBJZCk7XHJcblxyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9lbnJvbGwvZ2V0LWdyb3VwLWVucm9sbC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJQYWlkIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICBdO1xyXG4gIGlmIChlbmFibGVHcm91cENvbHVtbikge1xyXG4gICAgY29sdW1ucy5wdXNoKHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9KTtcclxuICB9XHJcbiAgY29sdW1ucy5wdXNoKFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXQgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcIm9sZF9yZWNlaXB0XCIsIGhlYWRlcjogXCJPbGQgUmVjZWlwdFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0XCIsIGhlYWRlcjogXCJSZWNlaXB0XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImRpc2J1cnNlZF9ieVwiLCBoZWFkZXI6IFwiRGlzYnVyc2VkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcImRpc2J1cnNlbWVudF90eXBlXCIsIGhlYWRlcjogXCJEaXNidXJzZW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJub3RlXCIsIGhlYWRlcjogXCJOb3RlXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfVxyXG4gICk7XHJcbiAgLy8gY29uc3QgaGFuZGxlR3JvdXAgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAvLyAgIGNvbnN0IGdyb3VwSWQgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgLy8gICBzZXRTZWxlY3RlZEdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgLy8gICBzZXRGb3JtRGF0YSgocHJldkZvcm1EYXRhKSA9PiAoe1xyXG4gIC8vICAgICAuLi5wcmV2Rm9ybURhdGEsXHJcbiAgLy8gICAgIHVzZXJfaWQ6IGdyb3VwSWQsXHJcbiAgLy8gICB9KSk7XHJcbiAgLy8gICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoeyAuLi5wcmV2RGF0YSwgY3VzdG9tZXI6IFwiXCIgfSkpO1xyXG5cclxuICAvLyAgIGhhbmRsZUdyb3VwQ2hhbmdlKGdyb3VwSWQpO1xyXG4gIC8vICAgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlKGdyb3VwSWQpO1xyXG5cclxuICAvLyAgIGlmIChncm91cElkKSB7XHJcbiAgLy8gICAgIHRyeSB7XHJcbiAgLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZ3JvdXAvZ2V0LWJ5LWlkLWdyb3VwLyR7Z3JvdXBJZH1gKTtcclxuICAvLyAgICAgICBzZXRHcm91cEluZm8ocmVzcG9uc2UuZGF0YSB8fCB7fSk7XHJcbiAgLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgLy8gICAgICAgc2V0R3JvdXBJbmZvKHt9KTtcclxuICAvLyAgICAgfVxyXG4gIC8vICAgfSBlbHNlIHtcclxuICAvLyAgICAgc2V0R3JvdXBJbmZvKHt9KTtcclxuICAvLyAgIH1cclxuICAvLyB9O1xyXG5cclxuICAvLyBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChlKSA9PiB7XHJcbiAgLy8gICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAvLyAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAvLyAgICAgLi4ucHJldkRhdGEsXHJcbiAgLy8gICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgLy8gICB9KSk7XHJcbiAgLy8gfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ3VzdG9tZXIgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cElkKGdyb3VwSWQpO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZGb3JtRGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkZvcm1EYXRhLFxyXG4gICAgICB1c2VyX2lkOiBncm91cElkLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RGF0YSkgPT4gKHsgLi4ucHJldkRhdGEsIGN1c3RvbWVyOiBcIlwiIH0pKTtcclxuICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgaGFuZGxlR3JvdXBDaGFuZ2UoZ3JvdXBJZCk7XHJcbiAgICBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UoZ3JvdXBJZCk7XHJcblxyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9ncm91cC9nZXQtYnktaWQtZ3JvdXAvJHtncm91cElkfWApO1xyXG4gICAgICAgIHNldEdyb3VwSW5mbyhyZXNwb25zZS5kYXRhIHx8IHt9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlR3JvdXBQYXltZW50ID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBoYW5kbGVHcm91cFBheW1lbnRDaGFuZ2UoZ3JvdXBJZCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0UGF5RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICByZXR1cm4gZGF0ZVN0cmluZz8uc3BsaXQoXCJUXCIpWzBdO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwUGF5bWVudENoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhncm91cElkLFwidGhpcyBpcyBncm91cElkXCIpXHJcbiAgICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cChncm91cElkKTtcclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIGxldCB1cmw7XHJcbiAgICAgIGlmIChncm91cElkID09PSBcInRvZGF5XCIpIHtcclxuICAgICAgICB1cmwgPSBgL3BheW1lbnQtb3V0L2dldC1wYXltZW50LW91dC1yZXBvcnQtZGF5Ym9vay8/cGF5X2RhdGU9JHt0b2RheX0mcGF5X2Zvcj0ke3BheW1lbnRUeXBlfWA7XHJcbiAgICAgICAgc2V0RW5hYmxlR3JvdXBDb2x1bW4odHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gdXJsID0gYC9wYXltZW50LW91dC9nZXQtZ3JvdXAtcGF5bWVudC1vdXQvP2dyb3VwX2lkPSR7Z3JvdXBJZH0mcGF5X2Zvcj0ke3BheW1lbnRUeXBlfWA7XHJcbiAgICAgICAgdXJsID0gYC9wYXltZW50LW91dC9nZXQtZ3JvdXAtcGF5bWVudC1vdXQvP2dyb3VwX2lkPSR7Z3JvdXBJZH1gO1xyXG4gICAgICAgIGlmIChwYXltZW50VHlwZSkge1xyXG4gICAgICAgICAgdXJsICs9IGAmcGF5X2Zvcj0ke3BheW1lbnRUeXBlfWA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldEVuYWJsZUdyb3VwQ29sdW1uKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldFRhYmxlUGF5bWVudHMoW10pO1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQodXJsKTtcclxuXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIWdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSkgcmV0dXJuIHt9O1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgbmFtZTogZ3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICAgIHRpY2tldDogZ3JvdXAudGlja2V0LFxyXG4gICAgICAgICAgICAgIHJlY2VpcHQ6IGdyb3VwLnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgb2xkX3JlY2VpcHQ6IGdyb3VwLm9sZF9yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIGFtb3VudDogZ3JvdXAuYW1vdW50LFxyXG4gICAgICAgICAgICAgIGRhdGU6IGdyb3VwPy5wYXlfZGF0ZS5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTogZ3JvdXA/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgICAgIGRpc2J1cnNlZF9ieTogZ3JvdXA/LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHwgXCJTdXBlciBBZG1pblwiLFxyXG4gICAgICAgICAgICAgIGRpc2J1cnNlbWVudF90eXBlOiBncm91cD8uZGlzYnVyc2VtZW50X3R5cGUsXHJcbiAgICAgICAgICAgICAgbm90ZTogZ3JvdXAubm90ZSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TW9kZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZE1vZGUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldFBheW1lbnRNb2RlKHNlbGVjdGVkTW9kZSk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBwYXlfdHlwZTogc2VsZWN0ZWRNb2RlLFxyXG5cclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IHNlbGVjdGVkTW9kZSA9PT0gXCJvbmxpbmVcIiA/IHByZXZEYXRhLnRyYW5zYWN0aW9uX2lkIDogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgICBzZXREaXNhYmxlZCh0cnVlKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHtcclxuICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICBsZXQgcGF5bG9hZDtcclxuICAgICAgICBjb25zdCB1c3IgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAgICAgbGV0IGFkbWluX3R5cGUgPSBudWxsO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBpZiAodXNyKSB7XHJcbiAgICAgICAgICAgIGFkbWluX3R5cGUgPSBKU09OLnBhcnNlKHVzcik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBwYXJzZSB1c2VyIGZyb20gbG9jYWxTdG9yYWdlOlwiLCBlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGZvcm1EYXRhLmRpc2J1cnNlbWVudF90eXBlID09PSBcIk90aGVyc1wiKSB7XHJcbiAgICAgICAgICBmb3JtRGF0YS5kaXNidXJzZW1lbnRfdHlwZSA9IGRpc2J1cnNlbWVudFR5cGU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvcm1EYXRhLnBheW1lbnRfZ3JvdXBfdGlja2V0cyA9IHBheW1lbnRHcm91cFRpY2tldHM7XHJcbiAgICAgICAgZm9ybURhdGEuYWRtaW5fdHlwZSA9IGFkbWluX3R5cGU/Ll9pZDtcclxuICAgICAgICBmb3JtRGF0YS5wYXlfZm9yID0gcGF5bWVudFR5cGU7XHJcbiAgICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGZvcm1EYXRhLCBcImZvcm1EYXRhIHRoaXMgaXMgZm9ybURhdGFcIik7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICAgIFwiL3BheW1lbnQtb3V0L2FkZC1wYXltZW50cy1vdXRcIixcclxuICAgICAgICAgIGZvcm1EYXRhXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAxKSB7XHJcbiAgICAgICAgICBzZXRTZWxlY3RlZEdyb3VwSWQoXCJcIik7XHJcbiAgICAgICAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKFtdKTtcclxuICAgICAgICAgIHNldERpc2FibGVkKGZhbHNlKTtcclxuICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgICAgICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgICAgICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogW10sXHJcbiAgICAgICAgICAgIGRpc2J1cnNlbWVudF90eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICBub3RlOiBcIlwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIlBheW1lbnQgQWRkZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMCkge1xyXG4gICAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgICAgICAgc2V0RGlzYWJsZWQoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfZGF0ZTogdG9kYXksXHJcbiAgICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgICAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgICAgICAgICAgZGlzYnVyc2VtZW50X3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICAgIG5vdGU6IFwiXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGF5bWVudCBBZGRlZCBGYWlsZWRcIixcclxuICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRTZWxlY3RlZEdyb3VwSWQoXCJcIik7XHJcbiAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgICAgIHBheV9kYXRlOiBcIlwiLFxyXG4gICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgICAgICBkaXNidXJzZW1lbnRfdHlwZTogXCJcIixcclxuICAgICAgICBub3RlOiBcIlwiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogYEVycm9yIHN1Ym1pdHRpbmcgcGF5bWVudCBkYXRhYCxcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXREaXNhYmxlZChmYWxzZSk7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBzdWJtaXR0aW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKGZhbHNlKTtcclxuICAgICAgc2V0UmVyZW5kZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9nZXQtcGF5bWVudC1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUF1Y3Rpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudEdyb3VwKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL3BheW1lbnQvZGVsZXRlLXBheW1lbnQvJHtjdXJyZW50R3JvdXAuX2lkfWApO1xyXG5cclxuICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJQYXltZW50IGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgYXVjdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVmlld01vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICBzZXRTaG93TW9kYWxWaWV3KHRydWUpO1xyXG4gICAgICBzZXRDdXJyZW50R3JvdXBJZChncm91cElkKTtcclxuICAgICAgc2V0Vmlld0xvYWRlcih0cnVlKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9nZXQtcGF5bWVudC1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRWaWV3R3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igdmlld2luZyBQYXltZW50OlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgc2V0Vmlld0xvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvZ2V0LXBheW1lbnQtYnktaWQvJHtncm91cElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlQW1vdW50KHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgYW1vdW50OiByZXNwb25zZT8uZGF0YT8uYW1vdW50LFxyXG4gICAgICAgIHBheV9kYXRlOiByZXNwb25zZT8uZGF0YT8ucGF5X2RhdGUuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0U2hvd1VwZGF0ZU1vZGFsKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIFBheW1lbnQgQW1vdW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkucHV0KFxyXG4gICAgICAgIGAvcGF5bWVudC91cGRhdGUtcGF5bWVudC1hbW91bnQvJHtjdXJyZW50VXBkYXRlQW1vdW50Ll9pZH1gLFxyXG4gICAgICAgIHVwZGF0ZUZvcm1EYXRhXHJcbiAgICAgICk7XHJcbiAgICAgIHNldFNob3dVcGRhdGVNb2RhbChmYWxzZSk7XHJcblxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlBheW1lbnQgQW1vdW50IFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIFBheW1lbnQgQW1vdW50OlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBlcnJvci5yZXNwb25zZSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2VcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGAke2Vycm9yPy5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZX1gLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZURpc2J1cnNlbWVudFR5cGVDaGFuZ2UgPSAoZXZlbnQpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGV2ZW50LnRhcmdldDtcclxuICAgIHNldERpc2J1cnNlbWVudFR5cGUodmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICAgIGAvZW5yb2xsL2dldC11c2VyLXRpY2tldHMtcmVwb3J0LyR7Z3JvdXBJZH1gXHJcbiAgICAgICAgKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IHZhbGlkQXVjdGlvbnMgPSByZXNwb25zZS5kYXRhLmZpbHRlcihcclxuICAgICAgICAgICAgKGF1Y3Rpb24pID0+IGF1Y3Rpb24uZW5yb2xsbWVudCAmJiBhdWN0aW9uLmVucm9sbG1lbnQuZ3JvdXBcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24odmFsaWRBdWN0aW9ucyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3Qgc2VsZWN0ZWRuZXdHcm91cCA9IGFjdHVhbEdyb3Vwcy5maW5kKFxyXG4gICAgKGcpID0+IGcuX2lkID09PSBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkXHJcbiAgKTtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAge29wZW5CYWNrZHJvcExvYWRlciA/IChcclxuICAgICAgICA8QmFja2Ryb3BCbHVyTG9hZGVyIHRpdGxlPXtcInBheW1lbnQgRGF0YSBwcm9jZXNzaW5nLi4uLlwifSAvPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICA8Q3VzdG9tQWxlcnRcclxuICAgICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgIG5vUmVsb2FkPXthbGVydENvbmZpZy5ub1JlbG9hZH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIHRleHQtcmVkLTUwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAge3BheW1lbnRUeXBlPy50b1VwcGVyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge1wiICBcIn1cclxuICAgICAgICAgICAgICAgIFBheW1lbnRzIE91dCBSZXBvcnRcclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiAgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+U2VhcmNoIG9yIFNlbGVjdCBHcm91cDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVG9kYXkncyBQYXltZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgIGgtMTQgbWF4LXctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQXVjdGlvbkdyb3VwSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e1wiIzFcIn0gdmFsdWU9e1widG9kYXlcIn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcIlBheW1lbnRzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YWN0dWFsR3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7VGFibGVQYXltZW50cyAmJiBUYWJsZVBheW1lbnRzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICBkYXRhPXtUYWJsZVBheW1lbnRzLmZpbHRlcigoaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC52YWx1ZXMoaXRlbSkuc29tZSgodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFN0cmluZyh2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhzZWFyY2hUZXh0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlBheU91dCBPdGhlcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1wiR3JvdXAgTmFtZVwiXX1cclxuICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W3NlbGVjdGVkbmV3R3JvdXA/Lmdyb3VwX25hbWVdfVxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BQYXlPdXQgT3RoZXJzLmNzdmB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YT1cIlBheW1lbnRzIERhdGFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmFpbHVyZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRhYmxlUGF5bWVudHMubGVuZ3RoIDw9IDAgJiYgc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZFxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbH1cclxuICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEdyb3VwSWQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBZGQgUGF5bWVudCBPdXRcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgICAgICA8RHJhd2VyXHJcbiAgICAgICAgICAgICAgICAgICAgY2xvc2FibGVcclxuICAgICAgICAgICAgICAgICAgICBkZXN0cm95T25IaWRkZW5cclxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17PHA+TGFzdCBUaHJlZSBUcmFuc2FjdGlvbnM8L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cInJpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICBvcGVuPXtvcGVuQW50RERyYXdlcn1cclxuICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtzaG93TG9hZGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE9wZW5BbnRERHJhd2VyKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtsYXN0VGhyZWVQYXltZW50cz8ubGVuZ3RoIDw9IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1jZW50ZXIgdGV4dC14bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBObyBUcmFuc2FjdGlvbiBGb3VuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xhc3RUaHJlZVBheW1lbnRzLm1hcCgocGF5bWVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgc2hhZG93LW1kIHJvdW5kZWQtbGcgcC00IHNwYWNlLXktMiBib3JkZXIgYm9yZGVyLWdyYXktMjAwIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50Py5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQuZ3JvdXBfaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cDp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQuZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50LnRpY2tldCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpY2tldDp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW5vcm1hbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudD8udGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheU91dCBBbW91bnQ6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e3BheW1lbnQ/LmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgVHlwZTp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ub3JtYWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50Py5wYXlfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5hbWU6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbm9ybWFsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC51c2VyX2lkPy5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvRHJhd2VyPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsICR7ZmllbGRTaXplLmhlaWdodH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cElkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHtncm91cC5mdWxsX25hbWV9IHwgJHtncm91cC5waG9uZV9udW1iZXJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY3VzdG9tZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmN1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXAgJiBUaWNrZXQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwIHwgVGlja2V0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50QW50U2VsZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRHcm91cFRpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgIHctZnVsbCBoLTE0XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRBdWN0aW9uLm1hcCgoZW50cnksIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5ncm91cF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJVbm5hbWVkIEdyb3VwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3VwSWQgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5Py5lbnJvbGxtZW50Py5ncm91cD8uX2lkIHx8IGBtaXNzaW5nLSR7aW5kZXh9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGlja2V0ID0gZW50cnk/LmVucm9sbG1lbnQ/LnRpY2tldHMgfHwgXCJVbmtub3duXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2BjaGl0LSR7Z3JvdXBJZH18JHt0aWNrZXR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwTmFtZX0gfCB7dGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5bWVudF9ncm91cF90aWNrZXRzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW1vZGlmeVBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBoLTE0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJMYXN0IDMgVHJhbnNhY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbWQgcC0yIGJvcmRlci0yIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGZldGNoTGFzdFRocmVlVHJhbnNhY3Rpb25zKGUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVJlY2VpcHQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGF5bWVudE1vZGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjYXNoXCI+Q2FzaDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHttb2RpZnlQYXltZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInN1c3BlbnNlXCI+U3VzcGVuc2U8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjcmVkaXRcIj5DcmVkaXQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhZGp1c3RtZW50XCI+QWRqdXN0bWVudDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm90aGVyc1wiPk90aGVyczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYW1vdW50ICYmIHBheW1lbnRHcm91cFRpY2tldHMubGVuZ3RoID4gMSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwYXlfbW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEluZGl2aWR1YWwgVGlja2V0IEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgaG92ZXI6Y3Vyc29yLW5vdC1hbGxvd2VkIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwidG90YWxBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyKGZvcm1EYXRhLmFtb3VudCkgLyBwYXltZW50R3JvdXBUaWNrZXRzLmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICB7cGF5bWVudE1vZGUgPT09IFwib25saW5lXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIElEIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgVHJhbnNhY3Rpb24gSURcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBEaXNidXJzZW1lbnQgVHlwZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRpc2J1cnNlbWVudF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmRpc2J1cnNlbWVudF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGFueTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Rpc2J1cnNlbWVudFR5cGVzLm1hcCgoZFR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2RUeXBlLmtleX0gdmFsdWU9e2RUeXBlLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZFR5cGUudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5kaXNidXJzZW1lbnRfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGlzYnVyc2VtZW50X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtzaG93T3RoZXJzRmllbGQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm90aGVyc0ZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE90aGVyc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm90aGVyc0ZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGlzYnVyc2VtZW50X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkaXNidXJzZW1lbnRUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU3BlY2lmeSBpZiB5b3VyIG9wdGlvbiBpcyBub3QgbGlzdGVkIGFib3ZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRGlzYnVyc2VtZW50VHlwZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5kaXNidXJzZW1lbnRfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRpc2J1cnNlbWVudF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm5vdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIE5vdGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubm90ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm90ZSBpZiBhbnk/XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdmlvbGV0LTUwIHAtMyByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRGlzYnVyc2VkIEJ5XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2FkbWluTmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcC00IG1heC13LWZ1bGwgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwU3F1YXJlIGNvbG9yPVwiZ3JlZW5cIiBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LW1kIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt3aGF0c2FwcEVuYWJsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi01MDAgY2hlY2tlZDpyaW5nLTIgIGNoZWNrZWQ6cmluZy1ncmVlbi03MDAgcm91bmRlZC1mdWxsIHctNCBoLTRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTZW5kIFZpYSBXaGF0c2FwcFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHNwYWNlLXgtMyBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIlNhdmluZyBQYXltZW50IE91dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNhdmUgUGF5bWVudCBPdXRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYXlPdXRSZXBvcnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9QYXlvdXRSZXBvcnQuanN4In0=