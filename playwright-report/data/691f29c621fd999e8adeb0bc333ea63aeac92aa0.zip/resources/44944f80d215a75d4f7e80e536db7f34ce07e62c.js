import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PigmyCollectionIncentiveReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"];
import {
  Select,
  Radio,
  Card,
  Button,
  Space,
  Divider,
  Tag,
  Statistic,
  Row,
  Col,
  DatePicker,
  Modal,
  message,
  Upload
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  UserOutlined,
  CalendarOutlined,
  PercentageOutlined,
  FileSearchOutlined,
  TeamOutlined,
  RiseOutlined,
  PrinterOutlined,
  DownloadOutlined,
  SignatureOutlined,
  UploadOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import { FaRupeeSign, FaPiggyBank, FaStamp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { FiTarget } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { MdCurrencyRupee, MdGroups } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import imageInput from "/src/assets/images/Logo.svg?import";
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import html2canvas from "/node_modules/.vite/deps/html2canvas.js?v=819e0a34";
const { RangePicker } = DatePicker;
const PigmyCollectionIncentiveReport = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [dateSelectionMode, setDateSelectionMode] = useState("month");
  const [tempSelectedMonth, setTempSelectedMonth] = useState(null);
  const [tempFromDate, setTempFromDate] = useState(null);
  const [tempToDate, setTempToDate] = useState(null);
  const [incentivePercentage, setIncentivePercentage] = useState(3);
  const [loading, setLoading] = useState(false);
  const [pigmyData, setPigmyData] = useState([]);
  const [pigmySummary, setPigmySummary] = useState({
    total_collection: 0,
    total_incentive: 0,
    total_payments: 0,
    completed_pigmys: 0,
    pending_pigmys: 0
  });
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [selectedEmployeeDetails, setSelectedEmployeeDetails] = useState(null);
  const [isFiltering, setIsFiltering] = useState(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [signatureData, setSignatureData] = useState(null);
  const [agentSignatureData, setAgentSignatureData] = useState(null);
  useEffect(() => {
    const today2 = /* @__PURE__ */ new Date();
    const currentMonth2 = `${today2.getFullYear()}-${String(
      today2.getMonth() + 1
    ).padStart(2, "0")}`;
    setTempSelectedMonth(currentMonth2);
    const year = today2.getFullYear();
    const month = today2.getMonth() + 1;
    const firstDay = `${year}-${String(month).padStart(2, "0")}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    setTempFromDate(firstDay);
    setTempToDate(
      `${year}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`
    );
  }, []);
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const res = await api.get("/employee");
        setEmployees(res?.data?.employee || []);
      } catch (err) {
        console.error(err);
      }
    };
    fetchEmployees();
  }, []);
  const handleTempMonthChange = (e) => {
    const value = e.target.value;
    setTempSelectedMonth(value);
    if (value) {
      const [year, month] = value.split("-");
      const firstDay = `${year}-${month}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      setTempFromDate(firstDay);
      setTempToDate(`${year}-${month}-${String(lastDay).padStart(2, "0")}`);
    }
  };
  const fetchPigmyCollectionData = async (employeeId, startDate, endDate) => {
    if (!employeeId || !startDate || !endDate) return;
    try {
      const response = await api.get(
        `/v1/admin/payments/pigmys/collection-agents/${employeeId}/${incentivePercentage}`,
        {
          params: {
            startDate,
            endDate
          }
        }
      );
      if (response.data && response.data.success) {
        const responseData = response.data.data || [];
        let allPayments = [];
        let totalCollection = 0;
        let totalIncentive = 0;
        responseData.forEach((item) => {
          if (item.payments && Array.isArray(item.payments)) {
            allPayments = [...allPayments, ...item.payments];
            totalCollection += item.total_payments || 0;
            totalIncentive += item.incentive_amount || 0;
          }
        });
        setPigmyData(allPayments);
        setPigmySummary({
          total_collection: totalCollection,
          total_incentive: totalIncentive,
          total_payments: allPayments.length,
          completed_pigmys: allPayments.filter(
            (p) => p.status === "completed" || p.is_completed
          ).length,
          pending_pigmys: allPayments.filter(
            (p) => p.status !== "completed" && !p.is_completed
          ).length
        });
      } else {
        setPigmyData([]);
        setPigmySummary({
          total_collection: 0,
          total_incentive: 0,
          total_payments: 0,
          completed_pigmys: 0,
          pending_pigmys: 0
        });
      }
    } catch (err) {
      console.error("Error fetching pigmy collection data:", err);
      setPigmyData([]);
      setPigmySummary({
        total_collection: 0,
        total_incentive: 0,
        total_payments: 0,
        completed_pigmys: 0,
        pending_pigmys: 0
      });
    }
  };
  const handleContinue = async () => {
    if (!selectedEmployeeId) {
      message.warning("Please select an employee.");
      return;
    }
    if (dateSelectionMode === "month" && !tempSelectedMonth) {
      message.warning("Please select a month.");
      return;
    }
    if (dateSelectionMode === "date-range" && (!tempFromDate || !tempToDate)) {
      message.warning("Please select both From and To dates.");
      return;
    }
    setIsFiltering(true);
    setLoading(true);
    let startDate, endDate;
    if (dateSelectionMode === "month") {
      const [year, month] = tempSelectedMonth.split("-");
      startDate = `${year}-${month}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      endDate = `${year}-${month}-${String(lastDay).padStart(2, "0")}`;
      setFromDate(startDate);
      setToDate(endDate);
    } else {
      startDate = tempFromDate;
      endDate = tempToDate;
      setFromDate(startDate);
      setToDate(endDate);
    }
    try {
      const emp = employees.find((e) => e._id === selectedEmployeeId);
      setSelectedEmployeeDetails(emp || null);
      await fetchPigmyCollectionData(selectedEmployeeId, startDate, endDate);
      message.success("Data loaded successfully!");
    } catch (error) {
      console.error("Error in handleContinue:", error);
      message.error("Failed to load data");
    } finally {
      setLoading(false);
    }
  };
  const numToWords = (num) => {
    if (isNaN(num) || num === 0) return "Zero";
    const a = [
      "",
      "One",
      "Two",
      "Three",
      "Four",
      "Five",
      "Six",
      "Seven",
      "Eight",
      "Nine",
      "Ten",
      "Eleven",
      "Twelve",
      "Thirteen",
      "Fourteen",
      "Fifteen",
      "Sixteen",
      "Seventeen",
      "Eighteen",
      "Nineteen"
    ];
    const b = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
    num = Math.round(num);
    if ((num = num.toString()).length > 9) return "Overflow";
    const n = ("000000000" + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return "";
    let str = "";
    str += n[1] != 0 ? (a[Number(n[1])] || b[n[1][0]] + " " + a[n[1][1]]) + " Crore " : "";
    str += n[2] != 0 ? (a[Number(n[2])] || b[n[2][0]] + " " + a[n[2][1]]) + " Lakh " : "";
    str += n[3] != 0 ? (a[Number(n[3])] || b[n[3][0]] + " " + a[n[3][1]]) + " Thousand " : "";
    str += n[4] != 0 ? (a[Number(n[4])] || b[n[4][0]] + " " + a[n[4][1]]) + " Hundred " : "";
    str += n[5] != 0 ? (str != "" ? "and " : "") + (a[Number(n[5])] || b[n[5][0]] + " " + a[n[5][1]]) + " " : "";
    return str.trim() || "Zero";
  };
  const handleSignatureChange = (e, type) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === "manager") {
          setSignatureData(reader.result);
        } else {
          setAgentSignatureData(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };
  const generateIncentiveSlipContent = () => {
    const agent = selectedEmployeeDetails;
    const period = dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${tempSelectedMonth}-01`)).toLocaleString("default", { month: "long", year: "numeric" }) : `${fromDate} to ${toDate}`;
    const amountInWords = numToWords(pigmySummary.total_incentive);
    const slipNumber = `INC-${Date.now().toString().slice(-6)}`;
    const currentDate = (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
    const logoUrl = imageInput.startsWith("http") ? imageInput : window.location.origin + imageInput;
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Incentive Slip - ${agent?.name || "Agent"}</title>
        <style>
          @page { 
            size: A4; 
            margin: 0;
          }
          
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          
          body { 
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; 
            background-color: #ffffff;
            margin: 0;
            padding: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          
          .document-container {
            width: 210mm;
            min-height: 297mm;
            margin: 0 auto;
            background: white;
            position: relative;
            page-break-after: avoid;
            page-break-inside: avoid;
          }
          
          /* Header Section */
          .header-section {
            background: linear-gradient(135deg, #00267C 0%, #003d9e 100%);
            padding: 20px 25px;
            color: white;
          }
          
          .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
          }
          
          .logo-area img {
            height: 60px;
            width: auto;
            object-fit: contain;
          }
          
          .company-info {
            text-align: center;
            flex: 1;
          }
          
          .company-name {
            font-size: 24px;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 3px;
          }
          
          .company-tagline {
            font-size: 10px;
            opacity: 0.9;
          }
          
          .document-meta {
            text-align: right;
            font-size: 11px;
            border-left: 1px solid rgba(255,255,255,0.3);
            padding-left: 15px;
          }
          
          .meta-item {
            margin-bottom: 3px;
          }
          
          .meta-label {
            font-weight: 600;
            opacity: 0.8;
          }
          
          /* Title Section */
          .title-section {
            background: #f8f9fa;
            padding: 12px 20px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
          }
          
          .document-title {
            font-size: 20px;
            font-weight: 700;
            color: #00267C;
            text-transform: uppercase;
          }
          
          /* Content Sections */
          .content-section {
            padding: 15px 25px;
          }
          
          .info-card {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            margin-bottom: 15px;
            overflow: hidden;
          }
          
          .card-header {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 10px 15px;
            border-bottom: 2px solid #00267C;
          }
          
          .card-header h3 {
            color: #00267C;
            font-size: 14px;
            font-weight: 700;
            margin: 0;
            text-transform: uppercase;
          }
          
          .card-body {
            padding: 12px 15px;
          }
          
          .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
          }
          
          .info-row {
            display: flex;
            flex-direction: column;
          }
          
          .info-label {
            font-size: 10px;
            font-weight: 600;
            color: #6c757d;
            text-transform: uppercase;
            margin-bottom: 3px;
          }
          
          .info-value {
            font-size: 13px;
            font-weight: 500;
            color: #212529;
          }
          
          /* Table Styles */
          .summary-table {
            width: 100%;
            border-collapse: collapse;
          }
          
          .summary-table tr {
            border-bottom: 1px solid #e9ecef;
          }
          
          .summary-table td {
            padding: 8px 5px;
            font-size: 12px;
          }
          
          .summary-table td:first-child {
            font-weight: 500;
            color: #495057;
          }
          
          .summary-table td:last-child {
            text-align: right;
            font-weight: 600;
            color: #212529;
          }
          
          .total-row {
            background: #e8f0fe;
          }
          
          .total-row td {
            font-weight: 700 !important;
            color: #00267C !important;
          }
          
          /* Highlight Box */
          .highlight-box {
            background: linear-gradient(135deg, #e8f0fe 0%, #d4e2f7 100%);
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            margin-top: 12px;
          }
          
          .highlight-label {
            font-size: 11px;
            font-weight: 600;
            color: #00267C;
            text-transform: uppercase;
            margin-bottom: 5px;
          }
          
          .highlight-amount {
            font-size: 28px;
            font-weight: 800;
            color: #00267C;
            margin: 5px 0;
          }
          
          .highlight-words {
            font-size: 10px;
            color: #495057;
            font-style: italic;
            border-top: 1px dashed #00267C40;
            padding-top: 8px;
            margin-top: 5px;
          }
          
          /* Declaration */
          .declaration-box {
            background: #f8f9fa;
            border-left: 3px solid #00267C;
            padding: 10px 15px;
            margin: 12px 0;
            font-size: 10px;
            color: #495057;
            line-height: 1.4;
          }
          
          /* Signature Section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            padding-top: 15px;
          }
          
          .signature-box {
            text-align: center;
            width: 45%;
          }
          
          .signature-image {
            max-height: 50px;
            margin-bottom: 8px;
            object-fit: contain;
          }
          
          .signature-line {
            border-top: 1px solid #212529;
            padding-top: 6px;
            font-size: 10px;
            font-weight: 600;
            color: #6c757d;
          }
          
          /* Footer */
          .footer-section {
            background: linear-gradient(135deg, #00267C 0%, #003d9e 100%);
            padding: 10px 20px;
            text-align: center;
            color: white;
            font-size: 8px;
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
          }
          
          .footer-company {
            font-weight: 700;
            margin-bottom: 3px;
          }
          
          .footer-address {
            opacity: 0.8;
            margin-bottom: 3px;
          }
          
          .footer-contact {
            opacity: 0.7;
          }
          
          @media print {
            body {
              background: white;
              padding: 0;
              margin: 0;
            }
            .document-container {
              box-shadow: none;
              page-break-after: avoid;
              page-break-inside: avoid;
            }
            .header-section, .footer-section {
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
          }
        </style>
      </head>
      <body>
        <div class="document-container">
          <!-- Header Section -->
          <div class="header-section">
            <div class="header-content">
              <div class="logo-area">
                <img src="${logoUrl}" alt="MyChits Logo" onerror="this.src='data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' fill='%2300267C'/%3E%3Ctext x='50' y='50' text-anchor='middle' dy='.3em' fill='white' font-size='14' font-family='Arial'%3EMC%3C/text%3E%3C/svg%3E'">
              </div>
              <div class="company-info">
                <div class="company-name">MYCHITS</div>
                <div class="company-tagline">Chit Funds • Loans • Investments</div>
              </div>
              <div class="document-meta">
                <div class="meta-item">
                  <span class="meta-label">Date:</span> ${currentDate}
                </div>
          
              </div>
            </div>
          </div>
          
          <!-- Title Section -->
          <div class="title-section">
            <div class="document-title">Pigmy Collection Incentive Slip</div>
          </div>
          
          <!-- Content Section -->
          <div class="content-section">
            <!-- Agent Details Card -->
            <div class="info-card">
              <div class="card-header">
                <h3>Agent / Employee Details</h3>
              </div>
              <div class="card-body">
                <div class="info-grid">
                  <div class="info-row">
                    <span class="info-label">Agent Name</span>
                    <span class="info-value">${agent?.name || "N/A"}</span>
                  </div>
                  <div class="info-row">
                    <span class="info-label">Employee ID</span>
                    <span class="info-value">${agent?.employeeCode || agent?._id?.slice(-6) || "N/A"}</span>
                  </div>
                  <div class="info-row">
                    <span class="info-label">Phone Number</span>
                    <span class="info-value">${agent?.phone_number || "N/A"}</span>
                  </div>
                  <div class="info-row">
                    <span class="info-label">Reporting Period</span>
                    <span class="info-value">${period}</span>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Collection Summary Card -->
            <div class="info-card">
              <div class="card-header">
                <h3>Collection & Incentive Summary</h3>
              </div>
              <div class="card-body">
                <table class="summary-table">
                  <tbody>
                    <tr>
                      <td>Total Collection Amount</td>
                      <td>₹${pigmySummary.total_collection?.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</td>
                    </tr>
                    <tr>
                      <td>Incentive Percentage Rate</td>
                      <td>${incentivePercentage}%</td>
                    </tr>
                    <tr>
                      <td>Total Transactions (Records)</td>
                      <td>${pigmyData.length}</td>
                    </tr>
                    <tr>
                      <td>Completed Pigmys</td>
                      <td>${pigmySummary.completed_pigmys}</td>
                    </tr>
                    <tr>
                      <td>Pending Pigmys</td>
                      <td>${pigmySummary.pending_pigmys}</td>
                    </tr>
                    <tr class="total-row">
                      <td style="font-weight: 700;">Gross Incentive Earned</td>
                      <td style="font-weight: 700; color: #00267C;">₹${pigmySummary.total_incentive?.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</td>
                    </tr>
                  </tbody>
                </table>
                
                <!-- Highlight Box -->
                <div class="highlight-box">
                  <div class="highlight-label">Net Payable Amount</div>
                  <div class="highlight-amount">₹${pigmySummary.total_incentive?.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</div>
                  <div class="highlight-words">
                    Rupees ${amountInWords} Only
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Declaration -->
            <div class="declaration-box">
              <strong>Declaration:</strong> This is a computer-generated incentive slip. The details contained herein are true to the best of our knowledge. Any discrepancy should be reported to the accounts department within 48 hours of receipt.
            </div>
            
            <!-- Signature Section -->
            <div class="signature-section">
              <div class="signature-box">
                ${agentSignatureData ? `<img src="${agentSignatureData}" class="signature-image" alt="Agent Sign">` : ""}
                <div class="signature-line">Agent's Signature</div>
              </div>
              <div class="signature-box">
                ${signatureData ? `<img src="${signatureData}" class="signature-image" alt="Manager Sign">` : ""}
                <div class="signature-line">Authorized Signatory</div>
              </div>
            </div>
          </div>
          
          <!-- Footer Section -->
          <div class="footer-section">
            <div class="footer-company">VIJAYA VINAYAK CHIT FUNDS PRIVATE LIMITED</div>
            <div class="footer-address">#11/36-25, 3rd Floor, 2nd Main, Kathriguppe Main Road, Banashankari 3rd Stage, Bengaluru-560085</div>
            <div class="footer-contact">Mob: 9483900777 | Ph: 080-4979 8763 | Email: info.mychits@gmail.com</div>
          </div>
        </div>
      </body>
      </html>
    `;
  };
  const handleGenerateSlip = async () => {
    if (!selectedEmployeeDetails) {
      message.warning("Please load employee data first by clicking Continue.");
      return;
    }
    setIsGeneratingPDF(true);
    try {
      const htmlContent = generateIncentiveSlipContent();
      const agent = selectedEmployeeDetails;
      const period = dateSelectionMode === "month" ? tempSelectedMonth : `${fromDate}_to_${toDate}`;
      const fileName = `Incentive_Slip_${agent?.name || "Agent"}_${period}.pdf`;
      const tempDiv = document.createElement("div");
      tempDiv.style.position = "absolute";
      tempDiv.style.left = "-9999px";
      tempDiv.style.top = "-9999px";
      tempDiv.style.width = "210mm";
      tempDiv.style.backgroundColor = "#ffffff";
      tempDiv.innerHTML = htmlContent;
      document.body.appendChild(tempDiv);
      await new Promise((r) => setTimeout(r, 800));
      const canvas = await html2canvas(tempDiv, {
        scale: 3,
        useCORS: true,
        backgroundColor: "#ffffff",
        logging: false,
        windowWidth: 800,
        allowTaint: false,
        foreignObjectRendering: false
      });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const pageWidth = 210;
      const pageHeight = 297;
      const imgWidth = pageWidth;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      pdf.save(fileName);
      document.body.removeChild(tempDiv);
      message.success("Incentive Slip downloaded successfully!");
    } catch (error) {
      console.error("Error generating PDF:", error);
      message.error("Failed to generate incentive slip");
    } finally {
      setIsGeneratingPDF(false);
    }
  };
  const handlePrintSlip = () => {
    if (!selectedEmployeeDetails) {
      message.warning("Please load employee data first by clicking Continue.");
      return;
    }
    const htmlContent = generateIncentiveSlipContent();
    const agent = selectedEmployeeDetails;
    const period = dateSelectionMode === "month" ? tempSelectedMonth : `${fromDate}_to_${toDate}`;
    const fileName = `Incentive_Slip_${agent?.name || "Agent"}_${period}`;
    const printWindow = window.open("", "_blank");
    printWindow.document.write(htmlContent);
    printWindow.document.title = fileName;
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 500);
  };
  const processedTableData = pigmyData.map((payment, index) => ({
    key: payment._id || index,
    sno: index + 1,
    pay_date: payment?.pay_date || payment?.createdAt?.split("T")[0] || "N/A",
    transaction_date: payment?.createdAt?.split("T")[0] || "N/A",
    customer_name: payment.user_id?.full_name || payment.customer_name || "N/A",
    phone_number: payment.user_id?.phone_number || payment.phone_number || "N/A",
    pigmy_id: payment?.pigme?.pigme_id || payment.pigmyId || "N/A",
    paid_amount: payment.paid_amount || payment.amount || 0,
    payment_mode: payment.pay_type || payment.mode || "N/A",
    receipt_no: payment?.receipt_no || "N/A"
  }));
  const columns = [
    { key: "sno", header: "SL.No" },
    { key: "pay_date", header: "Payment Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "pigmy_id", header: "Pigmy ID" },
    { key: "paid_amount", header: "Paid Amount (₹)" },
    { key: "payment_mode", header: "Payment Mode" },
    { key: "receipt_no", header: "Receipt No" }
  ];
  const today = /* @__PURE__ */ new Date();
  const currentMonth = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}`;
  const selectedEmployee = employees.find(
    (emp) => emp._id === selectedEmployeeId
  );
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "max-w-2xl", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent break-words leading-tight", children: "Pigmy Collection Incentive Reports" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 836,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-4 text-lg", children: "Track and manage employee incentives and commissions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 839,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 835,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-full p-3 shadow-md", children: /* @__PURE__ */ jsxDEV(FaPiggyBank, { className: "text-3xl text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 844,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 843,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 834,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 833,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl overflow-hidden mt-6 mb-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(FiTarget, { className: "text-blue-600", size: 18 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 852,
            columnNumber: 13
          }, this),
          "Quick Navigation to Other Reports"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 851,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "Explore other incentive reports" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 855,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 850,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/reports/target-incentive-new",
            className: "group relative overflow-hidden bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-blue-400 hover:shadow-lg transition-all duration-300",
            children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-100 rounded-lg group-hover:bg-blue-500 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
                FiTarget,
                {
                  className: "text-blue-600 group-hover:text-white transition-colors duration-300",
                  size: 22
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 868,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 867,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 group-hover:text-blue-600 transition-colors", children: "Chit Business Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 874,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "View chit-based incentives" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 877,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 873,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV(
                "svg",
                {
                  className: "w-5 h-5 text-blue-600",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                  children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M9 5l7 7-7 7"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                      lineNumber: 888,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 882,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 881,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 866,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 862,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/reports/loancollection-incentive",
            className: "group relative overflow-hidden bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-green-400 hover:shadow-lg transition-all duration-300",
            children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-green-100 rounded-lg group-hover:bg-green-500 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
                MdCurrencyRupee,
                {
                  className: "text-green-600 group-hover:text-white transition-colors duration-300",
                  size: 22
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 905,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 904,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 group-hover:text-green-600 transition-colors", children: "Loan Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 911,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "Track loan collections" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 914,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 910,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV(
                "svg",
                {
                  className: "w-5 h-5 text-green-600",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                  children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M9 5l7 7-7 7"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                      lineNumber: 925,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 919,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 918,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 903,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 899,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/reports/chitcollection-incentive",
            className: "group relative overflow-hidden bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-purple-400 hover:shadow-lg transition-all duration-300",
            children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-purple-100 rounded-lg group-hover:bg-purple-500 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
                MdGroups,
                {
                  className: "text-purple-600 group-hover:text-white transition-colors duration-300",
                  size: 22
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 943,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 942,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 group-hover:text-purple-600 transition-colors", children: "Chit Collection Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 949,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "Track Chit collections" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 952,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 948,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV(
                "svg",
                {
                  className: "w-5 h-5 text-purple-600",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                  children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M9 5l7 7-7 7"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                      lineNumber: 963,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 957,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 956,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 941,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 937,
            columnNumber: 14
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 861,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 860,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 849,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg hover:shadow-xl transition-shadow", children: /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Total Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 981,
            columnNumber: 22
          }, this),
          value: pigmySummary.total_collection,
          precision: 2,
          prefix: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-green-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 984,
            columnNumber: 23
          }, this),
          valueStyle: { color: "#3f8600", fontSize: "24px" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 980,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 979,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 978,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg hover:shadow-xl transition-shadow", children: /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Total Incentive" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 992,
            columnNumber: 22
          }, this),
          value: pigmySummary.total_incentive,
          precision: 2,
          prefix: /* @__PURE__ */ jsxDEV(RiseOutlined, { className: "text-blue-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 995,
            columnNumber: 23
          }, this),
          valueStyle: { color: "#1890ff", fontSize: "24px" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 991,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 990,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 989,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg hover:shadow-xl transition-shadow", children: /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Total Records" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1003,
            columnNumber: 22
          }, this),
          value: pigmySummary.total_payments,
          prefix: /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-purple-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1005,
            columnNumber: 23
          }, this),
          valueStyle: { color: "#722ed1", fontSize: "24px" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1002,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1001,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1e3,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 977,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 border-b border-gray-100", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(FileSearchOutlined, { className: "text-blue-500" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1015,
          columnNumber: 13
        }, this),
        "Report Filters"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1014,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1013,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 mb-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-blue-500 text-xs" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1024,
                columnNumber: 17
              }, this),
              "Date Selection Mode"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1023,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Radio.Group,
              {
                value: dateSelectionMode,
                onChange: (e) => setDateSelectionMode(e.target.value),
                size: "small",
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(
                    Radio.Button,
                    {
                      value: "month",
                      style: { width: "50%", textAlign: "center" },
                      children: "Monthly"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                      lineNumber: 1033,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Radio.Button,
                    {
                      value: "date-range",
                      style: { width: "50%", textAlign: "center" },
                      children: "Date Range"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                      lineNumber: 1039,
                      columnNumber: 17
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1027,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1022,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-500 text-xs" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1050,
                columnNumber: 17
              }, this),
              "Select Employee"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1049,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedEmployeeId || void 0,
                onChange: setSelectedEmployeeId,
                showSearch: true,
                placeholder: "Search by name or phone",
                size: "middle",
                className: "w-full",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                children: employees.map(
                  (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                    emp.name,
                    " - ",
                    emp.phone_number
                  ] }, emp._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                    lineNumber: 1068,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1053,
                columnNumber: 15
              },
              this
            ),
            selectedEmployee && /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-gray-500", children: [
              "Selected: ",
              selectedEmployee.name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1074,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1048,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1021,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1", children: dateSelectionMode === "month" ? "Select Month" : "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1083,
              columnNumber: 15
            }, this),
            dateSelectionMode === "month" ? /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "month",
                value: tempSelectedMonth || "",
                max: currentMonth,
                onChange: handleTempMonthChange,
                className: "w-full px-2 py-1.5 text-sm border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1087,
                columnNumber: 15
              },
              this
            ) : /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: tempFromDate || "",
                onChange: (e) => setTempFromDate(e.target.value),
                className: "w-full px-2 py-1.5 text-sm border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1095,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1082,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(PercentageOutlined, { className: "text-blue-500 text-xs" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1106,
                columnNumber: 17
              }, this),
              "Incentive Percentage"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1105,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  step: "0.1",
                  min: "0",
                  value: incentivePercentage,
                  onChange: (e) => setIncentivePercentage(e.target.value),
                  className: "w-full px-2 py-1.5 text-sm border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 pr-7"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                  lineNumber: 1110,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 text-xs", children: "%" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1118,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1109,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1104,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1081,
          columnNumber: 11
        }, this),
        dateSelectionMode === "date-range" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 mb-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1", children: "To Date" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1128,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              value: tempToDate || "",
              onChange: (e) => setTempToDate(e.target.value),
              className: "w-full px-2 py-1.5 text-sm border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1131,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1127,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1126,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 mt-2 pt-3 border-t border-gray-100", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "medium",
              onClick: () => {
                setSelectedEmployeeId(null);
                setSelectedEmployeeDetails(null);
                setTempSelectedMonth(currentMonth);
                setIncentivePercentage(3);
                setPigmyData([]);
                setPigmySummary({
                  total_collection: 0,
                  total_incentive: 0,
                  total_payments: 0,
                  completed_pigmys: 0,
                  pending_pigmys: 0
                });
                setIsFiltering(false);
                const today2 = /* @__PURE__ */ new Date();
                const year = today2.getFullYear();
                const month = today2.getMonth() + 1;
                const firstDay = `${year}-${String(month).padStart(2, "0")}-01`;
                const lastDay = new Date(year, month, 0).getDate();
                setTempFromDate(firstDay);
                setTempToDate(
                  `${year}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`
                );
              },
              children: "Reset"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1142,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              size: "medium",
              icon: /* @__PURE__ */ jsxDEV(FileSearchOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1174,
                columnNumber: 21
              }, this),
              loading,
              onClick: handleContinue,
              className: "px-8 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold shadow-sm",
              children: "Continue"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1171,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1141,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1020,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 1012,
      columnNumber: 7
    }, this),
    isFiltering && selectedEmployeeDetails && /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1191,
            columnNumber: 15
          }, this),
          "Employee Information"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1190,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Space, { children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              icon: /* @__PURE__ */ jsxDEV(PrinterOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1196,
                columnNumber: 21
              }, this),
              onClick: handlePrintSlip,
              className: "bg-gray-600 text-white hover:bg-gray-700",
              children: "Print Slip"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1195,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              icon: /* @__PURE__ */ jsxDEV(DownloadOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
                lineNumber: 1204,
                columnNumber: 21
              }, this),
              loading: isGeneratingPDF,
              onClick: handleGenerateSlip,
              className: "bg-green-600 hover:bg-green-700",
              children: "Generate Slip"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1202,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1194,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1189,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Name" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1216,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-900 font-medium mt-1", children: selectedEmployeeDetails?.name || "-" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1219,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1215,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Email" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1224,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-900 font-medium mt-1", children: selectedEmployeeDetails?.email || "-" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1227,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1223,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Phone" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1232,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-900 font-medium mt-1", children: selectedEmployeeDetails?.phone_number || "-" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1235,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1231,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1214,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1213,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 1188,
      columnNumber: 7
    }, this),
    isFiltering && pigmyData.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-green-50 to-emerald-50 border-b", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1250,
          columnNumber: 15
        }, this),
        "Collection Summary"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1249,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1248,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-5 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Period" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1257,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-blue-700 mt-1", children: dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${tempSelectedMonth}-01`)).toLocaleString(
            "default",
            {
              month: "long",
              year: "numeric"
            }
          ) : `${fromDate} to ${toDate}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1260,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1256,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Incentive Rate" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1274,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-green-700 mt-1", children: [
            incentivePercentage,
            "%"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1277,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1273,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Total Records" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1283,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-purple-700 mt-1", children: pigmyData.length }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1286,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1282,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Total Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1292,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-green-700 mt-1", children: [
            /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "inline-block mr-1 text-green-500" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1296,
              columnNumber: 19
            }, this),
            pigmySummary.total_collection?.toFixed(2)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1295,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1291,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Total Incentive" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1302,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-blue-700 mt-1", children: [
            /* @__PURE__ */ jsxDEV(RiseOutlined, { className: "inline-block mr-1 text-blue-500" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
              lineNumber: 1306,
              columnNumber: 19
            }, this),
            pigmySummary.total_incentive?.toFixed(2)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1305,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1301,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1255,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1254,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 1247,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 1317,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 1316,
      columnNumber: 7
    }, this) : isFiltering && pigmyData.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(FileSearchOutlined, { className: "text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
            lineNumber: 1325,
            columnNumber: 17
          }, this),
          "Payment Details"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1324,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: [
          "Showing ",
          pigmyData.length,
          " payment records"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1328,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1323,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: processedTableData,
          columns,
          exportedPdfName: `Pigmy_Collection_Incentive_Report`,
          printHeaderKeys: [
            "Employee Name",
            "Phone Number",
            "Period",
            "Incentive Percentage",
            "Total Collection",
            "Total Incentive",
            "Total Records"
          ],
          printHeaderValues: [
            selectedEmployeeDetails?.name || "-",
            selectedEmployeeDetails?.phone_number || "-",
            dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${tempSelectedMonth}-01`)).toLocaleString(
              "default",
              {
                month: "long",
                year: "numeric"
              }
            ) : `${fromDate} to ${toDate}`,
            `${incentivePercentage}%`,
            `₹${pigmySummary.total_collection?.toLocaleString("en-IN") || "0"}`,
            `₹${pigmySummary.total_incentive?.toLocaleString("en-IN") || "0"}`,
            pigmyData.length || "0"
          ],
          exportedFileName: `PigmyCollectionReport_${selectedEmployeeDetails?.name || "all"}_${dateSelectionMode === "month" ? tempSelectedMonth : `${fromDate}_to_${toDate}`}.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
          lineNumber: 1333,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
        lineNumber: 1332,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 1322,
      columnNumber: 7
    }, this),
    isFiltering && !loading && pigmyData.length === 0 && /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "p-12 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-lg font-medium", children: "No payment records found for the selected period." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 1377,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 1376,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
      lineNumber: 1375,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx",
    lineNumber: 832,
    columnNumber: 5
  }, this);
};
_s(PigmyCollectionIncentiveReport, "YW2Wf52zmU3CuKFqn7z2JcXzz2U=");
_c = PigmyCollectionIncentiveReport;
export default PigmyCollectionIncentiveReport;
var _c;
$RefreshReg$(_c, "PigmyCollectionIncentiveReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyCollectionIncentiveReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbTBCWTsyQkFuMEJaO0FBQWdCQSxNQUFXQyxjQUFVQyxPQUFNLHNCQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxhQUFhQyxhQUFhQyxlQUFlO0FBQ2xELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxpQkFBaUJDLGdCQUFnQjtBQUMxQyxTQUFTQyxZQUFZO0FBQ3JCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGlCQUFpQjtBQUV4QixNQUFNLEVBQUVDLFlBQVksSUFBSTVCO0FBRXhCLE1BQU02QixpQ0FBaUNBLE1BQU07QUFBQUMsS0FBQTtBQUMzQyxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSTVDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM2QyxvQkFBb0JDLHFCQUFxQixJQUFJOUMsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQytDLG1CQUFtQkMsb0JBQW9CLElBQUloRCxTQUFTLE9BQU87QUFDbEUsUUFBTSxDQUFDaUQsbUJBQW1CQyxvQkFBb0IsSUFBSWxELFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUNtRCxjQUFjQyxlQUFlLElBQUlwRCxTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDcUQsWUFBWUMsYUFBYSxJQUFJdEQsU0FBUyxJQUFJO0FBQ2pELFFBQU0sQ0FBQ3VELHFCQUFxQkMsc0JBQXNCLElBQUl4RCxTQUFTLENBQUc7QUFDbEUsUUFBTSxDQUFDeUQsU0FBU0MsVUFBVSxJQUFJMUQsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQzJELFdBQVdDLFlBQVksSUFBSTVELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM2RCxjQUFjQyxlQUFlLElBQUk5RCxTQUFTO0FBQUEsSUFDL0MrRCxrQkFBa0I7QUFBQSxJQUNsQkMsaUJBQWlCO0FBQUEsSUFDakJDLGdCQUFnQjtBQUFBLElBQ2hCQyxrQkFBa0I7QUFBQSxJQUNsQkMsZ0JBQWdCO0FBQUEsRUFDbEIsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJckUsU0FBUyxJQUFJO0FBQzdDLFFBQU0sQ0FBQ3NFLFFBQVFDLFNBQVMsSUFBSXZFLFNBQVMsSUFBSTtBQUN6QyxRQUFNLENBQUN3RSx5QkFBeUJDLDBCQUEwQixJQUFJekUsU0FBUyxJQUFJO0FBQzNFLFFBQU0sQ0FBQzBFLGFBQWFDLGNBQWMsSUFBSTNFLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUM0RSxpQkFBaUJDLGtCQUFrQixJQUFJN0UsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzhFLGVBQWVDLGdCQUFnQixJQUFJL0UsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ2dGLG9CQUFvQkMscUJBQXFCLElBQUlqRixTQUFTLElBQUk7QUFFakVELFlBQVUsTUFBTTtBQUNkLFVBQU1tRixTQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFVBQU1DLGdCQUFlLEdBQUdGLE9BQU1HLFlBQVksQ0FBQyxJQUFJQztBQUFBQSxNQUM3Q0osT0FBTUssU0FBUyxJQUFJO0FBQUEsSUFDckIsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUVsQnRDLHlCQUFxQmtDLGFBQVk7QUFFakMsVUFBTUssT0FBT1AsT0FBTUcsWUFBWTtBQUMvQixVQUFNSyxRQUFRUixPQUFNSyxTQUFTLElBQUk7QUFDakMsVUFBTUksV0FBVyxHQUFHRixJQUFJLElBQUlILE9BQU9JLEtBQUssRUFBRUYsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUMxRCxVQUFNSSxVQUFVLElBQUlULEtBQUtNLE1BQU1DLE9BQU8sQ0FBQyxFQUFFRyxRQUFRO0FBRWpEekMsb0JBQWdCdUMsUUFBUTtBQUN4QnJDO0FBQUFBLE1BQ0UsR0FBR21DLElBQUksSUFBSUgsT0FBT0ksS0FBSyxFQUFFRixTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUlGLE9BQU9NLE9BQU8sRUFBRUosU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUFBLElBQy9FO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTHpGLFlBQVUsTUFBTTtBQUNkLFVBQU0rRixpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTUMsTUFBTSxNQUFNckUsSUFBSXNFLElBQUksV0FBVztBQUNyQ3BELHFCQUFhbUQsS0FBS0UsTUFBTUMsWUFBWSxFQUFFO0FBQUEsTUFDeEMsU0FBU0MsS0FBSztBQUNaQyxnQkFBUUMsTUFBTUYsR0FBRztBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUNBTCxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMLFFBQU1RLHdCQUF3QkEsQ0FBQ0MsTUFBTTtBQUNuQyxVQUFNQyxRQUFRRCxFQUFFRSxPQUFPRDtBQUN2QnRELHlCQUFxQnNELEtBQUs7QUFDMUIsUUFBSUEsT0FBTztBQUNULFlBQU0sQ0FBQ2YsTUFBTUMsS0FBSyxJQUFJYyxNQUFNRSxNQUFNLEdBQUc7QUFDckMsWUFBTWYsV0FBVyxHQUFHRixJQUFJLElBQUlDLEtBQUs7QUFDakMsWUFBTUUsVUFBVSxJQUFJVCxLQUFLTSxNQUFNQyxPQUFPLENBQUMsRUFBRUcsUUFBUTtBQUNqRHpDLHNCQUFnQnVDLFFBQVE7QUFDeEJyQyxvQkFBYyxHQUFHbUMsSUFBSSxJQUFJQyxLQUFLLElBQUlKLE9BQU9NLE9BQU8sRUFBRUosU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFO0FBQUEsSUFDdEU7QUFBQSxFQUNGO0FBRUEsUUFBTW1CLDJCQUEyQixPQUFPQyxZQUFZQyxXQUFXQyxZQUFZO0FBQ3pFLFFBQUksQ0FBQ0YsY0FBYyxDQUFDQyxhQUFhLENBQUNDLFFBQVM7QUFFM0MsUUFBSTtBQUNGLFlBQU1DLFdBQVcsTUFBTXJGLElBQUlzRTtBQUFBQSxRQUN6QiwrQ0FBK0NZLFVBQVUsSUFBSXJELG1CQUFtQjtBQUFBLFFBQ2hGO0FBQUEsVUFDRXlELFFBQVE7QUFBQSxZQUNOSDtBQUFBQSxZQUNBQztBQUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxVQUFJQyxTQUFTZCxRQUFRYyxTQUFTZCxLQUFLZ0IsU0FBUztBQUMxQyxjQUFNQyxlQUFlSCxTQUFTZCxLQUFLQSxRQUFRO0FBRTNDLFlBQUlrQixjQUFjO0FBQ2xCLFlBQUlDLGtCQUFrQjtBQUN0QixZQUFJQyxpQkFBaUI7QUFFckJILHFCQUFhSSxRQUFRLENBQUNDLFNBQVM7QUFDN0IsY0FBSUEsS0FBS0MsWUFBWUMsTUFBTUMsUUFBUUgsS0FBS0MsUUFBUSxHQUFHO0FBQ2pETCwwQkFBYyxDQUFDLEdBQUdBLGFBQWEsR0FBR0ksS0FBS0MsUUFBUTtBQUMvQ0osK0JBQW1CRyxLQUFLdEQsa0JBQWtCO0FBQzFDb0QsOEJBQWtCRSxLQUFLSSxvQkFBb0I7QUFBQSxVQUM3QztBQUFBLFFBQ0YsQ0FBQztBQUVEL0QscUJBQWF1RCxXQUFXO0FBQ3hCckQsd0JBQWdCO0FBQUEsVUFDZEMsa0JBQWtCcUQ7QUFBQUEsVUFDbEJwRCxpQkFBaUJxRDtBQUFBQSxVQUNqQnBELGdCQUFnQmtELFlBQVlTO0FBQUFBLFVBQzVCMUQsa0JBQWtCaUQsWUFBWVU7QUFBQUEsWUFDNUIsQ0FBQ0MsTUFBTUEsRUFBRUMsV0FBVyxlQUFlRCxFQUFFRTtBQUFBQSxVQUN2QyxFQUFFSjtBQUFBQSxVQUNGekQsZ0JBQWdCZ0QsWUFBWVU7QUFBQUEsWUFDMUIsQ0FBQ0MsTUFBTUEsRUFBRUMsV0FBVyxlQUFlLENBQUNELEVBQUVFO0FBQUFBLFVBQ3hDLEVBQUVKO0FBQUFBLFFBQ0osQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMaEUscUJBQWEsRUFBRTtBQUNmRSx3QkFBZ0I7QUFBQSxVQUNkQyxrQkFBa0I7QUFBQSxVQUNsQkMsaUJBQWlCO0FBQUEsVUFDakJDLGdCQUFnQjtBQUFBLFVBQ2hCQyxrQkFBa0I7QUFBQSxVQUNsQkMsZ0JBQWdCO0FBQUEsUUFDbEIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNnQyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0seUNBQXlDRixHQUFHO0FBQzFEdkMsbUJBQWEsRUFBRTtBQUNmRSxzQkFBZ0I7QUFBQSxRQUNkQyxrQkFBa0I7QUFBQSxRQUNsQkMsaUJBQWlCO0FBQUEsUUFDakJDLGdCQUFnQjtBQUFBLFFBQ2hCQyxrQkFBa0I7QUFBQSxRQUNsQkMsZ0JBQWdCO0FBQUEsTUFDbEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTThELGlCQUFpQixZQUFZO0FBQ2pDLFFBQUksQ0FBQ3BGLG9CQUFvQjtBQUN2Qi9CLGNBQVFvSCxRQUFRLDRCQUE0QjtBQUM1QztBQUFBLElBQ0Y7QUFFQSxRQUFJbkYsc0JBQXNCLFdBQVcsQ0FBQ0UsbUJBQW1CO0FBQ3ZEbkMsY0FBUW9ILFFBQVEsd0JBQXdCO0FBQ3hDO0FBQUEsSUFDRjtBQUVBLFFBQUluRixzQkFBc0IsaUJBQWlCLENBQUNJLGdCQUFnQixDQUFDRSxhQUFhO0FBQ3hFdkMsY0FBUW9ILFFBQVEsdUNBQXVDO0FBQ3ZEO0FBQUEsSUFDRjtBQUVBdkQsbUJBQWUsSUFBSTtBQUNuQmpCLGVBQVcsSUFBSTtBQUVmLFFBQUltRCxXQUFXQztBQUVmLFFBQUkvRCxzQkFBc0IsU0FBUztBQUNqQyxZQUFNLENBQUMwQyxNQUFNQyxLQUFLLElBQUl6QyxrQkFBa0J5RCxNQUFNLEdBQUc7QUFDakRHLGtCQUFZLEdBQUdwQixJQUFJLElBQUlDLEtBQUs7QUFDNUIsWUFBTUUsVUFBVSxJQUFJVCxLQUFLTSxNQUFNQyxPQUFPLENBQUMsRUFBRUcsUUFBUTtBQUNqRGlCLGdCQUFVLEdBQUdyQixJQUFJLElBQUlDLEtBQUssSUFBSUosT0FBT00sT0FBTyxFQUFFSixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQzlEbkIsa0JBQVl3QyxTQUFTO0FBQ3JCdEMsZ0JBQVV1QyxPQUFPO0FBQUEsSUFDbkIsT0FBTztBQUNMRCxrQkFBWTFEO0FBQ1oyRCxnQkFBVXpEO0FBQ1ZnQixrQkFBWXdDLFNBQVM7QUFDckJ0QyxnQkFBVXVDLE9BQU87QUFBQSxJQUNuQjtBQUVBLFFBQUk7QUFDRixZQUFNcUIsTUFBTXhGLFVBQVV5RixLQUFLLENBQUM3QixNQUFNQSxFQUFFOEIsUUFBUXhGLGtCQUFrQjtBQUM5RDRCLGlDQUEyQjBELE9BQU8sSUFBSTtBQUN0QyxZQUFNeEIseUJBQXlCOUQsb0JBQW9CZ0UsV0FBV0MsT0FBTztBQUNyRWhHLGNBQVFtRyxRQUFRLDJCQUEyQjtBQUFBLElBQzdDLFNBQVNaLE9BQU87QUFDZEQsY0FBUUMsTUFBTSw0QkFBNEJBLEtBQUs7QUFDL0N2RixjQUFRdUYsTUFBTSxxQkFBcUI7QUFBQSxJQUNyQyxVQUFDO0FBQ0MzQyxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTTRFLGFBQWFBLENBQUNDLFFBQVE7QUFDMUIsUUFBSUMsTUFBTUQsR0FBRyxLQUFLQSxRQUFRLEVBQUcsUUFBTztBQUVwQyxVQUFNRSxJQUFJO0FBQUEsTUFDUjtBQUFBLE1BQUk7QUFBQSxNQUFPO0FBQUEsTUFBTztBQUFBLE1BQVM7QUFBQSxNQUFRO0FBQUEsTUFBUTtBQUFBLE1BQU87QUFBQSxNQUFTO0FBQUEsTUFBUztBQUFBLE1BQ3BFO0FBQUEsTUFBTztBQUFBLE1BQVU7QUFBQSxNQUFVO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFXO0FBQUEsTUFDOUQ7QUFBQSxNQUFhO0FBQUEsTUFBWTtBQUFBLElBQVU7QUFFckMsVUFBTUMsSUFBSSxDQUFDLElBQUksSUFBSSxVQUFVLFVBQVUsU0FBUyxTQUFTLFNBQVMsV0FBVyxVQUFVLFFBQVE7QUFFL0ZILFVBQU1JLEtBQUtDLE1BQU1MLEdBQUc7QUFDcEIsU0FBS0EsTUFBTUEsSUFBSU0sU0FBUyxHQUFHakIsU0FBUyxFQUFHLFFBQU87QUFFOUMsVUFBTWtCLEtBQUssY0FBY1AsS0FBS1EsT0FBTyxFQUFFLEVBQUVDLE1BQU0sdUNBQXVDO0FBQ3RGLFFBQUksQ0FBQ0YsRUFBRyxRQUFPO0FBRWYsUUFBSUcsTUFBTTtBQUNWQSxXQUFPSCxFQUFFLENBQUMsS0FBSyxLQUFLTCxFQUFFUyxPQUFPSixFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUtKLEVBQUVJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLE1BQU1MLEVBQUVLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFlBQVk7QUFDcEZHLFdBQU9ILEVBQUUsQ0FBQyxLQUFLLEtBQUtMLEVBQUVTLE9BQU9KLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBS0osRUFBRUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksTUFBTUwsRUFBRUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssV0FBVztBQUNuRkcsV0FBT0gsRUFBRSxDQUFDLEtBQUssS0FBS0wsRUFBRVMsT0FBT0osRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLSixFQUFFSSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxNQUFNTCxFQUFFSyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxlQUFlO0FBQ3ZGRyxXQUFPSCxFQUFFLENBQUMsS0FBSyxLQUFLTCxFQUFFUyxPQUFPSixFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUtKLEVBQUVJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLE1BQU1MLEVBQUVLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLGNBQWM7QUFDdEZHLFdBQU9ILEVBQUUsQ0FBQyxLQUFLLEtBQUtHLE9BQU8sS0FBSyxTQUFTLE9BQU9SLEVBQUVTLE9BQU9KLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBS0osRUFBRUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksTUFBTUwsRUFBRUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssTUFBTTtBQUUxRyxXQUFPRyxJQUFJRSxLQUFLLEtBQUs7QUFBQSxFQUN2QjtBQUVBLFFBQU1DLHdCQUF3QkEsQ0FBQzdDLEdBQUc4QyxTQUFTO0FBQ3pDLFVBQU1DLE9BQU8vQyxFQUFFRSxPQUFPOEMsTUFBTSxDQUFDO0FBQzdCLFFBQUlELE1BQU07QUFDUixZQUFNRSxTQUFTLElBQUlDLFdBQVc7QUFDOUJELGFBQU9FLFlBQVksTUFBTTtBQUN2QixZQUFJTCxTQUFTLFdBQVc7QUFDdEJ0RSwyQkFBaUJ5RSxPQUFPRyxNQUFNO0FBQUEsUUFDaEMsT0FBTztBQUNMMUUsZ0NBQXNCdUUsT0FBT0csTUFBTTtBQUFBLFFBQ3JDO0FBQUEsTUFDRjtBQUNBSCxhQUFPSSxjQUFjTixJQUFJO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBRUEsUUFBTU8sK0JBQStCQSxNQUFNO0FBQ3pDLFVBQU1DLFFBQVF0RjtBQUNkLFVBQU11RixTQUFTaEgsc0JBQXNCLFdBQ2pDLG9CQUFJb0MsS0FBSyxHQUFHbEMsaUJBQWlCLEtBQUssR0FBRStHLGVBQWUsV0FBVyxFQUFFdEUsT0FBTyxRQUFRRCxNQUFNLFVBQVUsQ0FBQyxJQUNoRyxHQUFHckIsUUFBUSxPQUFPRSxNQUFNO0FBRTVCLFVBQU0yRixnQkFBZ0IzQixXQUFXekUsYUFBYUcsZUFBZTtBQUM3RCxVQUFNa0csYUFBYSxPQUFPL0UsS0FBS2dGLElBQUksRUFBRXRCLFNBQVMsRUFBRXVCLE1BQU0sRUFBRSxDQUFDO0FBQ3pELFVBQU1DLGVBQWMsb0JBQUlsRixLQUFLLEdBQUVtRixtQkFBbUIsU0FBUyxFQUFFQyxLQUFLLFdBQVc3RSxPQUFPLFFBQVFELE1BQU0sVUFBVSxDQUFDO0FBRTdHLFVBQU0rRSxVQUFVbkksV0FBV29JLFdBQVcsTUFBTSxJQUFJcEksYUFBYXFJLE9BQU9DLFNBQVNDLFNBQVN2STtBQUV0RixXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FLdUJ5SCxPQUFPZSxRQUFRLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQTBUNUJMLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBEQVF1QkgsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0NBdUJ0QlAsT0FBT2UsUUFBUSxLQUFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0NBSXBCZixPQUFPZ0IsZ0JBQWdCaEIsT0FBT3pCLEtBQUsrQixNQUFNLEVBQUUsS0FBSyxLQUFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0NBSXJETixPQUFPaUIsZ0JBQWdCLEtBQUs7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQ0FJNUJoQixNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBZ0J4QmxHLGFBQWFFLGtCQUFrQmlHLGVBQWUsU0FBUyxFQUFFZ0IsdUJBQXVCLEVBQUUsQ0FBQyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBSXJGekgsbUJBQW1CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBSW5CSSxVQUFVaUUsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUloQi9ELGFBQWFLLGdCQUFnQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUk3QkwsYUFBYU0sY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBLHVFQUlnQk4sYUFBYUcsaUJBQWlCZ0csZUFBZSxTQUFTLEVBQUVnQix1QkFBdUIsRUFBRSxDQUFDLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1EQVF2R25ILGFBQWFHLGlCQUFpQmdHLGVBQWUsU0FBUyxFQUFFZ0IsdUJBQXVCLEVBQUUsQ0FBQyxDQUFDO0FBQUE7QUFBQSw2QkFFekdmLGFBQWE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWN4QmpGLHFCQUFxQixhQUFhQSxrQkFBa0IsZ0RBQWdELEVBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJdEdGLGdCQUFnQixhQUFhQSxhQUFhLGtEQUFrRCxFQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQjlHO0FBRUEsUUFBTW1HLHFCQUFxQixZQUFZO0FBQ3JDLFFBQUksQ0FBQ3pHLHlCQUF5QjtBQUM1QjFELGNBQVFvSCxRQUFRLHVEQUF1RDtBQUN2RTtBQUFBLElBQ0Y7QUFFQXJELHVCQUFtQixJQUFJO0FBQ3ZCLFFBQUk7QUFDRixZQUFNcUcsY0FBY3JCLDZCQUE2QjtBQUNqRCxZQUFNQyxRQUFRdEY7QUFDZCxZQUFNdUYsU0FBU2hILHNCQUFzQixVQUFVRSxvQkFBb0IsR0FBR21CLFFBQVEsT0FBT0UsTUFBTTtBQUMzRixZQUFNNkcsV0FBVyxrQkFBa0JyQixPQUFPZSxRQUFRLE9BQU8sSUFBSWQsTUFBTTtBQUVuRSxZQUFNcUIsVUFBVUMsU0FBU0MsY0FBYyxLQUFLO0FBQzVDRixjQUFRRyxNQUFNQyxXQUFXO0FBQ3pCSixjQUFRRyxNQUFNRSxPQUFPO0FBQ3JCTCxjQUFRRyxNQUFNRyxNQUFNO0FBQ3BCTixjQUFRRyxNQUFNSSxRQUFRO0FBQ3RCUCxjQUFRRyxNQUFNSyxrQkFBa0I7QUFDaENSLGNBQVFTLFlBQVlYO0FBQ3BCRyxlQUFTUyxLQUFLQyxZQUFZWCxPQUFPO0FBRWpDLFlBQU0sSUFBSVksUUFBUSxDQUFBQyxNQUFLQyxXQUFXRCxHQUFHLEdBQUcsQ0FBQztBQUV6QyxZQUFNRSxTQUFTLE1BQU01SixZQUFZNkksU0FBUztBQUFBLFFBQ3hDZ0IsT0FBTztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxRQUNUVCxpQkFBaUI7QUFBQSxRQUNqQlUsU0FBUztBQUFBLFFBQ1RDLGFBQWE7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsd0JBQXdCO0FBQUEsTUFDMUIsQ0FBQztBQUVELFlBQU1DLFVBQVVQLE9BQU9RLFVBQVUsV0FBVztBQUM1QyxZQUFNQyxNQUFNLElBQUl0SyxNQUFNLEtBQUssTUFBTSxJQUFJO0FBQ3JDLFlBQU11SyxZQUFZO0FBQ2xCLFlBQU1DLGFBQWE7QUFDbkIsWUFBTUMsV0FBV0Y7QUFDakIsWUFBTUcsWUFBYWIsT0FBT2MsU0FBU0YsV0FBWVosT0FBT1I7QUFFdERpQixVQUFJTSxTQUFTUixTQUFTLE9BQU8sR0FBRyxHQUFHSyxVQUFVQyxTQUFTO0FBQ3RESixVQUFJTyxLQUFLaEMsUUFBUTtBQUVqQkUsZUFBU1MsS0FBS3NCLFlBQVloQyxPQUFPO0FBQ2pDdEssY0FBUW1HLFFBQVEseUNBQXlDO0FBQUEsSUFDM0QsU0FBU1osT0FBTztBQUNkRCxjQUFRQyxNQUFNLHlCQUF5QkEsS0FBSztBQUM1Q3ZGLGNBQVF1RixNQUFNLG1DQUFtQztBQUFBLElBQ25ELFVBQUM7QUFDQ3hCLHlCQUFtQixLQUFLO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBRUEsUUFBTXdJLGtCQUFrQkEsTUFBTTtBQUM1QixRQUFJLENBQUM3SSx5QkFBeUI7QUFDNUIxRCxjQUFRb0gsUUFBUSx1REFBdUQ7QUFDdkU7QUFBQSxJQUNGO0FBRUEsVUFBTWdELGNBQWNyQiw2QkFBNkI7QUFDakQsVUFBTUMsUUFBUXRGO0FBQ2QsVUFBTXVGLFNBQVNoSCxzQkFBc0IsVUFBVUUsb0JBQW9CLEdBQUdtQixRQUFRLE9BQU9FLE1BQU07QUFDM0YsVUFBTTZHLFdBQVcsa0JBQWtCckIsT0FBT2UsUUFBUSxPQUFPLElBQUlkLE1BQU07QUFFbkUsVUFBTXVELGNBQWM1QyxPQUFPNkMsS0FBSyxJQUFJLFFBQVE7QUFDNUNELGdCQUFZakMsU0FBU21DLE1BQU10QyxXQUFXO0FBQ3RDb0MsZ0JBQVlqQyxTQUFTb0MsUUFBUXRDO0FBQzdCbUMsZ0JBQVlqQyxTQUFTcUMsTUFBTTtBQUMzQkosZ0JBQVlLLE1BQU07QUFDbEJ6QixlQUFXLE1BQU07QUFDZm9CLGtCQUFZTSxNQUFNO0FBQ2xCTixrQkFBWUksTUFBTTtBQUFBLElBQ3BCLEdBQUcsR0FBRztBQUFBLEVBQ1I7QUFFQSxRQUFNRyxxQkFBcUJsSyxVQUFVbUssSUFBSSxDQUFDQyxTQUFTQyxXQUFXO0FBQUEsSUFDNURDLEtBQUtGLFFBQVExRixPQUFPMkY7QUFBQUEsSUFDcEJFLEtBQUtGLFFBQVE7QUFBQSxJQUNiRyxVQUFVSixTQUFTSSxZQUFZSixTQUFTSyxXQUFXMUgsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsSUFDcEUySCxrQkFBa0JOLFNBQVNLLFdBQVcxSCxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxJQUN2RDRILGVBQWVQLFFBQVFRLFNBQVNDLGFBQWFULFFBQVFPLGlCQUFpQjtBQUFBLElBQ3RFdkQsY0FBY2dELFFBQVFRLFNBQVN4RCxnQkFBZ0JnRCxRQUFRaEQsZ0JBQWdCO0FBQUEsSUFDdkUwRCxVQUFVVixTQUFTVyxPQUFPQyxZQUFZWixRQUFRYSxXQUFXO0FBQUEsSUFDekRDLGFBQWFkLFFBQVFjLGVBQWVkLFFBQVFlLFVBQVU7QUFBQSxJQUN0REMsY0FBY2hCLFFBQVFpQixZQUFZakIsUUFBUWtCLFFBQVE7QUFBQSxJQUNsREMsWUFBWW5CLFNBQVNtQixjQUFjO0FBQUEsRUFDckMsRUFBRTtBQUVGLFFBQU1DLFVBQVU7QUFBQSxJQUNkLEVBQUVsQixLQUFLLE9BQU9tQixRQUFRLFFBQVE7QUFBQSxJQUM5QixFQUFFbkIsS0FBSyxZQUFZbUIsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRW5CLEtBQUssb0JBQW9CbUIsUUFBUSxtQkFBbUI7QUFBQSxJQUN0RCxFQUFFbkIsS0FBSyxpQkFBaUJtQixRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUVuQixLQUFLLGdCQUFnQm1CLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVuQixLQUFLLFlBQVltQixRQUFRLFdBQVc7QUFBQSxJQUN0QyxFQUFFbkIsS0FBSyxlQUFlbUIsUUFBUSxrQkFBa0I7QUFBQSxJQUNoRCxFQUFFbkIsS0FBSyxnQkFBZ0JtQixRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFbkIsS0FBSyxjQUFjbUIsUUFBUSxhQUFhO0FBQUEsRUFBQztBQUc3QyxRQUFNbEssUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFNQyxlQUFlLEdBQUdGLE1BQU1HLFlBQVksQ0FBQyxJQUFJQztBQUFBQSxJQUM3Q0osTUFBTUssU0FBUyxJQUFJO0FBQUEsRUFDckIsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUVsQixRQUFNNkosbUJBQW1CMU0sVUFBVXlGO0FBQUFBLElBQ2pDLENBQUNELFFBQVFBLElBQUlFLFFBQVF4RjtBQUFBQSxFQUN2QjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMkhBQTBILGtEQUF4STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsb0VBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2IsaUNBQUMsZUFBWSxXQUFVLDZCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdELEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsSUFFRSx1QkFBQyxRQUFLLFdBQVUsa0RBQ2hCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGlFQUNaO0FBQUEsaUNBQUMsWUFBUyxXQUFVLGlCQUFnQixNQUFNLE1BQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFBRztBQUFBLGFBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QiwrQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUscUZBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE1BQU07QUFBQTtBQUFBLGdCQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUVXLEtBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsMkVBQTBFLDhDQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLGdDQUErQiwwQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLFFBQU87QUFBQSxrQkFDUCxTQUFRO0FBQUEsa0JBRVI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsZUFBYztBQUFBLHNCQUNkLGdCQUFlO0FBQUEsc0JBQ2YsYUFBYTtBQUFBLHNCQUNiLEdBQUU7QUFBQTtBQUFBLG9CQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJa0I7QUFBQTtBQUFBLGdCQVZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxpQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4QkE7QUFBQTtBQUFBLFVBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW1DQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUc7QUFBQSxZQUNILFdBQVU7QUFBQSxZQUVWLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsTUFBTTtBQUFBO0FBQUEsZ0JBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRVcsS0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw0RUFBMkUscUNBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQStCLHNDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixNQUFLO0FBQUEsa0JBQ0wsUUFBTztBQUFBLGtCQUNQLFNBQVE7QUFBQSxrQkFFUjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxlQUFjO0FBQUEsc0JBQ2QsZ0JBQWU7QUFBQSxzQkFDZixhQUFhO0FBQUEsc0JBQ2IsR0FBRTtBQUFBO0FBQUEsb0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlrQjtBQUFBO0FBQUEsZ0JBVnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGlCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQTtBQUFBO0FBQUEsVUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUNBO0FBQUEsUUFHQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0EsSUFBRztBQUFBLFlBQ0gsV0FBVTtBQUFBLFlBRVYsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHlGQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixNQUFNO0FBQUE7QUFBQSxnQkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FFVyxLQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDZFQUE0RSxnREFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0Isc0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE1BQUs7QUFBQSxrQkFDTCxRQUFPO0FBQUEsa0JBQ1AsU0FBUTtBQUFBLGtCQUVSO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLGVBQWM7QUFBQSxzQkFDZCxnQkFBZTtBQUFBLHNCQUNmLGFBQWE7QUFBQSxzQkFDYixHQUFFO0FBQUE7QUFBQSxvQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSWtCO0FBQUE7QUFBQSxnQkFWcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsaUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUE7QUFBQSxVQWxDRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFtQ0Q7QUFBQSxXQS9HRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0hBLEtBakhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrSEE7QUFBQSxTQTdIQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEhGO0FBQUEsSUFFQSx1QkFBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FBRyxXQUFVLFFBQy9CO0FBQUEsNkJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkIsaUNBQUMsUUFBSyxXQUFVLCtDQUNkO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsZ0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsVUFDdkQsT0FBT2dCLGFBQWFFO0FBQUFBLFVBQ3BCLFdBQVc7QUFBQSxVQUNYLFFBQVEsdUJBQUMsZUFBWSxXQUFVLG9CQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLFVBQy9DLFlBQVksRUFBRXVMLE9BQU8sV0FBV0MsVUFBVSxPQUFPO0FBQUE7QUFBQSxRQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLcUQsS0FOdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QixpQ0FBQyxRQUFLLFdBQVUsK0NBQ2Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQiwrQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxVQUN0RCxPQUFPMUwsYUFBYUc7QUFBQUEsVUFDcEIsV0FBVztBQUFBLFVBQ1gsUUFBUSx1QkFBQyxnQkFBYSxXQUFVLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLFVBQy9DLFlBQVksRUFBRXNMLE9BQU8sV0FBV0MsVUFBVSxPQUFPO0FBQUE7QUFBQSxRQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLcUQsS0FOdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QixpQ0FBQyxRQUFLLFdBQVUsK0NBQ2Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQiw2QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxVQUNwRCxPQUFPMUwsYUFBYUk7QUFBQUEsVUFDcEIsUUFBUSx1QkFBQyxnQkFBYSxXQUFVLHFCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLFVBQ2pELFlBQVksRUFBRXFMLE9BQU8sV0FBV0MsVUFBVSxPQUFPO0FBQUE7QUFBQSxRQUpuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJcUQsS0FMdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlDQTtBQUFBLElBRUEsdUJBQUMsUUFBSyxXQUFVLDZCQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHNDQUNiLGlDQUFDLFFBQUcsV0FBVSxpRUFDWjtBQUFBLCtCQUFDLHNCQUFtQixXQUFVLG1CQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFBRztBQUFBLFdBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHdFQUNmO0FBQUEscUNBQUMsb0JBQWlCLFdBQVUsMkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsY0FBRztBQUFBLGlCQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQTtBQUFBLGNBQUMsTUFBTTtBQUFBLGNBQU47QUFBQSxnQkFDQyxPQUFPeE07QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDd0QsTUFBTXZELHFCQUFxQnVELEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxnQkFDcEQsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFFVjtBQUFBO0FBQUEsb0JBQUMsTUFBTTtBQUFBLG9CQUFOO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU8sRUFBRW1GLE9BQU8sT0FBTzZELFdBQVcsU0FBUztBQUFBLHNCQUFFO0FBQUE7QUFBQSxvQkFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQyxNQUFNO0FBQUEsb0JBQU47QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBTyxFQUFFN0QsT0FBTyxPQUFPNkQsV0FBVyxTQUFTO0FBQUEsc0JBQUU7QUFBQTtBQUFBLG9CQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQTtBQUFBO0FBQUEsY0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBa0JBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsd0VBQ2Y7QUFBQSxxQ0FBQyxnQkFBYSxXQUFVLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGNBQUc7QUFBQSxpQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPM00sc0JBQXNCNE07QUFBQUEsZ0JBQzdCLFVBQVUzTTtBQUFBQSxnQkFDVjtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLGNBQWMsQ0FBQzRNLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKL0csU0FBUyxFQUNUZ0gsWUFBWSxFQUNaQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxnQkFHaENsTixvQkFBVW1MO0FBQUFBLGtCQUFJLENBQUMzRixRQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxJQUFJRSxLQUNyQ0Y7QUFBQUEsd0JBQUkwQztBQUFBQSxvQkFBSztBQUFBLG9CQUFJMUMsSUFBSTRDO0FBQUFBLHVCQURBNUMsSUFBSUUsS0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtQkE7QUFBQSxZQUNDZ0gsb0JBQ0MsdUJBQUMsU0FBSSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsY0FDL0JBLGlCQUFpQnhFO0FBQUFBLGlCQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkE7QUFBQSxhQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMERBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUNkOUgsZ0NBQXNCLFVBQVUsaUJBQWlCLGVBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNDQSxzQkFBc0IsVUFDckI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0UscUJBQXFCO0FBQUEsZ0JBQzVCLEtBQUttQztBQUFBQSxnQkFDTCxVQUFVa0I7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLb0osSUFHcEo7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT25ELGdCQUFnQjtBQUFBLGdCQUN2QixVQUFVLENBQUNvRCxNQUFNbkQsZ0JBQWdCbUQsRUFBRUUsT0FBT0QsS0FBSztBQUFBLGdCQUMvQyxXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlvSjtBQUFBLGVBakJ4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSx3RUFDZjtBQUFBLHFDQUFDLHNCQUFtQixXQUFVLDJCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRDtBQUFBLGNBQUc7QUFBQSxpQkFEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLEtBQUk7QUFBQSxrQkFDSixPQUFPakQ7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDZ0QsTUFBTS9DLHVCQUF1QitDLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxrQkFDdEQsV0FBVTtBQUFBO0FBQUEsZ0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTXlKO0FBQUEsY0FFekosdUJBQUMsVUFBSyxXQUFVLDZFQUE0RSxpQkFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLGFBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQ0E7QUFBQSxRQUVDekQsc0JBQXNCLGdCQUNyQix1QkFBQyxTQUFJLFdBQVUsOENBQ2IsaUNBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPTSxjQUFjO0FBQUEsY0FDckIsVUFBVSxDQUFDa0QsTUFBTWpELGNBQWNpRCxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsY0FDN0MsV0FBVTtBQUFBO0FBQUEsWUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJb0o7QUFBQSxhQVJ0SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUdGLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU07QUFDYjFELHNDQUFzQixJQUFJO0FBQzFCMkIsMkNBQTJCLElBQUk7QUFDL0J2QixxQ0FBcUJrQyxZQUFZO0FBQ2pDNUIsdUNBQXVCLENBQUc7QUFDMUJJLDZCQUFhLEVBQUU7QUFDZkUsZ0NBQWdCO0FBQUEsa0JBQ2RDLGtCQUFrQjtBQUFBLGtCQUNsQkMsaUJBQWlCO0FBQUEsa0JBQ2pCQyxnQkFBZ0I7QUFBQSxrQkFDaEJDLGtCQUFrQjtBQUFBLGtCQUNsQkMsZ0JBQWdCO0FBQUEsZ0JBQ2xCLENBQUM7QUFDRFEsK0JBQWUsS0FBSztBQUNwQixzQkFBTU8sU0FBUSxvQkFBSUMsS0FBSztBQUN2QixzQkFBTU0sT0FBT1AsT0FBTUcsWUFBWTtBQUMvQixzQkFBTUssUUFBUVIsT0FBTUssU0FBUyxJQUFJO0FBQ2pDLHNCQUFNSSxXQUFXLEdBQUdGLElBQUksSUFBSUgsT0FBT0ksS0FBSyxFQUFFRixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQzFELHNCQUFNSSxVQUFVLElBQUlULEtBQUtNLE1BQU1DLE9BQU8sQ0FBQyxFQUFFRyxRQUFRO0FBQ2pEekMsZ0NBQWdCdUMsUUFBUTtBQUN4QnJDO0FBQUFBLGtCQUNFLEdBQUdtQyxJQUFJLElBQUlILE9BQU9JLEtBQUssRUFBRUYsU0FBUyxHQUFHLEdBQUcsQ0FBQyxJQUFJRixPQUFPTSxPQUFPLEVBQUVKLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFBQSxnQkFDL0U7QUFBQSxjQUNGO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBNEJBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsTUFBTSx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQ3pCO0FBQUEsY0FDQSxTQUFTeUM7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBNkc7QUFBQTtBQUFBLFlBTnpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsYUF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdDQTtBQUFBLFdBaktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrS0E7QUFBQSxTQTFLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMktBO0FBQUEsSUFJQ3ZELGVBQWVGLDJCQUNkLHVCQUFDLFFBQUssV0FBVSw2QkFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxtR0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxpRUFDWjtBQUFBLGlDQUFDLGdCQUFhLFdBQVUsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsVUFBRztBQUFBLGFBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdCO0FBQUEsY0FDdEIsU0FBUzZJO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQTBDO0FBQUE7QUFBQSxZQUh0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQU0sdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQSxjQUN2QixTQUFTekk7QUFBQUEsY0FDVCxTQUFTcUc7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBaUM7QUFBQTtBQUFBLFlBTDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFdBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaURBQWdELG9CQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsa0NBQ1Z6RyxtQ0FBeUJxRyxRQUFRLE9BRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxpREFBZ0QscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVnJHLG1DQUF5QnVMLFNBQVMsT0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlEQUFnRCxxQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGtDQUNWdkwsbUNBQXlCdUcsZ0JBQWdCLE9BRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQTtBQUFBLFNBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxREE7QUFBQSxJQUtEckcsZUFBZWYsVUFBVWlFLFNBQVMsS0FDakMsdUJBQUMsUUFBSyxXQUFVLDZCQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1FQUNiLGlDQUFDLFFBQUcsV0FBVSxpRUFDWjtBQUFBLCtCQUFDLGVBQVksV0FBVSxvQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQUc7QUFBQSxXQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxpREFBZ0Qsc0JBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSx3Q0FDVjdFLGdDQUFzQixXQUNuQixvQkFBSW9DLEtBQUssR0FBR2xDLGlCQUFpQixLQUFLLEdBQUUrRztBQUFBQSxZQUNsQztBQUFBLFlBQ0E7QUFBQSxjQUNFdEUsT0FBTztBQUFBLGNBQ1BELE1BQU07QUFBQSxZQUNSO0FBQUEsVUFDRixJQUNBLEdBQUdyQixRQUFRLE9BQU9FLE1BQU0sTUFUOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaURBQWdELDhCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUseUNBQ1ZmO0FBQUFBO0FBQUFBLFlBQW9CO0FBQUEsZUFEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaURBQWdELDZCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsMENBQ1ZJLG9CQUFVaUUsVUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxpREFBZ0QsZ0NBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FDWDtBQUFBLG1DQUFDLGVBQVksV0FBVSxzQ0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQ7QUFBQSxZQUN4RC9ELGFBQWFFLGtCQUFrQmlNLFFBQVEsQ0FBQztBQUFBLGVBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlEQUFnRCwrQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHdDQUNYO0FBQUEsbUNBQUMsZ0JBQWEsV0FBVSxxQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQ7QUFBQSxZQUN4RG5NLGFBQWFHLGlCQUFpQmdNLFFBQVEsQ0FBQztBQUFBLGVBRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1REEsS0F4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlEQTtBQUFBLFNBaEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpRUE7QUFBQSxJQUdEdk0sVUFDQyx1QkFBQyxTQUFJLFdBQVUsNkJBQ2IsaUNBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBaUIsZUFDQWYsVUFBVWlFLFNBQVMsS0FDakIsdUJBQUMsUUFBSyxXQUFVLHdDQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGlFQUNaO0FBQUEsaUNBQUMsc0JBQW1CLFdBQVUsbUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFBRztBQUFBLGFBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsVUFDL0JqRSxVQUFVaUU7QUFBQUEsVUFBTztBQUFBLGFBRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTWlHO0FBQUFBLFVBQ047QUFBQSxVQUNBLGlCQUFpQjtBQUFBLFVBQ2pCLGlCQUFpQjtBQUFBLFlBQ2Y7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUFlO0FBQUEsVUFFakIsbUJBQW1CO0FBQUEsWUFDakJySix5QkFBeUJxRyxRQUFRO0FBQUEsWUFDakNyRyx5QkFBeUJ1RyxnQkFBZ0I7QUFBQSxZQUN6Q2hJLHNCQUFzQixXQUNsQixvQkFBSW9DLEtBQUssR0FBR2xDLGlCQUFpQixLQUFLLEdBQUUrRztBQUFBQSxjQUNsQztBQUFBLGNBQ0E7QUFBQSxnQkFDRXRFLE9BQU87QUFBQSxnQkFDUEQsTUFBTTtBQUFBLGNBQ1I7QUFBQSxZQUNGLElBQ0EsR0FBR3JCLFFBQVEsT0FBT0UsTUFBTTtBQUFBLFlBQzVCLEdBQUdmLG1CQUFtQjtBQUFBLFlBQ3RCLElBQUlNLGFBQWFFLGtCQUFrQmlHLGVBQWUsT0FBTyxLQUFLLEdBQUc7QUFBQSxZQUNqRSxJQUFJbkcsYUFBYUcsaUJBQWlCZ0csZUFBZSxPQUFPLEtBQUssR0FBRztBQUFBLFlBQ2hFckcsVUFBVWlFLFVBQVU7QUFBQSxVQUFHO0FBQUEsVUFFekIsa0JBQWtCLHlCQUF5QnBELHlCQUF5QnFHLFFBQVEsS0FBSyxJQUMvRTlILHNCQUFzQixVQUNsQkUsb0JBQ0EsR0FBR21CLFFBQVEsT0FBT0UsTUFBTSxFQUFFO0FBQUE7QUFBQSxRQWpDbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Ba0NTLEtBbkNYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQ0E7QUFBQSxTQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0RBO0FBQUEsSUFJSEksZUFBZSxDQUFDakIsV0FBV0UsVUFBVWlFLFdBQVcsS0FDL0MsdUJBQUMsUUFBSyxXQUFVLHdCQUNkLGlDQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxPQUFFLFdBQVUscUNBQW9DLGlFQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQXJpQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVpQkE7QUFFSjtBQUFFbEYsR0E3ekNJRCxnQ0FBOEI7QUFBQXdOLEtBQTlCeE47QUErekNOLGVBQWVBO0FBQStCLElBQUF3TjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VSZWYiLCJTZWxlY3QiLCJSYWRpbyIsIkNhcmQiLCJCdXR0b24iLCJTcGFjZSIsIkRpdmlkZXIiLCJUYWciLCJTdGF0aXN0aWMiLCJSb3ciLCJDb2wiLCJEYXRlUGlja2VyIiwiTW9kYWwiLCJtZXNzYWdlIiwiVXBsb2FkIiwiVXNlck91dGxpbmVkIiwiQ2FsZW5kYXJPdXRsaW5lZCIsIlBlcmNlbnRhZ2VPdXRsaW5lZCIsIkZpbGVTZWFyY2hPdXRsaW5lZCIsIlRlYW1PdXRsaW5lZCIsIlJpc2VPdXRsaW5lZCIsIlByaW50ZXJPdXRsaW5lZCIsIkRvd25sb2FkT3V0bGluZWQiLCJTaWduYXR1cmVPdXRsaW5lZCIsIlVwbG9hZE91dGxpbmVkIiwiYXBpIiwibW9tZW50IiwiRmFSdXBlZVNpZ24iLCJGYVBpZ2d5QmFuayIsIkZhU3RhbXAiLCJGaVRhcmdldCIsIk1kQ3VycmVuY3lSdXBlZSIsIk1kR3JvdXBzIiwiTGluayIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiaW1hZ2VJbnB1dCIsImpzUERGIiwiaHRtbDJjYW52YXMiLCJSYW5nZVBpY2tlciIsIlBpZ215Q29sbGVjdGlvbkluY2VudGl2ZVJlcG9ydCIsIl9zIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwic2VsZWN0ZWRFbXBsb3llZUlkIiwic2V0U2VsZWN0ZWRFbXBsb3llZUlkIiwiZGF0ZVNlbGVjdGlvbk1vZGUiLCJzZXREYXRlU2VsZWN0aW9uTW9kZSIsInRlbXBTZWxlY3RlZE1vbnRoIiwic2V0VGVtcFNlbGVjdGVkTW9udGgiLCJ0ZW1wRnJvbURhdGUiLCJzZXRUZW1wRnJvbURhdGUiLCJ0ZW1wVG9EYXRlIiwic2V0VGVtcFRvRGF0ZSIsImluY2VudGl2ZVBlcmNlbnRhZ2UiLCJzZXRJbmNlbnRpdmVQZXJjZW50YWdlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJwaWdteURhdGEiLCJzZXRQaWdteURhdGEiLCJwaWdteVN1bW1hcnkiLCJzZXRQaWdteVN1bW1hcnkiLCJ0b3RhbF9jb2xsZWN0aW9uIiwidG90YWxfaW5jZW50aXZlIiwidG90YWxfcGF5bWVudHMiLCJjb21wbGV0ZWRfcGlnbXlzIiwicGVuZGluZ19waWdteXMiLCJmcm9tRGF0ZSIsInNldEZyb21EYXRlIiwidG9EYXRlIiwic2V0VG9EYXRlIiwic2VsZWN0ZWRFbXBsb3llZURldGFpbHMiLCJzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlscyIsImlzRmlsdGVyaW5nIiwic2V0SXNGaWx0ZXJpbmciLCJpc0dlbmVyYXRpbmdQREYiLCJzZXRJc0dlbmVyYXRpbmdQREYiLCJzaWduYXR1cmVEYXRhIiwic2V0U2lnbmF0dXJlRGF0YSIsImFnZW50U2lnbmF0dXJlRGF0YSIsInNldEFnZW50U2lnbmF0dXJlRGF0YSIsInRvZGF5IiwiRGF0ZSIsImN1cnJlbnRNb250aCIsImdldEZ1bGxZZWFyIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsInllYXIiLCJtb250aCIsImZpcnN0RGF5IiwibGFzdERheSIsImdldERhdGUiLCJmZXRjaEVtcGxveWVlcyIsInJlcyIsImdldCIsImRhdGEiLCJlbXBsb3llZSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZVRlbXBNb250aENoYW5nZSIsImUiLCJ2YWx1ZSIsInRhcmdldCIsInNwbGl0IiwiZmV0Y2hQaWdteUNvbGxlY3Rpb25EYXRhIiwiZW1wbG95ZWVJZCIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJyZXNwb25zZSIsInBhcmFtcyIsInN1Y2Nlc3MiLCJyZXNwb25zZURhdGEiLCJhbGxQYXltZW50cyIsInRvdGFsQ29sbGVjdGlvbiIsInRvdGFsSW5jZW50aXZlIiwiZm9yRWFjaCIsIml0ZW0iLCJwYXltZW50cyIsIkFycmF5IiwiaXNBcnJheSIsImluY2VudGl2ZV9hbW91bnQiLCJsZW5ndGgiLCJmaWx0ZXIiLCJwIiwic3RhdHVzIiwiaXNfY29tcGxldGVkIiwiaGFuZGxlQ29udGludWUiLCJ3YXJuaW5nIiwiZW1wIiwiZmluZCIsIl9pZCIsIm51bVRvV29yZHMiLCJudW0iLCJpc05hTiIsImEiLCJiIiwiTWF0aCIsInJvdW5kIiwidG9TdHJpbmciLCJuIiwic3Vic3RyIiwibWF0Y2giLCJzdHIiLCJOdW1iZXIiLCJ0cmltIiwiaGFuZGxlU2lnbmF0dXJlQ2hhbmdlIiwidHlwZSIsImZpbGUiLCJmaWxlcyIsInJlYWRlciIsIkZpbGVSZWFkZXIiLCJvbmxvYWRlbmQiLCJyZXN1bHQiLCJyZWFkQXNEYXRhVVJMIiwiZ2VuZXJhdGVJbmNlbnRpdmVTbGlwQ29udGVudCIsImFnZW50IiwicGVyaW9kIiwidG9Mb2NhbGVTdHJpbmciLCJhbW91bnRJbldvcmRzIiwic2xpcE51bWJlciIsIm5vdyIsInNsaWNlIiwiY3VycmVudERhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJsb2dvVXJsIiwic3RhcnRzV2l0aCIsIndpbmRvdyIsImxvY2F0aW9uIiwib3JpZ2luIiwibmFtZSIsImVtcGxveWVlQ29kZSIsInBob25lX251bWJlciIsIm1pbmltdW1GcmFjdGlvbkRpZ2l0cyIsImhhbmRsZUdlbmVyYXRlU2xpcCIsImh0bWxDb250ZW50IiwiZmlsZU5hbWUiLCJ0ZW1wRGl2IiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50Iiwic3R5bGUiLCJwb3NpdGlvbiIsImxlZnQiLCJ0b3AiLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsImlubmVySFRNTCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsIlByb21pc2UiLCJyIiwic2V0VGltZW91dCIsImNhbnZhcyIsInNjYWxlIiwidXNlQ09SUyIsImxvZ2dpbmciLCJ3aW5kb3dXaWR0aCIsImFsbG93VGFpbnQiLCJmb3JlaWduT2JqZWN0UmVuZGVyaW5nIiwiaW1nRGF0YSIsInRvRGF0YVVSTCIsInBkZiIsInBhZ2VXaWR0aCIsInBhZ2VIZWlnaHQiLCJpbWdXaWR0aCIsImltZ0hlaWdodCIsImhlaWdodCIsImFkZEltYWdlIiwic2F2ZSIsInJlbW92ZUNoaWxkIiwiaGFuZGxlUHJpbnRTbGlwIiwicHJpbnRXaW5kb3ciLCJvcGVuIiwid3JpdGUiLCJ0aXRsZSIsImNsb3NlIiwiZm9jdXMiLCJwcmludCIsInByb2Nlc3NlZFRhYmxlRGF0YSIsIm1hcCIsInBheW1lbnQiLCJpbmRleCIsImtleSIsInNubyIsInBheV9kYXRlIiwiY3JlYXRlZEF0IiwidHJhbnNhY3Rpb25fZGF0ZSIsImN1c3RvbWVyX25hbWUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwicGlnbXlfaWQiLCJwaWdtZSIsInBpZ21lX2lkIiwicGlnbXlJZCIsInBhaWRfYW1vdW50IiwiYW1vdW50IiwicGF5bWVudF9tb2RlIiwicGF5X3R5cGUiLCJtb2RlIiwicmVjZWlwdF9ubyIsImNvbHVtbnMiLCJoZWFkZXIiLCJzZWxlY3RlZEVtcGxveWVlIiwiY29sb3IiLCJmb250U2l6ZSIsInRleHRBbGlnbiIsInVuZGVmaW5lZCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZW1haWwiLCJ0b0ZpeGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGlnbXlDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgU2VsZWN0LFxyXG4gIFJhZGlvLFxyXG4gIENhcmQsXHJcbiAgQnV0dG9uLFxyXG4gIFNwYWNlLFxyXG4gIERpdmlkZXIsXHJcbiAgVGFnLFxyXG4gIFN0YXRpc3RpYyxcclxuICBSb3csXHJcbiAgQ29sLFxyXG4gIERhdGVQaWNrZXIsXHJcbiAgTW9kYWwsXHJcbiAgbWVzc2FnZSxcclxuICBVcGxvYWQsXHJcbn0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHtcclxuICBVc2VyT3V0bGluZWQsXHJcbiAgQ2FsZW5kYXJPdXRsaW5lZCxcclxuICBQZXJjZW50YWdlT3V0bGluZWQsXHJcbiAgRmlsZVNlYXJjaE91dGxpbmVkLFxyXG4gIFRlYW1PdXRsaW5lZCxcclxuICBSaXNlT3V0bGluZWQsXHJcbiAgUHJpbnRlck91dGxpbmVkLFxyXG4gIERvd25sb2FkT3V0bGluZWQsXHJcbiAgU2lnbmF0dXJlT3V0bGluZWQsXHJcbiAgVXBsb2FkT3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IG1vbWVudCBmcm9tIFwibW9tZW50XCI7XHJcbmltcG9ydCB7IEZhUnVwZWVTaWduLCBGYVBpZ2d5QmFuaywgRmFTdGFtcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBGaVRhcmdldCB9IGZyb20gXCJyZWFjdC1pY29ucy9maVwiO1xyXG5pbXBvcnQgeyBNZEN1cnJlbmN5UnVwZWUgLE1kR3JvdXBzIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBpbWFnZUlucHV0IGZyb20gXCIuLi9hc3NldHMvaW1hZ2VzL0xvZ28uc3ZnXCI7XHJcbmltcG9ydCBqc1BERiBmcm9tIFwianNwZGZcIjtcclxuaW1wb3J0IGh0bWwyY2FudmFzIGZyb20gXCJodG1sMmNhbnZhc1wiO1xyXG5cclxuY29uc3QgeyBSYW5nZVBpY2tlciB9ID0gRGF0ZVBpY2tlcjtcclxuXHJcbmNvbnN0IFBpZ215Q29sbGVjdGlvbkluY2VudGl2ZVJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlSWQsIHNldFNlbGVjdGVkRW1wbG95ZWVJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZGF0ZVNlbGVjdGlvbk1vZGUsIHNldERhdGVTZWxlY3Rpb25Nb2RlXSA9IHVzZVN0YXRlKFwibW9udGhcIik7XHJcbiAgY29uc3QgW3RlbXBTZWxlY3RlZE1vbnRoLCBzZXRUZW1wU2VsZWN0ZWRNb250aF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdGVtcEZyb21EYXRlLCBzZXRUZW1wRnJvbURhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RlbXBUb0RhdGUsIHNldFRlbXBUb0RhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2luY2VudGl2ZVBlcmNlbnRhZ2UsIHNldEluY2VudGl2ZVBlcmNlbnRhZ2VdID0gdXNlU3RhdGUoMy4wKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3BpZ215RGF0YSwgc2V0UGlnbXlEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcGlnbXlTdW1tYXJ5LCBzZXRQaWdteVN1bW1hcnldID0gdXNlU3RhdGUoe1xyXG4gICAgdG90YWxfY29sbGVjdGlvbjogMCxcclxuICAgIHRvdGFsX2luY2VudGl2ZTogMCxcclxuICAgIHRvdGFsX3BheW1lbnRzOiAwLFxyXG4gICAgY29tcGxldGVkX3BpZ215czogMCxcclxuICAgIHBlbmRpbmdfcGlnbXlzOiAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtmcm9tRGF0ZSwgc2V0RnJvbURhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RvRGF0ZSwgc2V0VG9EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlRGV0YWlscywgc2V0U2VsZWN0ZWRFbXBsb3llZURldGFpbHNdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2lzRmlsdGVyaW5nLCBzZXRJc0ZpbHRlcmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzR2VuZXJhdGluZ1BERiwgc2V0SXNHZW5lcmF0aW5nUERGXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2lnbmF0dXJlRGF0YSwgc2V0U2lnbmF0dXJlRGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbYWdlbnRTaWduYXR1cmVEYXRhLCBzZXRBZ2VudFNpZ25hdHVyZURhdGFdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBjdXJyZW50TW9udGggPSBgJHt0b2RheS5nZXRGdWxsWWVhcigpfS0ke1N0cmluZyhcclxuICAgICAgdG9kYXkuZ2V0TW9udGgoKSArIDEsXHJcbiAgICApLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG5cclxuICAgIHNldFRlbXBTZWxlY3RlZE1vbnRoKGN1cnJlbnRNb250aCk7XHJcblxyXG4gICAgY29uc3QgeWVhciA9IHRvZGF5LmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtb250aCA9IHRvZGF5LmdldE1vbnRoKCkgKyAxO1xyXG4gICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfS0wMWA7XHJcbiAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLmdldERhdGUoKTtcclxuXHJcbiAgICBzZXRUZW1wRnJvbURhdGUoZmlyc3REYXkpO1xyXG4gICAgc2V0VGVtcFRvRGF0ZShcclxuICAgICAgYCR7eWVhcn0tJHtTdHJpbmcobW9udGgpLnBhZFN0YXJ0KDIsIFwiMFwiKX0tJHtTdHJpbmcobGFzdERheSkucGFkU3RhcnQoMiwgXCIwXCIpfWAsXHJcbiAgICApO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRW1wbG95ZWVzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvZW1wbG95ZWVcIik7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKHJlcz8uZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVGVtcE1vbnRoQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHZhbHVlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRUZW1wU2VsZWN0ZWRNb250aCh2YWx1ZSk7XHJcbiAgICBpZiAodmFsdWUpIHtcclxuICAgICAgY29uc3QgW3llYXIsIG1vbnRoXSA9IHZhbHVlLnNwbGl0KFwiLVwiKTtcclxuICAgICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke21vbnRofS0wMWA7XHJcbiAgICAgIGNvbnN0IGxhc3REYXkgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgMCkuZ2V0RGF0ZSgpO1xyXG4gICAgICBzZXRUZW1wRnJvbURhdGUoZmlyc3REYXkpO1xyXG4gICAgICBzZXRUZW1wVG9EYXRlKGAke3llYXJ9LSR7bW9udGh9LSR7U3RyaW5nKGxhc3REYXkpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFBpZ215Q29sbGVjdGlvbkRhdGEgPSBhc3luYyAoZW1wbG95ZWVJZCwgc3RhcnREYXRlLCBlbmREYXRlKSA9PiB7XHJcbiAgICBpZiAoIWVtcGxveWVlSWQgfHwgIXN0YXJ0RGF0ZSB8fCAhZW5kRGF0ZSkgcmV0dXJuO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3YxL2FkbWluL3BheW1lbnRzL3BpZ215cy9jb2xsZWN0aW9uLWFnZW50cy8ke2VtcGxveWVlSWR9LyR7aW5jZW50aXZlUGVyY2VudGFnZX1gLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICBzdGFydERhdGU6IHN0YXJ0RGF0ZSxcclxuICAgICAgICAgICAgZW5kRGF0ZTogZW5kRGF0ZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuc3VjY2Vzcykge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgbGV0IGFsbFBheW1lbnRzID0gW107XHJcbiAgICAgICAgbGV0IHRvdGFsQ29sbGVjdGlvbiA9IDA7XHJcbiAgICAgICAgbGV0IHRvdGFsSW5jZW50aXZlID0gMDtcclxuXHJcbiAgICAgICAgcmVzcG9uc2VEYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICAgIGlmIChpdGVtLnBheW1lbnRzICYmIEFycmF5LmlzQXJyYXkoaXRlbS5wYXltZW50cykpIHtcclxuICAgICAgICAgICAgYWxsUGF5bWVudHMgPSBbLi4uYWxsUGF5bWVudHMsIC4uLml0ZW0ucGF5bWVudHNdO1xyXG4gICAgICAgICAgICB0b3RhbENvbGxlY3Rpb24gKz0gaXRlbS50b3RhbF9wYXltZW50cyB8fCAwO1xyXG4gICAgICAgICAgICB0b3RhbEluY2VudGl2ZSArPSBpdGVtLmluY2VudGl2ZV9hbW91bnQgfHwgMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0UGlnbXlEYXRhKGFsbFBheW1lbnRzKTtcclxuICAgICAgICBzZXRQaWdteVN1bW1hcnkoe1xyXG4gICAgICAgICAgdG90YWxfY29sbGVjdGlvbjogdG90YWxDb2xsZWN0aW9uLFxyXG4gICAgICAgICAgdG90YWxfaW5jZW50aXZlOiB0b3RhbEluY2VudGl2ZSxcclxuICAgICAgICAgIHRvdGFsX3BheW1lbnRzOiBhbGxQYXltZW50cy5sZW5ndGgsXHJcbiAgICAgICAgICBjb21wbGV0ZWRfcGlnbXlzOiBhbGxQYXltZW50cy5maWx0ZXIoXHJcbiAgICAgICAgICAgIChwKSA9PiBwLnN0YXR1cyA9PT0gXCJjb21wbGV0ZWRcIiB8fCBwLmlzX2NvbXBsZXRlZCxcclxuICAgICAgICAgICkubGVuZ3RoLFxyXG4gICAgICAgICAgcGVuZGluZ19waWdteXM6IGFsbFBheW1lbnRzLmZpbHRlcihcclxuICAgICAgICAgICAgKHApID0+IHAuc3RhdHVzICE9PSBcImNvbXBsZXRlZFwiICYmICFwLmlzX2NvbXBsZXRlZCxcclxuICAgICAgICAgICkubGVuZ3RoLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldFBpZ215RGF0YShbXSk7XHJcbiAgICAgICAgc2V0UGlnbXlTdW1tYXJ5KHtcclxuICAgICAgICAgIHRvdGFsX2NvbGxlY3Rpb246IDAsXHJcbiAgICAgICAgICB0b3RhbF9pbmNlbnRpdmU6IDAsXHJcbiAgICAgICAgICB0b3RhbF9wYXltZW50czogMCxcclxuICAgICAgICAgIGNvbXBsZXRlZF9waWdteXM6IDAsXHJcbiAgICAgICAgICBwZW5kaW5nX3BpZ215czogMCxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwaWdteSBjb2xsZWN0aW9uIGRhdGE6XCIsIGVycik7XHJcbiAgICAgIHNldFBpZ215RGF0YShbXSk7XHJcbiAgICAgIHNldFBpZ215U3VtbWFyeSh7XHJcbiAgICAgICAgdG90YWxfY29sbGVjdGlvbjogMCxcclxuICAgICAgICB0b3RhbF9pbmNlbnRpdmU6IDAsXHJcbiAgICAgICAgdG90YWxfcGF5bWVudHM6IDAsXHJcbiAgICAgICAgY29tcGxldGVkX3BpZ215czogMCxcclxuICAgICAgICBwZW5kaW5nX3BpZ215czogMCxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29udGludWUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkRW1wbG95ZWVJZCkge1xyXG4gICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2Ugc2VsZWN0IGFuIGVtcGxveWVlLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiICYmICF0ZW1wU2VsZWN0ZWRNb250aCkge1xyXG4gICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2Ugc2VsZWN0IGEgbW9udGguXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcImRhdGUtcmFuZ2VcIiAmJiAoIXRlbXBGcm9tRGF0ZSB8fCAhdGVtcFRvRGF0ZSkpIHtcclxuICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIHNlbGVjdCBib3RoIEZyb20gYW5kIFRvIGRhdGVzLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzRmlsdGVyaW5nKHRydWUpO1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICBsZXQgc3RhcnREYXRlLCBlbmREYXRlO1xyXG5cclxuICAgIGlmIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSB0ZW1wU2VsZWN0ZWRNb250aC5zcGxpdChcIi1cIik7XHJcbiAgICAgIHN0YXJ0RGF0ZSA9IGAke3llYXJ9LSR7bW9udGh9LTAxYDtcclxuICAgICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XHJcbiAgICAgIGVuZERhdGUgPSBgJHt5ZWFyfS0ke21vbnRofS0ke1N0cmluZyhsYXN0RGF5KS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICAgICAgc2V0RnJvbURhdGUoc3RhcnREYXRlKTtcclxuICAgICAgc2V0VG9EYXRlKGVuZERhdGUpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc3RhcnREYXRlID0gdGVtcEZyb21EYXRlO1xyXG4gICAgICBlbmREYXRlID0gdGVtcFRvRGF0ZTtcclxuICAgICAgc2V0RnJvbURhdGUoc3RhcnREYXRlKTtcclxuICAgICAgc2V0VG9EYXRlKGVuZERhdGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGVtcCA9IGVtcGxveWVlcy5maW5kKChlKSA9PiBlLl9pZCA9PT0gc2VsZWN0ZWRFbXBsb3llZUlkKTtcclxuICAgICAgc2V0U2VsZWN0ZWRFbXBsb3llZURldGFpbHMoZW1wIHx8IG51bGwpO1xyXG4gICAgICBhd2FpdCBmZXRjaFBpZ215Q29sbGVjdGlvbkRhdGEoc2VsZWN0ZWRFbXBsb3llZUlkLCBzdGFydERhdGUsIGVuZERhdGUpO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJEYXRhIGxvYWRlZCBzdWNjZXNzZnVsbHkhXCIpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIGhhbmRsZUNvbnRpbnVlOlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBkYXRhXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgbnVtVG9Xb3JkcyA9IChudW0pID0+IHtcclxuICAgIGlmIChpc05hTihudW0pIHx8IG51bSA9PT0gMCkgcmV0dXJuIFwiWmVyb1wiO1xyXG4gICAgXHJcbiAgICBjb25zdCBhID0gW1xyXG4gICAgICBcIlwiLCBcIk9uZVwiLCBcIlR3b1wiLCBcIlRocmVlXCIsIFwiRm91clwiLCBcIkZpdmVcIiwgXCJTaXhcIiwgXCJTZXZlblwiLCBcIkVpZ2h0XCIsIFwiTmluZVwiLCBcclxuICAgICAgXCJUZW5cIiwgXCJFbGV2ZW5cIiwgXCJUd2VsdmVcIiwgXCJUaGlydGVlblwiLCBcIkZvdXJ0ZWVuXCIsIFwiRmlmdGVlblwiLCBcIlNpeHRlZW5cIiwgXHJcbiAgICAgIFwiU2V2ZW50ZWVuXCIsIFwiRWlnaHRlZW5cIiwgXCJOaW5ldGVlblwiXHJcbiAgICBdO1xyXG4gICAgY29uc3QgYiA9IFtcIlwiLCBcIlwiLCBcIlR3ZW50eVwiLCBcIlRoaXJ0eVwiLCBcIkZvcnR5XCIsIFwiRmlmdHlcIiwgXCJTaXh0eVwiLCBcIlNldmVudHlcIiwgXCJFaWdodHlcIiwgXCJOaW5ldHlcIl07XHJcbiAgICBcclxuICAgIG51bSA9IE1hdGgucm91bmQobnVtKTtcclxuICAgIGlmICgobnVtID0gbnVtLnRvU3RyaW5nKCkpLmxlbmd0aCA+IDkpIHJldHVybiBcIk92ZXJmbG93XCI7XHJcbiAgICBcclxuICAgIGNvbnN0IG4gPSAoXCIwMDAwMDAwMDBcIiArIG51bSkuc3Vic3RyKC05KS5tYXRjaCgvXihcXGR7Mn0pKFxcZHsyfSkoXFxkezJ9KShcXGR7MX0pKFxcZHsyfSkkLyk7XHJcbiAgICBpZiAoIW4pIHJldHVybiBcIlwiO1xyXG4gICAgXHJcbiAgICBsZXQgc3RyID0gXCJcIjtcclxuICAgIHN0ciArPSBuWzFdICE9IDAgPyAoYVtOdW1iZXIoblsxXSldIHx8IGJbblsxXVswXV0gKyBcIiBcIiArIGFbblsxXVsxXV0pICsgXCIgQ3JvcmUgXCIgOiBcIlwiO1xyXG4gICAgc3RyICs9IG5bMl0gIT0gMCA/IChhW051bWJlcihuWzJdKV0gfHwgYltuWzJdWzBdXSArIFwiIFwiICsgYVtuWzJdWzFdXSkgKyBcIiBMYWtoIFwiIDogXCJcIjtcclxuICAgIHN0ciArPSBuWzNdICE9IDAgPyAoYVtOdW1iZXIoblszXSldIHx8IGJbblszXVswXV0gKyBcIiBcIiArIGFbblszXVsxXV0pICsgXCIgVGhvdXNhbmQgXCIgOiBcIlwiO1xyXG4gICAgc3RyICs9IG5bNF0gIT0gMCA/IChhW051bWJlcihuWzRdKV0gfHwgYltuWzRdWzBdXSArIFwiIFwiICsgYVtuWzRdWzFdXSkgKyBcIiBIdW5kcmVkIFwiIDogXCJcIjtcclxuICAgIHN0ciArPSBuWzVdICE9IDAgPyAoc3RyICE9IFwiXCIgPyBcImFuZCBcIiA6IFwiXCIpICsgKGFbTnVtYmVyKG5bNV0pXSB8fCBiW25bNV1bMF1dICsgXCIgXCIgKyBhW25bNV1bMV1dKSArIFwiIFwiIDogXCJcIjtcclxuICAgIFxyXG4gICAgcmV0dXJuIHN0ci50cmltKCkgfHwgXCJaZXJvXCI7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2lnbmF0dXJlQ2hhbmdlID0gKGUsIHR5cGUpID0+IHtcclxuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcclxuICAgIGlmIChmaWxlKSB7XHJcbiAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcbiAgICAgIHJlYWRlci5vbmxvYWRlbmQgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKHR5cGUgPT09ICdtYW5hZ2VyJykge1xyXG4gICAgICAgICAgc2V0U2lnbmF0dXJlRGF0YShyZWFkZXIucmVzdWx0KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0QWdlbnRTaWduYXR1cmVEYXRhKHJlYWRlci5yZXN1bHQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2VuZXJhdGVJbmNlbnRpdmVTbGlwQ29udGVudCA9ICgpID0+IHtcclxuICAgIGNvbnN0IGFnZW50ID0gc2VsZWN0ZWRFbXBsb3llZURldGFpbHM7XHJcbiAgICBjb25zdCBwZXJpb2QgPSBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgID8gbmV3IERhdGUoYCR7dGVtcFNlbGVjdGVkTW9udGh9LTAxYCkudG9Mb2NhbGVTdHJpbmcoXCJkZWZhdWx0XCIsIHsgbW9udGg6IFwibG9uZ1wiLCB5ZWFyOiBcIm51bWVyaWNcIiB9KVxyXG4gICAgICA6IGAke2Zyb21EYXRlfSB0byAke3RvRGF0ZX1gO1xyXG4gICAgXHJcbiAgICBjb25zdCBhbW91bnRJbldvcmRzID0gbnVtVG9Xb3JkcyhwaWdteVN1bW1hcnkudG90YWxfaW5jZW50aXZlKTtcclxuICAgIGNvbnN0IHNsaXBOdW1iZXIgPSBgSU5DLSR7RGF0ZS5ub3coKS50b1N0cmluZygpLnNsaWNlKC02KX1gO1xyXG4gICAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tSU4nLCB7IGRheTogJ251bWVyaWMnLCBtb250aDogJ2xvbmcnLCB5ZWFyOiAnbnVtZXJpYycgfSk7XHJcblxyXG4gICAgY29uc3QgbG9nb1VybCA9IGltYWdlSW5wdXQuc3RhcnRzV2l0aCgnaHR0cCcpID8gaW1hZ2VJbnB1dCA6IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gKyBpbWFnZUlucHV0O1xyXG5cclxuICAgIHJldHVybiBgXHJcbiAgICAgIDwhRE9DVFlQRSBodG1sPlxyXG4gICAgICA8aHRtbD5cclxuICAgICAgPGhlYWQ+XHJcbiAgICAgICAgPG1ldGEgY2hhcnNldD1cIlVURi04XCI+XHJcbiAgICAgICAgPHRpdGxlPkluY2VudGl2ZSBTbGlwIC0gJHthZ2VudD8ubmFtZSB8fCBcIkFnZW50XCJ9PC90aXRsZT5cclxuICAgICAgICA8c3R5bGU+XHJcbiAgICAgICAgICBAcGFnZSB7IFxyXG4gICAgICAgICAgICBzaXplOiBBNDsgXHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgKiB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgYm9keSB7IFxyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ0hlbHZldGljYSBOZXVlJywgSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZjsgXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgLXdlYmtpdC1wcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0O1xyXG4gICAgICAgICAgICBwcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuZG9jdW1lbnQtY29udGFpbmVyIHtcclxuICAgICAgICAgICAgd2lkdGg6IDIxMG1tO1xyXG4gICAgICAgICAgICBtaW4taGVpZ2h0OiAyOTdtbTtcclxuICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgIHBhZ2UtYnJlYWstYWZ0ZXI6IGF2b2lkO1xyXG4gICAgICAgICAgICBwYWdlLWJyZWFrLWluc2lkZTogYXZvaWQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC8qIEhlYWRlciBTZWN0aW9uICovXHJcbiAgICAgICAgICAuaGVhZGVyLXNlY3Rpb24ge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjMDAyNjdDIDAlLCAjMDAzZDllIDEwMCUpO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAyMHB4IDI1cHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmhlYWRlci1jb250ZW50IHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICAgICAgICAgIGdhcDogMTVweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmxvZ28tYXJlYSBpbWcge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgICAgICAgICBvYmplY3QtZml0OiBjb250YWluO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuY29tcGFueS1pbmZvIHtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBmbGV4OiAxO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuY29tcGFueS1uYW1lIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogODAwO1xyXG4gICAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jb21wYW55LXRhZ2xpbmUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuOTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmRvY3VtZW50LW1ldGEge1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgICAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkIHJnYmEoMjU1LDI1NSwyNTUsMC4zKTtcclxuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxNXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAubWV0YS1pdGVtIHtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogM3B4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAubWV0YS1sYWJlbCB7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuODtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLyogVGl0bGUgU2VjdGlvbiAqL1xyXG4gICAgICAgICAgLnRpdGxlLXNlY3Rpb24ge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZjhmOWZhO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxMnB4IDIwcHg7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOWVjZWY7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5kb2N1bWVudC10aXRsZSB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgICAgICAgY29sb3I6ICMwMDI2N0M7XHJcbiAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC8qIENvbnRlbnQgU2VjdGlvbnMgKi9cclxuICAgICAgICAgIC5jb250ZW50LXNlY3Rpb24ge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxNXB4IDI1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5pbmZvLWNhcmQge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2U5ZWNlZjtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuY2FyZC1oZWFkZXIge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjZjhmOWZhIDAlLCAjZTllY2VmIDEwMCUpO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxMHB4IDE1cHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjMDAyNjdDO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuY2FyZC1oZWFkZXIgaDMge1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMjY3QztcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jYXJkLWJvZHkge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxMnB4IDE1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5pbmZvLWdyaWQge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgICAgICAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCgyLCAxZnIpO1xyXG4gICAgICAgICAgICBnYXA6IDEycHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5pbmZvLXJvdyB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5pbmZvLWxhYmVsIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzZjNzU3ZDtcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogM3B4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuaW5mby12YWx1ZSB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgY29sb3I6ICMyMTI1Mjk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC8qIFRhYmxlIFN0eWxlcyAqL1xyXG4gICAgICAgICAgLnN1bW1hcnktdGFibGUge1xyXG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnN1bW1hcnktdGFibGUgdHIge1xyXG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U5ZWNlZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnN1bW1hcnktdGFibGUgdGQge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiA4cHggNXB4O1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5zdW1tYXJ5LXRhYmxlIHRkOmZpcnN0LWNoaWxkIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgY29sb3I6ICM0OTUwNTc7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5zdW1tYXJ5LXRhYmxlIHRkOmxhc3QtY2hpbGQge1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgY29sb3I6ICMyMTI1Mjk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC50b3RhbC1yb3cge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZThmMGZlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAudG90YWwtcm93IHRkIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMjY3QyAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAvKiBIaWdobGlnaHQgQm94ICovXHJcbiAgICAgICAgICAuaGlnaGxpZ2h0LWJveCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNlOGYwZmUgMCUsICNkNGUyZjcgMTAwJSk7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgICAgICAgcGFkZGluZzogMTVweDtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuaGlnaGxpZ2h0LWxhYmVsIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMjY3QztcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuaGlnaGxpZ2h0LWFtb3VudCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjhweDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICAgICAgICAgICAgY29sb3I6ICMwMDI2N0M7XHJcbiAgICAgICAgICAgIG1hcmdpbjogNXB4IDA7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5oaWdobGlnaHQtd29yZHMge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNDk1MDU3O1xyXG4gICAgICAgICAgICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgICAgICAgICAgIGJvcmRlci10b3A6IDFweCBkYXNoZWQgIzAwMjY3QzQwO1xyXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogOHB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC8qIERlY2xhcmF0aW9uICovXHJcbiAgICAgICAgICAuZGVjbGFyYXRpb24tYm94IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogI2Y4ZjlmYTtcclxuICAgICAgICAgICAgYm9yZGVyLWxlZnQ6IDNweCBzb2xpZCAjMDAyNjdDO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxMHB4IDE1cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMTJweCAwO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNDk1MDU3O1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMS40O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAvKiBTaWduYXR1cmUgU2VjdGlvbiAqL1xyXG4gICAgICAgICAgLnNpZ25hdHVyZS1zZWN0aW9uIHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMTVweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnNpZ25hdHVyZS1ib3gge1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIHdpZHRoOiA0NSU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5zaWduYXR1cmUtaW1hZ2Uge1xyXG4gICAgICAgICAgICBtYXgtaGVpZ2h0OiA1MHB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA4cHg7XHJcbiAgICAgICAgICAgIG9iamVjdC1maXQ6IGNvbnRhaW47XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5zaWduYXR1cmUtbGluZSB7XHJcbiAgICAgICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjMjEyNTI5O1xyXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogNnB4O1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNmM3NTdkO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAvKiBGb290ZXIgKi9cclxuICAgICAgICAgIC5mb290ZXItc2VjdGlvbiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICMwMDI2N0MgMCUsICMwMDNkOWUgMTAwJSk7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHggMjBweDtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogOHB4O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIGJvdHRvbTogMDtcclxuICAgICAgICAgICAgbGVmdDogMDtcclxuICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5mb290ZXItY29tcGFueSB7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDNweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmZvb3Rlci1hZGRyZXNzIHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMC44O1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5mb290ZXItY29udGFjdCB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuNztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgQG1lZGlhIHByaW50IHtcclxuICAgICAgICAgICAgYm9keSB7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLmRvY3VtZW50LWNvbnRhaW5lciB7XHJcbiAgICAgICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICAgICAgICBwYWdlLWJyZWFrLWFmdGVyOiBhdm9pZDtcclxuICAgICAgICAgICAgICBwYWdlLWJyZWFrLWluc2lkZTogYXZvaWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLmhlYWRlci1zZWN0aW9uLCAuZm9vdGVyLXNlY3Rpb24ge1xyXG4gICAgICAgICAgICAgIC13ZWJraXQtcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdDtcclxuICAgICAgICAgICAgICBwcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPC9zdHlsZT5cclxuICAgICAgPC9oZWFkPlxyXG4gICAgICA8Ym9keT5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZG9jdW1lbnQtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8IS0tIEhlYWRlciBTZWN0aW9uIC0tPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImhlYWRlci1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoZWFkZXItY29udGVudFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsb2dvLWFyZWFcIj5cclxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPVwiJHtsb2dvVXJsfVwiIGFsdD1cIk15Q2hpdHMgTG9nb1wiIG9uZXJyb3I9XCJ0aGlzLnNyYz0nZGF0YTppbWFnZS9zdmcreG1sLCUzQ3N2ZyB4bWxucz1cXCdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1xcJyB3aWR0aD1cXCcxMDBcXCcgaGVpZ2h0PVxcJzEwMFxcJyB2aWV3Qm94PVxcJzAgMCAxMDAgMTAwXFwnJTNFJTNDcmVjdCB3aWR0aD1cXCcxMDBcXCcgaGVpZ2h0PVxcJzEwMFxcJyBmaWxsPVxcJyUyMzAwMjY3Q1xcJy8lM0UlM0N0ZXh0IHg9XFwnNTBcXCcgeT1cXCc1MFxcJyB0ZXh0LWFuY2hvcj1cXCdtaWRkbGVcXCcgZHk9XFwnLjNlbVxcJyBmaWxsPVxcJ3doaXRlXFwnIGZvbnQtc2l6ZT1cXCcxNFxcJyBmb250LWZhbWlseT1cXCdBcmlhbFxcJyUzRU1DJTNDL3RleHQlM0UlM0Mvc3ZnJTNFJ1wiPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb21wYW55LWluZm9cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb21wYW55LW5hbWVcIj5NWUNISVRTPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29tcGFueS10YWdsaW5lXCI+Q2hpdCBGdW5kcyDigKIgTG9hbnMg4oCiIEludmVzdG1lbnRzPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRvY3VtZW50LW1ldGFcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtZXRhLWl0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJtZXRhLWxhYmVsXCI+RGF0ZTo8L3NwYW4+ICR7Y3VycmVudERhdGV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8IS0tIFRpdGxlIFNlY3Rpb24gLS0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwidGl0bGUtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZG9jdW1lbnQtdGl0bGVcIj5QaWdteSBDb2xsZWN0aW9uIEluY2VudGl2ZSBTbGlwPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPCEtLSBDb250ZW50IFNlY3Rpb24gLS0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29udGVudC1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDwhLS0gQWdlbnQgRGV0YWlscyBDYXJkIC0tPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1jYXJkXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8aDM+QWdlbnQgLyBFbXBsb3llZSBEZXRhaWxzPC9oMz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1ncmlkXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5mby1sYWJlbFwiPkFnZW50IE5hbWU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmZvLXZhbHVlXCI+JHthZ2VudD8ubmFtZSB8fCBcIk4vQVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5mby1sYWJlbFwiPkVtcGxveWVlIElEPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5mby12YWx1ZVwiPiR7YWdlbnQ/LmVtcGxveWVlQ29kZSB8fCBhZ2VudD8uX2lkPy5zbGljZSgtNikgfHwgXCJOL0FcIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImluZm8tbGFiZWxcIj5QaG9uZSBOdW1iZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmZvLXZhbHVlXCI+JHthZ2VudD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmZvLWxhYmVsXCI+UmVwb3J0aW5nIFBlcmlvZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImluZm8tdmFsdWVcIj4ke3BlcmlvZH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPCEtLSBDb2xsZWN0aW9uIFN1bW1hcnkgQ2FyZCAtLT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tY2FyZFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGgzPkNvbGxlY3Rpb24gJiBJbmNlbnRpdmUgU3VtbWFyeTwvaDM+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzPVwic3VtbWFyeS10YWJsZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPlRvdGFsIENvbGxlY3Rpb24gQW1vdW50PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD7igrkke3BpZ215U3VtbWFyeS50b3RhbF9jb2xsZWN0aW9uPy50b0xvY2FsZVN0cmluZygnZW4tSU4nLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiB9KX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPkluY2VudGl2ZSBQZXJjZW50YWdlIFJhdGU8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPiR7aW5jZW50aXZlUGVyY2VudGFnZX0lPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD5Ub3RhbCBUcmFuc2FjdGlvbnMgKFJlY29yZHMpPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD4ke3BpZ215RGF0YS5sZW5ndGh9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD5Db21wbGV0ZWQgUGlnbXlzPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD4ke3BpZ215U3VtbWFyeS5jb21wbGV0ZWRfcGlnbXlzfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+UGVuZGluZyBQaWdteXM8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPiR7cGlnbXlTdW1tYXJ5LnBlbmRpbmdfcGlnbXlzfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3M9XCJ0b3RhbC1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT1cImZvbnQtd2VpZ2h0OiA3MDA7XCI+R3Jvc3MgSW5jZW50aXZlIEVhcm5lZDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgc3R5bGU9XCJmb250LXdlaWdodDogNzAwOyBjb2xvcjogIzAwMjY3QztcIj7igrkke3BpZ215U3VtbWFyeS50b3RhbF9pbmNlbnRpdmU/LnRvTG9jYWxlU3RyaW5nKCdlbi1JTicsIHsgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDwhLS0gSGlnaGxpZ2h0IEJveCAtLT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWdobGlnaHQtYm94XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWdobGlnaHQtbGFiZWxcIj5OZXQgUGF5YWJsZSBBbW91bnQ8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhpZ2hsaWdodC1hbW91bnRcIj7igrkke3BpZ215U3VtbWFyeS50b3RhbF9pbmNlbnRpdmU/LnRvTG9jYWxlU3RyaW5nKCdlbi1JTicsIHsgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGlnaGxpZ2h0LXdvcmRzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUnVwZWVzICR7YW1vdW50SW5Xb3Jkc30gT25seVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwhLS0gRGVjbGFyYXRpb24gLS0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkZWNsYXJhdGlvbi1ib3hcIj5cclxuICAgICAgICAgICAgICA8c3Ryb25nPkRlY2xhcmF0aW9uOjwvc3Ryb25nPiBUaGlzIGlzIGEgY29tcHV0ZXItZ2VuZXJhdGVkIGluY2VudGl2ZSBzbGlwLiBUaGUgZGV0YWlscyBjb250YWluZWQgaGVyZWluIGFyZSB0cnVlIHRvIHRoZSBiZXN0IG9mIG91ciBrbm93bGVkZ2UuIEFueSBkaXNjcmVwYW5jeSBzaG91bGQgYmUgcmVwb3J0ZWQgdG8gdGhlIGFjY291bnRzIGRlcGFydG1lbnQgd2l0aGluIDQ4IGhvdXJzIG9mIHJlY2VpcHQuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPCEtLSBTaWduYXR1cmUgU2VjdGlvbiAtLT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNpZ25hdHVyZS1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNpZ25hdHVyZS1ib3hcIj5cclxuICAgICAgICAgICAgICAgICR7YWdlbnRTaWduYXR1cmVEYXRhID8gYDxpbWcgc3JjPVwiJHthZ2VudFNpZ25hdHVyZURhdGF9XCIgY2xhc3M9XCJzaWduYXR1cmUtaW1hZ2VcIiBhbHQ9XCJBZ2VudCBTaWduXCI+YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2lnbmF0dXJlLWxpbmVcIj5BZ2VudCdzIFNpZ25hdHVyZTwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzaWduYXR1cmUtYm94XCI+XHJcbiAgICAgICAgICAgICAgICAke3NpZ25hdHVyZURhdGEgPyBgPGltZyBzcmM9XCIke3NpZ25hdHVyZURhdGF9XCIgY2xhc3M9XCJzaWduYXR1cmUtaW1hZ2VcIiBhbHQ9XCJNYW5hZ2VyIFNpZ25cIj5gIDogXCJcIn1cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzaWduYXR1cmUtbGluZVwiPkF1dGhvcml6ZWQgU2lnbmF0b3J5PC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDwhLS0gRm9vdGVyIFNlY3Rpb24gLS0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9vdGVyLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3Rlci1jb21wYW55XCI+VklKQVlBIFZJTkFZQUsgQ0hJVCBGVU5EUyBQUklWQVRFIExJTUlURUQ8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3Rlci1hZGRyZXNzXCI+IzExLzM2LTI1LCAzcmQgRmxvb3IsIDJuZCBNYWluLCBLYXRocmlndXBwZSBNYWluIFJvYWQsIEJhbmFzaGFua2FyaSAzcmQgU3RhZ2UsIEJlbmdhbHVydS01NjAwODU8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3Rlci1jb250YWN0XCI+TW9iOiA5NDgzOTAwNzc3IHwgUGg6IDA4MC00OTc5IDg3NjMgfCBFbWFpbDogaW5mby5teWNoaXRzQGdtYWlsLmNvbTwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvYm9keT5cclxuICAgICAgPC9odG1sPlxyXG4gICAgYDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHZW5lcmF0ZVNsaXAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKSB7XHJcbiAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBsb2FkIGVtcGxveWVlIGRhdGEgZmlyc3QgYnkgY2xpY2tpbmcgQ29udGludWUuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNHZW5lcmF0aW5nUERGKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgaHRtbENvbnRlbnQgPSBnZW5lcmF0ZUluY2VudGl2ZVNsaXBDb250ZW50KCk7XHJcbiAgICAgIGNvbnN0IGFnZW50ID0gc2VsZWN0ZWRFbXBsb3llZURldGFpbHM7XHJcbiAgICAgIGNvbnN0IHBlcmlvZCA9IGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgPyB0ZW1wU2VsZWN0ZWRNb250aCA6IGAke2Zyb21EYXRlfV90b18ke3RvRGF0ZX1gO1xyXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGBJbmNlbnRpdmVfU2xpcF8ke2FnZW50Py5uYW1lIHx8IFwiQWdlbnRcIn1fJHtwZXJpb2R9LnBkZmA7XHJcblxyXG4gICAgICBjb25zdCB0ZW1wRGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcclxuICAgICAgdGVtcERpdi5zdHlsZS5wb3NpdGlvbiA9IFwiYWJzb2x1dGVcIjtcclxuICAgICAgdGVtcERpdi5zdHlsZS5sZWZ0ID0gXCItOTk5OXB4XCI7XHJcbiAgICAgIHRlbXBEaXYuc3R5bGUudG9wID0gXCItOTk5OXB4XCI7XHJcbiAgICAgIHRlbXBEaXYuc3R5bGUud2lkdGggPSBcIjIxMG1tXCI7XHJcbiAgICAgIHRlbXBEaXYuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gXCIjZmZmZmZmXCI7XHJcbiAgICAgIHRlbXBEaXYuaW5uZXJIVE1MID0gaHRtbENvbnRlbnQ7XHJcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGVtcERpdik7XHJcblxyXG4gICAgICBhd2FpdCBuZXcgUHJvbWlzZShyID0+IHNldFRpbWVvdXQociwgODAwKSk7XHJcblxyXG4gICAgICBjb25zdCBjYW52YXMgPSBhd2FpdCBodG1sMmNhbnZhcyh0ZW1wRGl2LCB7XHJcbiAgICAgICAgc2NhbGU6IDMsXHJcbiAgICAgICAgdXNlQ09SUzogdHJ1ZSxcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmZmZmZlwiLFxyXG4gICAgICAgIGxvZ2dpbmc6IGZhbHNlLFxyXG4gICAgICAgIHdpbmRvd1dpZHRoOiA4MDAsXHJcbiAgICAgICAgYWxsb3dUYWludDogZmFsc2UsXHJcbiAgICAgICAgZm9yZWlnbk9iamVjdFJlbmRlcmluZzogZmFsc2UsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgaW1nRGF0YSA9IGNhbnZhcy50b0RhdGFVUkwoXCJpbWFnZS9wbmdcIik7XHJcbiAgICAgIGNvbnN0IHBkZiA9IG5ldyBqc1BERihcInBcIiwgXCJtbVwiLCBcImE0XCIpO1xyXG4gICAgICBjb25zdCBwYWdlV2lkdGggPSAyMTA7XHJcbiAgICAgIGNvbnN0IHBhZ2VIZWlnaHQgPSAyOTc7XHJcbiAgICAgIGNvbnN0IGltZ1dpZHRoID0gcGFnZVdpZHRoO1xyXG4gICAgICBjb25zdCBpbWdIZWlnaHQgPSAoY2FudmFzLmhlaWdodCAqIGltZ1dpZHRoKSAvIGNhbnZhcy53aWR0aDtcclxuICAgICAgXHJcbiAgICAgIHBkZi5hZGRJbWFnZShpbWdEYXRhLCBcIlBOR1wiLCAwLCAwLCBpbWdXaWR0aCwgaW1nSGVpZ2h0KTtcclxuICAgICAgcGRmLnNhdmUoZmlsZU5hbWUpO1xyXG5cclxuICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZCh0ZW1wRGl2KTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiSW5jZW50aXZlIFNsaXAgZG93bmxvYWRlZCBzdWNjZXNzZnVsbHkhXCIpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGdlbmVyYXRpbmcgUERGOlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZ2VuZXJhdGUgaW5jZW50aXZlIHNsaXBcIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0dlbmVyYXRpbmdQREYoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVByaW50U2xpcCA9ICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRFbXBsb3llZURldGFpbHMpIHtcclxuICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIGxvYWQgZW1wbG95ZWUgZGF0YSBmaXJzdCBieSBjbGlja2luZyBDb250aW51ZS5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBodG1sQ29udGVudCA9IGdlbmVyYXRlSW5jZW50aXZlU2xpcENvbnRlbnQoKTtcclxuICAgIGNvbnN0IGFnZW50ID0gc2VsZWN0ZWRFbXBsb3llZURldGFpbHM7XHJcbiAgICBjb25zdCBwZXJpb2QgPSBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiID8gdGVtcFNlbGVjdGVkTW9udGggOiBgJHtmcm9tRGF0ZX1fdG9fJHt0b0RhdGV9YDtcclxuICAgIGNvbnN0IGZpbGVOYW1lID0gYEluY2VudGl2ZV9TbGlwXyR7YWdlbnQ/Lm5hbWUgfHwgXCJBZ2VudFwifV8ke3BlcmlvZH1gO1xyXG4gICAgXHJcbiAgICBjb25zdCBwcmludFdpbmRvdyA9IHdpbmRvdy5vcGVuKFwiXCIsIFwiX2JsYW5rXCIpO1xyXG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQud3JpdGUoaHRtbENvbnRlbnQpO1xyXG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQudGl0bGUgPSBmaWxlTmFtZTtcclxuICAgIHByaW50V2luZG93LmRvY3VtZW50LmNsb3NlKCk7XHJcbiAgICBwcmludFdpbmRvdy5mb2N1cygpO1xyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIHByaW50V2luZG93LnByaW50KCk7XHJcbiAgICAgIHByaW50V2luZG93LmNsb3NlKCk7XHJcbiAgICB9LCA1MDApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHByb2Nlc3NlZFRhYmxlRGF0YSA9IHBpZ215RGF0YS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiAoe1xyXG4gICAga2V5OiBwYXltZW50Ll9pZCB8fCBpbmRleCxcclxuICAgIHNubzogaW5kZXggKyAxLFxyXG4gICAgcGF5X2RhdGU6IHBheW1lbnQ/LnBheV9kYXRlIHx8IHBheW1lbnQ/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9kYXRlOiBwYXltZW50Py5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSB8fCBcIk4vQVwiLFxyXG4gICAgY3VzdG9tZXJfbmFtZTogcGF5bWVudC51c2VyX2lkPy5mdWxsX25hbWUgfHwgcGF5bWVudC5jdXN0b21lcl9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICBwaG9uZV9udW1iZXI6IHBheW1lbnQudXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IHBheW1lbnQucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICBwaWdteV9pZDogcGF5bWVudD8ucGlnbWU/LnBpZ21lX2lkIHx8IHBheW1lbnQucGlnbXlJZCB8fCBcIk4vQVwiLFxyXG4gICAgcGFpZF9hbW91bnQ6IHBheW1lbnQucGFpZF9hbW91bnQgfHwgcGF5bWVudC5hbW91bnQgfHwgMCxcclxuICAgIHBheW1lbnRfbW9kZTogcGF5bWVudC5wYXlfdHlwZSB8fCBwYXltZW50Lm1vZGUgfHwgXCJOL0FcIixcclxuICAgIHJlY2VpcHRfbm86IHBheW1lbnQ/LnJlY2VpcHRfbm8gfHwgXCJOL0FcIixcclxuICB9KSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbm9cIiwgaGVhZGVyOiBcIlNMLk5vXCIgfSxcclxuICAgIHsga2V5OiBcInBheV9kYXRlXCIsIGhlYWRlcjogXCJQYXltZW50IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInBpZ215X2lkXCIsIGhlYWRlcjogXCJQaWdteSBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJwYWlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiUGFpZCBBbW91bnQgKOKCuSlcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudF9tb2RlXCIsIGhlYWRlcjogXCJQYXltZW50IE1vZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVjZWlwdF9ub1wiLCBoZWFkZXI6IFwiUmVjZWlwdCBOb1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IGN1cnJlbnRNb250aCA9IGAke3RvZGF5LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKFxyXG4gICAgdG9kYXkuZ2V0TW9udGgoKSArIDEsXHJcbiAgKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuXHJcbiAgY29uc3Qgc2VsZWN0ZWRFbXBsb3llZSA9IGVtcGxveWVlcy5maW5kKFxyXG4gICAgKGVtcCkgPT4gZW1wLl9pZCA9PT0gc2VsZWN0ZWRFbXBsb3llZUlkLFxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTEwMCBwLTZcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctMnhsXCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnQgYnJlYWstd29yZHMgbGVhZGluZy10aWdodFwiPlxyXG4gICAgICAgICAgICAgIFBpZ215IENvbGxlY3Rpb24gSW5jZW50aXZlIFJlcG9ydHNcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtdC00IHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICBUcmFjayBhbmQgbWFuYWdlIGVtcGxveWVlIGluY2VudGl2ZXMgYW5kIGNvbW1pc3Npb25zXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWZ1bGwgcC0zIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICA8RmFQaWdneUJhbmsgY2xhc3NOYW1lPVwidGV4dC0zeGwgdGV4dC1ncmVlbi02MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctbGcgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gbXQtNiBtYi01XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTMgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTUwIGJvcmRlci1iXCI+XHJcbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8RmlUYXJnZXQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgICBRdWljayBOYXZpZ2F0aW9uIHRvIE90aGVyIFJlcG9ydHNcclxuICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICBFeHBsb3JlIG90aGVyIGluY2VudGl2ZSByZXBvcnRzXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL3RhcmdldC1pbmNlbnRpdmUtbmV3XCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gYmctd2hpdGUgYm9yZGVyLTIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgcC00IGhvdmVyOmJvcmRlci1ibHVlLTQwMCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWJsdWUtMTAwIHJvdW5kZWQtbGcgZ3JvdXAtaG92ZXI6YmctYmx1ZS01MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGaVRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9ezIyfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGdyb3VwLWhvdmVyOnRleHQtYmx1ZS02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICBDaGl0IEJ1c2luZXNzIEluY2VudGl2ZSBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFZpZXcgY2hpdC1iYXNlZCBpbmNlbnRpdmVzXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZD1cIk05IDVsNyA3LTcgN1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL2xvYW5jb2xsZWN0aW9uLWluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIGJvcmRlci0yIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIHAtNCBob3Zlcjpib3JkZXItZ3JlZW4tNDAwIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctZ3JlZW4tMTAwIHJvdW5kZWQtbGcgZ3JvdXAtaG92ZXI6YmctZ3JlZW4tNTAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8TWRDdXJyZW5jeVJ1cGVlXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9ezIyfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGdyb3VwLWhvdmVyOnRleHQtZ3JlZW4tNjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTG9hbiBJbmNlbnRpdmUgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICBUcmFjayBsb2FuIGNvbGxlY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOSA1bDcgNy03IDdcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuXHJcblxyXG4gICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL2NoaXRjb2xsZWN0aW9uLWluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIGJvcmRlci0yIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIHAtNCBob3Zlcjpib3JkZXItcHVycGxlLTQwMCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXB1cnBsZS0xMDAgcm91bmRlZC1sZyBncm91cC1ob3ZlcjpiZy1wdXJwbGUtNTAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8TWRHcm91cHNcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDAgZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9ezIyfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGdyb3VwLWhvdmVyOnRleHQtcHVycGxlLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIENoaXQgQ29sbGVjdGlvbiBJbmNlbnRpdmUgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICBUcmFjayBDaGl0IGNvbGxlY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcHVycGxlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkPVwiTTkgNWw3IDctNyA3XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfSBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbGc9ezZ9PlxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgdGl0bGU9ezxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5Ub3RhbCBDb2xsZWN0aW9uPC9zcGFuPn1cclxuICAgICAgICAgICAgICB2YWx1ZT17cGlnbXlTdW1tYXJ5LnRvdGFsX2NvbGxlY3Rpb259XHJcbiAgICAgICAgICAgICAgcHJlY2lzaW9uPXsyfVxyXG4gICAgICAgICAgICAgIHByZWZpeD17PEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwXCIgLz59XHJcbiAgICAgICAgICAgICAgdmFsdWVTdHlsZT17eyBjb2xvcjogXCIjM2Y4NjAwXCIsIGZvbnRTaXplOiBcIjI0cHhcIiB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IGxnPXs2fT5cclxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1sZyBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICAgIHRpdGxlPXs8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+VG90YWwgSW5jZW50aXZlPC9zcGFuPn1cclxuICAgICAgICAgICAgICB2YWx1ZT17cGlnbXlTdW1tYXJ5LnRvdGFsX2luY2VudGl2ZX1cclxuICAgICAgICAgICAgICBwcmVjaXNpb249ezJ9XHJcbiAgICAgICAgICAgICAgcHJlZml4PXs8UmlzZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiAvPn1cclxuICAgICAgICAgICAgICB2YWx1ZVN0eWxlPXt7IGNvbG9yOiBcIiMxODkwZmZcIiwgZm9udFNpemU6IFwiMjRweFwiIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbGc9ezZ9PlxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgdGl0bGU9ezxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5Ub3RhbCBSZWNvcmRzPC9zcGFuPn1cclxuICAgICAgICAgICAgICB2YWx1ZT17cGlnbXlTdW1tYXJ5LnRvdGFsX3BheW1lbnRzfVxyXG4gICAgICAgICAgICAgIHByZWZpeD17PFRlYW1PdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS01MDBcIiAvPn1cclxuICAgICAgICAgICAgICB2YWx1ZVN0eWxlPXt7IGNvbG9yOiBcIiM3MjJlZDFcIiwgZm9udFNpemU6IFwiMjRweFwiIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgPC9Db2w+XHJcbiAgICAgIDwvUm93PlxyXG5cclxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIHJvdW5kZWQteGwgbWItNlwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPEZpbGVTZWFyY2hPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCIgLz5cclxuICAgICAgICAgICAgUmVwb3J0IEZpbHRlcnNcclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTMgbWItM1wiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgPENhbGVuZGFyT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMCB0ZXh0LXhzXCIgLz5cclxuICAgICAgICAgICAgICAgIERhdGUgU2VsZWN0aW9uIE1vZGVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxSYWRpby5Hcm91cFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2RhdGVTZWxlY3Rpb25Nb2RlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREYXRlU2VsZWN0aW9uTW9kZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8UmFkaW8uQnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPVwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCI1MCVcIiwgdGV4dEFsaWduOiBcImNlbnRlclwiIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIE1vbnRobHlcclxuICAgICAgICAgICAgICAgIDwvUmFkaW8uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPFJhZGlvLkJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT1cImRhdGUtcmFuZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCI1MCVcIiwgdGV4dEFsaWduOiBcImNlbnRlclwiIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIERhdGUgUmFuZ2VcclxuICAgICAgICAgICAgICAgIDwvUmFkaW8uQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvUmFkaW8uR3JvdXA+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgIDxVc2VyT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMCB0ZXh0LXhzXCIgLz5cclxuICAgICAgICAgICAgICAgIFNlbGVjdCBFbXBsb3llZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRFbXBsb3llZUlkfVxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgbmFtZSBvciBwaG9uZVwiXHJcbiAgICAgICAgICAgICAgICBzaXplPVwibWlkZGxlXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9IC0ge2VtcC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0ZWQ6IHtzZWxlY3RlZEVtcGxveWVlLm5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtMyBtYi00XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICB7ZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIiA/IFwiU2VsZWN0IE1vbnRoXCIgOiBcIkZyb20gRGF0ZVwifVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAge2RhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgPyAoXHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBTZWxlY3RlZE1vbnRoIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIG1heD17Y3VycmVudE1vbnRofVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGVtcE1vbnRoQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xLjUgdGV4dC1zbSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1ibHVlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcEZyb21EYXRlIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMS41IHRleHQtc20gYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBtYi0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICA8UGVyY2VudGFnZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgdGV4dC14c1wiIC8+XHJcbiAgICAgICAgICAgICAgICBJbmNlbnRpdmUgUGVyY2VudGFnZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICBzdGVwPVwiMC4xXCJcclxuICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtpbmNlbnRpdmVQZXJjZW50YWdlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEluY2VudGl2ZVBlcmNlbnRhZ2UoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xLjUgdGV4dC1zbSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1ibHVlLTUwMCBwci03XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0yIHRvcC0xLzIgdHJhbnNmb3JtIC10cmFuc2xhdGUteS0xLzIgdGV4dC1ncmF5LTUwMCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICVcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7ZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwiZGF0ZS1yYW5nZVwiICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0zIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRvIERhdGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFRvRGF0ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xLjUgdGV4dC1zbSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1ibHVlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yIG10LTIgcHQtMyBib3JkZXItdCBib3JkZXItZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHNpemU9XCJtZWRpdW1cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVJZChudWxsKTtcclxuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgc2V0VGVtcFNlbGVjdGVkTW9udGgoY3VycmVudE1vbnRoKTtcclxuICAgICAgICAgICAgICAgIHNldEluY2VudGl2ZVBlcmNlbnRhZ2UoMy4wKTtcclxuICAgICAgICAgICAgICAgIHNldFBpZ215RGF0YShbXSk7XHJcbiAgICAgICAgICAgICAgICBzZXRQaWdteVN1bW1hcnkoe1xyXG4gICAgICAgICAgICAgICAgICB0b3RhbF9jb2xsZWN0aW9uOiAwLFxyXG4gICAgICAgICAgICAgICAgICB0b3RhbF9pbmNlbnRpdmU6IDAsXHJcbiAgICAgICAgICAgICAgICAgIHRvdGFsX3BheW1lbnRzOiAwLFxyXG4gICAgICAgICAgICAgICAgICBjb21wbGV0ZWRfcGlnbXlzOiAwLFxyXG4gICAgICAgICAgICAgICAgICBwZW5kaW5nX3BpZ215czogMCxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgc2V0SXNGaWx0ZXJpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgeWVhciA9IHRvZGF5LmdldEZ1bGxZZWFyKCk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBtb250aCA9IHRvZGF5LmdldE1vbnRoKCkgKyAxO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfS0wMWA7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLmdldERhdGUoKTtcclxuICAgICAgICAgICAgICAgIHNldFRlbXBGcm9tRGF0ZShmaXJzdERheSk7XHJcbiAgICAgICAgICAgICAgICBzZXRUZW1wVG9EYXRlKFxyXG4gICAgICAgICAgICAgICAgICBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfS0ke1N0cmluZyhsYXN0RGF5KS5wYWRTdGFydCgyLCBcIjBcIil9YCxcclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJlc2V0XHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIHNpemU9XCJtZWRpdW1cIlxyXG4gICAgICAgICAgICAgIGljb249ezxGaWxlU2VhcmNoT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb250aW51ZX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC04IHB5LTIuNSBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyBmb250LXNlbWlib2xkIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDb250aW51ZVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0NhcmQ+XHJcblxyXG4gICAgXHJcblxyXG4gICAgICB7aXNGaWx0ZXJpbmcgJiYgc2VsZWN0ZWRFbXBsb3llZURldGFpbHMgJiYgKFxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1sZyByb3VuZGVkLXhsIG1iLTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwIHRvLWluZGlnby01MCBib3JkZXItYiBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgIEVtcGxveWVlIEluZm9ybWF0aW9uXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxTcGFjZT5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICBpY29uPXs8UHJpbnRlck91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnRTbGlwfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgUHJpbnQgU2xpcFxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIGljb249ezxEb3dubG9hZE91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgbG9hZGluZz17aXNHZW5lcmF0aW5nUERGfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlR2VuZXJhdGVTbGlwfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNjAwIGhvdmVyOmJnLWdyZWVuLTcwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgR2VuZXJhdGUgU2xpcFxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L1NwYWNlPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBOYW1lXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBFbWFpbFxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LmVtYWlsIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgIFBob25lXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ucGhvbmVfbnVtYmVyIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgKX1cclxuXHJcbiAgICAgXHJcblxyXG4gICAgICB7aXNGaWx0ZXJpbmcgJiYgcGlnbXlEYXRhLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1sZyByb3VuZGVkLXhsIG1iLTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi01MCB0by1lbWVyYWxkLTUwIGJvcmRlci1iXCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgICAgICBDb2xsZWN0aW9uIFN1bW1hcnlcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy01IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAgdG8tYmx1ZS0xMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgUGVyaW9kXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ibHVlLTcwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShgJHt0ZW1wU2VsZWN0ZWRNb250aH0tMDFgKS50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJkZWZhdWx0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJsb25nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgOiBgJHtmcm9tRGF0ZX0gdG8gJHt0b0RhdGV9YH1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwIHRvLWdyZWVuLTEwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBJbmNlbnRpdmUgUmF0ZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAge2luY2VudGl2ZVBlcmNlbnRhZ2V9JVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwIHRvLXB1cnBsZS0xMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgUmVjb3Jkc1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwaWdteURhdGEubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNTAgdG8tZ3JlZW4tMTAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRvdGFsIENvbGxlY3Rpb25cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgbXItMSB0ZXh0LWdyZWVuLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtwaWdteVN1bW1hcnkudG90YWxfY29sbGVjdGlvbj8udG9GaXhlZCgyKX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAgdG8tYmx1ZS0xMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgSW5jZW50aXZlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ibHVlLTcwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxSaXNlT3V0bGluZWQgY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIG1yLTEgdGV4dC1ibHVlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtwaWdteVN1bW1hcnkudG90YWxfaW5jZW50aXZlPy50b0ZpeGVkKDIpfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0yMFwiPlxyXG4gICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICBpc0ZpbHRlcmluZyAmJlxyXG4gICAgICAgIHBpZ215RGF0YS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1sZyByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMyBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgYm9yZGVyLWJcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPEZpbGVTZWFyY2hPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIFNob3dpbmcge3BpZ215RGF0YS5sZW5ndGh9IHBheW1lbnQgcmVjb3Jkc1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00XCI+XHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgZGF0YT17cHJvY2Vzc2VkVGFibGVEYXRhfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT17YFBpZ215X0NvbGxlY3Rpb25fSW5jZW50aXZlX1JlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcclxuICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZSBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiUGVyaW9kXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiSW5jZW50aXZlIFBlcmNlbnRhZ2VcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBDb2xsZWN0aW9uXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgSW5jZW50aXZlXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgUmVjb3Jkc1wiLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShgJHt0ZW1wU2VsZWN0ZWRNb250aH0tMDFgKS50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJkZWZhdWx0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJsb25nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgOiBgJHtmcm9tRGF0ZX0gdG8gJHt0b0RhdGV9YCxcclxuICAgICAgICAgICAgICAgICAgYCR7aW5jZW50aXZlUGVyY2VudGFnZX0lYCxcclxuICAgICAgICAgICAgICAgICAgYOKCuSR7cGlnbXlTdW1tYXJ5LnRvdGFsX2NvbGxlY3Rpb24/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9YCxcclxuICAgICAgICAgICAgICAgICAgYOKCuSR7cGlnbXlTdW1tYXJ5LnRvdGFsX2luY2VudGl2ZT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCBcIjBcIn1gLFxyXG4gICAgICAgICAgICAgICAgICBwaWdteURhdGEubGVuZ3RoIHx8IFwiMFwiLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BQaWdteUNvbGxlY3Rpb25SZXBvcnRfJHtzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSB8fCBcImFsbFwifV8ke1xyXG4gICAgICAgICAgICAgICAgICBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyB0ZW1wU2VsZWN0ZWRNb250aFxyXG4gICAgICAgICAgICAgICAgICAgIDogYCR7ZnJvbURhdGV9X3RvXyR7dG9EYXRlfWBcclxuICAgICAgICAgICAgICAgIH0uY3N2YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICApXHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7aXNGaWx0ZXJpbmcgJiYgIWxvYWRpbmcgJiYgcGlnbXlEYXRhLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtbGcgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICBObyBwYXltZW50IHJlY29yZHMgZm91bmQgZm9yIHRoZSBzZWxlY3RlZCBwZXJpb2QuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQaWdteUNvbGxlY3Rpb25JbmNlbnRpdmVSZXBvcnQ7XHJcblxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGlnbXlDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0LmpzeCJ9