import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeAttendanceReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Button, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { CheckCircle2, XCircle, Calendar, Search, Clock } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import __vite__cjsImport12_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport12_dayjs.__esModule ? __vite__cjsImport12_dayjs.default : __vite__cjsImport12_dayjs;
import __vite__cjsImport13_dayjs_plugin_duration from "/node_modules/.vite/deps/dayjs_plugin_duration.js?v=819e0a34"; const duration = __vite__cjsImport13_dayjs_plugin_duration.__esModule ? __vite__cjsImport13_dayjs_plugin_duration.default : __vite__cjsImport13_dayjs_plugin_duration;
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
dayjs.extend(duration);
const EmployeeAttendanceReport = () => {
  _s();
  const [tableAttendanceData, setTableAttendanceData] = useState([]);
  const [screenLoading, setScreenLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState("");
  const [searchText, setSearchText] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectAll, setSelectAll] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const formatDateForDisplay = (date) => {
    if (!date) return "-";
    let d;
    if (typeof date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
      const [year2, month2, day2] = date.split("-");
      d = new Date(year2, month2 - 1, day2);
    } else if (typeof date === "string" && /^\d{2}-\d{2}-\d{4}$/.test(date)) {
      return date;
    } else {
      d = new Date(date);
    }
    if (isNaN(d.getTime())) {
      return "-";
    }
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };
  const formatDateForBackend = (date) => {
    if (!date) {
      const today = /* @__PURE__ */ new Date();
      return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(
        2,
        "0"
      )}-${String(today.getDate()).padStart(2, "0")}`;
    }
    let d;
    if (typeof date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return date;
    } else if (typeof date === "string" && /^\d{2}-\d{2}-\d{4}$/.test(date)) {
      const [day2, month2, year2] = date.split("-");
      return `${year2}-${month2}-${day2}`;
    } else {
      d = new Date(date);
      if (isNaN(d.getTime())) return null;
    }
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };
  const filterOption = (data, searchText2) => {
    if (!searchText2) return data;
    return data.filter(
      (item) => item.EmployeeName.toLowerCase().includes(searchText2.toLowerCase())
    );
  };
  const handleNoteChange = (id, value) => {
    setTableAttendanceData(
      (prev) => prev.map(
        (item) => item._id === id ? { ...item, Note: value, NoteRaw: value } : item
      )
    );
  };
  const summaryStats = useMemo(() => {
    const total = tableAttendanceData.length;
    const present = tableAttendanceData.filter(
      (r) => r.Status === "Present"
    ).length;
    const absent = tableAttendanceData.filter(
      (r) => r.Status === "Absent"
    ).length;
    const halfday = tableAttendanceData.filter(
      (r) => r.Status === "Half Day"
    ).length;
    const onleave = tableAttendanceData.filter(
      (r) => r.Status === "On Leave"
    ).length;
    const approved = tableAttendanceData.filter(
      (r) => r.ApprovalStatus === "Approved"
    ).length;
    const pendingEmployees = tableAttendanceData.filter(
      (r) => r.ApprovalStatus !== "Approved"
    );
    const pending = pendingEmployees.length;
    const pendingEmployeeNames = pendingEmployees.map(
      (emp) => emp.EmployeeName
    );
    return {
      total,
      present,
      absent,
      halfday,
      onleave,
      approved,
      pending,
      pendingEmployeeNames
    };
  }, [tableAttendanceData]);
  const fetchAttendanceReport = async (date) => {
    setScreenLoading(true);
    try {
      const currentDate = formatDateForBackend(date || /* @__PURE__ */ new Date());
      const response = await api.get(
        `/employee-attendance/employees/date/${currentDate}`
      );
      const formattedData = response?.data?.agentAttendanceData?.filter((v) => v.isVerified === true || v.isVerified === "true").map((attend, index) => {
        const details = attend?.attendance_details || {};
        const rawStatus = details?.status || "";
        let normalizedStatus = "";
        if (typeof rawStatus === "string") {
          const rs = rawStatus.trim().toLowerCase();
          if (rs === "present" || rs === "presented")
            normalizedStatus = "Present";
          else if (rs === "absent") normalizedStatus = "Absent";
          else if (rs === "half" || rs === "half day" || rs === "Half Day")
            normalizedStatus = "Half Day";
          else if (rs === "leave" || rs === "on leave" || rs === "On Leave")
            normalizedStatus = "On Leave";
          else
            normalizedStatus = rawStatus.charAt(0).toUpperCase() + rawStatus.slice(1);
        }
        const isApproved = (details?.approval_status || "").toString().toLowerCase() === "approved";
        const loginTime = details?.time;
        const logoutTime = details?.logout_time;
        let workingHours = "-";
        if (loginTime && logoutTime) {
          const start = dayjs(loginTime, "hh:mm:ss a");
          const end = dayjs(logoutTime, "hh:mm:ss a");
          if (start.isValid() && end.isValid() && end.isAfter(start)) {
            const diffMinutes = end.diff(start, "minute");
            const hours = Math.floor(diffMinutes / 60);
            const minutes = diffMinutes % 60;
            workingHours = `${hours}h ${minutes}m`;
          }
        }
        return {
          _id: attend?._id,
          id: index + 1,
          EmployeeName: attend?.employee_name || "-",
          EmployeeId: attend?.employeeCode || "-",
          // Default to Absent if no explicit status found (mirrors earlier behavior if desired)
          Status: normalizedStatus === "-" ? "Absent" : normalizedStatus,
          ApprovalStatus: details?.approval_status || "Pending",
          ApprovalStatusRaw: details?.approval_status || "Pending",
          Date: details?.date ? formatDateForDisplay(details.date) : "-",
          Time: details?.time || "-",
          OutTime: details?.logout_time || "-",
          WorkingHours: workingHours,
          Note: details?.note || "",
          NoteRaw: details?.note || "",
          attendanceId: details?._id,
          Approved: isApproved,
          InitialApproved: isApproved,
          InitialStatus: normalizedStatus === "-" ? "Absent" : normalizedStatus
        };
      }) || [];
      setTableAttendanceData(formattedData);
      const activeMap = {};
      formattedData.forEach((item) => {
        activeMap[item._id] = { info: { status: item.Approved } };
      });
      setActiveUserData(activeMap);
    } catch (error) {
      console.error("Failed to load attendance data", error);
    } finally {
      setScreenLoading(false);
    }
  };
  useEffect(() => {
    fetchAttendanceReport(selectedDate);
  }, [selectedDate]);
  const handleStatusToggle = (id, nextStatus) => {
    setTableAttendanceData(
      (prevData) => prevData.map((item) => {
        if (item._id !== id) return item;
        if (nextStatus) {
          return { ...item, Status: capitalizeStatus(nextStatus) };
        }
        const current = (item.Status || "Absent").toString().toLowerCase();
        let next = "Present";
        if (current === "present") next = "Absent";
        else if (current === "absent") next = "Half Day";
        else if (current === "half day")
          next = "On Leave";
        else if (current === "on leave")
          next = "Present";
        else next = "Present";
        return { ...item, Status: capitalizeStatus(next) };
      })
    );
  };
  const capitalizeStatus = (s) => {
    if (!s) return s;
    const str = s.toString();
    if (str.toLowerCase() === "half day" || str.toLowerCase() === "half") {
      return "Half Day";
    }
    if (str.toLowerCase() === "on leave" || str.toLowerCase() === "leave") {
      return "On Leave";
    }
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  };
  const handleCheckboxChange = (id, checked) => {
    const record = tableAttendanceData.find((item) => item._id === id);
    if (record && record.InitialApproved) {
      setAlertConfig({
        visibility: true,
        message: "Cannot unapprove a previously approved record.",
        type: "info"
      });
      return;
    }
    setActiveUserData((prev) => ({
      ...prev,
      [id]: { info: { status: checked } }
    }));
    setTableAttendanceData(
      (prevData) => prevData.map(
        (item) => item._id === id ? {
          ...item,
          Approved: checked,
          ApprovalStatus: checked ? "Approved" : "Pending",
          ApprovalStatusRaw: checked ? "Approved" : "Pending"
        } : item
      )
    );
  };
  const filteredAttendance = useMemo(() => {
    return filterOption(tableAttendanceData, searchText).map((item, index) => {
      const isPermanentlyApproved = item.InitialApproved === true;
      return {
        ...item,
        id: index + 1,
        ApprovalStatus: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: item.ApprovalStatus === "Approved" ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200", children: [
          /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 14 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 341,
            columnNumber: 17
          }, this),
          "Approved"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 340,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200", children: [
          /* @__PURE__ */ jsxDEV(Clock, { size: 14 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 346,
            columnNumber: 17
          }, this),
          "Pending"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 345,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 338,
          columnNumber: 9
        }, this),
        // 🟢 Editable Note (disabled once approved)
        Note: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: item.Note || "",
            disabled: isPermanentlyApproved,
            onChange: (e) => handleNoteChange(item._id, e.target.value),
            placeholder: "Enter Reason",
            className: `w-full px-3 py-1 border rounded-md text-sm focus:outline-none ${isPermanentlyApproved ? "bg-gray-100 text-gray-500 cursor-not-allowed" : "border-emerald-300 focus:border-emerald-500"}`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 355,
            columnNumber: 9
          },
          this
        ),
        // 🟢 Actions: disable both checkbox & status toggle if already approved
        checkBox: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => !isPermanentlyApproved && handleStatusToggle(item._id),
              disabled: isPermanentlyApproved,
              className: `inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 ${isPermanentlyApproved ? "bg-gray-100 text-gray-400 cursor-not-allowed" : item.Status === "Present" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-200" : item.Status === "Half Day" ? "bg-orange-300 text-white hover:brightness-95" : item.Status === "On Leave" ? "bg-pink-300 text-white hover:brightness-95" : "bg-red-100 text-red-700 hover:bg-red-200"}`,
              children: [
                item.Status === "Present" ? /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
                  lineNumber: 390,
                  columnNumber: 13
                }, this) : item.Status === "Half Day" ? /* @__PURE__ */ jsxDEV(Clock, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
                  lineNumber: 392,
                  columnNumber: 13
                }, this) : item.Status === "On Leave" ? /* @__PURE__ */ jsxDEV(Calendar, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
                  lineNumber: 394,
                  columnNumber: 13
                }, this) : /* @__PURE__ */ jsxDEV(XCircle, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
                  lineNumber: 396,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-1", children: item.Status }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
                  lineNumber: 398,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
              lineNumber: 372,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              checked: item.Approved,
              disabled: isPermanentlyApproved,
              onChange: (e) => handleCheckboxChange(item._id, e.target.checked),
              className: `w-5 h-5 rounded accent-emerald-600 transition-all ${isPermanentlyApproved ? "cursor-not-allowed opacity-40" : "cursor-pointer hover:accent-emerald-700"}`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
              lineNumber: 401,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 371,
          columnNumber: 9
        }, this)
      };
    });
  }, [tableAttendanceData, activeUserData, searchText]);
  const handleSelectAll = (checked) => {
    setSelectAll(checked);
    const updated = {};
    filteredAttendance.forEach((item) => {
      if (!item.InitialApproved) {
        updated[item._id] = { info: { status: checked } };
      }
    });
    setActiveUserData((prev) => ({ ...prev, ...updated }));
    setTableAttendanceData(
      (prevData) => prevData.map(
        (item) => filteredAttendance.find((f) => f._id === item._id) && !item.InitialApproved ? {
          ...item,
          Approved: checked,
          ApprovalStatus: checked ? "Approved" : "Pending"
        } : item
      )
    );
  };
  const handleSubmit = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    try {
      const currentUser = JSON.parse(localStorage.getItem("user")) || {};
      const approvedBy = currentUser?._id;
      const formattedDate = formatDateForBackend(selectedDate || /* @__PURE__ */ new Date());
      const recordsToUpdate = tableAttendanceData.filter(
        (row) => row.Approved !== row.InitialApproved || row.Approved && row.Status !== row.InitialStatus || row.Approved && row.Note && row.Note.trim() !== ""
      );
      const existingUpdates = recordsToUpdate.filter(
        (row) => row.attendanceId && row.Approved
      );
      const newAbsentees = recordsToUpdate.filter(
        (row) => !row.attendanceId && row.Approved
      );
      if (existingUpdates.length > 0) {
        const updatedData = existingUpdates.map((row) => ({
          employee_id: row._id,
          attendance_id: row.attendanceId,
          status: row.Status,
          approval_status: "Approved",
          approved_by: approvedBy,
          note: row.Note || ""
          // ✅ Include note in update
        }));
        await api.put("/employee-attendance/update-approvals", {
          updates: updatedData
        });
      }
      if (newAbsentees.length > 0) {
        await api.post("/employee-attendance/save-selected-absent", {
          absentees: newAbsentees.map((row) => ({
            employee_id: row._id,
            status: row.Status,
            approval_status: "Approved",
            approved_by: approvedBy,
            date: formattedDate,
            note: row.Note || ""
            // ✅ Include note in create
          }))
        });
      }
      await fetchAttendanceReport(selectedDate);
      setAlertConfig({
        visibility: true,
        message: "Attendance updates submitted successfully.",
        type: "success"
      });
      setSelectedDate(selectedDate);
    } catch (error) {
      console.error("Error while submitting attendance:", error);
      setAlertConfig({
        visibility: true,
        message: "Error updating selected employees!",
        type: "error"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  const AttendanceColumns = [
    { key: "id", header: "Sl No" },
    { key: "EmployeeId", header: "Employee Id" },
    { key: "EmployeeName", header: "Employee Name" },
    { key: "Status", header: "Status" },
    { key: "ApprovalStatus", header: "Approval Status" },
    { key: "Date", header: "Date" },
    { key: "Time", header: "Time" },
    { key: "OutTime", header: "Out-Time" },
    { key: "WorkingHours", header: "Working Hours" },
    { key: "Note", header: "Reason" },
    { key: "checkBox", header: "Actions" }
  ];
  const PDFAttendanceColumns = [
    { key: "id", header: "Sl No" },
    { key: "EmployeeId", header: "Employee Id" },
    { key: "EmployeeName", header: "Employee Name" },
    { key: "Status", header: "Status" },
    { key: "ApprovalStatusRaw", header: "Approval Status" },
    { key: "Date", header: "Date" },
    { key: "Time", header: "Time" },
    { key: "OutTime", header: "Out-Time" },
    { key: "WorkingHours", header: "Working Hours" },
    { key: "NoteRaw", header: "Reason" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "w-screen h-screen bg-gradient-to-br from-slate-50 to-slate-100 overflow-x-hidden overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "flex ", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
        lineNumber: 545,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
      lineNumber: 549,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
        lineNumber: 550,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8 mt-20", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 561,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold text-slate-900 mb-2", children: "Employee Attendance" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 562,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500", children: "Manage and approve employee attendance records" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 565,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
        lineNumber: 560,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-start sm:items-center gap-6 w-full lg:w-auto", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-semibold text-slate-700", children: "Select Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
              lineNumber: 577,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 bg-slate-50 px-4 py-3 rounded-lg border border-slate-200 focus-within:border-emerald-500 focus-within:bg-white transition-all", children: [
              /* @__PURE__ */ jsxDEV(Calendar, { size: 18, className: "text-slate-400" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
                lineNumber: 581,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                  max: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                  onChange: (e) => setSelectedDate(e.target.value),
                  className: "bg-transparent border-none outline-none text-slate-700 font-medium"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
                  lineNumber: 582,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
              lineNumber: 580,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 576,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 pt-2 sm:pt-6", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                id: "selectAll",
                checked: selectAll,
                onChange: (e) => handleSelectAll(e.target.checked),
                className: "w-5 h-5 rounded accent-emerald-600 cursor-pointer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
                lineNumber: 596,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                htmlFor: "selectAll",
                className: "text-sm font-medium text-slate-700 cursor-pointer",
                children: "Select All"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
                lineNumber: 603,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 595,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 574,
          columnNumber: 15
        }, this),
        screenLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-emerald-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 613,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV(
          Button,
          {
            type: "primary",
            loading: isSubmitting,
            disabled: isSubmitting,
            onClick: handleSubmit,
            className: "w-full sm:w-auto bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-semibold px-8 py-6 rounded-lg border-0 shadow-md hover:shadow-lg transition-all",
            children: isSubmitting ? "Updating..." : "Submit Attendance"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 615,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
        lineNumber: 572,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
        lineNumber: 571,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-md border border-slate-200 text-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold block", children: "Total Employees" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 630,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-slate-900", children: summaryStats.total }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 633,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 629,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-green-50 rounded-lg shadow-md border border-slate-200 text-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold block", children: "Present" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 639,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-green-700", children: summaryStats.present }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 640,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 638,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-red-50 rounded-lg shadow-md border border-slate-200 text-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold block", children: "Absent" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 646,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-red-700", children: summaryStats.absent }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 647,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 645,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-blue-50 rounded-lg shadow-md border border-slate-200 text-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold block", children: "Half Day" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 653,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-blue-700", children: summaryStats.halfday }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 654,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 652,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-purple-50 rounded-lg shadow-md border border-slate-200 text-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold block", children: "On Leave" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 660,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-purple-700", children: summaryStats.onleave }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 661,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 659,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-emerald-50 rounded-lg shadow-md border border-slate-200 text-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold block", children: "Approved" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 667,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-emerald-700", children: summaryStats.approved }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 668,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 666,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-amber-50 rounded-lg shadow-md border border-slate-200 text-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold block", children: "Pending" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 674,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-amber-700", children: summaryStats.pending }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
            lineNumber: 675,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 673,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
        lineNumber: 628,
        columnNumber: 11
      }, this),
      summaryStats.pendingEmployeeNames.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-white border border-amber-200 rounded-xl p-4 shadow-sm mb-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-amber-700 mb-3", children: "Pending Approval Employees" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 682,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: summaryStats.pendingEmployeeNames.map(
          (name, index) => /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: "px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm font-medium",
              children: name
            },
            index,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
              lineNumber: 688,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 686,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
        lineNumber: 681,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden p-4 min-h-[300px] flex justify-center items-center", children: screenLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-emerald-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
        lineNumber: 702,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns: AttendanceColumns,
          exportCols: PDFAttendanceColumns,
          data: filteredAttendance,
          printHeaderKeys: [
            "Total Employees",
            "Total Present",
            "Total Absent",
            "Total Half Day",
            "Total On Leave",
            "Total Approved"
          ],
          printHeaderValues: [
            `${summaryStats.total}`,
            `${summaryStats.present}`,
            `${summaryStats.absent}`,
            `${summaryStats.halfday}`,
            `${summaryStats.onleave}`,
            `${summaryStats.approved}`
          ],
          exportedPdfName: "Employee Attendence",
          exportedFileName: `EmployeeAttendence.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
          lineNumber: 704,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
        lineNumber: 700,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
      lineNumber: 558,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
    lineNumber: 544,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx",
    lineNumber: 543,
    columnNumber: 5
  }, this);
};
_s(EmployeeAttendanceReport, "PSeXipklTiMUBaqRDPMudpFKS64=");
_c = EmployeeAttendanceReport;
export default EmployeeAttendanceReport;
var _c;
$RefreshReg$(_c, "EmployeeAttendanceReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeAttendanceReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb1ZnQjsyQkFwVmhCO0FBQW9CQSxvQkFBaUIsT0FBUSxzQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNwRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxRQUFRQyxlQUFlO0FBQ2hDLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxjQUFjQyxTQUFTQyxVQUFVQyxRQUFRQyxhQUFhO0FBQy9ELE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxnQkFBZ0I7QUFFdkJGLE1BQU1HLE9BQU9GLFFBQVE7QUFFckIsTUFBTUcsMkJBQTJCQSxNQUFNO0FBQUFDLEtBQUE7QUFDckMsUUFBTSxDQUFDQyxxQkFBcUJDLHNCQUFzQixJQUFJckIsU0FBUyxFQUFFO0FBQ2pFLFFBQU0sQ0FBQ3NCLGVBQWVDLGdCQUFnQixJQUFJdkIsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ3dCLGNBQWNDLGVBQWUsSUFBSXpCLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEIsZ0JBQWdCQyxpQkFBaUIsSUFBSTdCLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZELFFBQU0sQ0FBQzhCLGNBQWNDLGVBQWUsSUFBSS9CLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNnQyxXQUFXQyxZQUFZLElBQUlqQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDa0MsYUFBYUMsY0FBYyxJQUFJbkMsU0FBUztBQUFBLElBQzdDb0MsWUFBWTtBQUFBLElBQ1ovQixTQUFTO0FBQUEsSUFDVGdDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFHRCxRQUFNQyx1QkFBdUJBLENBQUNDLFNBQVM7QUFDckMsUUFBSSxDQUFDQSxLQUFNLFFBQU87QUFFbEIsUUFBSUM7QUFDSixRQUFJLE9BQU9ELFNBQVMsWUFBWSxzQkFBc0JFLEtBQUtGLElBQUksR0FBRztBQUNoRSxZQUFNLENBQUNHLE9BQU1DLFFBQU9DLElBQUcsSUFBSUwsS0FBS00sTUFBTSxHQUFHO0FBQ3pDTCxVQUFJLElBQUlNLEtBQUtKLE9BQU1DLFNBQVEsR0FBR0MsSUFBRztBQUFBLElBQ25DLFdBQVcsT0FBT0wsU0FBUyxZQUFZLHNCQUFzQkUsS0FBS0YsSUFBSSxHQUFHO0FBQ3ZFLGFBQU9BO0FBQUFBLElBQ1QsT0FBTztBQUNMQyxVQUFJLElBQUlNLEtBQUtQLElBQUk7QUFBQSxJQUNuQjtBQUVBLFFBQUlRLE1BQU1QLEVBQUVRLFFBQVEsQ0FBQyxHQUFHO0FBQ3RCLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTUosTUFBTUssT0FBT1QsRUFBRVUsUUFBUSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQy9DLFVBQU1SLFFBQVFNLE9BQU9ULEVBQUVZLFNBQVMsSUFBSSxDQUFDLEVBQUVELFNBQVMsR0FBRyxHQUFHO0FBQ3RELFVBQU1ULE9BQU9GLEVBQUVhLFlBQVk7QUFDM0IsV0FBTyxHQUFHVCxHQUFHLElBQUlELEtBQUssSUFBSUQsSUFBSTtBQUFBLEVBQ2hDO0FBR0EsUUFBTVksdUJBQXVCQSxDQUFDZixTQUFTO0FBQ3JDLFFBQUksQ0FBQ0EsTUFBTTtBQUNULFlBQU1nQixRQUFRLG9CQUFJVCxLQUFLO0FBQ3ZCLGFBQU8sR0FBR1MsTUFBTUYsWUFBWSxDQUFDLElBQUlKLE9BQU9NLE1BQU1ILFNBQVMsSUFBSSxDQUFDLEVBQUVEO0FBQUFBLFFBQzVEO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQyxJQUFJRixPQUFPTSxNQUFNTCxRQUFRLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUFBLElBQy9DO0FBRUEsUUFBSVg7QUFDSixRQUFJLE9BQU9ELFNBQVMsWUFBWSxzQkFBc0JFLEtBQUtGLElBQUksR0FBRztBQUNoRSxhQUFPQTtBQUFBQSxJQUNULFdBQVcsT0FBT0EsU0FBUyxZQUFZLHNCQUFzQkUsS0FBS0YsSUFBSSxHQUFHO0FBQ3ZFLFlBQU0sQ0FBQ0ssTUFBS0QsUUFBT0QsS0FBSSxJQUFJSCxLQUFLTSxNQUFNLEdBQUc7QUFDekMsYUFBTyxHQUFHSCxLQUFJLElBQUlDLE1BQUssSUFBSUMsSUFBRztBQUFBLElBQ2hDLE9BQU87QUFDTEosVUFBSSxJQUFJTSxLQUFLUCxJQUFJO0FBQ2pCLFVBQUlRLE1BQU1QLEVBQUVRLFFBQVEsQ0FBQyxFQUFHLFFBQU87QUFBQSxJQUNqQztBQUVBLFVBQU1OLE9BQU9GLEVBQUVhLFlBQVk7QUFDM0IsVUFBTVYsUUFBUU0sT0FBT1QsRUFBRVksU0FBUyxJQUFJLENBQUMsRUFBRUQsU0FBUyxHQUFHLEdBQUc7QUFDdEQsVUFBTVAsTUFBTUssT0FBT1QsRUFBRVUsUUFBUSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQy9DLFdBQU8sR0FBR1QsSUFBSSxJQUFJQyxLQUFLLElBQUlDLEdBQUc7QUFBQSxFQUNoQztBQUVBLFFBQU1ZLGVBQWVBLENBQUNDLE1BQU0vQixnQkFBZTtBQUN6QyxRQUFJLENBQUNBLFlBQVksUUFBTytCO0FBQ3hCLFdBQU9BLEtBQUtDO0FBQUFBLE1BQU8sQ0FBQ0MsU0FDbEJBLEtBQUtDLGFBQWFDLFlBQVksRUFBRUMsU0FBU3BDLFlBQVdtQyxZQUFZLENBQUM7QUFBQSxJQUNuRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNRSxtQkFBbUJBLENBQUNDLElBQUlDLFVBQVU7QUFDdEM1QztBQUFBQSxNQUF1QixDQUFDNkMsU0FDdEJBLEtBQUtDO0FBQUFBLFFBQUksQ0FBQ1IsU0FDUkEsS0FBS1MsUUFBUUosS0FBSyxFQUFFLEdBQUdMLE1BQU1VLE1BQU1KLE9BQU9LLFNBQVNMLE1BQU0sSUFBSU47QUFBQUEsTUFDL0Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQXlCQSxRQUFNWSxlQUFlQyxRQUFRLE1BQU07QUFDakMsVUFBTUMsUUFBUXJELG9CQUFvQnNEO0FBRWxDLFVBQU1DLFVBQVV2RCxvQkFBb0JzQztBQUFBQSxNQUNsQyxDQUFDa0IsTUFBTUEsRUFBRUMsV0FBVztBQUFBLElBQ3RCLEVBQUVIO0FBRUYsVUFBTUksU0FBUzFELG9CQUFvQnNDO0FBQUFBLE1BQ2pDLENBQUNrQixNQUFNQSxFQUFFQyxXQUFXO0FBQUEsSUFDdEIsRUFBRUg7QUFFRixVQUFNSyxVQUFVM0Qsb0JBQW9Cc0M7QUFBQUEsTUFDbEMsQ0FBQ2tCLE1BQU1BLEVBQUVDLFdBQVc7QUFBQSxJQUN0QixFQUFFSDtBQUVGLFVBQU1NLFVBQVU1RCxvQkFBb0JzQztBQUFBQSxNQUNsQyxDQUFDa0IsTUFBTUEsRUFBRUMsV0FBVztBQUFBLElBQ3RCLEVBQUVIO0FBRUYsVUFBTU8sV0FBVzdELG9CQUFvQnNDO0FBQUFBLE1BQ25DLENBQUNrQixNQUFNQSxFQUFFTSxtQkFBbUI7QUFBQSxJQUM5QixFQUFFUjtBQUVGLFVBQU1TLG1CQUFtQi9ELG9CQUFvQnNDO0FBQUFBLE1BQzNDLENBQUNrQixNQUFNQSxFQUFFTSxtQkFBbUI7QUFBQSxJQUM5QjtBQUVBLFVBQU1FLFVBQVVELGlCQUFpQlQ7QUFFakMsVUFBTVcsdUJBQXVCRixpQkFBaUJoQjtBQUFBQSxNQUM1QyxDQUFDbUIsUUFBUUEsSUFBSTFCO0FBQUFBLElBQ2Y7QUFFQSxXQUFPO0FBQUEsTUFDTGE7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUc7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUc7QUFBQUEsTUFDQUM7QUFBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDakUsbUJBQW1CLENBQUM7QUFFeEIsUUFBTW1FLHdCQUF3QixPQUFPaEQsU0FBUztBQUM1Q2hCLHFCQUFpQixJQUFJO0FBQ3JCLFFBQUk7QUFDRixZQUFNaUUsY0FBY2xDLHFCQUFxQmYsUUFBUSxvQkFBSU8sS0FBSyxDQUFDO0FBQzNELFlBQU0yQyxXQUFXLE1BQU14RixJQUFJeUY7QUFBQUEsUUFDekIsdUNBQXVDRixXQUFXO0FBQUEsTUFDcEQ7QUFFQSxZQUFNRyxnQkFDSkYsVUFBVWhDLE1BQU1tQyxxQkFDWmxDLE9BQU8sQ0FBQ21DLE1BQU1BLEVBQUVDLGVBQWUsUUFBUUQsRUFBRUMsZUFBZSxNQUFNLEVBQy9EM0IsSUFBSSxDQUFDNEIsUUFBUUMsVUFBVTtBQUN0QixjQUFNQyxVQUFVRixRQUFRRyxzQkFBc0IsQ0FBQztBQUMvQyxjQUFNQyxZQUFZRixTQUFTRyxVQUFVO0FBRXJDLFlBQUlDLG1CQUFtQjtBQUN2QixZQUFJLE9BQU9GLGNBQWMsVUFBVTtBQUNqQyxnQkFBTUcsS0FBS0gsVUFBVUksS0FBSyxFQUFFMUMsWUFBWTtBQUN4QyxjQUFJeUMsT0FBTyxhQUFhQSxPQUFPO0FBQzdCRCwrQkFBbUI7QUFBQSxtQkFDWkMsT0FBTyxTQUFVRCxvQkFBbUI7QUFBQSxtQkFDcENDLE9BQU8sVUFBVUEsT0FBTyxjQUFjQSxPQUFPO0FBQ3BERCwrQkFBbUI7QUFBQSxtQkFDWkMsT0FBTyxXQUFXQSxPQUFPLGNBQWNBLE9BQU87QUFDckRELCtCQUFtQjtBQUFBO0FBRW5CQSwrQkFDRUYsVUFBVUssT0FBTyxDQUFDLEVBQUVDLFlBQVksSUFBSU4sVUFBVU8sTUFBTSxDQUFDO0FBQUEsUUFDM0Q7QUFFQSxjQUFNQyxjQUNIVixTQUFTVyxtQkFBbUIsSUFBSUMsU0FBUyxFQUFFaEQsWUFBWSxNQUN4RDtBQUNGLGNBQU1pRCxZQUFZYixTQUFTYztBQUMzQixjQUFNQyxhQUFhZixTQUFTZ0I7QUFFNUIsWUFBSUMsZUFBZTtBQUVuQixZQUFJSixhQUFhRSxZQUFZO0FBQzNCLGdCQUFNRyxRQUFRckcsTUFBTWdHLFdBQVcsWUFBWTtBQUMzQyxnQkFBTU0sTUFBTXRHLE1BQU1rRyxZQUFZLFlBQVk7QUFFMUMsY0FBSUcsTUFBTUUsUUFBUSxLQUFLRCxJQUFJQyxRQUFRLEtBQUtELElBQUlFLFFBQVFILEtBQUssR0FBRztBQUMxRCxrQkFBTUksY0FBY0gsSUFBSUksS0FBS0wsT0FBTyxRQUFRO0FBQzVDLGtCQUFNTSxRQUFRQyxLQUFLQyxNQUFNSixjQUFjLEVBQUU7QUFDekMsa0JBQU1LLFVBQVVMLGNBQWM7QUFFOUJMLDJCQUFlLEdBQUdPLEtBQUssS0FBS0csT0FBTztBQUFBLFVBQ3JDO0FBQUEsUUFDRjtBQUVBLGVBQU87QUFBQSxVQUNMeEQsS0FBSzJCLFFBQVEzQjtBQUFBQSxVQUNiSixJQUFJZ0MsUUFBUTtBQUFBLFVBQ1pwQyxjQUFjbUMsUUFBUThCLGlCQUFpQjtBQUFBLFVBQ3ZDQyxZQUFZL0IsUUFBUWdDLGdCQUFnQjtBQUFBO0FBQUEsVUFFcENsRCxRQUFRd0IscUJBQXFCLE1BQU0sV0FBV0E7QUFBQUEsVUFDOUNuQixnQkFBZ0JlLFNBQVNXLG1CQUFtQjtBQUFBLFVBQzVDb0IsbUJBQW1CL0IsU0FBU1csbUJBQW1CO0FBQUEsVUFDL0M5RCxNQUFNbUQsU0FBUzFELE9BQU9ELHFCQUFxQjJELFFBQVExRCxJQUFJLElBQUk7QUFBQSxVQUMzRDBGLE1BQU1oQyxTQUFTYyxRQUFRO0FBQUEsVUFDdkJtQixTQUFTakMsU0FBU2dCLGVBQWU7QUFBQSxVQUNqQ2tCLGNBQWNqQjtBQUFBQSxVQUNkN0MsTUFBTTRCLFNBQVNtQyxRQUFRO0FBQUEsVUFDdkI5RCxTQUFTMkIsU0FBU21DLFFBQVE7QUFBQSxVQUMxQkMsY0FBY3BDLFNBQVM3QjtBQUFBQSxVQUN2QmtFLFVBQVUzQjtBQUFBQSxVQUNWNEIsaUJBQWlCNUI7QUFBQUEsVUFFakI2QixlQUNFbkMscUJBQXFCLE1BQU0sV0FBV0E7QUFBQUEsUUFDMUM7QUFBQSxNQUNGLENBQUMsS0FBSztBQUVWaEYsNkJBQXVCc0UsYUFBYTtBQUVwQyxZQUFNOEMsWUFBWSxDQUFDO0FBQ25COUMsb0JBQWMrQyxRQUFRLENBQUMvRSxTQUFTO0FBQzlCOEUsa0JBQVU5RSxLQUFLUyxHQUFHLElBQUksRUFBRXVFLE1BQU0sRUFBRXZDLFFBQVF6QyxLQUFLMkUsU0FBUyxFQUFFO0FBQUEsTUFDMUQsQ0FBQztBQUNEekcsd0JBQWtCNEcsU0FBUztBQUFBLElBQzdCLFNBQVNHLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxrQ0FBa0NBLEtBQUs7QUFBQSxJQUN2RCxVQUFDO0FBQ0NySCx1QkFBaUIsS0FBSztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUVBdUgsWUFBVSxNQUFNO0FBQ2R2RCwwQkFBc0IvRCxZQUFZO0FBQUEsRUFDcEMsR0FBRyxDQUFDQSxZQUFZLENBQUM7QUFHakIsUUFBTXVILHFCQUFxQkEsQ0FBQy9FLElBQUlnRixlQUFlO0FBQzdDM0g7QUFBQUEsTUFBdUIsQ0FBQzRILGFBQ3RCQSxTQUFTOUUsSUFBSSxDQUFDUixTQUFTO0FBQ3JCLFlBQUlBLEtBQUtTLFFBQVFKLEdBQUksUUFBT0w7QUFHNUIsWUFBSXFGLFlBQVk7QUFDZCxpQkFBTyxFQUFFLEdBQUdyRixNQUFNa0IsUUFBUXFFLGlCQUFpQkYsVUFBVSxFQUFFO0FBQUEsUUFDekQ7QUFHQSxjQUFNRyxXQUFXeEYsS0FBS2tCLFVBQVUsVUFBVWdDLFNBQVMsRUFBRWhELFlBQVk7QUFDakUsWUFBSXVGLE9BQU87QUFDWCxZQUFJRCxZQUFZLFVBQVdDLFFBQU87QUFBQSxpQkFDekJELFlBQVksU0FBVUMsUUFBTztBQUFBLGlCQUM3QkQsWUFBWTtBQUNuQkMsaUJBQU87QUFBQSxpQkFDQUQsWUFBWTtBQUNuQkMsaUJBQU87QUFBQSxZQUNKQSxRQUFPO0FBRVosZUFBTyxFQUFFLEdBQUd6RixNQUFNa0IsUUFBUXFFLGlCQUFpQkUsSUFBSSxFQUFFO0FBQUEsTUFDbkQsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTUYsbUJBQW1CQSxDQUFDRyxNQUFNO0FBQzlCLFFBQUksQ0FBQ0EsRUFBRyxRQUFPQTtBQUNmLFVBQU1DLE1BQU1ELEVBQUV4QyxTQUFTO0FBQ3ZCLFFBQUl5QyxJQUFJekYsWUFBWSxNQUFNLGNBQWN5RixJQUFJekYsWUFBWSxNQUFNLFFBQVE7QUFDcEUsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJeUYsSUFBSXpGLFlBQVksTUFBTSxjQUFjeUYsSUFBSXpGLFlBQVksTUFBTSxTQUFTO0FBQ3JFLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBT3lGLElBQUk5QyxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUFJNkMsSUFBSTVDLE1BQU0sQ0FBQyxFQUFFN0MsWUFBWTtBQUFBLEVBQ2hFO0FBRUEsUUFBTTBGLHVCQUF1QkEsQ0FBQ3ZGLElBQUl3RixZQUFZO0FBRTVDLFVBQU1DLFNBQVNySSxvQkFBb0JzSSxLQUFLLENBQUMvRixTQUFTQSxLQUFLUyxRQUFRSixFQUFFO0FBQ2pFLFFBQUl5RixVQUFVQSxPQUFPbEIsaUJBQWlCO0FBRXBDcEcscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWi9CLFNBQVM7QUFBQSxRQUNUZ0MsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBUixzQkFBa0IsQ0FBQ3FDLFVBQVU7QUFBQSxNQUMzQixHQUFHQTtBQUFBQSxNQUNILENBQUNGLEVBQUUsR0FBRyxFQUFFMkUsTUFBTSxFQUFFdkMsUUFBUW9ELFFBQVEsRUFBRTtBQUFBLElBQ3BDLEVBQUU7QUFFRm5JO0FBQUFBLE1BQXVCLENBQUM0SCxhQUN0QkEsU0FBUzlFO0FBQUFBLFFBQUksQ0FBQ1IsU0FDWkEsS0FBS1MsUUFBUUosS0FDVDtBQUFBLFVBQ0UsR0FBR0w7QUFBQUEsVUFDSDJFLFVBQVVrQjtBQUFBQSxVQUNWdEUsZ0JBQWdCc0UsVUFBVSxhQUFhO0FBQUEsVUFDdkN4QixtQkFBbUJ3QixVQUFVLGFBQWE7QUFBQSxRQUM1QyxJQUNBN0Y7QUFBQUEsTUFDTjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTWdHLHFCQUFxQm5GLFFBQVEsTUFBTTtBQUN2QyxXQUFPaEIsYUFBYXBDLHFCQUFxQk0sVUFBVSxFQUFFeUMsSUFBSSxDQUFDUixNQUFNcUMsVUFBVTtBQUN4RSxZQUFNNEQsd0JBQXdCakcsS0FBSzRFLG9CQUFvQjtBQUV2RCxhQUFPO0FBQUEsUUFDTCxHQUFHNUU7QUFBQUEsUUFDSEssSUFBSWdDLFFBQVE7QUFBQSxRQUVaZCxnQkFDRSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1p2QixlQUFLdUIsbUJBQW1CLGFBQ3ZCLHVCQUFDLFVBQUssV0FBVSw0SUFDZDtBQUFBLGlDQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUFHO0FBQUEsYUFENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBRUEsdUJBQUMsVUFBSyxXQUFVLHNJQUNkO0FBQUEsaUNBQUMsU0FBTSxNQUFNLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0I7QUFBQSxVQUFHO0FBQUEsYUFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUE7QUFBQSxRQUlGYixNQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxPQUFPVixLQUFLVSxRQUFRO0FBQUEsWUFDcEIsVUFBVXVGO0FBQUFBLFlBQ1YsVUFBVSxDQUFDQyxNQUFNOUYsaUJBQWlCSixLQUFLUyxLQUFLeUYsRUFBRUMsT0FBTzdGLEtBQUs7QUFBQSxZQUMxRCxhQUFZO0FBQUEsWUFDWixXQUFXLGlFQUNUMkYsd0JBQ0ksaURBQ0EsNkNBQTZDO0FBQUE7QUFBQSxVQVRyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVSztBQUFBO0FBQUEsUUFLUEcsVUFDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUNQLENBQUNILHlCQUF5QmIsbUJBQW1CcEYsS0FBS1MsR0FBRztBQUFBLGNBRXZELFVBQVV3RjtBQUFBQSxjQUNWLFdBQVcsdUdBQ1RBLHdCQUNJLGlEQUNBakcsS0FBS2tCLFdBQVcsWUFDZCx5REFDQWxCLEtBQUtrQixXQUFXLGFBQ2QsaURBQ0FsQixLQUFLa0IsV0FBVyxhQUNkLCtDQUNBLDBDQUEwQztBQUFBLGNBR3JEbEI7QUFBQUEscUJBQUtrQixXQUFXLFlBQ2YsdUJBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QixJQUNyQmxCLEtBQUtrQixXQUFXLGFBQ2xCLHVCQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCLElBQ2RsQixLQUFLa0IsV0FBVyxhQUNsQix1QkFBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUIsSUFFbkIsdUJBQUMsV0FBUSxNQUFNLE1BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0I7QUFBQSxnQkFFcEIsdUJBQUMsVUFBSyxXQUFVLFFBQVFsQixlQUFLa0IsVUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0M7QUFBQTtBQUFBO0FBQUEsWUExQnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTJCQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNsQixLQUFLMkU7QUFBQUEsY0FDZCxVQUFVc0I7QUFBQUEsY0FDVixVQUFVLENBQUNDLE1BQU1OLHFCQUFxQjVGLEtBQUtTLEtBQUt5RixFQUFFQyxPQUFPTixPQUFPO0FBQUEsY0FDaEUsV0FBVyxxREFDVEksd0JBQ0ksa0NBQ0EseUNBQXlDO0FBQUE7QUFBQSxZQVJqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTSztBQUFBLGFBdkNQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0E7QUFBQSxNQUVKO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUN4SSxxQkFBcUJRLGdCQUFnQkYsVUFBVSxDQUFDO0FBRXBELFFBQU1zSSxrQkFBa0JBLENBQUNSLFlBQVk7QUFDbkN2SCxpQkFBYXVILE9BQU87QUFDcEIsVUFBTVMsVUFBVSxDQUFDO0FBR2pCTix1QkFBbUJqQixRQUFRLENBQUMvRSxTQUFTO0FBQ25DLFVBQUksQ0FBQ0EsS0FBSzRFLGlCQUFpQjtBQUN6QjBCLGdCQUFRdEcsS0FBS1MsR0FBRyxJQUFJLEVBQUV1RSxNQUFNLEVBQUV2QyxRQUFRb0QsUUFBUSxFQUFFO0FBQUEsTUFDbEQ7QUFBQSxJQUNGLENBQUM7QUFFRDNILHNCQUFrQixDQUFDcUMsVUFBVSxFQUFFLEdBQUdBLE1BQU0sR0FBRytGLFFBQVEsRUFBRTtBQUVyRDVJO0FBQUFBLE1BQXVCLENBQUM0SCxhQUN0QkEsU0FBUzlFO0FBQUFBLFFBQUksQ0FBQ1IsU0FDWmdHLG1CQUFtQkQsS0FBSyxDQUFDUSxNQUFNQSxFQUFFOUYsUUFBUVQsS0FBS1MsR0FBRyxLQUNqRCxDQUFDVCxLQUFLNEUsa0JBQ0Y7QUFBQSxVQUNFLEdBQUc1RTtBQUFBQSxVQUNIMkUsVUFBVWtCO0FBQUFBLFVBQ1Z0RSxnQkFBZ0JzRSxVQUFVLGFBQWE7QUFBQSxRQUN6QyxJQUNBN0Y7QUFBQUEsTUFDTjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTXdHLGVBQWUsWUFBWTtBQUMvQixRQUFJckksYUFBYztBQUNsQkMsb0JBQWdCLElBQUk7QUFDcEIsUUFBSTtBQUNGLFlBQU1xSSxjQUFjQyxLQUFLQyxNQUFNQyxhQUFhQyxRQUFRLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDakUsWUFBTUMsYUFBYUwsYUFBYWhHO0FBQ2hDLFlBQU1zRyxnQkFBZ0JwSCxxQkFBcUI5QixnQkFBZ0Isb0JBQUlzQixLQUFLLENBQUM7QUFFckUsWUFBTTZILGtCQUFrQnZKLG9CQUFvQnNDO0FBQUFBLFFBQzFDLENBQUNrSCxRQUNDQSxJQUFJdEMsYUFBYXNDLElBQUlyQyxtQkFDcEJxQyxJQUFJdEMsWUFBWXNDLElBQUkvRixXQUFXK0YsSUFBSXBDLGlCQUNuQ29DLElBQUl0QyxZQUFZc0MsSUFBSXZHLFFBQVF1RyxJQUFJdkcsS0FBS2tDLEtBQUssTUFBTTtBQUFBLE1BQ3JEO0FBRUEsWUFBTXNFLGtCQUFrQkYsZ0JBQWdCakg7QUFBQUEsUUFDdEMsQ0FBQ2tILFFBQVFBLElBQUl2QyxnQkFBZ0J1QyxJQUFJdEM7QUFBQUEsTUFDbkM7QUFDQSxZQUFNd0MsZUFBZUgsZ0JBQWdCakg7QUFBQUEsUUFDbkMsQ0FBQ2tILFFBQVEsQ0FBQ0EsSUFBSXZDLGdCQUFnQnVDLElBQUl0QztBQUFBQSxNQUNwQztBQUVBLFVBQUl1QyxnQkFBZ0JuRyxTQUFTLEdBQUc7QUFDOUIsY0FBTXFHLGNBQWNGLGdCQUFnQjFHLElBQUksQ0FBQ3lHLFNBQVM7QUFBQSxVQUNoREksYUFBYUosSUFBSXhHO0FBQUFBLFVBQ2pCNkcsZUFBZUwsSUFBSXZDO0FBQUFBLFVBQ25CakMsUUFBUXdFLElBQUkvRjtBQUFBQSxVQUNaK0IsaUJBQWlCO0FBQUEsVUFDakJzRSxhQUFhVDtBQUFBQSxVQUNickMsTUFBTXdDLElBQUl2RyxRQUFRO0FBQUE7QUFBQSxRQUNwQixFQUFFO0FBRUYsY0FBTXBFLElBQUlrTCxJQUFJLHlDQUF5QztBQUFBLFVBQ3JEQyxTQUFTTDtBQUFBQSxRQUNYLENBQUM7QUFBQSxNQUNIO0FBRUEsVUFBSUQsYUFBYXBHLFNBQVMsR0FBRztBQUMzQixjQUFNekUsSUFBSW9MLEtBQUssNkNBQTZDO0FBQUEsVUFDMURDLFdBQVdSLGFBQWEzRyxJQUFJLENBQUN5RyxTQUFTO0FBQUEsWUFDcENJLGFBQWFKLElBQUl4RztBQUFBQSxZQUNqQmdDLFFBQVF3RSxJQUFJL0Y7QUFBQUEsWUFDWitCLGlCQUFpQjtBQUFBLFlBQ2pCc0UsYUFBYVQ7QUFBQUEsWUFDYmxJLE1BQU1tSTtBQUFBQSxZQUNOdEMsTUFBTXdDLElBQUl2RyxRQUFRO0FBQUE7QUFBQSxVQUNwQixFQUFFO0FBQUEsUUFDSixDQUFDO0FBQUEsTUFDSDtBQUVBLFlBQU1rQixzQkFBc0IvRCxZQUFZO0FBQ3hDVyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaL0IsU0FBUztBQUFBLFFBQ1RnQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBRURaLHNCQUFnQkQsWUFBWTtBQUFBLElBQzlCLFNBQVNvSCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sc0NBQXNDQSxLQUFLO0FBQ3pEekcscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWi9CLFNBQVM7QUFBQSxRQUNUZ0MsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDTixzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU13SixvQkFBb0I7QUFBQSxJQUN4QixFQUFFQyxLQUFLLE1BQU1DLFFBQVEsUUFBUTtBQUFBLElBQzdCLEVBQUVELEtBQUssY0FBY0MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUVELEtBQUssUUFBUUMsUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFdBQVc7QUFBQSxJQUNyQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsU0FBUztBQUFBLElBQ2hDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxVQUFVO0FBQUEsRUFBQztBQUd4QyxRQUFNQyx1QkFBdUI7QUFBQSxJQUMzQixFQUFFRixLQUFLLE1BQU1DLFFBQVEsUUFBUTtBQUFBLElBQzdCLEVBQUVELEtBQUssY0FBY0MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLHFCQUFxQkMsUUFBUSxrQkFBa0I7QUFBQSxJQUN0RCxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUVELEtBQUssUUFBUUMsUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFdBQVc7QUFBQSxJQUNyQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHdEMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0dBQ2IsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsNkJBQTZCLENBQUM1QixNQUFNbEksY0FBY2tJLEVBQUVDLE9BQU83RixLQUFLO0FBQUEsUUFDaEUsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBQ1I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU0vQixZQUFZRztBQUFBQSxRQUNsQixXQUFXSCxZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZN0I7QUFBQUEsUUFDckIsU0FBUyxNQUNQOEIsZUFBZSxDQUFDK0IsVUFBVSxFQUFFLEdBQUdBLE1BQU05QixZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsTUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxJQUVILHVCQUFDLFNBQUksV0FBVSx1QkFFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsK0JBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDWCx1QkFBQyxRQUFHLFdBQVUsMENBQXlDLG1DQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxrQkFBaUIsOERBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsU0FBSSxXQUFVLCtFQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdGQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHdDQUF1QywyQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlKQUNiO0FBQUEscUNBQUMsWUFBUyxNQUFNLElBQUksV0FBVSxvQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQSxjQUM5QztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FDRVosaUJBQWdCLG9CQUFJc0IsS0FBSyxHQUFFNkksWUFBWSxFQUFFOUksTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLGtCQUV2RCxNQUFLLG9CQUFJQyxLQUFLLEdBQUU2SSxZQUFZLEVBQUU5SSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsa0JBQzFDLFVBQVUsQ0FBQ2dILE1BQU1wSSxnQkFBZ0JvSSxFQUFFQyxPQUFPN0YsS0FBSztBQUFBLGtCQUMvQyxXQUFVO0FBQUE7QUFBQSxnQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPZ0Y7QUFBQSxpQkFUbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSx3Q0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLElBQUc7QUFBQSxnQkFDSCxTQUFTakM7QUFBQUEsZ0JBQ1QsVUFBVSxDQUFDNkgsTUFBTUcsZ0JBQWdCSCxFQUFFQyxPQUFPTixPQUFPO0FBQUEsZ0JBQ2pELFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSytEO0FBQUEsWUFFL0Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFRO0FBQUEsZ0JBQ1IsV0FBVTtBQUFBLGdCQUFtRDtBQUFBO0FBQUEsY0FGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxhQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0NBO0FBQUEsUUFFQ2xJLGdCQUNDLHVCQUFDLGtCQUFlLE9BQU0sc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0MsSUFFeEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNRO0FBQUFBLFlBQ1QsVUFBVUE7QUFBQUEsWUFDVixTQUFTcUk7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVHJJLHlCQUFlLGdCQUFnQjtBQUFBO0FBQUEsVUFQbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxXQW5ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcURBLEtBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1REE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSwrQkFBOEIsK0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxvQ0FDYnlDLHVCQUFhRSxTQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw0RUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSwrQkFBOEIsdUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsVUFDckQsdUJBQUMsVUFBSyxXQUFVLG9DQUNiRix1QkFBYUksV0FEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMEVBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsK0JBQThCLHNCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQ3BELHVCQUFDLFVBQUssV0FBVSxrQ0FDYkosdUJBQWFPLFVBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLCtCQUE4Qix3QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Q7QUFBQSxVQUN0RCx1QkFBQyxVQUFLLFdBQVUsbUNBQ2JQLHVCQUFhUSxXQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSwrQkFBOEIsd0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNEO0FBQUEsVUFDdEQsdUJBQUMsVUFBSyxXQUFVLHFDQUNiUix1QkFBYVMsV0FEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsOEVBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsK0JBQThCLHdCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLFVBQ3RELHVCQUFDLFVBQUssV0FBVSxzQ0FDYlQsdUJBQWFVLFlBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDRFQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLCtCQUE4Qix1QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxVQUNyRCx1QkFBQyxVQUFLLFdBQVUsb0NBQ2JWLHVCQUFhYSxXQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbURBO0FBQUEsTUFDQ2IsYUFBYWMscUJBQXFCWCxTQUFTLEtBQzFDLHVCQUFDLFNBQUksV0FBVSx1RUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSw2Q0FBNEMsMENBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUNaSCx1QkFBYWMscUJBQXFCbEI7QUFBQUEsVUFBSSxDQUFDeUgsTUFBTTVGLFVBQzVDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFVO0FBQUEsY0FFVDRGO0FBQUFBO0FBQUFBLFlBSEk1RjtBQUFBQSxZQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFFBQ0QsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BSUYsdUJBQUMsU0FBSSxXQUFVLDZIQUNaMUUsMEJBQ0MsdUJBQUMsa0JBQWUsT0FBTSxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QyxJQUV4QztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBU2lLO0FBQUFBLFVBQ1QsWUFBWUc7QUFBQUEsVUFDWixNQUFNL0I7QUFBQUEsVUFDTixpQkFBaUI7QUFBQSxZQUNmO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUFnQjtBQUFBLFVBRWxCLG1CQUFtQjtBQUFBLFlBQ2pCLEdBQUdwRixhQUFhRSxLQUFLO0FBQUEsWUFDckIsR0FBR0YsYUFBYUksT0FBTztBQUFBLFlBQ3ZCLEdBQUdKLGFBQWFPLE1BQU07QUFBQSxZQUN0QixHQUFHUCxhQUFhUSxPQUFPO0FBQUEsWUFDdkIsR0FBR1IsYUFBYVMsT0FBTztBQUFBLFlBQ3ZCLEdBQUdULGFBQWFVLFFBQVE7QUFBQSxVQUFFO0FBQUEsVUFFNUIsaUJBQWdCO0FBQUEsVUFDaEIsa0JBQWtCO0FBQUE7QUFBQSxRQXJCcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcUI2QyxLQXpCakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRCQTtBQUFBLFNBMUtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyS0E7QUFBQSxPQXpMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMExBLEtBM0xGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0TEE7QUFFSjtBQUFFOUQsR0E3c0JJRCwwQkFBd0I7QUFBQTJLLEtBQXhCM0s7QUErc0JOLGVBQWVBO0FBQXlCLElBQUEySztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJhcGkiLCJEYXRhVGFibGUiLCJOYXZiYXIiLCJCdXR0b24iLCJtZXNzYWdlIiwiQ2lyY3VsYXJMb2FkZXIiLCJDdXN0b21BbGVydERpYWxvZyIsIlNpZGViYXIiLCJDaGVja0NpcmNsZTIiLCJYQ2lyY2xlIiwiQ2FsZW5kYXIiLCJTZWFyY2giLCJDbG9jayIsImRheWpzIiwiZHVyYXRpb24iLCJCcmVhZGNydW1iIiwiZXh0ZW5kIiwiRW1wbG95ZWVBdHRlbmRhbmNlUmVwb3J0IiwiX3MiLCJ0YWJsZUF0dGVuZGFuY2VEYXRhIiwic2V0VGFibGVBdHRlbmRhbmNlRGF0YSIsInNjcmVlbkxvYWRpbmciLCJzZXRTY3JlZW5Mb2FkaW5nIiwic2VsZWN0ZWREYXRlIiwic2V0U2VsZWN0ZWREYXRlIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJhY3RpdmVVc2VyRGF0YSIsInNldEFjdGl2ZVVzZXJEYXRhIiwiaXNTdWJtaXR0aW5nIiwic2V0SXNTdWJtaXR0aW5nIiwic2VsZWN0QWxsIiwic2V0U2VsZWN0QWxsIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJ0eXBlIiwiZm9ybWF0RGF0ZUZvckRpc3BsYXkiLCJkYXRlIiwiZCIsInRlc3QiLCJ5ZWFyIiwibW9udGgiLCJkYXkiLCJzcGxpdCIsIkRhdGUiLCJpc05hTiIsImdldFRpbWUiLCJTdHJpbmciLCJnZXREYXRlIiwicGFkU3RhcnQiLCJnZXRNb250aCIsImdldEZ1bGxZZWFyIiwiZm9ybWF0RGF0ZUZvckJhY2tlbmQiLCJ0b2RheSIsImZpbHRlck9wdGlvbiIsImRhdGEiLCJmaWx0ZXIiLCJpdGVtIiwiRW1wbG95ZWVOYW1lIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImhhbmRsZU5vdGVDaGFuZ2UiLCJpZCIsInZhbHVlIiwicHJldiIsIm1hcCIsIl9pZCIsIk5vdGUiLCJOb3RlUmF3Iiwic3VtbWFyeVN0YXRzIiwidXNlTWVtbyIsInRvdGFsIiwibGVuZ3RoIiwicHJlc2VudCIsInIiLCJTdGF0dXMiLCJhYnNlbnQiLCJoYWxmZGF5Iiwib25sZWF2ZSIsImFwcHJvdmVkIiwiQXBwcm92YWxTdGF0dXMiLCJwZW5kaW5nRW1wbG95ZWVzIiwicGVuZGluZyIsInBlbmRpbmdFbXBsb3llZU5hbWVzIiwiZW1wIiwiZmV0Y2hBdHRlbmRhbmNlUmVwb3J0IiwiY3VycmVudERhdGUiLCJyZXNwb25zZSIsImdldCIsImZvcm1hdHRlZERhdGEiLCJhZ2VudEF0dGVuZGFuY2VEYXRhIiwidiIsImlzVmVyaWZpZWQiLCJhdHRlbmQiLCJpbmRleCIsImRldGFpbHMiLCJhdHRlbmRhbmNlX2RldGFpbHMiLCJyYXdTdGF0dXMiLCJzdGF0dXMiLCJub3JtYWxpemVkU3RhdHVzIiwicnMiLCJ0cmltIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzbGljZSIsImlzQXBwcm92ZWQiLCJhcHByb3ZhbF9zdGF0dXMiLCJ0b1N0cmluZyIsImxvZ2luVGltZSIsInRpbWUiLCJsb2dvdXRUaW1lIiwibG9nb3V0X3RpbWUiLCJ3b3JraW5nSG91cnMiLCJzdGFydCIsImVuZCIsImlzVmFsaWQiLCJpc0FmdGVyIiwiZGlmZk1pbnV0ZXMiLCJkaWZmIiwiaG91cnMiLCJNYXRoIiwiZmxvb3IiLCJtaW51dGVzIiwiZW1wbG95ZWVfbmFtZSIsIkVtcGxveWVlSWQiLCJlbXBsb3llZUNvZGUiLCJBcHByb3ZhbFN0YXR1c1JhdyIsIlRpbWUiLCJPdXRUaW1lIiwiV29ya2luZ0hvdXJzIiwibm90ZSIsImF0dGVuZGFuY2VJZCIsIkFwcHJvdmVkIiwiSW5pdGlhbEFwcHJvdmVkIiwiSW5pdGlhbFN0YXR1cyIsImFjdGl2ZU1hcCIsImZvckVhY2giLCJpbmZvIiwiZXJyb3IiLCJjb25zb2xlIiwidXNlRWZmZWN0IiwiaGFuZGxlU3RhdHVzVG9nZ2xlIiwibmV4dFN0YXR1cyIsInByZXZEYXRhIiwiY2FwaXRhbGl6ZVN0YXR1cyIsImN1cnJlbnQiLCJuZXh0IiwicyIsInN0ciIsImhhbmRsZUNoZWNrYm94Q2hhbmdlIiwiY2hlY2tlZCIsInJlY29yZCIsImZpbmQiLCJmaWx0ZXJlZEF0dGVuZGFuY2UiLCJpc1Blcm1hbmVudGx5QXBwcm92ZWQiLCJlIiwidGFyZ2V0IiwiY2hlY2tCb3giLCJoYW5kbGVTZWxlY3RBbGwiLCJ1cGRhdGVkIiwiZiIsImhhbmRsZVN1Ym1pdCIsImN1cnJlbnRVc2VyIiwiSlNPTiIsInBhcnNlIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImFwcHJvdmVkQnkiLCJmb3JtYXR0ZWREYXRlIiwicmVjb3Jkc1RvVXBkYXRlIiwicm93IiwiZXhpc3RpbmdVcGRhdGVzIiwibmV3QWJzZW50ZWVzIiwidXBkYXRlZERhdGEiLCJlbXBsb3llZV9pZCIsImF0dGVuZGFuY2VfaWQiLCJhcHByb3ZlZF9ieSIsInB1dCIsInVwZGF0ZXMiLCJwb3N0IiwiYWJzZW50ZWVzIiwiQXR0ZW5kYW5jZUNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJQREZBdHRlbmRhbmNlQ29sdW1ucyIsInRvSVNPU3RyaW5nIiwibmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVtcGxveWVlQXR0ZW5kYW5jZVJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBCdXR0b24sIG1lc3NhZ2UgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBDaGVja0NpcmNsZTIsIFhDaXJjbGUsIENhbGVuZGFyLCBTZWFyY2gsIENsb2NrIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XHJcbmltcG9ydCBkdXJhdGlvbiBmcm9tIFwiZGF5anMvcGx1Z2luL2R1cmF0aW9uXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcbmRheWpzLmV4dGVuZChkdXJhdGlvbik7XHJcblxyXG5jb25zdCBFbXBsb3llZUF0dGVuZGFuY2VSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3RhYmxlQXR0ZW5kYW5jZURhdGEsIHNldFRhYmxlQXR0ZW5kYW5jZURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzY3JlZW5Mb2FkaW5nLCBzZXRTY3JlZW5Mb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWN0aXZlVXNlckRhdGEsIHNldEFjdGl2ZVVzZXJEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgLy8gRm9ybWF0IGRhdGUgZm9yIHVzZXIgZGlzcGxheSAoZGQtbW0teXl5eSlcclxuICBjb25zdCBmb3JtYXREYXRlRm9yRGlzcGxheSA9IChkYXRlKSA9PiB7XHJcbiAgICBpZiAoIWRhdGUpIHJldHVybiBcIi1cIjtcclxuXHJcbiAgICBsZXQgZDtcclxuICAgIGlmICh0eXBlb2YgZGF0ZSA9PT0gXCJzdHJpbmdcIiAmJiAvXlxcZHs0fS1cXGR7Mn0tXFxkezJ9JC8udGVzdChkYXRlKSkge1xyXG4gICAgICBjb25zdCBbeWVhciwgbW9udGgsIGRheV0gPSBkYXRlLnNwbGl0KFwiLVwiKTtcclxuICAgICAgZCA9IG5ldyBEYXRlKHllYXIsIG1vbnRoIC0gMSwgZGF5KTtcclxuICAgIH0gZWxzZSBpZiAodHlwZW9mIGRhdGUgPT09IFwic3RyaW5nXCIgJiYgL15cXGR7Mn0tXFxkezJ9LVxcZHs0fSQvLnRlc3QoZGF0ZSkpIHtcclxuICAgICAgcmV0dXJuIGRhdGU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGlzTmFOKGQuZ2V0VGltZSgpKSkge1xyXG4gICAgICByZXR1cm4gXCItXCI7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZGF5ID0gU3RyaW5nKGQuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICBjb25zdCBtb250aCA9IFN0cmluZyhkLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICBjb25zdCB5ZWFyID0gZC5nZXRGdWxsWWVhcigpO1xyXG4gICAgcmV0dXJuIGAke2RheX0tJHttb250aH0tJHt5ZWFyfWA7XHJcbiAgfTtcclxuXHJcbiAgLy8gRm9ybWF0IGRhdGUgZm9yIGJhY2tlbmQgKHl5eXktbW0tZGQpXHJcbiAgY29uc3QgZm9ybWF0RGF0ZUZvckJhY2tlbmQgPSAoZGF0ZSkgPT4ge1xyXG4gICAgaWYgKCFkYXRlKSB7XHJcbiAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgICAgcmV0dXJuIGAke3RvZGF5LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKHRvZGF5LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydChcclxuICAgICAgICAyLFxyXG4gICAgICAgIFwiMFwiLFxyXG4gICAgICApfS0ke1N0cmluZyh0b2RheS5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBkO1xyXG4gICAgaWYgKHR5cGVvZiBkYXRlID09PSBcInN0cmluZ1wiICYmIC9eXFxkezR9LVxcZHsyfS1cXGR7Mn0kLy50ZXN0KGRhdGUpKSB7XHJcbiAgICAgIHJldHVybiBkYXRlO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZGF0ZSA9PT0gXCJzdHJpbmdcIiAmJiAvXlxcZHsyfS1cXGR7Mn0tXFxkezR9JC8udGVzdChkYXRlKSkge1xyXG4gICAgICBjb25zdCBbZGF5LCBtb250aCwgeWVhcl0gPSBkYXRlLnNwbGl0KFwiLVwiKTtcclxuICAgICAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWA7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICAgIGlmIChpc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHllYXIgPSBkLmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtb250aCA9IFN0cmluZyhkLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICBjb25zdCBkYXkgPSBTdHJpbmcoZC5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZpbHRlck9wdGlvbiA9IChkYXRhLCBzZWFyY2hUZXh0KSA9PiB7XHJcbiAgICBpZiAoIXNlYXJjaFRleHQpIHJldHVybiBkYXRhO1xyXG4gICAgcmV0dXJuIGRhdGEuZmlsdGVyKChpdGVtKSA9PlxyXG4gICAgICBpdGVtLkVtcGxveWVlTmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSksXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU5vdGVDaGFuZ2UgPSAoaWQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRUYWJsZUF0dGVuZGFuY2VEYXRhKChwcmV2KSA9PlxyXG4gICAgICBwcmV2Lm1hcCgoaXRlbSkgPT5cclxuICAgICAgICBpdGVtLl9pZCA9PT0gaWQgPyB7IC4uLml0ZW0sIE5vdGU6IHZhbHVlLCBOb3RlUmF3OiB2YWx1ZSB9IDogaXRlbSxcclxuICAgICAgKSxcclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgLy8gY29uc3Qgc3VtbWFyeVN0YXRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgLy8gICBjb25zdCB0b3RhbCA9IHRhYmxlQXR0ZW5kYW5jZURhdGEubGVuZ3RoO1xyXG4gIC8vICAgY29uc3QgcHJlc2VudCA9IHRhYmxlQXR0ZW5kYW5jZURhdGEuZmlsdGVyKFxyXG4gIC8vICAgICAocikgPT4gci5TdGF0dXMgPT09IFwiUHJlc2VudFwiXHJcbiAgLy8gICApLmxlbmd0aDtcclxuICAvLyAgIGNvbnN0IGFic2VudCA9IHRhYmxlQXR0ZW5kYW5jZURhdGEuZmlsdGVyKFxyXG4gIC8vICAgICAocikgPT4gci5TdGF0dXMgPT09IFwiQWJzZW50XCJcclxuICAvLyAgICkubGVuZ3RoO1xyXG4gIC8vICAgY29uc3QgaGFsZmRheSA9IHRhYmxlQXR0ZW5kYW5jZURhdGEuZmlsdGVyKFxyXG4gIC8vICAgICAocikgPT4gci5TdGF0dXMgPT09IFwiSGFsZiBEYXlcIlxyXG4gIC8vICAgKS5sZW5ndGg7XHJcbiAgLy8gICAvLyBGaXhlZDogQ2hhbmdlZCByLnN0YXR1cyB0byByLlN0YXR1c1xyXG4gIC8vICAgY29uc3Qgb25sZWF2ZSA9IHRhYmxlQXR0ZW5kYW5jZURhdGEuZmlsdGVyKChyKSA9PiByLlN0YXR1cyA9PT0gXCJPbiBMZWF2ZVwiKS5sZW5ndGg7XHJcbiAgLy8gICBjb25zdCBhcHByb3ZlZCA9IHRhYmxlQXR0ZW5kYW5jZURhdGEuZmlsdGVyKFxyXG4gIC8vICAgICAocikgPT4gci5BcHByb3ZhbFN0YXR1cyA9PT0gXCJBcHByb3ZlZFwiXHJcbiAgLy8gICApLmxlbmd0aDtcclxuICAvLyAgIGNvbnN0IHBlbmRpbmcgPSB0YWJsZUF0dGVuZGFuY2VEYXRhLmZpbHRlcihcclxuICAvLyAgICAgKHIpID0+IHIuQXBwcm92YWxTdGF0dXMgPT09IFwiUGVuZGluZ1wiXHJcbiAgLy8gICApLmxlbmd0aDtcclxuXHJcbiAgLy8gICByZXR1cm4geyB0b3RhbCwgcHJlc2VudCwgYWJzZW50LCBoYWxmZGF5LCBvbmxlYXZlLCBhcHByb3ZlZCwgcGVuZGluZyB9O1xyXG4gIC8vIH0sIFt0YWJsZUF0dGVuZGFuY2VEYXRhXSk7XHJcblxyXG4gIGNvbnN0IHN1bW1hcnlTdGF0cyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgdG90YWwgPSB0YWJsZUF0dGVuZGFuY2VEYXRhLmxlbmd0aDtcclxuXHJcbiAgICBjb25zdCBwcmVzZW50ID0gdGFibGVBdHRlbmRhbmNlRGF0YS5maWx0ZXIoXHJcbiAgICAgIChyKSA9PiByLlN0YXR1cyA9PT0gXCJQcmVzZW50XCIsXHJcbiAgICApLmxlbmd0aDtcclxuXHJcbiAgICBjb25zdCBhYnNlbnQgPSB0YWJsZUF0dGVuZGFuY2VEYXRhLmZpbHRlcihcclxuICAgICAgKHIpID0+IHIuU3RhdHVzID09PSBcIkFic2VudFwiLFxyXG4gICAgKS5sZW5ndGg7XHJcblxyXG4gICAgY29uc3QgaGFsZmRheSA9IHRhYmxlQXR0ZW5kYW5jZURhdGEuZmlsdGVyKFxyXG4gICAgICAocikgPT4gci5TdGF0dXMgPT09IFwiSGFsZiBEYXlcIixcclxuICAgICkubGVuZ3RoO1xyXG5cclxuICAgIGNvbnN0IG9ubGVhdmUgPSB0YWJsZUF0dGVuZGFuY2VEYXRhLmZpbHRlcihcclxuICAgICAgKHIpID0+IHIuU3RhdHVzID09PSBcIk9uIExlYXZlXCIsXHJcbiAgICApLmxlbmd0aDtcclxuXHJcbiAgICBjb25zdCBhcHByb3ZlZCA9IHRhYmxlQXR0ZW5kYW5jZURhdGEuZmlsdGVyKFxyXG4gICAgICAocikgPT4gci5BcHByb3ZhbFN0YXR1cyA9PT0gXCJBcHByb3ZlZFwiLFxyXG4gICAgKS5sZW5ndGg7XHJcblxyXG4gICAgY29uc3QgcGVuZGluZ0VtcGxveWVlcyA9IHRhYmxlQXR0ZW5kYW5jZURhdGEuZmlsdGVyKFxyXG4gICAgICAocikgPT4gci5BcHByb3ZhbFN0YXR1cyAhPT0gXCJBcHByb3ZlZFwiLFxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCBwZW5kaW5nID0gcGVuZGluZ0VtcGxveWVlcy5sZW5ndGg7XHJcblxyXG4gICAgY29uc3QgcGVuZGluZ0VtcGxveWVlTmFtZXMgPSBwZW5kaW5nRW1wbG95ZWVzLm1hcChcclxuICAgICAgKGVtcCkgPT4gZW1wLkVtcGxveWVlTmFtZSxcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWwsXHJcbiAgICAgIHByZXNlbnQsXHJcbiAgICAgIGFic2VudCxcclxuICAgICAgaGFsZmRheSxcclxuICAgICAgb25sZWF2ZSxcclxuICAgICAgYXBwcm92ZWQsXHJcbiAgICAgIHBlbmRpbmcsXHJcbiAgICAgIHBlbmRpbmdFbXBsb3llZU5hbWVzLFxyXG4gICAgfTtcclxuICB9LCBbdGFibGVBdHRlbmRhbmNlRGF0YV0pO1xyXG5cclxuICBjb25zdCBmZXRjaEF0dGVuZGFuY2VSZXBvcnQgPSBhc3luYyAoZGF0ZSkgPT4ge1xyXG4gICAgc2V0U2NyZWVuTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnREYXRlID0gZm9ybWF0RGF0ZUZvckJhY2tlbmQoZGF0ZSB8fCBuZXcgRGF0ZSgpKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvZW1wbG95ZWUtYXR0ZW5kYW5jZS9lbXBsb3llZXMvZGF0ZS8ke2N1cnJlbnREYXRlfWAsXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID1cclxuICAgICAgICByZXNwb25zZT8uZGF0YT8uYWdlbnRBdHRlbmRhbmNlRGF0YVxyXG4gICAgICAgICAgPy5maWx0ZXIoKHYpID0+IHYuaXNWZXJpZmllZCA9PT0gdHJ1ZSB8fCB2LmlzVmVyaWZpZWQgPT09IFwidHJ1ZVwiKVxyXG4gICAgICAgICAgLm1hcCgoYXR0ZW5kLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBkZXRhaWxzID0gYXR0ZW5kPy5hdHRlbmRhbmNlX2RldGFpbHMgfHwge307XHJcbiAgICAgICAgICAgIGNvbnN0IHJhd1N0YXR1cyA9IGRldGFpbHM/LnN0YXR1cyB8fCBcIlwiO1xyXG4gICAgICAgICAgICAvLyBOb3JtYWxpemUgc3RhdHVzIChwb3NzaWJsZSBiYWNrZW5kIHZhbHVlcyAtPiBvdXIgVUkgdmFsdWVzKVxyXG4gICAgICAgICAgICBsZXQgbm9ybWFsaXplZFN0YXR1cyA9IFwiXCI7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcmF3U3RhdHVzID09PSBcInN0cmluZ1wiKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgcnMgPSByYXdTdGF0dXMudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgICAgaWYgKHJzID09PSBcInByZXNlbnRcIiB8fCBycyA9PT0gXCJwcmVzZW50ZWRcIilcclxuICAgICAgICAgICAgICAgIG5vcm1hbGl6ZWRTdGF0dXMgPSBcIlByZXNlbnRcIjtcclxuICAgICAgICAgICAgICBlbHNlIGlmIChycyA9PT0gXCJhYnNlbnRcIikgbm9ybWFsaXplZFN0YXR1cyA9IFwiQWJzZW50XCI7XHJcbiAgICAgICAgICAgICAgZWxzZSBpZiAocnMgPT09IFwiaGFsZlwiIHx8IHJzID09PSBcImhhbGYgZGF5XCIgfHwgcnMgPT09IFwiSGFsZiBEYXlcIilcclxuICAgICAgICAgICAgICAgIG5vcm1hbGl6ZWRTdGF0dXMgPSBcIkhhbGYgRGF5XCI7XHJcbiAgICAgICAgICAgICAgZWxzZSBpZiAocnMgPT09IFwibGVhdmVcIiB8fCBycyA9PT0gXCJvbiBsZWF2ZVwiIHx8IHJzID09PSBcIk9uIExlYXZlXCIpXHJcbiAgICAgICAgICAgICAgICBub3JtYWxpemVkU3RhdHVzID0gXCJPbiBMZWF2ZVwiO1xyXG4gICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgIG5vcm1hbGl6ZWRTdGF0dXMgPVxyXG4gICAgICAgICAgICAgICAgICByYXdTdGF0dXMuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyByYXdTdGF0dXMuc2xpY2UoMSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGlzQXBwcm92ZWQgPVxyXG4gICAgICAgICAgICAgIChkZXRhaWxzPy5hcHByb3ZhbF9zdGF0dXMgfHwgXCJcIikudG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpID09PVxyXG4gICAgICAgICAgICAgIFwiYXBwcm92ZWRcIjtcclxuICAgICAgICAgICAgY29uc3QgbG9naW5UaW1lID0gZGV0YWlscz8udGltZTtcclxuICAgICAgICAgICAgY29uc3QgbG9nb3V0VGltZSA9IGRldGFpbHM/LmxvZ291dF90aW1lO1xyXG5cclxuICAgICAgICAgICAgbGV0IHdvcmtpbmdIb3VycyA9IFwiLVwiO1xyXG5cclxuICAgICAgICAgICAgaWYgKGxvZ2luVGltZSAmJiBsb2dvdXRUaW1lKSB7XHJcbiAgICAgICAgICAgICAgY29uc3Qgc3RhcnQgPSBkYXlqcyhsb2dpblRpbWUsIFwiaGg6bW06c3MgYVwiKTtcclxuICAgICAgICAgICAgICBjb25zdCBlbmQgPSBkYXlqcyhsb2dvdXRUaW1lLCBcImhoOm1tOnNzIGFcIik7XHJcblxyXG4gICAgICAgICAgICAgIGlmIChzdGFydC5pc1ZhbGlkKCkgJiYgZW5kLmlzVmFsaWQoKSAmJiBlbmQuaXNBZnRlcihzdGFydCkpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRpZmZNaW51dGVzID0gZW5kLmRpZmYoc3RhcnQsIFwibWludXRlXCIpO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgaG91cnMgPSBNYXRoLmZsb29yKGRpZmZNaW51dGVzIC8gNjApO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbWludXRlcyA9IGRpZmZNaW51dGVzICUgNjA7XHJcblxyXG4gICAgICAgICAgICAgICAgd29ya2luZ0hvdXJzID0gYCR7aG91cnN9aCAke21pbnV0ZXN9bWA7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIF9pZDogYXR0ZW5kPy5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBFbXBsb3llZU5hbWU6IGF0dGVuZD8uZW1wbG95ZWVfbmFtZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICBFbXBsb3llZUlkOiBhdHRlbmQ/LmVtcGxveWVlQ29kZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAvLyBEZWZhdWx0IHRvIEFic2VudCBpZiBubyBleHBsaWNpdCBzdGF0dXMgZm91bmQgKG1pcnJvcnMgZWFybGllciBiZWhhdmlvciBpZiBkZXNpcmVkKVxyXG4gICAgICAgICAgICAgIFN0YXR1czogbm9ybWFsaXplZFN0YXR1cyA9PT0gXCItXCIgPyBcIkFic2VudFwiIDogbm9ybWFsaXplZFN0YXR1cyxcclxuICAgICAgICAgICAgICBBcHByb3ZhbFN0YXR1czogZGV0YWlscz8uYXBwcm92YWxfc3RhdHVzIHx8IFwiUGVuZGluZ1wiLFxyXG4gICAgICAgICAgICAgIEFwcHJvdmFsU3RhdHVzUmF3OiBkZXRhaWxzPy5hcHByb3ZhbF9zdGF0dXMgfHwgXCJQZW5kaW5nXCIsXHJcbiAgICAgICAgICAgICAgRGF0ZTogZGV0YWlscz8uZGF0ZSA/IGZvcm1hdERhdGVGb3JEaXNwbGF5KGRldGFpbHMuZGF0ZSkgOiBcIi1cIixcclxuICAgICAgICAgICAgICBUaW1lOiBkZXRhaWxzPy50aW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgIE91dFRpbWU6IGRldGFpbHM/LmxvZ291dF90aW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgIFdvcmtpbmdIb3Vyczogd29ya2luZ0hvdXJzLFxyXG4gICAgICAgICAgICAgIE5vdGU6IGRldGFpbHM/Lm5vdGUgfHwgXCJcIixcclxuICAgICAgICAgICAgICBOb3RlUmF3OiBkZXRhaWxzPy5ub3RlIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgYXR0ZW5kYW5jZUlkOiBkZXRhaWxzPy5faWQsXHJcbiAgICAgICAgICAgICAgQXBwcm92ZWQ6IGlzQXBwcm92ZWQsXHJcbiAgICAgICAgICAgICAgSW5pdGlhbEFwcHJvdmVkOiBpc0FwcHJvdmVkLFxyXG5cclxuICAgICAgICAgICAgICBJbml0aWFsU3RhdHVzOlxyXG4gICAgICAgICAgICAgICAgbm9ybWFsaXplZFN0YXR1cyA9PT0gXCItXCIgPyBcIkFic2VudFwiIDogbm9ybWFsaXplZFN0YXR1cyxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pIHx8IFtdO1xyXG5cclxuICAgICAgc2V0VGFibGVBdHRlbmRhbmNlRGF0YShmb3JtYXR0ZWREYXRhKTtcclxuXHJcbiAgICAgIGNvbnN0IGFjdGl2ZU1hcCA9IHt9O1xyXG4gICAgICBmb3JtYXR0ZWREYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICBhY3RpdmVNYXBbaXRlbS5faWRdID0geyBpbmZvOiB7IHN0YXR1czogaXRlbS5BcHByb3ZlZCB9IH07XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBY3RpdmVVc2VyRGF0YShhY3RpdmVNYXApO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBsb2FkIGF0dGVuZGFuY2UgZGF0YVwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRTY3JlZW5Mb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hBdHRlbmRhbmNlUmVwb3J0KHNlbGVjdGVkRGF0ZSk7XHJcbiAgfSwgW3NlbGVjdGVkRGF0ZV0pO1xyXG5cclxuICAvLyBUb2dnbGUgZW1wbG95ZWUgc3RhdHVzIChub3cgc3VwcG9ydHMgdGhyZWUtc3RhdGUgY3ljbGUgT1IgZGlyZWN0IG5leHRTdGF0dXMpXHJcbiAgY29uc3QgaGFuZGxlU3RhdHVzVG9nZ2xlID0gKGlkLCBuZXh0U3RhdHVzKSA9PiB7XHJcbiAgICBzZXRUYWJsZUF0dGVuZGFuY2VEYXRhKChwcmV2RGF0YSkgPT5cclxuICAgICAgcHJldkRhdGEubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgaWYgKGl0ZW0uX2lkICE9PSBpZCkgcmV0dXJuIGl0ZW07XHJcblxyXG4gICAgICAgIC8vIElmIGEgbmV4dFN0YXR1cyB3YXMgZXhwbGljaXRseSBwcm92aWRlZCwgdXNlIGl0XHJcbiAgICAgICAgaWYgKG5leHRTdGF0dXMpIHtcclxuICAgICAgICAgIHJldHVybiB7IC4uLml0ZW0sIFN0YXR1czogY2FwaXRhbGl6ZVN0YXR1cyhuZXh0U3RhdHVzKSB9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gT3RoZXJ3aXNlIGN5Y2xlOiBQcmVzZW50IC0+IEFic2VudCAtPiBIYWxmZGF5IC0+IE9uIExlYXZlIC0+IFByZXNlbnRcclxuICAgICAgICBjb25zdCBjdXJyZW50ID0gKGl0ZW0uU3RhdHVzIHx8IFwiQWJzZW50XCIpLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICBsZXQgbmV4dCA9IFwiUHJlc2VudFwiO1xyXG4gICAgICAgIGlmIChjdXJyZW50ID09PSBcInByZXNlbnRcIikgbmV4dCA9IFwiQWJzZW50XCI7XHJcbiAgICAgICAgZWxzZSBpZiAoY3VycmVudCA9PT0gXCJhYnNlbnRcIikgbmV4dCA9IFwiSGFsZiBEYXlcIjtcclxuICAgICAgICBlbHNlIGlmIChjdXJyZW50ID09PSBcImhhbGYgZGF5XCIpXHJcbiAgICAgICAgICBuZXh0ID0gXCJPbiBMZWF2ZVwiOyAvLyBGaXhlZDogQ2hhbmdlZCBcIkhhbGYgRGF5XCIgdG8gXCJoYWxmIGRheVwiXHJcbiAgICAgICAgZWxzZSBpZiAoY3VycmVudCA9PT0gXCJvbiBsZWF2ZVwiKVxyXG4gICAgICAgICAgbmV4dCA9IFwiUHJlc2VudFwiOyAvLyBGaXhlZDogQ2hhbmdlZCBcIk9uIExlYXZlXCIgdG8gXCJvbiBsZWF2ZVwiXHJcbiAgICAgICAgZWxzZSBuZXh0ID0gXCJQcmVzZW50XCI7XHJcblxyXG4gICAgICAgIHJldHVybiB7IC4uLml0ZW0sIFN0YXR1czogY2FwaXRhbGl6ZVN0YXR1cyhuZXh0KSB9O1xyXG4gICAgICB9KSxcclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FwaXRhbGl6ZVN0YXR1cyA9IChzKSA9PiB7XHJcbiAgICBpZiAoIXMpIHJldHVybiBzO1xyXG4gICAgY29uc3Qgc3RyID0gcy50b1N0cmluZygpO1xyXG4gICAgaWYgKHN0ci50b0xvd2VyQ2FzZSgpID09PSBcImhhbGYgZGF5XCIgfHwgc3RyLnRvTG93ZXJDYXNlKCkgPT09IFwiaGFsZlwiKSB7XHJcbiAgICAgIHJldHVybiBcIkhhbGYgRGF5XCI7XHJcbiAgICB9XHJcbiAgICAvLyBBZGRlZCBzcGVjaWZpYyBoYW5kbGluZyBmb3IgXCJPbiBMZWF2ZVwiXHJcbiAgICBpZiAoc3RyLnRvTG93ZXJDYXNlKCkgPT09IFwib24gbGVhdmVcIiB8fCBzdHIudG9Mb3dlckNhc2UoKSA9PT0gXCJsZWF2ZVwiKSB7XHJcbiAgICAgIHJldHVybiBcIk9uIExlYXZlXCI7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gc3RyLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc3RyLnNsaWNlKDEpLnRvTG93ZXJDYXNlKCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hlY2tib3hDaGFuZ2UgPSAoaWQsIGNoZWNrZWQpID0+IHtcclxuICAgIC8vIE9ubHkgYWxsb3cgY2hhbmdlcyBpZiB0aGUgcmVjb3JkIHdhcyBub3QgcHJldmlvdXNseSBhcHByb3ZlZCBmcm9tIHRoZSBiYWNrZW5kXHJcbiAgICBjb25zdCByZWNvcmQgPSB0YWJsZUF0dGVuZGFuY2VEYXRhLmZpbmQoKGl0ZW0pID0+IGl0ZW0uX2lkID09PSBpZCk7XHJcbiAgICBpZiAocmVjb3JkICYmIHJlY29yZC5Jbml0aWFsQXBwcm92ZWQpIHtcclxuICAgICAgLy8gUHJldmVudCBsb2NhbCBzdGF0ZSBjaGFuZ2UgaWYgaXQgd2FzIGFscmVhZHkgYXBwcm92ZWQgaW4gdGhlIGRhdGFiYXNlXHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiQ2Fubm90IHVuYXBwcm92ZSBhIHByZXZpb3VzbHkgYXBwcm92ZWQgcmVjb3JkLlwiLFxyXG4gICAgICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbaWRdOiB7IGluZm86IHsgc3RhdHVzOiBjaGVja2VkIH0gfSxcclxuICAgIH0pKTtcclxuXHJcbiAgICBzZXRUYWJsZUF0dGVuZGFuY2VEYXRhKChwcmV2RGF0YSkgPT5cclxuICAgICAgcHJldkRhdGEubWFwKChpdGVtKSA9PlxyXG4gICAgICAgIGl0ZW0uX2lkID09PSBpZFxyXG4gICAgICAgICAgPyB7XHJcbiAgICAgICAgICAgICAgLi4uaXRlbSxcclxuICAgICAgICAgICAgICBBcHByb3ZlZDogY2hlY2tlZCxcclxuICAgICAgICAgICAgICBBcHByb3ZhbFN0YXR1czogY2hlY2tlZCA/IFwiQXBwcm92ZWRcIiA6IFwiUGVuZGluZ1wiLFxyXG4gICAgICAgICAgICAgIEFwcHJvdmFsU3RhdHVzUmF3OiBjaGVja2VkID8gXCJBcHByb3ZlZFwiIDogXCJQZW5kaW5nXCIsXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIDogaXRlbSxcclxuICAgICAgKSxcclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRBdHRlbmRhbmNlID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyT3B0aW9uKHRhYmxlQXR0ZW5kYW5jZURhdGEsIHNlYXJjaFRleHQpLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgY29uc3QgaXNQZXJtYW5lbnRseUFwcHJvdmVkID0gaXRlbS5Jbml0aWFsQXBwcm92ZWQgPT09IHRydWU7XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuXHJcbiAgICAgICAgQXBwcm92YWxTdGF0dXM6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICB7aXRlbS5BcHByb3ZhbFN0YXR1cyA9PT0gXCJBcHByb3ZlZFwiID8gKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICBBcHByb3ZlZFxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LXNlbWlib2xkIGJnLWFtYmVyLTUwIHRleHQtYW1iZXItNzAwIGJvcmRlciBib3JkZXItYW1iZXItMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2xvY2sgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICBQZW5kaW5nXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuXHJcbiAgICAgICAgLy8g8J+foiBFZGl0YWJsZSBOb3RlIChkaXNhYmxlZCBvbmNlIGFwcHJvdmVkKVxyXG4gICAgICAgIE5vdGU6IChcclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtpdGVtLk5vdGUgfHwgXCJcIn1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUGVybWFuZW50bHlBcHByb3ZlZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVOb3RlQ2hhbmdlKGl0ZW0uX2lkLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUmVhc29uXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTMgcHktMSBib3JkZXIgcm91bmRlZC1tZCB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSAke1xyXG4gICAgICAgICAgICAgIGlzUGVybWFuZW50bHlBcHByb3ZlZFxyXG4gICAgICAgICAgICAgICAgPyBcImJnLWdyYXktMTAwIHRleHQtZ3JheS01MDAgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgIDogXCJib3JkZXItZW1lcmFsZC0zMDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICksXHJcblxyXG4gICAgICAgIC8vIPCfn6IgQWN0aW9uczogZGlzYWJsZSBib3RoIGNoZWNrYm94ICYgc3RhdHVzIHRvZ2dsZSBpZiBhbHJlYWR5IGFwcHJvdmVkXHJcbiAgICAgICAgY2hlY2tCb3g6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAhaXNQZXJtYW5lbnRseUFwcHJvdmVkICYmIGhhbmRsZVN0YXR1c1RvZ2dsZShpdGVtLl9pZClcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUGVybWFuZW50bHlBcHByb3ZlZH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gdGV4dC1zbSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuICAgICAgICAgICAgICAgIGlzUGVybWFuZW50bHlBcHByb3ZlZFxyXG4gICAgICAgICAgICAgICAgICA/IFwiYmctZ3JheS0xMDAgdGV4dC1ncmF5LTQwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICA6IGl0ZW0uU3RhdHVzID09PSBcIlByZXNlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1lbWVyYWxkLTEwMCB0ZXh0LWVtZXJhbGQtNzAwIGhvdmVyOmJnLWVtZXJhbGQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICA6IGl0ZW0uU3RhdHVzID09PSBcIkhhbGYgRGF5XCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1vcmFuZ2UtMzAwIHRleHQtd2hpdGUgaG92ZXI6YnJpZ2h0bmVzcy05NVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IGl0ZW0uU3RhdHVzID09PSBcIk9uIExlYXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXBpbmstMzAwIHRleHQtd2hpdGUgaG92ZXI6YnJpZ2h0bmVzcy05NVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCBob3ZlcjpiZy1yZWQtMjAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtpdGVtLlN0YXR1cyA9PT0gXCJQcmVzZW50XCIgPyAoXHJcbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgICkgOiBpdGVtLlN0YXR1cyA9PT0gXCJIYWxmIERheVwiID8gKFxyXG4gICAgICAgICAgICAgICAgPENsb2NrIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgICkgOiBpdGVtLlN0YXR1cyA9PT0gXCJPbiBMZWF2ZVwiID8gKFxyXG4gICAgICAgICAgICAgICAgPENhbGVuZGFyIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8WENpcmNsZSBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTFcIj57aXRlbS5TdGF0dXN9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17aXRlbS5BcHByb3ZlZH1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNQZXJtYW5lbnRseUFwcHJvdmVkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hlY2tib3hDaGFuZ2UoaXRlbS5faWQsIGUudGFyZ2V0LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctNSBoLTUgcm91bmRlZCBhY2NlbnQtZW1lcmFsZC02MDAgdHJhbnNpdGlvbi1hbGwgJHtcclxuICAgICAgICAgICAgICAgIGlzUGVybWFuZW50bHlBcHByb3ZlZFxyXG4gICAgICAgICAgICAgICAgICA/IFwiY3Vyc29yLW5vdC1hbGxvd2VkIG9wYWNpdHktNDBcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiY3Vyc29yLXBvaW50ZXIgaG92ZXI6YWNjZW50LWVtZXJhbGQtNzAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICB9LCBbdGFibGVBdHRlbmRhbmNlRGF0YSwgYWN0aXZlVXNlckRhdGEsIHNlYXJjaFRleHRdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0QWxsID0gKGNoZWNrZWQpID0+IHtcclxuICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTtcclxuICAgIGNvbnN0IHVwZGF0ZWQgPSB7fTtcclxuXHJcbiAgICAvLyBPbmx5IHVwZGF0ZSBpdGVtcyB0aGF0IGFyZSBOT1QgcGVybWFuZW50bHkgYXBwcm92ZWRcclxuICAgIGZpbHRlcmVkQXR0ZW5kYW5jZS5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICAgIGlmICghaXRlbS5Jbml0aWFsQXBwcm92ZWQpIHtcclxuICAgICAgICB1cGRhdGVkW2l0ZW0uX2lkXSA9IHsgaW5mbzogeyBzdGF0dXM6IGNoZWNrZWQgfSB9O1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgLi4udXBkYXRlZCB9KSk7XHJcblxyXG4gICAgc2V0VGFibGVBdHRlbmRhbmNlRGF0YSgocHJldkRhdGEpID0+XHJcbiAgICAgIHByZXZEYXRhLm1hcCgoaXRlbSkgPT5cclxuICAgICAgICBmaWx0ZXJlZEF0dGVuZGFuY2UuZmluZCgoZikgPT4gZi5faWQgPT09IGl0ZW0uX2lkKSAmJlxyXG4gICAgICAgICFpdGVtLkluaXRpYWxBcHByb3ZlZCAvLyBDaGVjayBleGlzdGVuY2UgaW4gZmlsdGVyIGFuZCBpZiBub3QgYXBwcm92ZWRcclxuICAgICAgICAgID8ge1xyXG4gICAgICAgICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgICAgICAgQXBwcm92ZWQ6IGNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgQXBwcm92YWxTdGF0dXM6IGNoZWNrZWQgPyBcIkFwcHJvdmVkXCIgOiBcIlBlbmRpbmdcIixcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgOiBpdGVtLFxyXG4gICAgICApLFxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoaXNTdWJtaXR0aW5nKSByZXR1cm47XHJcbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBjdXJyZW50VXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpKSB8fCB7fTtcclxuICAgICAgY29uc3QgYXBwcm92ZWRCeSA9IGN1cnJlbnRVc2VyPy5faWQ7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGUgPSBmb3JtYXREYXRlRm9yQmFja2VuZChzZWxlY3RlZERhdGUgfHwgbmV3IERhdGUoKSk7XHJcblxyXG4gICAgICBjb25zdCByZWNvcmRzVG9VcGRhdGUgPSB0YWJsZUF0dGVuZGFuY2VEYXRhLmZpbHRlcihcclxuICAgICAgICAocm93KSA9PlxyXG4gICAgICAgICAgcm93LkFwcHJvdmVkICE9PSByb3cuSW5pdGlhbEFwcHJvdmVkIHx8XHJcbiAgICAgICAgICAocm93LkFwcHJvdmVkICYmIHJvdy5TdGF0dXMgIT09IHJvdy5Jbml0aWFsU3RhdHVzKSB8fFxyXG4gICAgICAgICAgKHJvdy5BcHByb3ZlZCAmJiByb3cuTm90ZSAmJiByb3cuTm90ZS50cmltKCkgIT09IFwiXCIpLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgZXhpc3RpbmdVcGRhdGVzID0gcmVjb3Jkc1RvVXBkYXRlLmZpbHRlcihcclxuICAgICAgICAocm93KSA9PiByb3cuYXR0ZW5kYW5jZUlkICYmIHJvdy5BcHByb3ZlZCxcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgbmV3QWJzZW50ZWVzID0gcmVjb3Jkc1RvVXBkYXRlLmZpbHRlcihcclxuICAgICAgICAocm93KSA9PiAhcm93LmF0dGVuZGFuY2VJZCAmJiByb3cuQXBwcm92ZWQsXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBpZiAoZXhpc3RpbmdVcGRhdGVzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjb25zdCB1cGRhdGVkRGF0YSA9IGV4aXN0aW5nVXBkYXRlcy5tYXAoKHJvdykgPT4gKHtcclxuICAgICAgICAgIGVtcGxveWVlX2lkOiByb3cuX2lkLFxyXG4gICAgICAgICAgYXR0ZW5kYW5jZV9pZDogcm93LmF0dGVuZGFuY2VJZCxcclxuICAgICAgICAgIHN0YXR1czogcm93LlN0YXR1cyxcclxuICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czogXCJBcHByb3ZlZFwiLFxyXG4gICAgICAgICAgYXBwcm92ZWRfYnk6IGFwcHJvdmVkQnksXHJcbiAgICAgICAgICBub3RlOiByb3cuTm90ZSB8fCBcIlwiLCAvLyDinIUgSW5jbHVkZSBub3RlIGluIHVwZGF0ZVxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgYXdhaXQgYXBpLnB1dChcIi9lbXBsb3llZS1hdHRlbmRhbmNlL3VwZGF0ZS1hcHByb3ZhbHNcIiwge1xyXG4gICAgICAgICAgdXBkYXRlczogdXBkYXRlZERhdGEsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChuZXdBYnNlbnRlZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL2VtcGxveWVlLWF0dGVuZGFuY2Uvc2F2ZS1zZWxlY3RlZC1hYnNlbnRcIiwge1xyXG4gICAgICAgICAgYWJzZW50ZWVzOiBuZXdBYnNlbnRlZXMubWFwKChyb3cpID0+ICh7XHJcbiAgICAgICAgICAgIGVtcGxveWVlX2lkOiByb3cuX2lkLFxyXG4gICAgICAgICAgICBzdGF0dXM6IHJvdy5TdGF0dXMsXHJcbiAgICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czogXCJBcHByb3ZlZFwiLFxyXG4gICAgICAgICAgICBhcHByb3ZlZF9ieTogYXBwcm92ZWRCeSxcclxuICAgICAgICAgICAgZGF0ZTogZm9ybWF0dGVkRGF0ZSxcclxuICAgICAgICAgICAgbm90ZTogcm93Lk5vdGUgfHwgXCJcIiwgLy8g4pyFIEluY2x1ZGUgbm90ZSBpbiBjcmVhdGVcclxuICAgICAgICAgIH0pKSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgYXdhaXQgZmV0Y2hBdHRlbmRhbmNlUmVwb3J0KHNlbGVjdGVkRGF0ZSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiQXR0ZW5kYW5jZSB1cGRhdGVzIHN1Ym1pdHRlZCBzdWNjZXNzZnVsbHkuXCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKHNlbGVjdGVkRGF0ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igd2hpbGUgc3VibWl0dGluZyBhdHRlbmRhbmNlOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRXJyb3IgdXBkYXRpbmcgc2VsZWN0ZWQgZW1wbG95ZWVzIVwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IEF0dGVuZGFuY2VDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNsIE5vXCIgfSxcclxuICAgIHsga2V5OiBcIkVtcGxveWVlSWRcIiwgaGVhZGVyOiBcIkVtcGxveWVlIElkXCIgfSxcclxuICAgIHsga2V5OiBcIkVtcGxveWVlTmFtZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJTdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJBcHByb3ZhbFN0YXR1c1wiLCBoZWFkZXI6IFwiQXBwcm92YWwgU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcIkRhdGVcIiwgaGVhZGVyOiBcIkRhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiVGltZVwiLCBoZWFkZXI6IFwiVGltZVwiIH0sXHJcbiAgICB7IGtleTogXCJPdXRUaW1lXCIsIGhlYWRlcjogXCJPdXQtVGltZVwiIH0sXHJcbiAgICB7IGtleTogXCJXb3JraW5nSG91cnNcIiwgaGVhZGVyOiBcIldvcmtpbmcgSG91cnNcIiB9LFxyXG4gICAgeyBrZXk6IFwiTm90ZVwiLCBoZWFkZXI6IFwiUmVhc29uXCIgfSxcclxuICAgIHsga2V5OiBcImNoZWNrQm94XCIsIGhlYWRlcjogXCJBY3Rpb25zXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBQREZBdHRlbmRhbmNlQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJFbXBsb3llZUlkXCIsIGhlYWRlcjogXCJFbXBsb3llZSBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJFbXBsb3llZU5hbWVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiU3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiQXBwcm92YWxTdGF0dXNSYXdcIiwgaGVhZGVyOiBcIkFwcHJvdmFsIFN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJEYXRlXCIsIGhlYWRlcjogXCJEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcIlRpbWVcIiwgaGVhZGVyOiBcIlRpbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiT3V0VGltZVwiLCBoZWFkZXI6IFwiT3V0LVRpbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiV29ya2luZ0hvdXJzXCIsIGhlYWRlcjogXCJXb3JraW5nIEhvdXJzXCIgfSxcclxuICAgIHsga2V5OiBcIk5vdGVSYXdcIiwgaGVhZGVyOiBcIlJlYXNvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1zY3JlZW4gaC1zY3JlZW4gYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS01MCB0by1zbGF0ZS0xMDAgb3ZlcmZsb3cteC1oaWRkZW4gb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBcIj5cclxuICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9eyhlKSA9PiBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTggbXQtMjBcIj5cclxuICAgICAgICAgIHsvKiBIZWFkZXIgU2VjdGlvbiAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICA8QnJlYWRjcnVtYi8+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgIEVtcGxveWVlIEF0dGVuZGFuY2VcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICBNYW5hZ2UgYW5kIGFwcHJvdmUgZW1wbG95ZWUgYXR0ZW5kYW5jZSByZWNvcmRzXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBDb250cm9scyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC02IG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGxnOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBsZzppdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICB7LyogTGVmdCBDb250cm9scyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGdhcC02IHctZnVsbCBsZzp3LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgIHsvKiBEYXRlIFBpY2tlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0IERhdGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBiZy1zbGF0ZS01MCBweC00IHB5LTMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBmb2N1cy13aXRoaW46Ym9yZGVyLWVtZXJhbGQtNTAwIGZvY3VzLXdpdGhpbjpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhciBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZERhdGUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbWF4PXtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdHJhbnNwYXJlbnQgYm9yZGVyLW5vbmUgb3V0bGluZS1ub25lIHRleHQtc2xhdGUtNzAwIGZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBTZWxlY3QgQWxsICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwdC0yIHNtOnB0LTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInNlbGVjdEFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0QWxsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VsZWN0QWxsKGUudGFyZ2V0LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZCBhY2NlbnQtZW1lcmFsZC02MDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic2VsZWN0QWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBBbGxcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7c2NyZWVuTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtZW1lcmFsZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgbG9hZGluZz17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNjAwIHRvLWVtZXJhbGQtNzAwIGhvdmVyOmZyb20tZW1lcmFsZC03MDAgaG92ZXI6dG8tZW1lcmFsZC04MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHB4LTggcHktNiByb3VuZGVkLWxnIGJvcmRlci0wIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCJVcGRhdGluZy4uLlwiIDogXCJTdWJtaXQgQXR0ZW5kYW5jZVwifVxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTUgZ2FwLTYgbWItOFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgVG90YWwgRW1wbG95ZWVzXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+XHJcbiAgICAgICAgICAgICAgICB7c3VtbWFyeVN0YXRzLnRvdGFsfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1ncmVlbi01MCByb3VuZGVkLWxnIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCBibG9ja1wiPlByZXNlbnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzdW1tYXJ5U3RhdHMucHJlc2VudH1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctcmVkLTUwIHJvdW5kZWQtbGcgc2hhZG93LW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIGJsb2NrXCI+QWJzZW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtcmVkLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAge3N1bW1hcnlTdGF0cy5hYnNlbnR9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLWJsdWUtNTAgcm91bmRlZC1sZyBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5IYWxmIERheTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICB7c3VtbWFyeVN0YXRzLmhhbGZkYXl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXB1cnBsZS01MCByb3VuZGVkLWxnIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCBibG9ja1wiPk9uIExlYXZlPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAge3N1bW1hcnlTdGF0cy5vbmxlYXZlfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1lbWVyYWxkLTUwIHJvdW5kZWQtbGcgc2hhZG93LW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIGJsb2NrXCI+QXBwcm92ZWQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAge3N1bW1hcnlTdGF0cy5hcHByb3ZlZH1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctYW1iZXItNTAgcm91bmRlZC1sZyBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5QZW5kaW5nPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtYW1iZXItNzAwXCI+XHJcbiAgICAgICAgICAgICAgICB7c3VtbWFyeVN0YXRzLnBlbmRpbmd9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge3N1bW1hcnlTdGF0cy5wZW5kaW5nRW1wbG95ZWVOYW1lcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJnLXdoaXRlIGJvcmRlciBib3JkZXItYW1iZXItMjAwIHJvdW5kZWQteGwgcC00IHNoYWRvdy1zbSBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWFtYmVyLTcwMCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICBQZW5kaW5nIEFwcHJvdmFsIEVtcGxveWVlc1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIHtzdW1tYXJ5U3RhdHMucGVuZGluZ0VtcGxveWVlTmFtZXMubWFwKChuYW1lLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xIGJnLWFtYmVyLTEwMCB0ZXh0LWFtYmVyLTgwMCByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7bmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogVGFibGUgU2VjdGlvbiAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXNtIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIG92ZXJmbG93LWhpZGRlbiBwLTQgbWluLWgtWzMwMHB4XSBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICB7c2NyZWVuTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgY29sb3I9XCJ0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtBdHRlbmRhbmNlQ29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydENvbHM9e1BERkF0dGVuZGFuY2VDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRBdHRlbmRhbmNlfVxyXG4gICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgRW1wbG95ZWVzXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgUHJlc2VudFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIEFic2VudFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIEhhbGYgRGF5XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgT24gTGVhdmVcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBBcHByb3ZlZFwiLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgIGAke3N1bW1hcnlTdGF0cy50b3RhbH1gLFxyXG4gICAgICAgICAgICAgICAgICBgJHtzdW1tYXJ5U3RhdHMucHJlc2VudH1gLFxyXG4gICAgICAgICAgICAgICAgICBgJHtzdW1tYXJ5U3RhdHMuYWJzZW50fWAsXHJcbiAgICAgICAgICAgICAgICAgIGAke3N1bW1hcnlTdGF0cy5oYWxmZGF5fWAsXHJcbiAgICAgICAgICAgICAgICAgIGAke3N1bW1hcnlTdGF0cy5vbmxlYXZlfWAsXHJcbiAgICAgICAgICAgICAgICAgIGAke3N1bW1hcnlTdGF0cy5hcHByb3ZlZH1gLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkVtcGxveWVlIEF0dGVuZGVuY2VcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEVtcGxveWVlQXR0ZW5kZW5jZS5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRW1wbG95ZWVBdHRlbmRhbmNlUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRW1wbG95ZWVBdHRlbmRhbmNlUmVwb3J0LmpzeCJ9