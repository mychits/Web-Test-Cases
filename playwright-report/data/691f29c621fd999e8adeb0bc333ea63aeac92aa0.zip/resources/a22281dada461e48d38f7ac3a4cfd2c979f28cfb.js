import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChitCollectionExecutiveReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { header } from "/node_modules/.vite/deps/framer-motion_client.js?v=819e0a34";
const ChitCollectionExecutiveReport = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState("");
  const [paymentType, setPaymentType] = useState("daily");
  const [tableData, setTableData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState({
    chit: 0,
    loan: 0,
    pigmy: 0,
    overall: 0
  });
  const fetchEmployees = async () => {
    try {
      const res = await api.get("/agent/get-employee");
      if (res?.data?.employee) {
        setEmployees(res.data?.employee);
      }
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  const fetchReport = async () => {
    if (!selectedEmployee) return;
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.append("paymentTypes", paymentType);
      params.append(
        "paymentTypes",
        paymentType.charAt(0).toUpperCase() + paymentType.slice(1)
      );
      const res = await api.get(
        `/v1/admin/collection-executive/employees/${selectedEmployee}?${params.toString()}`
      );
      if (res?.data?.data) {
        let finalRows = [];
        let chitTotal = 0;
        let loanTotal = 0;
        let pigmyTotal = 0;
        let serial = 1;
        res.data.data.forEach((customer) => {
          customer.enrollments?.forEach((item) => {
            const amount = Number(item?.group_id?.installment || 0);
            chitTotal += amount;
            finalRows.push({
              _id: `${customer._id}-EN-${serial}`,
              sl_no: serial++,
              full_name: customer.full_name,
              phone_number: customer.phone_number,
              group_name: item?.group_id?.group_name || "-",
              group_value: item?.group_id?.group_value || "-",
              tickets: item?.tickets || "-",
              enrollment_amount: `₹${amount}`,
              loan_amount: "₹0",
              pigmy_amount: "₹0",
              total: `₹${amount}`
            });
          });
          customer.loans?.forEach((item) => {
            const amount = Number(item?.daily_payment_amount || 0);
            loanTotal += amount;
            finalRows.push({
              _id: `${customer._id}-LN-${serial}`,
              sl_no: serial++,
              full_name: customer.full_name,
              phone_number: customer.phone_number,
              group_name: item?.loan_id || "-",
              group_value: "-",
              tickets: "-",
              enrollment_amount: "₹0",
              loan_amount: `₹${amount}`,
              pigmy_amount: "₹0",
              total: `₹${amount}`
            });
          });
          customer.pigmys?.forEach((item) => {
            const amount = Number(item?.payable_amount || 0);
            pigmyTotal += amount;
            finalRows.push({
              _id: `${customer._id}-PG-${serial}`,
              sl_no: serial++,
              full_name: customer.full_name,
              phone_number: customer.phone_number,
              group_name: item?.pigme_id || "-",
              group_value: "-",
              tickets: "-",
              enrollment_amount: "₹0",
              loan_amount: "₹0",
              pigmy_amount: `₹${amount}`,
              total: `₹${amount}`
            });
          });
        });
        setTableData(finalRows);
        setSummary({
          chit: chitTotal,
          loan: loanTotal,
          pigmy: pigmyTotal,
          overall: chitTotal + loanTotal + pigmyTotal
        });
      }
    } catch (error) {
      console.log(error);
      setTableData([]);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchReport();
  }, [selectedEmployee, paymentType]);
  const columns = [
    { key: "sl_no", header: "SL No" },
    { key: "full_name", header: "Customer" },
    { key: "phone_number", header: "Phone" },
    { key: "group_name", header: "Group / Loan / Pigmy" },
    { key: "group_value", header: "Group Value" },
    { key: "tickets", header: "Tickets" },
    { key: "enrollment_amount", header: "Enrollment" },
    { key: "loan_amount", header: "Loan" },
    { key: "pigmy_amount", header: "Pigmy" },
    { key: "total", header: "Total" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-gray-100 min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-lg p-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-blue-700 mb-6", children: "Chit Collection Executive Summary Report" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
      lineNumber: 169,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-4 gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-4 rounded-xl shadow", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Chit Total" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 178,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-blue-700", children: [
          "₹",
          summary.chit
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 179,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
        lineNumber: 177,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-4 rounded-xl shadow", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Loan Total" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 185,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-green-700", children: [
          "₹",
          summary.loan
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 186,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
        lineNumber: 184,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-100 p-4 rounded-xl shadow", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Pigmy Total" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 192,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-yellow-700", children: [
          "₹",
          summary.pigmy
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 193,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
        lineNumber: 191,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-100 p-4 rounded-xl shadow", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Overall Total" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 199,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-purple-700", children: [
          "₹",
          summary.overall
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 200,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
        lineNumber: 198,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
      lineNumber: 176,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
      lineNumber: 172,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-2 gap-5 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold mb-2", children: "Select Employee" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 211,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full",
            size: "large",
            showSearch: true,
            placeholder: "Select Employee",
            value: selectedEmployee || void 0,
            onChange: (value) => setSelectedEmployee(value),
            optionFilterProp: "label",
            options: employees.map((item) => ({
              value: item._id,
              label: `${item.name} | ${item.phone_number}`
            }))
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
            lineNumber: 215,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
        lineNumber: 210,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold mb-2", children: "Payment Type" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
          lineNumber: 231,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: paymentType,
            onChange: (e) => setPaymentType(e.target.value.toLowerCase()),
            className: "w-full border rounded-lg px-4 py-2 h-10",
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "daily", children: "Daily" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
                lineNumber: 240,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "weekly", children: "Weekly" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
                lineNumber: 241,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "monthly", children: "Monthly" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
                lineNumber: 242,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
            lineNumber: 235,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
        lineNumber: 230,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
      lineNumber: 208,
      columnNumber: 9
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-blue-700 font-bold", children: "Loading..." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
      lineNumber: 249,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        catcher: "_id",
        data: tableData,
        columns,
        exportedPdfName: "CollectionExecutiveReport",
        exportedFileName: "CollectionExecutiveReport.csv"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
        lineNumber: 253,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
    lineNumber: 168,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx",
    lineNumber: 167,
    columnNumber: 5
  }, this);
};
_s(ChitCollectionExecutiveReport, "RxQkeHlFBfhuBlEqfCxmgUR5hVE=");
_c = ChitCollectionExecutiveReport;
export default ChitCollectionExecutiveReport;
var _c;
$RefreshReg$(_c, "ChitCollectionExecutiveReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionExecutiveReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0tROzJCQXhLUjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGNBQWM7QUFFdkIsTUFBTUMsZ0NBQWdDQSxNQUFNO0FBQUFDLEtBQUE7QUFDMUMsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlSLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNTLGtCQUFrQkMsbUJBQW1CLElBQUlWLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUNXLGFBQWFDLGNBQWMsSUFBSVosU0FBUyxPQUFPO0FBQ3RELFFBQU0sQ0FBQ2EsV0FBV0MsWUFBWSxJQUFJZCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDZSxTQUFTQyxVQUFVLElBQUloQixTQUFTLEtBQUs7QUFHNUMsUUFBTSxDQUFDaUIsU0FBU0MsVUFBVSxJQUFJbEIsU0FBUztBQUFBLElBQ3JDbUIsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUdELFFBQU1DLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRixZQUFNQyxNQUFNLE1BQU12QixJQUFJd0IsSUFBSSxxQkFBcUI7QUFFL0MsVUFBSUQsS0FBS0UsTUFBTUMsVUFBVTtBQUN2Qm5CLHFCQUFhZ0IsSUFBSUUsTUFBTUMsUUFBUTtBQUFBLE1BQ2pDO0FBQUEsSUFDRixTQUFTQyxPQUFPO0FBQ2RDLGNBQVFDLElBQUlGLEtBQUs7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFRTdCLFlBQVUsTUFBTTtBQUNoQndCLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBRUwsUUFBTVEsY0FBYyxZQUFZO0FBQy9CLFFBQUksQ0FBQ3RCLGlCQUFrQjtBQUV0QixRQUFJO0FBQ0ZPLGlCQUFXLElBQUk7QUFFZixZQUFNZ0IsU0FBUyxJQUFJQyxnQkFBZ0I7QUFFbkNELGFBQU9FLE9BQU8sZ0JBQWdCdkIsV0FBVztBQUN6Q3FCLGFBQU9FO0FBQUFBLFFBQ0w7QUFBQSxRQUNBdkIsWUFBWXdCLE9BQU8sQ0FBQyxFQUFFQyxZQUFZLElBQUl6QixZQUFZMEIsTUFBTSxDQUFDO0FBQUEsTUFDM0Q7QUFFQSxZQUFNYixNQUFNLE1BQU12QixJQUFJd0I7QUFBQUEsUUFDcEIsNENBQTRDaEIsZ0JBQWdCLElBQUl1QixPQUFPTSxTQUFTLENBQUM7QUFBQSxNQUNuRjtBQUVBLFVBQUlkLEtBQUtFLE1BQU1BLE1BQU07QUFDbkIsWUFBSWEsWUFBWTtBQUVoQixZQUFJQyxZQUFZO0FBQ2hCLFlBQUlDLFlBQVk7QUFDaEIsWUFBSUMsYUFBYTtBQUVqQixZQUFJQyxTQUFTO0FBRWJuQixZQUFJRSxLQUFLQSxLQUFLa0IsUUFBUSxDQUFDQyxhQUFhO0FBRWxDQSxtQkFBU0MsYUFBYUYsUUFBUSxDQUFDRyxTQUFTO0FBQ3RDLGtCQUFNQyxTQUFTQyxPQUFPRixNQUFNRyxVQUFVQyxlQUFlLENBQUM7QUFFdERYLHlCQUFhUTtBQUViVCxzQkFBVWEsS0FBSztBQUFBLGNBQ2JDLEtBQUssR0FBR1IsU0FBU1EsR0FBRyxPQUFPVixNQUFNO0FBQUEsY0FDakNXLE9BQU9YO0FBQUFBLGNBQ1BZLFdBQVdWLFNBQVNVO0FBQUFBLGNBQ3BCQyxjQUFjWCxTQUFTVztBQUFBQSxjQUN2QkMsWUFBWVYsTUFBTUcsVUFBVU8sY0FBYztBQUFBLGNBQzFDQyxhQUFhWCxNQUFNRyxVQUFVUSxlQUFlO0FBQUEsY0FDNUNDLFNBQVNaLE1BQU1ZLFdBQVc7QUFBQSxjQUMxQkMsbUJBQW1CLElBQUlaLE1BQU07QUFBQSxjQUM3QmEsYUFBYTtBQUFBLGNBQ2JDLGNBQWM7QUFBQSxjQUNkQyxPQUFPLElBQUlmLE1BQU07QUFBQSxZQUNuQixDQUFDO0FBQUEsVUFDSCxDQUFDO0FBR0RILG1CQUFTbUIsT0FBT3BCLFFBQVEsQ0FBQ0csU0FBUztBQUNoQyxrQkFBTUMsU0FBU0MsT0FBT0YsTUFBTWtCLHdCQUF3QixDQUFDO0FBRXJEeEIseUJBQWFPO0FBRWJULHNCQUFVYSxLQUFLO0FBQUEsY0FDYkMsS0FBSyxHQUFHUixTQUFTUSxHQUFHLE9BQU9WLE1BQU07QUFBQSxjQUNqQ1csT0FBT1g7QUFBQUEsY0FDUFksV0FBV1YsU0FBU1U7QUFBQUEsY0FDcEJDLGNBQWNYLFNBQVNXO0FBQUFBLGNBQ3ZCQyxZQUFZVixNQUFNbUIsV0FBVztBQUFBLGNBQzdCUixhQUFhO0FBQUEsY0FDYkMsU0FBUztBQUFBLGNBQ1RDLG1CQUFtQjtBQUFBLGNBQ25CQyxhQUFhLElBQUliLE1BQU07QUFBQSxjQUN2QmMsY0FBYztBQUFBLGNBQ2RDLE9BQU8sSUFBSWYsTUFBTTtBQUFBLFlBQ25CLENBQUM7QUFBQSxVQUNILENBQUM7QUFHREgsbUJBQVNzQixRQUFRdkIsUUFBUSxDQUFDRyxTQUFTO0FBQ2pDLGtCQUFNQyxTQUFTQyxPQUFPRixNQUFNcUIsa0JBQWtCLENBQUM7QUFFL0MxQiwwQkFBY007QUFFZFQsc0JBQVVhLEtBQUs7QUFBQSxjQUNiQyxLQUFLLEdBQUdSLFNBQVNRLEdBQUcsT0FBT1YsTUFBTTtBQUFBLGNBQ2pDVyxPQUFPWDtBQUFBQSxjQUNQWSxXQUFXVixTQUFTVTtBQUFBQSxjQUNwQkMsY0FBY1gsU0FBU1c7QUFBQUEsY0FDdkJDLFlBQVlWLE1BQU1zQixZQUFZO0FBQUEsY0FDOUJYLGFBQWE7QUFBQSxjQUNiQyxTQUFTO0FBQUEsY0FDVEMsbUJBQW1CO0FBQUEsY0FDbkJDLGFBQWE7QUFBQSxjQUNiQyxjQUFjLElBQUlkLE1BQU07QUFBQSxjQUN4QmUsT0FBTyxJQUFJZixNQUFNO0FBQUEsWUFDbkIsQ0FBQztBQUFBLFVBQ0gsQ0FBQztBQUFBLFFBQ0gsQ0FBQztBQUVEbEMscUJBQWF5QixTQUFTO0FBRXRCckIsbUJBQVc7QUFBQSxVQUNUQyxNQUFNcUI7QUFBQUEsVUFDTnBCLE1BQU1xQjtBQUFBQSxVQUNOcEIsT0FBT3FCO0FBQUFBLFVBQ1BwQixTQUFTa0IsWUFBWUMsWUFBWUM7QUFBQUEsUUFDbkMsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNkLE9BQU87QUFDZEMsY0FBUUMsSUFBSUYsS0FBSztBQUNqQmQsbUJBQWEsRUFBRTtBQUFBLElBQ2pCLFVBQUM7QUFDQ0UsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBakIsWUFBVSxNQUFNO0FBQ2ZnQyxnQkFBWTtBQUFBLEVBQ2YsR0FBRyxDQUFDdEIsa0JBQWtCRSxXQUFXLENBQUM7QUFHOUIsUUFBTTJELFVBQVU7QUFBQSxJQUNoQixFQUFFQyxLQUFLLFNBQVNuRSxRQUFRLFFBQVE7QUFBQSxJQUNoQyxFQUFFbUUsS0FBSyxhQUFhbkUsUUFBUSxXQUFXO0FBQUEsSUFDdkMsRUFBRW1FLEtBQUssZ0JBQWdCbkUsUUFBUSxRQUFRO0FBQUEsSUFDdkMsRUFBRW1FLEtBQUssY0FBY25FLFFBQVEsdUJBQXVCO0FBQUEsSUFDcEQsRUFBRW1FLEtBQUssZUFBZW5FLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVtRSxLQUFLLFdBQVduRSxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFbUUsS0FBSyxxQkFBcUJuRSxRQUFRLGFBQWE7QUFBQSxJQUNqRCxFQUFFbUUsS0FBSyxlQUFlbkUsUUFBUSxPQUFPO0FBQUEsSUFDckMsRUFBRW1FLEtBQUssZ0JBQWdCbkUsUUFBUSxRQUFRO0FBQUEsSUFDdkMsRUFBRW1FLEtBQUssU0FBU25FLFFBQVEsUUFBUTtBQUFBLEVBQUM7QUFHbkMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLHlDQUF3Qyx3REFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsT0FJYixpQ0FBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUseUJBQXdCLDBCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsUUFDL0MsdUJBQUMsUUFBRyxXQUFVLG9DQUFtQztBQUFBO0FBQUEsVUFDN0NhLFFBQVFFO0FBQUFBLGFBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSx5QkFBd0IsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxRQUMvQyx1QkFBQyxRQUFHLFdBQVUscUNBQW9DO0FBQUE7QUFBQSxVQUM5Q0YsUUFBUUc7QUFBQUEsYUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLHlCQUF3QiwyQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFFBQ2hELHVCQUFDLFFBQUcsV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLFVBQy9DSCxRQUFRSTtBQUFBQSxhQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUseUJBQXdCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQsdUJBQUMsUUFBRyxXQUFVLHNDQUFxQztBQUFBO0FBQUEsVUFDL0NKLFFBQVFLO0FBQUFBLGFBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBLEtBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQ0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxrQ0FFYjtBQUFBLDZCQUFDLFNBQ0M7QUFBQSwrQkFBQyxXQUFNLFdBQVUsb0NBQW1DLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixNQUFLO0FBQUEsWUFDTDtBQUFBLFlBQ0EsYUFBWTtBQUFBLFlBQ1osT0FBT2Isb0JBQW9CK0Q7QUFBQUEsWUFDM0IsVUFBVSxDQUFDQyxVQUFVL0Qsb0JBQW9CK0QsS0FBSztBQUFBLFlBQzlDLGtCQUFpQjtBQUFBLFlBQ2pCLFNBQVNsRSxVQUFVbUUsSUFBSSxDQUFDM0IsVUFBVTtBQUFBLGNBQ2hDMEIsT0FBTzFCLEtBQUtNO0FBQUFBLGNBQ1pzQixPQUFPLEdBQUc1QixLQUFLNkIsSUFBSSxNQUFNN0IsS0FBS1MsWUFBWTtBQUFBLFlBQzVDLEVBQUU7QUFBQTtBQUFBLFVBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV007QUFBQSxXQWhCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFFQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsV0FBTSxXQUFVLG9DQUFtQyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTzdDO0FBQUFBLFlBQ1AsVUFBVSxDQUFDa0UsTUFBTWpFLGVBQWVpRSxFQUFFQyxPQUFPTCxNQUFNTSxZQUFZLENBQUM7QUFBQSxZQUM1RCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFlBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGNBQzNCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGNBQzdCLHVCQUFDLFlBQU8sT0FBTSxXQUFVLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBO0FBQUE7QUFBQSxVQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsU0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFDQTtBQUFBLElBR0NoRSxVQUNDLHVCQUFDLFNBQUksV0FBVSw2Q0FBNEMsMEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixNQUFNRjtBQUFBQSxRQUNOO0FBQUEsUUFDQSxpQkFBZ0I7QUFBQSxRQUNoQixrQkFBaUI7QUFBQTtBQUFBLE1BTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtrRDtBQUFBLE9BMUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkZBLEtBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErRkE7QUFFSjtBQUFFUCxHQWpRSUQsK0JBQTZCO0FBQUEyRSxLQUE3QjNFO0FBbVFOLGVBQWVBO0FBQThCLElBQUEyRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJhcGkiLCJEYXRhVGFibGUiLCJTZWxlY3QiLCJoZWFkZXIiLCJDaGl0Q29sbGVjdGlvbkV4ZWN1dGl2ZVJlcG9ydCIsIl9zIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwic2VsZWN0ZWRFbXBsb3llZSIsInNldFNlbGVjdGVkRW1wbG95ZWUiLCJwYXltZW50VHlwZSIsInNldFBheW1lbnRUeXBlIiwidGFibGVEYXRhIiwic2V0VGFibGVEYXRhIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzdW1tYXJ5Iiwic2V0U3VtbWFyeSIsImNoaXQiLCJsb2FuIiwicGlnbXkiLCJvdmVyYWxsIiwiZmV0Y2hFbXBsb3llZXMiLCJyZXMiLCJnZXQiLCJkYXRhIiwiZW1wbG95ZWUiLCJlcnJvciIsImNvbnNvbGUiLCJsb2ciLCJmZXRjaFJlcG9ydCIsInBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsImFwcGVuZCIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJ0b1N0cmluZyIsImZpbmFsUm93cyIsImNoaXRUb3RhbCIsImxvYW5Ub3RhbCIsInBpZ215VG90YWwiLCJzZXJpYWwiLCJmb3JFYWNoIiwiY3VzdG9tZXIiLCJlbnJvbGxtZW50cyIsIml0ZW0iLCJhbW91bnQiLCJOdW1iZXIiLCJncm91cF9pZCIsImluc3RhbGxtZW50IiwicHVzaCIsIl9pZCIsInNsX25vIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBfbmFtZSIsImdyb3VwX3ZhbHVlIiwidGlja2V0cyIsImVucm9sbG1lbnRfYW1vdW50IiwibG9hbl9hbW91bnQiLCJwaWdteV9hbW91bnQiLCJ0b3RhbCIsImxvYW5zIiwiZGFpbHlfcGF5bWVudF9hbW91bnQiLCJsb2FuX2lkIiwicGlnbXlzIiwicGF5YWJsZV9hbW91bnQiLCJwaWdtZV9pZCIsImNvbHVtbnMiLCJrZXkiLCJ1bmRlZmluZWQiLCJ2YWx1ZSIsIm1hcCIsImxhYmVsIiwibmFtZSIsImUiLCJ0YXJnZXQiLCJ0b0xvd2VyQ2FzZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNoaXRDb2xsZWN0aW9uRXhlY3V0aXZlUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgaGVhZGVyIH0gZnJvbSBcImZyYW1lci1tb3Rpb24vY2xpZW50XCI7XHJcblxyXG5jb25zdCBDaGl0Q29sbGVjdGlvbkV4ZWN1dGl2ZVJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlLCBzZXRTZWxlY3RlZEVtcGxveWVlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXltZW50VHlwZSwgc2V0UGF5bWVudFR5cGVdID0gdXNlU3RhdGUoXCJkYWlseVwiKTtcclxuICBjb25zdCBbdGFibGVEYXRhLCBzZXRUYWJsZURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcblxyXG4gIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuICAgIGNoaXQ6IDAsXHJcbiAgICBsb2FuOiAwLFxyXG4gICAgcGlnbXk6IDAsXHJcbiAgICBvdmVyYWxsOiAwLFxyXG4gIH0pO1xyXG5cclxuICAvLyAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWVtcGxveWVlXCIpO1xyXG5cclxuICAgICAgaWYgKHJlcz8uZGF0YT8uZW1wbG95ZWUpIHtcclxuICAgICAgICBzZXRFbXBsb3llZXMocmVzLmRhdGE/LmVtcGxveWVlKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaFJlcG9ydCA9IGFzeW5jICgpID0+IHtcclxuICAgaWYgKCFzZWxlY3RlZEVtcGxveWVlKSByZXR1cm47XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcclxuXHJcbiAgICAgIHBhcmFtcy5hcHBlbmQoXCJwYXltZW50VHlwZXNcIiwgcGF5bWVudFR5cGUpO1xyXG4gICAgICBwYXJhbXMuYXBwZW5kKFxyXG4gICAgICAgIFwicGF5bWVudFR5cGVzXCIsXHJcbiAgICAgICAgcGF5bWVudFR5cGUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBwYXltZW50VHlwZS5zbGljZSgxKSxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC92MS9hZG1pbi9jb2xsZWN0aW9uLWV4ZWN1dGl2ZS9lbXBsb3llZXMvJHtzZWxlY3RlZEVtcGxveWVlfT8ke3BhcmFtcy50b1N0cmluZygpfWAsXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBpZiAocmVzPy5kYXRhPy5kYXRhKSB7XHJcbiAgICAgICAgbGV0IGZpbmFsUm93cyA9IFtdO1xyXG5cclxuICAgICAgICBsZXQgY2hpdFRvdGFsID0gMDtcclxuICAgICAgICBsZXQgbG9hblRvdGFsID0gMDtcclxuICAgICAgICBsZXQgcGlnbXlUb3RhbCA9IDA7XHJcblxyXG4gICAgICAgIGxldCBzZXJpYWwgPSAxO1xyXG5cclxuICAgICAgICByZXMuZGF0YS5kYXRhLmZvckVhY2goKGN1c3RvbWVyKSA9PiB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICBjdXN0b21lci5lbnJvbGxtZW50cz8uZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBhbW91bnQgPSBOdW1iZXIoaXRlbT8uZ3JvdXBfaWQ/Lmluc3RhbGxtZW50IHx8IDApO1xyXG5cclxuICAgICAgICAgICAgY2hpdFRvdGFsICs9IGFtb3VudDtcclxuXHJcbiAgICAgICAgICAgIGZpbmFsUm93cy5wdXNoKHtcclxuICAgICAgICAgICAgICBfaWQ6IGAke2N1c3RvbWVyLl9pZH0tRU4tJHtzZXJpYWx9YCxcclxuICAgICAgICAgICAgICBzbF9ubzogc2VyaWFsKyssXHJcbiAgICAgICAgICAgICAgZnVsbF9uYW1lOiBjdXN0b21lci5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBjdXN0b21lci5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogaXRlbT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfdmFsdWU6IGl0ZW0/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICB0aWNrZXRzOiBpdGVtPy50aWNrZXRzIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgIGVucm9sbG1lbnRfYW1vdW50OiBg4oK5JHthbW91bnR9YCxcclxuICAgICAgICAgICAgICBsb2FuX2Ftb3VudDogXCLigrkwXCIsXHJcbiAgICAgICAgICAgICAgcGlnbXlfYW1vdW50OiBcIuKCuTBcIixcclxuICAgICAgICAgICAgICB0b3RhbDogYOKCuSR7YW1vdW50fWAsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgICAgY3VzdG9tZXIubG9hbnM/LmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgY29uc3QgYW1vdW50ID0gTnVtYmVyKGl0ZW0/LmRhaWx5X3BheW1lbnRfYW1vdW50IHx8IDApO1xyXG5cclxuICAgICAgICAgICAgbG9hblRvdGFsICs9IGFtb3VudDtcclxuXHJcbiAgICAgICAgICAgIGZpbmFsUm93cy5wdXNoKHtcclxuICAgICAgICAgICAgICBfaWQ6IGAke2N1c3RvbWVyLl9pZH0tTE4tJHtzZXJpYWx9YCxcclxuICAgICAgICAgICAgICBzbF9ubzogc2VyaWFsKyssXHJcbiAgICAgICAgICAgICAgZnVsbF9uYW1lOiBjdXN0b21lci5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBjdXN0b21lci5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogaXRlbT8ubG9hbl9pZCB8fCBcIi1cIixcclxuICAgICAgICAgICAgICBncm91cF92YWx1ZTogXCItXCIsXHJcbiAgICAgICAgICAgICAgdGlja2V0czogXCItXCIsXHJcbiAgICAgICAgICAgICAgZW5yb2xsbWVudF9hbW91bnQ6IFwi4oK5MFwiLFxyXG4gICAgICAgICAgICAgIGxvYW5fYW1vdW50OiBg4oK5JHthbW91bnR9YCxcclxuICAgICAgICAgICAgICBwaWdteV9hbW91bnQ6IFwi4oK5MFwiLFxyXG4gICAgICAgICAgICAgIHRvdGFsOiBg4oK5JHthbW91bnR9YCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICBcclxuICAgICAgICAgIGN1c3RvbWVyLnBpZ215cz8uZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBhbW91bnQgPSBOdW1iZXIoaXRlbT8ucGF5YWJsZV9hbW91bnQgfHwgMCk7XHJcblxyXG4gICAgICAgICAgICBwaWdteVRvdGFsICs9IGFtb3VudDtcclxuXHJcbiAgICAgICAgICAgIGZpbmFsUm93cy5wdXNoKHtcclxuICAgICAgICAgICAgICBfaWQ6IGAke2N1c3RvbWVyLl9pZH0tUEctJHtzZXJpYWx9YCxcclxuICAgICAgICAgICAgICBzbF9ubzogc2VyaWFsKyssXHJcbiAgICAgICAgICAgICAgZnVsbF9uYW1lOiBjdXN0b21lci5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBjdXN0b21lci5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogaXRlbT8ucGlnbWVfaWQgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfdmFsdWU6IFwiLVwiLFxyXG4gICAgICAgICAgICAgIHRpY2tldHM6IFwiLVwiLFxyXG4gICAgICAgICAgICAgIGVucm9sbG1lbnRfYW1vdW50OiBcIuKCuTBcIixcclxuICAgICAgICAgICAgICBsb2FuX2Ftb3VudDogXCLigrkwXCIsXHJcbiAgICAgICAgICAgICAgcGlnbXlfYW1vdW50OiBg4oK5JHthbW91bnR9YCxcclxuICAgICAgICAgICAgICB0b3RhbDogYOKCuSR7YW1vdW50fWAsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldFRhYmxlRGF0YShmaW5hbFJvd3MpO1xyXG5cclxuICAgICAgICBzZXRTdW1tYXJ5KHtcclxuICAgICAgICAgIGNoaXQ6IGNoaXRUb3RhbCxcclxuICAgICAgICAgIGxvYW46IGxvYW5Ub3RhbCxcclxuICAgICAgICAgIHBpZ215OiBwaWdteVRvdGFsLFxyXG4gICAgICAgICAgb3ZlcmFsbDogY2hpdFRvdGFsICsgbG9hblRvdGFsICsgcGlnbXlUb3RhbCxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICBzZXRUYWJsZURhdGEoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgZmV0Y2hSZXBvcnQoKTtcclxufSwgW3NlbGVjdGVkRW1wbG95ZWUsIHBheW1lbnRUeXBlXSk7XHJcblxyXG5cclxuICAgIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZnVsbF9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lclwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIC8gTG9hbiAvIFBpZ215XCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX3ZhbHVlXCIsIGhlYWRlcjogXCJHcm91cCBWYWx1ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRzXCIsIGhlYWRlcjogXCJUaWNrZXRzXCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbG1lbnRfYW1vdW50XCIsIGhlYWRlcjogXCJFbnJvbGxtZW50XCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5fYW1vdW50XCIsIGhlYWRlcjogXCJMb2FuXCIgfSxcclxuICAgIHsga2V5OiBcInBpZ215X2Ftb3VudFwiLCBoZWFkZXI6IFwiUGlnbXlcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxcIiwgaGVhZGVyOiBcIlRvdGFsXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYmctZ3JheS0xMDAgbWluLWgtc2NyZWVuXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbGcgcC02XCI+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNzAwIG1iLTZcIj5cclxuICAgICAgICAgIENoaXQgQ29sbGVjdGlvbiBFeGVjdXRpdmUgU3VtbWFyeSBSZXBvcnRcclxuICAgICAgICA8L2gyPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICAgIHsvKiBUT1AgU1VNTUFSWSAqL31cclxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIG1kOmdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTEwMCBwLTQgcm91bmRlZC14bCBzaGFkb3dcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5DaGl0IFRvdGFsPC9wPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAg4oK5e3N1bW1hcnkuY2hpdH1cclxuICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHAtNCByb3VuZGVkLXhsIHNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPkxvYW4gVG90YWw8L3A+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAg4oK5e3N1bW1hcnkubG9hbn1cclxuICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmcteWVsbG93LTEwMCBwLTQgcm91bmRlZC14bCBzaGFkb3dcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5QaWdteSBUb3RhbDwvcD5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQteWVsbG93LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAg4oK5e3N1bW1hcnkucGlnbXl9XHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXB1cnBsZS0xMDAgcC00IHJvdW5kZWQteGwgc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+T3ZlcmFsbCBUb3RhbDwvcD5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAg4oK5e3N1bW1hcnkub3ZlcmFsbH1cclxuICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBZb3VyIEZpbHRlcnMgKyBEYXRhVGFibGUgQmVsb3cgKi99XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIG1kOmdyaWQtY29scy0yIGdhcC01IG1iLTZcIj5cclxuICAgICAgICAgIHsvKiBFbXBsb3llZSAqL31cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgbWItMlwiPlxyXG4gICAgICAgICAgICAgIFNlbGVjdCBFbXBsb3llZVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRTZWxlY3RlZEVtcGxveWVlKHZhbHVlKX1cclxuICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwibGFiZWxcIlxyXG4gICAgICAgICAgICAgIG9wdGlvbnM9e2VtcGxveWVlcy5tYXAoKGl0ZW0pID0+ICh7XHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogaXRlbS5faWQsXHJcbiAgICAgICAgICAgICAgICBsYWJlbDogYCR7aXRlbS5uYW1lfSB8ICR7aXRlbS5waG9uZV9udW1iZXJ9YCxcclxuICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICB7LyogUGF5bWVudCBUeXBlICovfVxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgUGF5bWVudCBUeXBlXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRUeXBlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGF5bWVudFR5cGUoZS50YXJnZXQudmFsdWUudG9Mb3dlckNhc2UoKSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkLWxnIHB4LTQgcHktMiBoLTEwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJkYWlseVwiPkRhaWx5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIndlZWtseVwiPldlZWtseTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJtb250aGx5XCI+TW9udGhseTwvb3B0aW9uPlxyXG4gICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogVGFibGUgKi99XHJcbiAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEwIHRleHQtYmx1ZS03MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgIExvYWRpbmcuLi5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICBkYXRhPXt0YWJsZURhdGF9XHJcbiAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkNvbGxlY3Rpb25FeGVjdXRpdmVSZXBvcnRcIlxyXG4gICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ29sbGVjdGlvbkV4ZWN1dGl2ZVJlcG9ydC5jc3ZcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDaGl0Q29sbGVjdGlvbkV4ZWN1dGl2ZVJlcG9ydDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0NoaXRDb2xsZWN0aW9uRXhlY3V0aXZlUmVwb3J0LmpzeCJ9