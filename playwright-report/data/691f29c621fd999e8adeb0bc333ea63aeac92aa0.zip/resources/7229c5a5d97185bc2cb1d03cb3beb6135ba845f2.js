import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeDeductionReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, DatePicker, Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const { MonthPicker } = DatePicker;
const { Option } = Select;
import { PiMoneyDuotone } from "/node_modules/.vite/deps/react-icons_pi.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const EmployeeDeductionReport = () => {
  _s();
  const [allEmployeeSalary, setAllEmployeeSalary] = useState([]);
  const [allEmployees, setAllEmployees] = useState([]);
  const [allSalaryTable, setAllSalaryTable] = useState([]);
  const [summary, setSummary] = useState({
    totalEsi: 0,
    totalEpf: 0,
    totalIt: 0,
    totalpt: 0,
    totalAdditionalDeductions: 0,
    addPaymentsListSummary: "",
    dedPaymentsListSummary: "",
    totalRemainingBalance: 0
  });
  const [isLoading, setIsLoading] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedMonthYear, setSelectedMonthYear] = useState(null);
  const parseAmount = (val) => parseFloat(val?.toString().replace(/[^0-9.-]+/g, "")) || 0;
  useEffect(() => {
    const fetchEmployee = async () => {
      try {
        const response = await api.get("/agent/get-employee");
        setAllEmployees(response?.data?.employee || []);
      } catch (error) {
        console.error("unable to fetch employee");
      }
    };
    fetchEmployee();
  }, []);
  const formatSalaryData = (salaryList) => {
    return salaryList.map((s, index) => {
      const addTotal = Array.isArray(s?.additional_payments) ? s.additional_payments.reduce((acc, cur) => acc + (cur.value || 0), 0) : 0;
      const dedTotal = Array.isArray(s?.additional_deductions) ? s.additional_deductions.reduce(
        (acc, cur) => acc + (cur.value || 0),
        0
      ) : 0;
      const addListStr = Array.isArray(s?.additional_payments) ? s.additional_payments.map((ele) => `${ele.name}:${ele.value}`).join(" | ") : "N/A";
      const dedListStr = Array.isArray(s?.additional_deductions) ? s.additional_deductions.map((ele) => `${ele.name}:${ele.value}`).join(" | ") : "N/A";
      return {
        _id: s?._id,
        slNo: index + 1,
        employeeCode: s?.employee_id?.employeeCode || "N/A",
        employeeName: s?.employee_id?.name || "N/A",
        employeePhone: s?.employee_id?.phone_number || "N/A",
        employeeSalary: s?.employee_id?.salary || "N/A",
        salaryMonth: s?.salary_month || "N/A",
        salaryYear: s?.salary_year || "N/A",
        totalSalaryPayable: s?.total_salary_payable || 0,
        netPayable: s?.net_payable || 0,
        paidAmount: s?.paid_amount || 0,
        remainingBalance: s?.remaining_balance || 0,
        paidDays: s?.paid_days || 0,
        paidDate: s?.pay_date?.split("T")[0] || "N/A",
        addPaymentsList: addListStr,
        dedPaymentsList: dedListStr,
        addPayments: addTotal,
        dedPayments: dedTotal,
        earningBasic: s?.earnings?.basic || 0,
        earningHra: s?.earnings?.hra || 0,
        earningTravelAllowance: s?.earnings?.travel_allowance || 0,
        earningMedicalAllowance: s?.earnings?.medical_allowance || 0,
        earningBenifits: s?.earnings?.basket_of_benifits || 0,
        earningPerformanceBonus: s?.earnings?.performance_bonus || 0,
        earningOthers: s?.earnings?.other_allowances || 0,
        earningConveyance: s?.earnings?.conveyance || 0,
        deductIT: s?.deductions?.income_tax || 0,
        deductESI: s?.deductions?.esi || 0,
        deductEPF: s?.deductions?.epf || 0,
        deductPT: s?.deductions?.professional_tax || 0,
        deductSalaryAdvance: s?.deductions?.salary_advance || 0,
        salaryPaymentMethod: s?.payment_method || "N/A",
        status: s?.status || "N/A"
      };
    });
  };
  const sortSalaryData = (data) => {
    const monthOrder = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ];
    return data.sort((a, b) => {
      const yearA = Number(a.salaryYear);
      const yearB = Number(b.salaryYear);
      if (yearA !== yearB) return yearA - yearB;
      return monthOrder.indexOf(a.salaryMonth) - monthOrder.indexOf(b.salaryMonth);
    });
  };
  const calculateSummary = (rows) => {
    const summaryData = {
      totalEsi: 0,
      totalEpf: 0,
      totalIt: 0,
      totalpt: 0,
      totalAdditionalDeductions: 0,
      totalRemainingBalance: 0,
      addPaymentsListSummary: "",
      dedPaymentsListSummary: ""
    };
    rows.forEach((r) => {
      summaryData.totalEsi += Number(r.deductESI) || 0;
      summaryData.totalEpf += Number(r.deductEPF) || 0;
      summaryData.totalIt += Number(r.deductIT) || 0;
      summaryData.totalpt += Number(r.deductPT) || 0;
    });
    setSummary(summaryData);
  };
  useEffect(() => {
    const fetchEmployeeAllSalaries = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/salary-payment/all");
        const formatted = formatSalaryData(response?.data?.data || []);
        const sortedData = sortSalaryData(formatted);
        setAllSalaryTable(sortedData);
        calculateSummary(sortedData);
      } catch (error) {
        console.error("unable to fetch Employee Salary Payment");
      } finally {
        setIsLoading(false);
      }
    };
    fetchEmployeeAllSalaries();
  }, []);
  useEffect(() => {
    const fetchAllEmployeeData = async () => {
      try {
        setIsLoading(true);
        let query = [];
        if (selectedEmployee) query.push(`employee_id=${selectedEmployee}`);
        if (selectedMonthYear) {
          query.push(`month=${selectedMonthYear.month}`);
          query.push(`year=${selectedMonthYear.year}`);
        }
        const url = `/salary-payment/report?${query.join("&")}`;
        const res = await api.get(url);
        const formatted = formatSalaryData(res?.data?.data || []);
        const sortedData = sortSalaryData(formatted);
        setAllSalaryTable(sortedData);
        calculateSummary(sortedData);
      } catch (err) {
        console.log("unable to fetch filtered employee data");
      } finally {
        setIsLoading(false);
      }
    };
    fetchAllEmployeeData();
  }, [selectedEmployee, selectedMonthYear]);
  const handleMonthPick = (value) => {
    if (!value) return setSelectedMonthYear(null);
    const monthIndex = value.month();
    const year = value.year();
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ];
    setSelectedMonthYear({
      month: monthNames[monthIndex],
      year
    });
  };
  const handleReset = () => {
    setSelectedEmployee(null);
    setSelectedMonthYear(null);
  };
  const columns = [
    { key: "slNo", header: "SL. NO" },
    { key: "employeeName", header: "Employee Name" },
    { key: "employeeCode", header: "Employee ID" },
    { key: "employeePhone", header: "Phone" },
    { key: "paidDate", header: "Pay Date" },
    { key: "salaryMonth", header: "Month" },
    { key: "salaryYear", header: "Year" },
    { key: "deductIT", header: "Income Tax" },
    { key: "deductESI", header: "ESI" },
    { key: "deductEPF", header: "EPF" },
    { key: "deductPT", header: "Professional Tax" }
  ];
  const printHeaderKeys = [
    "Employee",
    "Month",
    "Year",
    "Total ESI",
    "Total PF",
    "Total IT",
    "Total PT"
  ];
  const printHeaderValues = [
    selectedEmployee ? allEmployees.find((e) => e._id === selectedEmployee)?.name || "—" : "All Employees",
    selectedMonthYear?.month || "—",
    selectedMonthYear?.year || "—",
    `₹${summary.totalEsi.toLocaleString("en-IN")} (${numberToIndianWords(
      parseAmount(summary.totalEsi)
    )})`,
    `₹${summary.totalEpf.toLocaleString("en-IN")} (${numberToIndianWords(
      parseAmount(summary.totalEpf)
    )})`,
    `₹${summary.totalIt.toLocaleString("en-IN")} (${numberToIndianWords(
      parseAmount(summary.totalIt)
    )})`,
    `₹${summary.totalpt.toLocaleString("en-IN")} (${numberToIndianWords(
      parseAmount(summary.totalpt)
    )})`
  ];
  const DeductionSummaryCard = ({ title, value, iconType, color }) => {
    const getIcon = () => {
      const iconStyle = { width: "24px", height: "24px", color };
      switch (iconType) {
        case "pf":
          return /* @__PURE__ */ jsxDEV("svg", { style: iconStyle, fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxDEV("path", { d: "M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 689,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 688,
            columnNumber: 13
          }, this);
        case "esi":
          return /* @__PURE__ */ jsxDEV("svg", { style: iconStyle, fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxDEV(
            "path",
            {
              fillRule: "evenodd",
              d: "M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z",
              clipRule: "evenodd"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
              lineNumber: 695,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 694,
            columnNumber: 13
          }, this);
        case "it":
          return /* @__PURE__ */ jsxDEV("svg", { style: iconStyle, fill: "currentColor", viewBox: "0 0 20 20", children: [
            /* @__PURE__ */ jsxDEV("path", { d: "M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
              lineNumber: 705,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "path",
              {
                fillRule: "evenodd",
                d: "M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z",
                clipRule: "evenodd"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
                lineNumber: 706,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 704,
            columnNumber: 13
          }, this);
        case "pt":
          return /* @__PURE__ */ jsxDEV("svg", { style: iconStyle, fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxDEV(
            "path",
            {
              fillRule: "evenodd",
              d: "M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V4a2 2 0 00-2-2H6zm1 2a1 1 0 000 2h6a1 1 0 100-2H7zm0 4a1 1 0 000 2h6a1 1 0 100-2H7zm0 4a1 1 0 000 2h2a1 1 0 100-2H7z",
              clipRule: "evenodd"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
              lineNumber: 716,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 715,
            columnNumber: 13
          }, this);
        default:
          return null;
      }
    };
    const getTextClass = () => {
      if (color.includes("3b82f6")) return "text-violet-700";
      if (color.includes("10b981")) return "text-green-700";
      if (color.includes("f59e0b")) return "text-amber-700";
      if (color.includes("5d23aa")) return "text-purple-700";
      return "text-gray-700";
    };
    const isCurrency = !title.toLowerCase().includes("tax");
    const numericValue = parseAmount(value);
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 p-6 border-l-4",
        style: { borderLeftColor: color },
        children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-[13px] font-semibold uppercase tracking-wider", children: title }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
              lineNumber: 747,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-800 mt-1", children: isCurrency ? `₹${numericValue.toLocaleString("en-IN")}` : numericValue.toLocaleString("en-IN") }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
              lineNumber: 750,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono mt-1 block ${getTextClass()}`, children: numberToIndianWords(numericValue) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
              lineNumber: 756,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 746,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "p-3 rounded-full flex items-center justify-center ml-4",
              style: { backgroundColor: `${color}20` },
              children: getIcon()
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
              lineNumber: 760,
              columnNumber: 11
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
          lineNumber: 745,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
        lineNumber: 741,
        columnNumber: 7
      },
      this
    );
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
      lineNumber: 773,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "font-bold text-2xl mb-4", children: "Reports - Salary Deductions" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
        lineNumber: 775,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mb-6 items-center", children: [
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            allowClear: true,
            style: { width: 300 },
            value: selectedEmployee,
            placeholder: "Select Employee",
            onChange: (value) => setSelectedEmployee(value),
            children: allEmployees.map(
              (emp) => /* @__PURE__ */ jsxDEV(Option, { value: emp._id, children: [
                emp.name,
                " | ",
                emp.phone_number
              ] }, emp._id, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
                lineNumber: 787,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 779,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          MonthPicker,
          {
            style: { width: 250 },
            placeholder: "Select Month",
            onChange: handleMonthPick
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 793,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleReset,
            className: "px-4 py-2 bg-violet-500 text-white rounded hover:bg-violet-600 transition-colors",
            children: "Reset"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 799,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
        lineNumber: 778,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6", children: [
        /* @__PURE__ */ jsxDEV(
          DeductionSummaryCard,
          {
            title: "Total PF",
            value: summary.totalEpf,
            iconType: "pf",
            color: "#3b82f6"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 809,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DeductionSummaryCard,
          {
            title: "Total ESI",
            value: summary.totalEsi,
            iconType: "esi",
            color: "#10b981"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 815,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DeductionSummaryCard,
          {
            title: "Total Income Tax",
            value: summary.totalIt,
            iconType: "it",
            color: "#f59e0b"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 821,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DeductionSummaryCard,
          {
            title: "Total Professional Tax",
            value: summary.totalpt,
            iconType: "pt",
            color: "#5d23aaff"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
            lineNumber: 827,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
        lineNumber: 808,
        columnNumber: 9
      }, this),
      isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-10", children: /* @__PURE__ */ jsxDEV(Spin, { size: "large" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
        lineNumber: 837,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
        lineNumber: 836,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns,
          data: allSalaryTable,
          exportCols: columns,
          isExportEnabled: true,
          exportedPdfName: "Employee Deduction Report",
          printHeaderKeys,
          printHeaderValues,
          exportedFileName: "Employee Deduction Report.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
          lineNumber: 840,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
      lineNumber: 774,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx",
    lineNumber: 772,
    columnNumber: 5
  }, this);
};
_s(EmployeeDeductionReport, "Z6TY6fft0+03/1aOahJY+ax70h8=");
_c = EmployeeDeductionReport;
export default EmployeeDeductionReport;
var _c;
$RefreshReg$(_c, "EmployeeDeductionReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeDeductionReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ3JCYzsyQkFockJkO0FBQW9CQSxvQkFBZ0IsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxRQUFRQyxZQUFZQyxZQUFZO0FBQ3pDLE1BQU0sRUFBRUMsWUFBWSxJQUFJRjtBQUN4QixNQUFNLEVBQUVHLE9BQU8sSUFBSUo7QUFDbkIsU0FBU0ssc0JBQXNCO0FBRS9CLFNBQVNDLDJCQUEyQjtBQThZcEMsTUFBTUMsMEJBQTBCQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEMsUUFBTSxDQUFDQyxtQkFBbUJDLG9CQUFvQixJQUFJZCxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDZSxjQUFjQyxlQUFlLElBQUloQixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDaUIsZ0JBQWdCQyxpQkFBaUIsSUFBSWxCLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNtQixTQUFTQyxVQUFVLElBQUlwQixTQUFTO0FBQUEsSUFDckNxQixVQUFVO0FBQUEsSUFDVkMsVUFBVTtBQUFBLElBQ1ZDLFNBQVM7QUFBQSxJQUNUQyxTQUFTO0FBQUEsSUFDVEMsMkJBQTJCO0FBQUEsSUFDM0JDLHdCQUF3QjtBQUFBLElBQ3hCQyx3QkFBd0I7QUFBQSxJQUN4QkMsdUJBQXVCO0FBQUEsRUFDekIsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJOUIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQytCLGtCQUFrQkMsbUJBQW1CLElBQUloQyxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDaUMsbUJBQW1CQyxvQkFBb0IsSUFBSWxDLFNBQVMsSUFBSTtBQUcvRCxRQUFNbUMsY0FBY0EsQ0FBQ0MsUUFDbkJDLFdBQVdELEtBQUtFLFNBQVMsRUFBRUMsUUFBUSxjQUFjLEVBQUUsQ0FBQyxLQUFLO0FBRzNEQyxZQUFVLE1BQU07QUFDZCxVQUFNQyxnQkFBZ0IsWUFBWTtBQUNoQyxVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNekMsSUFBSTBDLElBQUkscUJBQXFCO0FBQ3BEM0Isd0JBQWdCMEIsVUFBVUUsTUFBTUMsWUFBWSxFQUFFO0FBQUEsTUFDaEQsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSwwQkFBMEI7QUFBQSxNQUMxQztBQUFBLElBQ0Y7QUFDQUwsa0JBQWM7QUFBQSxFQUNoQixHQUFHLEVBQUU7QUFHTCxRQUFNTyxtQkFBbUJBLENBQUNDLGVBQWU7QUFDdkMsV0FBT0EsV0FBV0MsSUFBSSxDQUFDQyxHQUFHQyxVQUFVO0FBQ2xDLFlBQU1DLFdBQVdDLE1BQU1DLFFBQVFKLEdBQUdLLG1CQUFtQixJQUNqREwsRUFBRUssb0JBQW9CQyxPQUFPLENBQUNDLEtBQUtDLFFBQVFELE9BQU9DLElBQUlDLFNBQVMsSUFBSSxDQUFDLElBQ3BFO0FBRUosWUFBTUMsV0FBV1AsTUFBTUMsUUFBUUosR0FBR1cscUJBQXFCLElBQ25EWCxFQUFFVyxzQkFBc0JMO0FBQUFBLFFBQ3RCLENBQUNDLEtBQUtDLFFBQVFELE9BQU9DLElBQUlDLFNBQVM7QUFBQSxRQUNsQztBQUFBLE1BQ0YsSUFDQTtBQUVKLFlBQU1HLGFBQWFULE1BQU1DLFFBQVFKLEdBQUdLLG1CQUFtQixJQUNuREwsRUFBRUssb0JBQ0NOLElBQUksQ0FBQ2MsUUFBUSxHQUFHQSxJQUFJQyxJQUFJLElBQUlELElBQUlKLEtBQUssRUFBRSxFQUN2Q00sS0FBSyxLQUFLLElBQ2I7QUFFSixZQUFNQyxhQUFhYixNQUFNQyxRQUFRSixHQUFHVyxxQkFBcUIsSUFDckRYLEVBQUVXLHNCQUNDWixJQUFJLENBQUNjLFFBQVEsR0FBR0EsSUFBSUMsSUFBSSxJQUFJRCxJQUFJSixLQUFLLEVBQUUsRUFDdkNNLEtBQUssS0FBSyxJQUNiO0FBRUosYUFBTztBQUFBLFFBQ0xFLEtBQUtqQixHQUFHaUI7QUFBQUEsUUFDUkMsTUFBTWpCLFFBQVE7QUFBQSxRQUNka0IsY0FBY25CLEdBQUdvQixhQUFhRCxnQkFBZ0I7QUFBQSxRQUM5Q0UsY0FBY3JCLEdBQUdvQixhQUFhTixRQUFRO0FBQUEsUUFDdENRLGVBQWV0QixHQUFHb0IsYUFBYUcsZ0JBQWdCO0FBQUEsUUFDL0NDLGdCQUFnQnhCLEdBQUdvQixhQUFhSyxVQUFVO0FBQUEsUUFDMUNDLGFBQWExQixHQUFHMkIsZ0JBQWdCO0FBQUEsUUFDaENDLFlBQVk1QixHQUFHNkIsZUFBZTtBQUFBLFFBQzlCQyxvQkFBb0I5QixHQUFHK0Isd0JBQXdCO0FBQUEsUUFDL0NDLFlBQVloQyxHQUFHaUMsZUFBZTtBQUFBLFFBQzlCQyxZQUFZbEMsR0FBR21DLGVBQWU7QUFBQSxRQUM5QkMsa0JBQWtCcEMsR0FBR3FDLHFCQUFxQjtBQUFBLFFBQzFDQyxVQUFVdEMsR0FBR3VDLGFBQWE7QUFBQSxRQUMxQkMsVUFBVXhDLEdBQUd5QyxVQUFVQyxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxRQUN4Q0MsaUJBQWlCL0I7QUFBQUEsUUFDakJnQyxpQkFBaUI1QjtBQUFBQSxRQUNqQjZCLGFBQWEzQztBQUFBQSxRQUNiNEMsYUFBYXBDO0FBQUFBLFFBQ2JxQyxjQUFjL0MsR0FBR2dELFVBQVVDLFNBQVM7QUFBQSxRQUNwQ0MsWUFBWWxELEdBQUdnRCxVQUFVRyxPQUFPO0FBQUEsUUFDaENDLHdCQUF3QnBELEdBQUdnRCxVQUFVSyxvQkFBb0I7QUFBQSxRQUN6REMseUJBQXlCdEQsR0FBR2dELFVBQVVPLHFCQUFxQjtBQUFBLFFBQzNEQyxpQkFBaUJ4RCxHQUFHZ0QsVUFBVVMsc0JBQXNCO0FBQUEsUUFDcERDLHlCQUF5QjFELEdBQUdnRCxVQUFVVyxxQkFBcUI7QUFBQSxRQUMzREMsZUFBZTVELEdBQUdnRCxVQUFVYSxvQkFBb0I7QUFBQSxRQUNoREMsbUJBQW1COUQsR0FBR2dELFVBQVVlLGNBQWM7QUFBQSxRQUM5Q0MsVUFBVWhFLEdBQUdpRSxZQUFZQyxjQUFjO0FBQUEsUUFDdkNDLFdBQVduRSxHQUFHaUUsWUFBWUcsT0FBTztBQUFBLFFBQ2pDQyxXQUFXckUsR0FBR2lFLFlBQVlLLE9BQU87QUFBQSxRQUNqQ0MsVUFBVXZFLEdBQUdpRSxZQUFZTyxvQkFBb0I7QUFBQSxRQUM3Q0MscUJBQXFCekUsR0FBR2lFLFlBQVlTLGtCQUFrQjtBQUFBLFFBQ3REQyxxQkFBcUIzRSxHQUFHNEUsa0JBQWtCO0FBQUEsUUFDMUNDLFFBQVE3RSxHQUFHNkUsVUFBVTtBQUFBLE1BQ3ZCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUdBLFFBQU1DLGlCQUFpQkEsQ0FBQ3JGLFNBQVM7QUFDL0IsVUFBTXNGLGFBQWE7QUFBQSxNQUNqQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFBVTtBQUdaLFdBQU90RixLQUFLdUYsS0FBSyxDQUFDQyxHQUFHQyxNQUFNO0FBQ3pCLFlBQU1DLFFBQVFDLE9BQU9ILEVBQUVyRCxVQUFVO0FBQ2pDLFlBQU15RCxRQUFRRCxPQUFPRixFQUFFdEQsVUFBVTtBQUNqQyxVQUFJdUQsVUFBVUUsTUFBTyxRQUFPRixRQUFRRTtBQUNwQyxhQUFPTixXQUFXTyxRQUFRTCxFQUFFdkQsV0FBVyxJQUFJcUQsV0FBV08sUUFBUUosRUFBRXhELFdBQVc7QUFBQSxJQUM3RSxDQUFDO0FBQUEsRUFDSDtBQUdBLFFBQU02RCxtQkFBbUJBLENBQUNDLFNBQVM7QUFDakMsVUFBTUMsY0FBYztBQUFBLE1BQ2xCdkgsVUFBVTtBQUFBLE1BQ1ZDLFVBQVU7QUFBQSxNQUNWQyxTQUFTO0FBQUEsTUFDVEMsU0FBUztBQUFBLE1BQ1RDLDJCQUEyQjtBQUFBLE1BQzNCRyx1QkFBdUI7QUFBQSxNQUN2QkYsd0JBQXdCO0FBQUEsTUFDeEJDLHdCQUF3QjtBQUFBLElBQzFCO0FBRUFnSCxTQUFLRSxRQUFRLENBQUNDLE1BQU07QUFDbEJGLGtCQUFZdkgsWUFBWWtILE9BQU9PLEVBQUV4QixTQUFTLEtBQUs7QUFDL0NzQixrQkFBWXRILFlBQVlpSCxPQUFPTyxFQUFFdEIsU0FBUyxLQUFLO0FBQy9Db0Isa0JBQVlySCxXQUFXZ0gsT0FBT08sRUFBRTNCLFFBQVEsS0FBSztBQUM3Q3lCLGtCQUFZcEgsV0FBVytHLE9BQU9PLEVBQUVwQixRQUFRLEtBQUs7QUFBQSxJQUMvQyxDQUFDO0FBRUR0RyxlQUFXd0gsV0FBVztBQUFBLEVBQ3hCO0FBR0FwRyxZQUFVLE1BQU07QUFDZCxVQUFNdUcsMkJBQTJCLFlBQVk7QUFDM0MsVUFBSTtBQUNGakgscUJBQWEsSUFBSTtBQUNqQixjQUFNWSxXQUFXLE1BQU16QyxJQUFJMEMsSUFBSSxxQkFBcUI7QUFDcEQsY0FBTXFHLFlBQVloRyxpQkFBaUJOLFVBQVVFLE1BQU1BLFFBQVEsRUFBRTtBQUM3RCxjQUFNcUcsYUFBYWhCLGVBQWVlLFNBQVM7QUFDM0M5SCwwQkFBa0IrSCxVQUFVO0FBQzVCUCx5QkFBaUJPLFVBQVU7QUFBQSxNQUM3QixTQUFTbkcsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx5Q0FBeUM7QUFBQSxNQUN6RCxVQUFDO0FBQ0NoQixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0FpSCw2QkFBeUI7QUFBQSxFQUMzQixHQUFHLEVBQUU7QUFHTHZHLFlBQVUsTUFBTTtBQUNkLFVBQU0wRyx1QkFBdUIsWUFBWTtBQUN2QyxVQUFJO0FBQ0ZwSCxxQkFBYSxJQUFJO0FBQ2pCLFlBQUlxSCxRQUFRO0FBQ1osWUFBSXBILGlCQUFrQm9ILE9BQU1DLEtBQUssZUFBZXJILGdCQUFnQixFQUFFO0FBQ2xFLFlBQUlFLG1CQUFtQjtBQUNyQmtILGdCQUFNQyxLQUFLLFNBQVNuSCxrQkFBa0JvSCxLQUFLLEVBQUU7QUFDN0NGLGdCQUFNQyxLQUFLLFFBQVFuSCxrQkFBa0JxSCxJQUFJLEVBQUU7QUFBQSxRQUM3QztBQUVBLGNBQU1DLE1BQU0sMEJBQTBCSixNQUFNakYsS0FBSyxHQUFHLENBQUM7QUFDckQsY0FBTXNGLE1BQU0sTUFBTXZKLElBQUkwQyxJQUFJNEcsR0FBRztBQUU3QixjQUFNUCxZQUFZaEcsaUJBQWlCd0csS0FBSzVHLE1BQU1BLFFBQVEsRUFBRTtBQUN4RCxjQUFNcUcsYUFBYWhCLGVBQWVlLFNBQVM7QUFDM0M5SCwwQkFBa0IrSCxVQUFVO0FBQzVCUCx5QkFBaUJPLFVBQVU7QUFBQSxNQUM3QixTQUFTUSxLQUFLO0FBQ1oxRyxnQkFBUTJHLElBQUksd0NBQXdDO0FBQUEsTUFDdEQsVUFBQztBQUNDNUgscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUVBb0gseUJBQXFCO0FBQUEsRUFDdkIsR0FBRyxDQUFDbkgsa0JBQWtCRSxpQkFBaUIsQ0FBQztBQUd4QyxRQUFNMEgsa0JBQWtCQSxDQUFDL0YsVUFBVTtBQUNqQyxRQUFJLENBQUNBLE1BQU8sUUFBTzFCLHFCQUFxQixJQUFJO0FBQzVDLFVBQU0wSCxhQUFhaEcsTUFBTXlGLE1BQU07QUFDL0IsVUFBTUMsT0FBTzFGLE1BQU0wRixLQUFLO0FBRXhCLFVBQU1PLGFBQWE7QUFBQSxNQUNqQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFBVTtBQUdaM0gseUJBQXFCO0FBQUEsTUFDbkJtSCxPQUFPUSxXQUFXRCxVQUFVO0FBQUEsTUFDNUJOO0FBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNUSxjQUFjQSxNQUFNO0FBQ3hCOUgsd0JBQW9CLElBQUk7QUFDeEJFLHlCQUFxQixJQUFJO0FBQUEsRUFDM0I7QUFFQSxRQUFNNkgsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxRQUFRQyxRQUFRLFNBQVM7QUFBQSxJQUNoQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxjQUFjO0FBQUEsSUFDN0MsRUFBRUQsS0FBSyxpQkFBaUJDLFFBQVEsUUFBUTtBQUFBLElBQ3hDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLFFBQVE7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsT0FBTztBQUFBLElBQ3BDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxhQUFhO0FBQUEsSUFDeEMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLE1BQU07QUFBQSxJQUNsQyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsTUFBTTtBQUFBLElBQ2xDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxtQkFBbUI7QUFBQSxFQUFDO0FBR2pELFFBQU1DLGtCQUFrQjtBQUFBLElBQ3RCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFBVTtBQUlaLFFBQU1DLG9CQUFvQjtBQUFBLElBQ3hCcEksbUJBQ0loQixhQUFhcUosS0FBSyxDQUFDQyxNQUFNQSxFQUFFakcsUUFBUXJDLGdCQUFnQixHQUFHa0MsUUFBUSxNQUM5RDtBQUFBLElBQ0poQyxtQkFBbUJvSCxTQUFTO0FBQUEsSUFDNUJwSCxtQkFBbUJxSCxRQUFRO0FBQUEsSUFDM0IsSUFBSW5JLFFBQVFFLFNBQVNpSixlQUFlLE9BQU8sQ0FBQyxLQUFLNUo7QUFBQUEsTUFDL0N5QixZQUFZaEIsUUFBUUUsUUFBUTtBQUFBLElBQzlCLENBQUM7QUFBQSxJQUNELElBQUlGLFFBQVFHLFNBQVNnSixlQUFlLE9BQU8sQ0FBQyxLQUFLNUo7QUFBQUEsTUFDL0N5QixZQUFZaEIsUUFBUUcsUUFBUTtBQUFBLElBQzlCLENBQUM7QUFBQSxJQUNELElBQUlILFFBQVFJLFFBQVErSSxlQUFlLE9BQU8sQ0FBQyxLQUFLNUo7QUFBQUEsTUFDOUN5QixZQUFZaEIsUUFBUUksT0FBTztBQUFBLElBQzdCLENBQUM7QUFBQSxJQUNELElBQUlKLFFBQVFLLFFBQVE4SSxlQUFlLE9BQU8sQ0FBQyxLQUFLNUo7QUFBQUEsTUFDOUN5QixZQUFZaEIsUUFBUUssT0FBTztBQUFBLElBQzdCLENBQUM7QUFBQSxFQUFHO0FBSU4sUUFBTStJLHVCQUF1QkEsQ0FBQyxFQUFFQyxPQUFPNUcsT0FBTzZHLFVBQVVDLE1BQU0sTUFBTTtBQUNsRSxVQUFNQyxVQUFVQSxNQUFNO0FBQ3BCLFlBQU1DLFlBQVksRUFBRUMsT0FBTyxRQUFRQyxRQUFRLFFBQVFKLE1BQU07QUFDekQsY0FBUUQsVUFBUTtBQUFBLFFBQ2QsS0FBSztBQUNILGlCQUNFLHVCQUFDLFNBQUksT0FBT0csV0FBVyxNQUFLLGdCQUFlLFNBQVEsYUFDakQsaUNBQUMsVUFBSyxHQUFFLHdNQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZNLEtBRC9NO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUVKLEtBQUs7QUFDSCxpQkFDRSx1QkFBQyxTQUFJLE9BQU9BLFdBQVcsTUFBSyxnQkFBZSxTQUFRLGFBQ2pEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFTO0FBQUEsY0FDVCxHQUFFO0FBQUEsY0FDRixVQUFTO0FBQUE7QUFBQSxZQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlDLEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFFBRUosS0FBSztBQUNILGlCQUNFLHVCQUFDLFNBQUksT0FBT0EsV0FBVyxNQUFLLGdCQUFlLFNBQVEsYUFDakQ7QUFBQSxtQ0FBQyxVQUFLLEdBQUUsZ1BBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcVA7QUFBQSxZQUNyUDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFVBQVM7QUFBQSxnQkFDVCxHQUFFO0FBQUEsZ0JBQ0YsVUFBUztBQUFBO0FBQUEsY0FIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJQztBQUFBLGVBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFFBRUosS0FBSztBQUNILGlCQUNFLHVCQUFDLFNBQUksT0FBT0EsV0FBVyxNQUFLLGdCQUFlLFNBQVEsYUFDakQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVM7QUFBQSxjQUNULEdBQUU7QUFBQSxjQUNGLFVBQVM7QUFBQTtBQUFBLFlBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSUMsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsUUFFSjtBQUNFLGlCQUFPO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFHQSxVQUFNRyxlQUFlQSxNQUFNO0FBQ3pCLFVBQUlMLE1BQU1NLFNBQVMsUUFBUSxFQUFHLFFBQU87QUFDckMsVUFBSU4sTUFBTU0sU0FBUyxRQUFRLEVBQUcsUUFBTztBQUNyQyxVQUFJTixNQUFNTSxTQUFTLFFBQVEsRUFBRyxRQUFPO0FBQ3JDLFVBQUlOLE1BQU1NLFNBQVMsUUFBUSxFQUFHLFFBQU87QUFDckMsYUFBTztBQUFBLElBQ1Q7QUFFQSxVQUFNQyxhQUFhLENBQUNULE1BQU1VLFlBQVksRUFBRUYsU0FBUyxLQUFLO0FBQ3RELFVBQU1HLGVBQWVoSixZQUFZeUIsS0FBSztBQUV0QyxXQUNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixPQUFPLEVBQUV3SCxpQkFBaUJWLE1BQU07QUFBQSxRQUVoQyxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxvRUFDVkYsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLHdDQUNWUyx1QkFDRyxJQUFJRSxhQUFhYixlQUFlLE9BQU8sQ0FBQyxLQUN4Q2EsYUFBYWIsZUFBZSxPQUFPLEtBSHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUVBLHVCQUFDLFVBQUssV0FBVyxnQ0FBZ0NTLGFBQWEsQ0FBQyxJQUM1RHJLLDhCQUFvQnlLLFlBQVksS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRUUsaUJBQWlCLEdBQUdYLEtBQUssS0FBSztBQUFBLGNBRXRDQyxrQkFBUTtBQUFBO0FBQUEsWUFKWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQTtBQUFBLE1BekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTBCQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsMkJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUNQLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDJCQUEwQiwyQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BR25FLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsT0FBTyxFQUFFRSxPQUFPLElBQUk7QUFBQSxZQUNwQixPQUFPOUk7QUFBQUEsWUFDUCxhQUFZO0FBQUEsWUFDWixVQUFVLENBQUM2QixVQUFVNUIsb0JBQW9CNEIsS0FBSztBQUFBLFlBRTdDN0MsdUJBQWFtQztBQUFBQSxjQUFJLENBQUNvSSxRQUNqQix1QkFBQyxVQUFxQixPQUFPQSxJQUFJbEgsS0FDOUJrSDtBQUFBQSxvQkFBSXJIO0FBQUFBLGdCQUFLO0FBQUEsZ0JBQUlxSCxJQUFJNUc7QUFBQUEsbUJBRFA0RyxJQUFJbEgsS0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0Q7QUFBQTtBQUFBLFVBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPLEVBQUV5RyxPQUFPLElBQUk7QUFBQSxZQUNwQixhQUFZO0FBQUEsWUFDWixVQUFVbEI7QUFBQUE7QUFBQUEsVUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHNEI7QUFBQSxRQUc1QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU0c7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFBa0Y7QUFBQTtBQUFBLFVBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU8zSSxRQUFRRztBQUFBQSxZQUNmLFVBQVM7QUFBQSxZQUNULE9BQU07QUFBQTtBQUFBLFVBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWlCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU9ILFFBQVFFO0FBQUFBLFlBQ2YsVUFBUztBQUFBLFlBQ1QsT0FBTTtBQUFBO0FBQUEsVUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJaUI7QUFBQSxRQUVqQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBT0YsUUFBUUk7QUFBQUEsWUFDZixVQUFTO0FBQUEsWUFDVCxPQUFNO0FBQUE7QUFBQSxVQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlpQjtBQUFBLFFBRWpCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPSixRQUFRSztBQUFBQSxZQUNmLFVBQVM7QUFBQSxZQUNULE9BQU07QUFBQTtBQUFBLFVBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSW1CO0FBQUEsV0F2QnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkE7QUFBQSxNQUVDSyxZQUNDLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxRQUFLLE1BQUssV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsTUFBTVo7QUFBQUEsVUFDTixZQUFZOEk7QUFBQUEsVUFDWixpQkFBaUI7QUFBQSxVQUNqQixpQkFBZ0I7QUFBQSxVQUNoQjtBQUFBLFVBQ0E7QUFBQSxVQUNBLGtCQUFpQjtBQUFBO0FBQUEsUUFSbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUWtEO0FBQUEsU0ExRXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2RUE7QUFBQSxPQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0ZBO0FBRUo7QUFBRW5KLEdBOWJJRCx5QkFBdUI7QUFBQTRLLEtBQXZCNUs7QUFpY04sZUFBZUE7QUFBd0IsSUFBQTRLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsImFwaSIsIkRhdGFUYWJsZSIsIk5hdmJhciIsIlNlbGVjdCIsIkRhdGVQaWNrZXIiLCJTcGluIiwiTW9udGhQaWNrZXIiLCJPcHRpb24iLCJQaU1vbmV5RHVvdG9uZSIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJFbXBsb3llZURlZHVjdGlvblJlcG9ydCIsIl9zIiwiYWxsRW1wbG95ZWVTYWxhcnkiLCJzZXRBbGxFbXBsb3llZVNhbGFyeSIsImFsbEVtcGxveWVlcyIsInNldEFsbEVtcGxveWVlcyIsImFsbFNhbGFyeVRhYmxlIiwic2V0QWxsU2FsYXJ5VGFibGUiLCJzdW1tYXJ5Iiwic2V0U3VtbWFyeSIsInRvdGFsRXNpIiwidG90YWxFcGYiLCJ0b3RhbEl0IiwidG90YWxwdCIsInRvdGFsQWRkaXRpb25hbERlZHVjdGlvbnMiLCJhZGRQYXltZW50c0xpc3RTdW1tYXJ5IiwiZGVkUGF5bWVudHNMaXN0U3VtbWFyeSIsInRvdGFsUmVtYWluaW5nQmFsYW5jZSIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNlbGVjdGVkRW1wbG95ZWUiLCJzZXRTZWxlY3RlZEVtcGxveWVlIiwic2VsZWN0ZWRNb250aFllYXIiLCJzZXRTZWxlY3RlZE1vbnRoWWVhciIsInBhcnNlQW1vdW50IiwidmFsIiwicGFyc2VGbG9hdCIsInRvU3RyaW5nIiwicmVwbGFjZSIsInVzZUVmZmVjdCIsImZldGNoRW1wbG95ZWUiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlbXBsb3llZSIsImVycm9yIiwiY29uc29sZSIsImZvcm1hdFNhbGFyeURhdGEiLCJzYWxhcnlMaXN0IiwibWFwIiwicyIsImluZGV4IiwiYWRkVG90YWwiLCJBcnJheSIsImlzQXJyYXkiLCJhZGRpdGlvbmFsX3BheW1lbnRzIiwicmVkdWNlIiwiYWNjIiwiY3VyIiwidmFsdWUiLCJkZWRUb3RhbCIsImFkZGl0aW9uYWxfZGVkdWN0aW9ucyIsImFkZExpc3RTdHIiLCJlbGUiLCJuYW1lIiwiam9pbiIsImRlZExpc3RTdHIiLCJfaWQiLCJzbE5vIiwiZW1wbG95ZWVDb2RlIiwiZW1wbG95ZWVfaWQiLCJlbXBsb3llZU5hbWUiLCJlbXBsb3llZVBob25lIiwicGhvbmVfbnVtYmVyIiwiZW1wbG95ZWVTYWxhcnkiLCJzYWxhcnkiLCJzYWxhcnlNb250aCIsInNhbGFyeV9tb250aCIsInNhbGFyeVllYXIiLCJzYWxhcnlfeWVhciIsInRvdGFsU2FsYXJ5UGF5YWJsZSIsInRvdGFsX3NhbGFyeV9wYXlhYmxlIiwibmV0UGF5YWJsZSIsIm5ldF9wYXlhYmxlIiwicGFpZEFtb3VudCIsInBhaWRfYW1vdW50IiwicmVtYWluaW5nQmFsYW5jZSIsInJlbWFpbmluZ19iYWxhbmNlIiwicGFpZERheXMiLCJwYWlkX2RheXMiLCJwYWlkRGF0ZSIsInBheV9kYXRlIiwic3BsaXQiLCJhZGRQYXltZW50c0xpc3QiLCJkZWRQYXltZW50c0xpc3QiLCJhZGRQYXltZW50cyIsImRlZFBheW1lbnRzIiwiZWFybmluZ0Jhc2ljIiwiZWFybmluZ3MiLCJiYXNpYyIsImVhcm5pbmdIcmEiLCJocmEiLCJlYXJuaW5nVHJhdmVsQWxsb3dhbmNlIiwidHJhdmVsX2FsbG93YW5jZSIsImVhcm5pbmdNZWRpY2FsQWxsb3dhbmNlIiwibWVkaWNhbF9hbGxvd2FuY2UiLCJlYXJuaW5nQmVuaWZpdHMiLCJiYXNrZXRfb2ZfYmVuaWZpdHMiLCJlYXJuaW5nUGVyZm9ybWFuY2VCb251cyIsInBlcmZvcm1hbmNlX2JvbnVzIiwiZWFybmluZ090aGVycyIsIm90aGVyX2FsbG93YW5jZXMiLCJlYXJuaW5nQ29udmV5YW5jZSIsImNvbnZleWFuY2UiLCJkZWR1Y3RJVCIsImRlZHVjdGlvbnMiLCJpbmNvbWVfdGF4IiwiZGVkdWN0RVNJIiwiZXNpIiwiZGVkdWN0RVBGIiwiZXBmIiwiZGVkdWN0UFQiLCJwcm9mZXNzaW9uYWxfdGF4IiwiZGVkdWN0U2FsYXJ5QWR2YW5jZSIsInNhbGFyeV9hZHZhbmNlIiwic2FsYXJ5UGF5bWVudE1ldGhvZCIsInBheW1lbnRfbWV0aG9kIiwic3RhdHVzIiwic29ydFNhbGFyeURhdGEiLCJtb250aE9yZGVyIiwic29ydCIsImEiLCJiIiwieWVhckEiLCJOdW1iZXIiLCJ5ZWFyQiIsImluZGV4T2YiLCJjYWxjdWxhdGVTdW1tYXJ5Iiwicm93cyIsInN1bW1hcnlEYXRhIiwiZm9yRWFjaCIsInIiLCJmZXRjaEVtcGxveWVlQWxsU2FsYXJpZXMiLCJmb3JtYXR0ZWQiLCJzb3J0ZWREYXRhIiwiZmV0Y2hBbGxFbXBsb3llZURhdGEiLCJxdWVyeSIsInB1c2giLCJtb250aCIsInllYXIiLCJ1cmwiLCJyZXMiLCJlcnIiLCJsb2ciLCJoYW5kbGVNb250aFBpY2siLCJtb250aEluZGV4IiwibW9udGhOYW1lcyIsImhhbmRsZVJlc2V0IiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsInByaW50SGVhZGVyS2V5cyIsInByaW50SGVhZGVyVmFsdWVzIiwiZmluZCIsImUiLCJ0b0xvY2FsZVN0cmluZyIsIkRlZHVjdGlvblN1bW1hcnlDYXJkIiwidGl0bGUiLCJpY29uVHlwZSIsImNvbG9yIiwiZ2V0SWNvbiIsImljb25TdHlsZSIsIndpZHRoIiwiaGVpZ2h0IiwiZ2V0VGV4dENsYXNzIiwiaW5jbHVkZXMiLCJpc0N1cnJlbmN5IiwidG9Mb3dlckNhc2UiLCJudW1lcmljVmFsdWUiLCJib3JkZXJMZWZ0Q29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJlbXAiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJFbXBsb3llZURlZHVjdGlvblJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIERhdGVQaWNrZXIsIFNwaW4gfSBmcm9tIFwiYW50ZFwiO1xyXG5jb25zdCB7IE1vbnRoUGlja2VyIH0gPSBEYXRlUGlja2VyO1xyXG5jb25zdCB7IE9wdGlvbiB9ID0gU2VsZWN0O1xyXG5pbXBvcnQgeyBQaU1vbmV5RHVvdG9uZSB9IGZyb20gXCJyZWFjdC1pY29ucy9waVwiO1xyXG5cclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuXHJcbi8vIGNvbnN0IEVtcGxveWVlRGVkdWN0aW9uUmVwb3J0ID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IFthbGxFbXBsb3llZVNhbGFyeSwgc2V0QWxsRW1wbG95ZWVTYWxhcnldID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFthbGxFbXBsb3llZXMsIHNldEFsbEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2FsbFNhbGFyeVRhYmxlLCBzZXRBbGxTYWxhcnlUYWJsZV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW3N1bW1hcnksIHNldFN1bW1hcnldID0gdXNlU3RhdGUoe1xyXG4vLyAgICAgdG90YWxFc2k6IDAsXHJcbi8vICAgICB0b3RhbEVwZjogMCxcclxuLy8gICAgIHRvdGFsSXQ6IDAsXHJcbi8vICAgICB0b3RhbHB0OiAwLFxyXG4vLyAgICAgdG90YWxBZGRpdGlvbmFsRGVkdWN0aW9uczogMCxcclxuLy8gICAgIGFkZFBheW1lbnRzTGlzdFN1bW1hcnk6IFwiXCIsXHJcbi8vICAgICBkZWRQYXltZW50c0xpc3RTdW1tYXJ5OiBcIlwiLFxyXG4vLyAgICAgdG90YWxSZW1haW5pbmdCYWxhbmNlOiAwLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlLCBzZXRTZWxlY3RlZEVtcGxveWVlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZE1vbnRoWWVhciwgc2V0U2VsZWN0ZWRNb250aFllYXJdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4vLyAgIC8vIEZldGNoIGFsbCBlbXBsb3llZXNcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hFbXBsb3llZSA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWVtcGxveWVlXCIpO1xyXG4vLyAgICAgICAgIHNldEFsbEVtcGxveWVlcyhyZXNwb25zZT8uZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJ1bmFibGUgdG8gZmV0Y2ggZW1wbG95ZWVcIik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaEVtcGxveWVlKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICAvLyBGb3JtYXQgc2FsYXJ5IHJvd3NcclxuLy8gICBjb25zdCBmb3JtYXRTYWxhcnlEYXRhID0gKHNhbGFyeUxpc3QpID0+IHtcclxuLy8gICAgIHJldHVybiBzYWxhcnlMaXN0Lm1hcCgocywgaW5kZXgpID0+IHtcclxuLy8gICAgICAgY29uc3QgYWRkVG90YWwgPSBBcnJheS5pc0FycmF5KHM/LmFkZGl0aW9uYWxfcGF5bWVudHMpXHJcbi8vICAgICAgICAgPyBzLmFkZGl0aW9uYWxfcGF5bWVudHMucmVkdWNlKChhY2MsIGN1cikgPT4gYWNjICsgKGN1ci52YWx1ZSB8fCAwKSwgMClcclxuLy8gICAgICAgICA6IDA7XHJcblxyXG4vLyAgICAgICBjb25zdCBkZWRUb3RhbCA9IEFycmF5LmlzQXJyYXkocz8uYWRkaXRpb25hbF9kZWR1Y3Rpb25zKVxyXG4vLyAgICAgICAgID8gcy5hZGRpdGlvbmFsX2RlZHVjdGlvbnMucmVkdWNlKFxyXG4vLyAgICAgICAgICAgICAoYWNjLCBjdXIpID0+IGFjYyArIChjdXIudmFsdWUgfHwgMCksXHJcbi8vICAgICAgICAgICAgIDBcclxuLy8gICAgICAgICAgIClcclxuLy8gICAgICAgICA6IDA7XHJcblxyXG4vLyAgICAgICBjb25zdCBhZGRMaXN0U3RyID0gQXJyYXkuaXNBcnJheShzPy5hZGRpdGlvbmFsX3BheW1lbnRzKVxyXG4vLyAgICAgICAgID8gcy5hZGRpdGlvbmFsX3BheW1lbnRzXHJcbi8vICAgICAgICAgICAgIC5tYXAoKGVsZSkgPT4gYCR7ZWxlLm5hbWV9OiR7ZWxlLnZhbHVlfWApXHJcbi8vICAgICAgICAgICAgIC5qb2luKFwiIHwgXCIpXHJcbi8vICAgICAgICAgOiBcIk4vQVwiO1xyXG5cclxuLy8gICAgICAgY29uc3QgZGVkTGlzdFN0ciA9IEFycmF5LmlzQXJyYXkocz8uYWRkaXRpb25hbF9kZWR1Y3Rpb25zKVxyXG4vLyAgICAgICAgID8gcy5hZGRpdGlvbmFsX2RlZHVjdGlvbnNcclxuLy8gICAgICAgICAgICAgLm1hcCgoZWxlKSA9PiBgJHtlbGUubmFtZX06JHtlbGUudmFsdWV9YClcclxuLy8gICAgICAgICAgICAgLmpvaW4oXCIgfCBcIilcclxuLy8gICAgICAgICA6IFwiTi9BXCI7XHJcblxyXG4vLyAgICAgICByZXR1cm4ge1xyXG4vLyAgICAgICAgIF9pZDogcz8uX2lkLFxyXG4vLyAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICBlbXBsb3llZUNvZGU6IHM/LmVtcGxveWVlX2lkPy5lbXBsb3llZUNvZGUgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICBlbXBsb3llZU5hbWU6IHM/LmVtcGxveWVlX2lkPy5uYW1lIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgZW1wbG95ZWVQaG9uZTogcz8uZW1wbG95ZWVfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgIGVtcGxveWVlU2FsYXJ5OiBzPy5lbXBsb3llZV9pZD8uc2FsYXJ5IHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgc2FsYXJ5TW9udGg6IHM/LnNhbGFyeV9tb250aCB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgIHNhbGFyeVllYXI6IHM/LnNhbGFyeV95ZWFyIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgdG90YWxTYWxhcnlQYXlhYmxlOiBzPy50b3RhbF9zYWxhcnlfcGF5YWJsZSB8fCAwLFxyXG4vLyAgICAgICAgIG5ldFBheWFibGU6IHM/Lm5ldF9wYXlhYmxlIHx8IDAsXHJcbi8vICAgICAgICAgcGFpZEFtb3VudDogcz8ucGFpZF9hbW91bnQgfHwgMCxcclxuLy8gICAgICAgICByZW1haW5pbmdCYWxhbmNlOiBzPy5yZW1haW5pbmdfYmFsYW5jZSB8fCAwLFxyXG4vLyAgICAgICAgIHBhaWREYXlzOiBzPy5wYWlkX2RheXMgfHwgMCxcclxuLy8gICAgICAgICBwYWlkRGF0ZTogcz8ucGF5X2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgIGFkZFBheW1lbnRzTGlzdDogYWRkTGlzdFN0cixcclxuLy8gICAgICAgICBkZWRQYXltZW50c0xpc3Q6IGRlZExpc3RTdHIsXHJcbi8vICAgICAgICAgYWRkUGF5bWVudHM6IGFkZFRvdGFsLFxyXG4vLyAgICAgICAgIGRlZFBheW1lbnRzOiBkZWRUb3RhbCxcclxuLy8gICAgICAgICBlYXJuaW5nQmFzaWM6IHM/LmVhcm5pbmdzPy5iYXNpYyB8fCAwLFxyXG4vLyAgICAgICAgIGVhcm5pbmdIcmE6IHM/LmVhcm5pbmdzPy5ocmEgfHwgMCxcclxuLy8gICAgICAgICBlYXJuaW5nVHJhdmVsQWxsb3dhbmNlOiBzPy5lYXJuaW5ncz8udHJhdmVsX2FsbG93YW5jZSB8fCAwLFxyXG4vLyAgICAgICAgIGVhcm5pbmdNZWRpY2FsQWxsb3dhbmNlOiBzPy5lYXJuaW5ncz8ubWVkaWNhbF9hbGxvd2FuY2UgfHwgMCxcclxuLy8gICAgICAgICBlYXJuaW5nQmVuaWZpdHM6IHM/LmVhcm5pbmdzPy5iYXNrZXRfb2ZfYmVuaWZpdHMgfHwgMCxcclxuLy8gICAgICAgICBlYXJuaW5nUGVyZm9ybWFuY2VCb251czogcz8uZWFybmluZ3M/LnBlcmZvcm1hbmNlX2JvbnVzIHx8IDAsXHJcbi8vICAgICAgICAgZWFybmluZ090aGVyczogcz8uZWFybmluZ3M/Lm90aGVyX2FsbG93YW5jZXMgfHwgMCxcclxuLy8gICAgICAgICBlYXJuaW5nQ29udmV5YW5jZTogcz8uZWFybmluZ3M/LmNvbnZleWFuY2UgfHwgMCxcclxuLy8gICAgICAgICBkZWR1Y3RJVDogcz8uZGVkdWN0aW9ucz8uaW5jb21lX3RheCB8fCAwLFxyXG4vLyAgICAgICAgIGRlZHVjdEVTSTogcz8uZGVkdWN0aW9ucz8uZXNpIHx8IDAsXHJcbi8vICAgICAgICAgZGVkdWN0RVBGOiBzPy5kZWR1Y3Rpb25zPy5lcGYgfHwgMCxcclxuLy8gICAgICAgICBkZWR1Y3RQVDogcz8uZGVkdWN0aW9ucz8ucHJvZmVzc2lvbmFsX3RheCB8fCAwLFxyXG4vLyAgICAgICAgIGRlZHVjdFNhbGFyeUFkdmFuY2U6IHM/LmRlZHVjdGlvbnM/LnNhbGFyeV9hZHZhbmNlIHx8IDAsXHJcbi8vICAgICAgICAgc2FsYXJ5UGF5bWVudE1ldGhvZDogcz8ucGF5bWVudF9tZXRob2QgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICBzdGF0dXM6IHM/LnN0YXR1cyB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICB9O1xyXG4vLyAgICAgfSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gU29ydCBzYWxhcnkgZGF0YSBieSBtb250aCBhbmQgeWVhclxyXG4vLyAgIGNvbnN0IHNvcnRTYWxhcnlEYXRhID0gKGRhdGEpID0+IHtcclxuLy8gICAgIGNvbnN0IG1vbnRoT3JkZXIgPSBbXHJcbi8vICAgICAgIFwiSmFudWFyeVwiLFxyXG4vLyAgICAgICBcIkZlYnJ1YXJ5XCIsXHJcbi8vICAgICAgIFwiTWFyY2hcIixcclxuLy8gICAgICAgXCJBcHJpbFwiLFxyXG4vLyAgICAgICBcIk1heVwiLFxyXG4vLyAgICAgICBcIkp1bmVcIixcclxuLy8gICAgICAgXCJKdWx5XCIsXHJcbi8vICAgICAgIFwiQXVndXN0XCIsXHJcbi8vICAgICAgIFwiU2VwdGVtYmVyXCIsXHJcbi8vICAgICAgIFwiT2N0b2JlclwiLFxyXG4vLyAgICAgICBcIk5vdmVtYmVyXCIsXHJcbi8vICAgICAgIFwiRGVjZW1iZXJcIixcclxuLy8gICAgIF07XHJcblxyXG4vLyAgICAgLy8gU29ydCBieSB5ZWFyICsgbW9udGggb3JkZXJcclxuLy8gICAgIHJldHVybiBkYXRhLnNvcnQoKGEsIGIpID0+IHtcclxuLy8gICAgICAgY29uc3QgeWVhckEgPSBOdW1iZXIoYS5zYWxhcnlZZWFyKTtcclxuLy8gICAgICAgY29uc3QgeWVhckIgPSBOdW1iZXIoYi5zYWxhcnlZZWFyKTtcclxuXHJcbi8vICAgICAgIGlmICh5ZWFyQSAhPT0geWVhckIpIHJldHVybiB5ZWFyQSAtIHllYXJCO1xyXG5cclxuLy8gICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICBtb250aE9yZGVyLmluZGV4T2YoYS5zYWxhcnlNb250aCkgLSBtb250aE9yZGVyLmluZGV4T2YoYi5zYWxhcnlNb250aClcclxuLy8gICAgICAgKTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIFNVTU1BUlkgQ0FMQ1VMQVRJT04gKEJhc2VkIG9uIGN1cnJlbnQgZmlsdGVyZWQgLyBmdWxsIGRhdGEpXHJcbi8vICAgY29uc3QgY2FsY3VsYXRlU3VtbWFyeSA9IChyb3dzKSA9PiB7XHJcbi8vICAgICBjb25zdCBzdW1tYXJ5RGF0YSA9IHtcclxuLy8gICAgICAgdG90YWxFc2k6IDAsXHJcbi8vICAgICAgIHRvdGFsRXBmOiAwLFxyXG4vLyAgICAgICB0b3RhbEl0OiAwLFxyXG4vLyAgICAgICB0b3RhbHB0OiAwLFxyXG4vLyAgICAgICB0b3RhbEFkZGl0aW9uYWxEZWR1Y3Rpb25zOiAwLFxyXG4vLyAgICAgICB0b3RhbFJlbWFpbmluZ0JhbGFuY2U6IDAsXHJcbi8vICAgICAgIGFkZFBheW1lbnRzTGlzdFN1bW1hcnk6IFwiXCIsXHJcbi8vICAgICAgIGRlZFBheW1lbnRzTGlzdFN1bW1hcnk6IFwiXCIsXHJcbi8vICAgICB9O1xyXG5cclxuLy8gICAgIGNvbnN0IGFkZExpc3RBcnIgPSBbXTtcclxuLy8gICAgIGNvbnN0IGRlZExpc3RBcnIgPSBbXTtcclxuXHJcbi8vICAgICByb3dzLmZvckVhY2goKHIpID0+IHtcclxuLy8gICAgICAgc3VtbWFyeURhdGEudG90YWxFc2kgKz0gTnVtYmVyKHIuZGVkdWN0RVNJKSB8fCAwO1xyXG4vLyAgICAgICBzdW1tYXJ5RGF0YS50b3RhbEVwZiArPSBOdW1iZXIoci5kZWR1Y3RFUEYpIHx8IDA7XHJcbi8vICAgICAgIHN1bW1hcnlEYXRhLnRvdGFsSXQgKz0gTnVtYmVyKHIuZGVkdWN0SVQpIHx8IDA7XHJcbi8vICAgICAgIHN1bW1hcnlEYXRhLnRvdGFscHQgKz0gTnVtYmVyKHIuZGVkdWN0UFQpIHx8IDA7XHJcbi8vICAgICAgIC8vICAgc3VtbWFyeURhdGEudG90YWxBZGRpdGlvbmFsRGVkdWN0aW9ucyArPSBOdW1iZXIoci5kZWRQYXltZW50cykgfHwgMDtcclxuLy8gICAgICAgLy8gICBzdW1tYXJ5RGF0YS50b3RhbFJlbWFpbmluZ0JhbGFuY2UgKz0gTnVtYmVyKHIucmVtYWluaW5nQmFsYW5jZSk7XHJcblxyXG4vLyAgICAgICAvLyAgIGlmIChyLmFkZFBheW1lbnRzTGlzdCAmJiByLmFkZFBheW1lbnRzTGlzdCAhPT0gXCJOL0FcIilcclxuLy8gICAgICAgLy8gICAgIGFkZExpc3RBcnIucHVzaChyLmFkZFBheW1lbnRzTGlzdCk7XHJcbi8vICAgICAgIC8vICAgaWYgKHIuZGVkUGF5bWVudHNMaXN0ICYmIHIuZGVkUGF5bWVudHNMaXN0ICE9PSBcIk4vQVwiKVxyXG4vLyAgICAgICAvLyAgICAgZGVkTGlzdEFyci5wdXNoKHIuZGVkUGF5bWVudHNMaXN0KTtcclxuLy8gICAgIH0pO1xyXG5cclxuLy8gICAgIC8vIHN1bW1hcnlEYXRhLmFkZFBheW1lbnRzTGlzdFN1bW1hcnkgPSBhZGRMaXN0QXJyLmpvaW4oXCIgfCBcIik7XHJcbi8vICAgICAvLyBzdW1tYXJ5RGF0YS5kZWRQYXltZW50c0xpc3RTdW1tYXJ5ID0gZGVkTGlzdEFyci5qb2luKFwiIHwgXCIpO1xyXG5cclxuLy8gICAgIHNldFN1bW1hcnkoc3VtbWFyeURhdGEpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIEZFVENIIEFMTCBTQUxBUklFU1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEVtcGxveWVlQWxsU2FsYXJpZXMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9zYWxhcnktcGF5bWVudC9hbGxcIik7XHJcbi8vICAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0U2FsYXJ5RGF0YShyZXNwb25zZT8uZGF0YT8uZGF0YSB8fCBbXSk7XHJcbi8vICAgICAgICAgLy8gQXBwbHkgc29ydGluZyBiZWZvcmUgc2V0dGluZyB0aGUgZGF0YVxyXG4vLyAgICAgICAgIGNvbnN0IHNvcnRlZERhdGEgPSBzb3J0U2FsYXJ5RGF0YShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgICAgIHNldEFsbFNhbGFyeVRhYmxlKHNvcnRlZERhdGEpO1xyXG4vLyAgICAgICAgIGNhbGN1bGF0ZVN1bW1hcnkoc29ydGVkRGF0YSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcInVuYWJsZSB0byBmZXRjaCBFbXBsb3llZSBTYWxhcnkgUGF5bWVudFwiKTtcclxuLy8gICAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG4vLyAgICAgZmV0Y2hFbXBsb3llZUFsbFNhbGFyaWVzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICAvLyBGRVRDSCBGSUxURVJFRCBEQVRBXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoQWxsRW1wbG95ZWVEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuLy8gICAgICAgICBsZXQgcXVlcnkgPSBbXTtcclxuLy8gICAgICAgICBpZiAoc2VsZWN0ZWRFbXBsb3llZSkgcXVlcnkucHVzaChgZW1wbG95ZWVfaWQ9JHtzZWxlY3RlZEVtcGxveWVlfWApO1xyXG4vLyAgICAgICAgIGlmIChzZWxlY3RlZE1vbnRoWWVhcikge1xyXG4vLyAgICAgICAgICAgcXVlcnkucHVzaChgbW9udGg9JHtzZWxlY3RlZE1vbnRoWWVhci5tb250aH1gKTtcclxuLy8gICAgICAgICAgIHF1ZXJ5LnB1c2goYHllYXI9JHtzZWxlY3RlZE1vbnRoWWVhci55ZWFyfWApO1xyXG4vLyAgICAgICAgIH1cclxuXHJcbi8vICAgICAgICAgY29uc3QgdXJsID0gYC9zYWxhcnktcGF5bWVudC9yZXBvcnQ/JHtxdWVyeS5qb2luKFwiJlwiKX1gO1xyXG4vLyAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQodXJsKTtcclxuXHJcbi8vICAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0U2FsYXJ5RGF0YShyZXM/LmRhdGE/LmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICAgIC8vIEFwcGx5IHNvcnRpbmcgYmVmb3JlIHNldHRpbmcgdGhlIGRhdGFcclxuLy8gICAgICAgICBjb25zdCBzb3J0ZWREYXRhID0gc29ydFNhbGFyeURhdGEoZm9ybWF0dGVkKTtcclxuLy8gICAgICAgICBzZXRBbGxTYWxhcnlUYWJsZShzb3J0ZWREYXRhKTtcclxuLy8gICAgICAgICBjYWxjdWxhdGVTdW1tYXJ5KHNvcnRlZERhdGEpO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmxvZyhcInVuYWJsZSB0byBmZXRjaCBmaWx0ZXJlZCBlbXBsb3llZSBkYXRhXCIpO1xyXG4vLyAgICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcblxyXG4vLyAgICAgZmV0Y2hBbGxFbXBsb3llZURhdGEoKTtcclxuLy8gICB9LCBbc2VsZWN0ZWRFbXBsb3llZSwgc2VsZWN0ZWRNb250aFllYXJdKTtcclxuXHJcbi8vICAgLy8gSEFORExFIE1PTlRIIFBJQ0tFUlxyXG4vLyAgIGNvbnN0IGhhbmRsZU1vbnRoUGljayA9ICh2YWx1ZSkgPT4ge1xyXG4vLyAgICAgaWYgKCF2YWx1ZSkgcmV0dXJuIHNldFNlbGVjdGVkTW9udGhZZWFyKG51bGwpO1xyXG4vLyAgICAgY29uc3QgbW9udGhJbmRleCA9IHZhbHVlLm1vbnRoKCk7XHJcbi8vICAgICBjb25zdCB5ZWFyID0gdmFsdWUueWVhcigpO1xyXG5cclxuLy8gICAgIGNvbnN0IG1vbnRoTmFtZXMgPSBbXHJcbi8vICAgICAgIFwiSmFudWFyeVwiLFxyXG4vLyAgICAgICBcIkZlYnJ1YXJ5XCIsXHJcbi8vICAgICAgIFwiTWFyY2hcIixcclxuLy8gICAgICAgXCJBcHJpbFwiLFxyXG4vLyAgICAgICBcIk1heVwiLFxyXG4vLyAgICAgICBcIkp1bmVcIixcclxuLy8gICAgICAgXCJKdWx5XCIsXHJcbi8vICAgICAgIFwiQXVndXN0XCIsXHJcbi8vICAgICAgIFwiU2VwdGVtYmVyXCIsXHJcbi8vICAgICAgIFwiT2N0b2JlclwiLFxyXG4vLyAgICAgICBcIk5vdmVtYmVyXCIsXHJcbi8vICAgICAgIFwiRGVjZW1iZXJcIixcclxuLy8gICAgIF07XHJcblxyXG4vLyAgICAgc2V0U2VsZWN0ZWRNb250aFllYXIoe1xyXG4vLyAgICAgICBtb250aDogbW9udGhOYW1lc1ttb250aEluZGV4XSxcclxuLy8gICAgICAgeWVhcixcclxuLy8gICAgIH0pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVJlc2V0ID0gKCkgPT4ge1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRFbXBsb3llZShudWxsKTtcclxuLy8gICAgIHNldFNlbGVjdGVkTW9udGhZZWFyKG51bGwpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGNvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJzbE5vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZW1wbG95ZWVOYW1lXCIsIGhlYWRlcjogXCJFbXBsb3llZSBOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImVtcGxveWVlQ29kZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgSURcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZW1wbG95ZWVQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicGFpZERhdGVcIiwgaGVhZGVyOiBcIlBheSBEYXRlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInNhbGFyeU1vbnRoXCIsIGhlYWRlcjogXCJNb250aFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJzYWxhcnlZZWFyXCIsIGhlYWRlcjogXCJZZWFyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlZHVjdElUXCIsIGhlYWRlcjogXCJJbmNvbWUgVGF4XCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlZHVjdEVTSVwiLCBoZWFkZXI6IFwiRVNJXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlZHVjdEVQRlwiLCBoZWFkZXI6IFwiRVBGXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlZHVjdFBUXCIsIGhlYWRlcjogXCJQcm9mZXNzaW9uYWwgVGF4XCIgfSxcclxuLy8gICAgIC8vIHsga2V5OiBcImVtcGxveWVlU2FsYXJ5XCIsIGhlYWRlcjogXCJTYWxhcnlcIiB9LFxyXG5cclxuLy8gICAgIC8vICB7IGtleTogXCJuZXRQYXlhYmxlXCIsIGhlYWRlcjogXCJOZXQgUGF5YWJsZVwiIH0sXHJcbi8vICAgICAvLyAgeyBrZXk6IFwicGFpZEFtb3VudFwiLCBoZWFkZXI6IFwiUGFpZCBBbW91bnRcIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGNvbnN0IGFsbENvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJzbE5vXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJlbXBsb3llZUNvZGVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIElEXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImVtcGxveWVlTmFtZVwiLCBoZWFkZXI6IFwiTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJlbXBsb3llZVBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZW1wbG95ZWVTYWxhcnlcIiwgaGVhZGVyOiBcIlNhbGFyeVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJzYWxhcnlNb250aFwiLCBoZWFkZXI6IFwiTW9udGhcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwic2FsYXJ5WWVhclwiLCBoZWFkZXI6IFwiWWVhclwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ0b3RhbFNhbGFyeVBheWFibGVcIiwgaGVhZGVyOiBcIlRvdGFsIFNhbGFyeSBQYXlhYmxlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcIm5ldFBheWFibGVcIiwgaGVhZGVyOiBcIk5ldCBQYXlhYmxlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInBhaWRBbW91bnRcIiwgaGVhZGVyOiBcIlBhaWQgQW1vdW50XCIgfSxcclxuLy8gICAgIHsga2V5OiBcInJlbWFpbmluZ0JhbGFuY2VcIiwgaGVhZGVyOiBcIlJlbWFpbmluZyBCYWxhbmNlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInBhaWREYXlzXCIsIGhlYWRlcjogXCJQYWlkIERheXNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicGFpZERhdGVcIiwgaGVhZGVyOiBcIlBhaWQgRGF0ZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhZGRQYXltZW50c1wiLCBoZWFkZXI6IFwiQWRkaXRpb25hbCBQYXltZW50c1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJkZWRQYXltZW50c1wiLCBoZWFkZXI6IFwiRGVkdWN0aW9uIFBheW1lbnRzXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImVhcm5pbmdCYXNpY1wiLCBoZWFkZXI6IFwiQmFzaWNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZWFybmluZ0hyYVwiLCBoZWFkZXI6IFwiSFJBXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImVhcm5pbmdUcmF2ZWxBbGxvd2FuY2VcIiwgaGVhZGVyOiBcIlRyYXZlbCBBbGxvd2FuY2VcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZWFybmluZ01lZGljYWxBbGxvd2FuY2VcIiwgaGVhZGVyOiBcIk1lZGljYWwgQWxsb3dhbmNlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImVhcm5pbmdCZW5pZml0c1wiLCBoZWFkZXI6IFwiUGVyZm9ybWFuY2UgQmVuaWZpdHNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZWFybmluZ090aGVyc1wiLCBoZWFkZXI6IFwiT3RoZXIgQWxsb3dhbmNlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImVhcm5pbmdDb252ZXlhbmNlXCIsIGhlYWRlcjogXCJDb252ZXlhbmNlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlZHVjdElUXCIsIGhlYWRlcjogXCJJbmNvbWUgVGF4XCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlZHVjdEVTSVwiLCBoZWFkZXI6IFwiRVNJXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlZHVjdEVQRlwiLCBoZWFkZXI6IFwiRVBGXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlZHVjdFBUXCIsIGhlYWRlcjogXCJQcm9mZXNzaW9uYWwgVGF4XCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRlZHVjdFNhbGFyeUFkdmFuY2VcIiwgaGVhZGVyOiBcIlNhbGFyeUFkdmFuY2VcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwic2FsYXJ5UGF5bWVudE1ldGhvZFwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICBjb25zdCBwcmludEhlYWRlcktleXMgPSBbXHJcbi8vICAgICBcIkVtcGxveWVlXCIsXHJcbi8vICAgICBcIk1vbnRoXCIsXHJcbi8vICAgICBcIlllYXJcIixcclxuLy8gICAgIFwiVG90YWwgRVNJXCIsXHJcbi8vICAgICBcIlRvdGFsIFBGXCIsXHJcbi8vICAgICBcIlRvdGFsIElUXCIsXHJcbi8vICAgICBcIlRvdGFsIFBUXCIsXHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3QgcHJpbnRIZWFkZXJWYWx1ZXMgPSBbXHJcbi8vICAgICBzZWxlY3RlZEVtcGxveWVlXHJcbi8vICAgICAgID8gYWxsRW1wbG95ZWVzLmZpbmQoKGUpID0+IGUuX2lkID09PSBzZWxlY3RlZEVtcGxveWVlKT8ubmFtZSB8fCBcIuKAlFwiXHJcbi8vICAgICAgIDogXCJBbGwgRW1wbG95ZWVzXCIsXHJcblxyXG4vLyAgICAgc2VsZWN0ZWRNb250aFllYXI/Lm1vbnRoIHx8IFwi4oCUXCIsXHJcbi8vICAgICBzZWxlY3RlZE1vbnRoWWVhcj8ueWVhciB8fCBcIuKAlFwiLFxyXG5cclxuLy8gICAgIGDigrkke3N1bW1hcnkudG90YWxFc2kudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4vLyAgICAgYOKCuSR7c3VtbWFyeS50b3RhbEVwZi50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbi8vICAgICBzdW1tYXJ5LnRvdGFsSXQsXHJcbi8vICAgICBg4oK5JHtzdW1tYXJ5LnRvdGFscHQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4vLyAgICAgYOKCuSR7c3VtbWFyeS50b3RhbEFkZGl0aW9uYWxEZWR1Y3Rpb25zLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuLy8gICAgIGDigrkke3N1bW1hcnkudG90YWxSZW1haW5pbmdCYWxhbmNlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuLy8gICBdO1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlblwiPlxyXG4vLyAgICAgICA8TmF2YmFyIC8+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4vLyAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC0yeGwgbWItNFwiPlJlcG9ydHMgLSBTYWxhcnkgUmVwb3J0PC9oMT5cclxuXHJcbi8vICAgICAgICAgey8qIEZJTFRFUlMgKi99XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IG1iLTYgaXRlbXMtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuLy8gICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDMwMCB9fVxyXG4vLyAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZX1cclxuLy8gICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRW1wbG95ZWVcIlxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRTZWxlY3RlZEVtcGxveWVlKHZhbHVlKX1cclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAge2FsbEVtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9IHwge2VtcC5waG9uZV9udW1iZXJ9XHJcbi8vICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgPC9TZWxlY3Q+XHJcblxyXG4vLyAgICAgICAgICAgPE1vbnRoUGlja2VyXHJcbi8vICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAyNTAgfX1cclxuLy8gICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTW9udGhcIlxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlTW9udGhQaWNrfVxyXG4vLyAgICAgICAgICAgLz5cclxuXHJcbi8vICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlc2V0fVxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctdmlvbGV0LTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWRcIlxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICBSZXNldFxyXG4vLyAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIHsvKiBTVU1NQVJZIEJPWCAqL31cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgYmctZ3JheS0xMDAgcC00IG1iLTUgcm91bmRlZFwiPlxyXG4vLyAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgPGI+VG90YWwgRVNJIDo8L2I+IOKCuXtzdW1tYXJ5LnRvdGFsRXNpfVxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICA8Yj5Ub3RhbCBQRiA6PC9iPiDigrl7c3VtbWFyeS50b3RhbEVwZn1cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgPGI+VG90YWwgSW5jb21lIFRheCA6PC9iPiB7c3VtbWFyeS50b3RhbEl0fVxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICA8Yj5Ub3RhbCBQcm9mZXNzaW9uYWwgVGF4IDo8L2I+IOKCuXtzdW1tYXJ5LnRvdGFscHR9XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAge2lzTG9hZGluZyA/IChcclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0xMFwiPlxyXG4vLyAgICAgICAgICAgICA8U3BpbiBzaXplPVwibGFyZ2VcIiAvPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgIDxEYXRhVGFibGVcclxuLy8gICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuLy8gICAgICAgICAgICAgZGF0YT17YWxsU2FsYXJ5VGFibGV9XHJcbi8vICAgICAgICAgICAgIGV4cG9ydENvbHM9e2NvbHVtbnN9XHJcbi8vICAgICAgICAgICAgIGlzRXhwb3J0RW5hYmxlZD17dHJ1ZX1cclxuLy8gICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiRW1wbG95ZWUgU2FsYXJ5IFJlcG9ydFwiXHJcbi8vICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17cHJpbnRIZWFkZXJLZXlzfVxyXG4vLyAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17cHJpbnRIZWFkZXJWYWx1ZXN9XHJcbi8vICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJFbXBsb3llZVNhbGFyeVJlcG9ydC5jc3ZcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICApfVxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG5cclxuXHJcblxyXG5jb25zdCBFbXBsb3llZURlZHVjdGlvblJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbYWxsRW1wbG95ZWVTYWxhcnksIHNldEFsbEVtcGxveWVlU2FsYXJ5XSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWxsRW1wbG95ZWVzLCBzZXRBbGxFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthbGxTYWxhcnlUYWJsZSwgc2V0QWxsU2FsYXJ5VGFibGVdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsRXNpOiAwLFxyXG4gICAgdG90YWxFcGY6IDAsXHJcbiAgICB0b3RhbEl0OiAwLFxyXG4gICAgdG90YWxwdDogMCxcclxuICAgIHRvdGFsQWRkaXRpb25hbERlZHVjdGlvbnM6IDAsXHJcbiAgICBhZGRQYXltZW50c0xpc3RTdW1tYXJ5OiBcIlwiLFxyXG4gICAgZGVkUGF5bWVudHNMaXN0U3VtbWFyeTogXCJcIixcclxuICAgIHRvdGFsUmVtYWluaW5nQmFsYW5jZTogMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZSwgc2V0U2VsZWN0ZWRFbXBsb3llZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRNb250aFllYXIsIHNldFNlbGVjdGVkTW9udGhZZWFyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICAvLyDinIUgSGVscGVyIHRvIHNhbml0aXplIHN0cmluZyBhbW91bnRzIHRvIG51bWJlcnMgZm9yIHdvcmQgY29udmVyc2lvblxyXG4gIGNvbnN0IHBhcnNlQW1vdW50ID0gKHZhbCkgPT5cclxuICAgIHBhcnNlRmxvYXQodmFsPy50b1N0cmluZygpLnJlcGxhY2UoL1teMC05Li1dKy9nLCBcIlwiKSkgfHwgMDtcclxuXHJcbiAgLy8gRmV0Y2ggYWxsIGVtcGxveWVlc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXQtZW1wbG95ZWVcIik7XHJcbiAgICAgICAgc2V0QWxsRW1wbG95ZWVzKHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZSB8fCBbXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcInVuYWJsZSB0byBmZXRjaCBlbXBsb3llZVwiKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW1wbG95ZWUoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIEZvcm1hdCBzYWxhcnkgcm93c1xyXG4gIGNvbnN0IGZvcm1hdFNhbGFyeURhdGEgPSAoc2FsYXJ5TGlzdCkgPT4ge1xyXG4gICAgcmV0dXJuIHNhbGFyeUxpc3QubWFwKChzLCBpbmRleCkgPT4ge1xyXG4gICAgICBjb25zdCBhZGRUb3RhbCA9IEFycmF5LmlzQXJyYXkocz8uYWRkaXRpb25hbF9wYXltZW50cylcclxuICAgICAgICA/IHMuYWRkaXRpb25hbF9wYXltZW50cy5yZWR1Y2UoKGFjYywgY3VyKSA9PiBhY2MgKyAoY3VyLnZhbHVlIHx8IDApLCAwKVxyXG4gICAgICAgIDogMDtcclxuXHJcbiAgICAgIGNvbnN0IGRlZFRvdGFsID0gQXJyYXkuaXNBcnJheShzPy5hZGRpdGlvbmFsX2RlZHVjdGlvbnMpXHJcbiAgICAgICAgPyBzLmFkZGl0aW9uYWxfZGVkdWN0aW9ucy5yZWR1Y2UoXHJcbiAgICAgICAgICAgIChhY2MsIGN1cikgPT4gYWNjICsgKGN1ci52YWx1ZSB8fCAwKSxcclxuICAgICAgICAgICAgMFxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIDogMDtcclxuXHJcbiAgICAgIGNvbnN0IGFkZExpc3RTdHIgPSBBcnJheS5pc0FycmF5KHM/LmFkZGl0aW9uYWxfcGF5bWVudHMpXHJcbiAgICAgICAgPyBzLmFkZGl0aW9uYWxfcGF5bWVudHNcclxuICAgICAgICAgICAgLm1hcCgoZWxlKSA9PiBgJHtlbGUubmFtZX06JHtlbGUudmFsdWV9YClcclxuICAgICAgICAgICAgLmpvaW4oXCIgfCBcIilcclxuICAgICAgICA6IFwiTi9BXCI7XHJcblxyXG4gICAgICBjb25zdCBkZWRMaXN0U3RyID0gQXJyYXkuaXNBcnJheShzPy5hZGRpdGlvbmFsX2RlZHVjdGlvbnMpXHJcbiAgICAgICAgPyBzLmFkZGl0aW9uYWxfZGVkdWN0aW9uc1xyXG4gICAgICAgICAgICAubWFwKChlbGUpID0+IGAke2VsZS5uYW1lfToke2VsZS52YWx1ZX1gKVxyXG4gICAgICAgICAgICAuam9pbihcIiB8IFwiKVxyXG4gICAgICAgIDogXCJOL0FcIjtcclxuXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgX2lkOiBzPy5faWQsXHJcbiAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4gICAgICAgIGVtcGxveWVlQ29kZTogcz8uZW1wbG95ZWVfaWQ/LmVtcGxveWVlQ29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIGVtcGxveWVlTmFtZTogcz8uZW1wbG95ZWVfaWQ/Lm5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICBlbXBsb3llZVBob25lOiBzPy5lbXBsb3llZV9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgZW1wbG95ZWVTYWxhcnk6IHM/LmVtcGxveWVlX2lkPy5zYWxhcnkgfHwgXCJOL0FcIixcclxuICAgICAgICBzYWxhcnlNb250aDogcz8uc2FsYXJ5X21vbnRoIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgc2FsYXJ5WWVhcjogcz8uc2FsYXJ5X3llYXIgfHwgXCJOL0FcIixcclxuICAgICAgICB0b3RhbFNhbGFyeVBheWFibGU6IHM/LnRvdGFsX3NhbGFyeV9wYXlhYmxlIHx8IDAsXHJcbiAgICAgICAgbmV0UGF5YWJsZTogcz8ubmV0X3BheWFibGUgfHwgMCxcclxuICAgICAgICBwYWlkQW1vdW50OiBzPy5wYWlkX2Ftb3VudCB8fCAwLFxyXG4gICAgICAgIHJlbWFpbmluZ0JhbGFuY2U6IHM/LnJlbWFpbmluZ19iYWxhbmNlIHx8IDAsXHJcbiAgICAgICAgcGFpZERheXM6IHM/LnBhaWRfZGF5cyB8fCAwLFxyXG4gICAgICAgIHBhaWREYXRlOiBzPy5wYXlfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgYWRkUGF5bWVudHNMaXN0OiBhZGRMaXN0U3RyLFxyXG4gICAgICAgIGRlZFBheW1lbnRzTGlzdDogZGVkTGlzdFN0cixcclxuICAgICAgICBhZGRQYXltZW50czogYWRkVG90YWwsXHJcbiAgICAgICAgZGVkUGF5bWVudHM6IGRlZFRvdGFsLFxyXG4gICAgICAgIGVhcm5pbmdCYXNpYzogcz8uZWFybmluZ3M/LmJhc2ljIHx8IDAsXHJcbiAgICAgICAgZWFybmluZ0hyYTogcz8uZWFybmluZ3M/LmhyYSB8fCAwLFxyXG4gICAgICAgIGVhcm5pbmdUcmF2ZWxBbGxvd2FuY2U6IHM/LmVhcm5pbmdzPy50cmF2ZWxfYWxsb3dhbmNlIHx8IDAsXHJcbiAgICAgICAgZWFybmluZ01lZGljYWxBbGxvd2FuY2U6IHM/LmVhcm5pbmdzPy5tZWRpY2FsX2FsbG93YW5jZSB8fCAwLFxyXG4gICAgICAgIGVhcm5pbmdCZW5pZml0czogcz8uZWFybmluZ3M/LmJhc2tldF9vZl9iZW5pZml0cyB8fCAwLFxyXG4gICAgICAgIGVhcm5pbmdQZXJmb3JtYW5jZUJvbnVzOiBzPy5lYXJuaW5ncz8ucGVyZm9ybWFuY2VfYm9udXMgfHwgMCxcclxuICAgICAgICBlYXJuaW5nT3RoZXJzOiBzPy5lYXJuaW5ncz8ub3RoZXJfYWxsb3dhbmNlcyB8fCAwLFxyXG4gICAgICAgIGVhcm5pbmdDb252ZXlhbmNlOiBzPy5lYXJuaW5ncz8uY29udmV5YW5jZSB8fCAwLFxyXG4gICAgICAgIGRlZHVjdElUOiBzPy5kZWR1Y3Rpb25zPy5pbmNvbWVfdGF4IHx8IDAsXHJcbiAgICAgICAgZGVkdWN0RVNJOiBzPy5kZWR1Y3Rpb25zPy5lc2kgfHwgMCxcclxuICAgICAgICBkZWR1Y3RFUEY6IHM/LmRlZHVjdGlvbnM/LmVwZiB8fCAwLFxyXG4gICAgICAgIGRlZHVjdFBUOiBzPy5kZWR1Y3Rpb25zPy5wcm9mZXNzaW9uYWxfdGF4IHx8IDAsXHJcbiAgICAgICAgZGVkdWN0U2FsYXJ5QWR2YW5jZTogcz8uZGVkdWN0aW9ucz8uc2FsYXJ5X2FkdmFuY2UgfHwgMCxcclxuICAgICAgICBzYWxhcnlQYXltZW50TWV0aG9kOiBzPy5wYXltZW50X21ldGhvZCB8fCBcIk4vQVwiLFxyXG4gICAgICAgIHN0YXR1czogcz8uc3RhdHVzIHx8IFwiTi9BXCIsXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICAvLyBTb3J0IHNhbGFyeSBkYXRhIGJ5IG1vbnRoIGFuZCB5ZWFyXHJcbiAgY29uc3Qgc29ydFNhbGFyeURhdGEgPSAoZGF0YSkgPT4ge1xyXG4gICAgY29uc3QgbW9udGhPcmRlciA9IFtcclxuICAgICAgXCJKYW51YXJ5XCIsXHJcbiAgICAgIFwiRmVicnVhcnlcIixcclxuICAgICAgXCJNYXJjaFwiLFxyXG4gICAgICBcIkFwcmlsXCIsXHJcbiAgICAgIFwiTWF5XCIsXHJcbiAgICAgIFwiSnVuZVwiLFxyXG4gICAgICBcIkp1bHlcIixcclxuICAgICAgXCJBdWd1c3RcIixcclxuICAgICAgXCJTZXB0ZW1iZXJcIixcclxuICAgICAgXCJPY3RvYmVyXCIsXHJcbiAgICAgIFwiTm92ZW1iZXJcIixcclxuICAgICAgXCJEZWNlbWJlclwiLFxyXG4gICAgXTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5zb3J0KChhLCBiKSA9PiB7XHJcbiAgICAgIGNvbnN0IHllYXJBID0gTnVtYmVyKGEuc2FsYXJ5WWVhcik7XHJcbiAgICAgIGNvbnN0IHllYXJCID0gTnVtYmVyKGIuc2FsYXJ5WWVhcik7XHJcbiAgICAgIGlmICh5ZWFyQSAhPT0geWVhckIpIHJldHVybiB5ZWFyQSAtIHllYXJCO1xyXG4gICAgICByZXR1cm4gbW9udGhPcmRlci5pbmRleE9mKGEuc2FsYXJ5TW9udGgpIC0gbW9udGhPcmRlci5pbmRleE9mKGIuc2FsYXJ5TW9udGgpO1xyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gU1VNTUFSWSBDQUxDVUxBVElPTlxyXG4gIGNvbnN0IGNhbGN1bGF0ZVN1bW1hcnkgPSAocm93cykgPT4ge1xyXG4gICAgY29uc3Qgc3VtbWFyeURhdGEgPSB7XHJcbiAgICAgIHRvdGFsRXNpOiAwLFxyXG4gICAgICB0b3RhbEVwZjogMCxcclxuICAgICAgdG90YWxJdDogMCxcclxuICAgICAgdG90YWxwdDogMCxcclxuICAgICAgdG90YWxBZGRpdGlvbmFsRGVkdWN0aW9uczogMCxcclxuICAgICAgdG90YWxSZW1haW5pbmdCYWxhbmNlOiAwLFxyXG4gICAgICBhZGRQYXltZW50c0xpc3RTdW1tYXJ5OiBcIlwiLFxyXG4gICAgICBkZWRQYXltZW50c0xpc3RTdW1tYXJ5OiBcIlwiLFxyXG4gICAgfTtcclxuXHJcbiAgICByb3dzLmZvckVhY2goKHIpID0+IHtcclxuICAgICAgc3VtbWFyeURhdGEudG90YWxFc2kgKz0gTnVtYmVyKHIuZGVkdWN0RVNJKSB8fCAwO1xyXG4gICAgICBzdW1tYXJ5RGF0YS50b3RhbEVwZiArPSBOdW1iZXIoci5kZWR1Y3RFUEYpIHx8IDA7XHJcbiAgICAgIHN1bW1hcnlEYXRhLnRvdGFsSXQgKz0gTnVtYmVyKHIuZGVkdWN0SVQpIHx8IDA7XHJcbiAgICAgIHN1bW1hcnlEYXRhLnRvdGFscHQgKz0gTnVtYmVyKHIuZGVkdWN0UFQpIHx8IDA7XHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRTdW1tYXJ5KHN1bW1hcnlEYXRhKTtcclxuICB9O1xyXG5cclxuICAvLyBGRVRDSCBBTEwgU0FMQVJJRVNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZUFsbFNhbGFyaWVzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvc2FsYXJ5LXBheW1lbnQvYWxsXCIpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdFNhbGFyeURhdGEocmVzcG9uc2U/LmRhdGE/LmRhdGEgfHwgW10pO1xyXG4gICAgICAgIGNvbnN0IHNvcnRlZERhdGEgPSBzb3J0U2FsYXJ5RGF0YShmb3JtYXR0ZWQpO1xyXG4gICAgICAgIHNldEFsbFNhbGFyeVRhYmxlKHNvcnRlZERhdGEpO1xyXG4gICAgICAgIGNhbGN1bGF0ZVN1bW1hcnkoc29ydGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcInVuYWJsZSB0byBmZXRjaCBFbXBsb3llZSBTYWxhcnkgUGF5bWVudFwiKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hFbXBsb3llZUFsbFNhbGFyaWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBGRVRDSCBGSUxURVJFRCBEQVRBXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWxsRW1wbG95ZWVEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBsZXQgcXVlcnkgPSBbXTtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRFbXBsb3llZSkgcXVlcnkucHVzaChgZW1wbG95ZWVfaWQ9JHtzZWxlY3RlZEVtcGxveWVlfWApO1xyXG4gICAgICAgIGlmIChzZWxlY3RlZE1vbnRoWWVhcikge1xyXG4gICAgICAgICAgcXVlcnkucHVzaChgbW9udGg9JHtzZWxlY3RlZE1vbnRoWWVhci5tb250aH1gKTtcclxuICAgICAgICAgIHF1ZXJ5LnB1c2goYHllYXI9JHtzZWxlY3RlZE1vbnRoWWVhci55ZWFyfWApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgdXJsID0gYC9zYWxhcnktcGF5bWVudC9yZXBvcnQ/JHtxdWVyeS5qb2luKFwiJlwiKX1gO1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQodXJsKTtcclxuXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0U2FsYXJ5RGF0YShyZXM/LmRhdGE/LmRhdGEgfHwgW10pO1xyXG4gICAgICAgIGNvbnN0IHNvcnRlZERhdGEgPSBzb3J0U2FsYXJ5RGF0YShmb3JtYXR0ZWQpO1xyXG4gICAgICAgIHNldEFsbFNhbGFyeVRhYmxlKHNvcnRlZERhdGEpO1xyXG4gICAgICAgIGNhbGN1bGF0ZVN1bW1hcnkoc29ydGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwidW5hYmxlIHRvIGZldGNoIGZpbHRlcmVkIGVtcGxveWVlIGRhdGFcIik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaEFsbEVtcGxveWVlRGF0YSgpO1xyXG4gIH0sIFtzZWxlY3RlZEVtcGxveWVlLCBzZWxlY3RlZE1vbnRoWWVhcl0pO1xyXG5cclxuICAvLyBIQU5ETEUgTU9OVEggUElDS0VSXHJcbiAgY29uc3QgaGFuZGxlTW9udGhQaWNrID0gKHZhbHVlKSA9PiB7XHJcbiAgICBpZiAoIXZhbHVlKSByZXR1cm4gc2V0U2VsZWN0ZWRNb250aFllYXIobnVsbCk7XHJcbiAgICBjb25zdCBtb250aEluZGV4ID0gdmFsdWUubW9udGgoKTtcclxuICAgIGNvbnN0IHllYXIgPSB2YWx1ZS55ZWFyKCk7XHJcblxyXG4gICAgY29uc3QgbW9udGhOYW1lcyA9IFtcclxuICAgICAgXCJKYW51YXJ5XCIsXHJcbiAgICAgIFwiRmVicnVhcnlcIixcclxuICAgICAgXCJNYXJjaFwiLFxyXG4gICAgICBcIkFwcmlsXCIsXHJcbiAgICAgIFwiTWF5XCIsXHJcbiAgICAgIFwiSnVuZVwiLFxyXG4gICAgICBcIkp1bHlcIixcclxuICAgICAgXCJBdWd1c3RcIixcclxuICAgICAgXCJTZXB0ZW1iZXJcIixcclxuICAgICAgXCJPY3RvYmVyXCIsXHJcbiAgICAgIFwiTm92ZW1iZXJcIixcclxuICAgICAgXCJEZWNlbWJlclwiLFxyXG4gICAgXTtcclxuXHJcbiAgICBzZXRTZWxlY3RlZE1vbnRoWWVhcih7XHJcbiAgICAgIG1vbnRoOiBtb250aE5hbWVzW21vbnRoSW5kZXhdLFxyXG4gICAgICB5ZWFyLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVzZXQgPSAoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEVtcGxveWVlKG51bGwpO1xyXG4gICAgc2V0U2VsZWN0ZWRNb250aFllYXIobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsTm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZU5hbWVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW1wbG95ZWVDb2RlXCIsIGhlYWRlcjogXCJFbXBsb3llZSBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZVBob25lXCIsIGhlYWRlcjogXCJQaG9uZVwiIH0sXHJcbiAgICB7IGtleTogXCJwYWlkRGF0ZVwiLCBoZWFkZXI6IFwiUGF5IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwic2FsYXJ5TW9udGhcIiwgaGVhZGVyOiBcIk1vbnRoXCIgfSxcclxuICAgIHsga2V5OiBcInNhbGFyeVllYXJcIiwgaGVhZGVyOiBcIlllYXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGVkdWN0SVRcIiwgaGVhZGVyOiBcIkluY29tZSBUYXhcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGVkdWN0RVNJXCIsIGhlYWRlcjogXCJFU0lcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGVkdWN0RVBGXCIsIGhlYWRlcjogXCJFUEZcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGVkdWN0UFRcIiwgaGVhZGVyOiBcIlByb2Zlc3Npb25hbCBUYXhcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHByaW50SGVhZGVyS2V5cyA9IFtcclxuICAgIFwiRW1wbG95ZWVcIixcclxuICAgIFwiTW9udGhcIixcclxuICAgIFwiWWVhclwiLFxyXG4gICAgXCJUb3RhbCBFU0lcIixcclxuICAgIFwiVG90YWwgUEZcIixcclxuICAgIFwiVG90YWwgSVRcIixcclxuICAgIFwiVG90YWwgUFRcIixcclxuICBdO1xyXG5cclxuICAvLyDinIUgVXBkYXRlZCBQcmludCBIZWFkZXIgVmFsdWVzIHdpdGggV29yZHNcclxuICBjb25zdCBwcmludEhlYWRlclZhbHVlcyA9IFtcclxuICAgIHNlbGVjdGVkRW1wbG95ZWVcclxuICAgICAgPyBhbGxFbXBsb3llZXMuZmluZCgoZSkgPT4gZS5faWQgPT09IHNlbGVjdGVkRW1wbG95ZWUpPy5uYW1lIHx8IFwi4oCUXCJcclxuICAgICAgOiBcIkFsbCBFbXBsb3llZXNcIixcclxuICAgIHNlbGVjdGVkTW9udGhZZWFyPy5tb250aCB8fCBcIuKAlFwiLFxyXG4gICAgc2VsZWN0ZWRNb250aFllYXI/LnllYXIgfHwgXCLigJRcIixcclxuICAgIGDigrkke3N1bW1hcnkudG90YWxFc2kudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX0gKCR7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgcGFyc2VBbW91bnQoc3VtbWFyeS50b3RhbEVzaSlcclxuICAgICl9KWAsXHJcbiAgICBg4oK5JHtzdW1tYXJ5LnRvdGFsRXBmLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgIHBhcnNlQW1vdW50KHN1bW1hcnkudG90YWxFcGYpXHJcbiAgICApfSlgLFxyXG4gICAgYOKCuSR7c3VtbWFyeS50b3RhbEl0LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgIHBhcnNlQW1vdW50KHN1bW1hcnkudG90YWxJdClcclxuICAgICl9KWAsXHJcbiAgICBg4oK5JHtzdW1tYXJ5LnRvdGFscHQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX0gKCR7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgcGFyc2VBbW91bnQoc3VtbWFyeS50b3RhbHB0KVxyXG4gICAgKX0pYCxcclxuICBdO1xyXG5cclxuICAvLyAtLS0gVXBkYXRlZDogUHJvZmVzc2lvbmFsIFN1bW1hcnkgQ2FyZCBDb21wb25lbnQgd2l0aCBXb3JkcyAtLS1cclxuICBjb25zdCBEZWR1Y3Rpb25TdW1tYXJ5Q2FyZCA9ICh7IHRpdGxlLCB2YWx1ZSwgaWNvblR5cGUsIGNvbG9yIH0pID0+IHtcclxuICAgIGNvbnN0IGdldEljb24gPSAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGljb25TdHlsZSA9IHsgd2lkdGg6IFwiMjRweFwiLCBoZWlnaHQ6IFwiMjRweFwiLCBjb2xvciB9O1xyXG4gICAgICBzd2l0Y2ggKGljb25UeXBlKSB7XHJcbiAgICAgICAgY2FzZSBcInBmXCI6XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8c3ZnIHN0eWxlPXtpY29uU3R5bGV9IGZpbGw9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCI+XHJcbiAgICAgICAgICAgICAgPHBhdGggZD1cIk0yIDExYTEgMSAwIDAxMS0xaDJhMSAxIDAgMDExIDF2NWExIDEgMCAwMS0xIDFIM2ExIDEgMCAwMS0xLTF2LTV6TTggN2ExIDEgMCAwMTEtMWgyYTEgMSAwIDAxMSAxdjlhMSAxIDAgMDEtMSAxSDlhMSAxIDAgMDEtMS0xVjd6TTE0IDRhMSAxIDAgMDExLTFoMmExIDEgMCAwMTEgMXYxMmExIDEgMCAwMS0xIDFoLTJhMSAxIDAgMDEtMS0xVjR6XCI+PC9wYXRoPlxyXG4gICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgY2FzZSBcImVzaVwiOlxyXG4gICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPHN2ZyBzdHlsZT17aWNvblN0eWxlfSBmaWxsPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyMCAyMFwiPlxyXG4gICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgICAgZD1cIk0zLjE3MiA1LjE3MmE0IDQgMCAwMTUuNjU2IDBMMTAgNi4zNDNsMS4xNzItMS4xNzFhNCA0IDAgMTE1LjY1NiA1LjY1NkwxMCAxNy42NTdsLTYuODI4LTYuODI5YTQgNCAwIDAxMC01LjY1NnpcIlxyXG4gICAgICAgICAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgICA+PC9wYXRoPlxyXG4gICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgY2FzZSBcIml0XCI6XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8c3ZnIHN0eWxlPXtpY29uU3R5bGV9IGZpbGw9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCI+XHJcbiAgICAgICAgICAgICAgPHBhdGggZD1cIk04LjQzMyA3LjQxOGMuMTU1LS4xMDMuMzQ2LS4xOTYuNTY3LS4yNjd2MS42OThhMi4zMDUgMi4zMDUgMCAwMS0uNTY3LS4yNjdDOC4wNyA4LjM0IDggOC4xMTQgOCA4YzAtLjExNC4wNy0uMzQuNDMzLS41ODJ6TTExIDEyLjg0OXYtMS42OThjLjIyLjA3MS40MTIuMTY0LjU2Ny4yNjcuMzY0LjI0My40MzMuNDY4LjQzMy41ODIgMCAuMTE0LS4wNy4zNC0uNDMzLjU4MmEyLjMwNSAyLjMwNSAwIDAxLS41NjcuMjY3elwiPjwvcGF0aD5cclxuICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgICAgIGQ9XCJNMTAgMThhOCA4IDAgMTAwLTE2IDggOCAwIDAwMCAxNnptMS0xM2ExIDEgMCAxMC0yIDB2LjA5MmE0LjUzNSA0LjUzNSAwIDAwLTEuNjc2LjY2MkM2LjYwMiA2LjIzNCA2IDcuMDA5IDYgOGMwIC45OS42MDIgMS43NjUgMS4zMjQgMi4yNDYuNDguMzIgMS4wNTQuNTQ1IDEuNjc2LjY2MnYxLjk0MWMtLjM5MS0uMTI3LS42OC0uMzE3LS44NDMtLjUwNGExIDEgMCAxMC0xLjUxIDEuMzFjLjU2Mi42NDkgMS40MTMgMS4wNzYgMi4zNTMgMS4yNTNWMTVhMSAxIDAgMTAyIDB2LS4wOTJhNC41MzUgNC41MzUgMCAwMDEuNjc2LS42NjJDMTMuMzk4IDEzLjc2NiAxNCAxMi45OTEgMTQgMTJjMC0uOTktLjYwMi0xLjc2NS0xLjMyNC0yLjI0NkE0LjUzNSA0LjUzNSAwIDAwMTEgOS4wOTJWNy4xNTFjLjM5MS4xMjcuNjguMzE3Ljg0My41MDRhMSAxIDAgMTAxLjUxMS0xLjMxYy0uNTYzLS42NDktMS40MTMtMS4wNzYtMi4zNTQtMS4yNTNWNXpcIlxyXG4gICAgICAgICAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgICA+PC9wYXRoPlxyXG4gICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgY2FzZSBcInB0XCI6XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8c3ZnIHN0eWxlPXtpY29uU3R5bGV9IGZpbGw9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCI+XHJcbiAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgIGZpbGxSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgICAgICAgICBkPVwiTTYgMmEyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJoOGEyIDIgMCAwMDItMlY0YTIgMiAwIDAwLTItMkg2em0xIDJhMSAxIDAgMDAwIDJoNmExIDEgMCAxMDAtMkg3em0wIDRhMSAxIDAgMDAwIDJoNmExIDEgMCAxMDAtMkg3em0wIDRhMSAxIDAgMDAwIDJoMmExIDEgMCAxMDAtMkg3elwiXHJcbiAgICAgICAgICAgICAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgID48L3BhdGg+XHJcbiAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgKTtcclxuICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gRGV0ZXJtaW5lIHRleHQgY29sb3IgYmFzZWQgb24gY2FyZCBjb2xvciBmb3IgY29uc2lzdGVuY3lcclxuICAgIGNvbnN0IGdldFRleHRDbGFzcyA9ICgpID0+IHtcclxuICAgICAgaWYgKGNvbG9yLmluY2x1ZGVzKFwiM2I4MmY2XCIpKSByZXR1cm4gXCJ0ZXh0LXZpb2xldC03MDBcIjsgLy8gUEZcclxuICAgICAgaWYgKGNvbG9yLmluY2x1ZGVzKFwiMTBiOTgxXCIpKSByZXR1cm4gXCJ0ZXh0LWdyZWVuLTcwMFwiOyAvLyBFU0lcclxuICAgICAgaWYgKGNvbG9yLmluY2x1ZGVzKFwiZjU5ZTBiXCIpKSByZXR1cm4gXCJ0ZXh0LWFtYmVyLTcwMFwiOyAvLyBJVFxyXG4gICAgICBpZiAoY29sb3IuaW5jbHVkZXMoXCI1ZDIzYWFcIikpIHJldHVybiBcInRleHQtcHVycGxlLTcwMFwiOyAvLyBQVFxyXG4gICAgICByZXR1cm4gXCJ0ZXh0LWdyYXktNzAwXCI7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGlzQ3VycmVuY3kgPSAhdGl0bGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcInRheFwiKTtcclxuICAgIGNvbnN0IG51bWVyaWNWYWx1ZSA9IHBhcnNlQW1vdW50KHZhbHVlKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LXhsIHRyYW5zaXRpb24tc2hhZG93IGR1cmF0aW9uLTMwMCBwLTYgYm9yZGVyLWwtNFwiXHJcbiAgICAgICAgc3R5bGU9e3sgYm9yZGVyTGVmdENvbG9yOiBjb2xvciB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAge2lzQ3VycmVuY3lcclxuICAgICAgICAgICAgICAgID8gYOKCuSR7bnVtZXJpY1ZhbHVlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YFxyXG4gICAgICAgICAgICAgICAgOiBudW1lcmljVmFsdWUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICB7Lyog4pyFIEFkZGVkIE51bWJlciB0byBXb3JkcyAqL31cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LW1vbm8gbXQtMSBibG9jayAke2dldFRleHRDbGFzcygpfWB9PlxyXG4gICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKG51bWVyaWNWYWx1ZSl9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1sLTRcIlxyXG4gICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGAke2NvbG9yfTIwYCB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7Z2V0SWNvbigpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgPE5hdmJhciAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBwLTdcIj5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtMnhsIG1iLTRcIj5SZXBvcnRzIC0gU2FsYXJ5IERlZHVjdGlvbnM8L2gxPlxyXG5cclxuICAgICAgICB7LyogRklMVEVSUyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgbWItNiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMzAwIH19XHJcbiAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlfVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldFNlbGVjdGVkRW1wbG95ZWUodmFsdWUpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7YWxsRW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuICAgICAgICAgICAgICAgIHtlbXAubmFtZX0gfCB7ZW1wLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICA8TW9udGhQaWNrZXJcclxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDI1MCB9fVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBNb250aFwiXHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVNb250aFBpY2t9XHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUmVzZXR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy12aW9sZXQtNTAwIHRleHQtd2hpdGUgcm91bmRlZCBob3ZlcjpiZy12aW9sZXQtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUmVzZXRcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogLS0tIFVQREFURUQ6IFNVTU1BUlkgQ0FSRFMgU0VDVElPTiBXSVRIIFdPUkRTIC0tLSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTYgbWItNlwiPlxyXG4gICAgICAgICAgPERlZHVjdGlvblN1bW1hcnlDYXJkXHJcbiAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgUEZcIlxyXG4gICAgICAgICAgICB2YWx1ZT17c3VtbWFyeS50b3RhbEVwZn1cclxuICAgICAgICAgICAgaWNvblR5cGU9XCJwZlwiXHJcbiAgICAgICAgICAgIGNvbG9yPVwiIzNiODJmNlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPERlZHVjdGlvblN1bW1hcnlDYXJkXHJcbiAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgRVNJXCJcclxuICAgICAgICAgICAgdmFsdWU9e3N1bW1hcnkudG90YWxFc2l9XHJcbiAgICAgICAgICAgIGljb25UeXBlPVwiZXNpXCJcclxuICAgICAgICAgICAgY29sb3I9XCIjMTBiOTgxXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8RGVkdWN0aW9uU3VtbWFyeUNhcmRcclxuICAgICAgICAgICAgdGl0bGU9XCJUb3RhbCBJbmNvbWUgVGF4XCJcclxuICAgICAgICAgICAgdmFsdWU9e3N1bW1hcnkudG90YWxJdH1cclxuICAgICAgICAgICAgaWNvblR5cGU9XCJpdFwiXHJcbiAgICAgICAgICAgIGNvbG9yPVwiI2Y1OWUwYlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPERlZHVjdGlvblN1bW1hcnlDYXJkXHJcbiAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgUHJvZmVzc2lvbmFsIFRheFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtzdW1tYXJ5LnRvdGFscHR9XHJcbiAgICAgICAgICAgIGljb25UeXBlPVwicHRcIlxyXG4gICAgICAgICAgICBjb2xvcj1cIiM1ZDIzYWFmZlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB5LTEwXCI+XHJcbiAgICAgICAgICAgIDxTcGluIHNpemU9XCJsYXJnZVwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICBkYXRhPXthbGxTYWxhcnlUYWJsZX1cclxuICAgICAgICAgICAgZXhwb3J0Q29scz17Y29sdW1uc31cclxuICAgICAgICAgICAgaXNFeHBvcnRFbmFibGVkPXt0cnVlfVxyXG4gICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJFbXBsb3llZSBEZWR1Y3Rpb24gUmVwb3J0XCJcclxuICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtwcmludEhlYWRlcktleXN9XHJcbiAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtwcmludEhlYWRlclZhbHVlc31cclxuICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkVtcGxveWVlIERlZHVjdGlvbiBSZXBvcnQuY3N2XCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEVtcGxveWVlRGVkdWN0aW9uUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRW1wbG95ZWVEZWR1Y3Rpb25SZXBvcnQuanN4In0=