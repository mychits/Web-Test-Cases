import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RewardSettings.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import { FiEdit2, FiSave, FiX, FiCheckCircle } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
const RewardSettings = () => {
  _s();
  const [settings, setSettings] = useState({
    reward_point_value: "",
    loan_reward_points: "",
    pigmy_reward_points: "",
    enrollment_divisor: "",
    auction_pay_reward_value: "",
    payment_link_reward_value: "",
    customer_referral_value: "",
    // New fields
    milestone_reward_value: "",
    referral_bonus_points: "",
    anniversary_reward_points: ""
  });
  const [tempSettings, setTempSettings] = useState({});
  const [loading, setLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [updateMessage, setUpdateMessage] = useState("");
  const fetchSettings = async () => {
    try {
      const res = await api.get("/reward-points/reward-settings");
      console.info(res, "gfjskgfsdgsdg");
      if (res.data?.success) {
        setSettings(res.data.settings);
        setTempSettings(res.data.settings);
      }
    } catch (err) {
      console.error("Failed to fetch reward settings", err);
    }
  };
  useEffect(() => {
    fetchSettings();
  }, []);
  const updateSettings = async () => {
    setLoading(true);
    try {
      const response = await api.put("/reward-points/reward-settings", {
        reward_point_value: Number(tempSettings.reward_point_value),
        loan_reward_points: Number(tempSettings.loan_reward_points),
        pigmy_reward_points: Number(tempSettings.pigmy_reward_points),
        enrollment_divisor: Number(tempSettings.enrollment_divisor),
        auction_pay_reward_value: Number(tempSettings.auction_pay_reward_value),
        payment_link_reward_value: Number(tempSettings.payment_link_reward_value),
        customer_referral_value: Number(tempSettings.customer_referral_value)
      });
      if (response.data?.success) {
        setSettings(tempSettings);
        setIsEditing(false);
        setUpdateMessage("Reward settings updated successfully!");
        setShowSuccess(true);
        setTimeout(() => setShowSuccess(false), 3e3);
      }
    } catch (err) {
      setUpdateMessage("Failed to update reward settings");
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3e3);
    } finally {
      setLoading(false);
    }
  };
  const handleEdit = () => {
    setTempSettings(settings);
    setIsEditing(true);
  };
  const handleCancel = () => {
    setTempSettings(settings);
    setIsEditing(false);
  };
  const handleInputChange = (field, value) => {
    setTempSettings({ ...tempSettings, [field]: value });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 min-h-screen", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
      lineNumber: 484,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(SettingSidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
        lineNumber: 486,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-5xl mx-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-800", children: "Reward Points" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
            lineNumber: 491,
            columnNumber: 15
          }, this),
          !isEditing && /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleEdit,
              className: "flex items-center gap-2 bg-violet-600 text-white px-4 py-2 rounded-lg hover:bg-violet-700 transition-colors",
              children: [
                /* @__PURE__ */ jsxDEV(FiEdit2, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 499,
                  columnNumber: 19
                }, this),
                "Edit Settings"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
              lineNumber: 495,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
          lineNumber: 490,
          columnNumber: 13
        }, this),
        showSuccess && /* @__PURE__ */ jsxDEV("div", { className: `mb-6 p-4 rounded-lg flex items-center gap-2 ${updateMessage.includes("successfully") ? "bg-green-100 text-green-700 border border-green-200" : "bg-red-100 text-red-700 border border-red-200"}`, children: [
          /* @__PURE__ */ jsxDEV(FiCheckCircle, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
            lineNumber: 512,
            columnNumber: 17
          }, this),
          updateMessage
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
          lineNumber: 507,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-violet-600 to-violet-700 text-white p-5", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold", children: "Current Reward Points Settings" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
              lineNumber: 520,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-violet-100 mt-1", children: "Manage your reward points configuration" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
              lineNumber: 521,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
            lineNumber: 519,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
            /* @__PURE__ */ jsxDEV("table", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-3 px-4 font-semibold text-gray-700", children: "Setting" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 528,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-3 px-4 font-semibold text-gray-700", children: "Value" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 529,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-3 px-4 font-semibold text-gray-700", children: "Description" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 530,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                lineNumber: 527,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                lineNumber: 526,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: [
                /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-100 hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 font-medium text-gray-800", children: "Reward Point Value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 535,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4", children: isEditing ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "mr-2 text-gray-600", children: "₹" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 539,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500",
                        value: tempSettings.reward_point_value ?? "",
                        onChange: (e) => handleInputChange("reward_point_value", e.target.value)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                        lineNumber: 540,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 538,
                    columnNumber: 25
                  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-green-600", children: [
                      "₹",
                      settings.reward_point_value
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 549,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-sm text-gray-500", children: "per point" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 550,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 548,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 536,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 text-gray-600", children: "Monetary value of each reward point" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 554,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 534,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-100 hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 font-medium text-gray-800", children: "Pigmy Reward Points" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 557,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4", children: isEditing ? /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500",
                      value: tempSettings.pigmy_reward_points ?? "",
                      onChange: (e) => handleInputChange("pigmy_reward_points", e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 560,
                      columnNumber: 25
                    },
                    this
                  ) : /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-violet-600", children: settings.pigmy_reward_points }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 567,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 558,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 text-gray-600", children: "Points awarded for pigmy enrollments" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 570,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 556,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-100 hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 font-medium text-gray-800", children: "Loan Reward Points" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 574,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4", children: isEditing ? /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500",
                      value: tempSettings.loan_reward_points ?? "",
                      onChange: (e) => handleInputChange("loan_reward_points", e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 577,
                      columnNumber: 25
                    },
                    this
                  ) : /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-violet-600", children: settings.loan_reward_points }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 584,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 575,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 text-gray-600", children: "Points awarded for each loan join" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 587,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 573,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-100 hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 font-medium text-gray-800", children: "Enrollment Divisor" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 593,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4", children: isEditing ? /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500",
                      value: tempSettings.enrollment_divisor ?? "",
                      onChange: (e) => handleInputChange("enrollment_divisor", e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 596,
                      columnNumber: 25
                    },
                    this
                  ) : /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-violet-600", children: settings.enrollment_divisor }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 603,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 594,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 text-gray-600", children: "Reward Points are awarded at the rate of one point for every ₹1 lakh of chit enrollment value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 606,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 592,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-100 hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 font-medium text-gray-800", children: "No Due Reward Value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 610,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4", children: isEditing ? /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500",
                      value: tempSettings.auction_pay_reward_value ?? "",
                      onChange: (e) => handleInputChange("auction_pay_reward_value", e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 613,
                      columnNumber: 25
                    },
                    this
                  ) : /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-violet-600", children: settings.auction_pay_reward_value }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 620,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 611,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 text-gray-600", children: "Points awarded for successful auction payments" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 623,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 609,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-100 hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 font-medium text-gray-800", children: "Payment Link Reward Value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 627,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4", children: isEditing ? /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500",
                      value: tempSettings.payment_link_reward_value ?? "",
                      onChange: (e) => handleInputChange("payment_link_reward_value", e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 630,
                      columnNumber: 25
                    },
                    this
                  ) : /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-violet-600", children: settings.payment_link_reward_value }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 637,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 628,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 text-gray-600", children: "Points awarded for payments made through payment links" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 640,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 626,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-100 hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 font-medium text-gray-800", children: "Customer Referral Value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 644,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4", children: isEditing ? /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500",
                      value: tempSettings.customer_referral_value ?? "",
                      onChange: (e) => handleInputChange("customer_referral_value", e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 647,
                      columnNumber: 25
                    },
                    this
                  ) : /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-violet-600", children: settings.customer_referral_value }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 654,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 645,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-4 px-4 text-gray-600", children: "Points awarded for successful customer referrals" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                    lineNumber: 657,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 643,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                lineNumber: 533,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
              lineNumber: 525,
              columnNumber: 17
            }, this),
            isEditing && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex justify-end gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: handleCancel,
                  className: "flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV(FiX, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 670,
                      columnNumber: 23
                    }, this),
                    "Cancel"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 666,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: updateSettings,
                  disabled: loading,
                  className: "flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50",
                  children: [
                    /* @__PURE__ */ jsxDEV(FiSave, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                      lineNumber: 678,
                      columnNumber: 23
                    }, this),
                    loading ? "Saving..." : "Save Changes"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
                  lineNumber: 673,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
              lineNumber: 665,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
            lineNumber: 524,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
          lineNumber: 518,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
        lineNumber: 489,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
        lineNumber: 488,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
      lineNumber: 485,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx",
    lineNumber: 483,
    columnNumber: 5
  }, this);
};
_s(RewardSettings, "mFu6FcDt1j76gvgT173VuHRwREk=");
_c = RewardSettings;
export default RewardSettings;
var _c;
$RefreshReg$(_c, "RewardSettings");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RewardSettings.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbWVNOzJCQW5lTjtBQUFpQkEsb0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDeEMsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0Msb0JBQW9CO0FBNkgzQixTQUFTQyxTQUFTQyxRQUFRQyxLQUFLQyxxQkFBcUI7QUEyUXBELE1BQU1DLGlCQUFpQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzNCLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJQyxTQUFTO0FBQUEsSUFDdkNDLG9CQUFvQjtBQUFBLElBQ3BCQyxvQkFBb0I7QUFBQSxJQUNwQkMscUJBQXFCO0FBQUEsSUFDckJDLG9CQUFvQjtBQUFBLElBQ3BCQywwQkFBMEI7QUFBQSxJQUMxQkMsMkJBQTJCO0FBQUEsSUFDM0JDLHlCQUF5QjtBQUFBO0FBQUEsSUFFekJDLHdCQUF3QjtBQUFBLElBQ3hCQyx1QkFBdUI7QUFBQSxJQUN2QkMsMkJBQTJCO0FBQUEsRUFDN0IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJWixTQUFTLENBQUMsQ0FBQztBQUNuRCxRQUFNLENBQUNhLFNBQVNDLFVBQVUsSUFBSWQsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ2UsV0FBV0MsWUFBWSxJQUFJaEIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2lCLGFBQWFDLGNBQWMsSUFBSWxCLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNtQixlQUFlQyxnQkFBZ0IsSUFBSXBCLFNBQVMsRUFBRTtBQUdyRCxRQUFNcUIsZ0JBQWdCLFlBQVk7QUFDaEMsUUFBSTtBQUNGLFlBQU1DLE1BQU0sTUFBTXBDLElBQUlxQyxJQUFJLGdDQUFnQztBQUMxREMsY0FBUUMsS0FBS0gsS0FBSyxlQUFlO0FBQ2pDLFVBQUlBLElBQUlJLE1BQU1DLFNBQVM7QUFDckI1QixvQkFBWXVCLElBQUlJLEtBQUs1QixRQUFRO0FBQzdCYyx3QkFBZ0JVLElBQUlJLEtBQUs1QixRQUFRO0FBQUEsTUFDbkM7QUFBQSxJQUNGLFNBQVM4QixLQUFLO0FBQ1pKLGNBQVFLLE1BQU0sbUNBQW1DRCxHQUFHO0FBQUEsSUFDdEQ7QUFBQSxFQUNGO0FBRUEzQyxZQUFVLE1BQU07QUFDZG9DLGtCQUFjO0FBQUEsRUFDaEIsR0FBRyxFQUFFO0FBR0wsUUFBTVMsaUJBQWlCLFlBQVk7QUFDakNoQixlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTWlCLFdBQVcsTUFBTTdDLElBQUk4QyxJQUFJLGtDQUFrQztBQUFBLFFBQy9EL0Isb0JBQW9CZ0MsT0FBT3RCLGFBQWFWLGtCQUFrQjtBQUFBLFFBQzFEQyxvQkFBb0IrQixPQUFPdEIsYUFBYVQsa0JBQWtCO0FBQUEsUUFDMURDLHFCQUFxQjhCLE9BQU90QixhQUFhUixtQkFBbUI7QUFBQSxRQUM1REMsb0JBQW9CNkIsT0FBT3RCLGFBQWFQLGtCQUFrQjtBQUFBLFFBQzFEQywwQkFBMEI0QixPQUFPdEIsYUFBYU4sd0JBQXdCO0FBQUEsUUFDdEVDLDJCQUEyQjJCLE9BQU90QixhQUFhTCx5QkFBeUI7QUFBQSxRQUN4RUMseUJBQXlCMEIsT0FBT3RCLGFBQWFKLHVCQUF1QjtBQUFBLE1BQ3RFLENBQUM7QUFFRCxVQUFJd0IsU0FBU0wsTUFBTUMsU0FBUztBQUMxQjVCLG9CQUFZWSxZQUFZO0FBQ3hCSyxxQkFBYSxLQUFLO0FBQ2xCSSx5QkFBaUIsdUNBQXVDO0FBQ3hERix1QkFBZSxJQUFJO0FBQ25CZ0IsbUJBQVcsTUFBTWhCLGVBQWUsS0FBSyxHQUFHLEdBQUk7QUFBQSxNQUM5QztBQUFBLElBQ0YsU0FBU1UsS0FBSztBQUNaUix1QkFBaUIsa0NBQWtDO0FBQ25ERixxQkFBZSxJQUFJO0FBQ25CZ0IsaUJBQVcsTUFBTWhCLGVBQWUsS0FBSyxHQUFHLEdBQUk7QUFBQSxJQUM5QyxVQUFDO0FBQ0NKLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNcUIsYUFBYUEsTUFBTTtBQUN2QnZCLG9CQUFnQmQsUUFBUTtBQUN4QmtCLGlCQUFhLElBQUk7QUFBQSxFQUNuQjtBQUVBLFFBQU1vQixlQUFlQSxNQUFNO0FBQ3pCeEIsb0JBQWdCZCxRQUFRO0FBQ3hCa0IsaUJBQWEsS0FBSztBQUFBLEVBQ3BCO0FBRUEsUUFBTXFCLG9CQUFvQkEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUMxQzNCLG9CQUFnQixFQUFFLEdBQUdELGNBQWMsQ0FBQzJCLEtBQUssR0FBR0MsTUFBTSxDQUFDO0FBQUEsRUFDckQ7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJCQUFDLFVBQU8sWUFBVSxRQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCO0FBQUEsSUFDbEIsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxNQUVmLHVCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsb0NBQW1DLDZCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQyxDQUFDeEIsYUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU29CO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVE7QUFBQSxnQkFBRztBQUFBO0FBQUE7QUFBQSxZQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUdDbEIsZUFDQyx1QkFBQyxTQUFJLFdBQVcsK0NBQ2RFLGNBQWNxQixTQUFTLGNBQWMsSUFDakMsd0RBQ0EsK0NBQStDLElBRW5EO0FBQUEsaUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYztBQUFBLFVBQ2JyQjtBQUFBQSxhQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBSUYsdUJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHlCQUF3Qiw4Q0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxPQUFFLFdBQVUsd0JBQXVCLHVEQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLGVBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLFVBQ2Y7QUFBQSxxQ0FBQyxXQUNDLGlDQUFDLFFBQUcsV0FBVSw0QkFDWjtBQUFBLHVDQUFDLFFBQUcsV0FBVSxtREFBa0QsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFO0FBQUEsZ0JBQ3ZFLHVCQUFDLFFBQUcsV0FBVSxtREFBa0QscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFO0FBQUEsZ0JBQ3JFLHVCQUFDLFFBQUcsV0FBVSxtREFBa0QsMkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJFO0FBQUEsbUJBSDdFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsY0FDQSx1QkFBQyxXQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDZDQUNaO0FBQUEseUNBQUMsUUFBRyxXQUFVLHVDQUFzQyxrQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0U7QUFBQSxrQkFDdEUsdUJBQUMsUUFBRyxXQUFVLGFBQ1hKLHNCQUNDLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSxzQkFBcUIsaUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNDO0FBQUEsb0JBQ3RDO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxXQUFVO0FBQUEsd0JBQ1YsT0FBT0osYUFBYVYsc0JBQXNCO0FBQUEsd0JBQzFDLFVBQVUsQ0FBQ3dDLE1BQU1KLGtCQUFrQixzQkFBc0JJLEVBQUVDLE9BQU9ILEtBQUs7QUFBQTtBQUFBLHNCQUp6RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSTJFO0FBQUEsdUJBTjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxzQkFBRXpDLFNBQVNHO0FBQUFBLHlCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRjtBQUFBLG9CQUNqRix1QkFBQyxVQUFLLFdBQVUsOEJBQTZCLHlCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzRDtBQUFBLHVCQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBLEtBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsMkJBQTBCLG1EQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRTtBQUFBLHFCQXBCN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQkE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsNkNBQ1o7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsdUNBQXNDLG1DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLGtCQUN2RSx1QkFBQyxRQUFHLFdBQVUsYUFDWGMsc0JBQ0M7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixPQUFPSixhQUFhUix1QkFBdUI7QUFBQSxzQkFDM0MsVUFBVSxDQUFDc0MsTUFBTUosa0JBQWtCLHVCQUF1QkksRUFBRUMsT0FBT0gsS0FBSztBQUFBO0FBQUEsb0JBSjFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJNEUsSUFHNUUsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ3pDLG1CQUFTSyx1QkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0YsS0FUdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSwyQkFBMEIsb0RBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRFO0FBQUEscUJBZDlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxnQkFFQSx1QkFBQyxRQUFHLFdBQVUsNkNBQ1o7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsdUNBQXNDLGtDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRTtBQUFBLGtCQUN0RSx1QkFBQyxRQUFHLFdBQVUsYUFDWFksc0JBQ0M7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixPQUFPSixhQUFhVCxzQkFBc0I7QUFBQSxzQkFDMUMsVUFBVSxDQUFDdUMsTUFBTUosa0JBQWtCLHNCQUFzQkksRUFBRUMsT0FBT0gsS0FBSztBQUFBO0FBQUEsb0JBSnpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJMkUsSUFHM0UsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ3pDLG1CQUFTSSxzQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUYsS0FUckY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSwyQkFBMEIsaURBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlFO0FBQUEscUJBZDNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxnQkFJQSx1QkFBQyxRQUFHLFdBQVUsNkNBQ1o7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsdUNBQXNDLGtDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRTtBQUFBLGtCQUN0RSx1QkFBQyxRQUFHLFdBQVUsYUFDWGEsc0JBQ0M7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixPQUFPSixhQUFhUCxzQkFBc0I7QUFBQSxzQkFDMUMsVUFBVSxDQUFDcUMsTUFBTUosa0JBQWtCLHNCQUFzQkksRUFBRUMsT0FBT0gsS0FBSztBQUFBO0FBQUEsb0JBSnpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJMkUsSUFHM0UsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ3pDLG1CQUFTTSxzQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUYsS0FUckY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSwyQkFBMEIsNkdBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFJO0FBQUEscUJBZHZJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxnQkFFQSx1QkFBQyxRQUFHLFdBQVUsNkNBQ1o7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsdUNBQXNDLG1DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLGtCQUN2RSx1QkFBQyxRQUFHLFdBQVUsYUFDWFcsc0JBQ0M7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixPQUFPSixhQUFhTiw0QkFBNEI7QUFBQSxzQkFDaEQsVUFBVSxDQUFDb0MsTUFBTUosa0JBQWtCLDRCQUE0QkksRUFBRUMsT0FBT0gsS0FBSztBQUFBO0FBQUEsb0JBSi9FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJaUYsSUFHakYsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ3pDLG1CQUFTTyw0QkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUYsS0FUM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSwyQkFBMEIsOERBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNGO0FBQUEscUJBZHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxnQkFFQSx1QkFBQyxRQUFHLFdBQVUsNkNBQ1o7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsdUNBQXNDLHlDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RTtBQUFBLGtCQUM3RSx1QkFBQyxRQUFHLFdBQVUsYUFDWFUsc0JBQ0M7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixPQUFPSixhQUFhTCw2QkFBNkI7QUFBQSxzQkFDakQsVUFBVSxDQUFDbUMsTUFBTUosa0JBQWtCLDZCQUE2QkksRUFBRUMsT0FBT0gsS0FBSztBQUFBO0FBQUEsb0JBSmhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJa0YsSUFHbEYsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ3pDLG1CQUFTUSw2QkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0YsS0FUNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSwyQkFBMEIsc0VBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThGO0FBQUEscUJBZGhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxnQkFFQSx1QkFBQyxRQUFHLFdBQVUsNkNBQ1o7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsdUNBQXNDLHVDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRTtBQUFBLGtCQUMzRSx1QkFBQyxRQUFHLFdBQVUsYUFDWFMsc0JBQ0M7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixPQUFPSixhQUFhSiwyQkFBMkI7QUFBQSxzQkFDL0MsVUFBVSxDQUFDa0MsTUFBTUosa0JBQWtCLDJCQUEyQkksRUFBRUMsT0FBT0gsS0FBSztBQUFBO0FBQUEsb0JBSjlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJZ0YsSUFHaEYsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ3pDLG1CQUFTUywyQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0YsS0FUMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSwyQkFBMEIsZ0VBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdGO0FBQUEscUJBZDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxtQkE3SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnSUE7QUFBQSxpQkF4SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5SUE7QUFBQSxZQUVDUSxhQUNDLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVNxQjtBQUFBQSxrQkFDVCxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQUk7QUFBQSxvQkFBRztBQUFBO0FBQUE7QUFBQSxnQkFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBU047QUFBQUEsa0JBQ1QsVUFBVWpCO0FBQUFBLGtCQUNWLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBTztBQUFBLG9CQUNOQSxVQUFVLGNBQWM7QUFBQTtBQUFBO0FBQUEsZ0JBTjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsaUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxlQTdKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStKQTtBQUFBLGFBcktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzS0E7QUFBQSxXQW5NRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc09BLEtBdk9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3T0E7QUFBQSxTQTNPRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNE9BO0FBQUEsT0E5T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStPQTtBQUVKO0FBQUVoQixHQXJVSUQsZ0JBQWM7QUFBQStDLEtBQWQvQztBQXVVTixlQUFlQTtBQUFlLElBQUErQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiYXBpIiwiTmF2YmFyIiwiRGF0YVRhYmxlIiwiU2lkZWJhciIsIkNpcmN1bGFyTG9hZGVyIiwiU2V0dGluZ1NpZGViYXIiLCJGaUVkaXQyIiwiRmlTYXZlIiwiRmlYIiwiRmlDaGVja0NpcmNsZSIsIlJld2FyZFNldHRpbmdzIiwiX3MiLCJzZXR0aW5ncyIsInNldFNldHRpbmdzIiwidXNlU3RhdGUiLCJyZXdhcmRfcG9pbnRfdmFsdWUiLCJsb2FuX3Jld2FyZF9wb2ludHMiLCJwaWdteV9yZXdhcmRfcG9pbnRzIiwiZW5yb2xsbWVudF9kaXZpc29yIiwiYXVjdGlvbl9wYXlfcmV3YXJkX3ZhbHVlIiwicGF5bWVudF9saW5rX3Jld2FyZF92YWx1ZSIsImN1c3RvbWVyX3JlZmVycmFsX3ZhbHVlIiwibWlsZXN0b25lX3Jld2FyZF92YWx1ZSIsInJlZmVycmFsX2JvbnVzX3BvaW50cyIsImFubml2ZXJzYXJ5X3Jld2FyZF9wb2ludHMiLCJ0ZW1wU2V0dGluZ3MiLCJzZXRUZW1wU2V0dGluZ3MiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImlzRWRpdGluZyIsInNldElzRWRpdGluZyIsInNob3dTdWNjZXNzIiwic2V0U2hvd1N1Y2Nlc3MiLCJ1cGRhdGVNZXNzYWdlIiwic2V0VXBkYXRlTWVzc2FnZSIsImZldGNoU2V0dGluZ3MiLCJyZXMiLCJnZXQiLCJjb25zb2xlIiwiaW5mbyIsImRhdGEiLCJzdWNjZXNzIiwiZXJyIiwiZXJyb3IiLCJ1cGRhdGVTZXR0aW5ncyIsInJlc3BvbnNlIiwicHV0IiwiTnVtYmVyIiwic2V0VGltZW91dCIsImhhbmRsZUVkaXQiLCJoYW5kbGVDYW5jZWwiLCJoYW5kbGVJbnB1dENoYW5nZSIsImZpZWxkIiwidmFsdWUiLCJpbmNsdWRlcyIsImUiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZXdhcmRTZXR0aW5ncy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHt1c2VTdGF0ZSx1c2VFZmZlY3R9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgYXBpIGZyb20gJy4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2UnO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gJy4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXInO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gJy4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGUnO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tICcuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhcic7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tICcuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXInO1xyXG5pbXBvcnQgU2V0dGluZ1NpZGViYXIgZnJvbSAnLi4vY29tcG9uZW50cy9sYXlvdXRzL1NldHRpbmdTaWRlYmFyJztcclxuXHJcblxyXG4vLyBjb25zdCBSZXdhcmRTZXR0aW5ncyA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbc2V0dGluZ3MsIHNldFNldHRpbmdzXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHJld2FyZF9wb2ludF92YWx1ZTogXCJcIixcclxuLy8gICAgIGxvYW5fcmV3YXJkX3BvaW50czogXCJcIixcclxuLy8gICAgIHBpZ215X3Jld2FyZF9wb2ludHM6IFwiXCIsXHJcbi8vICAgICBlbnJvbGxtZW50X2Rpdmlzb3I6IFwiXCIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgLyogPT09PT09PT09PT09PT09PT0gRkVUQ0ggU0VUVElOR1MgPT09PT09PT09PT09PT09PT0gKi9cclxuLy8gICBjb25zdCBmZXRjaFNldHRpbmdzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9yZXdhcmQtcG9pbnRzL3Jld2FyZC1zZXR0aW5nc1wiKTtcclxuXHJcbi8vICAgICAgIGlmIChyZXMuZGF0YT8uc3VjY2Vzcykge1xyXG4vLyAgICAgICAgIHNldFNldHRpbmdzKHJlcy5kYXRhLnNldHRpbmdzKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcmV3YXJkIHNldHRpbmdzXCIsIGVycik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoU2V0dGluZ3MoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IFVQREFURSBTRVRUSU5HUyA9PT09PT09PT09PT09PT09PSAqL1xyXG4vLyAgIGNvbnN0IHVwZGF0ZVNldHRpbmdzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnB1dChcIi9yZXdhcmQtcG9pbnRzL3Jld2FyZC1zZXR0aW5nc1wiLCB7XHJcbi8vICAgICAgICAgcmV3YXJkX3BvaW50X3ZhbHVlOiBOdW1iZXIoc2V0dGluZ3MucmV3YXJkX3BvaW50X3ZhbHVlKSxcclxuLy8gICAgICAgICBsb2FuX3Jld2FyZF9wb2ludHM6IE51bWJlcihzZXR0aW5ncy5sb2FuX3Jld2FyZF9wb2ludHMpLFxyXG4vLyAgICAgICAgIHBpZ215X3Jld2FyZF9wb2ludHM6IE51bWJlcihzZXR0aW5ncy5waWdteV9yZXdhcmRfcG9pbnRzKSxcclxuLy8gICAgICAgICBlbnJvbGxtZW50X2Rpdmlzb3I6IE51bWJlcihzZXR0aW5ncy5lbnJvbGxtZW50X2Rpdmlzb3IpLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlLmRhdGEsIFwiZmhzZ2RmamhzZ2ZzZ1wiKTtcclxuXHJcbi8vICAgICAgIGFsZXJ0KFwiUmV3YXJkIHNldHRpbmdzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4vLyAgICAgICBmZXRjaFNldHRpbmdzKCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgYWxlcnQoXCJGYWlsZWQgdG8gdXBkYXRlIHJld2FyZCBzZXR0aW5nc1wiKTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2PlxyXG4vLyAgICAgICA8TmF2YmFyIHZpc2liaWxpdHkgLz5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbi8vICAgICAgICAgPFNldHRpbmdTaWRlYmFyIC8+XHJcblxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNyBtYXgtdy14bFwiPlxyXG4vLyAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICBSZXdhcmQgU2V0dGluZ3NcclxuLy8gICAgICAgICAgIDwvaDE+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBwLTYgYmctd2hpdGUgc2hhZG93LXNtIHNwYWNlLXktNFwiPlxyXG4vLyAgICAgICAgICAgICA8SW5wdXRGaWVsZFxyXG4vLyAgICAgICAgICAgICAgIGxhYmVsPVwiUmV3YXJkIFBvaW50IFZhbHVlICjigrkpXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17c2V0dGluZ3MucmV3YXJkX3BvaW50X3ZhbHVlfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT5cclxuLy8gICAgICAgICAgICAgICAgIHNldFNldHRpbmdzKHsgLi4uc2V0dGluZ3MsIHJld2FyZF9wb2ludF92YWx1ZTogdiB9KVxyXG4vLyAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgLz5cclxuXHJcbi8vICAgICAgICAgICAgIDxJbnB1dEZpZWxkXHJcbi8vICAgICAgICAgICAgICAgbGFiZWw9XCJMb2FuIFJld2FyZCBQb2ludHNcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtzZXR0aW5ncy5sb2FuX3Jld2FyZF9wb2ludHN9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2KSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgc2V0U2V0dGluZ3MoeyAuLi5zZXR0aW5ncywgbG9hbl9yZXdhcmRfcG9pbnRzOiB2IH0pXHJcbi8vICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgPElucHV0RmllbGRcclxuLy8gICAgICAgICAgICAgICBsYWJlbD1cIlBpZ215IFJld2FyZCBQb2ludHNcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtzZXR0aW5ncy5waWdteV9yZXdhcmRfcG9pbnRzfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT5cclxuLy8gICAgICAgICAgICAgICAgIHNldFNldHRpbmdzKHsgLi4uc2V0dGluZ3MsIHBpZ215X3Jld2FyZF9wb2ludHM6IHYgfSlcclxuLy8gICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgIC8+XHJcblxyXG4vLyAgICAgICAgICAgICA8SW5wdXRGaWVsZFxyXG4vLyAgICAgICAgICAgICAgIGxhYmVsPVwiRW5yb2xsbWVudCBEaXZpc29yXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17c2V0dGluZ3MuZW5yb2xsbWVudF9kaXZpc29yfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT5cclxuLy8gICAgICAgICAgICAgICAgIHNldFNldHRpbmdzKHsgLi4uc2V0dGluZ3MsIGVucm9sbG1lbnRfZGl2aXNvcjogdiB9KVxyXG4vLyAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgLz5cclxuXHJcbi8vICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXt1cGRhdGVTZXR0aW5nc31cclxuLy8gICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcHgtNiBweS0yIHJvdW5kZWQgdy1mdWxsXCJcclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIHtsb2FkaW5nID8gXCJVcGRhdGluZy4uLlwiIDogXCJVcGRhdGUgU2V0dGluZ3NcIn1cclxuLy8gICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuXHJcbi8vIGNvbnN0IElucHV0RmllbGQgPSAoeyBsYWJlbCwgdmFsdWUsIG9uQ2hhbmdlIH0pID0+IChcclxuLy8gICA8ZGl2PlxyXG4vLyAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPntsYWJlbH08L2xhYmVsPlxyXG4vLyAgICAgPGlucHV0XHJcbi8vICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4vLyAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHJvdW5kZWQgdy1mdWxsIG10LTFcIlxyXG4vLyAgICAgICB2YWx1ZT17dmFsdWUgPz8gXCJcIn1cclxuLy8gICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAvPlxyXG4vLyAgIDwvZGl2PlxyXG4vLyApO1xyXG5cclxuLy8gZXhwb3J0IGRlZmF1bHQgUmV3YXJkU2V0dGluZ3M7XHJcblxyXG5cclxuaW1wb3J0IHsgRmlFZGl0MiwgRmlTYXZlLCBGaVgsIEZpQ2hlY2tDaXJjbGUgfSBmcm9tICdyZWFjdC1pY29ucy9maSc7XHJcblxyXG4vLyBjb25zdCBSZXdhcmRTZXR0aW5ncyA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbc2V0dGluZ3MsIHNldFNldHRpbmdzXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHJld2FyZF9wb2ludF92YWx1ZTogXCJcIixcclxuLy8gICAgIGxvYW5fcmV3YXJkX3BvaW50czogXCJcIixcclxuLy8gICAgIHBpZ215X3Jld2FyZF9wb2ludHM6IFwiXCIsXHJcbi8vICAgICBlbnJvbGxtZW50X2Rpdmlzb3I6IFwiXCIsXHJcbi8vICAgICBhdWN0aW9uX3BheV9yZXdhcmRfdmFsdWU6IFwiXCIsXHJcbi8vICAgICBwYXltZW50X2xpbmtfcmV3YXJkX3ZhbHVlOiBcIlwiLFxyXG4vLyAgICAgY3VzdG9tZXJfcmVmZXJyYWxfdmFsdWU6IFwiXCIsXHJcbi8vICAgfSk7XHJcbiAgXHJcbi8vICAgY29uc3QgW3RlbXBTZXR0aW5ncywgc2V0VGVtcFNldHRpbmdzXSA9IHVzZVN0YXRlKHt9KTtcclxuLy8gICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2lzRWRpdGluZywgc2V0SXNFZGl0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbc2hvd1N1Y2Nlc3MsIHNldFNob3dTdWNjZXNzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbdXBkYXRlTWVzc2FnZSwgc2V0VXBkYXRlTWVzc2FnZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbi8vICAgLyogPT09PT09PT09PT09PT09PT0gRkVUQ0ggU0VUVElOR1MgPT09PT09PT09PT09PT09PT0gKi9cclxuLy8gICBjb25zdCBmZXRjaFNldHRpbmdzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9yZXdhcmQtcG9pbnRzL3Jld2FyZC1zZXR0aW5nc1wiKTtcclxuLy8gICAgICAgY29uc29sZS5pbmZvKHJlcywgXCJnZmpza2dmc2Rnc2RnXCIpO1xyXG4vLyAgICAgICBpZiAocmVzLmRhdGE/LnN1Y2Nlc3MpIHtcclxuLy8gICAgICAgICBzZXRTZXR0aW5ncyhyZXMuZGF0YS5zZXR0aW5ncyk7XHJcbi8vICAgICAgICAgc2V0VGVtcFNldHRpbmdzKHJlcy5kYXRhLnNldHRpbmdzKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcmV3YXJkIHNldHRpbmdzXCIsIGVycik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoU2V0dGluZ3MoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IFVQREFURSBTRVRUSU5HUyA9PT09PT09PT09PT09PT09PSAqL1xyXG4vLyAgIGNvbnN0IHVwZGF0ZVNldHRpbmdzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnB1dChcIi9yZXdhcmQtcG9pbnRzL3Jld2FyZC1zZXR0aW5nc1wiLCB7XHJcbi8vICAgICAgICAgcmV3YXJkX3BvaW50X3ZhbHVlOiBOdW1iZXIodGVtcFNldHRpbmdzLnJld2FyZF9wb2ludF92YWx1ZSksXHJcbi8vICAgICAgICAgbG9hbl9yZXdhcmRfcG9pbnRzOiBOdW1iZXIodGVtcFNldHRpbmdzLmxvYW5fcmV3YXJkX3BvaW50cyksXHJcbi8vICAgICAgICAgcGlnbXlfcmV3YXJkX3BvaW50czogTnVtYmVyKHRlbXBTZXR0aW5ncy5waWdteV9yZXdhcmRfcG9pbnRzKSxcclxuLy8gICAgICAgICBlbnJvbGxtZW50X2Rpdmlzb3I6IE51bWJlcih0ZW1wU2V0dGluZ3MuZW5yb2xsbWVudF9kaXZpc29yKSxcclxuLy8gICAgICAgICBhdWN0aW9uX3BheV9yZXdhcmRfdmFsdWU6IE51bWJlcih0ZW1wU2V0dGluZ3MuYXVjdGlvbl9wYXlfcmV3YXJkX3ZhbHVlKSxcclxuLy8gICAgICAgICBwYXltZW50X2xpbmtfcmV3YXJkX3ZhbHVlOiBOdW1iZXIodGVtcFNldHRpbmdzLnBheW1lbnRfbGlua19yZXdhcmRfdmFsdWUpLFxyXG4vLyAgICAgICAgIGN1c3RvbWVyX3JlZmVycmFsX3ZhbHVlOiBOdW1iZXIodGVtcFNldHRpbmdzLmN1c3RvbWVyX3JlZmVycmFsX3ZhbHVlKSxcclxuLy8gICAgICAgfSk7XHJcbiAgICAgIFxyXG4vLyAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8uc3VjY2Vzcykge1xyXG4vLyAgICAgICAgIHNldFNldHRpbmdzKHRlbXBTZXR0aW5ncyk7XHJcbi8vICAgICAgICAgc2V0SXNFZGl0aW5nKGZhbHNlKTtcclxuLy8gICAgICAgICBzZXRVcGRhdGVNZXNzYWdlKFwiUmV3YXJkIHNldHRpbmdzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuLy8gICAgICAgICBzZXRTaG93U3VjY2Vzcyh0cnVlKTtcclxuLy8gICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFNob3dTdWNjZXNzKGZhbHNlKSwgMzAwMCk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICBzZXRVcGRhdGVNZXNzYWdlKFwiRmFpbGVkIHRvIHVwZGF0ZSByZXdhcmQgc2V0dGluZ3NcIik7XHJcbi8vICAgICAgIHNldFNob3dTdWNjZXNzKHRydWUpO1xyXG4vLyAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFNob3dTdWNjZXNzKGZhbHNlKSwgMzAwMCk7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVFZGl0ID0gKCkgPT4ge1xyXG4vLyAgICAgc2V0VGVtcFNldHRpbmdzKHNldHRpbmdzKTtcclxuLy8gICAgIHNldElzRWRpdGluZyh0cnVlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVDYW5jZWwgPSAoKSA9PiB7XHJcbi8vICAgICBzZXRUZW1wU2V0dGluZ3Moc2V0dGluZ3MpO1xyXG4vLyAgICAgc2V0SXNFZGl0aW5nKGZhbHNlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuLy8gICAgIHNldFRlbXBTZXR0aW5ncyh7IC4uLnRlbXBTZXR0aW5ncywgW2ZpZWxkXTogdmFsdWUgfSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBtaW4taC1zY3JlZW5cIj5cclxuLy8gICAgICAgPE5hdmJhciB2aXNpYmlsaXR5IC8+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4vLyAgICAgICAgIDxTZXR0aW5nU2lkZWJhciAvPlxyXG5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNXhsIG14LWF1dG9cIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgUmV3YXJkIFBvaW50cyBcclxuLy8gICAgICAgICAgICAgICA8L2gxPlxyXG4vLyAgICAgICAgICAgICAgIHshaXNFZGl0aW5nICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRWRpdH1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLXZpb2xldC03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8RmlFZGl0MiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICBFZGl0IFNldHRpbmdzXHJcbi8vICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBTdWNjZXNzIE1lc3NhZ2UgKi99XHJcbi8vICAgICAgICAgICAgIHtzaG93U3VjY2VzcyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BtYi02IHAtNCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yICR7XHJcbi8vICAgICAgICAgICAgICAgICB1cGRhdGVNZXNzYWdlLmluY2x1ZGVzKFwic3VjY2Vzc2Z1bGx5XCIpIFxyXG4vLyAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tNzAwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCIgXHJcbi8vICAgICAgICAgICAgICAgICAgIDogXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCBib3JkZXIgYm9yZGVyLXJlZC0yMDBcIlxyXG4vLyAgICAgICAgICAgICAgIH1gfT5cclxuLy8gICAgICAgICAgICAgICAgIDxGaUNoZWNrQ2lyY2xlIC8+XHJcbi8vICAgICAgICAgICAgICAgICB7dXBkYXRlTWVzc2FnZX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBSZXdhcmQgUG9pbnRzIFRhYmxlICovfVxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXNtIG92ZXJmbG93LWhpZGRlblwiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMCB0ZXh0LXdoaXRlIHAtNVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZFwiPkN1cnJlbnQgUmV3YXJkIFBvaW50cyBTZXR0aW5nczwvaDI+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC0xMDAgbXQtMVwiPk1hbmFnZSB5b3VyIHJld2FyZCBwb2ludHMgY29uZmlndXJhdGlvbjwvcD5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0zIHB4LTQgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+U2V0dGluZzwvdGg+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTMgcHgtNCBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5WYWx1ZTwvdGg+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTMgcHgtNCBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5EZXNjcmlwdGlvbjwvdGg+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuLy8gICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0xMDAgaG92ZXI6YmctZ3JheS01MFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNCBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+UGlnbXkgUmV3YXJkIFBvaW50czwvdGQ+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wU2V0dGluZ3MucGlnbXlfcmV3YXJkX3BvaW50cyA/PyBcIlwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcInBpZ215X3Jld2FyZF9wb2ludHNcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC12aW9sZXQtNjAwXCI+e3NldHRpbmdzLnBpZ215X3Jld2FyZF9wb2ludHN9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgdGV4dC1ncmF5LTYwMFwiPlBvaW50cyBhd2FyZGVkIGZvciBwaWdteSBlbnJvbGxtZW50czwvdGQ+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktNTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPkxvYW4gUmV3YXJkIFBvaW50czwvdGQ+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wU2V0dGluZ3MubG9hbl9yZXdhcmRfcG9pbnRzID8/IFwiXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKFwibG9hbl9yZXdhcmRfcG9pbnRzXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTYwMFwiPntzZXR0aW5ncy5sb2FuX3Jld2FyZF9wb2ludHN9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgdGV4dC1ncmF5LTYwMFwiPlBvaW50cyBhd2FyZGVkIGZvciBlYWNoIGxvYW4gam9pbjwvdGQ+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktNTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPlJld2FyZCBQb2ludCBWYWx1ZTwvdGQ+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXItMiB0ZXh0LWdyYXktNjAwXCI+4oK5PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wU2V0dGluZ3MucmV3YXJkX3BvaW50X3ZhbHVlID8/IFwiXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoXCJyZXdhcmRfcG9pbnRfdmFsdWVcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTYwMFwiPuKCuXtzZXR0aW5ncy5yZXdhcmRfcG9pbnRfdmFsdWV9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5wZXIgcG9pbnQ8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNCB0ZXh0LWdyYXktNjAwXCI+TW9uZXRhcnkgdmFsdWUgb2YgZWFjaCByZXdhcmQgcG9pbnQ8L3RkPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktNTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPkVucm9sbG1lbnQgRGl2aXNvcjwvdGQ+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wU2V0dGluZ3MuZW5yb2xsbWVudF9kaXZpc29yID8/IFwiXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKFwiZW5yb2xsbWVudF9kaXZpc29yXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTYwMFwiPntzZXR0aW5ncy5lbnJvbGxtZW50X2Rpdmlzb3J9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgdGV4dC1ncmF5LTYwMFwiPlJld2FyZCBQb2ludHMgYXJlIGF3YXJkZWQgYXQgdGhlIHJhdGUgb2Ygb25lIHBvaW50IGZvciBldmVyeSDigrkxIGxha2ggb2YgY2hpdCBlbnJvbGxtZW50IHZhbHVlLCBjYWxjdWxhdGVkIGFzOiAoQ2hpdCBFbnJvbGxtZW50IEdyb3VwIFZhbHVlIMO3IEVucm9sbG1lbnQgRGl2aXNvcikuPC90ZD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4vLyAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgIFxyXG4vLyAgICAgICAgICAgICAgICAge2lzRWRpdGluZyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2FuY2VsfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxGaVggLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3VwZGF0ZVNldHRpbmdzfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmVlbi03MDAgdHJhbnNpdGlvbi1jb2xvcnMgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPEZpU2F2ZSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyBcIlNhdmluZy4uLlwiIDogXCJTYXZlIENoYW5nZXNcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBBZGRpdGlvbmFsIEluZm9ybWF0aW9uIENhcmQgKi99XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBwLTZcIj5cclxuLy8gICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItNFwiPlJld2FyZCBQb2ludHMgSW5mb3JtYXRpb248L2gzPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPkhvdyBSZXdhcmQgUG9pbnRzIFdvcms8L2g0PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIHRleHQtc20gbGVhZGluZy1yZWxheGVkXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgUmV3YXJkIHBvaW50cyBhcmUgYXV0b21hdGljYWxseSBjcmVkaXRlZCB0byB1c2VycyB3aGVuIHRoZXkgbWVldCBzcGVjaWZpYyBjcml0ZXJpYSBzdWNoIGFzIGpvaW5pbmcgYSBsb2FuIGdyb3VwIG9yIG9wZW5pbmcgYSBwaWdteSBhY2NvdW50LiBUaGUgcG9pbnQgdmFsdWUgZGV0ZXJtaW5lcyB0aGUgbW9uZXRhcnkgZXF1aXZhbGVudCBvZiBlYWNoIHBvaW50LlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5DdXJyZW50IENvbmZpZ3VyYXRpb24gU3VtbWFyeTwvaDQ+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTUwIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItdmlvbGV0LTEwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5QaWdteSBQb2ludHM6PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtdmlvbGV0LTYwMFwiPntzZXR0aW5ncy5waWdteV9yZXdhcmRfcG9pbnRzfSBwdHM8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPkxvYW4gUG9pbnRzOjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXZpb2xldC02MDBcIj57c2V0dGluZ3MubG9hbl9yZXdhcmRfcG9pbnRzfSBwdHM8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5Qb2ludCBWYWx1ZTo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmVlbi02MDBcIj7igrl7c2V0dGluZ3MucmV3YXJkX3BvaW50X3ZhbHVlfTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuY29uc3QgUmV3YXJkU2V0dGluZ3MgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3NldHRpbmdzLCBzZXRTZXR0aW5nc10gPSB1c2VTdGF0ZSh7XHJcbiAgICByZXdhcmRfcG9pbnRfdmFsdWU6IFwiXCIsXHJcbiAgICBsb2FuX3Jld2FyZF9wb2ludHM6IFwiXCIsXHJcbiAgICBwaWdteV9yZXdhcmRfcG9pbnRzOiBcIlwiLFxyXG4gICAgZW5yb2xsbWVudF9kaXZpc29yOiBcIlwiLFxyXG4gICAgYXVjdGlvbl9wYXlfcmV3YXJkX3ZhbHVlOiBcIlwiLFxyXG4gICAgcGF5bWVudF9saW5rX3Jld2FyZF92YWx1ZTogXCJcIixcclxuICAgIGN1c3RvbWVyX3JlZmVycmFsX3ZhbHVlOiBcIlwiLFxyXG4gICAgLy8gTmV3IGZpZWxkc1xyXG4gICAgbWlsZXN0b25lX3Jld2FyZF92YWx1ZTogXCJcIixcclxuICAgIHJlZmVycmFsX2JvbnVzX3BvaW50czogXCJcIixcclxuICAgIGFubml2ZXJzYXJ5X3Jld2FyZF9wb2ludHM6IFwiXCIsXHJcbiAgfSk7XHJcbiAgXHJcbiAgY29uc3QgW3RlbXBTZXR0aW5ncywgc2V0VGVtcFNldHRpbmdzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzRWRpdGluZywgc2V0SXNFZGl0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd1N1Y2Nlc3MsIHNldFNob3dTdWNjZXNzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdXBkYXRlTWVzc2FnZSwgc2V0VXBkYXRlTWVzc2FnZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgLyogPT09PT09PT09PT09PT09PT0gRkVUQ0ggU0VUVElOR1MgPT09PT09PT09PT09PT09PT0gKi9cclxuICBjb25zdCBmZXRjaFNldHRpbmdzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9yZXdhcmQtcG9pbnRzL3Jld2FyZC1zZXR0aW5nc1wiKTtcclxuICAgICAgY29uc29sZS5pbmZvKHJlcywgXCJnZmpza2dmc2Rnc2RnXCIpO1xyXG4gICAgICBpZiAocmVzLmRhdGE/LnN1Y2Nlc3MpIHtcclxuICAgICAgICBzZXRTZXR0aW5ncyhyZXMuZGF0YS5zZXR0aW5ncyk7XHJcbiAgICAgICAgc2V0VGVtcFNldHRpbmdzKHJlcy5kYXRhLnNldHRpbmdzKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcmV3YXJkIHNldHRpbmdzXCIsIGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoU2V0dGluZ3MoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8qID09PT09PT09PT09PT09PT09IFVQREFURSBTRVRUSU5HUyA9PT09PT09PT09PT09PT09PSAqL1xyXG4gIGNvbnN0IHVwZGF0ZVNldHRpbmdzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnB1dChcIi9yZXdhcmQtcG9pbnRzL3Jld2FyZC1zZXR0aW5nc1wiLCB7XHJcbiAgICAgICAgcmV3YXJkX3BvaW50X3ZhbHVlOiBOdW1iZXIodGVtcFNldHRpbmdzLnJld2FyZF9wb2ludF92YWx1ZSksXHJcbiAgICAgICAgbG9hbl9yZXdhcmRfcG9pbnRzOiBOdW1iZXIodGVtcFNldHRpbmdzLmxvYW5fcmV3YXJkX3BvaW50cyksXHJcbiAgICAgICAgcGlnbXlfcmV3YXJkX3BvaW50czogTnVtYmVyKHRlbXBTZXR0aW5ncy5waWdteV9yZXdhcmRfcG9pbnRzKSxcclxuICAgICAgICBlbnJvbGxtZW50X2Rpdmlzb3I6IE51bWJlcih0ZW1wU2V0dGluZ3MuZW5yb2xsbWVudF9kaXZpc29yKSxcclxuICAgICAgICBhdWN0aW9uX3BheV9yZXdhcmRfdmFsdWU6IE51bWJlcih0ZW1wU2V0dGluZ3MuYXVjdGlvbl9wYXlfcmV3YXJkX3ZhbHVlKSxcclxuICAgICAgICBwYXltZW50X2xpbmtfcmV3YXJkX3ZhbHVlOiBOdW1iZXIodGVtcFNldHRpbmdzLnBheW1lbnRfbGlua19yZXdhcmRfdmFsdWUpLFxyXG4gICAgICAgIGN1c3RvbWVyX3JlZmVycmFsX3ZhbHVlOiBOdW1iZXIodGVtcFNldHRpbmdzLmN1c3RvbWVyX3JlZmVycmFsX3ZhbHVlKSxcclxuICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YT8uc3VjY2Vzcykge1xyXG4gICAgICAgIHNldFNldHRpbmdzKHRlbXBTZXR0aW5ncyk7XHJcbiAgICAgICAgc2V0SXNFZGl0aW5nKGZhbHNlKTtcclxuICAgICAgICBzZXRVcGRhdGVNZXNzYWdlKFwiUmV3YXJkIHNldHRpbmdzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuICAgICAgICBzZXRTaG93U3VjY2Vzcyh0cnVlKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFNob3dTdWNjZXNzKGZhbHNlKSwgMzAwMCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRVcGRhdGVNZXNzYWdlKFwiRmFpbGVkIHRvIHVwZGF0ZSByZXdhcmQgc2V0dGluZ3NcIik7XHJcbiAgICAgIHNldFNob3dTdWNjZXNzKHRydWUpO1xyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFNob3dTdWNjZXNzKGZhbHNlKSwgMzAwMCk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFZGl0ID0gKCkgPT4ge1xyXG4gICAgc2V0VGVtcFNldHRpbmdzKHNldHRpbmdzKTtcclxuICAgIHNldElzRWRpdGluZyh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDYW5jZWwgPSAoKSA9PiB7XHJcbiAgICBzZXRUZW1wU2V0dGluZ3Moc2V0dGluZ3MpO1xyXG4gICAgc2V0SXNFZGl0aW5nKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldFRlbXBTZXR0aW5ncyh7IC4uLnRlbXBTZXR0aW5ncywgW2ZpZWxkXTogdmFsdWUgfSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgPE5hdmJhciB2aXNpYmlsaXR5IC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxTZXR0aW5nU2lkZWJhciAvPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNXhsIG14LWF1dG9cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgUmV3YXJkIFBvaW50cyBcclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgIHshaXNFZGl0aW5nICYmIChcclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRWRpdH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLXZpb2xldC03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8RmlFZGl0MiAvPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IFNldHRpbmdzXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdWNjZXNzIE1lc3NhZ2UgKi99XHJcbiAgICAgICAgICAgIHtzaG93U3VjY2VzcyAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BtYi02IHAtNCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yICR7XHJcbiAgICAgICAgICAgICAgICB1cGRhdGVNZXNzYWdlLmluY2x1ZGVzKFwic3VjY2Vzc2Z1bGx5XCIpIFxyXG4gICAgICAgICAgICAgICAgICA/IFwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tNzAwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCIgXHJcbiAgICAgICAgICAgICAgICAgIDogXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCBib3JkZXIgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgIH1gfT5cclxuICAgICAgICAgICAgICAgIDxGaUNoZWNrQ2lyY2xlIC8+XHJcbiAgICAgICAgICAgICAgICB7dXBkYXRlTWVzc2FnZX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBSZXdhcmQgUG9pbnRzIFRhYmxlICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXNtIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMCB0ZXh0LXdoaXRlIHAtNVwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZFwiPkN1cnJlbnQgUmV3YXJkIFBvaW50cyBTZXR0aW5nczwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC0xMDAgbXQtMVwiPk1hbmFnZSB5b3VyIHJld2FyZCBwb2ludHMgY29uZmlndXJhdGlvbjwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0zIHB4LTQgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+U2V0dGluZzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTMgcHgtNCBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5WYWx1ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTMgcHgtNCBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5EZXNjcmlwdGlvbjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0xMDAgaG92ZXI6YmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNCBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+UmV3YXJkIFBvaW50IFZhbHVlPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yIHRleHQtZ3JheS02MDBcIj7igrk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBTZXR0aW5ncy5yZXdhcmRfcG9pbnRfdmFsdWUgPz8gXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcInJld2FyZF9wb2ludF92YWx1ZVwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+4oK5e3NldHRpbmdzLnJld2FyZF9wb2ludF92YWx1ZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPnBlciBwb2ludDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00IHRleHQtZ3JheS02MDBcIj5Nb25ldGFyeSB2YWx1ZSBvZiBlYWNoIHJld2FyZCBwb2ludDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPlBpZ215IFJld2FyZCBQb2ludHM8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFNldHRpbmdzLnBpZ215X3Jld2FyZF9wb2ludHMgPz8gXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoXCJwaWdteV9yZXdhcmRfcG9pbnRzXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTYwMFwiPntzZXR0aW5ncy5waWdteV9yZXdhcmRfcG9pbnRzfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00IHRleHQtZ3JheS02MDBcIj5Qb2ludHMgYXdhcmRlZCBmb3IgcGlnbXkgZW5yb2xsbWVudHM8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBob3ZlcjpiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00IGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5Mb2FuIFJld2FyZCBQb2ludHM8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFNldHRpbmdzLmxvYW5fcmV3YXJkX3BvaW50cyA/PyBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcImxvYW5fcmV3YXJkX3BvaW50c1wiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC02MDBcIj57c2V0dGluZ3MubG9hbl9yZXdhcmRfcG9pbnRzfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00IHRleHQtZ3JheS02MDBcIj5Qb2ludHMgYXdhcmRlZCBmb3IgZWFjaCBsb2FuIGpvaW48L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBob3ZlcjpiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00IGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5FbnJvbGxtZW50IERpdmlzb3I8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFNldHRpbmdzLmVucm9sbG1lbnRfZGl2aXNvciA/PyBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcImVucm9sbG1lbnRfZGl2aXNvclwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC02MDBcIj57c2V0dGluZ3MuZW5yb2xsbWVudF9kaXZpc29yfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00IHRleHQtZ3JheS02MDBcIj5SZXdhcmQgUG9pbnRzIGFyZSBhd2FyZGVkIGF0IHRoZSByYXRlIG9mIG9uZSBwb2ludCBmb3IgZXZlcnkg4oK5MSBsYWtoIG9mIGNoaXQgZW5yb2xsbWVudCB2YWx1ZTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPk5vIER1ZSBSZXdhcmQgVmFsdWU8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFNldHRpbmdzLmF1Y3Rpb25fcGF5X3Jld2FyZF92YWx1ZSA/PyBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcImF1Y3Rpb25fcGF5X3Jld2FyZF92YWx1ZVwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC02MDBcIj57c2V0dGluZ3MuYXVjdGlvbl9wYXlfcmV3YXJkX3ZhbHVlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00IHRleHQtZ3JheS02MDBcIj5Qb2ludHMgYXdhcmRlZCBmb3Igc3VjY2Vzc2Z1bCBhdWN0aW9uIHBheW1lbnRzPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0xMDAgaG92ZXI6YmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNCBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+UGF5bWVudCBMaW5rIFJld2FyZCBWYWx1ZTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wU2V0dGluZ3MucGF5bWVudF9saW5rX3Jld2FyZF92YWx1ZSA/PyBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcInBheW1lbnRfbGlua19yZXdhcmRfdmFsdWVcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC12aW9sZXQtNjAwXCI+e3NldHRpbmdzLnBheW1lbnRfbGlua19yZXdhcmRfdmFsdWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgdGV4dC1ncmF5LTYwMFwiPlBvaW50cyBhd2FyZGVkIGZvciBwYXltZW50cyBtYWRlIHRocm91Z2ggcGF5bWVudCBsaW5rczwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPkN1c3RvbWVyIFJlZmVycmFsIFZhbHVlPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBTZXR0aW5ncy5jdXN0b21lcl9yZWZlcnJhbF92YWx1ZSA/PyBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcImN1c3RvbWVyX3JlZmVycmFsX3ZhbHVlXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTYwMFwiPntzZXR0aW5ncy5jdXN0b21lcl9yZWZlcnJhbF92YWx1ZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNCB0ZXh0LWdyYXktNjAwXCI+UG9pbnRzIGF3YXJkZWQgZm9yIHN1Y2Nlc3NmdWwgY3VzdG9tZXIgcmVmZXJyYWxzPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB7aXNFZGl0aW5nICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDYW5jZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZpWCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17dXBkYXRlU2V0dGluZ3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8RmlTYXZlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IFwiU2F2aW5nLi4uXCIgOiBcIlNhdmUgQ2hhbmdlc1wifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEFkZGl0aW9uYWwgSW5mb3JtYXRpb24gQ2FyZCAqL31cclxuICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBwLTZcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItNFwiPlJld2FyZCBQb2ludHMgSW5mb3JtYXRpb248L2gzPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPkhvdyBSZXdhcmQgUG9pbnRzIFdvcms8L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIHRleHQtc20gbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUmV3YXJkIHBvaW50cyBhcmUgYXV0b21hdGljYWxseSBjcmVkaXRlZCB0byB1c2VycyB3aGVuIHRoZXkgbWVldCBzcGVjaWZpYyBjcml0ZXJpYSBzdWNoIGFzIGpvaW5pbmcgYSBsb2FuIGdyb3VwLCBvcGVuaW5nIGEgcGlnbXkgYWNjb3VudCwgb3IgcmVhY2hpbmcgbWlsZXN0b25lcy4gVGhlIHBvaW50IHZhbHVlIGRldGVybWluZXMgdGhlIG1vbmV0YXJ5IGVxdWl2YWxlbnQgb2YgZWFjaCBwb2ludC5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+Q3VycmVudCBDb25maWd1cmF0aW9uIFN1bW1hcnk8L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLXZpb2xldC0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+UGlnbXkgUG9pbnRzOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXZpb2xldC02MDBcIj57c2V0dGluZ3MucGlnbXlfcmV3YXJkX3BvaW50c30gcHRzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5Mb2FuIFBvaW50czo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC12aW9sZXQtNjAwXCI+e3NldHRpbmdzLmxvYW5fcmV3YXJkX3BvaW50c30gcHRzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5SZWZlcnJhbCBWYWx1ZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC12aW9sZXQtNjAwXCI+e3NldHRpbmdzLmN1c3RvbWVyX3JlZmVycmFsX3ZhbHVlfSBwdHM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5Qb2ludCBWYWx1ZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmVlbi02MDBcIj7igrl7c2V0dGluZ3MucmV3YXJkX3BvaW50X3ZhbHVlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJld2FyZFNldHRpbmdzO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUmV3YXJkU2V0dGluZ3MuanN4In0=