import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/modals/UploadModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import * as XLSX from "/node_modules/.vite/deps/xlsx.js?v=819e0a34";
const UploadModal = ({ show, onClose, onSubmit, groups, selectedGroupId, handleGroup, handleChangeUser, formData, filteredAuction }) => {
  if (!show) return null;
  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };
  const downloadExcel = () => {
    const data = [
      { payment_date: "", old_receipt_number: "", payment_type: "", amount: "" }
    ];
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    XLSX.writeFile(workbook, "payment-upload.xlsx");
  };
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-40",
      onClick: handleOverlayClick,
      children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-lg shadow-lg max-w-2xl w-full", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold", children: "Upload Payment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
            lineNumber: 29,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: downloadExcel,
              className: "bg-green-500 text-white px-4 py-2 rounded shadow-md hover:bg-green-600 transition duration-200",
              children: "Download Excel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
              lineNumber: 30,
              columnNumber: 11
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
          lineNumber: 28,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mb-4", children: /* @__PURE__ */ jsxDEV(
            "select",
            {
              name: "selectOption1",
              value: selectedGroupId,
              onChange: handleGroup,
              required: true,
              className: "w-full border border-gray-300 rounded-md p-2 mr-2",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", disabled: true, selected: true, children: "Select Customer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
                  lineNumber: 46,
                  columnNumber: 15
                }, this),
                groups.map(
                  (group) => /* @__PURE__ */ jsxDEV("option", { value: group._id, children: group.full_name }, group._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
                    lineNumber: 50,
                    columnNumber: 15
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
              lineNumber: 39,
              columnNumber: 13
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
            lineNumber: 38,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mb-4", children: /* @__PURE__ */ jsxDEV(
            "select",
            {
              name: "group_id",
              onChange: handleChangeUser,
              required: true,
              className: "w-full border border-gray-300 rounded-md p-2 mr-2",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Group | Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
                  lineNumber: 63,
                  columnNumber: 15
                }, this),
                filteredAuction.map((group) => {
                  if (!group.enrollment.group) return null;
                  return /* @__PURE__ */ jsxDEV(
                    "option",
                    {
                      value: `chit-${group.enrollment.group._id}|${group.enrollment.tickets}`,
                      children: [
                        group.enrollment.group.group_name,
                        " | ",
                        group.enrollment.tickets
                      ]
                    },
                    group.enrollment.group._id,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
                      lineNumber: 68,
                      columnNumber: 19
                    },
                    this
                  );
                })
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
              lineNumber: 57,
              columnNumber: 13
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
            lineNumber: 56,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "file",
              name: "file",
              accept: ".xlsx, .xls",
              required: true,
              className: "block w-full border border-gray-300 rounded-md mb-4 p-2"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
              lineNumber: 78,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "bg-gray-300 text-black px-4 py-2 rounded shadow-md hover:bg-gray-400 transition duration-200",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
                lineNumber: 86,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "bg-violet-500 text-white px-4 py-2 rounded shadow-md hover:bg-violet-600 transition duration-200",
                children: "Upload"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
                lineNumber: 93,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
            lineNumber: 85,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
          lineNumber: 37,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
        lineNumber: 27,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx",
      lineNumber: 23,
      columnNumber: 5
    },
    this
  );
};
_c = UploadModal;
export default UploadModal;
var _c;
$RefreshReg$(_c, "UploadModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/UploadModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJVO0FBNUJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFlBQVlBLFVBQVU7QUFFdEIsTUFBTUMsY0FBY0EsQ0FBQyxFQUFFQyxNQUFNQyxTQUFTQyxVQUFVQyxRQUFRQyxpQkFBaUJDLGFBQWFDLGtCQUFrQkMsVUFBVUMsZ0JBQWdCLE1BQU07QUFDdEksTUFBSSxDQUFDUixLQUFNLFFBQU87QUFFbEIsUUFBTVMscUJBQXFCQSxDQUFDQyxNQUFNO0FBQ2hDLFFBQUlBLEVBQUVDLFdBQVdELEVBQUVFLGNBQWVYLFNBQVE7QUFBQSxFQUM1QztBQUVBLFFBQU1ZLGdCQUFnQkEsTUFBTTtBQUMxQixVQUFNQyxPQUFPO0FBQUEsTUFDWCxFQUFFQyxjQUFjLElBQUlDLG9CQUFvQixJQUFJQyxjQUFjLElBQUlDLFFBQVEsR0FBRztBQUFBLElBQUM7QUFHNUUsVUFBTUMsWUFBWXJCLEtBQUtzQixNQUFNQyxjQUFjUCxJQUFJO0FBQy9DLFVBQU1RLFdBQVd4QixLQUFLc0IsTUFBTUcsU0FBUztBQUNyQ3pCLFNBQUtzQixNQUFNSSxrQkFBa0JGLFVBQVVILFdBQVcsUUFBUTtBQUMxRHJCLFNBQUsyQixVQUFVSCxVQUFVLHFCQUFxQjtBQUFBLEVBQ2hEO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVTtBQUFBLE1BQ1YsU0FBU2I7QUFBQUEsTUFFVCxpQ0FBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUscUJBQW9CLDhCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQ2hEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTSTtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUFnRztBQUFBO0FBQUEsWUFGNUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxVQUNKO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPVDtBQUFBQSxjQUNQLFVBQVVDO0FBQUFBLGNBQ1Y7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsWUFBTyxPQUFNLElBQUcsVUFBUSxNQUFDLFVBQVEsTUFBQywrQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNDRixPQUFPdUI7QUFBQUEsa0JBQUksQ0FBQ0MsVUFDWCx1QkFBQyxZQUF1QixPQUFPQSxNQUFNQyxLQUNsQ0QsZ0JBQU1FLGFBRElGLE1BQU1DLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUE7QUFBQSxZQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWVBLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFVBQVV0QjtBQUFBQSxjQUNWO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFlBQU8sT0FBTSxJQUFHLHFDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUNyQ0UsZ0JBQWdCa0IsSUFBSSxDQUFDQyxVQUFVO0FBQzlCLHNCQUFJLENBQUNBLE1BQU1HLFdBQVdILE1BQU8sUUFBTztBQUVwQyx5QkFDRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFQyxPQUFPLFFBQVFBLE1BQU1HLFdBQVdILE1BQU1DLEdBQUcsSUFBSUQsTUFBTUcsV0FBV0MsT0FBTztBQUFBLHNCQUVwRUo7QUFBQUEsOEJBQU1HLFdBQVdILE1BQU1LO0FBQUFBLHdCQUFXO0FBQUEsd0JBQUlMLE1BQU1HLFdBQVdDO0FBQUFBO0FBQUFBO0FBQUFBLG9CQUhuREosTUFBTUcsV0FBV0gsTUFBTUM7QUFBQUEsb0JBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxnQkFFSixDQUFDO0FBQUE7QUFBQTtBQUFBLFlBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQO0FBQUEsY0FDQSxXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtxRTtBQUFBLFVBRXJFLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMzQjtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQThGO0FBQUE7QUFBQSxjQUgxRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUFrRztBQUFBO0FBQUEsY0FGOUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxhQTlERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0RBO0FBQUEsV0F6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBFQTtBQUFBO0FBQUEsSUE5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBK0VBO0FBR0o7QUFBRWdDLEtBckdJbEM7QUF1R04sZUFBZUE7QUFBWSxJQUFBa0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlhMU1giLCJVcGxvYWRNb2RhbCIsInNob3ciLCJvbkNsb3NlIiwib25TdWJtaXQiLCJncm91cHMiLCJzZWxlY3RlZEdyb3VwSWQiLCJoYW5kbGVHcm91cCIsImhhbmRsZUNoYW5nZVVzZXIiLCJmb3JtRGF0YSIsImZpbHRlcmVkQXVjdGlvbiIsImhhbmRsZU92ZXJsYXlDbGljayIsImUiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwiZG93bmxvYWRFeGNlbCIsImRhdGEiLCJwYXltZW50X2RhdGUiLCJvbGRfcmVjZWlwdF9udW1iZXIiLCJwYXltZW50X3R5cGUiLCJhbW91bnQiLCJ3b3Jrc2hlZXQiLCJ1dGlscyIsImpzb25fdG9fc2hlZXQiLCJ3b3JrYm9vayIsImJvb2tfbmV3IiwiYm9va19hcHBlbmRfc2hlZXQiLCJ3cml0ZUZpbGUiLCJtYXAiLCJncm91cCIsIl9pZCIsImZ1bGxfbmFtZSIsImVucm9sbG1lbnQiLCJ0aWNrZXRzIiwiZ3JvdXBfbmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlVwbG9hZE1vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSByZWFjdC9wcm9wLXR5cGVzICovXHJcbmltcG9ydCAqIGFzIFhMU1ggZnJvbSBcInhsc3hcIjtcclxuXHJcbmNvbnN0IFVwbG9hZE1vZGFsID0gKHsgc2hvdywgb25DbG9zZSwgb25TdWJtaXQsIGdyb3Vwcywgc2VsZWN0ZWRHcm91cElkLCBoYW5kbGVHcm91cCwgaGFuZGxlQ2hhbmdlVXNlciwgZm9ybURhdGEsIGZpbHRlcmVkQXVjdGlvbiB9KSA9PiB7XHJcbiAgaWYgKCFzaG93KSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3QgaGFuZGxlT3ZlcmxheUNsaWNrID0gKGUpID0+IHtcclxuICAgIGlmIChlLnRhcmdldCA9PT0gZS5jdXJyZW50VGFyZ2V0KSBvbkNsb3NlKCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZG93bmxvYWRFeGNlbCA9ICgpID0+IHtcclxuICAgIGNvbnN0IGRhdGEgPSBbXHJcbiAgICAgIHsgcGF5bWVudF9kYXRlOiBcIlwiLCBvbGRfcmVjZWlwdF9udW1iZXI6IFwiXCIsIHBheW1lbnRfdHlwZTogXCJcIiwgYW1vdW50OiBcIlwiIH1cclxuICAgIF07XHJcblxyXG4gICAgY29uc3Qgd29ya3NoZWV0ID0gWExTWC51dGlscy5qc29uX3RvX3NoZWV0KGRhdGEpO1xyXG4gICAgY29uc3Qgd29ya2Jvb2sgPSBYTFNYLnV0aWxzLmJvb2tfbmV3KCk7XHJcbiAgICBYTFNYLnV0aWxzLmJvb2tfYXBwZW5kX3NoZWV0KHdvcmtib29rLCB3b3Jrc2hlZXQsIFwiU2hlZXQxXCIpO1xyXG4gICAgWExTWC53cml0ZUZpbGUod29ya2Jvb2ssIFwicGF5bWVudC11cGxvYWQueGxzeFwiKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrIGJnLW9wYWNpdHktNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei00MFwiXHJcbiAgICAgIG9uQ2xpY2s9e2hhbmRsZU92ZXJsYXlDbGlja31cclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC1sZyBzaGFkb3ctbGcgbWF4LXctMnhsIHctZnVsbFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZFwiPlVwbG9hZCBQYXltZW50PC9oMj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17ZG93bmxvYWRFeGNlbH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTYwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIERvd25sb2FkIEV4Y2VsXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17b25TdWJtaXR9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICBuYW1lPVwic2VsZWN0T3B0aW9uMVwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXBJZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlR3JvdXB9XHJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHAtMiBtci0yXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZCBzZWxlY3RlZD5cclxuICAgICAgICAgICAgICAgIFNlbGVjdCBDdXN0b21lclxyXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgIHtncm91cC5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlVXNlcn1cclxuICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgcC0yIG1yLTJcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBHcm91cCB8IFRpY2tldDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIHtmaWx0ZXJlZEF1Y3Rpb24ubWFwKChncm91cCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFncm91cC5lbnJvbGxtZW50Lmdyb3VwKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtncm91cC5lbnJvbGxtZW50Lmdyb3VwLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YGNoaXQtJHtncm91cC5lbnJvbGxtZW50Lmdyb3VwLl9pZH18JHtncm91cC5lbnJvbGxtZW50LnRpY2tldHN9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtncm91cC5lbnJvbGxtZW50Lmdyb3VwLmdyb3VwX25hbWV9IHwge2dyb3VwLmVucm9sbG1lbnQudGlja2V0c31cclxuICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgbmFtZT1cImZpbGVcIlxyXG4gICAgICAgICAgICBhY2NlcHQ9XCIueGxzeCwgLnhsc1wiXHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgbWItNCBwLTJcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0zMDAgdGV4dC1ibGFjayBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctZ3JheS00MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTUwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtNjAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFVwbG9hZFxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFVwbG9hZE1vZGFsO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvY29tcG9uZW50cy9tb2RhbHMvVXBsb2FkTW9kYWwuanN4In0=