import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AdvanceSalary.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Drawer, Modal, Empty, Alert } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { FiCalendar, FiCreditCard, FiHash } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
const EmployeeAdvancePayment = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [tablePayments, setTablePayments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [editId, setEditId] = useState(null);
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const initialForm = {
    employee_id: "",
    pay_date: today,
    month: (/* @__PURE__ */ new Date()).toLocaleString("default", { month: "long" }),
    pay_type: "cash",
    transaction_id: "",
    amount: 0
  };
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info",
    noReload: true
  });
  useEffect(() => {
    if (alertConfig.visibility) {
      const timer = setTimeout(() => {
        setAlertConfig((prev) => ({ ...prev, visibility: false }));
      }, 3e3);
      return () => clearTimeout(timer);
    }
  }, [alertConfig.visibility]);
  useEffect(() => {
    fetchEmployees();
    fetchAdvanceHistory();
  }, []);
  const fetchEmployees = async () => {
    const res = await api.get("/employee");
    if (res.data.status) setEmployees(res.data.employee);
  };
  const fetchAdvanceHistory = async () => {
    try {
      setIsLoading(true);
      const response = await api.get("/advance-payment/get-advances");
      const formatted = response.data.map((item, index) => ({
        ...item,
        id: index + 1,
        date: item.pay_date?.split("T")[0],
        employeeName: item.employee_id?.name || "N/A",
        action: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            menu: {
              items: [
                { key: "1", label: "Edit", onClick: () => handleEdit(item) },
                {
                  key: "2",
                  label: /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "Delete" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                    lineNumber: 78,
                    columnNumber: 22
                  }, this),
                  onClick: () => showDeleteConfirm(item._id)
                }
              ]
            },
            trigger: ["click"],
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 84,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
            lineNumber: 72,
            columnNumber: 9
          },
          this
        )
      }));
      setTablePayments(formatted);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  const showDeleteConfirm = (id) => {
    Modal.confirm({
      title: "Are you sure you want to delete this record?",
      content: "This action cannot be undone.",
      okText: "Yes, Delete",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete(id);
      }
    });
  };
  const handleEdit = (item) => {
    const employeeId = typeof item.employee_id === "object" ? item.employee_id._id : item.employee_id;
    setEditId(item._id);
    setFormData({
      employee_id: employeeId,
      pay_date: item.pay_date?.split("T")[0],
      month: item.month || (/* @__PURE__ */ new Date()).toLocaleString("default", { month: "long" }),
      pay_type: item.pay_type,
      transaction_id: item.transaction_id || "",
      amount: item.amount
    });
    setShowModal(true);
  };
  const handleDelete = async (id) => {
    try {
      setOpenBackdropLoader(true);
      await api.delete(`/advance-payment/delete-advance/${id}`);
      setAlertConfig({
        visibility: true,
        message: "Data Deleted Successfully!",
        type: "success",
        noReload: true
      });
      fetchAdvanceHistory();
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Delete failed",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    console.log(editId, "this is editId", formData);
    try {
      setOpenBackdropLoader(true);
      if (editId) {
        await api.put(`/advance-payment/update-advance/${editId}`, formData);
      } else {
        await api.post("/advance-payment/add-advance", formData);
      }
      setAlertConfig({
        visibility: true,
        message: editId ? "Data Updated Successfully!" : "Data Added Successfully!",
        type: "success",
        noReload: true
      });
      closeDrawer();
      fetchAdvanceHistory();
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Error saving data",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  const validateForm = () => {
    const errs = {};
    if (!formData.employee_id) errs.employee = "Required";
    if (!formData.amount || formData.amount <= 0)
      errs.amount = "Enter valid amount";
    if (!formData.month) errs.month = "Required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };
  const closeDrawer = () => {
    setShowModal(false);
    setEditId(null);
    setFormData(initialForm);
    setErrors({});
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "employeeName", header: "Employee" },
    { key: "month", header: "Month" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Mode" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    openBackdropLoader && /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "Processing..." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
      lineNumber: 212,
      columnNumber: 30
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
          lineNumber: 214,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
        lineNumber: 218,
        columnNumber: 9
      }, this),
      alertConfig.visibility && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-5 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-md px-4", children: /* @__PURE__ */ jsxDEV(
        Alert,
        {
          message: alertConfig.message,
          type: alertConfig.type,
          showIcon: true,
          closable: true,
          onClose: () => setAlertConfig({ ...alertConfig, visibility: false })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
          lineNumber: 221,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
        lineNumber: 220,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
          lineNumber: 232,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Employee Advances" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
            lineNumber: 234,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setEditId(null);
                setFormData(initialForm);
                setShowModal(true);
              },
              className: "bg-violet-950 text-white px-4 py-2 rounded",
              children: "+ Add Advance"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 235,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
          lineNumber: 233,
          columnNumber: 11
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Advance Salary" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
          lineNumber: 248,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: tablePayments.filter(
              (item) => item.employeeName?.toLowerCase().includes(searchText.toLowerCase())
            ),
            columns
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
            lineNumber: 250,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
        lineNumber: 231,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Drawer,
        {
          title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-violet-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-violet-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 265,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 264,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: editId ? "Edit Advance Payment" : "New Advance Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 267,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
            lineNumber: 263,
            columnNumber: 11
          }, this),
          open: showModal,
          onClose: closeDrawer,
          width: 480,
          children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6 p-1", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                "Employee ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 279,
                  columnNumber: 26
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 278,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  size: "large",
                  className: "w-full",
                  placeholder: "Search and select employee",
                  value: formData.employee_id || void 0,
                  optionFilterProp: "label",
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  onChange: (val) => setFormData({ ...formData, employee_id: val }),
                  children: employees.map(
                    (emp) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: emp._id,
                        label: `${emp.name} ${emp.employeeCode}`,
                        children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 bg-violet-100 rounded-full flex items-center justify-center text-xs font-medium text-violet-700", children: emp.name.charAt(0).toUpperCase() }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                            lineNumber: 301,
                            columnNumber: 23
                          }, this),
                          emp.name,
                          " | ",
                          emp.employeeCode
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                          lineNumber: 300,
                          columnNumber: 21
                        }, this)
                      },
                      emp._id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                        lineNumber: 295,
                        columnNumber: 17
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 281,
                  columnNumber: 15
                },
                this
              ),
              errors.employee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 312,
                  columnNumber: 19
                }, this),
                errors.employee
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 311,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 277,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 321,
                  columnNumber: 17
                }, this),
                "Payment Date"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 320,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition",
                  value: formData.pay_date,
                  onChange: (e) => setFormData({ ...formData, pay_date: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 325,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 324,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 319,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 338,
                  columnNumber: 17
                }, this),
                "Amount ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 339,
                  columnNumber: 24
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 337,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-medium", children: "₹" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 342,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    step: "0.01",
                    className: "w-full border border-gray-300 rounded-lg pl-8 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition",
                    placeholder: "0.00",
                    value: formData.amount,
                    onChange: (e) => setFormData({ ...formData, amount: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                    lineNumber: 345,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 341,
                columnNumber: 15
              }, this),
              formData.amount && /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 border border-violet-200 rounded-lg px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-violet-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(formData.amount) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 358,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 357,
                columnNumber: 15
              }, this),
              errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 365,
                  columnNumber: 19
                }, this),
                errors.amount
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 364,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 336,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCreditCard, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 374,
                  columnNumber: 17
                }, this),
                "Payment Mode"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 373,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  className: "w-full",
                  value: formData.pay_type,
                  onChange: (val) => setFormData({ ...formData, pay_type: val }),
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cash" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                      lineNumber: 383,
                      columnNumber: 19
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                      lineNumber: 382,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Online/UPI" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                      lineNumber: 386,
                      columnNumber: 19
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                      lineNumber: 385,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cheque", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cheque" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                      lineNumber: 389,
                      columnNumber: 19
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                      lineNumber: 388,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 377,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 372,
              columnNumber: 13
            }, this),
            formData.pay_type !== "cash" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 animate-fadeIn", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiHash, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 398,
                  columnNumber: 19
                }, this),
                formData.pay_type === "cheque" ? "Cheque Number" : "Transaction ID"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 397,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition",
                  placeholder: formData.pay_type === "cheque" ? "Enter cheque number" : "Enter transaction/UPI ID",
                  value: formData.transaction_id,
                  onChange: (e) => setFormData({ ...formData, transaction_id: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                  lineNumber: 403,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 396,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-full bg-gradient-to-r from-violet-600 to-violet-700 text-white py-3 rounded-lg hover:from-violet-700 hover:to-violet-800 transition-all duration-200 font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5 flex items-center justify-center gap-2",
                children: editId ? "Update Advance Payment" : "Save Advance Payment"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
                lineNumber: 421,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
              lineNumber: 420,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
            lineNumber: 275,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
          lineNumber: 261,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
      lineNumber: 213,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx",
    lineNumber: 211,
    columnNumber: 5
  }, this);
};
_s(EmployeeAdvancePayment, "looicvpxDTbLb4dl+zT5a8dmxuU=");
_c = EmployeeAdvancePayment;
export default EmployeeAdvancePayment;
var _c;
$RefreshReg$(_c, "EmployeeAdvancePayment");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvanceSalary.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkV5QixTQXFJckIsVUFySXFCOzJCQTdFekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLFlBQVk7QUFDbkIsU0FBU0MsUUFBUUMsVUFBVUMsUUFBUUMsT0FBT0MsT0FBT0MsYUFBYTtBQUM5RCxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0Msd0JBQXdCO0FBQy9CLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxZQUFZQyxjQUFjQyxjQUFjO0FBQ2pELFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0Msb0JBQW9CO0FBQzNCLE1BQU1DLHlCQUF5QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJeEIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3lCLGVBQWVDLGdCQUFnQixJQUFJMUIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzJCLFdBQVdDLFlBQVksSUFBSTVCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM2QixXQUFXQyxZQUFZLElBQUk5QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDK0IsWUFBWUMsYUFBYSxJQUFJaEMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2lDLG9CQUFvQkMscUJBQXFCLElBQUlsQyxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDbUMsUUFBUUMsU0FBUyxJQUFJcEMsU0FBUyxJQUFJO0FBRXpDLFFBQU1xQyxTQUFRLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUVuRCxRQUFNQyxjQUFjO0FBQUEsSUFDbEJDLGFBQWE7QUFBQSxJQUNiQyxVQUFVTjtBQUFBQSxJQUNWTyxRQUFPLG9CQUFJTixLQUFLLEdBQUVPLGVBQWUsV0FBVyxFQUFFRCxPQUFPLE9BQU8sQ0FBQztBQUFBLElBQzdERSxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLFFBQVE7QUFBQSxFQUNWO0FBRUEsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlsRCxTQUFTeUMsV0FBVztBQUNwRCxRQUFNLENBQUNVLFFBQVFDLFNBQVMsSUFBSXBELFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ3FELGFBQWFDLGNBQWMsSUFBSXRELFNBQVM7QUFBQSxJQUM3Q3VELFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLElBQ05DLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRDNELFlBQVUsTUFBTTtBQUNkLFFBQUlzRCxZQUFZRSxZQUFZO0FBQzFCLFlBQU1JLFFBQVFDLFdBQVcsTUFBTTtBQUM3Qk4sdUJBQWUsQ0FBQ08sVUFBVSxFQUFFLEdBQUdBLE1BQU1OLFlBQVksTUFBTSxFQUFFO0FBQUEsTUFDM0QsR0FBRyxHQUFJO0FBQ1AsYUFBTyxNQUFNTyxhQUFhSCxLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsQ0FBQ04sWUFBWUUsVUFBVSxDQUFDO0FBQzNCeEQsWUFBVSxNQUFNO0FBQ2RnRSxtQkFBZTtBQUNmQyx3QkFBb0I7QUFBQSxFQUN0QixHQUFHLEVBQUU7QUFFTCxRQUFNRCxpQkFBaUIsWUFBWTtBQUNqQyxVQUFNRSxNQUFNLE1BQU0vRCxJQUFJZ0UsSUFBSSxXQUFXO0FBQ3JDLFFBQUlELElBQUlFLEtBQUtDLE9BQVE1QyxjQUFheUMsSUFBSUUsS0FBS0UsUUFBUTtBQUFBLEVBQ3JEO0FBRUEsUUFBTUwsc0JBQXNCLFlBQVk7QUFDdEMsUUFBSTtBQUNGbEMsbUJBQWEsSUFBSTtBQUNqQixZQUFNd0MsV0FBVyxNQUFNcEUsSUFBSWdFLElBQUksK0JBQStCO0FBQzlELFlBQU1LLFlBQVlELFNBQVNILEtBQUtLLElBQUksQ0FBQ0MsTUFBTUMsV0FBVztBQUFBLFFBQ3BELEdBQUdEO0FBQUFBLFFBQ0hFLElBQUlELFFBQVE7QUFBQSxRQUNaRSxNQUFNSCxLQUFLOUIsVUFBVUgsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQ2pDcUMsY0FBY0osS0FBSy9CLGFBQWFvQyxRQUFRO0FBQUEsUUFDeENDLFFBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU07QUFBQSxjQUNKQyxPQUFPO0FBQUEsZ0JBQ0wsRUFBRUMsS0FBSyxLQUFLQyxPQUFPLFFBQVFDLFNBQVNBLE1BQU1DLFdBQVdYLElBQUksRUFBRTtBQUFBLGdCQUMzRDtBQUFBLGtCQUNFUSxLQUFLO0FBQUEsa0JBQ0xDLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGdCQUFlLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQztBQUFBLGtCQUM1Q0MsU0FBU0EsTUFBTUUsa0JBQWtCWixLQUFLYSxHQUFHO0FBQUEsZ0JBQzNDO0FBQUEsY0FBQztBQUFBLFlBRUw7QUFBQSxZQUNBLFNBQVMsQ0FBQyxPQUFPO0FBQUEsWUFDakIsaUNBQUMsWUFBUyxXQUFVLDRCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBO0FBQUEsVUFaOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBYUE7QUFBQSxNQUVKLEVBQUU7QUFDRjVELHVCQUFpQjZDLFNBQVM7QUFBQSxJQUM1QixTQUFTZ0IsS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFDbkIsVUFBQztBQUNDekQsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU11RCxvQkFBb0JBLENBQUNWLE9BQU87QUFDaENsRSxVQUFNaUYsUUFBUTtBQUFBLE1BQ1pDLE9BQU87QUFBQSxNQUNQQyxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JDLFFBQVE7QUFBQSxNQUNSQyxZQUFZO0FBQUEsTUFDWkMsT0FBTztBQUNMQyxxQkFBYXRCLEVBQUU7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNUyxhQUFhQSxDQUFDWCxTQUFTO0FBQzNCLFVBQU15QixhQUNKLE9BQU96QixLQUFLL0IsZ0JBQWdCLFdBQ3hCK0IsS0FBSy9CLFlBQVk0QyxNQUNqQmIsS0FBSy9CO0FBRVhOLGNBQVVxQyxLQUFLYSxHQUFHO0FBQ2xCcEMsZ0JBQVk7QUFBQSxNQUNWUixhQUFhd0Q7QUFBQUEsTUFDYnZELFVBQVU4QixLQUFLOUIsVUFBVUgsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3JDSSxPQUNFNkIsS0FBSzdCLFVBQVMsb0JBQUlOLEtBQUssR0FBRU8sZUFBZSxXQUFXLEVBQUVELE9BQU8sT0FBTyxDQUFDO0FBQUEsTUFDdEVFLFVBQVUyQixLQUFLM0I7QUFBQUEsTUFDZkMsZ0JBQWdCMEIsS0FBSzFCLGtCQUFrQjtBQUFBLE1BQ3ZDQyxRQUFReUIsS0FBS3pCO0FBQUFBLElBQ2YsQ0FBQztBQUNEcEIsaUJBQWEsSUFBSTtBQUFBLEVBQ25CO0FBRUEsUUFBTXFFLGVBQWUsT0FBT3RCLE9BQU87QUFDakMsUUFBSTtBQUNGekMsNEJBQXNCLElBQUk7QUFDMUIsWUFBTWhDLElBQUlpRyxPQUFPLG1DQUFtQ3hCLEVBQUUsRUFBRTtBQUN4RHJCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsUUFDTkMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUNETSwwQkFBb0I7QUFBQSxJQUN0QixTQUFTeUIsT0FBTztBQUNkbkMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxRQUNOQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0N4Qiw0QkFBc0IsS0FBSztBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUVBLFFBQU1rRSxlQUFlLE9BQU9DLE1BQU07QUFDaENBLE1BQUVDLGVBQWU7QUFDakIsUUFBSSxDQUFDQyxhQUFhLEVBQUc7QUFDckJmLFlBQVFnQixJQUFJckUsUUFBUSxrQkFBa0JjLFFBQVE7QUFFOUMsUUFBSTtBQUNGZiw0QkFBc0IsSUFBSTtBQUMxQixVQUFJQyxRQUFRO0FBQ1YsY0FBTWpDLElBQUl1RyxJQUFJLG1DQUFtQ3RFLE1BQU0sSUFBSWMsUUFBUTtBQUFBLE1BQ3JFLE9BQU87QUFDTCxjQUFNL0MsSUFBSXdHLEtBQUssZ0NBQWdDekQsUUFBUTtBQUFBLE1BQ3pEO0FBQ0FLLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVNyQixTQUFTLCtCQUErQjtBQUFBLFFBQ2pEc0IsTUFBTTtBQUFBLFFBQ05DLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFDRGlELGtCQUFZO0FBQ1ozQywwQkFBb0I7QUFBQSxJQUN0QixTQUFTeUIsT0FBTztBQUNkbkMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxRQUNOQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0N4Qiw0QkFBc0IsS0FBSztBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUVBLFFBQU1xRSxlQUFlQSxNQUFNO0FBQ3pCLFVBQU1LLE9BQU8sQ0FBQztBQUNkLFFBQUksQ0FBQzNELFNBQVNQLFlBQWFrRSxNQUFLdkMsV0FBVztBQUMzQyxRQUFJLENBQUNwQixTQUFTRCxVQUFVQyxTQUFTRCxVQUFVO0FBQ3pDNEQsV0FBSzVELFNBQVM7QUFDaEIsUUFBSSxDQUFDQyxTQUFTTCxNQUFPZ0UsTUFBS2hFLFFBQVE7QUFDbENRLGNBQVV3RCxJQUFJO0FBQ2QsV0FBT0MsT0FBT0MsS0FBS0YsSUFBSSxFQUFFRyxXQUFXO0FBQUEsRUFDdEM7QUFFQSxRQUFNSixjQUFjQSxNQUFNO0FBQ3hCL0UsaUJBQWEsS0FBSztBQUNsQlEsY0FBVSxJQUFJO0FBQ2RjLGdCQUFZVCxXQUFXO0FBQ3ZCVyxjQUFVLENBQUMsQ0FBQztBQUFBLEVBQ2Q7QUFFQSxRQUFNNEQsVUFBVTtBQUFBLElBQ2QsRUFBRS9CLEtBQUssTUFBTWdDLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVoQyxLQUFLLFFBQVFnQyxRQUFRLFlBQVk7QUFBQSxJQUNuQyxFQUFFaEMsS0FBSyxnQkFBZ0JnQyxRQUFRLFdBQVc7QUFBQSxJQUMxQyxFQUFFaEMsS0FBSyxTQUFTZ0MsUUFBUSxRQUFRO0FBQUEsSUFDaEMsRUFBRWhDLEtBQUssVUFBVWdDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVoQyxLQUFLLFlBQVlnQyxRQUFRLE9BQU87QUFBQSxJQUNsQyxFQUFFaEMsS0FBSyxVQUFVZ0MsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxTQUNFLG1DQUNHaEY7QUFBQUEsMEJBQXNCLHVCQUFDLHNCQUFtQixPQUFPLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJDO0FBQUEsSUFDbEUsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCLENBQUNvRSxNQUFNckUsY0FBY3FFLEVBQUVhLE9BQU9DLEtBQUs7QUFBQSxVQUNoRSxZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUDlELFlBQVlFLGNBQ1gsdUJBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTRixZQUFZRztBQUFBQSxVQUNyQixNQUFNSCxZQUFZSTtBQUFBQSxVQUNsQjtBQUFBLFVBQ0E7QUFBQSxVQUNBLFNBQVMsTUFBTUgsZUFBZSxFQUFFLEdBQUdELGFBQWFFLFlBQVksTUFBTSxDQUFDO0FBQUE7QUFBQSxRQUxyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLdUUsS0FOekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNYLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSwwQkFBeUIsaUNBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsVUFDeEQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTtBQUNibkIsMEJBQVUsSUFBSTtBQUNkYyw0QkFBWVQsV0FBVztBQUN2QmIsNkJBQWEsSUFBSTtBQUFBLGNBQ25CO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBNkM7QUFBQTtBQUFBLFlBTnpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUdDQyxZQUNDLHVCQUFDLGtCQUFlLFdBQVcsTUFBTSxNQUFLLG9CQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNELElBRXREO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNSixjQUFjMkY7QUFBQUEsY0FBTyxDQUFDM0MsU0FDMUJBLEtBQUtJLGNBQ0R3QyxZQUFZLEVBQ2JDLFNBQVN2RixXQUFXc0YsWUFBWSxDQUFDO0FBQUEsWUFDdEM7QUFBQSxZQUNBO0FBQUE7QUFBQSxVQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1tQjtBQUFBLFdBekJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEJBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsZUFBWSxXQUFVLHFCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QyxLQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUseUJBQ2JsRixtQkFBUyx5QkFBeUIseUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVGLE1BQU1SO0FBQUFBLFVBQ04sU0FBU2dGO0FBQUFBLFVBQ1QsT0FBTztBQUFBLFVBQ1AsaUNBQUMsVUFBSyxVQUFVUCxjQUFjLFdBQVUsaUJBRXRDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkRBQTREO0FBQUE7QUFBQSxnQkFDbEUsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQztBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLE9BQU9uRCxTQUFTUCxlQUFlNkU7QUFBQUEsa0JBQy9CLGtCQUFpQjtBQUFBLGtCQUNqQixjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQSxRQUFRdkMsT0FBT21DLFlBQVksRUFBRUMsU0FBU0UsTUFBTUgsWUFBWSxDQUFDO0FBQUEsa0JBRTNELFVBQVUsQ0FBQ0ssUUFDVHhFLFlBQVksRUFBRSxHQUFHRCxVQUFVUCxhQUFhZ0YsSUFBSSxDQUFDO0FBQUEsa0JBRTlDbkcsb0JBQVVpRDtBQUFBQSxvQkFBSSxDQUFDbUQsUUFDZDtBQUFBLHNCQUFDLE9BQU87QUFBQSxzQkFBUDtBQUFBLHdCQUVDLE9BQU9BLElBQUlyQztBQUFBQSx3QkFDWCxPQUFPLEdBQUdxQyxJQUFJN0MsSUFBSSxJQUFJNkMsSUFBSUMsWUFBWTtBQUFBLHdCQUV0QyxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpREFBQyxTQUFJLFdBQVUsMkdBQ1pELGNBQUk3QyxLQUFLK0MsT0FBTyxDQUFDLEVBQUVDLFlBQVksS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNDSCxJQUFJN0M7QUFBQUEsMEJBQUs7QUFBQSwwQkFBSTZDLElBQUlDO0FBQUFBLDZCQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUE7QUFBQSxzQkFUS0QsSUFBSXJDO0FBQUFBLHNCQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBV0E7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBMUJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTJCQTtBQUFBLGNBRUNuQyxPQUFPa0IsWUFDTix1QkFBQyxPQUFFLFdBQVUscURBQ1g7QUFBQSx1Q0FBQyxVQUFLLFdBQVUscUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtEO0FBQUEsZ0JBQ2pEbEIsT0FBT2tCO0FBQUFBLG1CQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1Q0E7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDZEQUNmO0FBQUEsdUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QztBQUFBLGdCQUFHO0FBQUEsbUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT3BCLFNBQVNOO0FBQUFBLGtCQUNoQixVQUFVLENBQUMwRCxNQUNUbkQsWUFBWSxFQUFFLEdBQUdELFVBQVVOLFVBQVUwRCxFQUFFYSxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGdCQUx6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNRyxLQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2REFDZjtBQUFBLHVDQUFDLGVBQVksV0FBVSwyQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEM7QUFBQSxnQkFBRztBQUFBLGdCQUMxQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHNFQUFxRSxpQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixPQUFPbEUsU0FBU0Q7QUFBQUEsb0JBQ2hCLFVBQVUsQ0FBQ3FELE1BQ1RuRCxZQUFZLEVBQUUsR0FBR0QsVUFBVUQsUUFBUXFELEVBQUVhLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsa0JBUHZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRRztBQUFBLG1CQVpMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUNDbEUsU0FBU0QsVUFDUix1QkFBQyxTQUFJLFdBQVUsOERBQ2IsaUNBQUMsT0FBRSxXQUFVLCtEQUNWbEMsOEJBQW9CbUMsU0FBU0QsTUFBTSxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGNBRURHLE9BQU9ILFVBQ04sdUJBQUMsT0FBRSxXQUFVLGdEQUNYO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHFDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRDtBQUFBLGdCQUNqREcsT0FBT0g7QUFBQUEsbUJBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlDQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx1Q0FBQyxnQkFBYSxXQUFVLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQztBQUFBLGdCQUFHO0FBQUEsbUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT0MsU0FBU0g7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQzRFLFFBQVF4RSxZQUFZLEVBQUUsR0FBR0QsVUFBVUgsVUFBVTRFLElBQUksQ0FBQztBQUFBLGtCQUM3RDtBQUFBLDJDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFDbkIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQixvQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFDbkIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQiwwQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUQsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFDbkIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQixzQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUE7QUFBQSxnQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjQTtBQUFBLGlCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBR0N6RSxTQUFTSCxhQUFhLFVBQ3JCLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2REFDZjtBQUFBLHVDQUFDLFVBQU8sV0FBVSwyQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxnQkFDeENHLFNBQVNILGFBQWEsV0FDbkIsa0JBQ0E7QUFBQSxtQkFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLGFBQ0VHLFNBQVNILGFBQWEsV0FDbEIsd0JBQ0E7QUFBQSxrQkFFTixPQUFPRyxTQUFTRjtBQUFBQSxrQkFDaEIsVUFBVSxDQUFDc0QsTUFDVG5ELFlBQVksRUFBRSxHQUFHRCxVQUFVRixnQkFBZ0JzRCxFQUFFYSxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGdCQVYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXRztBQUFBLGlCQWxCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBSUYsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVGhGLG1CQUFTLDJCQUEyQjtBQUFBO0FBQUEsY0FIdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUF2SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3SkE7QUFBQTtBQUFBLFFBdEtGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXVLQTtBQUFBLFNBdk5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3TkE7QUFBQSxPQTFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMk5BO0FBRUo7QUFBRWIsR0FoYUlELHdCQUFzQjtBQUFBMEcsS0FBdEIxRztBQWthTixlQUFlQTtBQUF1QixJQUFBMEc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsImFwaSIsIkRhdGFUYWJsZSIsIkN1c3RvbUFsZXJ0IiwiTmF2YmFyIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJEcmF3ZXIiLCJNb2RhbCIsIkVtcHR5IiwiQWxlcnQiLCJJb01kTW9yZSIsIkJhY2tkcm9wQmx1ckxvYWRlciIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJGaUNhbGVuZGFyIiwiRmlDcmVkaXRDYXJkIiwiRmlIYXNoIiwiRmFSdXBlZVNpZ24iLCJCcmVhZGNydW1iIiwiQ2lyY3VsYXJMb2FkZXIiLCJFbXBsb3llZUFkdmFuY2VQYXltZW50IiwiX3MiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJ0YWJsZVBheW1lbnRzIiwic2V0VGFibGVQYXltZW50cyIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0Iiwib3BlbkJhY2tkcm9wTG9hZGVyIiwic2V0T3BlbkJhY2tkcm9wTG9hZGVyIiwiZWRpdElkIiwic2V0RWRpdElkIiwidG9kYXkiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImluaXRpYWxGb3JtIiwiZW1wbG95ZWVfaWQiLCJwYXlfZGF0ZSIsIm1vbnRoIiwidG9Mb2NhbGVTdHJpbmciLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwiYW1vdW50IiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImVycm9ycyIsInNldEVycm9ycyIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJub1JlbG9hZCIsInRpbWVyIiwic2V0VGltZW91dCIsInByZXYiLCJjbGVhclRpbWVvdXQiLCJmZXRjaEVtcGxveWVlcyIsImZldGNoQWR2YW5jZUhpc3RvcnkiLCJyZXMiLCJnZXQiLCJkYXRhIiwic3RhdHVzIiwiZW1wbG95ZWUiLCJyZXNwb25zZSIsImZvcm1hdHRlZCIsIm1hcCIsIml0ZW0iLCJpbmRleCIsImlkIiwiZGF0ZSIsImVtcGxveWVlTmFtZSIsIm5hbWUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwib25DbGljayIsImhhbmRsZUVkaXQiLCJzaG93RGVsZXRlQ29uZmlybSIsIl9pZCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImNvbmZpcm0iLCJ0aXRsZSIsImNvbnRlbnQiLCJva1RleHQiLCJva1R5cGUiLCJjYW5jZWxUZXh0Iiwib25PayIsImhhbmRsZURlbGV0ZSIsImVtcGxveWVlSWQiLCJkZWxldGUiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJ2YWxpZGF0ZUZvcm0iLCJsb2ciLCJwdXQiLCJwb3N0IiwiY2xvc2VEcmF3ZXIiLCJlcnJzIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImNvbHVtbnMiLCJoZWFkZXIiLCJ0YXJnZXQiLCJ2YWx1ZSIsImZpbHRlciIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsInZhbCIsImVtcCIsImVtcGxveWVlQ29kZSIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWR2YW5jZVNhbGFyeS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIERyb3Bkb3duLCBEcmF3ZXIsIE1vZGFsLCBFbXB0eSwgQWxlcnQgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgQmFja2Ryb3BCbHVyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQmFja2Ryb3BCbHVyTG9hZGVyXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcbmltcG9ydCB7IEZpQ2FsZW5kYXIsIEZpQ3JlZGl0Q2FyZCwgRmlIYXNoIH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbmltcG9ydCB7IEZhUnVwZWVTaWduIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuY29uc3QgRW1wbG95ZWVBZHZhbmNlUGF5bWVudCA9ICgpID0+IHtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZVBheW1lbnRzLCBzZXRUYWJsZVBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW29wZW5CYWNrZHJvcExvYWRlciwgc2V0T3BlbkJhY2tkcm9wTG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWRpdElkLCBzZXRFZGl0SWRdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuXHJcbiAgY29uc3QgaW5pdGlhbEZvcm0gPSB7XHJcbiAgICBlbXBsb3llZV9pZDogXCJcIixcclxuICAgIHBheV9kYXRlOiB0b2RheSxcclxuICAgIG1vbnRoOiBuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKFwiZGVmYXVsdFwiLCB7IG1vbnRoOiBcImxvbmdcIiB9KSxcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgYW1vdW50OiAwLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoaW5pdGlhbEZvcm0pO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gIH0pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoYWxlcnRDb25maWcudmlzaWJpbGl0eSkge1xyXG4gICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSk7XHJcbiAgICAgIH0sIDMwMDApO1xyXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH1cclxuICB9LCBbYWxlcnRDb25maWcudmlzaWJpbGl0eV0pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gICAgZmV0Y2hBZHZhbmNlSGlzdG9yeSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgaWYgKHJlcy5kYXRhLnN0YXR1cykgc2V0RW1wbG95ZWVzKHJlcy5kYXRhLmVtcGxveWVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEFkdmFuY2VIaXN0b3J5ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWR2YW5jZS1wYXltZW50L2dldC1hZHZhbmNlc1wiKTtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gcmVzcG9uc2UuZGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICBkYXRlOiBpdGVtLnBheV9kYXRlPy5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgZW1wbG95ZWVOYW1lOiBpdGVtLmVtcGxveWVlX2lkPy5uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICB7IGtleTogXCIxXCIsIGxhYmVsOiBcIkVkaXRcIiwgb25DbGljazogKCkgPT4gaGFuZGxlRWRpdChpdGVtKSB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICBsYWJlbDogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+RGVsZXRlPC9zcGFuPixcclxuICAgICAgICAgICAgICAgICAgb25DbGljazogKCkgPT4gc2hvd0RlbGV0ZUNvbmZpcm0oaXRlbS5faWQpLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX0+XHJcbiAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRUYWJsZVBheW1lbnRzKGZvcm1hdHRlZCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBzaG93RGVsZXRlQ29uZmlybSA9IChpZCkgPT4ge1xyXG4gICAgTW9kYWwuY29uZmlybSh7XHJcbiAgICAgIHRpdGxlOiBcIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyByZWNvcmQ/XCIsXHJcbiAgICAgIGNvbnRlbnQ6IFwiVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS5cIixcclxuICAgICAgb2tUZXh0OiBcIlllcywgRGVsZXRlXCIsXHJcbiAgICAgIG9rVHlwZTogXCJkYW5nZXJcIixcclxuICAgICAgY2FuY2VsVGV4dDogXCJOb1wiLFxyXG4gICAgICBvbk9rKCkge1xyXG4gICAgICAgIGhhbmRsZURlbGV0ZShpZCk7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFZGl0ID0gKGl0ZW0pID0+IHtcclxuICAgIGNvbnN0IGVtcGxveWVlSWQgPVxyXG4gICAgICB0eXBlb2YgaXRlbS5lbXBsb3llZV9pZCA9PT0gXCJvYmplY3RcIlxyXG4gICAgICAgID8gaXRlbS5lbXBsb3llZV9pZC5faWRcclxuICAgICAgICA6IGl0ZW0uZW1wbG95ZWVfaWQ7XHJcblxyXG4gICAgc2V0RWRpdElkKGl0ZW0uX2lkKTtcclxuICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXHJcbiAgICAgIHBheV9kYXRlOiBpdGVtLnBheV9kYXRlPy5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgIG1vbnRoOlxyXG4gICAgICAgIGl0ZW0ubW9udGggfHwgbmV3IERhdGUoKS50b0xvY2FsZVN0cmluZyhcImRlZmF1bHRcIiwgeyBtb250aDogXCJsb25nXCIgfSksXHJcbiAgICAgIHBheV90eXBlOiBpdGVtLnBheV90eXBlLFxyXG4gICAgICB0cmFuc2FjdGlvbl9pZDogaXRlbS50cmFuc2FjdGlvbl9pZCB8fCBcIlwiLFxyXG4gICAgICBhbW91bnQ6IGl0ZW0uYW1vdW50LFxyXG4gICAgfSk7XHJcbiAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIodHJ1ZSk7XHJcbiAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9hZHZhbmNlLXBheW1lbnQvZGVsZXRlLWFkdmFuY2UvJHtpZH1gKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJEYXRhIERlbGV0ZWQgU3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgZmV0Y2hBZHZhbmNlSGlzdG9yeSgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJEZWxldGUgZmFpbGVkXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGVGb3JtKCkpIHJldHVybjtcclxuICAgIGNvbnNvbGUubG9nKGVkaXRJZCwgXCJ0aGlzIGlzIGVkaXRJZFwiLCBmb3JtRGF0YSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG4gICAgICBpZiAoZWRpdElkKSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLnB1dChgL2FkdmFuY2UtcGF5bWVudC91cGRhdGUtYWR2YW5jZS8ke2VkaXRJZH1gLCBmb3JtRGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvYWR2YW5jZS1wYXltZW50L2FkZC1hZHZhbmNlXCIsIGZvcm1EYXRhKTtcclxuICAgICAgfVxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlZGl0SWQgPyBcIkRhdGEgVXBkYXRlZCBTdWNjZXNzZnVsbHkhXCIgOiBcIkRhdGEgQWRkZWQgU3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgY2xvc2VEcmF3ZXIoKTtcclxuICAgICAgZmV0Y2hBZHZhbmNlSGlzdG9yeSgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJFcnJvciBzYXZpbmcgZGF0YVwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICgpID0+IHtcclxuICAgIGNvbnN0IGVycnMgPSB7fTtcclxuICAgIGlmICghZm9ybURhdGEuZW1wbG95ZWVfaWQpIGVycnMuZW1wbG95ZWUgPSBcIlJlcXVpcmVkXCI7XHJcbiAgICBpZiAoIWZvcm1EYXRhLmFtb3VudCB8fCBmb3JtRGF0YS5hbW91bnQgPD0gMClcclxuICAgICAgZXJycy5hbW91bnQgPSBcIkVudGVyIHZhbGlkIGFtb3VudFwiO1xyXG4gICAgaWYgKCFmb3JtRGF0YS5tb250aCkgZXJycy5tb250aCA9IFwiUmVxdWlyZWRcIjtcclxuICAgIHNldEVycm9ycyhlcnJzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhlcnJzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2xvc2VEcmF3ZXIgPSAoKSA9PiB7XHJcbiAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgc2V0RWRpdElkKG51bGwpO1xyXG4gICAgc2V0Rm9ybURhdGEoaW5pdGlhbEZvcm0pO1xyXG4gICAgc2V0RXJyb3JzKHt9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJQYWlkIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW1wbG95ZWVOYW1lXCIsIGhlYWRlcjogXCJFbXBsb3llZVwiIH0sXHJcbiAgICB7IGtleTogXCJtb250aFwiLCBoZWFkZXI6IFwiTW9udGhcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIk1vZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7b3BlbkJhY2tkcm9wTG9hZGVyICYmIDxCYWNrZHJvcEJsdXJMb2FkZXIgdGl0bGU9e1wiUHJvY2Vzc2luZy4uLlwifSAvPn1cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICB7YWxlcnRDb25maWcudmlzaWJpbGl0eSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIHRvcC01IGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgei1bMTAwMF0gdy1mdWxsIG1heC13LW1kIHB4LTRcIj5cclxuICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfSAvLyBzdWNjZXNzLCBpbmZvLCB3YXJuaW5nLCBlcnJvclxyXG4gICAgICAgICAgICAgIHNob3dJY29uXHJcbiAgICAgICAgICAgICAgY2xvc2FibGVcclxuICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBbGVydENvbmZpZyh7IC4uLmFsZXJ0Q29uZmlnLCB2aXNpYmlsaXR5OiBmYWxzZSB9KX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5FbXBsb3llZSBBZHZhbmNlczwvaDE+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRFZGl0SWQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShpbml0aWFsRm9ybSk7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICArIEFkZCBBZHZhbmNlXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIHt0YWJsZVBheW1lbnRzLmxlbmd0aCA8PSAwID8gKCAqL31cclxuICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IGRhdGE9XCJBZHZhbmNlIFNhbGFyeVwiIC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgZGF0YT17dGFibGVQYXltZW50cy5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgICBpdGVtLmVtcGxveWVlTmFtZVxyXG4gICAgICAgICAgICAgICAgICA/LnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8RHJhd2VyXHJcbiAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctdmlvbGV0LTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8RmFSdXBlZVNpZ24gY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIHtlZGl0SWQgPyBcIkVkaXQgQWR2YW5jZSBQYXltZW50XCIgOiBcIk5ldyBBZHZhbmNlIFBheW1lbnRcIn1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgb3Blbj17c2hvd01vZGFsfVxyXG4gICAgICAgICAgb25DbG9zZT17Y2xvc2VEcmF3ZXJ9XHJcbiAgICAgICAgICB3aWR0aD17NDgwfT5cclxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNiBwLTFcIj5cclxuICAgICAgICAgICAgey8qIEVtcGxveWVlIFNlbGVjdGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICBFbXBsb3llZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBhbmQgc2VsZWN0IGVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbXBsb3llZV9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwibGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uPy5sYWJlbD8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGVtcGxveWVlX2lkOiB2YWwgfSlcclxuICAgICAgICAgICAgICAgIH0+XHJcbiAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtlbXAuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbXAuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPXtgJHtlbXAubmFtZX0gJHtlbXAuZW1wbG95ZWVDb2RlfWB9IC8vIPCflJEgc2VhcmNoYWJsZSB0ZXh0XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYmctdmlvbGV0LTEwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXZpb2xldC03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2VtcC5uYW1lLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9IHwge2VtcC5lbXBsb3llZUNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLmVtcGxveWVlICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xIGgtMSBiZy1yZWQtNTAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbXBsb3llZX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBQYXltZW50IERhdGUgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgPEZpQ2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgcGF5X2RhdGU6IGUudGFyZ2V0LnZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8RmFSdXBlZVNpZ24gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC00IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcGwtOCBwci00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwLjAwXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGFtb3VudDogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7Zm9ybURhdGEuYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTUwIGJvcmRlciBib3JkZXItdmlvbGV0LTIwMCByb3VuZGVkLWxnIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC03MDAgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhLmFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xIGgtMSBiZy1yZWQtNTAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogUGF5bWVudCBNb2RlICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIDxGaUNyZWRpdENhcmQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGF5X3R5cGV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgcGF5X3R5cGU6IHZhbCB9KX0+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImNhc2hcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPkNhc2g8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwib25saW5lXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5PbmxpbmUvVVBJPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImNoZXF1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+Q2hlcXVlPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFRyYW5zYWN0aW9uL0NoZXF1ZSBJRCAqL31cclxuICAgICAgICAgICAge2Zvcm1EYXRhLnBheV90eXBlICE9PSBcImNhc2hcIiAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgYW5pbWF0ZS1mYWRlSW5cIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPEZpSGFzaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICB7Zm9ybURhdGEucGF5X3R5cGUgPT09IFwiY2hlcXVlXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwiQ2hlcXVlIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIlRyYW5zYWN0aW9uIElEXCJ9XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1xyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLnBheV90eXBlID09PSBcImNoZXF1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiRW50ZXIgY2hlcXVlIG51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiRW50ZXIgdHJhbnNhY3Rpb24vVVBJIElEXCJcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCB0cmFuc2FjdGlvbl9pZDogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdWJtaXQgQnV0dG9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMCB0ZXh0LXdoaXRlIHB5LTMgcm91bmRlZC1sZyBob3Zlcjpmcm9tLXZpb2xldC03MDAgaG92ZXI6dG8tdmlvbGV0LTgwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZm9udC1zZW1pYm9sZCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zZm9ybSBob3ZlcjotdHJhbnNsYXRlLXktMC41IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICB7ZWRpdElkID8gXCJVcGRhdGUgQWR2YW5jZSBQYXltZW50XCIgOiBcIlNhdmUgQWR2YW5jZSBQYXltZW50XCJ9XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvRHJhd2VyPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFbXBsb3llZUFkdmFuY2VQYXltZW50O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQWR2YW5jZVNhbGFyeS5qc3gifQ==