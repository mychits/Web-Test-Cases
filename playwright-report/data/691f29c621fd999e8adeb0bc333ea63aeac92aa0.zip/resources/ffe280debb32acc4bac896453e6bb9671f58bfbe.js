import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerTrackingReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { InfoCircleOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const CustomerTrackingReport = () => {
  _s();
  const [customerTrackingData, setCustomerTrackingData] = useState([]);
  const [users, setUsers] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [collectionAreas, setCollectionAreas] = useState([]);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [selectedFromDate, setSelectedFromDate] = useState("");
  const [selectedToDate, setSelectedToDate] = useState("");
  const [showFilterField, setShowFilterField] = useState(false);
  const [showRemainingFilters, setShowRemainingFilters] = useState(false);
  const [formData, setFormData] = useState({
    collectionArea: "",
    user: "",
    employee: "",
    filterType: "Today"
  });
  const [collectionTotals, setCollectionTotals] = useState({
    totalDailyInstallment: 0,
    totalRecentPayments: 0,
    dailyBalance: 0
  });
  const [summary, setSummary] = useState({
    totalTracking: 0,
    totalCustomers: 0,
    totalEmployees: 0,
    totalChits: 0,
    totalLoans: 0,
    totalPayable: 0,
    totalInvestment: 0,
    totalPenalty: 0,
    totalLateFee: 0,
    totalChitBalance: 0,
    totalLoanPaid: 0,
    totalLoanBalance: 0
  });
  const resetSummary = () => {
    setSummary({
      totalTracking: 0,
      totalCustomers: 0,
      totalEmployees: 0,
      totalChits: 0,
      totalLoans: 0,
      totalPayable: 0,
      totalInvestment: 0,
      totalPenalty: 0,
      totalLateFee: 0,
      totalChitBalance: 0,
      totalLoanPaid: 0,
      totalLoanBalance: 0
    });
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value || ""
    }));
  };
  const formatDate = (date) => {
    if (!date) return "";
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };
  const formatDisplayDate = (date) => {
    if (!date) return "-";
    const parsedDate = new Date(date);
    if (isNaN(parsedDate.getTime())) {
      return "-";
    }
    return parsedDate.toLocaleDateString("en-IN");
  };
  const formatAmount = (amount) => {
    return `₹${Number(amount || 0).toLocaleString("en-IN")}`;
  };
  const dateFilterOptions = [
    // {
    //   value: "Last 7 Days",
    //   label: "Last 7 Days",
    // },
    {
      value: "Today",
      label: "Today"
    },
    {
      value: "Yesterday",
      label: "Yesterday"
    },
    {
      value: "DayBeforeYesterday",
      label: "Day Before Yesterday"
    },
    // {
    //   value: "ThisMonth",
    //   label: "This Month",
    // },
    // {
    //   value: "LastMonth",
    //   label: "Last Month",
    // },
    // {
    //   value: "ThisYear",
    //   label: "This Year",
    // },
    {
      value: "Custom",
      label: "Custom"
    }
  ];
  const handleSelectFilter = (value) => {
    const today = /* @__PURE__ */ new Date();
    let from = "";
    let to = "";
    if (value === "Today") {
      from = formatDate(today);
      to = formatDate(today);
    }
    if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(today.getDate() - 1);
      from = formatDate(yesterday);
      to = formatDate(yesterday);
    }
    if (value === "DayBeforeYesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(today.getDate() - 2);
      from = formatDate(yesterday);
      to = formatDate(yesterday);
    }
    if (value === "ThisMonth") {
      const start = new Date(
        today.getFullYear(),
        today.getMonth(),
        1
      );
      const end = new Date(
        today.getFullYear(),
        today.getMonth() + 1,
        0
      );
      from = formatDate(start);
      to = formatDate(end);
    }
    if (value === "LastMonth") {
      const start = new Date(
        today.getFullYear(),
        today.getMonth() - 1,
        1
      );
      const end = new Date(
        today.getFullYear(),
        today.getMonth(),
        0
      );
      from = formatDate(start);
      to = formatDate(end);
    }
    if (value === "ThisYear") {
      const start = new Date(
        today.getFullYear(),
        0,
        1
      );
      const end = new Date(
        today.getFullYear(),
        11,
        31
      );
      from = formatDate(start);
      to = formatDate(end);
    }
    if (value === "Custom") {
      setShowFilterField(true);
      return;
    }
    setShowFilterField(false);
    setSelectedFromDate(from);
    setSelectedToDate(to);
  };
  useEffect(() => {
    if (!formData.filterType) return;
    handleSelectFilter(formData.filterType);
  }, [formData.filterType]);
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        setInitialLoading(true);
        const userResponse = await api.get("/user/get-user");
        const userData = userResponse.data?.data || userResponse.data || [];
        const safeUsers = Array.isArray(userData) ? userData : [];
        setUsers(safeUsers);
        const areaMap = /* @__PURE__ */ new Map();
        safeUsers.forEach((user) => {
          const area = user.collection_area;
          if (!area) return;
          if (typeof area === "object") {
            const areaId = area._id?.toString();
            if (!areaId) return;
            areaMap.set(areaId, {
              _id: areaId,
              route_name: area.route_name || area.area_name || area.name || areaId
            });
          } else {
            const areaId = area.toString();
            areaMap.set(areaId, {
              _id: areaId,
              route_name: areaId
            });
          }
        });
        setCollectionAreas(
          Array.from(areaMap.values())
        );
        const employeeResponse = await api.get("/employee");
        const employeeData = employeeResponse.data?.employee || employeeResponse.data?.data || employeeResponse.data || [];
        setEmployees(
          Array.isArray(employeeData) ? employeeData : []
        );
      } catch (error) {
        console.error(
          "Unable to fetch initial data",
          error
        );
      } finally {
        setInitialLoading(false);
      }
    };
    fetchInitialData();
  }, []);
  useEffect(() => {
    handleSelectFilter("Today");
  }, []);
  const handleCollectionAreaChange = (value) => {
    const areaValue = value || "";
    setFormData((prev) => ({
      ...prev,
      collectionArea: areaValue,
      user: "",
      employee: ""
    }));
    if (!areaValue) {
      setShowRemainingFilters(false);
      setCustomerTrackingData([]);
      setSelectedFromDate("");
      setSelectedToDate("");
      resetSummary();
      return;
    }
    setShowRemainingFilters(true);
    if (formData.filterType === "Custom") {
      setFormData((prev) => ({
        ...prev,
        filterType: "Today"
      }));
    } else {
      handleSelectFilter(
        formData.filterType || "Today"
      );
    }
  };
  const fetchCustomerTrackingReport = async () => {
    if (!formData.collectionArea) {
      console.log(
        "API NOT CALLED - Collection Area missing"
      );
      return;
    }
    if (!selectedFromDate || !selectedToDate) {
      console.log(
        "API NOT CALLED - Date missing",
        {
          selectedFromDate,
          selectedToDate
        }
      );
      return;
    }
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.append(
        "collectionArea",
        formData.collectionArea
      );
      params.append(
        "fromDate",
        selectedFromDate
      );
      params.append(
        "toDate",
        selectedToDate
      );
      if (formData.user) {
        params.append(
          "userId",
          formData.user
        );
      }
      if (formData.employee) {
        params.append(
          "empId",
          formData.employee
        );
      }
      const url = `/v1/admin/collection-tracking/tracking?${params.toString()}`;
      const response = await api.get(url);
      const responseData = response.data?.data || [];
      const uniqueCustomers = new Set(
        responseData.map(
          (item) => item.customer?._id
        ).filter(Boolean)
      );
      const uniqueEmployees = new Set(
        responseData.flatMap(
          (item) => item.collection_tracking || []
        ).map(
          (tracking) => tracking.collected_by?._id
        ).filter(Boolean)
      );
      const totalChits = responseData.reduce(
        (total, item) => total + (item.customer_overview?.length || 0),
        0
      );
      const totalLoans = responseData.reduce(
        (total, item) => total + (item.loan_details?.length || 0),
        0
      );
      const chitSummary = responseData.reduce(
        (acc, item) => {
          (item.customer_overview || []).forEach((chit) => {
            acc.totalPayable += Number(
              chit.total_payable || 0
            );
            acc.totalInvestment += Number(
              chit.total_investment || 0
            );
            acc.totalPenalty += Number(
              chit.total_penalty || 0
            );
            acc.totalLateFee += Number(
              chit.total_late_fee || 0
            );
            acc.totalBalance += Number(
              chit.total_balance || 0
            );
          });
          return acc;
        },
        {
          totalPayable: 0,
          totalInvestment: 0,
          totalPenalty: 0,
          totalLateFee: 0,
          totalBalance: 0
        }
      );
      const loanSummary = responseData.reduce(
        (acc, item) => {
          (item.loan_details || []).forEach((loan) => {
            acc.totalPaid += Number(
              loan.total_paid_amount || 0
            );
            acc.totalBalance += Number(
              loan.balance || 0
            );
          });
          return acc;
        },
        {
          totalPaid: 0,
          totalBalance: 0
        }
      );
      setSummary({
        totalTracking: responseData.length,
        totalCustomers: uniqueCustomers.size,
        totalEmployees: uniqueEmployees.size,
        totalChits,
        totalLoans,
        totalPayable: chitSummary.totalPayable,
        totalInvestment: chitSummary.totalInvestment,
        totalPenalty: chitSummary.totalPenalty,
        totalLateFee: chitSummary.totalLateFee,
        totalChitBalance: chitSummary.totalBalance,
        totalLoanPaid: loanSummary.totalPaid,
        totalLoanBalance: loanSummary.totalBalance
      });
      const formatted = responseData?.filter((item) => {
        const chit = item.customer_overview?.[0] || {};
        const dailyInstallment = chit?.group_id?.daily_installment;
        return dailyInstallment !== null && dailyInstallment !== void 0 && Number(dailyInstallment) > 0;
      }).map(
        (item, index) => {
          const customer = item.customer || {};
          const tracking = item.collection_tracking?.[0] || {};
          const customerOverview = item.customer_overview || [];
          const loanDetails = item.loan_details || [];
          const chit = customerOverview[0] || {};
          const loan = loanDetails[0] || {};
          let collectionAreaName = "-";
          if (customer.collection_area && typeof customer.collection_area === "object") {
            collectionAreaName = customer.collection_area?.route_name || customer.collection_area?.area_name || customer.collection_area?.name || "-";
          } else if (customer.collection_area) {
            const foundArea = collectionAreas.find(
              (area) => area._id?.toString() === customer.collection_area?.toString()
            );
            collectionAreaName = foundArea?.route_name || customer.collection_area || "-";
          }
          const employeeName = tracking.collected_by?.name || tracking.employee_name || "-";
          const employeePhone = tracking.collected_by?.phone_number || tracking.employee_phone || "-";
          const employeeCode = tracking.collected_by?.employeeCode || tracking.employeeCode || "-";
          const payment = item.payments?.[0] || null;
          return {
            id: tracking._id || customer._id || index,
            slNo: index + 1,
            // CUSTOMER
            customer: `${customer.full_name || "-"} | ${customer.phone_number || "-"}`,
            customerId: customer.customer_id || "-",
            collectionArea: collectionAreaName,
            address: customer.address || "-",
            pincode: customer.pincode || "-",
            // EMPLOYEE
            employee: `${employeeName} | ${employeePhone}`,
            employeeCode,
            // TRACKING
            collectionDate: tracking.collection_date ? formatDisplayDate(
              tracking.collection_date
            ) : "-",
            reason: item.payment_status === "Paid" ? "Paid" : item.not_paid_reason && item.not_paid_reason !== "Not Applicable" ? item.not_paid_reason.replace(/_/g, " ") : tracking.reason || "-",
            daily_installment: chit?.group_id?.daily_installment,
            recent_payments: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV("span", { children: item.payments?.reduce(
                (total, payment2) => total + Number(payment2.amount || 0),
                0
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                lineNumber: 2286,
                columnNumber: 19
              }, this),
              item.payments?.length > 1 && /* @__PURE__ */ jsxDEV(
                Tooltip,
                {
                  title: /* @__PURE__ */ jsxDEV("div", { children: item.payments?.map(
                    (payment2, index2) => /* @__PURE__ */ jsxDEV("div", { children: [
                      "₹",
                      payment2.amount
                    ] }, index2, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                      lineNumber: 2298,
                      columnNumber: 19
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                    lineNumber: 2296,
                    columnNumber: 17
                  }, this),
                  children: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 cursor-pointer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                    lineNumber: 2305,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                  lineNumber: 2294,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
              lineNumber: 2285,
              columnNumber: 13
            }, this),
            remark: tracking.remark || tracking.remarks || "-",
            paymentStatus: item.payment_status || "-",
            // CHIT
            groupName: chit.group_id?.group_name || chit.group_name || "-",
            ticket: chit.tickets ?? chit.ticket ?? "-",
            paymentType: chit.payment_type || payment?.payment_type || "-",
            customerStatus: chit.customer_status || "-",
            totalPayable: chit.total_payable !== void 0 ? Number(
              chit.total_payable
            ) : "-",
            totalInvestment: chit.total_investment !== void 0 ? Number(
              chit.total_investment
            ) : "-",
            totalPenalty: chit.total_penalty !== void 0 ? Number(
              chit.total_penalty
            ) : "-",
            totalLateFee: chit.total_late_fee !== void 0 ? Number(
              chit.total_late_fee
            ) : "-",
            chitBalance: chit.total_balance !== void 0 ? Number(
              chit.total_balance
            ) : "-",
            // LOAN
            loanId: loan.loan_id || "-",
            loanAmount: loan.loan_amount !== void 0 ? Number(
              loan.loan_amount
            ) : "-",
            loanStartDate: loan.start_date ? formatDisplayDate(
              loan.start_date
            ) : "-",
            loanEndDate: loan.end_date ? formatDisplayDate(
              loan.end_date
            ) : "-",
            loanPaidAmount: loan.total_paid_amount !== void 0 ? Number(
              loan.total_paid_amount
            ) : "-",
            loanBalance: loan.balance !== void 0 ? Number(
              loan.balance
            ) : "-",
            loanStatus: loan.status || "-"
          };
        }
      );
      const totalDailyInstallment = formatted.reduce(
        (total, item) => total + Number(item.daily_installment || 0),
        0
      );
      const totalRecentPayments = responseData.reduce(
        (total, item) => total + (item.payments?.reduce(
          (paymentTotal, payment) => paymentTotal + Number(payment.amount || 0),
          0
        ) || 0),
        0
      );
      const dailyBalance = Math.max(
        0,
        totalDailyInstallment - totalRecentPayments
      );
      setCollectionTotals({
        totalDailyInstallment,
        totalRecentPayments,
        dailyBalance
      });
      setCustomerTrackingData(
        formatted
      );
    } catch (error) {
      console.error(
        "Unable to fetch customer tracking report",
        error
      );
      setCustomerTrackingData([]);
      resetSummary();
    } finally {
      setLoading(false);
    }
  };
  useEffect(
    () => {
      if (!formData.collectionArea || !selectedFromDate || !selectedToDate) {
        return;
      }
      fetchCustomerTrackingReport();
    },
    [
      formData.collectionArea,
      formData.user,
      formData.employee,
      selectedFromDate,
      selectedToDate
    ]
  );
  const column = [
    {
      key: "slNo",
      header: "Sl No"
    },
    {
      key: "customer",
      header: "Customer"
    },
    // {
    //   key: "customerId",
    //   header: "Customer ID",
    // },
    {
      key: "collectionArea",
      header: "Collection Area"
    },
    {
      key: "employee",
      header: "Collected By"
    },
    // {
    //   key: "employeeCode",
    //   header: "Employee Code",
    // },
    {
      key: "collectionDate",
      header: "Collected On"
    },
    {
      key: "reason",
      header: "Reason"
    },
    {
      key: "remark",
      header: "Remark"
    },
    {
      key: "daily_installment",
      header: "Daily Payable"
    },
    {
      key: "recent_payments",
      header: "Daily Paid"
    },
    {
      key: "paymentStatus",
      header: "Payment Status"
    },
    {
      key: "groupName",
      header: "Group Name"
    },
    {
      key: "ticket",
      header: "Ticket"
    },
    // {
    //   key: "paymentType",
    //   header: "Payment Type",
    // },
    {
      key: "customerStatus",
      header: "Customer Status"
    },
    {
      key: "totalPayable",
      header: "Total Payable"
    },
    {
      key: "totalInvestment",
      header: "Total Paid"
    },
    // {
    //   key: "totalPenalty",
    //   header: "Total Penalty",
    // },
    // {
    //   key: "totalLateFee",
    //   header: "Total Late Fee",
    // },
    {
      key: "chitBalance",
      header: "Chit Balance"
    }
    // {
    //   key: "loanId",
    //   header: "Loan ID",
    // },
    // {
    //   key: "loanAmount",
    //   header: "Loan Amount",
    // },
    // {
    //   key: "loanStartDate",
    //   header: "Loan Start Date",
    // },
    // {
    //   key: "loanEndDate",
    //   header: "Loan End Date",
    // },
    // {
    //   key: "loanPaidAmount",
    //   header: "Loan Paid",
    // },
    // {
    //   key: "loanBalance",
    //   header: "Loan Balance",
    // },
    // {
    //   key: "loanStatus",
    //   header: "Loan Status",
    // },
  ];
  const handleResetArea = () => {
    setFormData({
      collectionArea: "",
      user: "",
      employee: "",
      filterType: "Today"
    });
    setShowRemainingFilters(false);
    setShowFilterField(false);
    setSelectedFromDate("");
    setSelectedToDate("");
    setCustomerTrackingData([]);
    resetSummary();
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-10 overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
      lineNumber: 2662,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 min-w-0", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mb-6", children: "Customer Payment Tracking Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
        lineNumber: 2666,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-5 rounded-lg shadow-sm mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 items-end", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium", children: "Select Collection Area" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
              lineNumber: 2680,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "w-full h-12",
                placeholder: "Select Collection Area",
                value: formData.collectionArea || void 0,
                onChange: handleCollectionAreaChange,
                allowClear: true,
                showSearch: true,
                optionFilterProp: "children",
                children: collectionAreas.map(
                  (area) => /* @__PURE__ */ jsxDEV(
                    Select.Option,
                    {
                      value: area._id,
                      children: area.route_name
                    },
                    area._id,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                      lineNumber: 2701,
                      columnNumber: 19
                    },
                    this
                  )
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                lineNumber: 2684,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 2678,
            columnNumber: 13
          }, this),
          formData.collectionArea && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleResetArea,
              className: "h-12 px-5 border rounded hover:bg-gray-100",
              children: "Reset"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
              lineNumber: 2715,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 2676,
          columnNumber: 11
        }, this),
        !formData.collectionArea && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-3", children: "Please select a Collection Area first." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 2727,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
        lineNumber: 2674,
        columnNumber: 9
      }, this),
      showRemainingFilters && /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-5 rounded-lg shadow-sm mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 items-end", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-1/4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Date Filter" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 2747,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-12",
              value: formData.filterType,
              onChange: (value) => {
                handleAntDSelect(
                  "filterType",
                  value
                );
              },
              children: dateFilterOptions.map(
                (option) => /* @__PURE__ */ jsxDEV(
                  Select.Option,
                  {
                    value: option.value,
                    children: option.label
                  },
                  option.value,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                    lineNumber: 2766,
                    columnNumber: 19
                  },
                  this
                )
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
              lineNumber: 2751,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 2745,
          columnNumber: 15
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 items-end", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm", children: "From" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
              lineNumber: 2831,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "border p-2 rounded h-12",
                value: selectedFromDate,
                onChange: (e) => {
                  const date = e.target.value;
                  setSelectedFromDate(date);
                  setSelectedToDate(date);
                }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                lineNumber: 2833,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 2830,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm", children: "To" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
              lineNumber: 2849,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "border p-2 rounded h-12",
                value: selectedToDate,
                min: selectedFromDate,
                max: selectedFromDate,
                onChange: (e) => {
                  setSelectedToDate(e.target.value);
                }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                lineNumber: 2851,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 2848,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 2786,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-1/4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Select Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 2870,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-12",
              placeholder: "All Employees",
              value: formData.employee || void 0,
              onChange: (value) => {
                handleAntDSelect(
                  "employee",
                  value
                );
              },
              allowClear: true,
              showSearch: true,
              optionFilterProp: "children",
              children: employees.map(
                (employee) => /* @__PURE__ */ jsxDEV(
                  Select.Option,
                  {
                    value: employee._id,
                    children: [
                      employee.name,
                      employee.phone_number ? ` - ${employee.phone_number}` : ""
                    ]
                  },
                  employee._id,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                    lineNumber: 2894,
                    columnNumber: 19
                  },
                  this
                )
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
              lineNumber: 2874,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 2868,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-1/4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Select Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 2919,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-12",
              placeholder: "All Customers",
              value: formData.user || void 0,
              onChange: (value) => {
                handleAntDSelect(
                  "user",
                  value
                );
              },
              allowClear: true,
              showSearch: true,
              optionFilterProp: "children",
              children: users.filter((user) => {
                const area = user.collection_area;
                if (!formData.collectionArea) {
                  return true;
                }
                if (typeof area === "object") {
                  return area?._id?.toString() === formData.collectionArea;
                }
                return area?.toString() === formData.collectionArea;
              }).map(
                (user) => /* @__PURE__ */ jsxDEV(
                  Select.Option,
                  {
                    value: user._id,
                    children: [
                      user.full_name,
                      user.phone_number ? ` - ${user.phone_number}` : ""
                    ]
                  },
                  user._id,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
                    lineNumber: 2968,
                    columnNumber: 17
                  },
                  this
                )
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
              lineNumber: 2923,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 2917,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
        lineNumber: 2741,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
        lineNumber: 2739,
        columnNumber: 9
      }, this),
      showRemainingFilters && formData.collectionArea && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-5 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-4 rounded-lg shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Tracking" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 2998,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mt-1", children: summary.totalTracking }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 3002,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 2997,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-4 rounded-lg shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 3008,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mt-1", children: summary.totalCustomers }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 3012,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 3007,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-indigo-100 p-4 rounded-lg shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Chit Payable" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 3048,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mt-1", children: [
            "₹",
            collectionTotals.totalDailyInstallment.toLocaleString()
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 3052,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 3047,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-teal-100 p-4 rounded-lg shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Chit Paid" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 3061,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mt-1", children: [
            "₹",
            collectionTotals.totalRecentPayments.toLocaleString()
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 3065,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 3060,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 p-4 rounded-lg shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Chit Balance" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 3074,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mt-1", children: [
            "₹",
            collectionTotals.dailyBalance.toLocaleString()
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
            lineNumber: 3078,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 3073,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
        lineNumber: 2995,
        columnNumber: 9
      }, this),
      showRemainingFilters && formData.collectionArea && (loading ? /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading: true,
          failure: false,
          data: "Customer Payment Tracking Report"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 3144,
          columnNumber: 9
        },
        this
      ) : customerTrackingData.length > 0 ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns: column,
          data: customerTrackingData,
          exportedFileName: "Customer Payment Tracking Report",
          exportedPdfName: "Customer Payment Tracking Report"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 3150,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading: false,
          failure: true,
          data: "Customer Payment Tracking Report"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
          lineNumber: 3157,
          columnNumber: 9
        },
        this
      ))
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
      lineNumber: 2664,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx",
    lineNumber: 2661,
    columnNumber: 5
  }, this);
};
_s(CustomerTrackingReport, "I/R2G1I4/emfF1r5zDB7yu+CjFQ=");
_c = CustomerTrackingReport;
export default CustomerTrackingReport;
var _c;
$RefreshReg$(_c, "CustomerTrackingReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerTrackingReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNnVFa0I7MkJBN3VFbEI7QUFBbUJBLG9CQUFpQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLGVBQWU7QUFDaEMsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLDBCQUEwQjtBQW04Q25DLE1BQU1DLHlCQUF5QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0Msc0JBQXNCQyx1QkFBdUIsSUFBSUMsU0FBUyxFQUFFO0FBRW5FLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJRixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDRyxXQUFXQyxZQUFZLElBQUlKLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNLLGlCQUFpQkMsa0JBQWtCLElBQUlOLFNBQVMsRUFBRTtBQUV6RCxRQUFNLENBQUNPLFNBQVNDLFVBQVUsSUFBSVIsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ1MsZ0JBQWdCQyxpQkFBaUIsSUFBSVYsU0FBUyxJQUFJO0FBRXpELFFBQU0sQ0FBQ1csa0JBQWtCQyxtQkFBbUIsSUFBSVosU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQ2EsZ0JBQWdCQyxpQkFBaUIsSUFBSWQsU0FBUyxFQUFFO0FBRXZELFFBQU0sQ0FBQ2UsaUJBQWlCQyxrQkFBa0IsSUFBSWhCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNpQixzQkFBc0JDLHVCQUF1QixJQUNsRGxCLFNBQVMsS0FBSztBQUVoQixRQUFNLENBQUNtQixVQUFVQyxXQUFXLElBQUlwQixTQUFTO0FBQUEsSUFDdkNxQixnQkFBZ0I7QUFBQSxJQUNoQkMsTUFBTTtBQUFBLElBQ05DLFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJMUIsU0FBUztBQUFBLElBQ3ZEMkIsdUJBQXVCO0FBQUEsSUFDdkJDLHFCQUFxQjtBQUFBLElBQ3JCQyxjQUFjO0FBQUEsRUFDaEIsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJL0IsU0FBUztBQUFBLElBQ3JDZ0MsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsWUFBWTtBQUFBLElBQ1pDLFlBQVk7QUFBQSxJQUNaQyxjQUFjO0FBQUEsSUFDZEMsaUJBQWlCO0FBQUEsSUFDakJDLGNBQWM7QUFBQSxJQUNkQyxjQUFjO0FBQUEsSUFDZEMsa0JBQWtCO0FBQUEsSUFDbEJDLGVBQWU7QUFBQSxJQUNmQyxrQkFBa0I7QUFBQSxFQUNwQixDQUFDO0FBTUQsUUFBTUMsZUFBZUEsTUFBTTtBQUN6QmIsZUFBVztBQUFBLE1BQ1RDLGVBQWU7QUFBQSxNQUNmQyxnQkFBZ0I7QUFBQSxNQUNoQkMsZ0JBQWdCO0FBQUEsTUFDaEJDLFlBQVk7QUFBQSxNQUNaQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLE1BQ2RDLGlCQUFpQjtBQUFBLE1BQ2pCQyxjQUFjO0FBQUEsTUFDZEMsY0FBYztBQUFBLE1BQ2RDLGtCQUFrQjtBQUFBLE1BQ2xCQyxlQUFlO0FBQUEsTUFDZkMsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNRSxtQkFBbUJBLENBQUNDLE9BQU9DLFVBQVU7QUFDekMzQixnQkFBWSxDQUFDNEIsVUFBVTtBQUFBLE1BQ3JCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0YsS0FBSyxHQUFHQyxTQUFTO0FBQUEsSUFDcEIsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNRSxhQUFhQSxDQUFDQyxTQUFTO0FBQzNCLFFBQUksQ0FBQ0EsS0FBTSxRQUFPO0FBRWxCLFVBQU1DLE9BQU9ELEtBQUtFLFlBQVk7QUFDOUIsVUFBTUMsUUFBUUMsT0FBT0osS0FBS0ssU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDekQsVUFBTUMsTUFBTUgsT0FBT0osS0FBS1EsUUFBUSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBRWxELFdBQU8sR0FBR0wsSUFBSSxJQUFJRSxLQUFLLElBQUlJLEdBQUc7QUFBQSxFQUNoQztBQUVBLFFBQU1FLG9CQUFvQkEsQ0FBQ1QsU0FBUztBQUNsQyxRQUFJLENBQUNBLEtBQU0sUUFBTztBQUVsQixVQUFNVSxhQUFhLElBQUlDLEtBQUtYLElBQUk7QUFFaEMsUUFBSVksTUFBTUYsV0FBV0csUUFBUSxDQUFDLEdBQUc7QUFDL0IsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPSCxXQUFXSSxtQkFBbUIsT0FBTztBQUFBLEVBQzlDO0FBRUEsUUFBTUMsZUFBZUEsQ0FBQ0MsV0FBVztBQUMvQixXQUFPLElBQUlDLE9BQU9ELFVBQVUsQ0FBQyxFQUFFRSxlQUFlLE9BQU8sQ0FBQztBQUFBLEVBQ3hEO0FBTUEsUUFBTUMsb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUt4QjtBQUFBLE1BQ0V0QixPQUFPO0FBQUEsTUFDUHVCLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0V2QixPQUFPO0FBQUEsTUFDUHVCLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0V2QixPQUFPO0FBQUEsTUFDUHVCLE9BQU87QUFBQSxJQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFhQTtBQUFBLE1BQ0V2QixPQUFPO0FBQUEsTUFDUHVCLE9BQU87QUFBQSxJQUNUO0FBQUEsRUFBQztBQU9ILFFBQU1DLHFCQUFxQkEsQ0FBQ3hCLFVBQVU7QUFDcEMsVUFBTXlCLFFBQVEsb0JBQUlYLEtBQUs7QUFFdkIsUUFBSVksT0FBTztBQUNYLFFBQUlDLEtBQUs7QUFXVCxRQUFJM0IsVUFBVSxTQUFTO0FBQ3JCMEIsYUFBT3hCLFdBQVd1QixLQUFLO0FBQ3ZCRSxXQUFLekIsV0FBV3VCLEtBQUs7QUFBQSxJQUN2QjtBQUVBLFFBQUl6QixVQUFVLGFBQWE7QUFDekIsWUFBTTRCLFlBQVksSUFBSWQsS0FBS1csS0FBSztBQUVoQ0csZ0JBQVVDLFFBQVFKLE1BQU1kLFFBQVEsSUFBSSxDQUFDO0FBRXJDZSxhQUFPeEIsV0FBVzBCLFNBQVM7QUFDM0JELFdBQUt6QixXQUFXMEIsU0FBUztBQUFBLElBQzNCO0FBRUEsUUFBSTVCLFVBQVUsc0JBQXNCO0FBQ2xDLFlBQU00QixZQUFZLElBQUlkLEtBQUtXLEtBQUs7QUFFaENHLGdCQUFVQyxRQUFRSixNQUFNZCxRQUFRLElBQUksQ0FBQztBQUVyQ2UsYUFBT3hCLFdBQVcwQixTQUFTO0FBQzNCRCxXQUFLekIsV0FBVzBCLFNBQVM7QUFBQSxJQUMzQjtBQUVBLFFBQUk1QixVQUFVLGFBQWE7QUFDekIsWUFBTThCLFFBQVEsSUFBSWhCO0FBQUFBLFFBQ2hCVyxNQUFNcEIsWUFBWTtBQUFBLFFBQ2xCb0IsTUFBTWpCLFNBQVM7QUFBQSxRQUNmO0FBQUEsTUFDRjtBQUVBLFlBQU11QixNQUFNLElBQUlqQjtBQUFBQSxRQUNkVyxNQUFNcEIsWUFBWTtBQUFBLFFBQ2xCb0IsTUFBTWpCLFNBQVMsSUFBSTtBQUFBLFFBQ25CO0FBQUEsTUFDRjtBQUVBa0IsYUFBT3hCLFdBQVc0QixLQUFLO0FBQ3ZCSCxXQUFLekIsV0FBVzZCLEdBQUc7QUFBQSxJQUNyQjtBQUVBLFFBQUkvQixVQUFVLGFBQWE7QUFDekIsWUFBTThCLFFBQVEsSUFBSWhCO0FBQUFBLFFBQ2hCVyxNQUFNcEIsWUFBWTtBQUFBLFFBQ2xCb0IsTUFBTWpCLFNBQVMsSUFBSTtBQUFBLFFBQ25CO0FBQUEsTUFDRjtBQUVBLFlBQU11QixNQUFNLElBQUlqQjtBQUFBQSxRQUNkVyxNQUFNcEIsWUFBWTtBQUFBLFFBQ2xCb0IsTUFBTWpCLFNBQVM7QUFBQSxRQUNmO0FBQUEsTUFDRjtBQUVBa0IsYUFBT3hCLFdBQVc0QixLQUFLO0FBQ3ZCSCxXQUFLekIsV0FBVzZCLEdBQUc7QUFBQSxJQUNyQjtBQUVBLFFBQUkvQixVQUFVLFlBQVk7QUFDeEIsWUFBTThCLFFBQVEsSUFBSWhCO0FBQUFBLFFBQ2hCVyxNQUFNcEIsWUFBWTtBQUFBLFFBQ2xCO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFFQSxZQUFNMEIsTUFBTSxJQUFJakI7QUFBQUEsUUFDZFcsTUFBTXBCLFlBQVk7QUFBQSxRQUNsQjtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBRUFxQixhQUFPeEIsV0FBVzRCLEtBQUs7QUFDdkJILFdBQUt6QixXQUFXNkIsR0FBRztBQUFBLElBQ3JCO0FBRUEsUUFBSS9CLFVBQVUsVUFBVTtBQUN0Qi9CLHlCQUFtQixJQUFJO0FBQ3ZCO0FBQUEsSUFDRjtBQUVBQSx1QkFBbUIsS0FBSztBQUd4Qkosd0JBQW9CNkQsSUFBSTtBQUN4QjNELHNCQUFrQjRELEVBQUU7QUFBQSxFQUN0QjtBQU1BdEYsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDK0IsU0FBU0ssV0FBWTtBQUUxQitDLHVCQUFtQnBELFNBQVNLLFVBQVU7QUFBQSxFQUN4QyxHQUFHLENBQUNMLFNBQVNLLFVBQVUsQ0FBQztBQU14QnBDLFlBQVUsTUFBTTtBQUNkLFVBQU0yRixtQkFBbUIsWUFBWTtBQUNuQyxVQUFJO0FBQ0ZyRSwwQkFBa0IsSUFBSTtBQU10QixjQUFNc0UsZUFDSixNQUFNMUYsSUFBSTJGLElBQUksZ0JBQWdCO0FBRWhDLGNBQU1DLFdBQ0pGLGFBQWFHLE1BQU1BLFFBQ25CSCxhQUFhRyxRQUNiO0FBRUYsY0FBTUMsWUFBWUMsTUFBTUMsUUFBUUosUUFBUSxJQUNwQ0EsV0FDQTtBQUVKaEYsaUJBQVNrRixTQUFTO0FBTWxCLGNBQU1HLFVBQVUsb0JBQUlDLElBQUk7QUFFeEJKLGtCQUFVSyxRQUFRLENBQUNuRSxTQUFTO0FBQzFCLGdCQUFNb0UsT0FBT3BFLEtBQUtxRTtBQUVsQixjQUFJLENBQUNELEtBQU07QUFFWCxjQUFJLE9BQU9BLFNBQVMsVUFBVTtBQUM1QixrQkFBTUUsU0FDSkYsS0FBS0csS0FBS0MsU0FBUztBQUVyQixnQkFBSSxDQUFDRixPQUFRO0FBRWJMLG9CQUFRUSxJQUFJSCxRQUFRO0FBQUEsY0FDbEJDLEtBQUtEO0FBQUFBLGNBQ0xJLFlBQ0VOLEtBQUtNLGNBQ0xOLEtBQUtPLGFBQ0xQLEtBQUtRLFFBQ0xOO0FBQUFBLFlBQ0osQ0FBQztBQUFBLFVBQ0gsT0FBTztBQUNMLGtCQUFNQSxTQUNKRixLQUFLSSxTQUFTO0FBRWhCUCxvQkFBUVEsSUFBSUgsUUFBUTtBQUFBLGNBQ2xCQyxLQUFLRDtBQUFBQSxjQUNMSSxZQUFZSjtBQUFBQSxZQUNkLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRixDQUFDO0FBRUR0RjtBQUFBQSxVQUNFK0UsTUFBTVosS0FBS2MsUUFBUVksT0FBTyxDQUFDO0FBQUEsUUFDN0I7QUFNQSxjQUFNQyxtQkFDSixNQUFNOUcsSUFBSTJGLElBQUksV0FBVztBQUUzQixjQUFNb0IsZUFDSkQsaUJBQWlCakIsTUFBTTVELFlBQ3ZCNkUsaUJBQWlCakIsTUFBTUEsUUFDdkJpQixpQkFBaUJqQixRQUNqQjtBQUVGL0U7QUFBQUEsVUFDRWlGLE1BQU1DLFFBQVFlLFlBQVksSUFDdEJBLGVBQ0E7QUFBQSxRQUNOO0FBQUEsTUFDRixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRDtBQUFBQSxVQUNOO0FBQUEsVUFDQUE7QUFBQUEsUUFDRjtBQUFBLE1BQ0YsVUFBQztBQUNDNUYsMEJBQWtCLEtBQUs7QUFBQSxNQUN6QjtBQUFBLElBQ0Y7QUFFQXFFLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQU1MM0YsWUFBVSxNQUFNO0FBQ2RtRix1QkFBbUIsT0FBTztBQUFBLEVBQzVCLEdBQUcsRUFBRTtBQU1MLFFBQU1pQyw2QkFBNkJBLENBQUN6RCxVQUFVO0FBQzVDLFVBQU0wRCxZQUFZMUQsU0FBUztBQUUzQjNCLGdCQUFZLENBQUM0QixVQUFVO0FBQUEsTUFDckIsR0FBR0E7QUFBQUEsTUFDSDNCLGdCQUFnQm9GO0FBQUFBLE1BQ2hCbkYsTUFBTTtBQUFBLE1BQ05DLFVBQVU7QUFBQSxJQUNaLEVBQUU7QUFFRixRQUFJLENBQUNrRixXQUFXO0FBQ2R2Riw4QkFBd0IsS0FBSztBQUU3Qm5CLDhCQUF3QixFQUFFO0FBRTFCYSwwQkFBb0IsRUFBRTtBQUN0QkUsd0JBQWtCLEVBQUU7QUFFcEI4QixtQkFBYTtBQUViO0FBQUEsSUFDRjtBQU1BMUIsNEJBQXdCLElBQUk7QUFNNUIsUUFBSUMsU0FBU0ssZUFBZSxVQUFVO0FBQ3BDSixrQkFBWSxDQUFDNEIsVUFBVTtBQUFBLFFBQ3JCLEdBQUdBO0FBQUFBLFFBQ0h4QixZQUFZO0FBQUEsTUFDZCxFQUFFO0FBQUEsSUFDSixPQUFPO0FBQ0wrQztBQUFBQSxRQUNFcEQsU0FBU0ssY0FBYztBQUFBLE1BQ3pCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFNQSxRQUFNa0YsOEJBQThCLFlBQVk7QUFDOUMsUUFBSSxDQUFDdkYsU0FBU0UsZ0JBQWdCO0FBQzVCa0YsY0FBUUk7QUFBQUEsUUFDTjtBQUFBLE1BQ0Y7QUFDQTtBQUFBLElBQ0Y7QUFFQSxRQUFJLENBQUNoRyxvQkFBb0IsQ0FBQ0UsZ0JBQWdCO0FBQ3hDMEYsY0FBUUk7QUFBQUEsUUFDTjtBQUFBLFFBQ0E7QUFBQSxVQUNFaEc7QUFBQUEsVUFDQUU7QUFBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQTtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0ZMLGlCQUFXLElBQUk7QUFFZixZQUFNb0csU0FBUyxJQUFJQyxnQkFBZ0I7QUFNbkNELGFBQU9FO0FBQUFBLFFBQ0w7QUFBQSxRQUNBM0YsU0FBU0U7QUFBQUEsTUFDWDtBQU1BdUYsYUFBT0U7QUFBQUEsUUFDTDtBQUFBLFFBQ0FuRztBQUFBQSxNQUNGO0FBRUFpRyxhQUFPRTtBQUFBQSxRQUNMO0FBQUEsUUFDQWpHO0FBQUFBLE1BQ0Y7QUFNQSxVQUFJTSxTQUFTRyxNQUFNO0FBQ2pCc0YsZUFBT0U7QUFBQUEsVUFDTDtBQUFBLFVBQ0EzRixTQUFTRztBQUFBQSxRQUNYO0FBQUEsTUFDRjtBQU1BLFVBQUlILFNBQVNJLFVBQVU7QUFDckJxRixlQUFPRTtBQUFBQSxVQUNMO0FBQUEsVUFDQTNGLFNBQVNJO0FBQUFBLFFBQ1g7QUFBQSxNQUNGO0FBRUEsWUFBTXdGLE1BQ0osMENBQTBDSCxPQUFPZCxTQUFTLENBQUM7QUFJN0QsWUFBTWtCLFdBQ0osTUFBTTFILElBQUkyRixJQUFJOEIsR0FBRztBQUVuQixZQUFNRSxlQUNKRCxTQUFTN0IsTUFBTUEsUUFBUTtBQU16QixZQUFNK0Isa0JBQWtCLElBQUlDO0FBQUFBLFFBQzFCRixhQUNHRztBQUFBQSxVQUNDLENBQUNDLFNBQ0NBLEtBQUtDLFVBQVV6QjtBQUFBQSxRQUNuQixFQUNDMEIsT0FBT0MsT0FBTztBQUFBLE1BQ25CO0FBRUEsWUFBTUMsa0JBQWtCLElBQUlOO0FBQUFBLFFBQzFCRixhQUNHUztBQUFBQSxVQUNDLENBQUNMLFNBQ0NBLEtBQUtNLHVCQUF1QjtBQUFBLFFBQ2hDLEVBQ0NQO0FBQUFBLFVBQ0MsQ0FBQ1EsYUFDQ0EsU0FBU0MsY0FBY2hDO0FBQUFBLFFBQzNCLEVBQ0MwQixPQUFPQyxPQUFPO0FBQUEsTUFDbkI7QUFFQSxZQUFNckYsYUFDSjhFLGFBQWFhO0FBQUFBLFFBQ1gsQ0FBQ0MsT0FBT1YsU0FDTlUsU0FDQ1YsS0FBS1csbUJBQ0ZDLFVBQVU7QUFBQSxRQUNoQjtBQUFBLE1BQ0Y7QUFFRixZQUFNN0YsYUFDSjZFLGFBQWFhO0FBQUFBLFFBQ1gsQ0FBQ0MsT0FBT1YsU0FDTlUsU0FDQ1YsS0FBS2EsY0FDRkQsVUFBVTtBQUFBLFFBQ2hCO0FBQUEsTUFDRjtBQU1GLFlBQU1FLGNBQ0psQixhQUFhYTtBQUFBQSxRQUNYLENBQUNNLEtBQUtmLFNBQVM7QUFDYixXQUNFQSxLQUFLVyxxQkFBcUIsSUFDMUJ2QyxRQUFRLENBQUM0QyxTQUFTO0FBQ2xCRCxnQkFBSS9GLGdCQUNGOEI7QUFBQUEsY0FDRWtFLEtBQUtDLGlCQUFpQjtBQUFBLFlBQ3hCO0FBRUZGLGdCQUFJOUYsbUJBQ0Y2QjtBQUFBQSxjQUNFa0UsS0FBS0Usb0JBQW9CO0FBQUEsWUFDM0I7QUFFRkgsZ0JBQUk3RixnQkFDRjRCO0FBQUFBLGNBQ0VrRSxLQUFLRyxpQkFBaUI7QUFBQSxZQUN4QjtBQUVGSixnQkFBSTVGLGdCQUNGMkI7QUFBQUEsY0FDRWtFLEtBQUtJLGtCQUFrQjtBQUFBLFlBQ3pCO0FBRUZMLGdCQUFJTSxnQkFDRnZFO0FBQUFBLGNBQ0VrRSxLQUFLTSxpQkFBaUI7QUFBQSxZQUN4QjtBQUFBLFVBQ0osQ0FBQztBQUVELGlCQUFPUDtBQUFBQSxRQUNUO0FBQUEsUUFDQTtBQUFBLFVBQ0UvRixjQUFjO0FBQUEsVUFDZEMsaUJBQWlCO0FBQUEsVUFDakJDLGNBQWM7QUFBQSxVQUNkQyxjQUFjO0FBQUEsVUFDZGtHLGNBQWM7QUFBQSxRQUNoQjtBQUFBLE1BQ0Y7QUFNRixZQUFNRSxjQUNKM0IsYUFBYWE7QUFBQUEsUUFDWCxDQUFDTSxLQUFLZixTQUFTO0FBQ2IsV0FDRUEsS0FBS2EsZ0JBQWdCLElBQ3JCekMsUUFBUSxDQUFDb0QsU0FBUztBQUNsQlQsZ0JBQUlVLGFBQ0YzRTtBQUFBQSxjQUNFMEUsS0FBS0UscUJBQXFCO0FBQUEsWUFDNUI7QUFFRlgsZ0JBQUlNLGdCQUNGdkU7QUFBQUEsY0FDRTBFLEtBQUtHLFdBQVc7QUFBQSxZQUNsQjtBQUFBLFVBQ0osQ0FBQztBQUVELGlCQUFPWjtBQUFBQSxRQUNUO0FBQUEsUUFDQTtBQUFBLFVBQ0VVLFdBQVc7QUFBQSxVQUNYSixjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGO0FBTUYzRyxpQkFBVztBQUFBLFFBQ1RDLGVBQ0VpRixhQUFhZ0I7QUFBQUEsUUFFZmhHLGdCQUNFaUYsZ0JBQWdCK0I7QUFBQUEsUUFFbEIvRyxnQkFDRXVGLGdCQUFnQndCO0FBQUFBLFFBRWxCOUc7QUFBQUEsUUFFQUM7QUFBQUEsUUFFQUMsY0FDRThGLFlBQVk5RjtBQUFBQSxRQUVkQyxpQkFDRTZGLFlBQVk3RjtBQUFBQSxRQUVkQyxjQUNFNEYsWUFBWTVGO0FBQUFBLFFBRWRDLGNBQ0UyRixZQUFZM0Y7QUFBQUEsUUFFZEMsa0JBQ0UwRixZQUFZTztBQUFBQSxRQUVkaEcsZUFDRWtHLFlBQVlFO0FBQUFBLFFBRWRuRyxrQkFDRWlHLFlBQVlGO0FBQUFBLE1BQ2hCLENBQUM7QUFNRCxZQUFNUSxZQUNKakMsY0FBY00sT0FBTyxDQUFDRixTQUFTO0FBQ2pDLGNBQU1nQixPQUNKaEIsS0FBS1csb0JBQW9CLENBQUMsS0FBSyxDQUFDO0FBRWxDLGNBQU1tQixtQkFDSmQsTUFBTWUsVUFBVUM7QUFFbEIsZUFDRUYscUJBQXFCLFFBQ3JCQSxxQkFBcUJHLFVBQ3JCbkYsT0FBT2dGLGdCQUFnQixJQUFJO0FBQUEsTUFFL0IsQ0FBQyxFQUFFL0I7QUFBQUEsUUFDRyxDQUFDQyxNQUFNa0MsVUFBVTtBQUVmLGdCQUFNakMsV0FDSkQsS0FBS0MsWUFBWSxDQUFDO0FBRXBCLGdCQUFNTSxXQUNKUCxLQUFLTSxzQkFBc0IsQ0FBQyxLQUM1QixDQUFDO0FBRUgsZ0JBQU02QixtQkFDSm5DLEtBQUtXLHFCQUFxQjtBQUU1QixnQkFBTXlCLGNBQ0pwQyxLQUFLYSxnQkFBZ0I7QUFFdkIsZ0JBQU1HLE9BQ0ptQixpQkFBaUIsQ0FBQyxLQUFLLENBQUM7QUFFMUIsZ0JBQU1YLE9BQ0pZLFlBQVksQ0FBQyxLQUFLLENBQUM7QUFNckIsY0FBSUMscUJBQXFCO0FBRXpCLGNBQ0VwQyxTQUFTM0IsbUJBQ1QsT0FBTzJCLFNBQVMzQixvQkFDaEIsVUFDQTtBQUNBK0QsaUNBQ0VwQyxTQUFTM0IsaUJBQ0xLLGNBQ0pzQixTQUFTM0IsaUJBQ0xNLGFBQ0pxQixTQUFTM0IsaUJBQ0xPLFFBQ0o7QUFBQSxVQUNKLFdBQ0VvQixTQUFTM0IsaUJBQ1Q7QUFDQSxrQkFBTWdFLFlBQ0p0SixnQkFBZ0J1SjtBQUFBQSxjQUNkLENBQUNsRSxTQUNDQSxLQUFLRyxLQUFLQyxTQUFTLE1BQ25Cd0IsU0FBUzNCLGlCQUFpQkcsU0FBUztBQUFBLFlBQ3ZDO0FBRUY0RCxpQ0FDRUMsV0FBVzNELGNBQ1hzQixTQUFTM0IsbUJBQ1Q7QUFBQSxVQUNKO0FBTUEsZ0JBQU1rRSxlQUNKakMsU0FBU0MsY0FBYzNCLFFBQ3ZCMEIsU0FBU2tDLGlCQUNUO0FBRUYsZ0JBQU1DLGdCQUNKbkMsU0FBU0MsY0FDTG1DLGdCQUNKcEMsU0FBU3FDLGtCQUNUO0FBRUYsZ0JBQU1DLGVBQ0p0QyxTQUFTQyxjQUNMcUMsZ0JBQ0p0QyxTQUFTc0MsZ0JBQ1Q7QUFNRixnQkFBTUMsVUFDSjlDLEtBQUsrQyxXQUFXLENBQUMsS0FBSztBQU14QixpQkFBTztBQUFBLFlBQ0xDLElBQ0V6QyxTQUFTL0IsT0FDVHlCLFNBQVN6QixPQUNUMEQ7QUFBQUEsWUFFRmUsTUFBTWYsUUFBUTtBQUFBO0FBQUEsWUFHZGpDLFVBQ0UsR0FBR0EsU0FBU2lELGFBQWEsR0FBRyxNQUFNakQsU0FBUzBDLGdCQUFnQixHQUFHO0FBQUEsWUFHaEVRLFlBQ0VsRCxTQUFTbUQsZUFBZTtBQUFBLFlBRTFCcEosZ0JBQ0VxSTtBQUFBQSxZQUVGZ0IsU0FDRXBELFNBQVNvRCxXQUFXO0FBQUEsWUFFdEJDLFNBQ0VyRCxTQUFTcUQsV0FBVztBQUFBO0FBQUEsWUFHdEJwSixVQUNFLEdBQUdzSSxZQUFZLE1BQU1FLGFBQWE7QUFBQSxZQUVwQ0c7QUFBQUE7QUFBQUEsWUFHQVUsZ0JBQ0VoRCxTQUFTaUQsa0JBQ0xsSDtBQUFBQSxjQUNBaUUsU0FBU2lEO0FBQUFBLFlBQ1gsSUFDRTtBQUFBLFlBRU5DLFFBQU96RCxLQUFLMEQsbUJBQWlCLFNBQVMsU0FDcEMxRCxLQUFLMkQsbUJBQ0gzRCxLQUFLMkQsb0JBQW9CLG1CQUN2QjNELEtBQUsyRCxnQkFBZ0JDLFFBQVEsTUFBTSxHQUFHLElBQ3RDckQsU0FBU2tELFVBQVU7QUFBQSxZQUN6QnpCLG1CQUFtQmhCLE1BQU1lLFVBQVVDO0FBQUFBLFlBQ25DNkIsaUJBQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsVUFDRTdELGVBQUsrQyxVQUFVdEM7QUFBQUEsZ0JBQ2QsQ0FBQ0MsT0FBT29DLGFBQVlwQyxRQUFRNUQsT0FBT2dHLFNBQVFqRyxVQUFVLENBQUM7QUFBQSxnQkFDdEQ7QUFBQSxjQUNGLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBRUNtRCxLQUFLK0MsVUFBVW5DLFNBQVMsS0FDdkI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FDRSx1QkFBQyxTQUNFWixlQUFLK0MsVUFBVWhEO0FBQUFBLG9CQUFJLENBQUMrQyxVQUFTWixXQUM1Qix1QkFBQyxTQUFnQjtBQUFBO0FBQUEsc0JBQ2JZLFNBQVFqRztBQUFBQSx5QkFERnFGLFFBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUdGLGlDQUFDLHNCQUFtQixXQUFVLGtDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RDtBQUFBO0FBQUEsZ0JBWDlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlBO0FBQUEsaUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUJBO0FBQUEsWUFHRjRCLFFBQ0V2RCxTQUFTdUQsVUFDVHZELFNBQVN3RCxXQUNUO0FBQUEsWUFFRkMsZUFDRWhFLEtBQUswRCxrQkFBa0I7QUFBQTtBQUFBLFlBR3pCTyxXQUNFakQsS0FBS2UsVUFBVW1DLGNBQ2ZsRCxLQUFLa0QsY0FDTDtBQUFBLFlBRUZDLFFBQ0VuRCxLQUFLb0QsV0FDTHBELEtBQUttRCxVQUNMO0FBQUEsWUFFRkUsYUFDRXJELEtBQUtzRCxnQkFDTHhCLFNBQVN3QixnQkFDVDtBQUFBLFlBRUZDLGdCQUNFdkQsS0FBS3dELG1CQUNMO0FBQUEsWUFFRnhKLGNBQ0VnRyxLQUFLQyxrQkFBa0JnQixTQUNuQm5GO0FBQUFBLGNBQ0FrRSxLQUFLQztBQUFBQSxZQUNQLElBQ0U7QUFBQSxZQUVOaEcsaUJBQ0UrRixLQUFLRSxxQkFBcUJlLFNBQ3RCbkY7QUFBQUEsY0FDQWtFLEtBQUtFO0FBQUFBLFlBQ1AsSUFDRTtBQUFBLFlBRU5oRyxjQUNFOEYsS0FBS0csa0JBQWtCYyxTQUNuQm5GO0FBQUFBLGNBQ0FrRSxLQUFLRztBQUFBQSxZQUNQLElBQ0U7QUFBQSxZQUVOaEcsY0FDRTZGLEtBQUtJLG1CQUFtQmEsU0FDcEJuRjtBQUFBQSxjQUNBa0UsS0FBS0k7QUFBQUEsWUFDUCxJQUNFO0FBQUEsWUFFTnFELGFBQ0V6RCxLQUFLTSxrQkFBa0JXLFNBQ25CbkY7QUFBQUEsY0FDQWtFLEtBQUtNO0FBQUFBLFlBQ1AsSUFDRTtBQUFBO0FBQUEsWUFHTm9ELFFBQ0VsRCxLQUFLbUQsV0FBVztBQUFBLFlBRWxCQyxZQUNFcEQsS0FBS3FELGdCQUFnQjVDLFNBQ2pCbkY7QUFBQUEsY0FDQTBFLEtBQUtxRDtBQUFBQSxZQUNQLElBQ0U7QUFBQSxZQUVOQyxlQUNFdEQsS0FBS3VELGFBQ0R6STtBQUFBQSxjQUNBa0YsS0FBS3VEO0FBQUFBLFlBQ1AsSUFDRTtBQUFBLFlBRU5DLGFBQ0V4RCxLQUFLeUQsV0FDRDNJO0FBQUFBLGNBQ0FrRixLQUFLeUQ7QUFBQUEsWUFDUCxJQUNFO0FBQUEsWUFFTkMsZ0JBQ0UxRCxLQUFLRSxzQkFDSE8sU0FDRW5GO0FBQUFBLGNBQ0EwRSxLQUFLRTtBQUFBQSxZQUNQLElBQ0U7QUFBQSxZQUVOeUQsYUFDRTNELEtBQUtHLFlBQVlNLFNBQ2JuRjtBQUFBQSxjQUNBMEUsS0FBS0c7QUFBQUEsWUFDUCxJQUNFO0FBQUEsWUFFTnlELFlBQ0U1RCxLQUFLNkQsVUFBVTtBQUFBLFVBQ25CO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDRixZQUFNL0ssd0JBQXdCdUgsVUFBVXBCO0FBQUFBLFFBQ3RDLENBQUNDLE9BQU9WLFNBQ05VLFFBQVE1RCxPQUFPa0QsS0FBS2dDLHFCQUFxQixDQUFDO0FBQUEsUUFDNUM7QUFBQSxNQUNGO0FBRUEsWUFBTXpILHNCQUFzQnFGLGFBQWFhO0FBQUFBLFFBQ3ZDLENBQUNDLE9BQU9WLFNBQ05VLFNBQ0NWLEtBQUsrQyxVQUFVdEM7QUFBQUEsVUFDZCxDQUFDNkUsY0FBY3hDLFlBQ2J3QyxlQUNBeEksT0FBT2dHLFFBQVFqRyxVQUFVLENBQUM7QUFBQSxVQUM1QjtBQUFBLFFBQ0YsS0FBSztBQUFBLFFBQ1A7QUFBQSxNQUNGO0FBRUEsWUFBTXJDLGVBQWUrSyxLQUFLQztBQUFBQSxRQUN4QjtBQUFBLFFBQ0FsTCx3QkFDQUM7QUFBQUEsTUFDRjtBQUVBRiwwQkFBb0I7QUFBQSxRQUNsQkM7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUM7QUFBQUEsTUFDRixDQUFDO0FBRUQ5QjtBQUFBQSxRQUNFbUo7QUFBQUEsTUFDRjtBQUFBLElBQ0YsU0FBUzVDLE9BQU87QUFDZEMsY0FBUUQ7QUFBQUEsUUFDTjtBQUFBLFFBQ0FBO0FBQUFBLE1BQ0Y7QUFFQXZHLDhCQUF3QixFQUFFO0FBRTFCNkMsbUJBQWE7QUFBQSxJQUNmLFVBQUM7QUFDQ3BDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFPQXBCO0FBQUFBLElBQVUsTUFBTTtBQUNkLFVBQ0UsQ0FBQytCLFNBQVNFLGtCQUNWLENBQUNWLG9CQUNELENBQUNFLGdCQUNEO0FBQ0E7QUFBQSxNQUNGO0FBRUE2RixrQ0FBNEI7QUFBQSxJQUM5QjtBQUFBLElBQUc7QUFBQSxNQUNEdkYsU0FBU0U7QUFBQUEsTUFDVEYsU0FBU0c7QUFBQUEsTUFDVEgsU0FBU0k7QUFBQUEsTUFDVFo7QUFBQUEsTUFDQUU7QUFBQUEsSUFBYztBQUFBLEVBQ2Y7QUFNRCxRQUFNaU0sU0FBUztBQUFBLElBQ2I7QUFBQSxNQUNFQyxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUVBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFFQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBRUE7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUVBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0E7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFHQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBRUE7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0E7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUVBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFFQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVlBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1DQTtBQU9GLFFBQU1DLGtCQUFrQkEsTUFBTTtBQUM1QjdMLGdCQUFZO0FBQUEsTUFDVkMsZ0JBQWdCO0FBQUEsTUFDaEJDLE1BQU07QUFBQSxNQUNOQyxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLElBQ2QsQ0FBQztBQUVETiw0QkFBd0IsS0FBSztBQUM3QkYsdUJBQW1CLEtBQUs7QUFFeEJKLHdCQUFvQixFQUFFO0FBQ3RCRSxzQkFBa0IsRUFBRTtBQUVwQmYsNEJBQXdCLEVBQUU7QUFFMUI2QyxpQkFBYTtBQUFBLEVBQ2Y7QUFNQSxTQUNFLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLDJCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFFekIsdUJBQUMsU0FBSSxXQUFVLHlCQUViO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtCQUE4QixnREFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFNQSx1QkFBQyxTQUFJLFdBQVUsMENBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0JBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FFYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrQ0FBaUMsc0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixPQUNFekIsU0FBU0Usa0JBQ1RpSTtBQUFBQSxnQkFFRixVQUNFOUM7QUFBQUEsZ0JBRUY7QUFBQSxnQkFDQTtBQUFBLGdCQUNBLGtCQUFpQjtBQUFBLGdCQUdoQm5HLDBCQUFnQitHO0FBQUFBLGtCQUNmLENBQUMxQixTQUNDO0FBQUEsb0JBQUMsT0FBTztBQUFBLG9CQUFQO0FBQUEsc0JBRUMsT0FBT0EsS0FBS0c7QUFBQUEsc0JBRVhILGVBQUtNO0FBQUFBO0FBQUFBLG9CQUhETixLQUFLRztBQUFBQSxvQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsZ0JBRUo7QUFBQTtBQUFBLGNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTBCQTtBQUFBLGVBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0NBO0FBQUEsVUFFQzFFLFNBQVNFLGtCQUNSO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTNEw7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBNEM7QUFBQTtBQUFBLFlBSHhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUE3Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdEQTtBQUFBLFFBRUMsQ0FBQzlMLFNBQVNFLGtCQUNULHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsc0RBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBdkRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwREE7QUFBQSxNQU1DSix3QkFDQyx1QkFBQyxTQUFJLFdBQVUsMENBRWIsaUNBQUMsU0FBSSxXQUFVLHdCQUliO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFNBRWI7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsc0JBQXFCLDJCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FDRUUsU0FBU0s7QUFBQUEsY0FFWCxVQUFVLENBQUN1QixVQUFVO0FBQ25CRjtBQUFBQSxrQkFDRTtBQUFBLGtCQUNBRTtBQUFBQSxnQkFDRjtBQUFBLGNBQ0Y7QUFBQSxjQUdDc0IsNEJBQWtCK0M7QUFBQUEsZ0JBQ2pCLENBQUM4RixXQUNDO0FBQUEsa0JBQUMsT0FBTztBQUFBLGtCQUFQO0FBQUEsb0JBSUMsT0FDRUEsT0FBT25LO0FBQUFBLG9CQUdSbUssaUJBQU81STtBQUFBQTtBQUFBQSxrQkFOTjRJLE9BQU9uSztBQUFBQSxrQkFGWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUEsY0FFSjtBQUFBO0FBQUEsWUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBNEJBO0FBQUEsYUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9DQTtBQUFBLFFBSUNoQyxtQkFDQyx1QkFBQyxTQUFJLFdBQVUsd0JBNENiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxpQkFBZ0Isb0JBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFDO0FBQUEsWUFFckM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLE9BQU9KO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ3dNLE1BQU07QUFDZix3QkFBTWpLLE9BQU9pSyxFQUFFQyxPQUFPcks7QUFFdEJuQyxzQ0FBb0JzQyxJQUFJO0FBR3hCcEMsb0NBQWtCb0MsSUFBSTtBQUFBLGdCQUN4QjtBQUFBO0FBQUEsY0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXSTtBQUFBLGVBZE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsaUJBQWdCLGtCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQztBQUFBLFlBRW5DO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixPQUFPckM7QUFBQUEsZ0JBQ1AsS0FBS0Y7QUFBQUEsZ0JBQ0wsS0FBS0E7QUFBQUEsZ0JBQ0wsVUFBVSxDQUFDd00sTUFBTTtBQUNmck0sb0NBQWtCcU0sRUFBRUMsT0FBT3JLLEtBQUs7QUFBQSxnQkFDbEM7QUFBQTtBQUFBLGNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUk7QUFBQSxlQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQTNFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkVBO0FBQUEsUUFLRix1QkFBQyxTQUFJLFdBQVUsU0FFYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxzQkFBcUIsK0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixPQUNFNUIsU0FBU0ksWUFDVCtIO0FBQUFBLGNBRUYsVUFBVSxDQUFDdkcsVUFBVTtBQUNuQkY7QUFBQUEsa0JBQ0U7QUFBQSxrQkFDQUU7QUFBQUEsZ0JBQ0Y7QUFBQSxjQUNGO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBLGtCQUFpQjtBQUFBLGNBR2hCNUMsb0JBQVVpSDtBQUFBQSxnQkFDVCxDQUFDN0YsYUFDQztBQUFBLGtCQUFDLE9BQU87QUFBQSxrQkFBUDtBQUFBLG9CQUlDLE9BQ0VBLFNBQVNzRTtBQUFBQSxvQkFHVnRFO0FBQUFBLCtCQUFTMkU7QUFBQUEsc0JBRVQzRSxTQUFTeUksZUFDTixNQUFNekksU0FBU3lJLFlBQVksS0FDM0I7QUFBQTtBQUFBO0FBQUEsa0JBVkZ6SSxTQUFTc0U7QUFBQUEsa0JBRmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFhQTtBQUFBLGNBRUo7QUFBQTtBQUFBLFlBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXFDQTtBQUFBLGFBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2Q0E7QUFBQSxRQUlBLHVCQUFDLFNBQUksV0FBVSxTQUViO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHNCQUFxQiwrQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQ0UxRSxTQUFTRyxRQUNUZ0k7QUFBQUEsY0FFRixVQUFVLENBQUN2RyxVQUFVO0FBQ25CRjtBQUFBQSxrQkFDRTtBQUFBLGtCQUNBRTtBQUFBQSxnQkFDRjtBQUFBLGNBQ0Y7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0Esa0JBQWlCO0FBQUEsY0FHaEI5QyxnQkFDRXNILE9BQU8sQ0FBQ2pHLFNBQVM7QUFDaEIsc0JBQU1vRSxPQUNKcEUsS0FBS3FFO0FBRVAsb0JBQ0UsQ0FBQ3hFLFNBQVNFLGdCQUNWO0FBQ0EseUJBQU87QUFBQSxnQkFDVDtBQUVBLG9CQUNFLE9BQU9xRSxTQUNQLFVBQ0E7QUFDQSx5QkFDRUEsTUFBTUcsS0FBS0MsU0FBUyxNQUNwQjNFLFNBQVNFO0FBQUFBLGdCQUViO0FBRUEsdUJBQ0VxRSxNQUFNSSxTQUFTLE1BQ2YzRSxTQUFTRTtBQUFBQSxjQUViLENBQUMsRUFDQStGO0FBQUFBLGdCQUFJLENBQUM5RixTQUNKO0FBQUEsa0JBQUMsT0FBTztBQUFBLGtCQUFQO0FBQUEsb0JBRUMsT0FBT0EsS0FBS3VFO0FBQUFBLG9CQUVYdkU7QUFBQUEsMkJBQUtpSjtBQUFBQSxzQkFFTGpKLEtBQUswSSxlQUNGLE1BQU0xSSxLQUFLMEksWUFBWSxLQUN2QjtBQUFBO0FBQUE7QUFBQSxrQkFQQzFJLEtBQUt1RTtBQUFBQSxrQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUF2REw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBeURBO0FBQUEsYUEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlFQTtBQUFBLFdBalBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtUEEsS0FyUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVQQTtBQUFBLE1BT0Q1RSx3QkFDQ0UsU0FBU0Usa0JBQ1AsdUJBQUMsU0FBSSxXQUFVLCtCQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHdDQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw4QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsUUFBRyxXQUFVLCtCQUNYUyxrQkFBUUUsaUJBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUseUJBQXdCLCtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxRQUFHLFdBQVUsK0JBQ1hGLGtCQUFRRyxrQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQWdDQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUseUJBQXdCLDRCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxRQUFHLFdBQVUsK0JBR047QUFBQTtBQUFBLFlBQ0pSLGlCQUFpQkUsc0JBQXNCeUMsZUFBZTtBQUFBLGVBSjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdDQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHlCQUF3Qix5QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsUUFBRyxXQUFVLCtCQUdOO0FBQUE7QUFBQSxZQUNKM0MsaUJBQWlCRyxvQkFBb0J3QyxlQUFlO0FBQUEsZUFKeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUseUJBQXdCLDRCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxRQUFHLFdBQVUsK0JBR047QUFBQTtBQUFBLFlBQ0ozQyxpQkFBaUJJLGFBQWF1QyxlQUFlO0FBQUEsZUFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0F6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJJQTtBQUFBLE1BT0huRCx3QkFDQ0UsU0FBU0UsbUJBQ1BkLFVBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVc7QUFBQSxVQUNYLFNBQVM7QUFBQSxVQUNULE1BQUs7QUFBQTtBQUFBLFFBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3lDLElBRXZDVCxxQkFBcUJtSSxTQUFTLElBQ2hDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTNkU7QUFBQUEsVUFDVCxNQUFNaE47QUFBQUEsVUFDTixrQkFBaUI7QUFBQSxVQUNqQixpQkFBZ0I7QUFBQTtBQUFBLFFBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlvRCxJQUdwRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVztBQUFBLFVBQ1gsU0FBUztBQUFBLFVBQ1QsTUFBSztBQUFBO0FBQUEsUUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHeUM7QUFBQSxTQWhmakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFmQTtBQUFBLE9BeGZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5ZkE7QUFFSjtBQUFFRCxHQXRwRElELHdCQUFzQjtBQUFBeU4sS0FBdEJ6TjtBQTBwRE4sZUFBZUE7QUFBdUIsSUFBQXlOO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJEYXRhVGFibGUiLCJhcGkiLCJOYXZiYXIiLCJTZWxlY3QiLCJUb29sdGlwIiwiQ2lyY3VsYXJMb2FkZXIiLCJJbmZvQ2lyY2xlT3V0bGluZWQiLCJDdXN0b21lclRyYWNraW5nUmVwb3J0IiwiX3MiLCJjdXN0b21lclRyYWNraW5nRGF0YSIsInNldEN1c3RvbWVyVHJhY2tpbmdEYXRhIiwidXNlU3RhdGUiLCJ1c2VycyIsInNldFVzZXJzIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwiY29sbGVjdGlvbkFyZWFzIiwic2V0Q29sbGVjdGlvbkFyZWFzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJpbml0aWFsTG9hZGluZyIsInNldEluaXRpYWxMb2FkaW5nIiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZFRvRGF0ZSIsInNldFNlbGVjdGVkVG9EYXRlIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwic2hvd1JlbWFpbmluZ0ZpbHRlcnMiLCJzZXRTaG93UmVtYWluaW5nRmlsdGVycyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJjb2xsZWN0aW9uQXJlYSIsInVzZXIiLCJlbXBsb3llZSIsImZpbHRlclR5cGUiLCJjb2xsZWN0aW9uVG90YWxzIiwic2V0Q29sbGVjdGlvblRvdGFscyIsInRvdGFsRGFpbHlJbnN0YWxsbWVudCIsInRvdGFsUmVjZW50UGF5bWVudHMiLCJkYWlseUJhbGFuY2UiLCJzdW1tYXJ5Iiwic2V0U3VtbWFyeSIsInRvdGFsVHJhY2tpbmciLCJ0b3RhbEN1c3RvbWVycyIsInRvdGFsRW1wbG95ZWVzIiwidG90YWxDaGl0cyIsInRvdGFsTG9hbnMiLCJ0b3RhbFBheWFibGUiLCJ0b3RhbEludmVzdG1lbnQiLCJ0b3RhbFBlbmFsdHkiLCJ0b3RhbExhdGVGZWUiLCJ0b3RhbENoaXRCYWxhbmNlIiwidG90YWxMb2FuUGFpZCIsInRvdGFsTG9hbkJhbGFuY2UiLCJyZXNldFN1bW1hcnkiLCJoYW5kbGVBbnREU2VsZWN0IiwiZmllbGQiLCJ2YWx1ZSIsInByZXYiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInllYXIiLCJnZXRGdWxsWWVhciIsIm1vbnRoIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImRheSIsImdldERhdGUiLCJmb3JtYXREaXNwbGF5RGF0ZSIsInBhcnNlZERhdGUiLCJEYXRlIiwiaXNOYU4iLCJnZXRUaW1lIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZm9ybWF0QW1vdW50IiwiYW1vdW50IiwiTnVtYmVyIiwidG9Mb2NhbGVTdHJpbmciLCJkYXRlRmlsdGVyT3B0aW9ucyIsImxhYmVsIiwiaGFuZGxlU2VsZWN0RmlsdGVyIiwidG9kYXkiLCJmcm9tIiwidG8iLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwic3RhcnQiLCJlbmQiLCJmZXRjaEluaXRpYWxEYXRhIiwidXNlclJlc3BvbnNlIiwiZ2V0IiwidXNlckRhdGEiLCJkYXRhIiwic2FmZVVzZXJzIiwiQXJyYXkiLCJpc0FycmF5IiwiYXJlYU1hcCIsIk1hcCIsImZvckVhY2giLCJhcmVhIiwiY29sbGVjdGlvbl9hcmVhIiwiYXJlYUlkIiwiX2lkIiwidG9TdHJpbmciLCJzZXQiLCJyb3V0ZV9uYW1lIiwiYXJlYV9uYW1lIiwibmFtZSIsInZhbHVlcyIsImVtcGxveWVlUmVzcG9uc2UiLCJlbXBsb3llZURhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVDb2xsZWN0aW9uQXJlYUNoYW5nZSIsImFyZWFWYWx1ZSIsImZldGNoQ3VzdG9tZXJUcmFja2luZ1JlcG9ydCIsImxvZyIsInBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsImFwcGVuZCIsInVybCIsInJlc3BvbnNlIiwicmVzcG9uc2VEYXRhIiwidW5pcXVlQ3VzdG9tZXJzIiwiU2V0IiwibWFwIiwiaXRlbSIsImN1c3RvbWVyIiwiZmlsdGVyIiwiQm9vbGVhbiIsInVuaXF1ZUVtcGxveWVlcyIsImZsYXRNYXAiLCJjb2xsZWN0aW9uX3RyYWNraW5nIiwidHJhY2tpbmciLCJjb2xsZWN0ZWRfYnkiLCJyZWR1Y2UiLCJ0b3RhbCIsImN1c3RvbWVyX292ZXJ2aWV3IiwibGVuZ3RoIiwibG9hbl9kZXRhaWxzIiwiY2hpdFN1bW1hcnkiLCJhY2MiLCJjaGl0IiwidG90YWxfcGF5YWJsZSIsInRvdGFsX2ludmVzdG1lbnQiLCJ0b3RhbF9wZW5hbHR5IiwidG90YWxfbGF0ZV9mZWUiLCJ0b3RhbEJhbGFuY2UiLCJ0b3RhbF9iYWxhbmNlIiwibG9hblN1bW1hcnkiLCJsb2FuIiwidG90YWxQYWlkIiwidG90YWxfcGFpZF9hbW91bnQiLCJiYWxhbmNlIiwic2l6ZSIsImZvcm1hdHRlZCIsImRhaWx5SW5zdGFsbG1lbnQiLCJncm91cF9pZCIsImRhaWx5X2luc3RhbGxtZW50IiwidW5kZWZpbmVkIiwiaW5kZXgiLCJjdXN0b21lck92ZXJ2aWV3IiwibG9hbkRldGFpbHMiLCJjb2xsZWN0aW9uQXJlYU5hbWUiLCJmb3VuZEFyZWEiLCJmaW5kIiwiZW1wbG95ZWVOYW1lIiwiZW1wbG95ZWVfbmFtZSIsImVtcGxveWVlUGhvbmUiLCJwaG9uZV9udW1iZXIiLCJlbXBsb3llZV9waG9uZSIsImVtcGxveWVlQ29kZSIsInBheW1lbnQiLCJwYXltZW50cyIsImlkIiwic2xObyIsImZ1bGxfbmFtZSIsImN1c3RvbWVySWQiLCJjdXN0b21lcl9pZCIsImFkZHJlc3MiLCJwaW5jb2RlIiwiY29sbGVjdGlvbkRhdGUiLCJjb2xsZWN0aW9uX2RhdGUiLCJyZWFzb24iLCJwYXltZW50X3N0YXR1cyIsIm5vdF9wYWlkX3JlYXNvbiIsInJlcGxhY2UiLCJyZWNlbnRfcGF5bWVudHMiLCJyZW1hcmsiLCJyZW1hcmtzIiwicGF5bWVudFN0YXR1cyIsImdyb3VwTmFtZSIsImdyb3VwX25hbWUiLCJ0aWNrZXQiLCJ0aWNrZXRzIiwicGF5bWVudFR5cGUiLCJwYXltZW50X3R5cGUiLCJjdXN0b21lclN0YXR1cyIsImN1c3RvbWVyX3N0YXR1cyIsImNoaXRCYWxhbmNlIiwibG9hbklkIiwibG9hbl9pZCIsImxvYW5BbW91bnQiLCJsb2FuX2Ftb3VudCIsImxvYW5TdGFydERhdGUiLCJzdGFydF9kYXRlIiwibG9hbkVuZERhdGUiLCJlbmRfZGF0ZSIsImxvYW5QYWlkQW1vdW50IiwibG9hbkJhbGFuY2UiLCJsb2FuU3RhdHVzIiwic3RhdHVzIiwicGF5bWVudFRvdGFsIiwiTWF0aCIsIm1heCIsImNvbHVtbiIsImtleSIsImhlYWRlciIsImhhbmRsZVJlc2V0QXJlYSIsIm9wdGlvbiIsImUiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDdXN0b21lclRyYWNraW5nUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgVG9vbHRpcCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEluZm9DaXJjbGVPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5cclxuLy8gY29uc3QgQ3VzdG9tZXJUcmFja2luZ1JlcG9ydCA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbY3VzdG9tZXJUcmFja2luZ0RhdGEsIHNldEN1c3RvbWVyVHJhY2tpbmdEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbi8vICAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbi8vICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRUb0RhdGUsIHNldFNlbGVjdGVkVG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuLy8gICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHVzZXI6IFwiXCIsXHJcbi8vICAgICBlbXBsb3llZTogXCJcIixcclxuLy8gICAgIGZpbHRlclR5cGU6IFwiVG9kYXlcIixcclxuLy8gICB9KTtcclxuLy8gICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB0b3RhbFRyYWNraW5nOiAwLFxyXG4vLyAgICAgdG90YWxDdXN0b21lcnM6IDAsXHJcbi8vICAgICB0b3RhbEVtcGxveWVlczogMCxcclxuLy8gICB9KTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuLy8gICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4vLyAgICAgICAuLi5wcmV2LFxyXG4vLyAgICAgICBbZmllbGRdOiB2YWx1ZSxcclxuLy8gICAgIH0pKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBkYXRlRmlsdGVyT3B0aW9ucyA9IFtcclxuLy8gICAgIHtcclxuLy8gICAgICAgdmFsdWU6IFwiVG9kYXlcIixcclxuLy8gICAgICAgbGFiZWw6IFwiVG9kYXlcIixcclxuLy8gICAgIH0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIHZhbHVlOiBcIlllc3RlcmRheVwiLFxyXG4vLyAgICAgICBsYWJlbDogXCJZZXN0ZXJkYXlcIixcclxuLy8gICAgIH0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIHZhbHVlOiBcIlRoaXNNb250aFwiLFxyXG4vLyAgICAgICBsYWJlbDogXCJUaGlzIE1vbnRoXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICB2YWx1ZTogXCJMYXN0TW9udGhcIixcclxuLy8gICAgICAgbGFiZWw6IFwiTGFzdCBNb250aFwiLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAgdmFsdWU6IFwiVGhpc1llYXJcIixcclxuLy8gICAgICAgbGFiZWw6IFwiVGhpcyBZZWFyXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICB2YWx1ZTogXCJDdXN0b21cIixcclxuLy8gICAgICAgbGFiZWw6IFwiQ3VzdG9tXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4ge1xyXG4vLyAgICAgcmV0dXJuIGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbi8vICAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuLy8gICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuXHJcbi8vICAgICBsZXQgZnJvbSA9IFwiXCI7XHJcbi8vICAgICBsZXQgdG8gPSBcIlwiO1xyXG5cclxuLy8gICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbi8vICAgICAgIGZyb20gPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgICAgdG8gPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG5cclxuLy8gICAgICAgeWVzdGVyZGF5LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcblxyXG4vLyAgICAgICBmcm9tID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4vLyAgICAgICB0byA9IGZvcm1hdERhdGUoeWVzdGVyZGF5KTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuXHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuXHJcbi8vICAgICAgIGZyb20gPSBmb3JtYXREYXRlKHN0YXJ0KTtcclxuLy8gICAgICAgdG8gPSBmb3JtYXREYXRlKGVuZCk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG5cclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcblxyXG4vLyAgICAgICBmcm9tID0gZm9ybWF0RGF0ZShzdGFydCk7XHJcbi8vICAgICAgIHRvID0gZm9ybWF0RGF0ZShlbmQpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcblxyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG5cclxuLy8gICAgICAgZnJvbSA9IGZvcm1hdERhdGUoc3RhcnQpO1xyXG4vLyAgICAgICB0byA9IGZvcm1hdERhdGUoZW5kKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuLy8gICAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKHRydWUpO1xyXG5cclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZnJvbSk7XHJcbi8vICAgICBzZXRTZWxlY3RlZFRvRGF0ZSh0byk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGhhbmRsZVNlbGVjdEZpbHRlcihmb3JtRGF0YS5maWx0ZXJUeXBlKTtcclxuLy8gICB9LCBbZm9ybURhdGEuZmlsdGVyVHlwZV0pO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuXHJcbi8vICAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSB8fCBbXSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcIlVuYWJsZSB0byBmZXRjaCBjdXN0b21lcnNcIiwgZXJyb3IpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG5cclxuLy8gICAgIGZldGNoVXNlcnMoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZW1wbG95ZWVcIik7XHJcblxyXG4vLyAgICAgICAgIHNldEVtcGxveWVlcyhyZXNwb25zZS5kYXRhPy5lbXBsb3llZSB8fCByZXNwb25zZS5kYXRhIHx8IFtdKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5hYmxlIHRvIGZldGNoIGVtcGxveWVlc1wiLCBlcnJvcik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcblxyXG4vLyAgICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoQ3VzdG9tZXJUcmFja2luZ1JlcG9ydCA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4vLyAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XHJcblxyXG4vLyAgICAgICBpZiAoZm9ybURhdGEudXNlcikge1xyXG4vLyAgICAgICAgIHBhcmFtcy5hcHBlbmQoXCJ1c2VySWRcIiwgZm9ybURhdGEudXNlcik7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIGlmIChmb3JtRGF0YS5lbXBsb3llZSkge1xyXG4vLyAgICAgICAgIHBhcmFtcy5hcHBlbmQoXCJlbXBJZFwiLCBmb3JtRGF0YS5lbXBsb3llZSk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIGlmIChzZWxlY3RlZEZyb21EYXRlICYmIHNlbGVjdGVkVG9EYXRlKSB7XHJcbi8vICAgICAgICAgcGFyYW1zLmFwcGVuZChcImZyb21EYXRlXCIsIHNlbGVjdGVkRnJvbURhdGUpO1xyXG5cclxuLy8gICAgICAgICBwYXJhbXMuYXBwZW5kKFwidG9EYXRlXCIsIHNlbGVjdGVkVG9EYXRlKTtcclxuLy8gICAgICAgfVxyXG5cclxuLy8gICAgICAgY29uc3QgcXVlcnlTdHJpbmcgPSBwYXJhbXMudG9TdHJpbmcoKTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHVybCA9XHJcbi8vICAgICAgICAgcXVlcnlTdHJpbmcubGVuZ3RoID4gMFxyXG4vLyAgICAgICAgICAgPyBgL3YxL2FkbWluL2NvbGxlY3Rpb24tdHJhY2tpbmcvdHJhY2tpbmc/JHtxdWVyeVN0cmluZ31gXHJcbi8vICAgICAgICAgICA6IGAvdjEvYWRtaW4vY29sbGVjdGlvbi10cmFja2luZy90cmFja2luZ2A7XHJcblxyXG4vLyAgICAgICBjb25zb2xlLmxvZyhcIlRyYWNraW5nIFJlcG9ydCBBUEk6XCIsIHVybCk7XHJcblxyXG4vLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQodXJsKTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4vLyAgICAgICBjb25zdCB1bmlxdWVDdXN0b21lcnMgPSBuZXcgU2V0KFxyXG4vLyAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmRhdGE/Lm1hcCgoaXRlbSkgPT4gaXRlbS51c2VyX2lkPy5faWQpLmZpbHRlcihCb29sZWFuKSxcclxuLy8gICAgICAgKTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHVuaXF1ZUVtcGxveWVlcyA9IG5ldyBTZXQoXHJcbi8vICAgICAgICAgcmVzcG9uc2UuZGF0YT8uZGF0YT8ubWFwKChpdGVtKSA9PiBpdGVtLmNvbGxlY3RlZF9ieT8uX2lkKS5maWx0ZXIoQm9vbGVhbiksXHJcbi8vICAgICAgICk7XHJcblxyXG4vLyAgICAgICBzZXRTdW1tYXJ5KHtcclxuLy8gICAgICAgICB0b3RhbFRyYWNraW5nOiByZXNwb25zZS5kYXRhPy5kYXRhPy5sZW5ndGgsXHJcbi8vICAgICAgICAgdG90YWxDdXN0b21lcnM6IHVuaXF1ZUN1c3RvbWVycy5zaXplLFxyXG4vLyAgICAgICAgIHRvdGFsRW1wbG95ZWVzOiB1bmlxdWVFbXBsb3llZXMuc2l6ZSxcclxuXHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgY29uc3QgZm9ybWF0dGVkID1cclxuLy8gICAgICAgICByZXNwb25zZT8uZGF0YT8uZGF0YT8ubWFwKCh0cmFja2luZywgaW5kZXgpID0+ICh7XHJcbi8vICAgICAgICAgICBpZDogdHJhY2tpbmcuX2lkLFxyXG5cclxuLy8gICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIGN1c3RvbWVyOiB0cmFja2luZy51c2VyX2lkXHJcbi8vICAgICAgICAgICAgID8gYCR7dHJhY2tpbmcudXNlcl9pZC5mdWxsX25hbWUgfHwgXCItXCJ9IHwgJHtcclxuLy8gICAgICAgICAgICAgICAgIHRyYWNraW5nLnVzZXJfaWQucGhvbmVfbnVtYmVyIHx8IFwiLVwiXHJcbi8vICAgICAgICAgICAgICAgfWBcclxuLy8gICAgICAgICAgICAgOiBcIi1cIixcclxuXHJcbi8vICAgICAgICAgICBlbXBsb3llZTogdHJhY2tpbmcuY29sbGVjdGVkX2J5XHJcbi8vICAgICAgICAgICAgID8gYCR7dHJhY2tpbmcuY29sbGVjdGVkX2J5Lm5hbWUgfHwgXCItXCJ9IHwgJHtcclxuLy8gICAgICAgICAgICAgICAgIHRyYWNraW5nLmNvbGxlY3RlZF9ieS5waG9uZV9udW1iZXIgfHwgXCItXCJcclxuLy8gICAgICAgICAgICAgICB9YFxyXG4vLyAgICAgICAgICAgICA6IFwiLVwiLFxyXG5cclxuLy8gICAgICAgICAgIGNvbGxlY3Rpb25EYXRlOiB0cmFja2luZy5jb2xsZWN0aW9uX2RhdGVcclxuLy8gICAgICAgICAgICAgPyBuZXcgRGF0ZSh0cmFja2luZy5jb2xsZWN0aW9uX2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygpXHJcbi8vICAgICAgICAgICAgIDogXCItXCIsXHJcblxyXG4vLyAgICAgICAgICAgcmVhc29uOiB0cmFja2luZy5yZWFzb24gfHwgXCItXCIsXHJcblxyXG4vLyAgICAgICAgICAgcmVtYXJrOiB0cmFja2luZy5yZW1hcmsgfHwgdHJhY2tpbmcucmVtYXJrcyB8fCBcIi1cIixcclxuLy8gICAgICAgICB9KSkgfHwgW107XHJcblxyXG4vLyAgICAgICBzZXRDdXN0b21lclRyYWNraW5nRGF0YShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIlVuYWJsZSB0byBmZXRjaCBjdXN0b21lciB0cmFja2luZyByZXBvcnRcIiwgZXJyb3IpO1xyXG5cclxuLy8gICAgICAgc2V0Q3VzdG9tZXJUcmFja2luZ0RhdGEoW10pO1xyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLypcclxuLy8gICAgKiBUcmlnZ2VyIEFQSSB3aGVuIGZpbHRlcnMgY2hhbmdlXHJcbi8vICAgICovXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGlmIChzZWxlY3RlZEZyb21EYXRlICYmIHNlbGVjdGVkVG9EYXRlKSB7XHJcbi8vICAgICAgIGZldGNoQ3VzdG9tZXJUcmFja2luZ1JlcG9ydCgpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtzZWxlY3RlZEZyb21EYXRlLCBzZWxlY3RlZFRvRGF0ZSwgZm9ybURhdGEudXNlciwgZm9ybURhdGEuZW1wbG95ZWVdKTtcclxuXHJcbi8vICAgLypcclxuLy8gICAgKiBEZWZhdWx0IGZpbHRlclxyXG4vLyAgICAqL1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoXCJUb2RheVwiKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8qXHJcbi8vICAgICogVGFibGUgY29sdW1uc1xyXG4vLyAgICAqL1xyXG4vLyAgIGNvbnN0IGNvbHVtbiA9IFtcclxuLy8gICAgIHtcclxuLy8gICAgICAga2V5OiBcInNsTm9cIixcclxuLy8gICAgICAgaGVhZGVyOiBcIlNsIE5vXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwiY3VzdG9tZXJcIixcclxuLy8gICAgICAgaGVhZGVyOiBcIkN1c3RvbWVyXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwiZW1wbG95ZWVcIixcclxuLy8gICAgICAgaGVhZGVyOiBcIkNvbGxlY3RlZCBCeVwiLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAga2V5OiBcImNvbGxlY3Rpb25EYXRlXCIsXHJcbi8vICAgICAgIGhlYWRlcjogXCJDb2xsZWN0ZWQgT25cIixcclxuLy8gICAgIH0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGtleTogXCJyZWFzb25cIixcclxuLy8gICAgICAgaGVhZGVyOiBcIlJlYXNvblwiLFxyXG4vLyAgICAgfSxcclxuXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGtleTogXCJyZW1hcmtcIixcclxuLy8gICAgICAgaGVhZGVyOiBcIlJlbWFya1wiLFxyXG4vLyAgICAgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTEwXCI+XHJcbi8vICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuXHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4vLyAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTZcIj5cclxuLy8gICAgICAgICAgIEN1c3RvbWVyIFBheW1lbnQgVHJhY2tpbmcgUmVwb3J0XHJcbi8vICAgICAgICAgPC9oMj5cclxuXHJcbi8vICAgICAgICAgey8qID09PT09PT09PT09PT09PT09IEZJTFRFUlMgPT09PT09PT09PT09PT09PT0gKi99XHJcblxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvNFwiPlxyXG4vLyAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSB0ZXh0LXNtXCI+RGF0ZSBGaWx0ZXI8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZmlsdGVyVHlwZX1cclxuLy8gICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiZmlsdGVyVHlwZVwiLCB2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICB7ZGF0ZUZpbHRlck9wdGlvbnMubWFwKChvcHRpb24pID0+IChcclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17b3B0aW9uLnZhbHVlfSB2YWx1ZT17b3B0aW9uLnZhbHVlfT5cclxuLy8gICAgICAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIHtzaG93RmlsdGVyRmllbGQgJiYgKFxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgaXRlbXMtZW5kXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtXCI+RnJvbTwvbGFiZWw+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkIGgtMTJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRGcm9tRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbVwiPlRvPC9sYWJlbD5cclxuXHJcbi8vICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWQgaC0xMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFRvRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZFRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS80XCI+XHJcbi8vICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5TZWxlY3QgRW1wbG95ZWU8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuLy8gICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBFbXBsb3llZXNcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbXBsb3llZSB8fCB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcImVtcGxveWVlXCIsIHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbi8vICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBFbXBsb3llZXM8L1NlbGVjdC5PcHRpb24+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXBsb3llZSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXBsb3llZS5faWR9IHZhbHVlPXtlbXBsb3llZS5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWUubmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAge2VtcGxveWVlLnBob25lX251bWJlciA/IGAgLSAke2VtcGxveWVlLnBob25lX251bWJlcn1gIDogXCJcIn1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS80XCI+XHJcbi8vICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5TZWxlY3QgQ3VzdG9tZXI8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuLy8gICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBDdXN0b21lcnNcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS51c2VyIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwidXNlclwiLCB2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4vLyAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgQ3VzdG9tZXJzPC9TZWxlY3QuT3B0aW9uPlxyXG5cclxuLy8gICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbi8vICAgICAgICAgICAgICAgICAgIHt1c2VyLnBob25lX251bWJlciA/IGAgLSAke3VzZXIucGhvbmVfbnVtYmVyfWAgOiBcIlwifVxyXG4vLyAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBPVkVSVklFVyA9PT09PT09PT09PT09PT09PSAqL31cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cclxuLy8gICAgICAgICAgIHsvKiBUb3RhbCBUcmFja2luZyAqL31cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtMTAwIHAtNCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5Ub3RhbCBUcmFja2luZzwvcD5cclxuXHJcbi8vICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICB7c3VtbWFyeS50b3RhbFRyYWNraW5nfVxyXG4vLyAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIFRvdGFsIEN1c3RvbWVycyAqL31cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCBwLTQgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+VG90YWwgQ3VzdG9tZXJzPC9wPlxyXG5cclxuLy8gICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgIHtzdW1tYXJ5LnRvdGFsQ3VzdG9tZXJzfVxyXG4vLyAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIFRvdGFsIEVtcGxveWVlcyAqL31cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXllbGxvdy0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlRvdGFsIEVtcGxveWVlczwvcD5cclxuXHJcbi8vICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICB7c3VtbWFyeS50b3RhbEVtcGxveWVlc31cclxuLy8gICAgICAgICAgICAgPC9oMj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gVEFCTEUgPT09PT09PT09PT09PT09PT0gKi99XHJcblxyXG4vLyAgICAgICAgIHtjdXN0b21lclRyYWNraW5nRGF0YS5sZW5ndGggPiAwICYmICFsb2FkaW5nID8gKFxyXG4vLyAgICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW59XHJcbi8vICAgICAgICAgICAgIGRhdGE9e2N1c3RvbWVyVHJhY2tpbmdEYXRhfVxyXG4vLyAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ3VzdG9tZXIgUGF5bWVudCBUcmFja2luZyBSZXBvcnRcIlxyXG4vLyAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDdXN0b21lciBQYXltZW50IFRyYWNraW5nIFJlcG9ydFwiXHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuLy8gICAgICAgICAgICAgaXNMb2FkaW5nPXtsb2FkaW5nfVxyXG4vLyAgICAgICAgICAgICBmYWlsdXJlPXtsb2FkaW5nIDw9IDB9XHJcbi8vICAgICAgICAgICAgIGRhdGE9XCJDdXN0b21lciBQeWFtZW50IFRyYWNraW5nIFJlcG9ydFwiXHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbi8vIGNvbnN0IEN1c3RvbWVyVHJhY2tpbmdSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW2N1c3RvbWVyVHJhY2tpbmdEYXRhLCBzZXRDdXN0b21lclRyYWNraW5nRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4vLyAgIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4vLyAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkVG9EYXRlLCBzZXRTZWxlY3RlZFRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbi8vICAgY29uc3QgW3Nob3dGaWx0ZXJGaWVsZCwgc2V0U2hvd0ZpbHRlckZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB1c2VyOiBcIlwiLFxyXG4vLyAgICAgZW1wbG95ZWU6IFwiXCIsXHJcbi8vICAgICBmaWx0ZXJUeXBlOiBcIlRvZGF5XCIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHRvdGFsVHJhY2tpbmc6IDAsXHJcbi8vICAgICB0b3RhbEN1c3RvbWVyczogMCxcclxuLy8gICAgIHRvdGFsRW1wbG95ZWVzOiAwLFxyXG4vLyAgICAgdG90YWxDaGl0czogMCxcclxuLy8gICAgIHRvdGFsTG9hbnM6IDAsXHJcbi8vICAgICB0b3RhbFBheWFibGU6IDAsXHJcbi8vICAgICB0b3RhbEludmVzdG1lbnQ6IDAsXHJcbi8vICAgICB0b3RhbFBlbmFsdHk6IDAsXHJcbi8vICAgICB0b3RhbExhdGVGZWU6IDAsXHJcbi8vICAgICB0b3RhbENoaXRCYWxhbmNlOiAwLFxyXG4vLyAgICAgdG90YWxMb2FuUGFpZDogMCxcclxuLy8gICAgIHRvdGFsTG9hbkJhbGFuY2U6IDAsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbi8vICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgLi4ucHJldixcclxuLy8gICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbi8vICAgICB9KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgZGF0ZUZpbHRlck9wdGlvbnMgPSBbXHJcbi8vICAgICB7XHJcbi8vICAgICAgIHZhbHVlOiBcIlRvZGF5XCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIlRvZGF5XCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICB2YWx1ZTogXCJZZXN0ZXJkYXlcIixcclxuLy8gICAgICAgbGFiZWw6IFwiWWVzdGVyZGF5XCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICB2YWx1ZTogXCJUaGlzTW9udGhcIixcclxuLy8gICAgICAgbGFiZWw6IFwiVGhpcyBNb250aFwiLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAgdmFsdWU6IFwiTGFzdE1vbnRoXCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIkxhc3QgTW9udGhcIixcclxuLy8gICAgIH0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIHZhbHVlOiBcIlRoaXNZZWFyXCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIlRoaXMgWWVhclwiLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAgdmFsdWU6IFwiQ3VzdG9tXCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIkN1c3RvbVwiLFxyXG4vLyAgICAgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IHtcclxuLy8gICAgIHJldHVybiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGZvcm1hdERpc3BsYXlEYXRlID0gKGRhdGUpID0+IHtcclxuLy8gICAgIGlmICghZGF0ZSkgcmV0dXJuIFwiLVwiO1xyXG5cclxuLy8gICAgIGNvbnN0IHBhcnNlZERhdGUgPSBuZXcgRGF0ZShkYXRlKTtcclxuXHJcbi8vICAgICBpZiAoaXNOYU4ocGFyc2VkRGF0ZS5nZXRUaW1lKCkpKSB7XHJcbi8vICAgICAgIHJldHVybiBcIi1cIjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICByZXR1cm4gcGFyc2VkRGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1JTlwiKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBmb3JtYXRBbW91bnQgPSAoYW1vdW50KSA9PiB7XHJcbi8vICAgICByZXR1cm4gYOKCuSR7TnVtYmVyKGFtb3VudCB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWA7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbi8vICAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuLy8gICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuXHJcbi8vICAgICBsZXQgZnJvbSA9IFwiXCI7XHJcbi8vICAgICBsZXQgdG8gPSBcIlwiO1xyXG5cclxuLy8gICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbi8vICAgICAgIGZyb20gPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgICAgdG8gPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG5cclxuLy8gICAgICAgeWVzdGVyZGF5LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcblxyXG4vLyAgICAgICBmcm9tID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4vLyAgICAgICB0byA9IGZvcm1hdERhdGUoeWVzdGVyZGF5KTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZShcclxuLy8gICAgICAgICB0b2RheS5nZXRGdWxsWWVhcigpLFxyXG4vLyAgICAgICAgIHRvZGF5LmdldE1vbnRoKCksXHJcbi8vICAgICAgICAgMVxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUoXHJcbi8vICAgICAgICAgdG9kYXkuZ2V0RnVsbFllYXIoKSxcclxuLy8gICAgICAgICB0b2RheS5nZXRNb250aCgpICsgMSxcclxuLy8gICAgICAgICAwXHJcbi8vICAgICAgICk7XHJcblxyXG4vLyAgICAgICBmcm9tID0gZm9ybWF0RGF0ZShzdGFydCk7XHJcbi8vICAgICAgIHRvID0gZm9ybWF0RGF0ZShlbmQpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKFxyXG4vLyAgICAgICAgIHRvZGF5LmdldEZ1bGxZZWFyKCksXHJcbi8vICAgICAgICAgdG9kYXkuZ2V0TW9udGgoKSAtIDEsXHJcbi8vICAgICAgICAgMVxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUoXHJcbi8vICAgICAgICAgdG9kYXkuZ2V0RnVsbFllYXIoKSxcclxuLy8gICAgICAgICB0b2RheS5nZXRNb250aCgpLFxyXG4vLyAgICAgICAgIDBcclxuLy8gICAgICAgKTtcclxuXHJcbi8vICAgICAgIGZyb20gPSBmb3JtYXREYXRlKHN0YXJ0KTtcclxuLy8gICAgICAgdG8gPSBmb3JtYXREYXRlKGVuZCk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZShcclxuLy8gICAgICAgICB0b2RheS5nZXRGdWxsWWVhcigpLFxyXG4vLyAgICAgICAgIDAsXHJcbi8vICAgICAgICAgMVxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUoXHJcbi8vICAgICAgICAgdG9kYXkuZ2V0RnVsbFllYXIoKSxcclxuLy8gICAgICAgICAxMSxcclxuLy8gICAgICAgICAzMVxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgZnJvbSA9IGZvcm1hdERhdGUoc3RhcnQpO1xyXG4vLyAgICAgICB0byA9IGZvcm1hdERhdGUoZW5kKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuLy8gICAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKHRydWUpO1xyXG4vLyAgICAgICByZXR1cm47XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmcm9tKTtcclxuLy8gICAgIHNldFNlbGVjdGVkVG9EYXRlKHRvKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgaGFuZGxlU2VsZWN0RmlsdGVyKGZvcm1EYXRhLmZpbHRlclR5cGUpO1xyXG4vLyAgIH0sIFtmb3JtRGF0YS5maWx0ZXJUeXBlXSk7XHJcblxyXG4vLyAgIC8qXHJcbi8vICAgICogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyAgICAqIEZFVENIIFVTRVJTXHJcbi8vICAgICogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyAgICAqL1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuXHJcbi8vICAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSB8fCBbXSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcclxuLy8gICAgICAgICAgIFwiVW5hYmxlIHRvIGZldGNoIGN1c3RvbWVyc1wiLFxyXG4vLyAgICAgICAgICAgZXJyb3JcclxuLy8gICAgICAgICApO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG5cclxuLy8gICAgIGZldGNoVXNlcnMoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8qXHJcbi8vICAgICogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyAgICAqIEZFVENIIEVNUExPWUVFU1xyXG4vLyAgICAqID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gICAgKi9cclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoRW1wbG95ZWVzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZVwiKTtcclxuXHJcbi8vICAgICAgICAgc2V0RW1wbG95ZWVzKFxyXG4vLyAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHxcclxuLy8gICAgICAgICAgICAgcmVzcG9uc2UuZGF0YSB8fFxyXG4vLyAgICAgICAgICAgICBbXVxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcclxuLy8gICAgICAgICAgIFwiVW5hYmxlIHRvIGZldGNoIGVtcGxveWVlc1wiLFxyXG4vLyAgICAgICAgICAgZXJyb3JcclxuLy8gICAgICAgICApO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG5cclxuLy8gICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICAvKlxyXG4vLyAgICAqID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gICAgKiBGRVRDSCBDVVNUT01FUiBUUkFDS0lORyBSRVBPUlRcclxuLy8gICAgKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vICAgICovXHJcblxyXG4vLyAgIGNvbnN0IGZldGNoQ3VzdG9tZXJUcmFja2luZ1JlcG9ydCA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4vLyAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XHJcblxyXG4vLyAgICAgICBpZiAoZm9ybURhdGEudXNlcikge1xyXG4vLyAgICAgICAgIHBhcmFtcy5hcHBlbmQoXHJcbi8vICAgICAgICAgICBcInVzZXJJZFwiLFxyXG4vLyAgICAgICAgICAgZm9ybURhdGEudXNlclxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIGlmIChmb3JtRGF0YS5lbXBsb3llZSkge1xyXG4vLyAgICAgICAgIHBhcmFtcy5hcHBlbmQoXHJcbi8vICAgICAgICAgICBcImVtcElkXCIsXHJcbi8vICAgICAgICAgICBmb3JtRGF0YS5lbXBsb3llZVxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIGlmIChcclxuLy8gICAgICAgICBzZWxlY3RlZEZyb21EYXRlICYmXHJcbi8vICAgICAgICAgc2VsZWN0ZWRUb0RhdGVcclxuLy8gICAgICAgKSB7XHJcbi8vICAgICAgICAgcGFyYW1zLmFwcGVuZChcclxuLy8gICAgICAgICAgIFwiZnJvbURhdGVcIixcclxuLy8gICAgICAgICAgIHNlbGVjdGVkRnJvbURhdGVcclxuLy8gICAgICAgICApO1xyXG5cclxuLy8gICAgICAgICBwYXJhbXMuYXBwZW5kKFxyXG4vLyAgICAgICAgICAgXCJ0b0RhdGVcIixcclxuLy8gICAgICAgICAgIHNlbGVjdGVkVG9EYXRlXHJcbi8vICAgICAgICAgKTtcclxuLy8gICAgICAgfVxyXG5cclxuLy8gICAgICAgY29uc3QgcXVlcnlTdHJpbmcgPSBwYXJhbXMudG9TdHJpbmcoKTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHVybCA9XHJcbi8vICAgICAgICAgcXVlcnlTdHJpbmcubGVuZ3RoID4gMFxyXG4vLyAgICAgICAgICAgPyBgL3YxL2FkbWluL2NvbGxlY3Rpb24tdHJhY2tpbmcvdHJhY2tpbmc/JHtxdWVyeVN0cmluZ31gXHJcbi8vICAgICAgICAgICA6IGAvdjEvYWRtaW4vY29sbGVjdGlvbi10cmFja2luZy90cmFja2luZ2A7XHJcblxyXG4vLyAgICAgICBjb25zb2xlLmxvZyhcclxuLy8gICAgICAgICBcIlRyYWNraW5nIFJlcG9ydCBBUEk6XCIsXHJcbi8vICAgICAgICAgdXJsXHJcbi8vICAgICAgICk7XHJcblxyXG4vLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQodXJsKTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9XHJcbi8vICAgICAgICAgcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCBbXTtcclxuXHJcbi8vICAgICAgIGNvbnNvbGUubG9nKFxyXG4vLyAgICAgICAgIFwiVHJhY2tpbmcgUmVwb3J0IFJlc3BvbnNlOlwiLFxyXG4vLyAgICAgICAgIHJlc3BvbnNlRGF0YVxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgLypcclxuLy8gICAgICAgICogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vICAgICAgICAqIFNVTU1BUllcclxuLy8gICAgICAgICogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vICAgICAgICAqL1xyXG5cclxuLy8gICAgICAgY29uc3QgdW5pcXVlQ3VzdG9tZXJzID0gbmV3IFNldChcclxuLy8gICAgICAgICByZXNwb25zZURhdGFcclxuLy8gICAgICAgICAgIC5tYXAoXHJcbi8vICAgICAgICAgICAgIChpdGVtKSA9PlxyXG4vLyAgICAgICAgICAgICAgIGl0ZW0udHJhY2tpbmc/LnVzZXJfaWQ/Ll9pZFxyXG4vLyAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKVxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgY29uc3QgdW5pcXVlRW1wbG95ZWVzID0gbmV3IFNldChcclxuLy8gICAgICAgICByZXNwb25zZURhdGFcclxuLy8gICAgICAgICAgIC5tYXAoXHJcbi8vICAgICAgICAgICAgIChpdGVtKSA9PlxyXG4vLyAgICAgICAgICAgICAgIGl0ZW0udHJhY2tpbmc/LmNvbGxlY3RlZF9ieT8uX2lkXHJcbi8vICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXHJcbi8vICAgICAgICk7XHJcblxyXG4vLyAgICAgICAvKlxyXG4vLyAgICAgICAgKiBUb3RhbCBDaGl0c1xyXG4vLyAgICAgICAgKi9cclxuXHJcbi8vICAgICAgIGNvbnN0IHRvdGFsQ2hpdHMgPVxyXG4vLyAgICAgICAgIHJlc3BvbnNlRGF0YS5yZWR1Y2UoXHJcbi8vICAgICAgICAgICAodG90YWwsIGl0ZW0pID0+XHJcbi8vICAgICAgICAgICAgIHRvdGFsICtcclxuLy8gICAgICAgICAgICAgKGl0ZW0uY3VzdG9tZXJfb3ZlcnZpZXdcclxuLy8gICAgICAgICAgICAgICA/Lmxlbmd0aCB8fCAwKSxcclxuLy8gICAgICAgICAgIDBcclxuLy8gICAgICAgICApO1xyXG5cclxuLy8gICAgICAgLypcclxuLy8gICAgICAgICogVG90YWwgTG9hbnNcclxuLy8gICAgICAgICovXHJcblxyXG4vLyAgICAgICBjb25zdCB0b3RhbExvYW5zID1cclxuLy8gICAgICAgICByZXNwb25zZURhdGEucmVkdWNlKFxyXG4vLyAgICAgICAgICAgKHRvdGFsLCBpdGVtKSA9PlxyXG4vLyAgICAgICAgICAgICB0b3RhbCArXHJcbi8vICAgICAgICAgICAgIChpdGVtLmxvYW5fZGV0YWlsc1xyXG4vLyAgICAgICAgICAgICAgID8ubGVuZ3RoIHx8IDApLFxyXG4vLyAgICAgICAgICAgMFxyXG4vLyAgICAgICAgICk7XHJcblxyXG4vLyAgICAgICAvKlxyXG4vLyAgICAgICAgKiBDaGl0IEZpbmFuY2lhbCBTdW1tYXJ5XHJcbi8vICAgICAgICAqL1xyXG5cclxuLy8gICAgICAgY29uc3QgY2hpdFN1bW1hcnkgPVxyXG4vLyAgICAgICAgIHJlc3BvbnNlRGF0YS5yZWR1Y2UoXHJcbi8vICAgICAgICAgICAoYWNjLCBpdGVtKSA9PiB7XHJcbi8vICAgICAgICAgICAgIChpdGVtLmN1c3RvbWVyX292ZXJ2aWV3IHx8IFtdKS5mb3JFYWNoKFxyXG4vLyAgICAgICAgICAgICAgIChjaGl0KSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICBhY2MudG90YWxQYXlhYmxlICs9IE51bWJlcihcclxuLy8gICAgICAgICAgICAgICAgICAgY2hpdC50b3RhbF9wYXlhYmxlIHx8IDBcclxuLy8gICAgICAgICAgICAgICAgICk7XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgYWNjLnRvdGFsSW52ZXN0bWVudCArPSBOdW1iZXIoXHJcbi8vICAgICAgICAgICAgICAgICAgIGNoaXQudG90YWxfaW52ZXN0bWVudCB8fCAwXHJcbi8vICAgICAgICAgICAgICAgICApO1xyXG5cclxuLy8gICAgICAgICAgICAgICAgIGFjYy50b3RhbFBlbmFsdHkgKz0gTnVtYmVyKFxyXG4vLyAgICAgICAgICAgICAgICAgICBjaGl0LnRvdGFsX3BlbmFsdHkgfHwgMFxyXG4vLyAgICAgICAgICAgICAgICAgKTtcclxuXHJcbi8vICAgICAgICAgICAgICAgICBhY2MudG90YWxMYXRlRmVlICs9IE51bWJlcihcclxuLy8gICAgICAgICAgICAgICAgICAgY2hpdC50b3RhbF9sYXRlX2ZlZSB8fCAwXHJcbi8vICAgICAgICAgICAgICAgICApO1xyXG5cclxuLy8gICAgICAgICAgICAgICAgIGFjYy50b3RhbEJhbGFuY2UgKz0gTnVtYmVyKFxyXG4vLyAgICAgICAgICAgICAgICAgICBjaGl0LnRvdGFsX2JhbGFuY2UgfHwgMFxyXG4vLyAgICAgICAgICAgICAgICAgKTtcclxuLy8gICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICk7XHJcblxyXG4vLyAgICAgICAgICAgICByZXR1cm4gYWNjO1xyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgdG90YWxQYXlhYmxlOiAwLFxyXG4vLyAgICAgICAgICAgICB0b3RhbEludmVzdG1lbnQ6IDAsXHJcbi8vICAgICAgICAgICAgIHRvdGFsUGVuYWx0eTogMCxcclxuLy8gICAgICAgICAgICAgdG90YWxMYXRlRmVlOiAwLFxyXG4vLyAgICAgICAgICAgICB0b3RhbEJhbGFuY2U6IDAsXHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgKTtcclxuXHJcbi8vICAgICAgIC8qXHJcbi8vICAgICAgICAqIExvYW4gRmluYW5jaWFsIFN1bW1hcnlcclxuLy8gICAgICAgICovXHJcblxyXG4vLyAgICAgICBjb25zdCBsb2FuU3VtbWFyeSA9XHJcbi8vICAgICAgICAgcmVzcG9uc2VEYXRhLnJlZHVjZShcclxuLy8gICAgICAgICAgIChhY2MsIGl0ZW0pID0+IHtcclxuLy8gICAgICAgICAgICAgKGl0ZW0ubG9hbl9kZXRhaWxzIHx8IFtdKS5mb3JFYWNoKFxyXG4vLyAgICAgICAgICAgICAgIChsb2FuKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICBhY2MudG90YWxQYWlkICs9IE51bWJlcihcclxuLy8gICAgICAgICAgICAgICAgICAgbG9hbi50b3RhbF9wYWlkX2Ftb3VudCB8fCAwXHJcbi8vICAgICAgICAgICAgICAgICApO1xyXG5cclxuLy8gICAgICAgICAgICAgICAgIGFjYy50b3RhbEJhbGFuY2UgKz0gTnVtYmVyKFxyXG4vLyAgICAgICAgICAgICAgICAgICBsb2FuLmJhbGFuY2UgfHwgMFxyXG4vLyAgICAgICAgICAgICAgICAgKTtcclxuLy8gICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICk7XHJcblxyXG4vLyAgICAgICAgICAgICByZXR1cm4gYWNjO1xyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgdG90YWxQYWlkOiAwLFxyXG4vLyAgICAgICAgICAgICB0b3RhbEJhbGFuY2U6IDAsXHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgKTtcclxuXHJcbi8vICAgICAgIHNldFN1bW1hcnkoe1xyXG4vLyAgICAgICAgIHRvdGFsVHJhY2tpbmc6IHJlc3BvbnNlRGF0YS5sZW5ndGgsXHJcblxyXG4vLyAgICAgICAgIHRvdGFsQ3VzdG9tZXJzOlxyXG4vLyAgICAgICAgICAgdW5pcXVlQ3VzdG9tZXJzLnNpemUsXHJcblxyXG4vLyAgICAgICAgIHRvdGFsRW1wbG95ZWVzOlxyXG4vLyAgICAgICAgICAgdW5pcXVlRW1wbG95ZWVzLnNpemUsXHJcblxyXG4vLyAgICAgICAgIHRvdGFsQ2hpdHMsXHJcblxyXG4vLyAgICAgICAgIHRvdGFsTG9hbnMsXHJcblxyXG4vLyAgICAgICAgIHRvdGFsUGF5YWJsZTpcclxuLy8gICAgICAgICAgIGNoaXRTdW1tYXJ5LnRvdGFsUGF5YWJsZSxcclxuXHJcbi8vICAgICAgICAgdG90YWxJbnZlc3RtZW50OlxyXG4vLyAgICAgICAgICAgY2hpdFN1bW1hcnkudG90YWxJbnZlc3RtZW50LFxyXG5cclxuLy8gICAgICAgICB0b3RhbFBlbmFsdHk6XHJcbi8vICAgICAgICAgICBjaGl0U3VtbWFyeS50b3RhbFBlbmFsdHksXHJcblxyXG4vLyAgICAgICAgIHRvdGFsTGF0ZUZlZTpcclxuLy8gICAgICAgICAgIGNoaXRTdW1tYXJ5LnRvdGFsTGF0ZUZlZSxcclxuXHJcbi8vICAgICAgICAgdG90YWxDaGl0QmFsYW5jZTpcclxuLy8gICAgICAgICAgIGNoaXRTdW1tYXJ5LnRvdGFsQmFsYW5jZSxcclxuXHJcbi8vICAgICAgICAgdG90YWxMb2FuUGFpZDpcclxuLy8gICAgICAgICAgIGxvYW5TdW1tYXJ5LnRvdGFsUGFpZCxcclxuXHJcbi8vICAgICAgICAgdG90YWxMb2FuQmFsYW5jZTpcclxuLy8gICAgICAgICAgIGxvYW5TdW1tYXJ5LnRvdGFsQmFsYW5jZSxcclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICAvKlxyXG4vLyAgICAgICAgKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gICAgICAgICogRk9STUFUIFRBQkxFIERBVEFcclxuLy8gICAgICAgICogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vICAgICAgICAqL1xyXG5cclxuLy8gICAgICAgY29uc3QgZm9ybWF0dGVkID1cclxuLy8gICByZXNwb25zZT8uZGF0YT8uZGF0YT8ubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgY29uc3QgdHJhY2tpbmcgPSBpdGVtLnRyYWNraW5nIHx8IHt9O1xyXG4vLyAgICAgY29uc3QgY3VzdG9tZXJPdmVydmlldyA9IGl0ZW0uY3VzdG9tZXJfb3ZlcnZpZXcgfHwgW107XHJcbi8vICAgICBjb25zdCBsb2FuRGV0YWlscyA9IGl0ZW0ubG9hbl9kZXRhaWxzIHx8IFtdO1xyXG5cclxuLy8gICAgIC8vIENoaXQgZGV0YWlsc1xyXG4vLyAgICAgY29uc3QgY2hpdCA9IGN1c3RvbWVyT3ZlcnZpZXdbMF0gfHwge307XHJcblxyXG4vLyAgICAgLy8gTG9hbiBkZXRhaWxzXHJcbi8vICAgICBjb25zdCBsb2FuID0gbG9hbkRldGFpbHNbMF0gfHwge307XHJcblxyXG4vLyAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgaWQ6IHRyYWNraW5nLl9pZCxcclxuXHJcbi8vICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuXHJcbi8vICAgICAgIC8vID09PT09PT09PT09PT09PT09IENVU1RPTUVSID09PT09PT09PT09PT09PT09XHJcbi8vICAgICAgIGN1c3RvbWVyOiB0cmFja2luZy51c2VyX2lkXHJcbi8vICAgICAgICAgPyBgJHt0cmFja2luZy51c2VyX2lkLmZ1bGxfbmFtZSB8fCBcIi1cIn0gfCAke1xyXG4vLyAgICAgICAgICAgICB0cmFja2luZy51c2VyX2lkLnBob25lX251bWJlciB8fCBcIi1cIlxyXG4vLyAgICAgICAgICAgfWBcclxuLy8gICAgICAgICA6IFwiLVwiLFxyXG5cclxuXHJcblxyXG4vLyAgICAgICBjdXN0b21lcklkOiB0cmFja2luZy51c2VyX2lkPy5jdXN0b21lcl9pZCB8fCBcIi1cIixcclxuXHJcbi8vICAgICAgIC8vID09PT09PT09PT09PT09PT09IEVNUExPWUVFID09PT09PT09PT09PT09PT09XHJcbi8vICAgICAgIGVtcGxveWVlOiB0cmFja2luZy5jb2xsZWN0ZWRfYnlcclxuLy8gICAgICAgICA/IGAke3RyYWNraW5nLmNvbGxlY3RlZF9ieS5uYW1lIHx8IFwiLVwifSB8ICR7XHJcbi8vICAgICAgICAgICAgIHRyYWNraW5nLmNvbGxlY3RlZF9ieS5waG9uZV9udW1iZXIgfHwgXCItXCJcclxuLy8gICAgICAgICAgIH1gXHJcbi8vICAgICAgICAgOiBcIi1cIixcclxuXHJcbi8vICAgICAgIGVtcGxveWVlQ29kZTogdHJhY2tpbmcuY29sbGVjdGVkX2J5Py5lbXBsb3llZUNvZGUgfHwgXCItXCIsXHJcblxyXG4vLyAgICAgICAvLyA9PT09PT09PT09PT09PT09PSBUUkFDS0lORyA9PT09PT09PT09PT09PT09PVxyXG4vLyAgICAgICBjb2xsZWN0aW9uRGF0ZTogdHJhY2tpbmcuY29sbGVjdGlvbl9kYXRlXHJcbi8vICAgICAgICAgPyBuZXcgRGF0ZSh0cmFja2luZy5jb2xsZWN0aW9uX2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygpXHJcbi8vICAgICAgICAgOiBcIi1cIixcclxuXHJcbi8vICAgICAgIHJlYXNvbjogdHJhY2tpbmcucmVhc29uIHx8IFwiLVwiLFxyXG5cclxuLy8gICAgICAgcmVtYXJrOiB0cmFja2luZy5yZW1hcmsgfHwgdHJhY2tpbmcucmVtYXJrcyB8fCBcIi1cIixcclxuXHJcblxyXG4vLyAgICAgICAgY29sbGVjdGlvbkFyZWE6IGNoaXQudXNlcl9pZD8uY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9uYW1lIHx8IFwiLVwiLFxyXG5cclxuLy8gZ3JvdXBOYW1lOiBjaGl0Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiLVwiLFxyXG5cclxuLy8gdGlja2V0OiBjaGl0LnRpY2tldHMgPz8gXCItXCIsXHJcbi8vICAgICAgIC8vID09PT09PT09PT09PT09PT09IENISVQgPT09PT09PT09PT09PT09PT1cclxuLy8gICAgICAgcGF5bWVudFR5cGU6IGNoaXQucGF5bWVudF90eXBlIHx8IFwiLVwiLFxyXG5cclxuLy8gICAgICAgY3VzdG9tZXJTdGF0dXM6IGNoaXQuY3VzdG9tZXJfc3RhdHVzIHx8IFwiLVwiLFxyXG5cclxuLy8gICAgICAgdG90YWxQYXlhYmxlOlxyXG4vLyAgICAgICAgIGNoaXQudG90YWxfcGF5YWJsZSAhPT0gdW5kZWZpbmVkXHJcbi8vICAgICAgICAgICA/IE51bWJlcihjaGl0LnRvdGFsX3BheWFibGUpLnRvTG9jYWxlU3RyaW5nKClcclxuLy8gICAgICAgICAgIDogXCItXCIsXHJcblxyXG4vLyAgICAgICB0b3RhbEludmVzdG1lbnQ6XHJcbi8vICAgICAgICAgY2hpdC50b3RhbF9pbnZlc3RtZW50ICE9PSB1bmRlZmluZWRcclxuLy8gICAgICAgICAgID8gTnVtYmVyKGNoaXQudG90YWxfaW52ZXN0bWVudCkudG9Mb2NhbGVTdHJpbmcoKVxyXG4vLyAgICAgICAgICAgOiBcIi1cIixcclxuXHJcbi8vICAgICAgIHRvdGFsUGVuYWx0eTpcclxuLy8gICAgICAgICBjaGl0LnRvdGFsX3BlbmFsdHkgIT09IHVuZGVmaW5lZFxyXG4vLyAgICAgICAgICAgPyBOdW1iZXIoY2hpdC50b3RhbF9wZW5hbHR5KS50b0xvY2FsZVN0cmluZygpXHJcbi8vICAgICAgICAgICA6IFwiLVwiLFxyXG5cclxuLy8gICAgICAgdG90YWxMYXRlRmVlOlxyXG4vLyAgICAgICAgIGNoaXQudG90YWxfbGF0ZV9mZWUgIT09IHVuZGVmaW5lZFxyXG4vLyAgICAgICAgICAgPyBOdW1iZXIoY2hpdC50b3RhbF9sYXRlX2ZlZSkudG9Mb2NhbGVTdHJpbmcoKVxyXG4vLyAgICAgICAgICAgOiBcIi1cIixcclxuXHJcbi8vICAgICAgIC8vID09PT09PT09PT09PT09PT09IExPQU4gPT09PT09PT09PT09PT09PT1cclxuLy8gICAgICAgbG9hbklkOiBsb2FuLmxvYW5faWQgfHwgXCItXCIsXHJcblxyXG4vLyAgICAgICBsb2FuQW1vdW50OlxyXG4vLyAgICAgICAgIGxvYW4ubG9hbl9hbW91bnQgIT09IHVuZGVmaW5lZFxyXG4vLyAgICAgICAgICAgPyBOdW1iZXIobG9hbi5sb2FuX2Ftb3VudCkudG9Mb2NhbGVTdHJpbmcoKVxyXG4vLyAgICAgICAgICAgOiBcIi1cIixcclxuXHJcbi8vICAgICAgIGxvYW5TdGFydERhdGU6IGxvYW4uc3RhcnRfZGF0ZVxyXG4vLyAgICAgICAgID8gbmV3IERhdGUobG9hbi5zdGFydF9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKVxyXG4vLyAgICAgICAgIDogXCItXCIsXHJcblxyXG4vLyAgICAgICBsb2FuRW5kRGF0ZTogbG9hbi5lbmRfZGF0ZVxyXG4vLyAgICAgICAgID8gbmV3IERhdGUobG9hbi5lbmRfZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKClcclxuLy8gICAgICAgICA6IFwiLVwiLFxyXG4vLyAgICAgfTtcclxuLy8gICB9KSB8fCBbXTtcclxuXHJcbi8vIHNldEN1c3RvbWVyVHJhY2tpbmdEYXRhKGZvcm1hdHRlZCk7XHJcblxyXG5cclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXHJcbi8vICAgICAgICAgXCJVbmFibGUgdG8gZmV0Y2ggY3VzdG9tZXIgdHJhY2tpbmcgcmVwb3J0XCIsXHJcbi8vICAgICAgICAgZXJyb3JcclxuLy8gICAgICAgKTtcclxuXHJcbi8vICAgICAgIHNldEN1c3RvbWVyVHJhY2tpbmdEYXRhKFtdKTtcclxuXHJcbi8vICAgICAgIHNldFN1bW1hcnkoe1xyXG4vLyAgICAgICAgIHRvdGFsVHJhY2tpbmc6IDAsXHJcbi8vICAgICAgICAgdG90YWxDdXN0b21lcnM6IDAsXHJcbi8vICAgICAgICAgdG90YWxFbXBsb3llZXM6IDAsXHJcbi8vICAgICAgICAgdG90YWxDaGl0czogMCxcclxuLy8gICAgICAgICB0b3RhbExvYW5zOiAwLFxyXG4vLyAgICAgICAgIHRvdGFsUGF5YWJsZTogMCxcclxuLy8gICAgICAgICB0b3RhbEludmVzdG1lbnQ6IDAsXHJcbi8vICAgICAgICAgdG90YWxQZW5hbHR5OiAwLFxyXG4vLyAgICAgICAgIHRvdGFsTGF0ZUZlZTogMCxcclxuLy8gICAgICAgICB0b3RhbENoaXRCYWxhbmNlOiAwLFxyXG4vLyAgICAgICAgIHRvdGFsTG9hblBhaWQ6IDAsXHJcbi8vICAgICAgICAgdG90YWxMb2FuQmFsYW5jZTogMCxcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvKlxyXG4vLyAgICAqID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gICAgKiBBUEkgVFJJR0dFUlxyXG4vLyAgICAqID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gICAgKi9cclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGlmIChcclxuLy8gICAgICAgc2VsZWN0ZWRGcm9tRGF0ZSAmJlxyXG4vLyAgICAgICBzZWxlY3RlZFRvRGF0ZVxyXG4vLyAgICAgKSB7XHJcbi8vICAgICAgIGZldGNoQ3VzdG9tZXJUcmFja2luZ1JlcG9ydCgpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtcclxuLy8gICAgIHNlbGVjdGVkRnJvbURhdGUsXHJcbi8vICAgICBzZWxlY3RlZFRvRGF0ZSxcclxuLy8gICAgIGZvcm1EYXRhLnVzZXIsXHJcbi8vICAgICBmb3JtRGF0YS5lbXBsb3llZSxcclxuLy8gICBdKTtcclxuXHJcbi8vICAgLypcclxuLy8gICAgKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vICAgICogREVGQVVMVCBGSUxURVJcclxuLy8gICAgKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vICAgICovXHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoXCJUb2RheVwiKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8qXHJcbi8vICAgICogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyAgICAqIFRBQkxFIENPTFVNTlNcclxuLy8gICAgKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vICAgICovXHJcblxyXG4vLyBjb25zdCBjb2x1bW4gPSBbXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcInNsTm9cIixcclxuLy8gICAgIGhlYWRlcjogXCJTbCBOb1wiLFxyXG4vLyAgIH0sXHJcblxyXG4vLyAgIC8vID09PT09PT09PT09PT09PT09IENVU1RPTUVSID09PT09PT09PT09PT09PT09XHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcImN1c3RvbWVyXCIsXHJcbi8vICAgICBoZWFkZXI6IFwiQ3VzdG9tZXJcIixcclxuLy8gICB9LFxyXG5cclxuLy8gICB7XHJcbi8vICAgICBrZXk6IFwiY3VzdG9tZXJJZFwiLFxyXG4vLyAgICAgaGVhZGVyOiBcIkN1c3RvbWVyIElEXCIsXHJcbi8vICAgfSxcclxuXHJcbi8vICAgLy8gPT09PT09PT09PT09PT09PT0gRU1QTE9ZRUUgPT09PT09PT09PT09PT09PT1cclxuLy8gICB7XHJcbi8vICAgICBrZXk6IFwiZW1wbG95ZWVcIixcclxuLy8gICAgIGhlYWRlcjogXCJDb2xsZWN0ZWQgQnlcIixcclxuLy8gICB9LFxyXG5cclxuLy8gICB7XHJcbi8vICAgICBrZXk6IFwiZW1wbG95ZWVDb2RlXCIsXHJcbi8vICAgICBoZWFkZXI6IFwiRW1wbG95ZWUgQ29kZVwiLFxyXG4vLyAgIH0sXHJcblxyXG4vLyAgIC8vID09PT09PT09PT09PT09PT09IFRSQUNLSU5HID09PT09PT09PT09PT09PT09XHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcImNvbGxlY3Rpb25EYXRlXCIsXHJcbi8vICAgICBoZWFkZXI6IFwiQ29sbGVjdGVkIE9uXCIsXHJcbi8vICAgfSxcclxuXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcInJlYXNvblwiLFxyXG4vLyAgICAgaGVhZGVyOiBcIlJlYXNvblwiLFxyXG4vLyAgIH0sXHJcblxyXG4vLyAgIHtcclxuLy8gICAgIGtleTogXCJyZW1hcmtcIixcclxuLy8gICAgIGhlYWRlcjogXCJSZW1hcmtcIixcclxuLy8gICB9LFxyXG5cclxuLy8gICB7XHJcbi8vICAga2V5OiBcImdyb3VwTmFtZVwiLFxyXG4vLyAgIGhlYWRlcjogXCJHcm91cCBOYW1lXCIsXHJcbi8vIH0sXHJcblxyXG4vLyB7XHJcbi8vICAga2V5OiBcInRpY2tldFwiLFxyXG4vLyAgIGhlYWRlcjogXCJUaWNrZXRcIixcclxuLy8gfSxcclxuXHJcbi8vICAgLy8gPT09PT09PT09PT09PT09PT0gQ0hJVCBERVRBSUxTID09PT09PT09PT09PT09PT09XHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcInBheW1lbnRUeXBlXCIsXHJcbi8vICAgICBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIsXHJcbi8vICAgfSxcclxuXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcImN1c3RvbWVyU3RhdHVzXCIsXHJcbi8vICAgICBoZWFkZXI6IFwiQ3VzdG9tZXIgU3RhdHVzXCIsXHJcbi8vICAgfSxcclxuXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcInRvdGFsUGF5YWJsZVwiLFxyXG4vLyAgICAgaGVhZGVyOiBcIlRvdGFsIFBheWFibGVcIixcclxuLy8gICB9LFxyXG5cclxuLy8gICB7XHJcbi8vICAgICBrZXk6IFwidG90YWxJbnZlc3RtZW50XCIsXHJcbi8vICAgICBoZWFkZXI6IFwiVG90YWwgSW52ZXN0bWVudFwiLFxyXG4vLyAgIH0sXHJcblxyXG4vLyAgIHtcclxuLy8gICAgIGtleTogXCJ0b3RhbFBlbmFsdHlcIixcclxuLy8gICAgIGhlYWRlcjogXCJUb3RhbCBQZW5hbHR5XCIsXHJcbi8vICAgfSxcclxuXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcInRvdGFsTGF0ZUZlZVwiLFxyXG4vLyAgICAgaGVhZGVyOiBcIlRvdGFsIExhdGUgRmVlXCIsXHJcbi8vICAgfSxcclxuXHJcbi8vICAgLy8gPT09PT09PT09PT09PT09PT0gTE9BTiBERVRBSUxTID09PT09PT09PT09PT09PT09XHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcImxvYW5JZFwiLFxyXG4vLyAgICAgaGVhZGVyOiBcIkxvYW4gSURcIixcclxuLy8gICB9LFxyXG5cclxuLy8gICB7XHJcbi8vICAgICBrZXk6IFwibG9hbkFtb3VudFwiLFxyXG4vLyAgICAgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIsXHJcbi8vICAgfSxcclxuXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcImxvYW5TdGFydERhdGVcIixcclxuLy8gICAgIGhlYWRlcjogXCJMb2FuIFN0YXJ0IERhdGVcIixcclxuLy8gICB9LFxyXG5cclxuLy8gICB7XHJcbi8vICAgICBrZXk6IFwibG9hbkVuZERhdGVcIixcclxuLy8gICAgIGhlYWRlcjogXCJMb2FuIEVuZCBEYXRlXCIsXHJcbi8vICAgfSxcclxuLy8gXTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0xMFwiPlxyXG4vLyAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcblxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuXHJcbi8vICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgQ3VzdG9tZXIgUGF5bWVudCBUcmFja2luZyBSZXBvcnRcclxuLy8gICAgICAgICA8L2gyPlxyXG5cclxuLy8gICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gICAgICAgICAgICAgRklMVEVSU1xyXG4vLyAgICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcblxyXG4vLyAgICAgICAgICAgey8qIERhdGUgRmlsdGVyICovfVxyXG5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzRcIj5cclxuLy8gICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEgdGV4dC1zbVwiPlxyXG4vLyAgICAgICAgICAgICAgIERhdGUgRmlsdGVyXHJcbi8vICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4vLyAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTJcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtcclxuLy8gICAgICAgICAgICAgICAgIGZvcm1EYXRhLmZpbHRlclR5cGVcclxuLy8gICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiZmlsdGVyVHlwZVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZVxyXG4vLyAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIHtkYXRlRmlsdGVyT3B0aW9ucy5tYXAoXHJcbi8vICAgICAgICAgICAgICAgICAob3B0aW9uKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAga2V5PXtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi52YWx1ZVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24udmFsdWVcclxuLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7b3B0aW9uLmxhYmVsfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICB7LyogQ3VzdG9tIERhdGUgKi99XHJcblxyXG4vLyAgICAgICAgICAge3Nob3dGaWx0ZXJGaWVsZCAmJiAoXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBpdGVtcy1lbmRcIj5cclxuXHJcbi8vICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIEZyb21cclxuLy8gICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkIGgtMTJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRGcm9tRGF0ZVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWVcclxuLy8gICAgICAgICAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBUb1xyXG4vLyAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbi8vICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWQgaC0xMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuLy8gICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFRvRGF0ZVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFRvRGF0ZShcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgIHsvKiBFbXBsb3llZSAqL31cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS80XCI+XHJcbi8vICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5cclxuLy8gICAgICAgICAgICAgICBTZWxlY3QgRW1wbG95ZWVcclxuLy8gICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbi8vICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbi8vICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbGwgRW1wbG95ZWVzXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17XHJcbi8vICAgICAgICAgICAgICAgICBmb3JtRGF0YS5lbXBsb3llZSB8fFxyXG4vLyAgICAgICAgICAgICAgICAgdW5kZWZpbmVkXHJcbi8vICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbi8vICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFxyXG4vLyAgICAgICAgICAgICAgICAgICBcImVtcGxveWVlXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlXHJcbi8vICAgICAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuLy8gICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+XHJcbi8vICAgICAgICAgICAgICAgICBBbGwgRW1wbG95ZWVzXHJcbi8vICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG5cclxuLy8gICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcChcclxuLy8gICAgICAgICAgICAgICAgIChlbXBsb3llZSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGtleT17XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBlbXBsb3llZS5faWRcclxuLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZW1wbG95ZWUuX2lkXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlLm5hbWV9XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZS5waG9uZV9udW1iZXJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID8gYCAtICR7ZW1wbG95ZWUucGhvbmVfbnVtYmVyfWBcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDogXCJcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIEN1c3RvbWVyICovfVxyXG5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzRcIj5cclxuLy8gICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEgdGV4dC1zbVwiPlxyXG4vLyAgICAgICAgICAgICAgIFNlbGVjdCBDdXN0b21lclxyXG4vLyAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuLy8gICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBDdXN0b21lcnNcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtcclxuLy8gICAgICAgICAgICAgICAgIGZvcm1EYXRhLnVzZXIgfHxcclxuLy8gICAgICAgICAgICAgICAgIHVuZGVmaW5lZFxyXG4vLyAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcclxuLy8gICAgICAgICAgICAgICAgICAgXCJ1c2VyXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlXHJcbi8vICAgICAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuLy8gICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+XHJcbi8vICAgICAgICAgICAgICAgICBBbGwgQ3VzdG9tZXJzXHJcbi8vICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG5cclxuLy8gICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4vLyAgICAgICAgICAgICAgICAgICBrZXk9e3VzZXIuX2lkfVxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXNlci5faWR9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX1cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgIHt1c2VyLnBob25lX251bWJlclxyXG4vLyAgICAgICAgICAgICAgICAgICAgID8gYCAtICR7dXNlci5waG9uZV9udW1iZXJ9YFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDogXCJcIn1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vICAgICAgICAgICAgIE9WRVJWSUVXXHJcbi8vICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTQgbWItNlwiPlxyXG5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFRvdGFsIFRyYWNraW5nXHJcbi8vICAgICAgICAgICAgIDwvcD5cclxuXHJcbi8vICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICB7c3VtbWFyeS50b3RhbFRyYWNraW5nfVxyXG4vLyAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFRvdGFsIEN1c3RvbWVyc1xyXG4vLyAgICAgICAgICAgICA8L3A+XHJcblxyXG4vLyAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAge3N1bW1hcnkudG90YWxDdXN0b21lcnN9XHJcbi8vICAgICAgICAgICAgIDwvaDI+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXllbGxvdy0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFRvdGFsIEVtcGxveWVlc1xyXG4vLyAgICAgICAgICAgICA8L3A+XHJcblxyXG4vLyAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAge3N1bW1hcnkudG90YWxFbXBsb3llZXN9XHJcbi8vICAgICAgICAgICAgIDwvaDI+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXB1cnBsZS0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFRvdGFsIENoaXRzXHJcbi8vICAgICAgICAgICAgIDwvcD5cclxuXHJcbi8vICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICB7c3VtbWFyeS50b3RhbENoaXRzfVxyXG4vLyAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtMTAwIHAtNCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuLy8gICAgICAgICAgICAgICBUb3RhbCBMb2Fuc1xyXG4vLyAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICB7c3VtbWFyeS50b3RhbExvYW5zfVxyXG4vLyAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWluZGlnby0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIENoaXQgUGF5YWJsZVxyXG4vLyAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICB7Zm9ybWF0QW1vdW50KFxyXG4vLyAgICAgICAgICAgICAgICAgc3VtbWFyeS50b3RhbFBheWFibGVcclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXRlYWwtMTAwIHAtNCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuLy8gICAgICAgICAgICAgICBDaGl0IEludmVzdG1lbnRcclxuLy8gICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAge2Zvcm1hdEFtb3VudChcclxuLy8gICAgICAgICAgICAgICAgIHN1bW1hcnkudG90YWxJbnZlc3RtZW50XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgPC9oMj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtMTAwIHAtNCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuLy8gICAgICAgICAgICAgICBDaGl0IEJhbGFuY2VcclxuLy8gICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAge2Zvcm1hdEFtb3VudChcclxuLy8gICAgICAgICAgICAgICAgIHN1bW1hcnkudG90YWxDaGl0QmFsYW5jZVxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvaDI+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcGluay0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFRvdGFsIFBlbmFsdHlcclxuLy8gICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAge2Zvcm1hdEFtb3VudChcclxuLy8gICAgICAgICAgICAgICAgIHN1bW1hcnkudG90YWxQZW5hbHR5XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgPC9oMj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBwLTQgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgVG90YWwgTGF0ZSBGZWVcclxuLy8gICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAge2Zvcm1hdEFtb3VudChcclxuLy8gICAgICAgICAgICAgICAgIHN1bW1hcnkudG90YWxMYXRlRmVlXHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgPC9oMj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1jeWFuLTEwMCBwLTQgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgTG9hbiBQYWlkXHJcbi8vICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgIHtmb3JtYXRBbW91bnQoXHJcbi8vICAgICAgICAgICAgICAgICBzdW1tYXJ5LnRvdGFsTG9hblBhaWRcclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWFtYmVyLTEwMCBwLTQgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgTG9hbiBCYWxhbmNlXHJcbi8vICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgIHtmb3JtYXRBbW91bnQoXHJcbi8vICAgICAgICAgICAgICAgICBzdW1tYXJ5LnRvdGFsTG9hbkJhbGFuY2VcclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAge2N1c3RvbWVyVHJhY2tpbmdEYXRhLmxlbmd0aCA+IDAgJiZcclxuLy8gICAgICAgICAhbG9hZGluZyA/IChcclxuLy8gICAgICAgICAgIDxEYXRhVGFibGVcclxuLy8gICAgICAgICAgICAgY29sdW1ucz17Y29sdW1ufVxyXG4vLyAgICAgICAgICAgICBkYXRhPXtjdXN0b21lclRyYWNraW5nRGF0YX1cclxuLy8gICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkN1c3RvbWVyIFBheW1lbnQgVHJhY2tpbmcgUmVwb3J0XCJcclxuLy8gICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ3VzdG9tZXIgUGF5bWVudCBUcmFja2luZyBSZXBvcnRcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbi8vICAgICAgICAgICAgIGlzTG9hZGluZz17bG9hZGluZ31cclxuLy8gICAgICAgICAgICAgZmFpbHVyZT17bG9hZGluZyA8PSAwfVxyXG4vLyAgICAgICAgICAgICBkYXRhPVwiQ3VzdG9tZXIgUGF5bWVudCBUcmFja2luZyBSZXBvcnRcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICApfVxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG5cclxuXHJcbmNvbnN0IEN1c3RvbWVyVHJhY2tpbmdSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2N1c3RvbWVyVHJhY2tpbmdEYXRhLCBzZXRDdXN0b21lclRyYWNraW5nRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NvbGxlY3Rpb25BcmVhcywgc2V0Q29sbGVjdGlvbkFyZWFzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpbml0aWFsTG9hZGluZywgc2V0SW5pdGlhbExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4gIGNvbnN0IFtzZWxlY3RlZEZyb21EYXRlLCBzZXRTZWxlY3RlZEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFRvRGF0ZSwgc2V0U2VsZWN0ZWRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IFtzaG93RmlsdGVyRmllbGQsIHNldFNob3dGaWx0ZXJGaWVsZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dSZW1haW5pbmdGaWx0ZXJzLCBzZXRTaG93UmVtYWluaW5nRmlsdGVyc10gPVxyXG4gICAgdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGNvbGxlY3Rpb25BcmVhOiBcIlwiLFxyXG4gICAgdXNlcjogXCJcIixcclxuICAgIGVtcGxveWVlOiBcIlwiLFxyXG4gICAgZmlsdGVyVHlwZTogXCJUb2RheVwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtjb2xsZWN0aW9uVG90YWxzLCBzZXRDb2xsZWN0aW9uVG90YWxzXSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsRGFpbHlJbnN0YWxsbWVudDogMCxcclxuICAgIHRvdGFsUmVjZW50UGF5bWVudHM6IDAsXHJcbiAgICBkYWlseUJhbGFuY2U6IDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsVHJhY2tpbmc6IDAsXHJcbiAgICB0b3RhbEN1c3RvbWVyczogMCxcclxuICAgIHRvdGFsRW1wbG95ZWVzOiAwLFxyXG4gICAgdG90YWxDaGl0czogMCxcclxuICAgIHRvdGFsTG9hbnM6IDAsXHJcbiAgICB0b3RhbFBheWFibGU6IDAsXHJcbiAgICB0b3RhbEludmVzdG1lbnQ6IDAsXHJcbiAgICB0b3RhbFBlbmFsdHk6IDAsXHJcbiAgICB0b3RhbExhdGVGZWU6IDAsXHJcbiAgICB0b3RhbENoaXRCYWxhbmNlOiAwLFxyXG4gICAgdG90YWxMb2FuUGFpZDogMCxcclxuICAgIHRvdGFsTG9hbkJhbGFuY2U6IDAsXHJcbiAgfSk7XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIENPTU1PTiBIRUxQRVJTXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gIGNvbnN0IHJlc2V0U3VtbWFyeSA9ICgpID0+IHtcclxuICAgIHNldFN1bW1hcnkoe1xyXG4gICAgICB0b3RhbFRyYWNraW5nOiAwLFxyXG4gICAgICB0b3RhbEN1c3RvbWVyczogMCxcclxuICAgICAgdG90YWxFbXBsb3llZXM6IDAsXHJcbiAgICAgIHRvdGFsQ2hpdHM6IDAsXHJcbiAgICAgIHRvdGFsTG9hbnM6IDAsXHJcbiAgICAgIHRvdGFsUGF5YWJsZTogMCxcclxuICAgICAgdG90YWxJbnZlc3RtZW50OiAwLFxyXG4gICAgICB0b3RhbFBlbmFsdHk6IDAsXHJcbiAgICAgIHRvdGFsTGF0ZUZlZTogMCxcclxuICAgICAgdG90YWxDaGl0QmFsYW5jZTogMCxcclxuICAgICAgdG90YWxMb2FuUGFpZDogMCxcclxuICAgICAgdG90YWxMb2FuQmFsYW5jZTogMCxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgW2ZpZWxkXTogdmFsdWUgfHwgXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IHtcclxuICAgIGlmICghZGF0ZSkgcmV0dXJuIFwiXCI7XHJcblxyXG4gICAgY29uc3QgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgIGNvbnN0IGRheSA9IFN0cmluZyhkYXRlLmdldERhdGUoKSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG5cclxuICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdERpc3BsYXlEYXRlID0gKGRhdGUpID0+IHtcclxuICAgIGlmICghZGF0ZSkgcmV0dXJuIFwiLVwiO1xyXG5cclxuICAgIGNvbnN0IHBhcnNlZERhdGUgPSBuZXcgRGF0ZShkYXRlKTtcclxuXHJcbiAgICBpZiAoaXNOYU4ocGFyc2VkRGF0ZS5nZXRUaW1lKCkpKSB7XHJcbiAgICAgIHJldHVybiBcIi1cIjtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcGFyc2VkRGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1JTlwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmb3JtYXRBbW91bnQgPSAoYW1vdW50KSA9PiB7XHJcbiAgICByZXR1cm4gYOKCuSR7TnVtYmVyKGFtb3VudCB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWA7XHJcbiAgfTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gREFURSBGSUxURVIgT1BUSU9OU1xyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICBjb25zdCBkYXRlRmlsdGVyT3B0aW9ucyA9IFtcclxuICAgIC8vIHtcclxuICAgIC8vICAgdmFsdWU6IFwiTGFzdCA3IERheXNcIixcclxuICAgIC8vICAgbGFiZWw6IFwiTGFzdCA3IERheXNcIixcclxuICAgIC8vIH0sXHJcbiAgICB7XHJcbiAgICAgIHZhbHVlOiBcIlRvZGF5XCIsXHJcbiAgICAgIGxhYmVsOiBcIlRvZGF5XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB2YWx1ZTogXCJZZXN0ZXJkYXlcIixcclxuICAgICAgbGFiZWw6IFwiWWVzdGVyZGF5XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB2YWx1ZTogXCJEYXlCZWZvcmVZZXN0ZXJkYXlcIixcclxuICAgICAgbGFiZWw6IFwiRGF5IEJlZm9yZSBZZXN0ZXJkYXlcIixcclxuICAgIH0sXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIHZhbHVlOiBcIlRoaXNNb250aFwiLFxyXG4gICAgLy8gICBsYWJlbDogXCJUaGlzIE1vbnRoXCIsXHJcbiAgICAvLyB9LFxyXG4gICAgLy8ge1xyXG4gICAgLy8gICB2YWx1ZTogXCJMYXN0TW9udGhcIixcclxuICAgIC8vICAgbGFiZWw6IFwiTGFzdCBNb250aFwiLFxyXG4gICAgLy8gfSxcclxuICAgIC8vIHtcclxuICAgIC8vICAgdmFsdWU6IFwiVGhpc1llYXJcIixcclxuICAgIC8vICAgbGFiZWw6IFwiVGhpcyBZZWFyXCIsXHJcbiAgICAvLyB9LFxyXG4gICAge1xyXG4gICAgICB2YWx1ZTogXCJDdXN0b21cIixcclxuICAgICAgbGFiZWw6IFwiQ3VzdG9tXCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIERBVEUgRklMVEVSIEhBTkRMRVJcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcblxyXG4gICAgbGV0IGZyb20gPSBcIlwiO1xyXG4gICAgbGV0IHRvID0gXCJcIjtcclxuXHJcbiAgICAvLyBpZiAodmFsdWUgPT09IFwiTGFzdCA3IERheXNcIikge1xyXG4gICAgLy8gICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5KTtcclxuXHJcbiAgICAvLyAgIHN0YXJ0LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gNik7XHJcblxyXG4gICAgLy8gICBmcm9tID0gZm9ybWF0RGF0ZShzdGFydCk7XHJcbiAgICAvLyAgIHRvID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgaWYgKHZhbHVlID09PSBcIlRvZGF5XCIpIHtcclxuICAgICAgZnJvbSA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4gICAgICB0byA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcblxyXG4gICAgICB5ZXN0ZXJkYXkuc2V0RGF0ZSh0b2RheS5nZXREYXRlKCkgLSAxKTtcclxuXHJcbiAgICAgIGZyb20gPSBmb3JtYXREYXRlKHllc3RlcmRheSk7XHJcbiAgICAgIHRvID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJEYXlCZWZvcmVZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcblxyXG4gICAgICB5ZXN0ZXJkYXkuc2V0RGF0ZSh0b2RheS5nZXREYXRlKCkgLSAyKTtcclxuXHJcbiAgICAgIGZyb20gPSBmb3JtYXREYXRlKHllc3RlcmRheSk7XHJcbiAgICAgIHRvID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKFxyXG4gICAgICAgIHRvZGF5LmdldEZ1bGxZZWFyKCksXHJcbiAgICAgICAgdG9kYXkuZ2V0TW9udGgoKSxcclxuICAgICAgICAxXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZShcclxuICAgICAgICB0b2RheS5nZXRGdWxsWWVhcigpLFxyXG4gICAgICAgIHRvZGF5LmdldE1vbnRoKCkgKyAxLFxyXG4gICAgICAgIDBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGZyb20gPSBmb3JtYXREYXRlKHN0YXJ0KTtcclxuICAgICAgdG8gPSBmb3JtYXREYXRlKGVuZCk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUoXHJcbiAgICAgICAgdG9kYXkuZ2V0RnVsbFllYXIoKSxcclxuICAgICAgICB0b2RheS5nZXRNb250aCgpIC0gMSxcclxuICAgICAgICAxXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZShcclxuICAgICAgICB0b2RheS5nZXRGdWxsWWVhcigpLFxyXG4gICAgICAgIHRvZGF5LmdldE1vbnRoKCksXHJcbiAgICAgICAgMFxyXG4gICAgICApO1xyXG5cclxuICAgICAgZnJvbSA9IGZvcm1hdERhdGUoc3RhcnQpO1xyXG4gICAgICB0byA9IGZvcm1hdERhdGUoZW5kKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKFxyXG4gICAgICAgIHRvZGF5LmdldEZ1bGxZZWFyKCksXHJcbiAgICAgICAgMCxcclxuICAgICAgICAxXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZShcclxuICAgICAgICB0b2RheS5nZXRGdWxsWWVhcigpLFxyXG4gICAgICAgIDExLFxyXG4gICAgICAgIDMxXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBmcm9tID0gZm9ybWF0RGF0ZShzdGFydCk7XHJcbiAgICAgIHRvID0gZm9ybWF0RGF0ZShlbmQpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4gICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuICAgIC8vIFRoZXNlIHR3byBzdGF0ZXMgdHJpZ2dlciBBUEkgdXNlRWZmZWN0XHJcbiAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZyb20pO1xyXG4gICAgc2V0U2VsZWN0ZWRUb0RhdGUodG8pO1xyXG4gIH07XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIFdIRU4gREFURSBGSUxURVIgQ0hBTkdFU1xyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFmb3JtRGF0YS5maWx0ZXJUeXBlKSByZXR1cm47XHJcblxyXG4gICAgaGFuZGxlU2VsZWN0RmlsdGVyKGZvcm1EYXRhLmZpbHRlclR5cGUpO1xyXG4gIH0sIFtmb3JtRGF0YS5maWx0ZXJUeXBlXSk7XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIEZFVENIIFVTRVJTIC8gRU1QTE9ZRUVTIC8gQ09MTEVDVElPTiBBUkVBU1xyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hJbml0aWFsRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJbml0aWFsTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgLy8gVVNFUlNcclxuICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbiAgICAgICAgY29uc3QgdXNlclJlc3BvbnNlID1cclxuICAgICAgICAgIGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuXHJcbiAgICAgICAgY29uc3QgdXNlckRhdGEgPVxyXG4gICAgICAgICAgdXNlclJlc3BvbnNlLmRhdGE/LmRhdGEgfHxcclxuICAgICAgICAgIHVzZXJSZXNwb25zZS5kYXRhIHx8XHJcbiAgICAgICAgICBbXTtcclxuXHJcbiAgICAgICAgY29uc3Qgc2FmZVVzZXJzID0gQXJyYXkuaXNBcnJheSh1c2VyRGF0YSlcclxuICAgICAgICAgID8gdXNlckRhdGFcclxuICAgICAgICAgIDogW107XHJcblxyXG4gICAgICAgIHNldFVzZXJzKHNhZmVVc2Vycyk7XHJcblxyXG4gICAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAgIC8vIENPTExFQ1RJT04gQVJFQVNcclxuICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbiAgICAgICAgY29uc3QgYXJlYU1hcCA9IG5ldyBNYXAoKTtcclxuXHJcbiAgICAgICAgc2FmZVVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgICAgIGNvbnN0IGFyZWEgPSB1c2VyLmNvbGxlY3Rpb25fYXJlYTtcclxuXHJcbiAgICAgICAgICBpZiAoIWFyZWEpIHJldHVybjtcclxuXHJcbiAgICAgICAgICBpZiAodHlwZW9mIGFyZWEgPT09IFwib2JqZWN0XCIpIHtcclxuICAgICAgICAgICAgY29uc3QgYXJlYUlkID1cclxuICAgICAgICAgICAgICBhcmVhLl9pZD8udG9TdHJpbmcoKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghYXJlYUlkKSByZXR1cm47XHJcblxyXG4gICAgICAgICAgICBhcmVhTWFwLnNldChhcmVhSWQsIHtcclxuICAgICAgICAgICAgICBfaWQ6IGFyZWFJZCxcclxuICAgICAgICAgICAgICByb3V0ZV9uYW1lOlxyXG4gICAgICAgICAgICAgICAgYXJlYS5yb3V0ZV9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICBhcmVhLmFyZWFfbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgYXJlYS5uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICBhcmVhSWQsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY29uc3QgYXJlYUlkID1cclxuICAgICAgICAgICAgICBhcmVhLnRvU3RyaW5nKCk7XHJcblxyXG4gICAgICAgICAgICBhcmVhTWFwLnNldChhcmVhSWQsIHtcclxuICAgICAgICAgICAgICBfaWQ6IGFyZWFJZCxcclxuICAgICAgICAgICAgICByb3V0ZV9uYW1lOiBhcmVhSWQsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRDb2xsZWN0aW9uQXJlYXMoXHJcbiAgICAgICAgICBBcnJheS5mcm9tKGFyZWFNYXAudmFsdWVzKCkpXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgLy8gRU1QTE9ZRUVTXHJcbiAgICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4gICAgICAgIGNvbnN0IGVtcGxveWVlUmVzcG9uc2UgPVxyXG4gICAgICAgICAgYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZVwiKTtcclxuXHJcbiAgICAgICAgY29uc3QgZW1wbG95ZWVEYXRhID1cclxuICAgICAgICAgIGVtcGxveWVlUmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHxcclxuICAgICAgICAgIGVtcGxveWVlUmVzcG9uc2UuZGF0YT8uZGF0YSB8fFxyXG4gICAgICAgICAgZW1wbG95ZWVSZXNwb25zZS5kYXRhIHx8XHJcbiAgICAgICAgICBbXTtcclxuXHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKFxyXG4gICAgICAgICAgQXJyYXkuaXNBcnJheShlbXBsb3llZURhdGEpXHJcbiAgICAgICAgICAgID8gZW1wbG95ZWVEYXRhXHJcbiAgICAgICAgICAgIDogW11cclxuICAgICAgICApO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXHJcbiAgICAgICAgICBcIlVuYWJsZSB0byBmZXRjaCBpbml0aWFsIGRhdGFcIixcclxuICAgICAgICAgIGVycm9yXHJcbiAgICAgICAgKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJbml0aWFsTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hJbml0aWFsRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gSU5JVElBTCBEQVRFXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoXCJUb2RheVwiKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIENPTExFQ1RJT04gQVJFQSBDSEFOR0VcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgY29uc3QgaGFuZGxlQ29sbGVjdGlvbkFyZWFDaGFuZ2UgPSAodmFsdWUpID0+IHtcclxuICAgIGNvbnN0IGFyZWFWYWx1ZSA9IHZhbHVlIHx8IFwiXCI7XHJcblxyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIGNvbGxlY3Rpb25BcmVhOiBhcmVhVmFsdWUsXHJcbiAgICAgIHVzZXI6IFwiXCIsXHJcbiAgICAgIGVtcGxveWVlOiBcIlwiLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIGlmICghYXJlYVZhbHVlKSB7XHJcbiAgICAgIHNldFNob3dSZW1haW5pbmdGaWx0ZXJzKGZhbHNlKTtcclxuXHJcbiAgICAgIHNldEN1c3RvbWVyVHJhY2tpbmdEYXRhKFtdKTtcclxuXHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoXCJcIik7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKFwiXCIpO1xyXG5cclxuICAgICAgcmVzZXRTdW1tYXJ5KCk7XHJcblxyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgLy8gU2hvdyByZW1haW5pbmcgZmlsdGVyc1xyXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuICAgIHNldFNob3dSZW1haW5pbmdGaWx0ZXJzKHRydWUpO1xyXG5cclxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgIC8vIFNldCBkZWZhdWx0IGRhdGUgPSBMYXN0IDcgRGF5c1xyXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuICAgIGlmIChmb3JtRGF0YS5maWx0ZXJUeXBlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgZmlsdGVyVHlwZTogXCJUb2RheVwiLFxyXG4gICAgICB9KSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoXHJcbiAgICAgICAgZm9ybURhdGEuZmlsdGVyVHlwZSB8fCBcIlRvZGF5XCJcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyBGRVRDSCBDVVNUT01FUiBUUkFDS0lORyBSRVBPUlRcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgY29uc3QgZmV0Y2hDdXN0b21lclRyYWNraW5nUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFmb3JtRGF0YS5jb2xsZWN0aW9uQXJlYSkge1xyXG4gICAgICBjb25zb2xlLmxvZyhcclxuICAgICAgICBcIkFQSSBOT1QgQ0FMTEVEIC0gQ29sbGVjdGlvbiBBcmVhIG1pc3NpbmdcIlxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFzZWxlY3RlZEZyb21EYXRlIHx8ICFzZWxlY3RlZFRvRGF0ZSkge1xyXG4gICAgICBjb25zb2xlLmxvZyhcclxuICAgICAgICBcIkFQSSBOT1QgQ0FMTEVEIC0gRGF0ZSBtaXNzaW5nXCIsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgc2VsZWN0ZWRGcm9tRGF0ZSxcclxuICAgICAgICAgIHNlbGVjdGVkVG9EYXRlLFxyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XHJcblxyXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAvLyBDT0xMRUNUSU9OIEFSRUFcclxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbiAgICAgIHBhcmFtcy5hcHBlbmQoXHJcbiAgICAgICAgXCJjb2xsZWN0aW9uQXJlYVwiLFxyXG4gICAgICAgIGZvcm1EYXRhLmNvbGxlY3Rpb25BcmVhXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAvLyBEQVRFXHJcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4gICAgICBwYXJhbXMuYXBwZW5kKFxyXG4gICAgICAgIFwiZnJvbURhdGVcIixcclxuICAgICAgICBzZWxlY3RlZEZyb21EYXRlXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBwYXJhbXMuYXBwZW5kKFxyXG4gICAgICAgIFwidG9EYXRlXCIsXHJcbiAgICAgICAgc2VsZWN0ZWRUb0RhdGVcclxuICAgICAgKTtcclxuXHJcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgIC8vIENVU1RPTUVSXHJcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4gICAgICBpZiAoZm9ybURhdGEudXNlcikge1xyXG4gICAgICAgIHBhcmFtcy5hcHBlbmQoXHJcbiAgICAgICAgICBcInVzZXJJZFwiLFxyXG4gICAgICAgICAgZm9ybURhdGEudXNlclxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgIC8vIEVNUExPWUVFXHJcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4gICAgICBpZiAoZm9ybURhdGEuZW1wbG95ZWUpIHtcclxuICAgICAgICBwYXJhbXMuYXBwZW5kKFxyXG4gICAgICAgICAgXCJlbXBJZFwiLFxyXG4gICAgICAgICAgZm9ybURhdGEuZW1wbG95ZWVcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCB1cmwgPVxyXG4gICAgICAgIGAvdjEvYWRtaW4vY29sbGVjdGlvbi10cmFja2luZy90cmFja2luZz8ke3BhcmFtcy50b1N0cmluZygpfWA7XHJcblxyXG5cclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID1cclxuICAgICAgICBhd2FpdCBhcGkuZ2V0KHVybCk7XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZURhdGEgPVxyXG4gICAgICAgIHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4gICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAvLyBTVU1NQVJZXHJcbiAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgICBjb25zdCB1bmlxdWVDdXN0b21lcnMgPSBuZXcgU2V0KFxyXG4gICAgICAgIHJlc3BvbnNlRGF0YVxyXG4gICAgICAgICAgLm1hcChcclxuICAgICAgICAgICAgKGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgaXRlbS5jdXN0b21lcj8uX2lkXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCB1bmlxdWVFbXBsb3llZXMgPSBuZXcgU2V0KFxyXG4gICAgICAgIHJlc3BvbnNlRGF0YVxyXG4gICAgICAgICAgLmZsYXRNYXAoXHJcbiAgICAgICAgICAgIChpdGVtKSA9PlxyXG4gICAgICAgICAgICAgIGl0ZW0uY29sbGVjdGlvbl90cmFja2luZyB8fCBbXVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgICAgLm1hcChcclxuICAgICAgICAgICAgKHRyYWNraW5nKSA9PlxyXG4gICAgICAgICAgICAgIHRyYWNraW5nLmNvbGxlY3RlZF9ieT8uX2lkXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCB0b3RhbENoaXRzID1cclxuICAgICAgICByZXNwb25zZURhdGEucmVkdWNlKFxyXG4gICAgICAgICAgKHRvdGFsLCBpdGVtKSA9PlxyXG4gICAgICAgICAgICB0b3RhbCArXHJcbiAgICAgICAgICAgIChpdGVtLmN1c3RvbWVyX292ZXJ2aWV3XHJcbiAgICAgICAgICAgICAgPy5sZW5ndGggfHwgMCksXHJcbiAgICAgICAgICAwXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IHRvdGFsTG9hbnMgPVxyXG4gICAgICAgIHJlc3BvbnNlRGF0YS5yZWR1Y2UoXHJcbiAgICAgICAgICAodG90YWwsIGl0ZW0pID0+XHJcbiAgICAgICAgICAgIHRvdGFsICtcclxuICAgICAgICAgICAgKGl0ZW0ubG9hbl9kZXRhaWxzXHJcbiAgICAgICAgICAgICAgPy5sZW5ndGggfHwgMCksXHJcbiAgICAgICAgICAwXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgIC8vIENISVQgU1VNTUFSWVxyXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuICAgICAgY29uc3QgY2hpdFN1bW1hcnkgPVxyXG4gICAgICAgIHJlc3BvbnNlRGF0YS5yZWR1Y2UoXHJcbiAgICAgICAgICAoYWNjLCBpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgIChcclxuICAgICAgICAgICAgICBpdGVtLmN1c3RvbWVyX292ZXJ2aWV3IHx8IFtdXHJcbiAgICAgICAgICAgICkuZm9yRWFjaCgoY2hpdCkgPT4ge1xyXG4gICAgICAgICAgICAgIGFjYy50b3RhbFBheWFibGUgKz1cclxuICAgICAgICAgICAgICAgIE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgY2hpdC50b3RhbF9wYXlhYmxlIHx8IDBcclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgIGFjYy50b3RhbEludmVzdG1lbnQgKz1cclxuICAgICAgICAgICAgICAgIE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgY2hpdC50b3RhbF9pbnZlc3RtZW50IHx8IDBcclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgIGFjYy50b3RhbFBlbmFsdHkgKz1cclxuICAgICAgICAgICAgICAgIE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgY2hpdC50b3RhbF9wZW5hbHR5IHx8IDBcclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgIGFjYy50b3RhbExhdGVGZWUgKz1cclxuICAgICAgICAgICAgICAgIE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgY2hpdC50b3RhbF9sYXRlX2ZlZSB8fCAwXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICBhY2MudG90YWxCYWxhbmNlICs9XHJcbiAgICAgICAgICAgICAgICBOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgIGNoaXQudG90YWxfYmFsYW5jZSB8fCAwXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiBhY2M7XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICB0b3RhbFBheWFibGU6IDAsXHJcbiAgICAgICAgICAgIHRvdGFsSW52ZXN0bWVudDogMCxcclxuICAgICAgICAgICAgdG90YWxQZW5hbHR5OiAwLFxyXG4gICAgICAgICAgICB0b3RhbExhdGVGZWU6IDAsXHJcbiAgICAgICAgICAgIHRvdGFsQmFsYW5jZTogMCxcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG5cclxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgLy8gTE9BTiBTVU1NQVJZXHJcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4gICAgICBjb25zdCBsb2FuU3VtbWFyeSA9XHJcbiAgICAgICAgcmVzcG9uc2VEYXRhLnJlZHVjZShcclxuICAgICAgICAgIChhY2MsIGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgKFxyXG4gICAgICAgICAgICAgIGl0ZW0ubG9hbl9kZXRhaWxzIHx8IFtdXHJcbiAgICAgICAgICAgICkuZm9yRWFjaCgobG9hbikgPT4ge1xyXG4gICAgICAgICAgICAgIGFjYy50b3RhbFBhaWQgKz1cclxuICAgICAgICAgICAgICAgIE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgbG9hbi50b3RhbF9wYWlkX2Ftb3VudCB8fCAwXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICBhY2MudG90YWxCYWxhbmNlICs9XHJcbiAgICAgICAgICAgICAgICBOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgIGxvYW4uYmFsYW5jZSB8fCAwXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiBhY2M7XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICB0b3RhbFBhaWQ6IDAsXHJcbiAgICAgICAgICAgIHRvdGFsQmFsYW5jZTogMCxcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG5cclxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgLy8gU0VUIFNVTU1BUllcclxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbiAgICAgIHNldFN1bW1hcnkoe1xyXG4gICAgICAgIHRvdGFsVHJhY2tpbmc6XHJcbiAgICAgICAgICByZXNwb25zZURhdGEubGVuZ3RoLFxyXG5cclxuICAgICAgICB0b3RhbEN1c3RvbWVyczpcclxuICAgICAgICAgIHVuaXF1ZUN1c3RvbWVycy5zaXplLFxyXG5cclxuICAgICAgICB0b3RhbEVtcGxveWVlczpcclxuICAgICAgICAgIHVuaXF1ZUVtcGxveWVlcy5zaXplLFxyXG5cclxuICAgICAgICB0b3RhbENoaXRzLFxyXG5cclxuICAgICAgICB0b3RhbExvYW5zLFxyXG5cclxuICAgICAgICB0b3RhbFBheWFibGU6XHJcbiAgICAgICAgICBjaGl0U3VtbWFyeS50b3RhbFBheWFibGUsXHJcblxyXG4gICAgICAgIHRvdGFsSW52ZXN0bWVudDpcclxuICAgICAgICAgIGNoaXRTdW1tYXJ5LnRvdGFsSW52ZXN0bWVudCxcclxuXHJcbiAgICAgICAgdG90YWxQZW5hbHR5OlxyXG4gICAgICAgICAgY2hpdFN1bW1hcnkudG90YWxQZW5hbHR5LFxyXG5cclxuICAgICAgICB0b3RhbExhdGVGZWU6XHJcbiAgICAgICAgICBjaGl0U3VtbWFyeS50b3RhbExhdGVGZWUsXHJcblxyXG4gICAgICAgIHRvdGFsQ2hpdEJhbGFuY2U6XHJcbiAgICAgICAgICBjaGl0U3VtbWFyeS50b3RhbEJhbGFuY2UsXHJcblxyXG4gICAgICAgIHRvdGFsTG9hblBhaWQ6XHJcbiAgICAgICAgICBsb2FuU3VtbWFyeS50b3RhbFBhaWQsXHJcblxyXG4gICAgICAgIHRvdGFsTG9hbkJhbGFuY2U6XHJcbiAgICAgICAgICBsb2FuU3VtbWFyeS50b3RhbEJhbGFuY2UsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgLy8gRk9STUFUIFRBQkxFXHJcbiAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPVxyXG4gICAgICAgIHJlc3BvbnNlRGF0YT8uZmlsdGVyKChpdGVtKSA9PiB7XHJcbiAgICAgIGNvbnN0IGNoaXQgPVxyXG4gICAgICAgIGl0ZW0uY3VzdG9tZXJfb3ZlcnZpZXc/LlswXSB8fCB7fTtcclxuXHJcbiAgICAgIGNvbnN0IGRhaWx5SW5zdGFsbG1lbnQgPVxyXG4gICAgICAgIGNoaXQ/Lmdyb3VwX2lkPy5kYWlseV9pbnN0YWxsbWVudDtcclxuXHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgZGFpbHlJbnN0YWxsbWVudCAhPT0gbnVsbCAmJlxyXG4gICAgICAgIGRhaWx5SW5zdGFsbG1lbnQgIT09IHVuZGVmaW5lZCAmJlxyXG4gICAgICAgIE51bWJlcihkYWlseUluc3RhbGxtZW50KSA+IDBcclxuICAgICAgKTtcclxuICAgIH0pLm1hcChcclxuICAgICAgICAgIChpdGVtLCBpbmRleCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgY29uc3QgY3VzdG9tZXIgPVxyXG4gICAgICAgICAgICAgIGl0ZW0uY3VzdG9tZXIgfHwge307XHJcblxyXG4gICAgICAgICAgICBjb25zdCB0cmFja2luZyA9XHJcbiAgICAgICAgICAgICAgaXRlbS5jb2xsZWN0aW9uX3RyYWNraW5nPy5bMF0gfHxcclxuICAgICAgICAgICAgICB7fTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGN1c3RvbWVyT3ZlcnZpZXcgPVxyXG4gICAgICAgICAgICAgIGl0ZW0uY3VzdG9tZXJfb3ZlcnZpZXcgfHwgW107XHJcblxyXG4gICAgICAgICAgICBjb25zdCBsb2FuRGV0YWlscyA9XHJcbiAgICAgICAgICAgICAgaXRlbS5sb2FuX2RldGFpbHMgfHwgW107XHJcblxyXG4gICAgICAgICAgICBjb25zdCBjaGl0ID1cclxuICAgICAgICAgICAgICBjdXN0b21lck92ZXJ2aWV3WzBdIHx8IHt9O1xyXG5cclxuICAgICAgICAgICAgY29uc3QgbG9hbiA9XHJcbiAgICAgICAgICAgICAgbG9hbkRldGFpbHNbMF0gfHwge307XHJcblxyXG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICAvLyBDT0xMRUNUSU9OIEFSRUFcclxuICAgICAgICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbiAgICAgICAgICAgIGxldCBjb2xsZWN0aW9uQXJlYU5hbWUgPSBcIi1cIjtcclxuXHJcbiAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICBjdXN0b21lci5jb2xsZWN0aW9uX2FyZWEgJiZcclxuICAgICAgICAgICAgICB0eXBlb2YgY3VzdG9tZXIuY29sbGVjdGlvbl9hcmVhID09PVxyXG4gICAgICAgICAgICAgIFwib2JqZWN0XCJcclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgY29sbGVjdGlvbkFyZWFOYW1lID1cclxuICAgICAgICAgICAgICAgIGN1c3RvbWVyLmNvbGxlY3Rpb25fYXJlYVxyXG4gICAgICAgICAgICAgICAgICA/LnJvdXRlX25hbWUgfHxcclxuICAgICAgICAgICAgICAgIGN1c3RvbWVyLmNvbGxlY3Rpb25fYXJlYVxyXG4gICAgICAgICAgICAgICAgICA/LmFyZWFfbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXIuY29sbGVjdGlvbl9hcmVhXHJcbiAgICAgICAgICAgICAgICAgID8ubmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgXCItXCI7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICAgICAgICAgY3VzdG9tZXIuY29sbGVjdGlvbl9hcmVhXHJcbiAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGZvdW5kQXJlYSA9XHJcbiAgICAgICAgICAgICAgICBjb2xsZWN0aW9uQXJlYXMuZmluZChcclxuICAgICAgICAgICAgICAgICAgKGFyZWEpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgYXJlYS5faWQ/LnRvU3RyaW5nKCkgPT09XHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXIuY29sbGVjdGlvbl9hcmVhPy50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICBjb2xsZWN0aW9uQXJlYU5hbWUgPVxyXG4gICAgICAgICAgICAgICAgZm91bmRBcmVhPy5yb3V0ZV9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICBjdXN0b21lci5jb2xsZWN0aW9uX2FyZWEgfHxcclxuICAgICAgICAgICAgICAgIFwiLVwiO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICAvLyBFTVBMT1lFRVxyXG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuICAgICAgICAgICAgY29uc3QgZW1wbG95ZWVOYW1lID1cclxuICAgICAgICAgICAgICB0cmFja2luZy5jb2xsZWN0ZWRfYnk/Lm5hbWUgfHxcclxuICAgICAgICAgICAgICB0cmFja2luZy5lbXBsb3llZV9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgXCItXCI7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBlbXBsb3llZVBob25lID1cclxuICAgICAgICAgICAgICB0cmFja2luZy5jb2xsZWN0ZWRfYnlcclxuICAgICAgICAgICAgICAgID8ucGhvbmVfbnVtYmVyIHx8XHJcbiAgICAgICAgICAgICAgdHJhY2tpbmcuZW1wbG95ZWVfcGhvbmUgfHxcclxuICAgICAgICAgICAgICBcIi1cIjtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGVtcGxveWVlQ29kZSA9XHJcbiAgICAgICAgICAgICAgdHJhY2tpbmcuY29sbGVjdGVkX2J5XHJcbiAgICAgICAgICAgICAgICA/LmVtcGxveWVlQ29kZSB8fFxyXG4gICAgICAgICAgICAgIHRyYWNraW5nLmVtcGxveWVlQ29kZSB8fFxyXG4gICAgICAgICAgICAgIFwiLVwiO1xyXG5cclxuICAgICAgICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgICAgICAgLy8gUEFZTUVOVFxyXG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuICAgICAgICAgICAgY29uc3QgcGF5bWVudCA9XHJcbiAgICAgICAgICAgICAgaXRlbS5wYXltZW50cz8uWzBdIHx8IG51bGw7XHJcblxyXG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICAvLyBSRVRVUk4gVEFCTEUgREFUQVxyXG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBpZDpcclxuICAgICAgICAgICAgICAgIHRyYWNraW5nLl9pZCB8fFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXIuX2lkIHx8XHJcbiAgICAgICAgICAgICAgICBpbmRleCxcclxuXHJcbiAgICAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG5cclxuICAgICAgICAgICAgICAvLyBDVVNUT01FUlxyXG4gICAgICAgICAgICAgIGN1c3RvbWVyOlxyXG4gICAgICAgICAgICAgICAgYCR7Y3VzdG9tZXIuZnVsbF9uYW1lIHx8IFwiLVwifSB8ICR7Y3VzdG9tZXIucGhvbmVfbnVtYmVyIHx8IFwiLVwiXHJcbiAgICAgICAgICAgICAgICB9YCxcclxuXHJcbiAgICAgICAgICAgICAgY3VzdG9tZXJJZDpcclxuICAgICAgICAgICAgICAgIGN1c3RvbWVyLmN1c3RvbWVyX2lkIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICBjb2xsZWN0aW9uQXJlYTpcclxuICAgICAgICAgICAgICAgIGNvbGxlY3Rpb25BcmVhTmFtZSxcclxuXHJcbiAgICAgICAgICAgICAgYWRkcmVzczpcclxuICAgICAgICAgICAgICAgIGN1c3RvbWVyLmFkZHJlc3MgfHwgXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgIHBpbmNvZGU6XHJcbiAgICAgICAgICAgICAgICBjdXN0b21lci5waW5jb2RlIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAvLyBFTVBMT1lFRVxyXG4gICAgICAgICAgICAgIGVtcGxveWVlOlxyXG4gICAgICAgICAgICAgICAgYCR7ZW1wbG95ZWVOYW1lfSB8ICR7ZW1wbG95ZWVQaG9uZX1gLFxyXG5cclxuICAgICAgICAgICAgICBlbXBsb3llZUNvZGUsXHJcblxyXG4gICAgICAgICAgICAgIC8vIFRSQUNLSU5HXHJcbiAgICAgICAgICAgICAgY29sbGVjdGlvbkRhdGU6XHJcbiAgICAgICAgICAgICAgICB0cmFja2luZy5jb2xsZWN0aW9uX2RhdGVcclxuICAgICAgICAgICAgICAgICAgPyBmb3JtYXREaXNwbGF5RGF0ZShcclxuICAgICAgICAgICAgICAgICAgICB0cmFja2luZy5jb2xsZWN0aW9uX2RhdGVcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICA6IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICByZWFzb246aXRlbS5wYXltZW50X3N0YXR1cz09PVwiUGFpZFwiID8gXCJQYWlkXCI6XHJcbiAgICAgICAgICAgICAgICBpdGVtLm5vdF9wYWlkX3JlYXNvbiAmJlxyXG4gICAgICAgICAgICAgICAgICBpdGVtLm5vdF9wYWlkX3JlYXNvbiAhPT0gXCJOb3QgQXBwbGljYWJsZVwiXHJcbiAgICAgICAgICAgICAgICAgID8gaXRlbS5ub3RfcGFpZF9yZWFzb24ucmVwbGFjZSgvXy9nLCBcIiBcIilcclxuICAgICAgICAgICAgICAgICAgOiB0cmFja2luZy5yZWFzb24gfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgZGFpbHlfaW5zdGFsbG1lbnQ6IGNoaXQ/Lmdyb3VwX2lkPy5kYWlseV9pbnN0YWxsbWVudCxcclxuICAgICAgICAgICAgICByZWNlbnRfcGF5bWVudHM6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAge2l0ZW0ucGF5bWVudHM/LnJlZHVjZShcclxuICAgICAgICAgICAgICAgICAgICAgICh0b3RhbCwgcGF5bWVudCkgPT4gdG90YWwgKyBOdW1iZXIocGF5bWVudC5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAwXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2l0ZW0ucGF5bWVudHM/Lmxlbmd0aCA+IDEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxUb29sdGlwXHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucGF5bWVudHM/Lm1hcCgocGF5bWVudCwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtwYXltZW50LmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5mb0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgY3Vyc29yLXBvaW50ZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgICAgIHJlbWFyazpcclxuICAgICAgICAgICAgICAgIHRyYWNraW5nLnJlbWFyayB8fFxyXG4gICAgICAgICAgICAgICAgdHJhY2tpbmcucmVtYXJrcyB8fFxyXG4gICAgICAgICAgICAgICAgXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgIHBheW1lbnRTdGF0dXM6XHJcbiAgICAgICAgICAgICAgICBpdGVtLnBheW1lbnRfc3RhdHVzIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAvLyBDSElUXHJcbiAgICAgICAgICAgICAgZ3JvdXBOYW1lOlxyXG4gICAgICAgICAgICAgICAgY2hpdC5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgY2hpdC5ncm91cF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgdGlja2V0OlxyXG4gICAgICAgICAgICAgICAgY2hpdC50aWNrZXRzID8/XHJcbiAgICAgICAgICAgICAgICBjaGl0LnRpY2tldCA/P1xyXG4gICAgICAgICAgICAgICAgXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgIHBheW1lbnRUeXBlOlxyXG4gICAgICAgICAgICAgICAgY2hpdC5wYXltZW50X3R5cGUgfHxcclxuICAgICAgICAgICAgICAgIHBheW1lbnQ/LnBheW1lbnRfdHlwZSB8fFxyXG4gICAgICAgICAgICAgICAgXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgIGN1c3RvbWVyU3RhdHVzOlxyXG4gICAgICAgICAgICAgICAgY2hpdC5jdXN0b21lcl9zdGF0dXMgfHxcclxuICAgICAgICAgICAgICAgIFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICB0b3RhbFBheWFibGU6XHJcbiAgICAgICAgICAgICAgICBjaGl0LnRvdGFsX3BheWFibGUgIT09IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICA/IE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgICBjaGl0LnRvdGFsX3BheWFibGVcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICA6IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICB0b3RhbEludmVzdG1lbnQ6XHJcbiAgICAgICAgICAgICAgICBjaGl0LnRvdGFsX2ludmVzdG1lbnQgIT09IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICA/IE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgICBjaGl0LnRvdGFsX2ludmVzdG1lbnRcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICA6IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICB0b3RhbFBlbmFsdHk6XHJcbiAgICAgICAgICAgICAgICBjaGl0LnRvdGFsX3BlbmFsdHkgIT09IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICA/IE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgICBjaGl0LnRvdGFsX3BlbmFsdHlcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICA6IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICB0b3RhbExhdGVGZWU6XHJcbiAgICAgICAgICAgICAgICBjaGl0LnRvdGFsX2xhdGVfZmVlICE9PSB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgPyBOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgY2hpdC50b3RhbF9sYXRlX2ZlZVxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgIDogXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgIGNoaXRCYWxhbmNlOlxyXG4gICAgICAgICAgICAgICAgY2hpdC50b3RhbF9iYWxhbmNlICE9PSB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgPyBOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgY2hpdC50b3RhbF9iYWxhbmNlXHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgLy8gTE9BTlxyXG4gICAgICAgICAgICAgIGxvYW5JZDpcclxuICAgICAgICAgICAgICAgIGxvYW4ubG9hbl9pZCB8fCBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgbG9hbkFtb3VudDpcclxuICAgICAgICAgICAgICAgIGxvYW4ubG9hbl9hbW91bnQgIT09IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICA/IE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgICBsb2FuLmxvYW5fYW1vdW50XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgbG9hblN0YXJ0RGF0ZTpcclxuICAgICAgICAgICAgICAgIGxvYW4uc3RhcnRfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICA/IGZvcm1hdERpc3BsYXlEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgIGxvYW4uc3RhcnRfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgIDogXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgIGxvYW5FbmREYXRlOlxyXG4gICAgICAgICAgICAgICAgbG9hbi5lbmRfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICA/IGZvcm1hdERpc3BsYXlEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgIGxvYW4uZW5kX2RhdGVcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICA6IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICBsb2FuUGFpZEFtb3VudDpcclxuICAgICAgICAgICAgICAgIGxvYW4udG90YWxfcGFpZF9hbW91bnQgIT09XHJcbiAgICAgICAgICAgICAgICAgIHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICA/IE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgICBsb2FuLnRvdGFsX3BhaWRfYW1vdW50XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgbG9hbkJhbGFuY2U6XHJcbiAgICAgICAgICAgICAgICBsb2FuLmJhbGFuY2UgIT09IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICA/IE51bWJlcihcclxuICAgICAgICAgICAgICAgICAgICBsb2FuLmJhbGFuY2VcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICA6IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICBsb2FuU3RhdHVzOlxyXG4gICAgICAgICAgICAgICAgbG9hbi5zdGF0dXMgfHwgXCItXCIsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgICAgY29uc3QgdG90YWxEYWlseUluc3RhbGxtZW50ID0gZm9ybWF0dGVkLnJlZHVjZShcclxuICAgICAgICAodG90YWwsIGl0ZW0pID0+XHJcbiAgICAgICAgICB0b3RhbCArIE51bWJlcihpdGVtLmRhaWx5X2luc3RhbGxtZW50IHx8IDApLFxyXG4gICAgICAgIDBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IHRvdGFsUmVjZW50UGF5bWVudHMgPSByZXNwb25zZURhdGEucmVkdWNlKFxyXG4gICAgICAgICh0b3RhbCwgaXRlbSkgPT5cclxuICAgICAgICAgIHRvdGFsICtcclxuICAgICAgICAgIChpdGVtLnBheW1lbnRzPy5yZWR1Y2UoXHJcbiAgICAgICAgICAgIChwYXltZW50VG90YWwsIHBheW1lbnQpID0+XHJcbiAgICAgICAgICAgICAgcGF5bWVudFRvdGFsICtcclxuICAgICAgICAgICAgICBOdW1iZXIocGF5bWVudC5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgIDBcclxuICAgICAgICAgICkgfHwgMCksXHJcbiAgICAgICAgMFxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgZGFpbHlCYWxhbmNlID0gTWF0aC5tYXgoXHJcbiAgICAgICAgMCxcclxuICAgICAgICB0b3RhbERhaWx5SW5zdGFsbG1lbnQgLVxyXG4gICAgICAgIHRvdGFsUmVjZW50UGF5bWVudHNcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldENvbGxlY3Rpb25Ub3RhbHMoe1xyXG4gICAgICAgIHRvdGFsRGFpbHlJbnN0YWxsbWVudCxcclxuICAgICAgICB0b3RhbFJlY2VudFBheW1lbnRzLFxyXG4gICAgICAgIGRhaWx5QmFsYW5jZSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRDdXN0b21lclRyYWNraW5nRGF0YShcclxuICAgICAgICBmb3JtYXR0ZWRcclxuICAgICAgKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXHJcbiAgICAgICAgXCJVbmFibGUgdG8gZmV0Y2ggY3VzdG9tZXIgdHJhY2tpbmcgcmVwb3J0XCIsXHJcbiAgICAgICAgZXJyb3JcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldEN1c3RvbWVyVHJhY2tpbmdEYXRhKFtdKTtcclxuXHJcbiAgICAgIHJlc2V0U3VtbWFyeSgpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gSU1QT1JUQU5UOlxyXG4gIC8vIE9OTFkgT05FIEFQSSBFRkZFQ1RcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChcclxuICAgICAgIWZvcm1EYXRhLmNvbGxlY3Rpb25BcmVhIHx8XHJcbiAgICAgICFzZWxlY3RlZEZyb21EYXRlIHx8XHJcbiAgICAgICFzZWxlY3RlZFRvRGF0ZVxyXG4gICAgKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBmZXRjaEN1c3RvbWVyVHJhY2tpbmdSZXBvcnQoKTtcclxuICB9LCBbXHJcbiAgICBmb3JtRGF0YS5jb2xsZWN0aW9uQXJlYSxcclxuICAgIGZvcm1EYXRhLnVzZXIsXHJcbiAgICBmb3JtRGF0YS5lbXBsb3llZSxcclxuICAgIHNlbGVjdGVkRnJvbURhdGUsXHJcbiAgICBzZWxlY3RlZFRvRGF0ZSxcclxuICBdKTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gVEFCTEUgQ09MVU1OU1xyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICBjb25zdCBjb2x1bW4gPSBbXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJzbE5vXCIsXHJcbiAgICAgIGhlYWRlcjogXCJTbCBOb1wiLFxyXG4gICAgfSxcclxuXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJjdXN0b21lclwiLFxyXG4gICAgICBoZWFkZXI6IFwiQ3VzdG9tZXJcIixcclxuICAgIH0sXHJcblxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBrZXk6IFwiY3VzdG9tZXJJZFwiLFxyXG4gICAgLy8gICBoZWFkZXI6IFwiQ3VzdG9tZXIgSURcIixcclxuICAgIC8vIH0sXHJcblxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiY29sbGVjdGlvbkFyZWFcIixcclxuICAgICAgaGVhZGVyOiBcIkNvbGxlY3Rpb24gQXJlYVwiLFxyXG4gICAgfSxcclxuXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJlbXBsb3llZVwiLFxyXG4gICAgICBoZWFkZXI6IFwiQ29sbGVjdGVkIEJ5XCIsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHtcclxuICAgIC8vICAga2V5OiBcImVtcGxveWVlQ29kZVwiLFxyXG4gICAgLy8gICBoZWFkZXI6IFwiRW1wbG95ZWUgQ29kZVwiLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJjb2xsZWN0aW9uRGF0ZVwiLFxyXG4gICAgICBoZWFkZXI6IFwiQ29sbGVjdGVkIE9uXCIsXHJcbiAgICB9LFxyXG5cclxuICAgIHtcclxuICAgICAga2V5OiBcInJlYXNvblwiLFxyXG4gICAgICBoZWFkZXI6IFwiUmVhc29uXCIsXHJcbiAgICB9LFxyXG5cclxuICAgIHtcclxuICAgICAga2V5OiBcInJlbWFya1wiLFxyXG4gICAgICBoZWFkZXI6IFwiUmVtYXJrXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiZGFpbHlfaW5zdGFsbG1lbnRcIixcclxuICAgICAgaGVhZGVyOiBcIkRhaWx5IFBheWFibGVcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJyZWNlbnRfcGF5bWVudHNcIixcclxuICAgICAgaGVhZGVyOiBcIkRhaWx5IFBhaWRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJwYXltZW50U3RhdHVzXCIsXHJcbiAgICAgIGhlYWRlcjogXCJQYXltZW50IFN0YXR1c1wiLFxyXG4gICAgfSxcclxuXHJcblxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiZ3JvdXBOYW1lXCIsXHJcbiAgICAgIGhlYWRlcjogXCJHcm91cCBOYW1lXCIsXHJcbiAgICB9LFxyXG5cclxuICAgIHtcclxuICAgICAga2V5OiBcInRpY2tldFwiLFxyXG4gICAgICBoZWFkZXI6IFwiVGlja2V0XCIsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHtcclxuICAgIC8vICAga2V5OiBcInBheW1lbnRUeXBlXCIsXHJcbiAgICAvLyAgIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIixcclxuICAgIC8vIH0sXHJcblxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiY3VzdG9tZXJTdGF0dXNcIixcclxuICAgICAgaGVhZGVyOiBcIkN1c3RvbWVyIFN0YXR1c1wiLFxyXG4gICAgfSxcclxuXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJ0b3RhbFBheWFibGVcIixcclxuICAgICAgaGVhZGVyOiBcIlRvdGFsIFBheWFibGVcIixcclxuICAgIH0sXHJcblxyXG4gICAge1xyXG4gICAgICBrZXk6IFwidG90YWxJbnZlc3RtZW50XCIsXHJcbiAgICAgIGhlYWRlcjogXCJUb3RhbCBQYWlkXCIsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHtcclxuICAgIC8vICAga2V5OiBcInRvdGFsUGVuYWx0eVwiLFxyXG4gICAgLy8gICBoZWFkZXI6IFwiVG90YWwgUGVuYWx0eVwiLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIGtleTogXCJ0b3RhbExhdGVGZWVcIixcclxuICAgIC8vICAgaGVhZGVyOiBcIlRvdGFsIExhdGUgRmVlXCIsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIHtcclxuICAgICAga2V5OiBcImNoaXRCYWxhbmNlXCIsXHJcbiAgICAgIGhlYWRlcjogXCJDaGl0IEJhbGFuY2VcIixcclxuICAgIH0sXHJcblxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBrZXk6IFwibG9hbklkXCIsXHJcbiAgICAvLyAgIGhlYWRlcjogXCJMb2FuIElEXCIsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIC8vIHtcclxuICAgIC8vICAga2V5OiBcImxvYW5BbW91bnRcIixcclxuICAgIC8vICAgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIC8vIHtcclxuICAgIC8vICAga2V5OiBcImxvYW5TdGFydERhdGVcIixcclxuICAgIC8vICAgaGVhZGVyOiBcIkxvYW4gU3RhcnQgRGF0ZVwiLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIGtleTogXCJsb2FuRW5kRGF0ZVwiLFxyXG4gICAgLy8gICBoZWFkZXI6IFwiTG9hbiBFbmQgRGF0ZVwiLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIGtleTogXCJsb2FuUGFpZEFtb3VudFwiLFxyXG4gICAgLy8gICBoZWFkZXI6IFwiTG9hbiBQYWlkXCIsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIC8vIHtcclxuICAgIC8vICAga2V5OiBcImxvYW5CYWxhbmNlXCIsXHJcbiAgICAvLyAgIGhlYWRlcjogXCJMb2FuIEJhbGFuY2VcIixcclxuICAgIC8vIH0sXHJcblxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBrZXk6IFwibG9hblN0YXR1c1wiLFxyXG4gICAgLy8gICBoZWFkZXI6IFwiTG9hbiBTdGF0dXNcIixcclxuICAgIC8vIH0sXHJcbiAgXTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gUkVTRVRcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgY29uc3QgaGFuZGxlUmVzZXRBcmVhID0gKCkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICBjb2xsZWN0aW9uQXJlYTogXCJcIixcclxuICAgICAgdXNlcjogXCJcIixcclxuICAgICAgZW1wbG95ZWU6IFwiXCIsXHJcbiAgICAgIGZpbHRlclR5cGU6IFwiVG9kYXlcIixcclxuICAgIH0pO1xyXG5cclxuICAgIHNldFNob3dSZW1haW5pbmdGaWx0ZXJzKGZhbHNlKTtcclxuICAgIHNldFNob3dGaWx0ZXJGaWVsZChmYWxzZSk7XHJcblxyXG4gICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShcIlwiKTtcclxuICAgIHNldFNlbGVjdGVkVG9EYXRlKFwiXCIpO1xyXG5cclxuICAgIHNldEN1c3RvbWVyVHJhY2tpbmdEYXRhKFtdKTtcclxuXHJcbiAgICByZXNldFN1bW1hcnkoKTtcclxuICB9O1xyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyBVSVxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTEwIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgbWluLXctMFwiPlxyXG5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi02XCI+XHJcbiAgICAgICAgICBDdXN0b21lciBQYXltZW50IFRyYWNraW5nIFJlcG9ydFxyXG4gICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICAgICAgU1RFUCAxIC0gQ09MTEVDVElPTiBBUkVBXHJcbiAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNSByb3VuZGVkLWxnIHNoYWRvdy1zbSBtYi02XCI+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IGl0ZW1zLWVuZFwiPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvM1wiPlxyXG5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICBTZWxlY3QgQ29sbGVjdGlvbiBBcmVhXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTJcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ29sbGVjdGlvbiBBcmVhXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgZm9ybURhdGEuY29sbGVjdGlvbkFyZWEgfHxcclxuICAgICAgICAgICAgICAgICAgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZUNvbGxlY3Rpb25BcmVhQ2hhbmdlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgID5cclxuXHJcbiAgICAgICAgICAgICAgICB7Y29sbGVjdGlvbkFyZWFzLm1hcChcclxuICAgICAgICAgICAgICAgICAgKGFyZWEpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXthcmVhLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXthcmVhLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YXJlYS5yb3V0ZV9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtmb3JtRGF0YS5jb2xsZWN0aW9uQXJlYSAmJiAoXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZXNldEFyZWF9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEyIHB4LTUgYm9yZGVyIHJvdW5kZWQgaG92ZXI6YmctZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFJlc2V0XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgeyFmb3JtRGF0YS5jb2xsZWN0aW9uQXJlYSAmJiAoXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0zXCI+XHJcbiAgICAgICAgICAgICAgUGxlYXNlIHNlbGVjdCBhIENvbGxlY3Rpb24gQXJlYSBmaXJzdC5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICAgICAgU1RFUCAyIC0gUkVNQUlOSU5HIEZJTFRFUlNcclxuICAgICAgICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XHJcblxyXG4gICAgICAgIHtzaG93UmVtYWluaW5nRmlsdGVycyAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNSByb3VuZGVkLWxnIHNoYWRvdy1zbSBtYi02XCI+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgaXRlbXMtZW5kXCI+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBEQVRFIEZJTFRFUiAqL31cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgRGF0ZSBGaWx0ZXJcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5maWx0ZXJUeXBlXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXHJcbiAgICAgICAgICAgICAgICAgICAgICBcImZpbHRlclR5cGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtkYXRlRmlsdGVyT3B0aW9ucy5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgKG9wdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24udmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogQ1VTVE9NIERBVEUgKi99XHJcblxyXG4gICAgICAgICAgICAgIHtzaG93RmlsdGVyRmllbGQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIGl0ZW1zLWVuZFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIDxkaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBGcm9tXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWQgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRnJvbURhdGVcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUb1xyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkIGgtMTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFRvRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkVG9EYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtXCI+RnJvbTwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkIGgtMTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGF0ZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShkYXRlKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFsd2F5cyBrZWVwIFRvIGRhdGUgc2FtZSBhcyBGcm9tIGRhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZGF0ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbVwiPlRvPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWQgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRUb0RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBtYXg9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7LyogRU1QTE9ZRUUgKi99XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzRcIj5cclxuXHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbGwgRW1wbG95ZWVzXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmVtcGxveWVlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXHJcbiAgICAgICAgICAgICAgICAgICAgICBcImVtcGxveWVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgKGVtcGxveWVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVtcGxveWVlLl9pZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlbXBsb3llZS5faWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWUubmFtZX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZS5waG9uZV9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IGAgLSAke2VtcGxveWVlLnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBDVVNUT01FUiAqL31cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTJcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEudXNlciB8fFxyXG4gICAgICAgICAgICAgICAgICAgIHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJ1c2VyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgPlxyXG5cclxuICAgICAgICAgICAgICAgICAge3VzZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigodXNlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgYXJlYSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXIuY29sbGVjdGlvbl9hcmVhO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgIWZvcm1EYXRhLmNvbGxlY3Rpb25BcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlb2YgYXJlYSA9PT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJvYmplY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXJlYT8uX2lkPy50b1N0cmluZygpID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmNvbGxlY3Rpb25BcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXJlYT8udG9TdHJpbmcoKSA9PT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuY29sbGVjdGlvbkFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3VzZXIuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXNlci5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gYCAtICR7dXNlci5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuXHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICAgICAgIFNVTU1BUllcclxuICAgICAgICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XHJcblxyXG4gICAgICAgIHtzaG93UmVtYWluaW5nRmlsdGVycyAmJlxyXG4gICAgICAgICAgZm9ybURhdGEuY29sbGVjdGlvbkFyZWEgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTUgZ2FwLTQgbWItNlwiPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtMTAwIHAtNCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRvdGFsIFRyYWNraW5nXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7c3VtbWFyeS50b3RhbFRyYWNraW5nfVxyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7c3VtbWFyeS50b3RhbEN1c3RvbWVyc31cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImJnLXllbGxvdy0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgRW1wbG95ZWVzXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7c3VtbWFyeS50b3RhbEVtcGxveWVlc31cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHVycGxlLTEwMCBwLTQgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBUb3RhbCBDaGl0c1xyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAge3N1bW1hcnkudG90YWxDaGl0c31cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtMTAwIHAtNCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRvdGFsIExvYW5zXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7c3VtbWFyeS50b3RhbExvYW5zfVxyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctaW5kaWdvLTEwMCBwLTQgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBDaGl0IFBheWFibGVcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiB7Zm9ybWF0QW1vdW50KFxyXG4gICAgICAgICAgICAgICAgICAgIHN1bW1hcnkudG90YWxQYXlhYmxlXHJcbiAgICAgICAgICAgICAgICAgICl9ICovfVxyXG4gICAgICAgICAgICAgICAgICDigrl7Y29sbGVjdGlvblRvdGFscy50b3RhbERhaWx5SW5zdGFsbG1lbnQudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctdGVhbC0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQ2hpdCBQYWlkXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7Lyoge2Zvcm1hdEFtb3VudChcclxuICAgICAgICAgICAgICAgICAgICBzdW1tYXJ5LnRvdGFsSW52ZXN0bWVudFxyXG4gICAgICAgICAgICAgICAgICApfSAqL31cclxuICAgICAgICAgICAgICAgICAg4oK5e2NvbGxlY3Rpb25Ub3RhbHMudG90YWxSZWNlbnRQYXltZW50cy50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtMTAwIHAtNCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIENoaXQgQmFsYW5jZVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgey8qIHtmb3JtYXRBbW91bnQoXHJcbiAgICAgICAgICAgICAgICAgICAgc3VtbWFyeS50b3RhbENoaXRCYWxhbmNlXHJcbiAgICAgICAgICAgICAgICAgICl9ICovfVxyXG4gICAgICAgICAgICAgICAgICDigrl7Y29sbGVjdGlvblRvdGFscy5kYWlseUJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImJnLXBpbmstMTAwIHAtNCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRvdGFsIFBlbmFsdHlcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtYXRBbW91bnQoXHJcbiAgICAgICAgICAgICAgICAgICAgc3VtbWFyeS50b3RhbFBlbmFsdHlcclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgTGF0ZSBGZWVcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtYXRBbW91bnQoXHJcbiAgICAgICAgICAgICAgICAgICAgc3VtbWFyeS50b3RhbExhdGVGZWVcclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJiZy1jeWFuLTEwMCBwLTQgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBMb2FuIFBhaWRcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtYXRBbW91bnQoXHJcbiAgICAgICAgICAgICAgICAgICAgc3VtbWFyeS50b3RhbExvYW5QYWlkXHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWFtYmVyLTEwMCBwLTQgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBMb2FuIEJhbGFuY2VcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtYXRBbW91bnQoXHJcbiAgICAgICAgICAgICAgICAgICAgc3VtbWFyeS50b3RhbExvYW5CYWxhbmNlXHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgICAgICBUQUJMRVxyXG4gICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuXHJcbiAgICAgICAge3Nob3dSZW1haW5pbmdGaWx0ZXJzICYmXHJcbiAgICAgICAgICBmb3JtRGF0YS5jb2xsZWN0aW9uQXJlYSAmJiAoXHJcbiAgICAgICAgICAgIGxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e3RydWV9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIGRhdGE9XCJDdXN0b21lciBQYXltZW50IFRyYWNraW5nIFJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IGN1c3RvbWVyVHJhY2tpbmdEYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1ufVxyXG4gICAgICAgICAgICAgICAgZGF0YT17Y3VzdG9tZXJUcmFja2luZ0RhdGF9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ3VzdG9tZXIgUGF5bWVudCBUcmFja2luZyBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ3VzdG9tZXIgUGF5bWVudCBUcmFja2luZyBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgZmFpbHVyZT17dHJ1ZX1cclxuICAgICAgICAgICAgICAgIGRhdGE9XCJDdXN0b21lciBQYXltZW50IFRyYWNraW5nIFJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ3VzdG9tZXJUcmFja2luZ1JlcG9ydDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0N1c3RvbWVyVHJhY2tpbmdSZXBvcnQuanN4In0=