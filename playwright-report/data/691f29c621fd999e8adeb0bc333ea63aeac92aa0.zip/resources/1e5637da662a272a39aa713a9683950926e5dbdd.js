import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoanCollectionIncentiveReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import {
  Select,
  Radio,
  Card,
  Button,
  Space,
  Statistic,
  Row,
  Col,
  message
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  UserOutlined,
  CalendarOutlined,
  PercentageOutlined,
  FileSearchOutlined,
  TeamOutlined,
  RiseOutlined,
  PrinterOutlined,
  DownloadOutlined,
  SignatureOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FiTarget } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { MdCurrencyRupee, MdGroups } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import imageInput from "/src/assets/images/Logo.svg?import";
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import html2canvas from "/node_modules/.vite/deps/html2canvas.js?v=819e0a34";
const LoanCollectionIncentiveReport = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [dateSelectionMode, setDateSelectionMode] = useState("month");
  const [tempSelectedMonth, setTempSelectedMonth] = useState(null);
  const [tempFromDate, setTempFromDate] = useState(null);
  const [tempToDate, setTempToDate] = useState(null);
  const [incentivePercentage, setIncentivePercentage] = useState(1.5);
  const [loading, setLoading] = useState(false);
  const [loanData, setLoanData] = useState([]);
  const [loanSummary, setLoanSummary] = useState({
    total_collection: 0,
    total_incentive: 0,
    total_loans: 0,
    completed_loans: 0,
    pending_loans: 0
  });
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [selectedEmployeeDetails, setSelectedEmployeeDetails] = useState(null);
  const [isFiltering, setIsFiltering] = useState(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [signatureData, setSignatureData] = useState(null);
  const [agentSignatureData, setAgentSignatureData] = useState(null);
  useEffect(() => {
    const today2 = /* @__PURE__ */ new Date();
    const currentMonth2 = `${today2.getFullYear()}-${String(
      today2.getMonth() + 1
    ).padStart(2, "0")}`;
    setTempSelectedMonth(currentMonth2);
    const year = today2.getFullYear();
    const month = today2.getMonth() + 1;
    const firstDay = `${year}-${String(month).padStart(2, "0")}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    setTempFromDate(firstDay);
    setTempToDate(
      `${year}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`
    );
  }, []);
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const res = await api.get("/employee");
        setEmployees(res?.data?.employee || []);
      } catch (err) {
        console.error(err);
      }
    };
    fetchEmployees();
  }, []);
  const handleTempMonthChange = (e) => {
    const value = e.target.value;
    setTempSelectedMonth(value);
    if (value) {
      const [year, month] = value.split("-");
      const firstDay = `${year}-${month}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      setTempFromDate(firstDay);
      setTempToDate(`${year}-${month}-${String(lastDay).padStart(2, "0")}`);
    }
  };
  const fetchLoanCollectionData = async (employeeId, startDate, endDate) => {
    if (!employeeId || !startDate || !endDate) return;
    try {
      const response = await api.get(
        `/v1/admin/payments/loans/collection-agents/${employeeId}/${incentivePercentage}`,
        {
          params: {
            startDate,
            endDate
          }
        }
      );
      if (response.data && response.data.success) {
        const responseData = response.data.data || [];
        let allPayments = [];
        let totalCollection = 0;
        let totalIncentive = 0;
        responseData.forEach((item) => {
          if (item.payments && Array.isArray(item.payments)) {
            allPayments = [...allPayments, ...item.payments];
            totalCollection += item.total_payments || 0;
            totalIncentive += item.incentive_amount || 0;
          }
        });
        setLoanData(allPayments);
        setLoanSummary({
          total_collection: totalCollection,
          total_incentive: totalIncentive,
          total_loans: allPayments.length,
          completed_loans: allPayments.filter(
            (p) => p.status === "completed" || p.is_completed
          ).length,
          pending_loans: allPayments.filter(
            (p) => p.status !== "completed" && !p.is_completed
          ).length
        });
      } else {
        setLoanData([]);
        setLoanSummary({
          total_collection: 0,
          total_incentive: 0,
          total_loans: 0,
          completed_loans: 0,
          pending_loans: 0
        });
      }
    } catch (err) {
      console.error("Error fetching loan collection data:", err);
      setLoanData([]);
      setLoanSummary({
        total_collection: 0,
        total_incentive: 0,
        total_loans: 0,
        completed_loans: 0,
        pending_loans: 0
      });
    }
  };
  const handleContinue = async () => {
    if (!selectedEmployeeId) {
      message.warning("Please select an employee.");
      return;
    }
    if (dateSelectionMode === "month" && !tempSelectedMonth) {
      message.warning("Please select a month.");
      return;
    }
    if (dateSelectionMode === "date-range" && (!tempFromDate || !tempToDate)) {
      message.warning("Please select both From and To dates.");
      return;
    }
    setIsFiltering(true);
    setLoading(true);
    let startDate, endDate;
    if (dateSelectionMode === "month") {
      const [year, month] = tempSelectedMonth.split("-");
      startDate = `${year}-${month}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      endDate = `${year}-${month}-${String(lastDay).padStart(2, "0")}`;
      setFromDate(startDate);
      setToDate(endDate);
    } else {
      startDate = tempFromDate;
      endDate = tempToDate;
      setFromDate(startDate);
      setToDate(endDate);
    }
    try {
      const emp = employees.find((e) => e._id === selectedEmployeeId);
      setSelectedEmployeeDetails(emp || null);
      await fetchLoanCollectionData(selectedEmployeeId, startDate, endDate);
      message.success("Data loaded successfully!");
    } catch (error) {
      console.error("Error in handleContinue:", error);
      message.error("Failed to load data");
    } finally {
      setLoading(false);
    }
  };
  const numToWords = (num) => {
    if (isNaN(num) || num === 0) return "Zero";
    const a = [
      "",
      "One",
      "Two",
      "Three",
      "Four",
      "Five",
      "Six",
      "Seven",
      "Eight",
      "Nine",
      "Ten",
      "Eleven",
      "Twelve",
      "Thirteen",
      "Fourteen",
      "Fifteen",
      "Sixteen",
      "Seventeen",
      "Eighteen",
      "Nineteen"
    ];
    const b = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
    let numVal = num;
    numVal = Math.round(numVal);
    if ((numVal = numVal.toString()).length > 9) return "Overflow";
    const n = ("000000000" + numVal).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return "";
    let str = "";
    str += n[1] != 0 ? (a[Number(n[1])] || b[n[1][0]] + " " + a[n[1][1]]) + " Crore " : "";
    str += n[2] != 0 ? (a[Number(n[2])] || b[n[2][0]] + " " + a[n[2][1]]) + " Lakh " : "";
    str += n[3] != 0 ? (a[Number(n[3])] || b[n[3][0]] + " " + a[n[3][1]]) + " Thousand " : "";
    str += n[4] != 0 ? (a[Number(n[4])] || b[n[4][0]] + " " + a[n[4][1]]) + " Hundred " : "";
    str += n[5] != 0 ? (str != "" ? "and " : "") + (a[Number(n[5])] || b[n[5][0]] + " " + a[n[5][1]]) + " " : "";
    return str.trim() || "Zero";
  };
  const handleSignatureChange = (e, type) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === "manager") {
          setSignatureData(reader.result);
        } else {
          setAgentSignatureData(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };
  const generateIncentiveSlipContent = () => {
    const agent = selectedEmployeeDetails;
    const period = dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${tempSelectedMonth}-01`)).toLocaleString("default", { month: "long", year: "numeric" }) : `${fromDate} to ${toDate}`;
    const amountInWords = numToWords(loanSummary.total_incentive);
    const slipNumber = `INC-LOAN-${Date.now().toString().slice(-6)}`;
    const currentDate = (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
    const logoUrl = imageInput.startsWith("http") ? imageInput : window.location.origin + imageInput;
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Loan Incentive Slip - ${agent?.name || "Agent"}</title>
        <style>
          @page { 
            size: A4; 
            margin: 0;
          }
          
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          
          body { 
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; 
            background-color: #ffffff;
            margin: 0;
            padding: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          
          .document-container {
            width: 210mm;
            min-height: 297mm;
            margin: 0 auto;
            background: white;
            position: relative;
            page-break-after: avoid;
            page-break-inside: avoid;
          }
          
          /* Header Section */
          .header-section {
            background: linear-gradient(135deg, #00267C 0%, #003d9e 100%);
            padding: 20px 25px;
            color: white;
          }
          
          .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
          }
          
          .logo-area img {
            height: 60px;
            width: auto;
            object-fit: contain;
          }
          
          .company-info {
            text-align: center;
            flex: 1;
          }
          
          .company-name {
            font-size: 24px;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 3px;
          }
          
          .company-tagline {
            font-size: 10px;
            opacity: 0.9;
          }
          
          .document-meta {
            text-align: right;
            font-size: 11px;
            border-left: 1px solid rgba(255,255,255,0.3);
            padding-left: 15px;
          }
          
          .meta-item {
            margin-bottom: 3px;
          }
          
          .meta-label {
            font-weight: 600;
            opacity: 0.8;
          }
          
          /* Title Section */
          .title-section {
            background: #f8f9fa;
            padding: 12px 20px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
          }
          
          .document-title {
            font-size: 20px;
            font-weight: 700;
            color: #00267C;
            text-transform: uppercase;
          }
          
          /* Content Sections */
          .content-section {
            padding: 15px 25px;
          }
          
          .info-card {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            margin-bottom: 15px;
            overflow: hidden;
          }
          
          .card-header {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 10px 15px;
            border-bottom: 2px solid #00267C;
          }
          
          .card-header h3 {
            color: #00267C;
            font-size: 14px;
            font-weight: 700;
            margin: 0;
            text-transform: uppercase;
          }
          
          .card-body {
            padding: 12px 15px;
          }
          
          .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
          }
          
          .info-row {
            display: flex;
            flex-direction: column;
          }
          
          .info-label {
            font-size: 10px;
            font-weight: 600;
            color: #6c757d;
            text-transform: uppercase;
            margin-bottom: 3px;
          }
          
          .info-value {
            font-size: 13px;
            font-weight: 500;
            color: #212529;
          }
          
          /* Table Styles */
          .summary-table {
            width: 100%;
            border-collapse: collapse;
          }
          
          .summary-table tr {
            border-bottom: 1px solid #e9ecef;
          }
          
          .summary-table td {
            padding: 8px 5px;
            font-size: 12px;
          }
          
          .summary-table td:first-child {
            font-weight: 500;
            color: #495057;
          }
          
          .summary-table td:last-child {
            text-align: right;
            font-weight: 600;
            color: #212529;
          }
          
          .total-row {
            background: #e8f0fe;
          }
          
          .total-row td {
            font-weight: 700 !important;
            color: #00267C !important;
          }
          
          /* Highlight Box */
          .highlight-box {
            background: linear-gradient(135deg, #e8f0fe 0%, #d4e2f7 100%);
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            margin-top: 12px;
          }
          
          .highlight-label {
            font-size: 11px;
            font-weight: 600;
            color: #00267C;
            text-transform: uppercase;
            margin-bottom: 5px;
          }
          
          .highlight-amount {
            font-size: 28px;
            font-weight: 800;
            color: #00267C;
            margin: 5px 0;
          }
          
          .highlight-words {
            font-size: 10px;
            color: #495057;
            font-style: italic;
            border-top: 1px dashed #00267C40;
            padding-top: 8px;
            margin-top: 5px;
          }
          
          /* Declaration */
          .declaration-box {
            background: #f8f9fa;
            border-left: 3px solid #00267C;
            padding: 10px 15px;
            margin: 12px 0;
            font-size: 10px;
            color: #495057;
            line-height: 1.4;
          }
          
          /* Signature Section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            padding-top: 15px;
          }
          
          .signature-box {
            text-align: center;
            width: 45%;
          }
          
          .signature-image {
            max-height: 50px;
            margin-bottom: 8px;
            object-fit: contain;
          }
          
          .signature-line {
            border-top: 1px solid #212529;
            padding-top: 6px;
            font-size: 10px;
            font-weight: 600;
            color: #6c757d;
          }
          
          /* Footer */
          .footer-section {
            background: linear-gradient(135deg, #00267C 0%, #003d9e 100%);
            padding: 10px 20px;
            text-align: center;
            color: white;
            font-size: 8px;
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
          }
          
          .footer-company {
            font-weight: 700;
            margin-bottom: 3px;
          }
          
          .footer-address {
            opacity: 0.8;
            margin-bottom: 3px;
          }
          
          .footer-contact {
            opacity: 0.7;
          }
          
          @media print {
            body {
              background: white;
              padding: 0;
              margin: 0;
            }
            .document-container {
              box-shadow: none;
              page-break-after: avoid;
              page-break-inside: avoid;
            }
            .header-section, .footer-section {
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
          }
        </style>
      </head>
      <body>
        <div class="document-container">
          <!-- Header Section -->
          <div class="header-section">
            <div class="header-content">
              <div class="logo-area">
                <img src="${logoUrl}" alt="MyChits Logo" onerror="this.src='data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' fill='%2300267C'/%3E%3Ctext x='50' y='50' text-anchor='middle' dy='.3em' fill='white' font-size='14' font-family='Arial'%3EMC%3C/text%3E%3C/svg%3E'">
              </div>
              <div class="company-info">
                <div class="company-name">MYCHITS</div>
                <div class="company-tagline">Chit Funds • Loans • Investments</div>
              </div>
              <div class="document-meta">
                <div class="meta-item">
                  <span class="meta-label">Date:</span> ${currentDate}
                </div>
                
              </div>
            </div>
          </div>
          
          <!-- Title Section -->
          <div class="title-section">
            <div class="document-title">Loan Collection Incentive Slip</div>
          </div>
          
          <!-- Content Section -->
          <div class="content-section">
            <!-- Agent Details Card -->
            <div class="info-card">
              <div class="card-header">
                <h3>Agent / Employee Details</h3>
              </div>
              <div class="card-body">
                <div class="info-grid">
                  <div class="info-row">
                    <span class="info-label">Agent Name</span>
                    <span class="info-value">${agent?.name || "N/A"}</span>
                  </div>
                  <div class="info-row">
                    <span class="info-label">Employee ID</span>
                    <span class="info-value">${agent?.employeeCode || agent?._id?.slice(-6) || "N/A"}</span>
                  </div>
                  <div class="info-row">
                    <span class="info-label">Phone Number</span>
                    <span class="info-value">${agent?.phone_number || "N/A"}</span>
                  </div>
                  <div class="info-row">
                    <span class="info-label">Reporting Period</span>
                    <span class="info-value">${period}</span>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Collection Summary Card -->
            <div class="info-card">
              <div class="card-header">
                <h3>Collection & Incentive Summary</h3>
              </div>
              <div class="card-body">
                <table class="summary-table">
                  <tbody>
                    <tr>
                      <td>Total Collection Amount</td>
                      <td>₹${loanSummary.total_collection?.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</td>
                    </tr>
                    <tr>
                      <td>Incentive Percentage Rate</td>
                      <td>${incentivePercentage}%</td>
                    </tr>
                    <tr>
                      <td>Total Transactions (Records)</td>
                      <td>${loanData.length}</td>
                    </tr>
                    <tr>
                      <td>Completed Loans</td>
                      <td>${loanSummary.completed_loans}</td>
                    </tr>
                    <tr>
                      <td>Pending Loans</td>
                      <td>${loanSummary.pending_loans}</td>
                    </tr>
                    <tr class="total-row">
                      <td style="font-weight: 700;">Gross Incentive Earned</td>
                      <td style="font-weight: 700; color: #00267C;">₹${loanSummary.total_incentive?.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</td>
                    </tr>
                  </tbody>
                </table>
                
                <!-- Highlight Box -->
                <div class="highlight-box">
                  <div class="highlight-label">Net Payable Amount</div>
                  <div class="highlight-amount">₹${loanSummary.total_incentive?.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</div>
                  <div class="highlight-words">
                    Rupees ${amountInWords} Only
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Declaration -->
            <div class="declaration-box">
              <strong>Declaration:</strong> This is a computer-generated incentive slip. The details contained herein are true to the best of our knowledge. Any discrepancy should be reported to the accounts department within 48 hours of receipt.
            </div>
            
            <!-- Signature Section -->
            <div class="signature-section">
              <div class="signature-box">
                ${agentSignatureData ? `<img src="${agentSignatureData}" class="signature-image" alt="Agent Sign">` : ""}
                <div class="signature-line">Agent's Signature</div>
              </div>
              <div class="signature-box">
                ${signatureData ? `<img src="${signatureData}" class="signature-image" alt="Manager Sign">` : ""}
                <div class="signature-line">Authorized Signatory</div>
              </div>
            </div>
          </div>
          
          <!-- Footer Section -->
          <div class="footer-section">
            <div class="footer-company">VIJAYA VINAYAK CHIT FUNDS PRIVATE LIMITED</div>
            <div class="footer-address">#11/36-25, 3rd Floor, 2nd Main, Kathriguppe Main Road, Banashankari 3rd Stage, Bengaluru-560085</div>
            <div class="footer-contact">Mob: 9483900777 | Ph: 080-4979 8763 | Email: info.mychits@gmail.com</div>
          </div>
        </div>
      </body>
      </html>
    `;
  };
  const handleGenerateSlip = async () => {
    if (!selectedEmployeeDetails) {
      message.warning("Please load employee data first by clicking Continue.");
      return;
    }
    setIsGeneratingPDF(true);
    try {
      const htmlContent = generateIncentiveSlipContent();
      const agent = selectedEmployeeDetails;
      const period = dateSelectionMode === "month" ? tempSelectedMonth : `${fromDate}_to_${toDate}`;
      const fileName = `Loan_Incentive_Slip_${agent?.name || "Agent"}_${period}.pdf`;
      const tempDiv = document.createElement("div");
      tempDiv.style.position = "absolute";
      tempDiv.style.left = "-9999px";
      tempDiv.style.top = "-9999px";
      tempDiv.style.width = "210mm";
      tempDiv.style.backgroundColor = "#ffffff";
      tempDiv.innerHTML = htmlContent;
      document.body.appendChild(tempDiv);
      await new Promise((r) => setTimeout(r, 800));
      const canvas = await html2canvas(tempDiv, {
        scale: 3,
        useCORS: true,
        backgroundColor: "#ffffff",
        logging: false,
        windowWidth: 800,
        allowTaint: false,
        foreignObjectRendering: false
      });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const pageWidth = 210;
      const imgWidth = pageWidth;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      pdf.save(fileName);
      document.body.removeChild(tempDiv);
      message.success("Loan Incentive Slip downloaded successfully!");
    } catch (error) {
      console.error("Error generating PDF:", error);
      message.error("Failed to generate incentive slip");
    } finally {
      setIsGeneratingPDF(false);
    }
  };
  const handlePrintSlip = () => {
    if (!selectedEmployeeDetails) {
      message.warning("Please load employee data first by clicking Continue.");
      return;
    }
    const htmlContent = generateIncentiveSlipContent();
    const agent = selectedEmployeeDetails;
    const period = dateSelectionMode === "month" ? tempSelectedMonth : `${fromDate}_to_${toDate}`;
    const fileName = `Loan_Incentive_Slip_${agent?.name || "Agent"}_${period}`;
    const printWindow = window.open("", "_blank");
    printWindow.document.write(htmlContent);
    printWindow.document.title = fileName;
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 500);
  };
  const processedTableData = loanData.map((payment, index) => ({
    key: payment._id || index,
    sno: index + 1,
    customer_name: payment.user_id?.full_name || "N/A",
    phone_number: payment.user_id?.phone_number || "N/A",
    loan_id: payment.loan?.loan_id || "N/A",
    loan_amount: payment?.loan?.loan_amount || payment.principal_amount || 0,
    emi_amount: payment?.loan?.daily_payment_amount || payment.monthly_installment || 0,
    paid_amount: payment.paid_amount || payment.amount || 0,
    transaction_date: payment?.createdAt?.split("T")[0] || "N/A",
    pay_date: payment?.pay_date || "N/A",
    payment_mode: payment.pay_type || payment.mode || "N/A",
    receipt_no: payment?.receipt_no || "N/A"
  }));
  const columns = [
    { key: "sno", header: "SL.No" },
    { key: "pay_date", header: "Payment Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "loan_id", header: "Loan ID" },
    { key: "loan_amount", header: "Loan Amount (₹)" },
    { key: "paid_amount", header: "Paid Amount (₹)" },
    { key: "payment_mode", header: "Payment Mode" },
    { key: "receipt_no", header: "Receipt No" }
  ];
  const today = /* @__PURE__ */ new Date();
  const currentMonth = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}`;
  const selectedEmployee = employees.find(
    (emp) => emp._id === selectedEmployeeId
  );
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent", children: "Loan Collection Incentive Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 836,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2 text-lg", children: "Track and manage employee incentives and commissions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 839,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 835,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-full p-3 shadow-md", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-3xl text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 844,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 843,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 834,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 833,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl overflow-hidden mt-6 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(FiTarget, { className: "text-blue-600", size: 18 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 852,
            columnNumber: 13
          }, this),
          "Quick Navigation to Other Reports"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 851,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "Explore other incentive reports" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 855,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 850,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/reports/target-incentive-new",
            className: "group relative overflow-hidden bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-blue-400 hover:shadow-lg transition-all duration-300",
            children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-100 rounded-lg group-hover:bg-blue-500 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
                FiTarget,
                {
                  className: "text-blue-600 group-hover:text-white transition-colors duration-300",
                  size: 22
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 868,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 867,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 group-hover:text-blue-600 transition-colors", children: "Chit Business Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 874,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "View chit-based incentives" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 877,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 873,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV(
                "svg",
                {
                  className: "w-5 h-5 text-blue-600",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                  children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M9 5l7 7-7 7"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                      lineNumber: 888,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 882,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 881,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 866,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 862,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/reports/pigmycollection-incentive",
            className: "group relative overflow-hidden bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-green-400 hover:shadow-lg transition-all duration-300",
            children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-green-100 rounded-lg group-hover:bg-green-500 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
                FaRupeeSign,
                {
                  className: "text-green-600 group-hover:text-white transition-colors duration-300",
                  size: 22
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 905,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 904,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 group-hover:text-green-600 transition-colors", children: "Pigmy Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 911,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "Track pigmy collections" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 914,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 910,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV(
                "svg",
                {
                  className: "w-5 h-5 text-green-600",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                  children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M9 5l7 7-7 7"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                      lineNumber: 925,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 919,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 918,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 903,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 899,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/reports/chitcollection-incentive",
            className: "group relative overflow-hidden bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-blue-400 hover:shadow-lg transition-all duration-300",
            children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-100 rounded-lg group-hover:bg-blue-500 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
                MdGroups,
                {
                  className: "text-blue-600 group-hover:text-white transition-colors duration-300",
                  size: 22
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 943,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 942,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 group-hover:text-blue-600 transition-colors", children: "Chit Collection Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 949,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "Track Chit collections" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 952,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 948,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV(
                "svg",
                {
                  className: "w-5 h-5 text-green-600",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                  children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M9 5l7 7-7 7"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                      lineNumber: 963,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 957,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 956,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 941,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 937,
            columnNumber: 14
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 861,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 860,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 849,
      columnNumber: 8
    }, this),
    /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg hover:shadow-xl transition-shadow", children: /* @__PURE__ */ jsxDEV("div", { className: "h-[100px] flex items-center", children: /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Total Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 982,
            columnNumber: 24
          }, this),
          value: loanSummary.total_collection,
          precision: 2,
          prefix: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-green-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 985,
            columnNumber: 25
          }, this),
          valueStyle: { color: "#3f8600", fontSize: "24px" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 981,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 980,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 979,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 978,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg hover:shadow-xl transition-shadow", children: /* @__PURE__ */ jsxDEV("div", { className: "h-[100px] flex items-center", children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-center", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 997,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 996,
        columnNumber: 15
      }, this) : /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Total Incentive" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1001,
            columnNumber: 24
          }, this),
          value: loanSummary.total_incentive,
          precision: 2,
          prefix: /* @__PURE__ */ jsxDEV(RiseOutlined, { className: "text-blue-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1004,
            columnNumber: 25
          }, this),
          valueStyle: { color: "#1890ff", fontSize: "24px" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1e3,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 994,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 993,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 992,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg hover:shadow-xl transition-shadow", children: /* @__PURE__ */ jsxDEV("div", { className: "h-[100px] flex items-center", children: /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Total Records" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1016,
            columnNumber: 24
          }, this),
          value: loanSummary.total_loans,
          prefix: /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-purple-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1018,
            columnNumber: 25
          }, this),
          valueStyle: { color: "#722ed1", fontSize: "24px" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1015,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1014,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1013,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1012,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 977,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 border-b border-gray-100", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(FileSearchOutlined, { className: "text-blue-500" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1029,
          columnNumber: 13
        }, this),
        "Report Filters"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1028,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1027,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 mb-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-blue-500 text-xs" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1038,
                columnNumber: 17
              }, this),
              "Date Selection Mode"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1037,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Radio.Group,
              {
                value: dateSelectionMode,
                onChange: (e) => setDateSelectionMode(e.target.value),
                size: "small",
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(
                    Radio.Button,
                    {
                      value: "month",
                      style: { width: "50%", textAlign: "center" },
                      children: "Monthly"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                      lineNumber: 1047,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Radio.Button,
                    {
                      value: "date-range",
                      style: { width: "50%", textAlign: "center" },
                      children: "Date Range"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                      lineNumber: 1053,
                      columnNumber: 17
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1041,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1036,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-500 text-xs" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1064,
                columnNumber: 17
              }, this),
              "Select Employee"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1063,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedEmployeeId || void 0,
                onChange: setSelectedEmployeeId,
                showSearch: true,
                placeholder: "Search by name or phone",
                size: "middle",
                className: "w-full",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                children: employees.map(
                  (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                    emp.name,
                    " - ",
                    emp.phone_number
                  ] }, emp._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                    lineNumber: 1082,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1067,
                columnNumber: 15
              },
              this
            ),
            selectedEmployee && /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-gray-500", children: [
              "Selected: ",
              selectedEmployee.name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1088,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1062,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1035,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1", children: dateSelectionMode === "month" ? "Select Month" : "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1097,
              columnNumber: 15
            }, this),
            dateSelectionMode === "month" ? /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "month",
                value: tempSelectedMonth || "",
                max: currentMonth,
                onChange: handleTempMonthChange,
                className: "w-full px-2 py-1.5 text-sm border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1101,
                columnNumber: 15
              },
              this
            ) : /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: tempFromDate || "",
                onChange: (e) => setTempFromDate(e.target.value),
                className: "w-full px-2 py-1.5 text-sm border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1109,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1096,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(PercentageOutlined, { className: "text-blue-500 text-xs" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1120,
                columnNumber: 17
              }, this),
              "Incentive Percentage"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1119,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  step: "0.1",
                  min: "0",
                  value: incentivePercentage,
                  onChange: (e) => setIncentivePercentage(e.target.value),
                  className: "w-full px-2 py-1.5 text-sm border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 pr-7"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                  lineNumber: 1124,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 text-xs", children: "%" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1132,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1123,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1118,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1095,
          columnNumber: 11
        }, this),
        dateSelectionMode === "date-range" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 mb-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1", children: "To Date" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1142,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              value: tempToDate || "",
              onChange: (e) => setTempToDate(e.target.value),
              className: "w-full px-2 py-1.5 text-sm border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1145,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1141,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1140,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 mt-2 pt-3 border-t border-gray-100", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "medium",
              onClick: () => {
                setSelectedEmployeeId(null);
                setSelectedEmployeeDetails(null);
                setTempSelectedMonth(currentMonth);
                setIncentivePercentage(1.5);
                setLoanData([]);
                setLoanSummary({
                  total_collection: 0,
                  total_incentive: 0,
                  total_loans: 0,
                  completed_loans: 0,
                  pending_loans: 0
                });
                setIsFiltering(false);
                const today2 = /* @__PURE__ */ new Date();
                const year = today2.getFullYear();
                const month = today2.getMonth() + 1;
                const firstDay = `${year}-${String(month).padStart(2, "0")}-01`;
                const lastDay = new Date(year, month, 0).getDate();
                setTempFromDate(firstDay);
                setTempToDate(
                  `${year}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`
                );
              },
              children: "Reset"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1156,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              size: "medium",
              icon: /* @__PURE__ */ jsxDEV(FileSearchOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1188,
                columnNumber: 21
              }, this),
              loading,
              onClick: handleContinue,
              className: "px-8 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold shadow-sm",
              children: "Continue"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1185,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1155,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1034,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 1026,
      columnNumber: 7
    }, this),
    isFiltering && selectedEmployeeDetails && /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1205,
            columnNumber: 15
          }, this),
          "Employee Information"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1204,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Space, { children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              icon: /* @__PURE__ */ jsxDEV(PrinterOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1210,
                columnNumber: 21
              }, this),
              onClick: handlePrintSlip,
              className: "bg-gray-600 text-white hover:bg-gray-700",
              children: "Print Slip"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1209,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              icon: /* @__PURE__ */ jsxDEV(DownloadOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
                lineNumber: 1218,
                columnNumber: 21
              }, this),
              loading: isGeneratingPDF,
              onClick: handleGenerateSlip,
              className: "bg-green-600 hover:bg-green-700",
              children: "Generate Slip"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1216,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1208,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1203,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Name" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1230,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-900 font-medium mt-1", children: selectedEmployeeDetails?.name || "-" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1233,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1229,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Email" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1238,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-900 font-medium mt-1", children: selectedEmployeeDetails?.email || "-" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1241,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1237,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Phone" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1246,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-900 font-medium mt-1", children: selectedEmployeeDetails?.phone_number || "-" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1249,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1245,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1228,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1227,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 1202,
      columnNumber: 7
    }, this),
    isFiltering && loanData.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-green-50 to-emerald-50 border-b", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1263,
          columnNumber: 15
        }, this),
        "Collection Summary"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1262,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1261,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Period" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1271,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-blue-700 mt-1", children: dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${tempSelectedMonth}-01`)).toLocaleString(
            "default",
            {
              month: "long",
              year: "numeric"
            }
          ) : `${fromDate} to ${toDate}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1274,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1270,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Incentive Rate" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1288,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-green-700 mt-1", children: [
            incentivePercentage,
            "%"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1291,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1287,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Total Records" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1297,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-purple-700 mt-1", children: loanData.length }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1300,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1296,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Total Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1306,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-green-700 mt-1 flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV(FaRupeeSign, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1310,
              columnNumber: 19
            }, this),
            loanSummary.total_collection?.toFixed(2)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1309,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1305,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Total Incentive" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1316,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-blue-700 mt-1 flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV(RiseOutlined, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
              lineNumber: 1320,
              columnNumber: 19
            }, this),
            loanSummary.total_incentive?.toFixed(2)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1319,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1315,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1269,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1268,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 1260,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 1331,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 1330,
      columnNumber: 7
    }, this) : isFiltering && loanData.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(FileSearchOutlined, { className: "text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
            lineNumber: 1339,
            columnNumber: 17
          }, this),
          "Payment Details"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1338,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: [
          "Showing ",
          loanData.length,
          " payment records"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1342,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1337,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: processedTableData,
          columns,
          exportedPdfName: `Loan_Collection_Incentive_Report`,
          printHeaderKeys: [
            "Employee Name",
            "Phone Number",
            "Period",
            "Incentive Percentage",
            "Total Collection",
            "Total Incentive",
            "Total Records"
          ],
          printHeaderValues: [
            selectedEmployeeDetails?.name || "-",
            selectedEmployeeDetails?.phone_number || "-",
            dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${tempSelectedMonth}-01`)).toLocaleString(
              "default",
              {
                month: "long",
                year: "numeric"
              }
            ) : `${fromDate} to ${toDate}`,
            `${incentivePercentage}%`,
            `₹${loanSummary.total_collection?.toLocaleString("en-IN") || "0"}`,
            `₹${loanSummary.total_incentive?.toLocaleString("en-IN") || "0"}`,
            loanData.length || "0"
          ],
          exportedFileName: `LoanCollectionReport_${selectedEmployeeDetails?.name || "all"}_${dateSelectionMode === "month" ? tempSelectedMonth : `${fromDate}_to_${toDate}`}.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
          lineNumber: 1347,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
        lineNumber: 1346,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 1336,
      columnNumber: 7
    }, this),
    isFiltering && !loading && loanData.length === 0 && /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "p-12 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-lg font-medium", children: "No payment records found for the selected period." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 1391,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 1390,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
      lineNumber: 1389,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx",
    lineNumber: 832,
    columnNumber: 5
  }, this);
};
_s(LoanCollectionIncentiveReport, "VwXnPcMxguOIW4fasOvopzZ9oL4=");
_c = LoanCollectionIncentiveReport;
export default LoanCollectionIncentiveReport;
var _c;
$RefreshReg$(_c, "LoanCollectionIncentiveReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCollectionIncentiveReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbTBCWTsyQkFuMEJaO0FBQWdCQSxNQUFXQyxjQUFRLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1A7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsaUJBQWdCQyxnQkFBZ0I7QUFDekMsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsaUJBQWlCO0FBRXhCLE1BQU1DLGdDQUFnQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQzFDLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJakMsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2tDLG9CQUFvQkMscUJBQXFCLElBQUluQyxTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDb0MsbUJBQW1CQyxvQkFBb0IsSUFBSXJDLFNBQVMsT0FBTztBQUNsRSxRQUFNLENBQUNzQyxtQkFBbUJDLG9CQUFvQixJQUFJdkMsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQ3dDLGNBQWNDLGVBQWUsSUFBSXpDLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUMwQyxZQUFZQyxhQUFhLElBQUkzQyxTQUFTLElBQUk7QUFDakQsUUFBTSxDQUFDNEMscUJBQXFCQyxzQkFBc0IsSUFBSTdDLFNBQVMsR0FBRztBQUNsRSxRQUFNLENBQUM4QyxTQUFTQyxVQUFVLElBQUkvQyxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDZ0QsVUFBVUMsV0FBVyxJQUFJakQsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2tELGFBQWFDLGNBQWMsSUFBSW5ELFNBQVM7QUFBQSxJQUM3Q29ELGtCQUFrQjtBQUFBLElBQ2xCQyxpQkFBaUI7QUFBQSxJQUNqQkMsYUFBYTtBQUFBLElBQ2JDLGlCQUFpQjtBQUFBLElBQ2pCQyxlQUFlO0FBQUEsRUFDakIsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJMUQsU0FBUyxJQUFJO0FBQzdDLFFBQU0sQ0FBQzJELFFBQVFDLFNBQVMsSUFBSTVELFNBQVMsSUFBSTtBQUN6QyxRQUFNLENBQUM2RCx5QkFBeUJDLDBCQUEwQixJQUFJOUQsU0FBUyxJQUFJO0FBQzNFLFFBQU0sQ0FBQytELGFBQWFDLGNBQWMsSUFBSWhFLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNpRSxpQkFBaUJDLGtCQUFrQixJQUFJbEUsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ21FLGVBQWVDLGdCQUFnQixJQUFJcEUsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ3FFLG9CQUFvQkMscUJBQXFCLElBQUl0RSxTQUFTLElBQUk7QUFFakVELFlBQVUsTUFBTTtBQUNkLFVBQU13RSxTQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFVBQU1DLGdCQUFlLEdBQUdGLE9BQU1HLFlBQVksQ0FBQyxJQUFJQztBQUFBQSxNQUM3Q0osT0FBTUssU0FBUyxJQUFJO0FBQUEsSUFDckIsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUVsQnRDLHlCQUFxQmtDLGFBQVk7QUFFakMsVUFBTUssT0FBT1AsT0FBTUcsWUFBWTtBQUMvQixVQUFNSyxRQUFRUixPQUFNSyxTQUFTLElBQUk7QUFDakMsVUFBTUksV0FBVyxHQUFHRixJQUFJLElBQUlILE9BQU9JLEtBQUssRUFBRUYsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUMxRCxVQUFNSSxVQUFVLElBQUlULEtBQUtNLE1BQU1DLE9BQU8sQ0FBQyxFQUFFRyxRQUFRO0FBRWpEekMsb0JBQWdCdUMsUUFBUTtBQUN4QnJDO0FBQUFBLE1BQ0UsR0FBR21DLElBQUksSUFBSUgsT0FBT0ksS0FBSyxFQUFFRixTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUlGLE9BQU9NLE9BQU8sRUFBRUosU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUFBLElBQy9FO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTDlFLFlBQVUsTUFBTTtBQUNkLFVBQU1vRixpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTUMsTUFBTSxNQUFNakUsSUFBSWtFLElBQUksV0FBVztBQUNyQ3BELHFCQUFhbUQsS0FBS0UsTUFBTUMsWUFBWSxFQUFFO0FBQUEsTUFDeEMsU0FBU0MsS0FBSztBQUNaQyxnQkFBUUMsTUFBTUYsR0FBRztBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUNBTCxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMLFFBQU1RLHdCQUF3QkEsQ0FBQ0MsTUFBTTtBQUNuQyxVQUFNQyxRQUFRRCxFQUFFRSxPQUFPRDtBQUN2QnRELHlCQUFxQnNELEtBQUs7QUFDMUIsUUFBSUEsT0FBTztBQUNULFlBQU0sQ0FBQ2YsTUFBTUMsS0FBSyxJQUFJYyxNQUFNRSxNQUFNLEdBQUc7QUFDckMsWUFBTWYsV0FBVyxHQUFHRixJQUFJLElBQUlDLEtBQUs7QUFDakMsWUFBTUUsVUFBVSxJQUFJVCxLQUFLTSxNQUFNQyxPQUFPLENBQUMsRUFBRUcsUUFBUTtBQUNqRHpDLHNCQUFnQnVDLFFBQVE7QUFDeEJyQyxvQkFBYyxHQUFHbUMsSUFBSSxJQUFJQyxLQUFLLElBQUlKLE9BQU9NLE9BQU8sRUFBRUosU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFO0FBQUEsSUFDdEU7QUFBQSxFQUNGO0FBRUEsUUFBTW1CLDBCQUEwQixPQUFPQyxZQUFZQyxXQUFXQyxZQUFZO0FBQ3hFLFFBQUksQ0FBQ0YsY0FBYyxDQUFDQyxhQUFhLENBQUNDLFFBQVM7QUFFM0MsUUFBSTtBQUNGLFlBQU1DLFdBQVcsTUFBTWpGLElBQUlrRTtBQUFBQSxRQUN6Qiw4Q0FBOENZLFVBQVUsSUFBSXJELG1CQUFtQjtBQUFBLFFBQy9FO0FBQUEsVUFDRXlELFFBQVE7QUFBQSxZQUNOSDtBQUFBQSxZQUNBQztBQUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxVQUFJQyxTQUFTZCxRQUFRYyxTQUFTZCxLQUFLZ0IsU0FBUztBQUMxQyxjQUFNQyxlQUFlSCxTQUFTZCxLQUFLQSxRQUFRO0FBRTNDLFlBQUlrQixjQUFjO0FBQ2xCLFlBQUlDLGtCQUFrQjtBQUN0QixZQUFJQyxpQkFBaUI7QUFFckJILHFCQUFhSSxRQUFRLENBQUNDLFNBQVM7QUFDN0IsY0FBSUEsS0FBS0MsWUFBWUMsTUFBTUMsUUFBUUgsS0FBS0MsUUFBUSxHQUFHO0FBQ2pETCwwQkFBYyxDQUFDLEdBQUdBLGFBQWEsR0FBR0ksS0FBS0MsUUFBUTtBQUMvQ0osK0JBQW1CRyxLQUFLSSxrQkFBa0I7QUFDMUNOLDhCQUFrQkUsS0FBS0ssb0JBQW9CO0FBQUEsVUFDN0M7QUFBQSxRQUNGLENBQUM7QUFFRGhFLG9CQUFZdUQsV0FBVztBQUN2QnJELHVCQUFlO0FBQUEsVUFDYkMsa0JBQWtCcUQ7QUFBQUEsVUFDbEJwRCxpQkFBaUJxRDtBQUFBQSxVQUNqQnBELGFBQWFrRCxZQUFZVTtBQUFBQSxVQUN6QjNELGlCQUFpQmlELFlBQVlXO0FBQUFBLFlBQzNCLENBQUNDLE1BQU1BLEVBQUVDLFdBQVcsZUFBZUQsRUFBRUU7QUFBQUEsVUFDdkMsRUFBRUo7QUFBQUEsVUFDRjFELGVBQWVnRCxZQUFZVztBQUFBQSxZQUN6QixDQUFDQyxNQUFNQSxFQUFFQyxXQUFXLGVBQWUsQ0FBQ0QsRUFBRUU7QUFBQUEsVUFDeEMsRUFBRUo7QUFBQUEsUUFDSixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0xqRSxvQkFBWSxFQUFFO0FBQ2RFLHVCQUFlO0FBQUEsVUFDYkMsa0JBQWtCO0FBQUEsVUFDbEJDLGlCQUFpQjtBQUFBLFVBQ2pCQyxhQUFhO0FBQUEsVUFDYkMsaUJBQWlCO0FBQUEsVUFDakJDLGVBQWU7QUFBQSxRQUNqQixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU2dDLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSx3Q0FBd0NGLEdBQUc7QUFDekR2QyxrQkFBWSxFQUFFO0FBQ2RFLHFCQUFlO0FBQUEsUUFDYkMsa0JBQWtCO0FBQUEsUUFDbEJDLGlCQUFpQjtBQUFBLFFBQ2pCQyxhQUFhO0FBQUEsUUFDYkMsaUJBQWlCO0FBQUEsUUFDakJDLGVBQWU7QUFBQSxNQUNqQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0QsaUJBQWlCLFlBQVk7QUFDakMsUUFBSSxDQUFDckYsb0JBQW9CO0FBQ3ZCekIsY0FBUStHLFFBQVEsNEJBQTRCO0FBQzVDO0FBQUEsSUFDRjtBQUVBLFFBQUlwRixzQkFBc0IsV0FBVyxDQUFDRSxtQkFBbUI7QUFDdkQ3QixjQUFRK0csUUFBUSx3QkFBd0I7QUFDeEM7QUFBQSxJQUNGO0FBRUEsUUFBSXBGLHNCQUFzQixpQkFBaUIsQ0FBQ0ksZ0JBQWdCLENBQUNFLGFBQWE7QUFDeEVqQyxjQUFRK0csUUFBUSx1Q0FBdUM7QUFDdkQ7QUFBQSxJQUNGO0FBRUF4RCxtQkFBZSxJQUFJO0FBQ25CakIsZUFBVyxJQUFJO0FBRWYsUUFBSW1ELFdBQVdDO0FBRWYsUUFBSS9ELHNCQUFzQixTQUFTO0FBQ2pDLFlBQU0sQ0FBQzBDLE1BQU1DLEtBQUssSUFBSXpDLGtCQUFrQnlELE1BQU0sR0FBRztBQUNqREcsa0JBQVksR0FBR3BCLElBQUksSUFBSUMsS0FBSztBQUM1QixZQUFNRSxVQUFVLElBQUlULEtBQUtNLE1BQU1DLE9BQU8sQ0FBQyxFQUFFRyxRQUFRO0FBQ2pEaUIsZ0JBQVUsR0FBR3JCLElBQUksSUFBSUMsS0FBSyxJQUFJSixPQUFPTSxPQUFPLEVBQUVKLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDOURuQixrQkFBWXdDLFNBQVM7QUFDckJ0QyxnQkFBVXVDLE9BQU87QUFBQSxJQUNuQixPQUFPO0FBQ0xELGtCQUFZMUQ7QUFDWjJELGdCQUFVekQ7QUFDVmdCLGtCQUFZd0MsU0FBUztBQUNyQnRDLGdCQUFVdUMsT0FBTztBQUFBLElBQ25CO0FBRUEsUUFBSTtBQUNGLFlBQU1zQixNQUFNekYsVUFBVTBGLEtBQUssQ0FBQzlCLE1BQU1BLEVBQUUrQixRQUFRekYsa0JBQWtCO0FBQzlENEIsaUNBQTJCMkQsT0FBTyxJQUFJO0FBQ3RDLFlBQU16Qix3QkFBd0I5RCxvQkFBb0JnRSxXQUFXQyxPQUFPO0FBQ3BFMUYsY0FBUTZGLFFBQVEsMkJBQTJCO0FBQUEsSUFDN0MsU0FBU1osT0FBTztBQUNkRCxjQUFRQyxNQUFNLDRCQUE0QkEsS0FBSztBQUMvQ2pGLGNBQVFpRixNQUFNLHFCQUFxQjtBQUFBLElBQ3JDLFVBQUM7QUFDQzNDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNNkUsYUFBYUEsQ0FBQ0MsUUFBUTtBQUMxQixRQUFJQyxNQUFNRCxHQUFHLEtBQUtBLFFBQVEsRUFBRyxRQUFPO0FBRXBDLFVBQU1FLElBQUk7QUFBQSxNQUNSO0FBQUEsTUFBSTtBQUFBLE1BQU87QUFBQSxNQUFPO0FBQUEsTUFBUztBQUFBLE1BQVE7QUFBQSxNQUFRO0FBQUEsTUFBTztBQUFBLE1BQVM7QUFBQSxNQUFTO0FBQUEsTUFDcEU7QUFBQSxNQUFPO0FBQUEsTUFBVTtBQUFBLE1BQVU7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVc7QUFBQSxNQUM5RDtBQUFBLE1BQWE7QUFBQSxNQUFZO0FBQUEsSUFBVTtBQUVyQyxVQUFNQyxJQUFJLENBQUMsSUFBSSxJQUFJLFVBQVUsVUFBVSxTQUFTLFNBQVMsU0FBUyxXQUFXLFVBQVUsUUFBUTtBQUUvRixRQUFJQyxTQUFTSjtBQUNiSSxhQUFTQyxLQUFLQyxNQUFNRixNQUFNO0FBQzFCLFNBQUtBLFNBQVNBLE9BQU9HLFNBQVMsR0FBR2xCLFNBQVMsRUFBRyxRQUFPO0FBRXBELFVBQU1tQixLQUFLLGNBQWNKLFFBQVFLLE9BQU8sRUFBRSxFQUFFQyxNQUFNLHVDQUF1QztBQUN6RixRQUFJLENBQUNGLEVBQUcsUUFBTztBQUVmLFFBQUlHLE1BQU07QUFDVkEsV0FBT0gsRUFBRSxDQUFDLEtBQUssS0FBS04sRUFBRVUsT0FBT0osRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLTCxFQUFFSyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxNQUFNTixFQUFFTSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxZQUFZO0FBQ3BGRyxXQUFPSCxFQUFFLENBQUMsS0FBSyxLQUFLTixFQUFFVSxPQUFPSixFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUtMLEVBQUVLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLE1BQU1OLEVBQUVNLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFdBQVc7QUFDbkZHLFdBQU9ILEVBQUUsQ0FBQyxLQUFLLEtBQUtOLEVBQUVVLE9BQU9KLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBS0wsRUFBRUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksTUFBTU4sRUFBRU0sRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssZUFBZTtBQUN2RkcsV0FBT0gsRUFBRSxDQUFDLEtBQUssS0FBS04sRUFBRVUsT0FBT0osRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLTCxFQUFFSyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxNQUFNTixFQUFFTSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxjQUFjO0FBQ3RGRyxXQUFPSCxFQUFFLENBQUMsS0FBSyxLQUFLRyxPQUFPLEtBQUssU0FBUyxPQUFPVCxFQUFFVSxPQUFPSixFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUtMLEVBQUVLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLE1BQU1OLEVBQUVNLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLE1BQU07QUFFMUcsV0FBT0csSUFBSUUsS0FBSyxLQUFLO0FBQUEsRUFDdkI7QUFHQSxRQUFNQyx3QkFBd0JBLENBQUMvQyxHQUFHZ0QsU0FBUztBQUN6QyxVQUFNQyxPQUFPakQsRUFBRUUsT0FBT2dELE1BQU0sQ0FBQztBQUM3QixRQUFJRCxNQUFNO0FBQ1IsWUFBTUUsU0FBUyxJQUFJQyxXQUFXO0FBQzlCRCxhQUFPRSxZQUFZLE1BQU07QUFDdkIsWUFBSUwsU0FBUyxXQUFXO0FBQ3RCeEUsMkJBQWlCMkUsT0FBT0csTUFBTTtBQUFBLFFBQ2hDLE9BQU87QUFDTDVFLGdDQUFzQnlFLE9BQU9HLE1BQU07QUFBQSxRQUNyQztBQUFBLE1BQ0Y7QUFDQUgsYUFBT0ksY0FBY04sSUFBSTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUVBLFFBQU1PLCtCQUErQkEsTUFBTTtBQUN6QyxVQUFNQyxRQUFReEY7QUFDZCxVQUFNeUYsU0FBU2xILHNCQUFzQixXQUNqQyxvQkFBSW9DLEtBQUssR0FBR2xDLGlCQUFpQixLQUFLLEdBQUVpSCxlQUFlLFdBQVcsRUFBRXhFLE9BQU8sUUFBUUQsTUFBTSxVQUFVLENBQUMsSUFDaEcsR0FBR3JCLFFBQVEsT0FBT0UsTUFBTTtBQUU1QixVQUFNNkYsZ0JBQWdCNUIsV0FBVzFFLFlBQVlHLGVBQWU7QUFDNUQsVUFBTW9HLGFBQWEsWUFBWWpGLEtBQUtrRixJQUFJLEVBQUV0QixTQUFTLEVBQUV1QixNQUFNLEVBQUUsQ0FBQztBQUM5RCxVQUFNQyxlQUFjLG9CQUFJcEYsS0FBSyxHQUFFcUYsbUJBQW1CLFNBQVMsRUFBRUMsS0FBSyxXQUFXL0UsT0FBTyxRQUFRRCxNQUFNLFVBQVUsQ0FBQztBQUU3RyxVQUFNaUYsVUFBVXBJLFdBQVdxSSxXQUFXLE1BQU0sSUFBSXJJLGFBQWFzSSxPQUFPQyxTQUFTQyxTQUFTeEk7QUFFdEYsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBSzRCMEgsT0FBT2UsUUFBUSxPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkEwVGpDTCxPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwREFRdUJILFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtDQXVCdEJQLE9BQU9lLFFBQVEsS0FBSztBQUFBO0FBQUE7QUFBQTtBQUFBLCtDQUlwQmYsT0FBT2dCLGdCQUFnQmhCLE9BQU8xQixLQUFLZ0MsTUFBTSxFQUFFLEtBQUssS0FBSztBQUFBO0FBQUE7QUFBQTtBQUFBLCtDQUlyRE4sT0FBT2lCLGdCQUFnQixLQUFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0NBSTVCaEIsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWdCeEJwRyxZQUFZRSxrQkFBa0JtRyxlQUFlLFNBQVMsRUFBRWdCLHVCQUF1QixFQUFFLENBQUMsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUlwRjNILG1CQUFtQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUluQkksU0FBU2tFLE1BQU07QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFJZmhFLFlBQVlLLGVBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFJM0JMLFlBQVlNLGFBQWE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1RUFJa0JOLFlBQVlHLGlCQUFpQmtHLGVBQWUsU0FBUyxFQUFFZ0IsdUJBQXVCLEVBQUUsQ0FBQyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtREFRdEdySCxZQUFZRyxpQkFBaUJrRyxlQUFlLFNBQVMsRUFBRWdCLHVCQUF1QixFQUFFLENBQUMsQ0FBQztBQUFBO0FBQUEsNkJBRXhHZixhQUFhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFjeEJuRixxQkFBcUIsYUFBYUEsa0JBQWtCLGdEQUFnRCxFQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSXRHRixnQkFBZ0IsYUFBYUEsYUFBYSxrREFBa0QsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBZ0I5RztBQUdBLFFBQU1xRyxxQkFBcUIsWUFBWTtBQUNyQyxRQUFJLENBQUMzRyx5QkFBeUI7QUFDNUJwRCxjQUFRK0csUUFBUSx1REFBdUQ7QUFDdkU7QUFBQSxJQUNGO0FBRUF0RCx1QkFBbUIsSUFBSTtBQUN2QixRQUFJO0FBQ0YsWUFBTXVHLGNBQWNyQiw2QkFBNkI7QUFDakQsWUFBTUMsUUFBUXhGO0FBQ2QsWUFBTXlGLFNBQVNsSCxzQkFBc0IsVUFBVUUsb0JBQW9CLEdBQUdtQixRQUFRLE9BQU9FLE1BQU07QUFDM0YsWUFBTStHLFdBQVcsdUJBQXVCckIsT0FBT2UsUUFBUSxPQUFPLElBQUlkLE1BQU07QUFFeEUsWUFBTXFCLFVBQVVDLFNBQVNDLGNBQWMsS0FBSztBQUM1Q0YsY0FBUUcsTUFBTUMsV0FBVztBQUN6QkosY0FBUUcsTUFBTUUsT0FBTztBQUNyQkwsY0FBUUcsTUFBTUcsTUFBTTtBQUNwQk4sY0FBUUcsTUFBTUksUUFBUTtBQUN0QlAsY0FBUUcsTUFBTUssa0JBQWtCO0FBQ2hDUixjQUFRUyxZQUFZWDtBQUNwQkcsZUFBU1MsS0FBS0MsWUFBWVgsT0FBTztBQUVqQyxZQUFNLElBQUlZLFFBQVEsQ0FBQUMsTUFBS0MsV0FBV0QsR0FBRyxHQUFHLENBQUM7QUFFekMsWUFBTUUsU0FBUyxNQUFNN0osWUFBWThJLFNBQVM7QUFBQSxRQUN4Q2dCLE9BQU87QUFBQSxRQUNQQyxTQUFTO0FBQUEsUUFDVFQsaUJBQWlCO0FBQUEsUUFDakJVLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLHdCQUF3QjtBQUFBLE1BQzFCLENBQUM7QUFFRCxZQUFNQyxVQUFVUCxPQUFPUSxVQUFVLFdBQVc7QUFDNUMsWUFBTUMsTUFBTSxJQUFJdkssTUFBTSxLQUFLLE1BQU0sSUFBSTtBQUNyQyxZQUFNd0ssWUFBWTtBQUNsQixZQUFNQyxXQUFXRDtBQUNqQixZQUFNRSxZQUFhWixPQUFPYSxTQUFTRixXQUFZWCxPQUFPUjtBQUV0RGlCLFVBQUlLLFNBQVNQLFNBQVMsT0FBTyxHQUFHLEdBQUdJLFVBQVVDLFNBQVM7QUFDdERILFVBQUlNLEtBQUsvQixRQUFRO0FBRWpCRSxlQUFTUyxLQUFLcUIsWUFBWS9CLE9BQU87QUFDakNsSyxjQUFRNkYsUUFBUSw4Q0FBOEM7QUFBQSxJQUNoRSxTQUFTWixPQUFPO0FBQ2RELGNBQVFDLE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDakYsY0FBUWlGLE1BQU0sbUNBQW1DO0FBQUEsSUFDbkQsVUFBQztBQUNDeEIseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNeUksa0JBQWtCQSxNQUFNO0FBQzVCLFFBQUksQ0FBQzlJLHlCQUF5QjtBQUM1QnBELGNBQVErRyxRQUFRLHVEQUF1RDtBQUN2RTtBQUFBLElBQ0Y7QUFFQSxVQUFNaUQsY0FBY3JCLDZCQUE2QjtBQUNqRCxVQUFNQyxRQUFReEY7QUFDZCxVQUFNeUYsU0FBU2xILHNCQUFzQixVQUFVRSxvQkFBb0IsR0FBR21CLFFBQVEsT0FBT0UsTUFBTTtBQUMzRixVQUFNK0csV0FBVyx1QkFBdUJyQixPQUFPZSxRQUFRLE9BQU8sSUFBSWQsTUFBTTtBQUV4RSxVQUFNc0QsY0FBYzNDLE9BQU80QyxLQUFLLElBQUksUUFBUTtBQUM1Q0QsZ0JBQVloQyxTQUFTa0MsTUFBTXJDLFdBQVc7QUFDdENtQyxnQkFBWWhDLFNBQVNtQyxRQUFRckM7QUFDN0JrQyxnQkFBWWhDLFNBQVNvQyxNQUFNO0FBQzNCSixnQkFBWUssTUFBTTtBQUNsQnhCLGVBQVcsTUFBTTtBQUNmbUIsa0JBQVlNLE1BQU07QUFDbEJOLGtCQUFZSSxNQUFNO0FBQUEsSUFDcEIsR0FBRyxHQUFHO0FBQUEsRUFDUjtBQUdBLFFBQU1HLHFCQUFxQm5LLFNBQVNvSyxJQUFJLENBQUNDLFNBQVNDLFdBQVc7QUFBQSxJQUMzREMsS0FBS0YsUUFBUTFGLE9BQU8yRjtBQUFBQSxJQUNwQkUsS0FBS0YsUUFBUTtBQUFBLElBQ2JHLGVBQWVKLFFBQVFLLFNBQVNDLGFBQWE7QUFBQSxJQUM3Q3JELGNBQWMrQyxRQUFRSyxTQUFTcEQsZ0JBQWdCO0FBQUEsSUFDL0NzRCxTQUFTUCxRQUFRUSxNQUFNRCxXQUFXO0FBQUEsSUFDbENFLGFBQWFULFNBQVNRLE1BQU1DLGVBQWVULFFBQVFVLG9CQUFvQjtBQUFBLElBQ3ZFQyxZQUFZWCxTQUFTUSxNQUFNSSx3QkFBd0JaLFFBQVFhLHVCQUF1QjtBQUFBLElBQ2xGQyxhQUFhZCxRQUFRYyxlQUFlZCxRQUFRZSxVQUFVO0FBQUEsSUFDdERDLGtCQUFrQmhCLFNBQVNpQixXQUFXdkksTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsSUFDdkR3SSxVQUFVbEIsU0FBU2tCLFlBQVk7QUFBQSxJQUMvQkMsY0FBY25CLFFBQVFvQixZQUFZcEIsUUFBUXFCLFFBQVE7QUFBQSxJQUNsREMsWUFBWXRCLFNBQVNzQixjQUFjO0FBQUEsRUFDckMsRUFBRTtBQUdGLFFBQU1DLFVBQVU7QUFBQSxJQUNkLEVBQUVyQixLQUFLLE9BQU9zQixRQUFRLFFBQVE7QUFBQSxJQUM5QixFQUFFdEIsS0FBSyxZQUFZc0IsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRXRCLEtBQUssb0JBQW9Cc0IsUUFBUSxtQkFBbUI7QUFBQSxJQUN0RCxFQUFFdEIsS0FBSyxpQkFBaUJzQixRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUV0QixLQUFLLGdCQUFnQnNCLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUV0QixLQUFLLFdBQVdzQixRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFdEIsS0FBSyxlQUFlc0IsUUFBUSxrQkFBa0I7QUFBQSxJQUNoRCxFQUFFdEIsS0FBSyxlQUFlc0IsUUFBUSxrQkFBa0I7QUFBQSxJQUNoRCxFQUFFdEIsS0FBSyxnQkFBZ0JzQixRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFdEIsS0FBSyxjQUFjc0IsUUFBUSxhQUFhO0FBQUEsRUFBQztBQUc3QyxRQUFNdEssUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFNQyxlQUFlLEdBQUdGLE1BQU1HLFlBQVksQ0FBQyxJQUFJQztBQUFBQSxJQUM3Q0osTUFBTUssU0FBUyxJQUFJO0FBQUEsRUFDckIsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUVsQixRQUFNaUssbUJBQW1COU0sVUFBVTBGO0FBQUFBLElBQ2pDLENBQUNELFFBQVFBLElBQUlFLFFBQVF6RjtBQUFBQSxFQUN2QjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxpR0FBZ0csZ0RBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixvRUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYixpQ0FBQyxlQUFZLFdBQVUsNkJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0QsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUVDLHVCQUFDLFFBQUssV0FBVSxrREFDZjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxpRUFDWjtBQUFBLGlDQUFDLFlBQVMsV0FBVSxpQkFBZ0IsTUFBTSxNQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQUc7QUFBQSxhQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsK0NBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0gsV0FBVTtBQUFBLFlBRVYsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFGQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixNQUFNO0FBQUE7QUFBQSxnQkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FFVyxLQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDJFQUEwRSw4Q0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0IsMENBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE1BQUs7QUFBQSxrQkFDTCxRQUFPO0FBQUEsa0JBQ1AsU0FBUTtBQUFBLGtCQUVSO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLGVBQWM7QUFBQSxzQkFDZCxnQkFBZTtBQUFBLHNCQUNmLGFBQWE7QUFBQSxzQkFDYixHQUFFO0FBQUE7QUFBQSxvQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSWtCO0FBQUE7QUFBQSxnQkFWcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsaUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUE7QUFBQSxVQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFtQ0E7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE1BQU07QUFBQTtBQUFBLGdCQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUVXLEtBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsNEVBQTJFLHNDQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLGdDQUErQix1Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLFFBQU87QUFBQSxrQkFDUCxTQUFRO0FBQUEsa0JBRVI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsZUFBYztBQUFBLHNCQUNkLGdCQUFlO0FBQUEsc0JBQ2YsYUFBYTtBQUFBLHNCQUNiLEdBQUU7QUFBQTtBQUFBLG9CQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJa0I7QUFBQTtBQUFBLGdCQVZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxpQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4QkE7QUFBQTtBQUFBLFVBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW1DQTtBQUFBLFFBR0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNBLElBQUc7QUFBQSxZQUNILFdBQVU7QUFBQSxZQUVWLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsTUFBTTtBQUFBO0FBQUEsZ0JBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRVcsS0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSwyRUFBMEUsZ0RBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQStCLHNDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixNQUFLO0FBQUEsa0JBQ0wsUUFBTztBQUFBLGtCQUNQLFNBQVE7QUFBQSxrQkFFUjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxlQUFjO0FBQUEsc0JBQ2QsZ0JBQWU7QUFBQSxzQkFDZixhQUFhO0FBQUEsc0JBQ2IsR0FBRTtBQUFBO0FBQUEsb0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlrQjtBQUFBO0FBQUEsZ0JBVnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGlCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQTtBQUFBO0FBQUEsVUFsQ0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUNEO0FBQUEsV0EvR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdIQSxLQWpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0hBO0FBQUEsU0E3SEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThIRDtBQUFBLElBRUEsdUJBQUMsT0FBSSxRQUFRLENBQUMsSUFBSSxFQUFFLEdBQUcsV0FBVSxRQUMvQjtBQUFBLDZCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQ3ZCLGlDQUFDLFFBQUssV0FBVSwrQ0FDZCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixnQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUN2RCxPQUFPZ0IsWUFBWUU7QUFBQUEsVUFDbkIsV0FBVztBQUFBLFVBQ1gsUUFBUSx1QkFBQyxlQUFZLFdBQVUsb0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsVUFDL0MsWUFBWSxFQUFFMkwsT0FBTyxXQUFXQyxVQUFVLE9BQU87QUFBQTtBQUFBLFFBTG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtxRCxLQU52RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUVBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQ3ZCLGlDQUFDLFFBQUssV0FBVSwrQ0FDZCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ1psTSxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsOEJBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsK0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsVUFDdEQsT0FBT0ksWUFBWUc7QUFBQUEsVUFDbkIsV0FBVztBQUFBLFVBQ1gsUUFBUSx1QkFBQyxnQkFBYSxXQUFVLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLFVBQy9DLFlBQVksRUFBRTBMLE9BQU8sV0FBV0MsVUFBVSxPQUFPO0FBQUE7QUFBQSxRQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLcUQsS0FYekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQSxLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFFQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QixpQ0FBQyxRQUFLLFdBQVUsK0NBQ2QsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsNkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFDcEQsT0FBTzlMLFlBQVlJO0FBQUFBLFVBQ25CLFFBQVEsdUJBQUMsZ0JBQWEsV0FBVSxxQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxVQUNqRCxZQUFZLEVBQUV5TCxPQUFPLFdBQVdDLFVBQVUsT0FBTztBQUFBO0FBQUEsUUFKbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXFELEtBTHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErQ0E7QUFBQSxJQUVBLHVCQUFDLFFBQUssV0FBVSw2QkFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxzQ0FDYixpQ0FBQyxRQUFHLFdBQVUsaUVBQ1o7QUFBQSwrQkFBQyxzQkFBbUIsV0FBVSxtQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFFBQUc7QUFBQSxXQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSx3RUFDZjtBQUFBLHFDQUFDLG9CQUFpQixXQUFVLDJCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRDtBQUFBLGNBQUc7QUFBQSxpQkFEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0E7QUFBQSxjQUFDLE1BQU07QUFBQSxjQUFOO0FBQUEsZ0JBQ0MsT0FBTzVNO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ3dELE1BQU12RCxxQkFBcUJ1RCxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBQ3BELE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBRVY7QUFBQTtBQUFBLG9CQUFDLE1BQU07QUFBQSxvQkFBTjtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPLEVBQUVxRixPQUFPLE9BQU8rRCxXQUFXLFNBQVM7QUFBQSxzQkFBRTtBQUFBO0FBQUEsb0JBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUMsTUFBTTtBQUFBLG9CQUFOO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU8sRUFBRS9ELE9BQU8sT0FBTytELFdBQVcsU0FBUztBQUFBLHNCQUFFO0FBQUE7QUFBQSxvQkFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUE7QUFBQTtBQUFBLGNBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWtCQTtBQUFBLGVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHdFQUNmO0FBQUEscUNBQUMsZ0JBQWEsV0FBVSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxjQUFHO0FBQUEsaUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTy9NLHNCQUFzQmdOO0FBQUFBLGdCQUM3QixVQUFVL007QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixjQUFjLENBQUNnTixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmpILFNBQVMsRUFDVGtILFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsZ0JBR2hDdE4sb0JBQVVvTDtBQUFBQSxrQkFBSSxDQUFDM0YsUUFDZCx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsSUFBSUUsS0FDckNGO0FBQUFBLHdCQUFJMkM7QUFBQUEsb0JBQUs7QUFBQSxvQkFBSTNDLElBQUk2QztBQUFBQSx1QkFEQTdDLElBQUlFLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbUJBO0FBQUEsWUFDQ21ILG9CQUNDLHVCQUFDLFNBQUksV0FBVSw4QkFBNkI7QUFBQTtBQUFBLGNBQy9CQSxpQkFBaUIxRTtBQUFBQSxpQkFEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOEJBO0FBQUEsYUF6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBEQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFDZGhJLGdDQUFzQixVQUFVLGlCQUFpQixlQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQ0Esc0JBQXNCLFVBQ3JCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9FLHFCQUFxQjtBQUFBLGdCQUM1QixLQUFLbUM7QUFBQUEsZ0JBQ0wsVUFBVWtCO0FBQUFBLGdCQUNWLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS29KLElBR3BKO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9uRCxnQkFBZ0I7QUFBQSxnQkFDdkIsVUFBVSxDQUFDb0QsTUFBTW5ELGdCQUFnQm1ELEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxnQkFDL0MsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJb0o7QUFBQSxlQWpCeEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsd0VBQ2Y7QUFBQSxxQ0FBQyxzQkFBbUIsV0FBVSwyQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxjQUFHO0FBQUEsaUJBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxLQUFJO0FBQUEsa0JBQ0osT0FBT2pEO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ2dELE1BQU0vQyx1QkFBdUIrQyxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsa0JBQ3RELFdBQVU7QUFBQTtBQUFBLGdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU15SjtBQUFBLGNBRXpKLHVCQUFDLFVBQUssV0FBVSw2RUFBNEUsaUJBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMENBO0FBQUEsUUFFQ3pELHNCQUFzQixnQkFDckIsdUJBQUMsU0FBSSxXQUFVLDhDQUNiLGlDQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT00sY0FBYztBQUFBLGNBQ3JCLFVBQVUsQ0FBQ2tELE1BQU1qRCxjQUFjaUQsRUFBRUUsT0FBT0QsS0FBSztBQUFBLGNBQzdDLFdBQVU7QUFBQTtBQUFBLFlBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSW9KO0FBQUEsYUFSdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFHRix1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNO0FBQ2IxRCxzQ0FBc0IsSUFBSTtBQUMxQjJCLDJDQUEyQixJQUFJO0FBQy9CdkIscUNBQXFCa0MsWUFBWTtBQUNqQzVCLHVDQUF1QixHQUFHO0FBQzFCSSw0QkFBWSxFQUFFO0FBQ2RFLCtCQUFlO0FBQUEsa0JBQ2JDLGtCQUFrQjtBQUFBLGtCQUNsQkMsaUJBQWlCO0FBQUEsa0JBQ2pCQyxhQUFhO0FBQUEsa0JBQ2JDLGlCQUFpQjtBQUFBLGtCQUNqQkMsZUFBZTtBQUFBLGdCQUNqQixDQUFDO0FBQ0RRLCtCQUFlLEtBQUs7QUFDcEIsc0JBQU1PLFNBQVEsb0JBQUlDLEtBQUs7QUFDdkIsc0JBQU1NLE9BQU9QLE9BQU1HLFlBQVk7QUFDL0Isc0JBQU1LLFFBQVFSLE9BQU1LLFNBQVMsSUFBSTtBQUNqQyxzQkFBTUksV0FBVyxHQUFHRixJQUFJLElBQUlILE9BQU9JLEtBQUssRUFBRUYsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUMxRCxzQkFBTUksVUFBVSxJQUFJVCxLQUFLTSxNQUFNQyxPQUFPLENBQUMsRUFBRUcsUUFBUTtBQUNqRHpDLGdDQUFnQnVDLFFBQVE7QUFDeEJyQztBQUFBQSxrQkFDRSxHQUFHbUMsSUFBSSxJQUFJSCxPQUFPSSxLQUFLLEVBQUVGLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSUYsT0FBT00sT0FBTyxFQUFFSixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQUEsZ0JBQy9FO0FBQUEsY0FDRjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTRCQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE1BQU0sdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUN6QjtBQUFBLGNBQ0EsU0FBUzBDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQTZHO0FBQUE7QUFBQSxZQU56SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLGFBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3Q0E7QUFBQSxXQWpLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0tBO0FBQUEsU0ExS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJLQTtBQUFBLElBSUN4RCxlQUFlRiwyQkFDZCx1QkFBQyxRQUFLLFdBQVUsNkJBQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbUdBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsaUVBQ1o7QUFBQSxpQ0FBQyxnQkFBYSxXQUFVLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLFVBQUc7QUFBQSxhQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTSx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBLGNBQ3RCLFNBQVM4STtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUEwQztBQUFBO0FBQUEsWUFIdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFNLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUEsY0FDdkIsU0FBUzFJO0FBQUFBLGNBQ1QsU0FBU3VHO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQWlDO0FBQUE7QUFBQSxZQUw3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxXQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlEQUFnRCxvQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGtDQUNWM0csbUNBQXlCdUcsUUFBUSxPQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaURBQWdELHFCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsa0NBQ1Z2RyxtQ0FBeUIyTCxTQUFTLE9BRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxpREFBZ0QscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVjNMLG1DQUF5QnlHLGdCQUFnQixPQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxTQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcURBO0FBQUEsSUFJRHZHLGVBQWVmLFNBQVNrRSxTQUFTLEtBQ2hDLHVCQUFDLFFBQUssV0FBVSw2QkFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxtRUFDYixpQ0FBQyxRQUFHLFdBQVUsaUVBQ1o7QUFBQSwrQkFBQyxlQUFZLFdBQVUsb0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxRQUFHO0FBQUEsV0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaURBQWdELHNCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsd0NBQ1Y5RSxnQ0FBc0IsV0FDbkIsb0JBQUlvQyxLQUFLLEdBQUdsQyxpQkFBaUIsS0FBSyxHQUFFaUg7QUFBQUEsWUFDbEM7QUFBQSxZQUNBO0FBQUEsY0FDRXhFLE9BQU87QUFBQSxjQUNQRCxNQUFNO0FBQUEsWUFDUjtBQUFBLFVBQ0YsSUFDQSxHQUFHckIsUUFBUSxPQUFPRSxNQUFNLE1BVDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlEQUFnRCw4QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUNWZjtBQUFBQTtBQUFBQSxZQUFvQjtBQUFBLGVBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlEQUFnRCw2QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDBDQUNWSSxtQkFBU2tFLFVBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaURBQWdELGdDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsaUVBQ1g7QUFBQSxtQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFZO0FBQUEsWUFDWGhFLFlBQVlFLGtCQUFrQnFNLFFBQVEsQ0FBQztBQUFBLGVBRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlEQUFnRCwrQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGdFQUNYO0FBQUEsbUNBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYTtBQUFBLFlBQ1p2TSxZQUFZRyxpQkFBaUJvTSxRQUFRLENBQUM7QUFBQSxlQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdURBLEtBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5REE7QUFBQSxTQWpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0VBO0FBQUEsSUFHRDNNLFVBQ0MsdUJBQUMsU0FBSSxXQUFVLDZCQUNiLGlDQUFDLGtCQUFlLFdBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFFQWlCLGVBQ0FmLFNBQVNrRSxTQUFTLEtBQ2hCLHVCQUFDLFFBQUssV0FBVSx3Q0FDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxpRUFDWjtBQUFBLGlDQUFDLHNCQUFtQixXQUFVLG1CQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQUc7QUFBQSxhQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkI7QUFBQTtBQUFBLFVBQy9CbEUsU0FBU2tFO0FBQUFBLFVBQU87QUFBQSxhQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1pRztBQUFBQSxVQUNOO0FBQUEsVUFDQSxpQkFBaUI7QUFBQSxVQUNqQixpQkFBaUI7QUFBQSxZQUNmO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFBZTtBQUFBLFVBRWpCLG1CQUFtQjtBQUFBLFlBQ2pCdEoseUJBQXlCdUcsUUFBUTtBQUFBLFlBQ2pDdkcseUJBQXlCeUcsZ0JBQWdCO0FBQUEsWUFDekNsSSxzQkFBc0IsV0FDbEIsb0JBQUlvQyxLQUFLLEdBQUdsQyxpQkFBaUIsS0FBSyxHQUFFaUg7QUFBQUEsY0FDbEM7QUFBQSxjQUNBO0FBQUEsZ0JBQ0V4RSxPQUFPO0FBQUEsZ0JBQ1BELE1BQU07QUFBQSxjQUNSO0FBQUEsWUFDRixJQUNBLEdBQUdyQixRQUFRLE9BQU9FLE1BQU07QUFBQSxZQUM1QixHQUFHZixtQkFBbUI7QUFBQSxZQUN0QixJQUFJTSxZQUFZRSxrQkFBa0JtRyxlQUFlLE9BQU8sS0FBSyxHQUFHO0FBQUEsWUFDaEUsSUFBSXJHLFlBQVlHLGlCQUFpQmtHLGVBQWUsT0FBTyxLQUFLLEdBQUc7QUFBQSxZQUMvRHZHLFNBQVNrRSxVQUFVO0FBQUEsVUFBRztBQUFBLFVBRXhCLGtCQUFrQix3QkFBd0JyRCx5QkFBeUJ1RyxRQUFRLEtBQUssSUFDOUVoSSxzQkFBc0IsVUFDbEJFLG9CQUNBLEdBQUdtQixRQUFRLE9BQU9FLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFqQ2xDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWtDUyxLQW5DWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUNBO0FBQUEsU0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdEQTtBQUFBLElBSUhJLGVBQWUsQ0FBQ2pCLFdBQVdFLFNBQVNrRSxXQUFXLEtBQzlDLHVCQUFDLFFBQUssV0FBVSx3QkFDZCxpQ0FBQyxTQUFJLFdBQVUsb0JBQ2IsaUNBQUMsT0FBRSxXQUFVLHFDQUFvQyxpRUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsT0FuakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxakJBO0FBRUo7QUFBRW5GLEdBcDFDSUQsK0JBQTZCO0FBQUE0TixLQUE3QjVOO0FBczFDTixlQUFlQTtBQUE4QixJQUFBNE47QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2VsZWN0IiwiUmFkaW8iLCJDYXJkIiwiQnV0dG9uIiwiU3BhY2UiLCJTdGF0aXN0aWMiLCJSb3ciLCJDb2wiLCJtZXNzYWdlIiwiVXNlck91dGxpbmVkIiwiQ2FsZW5kYXJPdXRsaW5lZCIsIlBlcmNlbnRhZ2VPdXRsaW5lZCIsIkZpbGVTZWFyY2hPdXRsaW5lZCIsIlRlYW1PdXRsaW5lZCIsIlJpc2VPdXRsaW5lZCIsIlByaW50ZXJPdXRsaW5lZCIsIkRvd25sb2FkT3V0bGluZWQiLCJTaWduYXR1cmVPdXRsaW5lZCIsImFwaSIsIkZhUnVwZWVTaWduIiwiTGluayIsIkZpVGFyZ2V0IiwiTWRDdXJyZW5jeVJ1cGVlIiwiTWRHcm91cHMiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsImltYWdlSW5wdXQiLCJqc1BERiIsImh0bWwyY2FudmFzIiwiTG9hbkNvbGxlY3Rpb25JbmNlbnRpdmVSZXBvcnQiLCJfcyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInNlbGVjdGVkRW1wbG95ZWVJZCIsInNldFNlbGVjdGVkRW1wbG95ZWVJZCIsImRhdGVTZWxlY3Rpb25Nb2RlIiwic2V0RGF0ZVNlbGVjdGlvbk1vZGUiLCJ0ZW1wU2VsZWN0ZWRNb250aCIsInNldFRlbXBTZWxlY3RlZE1vbnRoIiwidGVtcEZyb21EYXRlIiwic2V0VGVtcEZyb21EYXRlIiwidGVtcFRvRGF0ZSIsInNldFRlbXBUb0RhdGUiLCJpbmNlbnRpdmVQZXJjZW50YWdlIiwic2V0SW5jZW50aXZlUGVyY2VudGFnZSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwibG9hbkRhdGEiLCJzZXRMb2FuRGF0YSIsImxvYW5TdW1tYXJ5Iiwic2V0TG9hblN1bW1hcnkiLCJ0b3RhbF9jb2xsZWN0aW9uIiwidG90YWxfaW5jZW50aXZlIiwidG90YWxfbG9hbnMiLCJjb21wbGV0ZWRfbG9hbnMiLCJwZW5kaW5nX2xvYW5zIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsInNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzIiwic2V0U2VsZWN0ZWRFbXBsb3llZURldGFpbHMiLCJpc0ZpbHRlcmluZyIsInNldElzRmlsdGVyaW5nIiwiaXNHZW5lcmF0aW5nUERGIiwic2V0SXNHZW5lcmF0aW5nUERGIiwic2lnbmF0dXJlRGF0YSIsInNldFNpZ25hdHVyZURhdGEiLCJhZ2VudFNpZ25hdHVyZURhdGEiLCJzZXRBZ2VudFNpZ25hdHVyZURhdGEiLCJ0b2RheSIsIkRhdGUiLCJjdXJyZW50TW9udGgiLCJnZXRGdWxsWWVhciIsIlN0cmluZyIsImdldE1vbnRoIiwicGFkU3RhcnQiLCJ5ZWFyIiwibW9udGgiLCJmaXJzdERheSIsImxhc3REYXkiLCJnZXREYXRlIiwiZmV0Y2hFbXBsb3llZXMiLCJyZXMiLCJnZXQiLCJkYXRhIiwiZW1wbG95ZWUiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJoYW5kbGVUZW1wTW9udGhDaGFuZ2UiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJzcGxpdCIsImZldGNoTG9hbkNvbGxlY3Rpb25EYXRhIiwiZW1wbG95ZWVJZCIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJyZXNwb25zZSIsInBhcmFtcyIsInN1Y2Nlc3MiLCJyZXNwb25zZURhdGEiLCJhbGxQYXltZW50cyIsInRvdGFsQ29sbGVjdGlvbiIsInRvdGFsSW5jZW50aXZlIiwiZm9yRWFjaCIsIml0ZW0iLCJwYXltZW50cyIsIkFycmF5IiwiaXNBcnJheSIsInRvdGFsX3BheW1lbnRzIiwiaW5jZW50aXZlX2Ftb3VudCIsImxlbmd0aCIsImZpbHRlciIsInAiLCJzdGF0dXMiLCJpc19jb21wbGV0ZWQiLCJoYW5kbGVDb250aW51ZSIsIndhcm5pbmciLCJlbXAiLCJmaW5kIiwiX2lkIiwibnVtVG9Xb3JkcyIsIm51bSIsImlzTmFOIiwiYSIsImIiLCJudW1WYWwiLCJNYXRoIiwicm91bmQiLCJ0b1N0cmluZyIsIm4iLCJzdWJzdHIiLCJtYXRjaCIsInN0ciIsIk51bWJlciIsInRyaW0iLCJoYW5kbGVTaWduYXR1cmVDaGFuZ2UiLCJ0eXBlIiwiZmlsZSIsImZpbGVzIiwicmVhZGVyIiwiRmlsZVJlYWRlciIsIm9ubG9hZGVuZCIsInJlc3VsdCIsInJlYWRBc0RhdGFVUkwiLCJnZW5lcmF0ZUluY2VudGl2ZVNsaXBDb250ZW50IiwiYWdlbnQiLCJwZXJpb2QiLCJ0b0xvY2FsZVN0cmluZyIsImFtb3VudEluV29yZHMiLCJzbGlwTnVtYmVyIiwibm93Iiwic2xpY2UiLCJjdXJyZW50RGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImRheSIsImxvZ29VcmwiLCJzdGFydHNXaXRoIiwid2luZG93IiwibG9jYXRpb24iLCJvcmlnaW4iLCJuYW1lIiwiZW1wbG95ZWVDb2RlIiwicGhvbmVfbnVtYmVyIiwibWluaW11bUZyYWN0aW9uRGlnaXRzIiwiaGFuZGxlR2VuZXJhdGVTbGlwIiwiaHRtbENvbnRlbnQiLCJmaWxlTmFtZSIsInRlbXBEaXYiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJzdHlsZSIsInBvc2l0aW9uIiwibGVmdCIsInRvcCIsIndpZHRoIiwiYmFja2dyb3VuZENvbG9yIiwiaW5uZXJIVE1MIiwiYm9keSIsImFwcGVuZENoaWxkIiwiUHJvbWlzZSIsInIiLCJzZXRUaW1lb3V0IiwiY2FudmFzIiwic2NhbGUiLCJ1c2VDT1JTIiwibG9nZ2luZyIsIndpbmRvd1dpZHRoIiwiYWxsb3dUYWludCIsImZvcmVpZ25PYmplY3RSZW5kZXJpbmciLCJpbWdEYXRhIiwidG9EYXRhVVJMIiwicGRmIiwicGFnZVdpZHRoIiwiaW1nV2lkdGgiLCJpbWdIZWlnaHQiLCJoZWlnaHQiLCJhZGRJbWFnZSIsInNhdmUiLCJyZW1vdmVDaGlsZCIsImhhbmRsZVByaW50U2xpcCIsInByaW50V2luZG93Iiwib3BlbiIsIndyaXRlIiwidGl0bGUiLCJjbG9zZSIsImZvY3VzIiwicHJpbnQiLCJwcm9jZXNzZWRUYWJsZURhdGEiLCJtYXAiLCJwYXltZW50IiwiaW5kZXgiLCJrZXkiLCJzbm8iLCJjdXN0b21lcl9uYW1lIiwidXNlcl9pZCIsImZ1bGxfbmFtZSIsImxvYW5faWQiLCJsb2FuIiwibG9hbl9hbW91bnQiLCJwcmluY2lwYWxfYW1vdW50IiwiZW1pX2Ftb3VudCIsImRhaWx5X3BheW1lbnRfYW1vdW50IiwibW9udGhseV9pbnN0YWxsbWVudCIsInBhaWRfYW1vdW50IiwiYW1vdW50IiwidHJhbnNhY3Rpb25fZGF0ZSIsImNyZWF0ZWRBdCIsInBheV9kYXRlIiwicGF5bWVudF9tb2RlIiwicGF5X3R5cGUiLCJtb2RlIiwicmVjZWlwdF9ubyIsImNvbHVtbnMiLCJoZWFkZXIiLCJzZWxlY3RlZEVtcGxveWVlIiwiY29sb3IiLCJmb250U2l6ZSIsInRleHRBbGlnbiIsInVuZGVmaW5lZCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZW1haWwiLCJ0b0ZpeGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTG9hbkNvbGxlY3Rpb25JbmNlbnRpdmVSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgU2VsZWN0LFxyXG4gIFJhZGlvLFxyXG4gIENhcmQsXHJcbiAgQnV0dG9uLFxyXG4gIFNwYWNlLFxyXG4gIFN0YXRpc3RpYyxcclxuICBSb3csXHJcbiAgQ29sLFxyXG4gIG1lc3NhZ2UsXHJcbn0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHtcclxuICBVc2VyT3V0bGluZWQsXHJcbiAgQ2FsZW5kYXJPdXRsaW5lZCxcclxuICBQZXJjZW50YWdlT3V0bGluZWQsXHJcbiAgRmlsZVNlYXJjaE91dGxpbmVkLFxyXG4gIFRlYW1PdXRsaW5lZCxcclxuICBSaXNlT3V0bGluZWQsXHJcbiAgUHJpbnRlck91dGxpbmVkLFxyXG4gIERvd25sb2FkT3V0bGluZWQsXHJcbiAgU2lnbmF0dXJlT3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IHsgRmFSdXBlZVNpZ24gfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IEZpVGFyZ2V0IH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbmltcG9ydCB7IE1kQ3VycmVuY3lSdXBlZSxNZEdyb3VwcyB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBpbWFnZUlucHV0IGZyb20gXCIuLi9hc3NldHMvaW1hZ2VzL0xvZ28uc3ZnXCI7XHJcbmltcG9ydCBqc1BERiBmcm9tIFwianNwZGZcIjtcclxuaW1wb3J0IGh0bWwyY2FudmFzIGZyb20gXCJodG1sMmNhbnZhc1wiO1xyXG5cclxuY29uc3QgTG9hbkNvbGxlY3Rpb25JbmNlbnRpdmVSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZUlkLCBzZXRTZWxlY3RlZEVtcGxveWVlSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2RhdGVTZWxlY3Rpb25Nb2RlLCBzZXREYXRlU2VsZWN0aW9uTW9kZV0gPSB1c2VTdGF0ZShcIm1vbnRoXCIpO1xyXG4gIGNvbnN0IFt0ZW1wU2VsZWN0ZWRNb250aCwgc2V0VGVtcFNlbGVjdGVkTW9udGhdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RlbXBGcm9tRGF0ZSwgc2V0VGVtcEZyb21EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt0ZW1wVG9EYXRlLCBzZXRUZW1wVG9EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpbmNlbnRpdmVQZXJjZW50YWdlLCBzZXRJbmNlbnRpdmVQZXJjZW50YWdlXSA9IHVzZVN0YXRlKDEuNSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsb2FuRGF0YSwgc2V0TG9hbkRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FuU3VtbWFyeSwgc2V0TG9hblN1bW1hcnldID0gdXNlU3RhdGUoe1xyXG4gICAgdG90YWxfY29sbGVjdGlvbjogMCxcclxuICAgIHRvdGFsX2luY2VudGl2ZTogMCxcclxuICAgIHRvdGFsX2xvYW5zOiAwLFxyXG4gICAgY29tcGxldGVkX2xvYW5zOiAwLFxyXG4gICAgcGVuZGluZ19sb2FuczogMCxcclxuICB9KTtcclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt0b0RhdGUsIHNldFRvRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZURldGFpbHMsIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpc0ZpbHRlcmluZywgc2V0SXNGaWx0ZXJpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0dlbmVyYXRpbmdQREYsIHNldElzR2VuZXJhdGluZ1BERl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NpZ25hdHVyZURhdGEsIHNldFNpZ25hdHVyZURhdGFdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2FnZW50U2lnbmF0dXJlRGF0YSwgc2V0QWdlbnRTaWduYXR1cmVEYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgY3VycmVudE1vbnRoID0gYCR7dG9kYXkuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcoXHJcbiAgICAgIHRvZGF5LmdldE1vbnRoKCkgKyAxLFxyXG4gICAgKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuXHJcbiAgICBzZXRUZW1wU2VsZWN0ZWRNb250aChjdXJyZW50TW9udGgpO1xyXG5cclxuICAgIGNvbnN0IHllYXIgPSB0b2RheS5nZXRGdWxsWWVhcigpO1xyXG4gICAgY29uc3QgbW9udGggPSB0b2RheS5nZXRNb250aCgpICsgMTtcclxuICAgIGNvbnN0IGZpcnN0RGF5ID0gYCR7eWVhcn0tJHtTdHJpbmcobW9udGgpLnBhZFN0YXJ0KDIsIFwiMFwiKX0tMDFgO1xyXG4gICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XHJcblxyXG4gICAgc2V0VGVtcEZyb21EYXRlKGZpcnN0RGF5KTtcclxuICAgIHNldFRlbXBUb0RhdGUoXHJcbiAgICAgIGAke3llYXJ9LSR7U3RyaW5nKG1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LSR7U3RyaW5nKGxhc3REYXkpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gLFxyXG4gICAgKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICAgIHNldEVtcGxveWVlcyhyZXM/LmRhdGE/LmVtcGxveWVlIHx8IFtdKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVRlbXBNb250aENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB2YWx1ZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0VGVtcFNlbGVjdGVkTW9udGgodmFsdWUpO1xyXG4gICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSB2YWx1ZS5zcGxpdChcIi1cIik7XHJcbiAgICAgIGNvbnN0IGZpcnN0RGF5ID0gYCR7eWVhcn0tJHttb250aH0tMDFgO1xyXG4gICAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLmdldERhdGUoKTtcclxuICAgICAgc2V0VGVtcEZyb21EYXRlKGZpcnN0RGF5KTtcclxuICAgICAgc2V0VGVtcFRvRGF0ZShgJHt5ZWFyfS0ke21vbnRofS0ke1N0cmluZyhsYXN0RGF5KS5wYWRTdGFydCgyLCBcIjBcIil9YCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hMb2FuQ29sbGVjdGlvbkRhdGEgPSBhc3luYyAoZW1wbG95ZWVJZCwgc3RhcnREYXRlLCBlbmREYXRlKSA9PiB7XHJcbiAgICBpZiAoIWVtcGxveWVlSWQgfHwgIXN0YXJ0RGF0ZSB8fCAhZW5kRGF0ZSkgcmV0dXJuO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3YxL2FkbWluL3BheW1lbnRzL2xvYW5zL2NvbGxlY3Rpb24tYWdlbnRzLyR7ZW1wbG95ZWVJZH0vJHtpbmNlbnRpdmVQZXJjZW50YWdlfWAsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgIHN0YXJ0RGF0ZTogc3RhcnREYXRlLFxyXG4gICAgICAgICAgICBlbmREYXRlOiBlbmREYXRlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID0gcmVzcG9uc2UuZGF0YS5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgICBsZXQgYWxsUGF5bWVudHMgPSBbXTtcclxuICAgICAgICBsZXQgdG90YWxDb2xsZWN0aW9uID0gMDtcclxuICAgICAgICBsZXQgdG90YWxJbmNlbnRpdmUgPSAwO1xyXG5cclxuICAgICAgICByZXNwb25zZURhdGEuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgaWYgKGl0ZW0ucGF5bWVudHMgJiYgQXJyYXkuaXNBcnJheShpdGVtLnBheW1lbnRzKSkge1xyXG4gICAgICAgICAgICBhbGxQYXltZW50cyA9IFsuLi5hbGxQYXltZW50cywgLi4uaXRlbS5wYXltZW50c107XHJcbiAgICAgICAgICAgIHRvdGFsQ29sbGVjdGlvbiArPSBpdGVtLnRvdGFsX3BheW1lbnRzIHx8IDA7XHJcbiAgICAgICAgICAgIHRvdGFsSW5jZW50aXZlICs9IGl0ZW0uaW5jZW50aXZlX2Ftb3VudCB8fCAwO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRMb2FuRGF0YShhbGxQYXltZW50cyk7XHJcbiAgICAgICAgc2V0TG9hblN1bW1hcnkoe1xyXG4gICAgICAgICAgdG90YWxfY29sbGVjdGlvbjogdG90YWxDb2xsZWN0aW9uLFxyXG4gICAgICAgICAgdG90YWxfaW5jZW50aXZlOiB0b3RhbEluY2VudGl2ZSxcclxuICAgICAgICAgIHRvdGFsX2xvYW5zOiBhbGxQYXltZW50cy5sZW5ndGgsXHJcbiAgICAgICAgICBjb21wbGV0ZWRfbG9hbnM6IGFsbFBheW1lbnRzLmZpbHRlcihcclxuICAgICAgICAgICAgKHApID0+IHAuc3RhdHVzID09PSBcImNvbXBsZXRlZFwiIHx8IHAuaXNfY29tcGxldGVkLFxyXG4gICAgICAgICAgKS5sZW5ndGgsXHJcbiAgICAgICAgICBwZW5kaW5nX2xvYW5zOiBhbGxQYXltZW50cy5maWx0ZXIoXHJcbiAgICAgICAgICAgIChwKSA9PiBwLnN0YXR1cyAhPT0gXCJjb21wbGV0ZWRcIiAmJiAhcC5pc19jb21wbGV0ZWQsXHJcbiAgICAgICAgICApLmxlbmd0aCxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRMb2FuRGF0YShbXSk7XHJcbiAgICAgICAgc2V0TG9hblN1bW1hcnkoe1xyXG4gICAgICAgICAgdG90YWxfY29sbGVjdGlvbjogMCxcclxuICAgICAgICAgIHRvdGFsX2luY2VudGl2ZTogMCxcclxuICAgICAgICAgIHRvdGFsX2xvYW5zOiAwLFxyXG4gICAgICAgICAgY29tcGxldGVkX2xvYW5zOiAwLFxyXG4gICAgICAgICAgcGVuZGluZ19sb2FuczogMCxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBsb2FuIGNvbGxlY3Rpb24gZGF0YTpcIiwgZXJyKTtcclxuICAgICAgc2V0TG9hbkRhdGEoW10pO1xyXG4gICAgICBzZXRMb2FuU3VtbWFyeSh7XHJcbiAgICAgICAgdG90YWxfY29sbGVjdGlvbjogMCxcclxuICAgICAgICB0b3RhbF9pbmNlbnRpdmU6IDAsXHJcbiAgICAgICAgdG90YWxfbG9hbnM6IDAsXHJcbiAgICAgICAgY29tcGxldGVkX2xvYW5zOiAwLFxyXG4gICAgICAgIHBlbmRpbmdfbG9hbnM6IDAsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbnRpbnVlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZEVtcGxveWVlSWQpIHtcclxuICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIHNlbGVjdCBhbiBlbXBsb3llZS5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIiAmJiAhdGVtcFNlbGVjdGVkTW9udGgpIHtcclxuICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIHNlbGVjdCBhIG1vbnRoLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJkYXRlLXJhbmdlXCIgJiYgKCF0ZW1wRnJvbURhdGUgfHwgIXRlbXBUb0RhdGUpKSB7XHJcbiAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBzZWxlY3QgYm90aCBGcm9tIGFuZCBUbyBkYXRlcy5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRJc0ZpbHRlcmluZyh0cnVlKTtcclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgbGV0IHN0YXJ0RGF0ZSwgZW5kRGF0ZTtcclxuXHJcbiAgICBpZiAoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIikge1xyXG4gICAgICBjb25zdCBbeWVhciwgbW9udGhdID0gdGVtcFNlbGVjdGVkTW9udGguc3BsaXQoXCItXCIpO1xyXG4gICAgICBzdGFydERhdGUgPSBgJHt5ZWFyfS0ke21vbnRofS0wMWA7XHJcbiAgICAgIGNvbnN0IGxhc3REYXkgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgMCkuZ2V0RGF0ZSgpO1xyXG4gICAgICBlbmREYXRlID0gYCR7eWVhcn0tJHttb250aH0tJHtTdHJpbmcobGFzdERheSkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgICAgIHNldEZyb21EYXRlKHN0YXJ0RGF0ZSk7XHJcbiAgICAgIHNldFRvRGF0ZShlbmREYXRlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHN0YXJ0RGF0ZSA9IHRlbXBGcm9tRGF0ZTtcclxuICAgICAgZW5kRGF0ZSA9IHRlbXBUb0RhdGU7XHJcbiAgICAgIHNldEZyb21EYXRlKHN0YXJ0RGF0ZSk7XHJcbiAgICAgIHNldFRvRGF0ZShlbmREYXRlKTtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBlbXAgPSBlbXBsb3llZXMuZmluZCgoZSkgPT4gZS5faWQgPT09IHNlbGVjdGVkRW1wbG95ZWVJZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKGVtcCB8fCBudWxsKTtcclxuICAgICAgYXdhaXQgZmV0Y2hMb2FuQ29sbGVjdGlvbkRhdGEoc2VsZWN0ZWRFbXBsb3llZUlkLCBzdGFydERhdGUsIGVuZERhdGUpO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJEYXRhIGxvYWRlZCBzdWNjZXNzZnVsbHkhXCIpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIGhhbmRsZUNvbnRpbnVlOlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBkYXRhXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gQ29udmVydCBudW1iZXIgdG8gd29yZHNcclxuICBjb25zdCBudW1Ub1dvcmRzID0gKG51bSkgPT4ge1xyXG4gICAgaWYgKGlzTmFOKG51bSkgfHwgbnVtID09PSAwKSByZXR1cm4gXCJaZXJvXCI7XHJcbiAgICBcclxuICAgIGNvbnN0IGEgPSBbXHJcbiAgICAgIFwiXCIsIFwiT25lXCIsIFwiVHdvXCIsIFwiVGhyZWVcIiwgXCJGb3VyXCIsIFwiRml2ZVwiLCBcIlNpeFwiLCBcIlNldmVuXCIsIFwiRWlnaHRcIiwgXCJOaW5lXCIsIFxyXG4gICAgICBcIlRlblwiLCBcIkVsZXZlblwiLCBcIlR3ZWx2ZVwiLCBcIlRoaXJ0ZWVuXCIsIFwiRm91cnRlZW5cIiwgXCJGaWZ0ZWVuXCIsIFwiU2l4dGVlblwiLCBcclxuICAgICAgXCJTZXZlbnRlZW5cIiwgXCJFaWdodGVlblwiLCBcIk5pbmV0ZWVuXCJcclxuICAgIF07XHJcbiAgICBjb25zdCBiID0gW1wiXCIsIFwiXCIsIFwiVHdlbnR5XCIsIFwiVGhpcnR5XCIsIFwiRm9ydHlcIiwgXCJGaWZ0eVwiLCBcIlNpeHR5XCIsIFwiU2V2ZW50eVwiLCBcIkVpZ2h0eVwiLCBcIk5pbmV0eVwiXTtcclxuICAgIFxyXG4gICAgbGV0IG51bVZhbCA9IG51bTtcclxuICAgIG51bVZhbCA9IE1hdGgucm91bmQobnVtVmFsKTtcclxuICAgIGlmICgobnVtVmFsID0gbnVtVmFsLnRvU3RyaW5nKCkpLmxlbmd0aCA+IDkpIHJldHVybiBcIk92ZXJmbG93XCI7XHJcbiAgICBcclxuICAgIGNvbnN0IG4gPSAoXCIwMDAwMDAwMDBcIiArIG51bVZhbCkuc3Vic3RyKC05KS5tYXRjaCgvXihcXGR7Mn0pKFxcZHsyfSkoXFxkezJ9KShcXGR7MX0pKFxcZHsyfSkkLyk7XHJcbiAgICBpZiAoIW4pIHJldHVybiBcIlwiO1xyXG4gICAgXHJcbiAgICBsZXQgc3RyID0gXCJcIjtcclxuICAgIHN0ciArPSBuWzFdICE9IDAgPyAoYVtOdW1iZXIoblsxXSldIHx8IGJbblsxXVswXV0gKyBcIiBcIiArIGFbblsxXVsxXV0pICsgXCIgQ3JvcmUgXCIgOiBcIlwiO1xyXG4gICAgc3RyICs9IG5bMl0gIT0gMCA/IChhW051bWJlcihuWzJdKV0gfHwgYltuWzJdWzBdXSArIFwiIFwiICsgYVtuWzJdWzFdXSkgKyBcIiBMYWtoIFwiIDogXCJcIjtcclxuICAgIHN0ciArPSBuWzNdICE9IDAgPyAoYVtOdW1iZXIoblszXSldIHx8IGJbblszXVswXV0gKyBcIiBcIiArIGFbblszXVsxXV0pICsgXCIgVGhvdXNhbmQgXCIgOiBcIlwiO1xyXG4gICAgc3RyICs9IG5bNF0gIT0gMCA/IChhW051bWJlcihuWzRdKV0gfHwgYltuWzRdWzBdXSArIFwiIFwiICsgYVtuWzRdWzFdXSkgKyBcIiBIdW5kcmVkIFwiIDogXCJcIjtcclxuICAgIHN0ciArPSBuWzVdICE9IDAgPyAoc3RyICE9IFwiXCIgPyBcImFuZCBcIiA6IFwiXCIpICsgKGFbTnVtYmVyKG5bNV0pXSB8fCBiW25bNV1bMF1dICsgXCIgXCIgKyBhW25bNV1bMV1dKSArIFwiIFwiIDogXCJcIjtcclxuICAgIFxyXG4gICAgcmV0dXJuIHN0ci50cmltKCkgfHwgXCJaZXJvXCI7XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIFNpZ25hdHVyZSBDaGFuZ2VcclxuICBjb25zdCBoYW5kbGVTaWduYXR1cmVDaGFuZ2UgPSAoZSwgdHlwZSkgPT4ge1xyXG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzWzBdO1xyXG4gICAgaWYgKGZpbGUpIHtcclxuICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgcmVhZGVyLm9ubG9hZGVuZCA9ICgpID0+IHtcclxuICAgICAgICBpZiAodHlwZSA9PT0gJ21hbmFnZXInKSB7XHJcbiAgICAgICAgICBzZXRTaWduYXR1cmVEYXRhKHJlYWRlci5yZXN1bHQpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRBZ2VudFNpZ25hdHVyZURhdGEocmVhZGVyLnJlc3VsdCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9O1xyXG4gICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBnZW5lcmF0ZUluY2VudGl2ZVNsaXBDb250ZW50ID0gKCkgPT4ge1xyXG4gICAgY29uc3QgYWdlbnQgPSBzZWxlY3RlZEVtcGxveWVlRGV0YWlscztcclxuICAgIGNvbnN0IHBlcmlvZCA9IGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCJcclxuICAgICAgPyBuZXcgRGF0ZShgJHt0ZW1wU2VsZWN0ZWRNb250aH0tMDFgKS50b0xvY2FsZVN0cmluZyhcImRlZmF1bHRcIiwgeyBtb250aDogXCJsb25nXCIsIHllYXI6IFwibnVtZXJpY1wiIH0pXHJcbiAgICAgIDogYCR7ZnJvbURhdGV9IHRvICR7dG9EYXRlfWA7XHJcbiAgICBcclxuICAgIGNvbnN0IGFtb3VudEluV29yZHMgPSBudW1Ub1dvcmRzKGxvYW5TdW1tYXJ5LnRvdGFsX2luY2VudGl2ZSk7XHJcbiAgICBjb25zdCBzbGlwTnVtYmVyID0gYElOQy1MT0FOLSR7RGF0ZS5ub3coKS50b1N0cmluZygpLnNsaWNlKC02KX1gO1xyXG4gICAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tSU4nLCB7IGRheTogJ251bWVyaWMnLCBtb250aDogJ2xvbmcnLCB5ZWFyOiAnbnVtZXJpYycgfSk7XHJcblxyXG4gICAgY29uc3QgbG9nb1VybCA9IGltYWdlSW5wdXQuc3RhcnRzV2l0aCgnaHR0cCcpID8gaW1hZ2VJbnB1dCA6IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gKyBpbWFnZUlucHV0O1xyXG5cclxuICAgIHJldHVybiBgXHJcbiAgICAgIDwhRE9DVFlQRSBodG1sPlxyXG4gICAgICA8aHRtbD5cclxuICAgICAgPGhlYWQ+XHJcbiAgICAgICAgPG1ldGEgY2hhcnNldD1cIlVURi04XCI+XHJcbiAgICAgICAgPHRpdGxlPkxvYW4gSW5jZW50aXZlIFNsaXAgLSAke2FnZW50Py5uYW1lIHx8IFwiQWdlbnRcIn08L3RpdGxlPlxyXG4gICAgICAgIDxzdHlsZT5cclxuICAgICAgICAgIEBwYWdlIHsgXHJcbiAgICAgICAgICAgIHNpemU6IEE0OyBcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAqIHtcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBib2R5IHsgXHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnSGVsdmV0aWNhIE5ldWUnLCBIZWx2ZXRpY2EsIEFyaWFsLCBzYW5zLXNlcmlmOyBcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICAtd2Via2l0LXByaW50LWNvbG9yLWFkanVzdDogZXhhY3Q7XHJcbiAgICAgICAgICAgIHByaW50LWNvbG9yLWFkanVzdDogZXhhY3Q7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5kb2N1bWVudC1jb250YWluZXIge1xyXG4gICAgICAgICAgICB3aWR0aDogMjEwbW07XHJcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDI5N21tO1xyXG4gICAgICAgICAgICBtYXJnaW46IDAgYXV0bztcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgICAgcGFnZS1icmVhay1hZnRlcjogYXZvaWQ7XHJcbiAgICAgICAgICAgIHBhZ2UtYnJlYWstaW5zaWRlOiBhdm9pZDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLyogSGVhZGVyIFNlY3Rpb24gKi9cclxuICAgICAgICAgIC5oZWFkZXItc2VjdGlvbiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICMwMDI2N0MgMCUsICMwMDNkOWUgMTAwJSk7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDIwcHggMjVweDtcclxuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuaGVhZGVyLWNvbnRlbnQge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGZsZXgtd3JhcDogd3JhcDtcclxuICAgICAgICAgICAgZ2FwOiAxNXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAubG9nby1hcmVhIGltZyB7XHJcbiAgICAgICAgICAgIGhlaWdodDogNjBweDtcclxuICAgICAgICAgICAgd2lkdGg6IGF1dG87XHJcbiAgICAgICAgICAgIG9iamVjdC1maXQ6IGNvbnRhaW47XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jb21wYW55LWluZm8ge1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGZsZXg6IDE7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jb21wYW55LW5hbWUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDNweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmNvbXBhbnktdGFnbGluZSB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgb3BhY2l0eTogMC45O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuZG9jdW1lbnQtbWV0YSB7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1sZWZ0OiAxcHggc29saWQgcmdiYSgyNTUsMjU1LDI1NSwwLjMpO1xyXG4gICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDE1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5tZXRhLWl0ZW0ge1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5tZXRhLWxhYmVsIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgb3BhY2l0eTogMC44O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAvKiBUaXRsZSBTZWN0aW9uICovXHJcbiAgICAgICAgICAudGl0bGUtc2VjdGlvbiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmOGY5ZmE7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEycHggMjBweDtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U5ZWNlZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmRvY3VtZW50LXRpdGxlIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMjY3QztcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLyogQ29udGVudCBTZWN0aW9ucyAqL1xyXG4gICAgICAgICAgLmNvbnRlbnQtc2VjdGlvbiB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDE1cHggMjVweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmluZm8tY2FyZCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZTllY2VmO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jYXJkLWhlYWRlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNmOGY5ZmEgMCUsICNlOWVjZWYgMTAwJSk7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHggMTVweDtcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICMwMDI2N0M7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jYXJkLWhlYWRlciBoMyB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMDAyNjdDO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmNhcmQtYm9keSB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEycHggMTVweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmluZm8tZ3JpZCB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICAgICAgICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KDIsIDFmcik7XHJcbiAgICAgICAgICAgIGdhcDogMTJweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmluZm8tcm93IHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmluZm8tbGFiZWwge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNmM3NTdkO1xyXG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5pbmZvLXZhbHVlIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzIxMjUyOTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLyogVGFibGUgU3R5bGVzICovXHJcbiAgICAgICAgICAuc3VtbWFyeS10YWJsZSB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuc3VtbWFyeS10YWJsZSB0ciB7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZTllY2VmO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuc3VtbWFyeS10YWJsZSB0ZCB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDhweCA1cHg7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnN1bW1hcnktdGFibGUgdGQ6Zmlyc3QtY2hpbGQge1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzQ5NTA1NztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnN1bW1hcnktdGFibGUgdGQ6bGFzdC1jaGlsZCB7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzIxMjUyOTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnRvdGFsLXJvdyB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNlOGYwZmU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC50b3RhbC1yb3cgdGQge1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMDAyNjdDICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC8qIEhpZ2hsaWdodCBCb3ggKi9cclxuICAgICAgICAgIC5oaWdobGlnaHQtYm94IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgI2U4ZjBmZSAwJSwgI2Q0ZTJmNyAxMDAlKTtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxNXB4O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDEycHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5oaWdobGlnaHQtbGFiZWwge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMDAyNjdDO1xyXG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5oaWdobGlnaHQtYW1vdW50IHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAyOHB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogODAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMjY3QztcclxuICAgICAgICAgICAgbWFyZ2luOiA1cHggMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmhpZ2hsaWdodC13b3JkcyB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgY29sb3I6ICM0OTUwNTc7XHJcbiAgICAgICAgICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcclxuICAgICAgICAgICAgYm9yZGVyLXRvcDogMXB4IGRhc2hlZCAjMDAyNjdDNDA7XHJcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiA4cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLyogRGVjbGFyYXRpb24gKi9cclxuICAgICAgICAgIC5kZWNsYXJhdGlvbi1ib3gge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZjhmOWZhO1xyXG4gICAgICAgICAgICBib3JkZXItbGVmdDogM3B4IHNvbGlkICMwMDI2N0M7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHggMTVweDtcclxuICAgICAgICAgICAgbWFyZ2luOiAxMnB4IDA7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgY29sb3I6ICM0OTUwNTc7XHJcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC8qIFNpZ25hdHVyZSBTZWN0aW9uICovXHJcbiAgICAgICAgICAuc2lnbmF0dXJlLXNlY3Rpb24ge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAxNXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuc2lnbmF0dXJlLWJveCB7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgd2lkdGg6IDQ1JTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnNpZ25hdHVyZS1pbWFnZSB7XHJcbiAgICAgICAgICAgIG1heC1oZWlnaHQ6IDUwcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDhweDtcclxuICAgICAgICAgICAgb2JqZWN0LWZpdDogY29udGFpbjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnNpZ25hdHVyZS1saW5lIHtcclxuICAgICAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICMyMTI1Mjk7XHJcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiA2cHg7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgY29sb3I6ICM2Yzc1N2Q7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC8qIEZvb3RlciAqL1xyXG4gICAgICAgICAgLmZvb3Rlci1zZWN0aW9uIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzAwMjY3QyAwJSwgIzAwM2Q5ZSAxMDAlKTtcclxuICAgICAgICAgICAgcGFkZGluZzogMTBweCAyMHB4O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgZm9udC1zaXplOiA4cHg7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgYm90dG9tOiAwO1xyXG4gICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICByaWdodDogMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmZvb3Rlci1jb21wYW55IHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogM3B4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuZm9vdGVyLWFkZHJlc3Mge1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAwLjg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDNweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmZvb3Rlci1jb250YWN0IHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMC43O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBAbWVkaWEgcHJpbnQge1xyXG4gICAgICAgICAgICBib2R5IHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuZG9jdW1lbnQtY29udGFpbmVyIHtcclxuICAgICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgICAgICAgIHBhZ2UtYnJlYWstYWZ0ZXI6IGF2b2lkO1xyXG4gICAgICAgICAgICAgIHBhZ2UtYnJlYWstaW5zaWRlOiBhdm9pZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuaGVhZGVyLXNlY3Rpb24sIC5mb290ZXItc2VjdGlvbiB7XHJcbiAgICAgICAgICAgICAgLXdlYmtpdC1wcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0O1xyXG4gICAgICAgICAgICAgIHByaW50LWNvbG9yLWFkanVzdDogZXhhY3Q7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICA8L3N0eWxlPlxyXG4gICAgICA8L2hlYWQ+XHJcbiAgICAgIDxib2R5PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJkb2N1bWVudC1jb250YWluZXJcIj5cclxuICAgICAgICAgIDwhLS0gSGVhZGVyIFNlY3Rpb24gLS0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhlYWRlci1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxvZ28tYXJlYVwiPlxyXG4gICAgICAgICAgICAgICAgPGltZyBzcmM9XCIke2xvZ29Vcmx9XCIgYWx0PVwiTXlDaGl0cyBMb2dvXCIgb25lcnJvcj1cInRoaXMuc3JjPSdkYXRhOmltYWdlL3N2Zyt4bWwsJTNDc3ZnIHhtbG5zPVxcJ2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXFwnIHdpZHRoPVxcJzEwMFxcJyBoZWlnaHQ9XFwnMTAwXFwnIHZpZXdCb3g9XFwnMCAwIDEwMCAxMDBcXCclM0UlM0NyZWN0IHdpZHRoPVxcJzEwMFxcJyBoZWlnaHQ9XFwnMTAwXFwnIGZpbGw9XFwnJTIzMDAyNjdDXFwnLyUzRSUzQ3RleHQgeD1cXCc1MFxcJyB5PVxcJzUwXFwnIHRleHQtYW5jaG9yPVxcJ21pZGRsZVxcJyBkeT1cXCcuM2VtXFwnIGZpbGw9XFwnd2hpdGVcXCcgZm9udC1zaXplPVxcJzE0XFwnIGZvbnQtZmFtaWx5PVxcJ0FyaWFsXFwnJTNFTUMlM0MvdGV4dCUzRSUzQy9zdmclM0UnXCI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbXBhbnktaW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbXBhbnktbmFtZVwiPk1ZQ0hJVFM8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb21wYW55LXRhZ2xpbmVcIj5DaGl0IEZ1bmRzIOKAoiBMb2FucyDigKIgSW52ZXN0bWVudHM8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZG9jdW1lbnQtbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1ldGEtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cIm1ldGEtbGFiZWxcIj5EYXRlOjwvc3Bhbj4gJHtjdXJyZW50RGF0ZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDwhLS0gVGl0bGUgU2VjdGlvbiAtLT5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0aXRsZS1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkb2N1bWVudC10aXRsZVwiPkxvYW4gQ29sbGVjdGlvbiBJbmNlbnRpdmUgU2xpcDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDwhLS0gQ29udGVudCBTZWN0aW9uIC0tPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImNvbnRlbnQtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8IS0tIEFnZW50IERldGFpbHMgQ2FyZCAtLT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tY2FyZFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGgzPkFnZW50IC8gRW1wbG95ZWUgRGV0YWlsczwvaDM+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImluZm8tbGFiZWxcIj5BZ2VudCBOYW1lPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5mby12YWx1ZVwiPiR7YWdlbnQ/Lm5hbWUgfHwgXCJOL0FcIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImluZm8tbGFiZWxcIj5FbXBsb3llZSBJRDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImluZm8tdmFsdWVcIj4ke2FnZW50Py5lbXBsb3llZUNvZGUgfHwgYWdlbnQ/Ll9pZD8uc2xpY2UoLTYpIHx8IFwiTi9BXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmZvLWxhYmVsXCI+UGhvbmUgTnVtYmVyPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5mby12YWx1ZVwiPiR7YWdlbnQ/LnBob25lX251bWJlciB8fCBcIk4vQVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5mby1sYWJlbFwiPlJlcG9ydGluZyBQZXJpb2Q8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmZvLXZhbHVlXCI+JHtwZXJpb2R9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwhLS0gQ29sbGVjdGlvbiBTdW1tYXJ5IENhcmQgLS0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLWNhcmRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxoMz5Db2xsZWN0aW9uICYgSW5jZW50aXZlIFN1bW1hcnk8L2gzPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWJvZHlcIj5cclxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInN1bW1hcnktdGFibGVcIj5cclxuICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD5Ub3RhbCBDb2xsZWN0aW9uIEFtb3VudDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+4oK5JHtsb2FuU3VtbWFyeS50b3RhbF9jb2xsZWN0aW9uPy50b0xvY2FsZVN0cmluZygnZW4tSU4nLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiB9KX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPkluY2VudGl2ZSBQZXJjZW50YWdlIFJhdGU8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPiR7aW5jZW50aXZlUGVyY2VudGFnZX0lPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD5Ub3RhbCBUcmFuc2FjdGlvbnMgKFJlY29yZHMpPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD4ke2xvYW5EYXRhLmxlbmd0aH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPkNvbXBsZXRlZCBMb2FuczwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtsb2FuU3VtbWFyeS5jb21wbGV0ZWRfbG9hbnN9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD5QZW5kaW5nIExvYW5zPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD4ke2xvYW5TdW1tYXJ5LnBlbmRpbmdfbG9hbnN9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzcz1cInRvdGFsLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPVwiZm9udC13ZWlnaHQ6IDcwMDtcIj5Hcm9zcyBJbmNlbnRpdmUgRWFybmVkPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT1cImZvbnQtd2VpZ2h0OiA3MDA7IGNvbG9yOiAjMDAyNjdDO1wiPuKCuSR7bG9hblN1bW1hcnkudG90YWxfaW5jZW50aXZlPy50b0xvY2FsZVN0cmluZygnZW4tSU4nLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiB9KX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8IS0tIEhpZ2hsaWdodCBCb3ggLS0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGlnaGxpZ2h0LWJveFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGlnaGxpZ2h0LWxhYmVsXCI+TmV0IFBheWFibGUgQW1vdW50PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWdobGlnaHQtYW1vdW50XCI+4oK5JHtsb2FuU3VtbWFyeS50b3RhbF9pbmNlbnRpdmU/LnRvTG9jYWxlU3RyaW5nKCdlbi1JTicsIHsgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGlnaGxpZ2h0LXdvcmRzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUnVwZWVzICR7YW1vdW50SW5Xb3Jkc30gT25seVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwhLS0gRGVjbGFyYXRpb24gLS0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkZWNsYXJhdGlvbi1ib3hcIj5cclxuICAgICAgICAgICAgICA8c3Ryb25nPkRlY2xhcmF0aW9uOjwvc3Ryb25nPiBUaGlzIGlzIGEgY29tcHV0ZXItZ2VuZXJhdGVkIGluY2VudGl2ZSBzbGlwLiBUaGUgZGV0YWlscyBjb250YWluZWQgaGVyZWluIGFyZSB0cnVlIHRvIHRoZSBiZXN0IG9mIG91ciBrbm93bGVkZ2UuIEFueSBkaXNjcmVwYW5jeSBzaG91bGQgYmUgcmVwb3J0ZWQgdG8gdGhlIGFjY291bnRzIGRlcGFydG1lbnQgd2l0aGluIDQ4IGhvdXJzIG9mIHJlY2VpcHQuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPCEtLSBTaWduYXR1cmUgU2VjdGlvbiAtLT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNpZ25hdHVyZS1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNpZ25hdHVyZS1ib3hcIj5cclxuICAgICAgICAgICAgICAgICR7YWdlbnRTaWduYXR1cmVEYXRhID8gYDxpbWcgc3JjPVwiJHthZ2VudFNpZ25hdHVyZURhdGF9XCIgY2xhc3M9XCJzaWduYXR1cmUtaW1hZ2VcIiBhbHQ9XCJBZ2VudCBTaWduXCI+YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2lnbmF0dXJlLWxpbmVcIj5BZ2VudCdzIFNpZ25hdHVyZTwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzaWduYXR1cmUtYm94XCI+XHJcbiAgICAgICAgICAgICAgICAke3NpZ25hdHVyZURhdGEgPyBgPGltZyBzcmM9XCIke3NpZ25hdHVyZURhdGF9XCIgY2xhc3M9XCJzaWduYXR1cmUtaW1hZ2VcIiBhbHQ9XCJNYW5hZ2VyIFNpZ25cIj5gIDogXCJcIn1cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzaWduYXR1cmUtbGluZVwiPkF1dGhvcml6ZWQgU2lnbmF0b3J5PC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDwhLS0gRm9vdGVyIFNlY3Rpb24gLS0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9vdGVyLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3Rlci1jb21wYW55XCI+VklKQVlBIFZJTkFZQUsgQ0hJVCBGVU5EUyBQUklWQVRFIExJTUlURUQ8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3Rlci1hZGRyZXNzXCI+IzExLzM2LTI1LCAzcmQgRmxvb3IsIDJuZCBNYWluLCBLYXRocmlndXBwZSBNYWluIFJvYWQsIEJhbmFzaGFua2FyaSAzcmQgU3RhZ2UsIEJlbmdhbHVydS01NjAwODU8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3Rlci1jb250YWN0XCI+TW9iOiA5NDgzOTAwNzc3IHwgUGg6IDA4MC00OTc5IDg3NjMgfCBFbWFpbDogaW5mby5teWNoaXRzQGdtYWlsLmNvbTwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvYm9keT5cclxuICAgICAgPC9odG1sPlxyXG4gICAgYDtcclxuICB9O1xyXG5cclxuICAvLyBHZW5lcmF0ZSBQREYgZnVuY3Rpb25cclxuICBjb25zdCBoYW5kbGVHZW5lcmF0ZVNsaXAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKSB7XHJcbiAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBsb2FkIGVtcGxveWVlIGRhdGEgZmlyc3QgYnkgY2xpY2tpbmcgQ29udGludWUuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNHZW5lcmF0aW5nUERGKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgaHRtbENvbnRlbnQgPSBnZW5lcmF0ZUluY2VudGl2ZVNsaXBDb250ZW50KCk7XHJcbiAgICAgIGNvbnN0IGFnZW50ID0gc2VsZWN0ZWRFbXBsb3llZURldGFpbHM7XHJcbiAgICAgIGNvbnN0IHBlcmlvZCA9IGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgPyB0ZW1wU2VsZWN0ZWRNb250aCA6IGAke2Zyb21EYXRlfV90b18ke3RvRGF0ZX1gO1xyXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGBMb2FuX0luY2VudGl2ZV9TbGlwXyR7YWdlbnQ/Lm5hbWUgfHwgXCJBZ2VudFwifV8ke3BlcmlvZH0ucGRmYDtcclxuXHJcbiAgICAgIGNvbnN0IHRlbXBEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICB0ZW1wRGl2LnN0eWxlLnBvc2l0aW9uID0gXCJhYnNvbHV0ZVwiO1xyXG4gICAgICB0ZW1wRGl2LnN0eWxlLmxlZnQgPSBcIi05OTk5cHhcIjtcclxuICAgICAgdGVtcERpdi5zdHlsZS50b3AgPSBcIi05OTk5cHhcIjtcclxuICAgICAgdGVtcERpdi5zdHlsZS53aWR0aCA9IFwiMjEwbW1cIjtcclxuICAgICAgdGVtcERpdi5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBcIiNmZmZmZmZcIjtcclxuICAgICAgdGVtcERpdi5pbm5lckhUTUwgPSBodG1sQ29udGVudDtcclxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0ZW1wRGl2KTtcclxuXHJcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKHIgPT4gc2V0VGltZW91dChyLCA4MDApKTtcclxuXHJcbiAgICAgIGNvbnN0IGNhbnZhcyA9IGF3YWl0IGh0bWwyY2FudmFzKHRlbXBEaXYsIHtcclxuICAgICAgICBzY2FsZTogMyxcclxuICAgICAgICB1c2VDT1JTOiB0cnVlLFxyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmZmZmZmXCIsXHJcbiAgICAgICAgbG9nZ2luZzogZmFsc2UsXHJcbiAgICAgICAgd2luZG93V2lkdGg6IDgwMCxcclxuICAgICAgICBhbGxvd1RhaW50OiBmYWxzZSxcclxuICAgICAgICBmb3JlaWduT2JqZWN0UmVuZGVyaW5nOiBmYWxzZSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBpbWdEYXRhID0gY2FudmFzLnRvRGF0YVVSTChcImltYWdlL3BuZ1wiKTtcclxuICAgICAgY29uc3QgcGRmID0gbmV3IGpzUERGKFwicFwiLCBcIm1tXCIsIFwiYTRcIik7XHJcbiAgICAgIGNvbnN0IHBhZ2VXaWR0aCA9IDIxMDtcclxuICAgICAgY29uc3QgaW1nV2lkdGggPSBwYWdlV2lkdGg7XHJcbiAgICAgIGNvbnN0IGltZ0hlaWdodCA9IChjYW52YXMuaGVpZ2h0ICogaW1nV2lkdGgpIC8gY2FudmFzLndpZHRoO1xyXG4gICAgICBcclxuICAgICAgcGRmLmFkZEltYWdlKGltZ0RhdGEsIFwiUE5HXCIsIDAsIDAsIGltZ1dpZHRoLCBpbWdIZWlnaHQpO1xyXG4gICAgICBwZGYuc2F2ZShmaWxlTmFtZSk7XHJcblxyXG4gICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHRlbXBEaXYpO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJMb2FuIEluY2VudGl2ZSBTbGlwIGRvd25sb2FkZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBnZW5lcmF0aW5nIFBERjpcIiwgZXJyb3IpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGdlbmVyYXRlIGluY2VudGl2ZSBzbGlwXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNHZW5lcmF0aW5nUERGKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgUHJpbnQgZnVuY3Rpb25cclxuICBjb25zdCBoYW5kbGVQcmludFNsaXAgPSAoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKSB7XHJcbiAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBsb2FkIGVtcGxveWVlIGRhdGEgZmlyc3QgYnkgY2xpY2tpbmcgQ29udGludWUuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaHRtbENvbnRlbnQgPSBnZW5lcmF0ZUluY2VudGl2ZVNsaXBDb250ZW50KCk7XHJcbiAgICBjb25zdCBhZ2VudCA9IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzO1xyXG4gICAgY29uc3QgcGVyaW9kID0gZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIiA/IHRlbXBTZWxlY3RlZE1vbnRoIDogYCR7ZnJvbURhdGV9X3RvXyR7dG9EYXRlfWA7XHJcbiAgICBjb25zdCBmaWxlTmFtZSA9IGBMb2FuX0luY2VudGl2ZV9TbGlwXyR7YWdlbnQ/Lm5hbWUgfHwgXCJBZ2VudFwifV8ke3BlcmlvZH1gO1xyXG4gICAgXHJcbiAgICBjb25zdCBwcmludFdpbmRvdyA9IHdpbmRvdy5vcGVuKFwiXCIsIFwiX2JsYW5rXCIpO1xyXG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQud3JpdGUoaHRtbENvbnRlbnQpO1xyXG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQudGl0bGUgPSBmaWxlTmFtZTtcclxuICAgIHByaW50V2luZG93LmRvY3VtZW50LmNsb3NlKCk7XHJcbiAgICBwcmludFdpbmRvdy5mb2N1cygpO1xyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIHByaW50V2luZG93LnByaW50KCk7XHJcbiAgICAgIHByaW50V2luZG93LmNsb3NlKCk7XHJcbiAgICB9LCA1MDApO1xyXG4gIH07XHJcblxyXG4gIC8vIFByb2Nlc3MgdGFibGUgZGF0YSBmcm9tIHBheW1lbnRzIGFycmF5XHJcbiAgY29uc3QgcHJvY2Vzc2VkVGFibGVEYXRhID0gbG9hbkRhdGEubWFwKChwYXltZW50LCBpbmRleCkgPT4gKHtcclxuICAgIGtleTogcGF5bWVudC5faWQgfHwgaW5kZXgsXHJcbiAgICBzbm86IGluZGV4ICsgMSxcclxuICAgIGN1c3RvbWVyX25hbWU6IHBheW1lbnQudXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICBwaG9uZV9udW1iZXI6IHBheW1lbnQudXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICBsb2FuX2lkOiBwYXltZW50LmxvYW4/LmxvYW5faWQgfHwgXCJOL0FcIixcclxuICAgIGxvYW5fYW1vdW50OiBwYXltZW50Py5sb2FuPy5sb2FuX2Ftb3VudCB8fCBwYXltZW50LnByaW5jaXBhbF9hbW91bnQgfHwgMCxcclxuICAgIGVtaV9hbW91bnQ6IHBheW1lbnQ/LmxvYW4/LmRhaWx5X3BheW1lbnRfYW1vdW50IHx8IHBheW1lbnQubW9udGhseV9pbnN0YWxsbWVudCB8fCAwLFxyXG4gICAgcGFpZF9hbW91bnQ6IHBheW1lbnQucGFpZF9hbW91bnQgfHwgcGF5bWVudC5hbW91bnQgfHwgMCxcclxuICAgIHRyYW5zYWN0aW9uX2RhdGU6IHBheW1lbnQ/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbiAgICBwYXlfZGF0ZTogcGF5bWVudD8ucGF5X2RhdGUgfHwgXCJOL0FcIixcclxuICAgIHBheW1lbnRfbW9kZTogcGF5bWVudC5wYXlfdHlwZSB8fCBwYXltZW50Lm1vZGUgfHwgXCJOL0FcIixcclxuICAgIHJlY2VpcHRfbm86IHBheW1lbnQ/LnJlY2VpcHRfbm8gfHwgXCJOL0FcIixcclxuICB9KSk7XHJcblxyXG4gIC8vIFRhYmxlIGNvbHVtbnNcclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic25vXCIsIGhlYWRlcjogXCJTTC5Ob1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zYWN0aW9uX2RhdGVcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuX2lkXCIsIGhlYWRlcjogXCJMb2FuIElEXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5fYW1vdW50XCIsIGhlYWRlcjogXCJMb2FuIEFtb3VudCAo4oK5KVwiIH0sXHJcbiAgICB7IGtleTogXCJwYWlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiUGFpZCBBbW91bnQgKOKCuSlcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudF9tb2RlXCIsIGhlYWRlcjogXCJQYXltZW50IE1vZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVjZWlwdF9ub1wiLCBoZWFkZXI6IFwiUmVjZWlwdCBOb1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IGN1cnJlbnRNb250aCA9IGAke3RvZGF5LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKFxyXG4gICAgdG9kYXkuZ2V0TW9udGgoKSArIDEsXHJcbiAgKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuXHJcbiAgY29uc3Qgc2VsZWN0ZWRFbXBsb3llZSA9IGVtcGxveWVlcy5maW5kKFxyXG4gICAgKGVtcCkgPT4gZW1wLl9pZCA9PT0gc2VsZWN0ZWRFbXBsb3llZUlkLFxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTEwMCBwLTZcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnRcIj5cclxuICAgICAgICAgICAgICBMb2FuIENvbGxlY3Rpb24gSW5jZW50aXZlIFJlcG9ydFxyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG10LTIgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgIFRyYWNrIGFuZCBtYW5hZ2UgZW1wbG95ZWUgaW5jZW50aXZlcyBhbmQgY29tbWlzc2lvbnNcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtZnVsbCBwLTMgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCB0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIG10LTYgbWItNlwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwIHRvLWluZGlnby01MCBib3JkZXItYlwiPlxyXG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPEZpVGFyZ2V0IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgUXVpY2sgTmF2aWdhdGlvbiB0byBPdGhlciBSZXBvcnRzXHJcbiAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgRXhwbG9yZSBvdGhlciBpbmNlbnRpdmUgcmVwb3J0c1xyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy90YXJnZXQtaW5jZW50aXZlLW5ld1wiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIGJvcmRlci0yIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIHAtNCBob3Zlcjpib3JkZXItYmx1ZS00MDAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ibHVlLTEwMCByb3VuZGVkLWxnIGdyb3VwLWhvdmVyOmJnLWJsdWUtNTAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8RmlUYXJnZXRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPXsyMn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2hpdCBCdXNpbmVzcyBJbmNlbnRpdmUgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICBWaWV3IGNoaXQtYmFzZWQgaW5jZW50aXZlc1xyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOSA1bDcgNy03IDdcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9waWdteWNvbGxlY3Rpb24taW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gYmctd2hpdGUgYm9yZGVyLTIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgcC00IGhvdmVyOmJvcmRlci1ncmVlbi00MDAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmVlbi0xMDAgcm91bmRlZC1sZyBncm91cC1ob3ZlcjpiZy1ncmVlbi01MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPXsyMn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWdyZWVuLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBpZ215IEluY2VudGl2ZSBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRyYWNrIHBpZ215IGNvbGxlY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOSA1bDcgNy03IDdcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuXHJcblxyXG4gICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL2NoaXRjb2xsZWN0aW9uLWluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIGJvcmRlci0yIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIHAtNCBob3Zlcjpib3JkZXItYmx1ZS00MDAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ibHVlLTEwMCByb3VuZGVkLWxnIGdyb3VwLWhvdmVyOmJnLWJsdWUtNTAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8TWRHcm91cHNcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPXsyMn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2hpdCBDb2xsZWN0aW9uIEluY2VudGl2ZSBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRyYWNrIENoaXQgY29sbGVjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHlcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZD1cIk05IDVsNyA3LTcgN1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0gY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IGxnPXs2fT5cclxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1sZyBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLVsxMDBweF0gZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgICB0aXRsZT17PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlRvdGFsIENvbGxlY3Rpb248L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2xvYW5TdW1tYXJ5LnRvdGFsX2NvbGxlY3Rpb259XHJcbiAgICAgICAgICAgICAgICBwcmVjaXNpb249ezJ9XHJcbiAgICAgICAgICAgICAgICBwcmVmaXg9ezxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17eyBjb2xvcjogXCIjM2Y4NjAwXCIsIGZvbnRTaXplOiBcIjI0cHhcIiB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBsZz17Nn0+XHJcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctbGcgaG92ZXI6c2hhZG93LXhsIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1bMTAwcHhdIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICAgICAgdGl0bGU9ezxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5Ub3RhbCBJbmNlbnRpdmU8L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bG9hblN1bW1hcnkudG90YWxfaW5jZW50aXZlfVxyXG4gICAgICAgICAgICAgICAgICBwcmVjaXNpb249ezJ9XHJcbiAgICAgICAgICAgICAgICAgIHByZWZpeD17PFJpc2VPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCIgLz59XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3sgY29sb3I6IFwiIzE4OTBmZlwiLCBmb250U2l6ZTogXCIyNHB4XCIgfX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgPC9Db2w+XHJcblxyXG4gICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IGxnPXs2fT5cclxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1sZyBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLVsxMDBweF0gZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgICB0aXRsZT17PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlRvdGFsIFJlY29yZHM8L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2xvYW5TdW1tYXJ5LnRvdGFsX2xvYW5zfVxyXG4gICAgICAgICAgICAgICAgcHJlZml4PXs8VGVhbU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTUwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17eyBjb2xvcjogXCIjNzIyZWQxXCIsIGZvbnRTaXplOiBcIjI0cHhcIiB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICA8L1Jvdz5cclxuXHJcbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1sZyByb3VuZGVkLXhsIG1iLTZcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMyBib3JkZXItYiBib3JkZXItZ3JheS0xMDBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxGaWxlU2VhcmNoT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgIFJlcG9ydCBGaWx0ZXJzXHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0zIG1iLTNcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgdGV4dC14c1wiIC8+XHJcbiAgICAgICAgICAgICAgICBEYXRlIFNlbGVjdGlvbiBNb2RlXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8UmFkaW8uR3JvdXBcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRlU2VsZWN0aW9uTW9kZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGF0ZVNlbGVjdGlvbk1vZGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFJhZGlvLkJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT1cIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiNTAlXCIsIHRleHRBbGlnbjogXCJjZW50ZXJcIiB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBNb250aGx5XHJcbiAgICAgICAgICAgICAgICA8L1JhZGlvLkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxSYWRpby5CdXR0b25cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9XCJkYXRlLXJhbmdlXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiNTAlXCIsIHRleHRBbGlnbjogXCJjZW50ZXJcIiB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEYXRlIFJhbmdlXHJcbiAgICAgICAgICAgICAgICA8L1JhZGlvLkJ1dHRvbj5cclxuICAgICAgICAgICAgICA8L1JhZGlvLkdyb3VwPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBtYi0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgdGV4dC14c1wiIC8+XHJcbiAgICAgICAgICAgICAgICBTZWxlY3QgRW1wbG95ZWVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkRW1wbG95ZWVJZH1cclxuICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IG5hbWUgb3IgcGhvbmVcIlxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cIm1pZGRsZVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAge2VtcC5uYW1lfSAtIHtlbXAucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdGVkOiB7c2VsZWN0ZWRFbXBsb3llZS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTMgbWItNFwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAge2RhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgPyBcIlNlbGVjdCBNb250aFwiIDogXCJGcm9tIERhdGVcIn1cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIHtkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiID8gKFxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wU2VsZWN0ZWRNb250aCB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBtYXg9e2N1cnJlbnRNb250aH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVRlbXBNb250aENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMS41IHRleHQtc20gYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBGcm9tRGF0ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0yIHB5LTEuNSB0ZXh0LXNtIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgPFBlcmNlbnRhZ2VPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwIHRleHQteHNcIiAvPlxyXG4gICAgICAgICAgICAgICAgSW5jZW50aXZlIFBlcmNlbnRhZ2VcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMVwiXHJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17aW5jZW50aXZlUGVyY2VudGFnZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRJbmNlbnRpdmVQZXJjZW50YWdlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMS41IHRleHQtc20gYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYmx1ZS01MDAgcHItN1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMiB0b3AtMS8yIHRyYW5zZm9ybSAtdHJhbnNsYXRlLXktMS8yIHRleHQtZ3JheS01MDAgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICAlXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2RhdGVTZWxlY3Rpb25Nb2RlID09PSBcImRhdGUtcmFuZ2VcIiAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtMyBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBUbyBEYXRlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBUb0RhdGUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUZW1wVG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMS41IHRleHQtc20gYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMiBtdC0yIHB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBzaXplPVwibWVkaXVtXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEVtcGxveWVlSWQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlscyhudWxsKTtcclxuICAgICAgICAgICAgICAgIHNldFRlbXBTZWxlY3RlZE1vbnRoKGN1cnJlbnRNb250aCk7XHJcbiAgICAgICAgICAgICAgICBzZXRJbmNlbnRpdmVQZXJjZW50YWdlKDEuNSk7XHJcbiAgICAgICAgICAgICAgICBzZXRMb2FuRGF0YShbXSk7XHJcbiAgICAgICAgICAgICAgICBzZXRMb2FuU3VtbWFyeSh7XHJcbiAgICAgICAgICAgICAgICAgIHRvdGFsX2NvbGxlY3Rpb246IDAsXHJcbiAgICAgICAgICAgICAgICAgIHRvdGFsX2luY2VudGl2ZTogMCxcclxuICAgICAgICAgICAgICAgICAgdG90YWxfbG9hbnM6IDAsXHJcbiAgICAgICAgICAgICAgICAgIGNvbXBsZXRlZF9sb2FuczogMCxcclxuICAgICAgICAgICAgICAgICAgcGVuZGluZ19sb2FuczogMCxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgc2V0SXNGaWx0ZXJpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgeWVhciA9IHRvZGF5LmdldEZ1bGxZZWFyKCk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBtb250aCA9IHRvZGF5LmdldE1vbnRoKCkgKyAxO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfS0wMWA7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLmdldERhdGUoKTtcclxuICAgICAgICAgICAgICAgIHNldFRlbXBGcm9tRGF0ZShmaXJzdERheSk7XHJcbiAgICAgICAgICAgICAgICBzZXRUZW1wVG9EYXRlKFxyXG4gICAgICAgICAgICAgICAgICBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfS0ke1N0cmluZyhsYXN0RGF5KS5wYWRTdGFydCgyLCBcIjBcIil9YCxcclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJlc2V0XHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIHNpemU9XCJtZWRpdW1cIlxyXG4gICAgICAgICAgICAgIGljb249ezxGaWxlU2VhcmNoT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb250aW51ZX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC04IHB5LTIuNSBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyBmb250LXNlbWlib2xkIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDb250aW51ZVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0NhcmQ+XHJcblxyXG4gICAgIFxyXG5cclxuICAgICAge2lzRmlsdGVyaW5nICYmIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzICYmIChcclxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctbGcgcm91bmRlZC14bCBtYi02XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMyBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgYm9yZGVyLWIgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPFVzZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICBFbXBsb3llZSBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8U3BhY2U+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgaWNvbj17PFByaW50ZXJPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVByaW50U2xpcH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNjAwIHRleHQtd2hpdGUgaG92ZXI6YmctZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFByaW50IFNsaXBcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBpY29uPXs8RG93bmxvYWRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgIGxvYWRpbmc9e2lzR2VuZXJhdGluZ1BERn1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUdlbmVyYXRlU2xpcH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyZWVuLTYwMCBob3ZlcjpiZy1ncmVlbi03MDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEdlbmVyYXRlIFNsaXBcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9TcGFjZT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgTmFtZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgRW1haWxcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5lbWFpbCB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBQaG9uZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LnBob25lX251bWJlciB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICl9XHJcblxyXG4gICAgIFxyXG4gICAgICB7aXNGaWx0ZXJpbmcgJiYgbG9hbkRhdGEubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIHJvdW5kZWQteGwgbWItNlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTMgYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTUwIHRvLWVtZXJhbGQtNTAgYm9yZGVyLWJcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RmFSdXBlZVNpZ24gY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIiAvPlxyXG4gICAgICAgICAgICAgIENvbGxlY3Rpb24gU3VtbWFyeVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGxnOmdyaWQtY29scy01IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAgdG8tYmx1ZS0xMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgUGVyaW9kXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ibHVlLTcwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShgJHt0ZW1wU2VsZWN0ZWRNb250aH0tMDFgKS50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJkZWZhdWx0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJsb25nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgOiBgJHtmcm9tRGF0ZX0gdG8gJHt0b0RhdGV9YH1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwIHRvLWdyZWVuLTEwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBJbmNlbnRpdmUgUmF0ZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAge2luY2VudGl2ZVBlcmNlbnRhZ2V9JVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwIHRvLXB1cnBsZS0xMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgUmVjb3Jkc1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtsb2FuRGF0YS5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmVlbi01MCB0by1ncmVlbi0xMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgQ29sbGVjdGlvblxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtsb2FuU3VtbWFyeS50b3RhbF9jb2xsZWN0aW9uPy50b0ZpeGVkKDIpfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1ibHVlLTEwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBUb3RhbCBJbmNlbnRpdmVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNzAwIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgPFJpc2VPdXRsaW5lZCAvPlxyXG4gICAgICAgICAgICAgICAgICB7bG9hblN1bW1hcnkudG90YWxfaW5jZW50aXZlPy50b0ZpeGVkKDIpfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0yMFwiPlxyXG4gICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICBpc0ZpbHRlcmluZyAmJlxyXG4gICAgICAgIGxvYW5EYXRhLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwIHRvLWluZGlnby01MCBib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8RmlsZVNlYXJjaE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgUGF5bWVudCBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgU2hvd2luZyB7bG9hbkRhdGEubGVuZ3RofSBwYXltZW50IHJlY29yZHNcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGRhdGE9e3Byb2Nlc3NlZFRhYmxlRGF0YX1cclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BMb2FuX0NvbGxlY3Rpb25fSW5jZW50aXZlX1JlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcclxuICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZSBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiUGVyaW9kXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiSW5jZW50aXZlIFBlcmNlbnRhZ2VcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBDb2xsZWN0aW9uXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgSW5jZW50aXZlXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgUmVjb3Jkc1wiLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShgJHt0ZW1wU2VsZWN0ZWRNb250aH0tMDFgKS50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJkZWZhdWx0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJsb25nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgOiBgJHtmcm9tRGF0ZX0gdG8gJHt0b0RhdGV9YCxcclxuICAgICAgICAgICAgICAgICAgYCR7aW5jZW50aXZlUGVyY2VudGFnZX0lYCxcclxuICAgICAgICAgICAgICAgICAgYOKCuSR7bG9hblN1bW1hcnkudG90YWxfY29sbGVjdGlvbj8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCBcIjBcIn1gLFxyXG4gICAgICAgICAgICAgICAgICBg4oK5JHtsb2FuU3VtbWFyeS50b3RhbF9pbmNlbnRpdmU/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9YCxcclxuICAgICAgICAgICAgICAgICAgbG9hbkRhdGEubGVuZ3RoIHx8IFwiMFwiLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BMb2FuQ29sbGVjdGlvblJlcG9ydF8ke3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiYWxsXCJ9XyR7XHJcbiAgICAgICAgICAgICAgICAgIGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgICA/IHRlbXBTZWxlY3RlZE1vbnRoXHJcbiAgICAgICAgICAgICAgICAgICAgOiBgJHtmcm9tRGF0ZX1fdG9fJHt0b0RhdGV9YFxyXG4gICAgICAgICAgICAgICAgfS5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIClcclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtpc0ZpbHRlcmluZyAmJiAhbG9hZGluZyAmJiBsb2FuRGF0YS5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1sZyByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LWxnIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgTm8gcGF5bWVudCByZWNvcmRzIGZvdW5kIGZvciB0aGUgc2VsZWN0ZWQgcGVyaW9kLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9hbkNvbGxlY3Rpb25JbmNlbnRpdmVSZXBvcnQ7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0xvYW5Db2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0LmpzeCJ9