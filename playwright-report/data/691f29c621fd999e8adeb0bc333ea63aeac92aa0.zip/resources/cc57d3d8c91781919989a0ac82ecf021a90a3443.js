import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PenaltyWhatsappMessageMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import {
  Button,
  Select,
  Input,
  Modal,
  Checkbox,
  Alert,
  Tag,
  message
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  SearchOutlined,
  ReloadOutlined,
  ClockCircleOutlined,
  CheckCircleOutlined,
  ExclamationCircleOutlined,
  WhatsAppOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import api from "/src/instance/TokenInstance.js";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { Phone, User } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const { Option } = Select;
function PenaltyWhatsappMessageMenu() {
  _s();
  const [tableData, setTableData] = useState([]);
  const [groups, setGroups] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [selectedRows, setSelectedRows] = useState({});
  const [isSendingWhatsapp, setIsSendingWhatsapp] = useState(false);
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState(false);
  const [filters, setFilters] = useState({
    groupId: "",
    startDate: "",
    endDate: "",
    status: "all"
  });
  const [stats, setStats] = useState({
    totalCustomers: 0,
    totalPenaltyAmount: 0,
    totalLateFeeAmount: 0,
    totalDueAmount: 0
  });
  const [selectAll, setSelectAll] = useState(false);
  const formatNumber = (num) => {
    return parseFloat(num || 0).toFixed(2);
  };
  const formatCurrency = (amount) => {
    return `₹${parseFloat(amount).toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`;
  };
  const fetchGroups = async () => {
    try {
      const response = await api.get("/group/get-group-admin");
      setGroups(response.data || []);
    } catch (error) {
      console.error("Error fetching groups:", error);
      message.error("Failed to fetch groups");
    }
  };
  const formattedTableData = useMemo(() => {
    return tableData.map((penalty2, index) => {
      const totalPenaltyAmount = (penalty2.penalty_amount || 0) + (penalty2.late_fee_amount || 0);
      const totalPenaltySum = penalty2.total_penalty_sum || 0;
      const totalLateFeeSum = penalty2.total_late_fee_sum || 0;
      const totalDue = penalty2.current_balance || 0;
      const balance2 = totalDue - totalPenaltySum - totalLateFeeSum;
      const totalOutstanding = balance2 + totalPenaltySum + totalLateFeeSum;
      return {
        key: penalty2._id,
        _id: penalty2._id,
        id: index + 1,
        customerName: penalty2.user_id?.full_name || "N/A",
        phoneNumber: penalty2.user_id?.phone_number || "N/A",
        groupName: penalty2.group_id?.group_name || "N/A",
        ticket: penalty2.ticket,
        penaltyAmount: /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-blue-500", children: [
          "₹",
          formatNumber(penalty2.penalty_amount)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 108,
          columnNumber: 9
        }, this),
        lateFeeAmount: formatNumber(penalty2.late_fee_amount),
        totalPenalty: formatNumber(totalPenaltyAmount),
        // currentBalance: formatNumber(penalty.current_balance),
        // totalOutstanding: formatNumber(totalOutstanding),
        balance: formatNumber(balance2),
        // currentBalance: formatNumber(balance),
        currentBalance: /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-orange-600", children: [
          "₹",
          formatNumber(balance2)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 122,
          columnNumber: 9
        }, this),
        currentBalanceRaw: balance2,
        totalOutstanding: /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-red-600", children: [
          "₹",
          formatNumber(totalOutstanding)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 129,
          columnNumber: 9
        }, this),
        penaltyAmountRaw: penalty2.penalty_amount || 0,
        lateFeeAmountRaw: penalty2.late_fee_amount || 0,
        totalPenaltyRaw: totalPenaltyAmount,
        // totalOutstandingRaw: totalOutstanding,
        balanceRaw: balance2,
        totalOutstandingRaw: totalOutstanding,
        status: penalty2.penalty_amount > 0 || penalty2.late_fee_amount > 0 ? "Pending" : "Paid",
        createdAt: penalty2.createdAt,
        checkBox: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: selectedRows[penalty2._id] || false,
            onChange: (e) => handleCheckboxChange(penalty2, e),
            onClick: (e) => e.stopPropagation(),
            style: { cursor: "pointer", width: "16px", height: "16px" }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 142,
            columnNumber: 9
          },
          this
        )
      };
    });
  }, [tableData, selectedRows]);
  const filteredData = useMemo(() => {
    if (!searchText) return formattedTableData;
    return formattedTableData.filter(
      (item) => item.customerName?.toLowerCase().includes(searchText.toLowerCase()) || item.phoneNumber?.includes(searchText) || item.groupName?.toLowerCase().includes(searchText.toLowerCase()) || item.ticket?.toString().includes(searchText)
    );
  }, [formattedTableData, searchText]);
  const handleCheckboxChange = (record, e) => {
    const checked = e.target.checked;
    setSelectedRows((prev) => ({
      ...prev,
      [record._id]: checked
    }));
  };
  const handleSelectAll = (checked) => {
    setSelectAll(checked);
    const newSelectedRows = {};
    if (checked) {
      filteredData.forEach((item) => {
        newSelectedRows[item._id] = true;
      });
    }
    setSelectedRows(newSelectedRows);
  };
  const getSelectedCount = () => {
    return Object.values(selectedRows).filter((value) => value === true).length;
  };
  const fetchPenalties = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (filters.groupId) params.append("groupId", filters.groupId);
      if (filters.startDate) params.append("startDate", filters.startDate);
      if (filters.endDate) params.append("endDate", filters.endDate);
      params.append("limit", "1000");
      const response = await api.get(
        `/penalty-management/get-penalties-with-totals?${params.toString()}`
      );
      let penaltiesData = response.data.data || [];
      if (filters.status !== "all") {
        if (filters.status === "pending") {
          penaltiesData = penaltiesData.filter(
            (p) => p.penalty_amount > 0 || p.late_fee_amount > 0
          );
        } else if (filters.status === "paid") {
          penaltiesData = penaltiesData.filter(
            (p) => p.penalty_amount === 0 && p.late_fee_amount === 0
          );
        }
      }
      const uniqueCustomers = /* @__PURE__ */ new Map();
      let totalPenalty = 0;
      let totalLateFee = 0;
      let totalDue = 0;
      penaltiesData.forEach((penalty2) => {
        const customerKey = `${penalty2.user_id?._id}_${penalty2.group_id?._id}_${penalty2.ticket}`;
        if (!uniqueCustomers.has(customerKey)) {
          uniqueCustomers.set(customerKey, true);
        }
        totalPenalty += penalty2.penalty_amount || 0;
        totalLateFee += penalty2.late_fee_amount || 0;
        totalDue += penalty2.current_balance || 0;
      });
      setStats({
        totalCustomers: uniqueCustomers.size,
        totalPenaltyAmount: formatNumber(totalPenalty),
        totalLateFeeAmount: formatNumber(totalLateFee),
        totalDueAmount: formatNumber(totalDue)
      });
      setSelectedRows({});
      setSelectAll(false);
      setTableData(penaltiesData);
    } catch (error) {
      console.error("Error fetching penalties:", error);
      message.error("Failed to fetch penalties");
      setTableData([]);
    } finally {
      setIsLoading(false);
    }
  };
  const handleSendWhatsApp = () => {
    const selectedCount2 = getSelectedCount();
    if (selectedCount2 === 0) {
      message.warning("Please select at least one customer to send WhatsApp message");
      return;
    }
    setIsVerifyModalOpen(true);
  };
  const sendWhatsAppMessages = async () => {
    setIsSendingWhatsapp(true);
    try {
      const selectedItems = formattedTableData.filter(
        (item) => selectedRows[item._id] === true
      );
      const receivers = {};
      selectedItems.forEach((item, index) => {
        receivers[`receiver_${index}`] = {
          info: {
            status: true,
            userName: item.customerName,
            userPhone: item.phoneNumber,
            groupName: item.groupName,
            paymentsTicket: item.ticket,
            penaltyAmount: item.penaltyAmount,
            lateFeeAmount: item.lateFeeAmount,
            totalPenalty: item.totalPenalty,
            currentBalance: balance,
            totalOutstanding: balance + penalty + lateFee,
            // currentBalance: (item.currentBalance),
            // totalOutstanding: (item.totalOutstanding),
            dueDate: moment(item.createdAt).format("DD-MM-YYYY")
          }
        };
      });
      const response = await api.post("/whatsapp/penalty-added", receivers);
      if (response.data.success !== void 0) {
        const successCount = response.data.success || response.data.successCount || 0;
        const errorCount = response.data.error || response.data.errorCount || 0;
        if (successCount > 0) {
          message.success(`✅ Messages sent: ${successCount} successful, ${errorCount} failed`);
          setSelectedRows({});
          setSelectAll(false);
        } else {
          message.error("Failed to send messages");
        }
      } else {
        message.success(response.data.message || "Messages sent successfully");
        setSelectedRows({});
        setSelectAll(false);
      }
      setIsVerifyModalOpen(false);
    } catch (error) {
      console.error("Error sending WhatsApp messages:", error);
      message.error(error.response?.data?.message || "Failed to send WhatsApp messages");
    } finally {
      setIsSendingWhatsapp(false);
    }
  };
  const handleClearFilters = () => {
    setFilters({
      groupId: "",
      startDate: "",
      endDate: "",
      status: "all"
    });
    setSelectedRows({});
    setSelectAll(false);
  };
  useEffect(() => {
    fetchGroups();
  }, []);
  useEffect(() => {
    fetchPenalties();
  }, [filters]);
  const selectedCount = getSelectedCount();
  useEffect(() => {
    if (filteredData.length > 0) {
      const allSelected = filteredData.every((item) => selectedRows[item._id] === true);
      setSelectAll(allSelected);
    } else {
      setSelectAll(false);
    }
  }, [selectedRows, filteredData]);
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "customerName", header: "Customer Name" },
    { key: "phoneNumber", header: "Phone Number" },
    { key: "groupName", header: "Group" },
    { key: "ticket", header: "Ticket" },
    { key: "currentBalance", header: "Balance" },
    { key: "penaltyAmount", header: "Penalty Amount" },
    { key: "lateFeeAmount", header: "Late Fee" },
    { key: "totalPenalty", header: "Total Penalty" },
    { key: "totalOutstanding", header: "Balance + Penalty" },
    { key: "status", header: "Status" },
    { key: "checkBox", header: "Select" }
  ];
  const excelColumns = [
    { key: "id", header: "SL. NO" },
    { key: "customerName", header: "Customer Name" },
    { key: "phoneNumber", header: "Phone Number" },
    { key: "groupName", header: "Group" },
    { key: "ticket", header: "Ticket" },
    { key: "balanceRaw", header: "Balance" },
    { key: "penaltyAmountRaw", header: "Penalty Amount" },
    { key: "lateFeeAmountRaw", header: "Late Fee" },
    { key: "totalPenaltyRaw", header: "Total Penalty" },
    { key: "totalOutstandingRaw", header: "Balance + Penalty" },
    { key: "status", header: "Status" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen mt-20 bg-gradient-to-br from-gray-50 to-gray-100", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
        lineNumber: 393,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
        lineNumber: 398,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8 flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-800 mb-2 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "text-green-600 text-3xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 403,
                columnNumber: 17
              }, this),
              "Penalty WhatsApp Management"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 402,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600", children: "Send WhatsApp messages to customers with pending penalties and late fees" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 406,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 401,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              icon: /* @__PURE__ */ jsxDEV(ReloadOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 411,
                columnNumber: 21
              }, this),
              onClick: fetchPenalties,
              loading: isLoading,
              children: "Refresh"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 410,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 400,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-blue-500", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase", children: "Total Customers" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 423,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: stats.totalCustomers }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 424,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 422,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 421,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-red-500", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase", children: "Total Penalty" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 429,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-red-600", children: formatCurrency(stats.totalPenaltyAmount) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 430,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 428,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 427,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-orange-500", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase", children: "Total Late Fee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 437,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-orange-600", children: formatCurrency(stats.totalLateFeeAmount) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 438,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 436,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 435,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-purple-500", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase", children: "Total Outstanding" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 445,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-purple-600", children: formatCurrency(stats.totalDueAmount) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 446,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 444,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 443,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 420,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(SearchOutlined, { className: "text-blue-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 457,
                columnNumber: 17
              }, this),
              "Filter Customers"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 456,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { onClick: handleClearFilters, children: "Clear Filters" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 460,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 455,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Filter by Group",
                allowClear: true,
                value: filters.groupId || void 0,
                onChange: (value) => setFilters((prev) => ({ ...prev, groupId: value || "" })),
                children: groups.map(
                  (group) => /* @__PURE__ */ jsxDEV(Option, { value: group._id, children: group.group_name }, group._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                    lineNumber: 472,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 463,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: filters.status,
                onChange: (value) => setFilters((prev) => ({ ...prev, status: value })),
                children: [
                  /* @__PURE__ */ jsxDEV(Option, { value: "all", children: "All Status" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                    lineNumber: 483,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Option, { value: "pending", children: "Pending" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                    lineNumber: 484,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Option, { value: "paid", children: "Paid" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                    lineNumber: 485,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 477,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                placeholder: "Start Date",
                value: filters.startDate,
                onChange: (e) => setFilters((prev) => ({ ...prev, startDate: e.target.value }))
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 487,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                placeholder: "End Date",
                value: filters.endDate,
                onChange: (e) => setFilters((prev) => ({ ...prev, endDate: e.target.value }))
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 495,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 462,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 454,
          columnNumber: 11
        }, this),
        selectedCount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg shadow p-4 mb-6 transition-all duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-600 text-white rounded-full h-10 w-10 flex items-center justify-center font-bold text-lg shadow-md", children: selectedCount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 511,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-lg", children: "Customer(s) Selected" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 514,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 510,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              icon: /* @__PURE__ */ jsxDEV(WhatsAppOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 521,
                columnNumber: 25
              }, this),
              size: "large",
              className: "bg-green-600 hover:bg-green-700 border-green-600",
              onClick: handleSendWhatsApp,
              children: [
                "Send WhatsApp (",
                selectedCount,
                ")"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 519,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 518,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 509,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 508,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 min-h-[400px]", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 536,
          columnNumber: 13
        }, this) : filteredData.length === 0 ? /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading: false,
            failure: true,
            data: "Penalty Records"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 538,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filteredData,
            columns,
            exportCols: excelColumns,
            exportedFileName: `Penalty_WhatsApp_${moment().format("DD-MM-YYYY")}`,
            selectAllCheckbox: {
              checked: selectAll,
              onChange: handleSelectAll
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 544,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 534,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
        lineNumber: 399,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
      lineNumber: 397,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: isVerifyModalOpen,
        onCancel: () => setIsVerifyModalOpen(false),
        footer: null,
        centered: true,
        width: 500,
        children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 text-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 rounded-full p-4", children: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-4xl text-red-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 570,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 569,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 568,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800 mb-2", children: "Are You Sure?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 573,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mb-6", children: [
            "You are about to send WhatsApp messages to",
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-blue-600", children: [
              selectedCount,
              " customer(s)"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 578,
              columnNumber: 13
            }, this),
            ".",
            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
              lineNumber: 579,
              columnNumber: 13
            }, this),
            "This action cannot be undone once initiated."
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 576,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-4", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "large",
                onClick: () => setIsVerifyModalOpen(false),
                className: "w-32",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 583,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                size: "large",
                loading: isSendingWhatsapp,
                onClick: sendWhatsAppMessages,
                className: "w-32 bg-green-600 hover:bg-green-700",
                children: "Yes, Send"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
                lineNumber: 590,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
            lineNumber: 582,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
          lineNumber: 567,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
        lineNumber: 560,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx",
    lineNumber: 392,
    columnNumber: 5
  }, this);
}
_s(PenaltyWhatsappMessageMenu, "E5E7qHLHQULvQfxz7n30cpzI2yY=");
_c = PenaltyWhatsappMessageMenu;
export default PenaltyWhatsappMessageMenu;
var _c;
$RefreshReg$(_c, "PenaltyWhatsappMessageMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyWhatsappMessageMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkdVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFHVixTQUFTQSxVQUFVQyxXQUFXQyxlQUFlO0FBQzdDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLFlBQVk7QUFDbkIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLE9BQU9DLFlBQVk7QUFFNUIsTUFBTSxFQUFFQyxPQUFPLElBQUl0QjtBQUVuQixTQUFTdUIsNkJBQTZCO0FBQUFDLEtBQUE7QUFFcEMsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUk5QixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDK0IsUUFBUUMsU0FBUyxJQUFJaEMsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2lDLFdBQVdDLFlBQVksSUFBSWxDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNtQyxZQUFZQyxhQUFhLElBQUlwQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDcUMsY0FBY0MsZUFBZSxJQUFJdEMsU0FBUyxDQUFDLENBQUM7QUFDbkQsUUFBTSxDQUFDdUMsbUJBQW1CQyxvQkFBb0IsSUFBSXhDLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUN5QyxtQkFBbUJDLG9CQUFvQixJQUFJMUMsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzJDLFNBQVNDLFVBQVUsSUFBSTVDLFNBQVM7QUFBQSxJQUNyQzZDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsU0FBUztBQUFBLElBQ1RDLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFDRCxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSWxELFNBQVM7QUFBQSxJQUNqQ21ELGdCQUFnQjtBQUFBLElBQ2hCQyxvQkFBb0I7QUFBQSxJQUNwQkMsb0JBQW9CO0FBQUEsSUFDcEJDLGdCQUFnQjtBQUFBLEVBQ2xCLENBQUM7QUFDRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXhELFNBQVMsS0FBSztBQUdoRCxRQUFNeUQsZUFBZUEsQ0FBQ0MsUUFBUTtBQUM1QixXQUFPQyxXQUFXRCxPQUFPLENBQUMsRUFBRUUsUUFBUSxDQUFDO0FBQUEsRUFDdkM7QUFHQSxRQUFNQyxpQkFBaUJBLENBQUNDLFdBQVc7QUFDakMsV0FBTyxJQUFJSCxXQUFXRyxNQUFNLEVBQUVDLGVBQWUsU0FBUztBQUFBLE1BQ3BEQyx1QkFBdUI7QUFBQSxNQUN2QkMsdUJBQXVCO0FBQUEsSUFDekIsQ0FBQyxDQUFDO0FBQUEsRUFDSjtBQUdBLFFBQU1DLGNBQWMsWUFBWTtBQUM5QixRQUFJO0FBQ0YsWUFBTUMsV0FBVyxNQUFNOUMsSUFBSStDLElBQUksd0JBQXdCO0FBQ3ZEcEMsZ0JBQVVtQyxTQUFTRSxRQUFRLEVBQUU7QUFBQSxJQUMvQixTQUFTQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBQzdDNUQsY0FBUTRELE1BQU0sd0JBQXdCO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBR0EsUUFBTUUscUJBQXFCdEUsUUFBUSxNQUFNO0FBQ3ZDLFdBQU8yQixVQUFVNEMsSUFBSSxDQUFDQyxVQUFTQyxVQUFVO0FBRXZDLFlBQU12QixzQkFBc0JzQixTQUFRRSxrQkFBa0IsTUFBTUYsU0FBUUcsbUJBQW1CO0FBRW5GLFlBQU1DLGtCQUFrQkosU0FBUUsscUJBQXFCO0FBQ3JELFlBQU1DLGtCQUFrQk4sU0FBUU8sc0JBQXNCO0FBRXRELFlBQU1DLFdBQVdSLFNBQVFTLG1CQUFtQjtBQUU1QyxZQUFNQyxXQUNKRixXQUNBSixrQkFDQUU7QUFFRixZQUFNSyxtQkFDSkQsV0FDQU4sa0JBQ0FFO0FBQ04sYUFBTztBQUFBLFFBQ0xNLEtBQUtaLFNBQVFhO0FBQUFBLFFBQ2JBLEtBQUtiLFNBQVFhO0FBQUFBLFFBQ2JDLElBQUliLFFBQVE7QUFBQSxRQUNaYyxjQUFjZixTQUFRZ0IsU0FBU0MsYUFBYTtBQUFBLFFBQzVDQyxhQUFhbEIsU0FBUWdCLFNBQVNHLGdCQUFnQjtBQUFBLFFBQzlDQyxXQUFXcEIsU0FBUXFCLFVBQVVDLGNBQWM7QUFBQSxRQUMzQ0MsUUFBUXZCLFNBQVF1QjtBQUFBQSxRQUNoQkMsZUFDRSx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSxVQUN0Q3pDLGFBQWFpQixTQUFRRSxjQUFjO0FBQUEsYUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVJO0FBQUEsUUFHTnVCLGVBQWUxQyxhQUFhaUIsU0FBUUcsZUFBZTtBQUFBLFFBQ25EdUIsY0FBYzNDLGFBQWFMLGtCQUFrQjtBQUFBO0FBQUE7QUFBQSxRQUc3Q2dDLFNBQVUzQixhQUFhMkIsUUFBTztBQUFBO0FBQUEsUUFJMUJpQixnQkFDRSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCO0FBQUE7QUFBQSxVQUN4QzVDLGFBQWEyQixRQUFPO0FBQUEsYUFEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFRmtCLG1CQUFtQmxCO0FBQUFBLFFBRXJCQyxrQkFDRSx1QkFBQyxVQUFLLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxVQUNyQzVCLGFBQWE0QixnQkFBZ0I7QUFBQSxhQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVKa0Isa0JBQWtCN0IsU0FBUUUsa0JBQWtCO0FBQUEsUUFDNUM0QixrQkFBa0I5QixTQUFRRyxtQkFBbUI7QUFBQSxRQUM3QzRCLGlCQUFpQnJEO0FBQUFBO0FBQUFBLFFBRWpCc0QsWUFBWXRCO0FBQUFBLFFBQ1p1QixxQkFBcUJ0QjtBQUFBQSxRQUNyQnJDLFFBQVMwQixTQUFRRSxpQkFBaUIsS0FBS0YsU0FBUUcsa0JBQWtCLElBQUssWUFBWTtBQUFBLFFBQ2xGK0IsV0FBV2xDLFNBQVFrQztBQUFBQSxRQUNuQkMsVUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU3hFLGFBQWFxQyxTQUFRYSxHQUFHLEtBQUs7QUFBQSxZQUN0QyxVQUFVLENBQUN1QixNQUFNQyxxQkFBcUJyQyxVQUFTb0MsQ0FBQztBQUFBLFlBQ2hELFNBQVMsQ0FBQ0EsTUFBTUEsRUFBRUUsZ0JBQWdCO0FBQUEsWUFDbEMsT0FBTyxFQUFFQyxRQUFRLFdBQVdDLE9BQU8sUUFBUUMsUUFBUSxPQUFPO0FBQUE7QUFBQSxVQUw1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLOEQ7QUFBQSxNQUdsRTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDdEYsV0FBV1EsWUFBWSxDQUFDO0FBRTVCLFFBQU0rRSxlQUFlbEgsUUFBUSxNQUFNO0FBQ2pDLFFBQUksQ0FBQ2lDLFdBQVksUUFBT3FDO0FBQ3hCLFdBQU9BLG1CQUFtQjZDO0FBQUFBLE1BQ3hCLENBQUNDLFNBQ0NBLEtBQUs3QixjQUFjOEIsWUFBWSxFQUFFQyxTQUFTckYsV0FBV29GLFlBQVksQ0FBQyxLQUNsRUQsS0FBSzFCLGFBQWE0QixTQUFTckYsVUFBVSxLQUNyQ21GLEtBQUt4QixXQUFXeUIsWUFBWSxFQUFFQyxTQUFTckYsV0FBV29GLFlBQVksQ0FBQyxLQUMvREQsS0FBS3JCLFFBQVF3QixTQUFTLEVBQUVELFNBQVNyRixVQUFVO0FBQUEsSUFDL0M7QUFBQSxFQUNGLEdBQUcsQ0FBQ3FDLG9CQUFvQnJDLFVBQVUsQ0FBQztBQUduQyxRQUFNNEUsdUJBQXVCQSxDQUFDVyxRQUFRWixNQUFNO0FBQzFDLFVBQU1hLFVBQVViLEVBQUVjLE9BQU9EO0FBQ3pCckYsb0JBQWdCLENBQUF1RixVQUFTO0FBQUEsTUFDdkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDSCxPQUFPbkMsR0FBRyxHQUFHb0M7QUFBQUEsSUFDaEIsRUFBRTtBQUFBLEVBQ0o7QUFHQSxRQUFNRyxrQkFBa0JBLENBQUNILFlBQVk7QUFDbkNuRSxpQkFBYW1FLE9BQU87QUFDcEIsVUFBTUksa0JBQWtCLENBQUM7QUFDekIsUUFBSUosU0FBUztBQUNYUCxtQkFBYVksUUFBUSxDQUFBVixTQUFRO0FBQzNCUyx3QkFBZ0JULEtBQUsvQixHQUFHLElBQUk7QUFBQSxNQUM5QixDQUFDO0FBQUEsSUFDSDtBQUNBakQsb0JBQWdCeUYsZUFBZTtBQUFBLEVBQ2pDO0FBR0EsUUFBTUUsbUJBQW1CQSxNQUFNO0FBQzdCLFdBQU9DLE9BQU9DLE9BQU85RixZQUFZLEVBQUVnRixPQUFPLENBQUFlLFVBQVNBLFVBQVUsSUFBSSxFQUFFQztBQUFBQSxFQUNyRTtBQUdBLFFBQU1DLGlCQUFpQixZQUFZO0FBQ2pDcEcsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTXFHLFNBQVMsSUFBSUMsZ0JBQWdCO0FBQ25DLFVBQUk3RixRQUFRRSxRQUFTMEYsUUFBT0UsT0FBTyxXQUFXOUYsUUFBUUUsT0FBTztBQUM3RCxVQUFJRixRQUFRRyxVQUFXeUYsUUFBT0UsT0FBTyxhQUFhOUYsUUFBUUcsU0FBUztBQUNuRSxVQUFJSCxRQUFRSSxRQUFTd0YsUUFBT0UsT0FBTyxXQUFXOUYsUUFBUUksT0FBTztBQUM3RHdGLGFBQU9FLE9BQU8sU0FBUyxNQUFNO0FBRTdCLFlBQU10RSxXQUFXLE1BQU05QyxJQUFJK0M7QUFBQUEsUUFDekIsaURBQWlEbUUsT0FBT2QsU0FBUyxDQUFDO0FBQUEsTUFDcEU7QUFDQSxVQUFJaUIsZ0JBQWdCdkUsU0FBU0UsS0FBS0EsUUFBUTtBQUUxQyxVQUFJMUIsUUFBUUssV0FBVyxPQUFPO0FBQzVCLFlBQUlMLFFBQVFLLFdBQVcsV0FBVztBQUNoQzBGLDBCQUFnQkEsY0FBY3JCO0FBQUFBLFlBQzVCLENBQUNzQixNQUFNQSxFQUFFL0QsaUJBQWlCLEtBQUsrRCxFQUFFOUQsa0JBQWtCO0FBQUEsVUFDckQ7QUFBQSxRQUNGLFdBQVdsQyxRQUFRSyxXQUFXLFFBQVE7QUFDcEMwRiwwQkFBZ0JBLGNBQWNyQjtBQUFBQSxZQUM1QixDQUFDc0IsTUFBTUEsRUFBRS9ELG1CQUFtQixLQUFLK0QsRUFBRTlELG9CQUFvQjtBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFHQSxZQUFNK0Qsa0JBQWtCLG9CQUFJQyxJQUFJO0FBQ2hDLFVBQUl6QyxlQUFlO0FBQ25CLFVBQUkwQyxlQUFlO0FBQ25CLFVBQUk1RCxXQUFXO0FBRWZ3RCxvQkFBY1YsUUFBUSxDQUFDdEQsYUFBWTtBQUNqQyxjQUFNcUUsY0FBYyxHQUFHckUsU0FBUWdCLFNBQVNILEdBQUcsSUFBSWIsU0FBUXFCLFVBQVVSLEdBQUcsSUFBSWIsU0FBUXVCLE1BQU07QUFDdEYsWUFBSSxDQUFDMkMsZ0JBQWdCSSxJQUFJRCxXQUFXLEdBQUc7QUFDckNILDBCQUFnQkssSUFBSUYsYUFBYSxJQUFJO0FBQUEsUUFDdkM7QUFDQTNDLHdCQUFnQjFCLFNBQVFFLGtCQUFrQjtBQUMxQ2tFLHdCQUFnQnBFLFNBQVFHLG1CQUFtQjtBQUMzQ0ssb0JBQVlSLFNBQVFTLG1CQUFtQjtBQUFBLE1BQ3pDLENBQUM7QUFFRGpDLGVBQVM7QUFBQSxRQUNQQyxnQkFBZ0J5RixnQkFBZ0JNO0FBQUFBLFFBQ2hDOUYsb0JBQW9CSyxhQUFhMkMsWUFBWTtBQUFBLFFBQzdDL0Msb0JBQW9CSSxhQUFhcUYsWUFBWTtBQUFBLFFBQzdDeEYsZ0JBQWdCRyxhQUFheUIsUUFBUTtBQUFBLE1BQ3ZDLENBQUM7QUFHRDVDLHNCQUFnQixDQUFDLENBQUM7QUFDbEJrQixtQkFBYSxLQUFLO0FBRWxCMUIsbUJBQWE0RyxhQUFhO0FBQUEsSUFDNUIsU0FBU3BFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaEQ1RCxjQUFRNEQsTUFBTSwyQkFBMkI7QUFDekN4QyxtQkFBYSxFQUFFO0FBQUEsSUFDakIsVUFBQztBQUNDSSxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBS0EsUUFBTWlILHFCQUFxQkEsTUFBTTtBQUMvQixVQUFNQyxpQkFBZ0JuQixpQkFBaUI7QUFDdkMsUUFBSW1CLG1CQUFrQixHQUFHO0FBQ3ZCMUksY0FBUTJJLFFBQVEsOERBQThEO0FBQzlFO0FBQUEsSUFDRjtBQUNBM0cseUJBQXFCLElBQUk7QUFBQSxFQUMzQjtBQUdBLFFBQU00Ryx1QkFBdUIsWUFBWTtBQUN2QzlHLHlCQUFxQixJQUFJO0FBRXpCLFFBQUk7QUFDRixZQUFNK0csZ0JBQWdCL0UsbUJBQW1CNkM7QUFBQUEsUUFDdkMsQ0FBQ0MsU0FBU2pGLGFBQWFpRixLQUFLL0IsR0FBRyxNQUFNO0FBQUEsTUFDdkM7QUFFQSxZQUFNaUUsWUFBWSxDQUFDO0FBRW5CRCxvQkFBY3ZCLFFBQVEsQ0FBQ1YsTUFBTTNDLFVBQVU7QUFDckM2RSxrQkFBVSxZQUFZN0UsS0FBSyxFQUFFLElBQUk7QUFBQSxVQUMvQjhFLE1BQU07QUFBQSxZQUNKekcsUUFBUTtBQUFBLFlBQ1IwRyxVQUFVcEMsS0FBSzdCO0FBQUFBLFlBQ2ZrRSxXQUFXckMsS0FBSzFCO0FBQUFBLFlBQ2hCRSxXQUFXd0IsS0FBS3hCO0FBQUFBLFlBQ2hCOEQsZ0JBQWdCdEMsS0FBS3JCO0FBQUFBLFlBQ3JCQyxlQUFnQm9CLEtBQUtwQjtBQUFBQSxZQUNyQkMsZUFBZ0JtQixLQUFLbkI7QUFBQUEsWUFDckJDLGNBQWVrQixLQUFLbEI7QUFBQUEsWUFDcEJDLGdCQUFnQmpCO0FBQUFBLFlBQ2hCQyxrQkFBa0JELFVBQVVWLFVBQVVtRjtBQUFBQTtBQUFBQTtBQUFBQSxZQUd0Q0MsU0FBU3hJLE9BQU9nRyxLQUFLVixTQUFTLEVBQUVtRCxPQUFPLFlBQVk7QUFBQSxVQUNyRDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFHRCxZQUFNNUYsV0FBVyxNQUFNOUMsSUFBSTJJLEtBQUssMkJBQTJCUixTQUFTO0FBRXBFLFVBQUlyRixTQUFTRSxLQUFLNEYsWUFBWUMsUUFBVztBQUN2QyxjQUFNQyxlQUFlaEcsU0FBU0UsS0FBSzRGLFdBQVc5RixTQUFTRSxLQUFLOEYsZ0JBQWdCO0FBQzVFLGNBQU1DLGFBQWFqRyxTQUFTRSxLQUFLQyxTQUFTSCxTQUFTRSxLQUFLK0YsY0FBYztBQUV0RSxZQUFJRCxlQUFlLEdBQUc7QUFDcEJ6SixrQkFBUXVKLFFBQVEsb0JBQW9CRSxZQUFZLGdCQUFnQkMsVUFBVSxTQUFTO0FBRW5GOUgsMEJBQWdCLENBQUMsQ0FBQztBQUNsQmtCLHVCQUFhLEtBQUs7QUFBQSxRQUNwQixPQUFPO0FBQ0w5QyxrQkFBUTRELE1BQU0seUJBQXlCO0FBQUEsUUFDekM7QUFBQSxNQUNGLE9BQU87QUFDTDVELGdCQUFRdUosUUFBUTlGLFNBQVNFLEtBQUszRCxXQUFXLDRCQUE0QjtBQUNyRTRCLHdCQUFnQixDQUFDLENBQUM7QUFDbEJrQixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFFQWQsMkJBQXFCLEtBQUs7QUFBQSxJQUM1QixTQUFTNEIsT0FBTztBQUNkQyxjQUFRRCxNQUFNLG9DQUFvQ0EsS0FBSztBQUN2RDVELGNBQVE0RCxNQUFNQSxNQUFNSCxVQUFVRSxNQUFNM0QsV0FBVyxrQ0FBa0M7QUFBQSxJQUNuRixVQUFDO0FBQ0M4QiwyQkFBcUIsS0FBSztBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUVBLFFBQU02SCxxQkFBcUJBLE1BQU07QUFDL0J6SCxlQUFXO0FBQUEsTUFDVEMsU0FBUztBQUFBLE1BQ1RDLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLElBQ1YsQ0FBQztBQUNEVixvQkFBZ0IsQ0FBQyxDQUFDO0FBQ2xCa0IsaUJBQWEsS0FBSztBQUFBLEVBQ3BCO0FBRUF2RCxZQUFVLE1BQU07QUFDZGlFLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFFTGpFLFlBQVUsTUFBTTtBQUNkcUksbUJBQWU7QUFBQSxFQUNqQixHQUFHLENBQUMzRixPQUFPLENBQUM7QUFFWixRQUFNeUcsZ0JBQWdCbkIsaUJBQWlCO0FBR3ZDaEksWUFBVSxNQUFNO0FBQ2QsUUFBSW1ILGFBQWFpQixTQUFTLEdBQUc7QUFDM0IsWUFBTWlDLGNBQWNsRCxhQUFhbUQsTUFBTSxDQUFBakQsU0FBUWpGLGFBQWFpRixLQUFLL0IsR0FBRyxNQUFNLElBQUk7QUFDOUUvQixtQkFBYThHLFdBQVc7QUFBQSxJQUMxQixPQUFPO0FBQ0w5RyxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGLEdBQUcsQ0FBQ25CLGNBQWMrRSxZQUFZLENBQUM7QUFHL0IsUUFBTW9ELFVBQVU7QUFBQSxJQUNkLEVBQUVsRixLQUFLLE1BQU1tRixRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFbkYsS0FBSyxnQkFBZ0JtRixRQUFRLGdCQUFnQjtBQUFBLElBQy9DLEVBQUVuRixLQUFLLGVBQWVtRixRQUFRLGVBQWU7QUFBQSxJQUM3QyxFQUFFbkYsS0FBSyxhQUFhbUYsUUFBUSxRQUFRO0FBQUEsSUFDcEMsRUFBRW5GLEtBQUssVUFBVW1GLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVuRixLQUFLLGtCQUFrQm1GLFFBQVEsVUFBVTtBQUFBLElBQzNDLEVBQUVuRixLQUFLLGlCQUFpQm1GLFFBQVEsaUJBQWlCO0FBQUEsSUFDakQsRUFBRW5GLEtBQUssaUJBQWlCbUYsUUFBUSxXQUFXO0FBQUEsSUFDM0MsRUFBRW5GLEtBQUssZ0JBQWdCbUYsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFbkYsS0FBSyxvQkFBb0JtRixRQUFRLG9CQUFvQjtBQUFBLElBQ3ZELEVBQUVuRixLQUFLLFVBQVVtRixRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFbkYsS0FBSyxZQUFZbUYsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUd2QyxRQUFNQyxlQUFlO0FBQUEsSUFDbkIsRUFBRXBGLEtBQUssTUFBTW1GLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVuRixLQUFLLGdCQUFnQm1GLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRW5GLEtBQUssZUFBZW1GLFFBQVEsZUFBZTtBQUFBLElBQzdDLEVBQUVuRixLQUFLLGFBQWFtRixRQUFRLFFBQVE7QUFBQSxJQUNwQyxFQUFFbkYsS0FBSyxVQUFVbUYsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRW5GLEtBQUssY0FBY21GLFFBQVEsVUFBVTtBQUFBLElBQ3ZDLEVBQUVuRixLQUFLLG9CQUFvQm1GLFFBQVEsaUJBQWlCO0FBQUEsSUFDcEQsRUFBRW5GLEtBQUssb0JBQW9CbUYsUUFBUSxXQUFXO0FBQUEsSUFDOUMsRUFBRW5GLEtBQUssbUJBQW1CbUYsUUFBUSxnQkFBZ0I7QUFBQSxJQUNwRCxFQUFFbkYsS0FBSyx1QkFBdUJtRixRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUVuRixLQUFLLFVBQVVtRixRQUFRLFNBQVM7QUFBQSxFQUFDO0FBS3JDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLDZCQUE2QixDQUFDM0QsTUFBTTFFLGNBQWMwRSxFQUFFYyxPQUFPUSxLQUFLO0FBQUEsUUFDaEUsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGlFQUNaO0FBQUEscUNBQUMsY0FBVyxXQUFVLDZCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGNBQUc7QUFBQSxpQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLGlCQUFnQix3RkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU0sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZTtBQUFBLGNBQ3JCLFNBQVNFO0FBQUFBLGNBQ1QsU0FBU3JHO0FBQUFBLGNBQVU7QUFBQTtBQUFBLFlBSHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDZEQUNiLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsbUNBQWtDLCtCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzlELHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0NnQixnQkFBTUUsa0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsZUFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw0REFDYixpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyw2QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQ7QUFBQSxZQUM1RCx1QkFBQyxPQUFFLFdBQVUsbUNBQ1ZVLHlCQUFlWixNQUFNRyxrQkFBa0IsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwrREFDYixpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyw4QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxZQUM3RCx1QkFBQyxPQUFFLFdBQVUsc0NBQ1ZTLHlCQUFlWixNQUFNSSxrQkFBa0IsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwrREFDYixpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyxpQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxPQUFFLFdBQVUsc0NBQ1ZRLHlCQUFlWixNQUFNSyxjQUFjLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGlEQUNaO0FBQUEscUNBQUMsa0JBQWUsV0FBVSxtQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUM7QUFBQSxjQUFHO0FBQUEsaUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFVBQU8sU0FBUytHLG9CQUFvQiw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxlQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLE9BQU8xSCxRQUFRRSxXQUFXcUg7QUFBQUEsZ0JBQzFCLFVBQVUsQ0FBQzlCLFVBQ1R4RixXQUFXLENBQUNpRixVQUFVLEVBQUUsR0FBR0EsTUFBTWhGLFNBQVN1RixTQUFTLEdBQUcsRUFBRTtBQUFBLGdCQUd6RHJHLGlCQUFPMEM7QUFBQUEsa0JBQUksQ0FBQ2tHLFVBQ1gsdUJBQUMsVUFBdUIsT0FBT0EsTUFBTXBGLEtBQ2xDb0YsZ0JBQU0zRSxjQURJMkUsTUFBTXBGLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FaSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFhQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPNUMsUUFBUUs7QUFBQUEsZ0JBQ2YsVUFBVSxDQUFDb0YsVUFDVHhGLFdBQVcsQ0FBQ2lGLFVBQVUsRUFBRSxHQUFHQSxNQUFNN0UsUUFBUW9GLE1BQU0sRUFBRTtBQUFBLGdCQUduRDtBQUFBLHlDQUFDLFVBQU8sT0FBTSxPQUFNLDBCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4QjtBQUFBLGtCQUM5Qix1QkFBQyxVQUFPLE9BQU0sV0FBVSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQSxrQkFDL0IsdUJBQUMsVUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlCO0FBQUE7QUFBQTtBQUFBLGNBUjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FBT3pGLFFBQVFHO0FBQUFBLGdCQUNmLFVBQVUsQ0FBQ2dFLE1BQ1RsRSxXQUFXLENBQUNpRixVQUFVLEVBQUUsR0FBR0EsTUFBTS9FLFdBQVdnRSxFQUFFYyxPQUFPUSxNQUFNLEVBQUU7QUFBQTtBQUFBLGNBTGpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1HO0FBQUEsWUFFSDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FBT3pGLFFBQVFJO0FBQUFBLGdCQUNmLFVBQVUsQ0FBQytELE1BQ1RsRSxXQUFXLENBQUNpRixVQUFVLEVBQUUsR0FBR0EsTUFBTTlFLFNBQVMrRCxFQUFFYyxPQUFPUSxNQUFNLEVBQUU7QUFBQTtBQUFBLGNBTC9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1HO0FBQUEsZUF2Q0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5Q0E7QUFBQSxhQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0RBO0FBQUEsUUFHQ2dCLGdCQUFnQixLQUNmLHVCQUFDLFNBQUksV0FBVSwrSEFDYixpQ0FBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsK0dBQ1pBLDJCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSx1Q0FBc0Msb0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFNLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUEsY0FDdkIsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBU0Q7QUFBQUEsY0FBbUI7QUFBQTtBQUFBLGdCQUVaQztBQUFBQSxnQkFBYztBQUFBO0FBQUE7QUFBQSxZQVBoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBLEtBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxRQUlGLHVCQUFDLFNBQUksV0FBVSxnREFDWm5ILHNCQUNDLHVCQUFDLGtCQUFlLFdBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxJQUM5Qm1GLGFBQWFpQixXQUFXLElBQzFCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXO0FBQUEsWUFDWCxTQUFTO0FBQUEsWUFDVCxNQUFLO0FBQUE7QUFBQSxVQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUd3QixJQUd4QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTWpCO0FBQUFBLFlBQ047QUFBQSxZQUNBLFlBQVlzRDtBQUFBQSxZQUNaLGtCQUFrQixvQkFBb0JwSixPQUFPLEVBQUV5SSxPQUFPLFlBQVksQ0FBQztBQUFBLFlBQ25FLG1CQUFtQjtBQUFBLGNBQ2pCcEMsU0FBU3BFO0FBQUFBLGNBQ1RxSCxVQUFVOUM7QUFBQUEsWUFDWjtBQUFBO0FBQUEsVUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRSSxLQWxCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsV0E1SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZKQTtBQUFBLFNBL0pGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnS0E7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNckY7QUFBQUEsUUFDTixVQUFVLE1BQU1DLHFCQUFxQixLQUFLO0FBQUEsUUFDMUMsUUFBUTtBQUFBLFFBQ1I7QUFBQSxRQUNBLE9BQU87QUFBQSxRQUVQLGlDQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSw0QkFDYixpQ0FBQyxTQUFJLFdBQVUsK0JBQ2IsaUNBQUMsNkJBQTBCLFdBQVUsMkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRELEtBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUseUNBQXdDLDZCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCO0FBQUE7QUFBQSxZQUNXO0FBQUEsWUFDM0MsdUJBQUMsVUFBSyxXQUFVLDJCQUEyQjBHO0FBQUFBO0FBQUFBLGNBQWM7QUFBQSxpQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQSxZQUFPO0FBQUEsWUFDNUUsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFHO0FBQUEsWUFBRztBQUFBLGVBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNMUcscUJBQXFCLEtBQUs7QUFBQSxnQkFDekMsV0FBVTtBQUFBLGdCQUFNO0FBQUE7QUFBQSxjQUhsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLFNBQVNIO0FBQUFBLGdCQUNULFNBQVMrRztBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQXNDO0FBQUE7QUFBQSxjQUxsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsYUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlDQTtBQUFBO0FBQUEsTUF4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBeUNBO0FBQUEsT0FqTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtOQTtBQUVKO0FBQUMxSCxHQTVqQlFELDRCQUEwQjtBQUFBa0osS0FBMUJsSjtBQThqQlQsZUFBZUE7QUFBMkIsSUFBQWtKO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJCdXR0b24iLCJTZWxlY3QiLCJJbnB1dCIsIk1vZGFsIiwiQ2hlY2tib3giLCJBbGVydCIsIlRhZyIsIm1lc3NhZ2UiLCJTZWFyY2hPdXRsaW5lZCIsIlJlbG9hZE91dGxpbmVkIiwiQ2xvY2tDaXJjbGVPdXRsaW5lZCIsIkNoZWNrQ2lyY2xlT3V0bGluZWQiLCJFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIiwiV2hhdHNBcHBPdXRsaW5lZCIsIlNpZGViYXIiLCJOYXZiYXIiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsImFwaSIsIm1vbWVudCIsIkZhV2hhdHNhcHAiLCJQaG9uZSIsIlVzZXIiLCJPcHRpb24iLCJQZW5hbHR5V2hhdHNhcHBNZXNzYWdlTWVudSIsIl9zIiwidGFibGVEYXRhIiwic2V0VGFibGVEYXRhIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJzZWxlY3RlZFJvd3MiLCJzZXRTZWxlY3RlZFJvd3MiLCJpc1NlbmRpbmdXaGF0c2FwcCIsInNldElzU2VuZGluZ1doYXRzYXBwIiwiaXNWZXJpZnlNb2RhbE9wZW4iLCJzZXRJc1ZlcmlmeU1vZGFsT3BlbiIsImZpbHRlcnMiLCJzZXRGaWx0ZXJzIiwiZ3JvdXBJZCIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJzdGF0dXMiLCJzdGF0cyIsInNldFN0YXRzIiwidG90YWxDdXN0b21lcnMiLCJ0b3RhbFBlbmFsdHlBbW91bnQiLCJ0b3RhbExhdGVGZWVBbW91bnQiLCJ0b3RhbER1ZUFtb3VudCIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsImZvcm1hdE51bWJlciIsIm51bSIsInBhcnNlRmxvYXQiLCJ0b0ZpeGVkIiwiZm9ybWF0Q3VycmVuY3kiLCJhbW91bnQiLCJ0b0xvY2FsZVN0cmluZyIsIm1pbmltdW1GcmFjdGlvbkRpZ2l0cyIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsImZldGNoR3JvdXBzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZm9ybWF0dGVkVGFibGVEYXRhIiwibWFwIiwicGVuYWx0eSIsImluZGV4IiwicGVuYWx0eV9hbW91bnQiLCJsYXRlX2ZlZV9hbW91bnQiLCJ0b3RhbFBlbmFsdHlTdW0iLCJ0b3RhbF9wZW5hbHR5X3N1bSIsInRvdGFsTGF0ZUZlZVN1bSIsInRvdGFsX2xhdGVfZmVlX3N1bSIsInRvdGFsRHVlIiwiY3VycmVudF9iYWxhbmNlIiwiYmFsYW5jZSIsInRvdGFsT3V0c3RhbmRpbmciLCJrZXkiLCJfaWQiLCJpZCIsImN1c3RvbWVyTmFtZSIsInVzZXJfaWQiLCJmdWxsX25hbWUiLCJwaG9uZU51bWJlciIsInBob25lX251bWJlciIsImdyb3VwTmFtZSIsImdyb3VwX2lkIiwiZ3JvdXBfbmFtZSIsInRpY2tldCIsInBlbmFsdHlBbW91bnQiLCJsYXRlRmVlQW1vdW50IiwidG90YWxQZW5hbHR5IiwiY3VycmVudEJhbGFuY2UiLCJjdXJyZW50QmFsYW5jZVJhdyIsInBlbmFsdHlBbW91bnRSYXciLCJsYXRlRmVlQW1vdW50UmF3IiwidG90YWxQZW5hbHR5UmF3IiwiYmFsYW5jZVJhdyIsInRvdGFsT3V0c3RhbmRpbmdSYXciLCJjcmVhdGVkQXQiLCJjaGVja0JveCIsImUiLCJoYW5kbGVDaGVja2JveENoYW5nZSIsInN0b3BQcm9wYWdhdGlvbiIsImN1cnNvciIsIndpZHRoIiwiaGVpZ2h0IiwiZmlsdGVyZWREYXRhIiwiZmlsdGVyIiwiaXRlbSIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ0b1N0cmluZyIsInJlY29yZCIsImNoZWNrZWQiLCJ0YXJnZXQiLCJwcmV2IiwiaGFuZGxlU2VsZWN0QWxsIiwibmV3U2VsZWN0ZWRSb3dzIiwiZm9yRWFjaCIsImdldFNlbGVjdGVkQ291bnQiLCJPYmplY3QiLCJ2YWx1ZXMiLCJ2YWx1ZSIsImxlbmd0aCIsImZldGNoUGVuYWx0aWVzIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwiYXBwZW5kIiwicGVuYWx0aWVzRGF0YSIsInAiLCJ1bmlxdWVDdXN0b21lcnMiLCJNYXAiLCJ0b3RhbExhdGVGZWUiLCJjdXN0b21lcktleSIsImhhcyIsInNldCIsInNpemUiLCJoYW5kbGVTZW5kV2hhdHNBcHAiLCJzZWxlY3RlZENvdW50Iiwid2FybmluZyIsInNlbmRXaGF0c0FwcE1lc3NhZ2VzIiwic2VsZWN0ZWRJdGVtcyIsInJlY2VpdmVycyIsImluZm8iLCJ1c2VyTmFtZSIsInVzZXJQaG9uZSIsInBheW1lbnRzVGlja2V0IiwibGF0ZUZlZSIsImR1ZURhdGUiLCJmb3JtYXQiLCJwb3N0Iiwic3VjY2VzcyIsInVuZGVmaW5lZCIsInN1Y2Nlc3NDb3VudCIsImVycm9yQ291bnQiLCJoYW5kbGVDbGVhckZpbHRlcnMiLCJhbGxTZWxlY3RlZCIsImV2ZXJ5IiwiY29sdW1ucyIsImhlYWRlciIsImV4Y2VsQ29sdW1ucyIsImdyb3VwIiwib25DaGFuZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQZW5hbHR5V2hhdHNhcHBNZXNzYWdlTWVudS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBCdXR0b24sXHJcbiAgU2VsZWN0LFxyXG4gIElucHV0LFxyXG4gIE1vZGFsLFxyXG4gIENoZWNrYm94LFxyXG4gIEFsZXJ0LFxyXG4gIFRhZyxcclxuICBtZXNzYWdlLFxyXG59IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7XHJcbiAgU2VhcmNoT3V0bGluZWQsXHJcbiAgUmVsb2FkT3V0bGluZWQsXHJcbiAgQ2xvY2tDaXJjbGVPdXRsaW5lZCxcclxuICBDaGVja0NpcmNsZU91dGxpbmVkLFxyXG4gIEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQsXHJcbiAgV2hhdHNBcHBPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBtb21lbnQgZnJvbSBcIm1vbWVudFwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IFBob25lLCBVc2VyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5cclxuY29uc3QgeyBPcHRpb24gfSA9IFNlbGVjdDtcclxuXHJcbmZ1bmN0aW9uIFBlbmFsdHlXaGF0c2FwcE1lc3NhZ2VNZW51KCkge1xyXG4gIC8vIFN0YXRlIGRlY2xhcmF0aW9uc1xyXG4gIGNvbnN0IFt0YWJsZURhdGEsIHNldFRhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFJvd3MsIHNldFNlbGVjdGVkUm93c10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzU2VuZGluZ1doYXRzYXBwLCBzZXRJc1NlbmRpbmdXaGF0c2FwcF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzVmVyaWZ5TW9kYWxPcGVuLCBzZXRJc1ZlcmlmeU1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2ZpbHRlcnMsIHNldEZpbHRlcnNdID0gdXNlU3RhdGUoe1xyXG4gICAgZ3JvdXBJZDogXCJcIixcclxuICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuICAgIGVuZERhdGU6IFwiXCIsXHJcbiAgICBzdGF0dXM6IFwiYWxsXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3N0YXRzLCBzZXRTdGF0c10gPSB1c2VTdGF0ZSh7XHJcbiAgICB0b3RhbEN1c3RvbWVyczogMCxcclxuICAgIHRvdGFsUGVuYWx0eUFtb3VudDogMCxcclxuICAgIHRvdGFsTGF0ZUZlZUFtb3VudDogMCxcclxuICAgIHRvdGFsRHVlQW1vdW50OiAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIEZvcm1hdCBudW1iZXIgaGVscGVyIGZ1bmN0aW9uXHJcbiAgY29uc3QgZm9ybWF0TnVtYmVyID0gKG51bSkgPT4ge1xyXG4gICAgcmV0dXJuIHBhcnNlRmxvYXQobnVtIHx8IDApLnRvRml4ZWQoMik7XHJcbiAgfTtcclxuXHJcbiAgLy8gRm9ybWF0IGN1cnJlbmN5IGZvciBkaXNwbGF5XHJcbiAgY29uc3QgZm9ybWF0Q3VycmVuY3kgPSAoYW1vdW50KSA9PiB7XHJcbiAgICByZXR1cm4gYOKCuSR7cGFyc2VGbG9hdChhbW91bnQpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwgeyBcclxuICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLCBcclxuICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIFxyXG4gICAgfSl9YDtcclxuICB9O1xyXG5cclxuICAvLyBGZXRjaCBncm91cHNcclxuICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgIHNldEdyb3VwcyhyZXNwb25zZS5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cHM6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBncm91cHNcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcblxyXG4gIGNvbnN0IGZvcm1hdHRlZFRhYmxlRGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHRhYmxlRGF0YS5tYXAoKHBlbmFsdHksIGluZGV4KSA9PiB7XHJcblxyXG4gICAgICBjb25zdCB0b3RhbFBlbmFsdHlBbW91bnQgPSAocGVuYWx0eS5wZW5hbHR5X2Ftb3VudCB8fCAwKSArIChwZW5hbHR5LmxhdGVfZmVlX2Ftb3VudCB8fCAwKTtcclxuXHJcbiAgICAgICAgICBjb25zdCB0b3RhbFBlbmFsdHlTdW0gPSBwZW5hbHR5LnRvdGFsX3BlbmFsdHlfc3VtIHx8IDA7XHJcbiAgICAgICAgICBjb25zdCB0b3RhbExhdGVGZWVTdW0gPSBwZW5hbHR5LnRvdGFsX2xhdGVfZmVlX3N1bSB8fCAwO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHRvdGFsRHVlID0gcGVuYWx0eS5jdXJyZW50X2JhbGFuY2UgfHwgMDtcclxuXHJcbiAgICAgICAgICBjb25zdCBiYWxhbmNlID1cclxuICAgICAgICAgICAgdG90YWxEdWUgLVxyXG4gICAgICAgICAgICB0b3RhbFBlbmFsdHlTdW0gLVxyXG4gICAgICAgICAgICB0b3RhbExhdGVGZWVTdW07XHJcblxyXG4gICAgICAgICAgY29uc3QgdG90YWxPdXRzdGFuZGluZyA9XHJcbiAgICAgICAgICAgIGJhbGFuY2UgK1xyXG4gICAgICAgICAgICB0b3RhbFBlbmFsdHlTdW0gK1xyXG4gICAgICAgICAgICB0b3RhbExhdGVGZWVTdW07XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAga2V5OiBwZW5hbHR5Ll9pZCxcclxuICAgICAgICBfaWQ6IHBlbmFsdHkuX2lkLFxyXG4gICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgY3VzdG9tZXJOYW1lOiBwZW5hbHR5LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIHBob25lTnVtYmVyOiBwZW5hbHR5LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgIGdyb3VwTmFtZTogcGVuYWx0eS5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIHRpY2tldDogcGVuYWx0eS50aWNrZXQsXHJcbiAgICAgICAgcGVuYWx0eUFtb3VudDogKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmx1ZS01MDBcIj5cclxuICAgICAgICAgICAg4oK5e2Zvcm1hdE51bWJlcihwZW5hbHR5LnBlbmFsdHlfYW1vdW50KX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICBcclxuICAgICAgICBsYXRlRmVlQW1vdW50OiBmb3JtYXROdW1iZXIocGVuYWx0eS5sYXRlX2ZlZV9hbW91bnQpLFxyXG4gICAgICAgIHRvdGFsUGVuYWx0eTogZm9ybWF0TnVtYmVyKHRvdGFsUGVuYWx0eUFtb3VudCksXHJcbiAgICAgICAgLy8gY3VycmVudEJhbGFuY2U6IGZvcm1hdE51bWJlcihwZW5hbHR5LmN1cnJlbnRfYmFsYW5jZSksXHJcbiAgICAgICAgLy8gdG90YWxPdXRzdGFuZGluZzogZm9ybWF0TnVtYmVyKHRvdGFsT3V0c3RhbmRpbmcpLFxyXG4gICAgICAgIGJhbGFuY2U6ICBmb3JtYXROdW1iZXIoYmFsYW5jZSksXHJcblxyXG4gICAgICAvLyBjdXJyZW50QmFsYW5jZTogZm9ybWF0TnVtYmVyKGJhbGFuY2UpLFxyXG5cclxuICAgICAgICAgICAgY3VycmVudEJhbGFuY2U6IChcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1vcmFuZ2UtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICDigrl7Zm9ybWF0TnVtYmVyKGJhbGFuY2UpfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgY3VycmVudEJhbGFuY2VSYXc6IGJhbGFuY2UsXHJcblxyXG4gICAgICAgICAgdG90YWxPdXRzdGFuZGluZzogKFxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAg4oK5e2Zvcm1hdE51bWJlcih0b3RhbE91dHN0YW5kaW5nKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICBwZW5hbHR5QW1vdW50UmF3OiBwZW5hbHR5LnBlbmFsdHlfYW1vdW50IHx8IDAsXHJcbiAgICAgICAgbGF0ZUZlZUFtb3VudFJhdzogcGVuYWx0eS5sYXRlX2ZlZV9hbW91bnQgfHwgMCxcclxuICAgICAgICB0b3RhbFBlbmFsdHlSYXc6IHRvdGFsUGVuYWx0eUFtb3VudCxcclxuICAgICAgICAvLyB0b3RhbE91dHN0YW5kaW5nUmF3OiB0b3RhbE91dHN0YW5kaW5nLFxyXG4gICAgICAgIGJhbGFuY2VSYXc6IGJhbGFuY2UsXHJcbiAgICAgICAgdG90YWxPdXRzdGFuZGluZ1JhdzogdG90YWxPdXRzdGFuZGluZyxcclxuICAgICAgICBzdGF0dXM6IChwZW5hbHR5LnBlbmFsdHlfYW1vdW50ID4gMCB8fCBwZW5hbHR5LmxhdGVfZmVlX2Ftb3VudCA+IDApID8gXCJQZW5kaW5nXCIgOiBcIlBhaWRcIixcclxuICAgICAgICBjcmVhdGVkQXQ6IHBlbmFsdHkuY3JlYXRlZEF0LFxyXG4gICAgICAgIGNoZWNrQm94OiAoXHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRSb3dzW3BlbmFsdHkuX2lkXSB8fCBmYWxzZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGVja2JveENoYW5nZShwZW5hbHR5LCBlKX1cclxuICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgICAgIHN0eWxlPXt7IGN1cnNvcjogJ3BvaW50ZXInLCB3aWR0aDogJzE2cHgnLCBoZWlnaHQ6ICcxNnB4JyB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApLFxyXG4gICAgICB9O1xyXG4gICAgfSk7XHJcbiAgfSwgW3RhYmxlRGF0YSwgc2VsZWN0ZWRSb3dzXSk7XHJcbiAgICAvLyBGaWx0ZXIgZGF0YSBiYXNlZCBvbiBzZWFyY2hcclxuICBjb25zdCBmaWx0ZXJlZERhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGlmICghc2VhcmNoVGV4dCkgcmV0dXJuIGZvcm1hdHRlZFRhYmxlRGF0YTtcclxuICAgIHJldHVybiBmb3JtYXR0ZWRUYWJsZURhdGEuZmlsdGVyKFxyXG4gICAgICAoaXRlbSkgPT5cclxuICAgICAgICBpdGVtLmN1c3RvbWVyTmFtZT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXh0LnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgICAgaXRlbS5waG9uZU51bWJlcj8uaW5jbHVkZXMoc2VhcmNoVGV4dCkgfHxcclxuICAgICAgICBpdGVtLmdyb3VwTmFtZT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXh0LnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgICAgaXRlbS50aWNrZXQ/LnRvU3RyaW5nKCkuaW5jbHVkZXMoc2VhcmNoVGV4dClcclxuICAgICk7XHJcbiAgfSwgW2Zvcm1hdHRlZFRhYmxlRGF0YSwgc2VhcmNoVGV4dF0pO1xyXG5cclxuICAvLyBIYW5kbGUgY2hlY2tib3ggY2hhbmdlIC0gc2luZ2xlIHNlbGVjdFxyXG4gIGNvbnN0IGhhbmRsZUNoZWNrYm94Q2hhbmdlID0gKHJlY29yZCwgZSkgPT4ge1xyXG4gICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICBzZXRTZWxlY3RlZFJvd3MocHJldiA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbcmVjb3JkLl9pZF06IGNoZWNrZWRcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgc2VsZWN0IGFsbFxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEFsbCA9IChjaGVja2VkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RBbGwoY2hlY2tlZCk7XHJcbiAgICBjb25zdCBuZXdTZWxlY3RlZFJvd3MgPSB7fTtcclxuICAgIGlmIChjaGVja2VkKSB7XHJcbiAgICAgIGZpbHRlcmVkRGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAgIG5ld1NlbGVjdGVkUm93c1tpdGVtLl9pZF0gPSB0cnVlO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuICAgIHNldFNlbGVjdGVkUm93cyhuZXdTZWxlY3RlZFJvd3MpO1xyXG4gIH07XHJcblxyXG4gIC8vIEdldCBzZWxlY3RlZCBjb3VudFxyXG4gIGNvbnN0IGdldFNlbGVjdGVkQ291bnQgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gT2JqZWN0LnZhbHVlcyhzZWxlY3RlZFJvd3MpLmZpbHRlcih2YWx1ZSA9PiB2YWx1ZSA9PT0gdHJ1ZSkubGVuZ3RoO1xyXG4gIH07XHJcblxyXG4gIC8vIEZldGNoIHBlbmFsdGllc1xyXG4gIGNvbnN0IGZldGNoUGVuYWx0aWVzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xyXG4gICAgICBpZiAoZmlsdGVycy5ncm91cElkKSBwYXJhbXMuYXBwZW5kKFwiZ3JvdXBJZFwiLCBmaWx0ZXJzLmdyb3VwSWQpO1xyXG4gICAgICBpZiAoZmlsdGVycy5zdGFydERhdGUpIHBhcmFtcy5hcHBlbmQoXCJzdGFydERhdGVcIiwgZmlsdGVycy5zdGFydERhdGUpO1xyXG4gICAgICBpZiAoZmlsdGVycy5lbmREYXRlKSBwYXJhbXMuYXBwZW5kKFwiZW5kRGF0ZVwiLCBmaWx0ZXJzLmVuZERhdGUpO1xyXG4gICAgICBwYXJhbXMuYXBwZW5kKFwibGltaXRcIiwgXCIxMDAwXCIpO1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvcGVuYWx0eS1tYW5hZ2VtZW50L2dldC1wZW5hbHRpZXMtd2l0aC10b3RhbHM/JHtwYXJhbXMudG9TdHJpbmcoKX1gXHJcbiAgICAgICk7XHJcbiAgICAgIGxldCBwZW5hbHRpZXNEYXRhID0gcmVzcG9uc2UuZGF0YS5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgaWYgKGZpbHRlcnMuc3RhdHVzICE9PSBcImFsbFwiKSB7XHJcbiAgICAgICAgaWYgKGZpbHRlcnMuc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xyXG4gICAgICAgICAgcGVuYWx0aWVzRGF0YSA9IHBlbmFsdGllc0RhdGEuZmlsdGVyKFxyXG4gICAgICAgICAgICAocCkgPT4gcC5wZW5hbHR5X2Ftb3VudCA+IDAgfHwgcC5sYXRlX2ZlZV9hbW91bnQgPiAwXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoZmlsdGVycy5zdGF0dXMgPT09IFwicGFpZFwiKSB7XHJcbiAgICAgICAgICBwZW5hbHRpZXNEYXRhID0gcGVuYWx0aWVzRGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgIChwKSA9PiBwLnBlbmFsdHlfYW1vdW50ID09PSAwICYmIHAubGF0ZV9mZWVfYW1vdW50ID09PSAwXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gQ2FsY3VsYXRlIHN0YXRpc3RpY3Mgd2l0aCAyIGRlY2ltYWwgcGxhY2VzXHJcbiAgICAgIGNvbnN0IHVuaXF1ZUN1c3RvbWVycyA9IG5ldyBNYXAoKTtcclxuICAgICAgbGV0IHRvdGFsUGVuYWx0eSA9IDA7XHJcbiAgICAgIGxldCB0b3RhbExhdGVGZWUgPSAwO1xyXG4gICAgICBsZXQgdG90YWxEdWUgPSAwO1xyXG5cclxuICAgICAgcGVuYWx0aWVzRGF0YS5mb3JFYWNoKChwZW5hbHR5KSA9PiB7XHJcbiAgICAgICAgY29uc3QgY3VzdG9tZXJLZXkgPSBgJHtwZW5hbHR5LnVzZXJfaWQ/Ll9pZH1fJHtwZW5hbHR5Lmdyb3VwX2lkPy5faWR9XyR7cGVuYWx0eS50aWNrZXR9YDtcclxuICAgICAgICBpZiAoIXVuaXF1ZUN1c3RvbWVycy5oYXMoY3VzdG9tZXJLZXkpKSB7XHJcbiAgICAgICAgICB1bmlxdWVDdXN0b21lcnMuc2V0KGN1c3RvbWVyS2V5LCB0cnVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdG90YWxQZW5hbHR5ICs9IHBlbmFsdHkucGVuYWx0eV9hbW91bnQgfHwgMDtcclxuICAgICAgICB0b3RhbExhdGVGZWUgKz0gcGVuYWx0eS5sYXRlX2ZlZV9hbW91bnQgfHwgMDtcclxuICAgICAgICB0b3RhbER1ZSArPSBwZW5hbHR5LmN1cnJlbnRfYmFsYW5jZSB8fCAwO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFN0YXRzKHtcclxuICAgICAgICB0b3RhbEN1c3RvbWVyczogdW5pcXVlQ3VzdG9tZXJzLnNpemUsXHJcbiAgICAgICAgdG90YWxQZW5hbHR5QW1vdW50OiBmb3JtYXROdW1iZXIodG90YWxQZW5hbHR5KSxcclxuICAgICAgICB0b3RhbExhdGVGZWVBbW91bnQ6IGZvcm1hdE51bWJlcih0b3RhbExhdGVGZWUpLFxyXG4gICAgICAgIHRvdGFsRHVlQW1vdW50OiBmb3JtYXROdW1iZXIodG90YWxEdWUpLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIFJlc2V0IHNlbGVjdGlvbnMgd2hlbiBkYXRhIGNoYW5nZXNcclxuICAgICAgc2V0U2VsZWN0ZWRSb3dzKHt9KTtcclxuICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuXHJcbiAgICAgIHNldFRhYmxlRGF0YShwZW5hbHRpZXNEYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwZW5hbHRpZXM6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBwZW5hbHRpZXNcIik7XHJcbiAgICAgIHNldFRhYmxlRGF0YShbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG5cclxuXHJcbiAgLy8gSGFuZGxlIHNlbmQgV2hhdHNBcHAgLSBTaG93IGNvbmZpcm1hdGlvbiBtb2RhbFxyXG4gIGNvbnN0IGhhbmRsZVNlbmRXaGF0c0FwcCA9ICgpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkQ291bnQgPSBnZXRTZWxlY3RlZENvdW50KCk7XHJcbiAgICBpZiAoc2VsZWN0ZWRDb3VudCA9PT0gMCkge1xyXG4gICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2Ugc2VsZWN0IGF0IGxlYXN0IG9uZSBjdXN0b21lciB0byBzZW5kIFdoYXRzQXBwIG1lc3NhZ2VcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldElzVmVyaWZ5TW9kYWxPcGVuKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIC8vIFNlbmQgV2hhdHNBcHAgdG8gYmFja2VuZFxyXG4gIGNvbnN0IHNlbmRXaGF0c0FwcE1lc3NhZ2VzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0SXNTZW5kaW5nV2hhdHNhcHAodHJ1ZSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc2VsZWN0ZWRJdGVtcyA9IGZvcm1hdHRlZFRhYmxlRGF0YS5maWx0ZXIoXHJcbiAgICAgICAgKGl0ZW0pID0+IHNlbGVjdGVkUm93c1tpdGVtLl9pZF0gPT09IHRydWVcclxuICAgICAgKTtcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IHJlY2VpdmVycyA9IHt9O1xyXG5cclxuICAgICAgc2VsZWN0ZWRJdGVtcy5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIHJlY2VpdmVyc1tgcmVjZWl2ZXJfJHtpbmRleH1gXSA9IHtcclxuICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgc3RhdHVzOiB0cnVlLFxyXG4gICAgICAgICAgICB1c2VyTmFtZTogaXRlbS5jdXN0b21lck5hbWUsXHJcbiAgICAgICAgICAgIHVzZXJQaG9uZTogaXRlbS5waG9uZU51bWJlcixcclxuICAgICAgICAgICAgZ3JvdXBOYW1lOiBpdGVtLmdyb3VwTmFtZSxcclxuICAgICAgICAgICAgcGF5bWVudHNUaWNrZXQ6IGl0ZW0udGlja2V0LFxyXG4gICAgICAgICAgICBwZW5hbHR5QW1vdW50OiAoaXRlbS5wZW5hbHR5QW1vdW50KSxcclxuICAgICAgICAgICAgbGF0ZUZlZUFtb3VudDogKGl0ZW0ubGF0ZUZlZUFtb3VudCksXHJcbiAgICAgICAgICAgIHRvdGFsUGVuYWx0eTogKGl0ZW0udG90YWxQZW5hbHR5KSxcclxuICAgICAgICAgICAgY3VycmVudEJhbGFuY2U6IGJhbGFuY2UsXHJcbiAgICAgICAgICAgIHRvdGFsT3V0c3RhbmRpbmc6IGJhbGFuY2UgKyBwZW5hbHR5ICsgbGF0ZUZlZSxcclxuICAgICAgICAgICAgLy8gY3VycmVudEJhbGFuY2U6IChpdGVtLmN1cnJlbnRCYWxhbmNlKSxcclxuICAgICAgICAgICAgLy8gdG90YWxPdXRzdGFuZGluZzogKGl0ZW0udG90YWxPdXRzdGFuZGluZyksXHJcbiAgICAgICAgICAgIGR1ZURhdGU6IG1vbWVudChpdGVtLmNyZWF0ZWRBdCkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcblxyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi93aGF0c2FwcC9wZW5hbHR5LWFkZGVkXCIsIHJlY2VpdmVycyk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YS5zdWNjZXNzICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICBjb25zdCBzdWNjZXNzQ291bnQgPSByZXNwb25zZS5kYXRhLnN1Y2Nlc3MgfHwgcmVzcG9uc2UuZGF0YS5zdWNjZXNzQ291bnQgfHwgMDtcclxuICAgICAgICBjb25zdCBlcnJvckNvdW50ID0gcmVzcG9uc2UuZGF0YS5lcnJvciB8fCByZXNwb25zZS5kYXRhLmVycm9yQ291bnQgfHwgMDtcclxuXHJcbiAgICAgICAgaWYgKHN1Y2Nlc3NDb3VudCA+IDApIHtcclxuICAgICAgICAgIG1lc3NhZ2Uuc3VjY2Vzcyhg4pyFIE1lc3NhZ2VzIHNlbnQ6ICR7c3VjY2Vzc0NvdW50fSBzdWNjZXNzZnVsLCAke2Vycm9yQ291bnR9IGZhaWxlZGApO1xyXG4gICAgICAgICAgLy8gUmVzZXQgc2VsZWN0aW9uc1xyXG4gICAgICAgICAgc2V0U2VsZWN0ZWRSb3dzKHt9KTtcclxuICAgICAgICAgIHNldFNlbGVjdEFsbChmYWxzZSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gc2VuZCBtZXNzYWdlc1wiKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbWVzc2FnZS5zdWNjZXNzKHJlc3BvbnNlLmRhdGEubWVzc2FnZSB8fCBcIk1lc3NhZ2VzIHNlbnQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkUm93cyh7fSk7XHJcbiAgICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0SXNWZXJpZnlNb2RhbE9wZW4oZmFsc2UpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHNlbmRpbmcgV2hhdHNBcHAgbWVzc2FnZXM6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBzZW5kIFdoYXRzQXBwIG1lc3NhZ2VzXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNTZW5kaW5nV2hhdHNhcHAoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsZWFyRmlsdGVycyA9ICgpID0+IHtcclxuICAgIHNldEZpbHRlcnMoe1xyXG4gICAgICBncm91cElkOiBcIlwiLFxyXG4gICAgICBzdGFydERhdGU6IFwiXCIsXHJcbiAgICAgIGVuZERhdGU6IFwiXCIsXHJcbiAgICAgIHN0YXR1czogXCJhbGxcIixcclxuICAgIH0pO1xyXG4gICAgc2V0U2VsZWN0ZWRSb3dzKHt9KTtcclxuICAgIHNldFNlbGVjdEFsbChmYWxzZSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hQZW5hbHRpZXMoKTtcclxuICB9LCBbZmlsdGVyc10pO1xyXG5cclxuICBjb25zdCBzZWxlY3RlZENvdW50ID0gZ2V0U2VsZWN0ZWRDb3VudCgpO1xyXG5cclxuICAvLyBVcGRhdGUgc2VsZWN0QWxsIHdoZW4gc2VsZWN0aW9ucyBjaGFuZ2VcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGZpbHRlcmVkRGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGNvbnN0IGFsbFNlbGVjdGVkID0gZmlsdGVyZWREYXRhLmV2ZXJ5KGl0ZW0gPT4gc2VsZWN0ZWRSb3dzW2l0ZW0uX2lkXSA9PT0gdHJ1ZSk7XHJcbiAgICAgIHNldFNlbGVjdEFsbChhbGxTZWxlY3RlZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3RlZFJvd3MsIGZpbHRlcmVkRGF0YV0pO1xyXG5cclxuICAvLyBUYWJsZSBjb2x1bW5zIGNvbmZpZ3VyYXRpb25cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVOdW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcImN1cnJlbnRCYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcInBlbmFsdHlBbW91bnRcIiwgaGVhZGVyOiBcIlBlbmFsdHkgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImxhdGVGZWVBbW91bnRcIiwgaGVhZGVyOiBcIkxhdGUgRmVlXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsUGVuYWx0eVwiLCBoZWFkZXI6IFwiVG90YWwgUGVuYWx0eVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbE91dHN0YW5kaW5nXCIsIGhlYWRlcjogXCJCYWxhbmNlICsgUGVuYWx0eVwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJjaGVja0JveFwiLCBoZWFkZXI6IFwiU2VsZWN0XCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBleGNlbENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZU51bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXBcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVJhd1wiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgICB7IGtleTogXCJwZW5hbHR5QW1vdW50UmF3XCIsIGhlYWRlcjogXCJQZW5hbHR5IEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJsYXRlRmVlQW1vdW50UmF3XCIsIGhlYWRlcjogXCJMYXRlIEZlZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbFBlbmFsdHlSYXdcIiwgaGVhZGVyOiBcIlRvdGFsIFBlbmFsdHlcIiB9LFxyXG4gIHsga2V5OiBcInRvdGFsT3V0c3RhbmRpbmdSYXdcIiwgaGVhZGVyOiBcIkJhbGFuY2UgKyBQZW5hbHR5XCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICBdO1xyXG5cclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBtdC0yMCBiZy1ncmFkaWVudC10by1iciBmcm9tLWdyYXktNTAgdG8tZ3JheS0xMDBcIj5cclxuICAgICAgPE5hdmJhclxyXG4gICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleFwiPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC02XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTggZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIG1iLTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtM3hsXCIgLz5cclxuICAgICAgICAgICAgICAgIFBlbmFsdHkgV2hhdHNBcHAgTWFuYWdlbWVudFxyXG4gICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgU2VuZCBXaGF0c0FwcCBtZXNzYWdlcyB0byBjdXN0b21lcnMgd2l0aCBwZW5kaW5nIHBlbmFsdGllcyBhbmQgbGF0ZSBmZWVzXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIGljb249ezxSZWxvYWRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtmZXRjaFBlbmFsdGllc31cclxuICAgICAgICAgICAgICBsb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBSZWZyZXNoXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFN0YXRpc3RpY3MgQ2FyZHMgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBib3JkZXItbC00IGJvcmRlci1ibHVlLTUwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHMgdXBwZXJjYXNlXCI+VG90YWwgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57c3RhdHMudG90YWxDdXN0b21lcnN9PC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBwLTQgYm9yZGVyLWwtNCBib3JkZXItcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHMgdXBwZXJjYXNlXCI+VG90YWwgUGVuYWx0eTwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KHN0YXRzLnRvdGFsUGVuYWx0eUFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBib3JkZXItbC00IGJvcmRlci1vcmFuZ2UtNTAwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC14cyB1cHBlcmNhc2VcIj5Ub3RhbCBMYXRlIEZlZTwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KHN0YXRzLnRvdGFsTGF0ZUZlZUFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBib3JkZXItbC00IGJvcmRlci1wdXJwbGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC14cyB1cHBlcmNhc2VcIj5Ub3RhbCBPdXRzdGFuZGluZzwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KHN0YXRzLnRvdGFsRHVlQW1vdW50KX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRmlsdGVyIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8U2VhcmNoT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBGaWx0ZXIgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUNsZWFyRmlsdGVyc30+Q2xlYXIgRmlsdGVyczwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJGaWx0ZXIgYnkgR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMuZ3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBncm91cElkOiB2YWx1ZSB8fCBcIlwiIH0pKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8T3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5zdGF0dXN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBzdGF0dXM6IHZhbHVlIH0pKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJhbGxcIj5BbGwgU3RhdHVzPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwicGVuZGluZ1wiPlBlbmRpbmc8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJwYWlkXCI+UGFpZDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTdGFydCBEYXRlXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLnN0YXJ0RGF0ZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0RmlsdGVycygocHJldikgPT4gKHsgLi4ucHJldiwgc3RhcnREYXRlOiBlLnRhcmdldC52YWx1ZSB9KSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbmQgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5lbmREYXRlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBlbmREYXRlOiBlLnRhcmdldC52YWx1ZSB9KSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBTZWxlY3RlZCBBY3Rpb25zIEJhciAqL31cclxuICAgICAgICAgIHtzZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTUwIHRvLWVtZXJhbGQtNTAgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDAgcm91bmRlZC1sZyBzaGFkb3cgcC00IG1iLTYgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWZ1bGwgaC0xMCB3LTEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LWxnIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZENvdW50fVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICBDdXN0b21lcihzKSBTZWxlY3RlZFxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIGljb249ezxXaGF0c0FwcE91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNjAwIGhvdmVyOmJnLWdyZWVuLTcwMCBib3JkZXItZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTZW5kV2hhdHNBcHB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBTZW5kIFdoYXRzQXBwICh7c2VsZWN0ZWRDb3VudH0pXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogRGF0YSBUYWJsZSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC00IG1pbi1oLVs0MDBweF1cIj5cclxuICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICApIDogZmlsdGVyZWREYXRhLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgIGlzTG9hZGluZz17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgZGF0YT1cIlBlbmFsdHkgUmVjb3Jkc1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZERhdGF9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0Q29scz17ZXhjZWxDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YFBlbmFsdHlfV2hhdHNBcHBfJHttb21lbnQoKS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpfWB9XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RBbGxDaGVja2JveD17e1xyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkOiBzZWxlY3RBbGwsXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlOiBoYW5kbGVTZWxlY3RBbGwsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogV2hhdHNBcHAgQ29uZmlybWF0aW9uIE1vZGFsICovfVxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICBvcGVuPXtpc1ZlcmlmeU1vZGFsT3Blbn1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0SXNWZXJpZnlNb2RhbE9wZW4oZmFsc2UpfVxyXG4gICAgICAgIGZvb3Rlcj17bnVsbH1cclxuICAgICAgICBjZW50ZXJlZFxyXG4gICAgICAgIHdpZHRoPXs1MDB9XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IGZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtMTAwIHJvdW5kZWQtZnVsbCBwLTRcIj5cclxuICAgICAgICAgICAgICA8RXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCB0ZXh0LXJlZC01MDBcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIG1iLTJcIj5cclxuICAgICAgICAgICAgQXJlIFlvdSBTdXJlP1xyXG4gICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgbWItNlwiPlxyXG4gICAgICAgICAgICBZb3UgYXJlIGFib3V0IHRvIHNlbmQgV2hhdHNBcHAgbWVzc2FnZXMgdG97XCIgXCJ9XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwXCI+e3NlbGVjdGVkQ291bnR9IGN1c3RvbWVyKHMpPC9zcGFuPi5cclxuICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgIFRoaXMgYWN0aW9uIGNhbm5vdCBiZSB1bmRvbmUgb25jZSBpbml0aWF0ZWQuXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNWZXJpZnlNb2RhbE9wZW4oZmFsc2UpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMzJcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgbG9hZGluZz17aXNTZW5kaW5nV2hhdHNhcHB9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17c2VuZFdoYXRzQXBwTWVzc2FnZXN9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zMiBiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFllcywgU2VuZFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L01vZGFsPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGVuYWx0eVdoYXRzYXBwTWVzc2FnZU1lbnU7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1BlbmFsdHlXaGF0c2FwcE1lc3NhZ2VNZW51LmpzeCJ9