import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DueLoanReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Search, FileText, Users, Calendar, IndianRupee, TrendingUp } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { DatePicker } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import __vite__cjsImport6_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport6_dayjs.__esModule ? __vite__cjsImport6_dayjs.default : __vite__cjsImport6_dayjs;
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Collapse } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FileTextOutlined, DollarOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaMoneyBill } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const { RangePicker } = DatePicker;
const DueLoanReport = () => {
  _s();
  const [loanReportTable, setLoanReportTable] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedLoanId, setSelectedLoanId] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [selectedReferredBy, setSelectedReferredBy] = useState("");
  const [dateRange, setDateRange] = useState(null);
  useEffect(() => {
    const fetchLoanReport = async () => {
      try {
        const response = await api.get(`/payment/customers/due-loan-report`);
        console.info(response.data);
        const formattedData = response.data.loanReports.filter((loan) => (loan?.balance ?? 0) > 0).map((loan, index) => ({
          id: loan?._id,
          slNo: index + 1,
          loanIds: loan?.loan_id || "N/A",
          loanAmountValue: loan?.loan_amount || 0,
          customerId: loan?.borrower?.customer_id || "N/A",
          customerName: loan?.borrower?.full_name || "N/A",
          customerPhone: loan?.borrower?.phone_number || "N/A",
          daily_payment_amount: loan?.daily_payment_amount || "N/A",
          loanStartDate: loan?.start_date ? new Date(loan.start_date).toLocaleDateString("en-GB") : "N/A",
          // Store the original date for filtering
          loanStartDateObj: loan?.start_date ? new Date(loan.start_date) : null,
          // loanStartDateObj: loan?.start_date ? new Date(loan.start_date) : null,
          loanEndDate: loan?.end_date ? `${loan?.end_date}`.split("T")[0] : "N/A",
          loanSanctionDate: loan?.loan_sanction_date ? `${loan?.loan_sanction_date}`.split("T")[0] : "N/A",
          last_payment_date: loan?.last_payment_date ? `${loan?.last_payment_date}`.split("T")[0] : "N/A",
          last_payment_amount: loan?.last_payment_amount ?? 0,
          second_last_payment_date: loan?.second_last_payment_date ? `${loan?.second_last_payment_date}`.split("T")[0] : "N/A",
          second_last_payment_amount: loan?.second_last_payment_amount ?? 0,
          third_last_payment_date: loan?.third_last_payment_date ? `${loan?.third_last_payment_date}`.split("T")[0] : "N/A",
          third_last_payment_amount: loan?.third_last_payment_amount ?? 0,
          loanDocumentCharges: loan?.document_charges ?? 0,
          payableLoanDays: loan?.daysCount,
          duedaysCount: loan?.duedaysCount,
          loanServiceCharges: loan?.service_charges ?? 0,
          loanAmount: loan?.double_loan_amount ?? 0,
          payableAmount: loan?.amount_payable ?? 0,
          totalLoanAmount: loan?.total_paid_amount ?? 0,
          late_fee: loan?.total_extra_charges ?? 0,
          loanBalance: loan?.outstanding ?? 0,
          remainingBalance: loan?.balance ?? 0,
          status: loan?.status || "-",
          referredBy: loan?.referredBy || "N/A"
        }));
        setLoanReportTable(formattedData);
      } catch (error) {
        console.error("Error fetching loan report:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchLoanReport();
  }, []);
  const uniqueLoanCombos = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    loanReportTable.forEach((loan) => {
      const key = loan.loanIds;
      if (!map.has(key)) {
        map.set(key, { id: key, label: `${key} | ₹${loan.loanAmountValue}` });
      }
    });
    return Array.from(map.values());
  }, [loanReportTable]);
  const uniqueCustomers = useMemo(
    () => loanReportTable.map((loan) => ({
      id: loan.id,
      name: loan.customerName,
      phone: loan.customerPhone,
      custid: loan.customerId
    })),
    [loanReportTable]
  );
  const uniqueReferredBy = useMemo(() => {
    const set = /* @__PURE__ */ new Set();
    loanReportTable.forEach((loan) => {
      if (loan.referredBy && loan.referredBy !== "N/A") {
        set.add(loan.referredBy);
      }
    });
    return Array.from(set);
  }, [loanReportTable]);
  const filteredLoanReport = useMemo(() => {
    return loanReportTable.filter((loan) => {
      const matchLoanId = selectedLoanId ? loan.loanIds === selectedLoanId : true;
      const matchCustomer = selectedCustomer ? loan.id === selectedCustomer : true;
      const matchReferredBy = selectedReferredBy ? loan.referredBy === selectedReferredBy : true;
      let matchDateRange = true;
      if (dateRange && dateRange.length === 2 && loan.loanStartDateObj) {
        const startDate = dayjs(dateRange[0]).startOf("day");
        const endDate = dayjs(dateRange[1]).endOf("day");
        const loanDate = dayjs(loan.loanStartDateObj);
        matchDateRange = loanDate.isAfter(startDate) && loanDate.isBefore(endDate);
      }
      return matchLoanId && matchCustomer && matchReferredBy && matchDateRange;
    });
  }, [loanReportTable, selectedLoanId, selectedCustomer, selectedReferredBy, dateRange]);
  const summaryStats = useMemo(() => {
    const filtered = filteredLoanReport;
    return {
      totalLoans: filtered.length,
      totalAmount: filtered.reduce((sum, loan) => sum + loan.loanAmount, 0),
      totalPayable: filtered.reduce((sum, loan) => sum + loan.payableAmount, 0),
      totalPaid: filtered.reduce((sum, loan) => sum + loan.totalLoanAmount, 0),
      totalBalance: filtered.reduce((sum, loan) => sum + loan.loanBalance, 0)
    };
  }, [filteredLoanReport]);
  const loanReportColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "loanIds", header: "Loan ID" },
    { key: "customerName", header: "Customer Name" },
    { key: "customerPhone", header: "Phone Number" },
    { key: "referredBy", header: "Referred By" },
    { key: "loanSanctionDate", header: "Sanction Date" },
    { key: "loanStartDate", header: "Loan Start Date" },
    { key: "loanEndDate", header: "Loan End Date" },
    { key: "loanServiceCharges", header: "Service Charges" },
    { key: "loanDocumentCharges", header: "Documentation Charges" },
    { key: "daily_payment_amount", header: "Daily Installment" },
    { key: "loanAmountValue", header: "Loan Amount" },
    { key: "payableLoanDays", header: "Loan Age (in Days)" },
    { key: "third_last_payment_date", header: "Payment Date - 3nd Previous" },
    { key: "third_last_payment_amount", header: "Paid Amount - 3nd Previous  " },
    { key: "second_last_payment_date", header: "Payment Date - 2nd Previous" },
    { key: "second_last_payment_amount", header: "  Paid Amount - 2nd Previous" },
    { key: "last_payment_date", header: "Payment Date - Latest" },
    { key: "last_payment_amount", header: " Payment Amount – Latest" },
    { key: "duedaysCount", header: "Days Since Last Payment" },
    { key: "payableAmount", header: "Loan Payable" },
    { key: "totalLoanAmount", header: "Total Paid" },
    { key: "late_fee", header: "Late Fee" },
    { key: "remainingBalance", header: "Balance" },
    { key: "loanBalance", header: "OutStanding" },
    { key: "status", header: "Status" }
  ];
  const StatCard = ({ icon: Icon, label, value, color }) => /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-600 mb-1", children: label }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
        lineNumber: 181,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: value }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
        lineNumber: 182,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
      lineNumber: 180,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `p-3 rounded-lg ${color}`, children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-6 h-6 text-white" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
      lineNumber: 185,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
      lineNumber: 184,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
    lineNumber: 179,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
    lineNumber: 178,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: /* @__PURE__ */ jsxDEV("div", { className: " mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(FileText, { className: "w-7 h-7 text-violet-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
          lineNumber: 197,
          columnNumber: 13
        }, this),
        " Customer OutStanding Loan Report"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
        lineNumber: 196,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 ml-10", children: "Overview of customer outstanding loans, payments & referral details" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
        lineNumber: 199,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
      lineNumber: 195,
      columnNumber: 9
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-96", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
      lineNumber: 206,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
      lineNumber: 205,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "my-6", children: /* @__PURE__ */ jsxDEV(
        Collapse,
        {
          items: [
            {
              key: "1",
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-base", children: "Shortcut Keys" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                lineNumber: 217,
                columnNumber: 17
              }, this),
              children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-4", children: [
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/other-service-menu/loan",
                    className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(FaMoneyBill, { className: "text-violet-500", size: 30 }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                        lineNumber: 227,
                        columnNumber: 27
                      }, this),
                      "Add Loan"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                    lineNumber: 223,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/reports/customer-loan-report",
                    className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        DollarOutlined,
                        {
                          className: "text-violet-500",
                          size: 30
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                          lineNumber: 234,
                          columnNumber: 27
                        },
                        this
                      ),
                      "Loan Summary Report"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                    lineNumber: 230,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/reports/loan-completion-report",
                    className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        FileTextOutlined,
                        {
                          className: "text-violet-500",
                          size: 30
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                          lineNumber: 245,
                          columnNumber: 27
                        },
                        this
                      ),
                      "Loan Completion Report"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                    lineNumber: 241,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                lineNumber: 222,
                columnNumber: 17
              }, this)
            }
          ],
          defaultActiveKey: ["1"],
          className: "rounded-lg border border-gray-200 bg-white shadow-sm"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
          lineNumber: 212,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
        lineNumber: 211,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: FileText,
              label: "Total Loans",
              value: summaryStats.totalLoans,
              color: "bg-violet-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
              lineNumber: 263,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words", children: numberToIndianWords(summaryStats.totalLoans || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
            lineNumber: 269,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
          lineNumber: 262,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: IndianRupee,
              label: "Total Loan Amount",
              value: `₹${summaryStats.totalAmount}`,
              color: "bg-purple-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
              lineNumber: 275,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words", children: numberToIndianWords(summaryStats.totalAmount || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
            lineNumber: 281,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
          lineNumber: 274,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: TrendingUp,
              label: "Total Payable",
              value: `₹${summaryStats.totalPayable}`,
              color: "bg-violet-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
              lineNumber: 287,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words", children: numberToIndianWords(summaryStats.totalPayable || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
            lineNumber: 293,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
          lineNumber: 286,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: TrendingUp,
              label: "Total Paid",
              value: `₹${summaryStats.totalPaid}`,
              color: "bg-green-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
              lineNumber: 299,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words", children: numberToIndianWords(summaryStats.totalPaid || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
            lineNumber: 305,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
          lineNumber: 298,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
        lineNumber: 260,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border p-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold flex items-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "w-5 h-5" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
            lineNumber: 328,
            columnNumber: 17
          }, this),
          " Filter Options"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
          lineNumber: 327,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Loan ID & Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
              lineNumber: 334,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Select loan",
                value: selectedLoanId,
                onChange: setSelectedLoanId,
                allowClear: true,
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Loans" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                    lineNumber: 343,
                    columnNumber: 21
                  }, this),
                  uniqueLoanCombos.map(
                    (loan) => /* @__PURE__ */ jsxDEV(Select.Option, { value: loan.id, children: loan.label }, loan.id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                      lineNumber: 345,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                lineNumber: 335,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
            lineNumber: 333,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
              lineNumber: 354,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Select customer",
                value: selectedCustomer,
                onChange: setSelectedCustomer,
                allowClear: true,
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                    lineNumber: 363,
                    columnNumber: 21
                  }, this),
                  uniqueCustomers.map(
                    (cust) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: cust.id,
                        children: [
                          cust.custid,
                          " | ",
                          cust.name,
                          " | ",
                          cust.phone
                        ]
                      },
                      cust.id,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                        lineNumber: 365,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                lineNumber: 355,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
            lineNumber: 353,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Referred By" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
              lineNumber: 377,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Select referrer",
                value: selectedReferredBy,
                onChange: setSelectedReferredBy,
                allowClear: true,
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Referred By" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                    lineNumber: 386,
                    columnNumber: 21
                  }, this),
                  uniqueReferredBy.map(
                    (ref) => /* @__PURE__ */ jsxDEV(Select.Option, { value: ref, children: ref }, ref, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                      lineNumber: 388,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                lineNumber: 378,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
            lineNumber: 376,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Start Date Range" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
              lineNumber: 397,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              RangePicker,
              {
                value: dateRange,
                onChange: setDateRange,
                className: "w-full",
                format: "DD/MM/YYYY"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
                lineNumber: 398,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
            lineNumber: 396,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
          lineNumber: 331,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
        lineNumber: 326,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns: loanReportColumns,
          data: filteredLoanReport,
          printHeaderKeys: [
            "Total Loans",
            "Total Loan Amount",
            "Total Payable",
            "Total Paid",
            "Total Outstanding"
          ],
          printHeaderValues: [
            summaryStats.totalLoans.toLocaleString("en-IN"),
            `₹ ${summaryStats.totalAmount.toLocaleString("en-IN")}`,
            `₹ ${summaryStats.totalPayable.toLocaleString("en-IN")}`,
            `₹ ${summaryStats.totalPaid.toLocaleString("en-IN")}`,
            `₹ ${summaryStats.totalBalance.toLocaleString("en-IN")}`
          ],
          exportedPdfName: "OutStanding Customer Loan Report",
          exportedFileName: "OutStanding Customer Loan Report.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
          lineNumber: 410,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
        lineNumber: 409,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
      lineNumber: 209,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
    lineNumber: 193,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx",
    lineNumber: 192,
    columnNumber: 5
  }, this);
};
_s(DueLoanReport, "dENn+Yil8LNzO5ED7UbXhI9EW3s=");
_c = DueLoanReport;
export default DueLoanReport;
var _c;
$RefreshReg$(_c, "DueLoanReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0xVLFNBNEJBLFVBNUJBOzJCQXBMVjtBQUFvQkEsb0JBQWlCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDcEQsU0FBU0MsUUFBUUMsVUFBVUMsT0FBT0MsVUFBVUMsYUFBYUMsa0JBQWtCO0FBQzNFLFNBQVNDLGtCQUFrQjtBQUMzQixPQUFPQyxXQUFXO0FBRWxCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxrQkFBa0JDLHNCQUFzQjtBQUNqRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsMkJBQTJCO0FBRXBDLE1BQU0sRUFBRUMsWUFBWSxJQUFJWjtBQUV4QixNQUFNYSxnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUl2QixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDd0IsU0FBU0MsVUFBVSxJQUFJekIsU0FBUyxJQUFJO0FBRTNDLFFBQU0sQ0FBQzBCLGdCQUFnQkMsaUJBQWlCLElBQUkzQixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDNEIsa0JBQWtCQyxtQkFBbUIsSUFBSTdCLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUM4QixvQkFBb0JDLHFCQUFxQixJQUFJL0IsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQ2dDLFdBQVdDLFlBQVksSUFBSWpDLFNBQVMsSUFBSTtBQUUvQ2tDLFlBQVUsTUFBTTtBQUNkLFVBQU1DLGtCQUFrQixZQUFZO0FBQ2xDLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU0zQixJQUFJNEIsSUFBSSxvQ0FBb0M7QUFDbkVDLGdCQUFRQyxLQUFLSCxTQUFTSSxJQUFJO0FBRTFCLGNBQU1DLGdCQUFnQkwsU0FBU0ksS0FBS0UsWUFBWUMsT0FBTyxDQUFDQyxVQUFVQSxNQUFNQyxXQUFXLEtBQUssQ0FBQyxFQUFFQyxJQUFJLENBQUNGLE1BQU1HLFdBQVc7QUFBQSxVQUMvR0MsSUFBSUosTUFBTUs7QUFBQUEsVUFDVkMsTUFBTUgsUUFBUTtBQUFBLFVBQ2RJLFNBQVNQLE1BQU1RLFdBQVc7QUFBQSxVQUMxQkMsaUJBQWlCVCxNQUFNVSxlQUFlO0FBQUEsVUFFdENDLFlBQVlYLE1BQU1ZLFVBQVVDLGVBQWU7QUFBQSxVQUMzQ0MsY0FBY2QsTUFBTVksVUFBVUcsYUFBYTtBQUFBLFVBQzNDQyxlQUFlaEIsTUFBTVksVUFBVUssZ0JBQWdCO0FBQUEsVUFDL0NDLHNCQUFzQmxCLE1BQU1rQix3QkFBd0I7QUFBQSxVQUNwREMsZUFBZW5CLE1BQU1vQixhQUNqQixJQUFJQyxLQUFLckIsS0FBS29CLFVBQVUsRUFBRUUsbUJBQW1CLE9BQU8sSUFDcEQ7QUFBQTtBQUFBLFVBRUpDLGtCQUFrQnZCLE1BQU1vQixhQUFhLElBQUlDLEtBQUtyQixLQUFLb0IsVUFBVSxJQUFJO0FBQUE7QUFBQSxVQUVqRUksYUFBYXhCLE1BQU15QixXQUFXLEdBQUd6QixNQUFNeUIsUUFBUSxHQUFHQyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQzFEO0FBQUEsVUFDSkMsa0JBQWtCM0IsTUFBTTRCLHFCQUFxQixHQUFHNUIsTUFBTTRCLGtCQUFrQixHQUFHRixNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUk7QUFBQSxVQUMzRkcsbUJBQW1CN0IsTUFBTTZCLG9CQUFvQixHQUFHN0IsTUFBTTZCLGlCQUFpQixHQUFHSCxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUk7QUFBQSxVQUMxRkkscUJBQXFCOUIsTUFBTThCLHVCQUF1QjtBQUFBLFVBQ2xEQywwQkFBMEIvQixNQUFNK0IsMkJBQTJCLEdBQUcvQixNQUFNK0Isd0JBQXdCLEdBQUdMLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFBSTtBQUFBLFVBQy9HTSw0QkFBNEJoQyxNQUFNZ0MsOEJBQThCO0FBQUEsVUFDaEVDLHlCQUF5QmpDLE1BQU1pQywwQkFBMEIsR0FBR2pDLE1BQU1pQyx1QkFBdUIsR0FBR1AsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJO0FBQUEsVUFDNUdRLDJCQUEyQmxDLE1BQU1rQyw2QkFBNkI7QUFBQSxVQUU5REMscUJBQXFCbkMsTUFBTW9DLG9CQUFvQjtBQUFBLFVBQy9DQyxpQkFBaUJyQyxNQUFNc0M7QUFBQUEsVUFDdkJDLGNBQWN2QyxNQUFNdUM7QUFBQUEsVUFDcEJDLG9CQUFvQnhDLE1BQU15QyxtQkFBbUI7QUFBQSxVQUM3Q0MsWUFBWTFDLE1BQU0yQyxzQkFBc0I7QUFBQSxVQUN4Q0MsZUFBZTVDLE1BQU02QyxrQkFBa0I7QUFBQSxVQUN2Q0MsaUJBQWlCOUMsTUFBTStDLHFCQUFxQjtBQUFBLFVBQzVDQyxVQUFTaEQsTUFBTWlELHVCQUF1QjtBQUFBLFVBQ3RDQyxhQUFhbEQsTUFBTW1ELGVBQWU7QUFBQSxVQUNsQ0Msa0JBQWtCcEQsTUFBTUMsV0FBVztBQUFBLFVBQ25Db0QsUUFBUXJELE1BQU1xRCxVQUFVO0FBQUEsVUFDeEJDLFlBQVl0RCxNQUFNc0QsY0FBYztBQUFBLFFBQ2xDLEVBQUU7QUFHRjNFLDJCQUFtQmtCLGFBQWE7QUFBQSxNQUNsQyxTQUFTMEQsT0FBTztBQUNkN0QsZ0JBQVE2RCxNQUFNLCtCQUErQkEsS0FBSztBQUFBLE1BQ3BELFVBQUM7QUFDQzFFLG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFFQVUsb0JBQWdCO0FBQUEsRUFDbEIsR0FBRyxFQUFFO0FBRUwsUUFBTWlFLG1CQUFtQkMsUUFBUSxNQUFNO0FBQ3JDLFVBQU12RCxNQUFNLG9CQUFJd0QsSUFBSTtBQUNwQmhGLG9CQUFnQmlGLFFBQVEsQ0FBQzNELFNBQVM7QUFDaEMsWUFBTTRELE1BQU01RCxLQUFLTztBQUNqQixVQUFJLENBQUNMLElBQUkyRCxJQUFJRCxHQUFHLEdBQUc7QUFDakIxRCxZQUFJNEQsSUFBSUYsS0FBSyxFQUFFeEQsSUFBSXdELEtBQUtHLE9BQU8sR0FBR0gsR0FBRyxPQUFPNUQsS0FBS1MsZUFBZSxHQUFHLENBQUM7QUFBQSxNQUN0RTtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU91RCxNQUFNQyxLQUFLL0QsSUFBSWdFLE9BQU8sQ0FBQztBQUFBLEVBQ2hDLEdBQUcsQ0FBQ3hGLGVBQWUsQ0FBQztBQUVwQixRQUFNeUYsa0JBQWtCVjtBQUFBQSxJQUN0QixNQUNFL0UsZ0JBQWdCd0IsSUFBSSxDQUFDRixVQUFVO0FBQUEsTUFDN0JJLElBQUlKLEtBQUtJO0FBQUFBLE1BQ1RnRSxNQUFNcEUsS0FBS2M7QUFBQUEsTUFDWHVELE9BQU9yRSxLQUFLZ0I7QUFBQUEsTUFDWnNELFFBQVF0RSxLQUFLVztBQUFBQSxJQUNmLEVBQUU7QUFBQSxJQUNKLENBQUNqQyxlQUFlO0FBQUEsRUFDbEI7QUFFQSxRQUFNNkYsbUJBQW1CZCxRQUFRLE1BQU07QUFDckMsVUFBTUssTUFBTSxvQkFBSVUsSUFBSTtBQUNwQjlGLG9CQUFnQmlGLFFBQVEsQ0FBQzNELFNBQVM7QUFDaEMsVUFBSUEsS0FBS3NELGNBQWN0RCxLQUFLc0QsZUFBZSxPQUFPO0FBQ2hEUSxZQUFJVyxJQUFJekUsS0FBS3NELFVBQVU7QUFBQSxNQUN6QjtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU9VLE1BQU1DLEtBQUtILEdBQUc7QUFBQSxFQUN2QixHQUFHLENBQUNwRixlQUFlLENBQUM7QUFFcEIsUUFBTWdHLHFCQUFxQmpCLFFBQVEsTUFBTTtBQUN2QyxXQUFPL0UsZ0JBQWdCcUIsT0FBTyxDQUFDQyxTQUFTO0FBQ3RDLFlBQU0yRSxjQUFjN0YsaUJBQWlCa0IsS0FBS08sWUFBWXpCLGlCQUFpQjtBQUN2RSxZQUFNOEYsZ0JBQWdCNUYsbUJBQW1CZ0IsS0FBS0ksT0FBT3BCLG1CQUFtQjtBQUN4RSxZQUFNNkYsa0JBQWtCM0YscUJBQXFCYyxLQUFLc0QsZUFBZXBFLHFCQUFxQjtBQUd0RixVQUFJNEYsaUJBQWlCO0FBQ3JCLFVBQUkxRixhQUFhQSxVQUFVMkYsV0FBVyxLQUFLL0UsS0FBS3VCLGtCQUFrQjtBQUNoRSxjQUFNeUQsWUFBWXBILE1BQU13QixVQUFVLENBQUMsQ0FBQyxFQUFFNkYsUUFBUSxLQUFLO0FBQ25ELGNBQU1DLFVBQVV0SCxNQUFNd0IsVUFBVSxDQUFDLENBQUMsRUFBRStGLE1BQU0sS0FBSztBQUMvQyxjQUFNQyxXQUFXeEgsTUFBTW9DLEtBQUt1QixnQkFBZ0I7QUFDNUN1RCx5QkFBaUJNLFNBQVNDLFFBQVFMLFNBQVMsS0FBS0ksU0FBU0UsU0FBU0osT0FBTztBQUFBLE1BQzNFO0FBRUEsYUFBT1AsZUFBZUMsaUJBQWlCQyxtQkFBbUJDO0FBQUFBLElBQzVELENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ3BHLGlCQUFpQkksZ0JBQWdCRSxrQkFBa0JFLG9CQUFvQkUsU0FBUyxDQUFDO0FBRXJGLFFBQU1tRyxlQUFlOUIsUUFBUSxNQUFNO0FBQ2pDLFVBQU0rQixXQUFXZDtBQUNqQixXQUFPO0FBQUEsTUFDTGUsWUFBWUQsU0FBU1Q7QUFBQUEsTUFDckJXLGFBQWFGLFNBQVNHLE9BQU8sQ0FBQ0MsS0FBSzVGLFNBQVM0RixNQUFNNUYsS0FBSzBDLFlBQVksQ0FBQztBQUFBLE1BQ3BFbUQsY0FBY0wsU0FBU0csT0FBTyxDQUFDQyxLQUFLNUYsU0FBUzRGLE1BQU01RixLQUFLNEMsZUFBZSxDQUFDO0FBQUEsTUFDeEVrRCxXQUFXTixTQUFTRyxPQUFPLENBQUNDLEtBQUs1RixTQUFTNEYsTUFBTTVGLEtBQUs4QyxpQkFBaUIsQ0FBQztBQUFBLE1BQ3ZFaUQsY0FBY1AsU0FBU0csT0FBTyxDQUFDQyxLQUFLNUYsU0FBUzRGLE1BQU01RixLQUFLa0QsYUFBYSxDQUFDO0FBQUEsSUFDeEU7QUFBQSxFQUNGLEdBQUcsQ0FBQ3dCLGtCQUFrQixDQUFDO0FBRXZCLFFBQU1zQixvQkFBb0I7QUFBQSxJQUN4QixFQUFFcEMsS0FBSyxRQUFRcUMsUUFBUSxRQUFRO0FBQUEsSUFDL0IsRUFBRXJDLEtBQUssV0FBV3FDLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVyQyxLQUFLLGdCQUFnQnFDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRXJDLEtBQUssaUJBQWlCcUMsUUFBUSxlQUFlO0FBQUEsSUFDL0MsRUFBRXJDLEtBQUssY0FBY3FDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVyQyxLQUFLLG9CQUFvQnFDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDbkQsRUFBRXJDLEtBQUssaUJBQWlCcUMsUUFBUSxrQkFBa0I7QUFBQSxJQUNsRCxFQUFFckMsS0FBSyxlQUFlcUMsUUFBUSxnQkFBZ0I7QUFBQSxJQUM5QyxFQUFFckMsS0FBSyxzQkFBc0JxQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3ZELEVBQUVyQyxLQUFLLHVCQUF1QnFDLFFBQVEsd0JBQXdCO0FBQUEsSUFDOUQsRUFBRXJDLEtBQUssd0JBQXdCcUMsUUFBUSxvQkFBb0I7QUFBQSxJQUMzRCxFQUFFckMsS0FBSyxtQkFBbUJxQyxRQUFRLGNBQWM7QUFBQSxJQUNoRCxFQUFFckMsS0FBSyxtQkFBbUJxQyxRQUFRLHFCQUFxQjtBQUFBLElBQ3ZELEVBQUVyQyxLQUFLLDJCQUEyQnFDLFFBQVEsOEJBQThCO0FBQUEsSUFDeEUsRUFBRXJDLEtBQUssNkJBQTZCcUMsUUFBUSwrQkFBK0I7QUFBQSxJQUMzRSxFQUFFckMsS0FBSyw0QkFBNEJxQyxRQUFRLDhCQUE4QjtBQUFBLElBQ3pFLEVBQUVyQyxLQUFLLDhCQUE4QnFDLFFBQVEsK0JBQStCO0FBQUEsSUFDNUUsRUFBRXJDLEtBQUsscUJBQXFCcUMsUUFBUSx3QkFBd0I7QUFBQSxJQUM1RCxFQUFFckMsS0FBSyx1QkFBdUJxQyxRQUFRLDJCQUEyQjtBQUFBLElBQ2pFLEVBQUVyQyxLQUFLLGdCQUFnQnFDLFFBQVEsMEJBQTBCO0FBQUEsSUFDekQsRUFBRXJDLEtBQUssaUJBQWlCcUMsUUFBUSxlQUFlO0FBQUEsSUFDL0MsRUFBRXJDLEtBQUssbUJBQW1CcUMsUUFBUSxhQUFhO0FBQUEsSUFDL0MsRUFBRXJDLEtBQUssWUFBWXFDLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVyQyxLQUFLLG9CQUFvQnFDLFFBQVEsVUFBVTtBQUFBLElBQzdDLEVBQUVyQyxLQUFLLGVBQWVxQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFckMsS0FBSyxVQUFVcUMsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUlyQyxRQUFNQyxXQUFXQSxDQUFDLEVBQUVDLE1BQU1DLE1BQU1yQyxPQUFPc0MsT0FBT0MsTUFBTSxNQUNsRCx1QkFBQyxTQUFJLFdBQVUsNENBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUUsV0FBVSwwQ0FBMEN2QyxtQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdELHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0NzQyxtQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RDtBQUFBLFNBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXLGtCQUFrQkMsS0FBSyxJQUNyQyxpQ0FBQyxRQUFLLFdBQVUsd0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFHRixTQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFDYixpQ0FBQyxTQUFJLFdBQVUsWUFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDhDQUNaO0FBQUEsK0JBQUMsWUFBUyxXQUFVLDZCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFBRztBQUFBLFdBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLHVCQUFzQixtRkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVDMUgsVUFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLG1DQUVFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU87QUFBQSxZQUNMO0FBQUEsY0FDRWdGLEtBQUs7QUFBQSxjQUNMRyxPQUNFLHVCQUFDLFVBQUssV0FBVSx5Q0FBd0MsNkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVGd0MsVUFDRSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFHO0FBQUEsb0JBQ0gsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsZUFBWSxXQUFVLG1CQUFrQixNQUFNLE1BQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtEO0FBQUEsc0JBQUc7QUFBQTtBQUFBO0FBQUEsa0JBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLElBQUc7QUFBQSxvQkFDSCxXQUFVO0FBQUEsb0JBRVY7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsTUFBTTtBQUFBO0FBQUEsd0JBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUVXO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsSUFBRztBQUFBLG9CQUNILFdBQVU7QUFBQSxvQkFFVjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixNQUFNO0FBQUE7QUFBQSx3QkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxtQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2QkE7QUFBQSxZQUVKO0FBQUEsVUFBQztBQUFBLFVBRUgsa0JBQWtCLENBQUMsR0FBRztBQUFBLFVBQ3RCLFdBQVU7QUFBQTtBQUFBLFFBNUNaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTRDa0UsS0E3Q3BFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQ0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw2REFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNako7QUFBQUEsY0FDTixPQUFNO0FBQUEsY0FDTixPQUFPaUksYUFBYUU7QUFBQUEsY0FDcEIsT0FBTTtBQUFBO0FBQUEsWUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJdUI7QUFBQSxVQUV2Qix1QkFBQyxVQUFLLFdBQVUscURBQ2JuSCw4QkFBb0JpSCxhQUFhRSxjQUFjLENBQUMsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTWhJO0FBQUFBLGNBQ04sT0FBTTtBQUFBLGNBQ04sT0FBTyxJQUFJOEgsYUFBYUcsV0FBVztBQUFBLGNBQ25DLE9BQU07QUFBQTtBQUFBLFlBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXVCO0FBQUEsVUFFdkIsdUJBQUMsVUFBSyxXQUFVLHFEQUNicEgsOEJBQW9CaUgsYUFBYUcsZUFBZSxDQUFDLEtBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU1oSTtBQUFBQSxjQUNOLE9BQU07QUFBQSxjQUNOLE9BQU8sSUFBSTZILGFBQWFNLFlBQVk7QUFBQSxjQUNwQyxPQUFNO0FBQUE7QUFBQSxZQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl1QjtBQUFBLFVBRXZCLHVCQUFDLFVBQUssV0FBVSxxREFDYnZILDhCQUFvQmlILGFBQWFNLGdCQUFnQixDQUFDLEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU1uSTtBQUFBQSxjQUNOLE9BQU07QUFBQSxjQUNOLE9BQU8sSUFBSTZILGFBQWFPLFNBQVM7QUFBQSxjQUNqQyxPQUFNO0FBQUE7QUFBQSxZQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlzQjtBQUFBLFVBRXRCLHVCQUFDLFVBQUssV0FBVSxxREFDYnhILDhCQUFvQmlILGFBQWFPLGFBQWEsQ0FBQyxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxXQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOERBO0FBQUEsTUFJQSx1QkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsc0RBQ1o7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUFHO0FBQUEsYUFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBRWI7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtDQUFpQyxnQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNsRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsYUFBWTtBQUFBLGdCQUNaLE9BQU9oSDtBQUFBQSxnQkFDUCxVQUFVQztBQUFBQSxnQkFDVjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyx5QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFDaEN5RSxpQkFBaUJ0RDtBQUFBQSxvQkFBSSxDQUFDRixTQUNyQix1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsS0FBS0ksSUFDdENKLGVBQUsrRCxTQURZL0QsS0FBS0ksSUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY0E7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrQ0FBaUMsd0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDMUQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPcEI7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsNkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQ3BDa0YsZ0JBQWdCakU7QUFBQUEsb0JBQUksQ0FBQ3NHLFNBQ3BCO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBRUMsT0FBT0EsS0FBS3BHO0FBQUFBLHdCQUVYb0c7QUFBQUEsK0JBQUtsQztBQUFBQSwwQkFBTztBQUFBLDBCQUFJa0MsS0FBS3BDO0FBQUFBLDBCQUFLO0FBQUEsMEJBQUlvQyxLQUFLbkM7QUFBQUE7QUFBQUE7QUFBQUEsc0JBSC9CbUMsS0FBS3BHO0FBQUFBLHNCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFpQkE7QUFBQSxlQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrQ0FBaUMsMkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsWUFDN0Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPbEI7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsK0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUEsa0JBQ3RDb0YsaUJBQWlCckU7QUFBQUEsb0JBQUksQ0FBQ3VHLFFBQ3JCLHVCQUFDLE9BQU8sUUFBUCxFQUF3QixPQUFPQSxLQUM3QkEsaUJBRGlCQSxLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtDQUFpQyxnQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNsRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9ySDtBQUFBQSxnQkFDUCxVQUFVQztBQUFBQSxnQkFDVixXQUFVO0FBQUEsZ0JBQ1YsUUFBTztBQUFBO0FBQUEsY0FKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJcUI7QUFBQSxlQU52QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUF6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBFQTtBQUFBLFdBL0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnRkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUzJHO0FBQUFBLFVBQ1QsTUFBTXRCO0FBQUFBLFVBQ04saUJBQWlCO0FBQUEsWUFDZjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUFtQjtBQUFBLFVBRXJCLG1CQUFtQjtBQUFBLFlBQ2pCYSxhQUFhRSxXQUFXaUIsZUFBZSxPQUFPO0FBQUEsWUFDOUMsS0FBS25CLGFBQWFHLFlBQVlnQixlQUFlLE9BQU8sQ0FBQztBQUFBLFlBQ3JELEtBQUtuQixhQUFhTSxhQUFhYSxlQUFlLE9BQU8sQ0FBQztBQUFBLFlBQ3RELEtBQUtuQixhQUFhTyxVQUFVWSxlQUFlLE9BQU8sQ0FBQztBQUFBLFlBQ25ELEtBQUtuQixhQUFhUSxhQUFhVyxlQUFlLE9BQU8sQ0FBQztBQUFBLFVBQUU7QUFBQSxVQUUxRCxpQkFBZ0I7QUFBQSxVQUNoQixrQkFBaUI7QUFBQTtBQUFBLFFBbEJuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFrQnlELEtBbkIzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsU0E3TkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThOQTtBQUFBLE9BOU9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnUEEsS0FqUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtQQTtBQUVKO0FBQUVqSSxHQWxhSUQsZUFBYTtBQUFBbUksS0FBYm5JO0FBb2FOLGVBQWVBO0FBQWMsSUFBQW1JO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlNlYXJjaCIsIkZpbGVUZXh0IiwiVXNlcnMiLCJDYWxlbmRhciIsIkluZGlhblJ1cGVlIiwiVHJlbmRpbmdVcCIsIkRhdGVQaWNrZXIiLCJkYXlqcyIsImFwaSIsIkRhdGFUYWJsZSIsIlNlbGVjdCIsIkNpcmN1bGFyTG9hZGVyIiwiQ29sbGFwc2UiLCJMaW5rIiwiRmlsZVRleHRPdXRsaW5lZCIsIkRvbGxhck91dGxpbmVkIiwiRmFNb25leUJpbGwiLCJudW1iZXJUb0luZGlhbldvcmRzIiwiUmFuZ2VQaWNrZXIiLCJEdWVMb2FuUmVwb3J0IiwiX3MiLCJsb2FuUmVwb3J0VGFibGUiLCJzZXRMb2FuUmVwb3J0VGFibGUiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNlbGVjdGVkTG9hbklkIiwic2V0U2VsZWN0ZWRMb2FuSWQiLCJzZWxlY3RlZEN1c3RvbWVyIiwic2V0U2VsZWN0ZWRDdXN0b21lciIsInNlbGVjdGVkUmVmZXJyZWRCeSIsInNldFNlbGVjdGVkUmVmZXJyZWRCeSIsImRhdGVSYW5nZSIsInNldERhdGVSYW5nZSIsInVzZUVmZmVjdCIsImZldGNoTG9hblJlcG9ydCIsInJlc3BvbnNlIiwiZ2V0IiwiY29uc29sZSIsImluZm8iLCJkYXRhIiwiZm9ybWF0dGVkRGF0YSIsImxvYW5SZXBvcnRzIiwiZmlsdGVyIiwibG9hbiIsImJhbGFuY2UiLCJtYXAiLCJpbmRleCIsImlkIiwiX2lkIiwic2xObyIsImxvYW5JZHMiLCJsb2FuX2lkIiwibG9hbkFtb3VudFZhbHVlIiwibG9hbl9hbW91bnQiLCJjdXN0b21lcklkIiwiYm9ycm93ZXIiLCJjdXN0b21lcl9pZCIsImN1c3RvbWVyTmFtZSIsImZ1bGxfbmFtZSIsImN1c3RvbWVyUGhvbmUiLCJwaG9uZV9udW1iZXIiLCJkYWlseV9wYXltZW50X2Ftb3VudCIsImxvYW5TdGFydERhdGUiLCJzdGFydF9kYXRlIiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImxvYW5TdGFydERhdGVPYmoiLCJsb2FuRW5kRGF0ZSIsImVuZF9kYXRlIiwic3BsaXQiLCJsb2FuU2FuY3Rpb25EYXRlIiwibG9hbl9zYW5jdGlvbl9kYXRlIiwibGFzdF9wYXltZW50X2RhdGUiLCJsYXN0X3BheW1lbnRfYW1vdW50Iiwic2Vjb25kX2xhc3RfcGF5bWVudF9kYXRlIiwic2Vjb25kX2xhc3RfcGF5bWVudF9hbW91bnQiLCJ0aGlyZF9sYXN0X3BheW1lbnRfZGF0ZSIsInRoaXJkX2xhc3RfcGF5bWVudF9hbW91bnQiLCJsb2FuRG9jdW1lbnRDaGFyZ2VzIiwiZG9jdW1lbnRfY2hhcmdlcyIsInBheWFibGVMb2FuRGF5cyIsImRheXNDb3VudCIsImR1ZWRheXNDb3VudCIsImxvYW5TZXJ2aWNlQ2hhcmdlcyIsInNlcnZpY2VfY2hhcmdlcyIsImxvYW5BbW91bnQiLCJkb3VibGVfbG9hbl9hbW91bnQiLCJwYXlhYmxlQW1vdW50IiwiYW1vdW50X3BheWFibGUiLCJ0b3RhbExvYW5BbW91bnQiLCJ0b3RhbF9wYWlkX2Ftb3VudCIsImxhdGVfZmVlIiwidG90YWxfZXh0cmFfY2hhcmdlcyIsImxvYW5CYWxhbmNlIiwib3V0c3RhbmRpbmciLCJyZW1haW5pbmdCYWxhbmNlIiwic3RhdHVzIiwicmVmZXJyZWRCeSIsImVycm9yIiwidW5pcXVlTG9hbkNvbWJvcyIsInVzZU1lbW8iLCJNYXAiLCJmb3JFYWNoIiwia2V5IiwiaGFzIiwic2V0IiwibGFiZWwiLCJBcnJheSIsImZyb20iLCJ2YWx1ZXMiLCJ1bmlxdWVDdXN0b21lcnMiLCJuYW1lIiwicGhvbmUiLCJjdXN0aWQiLCJ1bmlxdWVSZWZlcnJlZEJ5IiwiU2V0IiwiYWRkIiwiZmlsdGVyZWRMb2FuUmVwb3J0IiwibWF0Y2hMb2FuSWQiLCJtYXRjaEN1c3RvbWVyIiwibWF0Y2hSZWZlcnJlZEJ5IiwibWF0Y2hEYXRlUmFuZ2UiLCJsZW5ndGgiLCJzdGFydERhdGUiLCJzdGFydE9mIiwiZW5kRGF0ZSIsImVuZE9mIiwibG9hbkRhdGUiLCJpc0FmdGVyIiwiaXNCZWZvcmUiLCJzdW1tYXJ5U3RhdHMiLCJmaWx0ZXJlZCIsInRvdGFsTG9hbnMiLCJ0b3RhbEFtb3VudCIsInJlZHVjZSIsInN1bSIsInRvdGFsUGF5YWJsZSIsInRvdGFsUGFpZCIsInRvdGFsQmFsYW5jZSIsImxvYW5SZXBvcnRDb2x1bW5zIiwiaGVhZGVyIiwiU3RhdENhcmQiLCJpY29uIiwiSWNvbiIsInZhbHVlIiwiY29sb3IiLCJjaGlsZHJlbiIsImN1c3QiLCJyZWYiLCJ0b0xvY2FsZVN0cmluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkR1ZUxvYW5SZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgU2VhcmNoLCBGaWxlVGV4dCwgVXNlcnMsIENhbGVuZGFyLCBJbmRpYW5SdXBlZSwgVHJlbmRpbmdVcCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgRGF0ZVBpY2tlciB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuXHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBTZWxlY3QgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBDb2xsYXBzZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBGaWxlVGV4dE91dGxpbmVkLCBEb2xsYXJPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBGYU1vbmV5QmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiXHJcblxyXG5jb25zdCB7IFJhbmdlUGlja2VyIH0gPSBEYXRlUGlja2VyO1xyXG5cclxuY29uc3QgRHVlTG9hblJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbbG9hblJlcG9ydFRhYmxlLCBzZXRMb2FuUmVwb3J0VGFibGVdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG5cclxuICBjb25zdCBbc2VsZWN0ZWRMb2FuSWQsIHNldFNlbGVjdGVkTG9hbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVyLCBzZXRTZWxlY3RlZEN1c3RvbWVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFJlZmVycmVkQnksIHNldFNlbGVjdGVkUmVmZXJyZWRCeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGF0ZVJhbmdlLCBzZXREYXRlUmFuZ2VdID0gdXNlU3RhdGUobnVsbCk7IC8vIE5FVyBTVEFURSBmb3IgZGF0ZSByYW5nZVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hMb2FuUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvY3VzdG9tZXJzL2R1ZS1sb2FuLXJlcG9ydGApO1xyXG4gICAgICAgIGNvbnNvbGUuaW5mbyhyZXNwb25zZS5kYXRhKVxyXG5cclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5sb2FuUmVwb3J0cy5maWx0ZXIoKGxvYW4pID0+IChsb2FuPy5iYWxhbmNlID8/IDApID4gMCkubWFwKChsb2FuLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgIGlkOiBsb2FuPy5faWQsXHJcbiAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBsb2FuSWRzOiBsb2FuPy5sb2FuX2lkIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBsb2FuQW1vdW50VmFsdWU6IGxvYW4/LmxvYW5fYW1vdW50IHx8IDAsXHJcblxyXG4gICAgICAgICAgY3VzdG9tZXJJZDogbG9hbj8uYm9ycm93ZXI/LmN1c3RvbWVyX2lkIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBjdXN0b21lck5hbWU6IGxvYW4/LmJvcnJvd2VyPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGN1c3RvbWVyUGhvbmU6IGxvYW4/LmJvcnJvd2VyPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGRhaWx5X3BheW1lbnRfYW1vdW50OiBsb2FuPy5kYWlseV9wYXltZW50X2Ftb3VudCB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgbG9hblN0YXJ0RGF0ZTogbG9hbj8uc3RhcnRfZGF0ZVxyXG4gICAgICAgICAgICA/IG5ldyBEYXRlKGxvYW4uc3RhcnRfZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIilcclxuICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgLy8gU3RvcmUgdGhlIG9yaWdpbmFsIGRhdGUgZm9yIGZpbHRlcmluZ1xyXG4gICAgICAgICAgbG9hblN0YXJ0RGF0ZU9iajogbG9hbj8uc3RhcnRfZGF0ZSA/IG5ldyBEYXRlKGxvYW4uc3RhcnRfZGF0ZSkgOiBudWxsLFxyXG4gICAgICAgICAgLy8gbG9hblN0YXJ0RGF0ZU9iajogbG9hbj8uc3RhcnRfZGF0ZSA/IG5ldyBEYXRlKGxvYW4uc3RhcnRfZGF0ZSkgOiBudWxsLFxyXG4gICAgICAgICAgbG9hbkVuZERhdGU6IGxvYW4/LmVuZF9kYXRlID8gYCR7bG9hbj8uZW5kX2RhdGV9YC5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgbG9hblNhbmN0aW9uRGF0ZTogbG9hbj8ubG9hbl9zYW5jdGlvbl9kYXRlID8gYCR7bG9hbj8ubG9hbl9zYW5jdGlvbl9kYXRlfWAuc3BsaXQoXCJUXCIpWzBdIDogXCJOL0FcIixcclxuICAgICAgICAgIGxhc3RfcGF5bWVudF9kYXRlOiBsb2FuPy5sYXN0X3BheW1lbnRfZGF0ZSA/IGAke2xvYW4/Lmxhc3RfcGF5bWVudF9kYXRlfWAuc3BsaXQoXCJUXCIpWzBdIDogXCJOL0FcIixcclxuICAgICAgICAgIGxhc3RfcGF5bWVudF9hbW91bnQ6IGxvYW4/Lmxhc3RfcGF5bWVudF9hbW91bnQgPz8gMCxcclxuICAgICAgICAgIHNlY29uZF9sYXN0X3BheW1lbnRfZGF0ZTogbG9hbj8uc2Vjb25kX2xhc3RfcGF5bWVudF9kYXRlID8gYCR7bG9hbj8uc2Vjb25kX2xhc3RfcGF5bWVudF9kYXRlfWAuc3BsaXQoXCJUXCIpWzBdIDogXCJOL0FcIixcclxuICAgICAgICAgIHNlY29uZF9sYXN0X3BheW1lbnRfYW1vdW50OiBsb2FuPy5zZWNvbmRfbGFzdF9wYXltZW50X2Ftb3VudCA/PyAwLFxyXG4gICAgICAgICAgdGhpcmRfbGFzdF9wYXltZW50X2RhdGU6IGxvYW4/LnRoaXJkX2xhc3RfcGF5bWVudF9kYXRlID8gYCR7bG9hbj8udGhpcmRfbGFzdF9wYXltZW50X2RhdGV9YC5zcGxpdChcIlRcIilbMF0gOiBcIk4vQVwiLFxyXG4gICAgICAgICAgdGhpcmRfbGFzdF9wYXltZW50X2Ftb3VudDogbG9hbj8udGhpcmRfbGFzdF9wYXltZW50X2Ftb3VudCA/PyAwLFxyXG5cclxuICAgICAgICAgIGxvYW5Eb2N1bWVudENoYXJnZXM6IGxvYW4/LmRvY3VtZW50X2NoYXJnZXMgPz8gMCxcclxuICAgICAgICAgIHBheWFibGVMb2FuRGF5czogbG9hbj8uZGF5c0NvdW50LFxyXG4gICAgICAgICAgZHVlZGF5c0NvdW50OiBsb2FuPy5kdWVkYXlzQ291bnQsXHJcbiAgICAgICAgICBsb2FuU2VydmljZUNoYXJnZXM6IGxvYW4/LnNlcnZpY2VfY2hhcmdlcyA/PyAwLFxyXG4gICAgICAgICAgbG9hbkFtb3VudDogbG9hbj8uZG91YmxlX2xvYW5fYW1vdW50ID8/IDAsXHJcbiAgICAgICAgICBwYXlhYmxlQW1vdW50OiBsb2FuPy5hbW91bnRfcGF5YWJsZSA/PyAwLFxyXG4gICAgICAgICAgdG90YWxMb2FuQW1vdW50OiBsb2FuPy50b3RhbF9wYWlkX2Ftb3VudCA/PyAwLFxyXG4gICAgICAgICAgbGF0ZV9mZWU6bG9hbj8udG90YWxfZXh0cmFfY2hhcmdlcyA/PyAwLFxyXG4gICAgICAgICAgbG9hbkJhbGFuY2U6IGxvYW4/Lm91dHN0YW5kaW5nID8/IDAsXHJcbiAgICAgICAgICByZW1haW5pbmdCYWxhbmNlOiBsb2FuPy5iYWxhbmNlID8/IDAsXHJcbiAgICAgICAgICBzdGF0dXM6IGxvYW4/LnN0YXR1cyB8fCBcIi1cIixcclxuICAgICAgICAgIHJlZmVycmVkQnk6IGxvYW4/LnJlZmVycmVkQnkgfHwgXCJOL0FcIixcclxuICAgICAgICB9KSk7XHJcblxyXG5cclxuICAgICAgICBzZXRMb2FuUmVwb3J0VGFibGUoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGxvYW4gcmVwb3J0OlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hMb2FuUmVwb3J0KCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCB1bmlxdWVMb2FuQ29tYm9zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XHJcbiAgICBsb2FuUmVwb3J0VGFibGUuZm9yRWFjaCgobG9hbikgPT4ge1xyXG4gICAgICBjb25zdCBrZXkgPSBsb2FuLmxvYW5JZHM7XHJcbiAgICAgIGlmICghbWFwLmhhcyhrZXkpKSB7XHJcbiAgICAgICAgbWFwLnNldChrZXksIHsgaWQ6IGtleSwgbGFiZWw6IGAke2tleX0gfCDigrkke2xvYW4ubG9hbkFtb3VudFZhbHVlfWAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIEFycmF5LmZyb20obWFwLnZhbHVlcygpKTtcclxuICB9LCBbbG9hblJlcG9ydFRhYmxlXSk7XHJcblxyXG4gIGNvbnN0IHVuaXF1ZUN1c3RvbWVycyA9IHVzZU1lbW8oXHJcbiAgICAoKSA9PlxyXG4gICAgICBsb2FuUmVwb3J0VGFibGUubWFwKChsb2FuKSA9PiAoe1xyXG4gICAgICAgIGlkOiBsb2FuLmlkLFxyXG4gICAgICAgIG5hbWU6IGxvYW4uY3VzdG9tZXJOYW1lLFxyXG4gICAgICAgIHBob25lOiBsb2FuLmN1c3RvbWVyUGhvbmUsXHJcbiAgICAgICAgY3VzdGlkOiBsb2FuLmN1c3RvbWVySWQsXHJcbiAgICAgIH0pKSxcclxuICAgIFtsb2FuUmVwb3J0VGFibGVdXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgdW5pcXVlUmVmZXJyZWRCeSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3Qgc2V0ID0gbmV3IFNldCgpO1xyXG4gICAgbG9hblJlcG9ydFRhYmxlLmZvckVhY2goKGxvYW4pID0+IHtcclxuICAgICAgaWYgKGxvYW4ucmVmZXJyZWRCeSAmJiBsb2FuLnJlZmVycmVkQnkgIT09IFwiTi9BXCIpIHtcclxuICAgICAgICBzZXQuYWRkKGxvYW4ucmVmZXJyZWRCeSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIEFycmF5LmZyb20oc2V0KTtcclxuICB9LCBbbG9hblJlcG9ydFRhYmxlXSk7XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkTG9hblJlcG9ydCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGxvYW5SZXBvcnRUYWJsZS5maWx0ZXIoKGxvYW4pID0+IHtcclxuICAgICAgY29uc3QgbWF0Y2hMb2FuSWQgPSBzZWxlY3RlZExvYW5JZCA/IGxvYW4ubG9hbklkcyA9PT0gc2VsZWN0ZWRMb2FuSWQgOiB0cnVlO1xyXG4gICAgICBjb25zdCBtYXRjaEN1c3RvbWVyID0gc2VsZWN0ZWRDdXN0b21lciA/IGxvYW4uaWQgPT09IHNlbGVjdGVkQ3VzdG9tZXIgOiB0cnVlO1xyXG4gICAgICBjb25zdCBtYXRjaFJlZmVycmVkQnkgPSBzZWxlY3RlZFJlZmVycmVkQnkgPyBsb2FuLnJlZmVycmVkQnkgPT09IHNlbGVjdGVkUmVmZXJyZWRCeSA6IHRydWU7XHJcblxyXG4gICAgICAvLyBORVc6IERhdGUgcmFuZ2UgZmlsdGVyaW5nXHJcbiAgICAgIGxldCBtYXRjaERhdGVSYW5nZSA9IHRydWU7XHJcbiAgICAgIGlmIChkYXRlUmFuZ2UgJiYgZGF0ZVJhbmdlLmxlbmd0aCA9PT0gMiAmJiBsb2FuLmxvYW5TdGFydERhdGVPYmopIHtcclxuICAgICAgICBjb25zdCBzdGFydERhdGUgPSBkYXlqcyhkYXRlUmFuZ2VbMF0pLnN0YXJ0T2YoJ2RheScpO1xyXG4gICAgICAgIGNvbnN0IGVuZERhdGUgPSBkYXlqcyhkYXRlUmFuZ2VbMV0pLmVuZE9mKCdkYXknKTtcclxuICAgICAgICBjb25zdCBsb2FuRGF0ZSA9IGRheWpzKGxvYW4ubG9hblN0YXJ0RGF0ZU9iaik7XHJcbiAgICAgICAgbWF0Y2hEYXRlUmFuZ2UgPSBsb2FuRGF0ZS5pc0FmdGVyKHN0YXJ0RGF0ZSkgJiYgbG9hbkRhdGUuaXNCZWZvcmUoZW5kRGF0ZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiBtYXRjaExvYW5JZCAmJiBtYXRjaEN1c3RvbWVyICYmIG1hdGNoUmVmZXJyZWRCeSAmJiBtYXRjaERhdGVSYW5nZTtcclxuICAgIH0pO1xyXG4gIH0sIFtsb2FuUmVwb3J0VGFibGUsIHNlbGVjdGVkTG9hbklkLCBzZWxlY3RlZEN1c3RvbWVyLCBzZWxlY3RlZFJlZmVycmVkQnksIGRhdGVSYW5nZV0pO1xyXG5cclxuICBjb25zdCBzdW1tYXJ5U3RhdHMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGZpbHRlcmVkID0gZmlsdGVyZWRMb2FuUmVwb3J0O1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWxMb2FuczogZmlsdGVyZWQubGVuZ3RoLFxyXG4gICAgICB0b3RhbEFtb3VudDogZmlsdGVyZWQucmVkdWNlKChzdW0sIGxvYW4pID0+IHN1bSArIGxvYW4ubG9hbkFtb3VudCwgMCksXHJcbiAgICAgIHRvdGFsUGF5YWJsZTogZmlsdGVyZWQucmVkdWNlKChzdW0sIGxvYW4pID0+IHN1bSArIGxvYW4ucGF5YWJsZUFtb3VudCwgMCksXHJcbiAgICAgIHRvdGFsUGFpZDogZmlsdGVyZWQucmVkdWNlKChzdW0sIGxvYW4pID0+IHN1bSArIGxvYW4udG90YWxMb2FuQW1vdW50LCAwKSxcclxuICAgICAgdG90YWxCYWxhbmNlOiBmaWx0ZXJlZC5yZWR1Y2UoKHN1bSwgbG9hbikgPT4gc3VtICsgbG9hbi5sb2FuQmFsYW5jZSwgMCksXHJcbiAgICB9O1xyXG4gIH0sIFtmaWx0ZXJlZExvYW5SZXBvcnRdKTtcclxuXHJcbiAgY29uc3QgbG9hblJlcG9ydENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbE5vXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuSWRzXCIsIGhlYWRlcjogXCJMb2FuIElEXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRCeVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hblNhbmN0aW9uRGF0ZVwiLCBoZWFkZXI6IFwiU2FuY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuU3RhcnREYXRlXCIsIGhlYWRlcjogXCJMb2FuIFN0YXJ0IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbkVuZERhdGVcIiwgaGVhZGVyOiBcIkxvYW4gRW5kIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hblNlcnZpY2VDaGFyZ2VzXCIsIGhlYWRlcjogXCJTZXJ2aWNlIENoYXJnZXNcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbkRvY3VtZW50Q2hhcmdlc1wiLCBoZWFkZXI6IFwiRG9jdW1lbnRhdGlvbiBDaGFyZ2VzXCIgfSxcclxuICAgIHsga2V5OiBcImRhaWx5X3BheW1lbnRfYW1vdW50XCIsIGhlYWRlcjogXCJEYWlseSBJbnN0YWxsbWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuQW1vdW50VmFsdWVcIiwgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBheWFibGVMb2FuRGF5c1wiLCBoZWFkZXI6IFwiTG9hbiBBZ2UgKGluIERheXMpXCIgfSxcclxuICAgIHsga2V5OiBcInRoaXJkX2xhc3RfcGF5bWVudF9kYXRlXCIsIGhlYWRlcjogXCJQYXltZW50IERhdGUgLSAzbmQgUHJldmlvdXNcIiB9LFxyXG4gICAgeyBrZXk6IFwidGhpcmRfbGFzdF9wYXltZW50X2Ftb3VudFwiLCBoZWFkZXI6IFwiUGFpZCBBbW91bnQgLSAzbmQgUHJldmlvdXMgIFwiIH0sXHJcbiAgICB7IGtleTogXCJzZWNvbmRfbGFzdF9wYXltZW50X2RhdGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgRGF0ZSAtIDJuZCBQcmV2aW91c1wiIH0sXHJcbiAgICB7IGtleTogXCJzZWNvbmRfbGFzdF9wYXltZW50X2Ftb3VudFwiLCBoZWFkZXI6IFwiICBQYWlkIEFtb3VudCAtIDJuZCBQcmV2aW91c1wiIH0sXHJcbiAgICB7IGtleTogXCJsYXN0X3BheW1lbnRfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBEYXRlIC0gTGF0ZXN0XCIgfSxcclxuICAgIHsga2V5OiBcImxhc3RfcGF5bWVudF9hbW91bnRcIiwgaGVhZGVyOiBcIiBQYXltZW50IEFtb3VudCDigJMgTGF0ZXN0XCIgfSxcclxuICAgIHsga2V5OiBcImR1ZWRheXNDb3VudFwiLCBoZWFkZXI6IFwiRGF5cyBTaW5jZSBMYXN0IFBheW1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5YWJsZUFtb3VudFwiLCBoZWFkZXI6IFwiTG9hbiBQYXlhYmxlXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsTG9hbkFtb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgUGFpZFwiIH0sXHJcbiAgICB7IGtleTogXCJsYXRlX2ZlZVwiLCBoZWFkZXI6IFwiTGF0ZSBGZWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVtYWluaW5nQmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuQmFsYW5jZVwiLCBoZWFkZXI6IFwiT3V0U3RhbmRpbmdcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG5cclxuICBdO1xyXG5cclxuICBjb25zdCBTdGF0Q2FyZCA9ICh7IGljb246IEljb24sIGxhYmVsLCB2YWx1ZSwgY29sb3IgfSkgPT4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBib3JkZXIgcC02XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBtYi0xXCI+e2xhYmVsfTwvcD5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+e3ZhbHVlfTwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLWxnICR7Y29sb3J9YH0+XHJcbiAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LXNjcmVlblwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIiBteC1hdXRvXCI+XHJcbiAgICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctNyBoLTcgdGV4dC12aW9sZXQtNjAwXCIgLz4gQ3VzdG9tZXIgT3V0U3RhbmRpbmcgTG9hbiBSZXBvcnRcclxuICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG1sLTEwXCI+XHJcbiAgICAgICAgICAgIE92ZXJ2aWV3IG9mIGN1c3RvbWVyIG91dHN0YW5kaW5nIGxvYW5zLCBwYXltZW50cyAmIHJlZmVycmFsIGRldGFpbHNcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGgtOTZcIj5cclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPD5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNlwiPlxyXG4gICAgICAgICAgICAgIDxDb2xsYXBzZVxyXG4gICAgICAgICAgICAgICAgaXRlbXM9e1tcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU2hvcnRjdXQgS2V5c1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNSBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL290aGVyLXNlcnZpY2UtbWVudS9sb2FuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3Zlcjp0ZXh0LXZpb2xldC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhTW9uZXlCaWxsIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTUwMFwiIHNpemU9ezMwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEFkZCBMb2FuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL2N1c3RvbWVyLWxvYW4tcmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3Zlcjp0ZXh0LXZpb2xldC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPERvbGxhck91dGxpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MzB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBMb2FuIFN1bW1hcnkgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9sb2FuLWNvbXBsZXRpb24tcmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3Zlcjp0ZXh0LXZpb2xldC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0T3V0bGluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXszMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIExvYW4gQ29tcGxldGlvbiBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0QWN0aXZlS2V5PXtbXCIxXCJdfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsvKiBTdW1tYXJ5IENhcmRzICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTYgbWItOFwiPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtGaWxlVGV4dH1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUb3RhbCBMb2Fuc1wiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1tYXJ5U3RhdHMudG90YWxMb2Fuc31cclxuICAgICAgICAgICAgICAgICAgY29sb3I9XCJiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJyZWFrLXdvcmRzXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHN1bW1hcnlTdGF0cy50b3RhbExvYW5zIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtJbmRpYW5SdXBlZX1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUb3RhbCBMb2FuIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHtzdW1tYXJ5U3RhdHMudG90YWxBbW91bnR9YH1cclxuICAgICAgICAgICAgICAgICAgY29sb3I9XCJiZy1wdXJwbGUtNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJyZWFrLXdvcmRzXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHN1bW1hcnlTdGF0cy50b3RhbEFtb3VudCB8fCAwKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8U3RhdENhcmRcclxuICAgICAgICAgICAgICAgICAgaWNvbj17VHJlbmRpbmdVcH1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUb3RhbCBQYXlhYmxlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Digrkke3N1bW1hcnlTdGF0cy50b3RhbFBheWFibGV9YH1cclxuICAgICAgICAgICAgICAgICAgY29sb3I9XCJiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJyZWFrLXdvcmRzXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHN1bW1hcnlTdGF0cy50b3RhbFBheWFibGUgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPFN0YXRDYXJkXHJcbiAgICAgICAgICAgICAgICAgIGljb249e1RyZW5kaW5nVXB9XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVG90YWwgUGFpZFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHtzdW1tYXJ5U3RhdHMudG90YWxQYWlkfWB9XHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yPVwiYmctZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJyZWFrLXdvcmRzXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHN1bW1hcnlTdGF0cy50b3RhbFBhaWQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgIDxTdGF0Q2FyZFxyXG4gICAgICBpY29uPXtDYWxlbmRhcn1cclxuICAgICAgbGFiZWw9XCJUb3RhbCBCYWxhbmNlXCJcclxuICAgICAgdmFsdWU9e2Digrkke3N1bW1hcnlTdGF0cy50b3RhbEJhbGFuY2V9YH1cclxuICAgICAgY29sb3I9XCJiZy1vcmFuZ2UtNjAwXCJcclxuICAgIC8+XHJcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJyZWFrLXdvcmRzXCI+XHJcbiAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHN1bW1hcnlTdGF0cy50b3RhbEJhbGFuY2UgfHwgMCl9XHJcbiAgICA8L3NwYW4+XHJcbiAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgey8qIEZJTFRFUlMgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIHAtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPiBGaWx0ZXIgT3B0aW9uc1xyXG4gICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgey8qIExvYW4gRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPkxvYW4gSUQgJiBBbW91bnQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGxvYW5cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExvYW5JZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRMb2FuSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBMb2FuczwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7dW5pcXVlTG9hbkNvbWJvcy5tYXAoKGxvYW4pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bG9hbi5pZH0gdmFsdWU9e2xvYW4uaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bG9hbi5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPkN1c3RvbWVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBjdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkQ3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBDdXN0b21lcnM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge3VuaXF1ZUN1c3RvbWVycy5tYXAoKGN1c3QpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Y3VzdC5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3QuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0LmN1c3RpZH0gfCB7Y3VzdC5uYW1lfSB8IHtjdXN0LnBob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBSZWZlcnJlZCBCeSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+UmVmZXJyZWQgQnk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IHJlZmVycmVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRSZWZlcnJlZEJ5fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTZWxlY3RlZFJlZmVycmVkQnl9XHJcbiAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBSZWZlcnJlZCBCeTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7dW5pcXVlUmVmZXJyZWRCeS5tYXAoKHJlZikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWZ9IHZhbHVlPXtyZWZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVmfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBORVc6IERhdGUgUmFuZ2UgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPlN0YXJ0IERhdGUgUmFuZ2U8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8UmFuZ2VQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGF0ZVJhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXREYXRlUmFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBmb3JtYXQ9XCJERC9NTS9ZWVlZXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUQUJMRSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1zY3JlZW5cIj5cclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtsb2FuUmVwb3J0Q29sdW1uc31cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkTG9hblJlcG9ydH1cclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIExvYW5zXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgTG9hbiBBbW91bnRcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBQYXlhYmxlXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgUGFpZFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIE91dHN0YW5kaW5nXCIsXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgc3VtbWFyeVN0YXRzLnRvdGFsTG9hbnMudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSxcclxuICAgICAgICAgICAgICAgICAgYOKCuSAke3N1bW1hcnlTdGF0cy50b3RhbEFtb3VudC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICAgICAgICAgIGDigrkgJHtzdW1tYXJ5U3RhdHMudG90YWxQYXlhYmxlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgICAgYOKCuSAke3N1bW1hcnlTdGF0cy50b3RhbFBhaWQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICAgICAgICAgICAgICBg4oK5ICR7c3VtbWFyeVN0YXRzLnRvdGFsQmFsYW5jZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiT3V0U3RhbmRpbmcgQ3VzdG9tZXIgTG9hbiBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIk91dFN0YW5kaW5nIEN1c3RvbWVyIExvYW4gUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8Lz5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEdWVMb2FuUmVwb3J0OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9EdWVMb2FuUmVwb3J0LmpzeCJ9