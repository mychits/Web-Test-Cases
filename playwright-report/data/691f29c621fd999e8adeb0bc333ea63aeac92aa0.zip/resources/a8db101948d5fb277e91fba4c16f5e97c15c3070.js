import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SoftTransferCustomer.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import {
  Button,
  Select,
  Input,
  Drawer,
  Space,
  Form,
  Row,
  Col,
  Spin
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { LoadingOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const SoftTransferCustomer = () => {
  _s();
  const [loader, setLoader] = useState(false);
  const [allGroups, setAllGroups] = useState([]);
  const [transferData, setTransferData] = useState([]);
  const [isDataTableLoading, setIsDataTableLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [amountPaid, setAmountPaid] = useState(0);
  const [destinationGroup, setDestinationGroup] = useState("");
  const [destinationCustomer, setDestinationCustomer] = useState("");
  const [destinationTicket, setDestinationTicket] = useState("");
  const [sourceGroup, setSourceGroup] = useState("");
  const [sourceTicket, setSourceTicket] = useState("");
  const [sourceCustomer, setSourceCustomer] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [destinationCustomers, setDestinationCustomers] = useState([]);
  const [sourceCustomers, setSourceCustomers] = useState([]);
  const [sourceEnrollment, setSourceEnrollment] = useState([]);
  const [destinationEnrollment, setDestinationEnrollment] = useState([]);
  const getGroupNameById = (groupId) => {
    const group = allGroups.find((g) => g._id === groupId);
    return group?.group_name || "Unknown Group";
  };
  const fetchTransfers = async () => {
    try {
      setIsDataTableLoading(true);
      const res = await api.get("/enroll/transfer/get-all/Soft");
      console.log(res.data, "response data");
      const formattedData = (res.data || []).map((transfer, index) => {
        const fromGroupName = transfer?.fromGroup?.group_name || transfer?.fromGroup;
        const toGroupName = transfer?.toGroup?.group_name || transfer?.toGroup;
        const fromUser = transfer?.fromUser || {};
        const toUser = transfer?.toUser || {};
        return {
          _id: transfer._id,
          id: index + 1,
          transfer_id: `TRAN-${index + 1}`,
          from_group: fromGroupName,
          to_group: toGroupName,
          from_customer: fromUser.full_name || "-",
          from_phone: fromUser.phone_number || "-",
          from_ticket: transfer?.fromTicket || "-",
          to_customer: toUser.full_name || "-",
          to_phone: toUser.phone_number || "-",
          to_ticket: transfer?.toTicket || "-",
          transfer_amount: transfer?.transferAmount ?? 0,
          transfer_type: transfer?.transferType || "-",
          date: transfer?.createdAt?.split("T")[0] || "-"
        };
      });
      setTransferData(formattedData);
    } catch (err) {
      console.error("Failed to fetch transfers", err);
    } finally {
      setIsDataTableLoading(false);
    }
  };
  const handleAddTransferClick = async () => {
    try {
      setLoader(true);
      const response = await api.get("/group/get-all-group-admin");
      setAllGroups(response.data);
      setShowModal(true);
    } catch (err) {
      setAllGroups([]);
      console.error("Error loading groups", err);
      alert("Could not load group data.");
    } finally {
      setLoader(false);
    }
  };
  const handleSourceCustomers = async () => {
    if (!sourceGroup) return;
    try {
      const response = await api.get(
        `/enroll/get-group-all-enroll/${sourceGroup}`
      );
      setSourceCustomers(response.data);
    } catch (error) {
      setSourceCustomers([]);
      console.log("Failed to get Source Customers", error);
    }
  };
  const handleDestinationCustomers = async () => {
    if (!destinationGroup) return;
    try {
      const response = await api.get(
        `/enroll/get-group-all-enroll/${destinationGroup}`
      );
      setDestinationCustomers(response.data);
    } catch (error) {
      setDestinationCustomers([]);
      console.log("Failed to get Destination Customers", error);
    }
  };
  useEffect(() => {
    if (sourceGroup) {
      handleSourceCustomers();
    }
  }, [sourceGroup]);
  useEffect(() => {
    if (destinationGroup) {
      handleDestinationCustomers();
    }
  }, [destinationGroup]);
  useEffect(() => {
    fetchTransfers();
  }, []);
  const handleChange = (key, value) => {
    switch (key) {
      case "sourceGroup":
        setSourceGroup(value);
        setSourceCustomer("");
        setSourceTicket("");
        setAmountPaid(0);
        break;
      case "sourceCustomer":
        const enrollFromSplit = value.split("-");
        const enrollFromId = Array.isArray(enrollFromSplit) ? enrollFromSplit[0] : [];
        const [userId, ticket] = enrollFromSplit.split("|");
        setSourceCustomer(userId);
        setSourceTicket(ticket);
        setSourceEnrollment(enrollFromId);
        setAmountPaid(0);
        break;
      case "destinationGroup":
        setDestinationGroup(value);
        setDestinationCustomer("");
        setDestinationTicket("");
        break;
      case "destinationCustomer":
        const enrollToSplit = value.split("-");
        const enrollToId = Array.isArray(enrollToSplit) ? enrollToSplit[0] : [];
        const [toUserId, toTicket] = enrollToSplit.split("|");
        setDestinationCustomer(toUserId);
        setDestinationTicket(toTicket);
        setDestinationEnrollment(enrollToId);
        break;
      case "transfer_amount":
        if (value === "" || /^\d*\.?\d*$/.test(value)) {
          setTransferAmount(value);
        }
        break;
      default:
        break;
    }
  };
  const fetchAmountPaid = async () => {
    if (!sourceGroup || !sourceCustomer || !sourceTicket) {
      alert("Please select Group, Enrolled Customer, and Ticket first.");
      return;
    }
    try {
      const res = await api.get("/enroll/get-amount-paid", {
        params: {
          group_id: sourceGroup,
          user_id: sourceCustomer,
          ticket: sourceTicket
        }
      });
      setAmountPaid(res.data.amountPaid || 0);
    } catch (error) {
      setAmountPaid(0);
      console.error("Failed to fetch amount paid", error);
      alert("Could not fetch amount paid.");
    }
  };
  const handleTransfer = async () => {
    if (!sourceGroup || !sourceCustomer || !sourceTicket || !destinationGroup || !destinationCustomer || !destinationTicket || !transferAmount || parseFloat(transferAmount) <= 0) {
      alert("Please fill all fields and enter a valid transfer amount.");
      return;
    }
    if (parseFloat(transferAmount) > amountPaid) {
      alert("Transfer amount cannot exceed amount paid.");
      return;
    }
    try {
      const payload = {
        fromGroup: sourceGroup,
        fromUserId: sourceCustomer,
        fromTicket: Number(sourceTicket),
        amountPaid,
        transferAmount: parseFloat(transferAmount),
        toGroup: destinationGroup,
        toUser: destinationCustomer,
        toTicket: Number(destinationTicket),
        transferType: "Soft",
        fromEnrollId: sourceEnrollment,
        toEnrollId: destinationEnrollment
      };
      const res = await api.post("/enroll/transfer-customer", payload);
      if (res.status === 200 || res.status === 201) {
        const transfer = res.data;
        const formatted = {
          _id: transfer._id,
          id: transferData.length + 1,
          transfer_id: `TRAN-${transferData.length + 1}`,
          from_group: getGroupNameById(sourceGroup),
          to_group: getGroupNameById(destinationGroup),
          from_customer: sourceCustomers.find((c) => c.user_id?._id === sourceCustomer)?.user_id?.full_name || "-",
          from_phone: sourceCustomers.find((c) => c.user_id?._id === sourceCustomer)?.user_id?.phone_number || "-",
          from_ticket: sourceTicket,
          to_customer: destinationCustomers.find(
            (c) => c.user_id?._id === destinationCustomer
          )?.user_id?.full_name || "-",
          to_phone: destinationCustomers.find(
            (c) => c.user_id?._id === destinationCustomer
          )?.user_id?.phone_number || "-",
          to_ticket: destinationTicket,
          transfer_amount: parseFloat(transferAmount),
          amount_paid: amountPaid,
          transfer_type: "Soft",
          date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
        };
        setTransferData((prev) => [...prev, formatted]);
        alert("Transfer successful!");
        resetForm();
        setShowModal(false);
      } else {
        alert("Transfer failed.");
      }
    } catch (error) {
      console.error("Transfer error:", error);
      alert("Transfer failed. Check console for details.");
    }
  };
  const resetForm = () => {
    setSourceGroup("");
    setSourceCustomer("");
    setSourceTicket("");
    setDestinationGroup("");
    setDestinationCustomer("");
    setDestinationTicket("");
    setTransferAmount("");
    setAmountPaid(0);
  };
  const columns = [
    { key: "id", header: "Sl No" },
    { key: "transfer_id", header: "Transfer ID" },
    { key: "from_group", header: "From Group" },
    { key: "from_customer", header: "From Customer" },
    { key: "from_ticket", header: "From Ticket" },
    { key: "to_group", header: "To Group" },
    { key: "to_customer", header: "To Customer" },
    { key: "to_ticket", header: "To Ticket" },
    { key: "transfer_amount", header: "Transfer Amount" },
    { key: "transfer_type", header: "Transfer Type" },
    { key: "date", header: "Transfer Date" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
          lineNumber: 307,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
        lineNumber: 311,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Soft Transfer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 314,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: handleAddTransferClick,
              className: "bg-violet-950 text-white px-5 py-5 rounded shadow-md hover:bg-violet-800 transition duration-200 text-lg",
              disabled: loader,
              children: loader ? /* @__PURE__ */ jsxDEV(Spin, { indicator: /* @__PURE__ */ jsxDEV(LoadingOutlined, { spin: true }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                lineNumber: 321,
                columnNumber: 32
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                lineNumber: 321,
                columnNumber: 15
              }, this) : "+ Add Transfer"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
              lineNumber: 315,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
          lineNumber: 313,
          columnNumber: 11
        }, this),
        transferData?.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(transferData, searchText),
            columns,
            exportedPdfName: "Soft Amount Transfer Customer",
            exportedFileName: "Soft Amount Transfer Customer.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 328,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading: isDataTableLoading,
            failure: transferData?.length === 0,
            data: "Transfers"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 335,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
        lineNumber: 312,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
      lineNumber: 306,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: "Add Soft Transfer",
        width: 840,
        onClose: () => setShowModal(false),
        open: showModal,
        styles: {
          body: { paddingBottom: 80, paddingTop: 16, fontSize: "16px" },
          header: { fontSize: "18px", fontWeight: "600" }
        },
        extra: /* @__PURE__ */ jsxDEV(Space, { children: [
          /* @__PURE__ */ jsxDEV(Button, { size: "large", onClick: () => setShowModal(false), children: "Cancel" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 355,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "large", type: "primary", onClick: handleTransfer, children: "Submit" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 358,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
          lineNumber: 354,
          columnNumber: 9
        }, this),
        children: /* @__PURE__ */ jsxDEV(Form, { layout: "vertical", size: "large", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 24], className: "px-2", children: [
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "From Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                lineNumber: 368,
                columnNumber: 24
              }, this),
              children: /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  placeholder: "Select Group",
                  onChange: (value) => handleChange("sourceGroup", value),
                  value: sourceGroup || void 0,
                  showSearch: true,
                  optionFilterProp: "children",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  style: { fontSize: "16px", height: "52px" },
                  children: allGroups.filter((g) => g.group_name).map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                      lineNumber: 385,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                  lineNumber: 370,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
              lineNumber: 367,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 366,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "From Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                lineNumber: 395,
                columnNumber: 24
              }, this),
              children: /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  placeholder: "Select Customer",
                  onChange: (value) => handleChange("sourceCustomer", value),
                  value: sourceCustomer && sourceTicket ? `${sourceCustomer}|${sourceTicket}` : void 0,
                  showSearch: true,
                  optionFilterProp: "children",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  style: { fontSize: "16px", height: "52px" },
                  children: sourceCustomers.filter((e) => e.user_id?._id && e.tickets).map(
                    (e) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: `${e.user_id._id}|${e.tickets}`,
                        children: `${e.user_id.full_name} | ${e.user_id.phone_number} | Ticket: ${e.tickets}`
                      },
                      e._id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                        lineNumber: 416,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                  lineNumber: 397,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
              lineNumber: 394,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 393,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: fetchAmountPaid,
              size: "large",
              type: "primary",
              style: {
                width: "100%",
                height: "52px",
                fontSize: "16px",
                fontWeight: "500",
                backgroundColor: "#1e40af"
              },
              children: "Check Total Amount Paid"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
              lineNumber: 428,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 427,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Amount Paid" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                lineNumber: 446,
                columnNumber: 24
              }, this),
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  disabled: true,
                  size: "large",
                  value: amountPaid,
                  style: {
                    fontSize: "16px",
                    height: "52px",
                    fontWeight: "500"
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                  lineNumber: 448,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
              lineNumber: 445,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 444,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Transfer Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                lineNumber: 463,
                columnNumber: 24
              }, this),
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  size: "large",
                  placeholder: "Enter Amount to Transfer",
                  value: transferAmount,
                  onChange: (e) => handleChange("transfer_amount", e.target.value),
                  style: { fontSize: "16px", height: "52px" }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                  lineNumber: 465,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
              lineNumber: 462,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 461,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(Form.Item, { label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "To Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 478,
            columnNumber: 33
          }, this), children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              size: "large",
              placeholder: "Select Destination Group",
              onChange: (value) => handleChange("destinationGroup", value),
              value: destinationGroup || void 0,
              showSearch: true,
              optionFilterProp: "children",
              filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
              style: { fontSize: "16px", height: "52px" },
              children: allGroups.filter((g) => g.group_name).map(
                (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                  lineNumber: 494,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
              lineNumber: 479,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 478,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 477,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "To Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                lineNumber: 504,
                columnNumber: 24
              }, this),
              children: /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  placeholder: "Select Destination Customer",
                  onChange: (value) => handleChange("destinationCustomer", value),
                  value: destinationCustomer && destinationTicket ? `${destinationCustomer}|${destinationTicket}` : void 0,
                  showSearch: true,
                  optionFilterProp: "children",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  style: { fontSize: "16px", height: "52px" },
                  children: destinationCustomers.filter((e) => e.user_id?._id && e.tickets).map(
                    (e) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: `${e.user_id._id}|${e.tickets}`,
                        children: `${e.user_id.full_name} | ${e.user_id.phone_number} | Ticket: ${e.tickets}`
                      },
                      e._id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                        lineNumber: 527,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
                  lineNumber: 506,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
              lineNumber: 503,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
            lineNumber: 502,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
          lineNumber: 365,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
          lineNumber: 364,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
        lineNumber: 344,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx",
    lineNumber: 305,
    columnNumber: 5
  }, this);
};
_s(SoftTransferCustomer, "pHjs5hHoa0hE6GdJcyw8fyrKT+Q=");
_c = SoftTransferCustomer;
export default SoftTransferCustomer;
var _c;
$RefreshReg$(_c, "SoftTransferCustomer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SoftTransferCustomer.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1RJLG1CQUVJLGNBRko7MkJBaFRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUNFQTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyx1QkFBdUI7QUFFaEMsTUFBTUMsdUJBQXVCQSxNQUFNO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlWLFNBQVMsS0FBSztBQUMxQyxRQUFNLENBQUNXLFdBQVdDLFlBQVksSUFBSVosU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2EsY0FBY0MsZUFBZSxJQUFJZCxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDZSxvQkFBb0JDLHFCQUFxQixJQUFJaEIsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQ2lCLFlBQVlDLGFBQWEsSUFBSWxCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNtQixXQUFXQyxZQUFZLElBQUlwQixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDcUIsWUFBWUMsYUFBYSxJQUFJdEIsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ3VCLGtCQUFrQkMsbUJBQW1CLElBQUl4QixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDeUIscUJBQXFCQyxzQkFBc0IsSUFBSTFCLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUMyQixtQkFBbUJDLG9CQUFvQixJQUFJNUIsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQzZCLGFBQWFDLGNBQWMsSUFBSTlCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUMrQixjQUFjQyxlQUFlLElBQUloQyxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDaUMsZ0JBQWdCQyxpQkFBaUIsSUFBSWxDLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNtQyxnQkFBZ0JDLGlCQUFpQixJQUFJcEMsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3FDLHNCQUFzQkMsdUJBQXVCLElBQUl0QyxTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDdUMsaUJBQWlCQyxrQkFBa0IsSUFBSXhDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUN5QyxrQkFBa0JDLG1CQUFtQixJQUFJMUMsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQzJDLHVCQUF1QkMsd0JBQXdCLElBQUk1QyxTQUFTLEVBQUU7QUFFckUsUUFBTTZDLG1CQUFtQkEsQ0FBQ0MsWUFBWTtBQUNwQyxVQUFNQyxRQUFRcEMsVUFBVXFDLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRUMsUUFBUUosT0FBTztBQUNyRCxXQUFPQyxPQUFPSSxjQUFjO0FBQUEsRUFDOUI7QUFFQSxRQUFNQyxpQkFBaUIsWUFBWTtBQUNqQyxRQUFJO0FBQ0ZwQyw0QkFBc0IsSUFBSTtBQUMxQixZQUFNcUMsTUFBTSxNQUFNcEQsSUFBSXFELElBQUksK0JBQStCO0FBQ3pEQyxjQUFRQyxJQUFJSCxJQUFJSSxNQUFNLGVBQWU7QUFDckMsWUFBTUMsaUJBQWlCTCxJQUFJSSxRQUFRLElBQUlFLElBQUksQ0FBQ0MsVUFBVUMsVUFBVTtBQUM5RCxjQUFNQyxnQkFDSkYsVUFBVUcsV0FBV1osY0FBY1MsVUFBVUc7QUFDL0MsY0FBTUMsY0FBY0osVUFBVUssU0FBU2QsY0FBY1MsVUFBVUs7QUFDL0QsY0FBTUMsV0FBV04sVUFBVU0sWUFBWSxDQUFDO0FBQ3hDLGNBQU1DLFNBQVNQLFVBQVVPLFVBQVUsQ0FBQztBQUVwQyxlQUFPO0FBQUEsVUFDTGpCLEtBQUtVLFNBQVNWO0FBQUFBLFVBQ2RrQixJQUFJUCxRQUFRO0FBQUEsVUFDWlEsYUFBYSxRQUFRUixRQUFRLENBQUM7QUFBQSxVQUM5QlMsWUFBWVI7QUFBQUEsVUFDWlMsVUFBVVA7QUFBQUEsVUFDVlEsZUFBZU4sU0FBU08sYUFBYTtBQUFBLFVBQ3JDQyxZQUFZUixTQUFTUyxnQkFBZ0I7QUFBQSxVQUNyQ0MsYUFBYWhCLFVBQVVpQixjQUFjO0FBQUEsVUFDckNDLGFBQWFYLE9BQU9NLGFBQWE7QUFBQSxVQUNqQ00sVUFBVVosT0FBT1EsZ0JBQWdCO0FBQUEsVUFDakNLLFdBQVdwQixVQUFVcUIsWUFBWTtBQUFBLFVBQ2pDQyxpQkFBaUJ0QixVQUFVekIsa0JBQWtCO0FBQUEsVUFFN0NnRCxlQUFldkIsVUFBVXdCLGdCQUFnQjtBQUFBLFVBQ3pDQyxNQUFNekIsVUFBVTBCLFdBQVdDLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLFFBQzlDO0FBQUEsTUFDRixDQUFDO0FBQ0R6RSxzQkFBZ0I0QyxhQUFhO0FBQUEsSUFDL0IsU0FBUzhCLEtBQUs7QUFDWmpDLGNBQVFrQyxNQUFNLDZCQUE2QkQsR0FBRztBQUFBLElBQ2hELFVBQUM7QUFDQ3hFLDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUEsUUFBTTBFLHlCQUF5QixZQUFZO0FBQ3pDLFFBQUk7QUFDRmhGLGdCQUFVLElBQUk7QUFDZCxZQUFNaUYsV0FBVyxNQUFNMUYsSUFBSXFELElBQUksNEJBQTRCO0FBQzNEMUMsbUJBQWErRSxTQUFTbEMsSUFBSTtBQUMxQnJDLG1CQUFhLElBQUk7QUFBQSxJQUNuQixTQUFTb0UsS0FBSztBQUNaNUUsbUJBQWEsRUFBRTtBQUNmMkMsY0FBUWtDLE1BQU0sd0JBQXdCRCxHQUFHO0FBQ3pDSSxZQUFNLDRCQUE0QjtBQUFBLElBQ3BDLFVBQUM7QUFDQ2xGLGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUYsd0JBQXdCLFlBQVk7QUFDeEMsUUFBSSxDQUFDaEUsWUFBYTtBQUNsQixRQUFJO0FBQ0YsWUFBTThELFdBQVcsTUFBTTFGLElBQUlxRDtBQUFBQSxRQUN6QixnQ0FBZ0N6QixXQUFXO0FBQUEsTUFDN0M7QUFDQVcseUJBQW1CbUQsU0FBU2xDLElBQUk7QUFBQSxJQUNsQyxTQUFTZ0MsT0FBTztBQUNkakQseUJBQW1CLEVBQUU7QUFDckJlLGNBQVFDLElBQUksa0NBQWtDaUMsS0FBSztBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUVBLFFBQU1LLDZCQUE2QixZQUFZO0FBQzdDLFFBQUksQ0FBQ3ZFLGlCQUFrQjtBQUN2QixRQUFJO0FBQ0YsWUFBTW9FLFdBQVcsTUFBTTFGLElBQUlxRDtBQUFBQSxRQUN6QixnQ0FBZ0MvQixnQkFBZ0I7QUFBQSxNQUNsRDtBQUNBZSw4QkFBd0JxRCxTQUFTbEMsSUFBSTtBQUFBLElBQ3ZDLFNBQVNnQyxPQUFPO0FBQ2RuRCw4QkFBd0IsRUFBRTtBQUMxQmlCLGNBQVFDLElBQUksdUNBQXVDaUMsS0FBSztBQUFBLElBQzFEO0FBQUEsRUFDRjtBQUVBMUYsWUFBVSxNQUFNO0FBQ2QsUUFBSThCLGFBQWE7QUFDZmdFLDRCQUFzQjtBQUFBLElBQ3hCO0FBQUEsRUFDRixHQUFHLENBQUNoRSxXQUFXLENBQUM7QUFFaEI5QixZQUFVLE1BQU07QUFDZCxRQUFJd0Isa0JBQWtCO0FBQ3BCdUUsaUNBQTJCO0FBQUEsSUFDN0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ3ZFLGdCQUFnQixDQUFDO0FBRXJCeEIsWUFBVSxNQUFNO0FBQ2RxRCxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMLFFBQU0yQyxlQUFlQSxDQUFDQyxLQUFLQyxVQUFVO0FBQ25DLFlBQVFELEtBQUc7QUFBQSxNQUNULEtBQUs7QUFDSGxFLHVCQUFlbUUsS0FBSztBQUNwQi9ELDBCQUFrQixFQUFFO0FBQ3BCRix3QkFBZ0IsRUFBRTtBQUNsQlYsc0JBQWMsQ0FBQztBQUNmO0FBQUEsTUFDRixLQUFLO0FBQ0gsY0FBTTRFLGtCQUFpQkQsTUFBTVYsTUFBTSxHQUFHO0FBQ3RDLGNBQU1ZLGVBQWNDLE1BQU1DLFFBQVNILGVBQWUsSUFBSUEsZ0JBQWdCLENBQUMsSUFBSTtBQUMzRSxjQUFNLENBQUNJLFFBQVFDLE1BQU0sSUFBSUwsZ0JBQWdCWCxNQUFNLEdBQUc7QUFDbERyRCwwQkFBa0JvRSxNQUFNO0FBQ3hCdEUsd0JBQWdCdUUsTUFBTTtBQUN0QjdELDRCQUFvQnlELFlBQVk7QUFDaEM3RSxzQkFBYyxDQUFDO0FBQ2Y7QUFBQSxNQUNGLEtBQUs7QUFDSEUsNEJBQW9CeUUsS0FBSztBQUN6QnZFLCtCQUF1QixFQUFFO0FBQ3pCRSw2QkFBcUIsRUFBRTtBQUN2QjtBQUFBLE1BQ0YsS0FBSztBQUNILGNBQU00RSxnQkFBZ0JQLE1BQU1WLE1BQU0sR0FBRztBQUNyQyxjQUFNa0IsYUFBYUwsTUFBTUMsUUFBUUcsYUFBYSxJQUFJQSxjQUFjLENBQUMsSUFBSTtBQUNyRSxjQUFNLENBQUNFLFVBQVV6QixRQUFRLElBQUl1QixjQUFjakIsTUFBTSxHQUFHO0FBQ3BEN0QsK0JBQXVCZ0YsUUFBUTtBQUMvQjlFLDZCQUFxQnFELFFBQVE7QUFDN0JyQyxpQ0FBeUI2RCxVQUFVO0FBQ25DO0FBQUEsTUFDRixLQUFLO0FBQ0gsWUFBSVIsVUFBVSxNQUFNLGNBQWNVLEtBQUtWLEtBQUssR0FBRztBQUM3QzdELDRCQUFrQjZELEtBQUs7QUFBQSxRQUN6QjtBQUNBO0FBQUEsTUFDRjtBQUNFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFQSxRQUFNVyxrQkFBa0IsWUFBWTtBQUNsQyxRQUFJLENBQUMvRSxlQUFlLENBQUNJLGtCQUFrQixDQUFDRixjQUFjO0FBQ3BENkQsWUFBTSwyREFBMkQ7QUFDakU7QUFBQSxJQUNGO0FBQ0EsUUFBSTtBQUNGLFlBQU12QyxNQUFNLE1BQU1wRCxJQUFJcUQsSUFBSSwyQkFBMkI7QUFBQSxRQUNuRHVELFFBQVE7QUFBQSxVQUNOQyxVQUFVakY7QUFBQUEsVUFDVmtGLFNBQVM5RTtBQUFBQSxVQUNUc0UsUUFBUXhFO0FBQUFBLFFBQ1Y7QUFBQSxNQUNGLENBQUM7QUFDRFQsb0JBQWMrQixJQUFJSSxLQUFLcEMsY0FBYyxDQUFDO0FBQUEsSUFDeEMsU0FBU29FLE9BQU87QUFDZG5FLG9CQUFjLENBQUM7QUFDZmlDLGNBQVFrQyxNQUFNLCtCQUErQkEsS0FBSztBQUNsREcsWUFBTSw4QkFBOEI7QUFBQSxJQUN0QztBQUFBLEVBQ0Y7QUFFQSxRQUFNb0IsaUJBQWlCLFlBQVk7QUFDakMsUUFDRSxDQUFDbkYsZUFDRCxDQUFDSSxrQkFDRCxDQUFDRixnQkFDRCxDQUFDUixvQkFDRCxDQUFDRSx1QkFDRCxDQUFDRSxxQkFDRCxDQUFDUSxrQkFDRDhFLFdBQVc5RSxjQUFjLEtBQUssR0FDOUI7QUFDQXlELFlBQU0sMkRBQTJEO0FBQ2pFO0FBQUEsSUFDRjtBQUVBLFFBQUlxQixXQUFXOUUsY0FBYyxJQUFJZCxZQUFZO0FBQzNDdUUsWUFBTSw0Q0FBNEM7QUFDbEQ7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGLFlBQU1zQixVQUFVO0FBQUEsUUFDZG5ELFdBQVdsQztBQUFBQSxRQUNYc0YsWUFBWWxGO0FBQUFBLFFBQ1o0QyxZQUFZdUMsT0FBT3JGLFlBQVk7QUFBQSxRQUMvQlY7QUFBQUEsUUFDQWMsZ0JBQWdCOEUsV0FBVzlFLGNBQWM7QUFBQSxRQUN6QzhCLFNBQVMxQztBQUFBQSxRQUNUNEMsUUFBUTFDO0FBQUFBLFFBQ1J3RCxVQUFVbUMsT0FBT3pGLGlCQUFpQjtBQUFBLFFBQ2xDeUQsY0FBYztBQUFBLFFBQ2RpQyxjQUFhNUU7QUFBQUEsUUFDYjZFLFlBQVczRTtBQUFBQSxNQUNiO0FBQ0EsWUFBTVUsTUFBTSxNQUFNcEQsSUFBSXNILEtBQUssNkJBQTZCTCxPQUFPO0FBQy9ELFVBQUk3RCxJQUFJbUUsV0FBVyxPQUFPbkUsSUFBSW1FLFdBQVcsS0FBSztBQUM1QyxjQUFNNUQsV0FBV1AsSUFBSUk7QUFDckIsY0FBTWdFLFlBQVk7QUFBQSxVQUNoQnZFLEtBQUtVLFNBQVNWO0FBQUFBLFVBQ2RrQixJQUFJdkQsYUFBYTZHLFNBQVM7QUFBQSxVQUMxQnJELGFBQWEsUUFBUXhELGFBQWE2RyxTQUFTLENBQUM7QUFBQSxVQUM1Q3BELFlBQVl6QixpQkFBaUJoQixXQUFXO0FBQUEsVUFDeEMwQyxVQUFVMUIsaUJBQWlCdEIsZ0JBQWdCO0FBQUEsVUFDM0NpRCxlQUNFakMsZ0JBQWdCUyxLQUFLLENBQUMyRSxNQUFNQSxFQUFFWixTQUFTN0QsUUFBUWpCLGNBQWMsR0FDekQ4RSxTQUFTdEMsYUFBYTtBQUFBLFVBQzVCQyxZQUNFbkMsZ0JBQWdCUyxLQUFLLENBQUMyRSxNQUFNQSxFQUFFWixTQUFTN0QsUUFBUWpCLGNBQWMsR0FDekQ4RSxTQUFTcEMsZ0JBQWdCO0FBQUEsVUFDL0JDLGFBQWE3QztBQUFBQSxVQUNiK0MsYUFDRXpDLHFCQUFxQlc7QUFBQUEsWUFDbkIsQ0FBQzJFLE1BQU1BLEVBQUVaLFNBQVM3RCxRQUFRekI7QUFBQUEsVUFDNUIsR0FBR3NGLFNBQVN0QyxhQUFhO0FBQUEsVUFDM0JNLFVBQ0UxQyxxQkFBcUJXO0FBQUFBLFlBQ25CLENBQUMyRSxNQUFNQSxFQUFFWixTQUFTN0QsUUFBUXpCO0FBQUFBLFVBQzVCLEdBQUdzRixTQUFTcEMsZ0JBQWdCO0FBQUEsVUFDOUJLLFdBQVdyRDtBQUFBQSxVQUNYdUQsaUJBQWlCK0IsV0FBVzlFLGNBQWM7QUFBQSxVQUMxQ3lGLGFBQWF2RztBQUFBQSxVQUNiOEQsZUFBZTtBQUFBLFVBQ2ZFLE9BQU0sb0JBQUl3QyxLQUFLLEdBQUVDLFlBQVksRUFBRXZDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxRQUM3QztBQUNBekUsd0JBQWdCLENBQUNpSCxTQUFTLENBQUMsR0FBR0EsTUFBTU4sU0FBUyxDQUFDO0FBQzlDN0IsY0FBTSxzQkFBc0I7QUFDNUJvQyxrQkFBVTtBQUNWNUcscUJBQWEsS0FBSztBQUFBLE1BQ3BCLE9BQU87QUFDTHdFLGNBQU0sa0JBQWtCO0FBQUEsTUFDMUI7QUFBQSxJQUNGLFNBQVNILE9BQU87QUFDZGxDLGNBQVFrQyxNQUFNLG1CQUFtQkEsS0FBSztBQUN0Q0csWUFBTSw2Q0FBNkM7QUFBQSxJQUNyRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0MsWUFBWUEsTUFBTTtBQUN0QmxHLG1CQUFlLEVBQUU7QUFDakJJLHNCQUFrQixFQUFFO0FBQ3BCRixvQkFBZ0IsRUFBRTtBQUNsQlIsd0JBQW9CLEVBQUU7QUFDdEJFLDJCQUF1QixFQUFFO0FBQ3pCRSx5QkFBcUIsRUFBRTtBQUN2QlEsc0JBQWtCLEVBQUU7QUFDcEJkLGtCQUFjLENBQUM7QUFBQSxFQUNqQjtBQUVBLFFBQU0yRyxVQUFVO0FBQUEsSUFDZCxFQUFFakMsS0FBSyxNQUFNa0MsUUFBUSxRQUFRO0FBQUEsSUFDN0IsRUFBRWxDLEtBQUssZUFBZWtDLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVsQyxLQUFLLGNBQWNrQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFbEMsS0FBSyxpQkFBaUJrQyxRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUVsQyxLQUFLLGVBQWVrQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFbEMsS0FBSyxZQUFZa0MsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRWxDLEtBQUssZUFBZWtDLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVsQyxLQUFLLGFBQWFrQyxRQUFRLFlBQVk7QUFBQSxJQUN4QyxFQUFFbEMsS0FBSyxtQkFBbUJrQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVsQyxLQUFLLGlCQUFpQmtDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRWxDLEtBQUssUUFBUWtDLFFBQVEsZ0JBQWdCO0FBQUEsRUFBQztBQUcxQyxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCLENBQUNDLE1BQU1qSCxjQUFjaUgsRUFBRUMsT0FBT25DLEtBQUs7QUFBQSxVQUNoRSxZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLDZCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQ3BEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTUDtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUNWLFVBQVVqRjtBQUFBQSxjQUVUQSxtQkFDQyx1QkFBQyxRQUFLLFdBQVcsdUJBQUMsbUJBQWdCLE1BQUksUUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUIsS0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEMsSUFFMUM7QUFBQTtBQUFBLFlBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0NJLGNBQWM2RyxTQUFTLElBQ3RCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNckgsYUFBYVEsY0FBY0ksVUFBVTtBQUFBLFlBQzNDO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBaUI7QUFBQTtBQUFBLFVBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlzRCxJQUd0RDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBV0Y7QUFBQUEsWUFDWCxTQUFTRixjQUFjNkcsV0FBVztBQUFBLFlBQ2xDLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR2tCO0FBQUEsV0ExQnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxTQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0NBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sT0FBTztBQUFBLFFBQ1AsU0FBUyxNQUFNdEcsYUFBYSxLQUFLO0FBQUEsUUFDakMsTUFBTUQ7QUFBQUEsUUFDTixRQUFRO0FBQUEsVUFDTmtILE1BQU0sRUFBRUMsZUFBZSxJQUFJQyxZQUFZLElBQUlDLFVBQVUsT0FBTztBQUFBLFVBQzVETixRQUFRLEVBQUVNLFVBQVUsUUFBUUMsWUFBWSxNQUFNO0FBQUEsUUFDaEQ7QUFBQSxRQUNBLE9BQ0UsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVMsTUFBTXJILGFBQWEsS0FBSyxHQUFHLHNCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLE1BQUssU0FBUSxNQUFLLFdBQVUsU0FBUzRGLGdCQUFnQixzQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFHRixpQ0FBQyxRQUFLLFFBQU8sWUFBVyxNQUFLLFNBQzNCLGlDQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQUFHLFdBQVUsUUFDL0I7QUFBQSxpQ0FBQyxPQUFJLE1BQU0sSUFDVDtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGVBQWMsMEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdDO0FBQUEsY0FFL0M7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLGFBQVk7QUFBQSxrQkFDWixVQUFVLENBQUNmLFVBQVVGLGFBQWEsZUFBZUUsS0FBSztBQUFBLGtCQUN0RCxPQUFPcEUsZUFBZTZHO0FBQUFBLGtCQUN0QjtBQUFBLGtCQUNBLGtCQUFpQjtBQUFBLGtCQUNqQixjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGtCQUU1RCxPQUFPLEVBQUVOLFVBQVUsUUFBUVEsUUFBUSxPQUFPO0FBQUEsa0JBRXpDckksb0JBQ0VzSSxPQUFPLENBQUNoRyxNQUFNQSxFQUFFRSxVQUFVLEVBQzFCUTtBQUFBQSxvQkFBSSxDQUFDWixVQUNKLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNRyxLQUN6Q0gsZ0JBQU1JLGNBRFdKLE1BQU1HLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBbEJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW1CQTtBQUFBO0FBQUEsWUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBdUJBLEtBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFFQSx1QkFBQyxPQUFJLE1BQU0sSUFDVDtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGVBQWMsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJDO0FBQUEsY0FFbEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLGFBQVk7QUFBQSxrQkFDWixVQUFVLENBQUMrQyxVQUFVRixhQUFhLGtCQUFrQkUsS0FBSztBQUFBLGtCQUN6RCxPQUNFaEUsa0JBQWtCRixlQUNkLEdBQUdFLGNBQWMsSUFBSUYsWUFBWSxLQUNqQzJHO0FBQUFBLGtCQUVOO0FBQUEsa0JBQ0Esa0JBQWlCO0FBQUEsa0JBQ2pCLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNDLFlBQVksRUFBRUMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU8sRUFBRU4sVUFBVSxRQUFRUSxRQUFRLE9BQU87QUFBQSxrQkFFekN6RywwQkFDRTBHLE9BQU8sQ0FBQ2QsTUFBTUEsRUFBRXBCLFNBQVM3RCxPQUFPaUYsRUFBRWUsT0FBTyxFQUN6Q3ZGO0FBQUFBLG9CQUFJLENBQUN3RSxNQUNKO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBRUMsT0FBTyxHQUFHQSxFQUFFcEIsUUFBUTdELEdBQUcsSUFBSWlGLEVBQUVlLE9BQU87QUFBQSx3QkFFbkMsYUFBR2YsRUFBRXBCLFFBQVF0QyxTQUFTLE1BQU0wRCxFQUFFcEIsUUFBUXBDLFlBQVksY0FBY3dELEVBQUVlLE9BQU87QUFBQTtBQUFBLHNCQUhyRWYsRUFBRWpGO0FBQUFBLHNCQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBekJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTBCQTtBQUFBO0FBQUEsWUE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBOEJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0NBO0FBQUEsVUFFQSx1QkFBQyxPQUFJLE1BQU0sSUFDVDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUzBEO0FBQUFBLGNBQ1QsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBTztBQUFBLGdCQUNMdUMsT0FBTztBQUFBLGdCQUNQSCxRQUFRO0FBQUEsZ0JBQ1JSLFVBQVU7QUFBQSxnQkFDVkMsWUFBWTtBQUFBLGdCQUNaVyxpQkFBaUI7QUFBQSxjQUNuQjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFFQSx1QkFBQyxPQUFJLE1BQU0sSUFDVDtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGVBQWMsMkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUEsY0FFaEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0M7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsT0FBTy9IO0FBQUFBLGtCQUNQLE9BQU87QUFBQSxvQkFDTG1ILFVBQVU7QUFBQSxvQkFDVlEsUUFBUTtBQUFBLG9CQUNSUCxZQUFZO0FBQUEsa0JBQ2Q7QUFBQTtBQUFBLGdCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFJO0FBQUE7QUFBQSxZQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBRUEsdUJBQUMsT0FBSSxNQUFNLElBQ1Q7QUFBQSxZQUFDLEtBQUs7QUFBQSxZQUFMO0FBQUEsY0FDQyxPQUFPLHVCQUFDLFVBQUssV0FBVSxlQUFjLCtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBLGNBRXBEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxhQUFZO0FBQUEsa0JBQ1osT0FBT3RHO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ2dHLE1BQ1RwQyxhQUFhLG1CQUFtQm9DLEVBQUVDLE9BQU9uQyxLQUFLO0FBQUEsa0JBRWhELE9BQU8sRUFBRXVDLFVBQVUsUUFBUVEsUUFBUSxPQUFPO0FBQUE7QUFBQSxnQkFQNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTzhDO0FBQUE7QUFBQSxZQVZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUVBLHVCQUFDLE9BQUksTUFBTSxJQUNULGlDQUFDLEtBQUssTUFBTCxFQUFVLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGVBQWMsd0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDLEdBQ3REO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxhQUFZO0FBQUEsY0FDWixVQUFVLENBQUMvQyxVQUFVRixhQUFhLG9CQUFvQkUsS0FBSztBQUFBLGNBQzNELE9BQU8xRSxvQkFBb0JtSDtBQUFBQSxjQUMzQjtBQUFBLGNBQ0Esa0JBQWlCO0FBQUEsY0FDakIsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0MsWUFBWSxFQUFFQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxjQUU1RCxPQUFPLEVBQUVOLFVBQVUsUUFBUVEsUUFBUSxPQUFPO0FBQUEsY0FFekNySSxvQkFDRXNJLE9BQU8sQ0FBQ2hHLE1BQU1BLEVBQUVFLFVBQVUsRUFDMUJRO0FBQUFBLGdCQUFJLENBQUNaLFVBQ0osdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1HLEtBQ3pDSCxnQkFBTUksY0FEV0osTUFBTUcsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBLFlBbEJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLFVBRUEsdUJBQUMsT0FBSSxNQUFNLElBQ1Q7QUFBQSxZQUFDLEtBQUs7QUFBQSxZQUFMO0FBQUEsY0FDQyxPQUFPLHVCQUFDLFVBQUssV0FBVSxlQUFjLDJCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGNBRWhEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxhQUFZO0FBQUEsa0JBQ1osVUFBVSxDQUFDK0MsVUFDVEYsYUFBYSx1QkFBdUJFLEtBQUs7QUFBQSxrQkFFM0MsT0FDRXhFLHVCQUF1QkUsb0JBQ25CLEdBQUdGLG1CQUFtQixJQUFJRSxpQkFBaUIsS0FDM0MrRztBQUFBQSxrQkFFTjtBQUFBLGtCQUNBLGtCQUFpQjtBQUFBLGtCQUNqQixjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGtCQUU1RCxPQUFPLEVBQUVOLFVBQVUsUUFBUVEsUUFBUSxPQUFPO0FBQUEsa0JBRXpDM0csK0JBQ0U0RyxPQUFPLENBQUNkLE1BQU1BLEVBQUVwQixTQUFTN0QsT0FBT2lGLEVBQUVlLE9BQU8sRUFDekN2RjtBQUFBQSxvQkFBSSxDQUFDd0UsTUFDSjtBQUFBLHNCQUFDLE9BQU87QUFBQSxzQkFBUDtBQUFBLHdCQUVDLE9BQU8sR0FBR0EsRUFBRXBCLFFBQVE3RCxHQUFHLElBQUlpRixFQUFFZSxPQUFPO0FBQUEsd0JBRW5DLGFBQUdmLEVBQUVwQixRQUFRdEMsU0FBUyxNQUFNMEQsRUFBRXBCLFFBQVFwQyxZQUFZLGNBQWN3RCxFQUFFZSxPQUFPO0FBQUE7QUFBQSxzQkFIckVmLEVBQUVqRjtBQUFBQSxzQkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQTNCTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0E0QkE7QUFBQTtBQUFBLFlBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWdDQSxLQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtDQTtBQUFBLGFBM0tGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0S0EsS0E3S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThLQTtBQUFBO0FBQUEsTUFsTUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbU1BO0FBQUEsT0ExT0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJPQTtBQUVKO0FBQUUxQyxHQXpnQklELHNCQUFvQjtBQUFBOEksS0FBcEI5STtBQTJnQk4sZUFBZUE7QUFBcUIsSUFBQThJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJCdXR0b24iLCJTZWxlY3QiLCJJbnB1dCIsIkRyYXdlciIsIlNwYWNlIiwiRm9ybSIsIlJvdyIsIkNvbCIsIlNwaW4iLCJTaWRlYmFyIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJhcGkiLCJOYXZiYXIiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsImZpbHRlck9wdGlvbiIsIkxvYWRpbmdPdXRsaW5lZCIsIlNvZnRUcmFuc2ZlckN1c3RvbWVyIiwiX3MiLCJsb2FkZXIiLCJzZXRMb2FkZXIiLCJhbGxHcm91cHMiLCJzZXRBbGxHcm91cHMiLCJ0cmFuc2ZlckRhdGEiLCJzZXRUcmFuc2ZlckRhdGEiLCJpc0RhdGFUYWJsZUxvYWRpbmciLCJzZXRJc0RhdGFUYWJsZUxvYWRpbmciLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsImFtb3VudFBhaWQiLCJzZXRBbW91bnRQYWlkIiwiZGVzdGluYXRpb25Hcm91cCIsInNldERlc3RpbmF0aW9uR3JvdXAiLCJkZXN0aW5hdGlvbkN1c3RvbWVyIiwic2V0RGVzdGluYXRpb25DdXN0b21lciIsImRlc3RpbmF0aW9uVGlja2V0Iiwic2V0RGVzdGluYXRpb25UaWNrZXQiLCJzb3VyY2VHcm91cCIsInNldFNvdXJjZUdyb3VwIiwic291cmNlVGlja2V0Iiwic2V0U291cmNlVGlja2V0Iiwic291cmNlQ3VzdG9tZXIiLCJzZXRTb3VyY2VDdXN0b21lciIsInRyYW5zZmVyQW1vdW50Iiwic2V0VHJhbnNmZXJBbW91bnQiLCJkZXN0aW5hdGlvbkN1c3RvbWVycyIsInNldERlc3RpbmF0aW9uQ3VzdG9tZXJzIiwic291cmNlQ3VzdG9tZXJzIiwic2V0U291cmNlQ3VzdG9tZXJzIiwic291cmNlRW5yb2xsbWVudCIsInNldFNvdXJjZUVucm9sbG1lbnQiLCJkZXN0aW5hdGlvbkVucm9sbG1lbnQiLCJzZXREZXN0aW5hdGlvbkVucm9sbG1lbnQiLCJnZXRHcm91cE5hbWVCeUlkIiwiZ3JvdXBJZCIsImdyb3VwIiwiZmluZCIsImciLCJfaWQiLCJncm91cF9uYW1lIiwiZmV0Y2hUcmFuc2ZlcnMiLCJyZXMiLCJnZXQiLCJjb25zb2xlIiwibG9nIiwiZGF0YSIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJ0cmFuc2ZlciIsImluZGV4IiwiZnJvbUdyb3VwTmFtZSIsImZyb21Hcm91cCIsInRvR3JvdXBOYW1lIiwidG9Hcm91cCIsImZyb21Vc2VyIiwidG9Vc2VyIiwiaWQiLCJ0cmFuc2Zlcl9pZCIsImZyb21fZ3JvdXAiLCJ0b19ncm91cCIsImZyb21fY3VzdG9tZXIiLCJmdWxsX25hbWUiLCJmcm9tX3Bob25lIiwicGhvbmVfbnVtYmVyIiwiZnJvbV90aWNrZXQiLCJmcm9tVGlja2V0IiwidG9fY3VzdG9tZXIiLCJ0b19waG9uZSIsInRvX3RpY2tldCIsInRvVGlja2V0IiwidHJhbnNmZXJfYW1vdW50IiwidHJhbnNmZXJfdHlwZSIsInRyYW5zZmVyVHlwZSIsImRhdGUiLCJjcmVhdGVkQXQiLCJzcGxpdCIsImVyciIsImVycm9yIiwiaGFuZGxlQWRkVHJhbnNmZXJDbGljayIsInJlc3BvbnNlIiwiYWxlcnQiLCJoYW5kbGVTb3VyY2VDdXN0b21lcnMiLCJoYW5kbGVEZXN0aW5hdGlvbkN1c3RvbWVycyIsImhhbmRsZUNoYW5nZSIsImtleSIsInZhbHVlIiwiZW5yb2xsRnJvbVNwbGl0IiwiZW5yb2xsRnJvbUlkIiwiQXJyYXkiLCJpc0FycmF5IiwidXNlcklkIiwidGlja2V0IiwiZW5yb2xsVG9TcGxpdCIsImVucm9sbFRvSWQiLCJ0b1VzZXJJZCIsInRlc3QiLCJmZXRjaEFtb3VudFBhaWQiLCJwYXJhbXMiLCJncm91cF9pZCIsInVzZXJfaWQiLCJoYW5kbGVUcmFuc2ZlciIsInBhcnNlRmxvYXQiLCJwYXlsb2FkIiwiZnJvbVVzZXJJZCIsIk51bWJlciIsImZyb21FbnJvbGxJZCIsInRvRW5yb2xsSWQiLCJwb3N0Iiwic3RhdHVzIiwiZm9ybWF0dGVkIiwibGVuZ3RoIiwiYyIsImFtb3VudF9wYWlkIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwicHJldiIsInJlc2V0Rm9ybSIsImNvbHVtbnMiLCJoZWFkZXIiLCJlIiwidGFyZ2V0IiwiYm9keSIsInBhZGRpbmdCb3R0b20iLCJwYWRkaW5nVG9wIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJoZWlnaHQiLCJmaWx0ZXIiLCJ0aWNrZXRzIiwid2lkdGgiLCJiYWNrZ3JvdW5kQ29sb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTb2Z0VHJhbnNmZXJDdXN0b21lci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBCdXR0b24sXHJcbiAgU2VsZWN0LFxyXG4gIElucHV0LFxyXG4gIERyYXdlcixcclxuICBTcGFjZSxcclxuICBGb3JtLFxyXG4gIFJvdyxcclxuICBDb2wsXHJcbiAgU3BpbixcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBMb2FkaW5nT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmNvbnN0IFNvZnRUcmFuc2ZlckN1c3RvbWVyID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtsb2FkZXIsIHNldExvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FsbEdyb3Vwcywgc2V0QWxsR3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdHJhbnNmZXJEYXRhLCBzZXRUcmFuc2ZlckRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0RhdGFUYWJsZUxvYWRpbmcsIHNldElzRGF0YVRhYmxlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYW1vdW50UGFpZCwgc2V0QW1vdW50UGFpZF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbZGVzdGluYXRpb25Hcm91cCwgc2V0RGVzdGluYXRpb25Hcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGVzdGluYXRpb25DdXN0b21lciwgc2V0RGVzdGluYXRpb25DdXN0b21lcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGVzdGluYXRpb25UaWNrZXQsIHNldERlc3RpbmF0aW9uVGlja2V0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzb3VyY2VHcm91cCwgc2V0U291cmNlR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NvdXJjZVRpY2tldCwgc2V0U291cmNlVGlja2V0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzb3VyY2VDdXN0b21lciwgc2V0U291cmNlQ3VzdG9tZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3RyYW5zZmVyQW1vdW50LCBzZXRUcmFuc2ZlckFtb3VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGVzdGluYXRpb25DdXN0b21lcnMsIHNldERlc3RpbmF0aW9uQ3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc291cmNlQ3VzdG9tZXJzLCBzZXRTb3VyY2VDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzb3VyY2VFbnJvbGxtZW50LCBzZXRTb3VyY2VFbnJvbGxtZW50XSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZGVzdGluYXRpb25FbnJvbGxtZW50LCBzZXREZXN0aW5hdGlvbkVucm9sbG1lbnRdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBnZXRHcm91cE5hbWVCeUlkID0gKGdyb3VwSWQpID0+IHtcclxuICAgIGNvbnN0IGdyb3VwID0gYWxsR3JvdXBzLmZpbmQoKGcpID0+IGcuX2lkID09PSBncm91cElkKTtcclxuICAgIHJldHVybiBncm91cD8uZ3JvdXBfbmFtZSB8fCBcIlVua25vd24gR3JvdXBcIjtcclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFRyYW5zZmVycyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzRGF0YVRhYmxlTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9lbnJvbGwvdHJhbnNmZXIvZ2V0LWFsbC9Tb2Z0XCIpO1xyXG4gICAgICBjb25zb2xlLmxvZyhyZXMuZGF0YSwgXCJyZXNwb25zZSBkYXRhXCIpO1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gKHJlcy5kYXRhIHx8IFtdKS5tYXAoKHRyYW5zZmVyLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGZyb21Hcm91cE5hbWUgPVxyXG4gICAgICAgICAgdHJhbnNmZXI/LmZyb21Hcm91cD8uZ3JvdXBfbmFtZSB8fCB0cmFuc2Zlcj8uZnJvbUdyb3VwO1xyXG4gICAgICAgIGNvbnN0IHRvR3JvdXBOYW1lID0gdHJhbnNmZXI/LnRvR3JvdXA/Lmdyb3VwX25hbWUgfHwgdHJhbnNmZXI/LnRvR3JvdXA7XHJcbiAgICAgICAgY29uc3QgZnJvbVVzZXIgPSB0cmFuc2Zlcj8uZnJvbVVzZXIgfHwge307XHJcbiAgICAgICAgY29uc3QgdG9Vc2VyID0gdHJhbnNmZXI/LnRvVXNlciB8fCB7fTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIF9pZDogdHJhbnNmZXIuX2lkLFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgIHRyYW5zZmVyX2lkOiBgVFJBTi0ke2luZGV4ICsgMX1gLFxyXG4gICAgICAgICAgZnJvbV9ncm91cDogZnJvbUdyb3VwTmFtZSxcclxuICAgICAgICAgIHRvX2dyb3VwOiB0b0dyb3VwTmFtZSxcclxuICAgICAgICAgIGZyb21fY3VzdG9tZXI6IGZyb21Vc2VyLmZ1bGxfbmFtZSB8fCBcIi1cIixcclxuICAgICAgICAgIGZyb21fcGhvbmU6IGZyb21Vc2VyLnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgIGZyb21fdGlja2V0OiB0cmFuc2Zlcj8uZnJvbVRpY2tldCB8fCBcIi1cIixcclxuICAgICAgICAgIHRvX2N1c3RvbWVyOiB0b1VzZXIuZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgdG9fcGhvbmU6IHRvVXNlci5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgICB0b190aWNrZXQ6IHRyYW5zZmVyPy50b1RpY2tldCB8fCBcIi1cIixcclxuICAgICAgICAgIHRyYW5zZmVyX2Ftb3VudDogdHJhbnNmZXI/LnRyYW5zZmVyQW1vdW50ID8/IDAsXHJcblxyXG4gICAgICAgICAgdHJhbnNmZXJfdHlwZTogdHJhbnNmZXI/LnRyYW5zZmVyVHlwZSB8fCBcIi1cIixcclxuICAgICAgICAgIGRhdGU6IHRyYW5zZmVyPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuICAgICAgc2V0VHJhbnNmZXJEYXRhKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggdHJhbnNmZXJzXCIsIGVycik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFkZFRyYW5zZmVyQ2xpY2sgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkZXIodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtYWxsLWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICBzZXRBbGxHcm91cHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRBbGxHcm91cHMoW10pO1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgbG9hZGluZyBncm91cHNcIiwgZXJyKTtcclxuICAgICAgYWxlcnQoXCJDb3VsZCBub3QgbG9hZCBncm91cCBkYXRhLlwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU291cmNlQ3VzdG9tZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFzb3VyY2VHcm91cCkgcmV0dXJuO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvZW5yb2xsL2dldC1ncm91cC1hbGwtZW5yb2xsLyR7c291cmNlR3JvdXB9YFxyXG4gICAgICApO1xyXG4gICAgICBzZXRTb3VyY2VDdXN0b21lcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRTb3VyY2VDdXN0b21lcnMoW10pO1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkZhaWxlZCB0byBnZXQgU291cmNlIEN1c3RvbWVyc1wiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVzdGluYXRpb25DdXN0b21lcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWRlc3RpbmF0aW9uR3JvdXApIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2Vucm9sbC9nZXQtZ3JvdXAtYWxsLWVucm9sbC8ke2Rlc3RpbmF0aW9uR3JvdXB9YFxyXG4gICAgICApO1xyXG4gICAgICBzZXREZXN0aW5hdGlvbkN1c3RvbWVycyhyZXNwb25zZS5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldERlc3RpbmF0aW9uQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgY29uc29sZS5sb2coXCJGYWlsZWQgdG8gZ2V0IERlc3RpbmF0aW9uIEN1c3RvbWVyc1wiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzb3VyY2VHcm91cCkge1xyXG4gICAgICBoYW5kbGVTb3VyY2VDdXN0b21lcnMoKTtcclxuICAgIH1cclxuICB9LCBbc291cmNlR3JvdXBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChkZXN0aW5hdGlvbkdyb3VwKSB7XHJcbiAgICAgIGhhbmRsZURlc3RpbmF0aW9uQ3VzdG9tZXJzKCk7XHJcbiAgICB9XHJcbiAgfSwgW2Rlc3RpbmF0aW9uR3JvdXBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoVHJhbnNmZXJzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoa2V5LCB2YWx1ZSkgPT4ge1xyXG4gICAgc3dpdGNoIChrZXkpIHtcclxuICAgICAgY2FzZSBcInNvdXJjZUdyb3VwXCI6XHJcbiAgICAgICAgc2V0U291cmNlR3JvdXAodmFsdWUpO1xyXG4gICAgICAgIHNldFNvdXJjZUN1c3RvbWVyKFwiXCIpO1xyXG4gICAgICAgIHNldFNvdXJjZVRpY2tldChcIlwiKTtcclxuICAgICAgICBzZXRBbW91bnRQYWlkKDApO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIFwic291cmNlQ3VzdG9tZXJcIjpcclxuICAgICAgICBjb25zdCBlbnJvbGxGcm9tU3BsaXQgPXZhbHVlLnNwbGl0KFwiLVwiKVxyXG4gICAgICAgIGNvbnN0IGVucm9sbEZyb21JZCA9QXJyYXkuaXNBcnJheSggZW5yb2xsRnJvbVNwbGl0KSA/IGVucm9sbEZyb21TcGxpdFswXSA6IFtdXHJcbiAgICAgICAgY29uc3QgW3VzZXJJZCwgdGlja2V0XSA9IGVucm9sbEZyb21TcGxpdC5zcGxpdChcInxcIik7XHJcbiAgICAgICAgc2V0U291cmNlQ3VzdG9tZXIodXNlcklkKTtcclxuICAgICAgICBzZXRTb3VyY2VUaWNrZXQodGlja2V0KTtcclxuICAgICAgICBzZXRTb3VyY2VFbnJvbGxtZW50KGVucm9sbEZyb21JZCk7XHJcbiAgICAgICAgc2V0QW1vdW50UGFpZCgwKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSBcImRlc3RpbmF0aW9uR3JvdXBcIjpcclxuICAgICAgICBzZXREZXN0aW5hdGlvbkdyb3VwKHZhbHVlKTtcclxuICAgICAgICBzZXREZXN0aW5hdGlvbkN1c3RvbWVyKFwiXCIpO1xyXG4gICAgICAgIHNldERlc3RpbmF0aW9uVGlja2V0KFwiXCIpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIFwiZGVzdGluYXRpb25DdXN0b21lclwiOlxyXG4gICAgICAgIGNvbnN0IGVucm9sbFRvU3BsaXQgPSB2YWx1ZS5zcGxpdChcIi1cIik7XHJcbiAgICAgICAgY29uc3QgZW5yb2xsVG9JZCA9IEFycmF5LmlzQXJyYXkoZW5yb2xsVG9TcGxpdCkgPyBlbnJvbGxUb1NwbGl0WzBdIDogW107XHJcbiAgICAgICAgY29uc3QgW3RvVXNlcklkLCB0b1RpY2tldF0gPSBlbnJvbGxUb1NwbGl0LnNwbGl0KFwifFwiKTtcclxuICAgICAgICBzZXREZXN0aW5hdGlvbkN1c3RvbWVyKHRvVXNlcklkKTtcclxuICAgICAgICBzZXREZXN0aW5hdGlvblRpY2tldCh0b1RpY2tldCk7XHJcbiAgICAgICAgc2V0RGVzdGluYXRpb25FbnJvbGxtZW50KGVucm9sbFRvSWQpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIFwidHJhbnNmZXJfYW1vdW50XCI6XHJcbiAgICAgICAgaWYgKHZhbHVlID09PSBcIlwiIHx8IC9eXFxkKlxcLj9cXGQqJC8udGVzdCh2YWx1ZSkpIHtcclxuICAgICAgICAgIHNldFRyYW5zZmVyQW1vdW50KHZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBbW91bnRQYWlkID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFzb3VyY2VHcm91cCB8fCAhc291cmNlQ3VzdG9tZXIgfHwgIXNvdXJjZVRpY2tldCkge1xyXG4gICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgR3JvdXAsIEVucm9sbGVkIEN1c3RvbWVyLCBhbmQgVGlja2V0IGZpcnN0LlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9lbnJvbGwvZ2V0LWFtb3VudC1wYWlkXCIsIHtcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGdyb3VwX2lkOiBzb3VyY2VHcm91cCxcclxuICAgICAgICAgIHVzZXJfaWQ6IHNvdXJjZUN1c3RvbWVyLFxyXG4gICAgICAgICAgdGlja2V0OiBzb3VyY2VUaWNrZXQsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEFtb3VudFBhaWQocmVzLmRhdGEuYW1vdW50UGFpZCB8fCAwKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFtb3VudFBhaWQoMCk7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggYW1vdW50IHBhaWRcIiwgZXJyb3IpO1xyXG4gICAgICBhbGVydChcIkNvdWxkIG5vdCBmZXRjaCBhbW91bnQgcGFpZC5cIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVHJhbnNmZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoXHJcbiAgICAgICFzb3VyY2VHcm91cCB8fFxyXG4gICAgICAhc291cmNlQ3VzdG9tZXIgfHxcclxuICAgICAgIXNvdXJjZVRpY2tldCB8fFxyXG4gICAgICAhZGVzdGluYXRpb25Hcm91cCB8fFxyXG4gICAgICAhZGVzdGluYXRpb25DdXN0b21lciB8fFxyXG4gICAgICAhZGVzdGluYXRpb25UaWNrZXQgfHxcclxuICAgICAgIXRyYW5zZmVyQW1vdW50IHx8XHJcbiAgICAgIHBhcnNlRmxvYXQodHJhbnNmZXJBbW91bnQpIDw9IDBcclxuICAgICkge1xyXG4gICAgICBhbGVydChcIlBsZWFzZSBmaWxsIGFsbCBmaWVsZHMgYW5kIGVudGVyIGEgdmFsaWQgdHJhbnNmZXIgYW1vdW50LlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChwYXJzZUZsb2F0KHRyYW5zZmVyQW1vdW50KSA+IGFtb3VudFBhaWQpIHtcclxuICAgICAgYWxlcnQoXCJUcmFuc2ZlciBhbW91bnQgY2Fubm90IGV4Y2VlZCBhbW91bnQgcGFpZC5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIGZyb21Hcm91cDogc291cmNlR3JvdXAsXHJcbiAgICAgICAgZnJvbVVzZXJJZDogc291cmNlQ3VzdG9tZXIsXHJcbiAgICAgICAgZnJvbVRpY2tldDogTnVtYmVyKHNvdXJjZVRpY2tldCksXHJcbiAgICAgICAgYW1vdW50UGFpZCxcclxuICAgICAgICB0cmFuc2ZlckFtb3VudDogcGFyc2VGbG9hdCh0cmFuc2ZlckFtb3VudCksXHJcbiAgICAgICAgdG9Hcm91cDogZGVzdGluYXRpb25Hcm91cCxcclxuICAgICAgICB0b1VzZXI6IGRlc3RpbmF0aW9uQ3VzdG9tZXIsXHJcbiAgICAgICAgdG9UaWNrZXQ6IE51bWJlcihkZXN0aW5hdGlvblRpY2tldCksXHJcbiAgICAgICAgdHJhbnNmZXJUeXBlOiBcIlNvZnRcIixcclxuICAgICAgICBmcm9tRW5yb2xsSWQ6c291cmNlRW5yb2xsbWVudCxcclxuICAgICAgICB0b0Vucm9sbElkOmRlc3RpbmF0aW9uRW5yb2xsbWVudCxcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLnBvc3QoXCIvZW5yb2xsL3RyYW5zZmVyLWN1c3RvbWVyXCIsIHBheWxvYWQpO1xyXG4gICAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjAwIHx8IHJlcy5zdGF0dXMgPT09IDIwMSkge1xyXG4gICAgICAgIGNvbnN0IHRyYW5zZmVyID0gcmVzLmRhdGE7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID0ge1xyXG4gICAgICAgICAgX2lkOiB0cmFuc2Zlci5faWQsXHJcbiAgICAgICAgICBpZDogdHJhbnNmZXJEYXRhLmxlbmd0aCArIDEsXHJcbiAgICAgICAgICB0cmFuc2Zlcl9pZDogYFRSQU4tJHt0cmFuc2ZlckRhdGEubGVuZ3RoICsgMX1gLFxyXG4gICAgICAgICAgZnJvbV9ncm91cDogZ2V0R3JvdXBOYW1lQnlJZChzb3VyY2VHcm91cCksXHJcbiAgICAgICAgICB0b19ncm91cDogZ2V0R3JvdXBOYW1lQnlJZChkZXN0aW5hdGlvbkdyb3VwKSxcclxuICAgICAgICAgIGZyb21fY3VzdG9tZXI6XHJcbiAgICAgICAgICAgIHNvdXJjZUN1c3RvbWVycy5maW5kKChjKSA9PiBjLnVzZXJfaWQ/Ll9pZCA9PT0gc291cmNlQ3VzdG9tZXIpXHJcbiAgICAgICAgICAgICAgPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICBmcm9tX3Bob25lOlxyXG4gICAgICAgICAgICBzb3VyY2VDdXN0b21lcnMuZmluZCgoYykgPT4gYy51c2VyX2lkPy5faWQgPT09IHNvdXJjZUN1c3RvbWVyKVxyXG4gICAgICAgICAgICAgID8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgZnJvbV90aWNrZXQ6IHNvdXJjZVRpY2tldCxcclxuICAgICAgICAgIHRvX2N1c3RvbWVyOlxyXG4gICAgICAgICAgICBkZXN0aW5hdGlvbkN1c3RvbWVycy5maW5kKFxyXG4gICAgICAgICAgICAgIChjKSA9PiBjLnVzZXJfaWQ/Ll9pZCA9PT0gZGVzdGluYXRpb25DdXN0b21lclxyXG4gICAgICAgICAgICApPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICB0b19waG9uZTpcclxuICAgICAgICAgICAgZGVzdGluYXRpb25DdXN0b21lcnMuZmluZChcclxuICAgICAgICAgICAgICAoYykgPT4gYy51c2VyX2lkPy5faWQgPT09IGRlc3RpbmF0aW9uQ3VzdG9tZXJcclxuICAgICAgICAgICAgKT8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgdG9fdGlja2V0OiBkZXN0aW5hdGlvblRpY2tldCxcclxuICAgICAgICAgIHRyYW5zZmVyX2Ftb3VudDogcGFyc2VGbG9hdCh0cmFuc2ZlckFtb3VudCksXHJcbiAgICAgICAgICBhbW91bnRfcGFpZDogYW1vdW50UGFpZCxcclxuICAgICAgICAgIHRyYW5zZmVyX3R5cGU6IFwiU29mdFwiLFxyXG4gICAgICAgICAgZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHNldFRyYW5zZmVyRGF0YSgocHJldikgPT4gWy4uLnByZXYsIGZvcm1hdHRlZF0pO1xyXG4gICAgICAgIGFsZXJ0KFwiVHJhbnNmZXIgc3VjY2Vzc2Z1bCFcIik7XHJcbiAgICAgICAgcmVzZXRGb3JtKCk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhbGVydChcIlRyYW5zZmVyIGZhaWxlZC5cIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJUcmFuc2ZlciBlcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgICBhbGVydChcIlRyYW5zZmVyIGZhaWxlZC4gQ2hlY2sgY29uc29sZSBmb3IgZGV0YWlscy5cIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVzZXRGb3JtID0gKCkgPT4ge1xyXG4gICAgc2V0U291cmNlR3JvdXAoXCJcIik7XHJcbiAgICBzZXRTb3VyY2VDdXN0b21lcihcIlwiKTtcclxuICAgIHNldFNvdXJjZVRpY2tldChcIlwiKTtcclxuICAgIHNldERlc3RpbmF0aW9uR3JvdXAoXCJcIik7XHJcbiAgICBzZXREZXN0aW5hdGlvbkN1c3RvbWVyKFwiXCIpO1xyXG4gICAgc2V0RGVzdGluYXRpb25UaWNrZXQoXCJcIik7XHJcbiAgICBzZXRUcmFuc2ZlckFtb3VudChcIlwiKTtcclxuICAgIHNldEFtb3VudFBhaWQoMCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2Zlcl9pZFwiLCBoZWFkZXI6IFwiVHJhbnNmZXIgSURcIiB9LFxyXG4gICAgeyBrZXk6IFwiZnJvbV9ncm91cFwiLCBoZWFkZXI6IFwiRnJvbSBHcm91cFwiIH0sXHJcbiAgICB7IGtleTogXCJmcm9tX2N1c3RvbWVyXCIsIGhlYWRlcjogXCJGcm9tIEN1c3RvbWVyXCIgfSxcclxuICAgIHsga2V5OiBcImZyb21fdGlja2V0XCIsIGhlYWRlcjogXCJGcm9tIFRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b19ncm91cFwiLCBoZWFkZXI6IFwiVG8gR3JvdXBcIiB9LFxyXG4gICAgeyBrZXk6IFwidG9fY3VzdG9tZXJcIiwgaGVhZGVyOiBcIlRvIEN1c3RvbWVyXCIgfSxcclxuICAgIHsga2V5OiBcInRvX3RpY2tldFwiLCBoZWFkZXI6IFwiVG8gVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zZmVyX2Ftb3VudFwiLCBoZWFkZXI6IFwiVHJhbnNmZXIgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zZmVyX3R5cGVcIiwgaGVhZGVyOiBcIlRyYW5zZmVyIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNmZXIgRGF0ZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+U29mdCBUcmFuc2ZlcjwvaDE+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBZGRUcmFuc2ZlckNsaWNrfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXZpb2xldC05NTAgdGV4dC13aGl0ZSBweC01IHB5LTUgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctdmlvbGV0LTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCB0ZXh0LWxnXCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGVyfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2xvYWRlciA/IChcclxuICAgICAgICAgICAgICAgIDxTcGluIGluZGljYXRvcj17PExvYWRpbmdPdXRsaW5lZCBzcGluIC8+fSAvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICBcIisgQWRkIFRyYW5zZmVyXCJcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge3RyYW5zZmVyRGF0YT8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbih0cmFuc2ZlckRhdGEsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiU29mdCBBbW91bnQgVHJhbnNmZXIgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJTb2Z0IEFtb3VudCBUcmFuc2ZlciBDdXN0b21lci5jc3ZcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0RhdGFUYWJsZUxvYWRpbmd9XHJcbiAgICAgICAgICAgICAgZmFpbHVyZT17dHJhbnNmZXJEYXRhPy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgZGF0YT1cIlRyYW5zZmVyc1wiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxEcmF3ZXJcclxuICAgICAgICB0aXRsZT1cIkFkZCBTb2Z0IFRyYW5zZmVyXCJcclxuICAgICAgICB3aWR0aD17ODQwfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgb3Blbj17c2hvd01vZGFsfVxyXG4gICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgYm9keTogeyBwYWRkaW5nQm90dG9tOiA4MCwgcGFkZGluZ1RvcDogMTYsIGZvbnRTaXplOiBcIjE2cHhcIiB9LFxyXG4gICAgICAgICAgaGVhZGVyOiB7IGZvbnRTaXplOiBcIjE4cHhcIiwgZm9udFdlaWdodDogXCI2MDBcIiB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgZXh0cmE9e1xyXG4gICAgICAgICAgPFNwYWNlPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJsYXJnZVwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9PlxyXG4gICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibGFyZ2VcIiB0eXBlPVwicHJpbWFyeVwiIG9uQ2xpY2s9e2hhbmRsZVRyYW5zZmVyfT5cclxuICAgICAgICAgICAgICBTdWJtaXRcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L1NwYWNlPlxyXG4gICAgICAgIH1cclxuICAgICAgPlxyXG4gICAgICAgIDxGb3JtIGxheW91dD1cInZlcnRpY2FsXCIgc2l6ZT1cImxhcmdlXCI+XHJcbiAgICAgICAgICA8Um93IGd1dHRlcj17WzE2LCAyNF19IGNsYXNzTmFtZT1cInB4LTJcIj5cclxuICAgICAgICAgICAgPENvbCBzcGFuPXsyNH0+XHJcbiAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgbGFiZWw9ezxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+RnJvbSBHcm91cDwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUNoYW5nZShcInNvdXJjZUdyb3VwXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NvdXJjZUdyb3VwIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IFwiMTZweFwiLCBoZWlnaHQ6IFwiNTJweFwiIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHthbGxHcm91cHNcclxuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKChnKSA9PiBnLmdyb3VwX25hbWUpXHJcbiAgICAgICAgICAgICAgICAgICAgLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgPC9Db2w+XHJcblxyXG4gICAgICAgICAgICA8Q29sIHNwYW49ezI0fT5cclxuICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5Gcm9tIEN1c3RvbWVyPC9zcGFuPn1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQ2hhbmdlKFwic291cmNlQ3VzdG9tZXJcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgc291cmNlQ3VzdG9tZXIgJiYgc291cmNlVGlja2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IGAke3NvdXJjZUN1c3RvbWVyfXwke3NvdXJjZVRpY2tldH1gXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiBcIjE2cHhcIiwgaGVpZ2h0OiBcIjUycHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7c291cmNlQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigoZSkgPT4gZS51c2VyX2lkPy5faWQgJiYgZS50aWNrZXRzKVxyXG4gICAgICAgICAgICAgICAgICAgIC5tYXAoKGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17ZS5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHtlLnVzZXJfaWQuX2lkfXwke2UudGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YCR7ZS51c2VyX2lkLmZ1bGxfbmFtZX0gfCAke2UudXNlcl9pZC5waG9uZV9udW1iZXJ9IHwgVGlja2V0OiAke2UudGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICAgICAgPENvbCBzcGFuPXsyNH0+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17ZmV0Y2hBbW91bnRQYWlkfVxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBcIjUycHhcIixcclxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTZweFwiLFxyXG4gICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjUwMFwiLFxyXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiIzFlNDBhZlwiLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDaGVjayBUb3RhbCBBbW91bnQgUGFpZFxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgICAgIDxDb2wgc3Bhbj17MjR9PlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPXs8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPkFtb3VudCBQYWlkPC9zcGFuPn1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ftb3VudFBhaWR9XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTZweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCI1MnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogXCI1MDBcIixcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICAgICAgPENvbCBzcGFuPXsyNH0+XHJcbiAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgbGFiZWw9ezxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+VHJhbnNmZXIgQW1vdW50PC9zcGFuPn1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBbW91bnQgdG8gVHJhbnNmZXJcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dHJhbnNmZXJBbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoXCJ0cmFuc2Zlcl9hbW91bnRcIiwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IFwiMTZweFwiLCBoZWlnaHQ6IFwiNTJweFwiIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgICAgIDxDb2wgc3Bhbj17MjR9PlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbGFiZWw9ezxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+VG8gR3JvdXA8L3NwYW4+fT5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRGVzdGluYXRpb24gR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVDaGFuZ2UoXCJkZXN0aW5hdGlvbkdyb3VwXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Rlc3RpbmF0aW9uR3JvdXAgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogXCIxNnB4XCIsIGhlaWdodDogXCI1MnB4XCIgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2FsbEdyb3Vwc1xyXG4gICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGcpID0+IGcuZ3JvdXBfbmFtZSlcclxuICAgICAgICAgICAgICAgICAgICAubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgICAgIDxDb2wgc3Bhbj17MjR9PlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPXs8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlRvIEN1c3RvbWVyPC9zcGFuPn1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IERlc3RpbmF0aW9uIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoXCJkZXN0aW5hdGlvbkN1c3RvbWVyXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICBkZXN0aW5hdGlvbkN1c3RvbWVyICYmIGRlc3RpbmF0aW9uVGlja2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IGAke2Rlc3RpbmF0aW9uQ3VzdG9tZXJ9fCR7ZGVzdGluYXRpb25UaWNrZXR9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogXCIxNnB4XCIsIGhlaWdodDogXCI1MnB4XCIgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2Rlc3RpbmF0aW9uQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigoZSkgPT4gZS51c2VyX2lkPy5faWQgJiYgZS50aWNrZXRzKVxyXG4gICAgICAgICAgICAgICAgICAgIC5tYXAoKGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17ZS5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHtlLnVzZXJfaWQuX2lkfXwke2UudGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YCR7ZS51c2VyX2lkLmZ1bGxfbmFtZX0gfCAke2UudXNlcl9pZC5waG9uZV9udW1iZXJ9IHwgVGlja2V0OiAke2UudGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgPC9Gb3JtPlxyXG4gICAgICA8L0RyYXdlcj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTb2Z0VHJhbnNmZXJDdXN0b21lcjtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1NvZnRUcmFuc2ZlckN1c3RvbWVyLmpzeCJ9