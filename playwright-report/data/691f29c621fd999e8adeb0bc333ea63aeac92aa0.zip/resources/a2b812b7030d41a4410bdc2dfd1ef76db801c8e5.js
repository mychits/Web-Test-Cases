import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AdvancePaymentIn.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Drawer, Modal, Empty, Alert } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { FiCalendar, FiCreditCard, FiHash, FiFileText } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { GrStatusGood } from "/node_modules/.vite/deps/react-icons_gr.js?v=819e0a34";
import { s } from "/node_modules/.vite/deps/framer-motion_client.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { RiMoneyRupeeCircleFill } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import { MdOutlineMan } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import { User } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const EmployeeAdvancePaymentIn = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [tablePayments, setTablePayments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [editId, setEditId] = useState(null);
  const [totalCount, setTotalCount] = useState({ pending: 0, completed: 0 });
  const tabs = ["Pending", "Completed"];
  const [activeTab, setActiveTab] = useState(tabs[0]);
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const initialForm = {
    employee_id: "",
    pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    month: null,
    year: null,
    pay_type: "cash",
    transaction_id: "",
    amount: 0,
    note: "",
    status: ""
  };
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info",
    noReload: true
  });
  useEffect(() => {
    if (alertConfig.visibility) {
      const timer = setTimeout(() => {
        setAlertConfig((prev) => ({ ...prev, visibility: false }));
      }, 3e3);
      return () => clearTimeout(timer);
    }
  }, [alertConfig.visibility]);
  useEffect(() => {
    fetchEmployees();
    fetchAdvanceHistory();
  }, [activeTab]);
  useEffect(() => {
    fetchTotalCounts();
  }, [reloadTrigger]);
  const fetchTotalCounts = async () => {
    try {
      const [pendingRes, completedRes] = await Promise.all(
        [
          api.get(`/advance-payment-in/status/Pending`),
          api.get(`/advance-payment-in/status/Completed`)
        ]
      );
      setTotalCount({
        pending: pendingRes.data.data?.length || 0,
        completed: completedRes.data.data?.length || 0
      });
    } catch (error) {
      console.error("Error fetching counts:", error);
      setTotalCount({ pending: 0, completed: 0 });
    }
  };
  const fetchEmployees = async () => {
    const res = await api.get("/employee");
    if (res.data.status) setEmployees(res.data.employee);
  };
  const fetchAdvanceHistory = async () => {
    try {
      let status = activeTab === "Pending" ? "Pending" : "Completed";
      setIsLoading(true);
      const response = await api.get(`/advance-payment-in/status/${status}`);
      const formatted = response.data.data?.map((item, index) => ({
        ...item,
        id: index + 1,
        date: item.pay_date?.split("T")[0],
        employeeName: item.employee_id?.name || "N/A",
        pay_date: new Date(item?.pay_date)?.toLocaleDateString("en-GB", {
          day: "numeric",
          month: "2-digit",
          year: "numeric"
        }).replace(/\//g, "-"),
        action: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            menu: {
              items: [
                { key: "1", label: "Edit", onClick: () => handleEdit(item) },
                {
                  key: "2",
                  label: /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "Delete" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 124,
                    columnNumber: 22
                  }, this),
                  onClick: () => showDeleteConfirm(item._id)
                }
              ]
            },
            trigger: ["click"],
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 131,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 118,
            columnNumber: 9
          },
          this
        )
      }));
      setTablePayments(formatted);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  const showDeleteConfirm = (id) => {
    Modal.confirm({
      title: "Are you sure you want to delete this record?",
      content: "This action cannot be undone.",
      okText: "Yes, Delete",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete(id);
      }
    });
  };
  const handleEdit = (item) => {
    const employeeId = typeof item.employee_id === "object" ? item.employee_id._id : item.employee_id;
    setEditId(item._id);
    setFormData({
      employee_id: employeeId,
      pay_date: item.pay_date?.split("T")[0],
      month: item.month,
      year: Number(item.year),
      pay_type: item.pay_type,
      transaction_id: item.transaction_id || "",
      amount: item.amount,
      note: item.note || "",
      status: item.status
    });
    setShowModal(true);
  };
  const handleDelete = async (id) => {
    try {
      setOpenBackdropLoader(true);
      await api.delete(`/advance-payment-in/${id}`);
      setAlertConfig({
        visibility: true,
        message: "Data Deleted Successfully!",
        type: "success",
        noReload: true
      });
      fetchAdvanceHistory();
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Delete failed",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
      setReloadTrigger((prev) => prev + 1);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    try {
      setOpenBackdropLoader(true);
      if (editId) {
        await api.put(`/advance-payment-in/${editId}`, formData);
      } else {
        await api.post("/advance-payment-in/", formData);
      }
      setAlertConfig({
        visibility: true,
        message: editId ? "Data Updated Successfully!" : "Data Added Successfully!",
        type: "success",
        noReload: true
      });
      closeDrawer();
      fetchAdvanceHistory();
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Error saving data",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
      setReloadTrigger((prev) => prev + 1);
    }
  };
  const validateForm = () => {
    const errs = {};
    if (!formData.employee_id) errs.employee = "Required";
    if (!formData.amount || formData.amount <= 0)
      errs.amount = "Enter valid amount";
    if (!formData.month) errs.month = "Required";
    if (!formData.year) errs.year = "Required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };
  const closeDrawer = () => {
    setShowModal(false);
    setEditId(null);
    setFormData(initialForm);
    setErrors({});
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Paid Date" },
    { key: "employeeName", header: "Employee" },
    { key: "month", header: "Month" },
    { key: "year", header: "Year" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Payment Mode" },
    { key: "transaction_id", header: "Transaction ID" },
    { key: "note", header: "Remarks" },
    { key: "action", header: "Action" }
  ];
  const NAV_LINKS = [
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
        lineNumber: 270,
        columnNumber: 11
      }, this),
      label: "Salary payment"
    },
    {
      to: "/staff-menu/employee-menu/salary-management",
      icon: /* @__PURE__ */ jsxDEV(MdOutlineMan, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
        lineNumber: 275,
        columnNumber: 11
      }, this),
      label: "Salary management"
    },
    {
      to: "/staff-menu/employee-menu/employee-statement",
      icon: /* @__PURE__ */ jsxDEV(User, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
        lineNumber: 280,
        columnNumber: 11
      }, this),
      label: "Salary Ledger"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-incentive",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
        lineNumber: 285,
        columnNumber: 11
      }, this),
      label: "Salary incentive"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/additional-salary",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
        lineNumber: 290,
        columnNumber: 11
      }, this),
      label: "Additional salary"
    }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    openBackdropLoader && /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "Processing..." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
      lineNumber: 297,
      columnNumber: 30
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
        lineNumber: 300,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 px-6", children: [
        /* @__PURE__ */ jsxDEV(Navbar, { onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value), visibility: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
          lineNumber: 302,
          columnNumber: 11
        }, this),
        alertConfig.visibility && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-5 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-md px-4", children: /* @__PURE__ */ jsxDEV(
          Alert,
          {
            message: alertConfig.message,
            type: alertConfig.type,
            showIcon: true,
            closable: true,
            onClose: () => setAlertConfig({ ...alertConfig, visibility: false })
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 306,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
          lineNumber: 305,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 316,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-4", children: "Employee Advance Repayment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 317,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-widest text-gray-400 mb-3", children: "Quick navigator" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 321,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: NAV_LINKS.map(
              (link) => /* @__PURE__ */ jsxDEV(
                Link,
                {
                  to: link.to,
                  className: "flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 hover:border-blue-400 hover:text-blue-600 hover:bg-blue-50 transition-all",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-blue-500", children: link.icon }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                      lineNumber: 331,
                      columnNumber: 21
                    }, this),
                    link.label
                  ]
                },
                link.to,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 326,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 324,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 320,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
          lineNumber: 315,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center border-b border-gray-200 mb-6 mt-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: tabs.map(
            (tab) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: `px-4 py-2 font-medium ${activeTab === tab ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"}`,
                onClick: () => setActiveTab(tab),
                children: tab === "Pending" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  "Pending",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "bg-orange-500 text-white text-[12px] px-2 py-0.5 rounded-full", children: totalCount?.pending }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 355,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 353,
                  columnNumber: 17
                }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  "Completed",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "bg-green-500 text-white text-[12px] px-2 py-0.5 rounded-full", children: totalCount?.completed }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 362,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 360,
                  columnNumber: 17
                }, this)
              },
              tab,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 344,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 342,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setEditId(null);
                setFormData(initialForm);
                setShowModal(true);
              },
              className: "bg-blue-950 text-white px-4 py-2 rounded mb-3",
              children: "+ Add Advance"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 372,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
          lineNumber: 340,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          activeTab === "Pending" && /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 392,
            columnNumber: 15
          }, this) : tablePayments.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Advance Repayment Data Found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 394,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: tablePayments.filter(
                (item) => item.employeeName?.toLowerCase().includes(searchText.toLowerCase())
              ),
              columns
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 396,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 387,
            columnNumber: 13
          }, this),
          activeTab === "Completed" && /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 409,
              columnNumber: 17
            }, this),
            isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 427,
              columnNumber: 15
            }, this) : tablePayments.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Advance Repayment Data Found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 429,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: tablePayments.filter(
                  (item) => item.employeeName?.toLowerCase().includes(searchText.toLowerCase())
                ),
                columns
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 431,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 408,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
          lineNumber: 385,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Drawer,
          {
            title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-blue-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 449,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 448,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: editId ? "Edit Advance Repayment" : "New Advance Repayment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 451,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 447,
              columnNumber: 13
            }, this),
            open: showModal,
            onClose: closeDrawer,
            width: 480,
            children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6 p-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  "Employee ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 464,
                    columnNumber: 28
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 463,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    showSearch: true,
                    size: "large",
                    className: "w-full",
                    placeholder: "Search and select employee",
                    value: formData.employee_id || void 0,
                    optionFilterProp: "label",
                    filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                    onChange: (val) => setFormData({ ...formData, employee_id: val }),
                    children: employees.map(
                      (emp) => /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: emp._id,
                          label: `${emp.name} ${emp.employeeCode}`,
                          children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                            /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-medium text-blue-700", children: emp.name.charAt(0).toUpperCase() }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                              lineNumber: 487,
                              columnNumber: 25
                            }, this),
                            emp.name,
                            " | ",
                            emp.employeeCode
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 486,
                            columnNumber: 23
                          }, this)
                        },
                        emp._id,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                          lineNumber: 481,
                          columnNumber: 19
                        },
                        this
                      )
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 466,
                    columnNumber: 17
                  },
                  this
                ),
                errors.employee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 497,
                    columnNumber: 21
                  }, this),
                  errors.employee
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 496,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 462,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 508,
                    columnNumber: 19
                  }, this),
                  "Month & Year"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 507,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV(
                      "select",
                      {
                        className: "w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                        value: formData.month || "",
                        onChange: (e) => setFormData({ ...formData, month: e.target.value }),
                        disabled: editId ? true : false,
                        children: [
                          /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Month" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 524,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "January", children: "January" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 525,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "February", children: "February" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 526,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "March", children: "March" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 527,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "April", children: "April" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 528,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "May", children: "May" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 529,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "June", children: "June" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 530,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "July", children: "July" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 531,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "August", children: "August" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 532,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "September", children: "September" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 533,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "October", children: "October" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 534,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "November", children: "November" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 535,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "December", children: "December" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 536,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 516,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.month && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 540,
                        columnNumber: 25
                      }, this),
                      errors.month
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                      lineNumber: 539,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 515,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV(
                      "select",
                      {
                        className: "w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                        value: formData.year || 0,
                        onChange: (e) => setFormData({ ...formData, year: Number(e.target.value) }),
                        disabled: editId ? true : false,
                        children: [
                          /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Year" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                            lineNumber: 555,
                            columnNumber: 23
                          }, this),
                          Array.from({ length: 10 }, (_, i) => {
                            const year = (/* @__PURE__ */ new Date()).getFullYear() - 5 + i;
                            return /* @__PURE__ */ jsxDEV("option", { value: year, children: year }, year, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                              lineNumber: 559,
                              columnNumber: 27
                            }, this);
                          })
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 547,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.year && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 567,
                        columnNumber: 25
                      }, this),
                      errors.year
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                      lineNumber: 566,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 546,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 512,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 506,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 578,
                    columnNumber: 19
                  }, this),
                  "Amount ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 579,
                    columnNumber: 26
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 577,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-medium", children: "₹" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 582,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      step: "0.01",
                      className: "w-full border border-gray-300 rounded-lg pl-8 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                      placeholder: "0.00",
                      value: formData.amount,
                      onChange: (e) => setFormData({ ...formData, amount: e.target.value })
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                      lineNumber: 585,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 581,
                  columnNumber: 17
                }, this),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 605,
                    columnNumber: 21
                  }, this),
                  errors.amount
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 604,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 576,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 614,
                    columnNumber: 19
                  }, this),
                  "Payment Date"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 613,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative", children: /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                    value: formData.pay_date,
                    onChange: (e) => setFormData({ ...formData, pay_date: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 618,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 617,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 612,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiCreditCard, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 632,
                    columnNumber: 19
                  }, this),
                  "Payment Mode"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 631,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    size: "large",
                    className: "w-full",
                    value: formData.pay_type,
                    onChange: (val) => setFormData({ ...formData, pay_type: val }),
                    children: [
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 642,
                        columnNumber: 21
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 641,
                        columnNumber: 19
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Online/UPI" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 645,
                        columnNumber: 21
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 644,
                        columnNumber: 19
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "cheque", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cheque" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 648,
                        columnNumber: 21
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 647,
                        columnNumber: 19
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 635,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 630,
                columnNumber: 15
              }, this),
              formData.pay_type !== "cash" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 animate-fadeIn", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiHash, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 657,
                    columnNumber: 21
                  }, this),
                  formData.pay_type === "cheque" ? "Cheque Number" : "Transaction ID"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 656,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                    placeholder: formData.pay_type === "cheque" ? "Enter cheque number" : "Enter transaction/UPI ID",
                    value: formData.transaction_id,
                    onChange: (e) => setFormData({ ...formData, transaction_id: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 662,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 655,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiFileText, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 681,
                    columnNumber: 19
                  }, this),
                  "Note (Optional)"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 680,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    rows: 3,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition resize-none",
                    placeholder: "Add any remarks or reference...",
                    value: formData.note,
                    onChange: (e) => setFormData({ ...formData, note: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 684,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 679,
                columnNumber: 15
              }, this),
              editId && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(GrStatusGood, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 698,
                    columnNumber: 19
                  }, this),
                  "Status"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 697,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    size: "large",
                    className: "w-full",
                    value: formData?.status,
                    onChange: (val) => setFormData({ ...formData, status: val }),
                    children: [
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "Pending", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Pending" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 708,
                        columnNumber: 21
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 707,
                        columnNumber: 19
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "Completed", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Completed" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 711,
                        columnNumber: 21
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                        lineNumber: 710,
                        columnNumber: 19
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                    lineNumber: 701,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 696,
                columnNumber: 26
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-200 font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5 flex items-center justify-center gap-2",
                  children: editId ? "Update Advance Payment" : "Save Advance Payment"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                  lineNumber: 719,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
                lineNumber: 718,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
              lineNumber: 460,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
            lineNumber: 445,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
        lineNumber: 301,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
      lineNumber: 299,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx",
    lineNumber: 296,
    columnNumber: 5
  }, this);
};
_s(EmployeeAdvancePaymentIn, "Pv9W1EL3vOoWhnH5fBKyoxlH4CI=");
_c = EmployeeAdvancePaymentIn;
export default EmployeeAdvancePaymentIn;
var _c;
$RefreshReg$(_c, "EmployeeAdvancePaymentIn");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdvancePaymentIn.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkh5QixTQXFPTCxVQXJPSzsyQkEzSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFVBQVVDLFFBQVFDLE9BQU9DLE9BQU9DLGFBQWE7QUFDOUQsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsWUFBWUMsY0FBY0MsUUFBUUMsa0JBQWtCO0FBQzdELFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLFNBQVM7QUFDbEIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0Msb0JBQW9CO0FBQzdCLE9BQU9DLGdCQUFnQjtBQUN2QixTQUFTQyxZQUFZO0FBRXJCLE1BQU1DLDJCQUEyQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3JDLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJL0IsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2dDLGVBQWVDLGdCQUFnQixJQUFJakMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ2tDLFdBQVdDLFlBQVksSUFBSW5DLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNvQyxXQUFXQyxZQUFZLElBQUlyQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDc0MsZUFBZUMsZ0JBQWdCLElBQUl2QyxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDd0MsWUFBWUMsYUFBYSxJQUFJekMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzBDLG9CQUFvQkMscUJBQXFCLElBQUkzQyxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDNEMsUUFBUUMsU0FBUyxJQUFJN0MsU0FBUyxJQUFJO0FBQ3pDLFFBQU0sQ0FBQzhDLFlBQVlDLGFBQWEsSUFBSS9DLFNBQVMsRUFBRWdELFNBQVMsR0FBR0MsV0FBVyxFQUFFLENBQUM7QUFDekUsUUFBTUMsT0FBTyxDQUFDLFdBQVcsV0FBVztBQUVwQyxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXBELFNBQVNrRCxLQUFLLENBQUMsQ0FBQztBQUVsRCxRQUFNRyxTQUFRLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUVuRCxRQUFNQyxjQUFjO0FBQUEsSUFDbEJDLGFBQWE7QUFBQSxJQUNiQyxXQUFVLG9CQUFJTCxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLElBQy9DSSxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFVBQVU7QUFBQSxJQUNWQyxnQkFBZ0I7QUFBQSxJQUNoQkMsUUFBUTtBQUFBLElBQ1JDLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsRUFDVjtBQUVBLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJcEUsU0FBU3lELFdBQVc7QUFDcEQsUUFBTSxDQUFDWSxRQUFRQyxTQUFTLElBQUl0RSxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUN1RSxhQUFhQyxjQUFjLElBQUl4RSxTQUFTO0FBQUEsSUFDN0N5RSxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxJQUNOQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBR0Q3RSxZQUFVLE1BQU07QUFDZCxRQUFJd0UsWUFBWUUsWUFBWTtBQUMxQixZQUFNSSxRQUFRQyxXQUFXLE1BQU07QUFDN0JOLHVCQUFlLENBQUNPLFVBQVUsRUFBRSxHQUFHQSxNQUFNTixZQUFZLE1BQU0sRUFBRTtBQUFBLE1BQzNELEdBQUcsR0FBSTtBQUNQLGFBQU8sTUFBTU8sYUFBYUgsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLENBQUNOLFlBQVlFLFVBQVUsQ0FBQztBQUUzQjFFLFlBQVUsTUFBTTtBQUNka0YsbUJBQWU7QUFDZkMsd0JBQW9CO0FBQUEsRUFFdEIsR0FBRyxDQUFDL0IsU0FBUyxDQUFDO0FBQ2RwRCxZQUFVLE1BQU07QUFDZG9GLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsQ0FBQzdDLGFBQWEsQ0FBQztBQUVsQixRQUFNNkMsbUJBQW1CLFlBQVk7QUFDbkMsUUFBSTtBQUNGLFlBQU0sQ0FBQ0MsWUFBWUMsWUFBWSxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUNuRHJGLElBQUlzRixJQUFJLG9DQUFvQztBQUFBLFVBQzVDdEYsSUFBSXNGLElBQUksc0NBQXNDO0FBQUEsUUFBQztBQUFBLE1BQ2hEO0FBRUR6QyxvQkFBYztBQUFBLFFBQ1pDLFNBQVNvQyxXQUFXSyxLQUFLQSxNQUFNQyxVQUFVO0FBQUEsUUFDekN6QyxXQUFXb0MsYUFBYUksS0FBS0EsTUFBTUMsVUFBVTtBQUFBLE1BQy9DLENBQUM7QUFBQSxJQUNILFNBQVNDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwwQkFBMEJBLEtBQUs7QUFDN0M1QyxvQkFBYyxFQUFFQyxTQUFTLEdBQUdDLFdBQVcsRUFBRSxDQUFDO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBRUEsUUFBTWdDLGlCQUFpQixZQUFZO0FBQ2pDLFVBQU1ZLE1BQU0sTUFBTTNGLElBQUlzRixJQUFJLFdBQVc7QUFDckMsUUFBSUssSUFBSUosS0FBS3ZCLE9BQVFuQyxjQUFhOEQsSUFBSUosS0FBS0ssUUFBUTtBQUFBLEVBQ3JEO0FBRUEsUUFBTVosc0JBQXNCLFlBQVk7QUFDdEMsUUFBSTtBQUNGLFVBQUloQixTQUFTZixjQUFjLFlBQVksWUFBWTtBQUNuRGQsbUJBQWEsSUFBSTtBQUNqQixZQUFNMEQsV0FBVyxNQUFNN0YsSUFBSXNGLElBQUksOEJBQThCdEIsTUFBTSxFQUFFO0FBRXJFLFlBQU04QixZQUFZRCxTQUFTTixLQUFLQSxNQUFNUSxJQUFJLENBQUNDLE1BQU1DLFdBQVc7QUFBQSxRQUMxRCxHQUFHRDtBQUFBQSxRQUNIRSxJQUFJRCxRQUFRO0FBQUEsUUFDWkUsTUFBTUgsS0FBS3ZDLFVBQVVILE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxRQUNqQzhDLGNBQWNKLEtBQUt4QyxhQUFhNkMsUUFBUTtBQUFBLFFBQ3hDNUMsVUFBVSxJQUFJTCxLQUFLNEMsTUFBTXZDLFFBQVEsR0FBRzZDLG1CQUFtQixTQUFTO0FBQUEsVUFDOURDLEtBQUs7QUFBQSxVQUNMN0MsT0FBTztBQUFBLFVBQ1BDLE1BQU07QUFBQSxRQUNSLENBQUMsRUFBRTZDLFFBQVEsT0FBTyxHQUFHO0FBQUEsUUFDckJDLFFBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU07QUFBQSxjQUNKQyxPQUFPO0FBQUEsZ0JBQ0wsRUFBRUMsS0FBSyxLQUFLQyxPQUFPLFFBQVFDLFNBQVNBLE1BQU1DLFdBQVdkLElBQUksRUFBRTtBQUFBLGdCQUMzRDtBQUFBLGtCQUNFVyxLQUFLO0FBQUEsa0JBQ0xDLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGdCQUFlLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQztBQUFBLGtCQUM1Q0MsU0FBU0EsTUFBTUUsa0JBQWtCZixLQUFLZ0IsR0FBRztBQUFBLGdCQUMzQztBQUFBLGNBQUM7QUFBQSxZQUVMO0FBQUEsWUFDQSxTQUFTLENBQUMsT0FBTztBQUFBLFlBRWpCLGlDQUFDLFlBQVMsV0FBVSw0QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQTtBQUFBLFVBYjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNBO0FBQUEsTUFFSixFQUFFO0FBQ0ZqRix1QkFBaUIrRCxTQUFTO0FBQUEsSUFDNUIsU0FBU21CLEtBQUs7QUFDWnZCLGNBQVFELE1BQU13QixHQUFHO0FBQUEsSUFDbkIsVUFBQztBQUNDOUUsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU00RSxvQkFBb0JBLENBQUNiLE9BQU87QUFDaEMzRixVQUFNMkcsUUFBUTtBQUFBLE1BQ1pDLE9BQU87QUFBQSxNQUNQQyxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JDLFFBQVE7QUFBQSxNQUNSQyxZQUFZO0FBQUEsTUFDWkMsT0FBTztBQUNMQyxxQkFBYXZCLEVBQUU7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNWSxhQUFhQSxDQUFDZCxTQUFTO0FBQzNCLFVBQU0wQixhQUNKLE9BQU8xQixLQUFLeEMsZ0JBQWdCLFdBQ3hCd0MsS0FBS3hDLFlBQVl3RCxNQUNqQmhCLEtBQUt4QztBQUNYYixjQUFVcUQsS0FBS2dCLEdBQUc7QUFDbEI5QyxnQkFBWTtBQUFBLE1BQ1ZWLGFBQWFrRTtBQUFBQSxNQUNiakUsVUFBVXVDLEtBQUt2QyxVQUFVSCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDckNJLE9BQU9zQyxLQUFLdEM7QUFBQUEsTUFDWkMsTUFBTWdFLE9BQU8zQixLQUFLckMsSUFBSTtBQUFBLE1BQ3RCQyxVQUFVb0MsS0FBS3BDO0FBQUFBLE1BQ2ZDLGdCQUFnQm1DLEtBQUtuQyxrQkFBa0I7QUFBQSxNQUN2Q0MsUUFBUWtDLEtBQUtsQztBQUFBQSxNQUNiQyxNQUFNaUMsS0FBS2pDLFFBQVE7QUFBQSxNQUNuQkMsUUFBUWdDLEtBQUtoQztBQUFBQSxJQUNmLENBQUM7QUFDRC9CLGlCQUFhLElBQUk7QUFBQSxFQUNuQjtBQUVBLFFBQU13RixlQUFlLE9BQU92QixPQUFPO0FBQ2pDLFFBQUk7QUFDRnpELDRCQUFzQixJQUFJO0FBQzFCLFlBQU16QyxJQUFJNEgsT0FBTyx1QkFBdUIxQixFQUFFLEVBQUU7QUFDNUM1QixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLFFBQ05DLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFDRE0sMEJBQW9CO0FBQUEsSUFDdEIsU0FBU1MsT0FBTztBQUNkbkIscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxRQUNOQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0NqQyw0QkFBc0IsS0FBSztBQUMzQkosdUJBQWlCLENBQUN3QyxTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNyQztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0QsZUFBZSxPQUFPQyxNQUFNO0FBQ2hDQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ0MsYUFBYSxFQUFHO0FBRXJCLFFBQUk7QUFDRnZGLDRCQUFzQixJQUFJO0FBQzFCLFVBQUlDLFFBQVE7QUFDVixjQUFNMUMsSUFBSWlJLElBQUksdUJBQXVCdkYsTUFBTSxJQUFJdUIsUUFBUTtBQUFBLE1BQ3pELE9BQU87QUFDTCxjQUFNakUsSUFBSWtJLEtBQUssd0JBQXdCakUsUUFBUTtBQUFBLE1BQ2pEO0FBQ0FLLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM5QixTQUNMLCtCQUNBO0FBQUEsUUFDSitCLE1BQU07QUFBQSxRQUNOQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQ0R5RCxrQkFBWTtBQUNabkQsMEJBQW9CO0FBQUEsSUFDdEIsU0FBU1MsT0FBTztBQUNkbkIscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxRQUNOQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0NqQyw0QkFBc0IsS0FBSztBQUMzQkosdUJBQWlCLENBQUN3QyxTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNyQztBQUFBLEVBQ0Y7QUFFQSxRQUFNbUQsZUFBZUEsTUFBTTtBQUN6QixVQUFNSSxPQUFPLENBQUM7QUFDZCxRQUFJLENBQUNuRSxTQUFTVCxZQUFhNEUsTUFBS3hDLFdBQVc7QUFDM0MsUUFBSSxDQUFDM0IsU0FBU0gsVUFBVUcsU0FBU0gsVUFBVTtBQUN6Q3NFLFdBQUt0RSxTQUFTO0FBQ2hCLFFBQUksQ0FBQ0csU0FBU1AsTUFBTzBFLE1BQUsxRSxRQUFRO0FBQ2xDLFFBQUksQ0FBQ08sU0FBU04sS0FBTXlFLE1BQUt6RSxPQUFPO0FBQ2hDUyxjQUFVZ0UsSUFBSTtBQUNkLFdBQU9DLE9BQU9DLEtBQUtGLElBQUksRUFBRTVDLFdBQVc7QUFBQSxFQUN0QztBQUVBLFFBQU0yQyxjQUFjQSxNQUFNO0FBQ3hCbEcsaUJBQWEsS0FBSztBQUNsQlUsY0FBVSxJQUFJO0FBQ2R1QixnQkFBWVgsV0FBVztBQUN2QmEsY0FBVSxDQUFDLENBQUM7QUFBQSxFQUNkO0FBRUEsUUFBTW1FLFVBQVU7QUFBQSxJQUNkLEVBQUU1QixLQUFLLE1BQU02QixRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFN0IsS0FBSyxZQUFZNkIsUUFBUSxZQUFZO0FBQUEsSUFDdkMsRUFBRTdCLEtBQUssZ0JBQWdCNkIsUUFBUSxXQUFXO0FBQUEsSUFDMUMsRUFBRTdCLEtBQUssU0FBUzZCLFFBQVEsUUFBUTtBQUFBLElBQ2hDLEVBQUU3QixLQUFLLFFBQVE2QixRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFN0IsS0FBSyxVQUFVNkIsUUFBUSxTQUFTO0FBQUEsSUFFbEMsRUFBRTdCLEtBQUssWUFBWTZCLFFBQVEsZUFBZTtBQUFBLElBQzFDLEVBQUU3QixLQUFLLGtCQUFrQjZCLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRTdCLEtBQUssUUFBUTZCLFFBQVEsVUFBVTtBQUFBLElBQ2pDLEVBQUU3QixLQUFLLFVBQVU2QixRQUFRLFNBQVM7QUFBQSxFQUFDO0FBSXJDLFFBQU1DLFlBQVk7QUFBQSxJQUNoQjtBQUFBLE1BQ0VDLElBQUk7QUFBQSxNQUNKQyxNQUFNLHVCQUFDLDBCQUF1QixNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUN2Qy9CLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0U4QixJQUFJO0FBQUEsTUFDSkMsTUFBTSx1QkFBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUI7QUFBQSxNQUM3Qi9CLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0U4QixJQUFJO0FBQUEsTUFDSkMsTUFBTSx1QkFBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxNQUNyQi9CLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0U4QixJQUFJO0FBQUEsTUFDSkMsTUFBTSx1QkFBQywwQkFBdUIsTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDdkMvQixPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFOEIsSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsMEJBQXVCLE1BQU0sTUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ3ZDL0IsT0FBTztBQUFBLElBQ1Q7QUFBQSxFQUFDO0FBR0gsU0FDRSxtQ0FDR3BFO0FBQUFBLDBCQUFzQix1QkFBQyxzQkFBbUIsT0FBTSxtQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QztBQUFBLElBRWhFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFVBQU8sNkJBQTZCLENBQUNzRixNQUFNdkYsY0FBY3VGLEVBQUVjLE9BQU9DLEtBQUssR0FBRyxZQUFZLFFBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEY7QUFBQSxRQUUzRnhFLFlBQVlFLGNBQ1gsdUJBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTRixZQUFZRztBQUFBQSxZQUNyQixNQUFNSCxZQUFZSTtBQUFBQSxZQUNsQjtBQUFBLFlBQ0E7QUFBQSxZQUNBLFNBQVMsTUFBTUgsZUFBZSxFQUFFLEdBQUdELGFBQWFFLFlBQVksTUFBTSxDQUFDO0FBQUE7QUFBQSxVQUxyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLdUUsS0FOekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFRix1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVc7QUFBQSxVQUNYLHVCQUFDLFFBQUcsV0FBVSwrQkFBOEIsMENBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsVUFHdEUsdUJBQUMsYUFBUSxXQUFVLFFBQ2pCO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHNFQUFxRSwrQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNaa0Usb0JBQVUxQztBQUFBQSxjQUFJLENBQUMrQyxTQUNkO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLElBQUlBLEtBQUtKO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFVBQUssV0FBVSxpQkFBaUJJLGVBQUtILFFBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJDO0FBQUEsb0JBQzFDRyxLQUFLbEM7QUFBQUE7QUFBQUE7QUFBQUEsZ0JBTERrQyxLQUFLSjtBQUFBQSxnQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxZQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxhQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsd0VBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsY0FDWjFGLGVBQUsrQztBQUFBQSxZQUFJLENBQUNnRCxRQUNUO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVyx5QkFBeUI5RixjQUFjOEYsTUFDOUMsNkNBQ0EsZUFBZTtBQUFBLGdCQUVuQixTQUFTLE1BQU03RixhQUFhNkYsR0FBRztBQUFBLGdCQUU5QkEsa0JBQVEsWUFDUCxtQ0FBRTtBQUFBO0FBQUEsa0JBQ1E7QUFBQSxrQkFDUix1QkFBQyxVQUFLLFdBQVUsaUVBQ2JuRyxzQkFBWUUsV0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQSxJQUVBLG1DQUFFO0FBQUE7QUFBQSxrQkFDVTtBQUFBLGtCQUNWLHVCQUFDLFVBQUssV0FBVSxnRUFDYkYsc0JBQVlHLGFBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQTtBQUFBLGNBcEJHZ0c7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBdUJBO0FBQUEsVUFDRCxLQTFCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJCQTtBQUFBLFVBR0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTtBQUNicEcsMEJBQVUsSUFBSTtBQUNkdUIsNEJBQVlYLFdBQVc7QUFDdkJ0Qiw2QkFBYSxJQUFJO0FBQUEsY0FDbkI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUErQztBQUFBO0FBQUEsWUFOM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMENBO0FBQUEsUUFHQSx1QkFBQyxTQUNFZ0I7QUFBQUEsd0JBQWMsYUFDYix1QkFBQyxTQUFJLFdBQVUsaUJBSVpmLHNCQUNDLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWUsSUFDYkosY0FBYzBELFVBQVUsSUFDMUIsdUJBQUMsU0FBTSxhQUFZLHFDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRCxJQUVwRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTFELGNBQWNrSDtBQUFBQSxnQkFBTyxDQUFDaEQsU0FDMUJBLEtBQUtJLGNBQ0Q2QyxZQUFZLEVBQ2JDLFNBQVM1RyxXQUFXMkcsWUFBWSxDQUFDO0FBQUEsY0FDdEM7QUFBQSxjQUNBO0FBQUE7QUFBQSxZQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1tQixLQWZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBRURoRyxjQUFjLGVBQ2IsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDRDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUVDZixZQUNDLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWUsSUFDYkosY0FBYzBELFVBQVUsSUFDMUIsdUJBQUMsU0FBTSxhQUFZLHFDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRCxJQUVwRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU0xRCxjQUFja0g7QUFBQUEsa0JBQU8sQ0FBQ2hELFNBQzFCQSxLQUFLSSxjQUNENkMsWUFBWSxFQUNiQyxTQUFTNUcsV0FBVzJHLFlBQVksQ0FBQztBQUFBLGdCQUN0QztBQUFBLGdCQUNBO0FBQUE7QUFBQSxjQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1tQjtBQUFBLGVBN0J2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdDQTtBQUFBLGFBdkRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5REE7QUFBQSxRQUdBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxtRUFDYixpQ0FBQyxlQUFZLFdBQVUsbUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSx5QkFDYnZHLG1CQUFTLDJCQUEyQiwyQkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUVGLE1BQU1WO0FBQUFBLFlBQ04sU0FBU21HO0FBQUFBLFlBQ1QsT0FBTztBQUFBLFlBRVAsaUNBQUMsVUFBSyxVQUFVTixjQUFjLFdBQVUsaUJBRXRDO0FBQUEscUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsNkRBQTREO0FBQUE7QUFBQSxrQkFDbEUsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0M7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixPQUFPNUQsU0FBU1QsZUFBZTJGO0FBQUFBLG9CQUMvQixrQkFBaUI7QUFBQSxvQkFDakIsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsUUFBUXpDLE9BQU9xQyxZQUFZLEVBQUVDLFNBQVNFLE1BQU1ILFlBQVksQ0FBQztBQUFBLG9CQUUzRCxVQUFVLENBQUNLLFFBQ1RwRixZQUFZLEVBQUUsR0FBR0QsVUFBVVQsYUFBYThGLElBQUksQ0FBQztBQUFBLG9CQUc5QzFILG9CQUFVbUU7QUFBQUEsc0JBQUksQ0FBQ3dELFFBQ2Q7QUFBQSx3QkFBQyxPQUFPO0FBQUEsd0JBQVA7QUFBQSwwQkFFQyxPQUFPQSxJQUFJdkM7QUFBQUEsMEJBQ1gsT0FBTyxHQUFHdUMsSUFBSWxELElBQUksSUFBSWtELElBQUlDLFlBQVk7QUFBQSwwQkFFdEMsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbURBQUMsU0FBSSxXQUFVLHVHQUNaRCxjQUFJbEQsS0FBS29ELE9BQU8sQ0FBQyxFQUFFQyxZQUFZLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFDQ0gsSUFBSWxEO0FBQUFBLDRCQUFLO0FBQUEsNEJBQUlrRCxJQUFJQztBQUFBQSwrQkFKcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FLQTtBQUFBO0FBQUEsd0JBVEtELElBQUl2QztBQUFBQSx3QkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVdBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQTNCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBNEJBO0FBQUEsZ0JBQ0M3QyxPQUFPeUIsWUFDTix1QkFBQyxPQUFFLFdBQVUscURBQ1g7QUFBQSx5Q0FBQyxVQUFLLFdBQVUscUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtEO0FBQUEsa0JBQ2pEekIsT0FBT3lCO0FBQUFBLHFCQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1Q0E7QUFBQSxjQUtBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDZEQUNmO0FBQUEseUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUFHO0FBQUEscUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBR2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLE9BQU8zQixTQUFTUCxTQUFTO0FBQUEsd0JBQ3pCLFVBQVUsQ0FBQ29FLE1BQ1Q1RCxZQUFZLEVBQUUsR0FBR0QsVUFBVVAsT0FBT29FLEVBQUVjLE9BQU9DLE1BQU0sQ0FBQztBQUFBLHdCQUVwRCxVQUFVbkcsU0FBUyxPQUFPO0FBQUEsd0JBRTFCO0FBQUEsaURBQUMsWUFBTyxPQUFNLElBQUcsNEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTZCO0FBQUEsMEJBQzdCLHVCQUFDLFlBQU8sT0FBTSxXQUFVLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUErQjtBQUFBLDBCQUMvQix1QkFBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBaUM7QUFBQSwwQkFDakMsdUJBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTJCO0FBQUEsMEJBQzNCLHVCQUFDLFlBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUEyQjtBQUFBLDBCQUMzQix1QkFBQyxZQUFPLE9BQU0sT0FBTSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBdUI7QUFBQSwwQkFDdkIsdUJBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXlCO0FBQUEsMEJBQ3pCLHVCQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUF5QjtBQUFBLDBCQUN6Qix1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBNkI7QUFBQSwwQkFDN0IsdUJBQUMsWUFBTyxPQUFNLGFBQVkseUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW1DO0FBQUEsMEJBQ25DLHVCQUFDLFlBQU8sT0FBTSxXQUFVLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUErQjtBQUFBLDBCQUMvQix1QkFBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBaUM7QUFBQSwwQkFDakMsdUJBQUMsWUFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUE7QUFBQTtBQUFBLHNCQXBCbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXFCQTtBQUFBLG9CQUNDeUIsT0FBT1QsU0FDTix1QkFBQyxPQUFFLFdBQVUscURBQ1g7QUFBQSw2Q0FBQyxVQUFLLFdBQVUscUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtEO0FBQUEsc0JBQ2pEUyxPQUFPVDtBQUFBQSx5QkFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBNkJBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixPQUFPTyxTQUFTTixRQUFRO0FBQUEsd0JBQ3hCLFVBQVUsQ0FBQ21FLE1BQ1Q1RCxZQUFZLEVBQUUsR0FBR0QsVUFBVU4sTUFBTWdFLE9BQU9HLEVBQUVjLE9BQU9DLEtBQUssRUFBRSxDQUFDO0FBQUEsd0JBRTNELFVBQVVuRyxTQUFTLE9BQU87QUFBQSx3QkFFMUI7QUFBQSxpREFBQyxZQUFPLE9BQU0sSUFBRywyQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBNEI7QUFBQSwwQkFDM0JpSCxNQUFNQyxLQUFLLEVBQUVwRSxRQUFRLEdBQUcsR0FBRyxDQUFDcUUsR0FBR0MsTUFBTTtBQUNwQyxrQ0FBTW5HLFFBQU8sb0JBQUlQLEtBQUssR0FBRTJHLFlBQVksSUFBSSxJQUFJRDtBQUM1QyxtQ0FDRSx1QkFBQyxZQUFrQixPQUFPbkcsTUFDdkJBLGtCQURVQSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSwwQkFFSixDQUFDO0FBQUE7QUFBQTtBQUFBLHNCQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBaUJBO0FBQUEsb0JBQ0NRLE9BQU9SLFFBQ04sdUJBQUMsT0FBRSxXQUFVLHFEQUNYO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHFDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFrRDtBQUFBLHNCQUNqRFEsT0FBT1I7QUFBQUEseUJBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXlCQTtBQUFBLHFCQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTREQTtBQUFBLG1CQWxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1FQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx5Q0FBQyxlQUFZLFdBQVUsMkJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThDO0FBQUEsa0JBQUc7QUFBQSxrQkFDMUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsc0VBQXFFLGlCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxXQUFVO0FBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaLE9BQU9NLFNBQVNIO0FBQUFBLHNCQUNoQixVQUFVLENBQUNnRSxNQUNUNUQsWUFBWSxFQUFFLEdBQUdELFVBQVVILFFBQVFnRSxFQUFFYyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLG9CQVB2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUc7QUFBQSxxQkFaTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsZ0JBUUMxRSxPQUFPTCxVQUNOLHVCQUFDLE9BQUUsV0FBVSxnREFDWDtBQUFBLHlDQUFDLFVBQUssV0FBVSxxQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQSxrQkFDakRLLE9BQU9MO0FBQUFBLHFCQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkEvQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQ0E7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDZEQUNmO0FBQUEseUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUFHO0FBQUEscUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLE9BQU9HLFNBQVNSO0FBQUFBLG9CQUNoQixVQUFVLENBQUNxRSxNQUNUNUQsWUFBWSxFQUFFLEdBQUdELFVBQVVSLFVBQVVxRSxFQUFFYyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGtCQUx6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUcsS0FQTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx5Q0FBQyxnQkFBYSxXQUFVLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQztBQUFBLGtCQUFHO0FBQUEscUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLE9BQU81RSxTQUFTTDtBQUFBQSxvQkFDaEIsVUFBVSxDQUFDMEYsUUFBUXBGLFlBQVksRUFBRSxHQUFHRCxVQUFVTCxVQUFVMEYsSUFBSSxDQUFDO0FBQUEsb0JBRTdEO0FBQUEsNkNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxRQUNuQixpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCLG9CQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUNuQixpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCLDBCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUNuQixpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCLHNCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUErQyxLQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUE7QUFBQTtBQUFBLGtCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFlQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGNBR0NyRixTQUFTTCxhQUFhLFVBQ3JCLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSw2REFDZjtBQUFBLHlDQUFDLFVBQU8sV0FBVSwyQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUM7QUFBQSxrQkFDeENLLFNBQVNMLGFBQWEsV0FDbkIsa0JBQ0E7QUFBQSxxQkFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixhQUNFSyxTQUFTTCxhQUFhLFdBQ2xCLHdCQUNBO0FBQUEsb0JBRU4sT0FBT0ssU0FBU0o7QUFBQUEsb0JBQ2hCLFVBQVUsQ0FBQ2lFLE1BQ1Q1RCxZQUFZLEVBQUUsR0FBR0QsVUFBVUosZ0JBQWdCaUUsRUFBRWMsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxrQkFWL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVdHO0FBQUEsbUJBbEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsY0FJRix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSw2REFDZjtBQUFBLHlDQUFDLGNBQVcsV0FBVSwyQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkM7QUFBQSxrQkFBRztBQUFBLHFCQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBTTtBQUFBLG9CQUNOLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osT0FBTzVFLFNBQVNGO0FBQUFBLG9CQUNoQixVQUFVLENBQUMrRCxNQUNUNUQsWUFBWSxFQUFFLEdBQUdELFVBQVVGLE1BQU0rRCxFQUFFYyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGtCQU5yRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0c7QUFBQSxtQkFaTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsY0FHQ25HLFVBQVUsdUJBQUMsU0FBSSxXQUFVLGFBQ3hCO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDZEQUNmO0FBQUEseUNBQUMsZ0JBQWEsV0FBVSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQSxrQkFBRztBQUFBLHFCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixPQUFPdUIsVUFBVUQ7QUFBQUEsb0JBQ2pCLFVBQVUsQ0FBQ3NGLFFBQVFwRixZQUFZLEVBQUUsR0FBR0QsVUFBVUQsUUFBUXNGLElBQUksQ0FBQztBQUFBLG9CQUUzRDtBQUFBLDZDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sV0FDbkIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQix1QkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0QsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sYUFDbkIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQix5QkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBa0QsS0FEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBO0FBQUE7QUFBQSxrQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWUE7QUFBQSxtQkFqQlM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQlg7QUFBQSxjQUlBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUVUNUcsbUJBQVMsMkJBQTJCO0FBQUE7QUFBQSxnQkFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsaUJBelFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMFFBO0FBQUE7QUFBQSxVQXpSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUEwUkE7QUFBQSxXQTFhRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMmFBO0FBQUEsU0E3YUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThhQTtBQUFBLE9BamJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrYkE7QUFFSjtBQUFFZixHQXJzQklELDBCQUF3QjtBQUFBc0ksS0FBeEJ0STtBQXVzQk4sZUFBZUE7QUFBeUIsSUFBQXNJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIk5hdmJhciIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiRHJhd2VyIiwiTW9kYWwiLCJFbXB0eSIsIkFsZXJ0IiwiSW9NZE1vcmUiLCJCYWNrZHJvcEJsdXJMb2FkZXIiLCJudW1iZXJUb0luZGlhbldvcmRzIiwiRmlDYWxlbmRhciIsIkZpQ3JlZGl0Q2FyZCIsIkZpSGFzaCIsIkZpRmlsZVRleHQiLCJGYVJ1cGVlU2lnbiIsIkNpcmN1bGFyTG9hZGVyIiwiR3JTdGF0dXNHb29kIiwicyIsIkxpbmsiLCJSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIiwiTWRPdXRsaW5lTWFuIiwiQnJlYWRjcnVtYiIsIlVzZXIiLCJFbXBsb3llZUFkdmFuY2VQYXltZW50SW4iLCJfcyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInRhYmxlUGF5bWVudHMiLCJzZXRUYWJsZVBheW1lbnRzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsIm9wZW5CYWNrZHJvcExvYWRlciIsInNldE9wZW5CYWNrZHJvcExvYWRlciIsImVkaXRJZCIsInNldEVkaXRJZCIsInRvdGFsQ291bnQiLCJzZXRUb3RhbENvdW50IiwicGVuZGluZyIsImNvbXBsZXRlZCIsInRhYnMiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJ0b2RheSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwiaW5pdGlhbEZvcm0iLCJlbXBsb3llZV9pZCIsInBheV9kYXRlIiwibW9udGgiLCJ5ZWFyIiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsImFtb3VudCIsIm5vdGUiLCJzdGF0dXMiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsIm5vUmVsb2FkIiwidGltZXIiLCJzZXRUaW1lb3V0IiwicHJldiIsImNsZWFyVGltZW91dCIsImZldGNoRW1wbG95ZWVzIiwiZmV0Y2hBZHZhbmNlSGlzdG9yeSIsImZldGNoVG90YWxDb3VudHMiLCJwZW5kaW5nUmVzIiwiY29tcGxldGVkUmVzIiwiUHJvbWlzZSIsImFsbCIsImdldCIsImRhdGEiLCJsZW5ndGgiLCJlcnJvciIsImNvbnNvbGUiLCJyZXMiLCJlbXBsb3llZSIsInJlc3BvbnNlIiwiZm9ybWF0dGVkIiwibWFwIiwiaXRlbSIsImluZGV4IiwiaWQiLCJkYXRlIiwiZW1wbG95ZWVOYW1lIiwibmFtZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImRheSIsInJlcGxhY2UiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwib25DbGljayIsImhhbmRsZUVkaXQiLCJzaG93RGVsZXRlQ29uZmlybSIsIl9pZCIsImVyciIsImNvbmZpcm0iLCJ0aXRsZSIsImNvbnRlbnQiLCJva1RleHQiLCJva1R5cGUiLCJjYW5jZWxUZXh0Iiwib25PayIsImhhbmRsZURlbGV0ZSIsImVtcGxveWVlSWQiLCJOdW1iZXIiLCJkZWxldGUiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJ2YWxpZGF0ZUZvcm0iLCJwdXQiLCJwb3N0IiwiY2xvc2VEcmF3ZXIiLCJlcnJzIiwiT2JqZWN0Iiwia2V5cyIsImNvbHVtbnMiLCJoZWFkZXIiLCJOQVZfTElOS1MiLCJ0byIsImljb24iLCJ0YXJnZXQiLCJ2YWx1ZSIsImxpbmsiLCJ0YWIiLCJmaWx0ZXIiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJ2YWwiLCJlbXAiLCJlbXBsb3llZUNvZGUiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsIkFycmF5IiwiZnJvbSIsIl8iLCJpIiwiZ2V0RnVsbFllYXIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBZHZhbmNlUGF5bWVudEluLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0IGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgRHJvcGRvd24sIERyYXdlciwgTW9kYWwsIEVtcHR5LCBBbGVydCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBCYWNrZHJvcEJsdXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9CYWNrZHJvcEJsdXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuaW1wb3J0IHsgRmlDYWxlbmRhciwgRmlDcmVkaXRDYXJkLCBGaUhhc2gsIEZpRmlsZVRleHQgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgRmFSdXBlZVNpZ24gfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgR3JTdGF0dXNHb29kIH0gZnJvbSBcInJlYWN0LWljb25zL2dyXCI7XHJcbmltcG9ydCB7IHMgfSBmcm9tIFwiZnJhbWVyLW1vdGlvbi9jbGllbnRcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwgfSBmcm9tIFwicmVhY3QtaWNvbnMvcmlcIjtcclxuaW1wb3J0IHsgTWRPdXRsaW5lTWFuIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IHsgVXNlciB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuXHJcbmNvbnN0IEVtcGxveWVlQWR2YW5jZVBheW1lbnRJbiA9ICgpID0+IHtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZVBheW1lbnRzLCBzZXRUYWJsZVBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW29wZW5CYWNrZHJvcExvYWRlciwgc2V0T3BlbkJhY2tkcm9wTG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWRpdElkLCBzZXRFZGl0SWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RvdGFsQ291bnQsIHNldFRvdGFsQ291bnRdID0gdXNlU3RhdGUoeyBwZW5kaW5nOiAwLCBjb21wbGV0ZWQ6IDAgfSlcclxuICBjb25zdCB0YWJzID0gW1wiUGVuZGluZ1wiLCBcIkNvbXBsZXRlZFwiXTtcclxuXHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKHRhYnNbMF0pO1xyXG5cclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcblxyXG4gIGNvbnN0IGluaXRpYWxGb3JtID0ge1xyXG4gICAgZW1wbG95ZWVfaWQ6IFwiXCIsXHJcbiAgICBwYXlfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuICAgIG1vbnRoOiBudWxsLFxyXG4gICAgeWVhcjogbnVsbCxcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgYW1vdW50OiAwLFxyXG4gICAgbm90ZTogXCJcIixcclxuICAgIHN0YXR1czogXCJcIlxyXG4gIH07XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoaW5pdGlhbEZvcm0pO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gIH0pO1xyXG5cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChhbGVydENvbmZpZy52aXNpYmlsaXR5KSB7XHJcbiAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKTtcclxuICAgICAgfSwgMzAwMCk7XHJcbiAgICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodGltZXIpO1xyXG4gICAgfVxyXG4gIH0sIFthbGVydENvbmZpZy52aXNpYmlsaXR5XSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gICAgZmV0Y2hBZHZhbmNlSGlzdG9yeSgpO1xyXG5cclxuICB9LCBbYWN0aXZlVGFiXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoVG90YWxDb3VudHMoKVxyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSlcclxuXHJcbiAgY29uc3QgZmV0Y2hUb3RhbENvdW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IFtwZW5kaW5nUmVzLCBjb21wbGV0ZWRSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgIGFwaS5nZXQoYC9hZHZhbmNlLXBheW1lbnQtaW4vc3RhdHVzL1BlbmRpbmdgKSxcclxuICAgICAgICBhcGkuZ2V0KGAvYWR2YW5jZS1wYXltZW50LWluL3N0YXR1cy9Db21wbGV0ZWRgKVxyXG4gICAgICBdKTtcclxuXHJcbiAgICAgIHNldFRvdGFsQ291bnQoe1xyXG4gICAgICAgIHBlbmRpbmc6IHBlbmRpbmdSZXMuZGF0YS5kYXRhPy5sZW5ndGggfHwgMCxcclxuICAgICAgICBjb21wbGV0ZWQ6IGNvbXBsZXRlZFJlcy5kYXRhLmRhdGE/Lmxlbmd0aCB8fCAwLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjb3VudHM6XCIsIGVycm9yKTtcclxuICAgICAgc2V0VG90YWxDb3VudCh7IHBlbmRpbmc6IDAsIGNvbXBsZXRlZDogMCB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvZW1wbG95ZWVcIik7XHJcbiAgICBpZiAocmVzLmRhdGEuc3RhdHVzKSBzZXRFbXBsb3llZXMocmVzLmRhdGEuZW1wbG95ZWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQWR2YW5jZUhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgc3RhdHVzID0gYWN0aXZlVGFiID09PSBcIlBlbmRpbmdcIiA/IFwiUGVuZGluZ1wiIDogXCJDb21wbGV0ZWRcIjtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9hZHZhbmNlLXBheW1lbnQtaW4vc3RhdHVzLyR7c3RhdHVzfWApO1xyXG5cclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gcmVzcG9uc2UuZGF0YS5kYXRhPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICBkYXRlOiBpdGVtLnBheV9kYXRlPy5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgZW1wbG95ZWVOYW1lOiBpdGVtLmVtcGxveWVlX2lkPy5uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgcGF5X2RhdGU6IG5ldyBEYXRlKGl0ZW0/LnBheV9kYXRlKT8udG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIiwge1xyXG4gICAgICAgICAgZGF5OiBcIm51bWVyaWNcIixcclxuICAgICAgICAgIG1vbnRoOiBcIjItZGlnaXRcIixcclxuICAgICAgICAgIHllYXI6IFwibnVtZXJpY1wiLFxyXG4gICAgICAgIH0pLnJlcGxhY2UoL1xcLy9nLCBcIi1cIiksXHJcbiAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICB7IGtleTogXCIxXCIsIGxhYmVsOiBcIkVkaXRcIiwgb25DbGljazogKCkgPT4gaGFuZGxlRWRpdChpdGVtKSB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICBsYWJlbDogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+RGVsZXRlPC9zcGFuPixcclxuICAgICAgICAgICAgICAgICAgb25DbGljazogKCkgPT4gc2hvd0RlbGV0ZUNvbmZpcm0oaXRlbS5faWQpLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHRleHQteGxcIiAvPlxyXG4gICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICApLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldFRhYmxlUGF5bWVudHMoZm9ybWF0dGVkKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNob3dEZWxldGVDb25maXJtID0gKGlkKSA9PiB7XHJcbiAgICBNb2RhbC5jb25maXJtKHtcclxuICAgICAgdGl0bGU6IFwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIHJlY29yZD9cIixcclxuICAgICAgY29udGVudDogXCJUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLlwiLFxyXG4gICAgICBva1RleHQ6IFwiWWVzLCBEZWxldGVcIixcclxuICAgICAgb2tUeXBlOiBcImRhbmdlclwiLFxyXG4gICAgICBjYW5jZWxUZXh0OiBcIk5vXCIsXHJcbiAgICAgIG9uT2soKSB7XHJcbiAgICAgICAgaGFuZGxlRGVsZXRlKGlkKTtcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUVkaXQgPSAoaXRlbSkgPT4ge1xyXG4gICAgY29uc3QgZW1wbG95ZWVJZCA9XHJcbiAgICAgIHR5cGVvZiBpdGVtLmVtcGxveWVlX2lkID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgPyBpdGVtLmVtcGxveWVlX2lkLl9pZFxyXG4gICAgICAgIDogaXRlbS5lbXBsb3llZV9pZDtcclxuICAgIHNldEVkaXRJZChpdGVtLl9pZCk7XHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIGVtcGxveWVlX2lkOiBlbXBsb3llZUlkLFxyXG4gICAgICBwYXlfZGF0ZTogaXRlbS5wYXlfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICBtb250aDogaXRlbS5tb250aCxcclxuICAgICAgeWVhcjogTnVtYmVyKGl0ZW0ueWVhciksXHJcbiAgICAgIHBheV90eXBlOiBpdGVtLnBheV90eXBlLFxyXG4gICAgICB0cmFuc2FjdGlvbl9pZDogaXRlbS50cmFuc2FjdGlvbl9pZCB8fCBcIlwiLFxyXG4gICAgICBhbW91bnQ6IGl0ZW0uYW1vdW50LFxyXG4gICAgICBub3RlOiBpdGVtLm5vdGUgfHwgXCJcIixcclxuICAgICAgc3RhdHVzOiBpdGVtLnN0YXR1cyxcclxuICAgIH0pO1xyXG4gICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG4gICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvYWR2YW5jZS1wYXltZW50LWluLyR7aWR9YCk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRGF0YSBEZWxldGVkIFN1Y2Nlc3NmdWxseSFcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICAgIGZldGNoQWR2YW5jZUhpc3RvcnkoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRGVsZXRlIGZhaWxlZFwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIoZmFsc2UpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGVGb3JtKCkpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIodHJ1ZSk7XHJcbiAgICAgIGlmIChlZGl0SWQpIHtcclxuICAgICAgICBhd2FpdCBhcGkucHV0KGAvYWR2YW5jZS1wYXltZW50LWluLyR7ZWRpdElkfWAsIGZvcm1EYXRhKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhd2FpdCBhcGkucG9zdChcIi9hZHZhbmNlLXBheW1lbnQtaW4vXCIsIGZvcm1EYXRhKTtcclxuICAgICAgfVxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlZGl0SWRcclxuICAgICAgICAgID8gXCJEYXRhIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5IVwiXHJcbiAgICAgICAgICA6IFwiRGF0YSBBZGRlZCBTdWNjZXNzZnVsbHkhXCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBjbG9zZURyYXdlcigpO1xyXG4gICAgICBmZXRjaEFkdmFuY2VIaXN0b3J5KCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkVycm9yIHNhdmluZyBkYXRhXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcihmYWxzZSk7XHJcbiAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBlcnJzID0ge307XHJcbiAgICBpZiAoIWZvcm1EYXRhLmVtcGxveWVlX2lkKSBlcnJzLmVtcGxveWVlID0gXCJSZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFmb3JtRGF0YS5hbW91bnQgfHwgZm9ybURhdGEuYW1vdW50IDw9IDApXHJcbiAgICAgIGVycnMuYW1vdW50ID0gXCJFbnRlciB2YWxpZCBhbW91bnRcIjtcclxuICAgIGlmICghZm9ybURhdGEubW9udGgpIGVycnMubW9udGggPSBcIlJlcXVpcmVkXCI7XHJcbiAgICBpZiAoIWZvcm1EYXRhLnllYXIpIGVycnMueWVhciA9IFwiUmVxdWlyZWRcIjtcclxuICAgIHNldEVycm9ycyhlcnJzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhlcnJzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2xvc2VEcmF3ZXIgPSAoKSA9PiB7XHJcbiAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgc2V0RWRpdElkKG51bGwpO1xyXG4gICAgc2V0Rm9ybURhdGEoaW5pdGlhbEZvcm0pO1xyXG4gICAgc2V0RXJyb3JzKHt9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGFpZCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlTmFtZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWVcIiB9LFxyXG4gICAgeyBrZXk6IFwibW9udGhcIiwgaGVhZGVyOiBcIk1vbnRoXCIgfSxcclxuICAgIHsga2V5OiBcInllYXJcIiwgaGVhZGVyOiBcIlllYXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG5cclxuICAgIHsga2V5OiBcInBheV90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IE1vZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25faWRcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIElEXCIgfSxcclxuICAgIHsga2V5OiBcIm5vdGVcIiwgaGVhZGVyOiBcIlJlbWFya3NcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIC8vIFF1aWNrIG5hdmlnYXRvciBsaW5rIGRhdGFcclxuICBjb25zdCBOQVZfTElOS1MgPSBbXHJcbiAgICB7XHJcbiAgICAgIHRvOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvc2FsYXJ5LXBheW1lbnRcIixcclxuICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwgc2l6ZT17MTZ9IC8+LFxyXG4gICAgICBsYWJlbDogXCJTYWxhcnkgcGF5bWVudFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdG86IFwiL3N0YWZmLW1lbnUvZW1wbG95ZWUtbWVudS9zYWxhcnktbWFuYWdlbWVudFwiLFxyXG4gICAgICBpY29uOiA8TWRPdXRsaW5lTWFuIHNpemU9ezE2fSAvPixcclxuICAgICAgbGFiZWw6IFwiU2FsYXJ5IG1hbmFnZW1lbnRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRvOiBcIi9zdGFmZi1tZW51L2VtcGxveWVlLW1lbnUvZW1wbG95ZWUtc3RhdGVtZW50XCIsXHJcbiAgICAgIGljb246IDxVc2VyIHNpemU9ezE2fSAvPixcclxuICAgICAgbGFiZWw6IFwiU2FsYXJ5IExlZGdlclwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdG86IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9zYWxhcnktaW5jZW50aXZlXCIsXHJcbiAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgICAgbGFiZWw6IFwiU2FsYXJ5IGluY2VudGl2ZVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdG86IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9hZGRpdGlvbmFsLXNhbGFyeVwiLFxyXG4gICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlRmlsbCBzaXplPXsxNn0gLz4sXHJcbiAgICAgIGxhYmVsOiBcIkFkZGl0aW9uYWwgc2FsYXJ5XCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7b3BlbkJhY2tkcm9wTG9hZGVyICYmIDxCYWNrZHJvcEJsdXJMb2FkZXIgdGl0bGU9XCJQcm9jZXNzaW5nLi4uXCIgLz59XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjAgbWluLWgtc2NyZWVuXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBweC02XCI+XHJcbiAgICAgICAgICA8TmF2YmFyIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfSB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG5cclxuICAgICAgICAgIHthbGVydENvbmZpZy52aXNpYmlsaXR5ICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtNSBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIHotWzEwMDBdIHctZnVsbCBtYXgtdy1tZCBweC00XCI+XHJcbiAgICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgICAgIHNob3dJY29uXHJcbiAgICAgICAgICAgICAgICBjbG9zYWJsZVxyXG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWxlcnRDb25maWcoeyAuLi5hbGVydENvbmZpZywgdmlzaWJpbGl0eTogZmFsc2UgfSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zXCI+XHJcbiAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTRcIj5FbXBsb3llZSBBZHZhbmNlIFJlcGF5bWVudDwvaDE+XHJcblxyXG4gICAgICAgICAgICB7Lyog4pSA4pSAIFF1aWNrIE5hdmlnYXRvciDilIDilIAgKi99XHJcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWdyYXktNDAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgIFF1aWNrIG5hdmlnYXRvclxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICB7TkFWX0xJTktTLm1hcCgobGluaykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIGtleT17bGluay50b31cclxuICAgICAgICAgICAgICAgICAgICB0bz17bGluay50b31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHRleHQtc20gdGV4dC1ncmF5LTYwMCBob3Zlcjpib3JkZXItYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIj57bGluay5pY29ufTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB7bGluay5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgey8qIFRhYiBCdXR0b25zICovfVxyXG4gICAgICAgICAgey8qIFRhYiBIZWFkZXIgd2l0aCBSaWdodC1BbGlnbmVkIEFkZCBCdXR0b24gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgbWItNiBtdC02XCI+XHJcbiAgICAgICAgICAgIHsvKiBUYWJzIG9uIHRoZSBsZWZ0ICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cclxuICAgICAgICAgICAgICB7dGFicy5tYXAoKHRhYikgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBrZXk9e3RhYn1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIGZvbnQtbWVkaXVtICR7YWN0aXZlVGFiID09PSB0YWJcclxuICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLWItMiBib3JkZXItYmx1ZS02MDAgdGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtZ3JheS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIodGFiKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3RhYiA9PT0gXCJQZW5kaW5nXCIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgIFBlbmRpbmd7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtNTAwIHRleHQtd2hpdGUgdGV4dC1bMTJweF0gcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0b3RhbENvdW50Py5wZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDb21wbGV0ZWR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSB0ZXh0LVsxMnB4XSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3RvdGFsQ291bnQ/LmNvbXBsZXRlZH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBBZGQgYnV0dG9uIG9uIHRoZSByaWdodCAqL31cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldEVkaXRJZChudWxsKTtcclxuICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKGluaXRpYWxGb3JtKTtcclxuICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgbWItM1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICArIEFkZCBBZHZhbmNlXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFRhYiBDb250ZW50ICovfVxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJQZW5kaW5nXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICAgICAgICApIDogdGFibGVQYXltZW50cy5sZW5ndGggPD0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgPEVtcHR5IGRlc2NyaXB0aW9uPVwiTm8gQWR2YW5jZSBSZXBheW1lbnQgRGF0YSBGb3VuZFwiIC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17dGFibGVQYXltZW50cy5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtLmVtcGxveWVlTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/LnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcIkNvbXBsZXRlZFwiICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgey8qIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+RW1wbG95ZWUgQWR2YW5jZSBSZXBheW1lbnQ8L2gxPiAqL31cclxuICAgICAgICAgICAgICAgICAgey8qIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgey8qIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+RW1wbG95ZWUgQWR2YW5jZSBSZXBheW1lbnQ8L2gxPiAqL31cclxuICAgICAgICAgICAgICAgICAgey8qIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0SWQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShpbml0aWFsRm9ybSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICsgQWRkIEFkdmFuY2VcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz5cclxuICAgICAgICAgICAgICAgICkgOiB0YWJsZVBheW1lbnRzLmxlbmd0aCA8PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICA8RW1wdHkgZGVzY3JpcHRpb249XCJObyBBZHZhbmNlIFJlcGF5bWVudCBEYXRhIEZvdW5kXCIgLz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICBkYXRhPXt0YWJsZVBheW1lbnRzLmZpbHRlcigoaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGl0ZW0uZW1wbG95ZWVOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8udG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRHJhd2VyIEZvcm0gKi99XHJcbiAgICAgICAgICA8RHJhd2VyXHJcbiAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctYmx1ZS0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8RmFSdXBlZVNpZ24gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZWRpdElkID8gXCJFZGl0IEFkdmFuY2UgUmVwYXltZW50XCIgOiBcIk5ldyBBZHZhbmNlIFJlcGF5bWVudFwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9wZW49e3Nob3dNb2RhbH1cclxuICAgICAgICAgICAgb25DbG9zZT17Y2xvc2VEcmF3ZXJ9XHJcbiAgICAgICAgICAgIHdpZHRoPXs0ODB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNiBwLTFcIj5cclxuICAgICAgICAgICAgICB7LyogRW1wbG95ZWUgU2VsZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVtcGxveWVlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGFuZCBzZWxlY3QgZW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1wbG95ZWVfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwibGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbj8ubGFiZWw/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBlbXBsb3llZV9pZDogdmFsIH0pXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2VtcC5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1wLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtgJHtlbXAubmFtZX0gJHtlbXAuZW1wbG95ZWVDb2RlfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYmctYmx1ZS0xMDAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX0gfCB7ZW1wLmVtcGxveWVlQ29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1wbG95ZWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xIGgtMSBiZy1yZWQtNTAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtcGxveWVlfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgIHsvKiBBZHZhbmNlIFJlUGF5bWVudCBNb250aCAmIFllYXIgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPEZpQ2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgTW9udGggJiBZZWFyXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIE1vbnRoICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtMyBweS0yLjUgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm1vbnRoIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIG1vbnRoOiBlLnRhcmdldC52YWx1ZSB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2VkaXRJZCA/IHRydWUgOiBmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IE1vbnRoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSmFudWFyeVwiPkphbnVhcnk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJGZWJydWFyeVwiPkZlYnJ1YXJ5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTWFyY2hcIj5NYXJjaDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFwcmlsXCI+QXByaWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNYXlcIj5NYXk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJKdW5lXCI+SnVuZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkp1bHlcIj5KdWx5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQXVndXN0XCI+QXVndXN0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU2VwdGVtYmVyXCI+U2VwdGVtYmVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT2N0b2JlclwiPk9jdG9iZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJOb3ZlbWJlclwiPk5vdmVtYmVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRGVjZW1iZXJcIj5EZWNlbWJlcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubW9udGggJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC0xIGJnLXJlZC01MDAgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm1vbnRofVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICB7LyogWWVhciAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTMgcHktMi41IHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS55ZWFyIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHllYXI6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0SWQgPyB0cnVlIDogZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBZZWFyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogMTAgfSwgKF8sIGkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKSAtIDUgKyBpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt5ZWFyfSB2YWx1ZT17eWVhcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eWVhcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMueWVhciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTEgYmctcmVkLTUwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMueWVhcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogQW1vdW50ICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICBBbW91bnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtNCB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHBsLTggcHItNCBweS0yLjUgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMC4wMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBhbW91bnQ6IGUudGFyZ2V0LnZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7Lyoge2Zvcm1EYXRhLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHJvdW5kZWQtbGcgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5hbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfSAqL31cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC0xIGJnLXJlZC01MDAgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogUGF5bWVudCBEYXRlICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGaUNhbGVuZGFyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBwYXlfZGF0ZTogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFBheW1lbnQgTW9kZSAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8RmlDcmVkaXRDYXJkIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV90eXBlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgcGF5X3R5cGU6IHZhbCB9KX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjYXNoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPkNhc2g8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5PbmxpbmUvVVBJPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjaGVxdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+Q2hlcXVlPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogVHJhbnNhY3Rpb24vQ2hlcXVlIElEICovfVxyXG4gICAgICAgICAgICAgIHtmb3JtRGF0YS5wYXlfdHlwZSAhPT0gXCJjYXNoXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgYW5pbWF0ZS1mYWRlSW5cIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGaUhhc2ggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEucGF5X3R5cGUgPT09IFwiY2hlcXVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJDaGVxdWUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJUcmFuc2FjdGlvbiBJRFwifVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEucGF5X3R5cGUgPT09IFwiY2hlcXVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkVudGVyIGNoZXF1ZSBudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiRW50ZXIgdHJhbnNhY3Rpb24vVVBJIElEXCJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHRyYW5zYWN0aW9uX2lkOiBlLnRhcmdldC52YWx1ZSB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiDwn5GHIE5vdGUgRmllbGQgKE9wdGlvbmFsKSAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8RmlGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICBOb3RlIChPcHRpb25hbClcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvbiByZXNpemUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGFueSByZW1hcmtzIG9yIHJlZmVyZW5jZS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbm90ZTogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFN0YXR1cyAqL31cclxuICAgICAgICAgICAgICB7ZWRpdElkICYmIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxHclN0YXR1c0dvb2QgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHN0YXR1czogdmFsIH0pfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlBlbmRpbmdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+UGVuZGluZzwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQ29tcGxldGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPkNvbXBsZXRlZDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj59XHJcblxyXG5cclxuICAgICAgICAgICAgICB7LyogU3VibWl0IEJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWJsdWUtNzAwIHRleHQtd2hpdGUgcHktMyByb3VuZGVkLWxnIGhvdmVyOmZyb20tYmx1ZS03MDAgaG92ZXI6dG8tYmx1ZS04MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGZvbnQtc2VtaWJvbGQgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2Zvcm0gaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtlZGl0SWQgPyBcIlVwZGF0ZSBBZHZhbmNlIFBheW1lbnRcIiA6IFwiU2F2ZSBBZHZhbmNlIFBheW1lbnRcIn1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L0RyYXdlcj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRW1wbG95ZWVBZHZhbmNlUGF5bWVudEluOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9BZHZhbmNlUGF5bWVudEluLmpzeCJ9