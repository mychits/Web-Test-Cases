import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ViewCustomerTransactions.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Drawer, Spin, Button } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
const ViewCustomerTransactions = ({ customerId, visible, onClose }) => {
  _s();
  const [customerTransactions, setCustomerTransactions] = useState({
    chit_accounts: [],
    last_transactions_per_group: [],
    last_transactions_per_loan: [],
    loan_summary: [],
    pigme_summary: [],
    user: null
  });
  const [showDrawer, setShowDrawer] = useState(false);
  const [loadingTransactions, setLoadingTransactions] = useState(false);
  const [showAllChits, setShowAllChits] = useState(false);
  const [showAllGroupTxns, setShowAllGroupTxns] = useState(false);
  const [showAllLoanTxns, setShowAllLoanTxns] = useState(false);
  const [showAllLoanSummary, setShowAllLoanSummary] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const fetchTransactions = async () => {
    if (!customerId) return;
    try {
      setLoadingTransactions(true);
      const res = await api.get(`/enroll/loan-chit-summary/${customerId}`);
      if (res.data.status && res.data) {
        setCustomerTransactions({
          chit_accounts: res.data.chit_accounts || [],
          last_transactions_per_group: res.data.last_transactions_per_group || [],
          last_transactions_per_loan: res.data.last_transactions_per_loan || [],
          loan_summary: res.data.loan_summary || [],
          pigme_summary: res.data.pigme_summary || [],
          user: res.data.user || null
        });
        setShowDrawer(true);
      } else {
        setAlertConfig({
          visibility: true,
          message: "No data found for this customer.",
          type: "warning"
        });
      }
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: error?.response?.data?.message || "Something went wrong!",
        type: "error"
      });
      console.error("Failed to fetch transactions", error);
    } finally {
      setLoadingTransactions(false);
    }
  };
  useEffect(() => {
    if (visible) fetchTransactions();
  }, [visible, customerId]);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    alertConfig.visibility && /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
        lineNumber: 76,
        columnNumber: 7
      },
      this
    ),
    showDrawer && /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        open: visible,
        onClose,
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold text-gray-700", children: "Customer Transactions" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 93,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-blue-700 font-semibold text-sm bg-blue-50 px-3 py-1 rounded-full", children: "Customer Name  -  " + customerTransactions?.user?.full_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 98,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
          lineNumber: 90,
          columnNumber: 9
        }, this),
        className: "z-50",
        width: 800,
        children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col h-full", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto px-4 pb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
          customerTransactions?.chit_accounts?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-800 mb-3", children: "Chit Accounts Summary" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 114,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", style: { maxHeight: "300px", overflowY: "auto" }, children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "sticky top-0 bg-white", children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b", children: [
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Group Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 123,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Group Value" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 124,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 125,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Prized" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 126,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Total to Pay" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 127,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Paid" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 128,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Balance" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 129,
                  columnNumber: 57
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 122,
                columnNumber: 53
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 121,
                columnNumber: 49
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: customerTransactions.chit_accounts.slice(0, showAllChits ? customerTransactions.chit_accounts.length : 2).map(
                (account, index) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: account?.group.group_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 136,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: [
                    "₹",
                    account?.group.group_value
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 137,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: account?.ticket }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 138,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-1 rounded text-xs ${account?.isPrized ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`, children: account.isPrized ? "Yes" : "No" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 140,
                    columnNumber: 65
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 139,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: [
                    "₹",
                    account?.totals.totalBePaid
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 147,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: [
                    "₹",
                    account?.totals.paid
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 148,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: `py-2 px-3 font-medium ${account?.totals.balance >= 0 ? "text-red-600" : "text-green-600"}`, children: [
                    "₹",
                    account?.totals.balance
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 149,
                    columnNumber: 61
                  }, this)
                ] }, index, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 135,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 132,
                columnNumber: 49
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 120,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 119,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 113,
            columnNumber: 15
          }, this),
          customerTransactions?.chit_accounts?.length > 2 && /* @__PURE__ */ jsxDEV("div", { className: "text-center ", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setShowAllChits(!showAllChits),
              className: "text-blue-600 text-sm font-medium",
              children: showAllChits ? "▲ Show Less" : "▼ Show More"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 164,
              columnNumber: 41
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 163,
            columnNumber: 15
          }, this),
          customerTransactions?.loan_summary?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-800 mb-3", children: "Loan Summary" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 177,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", style: { maxHeight: "300px", overflowY: "auto" }, children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "sticky top-0 bg-white", children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b", children: [
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Loan ID" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 186,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Loan Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 187,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Start date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 188,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "End date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 189,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Paid" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 190,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Balance" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 191,
                  columnNumber: 57
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 185,
                columnNumber: 53
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 184,
                columnNumber: 49
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: customerTransactions.loan_summary.slice(0, showAllLoanSummary ? customerTransactions?.loan_summary?.length : 2).map(
                (loan, index) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: loan?.loan_id }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 199,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: [
                    "₹",
                    loan?.loan_amount
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 200,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: new Date(loan?.start_date).toLocaleDateString("en-GB", {
                    day: "2-digit",
                    month: "short",
                    // "Jan", "Feb", "Mar", etc.
                    year: "numeric"
                  }) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 201,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: new Date(loan?.end_date).toLocaleDateString("en-GB", {
                    day: "2-digit",
                    month: "short",
                    year: "numeric"
                  }) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 208,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: [
                    "₹",
                    loan?.total_paid_amount
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 215,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: `py-2 px-3 font-medium ${loan?.balance >= 0 ? "text-red-600" : "text-green-600"}`, children: [
                    "₹",
                    loan?.balance
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 217,
                    columnNumber: 61
                  }, this)
                ] }, index, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 198,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 194,
                columnNumber: 49
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 183,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 182,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 176,
            columnNumber: 15
          }, this),
          customerTransactions?.pigme_summary?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-800 mb-3", children: "Pigmy Summary" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 234,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", style: { maxHeight: "300px", overflowY: "auto" }, children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "sticky top-0 bg-white", children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b", children: [
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Pigmy ID" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 243,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Start date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 244,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Pigmy Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 245,
                  columnNumber: 57
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 242,
                columnNumber: 53
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 241,
                columnNumber: 49
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: customerTransactions.pigme_summary.slice(0, showAllLoanSummary ? customerTransactions?.pigme_summary?.length : 2).map(
                (pigmy, index) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: pigmy?.pigme_id }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 253,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: new Date(pigmy?.start_date).toLocaleDateString("en-GB", {
                    day: "2-digit",
                    month: "short",
                    // "Jan", "Feb", "Mar", etc.
                    year: "numeric"
                  }) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 254,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: `py-2 px-3 font-medium ${pigmy?.total_paid_amount >= 0 ? "text-green-600" : "text-red-600"}`, children: [
                    "₹",
                    pigmy?.total_paid_amount
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 261,
                    columnNumber: 61
                  }, this)
                ] }, index, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 252,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 248,
                columnNumber: 49
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 240,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 239,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 233,
            columnNumber: 15
          }, this),
          customerTransactions?.last_transactions_per_group?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-800 mb-3", children: "Recent Group Transactions" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 276,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", style: { maxHeight: "300px", overflowY: "auto" }, children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "sticky top-0 bg-white", children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b", children: [
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Group Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 285,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 286,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Receipt No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 287,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 288,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 289,
                  columnNumber: 57
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 284,
                columnNumber: 53
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 283,
                columnNumber: 49
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: (customerTransactions?.last_transactions_per_group.slice(0, showAllGroupTxns ? customerTransactions.last_transactions_per_group.length : 2)).map((group, index) => {
                const firstTxn = group.transactions?.[0];
                return /* @__PURE__ */ jsxDEV("tr", { className: "border-b hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: group?.group_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 300,
                    columnNumber: 65
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: group?.ticket }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 301,
                    columnNumber: 65
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: firstTxn?.receipt_no }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 302,
                    columnNumber: 65
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: [
                    "₹",
                    firstTxn?.amount
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 303,
                    columnNumber: 65
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: new Date(firstTxn?.createdAt).toLocaleDateString("en-GB", {
                    day: "2-digit",
                    month: "short",
                    // "Jan", "Feb", "Mar", etc.
                    year: "numeric"
                  }) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 304,
                    columnNumber: 70
                  }, this)
                ] }, index, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 299,
                  columnNumber: 27
                }, this);
              }) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 292,
                columnNumber: 49
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 282,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 281,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 275,
            columnNumber: 15
          }, this),
          customerTransactions?.last_transactions_per_group.length > 2 && /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setShowAllGroupTxns(!showAllGroupTxns),
              className: "text-blue-600 text-sm font-medium",
              children: showAllGroupTxns ? "▲ Show Less" : "▼ Show More"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 321,
              columnNumber: 41
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 320,
            columnNumber: 15
          }, this),
          customerTransactions?.last_transactions_per_loan?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-800 mb-3", children: "Recent Loan Transactions" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 333,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", style: { maxHeight: "300px", overflowY: "auto" }, children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "sticky top-0 bg-white", children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b", children: [
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Loan ID" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 342,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Receipt No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 343,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 344,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "text-left py-2 px-3", children: "Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 345,
                  columnNumber: 57
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 341,
                columnNumber: 53
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 340,
                columnNumber: 49
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: customerTransactions.last_transactions_per_loan.slice(0, showAllLoanTxns ? customerTransactions.last_transactions_per_loan.length : 2).map((loan, index) => {
                const firstTxn = loan.transactions?.[0];
                return /* @__PURE__ */ jsxDEV("tr", { className: "border-b hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: loan?.loan_id || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 356,
                    columnNumber: 65
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: firstTxn?.receipt_no }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 357,
                    columnNumber: 65
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: [
                    "₹",
                    firstTxn?.amount
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 358,
                    columnNumber: 65
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: new Date(firstTxn?.createdAt).toLocaleDateString("en-GB", {
                    day: "2-digit",
                    month: "short",
                    // "Jan", "Feb", "Mar", etc.
                    year: "numeric"
                  }) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                    lineNumber: 359,
                    columnNumber: 70
                  }, this)
                ] }, index, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                  lineNumber: 355,
                  columnNumber: 27
                }, this);
              }) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
                lineNumber: 348,
                columnNumber: 49
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 339,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
              lineNumber: 338,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 332,
            columnNumber: 15
          }, this),
          (!customerTransactions?.chit_accounts || customerTransactions.chit_accounts.length === 0) && (!customerTransactions?.last_transactions_per_group || customerTransactions.last_transactions_per_group.length === 0) && (!customerTransactions?.last_transactions_per_loan || customerTransactions.last_transactions_per_loan.length === 0) && (!customerTransactions?.loan_summary || customerTransactions.loan_summary.length === 0) && /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No transaction data available for this customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 383,
            columnNumber: 45
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
            lineNumber: 382,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
          lineNumber: 110,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
          lineNumber: 109,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
          lineNumber: 107,
          columnNumber: 21
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
        lineNumber: 86,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx",
    lineNumber: 74,
    columnNumber: 5
  }, this);
};
_s(ViewCustomerTransactions, "ONAzR7X8oq95N+R5AyMuS9uS2Lw=");
_c = ViewCustomerTransactions;
export default ViewCustomerTransactions;
var _c;
$RefreshReg$(_c, "ViewCustomerTransactions");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ViewCustomerTransactions.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkVnQjsyQkEzRWhCO0FBQWdCQSxNQUFXQyxjQUFRLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbEQsU0FBU0MsUUFBUUMsTUFBTUMsY0FBYztBQUNyQyxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLHVCQUF1QjtBQUU5QixNQUFNQywyQkFBMkJBLENBQUMsRUFBRUMsWUFBWUMsU0FBU0MsUUFBUSxNQUFNO0FBQUFDLEtBQUE7QUFDbkUsUUFBTSxDQUFDQyxzQkFBc0JDLHVCQUF1QixJQUFJWixTQUFTO0FBQUEsSUFDN0RhLGVBQWU7QUFBQSxJQUNmQyw2QkFBNkI7QUFBQSxJQUM3QkMsNEJBQTRCO0FBQUEsSUFDNUJDLGNBQWM7QUFBQSxJQUNkQyxlQUFlO0FBQUEsSUFDZkMsTUFBTTtBQUFBLEVBQ1YsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJcEIsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ3FCLHFCQUFxQkMsc0JBQXNCLElBQUl0QixTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDdUIsY0FBY0MsZUFBZSxJQUFJeEIsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ3lCLGtCQUFrQkMsbUJBQW1CLElBQUkxQixTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDMkIsaUJBQWlCQyxrQkFBa0IsSUFBSTVCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM2QixvQkFBb0JDLHFCQUFxQixJQUFJOUIsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQytCLGFBQWFDLGNBQWMsSUFBSWhDLFNBQVM7QUFBQSxJQUMzQ2lDLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1YsQ0FBQztBQUdELFFBQU1DLG9CQUFvQixZQUFZO0FBQ2xDLFFBQUksQ0FBQzdCLFdBQVk7QUFFakIsUUFBSTtBQUNBZSw2QkFBdUIsSUFBSTtBQUMzQixZQUFNZSxNQUFNLE1BQU1qQyxJQUFJa0MsSUFBSSw2QkFBNkIvQixVQUFVLEVBQUU7QUFFbkUsVUFBSThCLElBQUlFLEtBQUtDLFVBQVVILElBQUlFLE1BQU07QUFDN0IzQixnQ0FBd0I7QUFBQSxVQUNwQkMsZUFBZXdCLElBQUlFLEtBQUsxQixpQkFBaUI7QUFBQSxVQUN6Q0MsNkJBQTZCdUIsSUFBSUUsS0FBS3pCLCtCQUErQjtBQUFBLFVBQ3JFQyw0QkFBNEJzQixJQUFJRSxLQUFLeEIsOEJBQThCO0FBQUEsVUFDbkVDLGNBQWNxQixJQUFJRSxLQUFLdkIsZ0JBQWdCO0FBQUEsVUFDdkNDLGVBQWVvQixJQUFJRSxLQUFLdEIsaUJBQWlCO0FBQUEsVUFDekNDLE1BQU1tQixJQUFJRSxLQUFLckIsUUFBUTtBQUFBLFFBQzNCLENBQUM7QUFHREUsc0JBQWMsSUFBSTtBQUFBLE1BQ3RCLE9BQU87QUFDSFksdUJBQWU7QUFBQSxVQUNYQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNWLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDSixTQUFTTSxPQUFPO0FBQ1pULHFCQUFlO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLFNBQVNPLE9BQU9DLFVBQVVILE1BQU1MLFdBQVc7QUFBQSxRQUMzQ0MsTUFBTTtBQUFBLE1BQ1YsQ0FBQztBQUNEUSxjQUFRRixNQUFNLGdDQUFnQ0EsS0FBSztBQUFBLElBQ3ZELFVBQUM7QUFDR25CLDZCQUF1QixLQUFLO0FBQUEsSUFDaEM7QUFBQSxFQUNKO0FBR0F2QixZQUFVLE1BQU07QUFDWixRQUFJUyxRQUFTNEIsbUJBQWtCO0FBQUEsRUFDbkMsR0FBRyxDQUFDNUIsU0FBU0QsVUFBVSxDQUFDO0FBR3hCLFNBRUksdUJBQUMsU0FDSXdCO0FBQUFBLGdCQUFZRSxjQUNUO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxNQUFNRixZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ0xGLGVBQWUsQ0FBQ1ksVUFBVSxFQUFFLEdBQUdBLE1BQU1YLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUxqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNSztBQUFBLElBR1JkLGNBQ0c7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQU1YO0FBQUFBLFFBQ047QUFBQSxRQUNBLE9BQ0ksdUJBQUMsU0FBSSxXQUFVLDRDQUdYO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHVDQUFzQyxxQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBR0EsdUJBQUMsVUFBSyxXQUFVLHlFQUNWLGlDQUF5Qkcsc0JBQXNCTyxNQUFNMkIsYUFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFFSixXQUFVO0FBQUEsUUFDVixPQUFPO0FBQUEsUUFFUCxpQ0FBQyxTQUFJLFdBQVUsd0JBRVgsaUNBQUMsU0FBSSxXQUFVLG9DQUNYLGlDQUFDLFNBQUksV0FBVSxhQUVWbEM7QUFBQUEsZ0NBQXNCRSxlQUFlaUMsU0FBUyxLQUMzQyx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNENBQTJDLHFDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCLE9BQU8sRUFBRUMsV0FBVyxTQUFTQyxXQUFXLE9BQU8sR0FDNUUsaUNBQUMsV0FBTSxXQUFVLHNCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLHlCQUNiLGlDQUFDLFFBQUcsV0FBVSxZQUNWO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHVCQUFzQiwwQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEM7QUFBQSxnQkFDOUMsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQiwyQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0M7QUFBQSxnQkFDL0MsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQixzQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEM7QUFBQSxnQkFDMUMsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQixzQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEM7QUFBQSxnQkFDMUMsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQiw0QkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQSxnQkFDaEQsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQixvQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0M7QUFBQSxnQkFDeEMsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQix1QkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxtQkFQL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQSxLQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLFdBRUtyQywrQkFBcUJFLGNBQWNvQyxNQUFNLEdBQUcxQixlQUFlWixxQkFBcUJFLGNBQWNpQyxTQUFTLENBQUMsRUFBR0k7QUFBQUEsZ0JBQUksQ0FBQ0MsU0FBU0MsVUFDdkgsdUJBQUMsUUFBZSxXQUFVLDZCQUN0QjtBQUFBLHlDQUFDLFFBQUcsV0FBVSxhQUFhRCxtQkFBU0UsTUFBTUMsY0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUQ7QUFBQSxrQkFDckQsdUJBQUMsUUFBRyxXQUFVLGFBQVk7QUFBQTtBQUFBLG9CQUFFSCxTQUFTRSxNQUFNRTtBQUFBQSx1QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUQ7QUFBQSxrQkFDdkQsdUJBQUMsUUFBRyxXQUFVLGFBQWFKLG1CQUFTSyxVQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBLGtCQUMzQyx1QkFBQyxRQUFHLFdBQVUsYUFDVixpQ0FBQyxVQUFLLFdBQVcsNkJBQTZCTCxTQUFTTSxXQUNqRCxnQ0FDQSwyQkFBMkIsSUFFNUJOLGtCQUFRTSxXQUFXLFFBQVEsUUFKaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsYUFBWTtBQUFBO0FBQUEsb0JBQUVOLFNBQVNPLE9BQU9DO0FBQUFBLHVCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLGtCQUN4RCx1QkFBQyxRQUFHLFdBQVUsYUFBWTtBQUFBO0FBQUEsb0JBQUVSLFNBQVNPLE9BQU9FO0FBQUFBLHVCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRDtBQUFBLGtCQUNqRCx1QkFBQyxRQUFHLFdBQVcseUJBQXlCVCxTQUFTTyxPQUFPRyxXQUFXLElBQzdELGlCQUNBLGdCQUFnQixJQUNkO0FBQUE7QUFBQSxvQkFDRlYsU0FBU08sT0FBT0c7QUFBQUEsdUJBSnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxxQkFuQktULE9BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFvQkE7QUFBQSxjQUNILEtBeEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUEsaUJBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0NBLEtBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0NBO0FBQUEsZUE5Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQ0E7QUFBQSxVQUVIekMsc0JBQXNCRSxlQUFlaUMsU0FBUyxLQUMzQyx1QkFBQyxTQUFJLFdBQVUsZ0JBQ1g7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVMsTUFBTXRCLGdCQUFnQixDQUFDRCxZQUFZO0FBQUEsY0FDNUMsV0FBVTtBQUFBLGNBRVRBLHlCQUFlLGdCQUFnQjtBQUFBO0FBQUEsWUFKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0EsS0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFLSFosc0JBQXNCSyxjQUFjOEIsU0FBUyxLQUMxQyx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNENBQTJDLDRCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCLE9BQU8sRUFBRUMsV0FBVyxTQUFTQyxXQUFXLE9BQU8sR0FDNUUsaUNBQUMsV0FBTSxXQUFVLHNCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLHlCQUNiLGlDQUFDLFFBQUcsV0FBVSxZQUNWO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHVCQUFzQix1QkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxnQkFDM0MsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQiwyQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0M7QUFBQSxnQkFDL0MsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQiwwQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEM7QUFBQSxnQkFDOUMsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQix3QkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEM7QUFBQSxnQkFDNUMsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQixvQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0M7QUFBQSxnQkFDeEMsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQix1QkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxtQkFOL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQSxLQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNBLHVCQUFDLFdBQ0tyQywrQkFBcUJLLGFBQ2xCaUMsTUFBTSxHQUFHcEIscUJBQXFCbEIsc0JBQXNCSyxjQUFjOEIsU0FBUyxDQUFDLEVBQy9FSTtBQUFBQSxnQkFBSSxDQUFDWSxNQUFNVixVQUNULHVCQUFDLFFBQWUsV0FBVSw2QkFDdEI7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsYUFBYVUsZ0JBQU1DLFdBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlDO0FBQUEsa0JBQ3pDLHVCQUFDLFFBQUcsV0FBVSxhQUFZO0FBQUE7QUFBQSxvQkFBRUQsTUFBTUU7QUFBQUEsdUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThDO0FBQUEsa0JBQzlDLHVCQUFDLFFBQUcsV0FBVSxhQUNULGNBQUlDLEtBQUtILE1BQU1JLFVBQVUsRUFBRUMsbUJBQW1CLFNBQVM7QUFBQSxvQkFDcERDLEtBQUs7QUFBQSxvQkFDTEMsT0FBTztBQUFBO0FBQUEsb0JBQ1BDLE1BQU07QUFBQSxrQkFDVixDQUFDLEtBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNULGNBQUlMLEtBQUtILE1BQU1TLFFBQVEsRUFBRUosbUJBQW1CLFNBQVM7QUFBQSxvQkFDbERDLEtBQUs7QUFBQSxvQkFDTEMsT0FBTztBQUFBLG9CQUNQQyxNQUFNO0FBQUEsa0JBQ1YsQ0FBQyxLQUxMO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsYUFBWTtBQUFBO0FBQUEsb0JBQUVSLE1BQU1VO0FBQUFBLHVCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRDtBQUFBLGtCQUVwRCx1QkFBQyxRQUFHLFdBQVcseUJBQXlCVixNQUFNRCxXQUFXLElBQ25ELGlCQUNBLGdCQUFnQixJQUNkO0FBQUE7QUFBQSxvQkFDRkMsTUFBTUQ7QUFBQUEsdUJBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLHFCQXhCS1QsT0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlCQTtBQUFBLGNBQ0gsS0E5Qkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErQkE7QUFBQSxpQkExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQ0EsS0E1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2Q0E7QUFBQSxlQW5ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9EQTtBQUFBLFVBSUh6QyxzQkFBc0JNLGVBQWU2QixTQUFTLEtBQzNDLHVCQUFDLFNBQUksV0FBVSw2QkFDWDtBQUFBLG1DQUFDLFFBQUcsV0FBVSw0Q0FBMkMsNkJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsT0FBTyxFQUFFQyxXQUFXLFNBQVNDLFdBQVcsT0FBTyxHQUM1RSxpQ0FBQyxXQUFNLFdBQVUsc0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUseUJBQ2IsaUNBQUMsUUFBRyxXQUFVLFlBQ1Y7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsdUJBQXNCLHdCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QztBQUFBLGdCQUM1Qyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLDBCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QztBQUFBLGdCQUM5Qyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLDRCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRDtBQUFBLG1CQUhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGNBQ0EsdUJBQUMsV0FDS3JDLCtCQUFxQk0sY0FDbEJnQyxNQUFNLEdBQUdwQixxQkFBcUJsQixzQkFBc0JNLGVBQWU2QixTQUFTLENBQUMsRUFDaEZJO0FBQUFBLGdCQUFJLENBQUN1QixPQUFPckIsVUFDVix1QkFBQyxRQUFlLFdBQVUsNkJBQ3RCO0FBQUEseUNBQUMsUUFBRyxXQUFVLGFBQWFxQixpQkFBT0MsWUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkM7QUFBQSxrQkFDM0MsdUJBQUMsUUFBRyxXQUFVLGFBQ1QsY0FBSVQsS0FBS1EsT0FBT1AsVUFBVSxFQUFFQyxtQkFBbUIsU0FBUztBQUFBLG9CQUNyREMsS0FBSztBQUFBLG9CQUNMQyxPQUFPO0FBQUE7QUFBQSxvQkFDUEMsTUFBTTtBQUFBLGtCQUNWLENBQUMsS0FMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFXLHlCQUF5QkcsT0FBT0QscUJBQXFCLElBQzlELG1CQUNBLGNBQWMsSUFDWDtBQUFBO0FBQUEsb0JBQUVDLE9BQU9EO0FBQUFBLHVCQUhsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdvQztBQUFBLHFCQVovQnBCLE9BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLGNBQ0gsS0FsQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkE7QUFBQSxpQkEzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkEsS0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4QkE7QUFBQSxlQXBDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFDQTtBQUFBLFVBSUh6QyxzQkFBc0JHLDZCQUE2QmdDLFNBQVMsS0FDekQsdUJBQUMsU0FBSSxXQUFVLDZCQUNYO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDRDQUEyQyx5Q0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixPQUFPLEVBQUVDLFdBQVcsU0FBU0MsV0FBVyxPQUFPLEdBQzVFLGlDQUFDLFdBQU0sV0FBVSxzQkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSx5QkFDYixpQ0FBQyxRQUFHLFdBQVUsWUFDVjtBQUFBLHVDQUFDLFFBQUcsV0FBVSx1QkFBc0IsMEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThDO0FBQUEsZ0JBQzlDLHVCQUFDLFFBQUcsV0FBVSx1QkFBc0Isc0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsZ0JBQzFDLHVCQUFDLFFBQUcsV0FBVSx1QkFBc0IsMEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThDO0FBQUEsZ0JBQzlDLHVCQUFDLFFBQUcsV0FBVSx1QkFBc0Isc0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsZ0JBQzFDLHVCQUFDLFFBQUcsV0FBVSx1QkFBc0Isb0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdDO0FBQUEsbUJBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxXQUNLckMsaUNBQXNCRyw0QkFDbkJtQyxNQUFNLEdBQUd4QixtQkFBbUJkLHFCQUFxQkcsNEJBQTRCZ0MsU0FBUyxDQUFDLEdBQzFGSSxJQUFJLENBQUNHLE9BQU9ELFVBQVU7QUFDcEIsc0JBQU11QixXQUFXdEIsTUFBTXVCLGVBQWUsQ0FBQztBQUV2Qyx1QkFDSSx1QkFBQyxRQUFlLFdBQVUsNkJBQ3RCO0FBQUEseUNBQUMsUUFBRyxXQUFVLGFBQWF2QixpQkFBT0MsY0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkM7QUFBQSxrQkFDN0MsdUJBQUMsUUFBRyxXQUFVLGFBQWFELGlCQUFPRyxVQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QztBQUFBLGtCQUN6Qyx1QkFBQyxRQUFHLFdBQVUsYUFBYW1CLG9CQUFVRSxjQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRDtBQUFBLGtCQUNoRCx1QkFBQyxRQUFHLFdBQVUsYUFBWTtBQUFBO0FBQUEsb0JBQUVGLFVBQVVHO0FBQUFBLHVCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUN4Qyx1QkFBQyxRQUFHLFdBQVUsYUFDbEIsY0FBSWIsS0FBS1UsVUFBVUksU0FBUyxFQUFFWixtQkFBbUIsU0FBUztBQUFBLG9CQUN2REMsS0FBSztBQUFBLG9CQUNMQyxPQUFPO0FBQUE7QUFBQSxvQkFDUEMsTUFBTTtBQUFBLGtCQUNWLENBQUMsS0FMSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1UO0FBQUEscUJBWFNsQixPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWUE7QUFBQSxjQUVSLENBQUMsS0FyQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxpQkFoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQ0EsS0FsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQ0E7QUFBQSxlQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBDQTtBQUFBLFVBRUh6QyxzQkFBc0JHLDRCQUE0QmdDLFNBQVMsS0FDeEQsdUJBQUMsU0FBSSxXQUFVLGVBQ1g7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVMsTUFBTXBCLG9CQUFvQixDQUFDRCxnQkFBZ0I7QUFBQSxjQUNwRCxXQUFVO0FBQUEsY0FFVEEsNkJBQW1CLGdCQUFnQjtBQUFBO0FBQUEsWUFKeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0EsS0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFJSGQsc0JBQXNCSSw0QkFBNEIrQixTQUFTLEtBQ3hELHVCQUFDLFNBQUksV0FBVSw2QkFDWDtBQUFBLG1DQUFDLFFBQUcsV0FBVSw0Q0FBMkMsd0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsT0FBTyxFQUFFQyxXQUFXLFNBQVNDLFdBQVcsT0FBTyxHQUM1RSxpQ0FBQyxXQUFNLFdBQVUsc0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUseUJBQ2IsaUNBQUMsUUFBRyxXQUFVLFlBQ1Y7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsdUJBQXNCLHVCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQztBQUFBLGdCQUMzQyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLDBCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QztBQUFBLGdCQUM5Qyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLHNCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBLGdCQUMxQyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLG9CQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QztBQUFBLG1CQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsV0FDS3JDLCtCQUFxQkksMkJBQ2xCa0MsTUFBTSxHQUFHdEIsa0JBQWtCaEIscUJBQXFCSSwyQkFBMkIrQixTQUFTLENBQUMsRUFDeEZJLElBQUksQ0FBQ1ksTUFBTVYsVUFBVTtBQUNuQixzQkFBTXVCLFdBQVdiLEtBQUtjLGVBQWUsQ0FBQztBQUV0Qyx1QkFDSSx1QkFBQyxRQUFlLFdBQVUsNkJBQ3RCO0FBQUEseUNBQUMsUUFBRyxXQUFVLGFBQWFkLGdCQUFNQyxXQUFXLE9BQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdEO0FBQUEsa0JBQ2hELHVCQUFDLFFBQUcsV0FBVSxhQUFhWSxvQkFBVUUsY0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0Q7QUFBQSxrQkFDaEQsdUJBQUMsUUFBRyxXQUFVLGFBQVk7QUFBQTtBQUFBLG9CQUFFRixVQUFVRztBQUFBQSx1QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkM7QUFBQSxrQkFDeEMsdUJBQUMsUUFBRyxXQUFVLGFBQ2xCLGNBQUliLEtBQUtVLFVBQVVJLFNBQVMsRUFBRVosbUJBQW1CLFNBQVM7QUFBQSxvQkFDdkRDLEtBQUs7QUFBQSxvQkFDTEMsT0FBTztBQUFBO0FBQUEsb0JBQ1BDLE1BQU07QUFBQSxrQkFDVixDQUFDLEtBTEk7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNVDtBQUFBLHFCQVZTbEIsT0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsY0FFUixDQUFDLEtBcEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBOUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBLEtBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUNBO0FBQUEsZUF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3Q0E7QUFBQSxXQU1GLENBQUN6QyxzQkFBc0JFLGlCQUFpQkYscUJBQXFCRSxjQUFjaUMsV0FBVyxPQUNuRixDQUFDbkMsc0JBQXNCRywrQkFBK0JILHFCQUFxQkcsNEJBQTRCZ0MsV0FBVyxPQUNsSCxDQUFDbkMsc0JBQXNCSSw4QkFBOEJKLHFCQUFxQkksMkJBQTJCK0IsV0FBVyxPQUNoSCxDQUFDbkMsc0JBQXNCSyxnQkFBZ0JMLHFCQUFxQkssYUFBYThCLFdBQVcsTUFDakYsdUJBQUMsU0FBSSxXQUFVLG9CQUNYLGlDQUFDLE9BQUUsV0FBVSxpQkFBZ0IsK0RBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFLEtBRGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQWxSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb1JBLEtBclJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzUkEsS0F4Uko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlSQTtBQUFBO0FBQUEsTUE5U0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBK1NBO0FBQUEsT0EzVFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZUQTtBQUVSO0FBQUVwQyxHQW5ZSUosMEJBQXdCO0FBQUEwRSxLQUF4QjFFO0FBcVlOLGVBQWVBO0FBQXlCLElBQUEwRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJEcmF3ZXIiLCJTcGluIiwiQnV0dG9uIiwiYXBpIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJWaWV3Q3VzdG9tZXJUcmFuc2FjdGlvbnMiLCJjdXN0b21lcklkIiwidmlzaWJsZSIsIm9uQ2xvc2UiLCJfcyIsImN1c3RvbWVyVHJhbnNhY3Rpb25zIiwic2V0Q3VzdG9tZXJUcmFuc2FjdGlvbnMiLCJjaGl0X2FjY291bnRzIiwibGFzdF90cmFuc2FjdGlvbnNfcGVyX2dyb3VwIiwibGFzdF90cmFuc2FjdGlvbnNfcGVyX2xvYW4iLCJsb2FuX3N1bW1hcnkiLCJwaWdtZV9zdW1tYXJ5IiwidXNlciIsInNob3dEcmF3ZXIiLCJzZXRTaG93RHJhd2VyIiwibG9hZGluZ1RyYW5zYWN0aW9ucyIsInNldExvYWRpbmdUcmFuc2FjdGlvbnMiLCJzaG93QWxsQ2hpdHMiLCJzZXRTaG93QWxsQ2hpdHMiLCJzaG93QWxsR3JvdXBUeG5zIiwic2V0U2hvd0FsbEdyb3VwVHhucyIsInNob3dBbGxMb2FuVHhucyIsInNldFNob3dBbGxMb2FuVHhucyIsInNob3dBbGxMb2FuU3VtbWFyeSIsInNldFNob3dBbGxMb2FuU3VtbWFyeSIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJmZXRjaFRyYW5zYWN0aW9ucyIsInJlcyIsImdldCIsImRhdGEiLCJzdGF0dXMiLCJlcnJvciIsInJlc3BvbnNlIiwiY29uc29sZSIsInByZXYiLCJmdWxsX25hbWUiLCJsZW5ndGgiLCJtYXhIZWlnaHQiLCJvdmVyZmxvd1kiLCJzbGljZSIsIm1hcCIsImFjY291bnQiLCJpbmRleCIsImdyb3VwIiwiZ3JvdXBfbmFtZSIsImdyb3VwX3ZhbHVlIiwidGlja2V0IiwiaXNQcml6ZWQiLCJ0b3RhbHMiLCJ0b3RhbEJlUGFpZCIsInBhaWQiLCJiYWxhbmNlIiwibG9hbiIsImxvYW5faWQiLCJsb2FuX2Ftb3VudCIsIkRhdGUiLCJzdGFydF9kYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwiZW5kX2RhdGUiLCJ0b3RhbF9wYWlkX2Ftb3VudCIsInBpZ215IiwicGlnbWVfaWQiLCJmaXJzdFR4biIsInRyYW5zYWN0aW9ucyIsInJlY2VpcHRfbm8iLCJhbW91bnQiLCJjcmVhdGVkQXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJWaWV3Q3VzdG9tZXJUcmFuc2FjdGlvbnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBEcmF3ZXIsIFNwaW4sIEJ1dHRvbiB9IGZyb20gJ2FudGQnO1xyXG5pbXBvcnQgYXBpIGZyb20gJy4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2UnO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSAnLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2cnO1xyXG5cclxuY29uc3QgVmlld0N1c3RvbWVyVHJhbnNhY3Rpb25zID0gKHsgY3VzdG9tZXJJZCwgdmlzaWJsZSwgb25DbG9zZSB9KSA9PiB7XHJcbiAgICBjb25zdCBbY3VzdG9tZXJUcmFuc2FjdGlvbnMsIHNldEN1c3RvbWVyVHJhbnNhY3Rpb25zXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICBjaGl0X2FjY291bnRzOiBbXSxcclxuICAgICAgICBsYXN0X3RyYW5zYWN0aW9uc19wZXJfZ3JvdXA6IFtdLFxyXG4gICAgICAgIGxhc3RfdHJhbnNhY3Rpb25zX3Blcl9sb2FuOiBbXSxcclxuICAgICAgICBsb2FuX3N1bW1hcnk6IFtdLFxyXG4gICAgICAgIHBpZ21lX3N1bW1hcnk6IFtdLFxyXG4gICAgICAgIHVzZXI6IG51bGwsXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IFtzaG93RHJhd2VyLCBzZXRTaG93RHJhd2VyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nVHJhbnNhY3Rpb25zLCBzZXRMb2FkaW5nVHJhbnNhY3Rpb25zXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtzaG93QWxsQ2hpdHMsIHNldFNob3dBbGxDaGl0c10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbc2hvd0FsbEdyb3VwVHhucywgc2V0U2hvd0FsbEdyb3VwVHhuc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbc2hvd0FsbExvYW5UeG5zLCBzZXRTaG93QWxsTG9hblR4bnNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3Nob3dBbGxMb2FuU3VtbWFyeSwgc2V0U2hvd0FsbExvYW5TdW1tYXJ5XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICAgICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBGZXRjaCBjdXN0b21lciB0cmFuc2FjdGlvbnNcclxuICAgIGNvbnN0IGZldGNoVHJhbnNhY3Rpb25zID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGlmICghY3VzdG9tZXJJZCkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nVHJhbnNhY3Rpb25zKHRydWUpO1xyXG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KGAvZW5yb2xsL2xvYW4tY2hpdC1zdW1tYXJ5LyR7Y3VzdG9tZXJJZH1gKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChyZXMuZGF0YS5zdGF0dXMgJiYgcmVzLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgIHNldEN1c3RvbWVyVHJhbnNhY3Rpb25zKHtcclxuICAgICAgICAgICAgICAgICAgICBjaGl0X2FjY291bnRzOiByZXMuZGF0YS5jaGl0X2FjY291bnRzIHx8IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhc3RfdHJhbnNhY3Rpb25zX3Blcl9ncm91cDogcmVzLmRhdGEubGFzdF90cmFuc2FjdGlvbnNfcGVyX2dyb3VwIHx8IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhc3RfdHJhbnNhY3Rpb25zX3Blcl9sb2FuOiByZXMuZGF0YS5sYXN0X3RyYW5zYWN0aW9uc19wZXJfbG9hbiB8fCBbXSxcclxuICAgICAgICAgICAgICAgICAgICBsb2FuX3N1bW1hcnk6IHJlcy5kYXRhLmxvYW5fc3VtbWFyeSB8fCBbXSxcclxuICAgICAgICAgICAgICAgICAgICBwaWdtZV9zdW1tYXJ5OiByZXMuZGF0YS5waWdtZV9zdW1tYXJ5IHx8IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXI6IHJlcy5kYXRhLnVzZXIgfHwgbnVsbCxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIE9ubHkgb3BlbiBkcmF3ZXIgaWYgZmV0Y2ggaXMgc3VjY2Vzc2Z1bFxyXG4gICAgICAgICAgICAgICAgc2V0U2hvd0RyYXdlcih0cnVlKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiTm8gZGF0YSBmb3VuZCBmb3IgdGhpcyBjdXN0b21lci5cIixcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGVycm9yPy5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0cmFuc2FjdGlvbnNcIiwgZXJyb3IpO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmdUcmFuc2FjdGlvbnMoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gRmV0Y2ggdHJhbnNhY3Rpb25zIHdoZW4gZHJhd2VyIG9wZW5zXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGlmICh2aXNpYmxlKSBmZXRjaFRyYW5zYWN0aW9ucygpO1xyXG4gICAgfSwgW3Zpc2libGUsIGN1c3RvbWVySWRdKTtcclxuXHJcblxyXG4gICAgcmV0dXJuIChcclxuXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAge2FsZXJ0Q29uZmlnLnZpc2liaWxpdHkgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge3Nob3dEcmF3ZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPERyYXdlclxyXG4gICAgICAgICAgICAgICAgICAgIG9wZW49e3Zpc2libGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17b25DbG9zZX1cclxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBMZWZ0IHNpZGUgKG9wdGlvbmFsKSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgVHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJpZ2h0IHNpZGUgKEN1c3RvbWVyIE5hbWUpICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCBmb250LXNlbWlib2xkIHRleHQtc20gYmctYmx1ZS01MCBweC0zIHB5LTEgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBcIkN1c3RvbWVyIE5hbWUgIC0gIFwiICsgKCBjdXN0b21lclRyYW5zYWN0aW9ucz8udXNlcj8uZnVsbF9uYW1lICkgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInotNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPXs4MDB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGgtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogTWFpbiBzY3JvbGxhYmxlIGNvbnRhaW5lciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHB4LTQgcGItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQ2hpdCBBY2NvdW50cyBTdW1tYXJ5IFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyVHJhbnNhY3Rpb25zPy5jaGl0X2FjY291bnRzPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoaXQgQWNjb3VudHMgU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVGFibGUgY29udGFpbmVyIHdpdGggZml4ZWQgaGVpZ2h0IGFuZCBzY3JvbGwgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiIHN0eWxlPXt7IG1heEhlaWdodDogJzMwMHB4Jywgb3ZlcmZsb3dZOiAnYXV0bycgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIGJnLXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTIgcHgtM1wiPkdyb3VwIE5hbWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMiBweC0zXCI+R3JvdXAgVmFsdWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMiBweC0zXCI+VGlja2V0PC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTIgcHgtM1wiPlByaXplZDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5Ub3RhbCB0byBQYXk8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMiBweC0zXCI+UGFpZDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5CYWxhbmNlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiB7Y3VzdG9tZXJUcmFuc2FjdGlvbnMuY2hpdF9hY2NvdW50cy5tYXAoKGFjY291bnQsIGluZGV4KSA9PiAoICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhjdXN0b21lclRyYW5zYWN0aW9ucy5jaGl0X2FjY291bnRzLnNsaWNlKDAsIHNob3dBbGxDaGl0cyA/IGN1c3RvbWVyVHJhbnNhY3Rpb25zLmNoaXRfYWNjb3VudHMubGVuZ3RoIDogMikpLm1hcCgoYWNjb3VudCwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwiYm9yZGVyLWIgaG92ZXI6YmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMiBweC0zXCI+e2FjY291bnQ/Lmdyb3VwLmdyb3VwX25hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtM1wiPuKCuXthY2NvdW50Py5ncm91cC5ncm91cF92YWx1ZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMiBweC0zXCI+e2FjY291bnQ/LnRpY2tldH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMiBweC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTEgcm91bmRlZCB0ZXh0LXhzICR7YWNjb3VudD8uaXNQcml6ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjY291bnQuaXNQcml6ZWQgPyAnWWVzJyA6ICdObyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj7igrl7YWNjb3VudD8udG90YWxzLnRvdGFsQmVQYWlkfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj7igrl7YWNjb3VudD8udG90YWxzLnBhaWR9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT17YHB5LTIgcHgtMyBmb250LW1lZGl1bSAke2FjY291bnQ/LnRvdGFscy5iYWxhbmNlID49IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ3RleHQtcmVkLTYwMCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JlZW4tNjAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2FjY291bnQ/LnRvdGFscy5iYWxhbmNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyVHJhbnNhY3Rpb25zPy5jaGl0X2FjY291bnRzPy5sZW5ndGggPiAyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWxsQ2hpdHMoIXNob3dBbGxDaGl0cyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd0FsbENoaXRzID8gXCLilrIgU2hvdyBMZXNzXCIgOiBcIuKWvCBTaG93IE1vcmVcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIExvYW4gU3VtbWFyeSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lclRyYW5zYWN0aW9ucz8ubG9hbl9zdW1tYXJ5Py5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExvYW4gU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVGFibGUgY29udGFpbmVyIHdpdGggZml4ZWQgaGVpZ2h0IGFuZCBzY3JvbGwgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiIHN0eWxlPXt7IG1heEhlaWdodDogJzMwMHB4Jywgb3ZlcmZsb3dZOiAnYXV0bycgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIGJnLXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTIgcHgtM1wiPkxvYW4gSUQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMiBweC0zXCI+TG9hbiBBbW91bnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMiBweC0zXCI+U3RhcnQgZGF0ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5FbmQgZGF0ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5QYWlkPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTIgcHgtM1wiPkJhbGFuY2U8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhjdXN0b21lclRyYW5zYWN0aW9ucy5sb2FuX3N1bW1hcnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc2xpY2UoMCwgc2hvd0FsbExvYW5TdW1tYXJ5ID8gY3VzdG9tZXJUcmFuc2FjdGlvbnM/LmxvYW5fc3VtbWFyeT8ubGVuZ3RoIDogMilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkubWFwKChsb2FuLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJib3JkZXItYiBob3ZlcjpiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj57bG9hbj8ubG9hbl9pZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMiBweC0zXCI+4oK5e2xvYW4/LmxvYW5fYW1vdW50fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShsb2FuPy5zdGFydF9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUdCJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogJzItZGlnaXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiAnc2hvcnQnLCAvLyBcIkphblwiLCBcIkZlYlwiLCBcIk1hclwiLCBldGMuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogJ251bWVyaWMnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGxvYW4/LmVuZF9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUdCJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogJzItZGlnaXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiAnc2hvcnQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHllYXI6ICdudW1lcmljJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj7igrl7bG9hbj8udG90YWxfcGFpZF9hbW91bnR9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj7igrl7bG9hbj8uYmFsYW5jZX08L3RkPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT17YHB5LTIgcHgtMyBmb250LW1lZGl1bSAke2xvYW4/LmJhbGFuY2UgPj0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1yZWQtNjAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1ncmVlbi02MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7bG9hbj8uYmFsYW5jZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUGlnbXkgU3VtbWFyeSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lclRyYW5zYWN0aW9ucz8ucGlnbWVfc3VtbWFyeT8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaWdteSBTdW1tYXJ5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBUYWJsZSBjb250YWluZXIgd2l0aCBmaXhlZCBoZWlnaHQgYW5kIHNjcm9sbCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCIgc3R5bGU9e3sgbWF4SGVpZ2h0OiAnMzAwcHgnLCBvdmVyZmxvd1k6ICdhdXRvJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgYmctd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMiBweC0zXCI+UGlnbXkgSUQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMiBweC0zXCI+U3RhcnQgZGF0ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5QaWdteSBBbW91bnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhjdXN0b21lclRyYW5zYWN0aW9ucy5waWdtZV9zdW1tYXJ5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnNsaWNlKDAsIHNob3dBbGxMb2FuU3VtbWFyeSA/IGN1c3RvbWVyVHJhbnNhY3Rpb25zPy5waWdtZV9zdW1tYXJ5Py5sZW5ndGggOiAyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5tYXAoKHBpZ215LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJib3JkZXItYiBob3ZlcjpiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj57cGlnbXk/LnBpZ21lX2lkfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShwaWdteT8uc3RhcnRfZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1HQicsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXk6ICcyLWRpZ2l0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogJ3Nob3J0JywgLy8gXCJKYW5cIiwgXCJGZWJcIiwgXCJNYXJcIiwgZXRjLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHllYXI6ICdudW1lcmljJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9e2BweS0yIHB4LTMgZm9udC1tZWRpdW0gJHtwaWdteT8udG90YWxfcGFpZF9hbW91bnQgPj0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1ncmVlbi02MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXJlZC02MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0gPuKCuXtwaWdteT8udG90YWxfcGFpZF9hbW91bnR9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUmVjZW50IEdyb3VwIFRyYW5zYWN0aW9ucyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lclRyYW5zYWN0aW9ucz8ubGFzdF90cmFuc2FjdGlvbnNfcGVyX2dyb3VwPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlY2VudCBHcm91cCBUcmFuc2FjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRhYmxlIGNvbnRhaW5lciB3aXRoIGZpeGVkIGhlaWdodCBhbmQgc2Nyb2xsICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIiBzdHlsZT17eyBtYXhIZWlnaHQ6ICczMDBweCcsIG92ZXJmbG93WTogJ2F1dG8nIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cInN0aWNreSB0b3AtMCBiZy13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5Hcm91cCBOYW1lPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTIgcHgtM1wiPlRpY2tldDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5SZWNlaXB0IE5vPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTIgcHgtM1wiPkFtb3VudDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5EYXRlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoY3VzdG9tZXJUcmFuc2FjdGlvbnM/Lmxhc3RfdHJhbnNhY3Rpb25zX3Blcl9ncm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5zbGljZSgwLCBzaG93QWxsR3JvdXBUeG5zID8gY3VzdG9tZXJUcmFuc2FjdGlvbnMubGFzdF90cmFuc2FjdGlvbnNfcGVyX2dyb3VwLmxlbmd0aCA6IDIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZmlyc3RUeG4gPSBncm91cC50cmFuc2FjdGlvbnM/LlswXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImJvcmRlci1iIGhvdmVyOmJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj57Z3JvdXA/Lmdyb3VwX25hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj57Z3JvdXA/LnRpY2tldH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtM1wiPntmaXJzdFR4bj8ucmVjZWlwdF9ub308L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtM1wiPuKCuXtmaXJzdFR4bj8uYW1vdW50fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShmaXJzdFR4bj8uY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUdCJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogJzItZGlnaXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiAnc2hvcnQnLCAvLyBcIkphblwiLCBcIkZlYlwiLCBcIk1hclwiLCBldGMuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogJ251bWVyaWMnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lclRyYW5zYWN0aW9ucz8ubGFzdF90cmFuc2FjdGlvbnNfcGVyX2dyb3VwLmxlbmd0aCA+IDIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FsbEdyb3VwVHhucyghc2hvd0FsbEdyb3VwVHhucyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd0FsbEdyb3VwVHhucyA/IFwi4payIFNob3cgTGVzc1wiIDogXCLilrwgU2hvdyBNb3JlXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJlY2VudCBMb2FuIFRyYW5zYWN0aW9ucyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lclRyYW5zYWN0aW9ucz8ubGFzdF90cmFuc2FjdGlvbnNfcGVyX2xvYW4/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVjZW50IExvYW4gVHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBUYWJsZSBjb250YWluZXIgd2l0aCBmaXhlZCBoZWlnaHQgYW5kIHNjcm9sbCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCIgc3R5bGU9e3sgbWF4SGVpZ2h0OiAnMzAwcHgnLCBvdmVyZmxvd1k6ICdhdXRvJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgYmctd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMiBweC0zXCI+TG9hbiBJRDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5SZWNlaXB0IE5vPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTIgcHgtM1wiPkFtb3VudDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0yIHB4LTNcIj5EYXRlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoY3VzdG9tZXJUcmFuc2FjdGlvbnMubGFzdF90cmFuc2FjdGlvbnNfcGVyX2xvYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc2xpY2UoMCwgc2hvd0FsbExvYW5UeG5zID8gY3VzdG9tZXJUcmFuc2FjdGlvbnMubGFzdF90cmFuc2FjdGlvbnNfcGVyX2xvYW4ubGVuZ3RoIDogMilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkubWFwKChsb2FuLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpcnN0VHhuID0gbG9hbi50cmFuc2FjdGlvbnM/LlswXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImJvcmRlci1iIGhvdmVyOmJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj57bG9hbj8ubG9hbl9pZCB8fCBcIi1cIn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtM1wiPntmaXJzdFR4bj8ucmVjZWlwdF9ub308L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtM1wiPuKCuXtmaXJzdFR4bj8uYW1vdW50fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShmaXJzdFR4bj8uY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUdCJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogJzItZGlnaXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiAnc2hvcnQnLCAvLyBcIkphblwiLCBcIkZlYlwiLCBcIk1hclwiLCBldGMuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogJ251bWVyaWMnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTaG93IG1lc3NhZ2UgaWYgbm8gZGF0YSBpcyBhdmFpbGFibGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyghY3VzdG9tZXJUcmFuc2FjdGlvbnM/LmNoaXRfYWNjb3VudHMgfHwgY3VzdG9tZXJUcmFuc2FjdGlvbnMuY2hpdF9hY2NvdW50cy5sZW5ndGggPT09IDApICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICghY3VzdG9tZXJUcmFuc2FjdGlvbnM/Lmxhc3RfdHJhbnNhY3Rpb25zX3Blcl9ncm91cCB8fCBjdXN0b21lclRyYW5zYWN0aW9ucy5sYXN0X3RyYW5zYWN0aW9uc19wZXJfZ3JvdXAubGVuZ3RoID09PSAwKSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoIWN1c3RvbWVyVHJhbnNhY3Rpb25zPy5sYXN0X3RyYW5zYWN0aW9uc19wZXJfbG9hbiB8fCBjdXN0b21lclRyYW5zYWN0aW9ucy5sYXN0X3RyYW5zYWN0aW9uc19wZXJfbG9hbi5sZW5ndGggPT09IDApICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICghY3VzdG9tZXJUcmFuc2FjdGlvbnM/LmxvYW5fc3VtbWFyeSB8fCBjdXN0b21lclRyYW5zYWN0aW9ucy5sb2FuX3N1bW1hcnkubGVuZ3RoID09PSAwKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+Tm8gdHJhbnNhY3Rpb24gZGF0YSBhdmFpbGFibGUgZm9yIHRoaXMgY3VzdG9tZXI8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvRHJhd2VyPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFZpZXdDdXN0b21lclRyYW5zYWN0aW9uczsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvVmlld0N1c3RvbWVyVHJhbnNhY3Rpb25zLmpzeCJ9