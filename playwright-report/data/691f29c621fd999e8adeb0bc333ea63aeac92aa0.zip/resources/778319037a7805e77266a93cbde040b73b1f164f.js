import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/modals/EditSalaryModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import API from "/src/instance/TokenInstance.js";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { FaCalendar } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const EditSalaryModal = ({ isVisible, onClose, salary, onEditSuccess }) => {
  _s();
  const [api, contextHolder] = notification.useNotification();
  const [loading, setLoading] = useState(false);
  const [formValues, setFormValues] = useState({
    pay_date: "",
    total_paid_amount: "",
    other_payments: "",
    note: "",
    pay_type: "",
    transaction_id: ""
  });
  const [originalValues, setOriginalValues] = useState(null);
  const [hasChanges, setHasChanges] = useState(false);
  const [errors, setErrors] = useState({});
  const [otherPaymentsList, setOtherPaymentsList] = useState([{ description: "", amount: "" }]);
  useEffect(() => {
    if (isVisible && salary) {
      const metadata = salary.payout_metadata;
      const existingOther = Array.isArray(metadata.other_payments) ? metadata.other_payments.map((p) => ({
        description: p.description || "",
        amount: p.amount || ""
      })) : [{ description: "", amount: "" }];
      setOtherPaymentsList(existingOther);
    }
  }, [isVisible, salary]);
  const handleAddOtherPayment = () => {
    setOtherPaymentsList([...otherPaymentsList, { description: "", amount: "" }]);
  };
  const handleOtherPaymentChange = (index, field, value) => {
    const updated = [...otherPaymentsList];
    updated[index][field] = value;
    setOtherPaymentsList(updated);
  };
  const handleRemoveOtherPayment = (index) => {
    setOtherPaymentsList(otherPaymentsList.filter((_, i) => i !== index));
  };
  useEffect(() => {
    if (isVisible && salary) {
      const metadata = salary.payout_metadata;
      const initialValues = {
        pay_date: new Date(metadata.date_range.from).toISOString().split("T")[0],
        total_paid_amount: metadata.total_paid_amount,
        other_payments: metadata.other_payments || "",
        note: metadata.note,
        pay_type: metadata.pay_type,
        transaction_id: metadata.transaction_id || ""
      };
      setFormValues(initialValues);
      setOriginalValues(initialValues);
      setHasChanges(false);
      setErrors({});
    }
  }, [isVisible, salary]);
  useEffect(() => {
    if (originalValues && salary) {
      const formChanged = Object.keys(originalValues).some(
        (key) => formValues[key] !== originalValues[key]
      );
      const originalOtherPayments = Array.isArray(salary?.payout_metadata?.other_payments) ? salary.payout_metadata.other_payments.map((p) => ({
        description: p.description || "",
        amount: Number(p.amount) || 0
      })) : [];
      const currentOtherPayments = otherPaymentsList.map((p) => ({
        description: p.description,
        amount: Number(p.amount)
      }));
      const otherPaymentsChanged = JSON.stringify(currentOtherPayments) !== JSON.stringify(originalOtherPayments);
      setHasChanges(formChanged || otherPaymentsChanged);
    }
  }, [formValues, otherPaymentsList, originalValues, salary]);
  const validateForm = () => {
    const newErrors = {};
    if (formValues.total_paid_amount !== "" && (isNaN(formValues.total_paid_amount) || formValues.total_paid_amount < 0)) {
      newErrors.total_paid_amount = "Amount must be a positive number";
    }
    if (formValues.pay_type === "online" && !formValues.transaction_id) {
      newErrors.transaction_id = "Transaction ID is required for online payments";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    setLoading(true);
    try {
      const payload = {};
      if (formValues.pay_date !== originalValues.pay_date) {
        payload.pay_date = formValues.pay_date;
      }
      if (formValues.total_paid_amount !== originalValues.total_paid_amount) {
        payload.total_paid_amount = parseFloat(formValues.total_paid_amount);
      }
      if (formValues.note !== originalValues.note) {
        payload.note = formValues.note;
      }
      if (formValues.pay_type !== originalValues.pay_type) {
        payload.pay_type = formValues.pay_type;
      }
      if (formValues.transaction_id !== originalValues.transaction_id) {
        payload.transaction_id = formValues.transaction_id;
      }
      const cleanOtherPayments = otherPaymentsList.filter(
        (item) => item.description.trim() !== "" && !isNaN(Number(item.amount)) && Number(item.amount) >= 0
      ).map((item) => ({
        description: item.description.trim(),
        amount: Number(item.amount)
      }));
      const originalOtherPayments = Array.isArray(salary?.payout_metadata?.other_payments) && salary.payout_metadata.other_payments.map((p) => ({
        description: p.description,
        amount: Number(p.amount)
      }));
      const hasOtherPaymentsChanged = JSON.stringify(cleanOtherPayments) !== JSON.stringify(originalOtherPayments);
      if (hasOtherPaymentsChanged) {
        payload.other_payments = cleanOtherPayments;
      }
      if (Object.keys(payload).length === 0) {
        api.open({
          message: "No changes made",
          description: "No fields were changed",
          className: "bg-violet-500 rounded-lg font-semibold text-white"
        });
        return;
      }
      await API.put(`/salary/edit/${salary._id}`, payload);
      api.open({
        message: "Salary Payment Updated",
        description: "Salary payment has been updated successfully",
        className: "bg-green-500 rounded-lg font-semibold text-white"
      });
      if (onEditSuccess) onEditSuccess();
    } catch (error) {
      const message = error.response?.data?.error || "Failed to update salary payment";
      api.open({
        message: "Update Failed",
        description: message,
        className: "bg-red-500 rounded-lg font-semibold text-white"
      });
    } finally {
      setLoading(false);
    }
  };
  if (!salary || !isVisible) return null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 transition-opacity duration-300 ${isVisible ? "opacity-100" : "opacity-0 pointer-events-none"}`,
        onClick: onClose,
        children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "bg-white rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto transform transition-all duration-300 relative shadow-2xl border border-gray-100",
            onClick: (e) => e.stopPropagation(),
            children: /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
                  /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-900 flex items-center", children: "Edit Salary Payment" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 781,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm", children: [
                    "Update payment details for",
                    " ",
                    salary.employee_id?.name || "this employee"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 784,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                  lineNumber: 780,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: onClose,
                    className: "text-gray-500 hover:text-gray-700 transition-colors",
                    children: /* @__PURE__ */ jsxDEV(
                      "svg",
                      {
                        className: "w-5 h-5",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24",
                        children: /* @__PURE__ */ jsxDEV(
                          "path",
                          {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: "2",
                            d: "M6 18L18 6M6 6l12 12"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                            lineNumber: 799,
                            columnNumber: 19
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 793,
                        columnNumber: 17
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 789,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                lineNumber: 779,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-violet-50 to-violet-100 rounded-xl p-5 border border-violet-100 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-medium text-violet-800", children: "Payment Summary" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 812,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-violet-600 mt-1", children: [
                    "Period:",
                    " ",
                    new Date(
                      salary.payout_metadata.date_range.from
                    ).toLocaleDateString(),
                    " ",
                    "to",
                    new Date(
                      salary.payout_metadata.date_range.to
                    ).toLocaleDateString()
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 815,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                  lineNumber: 811,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-violet-900", children: [
                    "₹",
                    (parseFloat(
                      salary.payout_metadata.total_paid_amount || 0
                    ) + parseFloat(salary.payout_metadata.other_payments || 0)).toFixed(2)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 827,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-violet-600", children: "Total Payment Amount" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 835,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                  lineNumber: 826,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                lineNumber: 810,
                columnNumber: 15
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                lineNumber: 809,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-100 pb-4", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-medium text-gray-900 mb-3 flex items-center", children: [
                    /* @__PURE__ */ jsxDEV(FaCalendar, { className: "mr-2 text-violet-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 844,
                      columnNumber: 19
                    }, this),
                    "Payment Date"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 843,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Current Payment Date" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 849,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-3 rounded-lg border border-gray-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-900", children: originalValues?.pay_date || "N/A" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 853,
                        columnNumber: 23
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 852,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 848,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "New Payment Date" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 859,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "date",
                          value: formValues.pay_date,
                          onChange: (e) => setFormValues({
                            ...formValues,
                            pay_date: e.target.value
                          }),
                          className: `w-full px-3 py-2 border rounded-md ${errors.pay_date ? "border-red-500" : "border-gray-300 focus:border-violet-500"}`,
                          min: salary.payout_metadata.date_range.from,
                          max: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                          lineNumber: 862,
                          columnNumber: 21
                        },
                        this
                      ),
                      errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 879,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 858,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 847,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                  lineNumber: 842,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-100 pb-4", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-medium text-gray-900 mb-3 flex items-center", children: [
                    /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "mr-2 text-green-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 890,
                      columnNumber: 19
                    }, this),
                    "Payment Amount"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 889,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Base Salary Amount" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 895,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-3 rounded-lg border border-gray-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-900", children: [
                        "₹",
                        salary.payout_metadata.total_salary.toFixed(2)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 899,
                        columnNumber: 23
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 898,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 894,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Total Paid Amount (₹)" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 905,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "number",
                          step: "0.01",
                          min: "0",
                          value: formValues.total_paid_amount,
                          onChange: (e) => setFormValues({
                            ...formValues,
                            total_paid_amount: e.target.value
                          }),
                          className: `w-full px-3 py-2 border rounded-md ${errors.total_paid_amount ? "border-red-500" : "border-gray-300 focus:border-violet-500"}`,
                          placeholder: "Enter payment amount"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                          lineNumber: 908,
                          columnNumber: 21
                        },
                        this
                      ),
                      errors.total_paid_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.total_paid_amount }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 926,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 904,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 893,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-100 pb-4", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "font-medium text-gray-900 mb-3", children: "Additional Payments" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 967,
                      columnNumber: 19
                    }, this),
                    otherPaymentsList.map(
                      (item, index) => /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3 mb-3", children: [
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Payment Description" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                            lineNumber: 974,
                            columnNumber: 25
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              type: "text",
                              placeholder: "e.g., Bonus, Reimbursement",
                              value: item.description,
                              onChange: (e) => handleOtherPaymentChange(index, "description", e.target.value),
                              className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-violet-500"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                              lineNumber: 977,
                              columnNumber: 25
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                          lineNumber: 973,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Payment Amount (₹)" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                            lineNumber: 988,
                            columnNumber: 25
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              type: "number",
                              min: "0",
                              step: "0.01",
                              placeholder: "Enter amount",
                              value: item.amount,
                              onChange: (e) => handleOtherPaymentChange(index, "amount", e.target.value),
                              className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-violet-500"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                              lineNumber: 991,
                              columnNumber: 25
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                          lineNumber: 987,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-end", children: index > 0 && /* @__PURE__ */ jsxDEV(
                          "button",
                          {
                            type: "button",
                            onClick: () => handleRemoveOtherPayment(index),
                            className: "text-red-500 hover:text-red-700 font-semibold",
                            children: "Remove"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                            lineNumber: 1005,
                            columnNumber: 23
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                          lineNumber: 1003,
                          columnNumber: 23
                        }, this)
                      ] }, index, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 972,
                        columnNumber: 19
                      }, this)
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: handleAddOtherPayment,
                        className: "bg-green-600 text-white px-4 py-2 text-sm font-medium rounded-md hover:bg-green-700 transition",
                        children: "+ Add Another Payment"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 1017,
                        columnNumber: 19
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 966,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                  lineNumber: 888,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-100 pb-4", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-medium text-gray-900 mb-3 flex items-center", children: "Payment Method" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 1030,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col justify-between  p-3 rounded", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Current Payment Method" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 1035,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-3 rounded-lg border border-gray-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-900 capitalize", children: originalValues?.pay_type || "N/A" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 1039,
                        columnNumber: 23
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 1038,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 1034,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col justify-between  p-3 rounded", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "New Payment Method" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 1046,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          value: formValues.pay_type,
                          onChange: (value) => setFormValues({ ...formValues, pay_type: value }),
                          className: "w-full h-[42px]",
                          children: [
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: "Cash" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                              lineNumber: 1056,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: "Online Transfer" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                              lineNumber: 1057,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "cheque", children: "Cheque" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                              lineNumber: 1060,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "bank_transfer", children: "Bank Transfer" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                              lineNumber: 1061,
                              columnNumber: 23
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                          lineNumber: 1049,
                          columnNumber: 21
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 1045,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 1033,
                    columnNumber: 17
                  }, this),
                  formValues.pay_type === "online" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Transaction ID" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 1070,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        value: formValues.transaction_id,
                        onChange: (e) => setFormValues({
                          ...formValues,
                          transaction_id: e.target.value
                        }),
                        className: `w-full px-3 py-2 border rounded-md ${errors.transaction_id ? "border-red-500" : "border-gray-300 focus:border-violet-500"}`,
                        placeholder: "Enter transaction ID"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 1073,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 1089,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 1069,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                  lineNumber: 1029,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-medium text-gray-900 mb-3 flex items-center", children: "Additional Notes" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 1099,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "textarea",
                    {
                      value: formValues.note,
                      onChange: (e) => setFormValues({ ...formValues, note: e.target.value }),
                      className: `w-full px-3 py-2 border rounded-md ${errors.note ? "border-red-500" : "border-gray-300 focus:border-violet-500"}`,
                      rows: "3",
                      placeholder: "Add any notes about this payment..."
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 1102,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "These notes will be visible on the salary slip" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                    lineNumber: 1114,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                  lineNumber: 1098,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200 mt-6 flex justify-end gap-3", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: onClose,
                      className: "px-5 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors",
                      children: "Cancel"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 1121,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "submit",
                      disabled: !hasChanges || loading,
                      className: `px-5 py-2.5 rounded-lg text-white font-medium transition-colors ${hasChanges && !loading ? "bg-violet-600 hover:bg-violet-700" : "bg-gray-400 cursor-not-allowed"}`,
                      children: loading ? /* @__PURE__ */ jsxDEV("span", { className: "flex items-center", children: [
                        /* @__PURE__ */ jsxDEV(
                          "svg",
                          {
                            className: "animate-spin -ml-1 mr-2 h-4 w-4 text-white",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            children: [
                              /* @__PURE__ */ jsxDEV(
                                "circle",
                                {
                                  className: "opacity-25",
                                  cx: "12",
                                  cy: "12",
                                  r: "10",
                                  stroke: "currentColor",
                                  strokeWidth: "4"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                                  lineNumber: 1143,
                                  columnNumber: 25
                                },
                                this
                              ),
                              /* @__PURE__ */ jsxDEV(
                                "path",
                                {
                                  className: "opacity-75",
                                  fill: "currentColor",
                                  d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                                  lineNumber: 1151,
                                  columnNumber: 25
                                },
                                this
                              )
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                            lineNumber: 1138,
                            columnNumber: 23
                          },
                          this
                        ),
                        "Saving..."
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                        lineNumber: 1137,
                        columnNumber: 19
                      }, this) : "Save Changes"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                      lineNumber: 1128,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                  lineNumber: 1120,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
                lineNumber: 840,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
              lineNumber: 778,
              columnNumber: 11
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
            lineNumber: 774,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
        lineNumber: 769,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx",
    lineNumber: 767,
    columnNumber: 5
  }, this);
};
_s(EditSalaryModal, "rfX83Hq0JZV9Mula0WcTpu9GNQE=", false, function() {
  return [notification.useNotification];
});
_c = EditSalaryModal;
export default EditSalaryModal;
var _c;
$RefreshReg$(_c, "EditSalaryModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/EditSalaryModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOHZCSSxtQkFjWSxjQWRaOzJCQTl2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFzZUEsT0FBT0EsU0FBU0MsVUFBVUMsaUJBQWlCO0FBQzNDLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsY0FBYztBQUN2QixNQUFNQyxrQkFBa0JBLENBQUMsRUFBRUMsV0FBV0MsU0FBU0MsUUFBUUMsY0FBYyxNQUFNO0FBQUFDLEtBQUE7QUFDekUsUUFBTSxDQUFDQyxLQUFLQyxhQUFhLElBQUlYLGFBQWFZLGdCQUFnQjtBQUMxRCxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSWpCLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNrQixZQUFZQyxhQUFhLElBQUluQixTQUFTO0FBQUEsSUFDM0NvQixVQUFVO0FBQUEsSUFDVkMsbUJBQW1CO0FBQUEsSUFDbkJDLGdCQUFnQjtBQUFBLElBQ2hCQyxNQUFNO0FBQUEsSUFDTkMsVUFBVTtBQUFBLElBQ1ZDLGdCQUFnQjtBQUFBLEVBQ2xCLENBQUM7QUFDRCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUkzQixTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDNEIsWUFBWUMsYUFBYSxJQUFJN0IsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzhCLFFBQVFDLFNBQVMsSUFBSS9CLFNBQVMsQ0FBQyxDQUFDO0FBRXZDLFFBQU0sQ0FBQ2dDLG1CQUFtQkMsb0JBQW9CLElBQUlqQyxTQUFTLENBQUMsRUFBRWtDLGFBQWEsSUFBSUMsUUFBUSxHQUFHLENBQUMsQ0FBQztBQUU1RmxDLFlBQVUsTUFBTTtBQUNkLFFBQUlPLGFBQWFFLFFBQVE7QUFDdkIsWUFBTTBCLFdBQVcxQixPQUFPMkI7QUFDeEIsWUFBTUMsZ0JBQWdCQyxNQUFNQyxRQUFRSixTQUFTZCxjQUFjLElBQ3ZEYyxTQUFTZCxlQUFlbUIsSUFBSSxDQUFBQyxPQUFNO0FBQUEsUUFDbENSLGFBQWFRLEVBQUVSLGVBQWU7QUFBQSxRQUM5QkMsUUFBUU8sRUFBRVAsVUFBVTtBQUFBLE1BQ3RCLEVBQUUsSUFDQSxDQUFDLEVBQUVELGFBQWEsSUFBSUMsUUFBUSxHQUFHLENBQUM7QUFDcENGLDJCQUFxQkssYUFBYTtBQUFBLElBQ3BDO0FBQUEsRUFDRixHQUFHLENBQUM5QixXQUFXRSxNQUFNLENBQUM7QUFFdEIsUUFBTWlDLHdCQUF3QkEsTUFBTTtBQUNsQ1YseUJBQXFCLENBQUMsR0FBR0QsbUJBQW1CLEVBQUVFLGFBQWEsSUFBSUMsUUFBUSxHQUFHLENBQUMsQ0FBQztBQUFBLEVBQzlFO0FBRUEsUUFBTVMsMkJBQTJCQSxDQUFDQyxPQUFPQyxPQUFPQyxVQUFVO0FBQ3hELFVBQU1DLFVBQVUsQ0FBQyxHQUFHaEIsaUJBQWlCO0FBQ3JDZ0IsWUFBUUgsS0FBSyxFQUFFQyxLQUFLLElBQUlDO0FBQ3hCZCx5QkFBcUJlLE9BQU87QUFBQSxFQUM5QjtBQUVBLFFBQU1DLDJCQUEyQkEsQ0FBQ0osVUFBVTtBQUMxQ1oseUJBQXFCRCxrQkFBa0JrQixPQUFPLENBQUNDLEdBQUdDLE1BQU1BLE1BQU1QLEtBQUssQ0FBQztBQUFBLEVBQ3RFO0FBRUE1QyxZQUFVLE1BQU07QUFDZCxRQUFJTyxhQUFhRSxRQUFRO0FBQ3ZCLFlBQU0wQixXQUFXMUIsT0FBTzJCO0FBQ3hCLFlBQU1nQixnQkFBZ0I7QUFBQSxRQUNwQmpDLFVBQVUsSUFBSWtDLEtBQUtsQixTQUFTbUIsV0FBV0MsSUFBSSxFQUN4Q0MsWUFBWSxFQUNaQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDZnJDLG1CQUFtQmUsU0FBU2Y7QUFBQUEsUUFDNUJDLGdCQUFnQmMsU0FBU2Qsa0JBQWtCO0FBQUEsUUFDM0NDLE1BQU1hLFNBQVNiO0FBQUFBLFFBQ2ZDLFVBQVVZLFNBQVNaO0FBQUFBLFFBQ25CQyxnQkFBZ0JXLFNBQVNYLGtCQUFrQjtBQUFBLE1BQzdDO0FBQ0FOLG9CQUFja0MsYUFBYTtBQUMzQjFCLHdCQUFrQjBCLGFBQWE7QUFDL0J4QixvQkFBYyxLQUFLO0FBQ25CRSxnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLENBQUN2QixXQUFXRSxNQUFNLENBQUM7QUFXdEJULFlBQVUsTUFBTTtBQUNoQixRQUFJeUIsa0JBQWtCaEIsUUFBUTtBQUU1QixZQUFNaUQsY0FBY0MsT0FBT0MsS0FBS25DLGNBQWMsRUFBRW9DO0FBQUFBLFFBQzlDLENBQUNDLFFBQVE3QyxXQUFXNkMsR0FBRyxNQUFNckMsZUFBZXFDLEdBQUc7QUFBQSxNQUNqRDtBQUdKLFlBQU1DLHdCQUF3QnpCLE1BQU1DLFFBQVE5QixRQUFRMkIsaUJBQWlCZixjQUFjLElBQy9FWixPQUFPMkIsZ0JBQWdCZixlQUFlbUIsSUFBSSxDQUFDQyxPQUFPO0FBQUEsUUFDaERSLGFBQWFRLEVBQUVSLGVBQWU7QUFBQSxRQUM5QkMsUUFBUThCLE9BQU92QixFQUFFUCxNQUFNLEtBQUs7QUFBQSxNQUM5QixFQUFFLElBQ0Y7QUFFQSxZQUFNK0IsdUJBQXVCbEMsa0JBQWtCUyxJQUFJLENBQUNDLE9BQU87QUFBQSxRQUN6RFIsYUFBYVEsRUFBRVI7QUFBQUEsUUFDZkMsUUFBUThCLE9BQU92QixFQUFFUCxNQUFNO0FBQUEsTUFDekIsRUFBRTtBQUVGLFlBQU1nQyx1QkFDSkMsS0FBS0MsVUFBVUgsb0JBQW9CLE1BQ25DRSxLQUFLQyxVQUFVTCxxQkFBcUI7QUFFdENuQyxvQkFBYzhCLGVBQWVRLG9CQUFvQjtBQUFBLElBQ25EO0FBQUEsRUFDRixHQUFHLENBQUNqRCxZQUFZYyxtQkFBbUJOLGdCQUFnQmhCLE1BQU0sQ0FBQztBQUV4RCxRQUFNNEQsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxZQUFZLENBQUM7QUFDbkIsUUFDRXJELFdBQVdHLHNCQUFzQixPQUNoQ21ELE1BQU10RCxXQUFXRyxpQkFBaUIsS0FBS0gsV0FBV0csb0JBQW9CLElBQ3ZFO0FBQ0FrRCxnQkFBVWxELG9CQUFvQjtBQUFBLElBQ2hDO0FBT0EsUUFBSUgsV0FBV00sYUFBYSxZQUFZLENBQUNOLFdBQVdPLGdCQUFnQjtBQUNsRThDLGdCQUFVOUMsaUJBQ1I7QUFBQSxJQUNKO0FBQ0FNLGNBQVV3QyxTQUFTO0FBQ25CLFdBQU9YLE9BQU9DLEtBQUtVLFNBQVMsRUFBRUUsV0FBVztBQUFBLEVBQzNDO0FBNkRGLFFBQU1DLGVBQWUsT0FBT0MsTUFBTTtBQUNoQ0EsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUNOLGFBQWEsRUFBRztBQUVyQnJELGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNNEQsVUFBVSxDQUFDO0FBR2pCLFVBQUkzRCxXQUFXRSxhQUFhTSxlQUFlTixVQUFVO0FBQ25EeUQsZ0JBQVF6RCxXQUFXRixXQUFXRTtBQUFBQSxNQUNoQztBQUNBLFVBQUlGLFdBQVdHLHNCQUFzQkssZUFBZUwsbUJBQW1CO0FBQ3JFd0QsZ0JBQVF4RCxvQkFBb0J5RCxXQUFXNUQsV0FBV0csaUJBQWlCO0FBQUEsTUFDckU7QUFDQSxVQUFJSCxXQUFXSyxTQUFTRyxlQUFlSCxNQUFNO0FBQzNDc0QsZ0JBQVF0RCxPQUFPTCxXQUFXSztBQUFBQSxNQUM1QjtBQUNBLFVBQUlMLFdBQVdNLGFBQWFFLGVBQWVGLFVBQVU7QUFDbkRxRCxnQkFBUXJELFdBQVdOLFdBQVdNO0FBQUFBLE1BQ2hDO0FBQ0EsVUFBSU4sV0FBV08sbUJBQW1CQyxlQUFlRCxnQkFBZ0I7QUFDL0RvRCxnQkFBUXBELGlCQUFpQlAsV0FBV087QUFBQUEsTUFDdEM7QUFHQSxZQUFNc0QscUJBQXFCL0Msa0JBQ3hCa0I7QUFBQUEsUUFDQyxDQUFDOEIsU0FDQ0EsS0FBSzlDLFlBQVkrQyxLQUFLLE1BQU0sTUFDNUIsQ0FBQ1QsTUFBTVAsT0FBT2UsS0FBSzdDLE1BQU0sQ0FBQyxLQUMxQjhCLE9BQU9lLEtBQUs3QyxNQUFNLEtBQUs7QUFBQSxNQUMzQixFQUNDTSxJQUFJLENBQUN1QyxVQUFVO0FBQUEsUUFDZDlDLGFBQWE4QyxLQUFLOUMsWUFBWStDLEtBQUs7QUFBQSxRQUNuQzlDLFFBQVE4QixPQUFPZSxLQUFLN0MsTUFBTTtBQUFBLE1BQzVCLEVBQUU7QUFHSixZQUFNNkIsd0JBQ0p6QixNQUFNQyxRQUFROUIsUUFBUTJCLGlCQUFpQmYsY0FBYyxLQUNyRFosT0FBTzJCLGdCQUFnQmYsZUFBZW1CLElBQUksQ0FBQ0MsT0FBTztBQUFBLFFBQ2hEUixhQUFhUSxFQUFFUjtBQUFBQSxRQUNmQyxRQUFROEIsT0FBT3ZCLEVBQUVQLE1BQU07QUFBQSxNQUN6QixFQUFFO0FBRUosWUFBTStDLDBCQUNKZCxLQUFLQyxVQUFVVSxrQkFBa0IsTUFDakNYLEtBQUtDLFVBQVVMLHFCQUFxQjtBQUV0QyxVQUFJa0IseUJBQXlCO0FBQzNCTCxnQkFBUXZELGlCQUFpQnlEO0FBQUFBLE1BQzNCO0FBR0EsVUFBSW5CLE9BQU9DLEtBQUtnQixPQUFPLEVBQUVKLFdBQVcsR0FBRztBQUNyQzVELFlBQUlzRSxLQUFLO0FBQUEsVUFDUEMsU0FBUztBQUFBLFVBQ1RsRCxhQUFhO0FBQUEsVUFDYm1ELFdBQVc7QUFBQSxRQUNiLENBQUM7QUFDRDtBQUFBLE1BQ0Y7QUFHQSxZQUFNbkYsSUFBSW9GLElBQUksZ0JBQWdCNUUsT0FBTzZFLEdBQUcsSUFBSVYsT0FBTztBQUVuRGhFLFVBQUlzRSxLQUFLO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RsRCxhQUFhO0FBQUEsUUFDYm1ELFdBQVc7QUFBQSxNQUNiLENBQUM7QUFFRCxVQUFJMUUsY0FBZUEsZUFBYztBQUFBLElBQ25DLFNBQVM2RSxPQUFPO0FBQ2QsWUFBTUosVUFDSkksTUFBTUMsVUFBVUMsTUFBTUYsU0FBUztBQUNqQzNFLFVBQUlzRSxLQUFLO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RsRCxhQUFha0Q7QUFBQUEsUUFDYkMsV0FBVztBQUFBLE1BQ2IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDcEUsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUlFLE1BQUksQ0FBQ1AsVUFBVSxDQUFDRixVQUFXLFFBQU87QUFFbEMsU0FDRSxtQ0FDR007QUFBQUE7QUFBQUEsSUFDRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVyw4R0FBOEdOLFlBQVksZ0JBQWdCLCtCQUErQjtBQUFBLFFBRXBMLFNBQVNDO0FBQUFBLFFBRVQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLFNBQVMsQ0FBQ2tFLE1BQU1BLEVBQUVnQixnQkFBZ0I7QUFBQSxZQUVsQyxpQ0FBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLHNEQUFxRCxtQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0I7QUFBQTtBQUFBLG9CQUNSO0FBQUEsb0JBQzFCakYsT0FBT2tGLGFBQWFDLFFBQVE7QUFBQSx1QkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTcEY7QUFBQUEsb0JBQ1QsV0FBVTtBQUFBLG9CQUVWO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixNQUFLO0FBQUEsd0JBQ0wsUUFBTztBQUFBLHdCQUNQLFNBQVE7QUFBQSx3QkFFUjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxlQUFjO0FBQUEsNEJBQ2QsZ0JBQWU7QUFBQSw0QkFDZixhQUFZO0FBQUEsNEJBQ1osR0FBRTtBQUFBO0FBQUEsMEJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUkwQjtBQUFBO0FBQUEsc0JBVjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFZQTtBQUFBO0FBQUEsa0JBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFpQkE7QUFBQSxtQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0QkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSw4RkFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsUUFBRyxXQUFVLHVDQUFzQywrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0I7QUFBQTtBQUFBLG9CQUNsQztBQUFBLG9CQUNQLElBQUk2QztBQUFBQSxzQkFDSDVDLE9BQU8yQixnQkFBZ0JrQixXQUFXQztBQUFBQSxvQkFDcEMsRUFBRXNDLG1CQUFtQjtBQUFBLG9CQUFHO0FBQUEsb0JBQUk7QUFBQSxvQkFFM0IsSUFBSXhDO0FBQUFBLHNCQUNINUMsT0FBTzJCLGdCQUFnQmtCLFdBQVd3QztBQUFBQSxvQkFDcEMsRUFBRUQsbUJBQW1CO0FBQUEsdUJBUnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxxQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUscUNBQW9DO0FBQUE7QUFBQSxxQkFHN0NoQjtBQUFBQSxzQkFDRXBFLE9BQU8yQixnQkFBZ0JoQixxQkFBcUI7QUFBQSxvQkFDOUMsSUFBSXlELFdBQVdwRSxPQUFPMkIsZ0JBQWdCZixrQkFBa0IsQ0FBQyxHQUN6RDBFLFFBQVEsQ0FBQztBQUFBLHVCQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsMkJBQTBCLG9DQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRDtBQUFBLHFCQVQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsbUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkJBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNkJBO0FBQUEsY0FFQSx1QkFBQyxVQUFLLFVBQVV0QixjQUFjLFdBQVUsYUFFdEM7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsb0RBQ1o7QUFBQSwyQ0FBQyxjQUFXLFdBQVUsMEJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRDO0FBQUEsb0JBQUc7QUFBQSx1QkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDJDQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLG9DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG9EQUNiLGlDQUFDLE9BQUUsV0FBVSxpQkFDVmhELDBCQUFnQk4sWUFBWSxTQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJQTtBQUFBLHlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBU0E7QUFBQSxvQkFDQSx1QkFBQyxTQUNDO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyxnQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxPQUFPRixXQUFXRTtBQUFBQSwwQkFDbEIsVUFBVSxDQUFDdUQsTUFDVHhELGNBQWM7QUFBQSw0QkFDWixHQUFHRDtBQUFBQSw0QkFDSEUsVUFBVXVELEVBQUVzQixPQUFPbEQ7QUFBQUEsMEJBQ3JCLENBQUM7QUFBQSwwQkFFSCxXQUFXLHNDQUFzQ2pCLE9BQU9WLFdBQ2xELG1CQUNBLHlDQUF5QztBQUFBLDBCQUUvQyxLQUFLVixPQUFPMkIsZ0JBQWdCa0IsV0FBV0M7QUFBQUEsMEJBQ3ZDLE1BQUssb0JBQUlGLEtBQUssR0FBRUcsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUE7QUFBQSx3QkFkNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWM4QztBQUFBLHNCQUU3QzVCLE9BQU9WLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVSxpQkFBT1YsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBeUJBO0FBQUEsdUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBcUNBO0FBQUEscUJBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMkNBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLG9EQUNaO0FBQUEsMkNBQUMsZUFBWSxXQUFVLHlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0QztBQUFBLG9CQUFHO0FBQUEsdUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSwyQ0FBQyxTQUNDO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyxrQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxvREFDYixpQ0FBQyxPQUFFLFdBQVUsaUJBQWdCO0FBQUE7QUFBQSx3QkFDekJWLE9BQU8yQixnQkFBZ0I2RCxhQUFhRixRQUFRLENBQUM7QUFBQSwyQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSUE7QUFBQSx5QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBO0FBQUEsb0JBQ0EsdUJBQUMsU0FDQztBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MscUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLEtBQUk7QUFBQSwwQkFDSixPQUFPOUUsV0FBV0c7QUFBQUEsMEJBQ2xCLFVBQVUsQ0FBQ3NELE1BQ1R4RCxjQUFjO0FBQUEsNEJBQ1osR0FBR0Q7QUFBQUEsNEJBQ0hHLG1CQUFtQnNELEVBQUVzQixPQUFPbEQ7QUFBQUEsMEJBQzlCLENBQUM7QUFBQSwwQkFFSCxXQUFXLHNDQUFzQ2pCLE9BQU9ULG9CQUNsRCxtQkFDQSx5Q0FBeUM7QUFBQSwwQkFFL0MsYUFBWTtBQUFBO0FBQUEsd0JBZmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWVvQztBQUFBLHNCQUVuQ1MsT0FBT1QscUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWUyxpQkFBT1QscUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQTBCQTtBQUFBLHVCQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXNDQTtBQUFBLGtCQW1DQSx1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsa0NBQWlDLG1DQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUNXLGtCQUFrQlM7QUFBQUEsc0JBQUksQ0FBQ3VDLE1BQU1uQyxVQUM1Qix1QkFBQyxTQUFnQixXQUFVLDhDQUN6QjtBQUFBLCtDQUFDLFNBQ0M7QUFBQSxpREFBQyxXQUFNLFdBQVUsZ0RBQStDLG1DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0E7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsTUFBSztBQUFBLDhCQUNMLGFBQVk7QUFBQSw4QkFDWixPQUFPbUMsS0FBSzlDO0FBQUFBLDhCQUNaLFVBQVUsQ0FBQ3lDLE1BQ1QvQix5QkFBeUJDLE9BQU8sZUFBZThCLEVBQUVzQixPQUFPbEQsS0FBSztBQUFBLDhCQUUvRCxXQUFVO0FBQUE7QUFBQSw0QkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBT21HO0FBQUEsNkJBWHJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBYUE7QUFBQSx3QkFDQSx1QkFBQyxTQUNDO0FBQUEsaURBQUMsV0FBTSxXQUFVLGdEQUErQyxrQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLE1BQUs7QUFBQSw4QkFDTCxLQUFJO0FBQUEsOEJBQ0osTUFBSztBQUFBLDhCQUNMLGFBQVk7QUFBQSw4QkFDWixPQUFPaUMsS0FBSzdDO0FBQUFBLDhCQUNaLFVBQVUsQ0FBQ3dDLE1BQ1QvQix5QkFBeUJDLE9BQU8sVUFBVThCLEVBQUVzQixPQUFPbEQsS0FBSztBQUFBLDhCQUUxRCxXQUFVO0FBQUE7QUFBQSw0QkFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBU21HO0FBQUEsNkJBYnJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBZUE7QUFBQSx3QkFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ1pGLGtCQUFRLEtBQ1A7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsTUFBSztBQUFBLDRCQUNMLFNBQVMsTUFBTUkseUJBQXlCSixLQUFLO0FBQUEsNEJBQzdDLFdBQVU7QUFBQSw0QkFBK0M7QUFBQTtBQUFBLDBCQUgzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBTUEsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVVBO0FBQUEsMkJBekNRQSxPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBMENBO0FBQUEsb0JBQ0Q7QUFBQSxvQkFFRDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsU0FBU0Y7QUFBQUEsd0JBQ1QsV0FBVTtBQUFBLHdCQUFnRztBQUFBO0FBQUEsc0JBSDVHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLHVCQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTBEQTtBQUFBLHFCQXhJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBJQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLHlDQUFDLFFBQUcsV0FBVSxvREFBbUQsOEJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHNDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG9EQUNiLGlDQUFDLE9BQUUsV0FBVSw0QkFDVmpCLDBCQUFnQkYsWUFBWSxTQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJQTtBQUFBLHlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBU0E7QUFBQSxvQkFFQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLGtDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsT0FBT04sV0FBV007QUFBQUEsMEJBQ2xCLFVBQVUsQ0FBQ3VCLFVBQ1Q1QixjQUFjLEVBQUUsR0FBR0QsWUFBWU0sVUFBVXVCLE1BQU0sQ0FBQztBQUFBLDBCQUVsRCxXQUFVO0FBQUEsMEJBRVY7QUFBQSxtREFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFFBQU8sb0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWdDO0FBQUEsNEJBQ2hDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFBUywrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDRCQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFBUyxzQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBb0M7QUFBQSw0QkFDcEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxpQkFBZ0IsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQTtBQUFBO0FBQUEsd0JBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWVBO0FBQUEseUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBb0JBO0FBQUEsdUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUNBO0FBQUEsa0JBRUM3QixXQUFXTSxhQUFhLFlBQ3ZCLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyw4QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxPQUFPTixXQUFXTztBQUFBQSx3QkFDbEIsVUFBVSxDQUFDa0QsTUFDVHhELGNBQWM7QUFBQSwwQkFDWixHQUFHRDtBQUFBQSwwQkFDSE8sZ0JBQWdCa0QsRUFBRXNCLE9BQU9sRDtBQUFBQSx3QkFDM0IsQ0FBQztBQUFBLHdCQUVILFdBQVcsc0NBQXNDakIsT0FBT0wsaUJBQ2xELG1CQUNBLHlDQUF5QztBQUFBLHdCQUUvQyxhQUFZO0FBQUE7QUFBQSxzQkFiZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBYW9DO0FBQUEsb0JBRW5DSyxPQUFPTCxrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZLLGlCQUFPTCxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBd0JBO0FBQUEscUJBaEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0VBO0FBQUEsZ0JBR0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUcsV0FBVSxvREFBbUQsZ0NBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFPUCxXQUFXSztBQUFBQSxzQkFDbEIsVUFBVSxDQUFDb0QsTUFDVHhELGNBQWMsRUFBRSxHQUFHRCxZQUFZSyxNQUFNb0QsRUFBRXNCLE9BQU9sRCxNQUFNLENBQUM7QUFBQSxzQkFFdkQsV0FBVyxzQ0FBc0NqQixPQUFPUCxPQUNsRCxtQkFDQSx5Q0FBeUM7QUFBQSxzQkFFL0MsTUFBSztBQUFBLHNCQUNMLGFBQVk7QUFBQTtBQUFBLG9CQVZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFVbUQ7QUFBQSxrQkFFbkQsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qiw4REFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTZDtBQUFBQSxzQkFDVCxXQUFVO0FBQUEsc0JBQWdHO0FBQUE7QUFBQSxvQkFINUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFVBQVUsQ0FBQ21CLGNBQWNaO0FBQUFBLHNCQUN6QixXQUFXLG1FQUFtRVksY0FBYyxDQUFDWixVQUN2RixzQ0FDQSxnQ0FBZ0M7QUFBQSxzQkFHckNBLG9CQUNDLHVCQUFDLFVBQUssV0FBVSxxQkFDZDtBQUFBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixNQUFLO0FBQUEsNEJBQ0wsU0FBUTtBQUFBLDRCQUVSO0FBQUE7QUFBQSxnQ0FBQztBQUFBO0FBQUEsa0NBQ0MsV0FBVTtBQUFBLGtDQUNWLElBQUc7QUFBQSxrQ0FDSCxJQUFHO0FBQUEsa0NBQ0gsR0FBRTtBQUFBLGtDQUNGLFFBQU87QUFBQSxrQ0FDUCxhQUFZO0FBQUE7QUFBQSxnQ0FOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBT0M7QUFBQSw4QkFDRDtBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FDQyxXQUFVO0FBQUEsa0NBQ1YsTUFBSztBQUFBLGtDQUNMLEdBQUU7QUFBQTtBQUFBLGdDQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFJQztBQUFBO0FBQUE7QUFBQSwwQkFqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWtCQTtBQUFBLHdCQUFNO0FBQUEsMkJBbkJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBcUJBLElBRUE7QUFBQTtBQUFBLG9CQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBa0NBO0FBQUEscUJBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMkNBO0FBQUEsbUJBblVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb1VBO0FBQUEsaUJBbFlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbVlBO0FBQUE7QUFBQSxVQXZZRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF3WUE7QUFBQTtBQUFBLE1BN1lGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQThZQTtBQUFBLE9BaFpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpWkE7QUFFSjtBQUFFSixHQXJxQklMLGlCQUFlO0FBQUEsVUFDVUosYUFBYVksZUFBZTtBQUFBO0FBQUFvRixLQURyRDVGO0FBdXFCTixlQUFlQTtBQUFnQixJQUFBNEY7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJBUEkiLCJub3RpZmljYXRpb24iLCJGYUNhbGVuZGFyIiwiRmFSdXBlZVNpZ24iLCJTZWxlY3QiLCJFZGl0U2FsYXJ5TW9kYWwiLCJpc1Zpc2libGUiLCJvbkNsb3NlIiwic2FsYXJ5Iiwib25FZGl0U3VjY2VzcyIsIl9zIiwiYXBpIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZm9ybVZhbHVlcyIsInNldEZvcm1WYWx1ZXMiLCJwYXlfZGF0ZSIsInRvdGFsX3BhaWRfYW1vdW50Iiwib3RoZXJfcGF5bWVudHMiLCJub3RlIiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsIm9yaWdpbmFsVmFsdWVzIiwic2V0T3JpZ2luYWxWYWx1ZXMiLCJoYXNDaGFuZ2VzIiwic2V0SGFzQ2hhbmdlcyIsImVycm9ycyIsInNldEVycm9ycyIsIm90aGVyUGF5bWVudHNMaXN0Iiwic2V0T3RoZXJQYXltZW50c0xpc3QiLCJkZXNjcmlwdGlvbiIsImFtb3VudCIsIm1ldGFkYXRhIiwicGF5b3V0X21ldGFkYXRhIiwiZXhpc3RpbmdPdGhlciIsIkFycmF5IiwiaXNBcnJheSIsIm1hcCIsInAiLCJoYW5kbGVBZGRPdGhlclBheW1lbnQiLCJoYW5kbGVPdGhlclBheW1lbnRDaGFuZ2UiLCJpbmRleCIsImZpZWxkIiwidmFsdWUiLCJ1cGRhdGVkIiwiaGFuZGxlUmVtb3ZlT3RoZXJQYXltZW50IiwiZmlsdGVyIiwiXyIsImkiLCJpbml0aWFsVmFsdWVzIiwiRGF0ZSIsImRhdGVfcmFuZ2UiLCJmcm9tIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImZvcm1DaGFuZ2VkIiwiT2JqZWN0Iiwia2V5cyIsInNvbWUiLCJrZXkiLCJvcmlnaW5hbE90aGVyUGF5bWVudHMiLCJOdW1iZXIiLCJjdXJyZW50T3RoZXJQYXltZW50cyIsIm90aGVyUGF5bWVudHNDaGFuZ2VkIiwiSlNPTiIsInN0cmluZ2lmeSIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsImlzTmFOIiwibGVuZ3RoIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwicGF5bG9hZCIsInBhcnNlRmxvYXQiLCJjbGVhbk90aGVyUGF5bWVudHMiLCJpdGVtIiwidHJpbSIsImhhc090aGVyUGF5bWVudHNDaGFuZ2VkIiwib3BlbiIsIm1lc3NhZ2UiLCJjbGFzc05hbWUiLCJwdXQiLCJfaWQiLCJlcnJvciIsInJlc3BvbnNlIiwiZGF0YSIsInN0b3BQcm9wYWdhdGlvbiIsImVtcGxveWVlX2lkIiwibmFtZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInRvIiwidG9GaXhlZCIsInRhcmdldCIsInRvdGFsX3NhbGFyeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVkaXRTYWxhcnlNb2RhbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuLy8gaW1wb3J0IEFQSSBmcm9tIFwiLi4vLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG4vLyBpbXBvcnQgeyBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG4vLyBpbXBvcnQgeyBGYUNhbGVuZGFyIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbi8vIGltcG9ydCB7IEZhUnVwZWVTaWduIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbi8vIGltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbi8vIGNvbnN0IEVkaXRTYWxhcnlNb2RhbCA9ICh7IGlzVmlzaWJsZSwgb25DbG9zZSwgc2FsYXJ5LCBvbkVkaXRTdWNjZXNzIH0pID0+IHtcclxuLy8gICBjb25zdCBbYXBpLCBjb250ZXh0SG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcclxuLy8gICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2Zvcm1WYWx1ZXMsIHNldEZvcm1WYWx1ZXNdID0gdXNlU3RhdGUoe1xyXG4vLyAgICAgcGF5X2RhdGU6IFwiXCIsXHJcbi8vICAgICB0b3RhbF9wYWlkX2Ftb3VudDogXCJcIixcclxuLy8gICAgIG90aGVyX3BheW1lbnRzOiBcIlwiLFxyXG4vLyAgICAgbm90ZTogXCJcIixcclxuLy8gICAgIHBheV90eXBlOiBcIlwiLFxyXG4vLyAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbi8vICAgfSk7XHJcbi8vICAgY29uc3QgW29yaWdpbmFsVmFsdWVzLCBzZXRPcmlnaW5hbFZhbHVlc10gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbaGFzQ2hhbmdlcywgc2V0SGFzQ2hhbmdlc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGlmIChpc1Zpc2libGUgJiYgc2FsYXJ5KSB7XHJcbi8vICAgICAgIGNvbnN0IG1ldGFkYXRhID0gc2FsYXJ5LnBheW91dF9tZXRhZGF0YTtcclxuLy8gICAgICAgY29uc3QgaW5pdGlhbFZhbHVlcyA9IHtcclxuLy8gICAgICAgICBwYXlfZGF0ZTogbmV3IERhdGUobWV0YWRhdGEuZGF0ZV9yYW5nZS5mcm9tKVxyXG4vLyAgICAgICAgICAgLnRvSVNPU3RyaW5nKClcclxuLy8gICAgICAgICAgIC5zcGxpdChcIlRcIilbMF0sXHJcbi8vICAgICAgICAgdG90YWxfcGFpZF9hbW91bnQ6IG1ldGFkYXRhLnRvdGFsX3BhaWRfYW1vdW50LFxyXG4vLyAgICAgICAgIG90aGVyX3BheW1lbnRzOiBtZXRhZGF0YS5vdGhlcl9wYXltZW50cyB8fCBcIlwiLFxyXG4vLyAgICAgICAgIG5vdGU6IG1ldGFkYXRhLm5vdGUsXHJcbi8vICAgICAgICAgcGF5X3R5cGU6IG1ldGFkYXRhLnBheV90eXBlLFxyXG4vLyAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBtZXRhZGF0YS50cmFuc2FjdGlvbl9pZCB8fCBcIlwiLFxyXG4vLyAgICAgICB9O1xyXG4vLyAgICAgICBzZXRGb3JtVmFsdWVzKGluaXRpYWxWYWx1ZXMpO1xyXG4vLyAgICAgICBzZXRPcmlnaW5hbFZhbHVlcyhpbml0aWFsVmFsdWVzKTtcclxuLy8gICAgICAgc2V0SGFzQ2hhbmdlcyhmYWxzZSk7XHJcbi8vICAgICAgIHNldEVycm9ycyh7fSk7XHJcbi8vICAgICB9XHJcbi8vICAgfSwgW2lzVmlzaWJsZSwgc2FsYXJ5XSk7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBpZiAob3JpZ2luYWxWYWx1ZXMpIHtcclxuLy8gICAgICAgY29uc3QgY2hhbmdlZCA9IE9iamVjdC5rZXlzKG9yaWdpbmFsVmFsdWVzKS5zb21lKChrZXkpID0+IHtcclxuLy8gICAgICAgICByZXR1cm4gZm9ybVZhbHVlc1trZXldICE9PSBvcmlnaW5hbFZhbHVlc1trZXldO1xyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgc2V0SGFzQ2hhbmdlcyhjaGFuZ2VkKTtcclxuLy8gICAgIH1cclxuLy8gICB9LCBbZm9ybVZhbHVlcywgb3JpZ2luYWxWYWx1ZXNdKTtcclxuXHJcbi8vICAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbi8vICAgICBpZiAoXHJcbi8vICAgICAgIGZvcm1WYWx1ZXMudG90YWxfcGFpZF9hbW91bnQgIT09IFwiXCIgJiZcclxuLy8gICAgICAgKGlzTmFOKGZvcm1WYWx1ZXMudG90YWxfcGFpZF9hbW91bnQpIHx8IGZvcm1WYWx1ZXMudG90YWxfcGFpZF9hbW91bnQgPCAwKVxyXG4vLyAgICAgKSB7XHJcbi8vICAgICAgIG5ld0Vycm9ycy50b3RhbF9wYWlkX2Ftb3VudCA9IFwiQW1vdW50IG11c3QgYmUgYSBwb3NpdGl2ZSBudW1iZXJcIjtcclxuLy8gICAgIH1cclxuLy8gICAgIGlmIChcclxuLy8gICAgICAgZm9ybVZhbHVlcy5vdGhlcl9wYXltZW50cyAhPT0gXCJcIiAmJlxyXG4vLyAgICAgICAoaXNOYU4oZm9ybVZhbHVlcy5vdGhlcl9wYXltZW50cykgfHwgZm9ybVZhbHVlcy5vdGhlcl9wYXltZW50cyA8IDApXHJcbi8vICAgICApIHtcclxuLy8gICAgICAgbmV3RXJyb3JzLm90aGVyX3BheW1lbnRzID0gXCJPdGhlciBwYXltZW50cyBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyXCI7XHJcbi8vICAgICB9XHJcbi8vICAgICBpZiAoZm9ybVZhbHVlcy5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiAmJiAhZm9ybVZhbHVlcy50cmFuc2FjdGlvbl9pZCkge1xyXG4vLyAgICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPVxyXG4vLyAgICAgICAgIFwiVHJhbnNhY3Rpb24gSUQgaXMgcmVxdWlyZWQgZm9yIG9ubGluZSBwYXltZW50c1wiO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbi8vICAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuLy8gICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuLy8gICAgIGlmICghdmFsaWRhdGVGb3JtKCkpIHJldHVybjtcclxuXHJcbi8vICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcGF5bG9hZCA9IHt9O1xyXG5cclxuLy8gICAgICAgLy8gT25seSBpbmNsdWRlIGZpZWxkcyB0aGF0IGhhdmUgY2hhbmdlZFxyXG4vLyAgICAgICBpZiAoZm9ybVZhbHVlcy5wYXlfZGF0ZSAhPT0gb3JpZ2luYWxWYWx1ZXMucGF5X2RhdGUpIHtcclxuLy8gICAgICAgICBwYXlsb2FkLnBheV9kYXRlID0gZm9ybVZhbHVlcy5wYXlfZGF0ZTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgICBpZiAoZm9ybVZhbHVlcy50b3RhbF9wYWlkX2Ftb3VudCAhPT0gb3JpZ2luYWxWYWx1ZXMudG90YWxfcGFpZF9hbW91bnQpIHtcclxuLy8gICAgICAgICBwYXlsb2FkLnRvdGFsX3BhaWRfYW1vdW50ID0gcGFyc2VGbG9hdChmb3JtVmFsdWVzLnRvdGFsX3BhaWRfYW1vdW50KTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgICBpZiAoZm9ybVZhbHVlcy5vdGhlcl9wYXltZW50cyAhPT0gb3JpZ2luYWxWYWx1ZXMub3RoZXJfcGF5bWVudHMpIHtcclxuLy8gICAgICAgICBwYXlsb2FkLm90aGVyX3BheW1lbnRzID0gcGFyc2VGbG9hdChmb3JtVmFsdWVzLm90aGVyX3BheW1lbnRzKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgICBpZiAoZm9ybVZhbHVlcy5ub3RlICE9PSBvcmlnaW5hbFZhbHVlcy5ub3RlKSB7XHJcbi8vICAgICAgICAgcGF5bG9hZC5ub3RlID0gZm9ybVZhbHVlcy5ub3RlO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICAgIGlmIChmb3JtVmFsdWVzLnBheV90eXBlICE9PSBvcmlnaW5hbFZhbHVlcy5wYXlfdHlwZSkge1xyXG4vLyAgICAgICAgIHBheWxvYWQucGF5X3R5cGUgPSBmb3JtVmFsdWVzLnBheV90eXBlO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICAgIGlmIChmb3JtVmFsdWVzLnRyYW5zYWN0aW9uX2lkICE9PSBvcmlnaW5hbFZhbHVlcy50cmFuc2FjdGlvbl9pZCkge1xyXG4vLyAgICAgICAgIHBheWxvYWQudHJhbnNhY3Rpb25faWQgPSBmb3JtVmFsdWVzLnRyYW5zYWN0aW9uX2lkO1xyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBpZiAoT2JqZWN0LmtleXMocGF5bG9hZCkubGVuZ3RoID09PSAwKSB7XHJcbi8vICAgICAgICAgYXBpLm9wZW4oe1xyXG4vLyAgICAgICAgICAgbWVzc2FnZTogXCJObyBjaGFuZ2VzIG1hZGVcIixcclxuLy8gICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIk5vIGZpZWxkcyB3ZXJlIGNoYW5nZWRcIixcclxuLy8gICAgICAgICAgIGNsYXNzTmFtZTogXCJiZy12aW9sZXQtNTAwIHJvdW5kZWQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCIsXHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgICAgcmV0dXJuO1xyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkucHV0KGAvc2FsYXJ5L2VkaXQvJHtzYWxhcnkuX2lkfWAsIHBheWxvYWQpO1xyXG5cclxuLy8gICAgICAgYXBpLm9wZW4oe1xyXG4vLyAgICAgICAgIG1lc3NhZ2U6IFwiU2FsYXJ5IFBheW1lbnQgVXBkYXRlZFwiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlNhbGFyeSBwYXltZW50IGhhcyBiZWVuIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbi8vICAgICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTUwMCByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiLFxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIGlmIChvbkVkaXRTdWNjZXNzKSBvbkVkaXRTdWNjZXNzKCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zdCBtZXNzYWdlID1cclxuLy8gICAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8uZXJyb3IgfHwgXCJGYWlsZWQgdG8gdXBkYXRlIHNhbGFyeSBwYXltZW50XCI7XHJcbi8vICAgICAgIGFwaS5vcGVuKHtcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIlVwZGF0ZSBGYWlsZWRcIixcclxuLy8gICAgICAgICBkZXNjcmlwdGlvbjogbWVzc2FnZSxcclxuLy8gICAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTUwMCByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGlmICghc2FsYXJ5IHx8ICFpc1Zpc2libGUpIHJldHVybiBudWxsO1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPD5cclxuLy8gICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbi8vICAgICAgIDxkaXZcclxuLy8gICAgICAgICBjbGFzc05hbWU9e2BmaXhlZCBpbnNldC0wIGJnLWJsYWNrIGJnLW9wYWNpdHktNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei01MCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tMzAwICR7XHJcbi8vICAgICAgICAgICBpc1Zpc2libGUgPyBcIm9wYWNpdHktMTAwXCIgOiBcIm9wYWNpdHktMCBwb2ludGVyLWV2ZW50cy1ub25lXCJcclxuLy8gICAgICAgICB9YH1cclxuLy8gICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4vLyAgICAgICA+XHJcbi8vICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgdy1mdWxsIG1heC13LTN4bCBtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvIHRyYW5zZm9ybSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgcmVsYXRpdmUgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCJcclxuLy8gICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxyXG4vLyAgICAgICAgID5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04XCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgRWRpdCBTYWxhcnkgUGF5bWVudFxyXG4vLyAgICAgICAgICAgICAgICAgPC9oMj5cclxuLy8gICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBVcGRhdGUgcGF5bWVudCBkZXRhaWxzIGZvcntcIiBcIn1cclxuLy8gICAgICAgICAgICAgICAgICAge3NhbGFyeS5lbXBsb3llZV9pZD8ubmFtZSB8fCBcInRoaXMgZW1wbG95ZWVcIn1cclxuLy8gICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBkPVwiTTYgMThMMTggNk02IDZsMTIgMTJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tdmlvbGV0LTUwIHRvLXZpb2xldC0xMDAgcm91bmRlZC14bCBwLTUgYm9yZGVyIGJvcmRlci12aW9sZXQtMTAwIG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC12aW9sZXQtODAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBTdW1tYXJ5XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC12aW9sZXQtNjAwIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBQZXJpb2Q6e1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHNhbGFyeS5wYXlvdXRfbWV0YWRhdGEuZGF0ZV9yYW5nZS5mcm9tXHJcbi8vICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoKX17XCIgXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdG9cclxuLy8gICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzYWxhcnkucGF5b3V0X21ldGFkYXRhLmRhdGVfcmFuZ2UudG9cclxuLy8gICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlRGF0ZVN0cmluZygpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC05MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICDigrlcclxuLy8gICAgICAgICAgICAgICAgICAgICB7KFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VGbG9hdChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgc2FsYXJ5LnBheW91dF9tZXRhZGF0YS50b3RhbF9wYWlkX2Ftb3VudCB8fCAwXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApICsgcGFyc2VGbG9hdChzYWxhcnkucGF5b3V0X21ldGFkYXRhLm90aGVyX3BheW1lbnRzIHx8IDApXHJcbi8vICAgICAgICAgICAgICAgICAgICAgKS50b0ZpeGVkKDIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC12aW9sZXQtNjAwXCI+VG90YWwgUGF5bWVudCBBbW91bnQ8L3A+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuLy8gICAgICAgICAgICAgICB7LyogUGF5bWVudCBEYXRlIFNlY3Rpb24gKi99XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0xMDAgcGItNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8RmFDYWxlbmRhciBjbGFzc05hbWU9XCJtci0yIHRleHQtdmlvbGV0LTUwMFwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZVxyXG4vLyAgICAgICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgQ3VycmVudCBQYXltZW50IERhdGVcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBwLTMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtvcmlnaW5hbFZhbHVlcz8ucGF5X2RhdGUgfHwgXCJOL0FcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBOZXcgUGF5bWVudCBEYXRlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtVmFsdWVzLnBheV9kYXRlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtVmFsdWVzKHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtVmFsdWVzLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHBheV9kYXRlOiBlLnRhcmdldC52YWx1ZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbWQgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JzLnBheV9kYXRlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1yZWQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbWluPXtzYWxhcnkucGF5b3V0X21ldGFkYXRhLmRhdGVfcmFuZ2UuZnJvbX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG1heD17bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGUgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBheV9kYXRlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBBbW91bnQgU2VjdGlvbiAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBwYi00XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJtci0yIHRleHQtZ3JlZW4tNTAwXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgUGF5bWVudCBBbW91bnRcclxuLy8gICAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIEJhc2UgU2FsYXJ5IEFtb3VudFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHAtMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAg4oK5e3NhbGFyeS5wYXlvdXRfbWV0YWRhdGEudG90YWxfc2FsYXJ5LnRvRml4ZWQoMil9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgUGFpZCBBbW91bnQgKOKCuSlcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtVmFsdWVzLnRvdGFsX3BhaWRfYW1vdW50fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtVmFsdWVzKHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtVmFsdWVzLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsX3BhaWRfYW1vdW50OiBlLnRhcmdldC52YWx1ZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbWQgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JzLnRvdGFsX3BhaWRfYW1vdW50XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1yZWQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwYXltZW50IGFtb3VudFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRvdGFsX3BhaWRfYW1vdW50ICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50b3RhbF9wYWlkX2Ftb3VudH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBPdGhlciBQYXltZW50cyAo4oK5KVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1WYWx1ZXMub3RoZXJfcGF5bWVudHN9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybVZhbHVlcyh7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1WYWx1ZXMsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG90aGVyX3BheW1lbnRzOiBlLnRhcmdldC52YWx1ZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbWQgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGVycm9ycy5vdGhlcl9wYXltZW50c1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXJlZC01MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGFkZGl0aW9uYWwgcGF5bWVudHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm90aGVyX3BheW1lbnRzICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm90aGVyX3BheW1lbnRzfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIHBheW1lbnRzIHdpbGwgYmUgYWRkZWQgdG8gdGhlIGJhc2UgYW1vdW50XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogUGF5bWVudCBNZXRob2QgU2VjdGlvbiAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBwYi00XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIFBheW1lbnQgTWV0aG9kXHJcbi8vICAgICAgICAgICAgICAgICA8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gIHAtMyByb3VuZGVkXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBDdXJyZW50IFBheW1lbnQgTWV0aG9kXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBjYXBpdGFsaXplXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtvcmlnaW5hbFZhbHVlcz8ucGF5X3R5cGUgfHwgXCJOL0FcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuICBwLTMgcm91bmRlZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgTmV3IFBheW1lbnQgTWV0aG9kXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybVZhbHVlcy5wYXlfdHlwZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1WYWx1ZXMoeyAuLi5mb3JtVmFsdWVzLCBwYXlfdHlwZTogdmFsdWUgfSlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLVs0MnB4XVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjYXNoXCI+Q2FzaDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwib25saW5lXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIE9ubGluZSBUcmFuc2ZlclxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjaGVxdWVcIj5DaGVxdWU8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImJhbmtfdHJhbnNmZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBUcmFuc2ZlclxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHtmb3JtVmFsdWVzLnBheV90eXBlID09PSBcIm9ubGluZVwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBUcmFuc2FjdGlvbiBJRFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybVZhbHVlcy50cmFuc2FjdGlvbl9pZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybVZhbHVlcyh7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybVZhbHVlcyxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogZS50YXJnZXQudmFsdWUsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciByb3VuZGVkLW1kICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9ycy50cmFuc2FjdGlvbl9pZFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItcmVkLTUwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci1ncmF5LTMwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdHJhbnNhY3Rpb24gSURcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudHJhbnNhY3Rpb25faWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogTm90ZXMgU2VjdGlvbiAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIE5vdGVzXHJcbi8vICAgICAgICAgICAgICAgICA8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtVmFsdWVzLm5vdGV9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRGb3JtVmFsdWVzKHsgLi4uZm9ybVZhbHVlcywgbm90ZTogZS50YXJnZXQudmFsdWUgfSlcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciByb3VuZGVkLW1kICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgZXJyb3JzLm5vdGVcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItcmVkLTUwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHJvd3M9XCIzXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBZGQgYW55IG5vdGVzIGFib3V0IHRoaXMgcGF5bWVudC4uLlwiXHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgVGhlc2Ugbm90ZXMgd2lsbCBiZSB2aXNpYmxlIG9uIHRoZSBzYWxhcnkgc2xpcFxyXG4vLyAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMCBtdC02IGZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMi41IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFoYXNDaGFuZ2VzIHx8IGxvYWRpbmd9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMi41IHJvdW5kZWQtbGcgdGV4dC13aGl0ZSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGhhc0NoYW5nZXMgJiYgIWxvYWRpbmdcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy12aW9sZXQtNjAwIGhvdmVyOmJnLXZpb2xldC03MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktNDAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gLW1sLTEgbXItMiBoLTQgdy00IHRleHQtd2hpdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwib3BhY2l0eS0yNVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY3g9XCIxMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY3k9XCIxMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgcj1cIjEwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiNFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgID48L2NpcmNsZT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTc1XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTQgMTJhOCA4IDAgMDE4LThWMEM1LjM3MyAwIDAgNS4zNzMgMCAxMmg0em0yIDUuMjkxQTcuOTYyIDcuOTYyIDAgMDE0IDEySDBjMCAzLjA0MiAxLjEzNSA1LjgyNCAzIDcuOTM4bDMtMi42NDd6XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPjwvcGF0aD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgU2F2aW5nLi4uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFwiU2F2ZSBDaGFuZ2VzXCJcclxuLy8gICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Zvcm0+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8Lz5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuLy8gZXhwb3J0IGRlZmF1bHQgRWRpdFNhbGFyeU1vZGFsO1xyXG5cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBBUEkgZnJvbSBcIi4uLy4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IHsgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgRmFDYWxlbmRhciB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBGYVJ1cGVlU2lnbiB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBTZWxlY3QgfSBmcm9tIFwiYW50ZFwiO1xyXG5jb25zdCBFZGl0U2FsYXJ5TW9kYWwgPSAoeyBpc1Zpc2libGUsIG9uQ2xvc2UsIHNhbGFyeSwgb25FZGl0U3VjY2VzcyB9KSA9PiB7XHJcbiAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtmb3JtVmFsdWVzLCBzZXRGb3JtVmFsdWVzXSA9IHVzZVN0YXRlKHtcclxuICAgIHBheV9kYXRlOiBcIlwiLFxyXG4gICAgdG90YWxfcGFpZF9hbW91bnQ6IFwiXCIsXHJcbiAgICBvdGhlcl9wYXltZW50czogXCJcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtvcmlnaW5hbFZhbHVlcywgc2V0T3JpZ2luYWxWYWx1ZXNdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2hhc0NoYW5nZXMsIHNldEhhc0NoYW5nZXNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gIGNvbnN0IFtvdGhlclBheW1lbnRzTGlzdCwgc2V0T3RoZXJQYXltZW50c0xpc3RdID0gdXNlU3RhdGUoW3sgZGVzY3JpcHRpb246IFwiXCIsIGFtb3VudDogXCJcIiB9XSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNWaXNpYmxlICYmIHNhbGFyeSkge1xyXG4gICAgICBjb25zdCBtZXRhZGF0YSA9IHNhbGFyeS5wYXlvdXRfbWV0YWRhdGE7XHJcbiAgICAgIGNvbnN0IGV4aXN0aW5nT3RoZXIgPSBBcnJheS5pc0FycmF5KG1ldGFkYXRhLm90aGVyX3BheW1lbnRzKVxyXG4gICAgICAgID8gbWV0YWRhdGEub3RoZXJfcGF5bWVudHMubWFwKHAgPT4gKHtcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBwLmRlc2NyaXB0aW9uIHx8IFwiXCIsXHJcbiAgICAgICAgICBhbW91bnQ6IHAuYW1vdW50IHx8IFwiXCJcclxuICAgICAgICB9KSlcclxuICAgICAgICA6IFt7IGRlc2NyaXB0aW9uOiBcIlwiLCBhbW91bnQ6IFwiXCIgfV07XHJcbiAgICAgIHNldE90aGVyUGF5bWVudHNMaXN0KGV4aXN0aW5nT3RoZXIpO1xyXG4gICAgfVxyXG4gIH0sIFtpc1Zpc2libGUsIHNhbGFyeV0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVBZGRPdGhlclBheW1lbnQgPSAoKSA9PiB7XHJcbiAgICBzZXRPdGhlclBheW1lbnRzTGlzdChbLi4ub3RoZXJQYXltZW50c0xpc3QsIHsgZGVzY3JpcHRpb246IFwiXCIsIGFtb3VudDogXCJcIiB9XSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlT3RoZXJQYXltZW50Q2hhbmdlID0gKGluZGV4LCBmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4ub3RoZXJQYXltZW50c0xpc3RdO1xyXG4gICAgdXBkYXRlZFtpbmRleF1bZmllbGRdID0gdmFsdWU7XHJcbiAgICBzZXRPdGhlclBheW1lbnRzTGlzdCh1cGRhdGVkKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVSZW1vdmVPdGhlclBheW1lbnQgPSAoaW5kZXgpID0+IHtcclxuICAgIHNldE90aGVyUGF5bWVudHNMaXN0KG90aGVyUGF5bWVudHNMaXN0LmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGlzVmlzaWJsZSAmJiBzYWxhcnkpIHtcclxuICAgICAgY29uc3QgbWV0YWRhdGEgPSBzYWxhcnkucGF5b3V0X21ldGFkYXRhO1xyXG4gICAgICBjb25zdCBpbml0aWFsVmFsdWVzID0ge1xyXG4gICAgICAgIHBheV9kYXRlOiBuZXcgRGF0ZShtZXRhZGF0YS5kYXRlX3JhbmdlLmZyb20pXHJcbiAgICAgICAgICAudG9JU09TdHJpbmcoKVxyXG4gICAgICAgICAgLnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICB0b3RhbF9wYWlkX2Ftb3VudDogbWV0YWRhdGEudG90YWxfcGFpZF9hbW91bnQsXHJcbiAgICAgICAgb3RoZXJfcGF5bWVudHM6IG1ldGFkYXRhLm90aGVyX3BheW1lbnRzIHx8IFwiXCIsXHJcbiAgICAgICAgbm90ZTogbWV0YWRhdGEubm90ZSxcclxuICAgICAgICBwYXlfdHlwZTogbWV0YWRhdGEucGF5X3R5cGUsXHJcbiAgICAgICAgdHJhbnNhY3Rpb25faWQ6IG1ldGFkYXRhLnRyYW5zYWN0aW9uX2lkIHx8IFwiXCIsXHJcbiAgICAgIH07XHJcbiAgICAgIHNldEZvcm1WYWx1ZXMoaW5pdGlhbFZhbHVlcyk7XHJcbiAgICAgIHNldE9yaWdpbmFsVmFsdWVzKGluaXRpYWxWYWx1ZXMpO1xyXG4gICAgICBzZXRIYXNDaGFuZ2VzKGZhbHNlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH1cclxuICB9LCBbaXNWaXNpYmxlLCBzYWxhcnldKTtcclxuXHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIGlmIChvcmlnaW5hbFZhbHVlcykge1xyXG4gIC8vICAgICBjb25zdCBjaGFuZ2VkID0gT2JqZWN0LmtleXMob3JpZ2luYWxWYWx1ZXMpLnNvbWUoKGtleSkgPT4ge1xyXG4gIC8vICAgICAgIHJldHVybiBmb3JtVmFsdWVzW2tleV0gIT09IG9yaWdpbmFsVmFsdWVzW2tleV07XHJcbiAgLy8gICAgIH0pO1xyXG4gIC8vICAgICBzZXRIYXNDaGFuZ2VzKGNoYW5nZWQpO1xyXG4gIC8vICAgfVxyXG4gIC8vIH0sIFtmb3JtVmFsdWVzLCBvcmlnaW5hbFZhbHVlc10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gIGlmIChvcmlnaW5hbFZhbHVlcyAmJiBzYWxhcnkpIHtcclxuICAgIC8vIGRldGVjdCBjaGFuZ2VzIGluIGJhc2UgZm9ybSBmaWVsZHNcclxuICAgIGNvbnN0IGZvcm1DaGFuZ2VkID0gT2JqZWN0LmtleXMob3JpZ2luYWxWYWx1ZXMpLnNvbWUoXHJcbiAgICAgIChrZXkpID0+IGZvcm1WYWx1ZXNba2V5XSAhPT0gb3JpZ2luYWxWYWx1ZXNba2V5XVxyXG4gICAgKTtcclxuXHJcbiAgICAvLyBkZXRlY3QgY2hhbmdlcyBpbiBvdGhlciBwYXltZW50c1xyXG5jb25zdCBvcmlnaW5hbE90aGVyUGF5bWVudHMgPSBBcnJheS5pc0FycmF5KHNhbGFyeT8ucGF5b3V0X21ldGFkYXRhPy5vdGhlcl9wYXltZW50cylcclxuICA/IHNhbGFyeS5wYXlvdXRfbWV0YWRhdGEub3RoZXJfcGF5bWVudHMubWFwKChwKSA9PiAoe1xyXG4gICAgICBkZXNjcmlwdGlvbjogcC5kZXNjcmlwdGlvbiB8fCBcIlwiLFxyXG4gICAgICBhbW91bnQ6IE51bWJlcihwLmFtb3VudCkgfHwgMCxcclxuICAgIH0pKVxyXG4gIDogW107XHJcblxyXG4gICAgY29uc3QgY3VycmVudE90aGVyUGF5bWVudHMgPSBvdGhlclBheW1lbnRzTGlzdC5tYXAoKHApID0+ICh7XHJcbiAgICAgIGRlc2NyaXB0aW9uOiBwLmRlc2NyaXB0aW9uLFxyXG4gICAgICBhbW91bnQ6IE51bWJlcihwLmFtb3VudCksXHJcbiAgICB9KSk7XHJcblxyXG4gICAgY29uc3Qgb3RoZXJQYXltZW50c0NoYW5nZWQgPVxyXG4gICAgICBKU09OLnN0cmluZ2lmeShjdXJyZW50T3RoZXJQYXltZW50cykgIT09XHJcbiAgICAgIEpTT04uc3RyaW5naWZ5KG9yaWdpbmFsT3RoZXJQYXltZW50cyk7XHJcblxyXG4gICAgc2V0SGFzQ2hhbmdlcyhmb3JtQ2hhbmdlZCB8fCBvdGhlclBheW1lbnRzQ2hhbmdlZCk7XHJcbiAgfVxyXG59LCBbZm9ybVZhbHVlcywgb3RoZXJQYXltZW50c0xpc3QsIG9yaWdpbmFsVmFsdWVzLCBzYWxhcnldKTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbiAgICBpZiAoXHJcbiAgICAgIGZvcm1WYWx1ZXMudG90YWxfcGFpZF9hbW91bnQgIT09IFwiXCIgJiZcclxuICAgICAgKGlzTmFOKGZvcm1WYWx1ZXMudG90YWxfcGFpZF9hbW91bnQpIHx8IGZvcm1WYWx1ZXMudG90YWxfcGFpZF9hbW91bnQgPCAwKVxyXG4gICAgKSB7XHJcbiAgICAgIG5ld0Vycm9ycy50b3RhbF9wYWlkX2Ftb3VudCA9IFwiQW1vdW50IG11c3QgYmUgYSBwb3NpdGl2ZSBudW1iZXJcIjtcclxuICAgIH1cclxuICAgIC8vIGlmIChcclxuICAgIC8vICAgZm9ybVZhbHVlcy5vdGhlcl9wYXltZW50cyAhPT0gXCJcIiAmJlxyXG4gICAgLy8gICAoaXNOYU4oZm9ybVZhbHVlcy5vdGhlcl9wYXltZW50cykgfHwgZm9ybVZhbHVlcy5vdGhlcl9wYXltZW50cyA8IDApXHJcbiAgICAvLyApIHtcclxuICAgIC8vICAgbmV3RXJyb3JzLm90aGVyX3BheW1lbnRzID0gXCJPdGhlciBwYXltZW50cyBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyXCI7XHJcbiAgICAvLyB9XHJcbiAgICBpZiAoZm9ybVZhbHVlcy5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiAmJiAhZm9ybVZhbHVlcy50cmFuc2FjdGlvbl9pZCkge1xyXG4gICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPVxyXG4gICAgICAgIFwiVHJhbnNhY3Rpb24gSUQgaXMgcmVxdWlyZWQgZm9yIG9ubGluZSBwYXltZW50c1wiO1xyXG4gICAgfVxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgLy8gY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAvLyAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAvLyAgIGlmICghdmFsaWRhdGVGb3JtKCkpIHJldHVybjtcclxuXHJcbiAgLy8gICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gIC8vICAgdHJ5IHtcclxuICAvLyAgICAgY29uc3QgcGF5bG9hZCA9IHt9O1xyXG5cclxuICAvLyAgICAgLy8gT25seSBpbmNsdWRlIGZpZWxkcyB0aGF0IGhhdmUgY2hhbmdlZFxyXG4gIC8vICAgICBpZiAoZm9ybVZhbHVlcy5wYXlfZGF0ZSAhPT0gb3JpZ2luYWxWYWx1ZXMucGF5X2RhdGUpIHtcclxuICAvLyAgICAgICBwYXlsb2FkLnBheV9kYXRlID0gZm9ybVZhbHVlcy5wYXlfZGF0ZTtcclxuICAvLyAgICAgfVxyXG4gIC8vICAgICBpZiAoZm9ybVZhbHVlcy50b3RhbF9wYWlkX2Ftb3VudCAhPT0gb3JpZ2luYWxWYWx1ZXMudG90YWxfcGFpZF9hbW91bnQpIHtcclxuICAvLyAgICAgICBwYXlsb2FkLnRvdGFsX3BhaWRfYW1vdW50ID0gcGFyc2VGbG9hdChmb3JtVmFsdWVzLnRvdGFsX3BhaWRfYW1vdW50KTtcclxuICAvLyAgICAgfVxyXG4gIC8vICAgICBpZiAoZm9ybVZhbHVlcy5vdGhlcl9wYXltZW50cyAhPT0gb3JpZ2luYWxWYWx1ZXMub3RoZXJfcGF5bWVudHMpIHtcclxuICAvLyAgICAgICBwYXlsb2FkLm90aGVyX3BheW1lbnRzID0gcGFyc2VGbG9hdChmb3JtVmFsdWVzLm90aGVyX3BheW1lbnRzKTtcclxuICAvLyAgICAgfVxyXG4gIC8vICAgICBpZiAoZm9ybVZhbHVlcy5ub3RlICE9PSBvcmlnaW5hbFZhbHVlcy5ub3RlKSB7XHJcbiAgLy8gICAgICAgcGF5bG9hZC5ub3RlID0gZm9ybVZhbHVlcy5ub3RlO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICAgIGlmIChmb3JtVmFsdWVzLnBheV90eXBlICE9PSBvcmlnaW5hbFZhbHVlcy5wYXlfdHlwZSkge1xyXG4gIC8vICAgICAgIHBheWxvYWQucGF5X3R5cGUgPSBmb3JtVmFsdWVzLnBheV90eXBlO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICAgIGlmIChmb3JtVmFsdWVzLnRyYW5zYWN0aW9uX2lkICE9PSBvcmlnaW5hbFZhbHVlcy50cmFuc2FjdGlvbl9pZCkge1xyXG4gIC8vICAgICAgIHBheWxvYWQudHJhbnNhY3Rpb25faWQgPSBmb3JtVmFsdWVzLnRyYW5zYWN0aW9uX2lkO1xyXG4gIC8vICAgICB9XHJcblxyXG4gIC8vICAgICBpZiAoT2JqZWN0LmtleXMocGF5bG9hZCkubGVuZ3RoID09PSAwKSB7XHJcbiAgLy8gICAgICAgYXBpLm9wZW4oe1xyXG4gIC8vICAgICAgICAgbWVzc2FnZTogXCJObyBjaGFuZ2VzIG1hZGVcIixcclxuICAvLyAgICAgICAgIGRlc2NyaXB0aW9uOiBcIk5vIGZpZWxkcyB3ZXJlIGNoYW5nZWRcIixcclxuICAvLyAgICAgICAgIGNsYXNzTmFtZTogXCJiZy12aW9sZXQtNTAwIHJvdW5kZWQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCIsXHJcbiAgLy8gICAgICAgfSk7XHJcbiAgLy8gICAgICAgcmV0dXJuO1xyXG4gIC8vICAgICB9XHJcblxyXG4gIC8vICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkucHV0KGAvc2FsYXJ5L2VkaXQvJHtzYWxhcnkuX2lkfWAsIHBheWxvYWQpO1xyXG5cclxuICAvLyAgICAgYXBpLm9wZW4oe1xyXG4gIC8vICAgICAgIG1lc3NhZ2U6IFwiU2FsYXJ5IFBheW1lbnQgVXBkYXRlZFwiLFxyXG4gIC8vICAgICAgIGRlc2NyaXB0aW9uOiBcIlNhbGFyeSBwYXltZW50IGhhcyBiZWVuIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgLy8gICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTUwMCByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiLFxyXG4gIC8vICAgICB9KTtcclxuXHJcbiAgLy8gICAgIGlmIChvbkVkaXRTdWNjZXNzKSBvbkVkaXRTdWNjZXNzKCk7XHJcbiAgLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4gIC8vICAgICBjb25zdCBtZXNzYWdlID1cclxuICAvLyAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8uZXJyb3IgfHwgXCJGYWlsZWQgdG8gdXBkYXRlIHNhbGFyeSBwYXltZW50XCI7XHJcbiAgLy8gICAgIGFwaS5vcGVuKHtcclxuICAvLyAgICAgICBtZXNzYWdlOiBcIlVwZGF0ZSBGYWlsZWRcIixcclxuICAvLyAgICAgICBkZXNjcmlwdGlvbjogbWVzc2FnZSxcclxuICAvLyAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTUwMCByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiLFxyXG4gIC8vICAgICB9KTtcclxuICAvLyAgIH0gZmluYWxseSB7XHJcbiAgLy8gICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gIC8vICAgfVxyXG4gIC8vIH07XHJcblxyXG5jb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gIGUucHJldmVudERlZmF1bHQoKTtcclxuICBpZiAoIXZhbGlkYXRlRm9ybSgpKSByZXR1cm47XHJcblxyXG4gIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHBheWxvYWQgPSB7fTtcclxuXHJcbiAgICAvLyBJbmNsdWRlIG9ubHkgY2hhbmdlZCBiYXNlIGZpZWxkc1xyXG4gICAgaWYgKGZvcm1WYWx1ZXMucGF5X2RhdGUgIT09IG9yaWdpbmFsVmFsdWVzLnBheV9kYXRlKSB7XHJcbiAgICAgIHBheWxvYWQucGF5X2RhdGUgPSBmb3JtVmFsdWVzLnBheV9kYXRlO1xyXG4gICAgfVxyXG4gICAgaWYgKGZvcm1WYWx1ZXMudG90YWxfcGFpZF9hbW91bnQgIT09IG9yaWdpbmFsVmFsdWVzLnRvdGFsX3BhaWRfYW1vdW50KSB7XHJcbiAgICAgIHBheWxvYWQudG90YWxfcGFpZF9hbW91bnQgPSBwYXJzZUZsb2F0KGZvcm1WYWx1ZXMudG90YWxfcGFpZF9hbW91bnQpO1xyXG4gICAgfVxyXG4gICAgaWYgKGZvcm1WYWx1ZXMubm90ZSAhPT0gb3JpZ2luYWxWYWx1ZXMubm90ZSkge1xyXG4gICAgICBwYXlsb2FkLm5vdGUgPSBmb3JtVmFsdWVzLm5vdGU7XHJcbiAgICB9XHJcbiAgICBpZiAoZm9ybVZhbHVlcy5wYXlfdHlwZSAhPT0gb3JpZ2luYWxWYWx1ZXMucGF5X3R5cGUpIHtcclxuICAgICAgcGF5bG9hZC5wYXlfdHlwZSA9IGZvcm1WYWx1ZXMucGF5X3R5cGU7XHJcbiAgICB9XHJcbiAgICBpZiAoZm9ybVZhbHVlcy50cmFuc2FjdGlvbl9pZCAhPT0gb3JpZ2luYWxWYWx1ZXMudHJhbnNhY3Rpb25faWQpIHtcclxuICAgICAgcGF5bG9hZC50cmFuc2FjdGlvbl9pZCA9IGZvcm1WYWx1ZXMudHJhbnNhY3Rpb25faWQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8g4pyFIEhhbmRsZSBPdGhlciBQYXltZW50cyDigJQgeW91ciBuZXcgZW5oYW5jZW1lbnRcclxuICAgIGNvbnN0IGNsZWFuT3RoZXJQYXltZW50cyA9IG90aGVyUGF5bWVudHNMaXN0XHJcbiAgICAgIC5maWx0ZXIoXHJcbiAgICAgICAgKGl0ZW0pID0+XHJcbiAgICAgICAgICBpdGVtLmRlc2NyaXB0aW9uLnRyaW0oKSAhPT0gXCJcIiAmJlxyXG4gICAgICAgICAgIWlzTmFOKE51bWJlcihpdGVtLmFtb3VudCkpICYmXHJcbiAgICAgICAgICBOdW1iZXIoaXRlbS5hbW91bnQpID49IDBcclxuICAgICAgKVxyXG4gICAgICAubWFwKChpdGVtKSA9PiAoe1xyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBpdGVtLmRlc2NyaXB0aW9uLnRyaW0oKSxcclxuICAgICAgICBhbW91bnQ6IE51bWJlcihpdGVtLmFtb3VudCksXHJcbiAgICAgIH0pKTtcclxuXHJcbiAgICAvLyBDb21wYXJlIHdpdGggb3JpZ2luYWwgb3RoZXJfcGF5bWVudHNcclxuICAgIGNvbnN0IG9yaWdpbmFsT3RoZXJQYXltZW50cyA9XHJcbiAgICAgIEFycmF5LmlzQXJyYXkoc2FsYXJ5Py5wYXlvdXRfbWV0YWRhdGE/Lm90aGVyX3BheW1lbnRzKSAmJlxyXG4gICAgICBzYWxhcnkucGF5b3V0X21ldGFkYXRhLm90aGVyX3BheW1lbnRzLm1hcCgocCkgPT4gKHtcclxuICAgICAgICBkZXNjcmlwdGlvbjogcC5kZXNjcmlwdGlvbixcclxuICAgICAgICBhbW91bnQ6IE51bWJlcihwLmFtb3VudCksXHJcbiAgICAgIH0pKTtcclxuXHJcbiAgICBjb25zdCBoYXNPdGhlclBheW1lbnRzQ2hhbmdlZCA9XHJcbiAgICAgIEpTT04uc3RyaW5naWZ5KGNsZWFuT3RoZXJQYXltZW50cykgIT09XHJcbiAgICAgIEpTT04uc3RyaW5naWZ5KG9yaWdpbmFsT3RoZXJQYXltZW50cyk7XHJcblxyXG4gICAgaWYgKGhhc090aGVyUGF5bWVudHNDaGFuZ2VkKSB7XHJcbiAgICAgIHBheWxvYWQub3RoZXJfcGF5bWVudHMgPSBjbGVhbk90aGVyUGF5bWVudHM7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gUHJldmVudCBlbXB0eSBzYXZlXHJcbiAgICBpZiAoT2JqZWN0LmtleXMocGF5bG9hZCkubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIGFwaS5vcGVuKHtcclxuICAgICAgICBtZXNzYWdlOiBcIk5vIGNoYW5nZXMgbWFkZVwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIk5vIGZpZWxkcyB3ZXJlIGNoYW5nZWRcIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctdmlvbGV0LTUwMCByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEFQSSB1cGRhdGVcclxuICAgIGF3YWl0IEFQSS5wdXQoYC9zYWxhcnkvZWRpdC8ke3NhbGFyeS5faWR9YCwgcGF5bG9hZCk7XHJcblxyXG4gICAgYXBpLm9wZW4oe1xyXG4gICAgICBtZXNzYWdlOiBcIlNhbGFyeSBQYXltZW50IFVwZGF0ZWRcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiU2FsYXJ5IHBheW1lbnQgaGFzIGJlZW4gdXBkYXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTUwMCByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKG9uRWRpdFN1Y2Nlc3MpIG9uRWRpdFN1Y2Nlc3MoKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc3QgbWVzc2FnZSA9XHJcbiAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5lcnJvciB8fCBcIkZhaWxlZCB0byB1cGRhdGUgc2FsYXJ5IHBheW1lbnRcIjtcclxuICAgIGFwaS5vcGVuKHtcclxuICAgICAgbWVzc2FnZTogXCJVcGRhdGUgRmFpbGVkXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBtZXNzYWdlLFxyXG4gICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTUwMCByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiLFxyXG4gICAgfSk7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gIH1cclxufTtcclxuXHJcblxyXG5cclxuICBpZiAoIXNhbGFyeSB8fCAhaXNWaXNpYmxlKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgZml4ZWQgaW5zZXQtMCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHotNTAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTMwMCAke2lzVmlzaWJsZSA/IFwib3BhY2l0eS0xMDBcIiA6IFwib3BhY2l0eS0wIHBvaW50ZXItZXZlbnRzLW5vbmVcIlxyXG4gICAgICAgICAgfWB9XHJcbiAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHctZnVsbCBtYXgtdy0zeGwgbWF4LWgtWzkwdmhdIG92ZXJmbG93LXktYXV0byB0cmFuc2Zvcm0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHJlbGF0aXZlIHNoYWRvdy0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXQgU2FsYXJ5IFBheW1lbnRcclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlIHBheW1lbnQgZGV0YWlscyBmb3J7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtzYWxhcnkuZW1wbG95ZWVfaWQ/Lm5hbWUgfHwgXCJ0aGlzIGVtcGxveWVlXCJ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01XCJcclxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgZD1cIk02IDE4TDE4IDZNNiA2bDEyIDEyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC01MCB0by12aW9sZXQtMTAwIHJvdW5kZWQteGwgcC01IGJvcmRlciBib3JkZXItdmlvbGV0LTEwMCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdmlvbGV0LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnQgU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtdmlvbGV0LTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGVyaW9kOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoXHJcbiAgICAgICAgICAgICAgICAgICAgICBzYWxhcnkucGF5b3V0X21ldGFkYXRhLmRhdGVfcmFuZ2UuZnJvbVxyXG4gICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHRvXHJcbiAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2FsYXJ5LnBheW91dF9tZXRhZGF0YS5kYXRlX3JhbmdlLnRvXHJcbiAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC12aW9sZXQtOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgeyhcclxuICAgICAgICAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhbGFyeS5wYXlvdXRfbWV0YWRhdGEudG90YWxfcGFpZF9hbW91bnQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKSArIHBhcnNlRmxvYXQoc2FsYXJ5LnBheW91dF9tZXRhZGF0YS5vdGhlcl9wYXltZW50cyB8fCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICkudG9GaXhlZCgyKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtdmlvbGV0LTYwMFwiPlRvdGFsIFBheW1lbnQgQW1vdW50PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAgey8qIFBheW1lbnQgRGF0ZSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIHBiLTRcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPEZhQ2FsZW5kYXIgY2xhc3NOYW1lPVwibXItMiB0ZXh0LXZpb2xldC01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICBQYXltZW50IERhdGVcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1cnJlbnQgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7b3JpZ2luYWxWYWx1ZXM/LnBheV9kYXRlIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTmV3IFBheW1lbnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybVZhbHVlcy5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybVZhbHVlcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybVZhbHVlcyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYXlfZGF0ZTogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciByb3VuZGVkLW1kICR7ZXJyb3JzLnBheV9kYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1yZWQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49e3NhbGFyeS5wYXlvdXRfbWV0YWRhdGEuZGF0ZV9yYW5nZS5mcm9tfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbWF4PXtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEFtb3VudCBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIHBiLTRcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cIm1yLTIgdGV4dC1ncmVlbi01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICBQYXltZW50IEFtb3VudFxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQmFzZSBTYWxhcnkgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDigrl7c2FsYXJ5LnBheW91dF9tZXRhZGF0YS50b3RhbF9zYWxhcnkudG9GaXhlZCgyKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBQYWlkIEFtb3VudCAo4oK5KVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1WYWx1ZXMudG90YWxfcGFpZF9hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1WYWx1ZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1WYWx1ZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxfcGFpZF9hbW91bnQ6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgcm91bmRlZC1tZCAke2Vycm9ycy50b3RhbF9wYWlkX2Ftb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItcmVkLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci1ncmF5LTMwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwYXltZW50IGFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRvdGFsX3BhaWRfYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50b3RhbF9wYWlkX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgT3RoZXIgUGF5bWVudHMgKOKCuSlcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtVmFsdWVzLm90aGVyX3BheW1lbnRzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1WYWx1ZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtVmFsdWVzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvdGhlcl9wYXltZW50czogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciByb3VuZGVkLW1kICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICBlcnJvcnMub3RoZXJfcGF5bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1yZWQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci1ncmF5LTMwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhZGRpdGlvbmFsIHBheW1lbnRzXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5vdGhlcl9wYXltZW50cyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5vdGhlcl9wYXltZW50c31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQWRkaXRpb25hbCBwYXltZW50cyB3aWxsIGJlIGFkZGVkIHRvIHRoZSBiYXNlIGFtb3VudFxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIE90aGVyIFBheW1lbnRzIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBwYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIFBheW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7b3RoZXJQYXltZW50c0xpc3QubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtMyBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IERlc2NyaXB0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIEJvbnVzLCBSZWltYnVyc2VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVPdGhlclBheW1lbnRDaGFuZ2UoaW5kZXgsIFwiZGVzY3JpcHRpb25cIiwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IEFtb3VudCAo4oK5KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVPdGhlclBheW1lbnRDaGFuZ2UoaW5kZXgsIFwiYW1vdW50XCIsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aW5kZXggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZU90aGVyUGF5bWVudChpbmRleCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlbW92ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZE90aGVyUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSByb3VuZGVkLW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICsgQWRkIEFub3RoZXIgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFBheW1lbnQgTWV0aG9kIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0xMDAgcGItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICBQYXltZW50IE1ldGhvZFxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuICBwLTMgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ3VycmVudCBQYXltZW50IE1ldGhvZFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHAtMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgY2FwaXRhbGl6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7b3JpZ2luYWxWYWx1ZXM/LnBheV90eXBlIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiAgcC0zIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE5ldyBQYXltZW50IE1ldGhvZFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1WYWx1ZXMucGF5X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtVmFsdWVzKHsgLi4uZm9ybVZhbHVlcywgcGF5X3R5cGU6IHZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1bNDJweF1cIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBPbmxpbmUgVHJhbnNmZXJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY2hlcXVlXCI+Q2hlcXVlPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJiYW5rX3RyYW5zZmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgVHJhbnNmZXJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7Zm9ybVZhbHVlcy5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSURcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1WYWx1ZXMudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1WYWx1ZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1WYWx1ZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNhY3Rpb25faWQ6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgcm91bmRlZC1tZCAke2Vycm9ycy50cmFuc2FjdGlvbl9pZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItcmVkLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci1ncmF5LTMwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0cmFuc2FjdGlvbiBJRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBOb3RlcyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZGl0aW9uYWwgTm90ZXNcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1WYWx1ZXMubm90ZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1WYWx1ZXMoeyAuLi5mb3JtVmFsdWVzLCBub3RlOiBlLnRhcmdldC52YWx1ZSB9KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbWQgJHtlcnJvcnMubm90ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1yZWQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICByb3dzPVwiM1wiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGFueSBub3RlcyBhYm91dCB0aGlzIHBheW1lbnQuLi5cIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRoZXNlIG5vdGVzIHdpbGwgYmUgdmlzaWJsZSBvbiB0aGUgc2FsYXJ5IHNsaXBcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDAgbXQtNiBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIuNSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshaGFzQ2hhbmdlcyB8fCBsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC01IHB5LTIuNSByb3VuZGVkLWxnIHRleHQtd2hpdGUgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtoYXNDaGFuZ2VzICYmICFsb2FkaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctdmlvbGV0LTYwMCBob3ZlcjpiZy12aW9sZXQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTQwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gLW1sLTEgbXItMiBoLTQgdy00IHRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwib3BhY2l0eS0yNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3g9XCIxMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3k9XCIxMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcj1cIjEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID48L2NpcmNsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTc1XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTQgMTJhOCA4IDAgMDE4LThWMEM1LjM3MyAwIDAgNS4zNzMgMCAxMmg0em0yIDUuMjkxQTcuOTYyIDcuOTYyIDAgMDE0IDEySDBjMCAzLjA0MiAxLjEzNSA1LjgyNCAzIDcuOTM4bDMtMi42NDd6XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvcGF0aD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2F2aW5nLi4uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIFwiU2F2ZSBDaGFuZ2VzXCJcclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRWRpdFNhbGFyeU1vZGFsO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvY29tcG9uZW50cy9tb2RhbHMvRWRpdFNhbGFyeU1vZGFsLmpzeCJ9