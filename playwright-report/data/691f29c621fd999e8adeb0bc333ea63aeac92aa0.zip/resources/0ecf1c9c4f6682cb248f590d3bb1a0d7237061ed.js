import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Subscriptions.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Tabs, Dropdown, Select, Tooltip, Checkbox, Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { CheckCircleOutlined, CloseCircleOutlined, InfoCircleOutlined, SyncOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { RefreshCw } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const { TabPane } = Tabs;
const Subscriptions = () => {
  _s();
  const [activeTab, setActiveTab] = useState("plans");
  const [searchText, setSearchText] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [plans, setPlans] = useState([]);
  const [tablePlans, setTablePlans] = useState([]);
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [showPlanDeleteModal, setShowPlanDeleteModal] = useState(false);
  const [showPlanViewModal, setShowPlanViewModal] = useState(false);
  const [viewPlan, setViewPlan] = useState(null);
  const [currentPlan, setCurrentPlan] = useState(null);
  const [currentUpdatePlan, setCurrentUpdatePlan] = useState(null);
  const [planReloadTrigger, setPlanReloadTrigger] = useState(0);
  const [planIsLoading, setPlanIsLoading] = useState(false);
  const [planFormData, setPlanFormData] = useState({
    plan_id: "",
    plan_name: "",
    plan_type: "PERIODIC",
    plan_currency: "INR",
    plan_recurring_amount: "",
    plan_max_amount: "",
    plan_max_cycles: "",
    plan_intervals: "",
    plan_interval_type: "MONTH",
    plan_note: "Chit"
  });
  const [planErrors, setPlanErrors] = useState({});
  const [updateFormData, setUpdateFormData] = useState({ ...planFormData });
  const [subscriptions, setSubscriptions] = useState([]);
  const [tableSubscriptions, setTableSubscriptions] = useState([]);
  const [showSubModal, setShowSubModal] = useState(false);
  const [showSubDeleteModal, setShowSubDeleteModal] = useState(false);
  const [showSubEditModal, setShowSubEditModal] = useState(false);
  const [currentEditSub, setCurrentEditSub] = useState(null);
  const [editSubTags, setEditSubTags] = useState({
    // NEW: editable tags state
    pay_type: "CHIT",
    group_id: "",
    ticket: "",
    pigme_id: "",
    loan_id: ""
  });
  const [editGroupTicketValue, setEditGroupTicketValue] = useState(null);
  const [editFilteredEnrollments, setEditFilteredEnrollments] = useState([]);
  const [editPigmeCustomers, setEditPigmeCustomers] = useState([]);
  const [editBorrowers, setEditBorrowers] = useState([]);
  const [currentSubscription, setCurrentSubscription] = useState(null);
  const [subReloadTrigger, setSubReloadTrigger] = useState(0);
  const [subIsLoading, setSubIsLoading] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [enrollmentLoading, setEnrollmentLoading] = useState(false);
  const [filteredEnrollments, setFilteredEnrollments] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [borrowers, setBorrowers] = useState([]);
  const [selectedGroupTicketValue, setSelectedGroupTicketValue] = useState(null);
  const [firstChargeTimeMin, setFirstChargeTimeMin] = useState("");
  const [expiryTimeMin, setExpiryTimeMin] = useState("");
  const [plansForDropdown, setPlansForDropdown] = useState([]);
  const [users, setUsers] = useState([]);
  const [editModalLoading, setEditModalLoading] = useState(false);
  const [subFormData, setSubFormData] = useState({
    subscription_id: "",
    customer_details: {
      customer_name: "",
      customer_email: "",
      customer_phone: ""
    },
    plan_details: {
      plan_id: ""
    },
    subscription_expiry_time: "",
    subscription_first_charge_time: "",
    subscription_meta: {
      notification_channel: ["SMS"]
    },
    authorization_details: {
      authorization_amount: "",
      authorization_amount_refund: false,
      payment_methods: ["upi"]
    },
    subscription_tags: {
      user_id: "",
      pay_type: "CHIT",
      group_id: "",
      ticket: ""
    }
  });
  const [subErrors, setSubErrors] = useState({});
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const handlePlanViewModalOpen = async (planId) => {
    try {
      const response = await api.get(`/cashfree-subscription/plans/${planId}`);
      setViewPlan(response.data?.data || response.data);
      setShowPlanViewModal(true);
    } catch (error) {
      console.error("Error fetching plan for view:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch plan details",
        type: "error"
      });
    }
  };
  useEffect(() => {
    const fetchPlans = async () => {
      try {
        setPlanIsLoading(true);
        const response = await api.get("/cashfree-subscription/plans");
        const plansData = response.data?.data || response.data || [];
        setPlans(plansData);
        const formattedData = plansData.map((plan, index) => ({
          _id: plan._id,
          id: index + 1,
          plan_id: plan.plan_id,
          plan_name: plan.plan_name,
          plan_type: plan.plan_type,
          plan_currency: plan.plan_currency,
          plan_recurring_amount: plan.plan_recurring_amount,
          plan_max_amount: plan.plan_max_amount,
          plan_max_cycles: plan.plan_max_cycles,
          plan_intervals: plan.plan_intervals,
          plan_interval_type: plan.plan_interval_type,
          plan_note: plan.plan_note,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV("div", { onClick: () => handlePlanViewModalOpen(plan._id), children: "View" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 170,
                      columnNumber: 19
                    }, this)
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handlePlanDeleteModalOpen(plan._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 178,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold cursor-pointer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 190,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 164,
              columnNumber: 15
            },
            this
          ) }, plan._id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 163,
            columnNumber: 11
          }, this)
        }));
        setTablePlans(formattedData);
      } catch (error) {
        console.error("Error fetching plans:", error);
        setAlertConfig({
          visibility: true,
          message: "Failed to fetch plans",
          type: "error"
        });
      } finally {
        setPlanIsLoading(false);
      }
    };
    fetchPlans();
  }, [planReloadTrigger]);
  const handlePlanChange = (e) => {
    const { name, value } = e.target;
    setPlanFormData((prev) => ({ ...prev, [name]: value }));
    setPlanErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const handlePlanAntDSelect = (field, value) => {
    setPlanFormData((prev) => ({ ...prev, [field]: value }));
    setPlanErrors((prev) => ({ ...prev, [field]: "" }));
  };
  const validatePlanForm = () => {
    const newErrors = {};
    if (!planFormData.plan_id) newErrors.plan_id = "Plan ID is required";
    if (!planFormData.plan_name) newErrors.plan_name = "Plan Name is required";
    if (!planFormData.plan_recurring_amount || planFormData.plan_recurring_amount <= 0)
      newErrors.plan_recurring_amount = "Recurring amount must be positive";
    if (!planFormData.plan_max_amount || planFormData.plan_max_amount <= 0)
      newErrors.plan_max_amount = "Max amount must be positive";
    if (!planFormData.plan_intervals || planFormData.plan_intervals <= 0)
      newErrors.plan_intervals = "Intervals must be positive";
    if (!planFormData.plan_interval_type)
      newErrors.plan_interval_type = "Interval type is required";
    if (!planFormData.plan_note) newErrors.plan_note = "Plan note is required";
    setPlanErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handlePlanSubmit = async (e) => {
    e.preventDefault();
    if (!validatePlanForm()) return;
    try {
      const { plan_max_cycles, ...rest } = planFormData;
      const payload = {
        ...rest,
        plan_recurring_amount: Number(planFormData.plan_recurring_amount),
        plan_max_amount: Number(planFormData.plan_max_amount),
        plan_intervals: Number(planFormData.plan_intervals)
      };
      if (plan_max_cycles !== "" && plan_max_cycles !== null) {
        payload.plan_max_cycles = Number(plan_max_cycles);
      }
      await api.post("/cashfree-subscription/plans", payload);
      setPlanReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Plan added successfully",
        type: "success"
      });
      setShowPlanModal(false);
      setPlanFormData({
        plan_id: "",
        plan_name: "",
        plan_type: "PERIODIC",
        plan_currency: "INR",
        plan_recurring_amount: "",
        plan_max_amount: "",
        plan_max_cycles: "",
        plan_intervals: "",
        plan_interval_type: "MONTH",
        plan_note: "Chit"
      });
    } catch (error) {
      console.error("Error adding plan:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to add plan",
        type: "error"
      });
    }
  };
  const handlePlanDeleteModalOpen = async (planId) => {
    try {
      const response = await api.get(`/cashfree-subscription/plans/${planId}`);
      setCurrentPlan(response.data?.data || response.data);
      setShowPlanDeleteModal(true);
    } catch (error) {
      console.error("Error fetching plan for delete:", error);
    }
  };
  const handlePlanDelete = async () => {
    if (currentPlan) {
      try {
        await api.delete(`/cashfree-subscription/plans/${currentPlan._id}`);
        setPlanReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Plan deleted successfully",
          type: "success",
          visibility: true
        });
        setShowPlanDeleteModal(false);
        setCurrentPlan(null);
      } catch (error) {
        console.error("Error deleting plan:", error);
        setAlertConfig({
          message: "Failed to delete plan",
          type: "error",
          visibility: true
        });
      }
    }
  };
  const formatDateTime = (isoString) => {
    if (!isoString) return "";
    const date = new Date(isoString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    return `${day}-${month}-${year} ${hours}:${minutes}`;
  };
  const isoToDatetimeLocal = (isoString) => {
    if (!isoString) return "";
    const date = new Date(isoString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };
  const handleSubEditModalOpen = async (subId) => {
    try {
      const response = await api.get(`/cashfree-subscription/subscription/${subId}`);
      const subData = response.data?.data || response.data;
      setCurrentEditSub(subData);
      setEditModalLoading(true);
      setShowSubEditModal(true);
      const tags = subData.subscription_tags || {};
      let payType = tags.pay_type || "CHIT";
      let groupId = tags.group_id?._id || tags.group_id || "";
      let ticket = tags.ticket || "";
      let pigmeId = tags.pigme_id?.pigme_id || "";
      let loanId = tags.loan_id?.loan_id || "";
      setEditSubTags({ pay_type: payType, group_id: groupId, ticket, pigme_id: pigmeId, loan_id: loanId });
      if (payType === "CHIT" && groupId) {
        setEditGroupTicketValue(`chit|${groupId}|${ticket}`);
      } else if (payType === "Pigme" && pigmeId) {
        setEditGroupTicketValue(`pigme|${pigmeId}`);
      } else if (payType === "Loan" && loanId) {
        setEditGroupTicketValue(`loan|${loanId}`);
      } else {
        setEditGroupTicketValue(null);
      }
      const userId = tags.user_id?._id || tags.user_id || "";
      if (userId) {
        try {
          const enrollResp = await api.post(`/enroll/get-user-tickets-report/${userId}`);
          const validEnrollments = (enrollResp.data || []).filter(
            (auction) => auction.enrollment && auction.enrollment.group
          );
          setEditFilteredEnrollments(validEnrollments);
        } catch {
          setEditFilteredEnrollments([]);
        }
        try {
          const pigmeResp = await api.get(`/pigme/get-pigme-customer-by-user-id/${userId}`);
          setEditPigmeCustomers(pigmeResp.data || []);
        } catch {
          setEditPigmeCustomers([]);
        }
        try {
          const loanResp = await api.get(`/v1/admin/loans/borrowers/${userId}`);
          setEditBorrowers(loanResp.data?.data || []);
        } catch {
          setEditBorrowers([]);
        }
      }
    } catch (error) {
      console.error("Error fetching subscription for edit:", error);
      setAlertConfig({ visibility: true, message: "Failed to fetch subscription details", type: "error" });
    } finally {
      setEditModalLoading(false);
    }
  };
  const handleEditGroupTicketSelect = (value) => {
    setEditGroupTicketValue(value);
    if (!value) {
      setEditSubTags((prev) => ({ ...prev, group_id: "", ticket: "", pigme_id: "", loan_id: "", pay_type: "CHIT" }));
      return;
    }
    const [type, id, ticket] = value.split("|");
    if (type === "chit") {
      setEditSubTags({ pay_type: "CHIT", group_id: id, ticket, pigme_id: "", loan_id: "" });
    } else if (type === "pigme") {
      setEditSubTags({ pay_type: "Pigme", group_id: "", ticket: "", pigme_id: id, loan_id: "" });
    } else if (type === "loan") {
      setEditSubTags({ pay_type: "Loan", group_id: "", ticket: "", pigme_id: "", loan_id: id });
    }
  };
  const handleSubEditSubmit = async (e) => {
    e.preventDefault();
    if (!currentEditSub) return;
    try {
      const payload = { pay_type: editSubTags.pay_type };
      if (editSubTags.pay_type === "CHIT") {
        payload.group_id = editSubTags.group_id;
        payload.ticket = editSubTags.ticket;
      } else if (editSubTags.pay_type === "Pigme") {
        payload.pigme_id = editSubTags.pigme_id;
      } else if (editSubTags.pay_type === "Loan") {
        payload.loan_id = editSubTags.loan_id;
      }
      await api.patch(`/cashfree-subscription/subscription/${currentEditSub._id}`, payload);
      setSubReloadTrigger((prev) => prev + 1);
      setAlertConfig({ visibility: true, message: "Subscription updated successfully", type: "success" });
      setShowSubEditModal(false);
      setCurrentEditSub(null);
    } catch (error) {
      console.error("Error updating subscription:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to update subscription",
        type: "error"
      });
    }
  };
  useEffect(() => {
    const fetchSubscriptions = async () => {
      try {
        setSubIsLoading(true);
        const response = await api.get("/cashfree-subscription/subscription");
        let subsData = response.data?.data || response.data || [];
        subsData.sort((a, b) => new Date(b.subscription_first_charge_time) - new Date(a.subscription_first_charge_time));
        setSubscriptions(subsData);
        const formattedData = subsData.map((sub, index) => {
          const getStatusDisplay = (status) => {
            switch (status?.toUpperCase()) {
              case "ACTIVE":
                return { icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, { className: "text-green-500 text-base" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                  lineNumber: 523,
                  columnNumber: 32
                }, this), color: "text-green-700", bg: "bg-green-100", label: "Active" };
              case "INITIALIZED":
                return { icon: /* @__PURE__ */ jsxDEV(SyncOutlined, { spin: true, className: "text-blue-500 text-base" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                  lineNumber: 525,
                  columnNumber: 32
                }, this), color: "text-blue-700", bg: "bg-blue-100", label: "Initialized" };
              case "CANCELLED":
                return { icon: /* @__PURE__ */ jsxDEV(CloseCircleOutlined, { className: "text-red-500 text-base" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                  lineNumber: 527,
                  columnNumber: 32
                }, this), color: "text-red-700", bg: "bg-red-100", label: "Cancelled" };
              default:
                return { icon: /* @__PURE__ */ jsxDEV(CloseCircleOutlined, { className: "text-gray-400 text-base" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                  lineNumber: 529,
                  columnNumber: 32
                }, this), color: "text-gray-600", bg: "bg-gray-100", label: status || "Unknown" };
            }
          };
          const statusDisplay = getStatusDisplay(sub.subscription_status);
          const getGroupDetails = sub.subscription_tags?.loan_id?.loan_id || (sub.subscription_tags?.group_id ? `${sub.subscription_tags.group_id.group_name || "Group"} | Ticket: ${sub.subscription_tags.ticket || "?"}` : sub.subscription_tags?.pigme_id?.pigme_id || "—");
          return {
            _id: sub._id,
            id: index + 1,
            subscription_id: sub.subscription_id,
            customer_name: sub.customer_details?.customer_name,
            customer_email: sub.customer_details?.customer_email,
            customer_phone: sub.customer_details?.customer_phone,
            plan_id: sub.plan_details?.plan_id,
            expiry_time: formatDateTime(sub.subscription_expiry_time),
            first_charge_time: formatDateTime(sub.subscription_first_charge_time),
            notification_channel: sub.subscription_meta?.notification_channel?.join(", "),
            authorization_amount: sub.authorization_details?.authorization_amount,
            refund: sub.authorization_details?.authorization_amount_refund ? "Yes" : "No",
            payment_methods: sub.authorization_details?.payment_methods?.join(", "),
            user_id: sub.subscription_tags?.user_id,
            pay_type: sub.subscription_tags?.pay_type,
            group_id: getGroupDetails,
            ticket: sub.subscription_tags?.ticket,
            Status: sub.subscription_status,
            status: /* @__PURE__ */ jsxDEV("div", { className: `inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${statusDisplay.bg} ${statusDisplay.color}`, children: [
              statusDisplay.icon,
              /* @__PURE__ */ jsxDEV("span", { children: statusDisplay.label }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 562,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 560,
              columnNumber: 13
            }, this),
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
              Dropdown,
              {
                menu: {
                  items: [
                    {
                      key: "1",
                      label: /* @__PURE__ */ jsxDEV("div", { onClick: () => handleSubEditModalOpen(sub._id), children: "Edit" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 573,
                        columnNumber: 21
                      }, this)
                    },
                    {
                      key: "2",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-red-600",
                          onClick: () => handleSubDeleteModalOpen(sub._id),
                          children: "Delete"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                          lineNumber: 581,
                          columnNumber: 21
                        },
                        this
                      )
                    }
                  ]
                },
                placement: "bottomLeft",
                children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold cursor-pointer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                  lineNumber: 593,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 567,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 566,
              columnNumber: 13
            }, this)
          };
        });
        setTableSubscriptions(formattedData);
      } catch (error) {
        console.error("Error fetching subscriptions:", error);
        setAlertConfig({ visibility: true, message: "Failed to fetch subscriptions", type: "error" });
      } finally {
        setSubIsLoading(false);
      }
    };
    fetchSubscriptions();
  }, [subReloadTrigger]);
  useEffect(() => {
    const fetchPlans = async () => {
      try {
        const response = await api.get("/cashfree-subscription/plans");
        const plansData = response.data?.data || response.data || [];
        setPlansForDropdown(plansData);
      } catch (error) {
        console.error("Error fetching plans:", error);
      }
    };
    fetchPlans();
  }, [planReloadTrigger]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const now = /* @__PURE__ */ new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(now.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    const year = tomorrow.getFullYear();
    const month = String(tomorrow.getMonth() + 1).padStart(2, "0");
    const day = String(tomorrow.getDate()).padStart(2, "0");
    const minDateTime = `${year}-${month}-${day}T00:00`;
    setFirstChargeTimeMin(minDateTime);
    setExpiryTimeMin(minDateTime);
  }, []);
  useEffect(() => {
    if (subFormData.subscription_first_charge_time) {
      setExpiryTimeMin(subFormData.subscription_first_charge_time);
      if (subFormData.subscription_expiry_time && subFormData.subscription_expiry_time <= subFormData.subscription_first_charge_time) {
        setSubFormData((prev) => ({ ...prev, subscription_expiry_time: "" }));
        setSubErrors((prev) => ({ ...prev, subscription_expiry_time: "Expiry time must be greater than first charge time" }));
      }
    } else {
      const now = /* @__PURE__ */ new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(now.getDate() + 1);
      const year = tomorrow.getFullYear();
      const month = String(tomorrow.getMonth() + 1).padStart(2, "0");
      const day = String(tomorrow.getDate()).padStart(2, "0");
      setExpiryTimeMin(`${year}-${month}-${day}T00:00`);
    }
  }, [subFormData.subscription_first_charge_time]);
  useEffect(() => {
    if (!selectedUserId) return;
    const fetchBorrowers = async () => {
      try {
        const response = await api.get(`/v1/admin/loans/borrowers/${selectedUserId}`);
        setBorrowers(response.data.data);
      } catch (err) {
        setBorrowers([]);
      }
    };
    const fetchPigme = async () => {
      try {
        const response = await api.get(`/pigme/get-pigme-customer-by-user-id/${selectedUserId}`);
        setPigmeCustomers(response.data);
      } catch (err) {
        setPigmeCustomers([]);
      }
    };
    fetchBorrowers();
    fetchPigme();
  }, [selectedUserId]);
  const handleGroupAuctionChange = async (userId) => {
    if (!userId) return;
    try {
      const response = await api.post(`/enroll/get-user-tickets-report/${userId}`);
      if (response.data && response.data.length > 0) {
        const validEnrollments = response.data.filter(
          (auction) => auction.enrollment && auction.enrollment.group
        );
        setFilteredEnrollments(validEnrollments);
      }
    } catch (error) {
      console.error("Error fetching enrollment data:", error);
      setFilteredEnrollments([]);
    }
  };
  const handleCustomerSelect = async (userId) => {
    setSelectedUserId(userId);
    const selectedUser = users.find((user) => user._id === userId);
    if (selectedUser) {
      setSubFormData((prev) => ({
        ...prev,
        customer_details: {
          customer_name: selectedUser.full_name || "",
          customer_email: selectedUser.email || "",
          customer_phone: selectedUser.phone_number || ""
        },
        subscription_tags: { ...prev.subscription_tags, user_id: userId }
      }));
    } else {
      setSubFormData((prev) => ({
        ...prev,
        subscription_tags: { ...prev.subscription_tags, user_id: userId }
      }));
    }
    setSubErrors((prev) => ({ ...prev, customer: "" }));
    setSelectedGroupTicketValue(null);
    await handleGroupAuctionChange(userId);
  };
  const handleGroupTicketSelect = (value) => {
    setSelectedGroupTicketValue(value);
    if (!value) {
      setSubFormData((prev) => ({
        ...prev,
        subscription_tags: { ...prev.subscription_tags, group_id: "", ticket: "", pay_type: "CHIT" }
      }));
      return;
    }
    const [type, id, ticket] = value.split("|");
    if (type === "chit") {
      setSubFormData((prev) => ({
        ...prev,
        subscription_tags: { ...prev.subscription_tags, group_id: id, ticket, pay_type: "CHIT" }
      }));
    } else if (type === "pigme") {
      setSubFormData((prev) => ({
        ...prev,
        subscription_tags: { ...prev.subscription_tags, pigme_id: id, pay_type: "Pigme" }
      }));
    } else if (type === "loan") {
      setSubFormData((prev) => ({
        ...prev,
        subscription_tags: { ...prev.subscription_tags, loan_id: id, pay_type: "Loan" }
      }));
    }
  };
  const handleSubNestedChange = (section, field, value) => {
    setSubFormData((prev) => ({
      ...prev,
      [section]: { ...prev[section], [field]: value }
    }));
    setSubErrors((prev) => ({ ...prev, [`${section}.${field}`]: "" }));
  };
  const handleSubChange = (e) => {
    const { name, value } = e.target;
    setSubFormData((prev) => ({ ...prev, [name]: value }));
    setSubErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const convertToISOWithOffset = (datetimeLocal) => {
    if (!datetimeLocal) return "";
    const date = new Date(datetimeLocal);
    const tzOffset = -date.getTimezoneOffset();
    const sign = tzOffset >= 0 ? "+" : "-";
    const hours = String(Math.floor(Math.abs(tzOffset) / 60)).padStart(2, "0");
    const minutes = String(Math.abs(tzOffset) % 60).padStart(2, "0");
    return date.toISOString().replace("Z", `${sign}${hours}:${minutes}`);
  };
  const validateSubForm = () => {
    const newErrors = {};
    if (!selectedUserId) newErrors.customer = "Please select a customer";
    if (!selectedGroupTicketValue) newErrors.group = "Please select a group and ticket";
    if (!subFormData.subscription_id) newErrors.subscription_id = "Subscription ID is required";
    if (!subFormData.plan_details.plan_id) newErrors["plan_details.plan_id"] = "Plan is required";
    if (!subFormData.subscription_expiry_time) newErrors.subscription_expiry_time = "Expiry time is required";
    if (!subFormData.subscription_first_charge_time) newErrors.subscription_first_charge_time = "First charge time is required";
    if (subFormData.subscription_expiry_time && subFormData.subscription_first_charge_time && subFormData.subscription_expiry_time <= subFormData.subscription_first_charge_time) {
      newErrors.subscription_expiry_time = "Expiry time must be greater than first charge time";
    }
    if (!subFormData.authorization_details.authorization_amount || subFormData.authorization_details.authorization_amount <= 0)
      newErrors["authorization_details.authorization_amount"] = "Authorization amount must be positive";
    setSubErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubSubmit = async (e) => {
    e.preventDefault();
    if (!validateSubForm()) return;
    try {
      let subscriptionTags = { user_id: selectedUserId, pay_type: subFormData.subscription_tags.pay_type };
      if (subscriptionTags.pay_type === "CHIT") {
        subscriptionTags.group_id = subFormData.subscription_tags.group_id;
        subscriptionTags.ticket = subFormData.subscription_tags.ticket;
      } else if (subscriptionTags.pay_type === "Pigme") {
        subscriptionTags.pigme_id = subFormData.subscription_tags.pigme_id;
      } else if (subscriptionTags.pay_type === "Loan") {
        subscriptionTags.loan_id = subFormData.subscription_tags.loan_id;
      }
      const payload = {
        subscription_id: subFormData.subscription_id,
        customer_details: {
          customer_name: subFormData.customer_details.customer_name,
          customer_email: subFormData.customer_details.customer_email || "admin@mychits.co.in",
          customer_phone: subFormData.customer_details.customer_phone
        },
        plan_details: { plan_id: subFormData.plan_details.plan_id },
        subscription_expiry_time: convertToISOWithOffset(subFormData.subscription_expiry_time),
        subscription_first_charge_time: convertToISOWithOffset(subFormData.subscription_first_charge_time),
        subscription_meta: { notification_channel: ["SMS"] },
        authorization_details: {
          authorization_amount: Number(subFormData.authorization_details.authorization_amount),
          authorization_amount_refund: subFormData.authorization_details.authorization_amount_refund,
          payment_methods: subFormData.authorization_details.payment_methods
        },
        subscription_tags: subscriptionTags
      };
      await api.post("/cashfree-subscription/subscription", payload);
      setSubReloadTrigger((prev) => prev + 1);
      setAlertConfig({ visibility: true, message: "Subscription added successfully", type: "success" });
      setShowSubModal(false);
      setSubFormData({
        subscription_id: "",
        customer_details: { customer_name: "", customer_email: "", customer_phone: "" },
        plan_details: { plan_id: "" },
        subscription_expiry_time: "",
        subscription_first_charge_time: "",
        subscription_meta: { notification_channel: [] },
        authorization_details: { authorization_amount: "", authorization_amount_refund: true, payment_methods: ["upi"] },
        subscription_tags: { user_id: "", pay_type: "CHIT", group_id: "", ticket: "" }
      });
      setSelectedUserId("");
      setSelectedGroupTicketValue(null);
    } catch (error) {
      console.error("Error adding subscription:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to add subscription",
        type: "error"
      });
    }
  };
  const handleSubDeleteModalOpen = async (subId) => {
    try {
      const response = await api.get(`/cashfree-subscription/subscription/${subId}`);
      setCurrentSubscription(response.data?.data || response.data);
      setShowSubDeleteModal(true);
    } catch (error) {
      console.error("Error fetching subscription:", error);
    }
  };
  const handleSubDelete = async () => {
    if (currentSubscription) {
      try {
        await api.delete(`/cashfree-subscription/subscription/${currentSubscription._id}`);
        setSubReloadTrigger((prev) => prev + 1);
        setAlertConfig({ message: "Subscription deleted successfully", type: "success", visibility: true });
        setShowSubDeleteModal(false);
        setCurrentSubscription(null);
      } catch (error) {
        console.error("Error deleting subscription:", error);
        setAlertConfig({ message: "Failed to delete subscription", type: "error", visibility: true });
      }
    }
  };
  const planColumns = [
    { key: "id", header: "SL. NO" },
    { key: "plan_id", header: "Plan ID" },
    { key: "plan_name", header: "Plan Name" },
    { key: "plan_type", header: "Type" },
    { key: "plan_currency", header: "Currency" },
    { key: "plan_recurring_amount", header: "Recurring Amount" },
    { key: "plan_max_amount", header: "Max Amount" },
    { key: "plan_max_cycles", header: "Max Cycles" },
    { key: "plan_intervals", header: "Intervals" },
    { key: "plan_interval_type", header: "Interval Type" },
    { key: "plan_note", header: "Note" },
    { key: "action", header: "Action" }
  ];
  const subColumns = [
    { key: "id", header: "SL. NO" },
    { key: "subscription_id", header: "Subscription ID" },
    { key: "status", header: "Status" },
    { key: "customer_name", header: "Customer Name" },
    { key: "customer_email", header: "Email" },
    { key: "customer_phone", header: "Phone" },
    { key: "plan_id", header: "Plan ID" },
    { key: "pay_type", header: "Pay Type" },
    { key: "group_id", header: "Group Details" },
    { key: "first_charge_time", header: "First Charge Date", width: 190 },
    { key: "expiry_time", header: "Expiry Date", width: 180 },
    { key: "authorization_amount", header: "Auth Amount" },
    { key: "action", header: "Action" }
  ];
  const ExcelColumns = [
    { key: "id", header: "SL. NO" },
    { key: "subscription_id", header: "Subscription ID" },
    { key: "Status", header: "Status" },
    { key: "customer_name", header: "Customer Name" },
    { key: "customer_email", header: "Email" },
    { key: "customer_phone", header: "Phone" },
    { key: "plan_id", header: "Plan ID" },
    { key: "pay_type", header: "Pay Type" },
    { key: "group_id", header: "Group Details" },
    { key: "first_charge_time", header: "First Charge Date", width: 190 },
    { key: "expiry_time", header: "Expiry Date", width: 180 },
    { key: "authorization_amount", header: "Auth Amount" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen overflow-x-hidden", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true, onGlobalSearchChangeHandler }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 937,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 938,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 945,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0 p-7 overflow-x-hidden", children: /* @__PURE__ */ jsxDEV(Tabs, { activeKey: activeTab, onChange: setActiveTab, className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV(TabPane, { tab: "Plans", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Subscription Plans" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 950,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowPlanModal(true);
                  setPlanErrors({});
                },
                className: "bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition",
                children: "+ Add Plan"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 951,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 949,
            columnNumber: 17
          }, this),
          tablePlans.length > 0 && !planIsLoading ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              catcher: "_id",
              updateHandler: handlePlanViewModalOpen,
              data: filterOption(tablePlans, searchText),
              columns: planColumns,
              exportedPdfName: "SubscriptionPlans",
              exportedFileName: "SubscriptionPlans.csv"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 962,
              columnNumber: 17
            },
            this
          ) : /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: planIsLoading, data: "Plans", failure: tablePlans.length <= 0 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 971,
            columnNumber: 17
          }, this)
        ] }, "plans", true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 948,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TabPane, { tab: "Subscriptions", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Subscriptions" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 977,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowSubModal(true);
                  setSubErrors({});
                },
                className: "bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition",
                children: "+ Add Subscription"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 978,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 976,
            columnNumber: 17
          }, this),
          tableSubscriptions.length > 0 && !subIsLoading ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              catcher: "_id",
              data: filterOption(tableSubscriptions, searchText),
              columns: subColumns,
              updateHandler: handleSubEditModalOpen,
              exportedPdfName: "Subscriptions",
              exportedFileName: "Subscriptions.csv",
              exportCols: ExcelColumns
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 989,
              columnNumber: 17
            },
            this
          ) : /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: subIsLoading, data: "Subscriptions", failure: tableSubscriptions.length <= 0 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 999,
            columnNumber: 17
          }, this)
        ] }, "subscriptions", true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 975,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 947,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 946,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 944,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showPlanViewModal, onClose: () => {
      setShowPlanViewModal(false);
      setViewPlan(null);
    }, children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-6 text-left bg-white rounded-2xl max-h-[90vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6 border-b pb-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-800", children: "View Plan" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1013,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Plan details (read-only)" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1014,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1012,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1011,
        columnNumber: 13
      }, this),
      viewPlan && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Plan ID" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1020,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_id || "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1022,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1019,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Plan Name" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1025,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_name || "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1026,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1024,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Plan Type" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1029,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_type || "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1030,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1028,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Currency" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1033,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_currency || "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1034,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1032,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Recurring Amount (₹)" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1037,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_recurring_amount ?? "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1038,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1036,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Max Amount (₹)" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1041,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_max_amount ?? "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1042,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1040,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Max Cycles" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1045,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_max_cycles ?? "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1046,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1044,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Intervals" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1049,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_intervals ?? "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1050,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1048,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Interval Type" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1053,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_interval_type || "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1054,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1052,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Plan Category" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1057,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.plan_note || "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1058,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1056,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Created At" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1061,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.createdAt ? formatDateTime(viewPlan.createdAt) : "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1062,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1060,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Updated At" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1065,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: viewPlan.updatedAt ? formatDateTime(viewPlan.updatedAt) : "", readOnly: true, className: "w-full rounded-xl border border-gray-200 bg-gray-100 px-4 py-3 text-sm outline-none cursor-not-allowed text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1066,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1064,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1018,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-8", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setShowPlanViewModal(false);
            setViewPlan(null);
          },
          className: "px-6 py-2.5 rounded-xl bg-blue-900 text-white font-medium hover:bg-blue-800 transition shadow-lg",
          children: "Close"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1071,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1070,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1010,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1009,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showPlanModal, onClose: () => setShowPlanModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-6 text-left bg-white rounded-2xl max-h-[90vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6 border-b pb-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-800", children: "Create Subscription Plan" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1087,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Add new recurring subscription plan" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1088,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1086,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1085,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handlePlanSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
              "Plan ID ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1095,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1094,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "plan_id",
                  value: planFormData.plan_id,
                  onChange: handlePlanChange,
                  placeholder: "MCF-PL-{{NUMBER}}-{{AMOUNT}}",
                  className: "w-full rounded-xl border border-gray-300 bg-gray-50 pl-4 pr-28 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                  lineNumber: 1098,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setPlanFormData((prev) => ({
                    ...prev,
                    plan_id: `MCF-PL-${globalThis.crypto.randomUUID().replace(/-/g, "").slice(0, 12)}`
                  })),
                  className: "absolute right-1.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5 rounded-lg bg-blue-600 text-white px-3 py-2 text-xs font-medium hover:bg-blue-700 active:scale-95 transition",
                  children: [
                    /* @__PURE__ */ jsxDEV(RefreshCw, { size: 14 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1116,
                      columnNumber: 23
                    }, this),
                    "Generate"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                  lineNumber: 1106,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1097,
              columnNumber: 19
            }, this),
            planErrors.plan_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: planErrors.plan_id }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1120,
              columnNumber: 42
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1093,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
              "Plan Name ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1123,
                columnNumber: 95
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1123,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", name: "plan_name", value: planFormData.plan_name, onChange: handlePlanChange, placeholder: "Gold Monthly Plan", className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1124,
              columnNumber: 19
            }, this),
            planErrors.plan_name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: planErrors.plan_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1125,
              columnNumber: 44
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1122,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 text-sm font-semibold text-gray-700 inline-flex items-center gap-2", children: [
              "Recurring Amount (₹) ",
              /* @__PURE__ */ jsxDEV(Tooltip, { title: "Amount that customer needs to pay repeatedly for each cycle.", children: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 cursor-pointer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1128,
                columnNumber: 209
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1128,
                columnNumber: 131
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1128,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", name: "plan_recurring_amount", value: planFormData.plan_recurring_amount, onChange: handlePlanChange, placeholder: "500", className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1129,
              columnNumber: 19
            }, this),
            planErrors.plan_recurring_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: planErrors.plan_recurring_amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1130,
              columnNumber: 56
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1127,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 text-sm font-semibold text-gray-700 inline-flex items-center gap-2", children: [
              "Max Amount (₹) ",
              /* @__PURE__ */ jsxDEV(Tooltip, { title: "Maximum total amount allowed under this subscription plan.", children: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 cursor-pointer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1133,
                columnNumber: 201
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1133,
                columnNumber: 125
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1133,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", name: "plan_max_amount", value: planFormData.plan_max_amount, onChange: handlePlanChange, placeholder: "10000", className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1134,
              columnNumber: 19
            }, this),
            planErrors.plan_max_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: planErrors.plan_max_amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1135,
              columnNumber: 50
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1132,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 text-sm font-semibold text-gray-700 inline-flex items-center gap-2", children: [
              "Max Cycles (Optional) ",
              /* @__PURE__ */ jsxDEV(Tooltip, { title: "Maximum number of cycles for this subscription plan.", children: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 cursor-pointer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1138,
                columnNumber: 202
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1138,
                columnNumber: 132
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1138,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", name: "plan_max_cycles", value: planFormData.plan_max_cycles, onChange: handlePlanChange, placeholder: "12", className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1139,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1137,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 text-sm font-semibold text-gray-700 inline-flex items-center gap-2", children: [
              "Intervals ",
              /* @__PURE__ */ jsxDEV(Tooltip, { title: "Total number of Intervals for this subscription plan.", children: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 cursor-pointer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1142,
                columnNumber: 191
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1142,
                columnNumber: 120
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1142,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", name: "plan_intervals", value: planFormData.plan_intervals, onChange: handlePlanChange, placeholder: "1", className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1143,
              columnNumber: 19
            }, this),
            planErrors.plan_intervals && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: planErrors.plan_intervals }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1144,
              columnNumber: 49
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1141,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Interval Type" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1147,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { className: "w-full", value: planFormData.plan_interval_type, onChange: (value) => handlePlanAntDSelect("plan_interval_type", value), size: "large", children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "DAY", children: "Daily" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1149,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "WEEK", children: "Weekly" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1150,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "MONTH", children: "Monthly" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1151,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "YEAR", children: "Yearly" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1152,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1148,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1146,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Plan Category" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1156,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { className: "w-full", value: planFormData.plan_note, onChange: (value) => handlePlanAntDSelect("plan_note", value), size: "large", children: ["Chit", "Loan", "Pigmy"].map((note) => /* @__PURE__ */ jsxDEV(Select.Option, { value: note, children: note }, note, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1158,
              columnNumber: 62
            }, this)) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1157,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1155,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1092,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "hidden", name: "plan_type", value: "PERIODIC" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1162,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "hidden", name: "plan_currency", value: "INR" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1163,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-8", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setShowPlanModal(false), className: "px-5 py-2.5 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-100 transition", children: "Cancel" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1165,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "px-6 py-2.5 rounded-xl bg-blue-900 text-white font-medium hover:bg-blue-800 transition shadow-lg", children: "Save Plan" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1166,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1164,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1091,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1084,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1083,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showPlanDeleteModal, onClose: () => {
      setShowPlanDeleteModal(false);
      setCurrentPlan(null);
    }, children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Plan" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1175,
        columnNumber: 13
      }, this),
      currentPlan && /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => {
        e.preventDefault();
        handlePlanDelete();
      }, className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Please enter ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentPlan.plan_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1179,
              columnNumber: 96
            }, this),
            " to confirm deletion. ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1179,
              columnNumber: 189
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1179,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", id: "planNameConfirm", placeholder: "Enter the plan name", required: true, className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1180,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1178,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "w-full text-white bg-red-700 hover:bg-red-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center", children: "Delete" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1182,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1177,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1174,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1173,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showSubModal, onClose: () => setShowSubModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full mx-auto bg-white rounded-3xl border-slate-100 overflow-hidden flex flex-col", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-8 py-6 bg-gradient-to-r from-slate-50 to-white border-b border-slate-100 shrink-0", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-slate-800 tracking-tight", children: "Create Subscription" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1226,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500 mt-1 font-medium", children: "Configure a new recurring payment plan" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1227,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1225,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1224,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1223,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto px-8 py-6 custom-scrollbar", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: [
              "Customer ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ml-1", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1235,
                columnNumber: 92
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1235,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Select or search customer...",
                showSearch: true,
                className: "w-full h-12 rounded-lg",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                value: selectedUserId || void 0,
                onChange: handleCustomerSelect,
                children: users.map(
                  (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                    user.full_name,
                    " | ",
                    user.phone_number,
                    " ",
                    user.email && `| ${user.email}`
                  ] }, user._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                    lineNumber: 1245,
                    columnNumber: 23
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1236,
                columnNumber: 21
              },
              this
            ),
            subErrors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: subErrors.customer }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1250,
              columnNumber: 44
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1234,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: [
              "Group & Ticket ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ml-1", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1254,
                columnNumber: 98
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1254,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Select Group | Ticket",
                onChange: handleGroupTicketSelect,
                value: selectedGroupTicketValue,
                className: "w-full h-12 rounded-lg",
                allowClear: true,
                children: [
                  filteredEnrollments.map((entry, idx) => {
                    const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                    const groupId = entry?.enrollment?.group?._id || `missing-${idx}`;
                    const ticket = entry?.enrollment?.tickets || "Unknown";
                    return /* @__PURE__ */ jsxDEV(Select.Option, { value: `chit|${groupId}|${ticket}`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: groupName }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1267,
                        columnNumber: 58
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: [
                        "Ticket: ",
                        ticket,
                        " (CHIT)"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1267,
                        columnNumber: 106
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1267,
                      columnNumber: 27
                    }, this) }, `chit|${groupId}|${ticket}`, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1266,
                      columnNumber: 32
                    }, this);
                  }),
                  pigmeCustomers.map(
                    (pigme) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `pigme|${pigme._id}|${pigme.pigme_id || pigme._id}`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: pigme.pigme_id }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1272,
                        columnNumber: 58
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: [
                        "₹ ",
                        pigme.payable_amount,
                        " (PIGMY)"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1272,
                        columnNumber: 111
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1272,
                      columnNumber: 27
                    }, this) }, `pigme|${pigme._id}`, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1271,
                      columnNumber: 23
                    }, this)
                  ),
                  borrowers.map(
                    (borrower) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `loan|${borrower._id}|${borrower.loan_id || borrower._id}`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: borrower.loan_id }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1277,
                        columnNumber: 58
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: [
                        "₹ ",
                        borrower.loan_amount,
                        " (LOAN)"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1277,
                        columnNumber: 113
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1277,
                      columnNumber: 27
                    }, this) }, `loan|${borrower._id}`, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1276,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1255,
                columnNumber: 21
              },
              this
            ),
            subErrors.group && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: subErrors.group }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1281,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1253,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: [
              "Subscription ID ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ml-1", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1287,
                columnNumber: 39
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1286,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "subscription_id",
                  value: subFormData.subscription_id,
                  onChange: handleSubChange,
                  placeholder: "e.g. SUB_001",
                  className: "w-full h-12 rounded-lg border border-slate-200 pl-4 pr-28"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                  lineNumber: 1290,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setSubFormData((prev) => ({
                    ...prev,
                    subscription_id: `SUB_${globalThis.crypto.randomUUID().replace(/-/g, "").slice(0, 12)}`
                  })),
                  className: "absolute right-1.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5 rounded-md bg-slate-800 text-white px-3 py-2 text-xs font-medium hover:bg-slate-900 active:scale-95 transition",
                  children: [
                    /* @__PURE__ */ jsxDEV(RefreshCw, { size: 14 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1308,
                      columnNumber: 25
                    }, this),
                    "Generate"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                  lineNumber: 1298,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1289,
              columnNumber: 21
            }, this),
            subErrors.subscription_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs", children: subErrors.subscription_id }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1312,
              columnNumber: 51
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1285,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: [
              "Plan ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ml-1", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1316,
                columnNumber: 88
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1316,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { className: "w-full h-12 rounded-lg", placeholder: "Select a plan", value: subFormData.plan_details.plan_id || void 0, onChange: (value) => handleSubNestedChange("plan_details", "plan_id", value), children: plansForDropdown.map((plan) => /* @__PURE__ */ jsxDEV(Select.Option, { value: plan.plan_id, children: [
              plan.plan_name,
              " (",
              plan.plan_id,
              ")"
            ] }, plan.plan_id, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1318,
              columnNumber: 55
            }, this)) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1317,
              columnNumber: 21
            }, this),
            subErrors["plan_details.plan_id"] && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs", children: subErrors["plan_details.plan_id"] }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1320,
              columnNumber: 59
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1315,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: [
              "First Charge Time ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ml-1", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1324,
                columnNumber: 101
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1324,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "datetime-local", min: firstChargeTimeMin, value: subFormData.subscription_first_charge_time, onChange: (e) => setSubFormData({ ...subFormData, subscription_first_charge_time: e.target.value }), className: "w-full h-12 rounded-lg border border-slate-200 px-4" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1325,
              columnNumber: 21
            }, this),
            subErrors.subscription_first_charge_time && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs", children: subErrors.subscription_first_charge_time }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1326,
              columnNumber: 66
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1323,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: [
              "Expiry Time ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ml-1", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1330,
                columnNumber: 95
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1330,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "datetime-local", min: expiryTimeMin, value: subFormData.subscription_expiry_time, onChange: (e) => setSubFormData({ ...subFormData, subscription_expiry_time: e.target.value }), className: "w-full h-12 rounded-lg border border-slate-200 px-4" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1331,
              columnNumber: 21
            }, this),
            subErrors.subscription_expiry_time && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs", children: subErrors.subscription_expiry_time }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1332,
              columnNumber: 60
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1329,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: [
              "Authorization Amount (₹) ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ml-1", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1336,
                columnNumber: 108
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1336,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", value: subFormData.authorization_details.authorization_amount, onChange: (e) => handleSubNestedChange("authorization_details", "authorization_amount", e.target.value), placeholder: "0.00", className: "w-full h-12 rounded-lg border border-slate-200 px-4" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1337,
              columnNumber: 21
            }, this),
            subErrors["authorization_details.authorization_amount"] && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs", children: subErrors["authorization_details.authorization_amount"] }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1338,
              columnNumber: 81
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1335,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 bg-slate-50 rounded-xl", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium", children: "Refund Authorization Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1342,
                columnNumber: 26
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-500 block", children: "Refund the initial hold amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1342,
                columnNumber: 98
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1342,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Checkbox, { checked: subFormData.authorization_details.authorization_amount_refund, onChange: (e) => handleSubNestedChange("authorization_details", "authorization_amount_refund", e.target.checked) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1343,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1341,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "Payment Methods" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1347,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { className: "w-full h-12", value: subFormData.authorization_details.payment_methods, disabled: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1348,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1346,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "Notification Channels" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1352,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { className: "w-full h-12", value: "SMS", disabled: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1353,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1351,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1233,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-4 mt-10 pt-6 border-t", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setShowSubModal(false), className: "px-6 py-2.5 rounded-xl border", children: "Cancel" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1358,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "px-8 py-2.5 rounded-xl bg-blue-600 text-white font-semibold shadow-lg", children: "Save Subscription" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1359,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1357,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1232,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1231,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1222,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1221,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showSubEditModal, onClose: () => {
      setShowSubEditModal(false);
      setCurrentEditSub(null);
      setEditModalLoading(false);
    }, children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full mx-auto bg-white rounded-3xl border-slate-100 overflow-hidden flex flex-col", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-8 py-6 bg-gradient-to-r from-slate-50 to-white border-b border-slate-100 shrink-0", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-slate-800 tracking-tight", children: "Edit Subscription" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1371,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500 mt-1 font-medium", children: "Only Group & Ticket can be modified" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1372,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1370,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1369,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto px-8 py-6 custom-scrollbar", children: editModalLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(Spin, { size: "large", tip: "Loading subscription details..." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1378,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1377,
        columnNumber: 15
      }, this) : currentEditSub && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubEditSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1386,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: `${currentEditSub.customer_details?.customer_name || ""} | ${currentEditSub.customer_details?.customer_phone || ""}`,
                readOnly: true,
                className: "w-full h-12 rounded-lg border border-slate-200 bg-slate-100 px-4 text-slate-500 cursor-not-allowed"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1387,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1385,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: [
              "Group & Ticket ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ml-1", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1397,
                columnNumber: 102
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1397,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Select Group | Ticket",
                onChange: handleEditGroupTicketSelect,
                value: editGroupTicketValue,
                className: "w-full h-12 rounded-lg",
                allowClear: true,
                children: [
                  editFilteredEnrollments.map((entry, idx) => {
                    const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                    const groupId = entry?.enrollment?.group?._id || `missing-${idx}`;
                    const ticket = entry?.enrollment?.tickets || "Unknown";
                    return /* @__PURE__ */ jsxDEV(Select.Option, { value: `chit|${groupId}|${ticket}`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: groupName }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1411,
                        columnNumber: 64
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: [
                        "Ticket: ",
                        ticket,
                        " (CHIT)"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1411,
                        columnNumber: 112
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1411,
                      columnNumber: 33
                    }, this) }, `chit|${groupId}|${ticket}`, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1410,
                      columnNumber: 27
                    }, this);
                  }),
                  editPigmeCustomers.map(
                    (pigme) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `pigme|${pigme._id}|${pigme.pigme_id || pigme._id}`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: pigme.pigme_id }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1417,
                        columnNumber: 62
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: [
                        "₹ ",
                        pigme.payable_amount,
                        " (PIGMY)"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1417,
                        columnNumber: 115
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1417,
                      columnNumber: 31
                    }, this) }, `pigme|${pigme._id}`, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1416,
                      columnNumber: 23
                    }, this)
                  ),
                  editBorrowers.map(
                    (borrower) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `loan|${borrower._id}|${borrower.loan_id || borrower._id}`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: borrower.loan_id }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1422,
                        columnNumber: 62
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: [
                        "₹ ",
                        borrower.loan_amount,
                        " (LOAN)"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                        lineNumber: 1422,
                        columnNumber: 117
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1422,
                      columnNumber: 31
                    }, this) }, `loan|${borrower._id}`, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                      lineNumber: 1421,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1398,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1396,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "Subscription ID" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1430,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", value: currentEditSub.subscription_id || "", readOnly: true, className: "w-full h-12 rounded-lg border border-slate-200 bg-slate-100 px-4 text-slate-500 cursor-not-allowed" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1431,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1429,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "Plan" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1436,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", value: currentEditSub.plan_details?.plan_id || "", readOnly: true, className: "w-full h-12 rounded-lg border border-slate-200 bg-slate-100 px-4 text-slate-500 cursor-not-allowed" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1437,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1435,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "First Charge Time" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1442,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "datetime-local",
                value: isoToDatetimeLocal(currentEditSub.subscription_first_charge_time),
                readOnly: true,
                className: "w-full h-12 rounded-lg border border-slate-200 bg-slate-100 px-4 text-slate-500 cursor-not-allowed"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1443,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1441,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "Expiry Time" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1453,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "datetime-local",
                value: isoToDatetimeLocal(currentEditSub.subscription_expiry_time),
                readOnly: true,
                className: "w-full h-12 rounded-lg border border-slate-200 bg-slate-100 px-4 text-slate-500 cursor-not-allowed"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1454,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1452,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "Authorization Amount (₹)" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1464,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", value: currentEditSub.authorization_details?.authorization_amount ?? "", readOnly: true, className: "w-full h-12 rounded-lg border border-slate-200 bg-slate-100 px-4 text-slate-500 cursor-not-allowed" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1465,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1463,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 bg-slate-50 rounded-xl opacity-60", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium", children: "Refund Authorization Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1470,
                columnNumber: 30
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-500 block", children: "Refund the initial hold amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
                lineNumber: 1470,
                columnNumber: 102
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1470,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Checkbox, { checked: currentEditSub.authorization_details?.authorization_amount_refund, disabled: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1471,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1469,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "Payment Methods" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1476,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { className: "w-full h-12", value: currentEditSub.authorization_details?.payment_methods || ["upi"], disabled: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1477,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1475,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700", children: "Notification Channels" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1482,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { className: "w-full h-12", value: "SMS", disabled: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1483,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1481,
            columnNumber: 23
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1383,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-4 mt-10 pt-6 border-t", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
            setShowSubEditModal(false);
            setCurrentEditSub(null);
          }, className: "px-6 py-2.5 rounded-xl border", children: "Cancel" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1488,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "px-8 py-2.5 rounded-xl bg-blue-600 text-white font-semibold shadow-lg", children: "Update Subscription" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1489,
            columnNumber: 23
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1487,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1382,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1375,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1368,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1367,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showSubDeleteModal, onClose: () => {
      setShowSubDeleteModal(false);
      setCurrentSubscription(null);
    }, children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Subscription" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1501,
        columnNumber: 13
      }, this),
      currentSubscription && /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => {
        e.preventDefault();
        handleSubDelete();
      }, className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Please enter ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-primary", children: currentSubscription.subscription_id }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1505,
              columnNumber: 96
            }, this),
            " to confirm deletion. ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
              lineNumber: 1505,
              columnNumber: 203
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1505,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", id: "subscriptionConfirm", placeholder: "Enter the subscription ID", required: true, className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
            lineNumber: 1506,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1504,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "w-full text-white bg-red-700 hover:bg-red-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center", children: "Delete" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
          lineNumber: 1508,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
        lineNumber: 1503,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1500,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
      lineNumber: 1499,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
    lineNumber: 936,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx",
    lineNumber: 935,
    columnNumber: 5
  }, this);
};
_s(Subscriptions, "LDDv8qFz6rKKYyJ9RGRKMhF9SAM=");
_c = Subscriptions;
export default Subscriptions;
var _c;
$RefreshReg$(_c, "Subscriptions");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Subscriptions.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUt3QixTQTZ2QnBCLFVBN3ZCb0I7MkJBekt4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxTQUFTQyxNQUFNQyxVQUFVQyxRQUFRQyxTQUFTQyxVQUFVQyxZQUFZO0FBQ2hFLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxxQkFBcUJDLHFCQUFxQkMsb0JBQW9CQyxvQkFBb0I7QUFDM0YsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGlCQUFpQjtBQUUxQixNQUFNLEVBQUVDLFFBQVEsSUFBSXBCO0FBRXBCLE1BQU1xQixnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUUxQixRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXpCLFNBQVMsT0FBTztBQUNsRCxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEIsYUFBYUMsY0FBYyxJQUFJN0IsU0FBUztBQUFBLElBQzdDOEIsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBR0QsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlsQyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDbUMsWUFBWUMsYUFBYSxJQUFJcEMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3FDLGVBQWVDLGdCQUFnQixJQUFJdEMsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3VDLHFCQUFxQkMsc0JBQXNCLElBQUl4QyxTQUFTLEtBQUs7QUFFcEUsUUFBTSxDQUFDeUMsbUJBQW1CQyxvQkFBb0IsSUFBSTFDLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUMyQyxVQUFVQyxXQUFXLElBQUk1QyxTQUFTLElBQUk7QUFDN0MsUUFBTSxDQUFDNkMsYUFBYUMsY0FBYyxJQUFJOUMsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQytDLG1CQUFtQkMsb0JBQW9CLElBQUloRCxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDaUQsbUJBQW1CQyxvQkFBb0IsSUFBSWxELFNBQVMsQ0FBQztBQUM1RCxRQUFNLENBQUNtRCxlQUFlQyxnQkFBZ0IsSUFBSXBELFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNxRCxjQUFjQyxlQUFlLElBQUl0RCxTQUFTO0FBQUEsSUFDL0N1RCxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxlQUFlO0FBQUEsSUFDZkMsdUJBQXVCO0FBQUEsSUFDdkJDLGlCQUFpQjtBQUFBLElBQ2pCQyxpQkFBaUI7QUFBQSxJQUNqQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLG9CQUFvQjtBQUFBLElBQ3BCQyxXQUFXO0FBQUEsRUFDYixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlsRSxTQUFTLENBQUMsQ0FBQztBQUMvQyxRQUFNLENBQUNtRSxnQkFBZ0JDLGlCQUFpQixJQUFJcEUsU0FBUyxFQUFFLEdBQUdxRCxhQUFhLENBQUM7QUFHeEUsUUFBTSxDQUFDZ0IsZUFBZUMsZ0JBQWdCLElBQUl0RSxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDdUUsb0JBQW9CQyxxQkFBcUIsSUFBSXhFLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUN5RSxjQUFjQyxlQUFlLElBQUkxRSxTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDMkUsb0JBQW9CQyxxQkFBcUIsSUFBSTVFLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUM2RSxrQkFBa0JDLG1CQUFtQixJQUFJOUUsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQytFLGdCQUFnQkMsaUJBQWlCLElBQUloRixTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDaUYsYUFBYUMsY0FBYyxJQUFJbEYsU0FBUztBQUFBO0FBQUEsSUFDN0NtRixVQUFVO0FBQUEsSUFDVkMsVUFBVTtBQUFBLElBQ1ZDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUNELFFBQU0sQ0FBQ0Msc0JBQXNCQyx1QkFBdUIsSUFBSXpGLFNBQVMsSUFBSTtBQUNyRSxRQUFNLENBQUMwRix5QkFBeUJDLDBCQUEwQixJQUFJM0YsU0FBUyxFQUFFO0FBQ3pFLFFBQU0sQ0FBQzRGLG9CQUFvQkMscUJBQXFCLElBQUk3RixTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDOEYsZUFBZUMsZ0JBQWdCLElBQUkvRixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDZ0cscUJBQXFCQyxzQkFBc0IsSUFBSWpHLFNBQVMsSUFBSTtBQUNuRSxRQUFNLENBQUNrRyxrQkFBa0JDLG1CQUFtQixJQUFJbkcsU0FBUyxDQUFDO0FBQzFELFFBQU0sQ0FBQ29HLGNBQWNDLGVBQWUsSUFBSXJHLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNzRyxnQkFBZ0JDLGlCQUFpQixJQUFJdkcsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3dHLG1CQUFtQkMsb0JBQW9CLElBQUl6RyxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDMEcscUJBQXFCQyxzQkFBc0IsSUFBSTNHLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUM0RyxnQkFBZ0JDLGlCQUFpQixJQUFJN0csU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQzhHLFdBQVdDLFlBQVksSUFBSS9HLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNnSCwwQkFBMEJDLDJCQUEyQixJQUFJakgsU0FBUyxJQUFJO0FBQzdFLFFBQU0sQ0FBQ2tILG9CQUFvQkMscUJBQXFCLElBQUluSCxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDb0gsZUFBZUMsZ0JBQWdCLElBQUlySCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDc0gsa0JBQWtCQyxtQkFBbUIsSUFBSXZILFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUN3SCxPQUFPQyxRQUFRLElBQUl6SCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDMEgsa0JBQWtCQyxtQkFBbUIsSUFBSTNILFNBQVMsS0FBSztBQUc5RCxRQUFNLENBQUM0SCxhQUFhQyxjQUFjLElBQUk3SCxTQUFTO0FBQUEsSUFDN0M4SCxpQkFBaUI7QUFBQSxJQUNqQkMsa0JBQWtCO0FBQUEsTUFDaEJDLGVBQWU7QUFBQSxNQUNmQyxnQkFBZ0I7QUFBQSxNQUNoQkMsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxJQUNBQyxjQUFjO0FBQUEsTUFDWjVFLFNBQVM7QUFBQSxJQUNYO0FBQUEsSUFDQTZFLDBCQUEwQjtBQUFBLElBQzFCQyxnQ0FBZ0M7QUFBQSxJQUNoQ0MsbUJBQW1CO0FBQUEsTUFDakJDLHNCQUFzQixDQUFDLEtBQUs7QUFBQSxJQUM5QjtBQUFBLElBQ0FDLHVCQUF1QjtBQUFBLE1BQ3JCQyxzQkFBc0I7QUFBQSxNQUN0QkMsNkJBQTZCO0FBQUEsTUFDN0JDLGlCQUFpQixDQUFDLEtBQUs7QUFBQSxJQUN6QjtBQUFBLElBQ0FDLG1CQUFtQjtBQUFBLE1BQ2pCQyxTQUFTO0FBQUEsTUFDVDFELFVBQVU7QUFBQSxNQUNWQyxVQUFVO0FBQUEsTUFDVkMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLENBQUN5RCxXQUFXQyxZQUFZLElBQUkvSSxTQUFTLENBQUMsQ0FBQztBQUc3QyxRQUFNZ0osOEJBQThCQSxDQUFDQyxNQUFNO0FBQ3pDdEgsa0JBQWNzSCxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsRUFDOUI7QUFLQSxRQUFNQywwQkFBMEIsT0FBT0MsV0FBVztBQUNoRCxRQUFJO0FBQ0YsWUFBTUMsV0FBVyxNQUFNeEksSUFBSXlJLElBQUksZ0NBQWdDRixNQUFNLEVBQUU7QUFDdkV6RyxrQkFBWTBHLFNBQVNFLE1BQU1BLFFBQVFGLFNBQVNFLElBQUk7QUFDaEQ5RywyQkFBcUIsSUFBSTtBQUFBLElBQzNCLFNBQVMrRyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQ3BENUgscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUdBakMsWUFBVSxNQUFNO0FBQ2QsVUFBTTRKLGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0Z2Ryx5QkFBaUIsSUFBSTtBQUNyQixjQUFNa0csV0FBVyxNQUFNeEksSUFBSXlJLElBQUksOEJBQThCO0FBQzdELGNBQU1LLFlBQVlOLFNBQVNFLE1BQU1BLFFBQVFGLFNBQVNFLFFBQVE7QUFDMUR0SCxpQkFBUzBILFNBQVM7QUFDbEIsY0FBTUMsZ0JBQWdCRCxVQUFVRSxJQUFJLENBQUNDLE1BQU1DLFdBQVc7QUFBQSxVQUNwREMsS0FBS0YsS0FBS0U7QUFBQUEsVUFDVkMsSUFBSUYsUUFBUTtBQUFBLFVBQ1p6RyxTQUFTd0csS0FBS3hHO0FBQUFBLFVBQ2RDLFdBQVd1RyxLQUFLdkc7QUFBQUEsVUFDaEJDLFdBQVdzRyxLQUFLdEc7QUFBQUEsVUFDaEJDLGVBQWVxRyxLQUFLckc7QUFBQUEsVUFDcEJDLHVCQUF1Qm9HLEtBQUtwRztBQUFBQSxVQUM1QkMsaUJBQWlCbUcsS0FBS25HO0FBQUFBLFVBQ3RCQyxpQkFBaUJrRyxLQUFLbEc7QUFBQUEsVUFDdEJDLGdCQUFnQmlHLEtBQUtqRztBQUFBQSxVQUNyQkMsb0JBQW9CZ0csS0FBS2hHO0FBQUFBLFVBQ3pCQyxXQUFXK0YsS0FBSy9GO0FBQUFBLFVBQ2hCbUcsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU07QUFBQSxnQkFDSkMsT0FBTztBQUFBLGtCQUNMO0FBQUEsb0JBQ0VDLEtBQUs7QUFBQSxvQkFDTEMsT0FDRSx1QkFBQyxTQUFJLFNBQVMsTUFBTWxCLHdCQUF3QlcsS0FBS0UsR0FBRyxHQUFHLG9CQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFSSxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTUMsMEJBQTBCUixLQUFLRSxHQUFHO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGdCQUFDO0FBQUEsY0FFTDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsWUFBUyxXQUFVLDhCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBO0FBQUEsWUExQmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTJCQSxLQTVCOENGLEtBQUtFLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkJBO0FBQUEsUUFFSixFQUFFO0FBQ0Y3SCxzQkFBY3lILGFBQWE7QUFBQSxNQUM3QixTQUFTSixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUM1QzVILHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxVQUFDO0FBQ0NvQix5QkFBaUIsS0FBSztBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUNBdUcsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDMUcsaUJBQWlCLENBQUM7QUFFdEIsUUFBTXVILG1CQUFtQkEsQ0FBQ3ZCLE1BQU07QUFDOUIsVUFBTSxFQUFFd0IsTUFBTXRCLE1BQU0sSUFBSUYsRUFBRUM7QUFDMUI1RixvQkFBZ0IsQ0FBQ29ILFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNELElBQUksR0FBR3RCLE1BQU0sRUFBRTtBQUN0RGpGLGtCQUFjLENBQUN3RyxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDRCxJQUFJLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDbkQ7QUFFQSxRQUFNRSx1QkFBdUJBLENBQUNDLE9BQU96QixVQUFVO0FBQzdDN0Ysb0JBQWdCLENBQUNvSCxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDRSxLQUFLLEdBQUd6QixNQUFNLEVBQUU7QUFDdkRqRixrQkFBYyxDQUFDd0csVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0UsS0FBSyxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQ3BEO0FBRUEsUUFBTUMsbUJBQW1CQSxNQUFNO0FBQzdCLFVBQU1DLFlBQVksQ0FBQztBQUNuQixRQUFJLENBQUN6SCxhQUFhRSxRQUFTdUgsV0FBVXZILFVBQVU7QUFDL0MsUUFBSSxDQUFDRixhQUFhRyxVQUFXc0gsV0FBVXRILFlBQVk7QUFDbkQsUUFBSSxDQUFDSCxhQUFhTSx5QkFBeUJOLGFBQWFNLHlCQUF5QjtBQUMvRW1ILGdCQUFVbkgsd0JBQXdCO0FBQ3BDLFFBQUksQ0FBQ04sYUFBYU8sbUJBQW1CUCxhQUFhTyxtQkFBbUI7QUFDbkVrSCxnQkFBVWxILGtCQUFrQjtBQUM5QixRQUFJLENBQUNQLGFBQWFTLGtCQUFrQlQsYUFBYVMsa0JBQWtCO0FBQ2pFZ0gsZ0JBQVVoSCxpQkFBaUI7QUFDN0IsUUFBSSxDQUFDVCxhQUFhVTtBQUNoQitHLGdCQUFVL0cscUJBQXFCO0FBQ2pDLFFBQUksQ0FBQ1YsYUFBYVcsVUFBVzhHLFdBQVU5RyxZQUFZO0FBQ25ERSxrQkFBYzRHLFNBQVM7QUFDdkIsV0FBT0MsT0FBT0MsS0FBS0YsU0FBUyxFQUFFRyxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNQyxtQkFBbUIsT0FBT2pDLE1BQU07QUFDcENBLE1BQUVrQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ04saUJBQWlCLEVBQUc7QUFDekIsUUFBSTtBQUNGLFlBQU0sRUFBRWhILGlCQUFpQixHQUFHdUgsS0FBSyxJQUFJL0g7QUFDckMsWUFBTWdJLFVBQVU7QUFBQSxRQUNkLEdBQUdEO0FBQUFBLFFBQ0h6SCx1QkFBdUIySCxPQUFPakksYUFBYU0scUJBQXFCO0FBQUEsUUFDaEVDLGlCQUFpQjBILE9BQU9qSSxhQUFhTyxlQUFlO0FBQUEsUUFDcERFLGdCQUFnQndILE9BQU9qSSxhQUFhUyxjQUFjO0FBQUEsTUFDcEQ7QUFDQSxVQUFJRCxvQkFBb0IsTUFBTUEsb0JBQW9CLE1BQU07QUFDdER3SCxnQkFBUXhILGtCQUFrQnlILE9BQU96SCxlQUFlO0FBQUEsTUFDbEQ7QUFDQSxZQUFNL0MsSUFBSXlLLEtBQUssZ0NBQWdDRixPQUFPO0FBQ3REbkksMkJBQXFCLENBQUN3SCxTQUFTQSxPQUFPLENBQUM7QUFDdkM3SSxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNETSx1QkFBaUIsS0FBSztBQUN0QmdCLHNCQUFnQjtBQUFBLFFBQ2RDLFNBQVM7QUFBQSxRQUNUQyxXQUFXO0FBQUEsUUFDWEMsV0FBVztBQUFBLFFBQ1hDLGVBQWU7QUFBQSxRQUNmQyx1QkFBdUI7QUFBQSxRQUN2QkMsaUJBQWlCO0FBQUEsUUFDakJDLGlCQUFpQjtBQUFBLFFBQ2pCQyxnQkFBZ0I7QUFBQSxRQUNoQkMsb0JBQW9CO0FBQUEsUUFDcEJDLFdBQVc7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNILFNBQVN5RixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sc0JBQXNCQSxLQUFLO0FBQ3pDNUgscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUzBILE1BQU1ILFVBQVVFLE1BQU16SCxXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU11SSw0QkFBNEIsT0FBT2xCLFdBQVc7QUFDbEQsUUFBSTtBQUNGLFlBQU1DLFdBQVcsTUFBTXhJLElBQUl5SSxJQUFJLGdDQUFnQ0YsTUFBTSxFQUFFO0FBQ3ZFdkcscUJBQWV3RyxTQUFTRSxNQUFNQSxRQUFRRixTQUFTRSxJQUFJO0FBQ25EaEgsNkJBQXVCLElBQUk7QUFBQSxJQUM3QixTQUFTaUgsT0FBTztBQUNkQyxjQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUFBLElBQ3hEO0FBQUEsRUFDRjtBQTBCQSxRQUFNK0IsbUJBQW1CLFlBQVk7QUFDbkMsUUFBSTNJLGFBQWE7QUFDZixVQUFJO0FBQ0YsY0FBTS9CLElBQUkySyxPQUFPLGdDQUFnQzVJLFlBQVlvSCxHQUFHLEVBQUU7QUFDbEUvRyw2QkFBcUIsQ0FBQ3dILFNBQVNBLE9BQU8sQ0FBQztBQUN2QzdJLHVCQUFlO0FBQUEsVUFDYkUsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxVQUNORixZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQ0RVLCtCQUF1QixLQUFLO0FBQzVCTSx1QkFBZSxJQUFJO0FBQUEsTUFDckIsU0FBUzJHLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQzNDNUgsdUJBQWU7QUFBQSxVQUNiRSxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFVBQ05GLFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUE4Q0EsUUFBTTRKLGlCQUFpQkEsQ0FBQ0MsY0FBYztBQUNwQyxRQUFJLENBQUNBLFVBQVcsUUFBTztBQUN2QixVQUFNQyxPQUFPLElBQUlDLEtBQUtGLFNBQVM7QUFDL0IsVUFBTUcsTUFBTUMsT0FBT0gsS0FBS0ksUUFBUSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQ2xELFVBQU1DLFFBQVFILE9BQU9ILEtBQUtPLFNBQVMsSUFBSSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQ3pELFVBQU1HLE9BQU9SLEtBQUtTLFlBQVk7QUFDOUIsVUFBTUMsUUFBUVAsT0FBT0gsS0FBS1csU0FBUyxDQUFDLEVBQUVOLFNBQVMsR0FBRyxHQUFHO0FBQ3JELFVBQU1PLFVBQVVULE9BQU9ILEtBQUthLFdBQVcsQ0FBQyxFQUFFUixTQUFTLEdBQUcsR0FBRztBQUN6RCxXQUFPLEdBQUdILEdBQUcsSUFBSUksS0FBSyxJQUFJRSxJQUFJLElBQUlFLEtBQUssSUFBSUUsT0FBTztBQUFBLEVBQ3BEO0FBR0EsUUFBTUUscUJBQXFCQSxDQUFDZixjQUFjO0FBQ3hDLFFBQUksQ0FBQ0EsVUFBVyxRQUFPO0FBQ3ZCLFVBQU1DLE9BQU8sSUFBSUMsS0FBS0YsU0FBUztBQUMvQixVQUFNUyxPQUFPUixLQUFLUyxZQUFZO0FBQzlCLFVBQU1ILFFBQVFILE9BQU9ILEtBQUtPLFNBQVMsSUFBSSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQ3pELFVBQU1ILE1BQU1DLE9BQU9ILEtBQUtJLFFBQVEsQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUNsRCxVQUFNSyxRQUFRUCxPQUFPSCxLQUFLVyxTQUFTLENBQUMsRUFBRU4sU0FBUyxHQUFHLEdBQUc7QUFDckQsVUFBTU8sVUFBVVQsT0FBT0gsS0FBS2EsV0FBVyxDQUFDLEVBQUVSLFNBQVMsR0FBRyxHQUFHO0FBQ3pELFdBQU8sR0FBR0csSUFBSSxJQUFJRixLQUFLLElBQUlKLEdBQUcsSUFBSVEsS0FBSyxJQUFJRSxPQUFPO0FBQUEsRUFDcEQ7QUFHQSxRQUFNRyx5QkFBeUIsT0FBT0MsVUFBVTtBQUM5QyxRQUFJO0FBQ0YsWUFBTXRELFdBQVcsTUFBTXhJLElBQUl5SSxJQUFJLHVDQUF1Q3FELEtBQUssRUFBRTtBQUM3RSxZQUFNQyxVQUFVdkQsU0FBU0UsTUFBTUEsUUFBUUYsU0FBU0U7QUFDaER4RSx3QkFBa0I2SCxPQUFPO0FBQ3pCbEYsMEJBQW9CLElBQUk7QUFDeEI3QywwQkFBb0IsSUFBSTtBQUN4QixZQUFNZ0ksT0FBT0QsUUFBUWpFLHFCQUFxQixDQUFDO0FBQzNDLFVBQUltRSxVQUFVRCxLQUFLM0gsWUFBWTtBQUMvQixVQUFJNkgsVUFBVUYsS0FBSzFILFVBQVU2RSxPQUFPNkMsS0FBSzFILFlBQVk7QUFDckQsVUFBSUMsU0FBU3lILEtBQUt6SCxVQUFVO0FBQzVCLFVBQUk0SCxVQUFVSCxLQUFLeEgsVUFBVUEsWUFBWTtBQUN6QyxVQUFJNEgsU0FBU0osS0FBS3ZILFNBQVNBLFdBQVc7QUFFdENMLHFCQUFlLEVBQUVDLFVBQVU0SCxTQUFTM0gsVUFBVTRILFNBQVMzSCxRQUFRQyxVQUFVMkgsU0FBUzFILFNBQVMySCxPQUFPLENBQUM7QUFHbkcsVUFBSUgsWUFBWSxVQUFVQyxTQUFTO0FBQ2pDdkgsZ0NBQXdCLFFBQVF1SCxPQUFPLElBQUkzSCxNQUFNLEVBQUU7QUFBQSxNQUNyRCxXQUFXMEgsWUFBWSxXQUFXRSxTQUFTO0FBQ3pDeEgsZ0NBQXdCLFNBQVN3SCxPQUFPLEVBQUU7QUFBQSxNQUM1QyxXQUFXRixZQUFZLFVBQVVHLFFBQVE7QUFDdkN6SCxnQ0FBd0IsUUFBUXlILE1BQU0sRUFBRTtBQUFBLE1BQzFDLE9BQU87QUFDTHpILGdDQUF3QixJQUFJO0FBQUEsTUFDOUI7QUFHQSxZQUFNMEgsU0FBU0wsS0FBS2pFLFNBQVNvQixPQUFPNkMsS0FBS2pFLFdBQVc7QUFDcEQsVUFBSXNFLFFBQVE7QUFDVixZQUFJO0FBQ0YsZ0JBQU1DLGFBQWEsTUFBTXRNLElBQUl5SyxLQUFLLG1DQUFtQzRCLE1BQU0sRUFBRTtBQUM3RSxnQkFBTUUsb0JBQW9CRCxXQUFXNUQsUUFBUSxJQUFJOEQ7QUFBQUEsWUFDL0MsQ0FBQ0MsWUFBWUEsUUFBUUMsY0FBY0QsUUFBUUMsV0FBV0M7QUFBQUEsVUFDeEQ7QUFDQTlILHFDQUEyQjBILGdCQUFnQjtBQUFBLFFBQzdDLFFBQVE7QUFBRTFILHFDQUEyQixFQUFFO0FBQUEsUUFBRztBQUUxQyxZQUFJO0FBQ0YsZ0JBQU0rSCxZQUFZLE1BQU01TSxJQUFJeUksSUFBSSx3Q0FBd0M0RCxNQUFNLEVBQUU7QUFDaEZ0SCxnQ0FBc0I2SCxVQUFVbEUsUUFBUSxFQUFFO0FBQUEsUUFDNUMsUUFBUTtBQUFFM0QsZ0NBQXNCLEVBQUU7QUFBQSxRQUFHO0FBRXJDLFlBQUk7QUFDRixnQkFBTThILFdBQVcsTUFBTTdNLElBQUl5SSxJQUFJLDZCQUE2QjRELE1BQU0sRUFBRTtBQUNwRXBILDJCQUFpQjRILFNBQVNuRSxNQUFNQSxRQUFRLEVBQUU7QUFBQSxRQUM1QyxRQUFRO0FBQUV6RCwyQkFBaUIsRUFBRTtBQUFBLFFBQUc7QUFBQSxNQUNsQztBQUFBLElBRUYsU0FBUzBELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5Q0FBeUNBLEtBQUs7QUFDNUQ1SCxxQkFBZSxFQUFFQyxZQUFZLE1BQU1DLFNBQVMsd0NBQXdDQyxNQUFNLFFBQVEsQ0FBQztBQUFBLElBQ3JHLFVBQUM7QUFFQzJGLDBCQUFvQixLQUFLO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBRUEsUUFBTWlHLDhCQUE4QkEsQ0FBQ3pFLFVBQVU7QUFDN0MxRCw0QkFBd0IwRCxLQUFLO0FBQzdCLFFBQUksQ0FBQ0EsT0FBTztBQUNWakUscUJBQWUsQ0FBQXdGLFVBQVMsRUFBRSxHQUFHQSxNQUFNdEYsVUFBVSxJQUFJQyxRQUFRLElBQUlDLFVBQVUsSUFBSUMsU0FBUyxJQUFJSixVQUFVLE9BQU8sRUFBRTtBQUMzRztBQUFBLElBQ0Y7QUFDQSxVQUFNLENBQUNuRCxNQUFNa0ksSUFBSTdFLE1BQU0sSUFBSThELE1BQU0wRSxNQUFNLEdBQUc7QUFDMUMsUUFBSTdMLFNBQVMsUUFBUTtBQUNuQmtELHFCQUFlLEVBQUVDLFVBQVUsUUFBUUMsVUFBVThFLElBQUk3RSxRQUFRQyxVQUFVLElBQUlDLFNBQVMsR0FBRyxDQUFDO0FBQUEsSUFDdEYsV0FBV3ZELFNBQVMsU0FBUztBQUMzQmtELHFCQUFlLEVBQUVDLFVBQVUsU0FBU0MsVUFBVSxJQUFJQyxRQUFRLElBQUlDLFVBQVU0RSxJQUFJM0UsU0FBUyxHQUFHLENBQUM7QUFBQSxJQUMzRixXQUFXdkQsU0FBUyxRQUFRO0FBQzFCa0QscUJBQWUsRUFBRUMsVUFBVSxRQUFRQyxVQUFVLElBQUlDLFFBQVEsSUFBSUMsVUFBVSxJQUFJQyxTQUFTMkUsR0FBRyxDQUFDO0FBQUEsSUFDMUY7QUFBQSxFQUNGO0FBRUEsUUFBTTRELHNCQUFzQixPQUFPN0UsTUFBTTtBQUN2Q0EsTUFBRWtDLGVBQWU7QUFDakIsUUFBSSxDQUFDcEcsZUFBZ0I7QUFDckIsUUFBSTtBQUNGLFlBQU1zRyxVQUFVLEVBQUVsRyxVQUFVRixZQUFZRSxTQUFTO0FBQ2pELFVBQUlGLFlBQVlFLGFBQWEsUUFBUTtBQUNuQ2tHLGdCQUFRakcsV0FBV0gsWUFBWUc7QUFDL0JpRyxnQkFBUWhHLFNBQVNKLFlBQVlJO0FBQUFBLE1BQy9CLFdBQVdKLFlBQVlFLGFBQWEsU0FBUztBQUMzQ2tHLGdCQUFRL0YsV0FBV0wsWUFBWUs7QUFBQUEsTUFDakMsV0FBV0wsWUFBWUUsYUFBYSxRQUFRO0FBQzFDa0csZ0JBQVE5RixVQUFVTixZQUFZTTtBQUFBQSxNQUNoQztBQUNBLFlBQU16RSxJQUFJaU4sTUFBTSx1Q0FBdUNoSixlQUFla0YsR0FBRyxJQUFJb0IsT0FBTztBQUNwRmxGLDBCQUFvQixDQUFBdUUsU0FBUUEsT0FBTyxDQUFDO0FBQ3BDN0kscUJBQWUsRUFBRUMsWUFBWSxNQUFNQyxTQUFTLHFDQUFxQ0MsTUFBTSxVQUFVLENBQUM7QUFDbEc4QywwQkFBb0IsS0FBSztBQUN6QkUsd0JBQWtCLElBQUk7QUFBQSxJQUN4QixTQUFTeUUsT0FBTztBQUNkQyxjQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRDVILHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVMwSCxNQUFNSCxVQUFVRSxNQUFNekgsV0FBVztBQUFBLFFBQzFDQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFHQWpDLFlBQVUsTUFBTTtBQUNkLFVBQU1pTyxxQkFBcUIsWUFBWTtBQUNyQyxVQUFJO0FBQ0YzSCx3QkFBZ0IsSUFBSTtBQUNwQixjQUFNaUQsV0FBVyxNQUFNeEksSUFBSXlJLElBQUkscUNBQXFDO0FBQ3BFLFlBQUkwRSxXQUFXM0UsU0FBU0UsTUFBTUEsUUFBUUYsU0FBU0UsUUFBUTtBQUN2RHlFLGlCQUFTQyxLQUFLLENBQUNDLEdBQUdDLE1BQU0sSUFBSXZDLEtBQUt1QyxFQUFFL0YsOEJBQThCLElBQUksSUFBSXdELEtBQUtzQyxFQUFFOUYsOEJBQThCLENBQUM7QUFDL0cvRCx5QkFBaUIySixRQUFRO0FBQ3pCLGNBQU1wRSxnQkFBZ0JvRSxTQUFTbkUsSUFBSSxDQUFDdUUsS0FBS3JFLFVBQVU7QUFFakQsZ0JBQU1zRSxtQkFBbUJBLENBQUNDLFdBQVc7QUFDbkMsb0JBQVFBLFFBQVFDLFlBQVksR0FBQztBQUFBLGNBQzNCLEtBQUs7QUFDSCx1QkFBTyxFQUFFQyxNQUFNLHVCQUFDLHVCQUFvQixXQUFVLDhCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RCxHQUFLQyxPQUFPLGtCQUFrQkMsSUFBSSxnQkFBZ0JyRSxPQUFPLFNBQVM7QUFBQSxjQUM1SSxLQUFLO0FBQ0gsdUJBQU8sRUFBRW1FLE1BQU0sdUJBQUMsZ0JBQWEsTUFBSSxNQUFDLFdBQVUsNkJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNELEdBQUtDLE9BQU8saUJBQWlCQyxJQUFJLGVBQWVyRSxPQUFPLGNBQWM7QUFBQSxjQUM1SSxLQUFLO0FBQ0gsdUJBQU8sRUFBRW1FLE1BQU0sdUJBQUMsdUJBQW9CLFdBQVUsNEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVELEdBQUtDLE9BQU8sZ0JBQWdCQyxJQUFJLGNBQWNyRSxPQUFPLFlBQVk7QUFBQSxjQUN6STtBQUNFLHVCQUFPLEVBQUVtRSxNQUFNLHVCQUFDLHVCQUFvQixXQUFVLDZCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RCxHQUFLQyxPQUFPLGlCQUFpQkMsSUFBSSxlQUFlckUsT0FBT2lFLFVBQVUsVUFBVTtBQUFBLFlBQ3RKO0FBQUEsVUFDRjtBQUVBLGdCQUFNSyxnQkFBZ0JOLGlCQUFpQkQsSUFBSVEsbUJBQW1CO0FBRTlELGdCQUFNQyxrQkFBa0JULElBQUl6RixtQkFBbUJyRCxTQUFTQSxZQUNsRDhJLElBQUl6RixtQkFBbUJ4RCxXQUN2QixHQUFHaUosSUFBSXpGLGtCQUFrQnhELFNBQVMySixjQUFjLE9BQU8sY0FBY1YsSUFBSXpGLGtCQUFrQnZELFVBQVUsR0FBRyxLQUN4R2dKLElBQUl6RixtQkFBbUJ0RCxVQUFVQSxZQUFZO0FBRW5ELGlCQUFPO0FBQUEsWUFDTDJFLEtBQUtvRSxJQUFJcEU7QUFBQUEsWUFDVEMsSUFBSUYsUUFBUTtBQUFBLFlBQ1psQyxpQkFBaUJ1RyxJQUFJdkc7QUFBQUEsWUFDckJFLGVBQWVxRyxJQUFJdEcsa0JBQWtCQztBQUFBQSxZQUNyQ0MsZ0JBQWdCb0csSUFBSXRHLGtCQUFrQkU7QUFBQUEsWUFDdENDLGdCQUFnQm1HLElBQUl0RyxrQkFBa0JHO0FBQUFBLFlBQ3RDM0UsU0FBUzhLLElBQUlsRyxjQUFjNUU7QUFBQUEsWUFDM0J5TCxhQUFhdEQsZUFBZTJDLElBQUlqRyx3QkFBd0I7QUFBQSxZQUN4RDZHLG1CQUFtQnZELGVBQWUyQyxJQUFJaEcsOEJBQThCO0FBQUEsWUFDcEVFLHNCQUFzQjhGLElBQUkvRixtQkFBbUJDLHNCQUFzQjJHLEtBQUssSUFBSTtBQUFBLFlBQzVFekcsc0JBQXNCNEYsSUFBSTdGLHVCQUF1QkM7QUFBQUEsWUFDakQwRyxRQUFRZCxJQUFJN0YsdUJBQXVCRSw4QkFBOEIsUUFBUTtBQUFBLFlBQ3pFQyxpQkFBaUIwRixJQUFJN0YsdUJBQXVCRyxpQkFBaUJ1RyxLQUFLLElBQUk7QUFBQSxZQUN0RXJHLFNBQVN3RixJQUFJekYsbUJBQW1CQztBQUFBQSxZQUNoQzFELFVBQVVrSixJQUFJekYsbUJBQW1CekQ7QUFBQUEsWUFDakNDLFVBQVUwSjtBQUFBQSxZQUNWekosUUFBUWdKLElBQUl6RixtQkFBbUJ2RDtBQUFBQSxZQUMvQitKLFFBQVFmLElBQUlRO0FBQUFBLFlBQ1pOLFFBQ0UsdUJBQUMsU0FBSSxXQUFXLDZFQUE2RUssY0FBY0QsRUFBRSxJQUFJQyxjQUFjRixLQUFLLElBQ2pJRTtBQUFBQSw0QkFBY0g7QUFBQUEsY0FDZix1QkFBQyxVQUFNRyx3QkFBY3RFLFNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsaUJBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUVGSCxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU07QUFBQSxrQkFDSkMsT0FBTztBQUFBLG9CQUNMO0FBQUEsc0JBQ0VDLEtBQUs7QUFBQSxzQkFDTEMsT0FDRSx1QkFBQyxTQUFJLFNBQVMsTUFBTXFDLHVCQUF1QjBCLElBQUlwRSxHQUFHLEdBQUcsb0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFFSjtBQUFBLG9CQUNBO0FBQUEsc0JBQ0VJLEtBQUs7QUFBQSxzQkFDTEMsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUFNK0UseUJBQXlCaEIsSUFBSXBFLEdBQUc7QUFBQSwwQkFBRTtBQUFBO0FBQUEsd0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUVKO0FBQUEsa0JBQUM7QUFBQSxnQkFFTDtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFFVixpQ0FBQyxZQUFTLFdBQVUsOEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThDO0FBQUE7QUFBQSxjQTFCaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBMkJBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsVUFFSjtBQUFBLFFBQ0YsQ0FBQztBQUNEekYsOEJBQXNCcUYsYUFBYTtBQUFBLE1BQ3JDLFNBQVNKLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQ3BENUgsdUJBQWUsRUFBRUMsWUFBWSxNQUFNQyxTQUFTLGlDQUFpQ0MsTUFBTSxRQUFRLENBQUM7QUFBQSxNQUM5RixVQUFDO0FBQ0NxRSx3QkFBZ0IsS0FBSztBQUFBLE1BQ3ZCO0FBQUEsSUFDRjtBQUNBMkgsdUJBQW1CO0FBQUEsRUFDckIsR0FBRyxDQUFDOUgsZ0JBQWdCLENBQUM7QUFHckJuRyxZQUFVLE1BQU07QUFDZCxVQUFNNEosYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNTCxXQUFXLE1BQU14SSxJQUFJeUksSUFBSSw4QkFBOEI7QUFDN0QsY0FBTUssWUFBWU4sU0FBU0UsTUFBTUEsUUFBUUYsU0FBU0UsUUFBUTtBQUMxRGpDLDRCQUFvQnFDLFNBQVM7QUFBQSxNQUMvQixTQUFTSCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUNBRSxlQUFXO0FBQUEsRUFDYixHQUFHLENBQUMxRyxpQkFBaUIsQ0FBQztBQUd0QmxELFlBQVUsTUFBTTtBQUNkLFVBQU11UCxhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGLGNBQU1oRyxXQUFXLE1BQU14SSxJQUFJeUksSUFBSSxnQkFBZ0I7QUFDL0M5QixpQkFBUzZCLFNBQVNFLElBQUk7QUFBQSxNQUN4QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUNBNkYsZUFBVztBQUFBLEVBQ2IsR0FBRyxFQUFFO0FBR0x2UCxZQUFVLE1BQU07QUFDZCxVQUFNd1AsTUFBTSxvQkFBSTFELEtBQUs7QUFDckIsVUFBTTJELFdBQVcsSUFBSTNELEtBQUswRCxHQUFHO0FBQzdCQyxhQUFTQyxRQUFRRixJQUFJdkQsUUFBUSxJQUFJLENBQUM7QUFDbEN3RCxhQUFTRSxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDNUIsVUFBTXRELE9BQU9vRCxTQUFTbkQsWUFBWTtBQUNsQyxVQUFNSCxRQUFRSCxPQUFPeUQsU0FBU3JELFNBQVMsSUFBSSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQzdELFVBQU1ILE1BQU1DLE9BQU95RCxTQUFTeEQsUUFBUSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQ3RELFVBQU0wRCxjQUFjLEdBQUd2RCxJQUFJLElBQUlGLEtBQUssSUFBSUosR0FBRztBQUMzQzNFLDBCQUFzQndJLFdBQVc7QUFDakN0SSxxQkFBaUJzSSxXQUFXO0FBQUEsRUFDOUIsR0FBRyxFQUFFO0FBRUw1UCxZQUFVLE1BQU07QUFDZCxRQUFJNkgsWUFBWVMsZ0NBQWdDO0FBQzlDaEIsdUJBQWlCTyxZQUFZUyw4QkFBOEI7QUFDM0QsVUFBSVQsWUFBWVEsNEJBQTRCUixZQUFZUSw0QkFBNEJSLFlBQVlTLGdDQUFnQztBQUM5SFIsdUJBQWUsQ0FBQTZDLFVBQVMsRUFBRSxHQUFHQSxNQUFNdEMsMEJBQTBCLEdBQUcsRUFBRTtBQUNsRVcscUJBQWEsQ0FBQTJCLFVBQVMsRUFBRSxHQUFHQSxNQUFNdEMsMEJBQTBCLHFEQUFxRCxFQUFFO0FBQUEsTUFDcEg7QUFBQSxJQUNGLE9BQU87QUFDTCxZQUFNbUgsTUFBTSxvQkFBSTFELEtBQUs7QUFDckIsWUFBTTJELFdBQVcsSUFBSTNELEtBQUswRCxHQUFHO0FBQzdCQyxlQUFTQyxRQUFRRixJQUFJdkQsUUFBUSxJQUFJLENBQUM7QUFDbEMsWUFBTUksT0FBT29ELFNBQVNuRCxZQUFZO0FBQ2xDLFlBQU1ILFFBQVFILE9BQU95RCxTQUFTckQsU0FBUyxJQUFJLENBQUMsRUFBRUYsU0FBUyxHQUFHLEdBQUc7QUFDN0QsWUFBTUgsTUFBTUMsT0FBT3lELFNBQVN4RCxRQUFRLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDdEQ1RSx1QkFBaUIsR0FBRytFLElBQUksSUFBSUYsS0FBSyxJQUFJSixHQUFHLFFBQVE7QUFBQSxJQUNsRDtBQUFBLEVBQ0YsR0FBRyxDQUFDbEUsWUFBWVMsOEJBQThCLENBQUM7QUFHL0N0SSxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUN1RyxlQUFnQjtBQUNyQixVQUFNc0osaUJBQWlCLFlBQVk7QUFDakMsVUFBSTtBQUNGLGNBQU10RyxXQUFXLE1BQU14SSxJQUFJeUksSUFBSSw2QkFBNkJqRCxjQUFjLEVBQUU7QUFDNUVTLHFCQUFhdUMsU0FBU0UsS0FBS0EsSUFBSTtBQUFBLE1BQ2pDLFNBQVNxRyxLQUFLO0FBQ1o5SSxxQkFBYSxFQUFFO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBQ0EsVUFBTStJLGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0YsY0FBTXhHLFdBQVcsTUFBTXhJLElBQUl5SSxJQUFJLHdDQUF3Q2pELGNBQWMsRUFBRTtBQUN2Rk8sMEJBQWtCeUMsU0FBU0UsSUFBSTtBQUFBLE1BQ2pDLFNBQVNxRyxLQUFLO0FBQ1poSiwwQkFBa0IsRUFBRTtBQUFBLE1BQ3RCO0FBQUEsSUFDRjtBQUNBK0ksbUJBQWU7QUFDZkUsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDeEosY0FBYyxDQUFDO0FBRW5CLFFBQU15SiwyQkFBMkIsT0FBTzVDLFdBQVc7QUFDakQsUUFBSSxDQUFDQSxPQUFRO0FBQ2IsUUFBSTtBQUNGLFlBQU03RCxXQUFXLE1BQU14SSxJQUFJeUssS0FBSyxtQ0FBbUM0QixNQUFNLEVBQUU7QUFDM0UsVUFBSTdELFNBQVNFLFFBQVFGLFNBQVNFLEtBQUt5QixTQUFTLEdBQUc7QUFDN0MsY0FBTW9DLG1CQUFtQi9ELFNBQVNFLEtBQUs4RDtBQUFBQSxVQUNyQyxDQUFDQyxZQUFZQSxRQUFRQyxjQUFjRCxRQUFRQyxXQUFXQztBQUFBQSxRQUN4RDtBQUNBOUcsK0JBQXVCMEcsZ0JBQWdCO0FBQUEsTUFDekM7QUFBQSxJQUNGLFNBQVM1RCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REOUMsNkJBQXVCLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNcUosdUJBQXVCLE9BQU83QyxXQUFXO0FBQzdDNUcsc0JBQWtCNEcsTUFBTTtBQUN4QixVQUFNOEMsZUFBZXpJLE1BQU0wSSxLQUFLLENBQUFDLFNBQVFBLEtBQUtsRyxRQUFRa0QsTUFBTTtBQUMzRCxRQUFJOEMsY0FBYztBQUNoQnBJLHFCQUFlLENBQUE2QyxVQUFTO0FBQUEsUUFDdEIsR0FBR0E7QUFBQUEsUUFDSDNDLGtCQUFrQjtBQUFBLFVBQ2hCQyxlQUFlaUksYUFBYUcsYUFBYTtBQUFBLFVBQ3pDbkksZ0JBQWdCZ0ksYUFBYUksU0FBUztBQUFBLFVBQ3RDbkksZ0JBQWdCK0gsYUFBYUssZ0JBQWdCO0FBQUEsUUFDL0M7QUFBQSxRQUNBMUgsbUJBQW1CLEVBQUUsR0FBRzhCLEtBQUs5QixtQkFBbUJDLFNBQVNzRSxPQUFPO0FBQUEsTUFDbEUsRUFBRTtBQUFBLElBQ0osT0FBTztBQUNMdEYscUJBQWUsQ0FBQTZDLFVBQVM7QUFBQSxRQUN0QixHQUFHQTtBQUFBQSxRQUNIOUIsbUJBQW1CLEVBQUUsR0FBRzhCLEtBQUs5QixtQkFBbUJDLFNBQVNzRSxPQUFPO0FBQUEsTUFDbEUsRUFBRTtBQUFBLElBQ0o7QUFDQXBFLGlCQUFhLENBQUEyQixVQUFTLEVBQUUsR0FBR0EsTUFBTTZGLFVBQVUsR0FBRyxFQUFFO0FBQ2hEdEosZ0NBQTRCLElBQUk7QUFDaEMsVUFBTThJLHlCQUF5QjVDLE1BQU07QUFBQSxFQUN2QztBQUVBLFFBQU1xRCwwQkFBMEJBLENBQUNySCxVQUFVO0FBQ3pDbEMsZ0NBQTRCa0MsS0FBSztBQUNqQyxRQUFJLENBQUNBLE9BQU87QUFDVnRCLHFCQUFlLENBQUE2QyxVQUFTO0FBQUEsUUFDdEIsR0FBR0E7QUFBQUEsUUFDSDlCLG1CQUFtQixFQUFFLEdBQUc4QixLQUFLOUIsbUJBQW1CeEQsVUFBVSxJQUFJQyxRQUFRLElBQUlGLFVBQVUsT0FBTztBQUFBLE1BQzdGLEVBQUU7QUFDRjtBQUFBLElBQ0Y7QUFDQSxVQUFNLENBQUNuRCxNQUFNa0ksSUFBSTdFLE1BQU0sSUFBSThELE1BQU0wRSxNQUFNLEdBQUc7QUFDMUMsUUFBSTdMLFNBQVMsUUFBUTtBQUNuQjZGLHFCQUFlLENBQUE2QyxVQUFTO0FBQUEsUUFDdEIsR0FBR0E7QUFBQUEsUUFDSDlCLG1CQUFtQixFQUFFLEdBQUc4QixLQUFLOUIsbUJBQW1CeEQsVUFBVThFLElBQUk3RSxRQUFRRixVQUFVLE9BQU87QUFBQSxNQUN6RixFQUFFO0FBQUEsSUFDSixXQUFXbkQsU0FBUyxTQUFTO0FBQzNCNkYscUJBQWUsQ0FBQTZDLFVBQVM7QUFBQSxRQUN0QixHQUFHQTtBQUFBQSxRQUNIOUIsbUJBQW1CLEVBQUUsR0FBRzhCLEtBQUs5QixtQkFBbUJ0RCxVQUFVNEUsSUFBSS9FLFVBQVUsUUFBUTtBQUFBLE1BQ2xGLEVBQUU7QUFBQSxJQUNKLFdBQVduRCxTQUFTLFFBQVE7QUFDMUI2RixxQkFBZSxDQUFBNkMsVUFBUztBQUFBLFFBQ3RCLEdBQUdBO0FBQUFBLFFBQ0g5QixtQkFBbUIsRUFBRSxHQUFHOEIsS0FBSzlCLG1CQUFtQnJELFNBQVMyRSxJQUFJL0UsVUFBVSxPQUFPO0FBQUEsTUFDaEYsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBRUEsUUFBTXNMLHdCQUF3QkEsQ0FBQ0MsU0FBUzlGLE9BQU96QixVQUFVO0FBQ3ZEdEIsbUJBQWUsQ0FBQTZDLFVBQVM7QUFBQSxNQUN0QixHQUFHQTtBQUFBQSxNQUNILENBQUNnRyxPQUFPLEdBQUcsRUFBRSxHQUFHaEcsS0FBS2dHLE9BQU8sR0FBRyxDQUFDOUYsS0FBSyxHQUFHekIsTUFBTTtBQUFBLElBQ2hELEVBQUU7QUFDRkosaUJBQWEsQ0FBQTJCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUMsR0FBR2dHLE9BQU8sSUFBSTlGLEtBQUssRUFBRSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQ2pFO0FBRUEsUUFBTStGLGtCQUFrQkEsQ0FBQzFILE1BQU07QUFDN0IsVUFBTSxFQUFFd0IsTUFBTXRCLE1BQU0sSUFBSUYsRUFBRUM7QUFDMUJyQixtQkFBZSxDQUFBNkMsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsSUFBSSxHQUFHdEIsTUFBTSxFQUFFO0FBQ25ESixpQkFBYSxDQUFBMkIsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQ2hEO0FBRUEsUUFBTW1HLHlCQUF5QkEsQ0FBQ0Msa0JBQWtCO0FBQ2hELFFBQUksQ0FBQ0EsY0FBZSxRQUFPO0FBQzNCLFVBQU1qRixPQUFPLElBQUlDLEtBQUtnRixhQUFhO0FBQ25DLFVBQU1DLFdBQVcsQ0FBQ2xGLEtBQUttRixrQkFBa0I7QUFDekMsVUFBTUMsT0FBT0YsWUFBWSxJQUFJLE1BQU07QUFDbkMsVUFBTXhFLFFBQVFQLE9BQU9rRixLQUFLQyxNQUFNRCxLQUFLRSxJQUFJTCxRQUFRLElBQUksRUFBRSxDQUFDLEVBQUU3RSxTQUFTLEdBQUcsR0FBRztBQUN6RSxVQUFNTyxVQUFVVCxPQUFPa0YsS0FBS0UsSUFBSUwsUUFBUSxJQUFJLEVBQUUsRUFBRTdFLFNBQVMsR0FBRyxHQUFHO0FBQy9ELFdBQU9MLEtBQUt3RixZQUFZLEVBQUVDLFFBQVEsS0FBSyxHQUFHTCxJQUFJLEdBQUcxRSxLQUFLLElBQUlFLE9BQU8sRUFBRTtBQUFBLEVBQ3JFO0FBRUEsUUFBTThFLGtCQUFrQkEsTUFBTTtBQUM1QixVQUFNeEcsWUFBWSxDQUFDO0FBQ25CLFFBQUksQ0FBQ3hFLGVBQWdCd0UsV0FBVXlGLFdBQVc7QUFDMUMsUUFBSSxDQUFDdkoseUJBQTBCOEQsV0FBVTJDLFFBQVE7QUFDakQsUUFBSSxDQUFDN0YsWUFBWUUsZ0JBQWlCZ0QsV0FBVWhELGtCQUFrQjtBQUM5RCxRQUFJLENBQUNGLFlBQVlPLGFBQWE1RSxRQUFTdUgsV0FBVSxzQkFBc0IsSUFBSTtBQUMzRSxRQUFJLENBQUNsRCxZQUFZUSx5QkFBMEIwQyxXQUFVMUMsMkJBQTJCO0FBQ2hGLFFBQUksQ0FBQ1IsWUFBWVMsK0JBQWdDeUMsV0FBVXpDLGlDQUFpQztBQUM1RixRQUFJVCxZQUFZUSw0QkFBNEJSLFlBQVlTLGtDQUN0RFQsWUFBWVEsNEJBQTRCUixZQUFZUyxnQ0FBZ0M7QUFDcEZ5QyxnQkFBVTFDLDJCQUEyQjtBQUFBLElBQ3ZDO0FBQ0EsUUFBSSxDQUFDUixZQUFZWSxzQkFBc0JDLHdCQUF3QmIsWUFBWVksc0JBQXNCQyx3QkFBd0I7QUFDdkhxQyxnQkFBVSw0Q0FBNEMsSUFBSTtBQUM1RC9CLGlCQUFhK0IsU0FBUztBQUN0QixXQUFPQyxPQUFPQyxLQUFLRixTQUFTLEVBQUVHLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU1zRyxrQkFBa0IsT0FBT3RJLE1BQU07QUFDbkNBLE1BQUVrQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ21HLGdCQUFnQixFQUFHO0FBQ3hCLFFBQUk7QUFDRixVQUFJRSxtQkFBbUIsRUFBRTNJLFNBQVN2QyxnQkFBZ0JuQixVQUFVeUMsWUFBWWdCLGtCQUFrQnpELFNBQVM7QUFDbkcsVUFBSXFNLGlCQUFpQnJNLGFBQWEsUUFBUTtBQUN4Q3FNLHlCQUFpQnBNLFdBQVd3QyxZQUFZZ0Isa0JBQWtCeEQ7QUFDMURvTSx5QkFBaUJuTSxTQUFTdUMsWUFBWWdCLGtCQUFrQnZEO0FBQUFBLE1BQzFELFdBQVdtTSxpQkFBaUJyTSxhQUFhLFNBQVM7QUFDaERxTSx5QkFBaUJsTSxXQUFXc0MsWUFBWWdCLGtCQUFrQnREO0FBQUFBLE1BQzVELFdBQVdrTSxpQkFBaUJyTSxhQUFhLFFBQVE7QUFDL0NxTSx5QkFBaUJqTSxVQUFVcUMsWUFBWWdCLGtCQUFrQnJEO0FBQUFBLE1BQzNEO0FBQ0EsWUFBTThGLFVBQVU7QUFBQSxRQUNkdkQsaUJBQWlCRixZQUFZRTtBQUFBQSxRQUM3QkMsa0JBQWtCO0FBQUEsVUFDaEJDLGVBQWVKLFlBQVlHLGlCQUFpQkM7QUFBQUEsVUFDNUNDLGdCQUFnQkwsWUFBWUcsaUJBQWlCRSxrQkFBa0I7QUFBQSxVQUMvREMsZ0JBQWdCTixZQUFZRyxpQkFBaUJHO0FBQUFBLFFBQy9DO0FBQUEsUUFDQUMsY0FBYyxFQUFFNUUsU0FBU3FFLFlBQVlPLGFBQWE1RSxRQUFRO0FBQUEsUUFDMUQ2RSwwQkFBMEJ3SSx1QkFBdUJoSixZQUFZUSx3QkFBd0I7QUFBQSxRQUNyRkMsZ0NBQWdDdUksdUJBQXVCaEosWUFBWVMsOEJBQThCO0FBQUEsUUFDakdDLG1CQUFtQixFQUFFQyxzQkFBc0IsQ0FBQyxLQUFLLEVBQUU7QUFBQSxRQUNuREMsdUJBQXVCO0FBQUEsVUFDckJDLHNCQUFzQjZDLE9BQU8xRCxZQUFZWSxzQkFBc0JDLG9CQUFvQjtBQUFBLFVBQ25GQyw2QkFBNkJkLFlBQVlZLHNCQUFzQkU7QUFBQUEsVUFDL0RDLGlCQUFpQmYsWUFBWVksc0JBQXNCRztBQUFBQSxRQUNyRDtBQUFBLFFBQ0FDLG1CQUFtQjRJO0FBQUFBLE1BQ3JCO0FBQ0EsWUFBTTFRLElBQUl5SyxLQUFLLHVDQUF1Q0YsT0FBTztBQUM3RGxGLDBCQUFvQixDQUFBdUUsU0FBUUEsT0FBTyxDQUFDO0FBQ3BDN0kscUJBQWUsRUFBRUMsWUFBWSxNQUFNQyxTQUFTLG1DQUFtQ0MsTUFBTSxVQUFVLENBQUM7QUFDaEcwQyxzQkFBZ0IsS0FBSztBQUNyQm1ELHFCQUFlO0FBQUEsUUFDYkMsaUJBQWlCO0FBQUEsUUFDakJDLGtCQUFrQixFQUFFQyxlQUFlLElBQUlDLGdCQUFnQixJQUFJQyxnQkFBZ0IsR0FBRztBQUFBLFFBQzlFQyxjQUFjLEVBQUU1RSxTQUFTLEdBQUc7QUFBQSxRQUM1QjZFLDBCQUEwQjtBQUFBLFFBQzFCQyxnQ0FBZ0M7QUFBQSxRQUNoQ0MsbUJBQW1CLEVBQUVDLHNCQUFzQixHQUFHO0FBQUEsUUFDOUNDLHVCQUF1QixFQUFFQyxzQkFBc0IsSUFBSUMsNkJBQTZCLE1BQU1DLGlCQUFpQixDQUFDLEtBQUssRUFBRTtBQUFBLFFBQy9HQyxtQkFBbUIsRUFBRUMsU0FBUyxJQUFJMUQsVUFBVSxRQUFRQyxVQUFVLElBQUlDLFFBQVEsR0FBRztBQUFBLE1BQy9FLENBQUM7QUFDRGtCLHdCQUFrQixFQUFFO0FBQ3BCVSxrQ0FBNEIsSUFBSTtBQUFBLElBQ2xDLFNBQVN3QyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQ2pENUgscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUzBILE1BQU1ILFVBQVVFLE1BQU16SCxXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1xTiwyQkFBMkIsT0FBT3pDLFVBQVU7QUFDaEQsUUFBSTtBQUNGLFlBQU10RCxXQUFXLE1BQU14SSxJQUFJeUksSUFBSSx1Q0FBdUNxRCxLQUFLLEVBQUU7QUFDN0UzRyw2QkFBdUJxRCxTQUFTRSxNQUFNQSxRQUFRRixTQUFTRSxJQUFJO0FBQzNENUUsNEJBQXNCLElBQUk7QUFBQSxJQUM1QixTQUFTNkUsT0FBTztBQUNkQyxjQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUVBLFFBQU1nSSxrQkFBa0IsWUFBWTtBQUNsQyxRQUFJekwscUJBQXFCO0FBQ3ZCLFVBQUk7QUFDRixjQUFNbEYsSUFBSTJLLE9BQU8sdUNBQXVDekYsb0JBQW9CaUUsR0FBRyxFQUFFO0FBQ2pGOUQsNEJBQW9CLENBQUF1RSxTQUFRQSxPQUFPLENBQUM7QUFDcEM3SSx1QkFBZSxFQUFFRSxTQUFTLHFDQUFxQ0MsTUFBTSxXQUFXRixZQUFZLEtBQUssQ0FBQztBQUNsRzhDLDhCQUFzQixLQUFLO0FBQzNCcUIsK0JBQXVCLElBQUk7QUFBQSxNQUM3QixTQUFTd0QsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkQ1SCx1QkFBZSxFQUFFRSxTQUFTLGlDQUFpQ0MsTUFBTSxTQUFTRixZQUFZLEtBQUssQ0FBQztBQUFBLE1BQzlGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFHQSxRQUFNNFAsY0FBYztBQUFBLElBQ2xCLEVBQUVySCxLQUFLLE1BQU1zSCxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFdEgsS0FBSyxXQUFXc0gsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRXRILEtBQUssYUFBYXNILFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUV0SCxLQUFLLGFBQWFzSCxRQUFRLE9BQU87QUFBQSxJQUNuQyxFQUFFdEgsS0FBSyxpQkFBaUJzSCxRQUFRLFdBQVc7QUFBQSxJQUMzQyxFQUFFdEgsS0FBSyx5QkFBeUJzSCxRQUFRLG1CQUFtQjtBQUFBLElBQzNELEVBQUV0SCxLQUFLLG1CQUFtQnNILFFBQVEsYUFBYTtBQUFBLElBQy9DLEVBQUV0SCxLQUFLLG1CQUFtQnNILFFBQVEsYUFBYTtBQUFBLElBQy9DLEVBQUV0SCxLQUFLLGtCQUFrQnNILFFBQVEsWUFBWTtBQUFBLElBQzdDLEVBQUV0SCxLQUFLLHNCQUFzQnNILFFBQVEsZ0JBQWdCO0FBQUEsSUFDckQsRUFBRXRILEtBQUssYUFBYXNILFFBQVEsT0FBTztBQUFBLElBQ25DLEVBQUV0SCxLQUFLLFVBQVVzSCxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBSXJDLFFBQU1DLGFBQWE7QUFBQSxJQUNqQixFQUFFdkgsS0FBSyxNQUFNc0gsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRXRILEtBQUssbUJBQW1Cc0gsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFdEgsS0FBSyxVQUFVc0gsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRXRILEtBQUssaUJBQWlCc0gsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFdEgsS0FBSyxrQkFBa0JzSCxRQUFRLFFBQVE7QUFBQSxJQUN6QyxFQUFFdEgsS0FBSyxrQkFBa0JzSCxRQUFRLFFBQVE7QUFBQSxJQUN6QyxFQUFFdEgsS0FBSyxXQUFXc0gsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRXRILEtBQUssWUFBWXNILFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUV0SCxLQUFLLFlBQVlzSCxRQUFRLGdCQUFnQjtBQUFBLElBQzNDLEVBQUV0SCxLQUFLLHFCQUFxQnNILFFBQVEscUJBQXFCRSxPQUFPLElBQUk7QUFBQSxJQUNwRSxFQUFFeEgsS0FBSyxlQUFlc0gsUUFBUSxlQUFlRSxPQUFPLElBQUk7QUFBQSxJQUN4RCxFQUFFeEgsS0FBSyx3QkFBd0JzSCxRQUFRLGNBQWM7QUFBQSxJQUNyRCxFQUFFdEgsS0FBSyxVQUFVc0gsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNRyxlQUFlO0FBQUEsSUFDbkIsRUFBRXpILEtBQUssTUFBTXNILFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUV0SCxLQUFLLG1CQUFtQnNILFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRXRILEtBQUssVUFBVXNILFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUV0SCxLQUFLLGlCQUFpQnNILFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRXRILEtBQUssa0JBQWtCc0gsUUFBUSxRQUFRO0FBQUEsSUFDekMsRUFBRXRILEtBQUssa0JBQWtCc0gsUUFBUSxRQUFRO0FBQUEsSUFDekMsRUFBRXRILEtBQUssV0FBV3NILFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUV0SCxLQUFLLFlBQVlzSCxRQUFRLFdBQVc7QUFBQSxJQUN0QyxFQUFFdEgsS0FBSyxZQUFZc0gsUUFBUSxnQkFBZ0I7QUFBQSxJQUMzQyxFQUFFdEgsS0FBSyxxQkFBcUJzSCxRQUFRLHFCQUFxQkUsT0FBTyxJQUFJO0FBQUEsSUFDcEUsRUFBRXhILEtBQUssZUFBZXNILFFBQVEsZUFBZUUsT0FBTyxJQUFJO0FBQUEsSUFDeEQsRUFBRXhILEtBQUssd0JBQXdCc0gsUUFBUSxjQUFjO0FBQUEsSUFDckQsRUFBRXRILEtBQUssVUFBVXNILFFBQVEsU0FBUztBQUFBLEVBQUM7QUFJckMsU0FDRSxtQ0FDRSxpQ0FBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSwyQkFBQyxVQUFPLFlBQVksTUFBTSwrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRjtBQUFBLElBQ25GO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNL1AsWUFBWUk7QUFBQUEsUUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsUUFDckIsU0FBUyxNQUFNRixlQUFlLENBQUE2SSxVQUFTLEVBQUUsR0FBR0EsTUFBTTVJLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUp4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJMEU7QUFBQSxJQUUxRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsd0NBQ2IsaUNBQUMsUUFBSyxXQUFXTixXQUFXLFVBQVVDLGNBQWMsV0FBVSxRQUM1RDtBQUFBLCtCQUFDLFdBQVEsS0FBSSxTQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDBCQUF5QixrQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQ7QUFBQSxZQUN6RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiYSxtQ0FBaUIsSUFBSTtBQUNyQjRCLGdDQUFjLENBQUMsQ0FBQztBQUFBLGdCQUNsQjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFBaUY7QUFBQTtBQUFBLGNBTDdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFDQy9CLFdBQVc4SSxTQUFTLEtBQUssQ0FBQzlILGdCQUN6QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsZUFBZWlHO0FBQUFBLGNBQ2YsTUFBTWxJLGFBQWFpQixZQUFZVCxVQUFVO0FBQUEsY0FDekMsU0FBU2dRO0FBQUFBLGNBQ1QsaUJBQWdCO0FBQUEsY0FDaEIsa0JBQWlCO0FBQUE7QUFBQSxZQU5uQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNMEMsSUFHMUMsdUJBQUMsa0JBQWUsV0FBV3ZPLGVBQWUsTUFBSyxTQUFRLFNBQVNoQixXQUFXOEksVUFBVSxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RjtBQUFBLGFBdkJsRSxTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBO0FBQUEsUUFFQSx1QkFBQyxXQUFRLEtBQUksaUJBQ1g7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLDZCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRDtBQUFBLFlBQ3BEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBQ2J2RyxrQ0FBZ0IsSUFBSTtBQUNwQnFFLCtCQUFhLENBQUMsQ0FBQztBQUFBLGdCQUNqQjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFBaUY7QUFBQTtBQUFBLGNBTDdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFDQ3hFLG1CQUFtQjBHLFNBQVMsS0FBSyxDQUFDN0UsZUFDakM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVE7QUFBQSxjQUNSLE1BQU1sRixhQUFhcUQsb0JBQW9CN0MsVUFBVTtBQUFBLGNBQ2pELFNBQVNrUTtBQUFBQSxjQUNULGVBQWVqRjtBQUFBQSxjQUNmLGlCQUFnQjtBQUFBLGNBQ2hCLGtCQUFpQjtBQUFBLGNBQ2pCLFlBQVltRjtBQUFBQTtBQUFBQSxZQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU8yQixJQUczQix1QkFBQyxrQkFBZSxXQUFXMUwsY0FBYyxNQUFLLGlCQUFnQixTQUFTN0IsbUJBQW1CMEcsVUFBVSxLQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRztBQUFBLGFBeEJ6RSxpQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFdBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1REEsS0F4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlEQTtBQUFBLFNBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0REE7QUFBQSxJQUtBLHVCQUFDLFNBQU0sV0FBV3hJLG1CQUFtQixTQUFTLE1BQU07QUFBRUMsMkJBQXFCLEtBQUs7QUFBR0Usa0JBQVksSUFBSTtBQUFBLElBQUcsR0FDcEcsaUNBQUMsU0FBSSxXQUFVLHlFQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdEQUNiLGlDQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0NBQW1DLHlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qix3Q0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFdBRnBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0NELFlBQ0MsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQsdUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsVUFFekUsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT0EsU0FBU1ksV0FBVyxJQUFJLFVBQVEsTUFBQyxXQUFVLDBIQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyTDtBQUFBLGFBSDdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQseUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT1osU0FBU2EsYUFBYSxJQUFJLFVBQVEsTUFBQyxXQUFVLDBIQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2TDtBQUFBLGFBRi9MO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQseUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT2IsU0FBU2MsYUFBYSxJQUFJLFVBQVEsTUFBQyxXQUFVLDBIQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2TDtBQUFBLGFBRi9MO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQsd0JBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBFO0FBQUEsVUFDMUUsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT2QsU0FBU2UsaUJBQWlCLElBQUksVUFBUSxNQUFDLFdBQVUsMEhBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlNO0FBQUEsYUFGbk07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRCxvQ0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxVQUN0Rix1QkFBQyxXQUFNLE1BQUssUUFBTyxPQUFPZixTQUFTZ0IseUJBQXlCLElBQUksVUFBUSxNQUFDLFdBQVUsMEhBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlNO0FBQUEsYUFGM007QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRCw4QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRix1QkFBQyxXQUFNLE1BQUssUUFBTyxPQUFPaEIsU0FBU2lCLG1CQUFtQixJQUFJLFVBQVEsTUFBQyxXQUFVLDBIQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtTTtBQUFBLGFBRnJNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQsMEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT2pCLFNBQVNrQixtQkFBbUIsSUFBSSxVQUFRLE1BQUMsV0FBVSwwSEFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbU07QUFBQSxhQUZyTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0RBQWlELHlCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRTtBQUFBLFVBQzNFLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE9BQU9sQixTQUFTbUIsa0JBQWtCLElBQUksVUFBUSxNQUFDLFdBQVUsMEhBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtNO0FBQUEsYUFGcE07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRCw2QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxVQUMvRSx1QkFBQyxXQUFNLE1BQUssUUFBTyxPQUFPbkIsU0FBU29CLHNCQUFzQixJQUFJLFVBQVEsTUFBQyxXQUFVLDBIQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzTTtBQUFBLGFBRnhNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQsNkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0UsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT3BCLFNBQVNxQixhQUFhLElBQUksVUFBUSxNQUFDLFdBQVUsMEhBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZMO0FBQUEsYUFGL0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRCwwQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxVQUM1RSx1QkFBQyxXQUFNLE1BQUssUUFBTyxPQUFPckIsU0FBU29QLFlBQVlyRyxlQUFlL0ksU0FBU29QLFNBQVMsSUFBSSxJQUFJLFVBQVEsTUFBQyxXQUFVLDBIQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpTztBQUFBLGFBRm5PO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQsMEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT3BQLFNBQVNxUCxZQUFZdEcsZUFBZS9JLFNBQVNxUCxTQUFTLElBQUksSUFBSSxVQUFRLE1BQUMsV0FBVSwwSEFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaU87QUFBQSxhQUZuTztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0RBO0FBQUEsTUFFRix1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTTtBQUFFdFAsaUNBQXFCLEtBQUs7QUFBR0Usd0JBQVksSUFBSTtBQUFBLFVBQUc7QUFBQSxVQUNqRSxXQUFVO0FBQUEsVUFBa0c7QUFBQTtBQUFBLFFBSDlHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0FwRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFFQSxLQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUVBO0FBQUEsSUFHQSx1QkFBQyxTQUFNLFdBQVdQLGVBQWUsU0FBUyxNQUFNQyxpQkFBaUIsS0FBSyxHQUNwRSxpQ0FBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0RBQ2IsaUNBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsd0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxRQUN6RSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLG1EQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZFO0FBQUEsV0FGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFVBQVU0SSxrQkFBa0IsWUFBVSxNQUMxQztBQUFBLCtCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxjQUN4RCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPN0gsYUFBYUU7QUFBQUEsa0JBQ3BCLFVBQVVpSDtBQUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osV0FBVTtBQUFBO0FBQUEsZ0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTTZKO0FBQUEsY0FFN0o7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFDUGxILGdCQUFnQixDQUFDb0gsVUFBVTtBQUFBLG9CQUN6QixHQUFHQTtBQUFBQSxvQkFDSG5ILFNBQVMsVUFBVTBPLFdBQVdDLE9BQU9DLFdBQVcsRUFBRWQsUUFBUSxNQUFNLEVBQUUsRUFBRWUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLGtCQUNsRixFQUFFO0FBQUEsa0JBRUosV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9CO0FBQUEsb0JBQUc7QUFBQTtBQUFBO0FBQUEsZ0JBVnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFDQ25PLFdBQVdWLFdBQVcsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QlUscUJBQVdWLFdBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsZUEzQnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsY0FBVSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1IO0FBQUEsWUFDbkgsdUJBQUMsV0FBTSxNQUFLLFFBQU8sTUFBSyxhQUFZLE9BQU9GLGFBQWFHLFdBQVcsVUFBVWdILGtCQUFrQixhQUFZLHFCQUFvQixXQUFVLCtJQUF6STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvUjtBQUFBLFlBQ25SdkcsV0FBV1QsYUFBYSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCUyxxQkFBV1QsYUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxlQUgxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJFQUEwRTtBQUFBO0FBQUEsY0FBcUIsdUJBQUMsV0FBUSxPQUFNLGdFQUErRCxpQ0FBQyxzQkFBbUIsV0FBVSxrQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEQsS0FBMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkk7QUFBQSxpQkFBN1A7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdVE7QUFBQSxZQUN2USx1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLHlCQUF3QixPQUFPSCxhQUFhTSx1QkFBdUIsVUFBVTZHLGtCQUFrQixhQUFZLE9BQU0sV0FBVSwrSUFBcko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ1M7QUFBQSxZQUMvUnZHLFdBQVdOLHlCQUF5Qix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCTSxxQkFBV04seUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsZUFIbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwyRUFBMEU7QUFBQTtBQUFBLGNBQWUsdUJBQUMsV0FBUSxPQUFNLDhEQUE2RCxpQ0FBQyxzQkFBbUIsV0FBVSxrQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEQsS0FBeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkk7QUFBQSxpQkFBclA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1A7QUFBQSxZQUMvUCx1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLG1CQUFrQixPQUFPTixhQUFhTyxpQkFBaUIsVUFBVTRHLGtCQUFrQixhQUFZLFNBQVEsV0FBVSwrSUFBM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc1I7QUFBQSxZQUNyUnZHLFdBQVdMLG1CQUFtQix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCSyxxQkFBV0wsbUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsZUFIdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwyRUFBMEU7QUFBQTtBQUFBLGNBQXNCLHVCQUFDLFdBQVEsT0FBTSx3REFBdUQsaUNBQUMsc0JBQW1CLFdBQVUsa0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRELEtBQWxJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFJO0FBQUEsaUJBQXRQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdRO0FBQUEsWUFDaFEsdUJBQUMsV0FBTSxNQUFLLFVBQVMsTUFBSyxtQkFBa0IsT0FBT1AsYUFBYVEsaUJBQWlCLFVBQVUyRyxrQkFBa0IsYUFBWSxNQUFLLFdBQVUsK0lBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1SO0FBQUEsZUFGclI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwyRUFBMEU7QUFBQTtBQUFBLGNBQVUsdUJBQUMsV0FBUSxPQUFNLHlEQUF3RCxpQ0FBQyxzQkFBbUIsV0FBVSxrQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEQsS0FBbkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0k7QUFBQSxpQkFBM087QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcVA7QUFBQSxZQUNyUCx1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLGtCQUFpQixPQUFPbkgsYUFBYVMsZ0JBQWdCLFVBQVUwRyxrQkFBa0IsYUFBWSxLQUFJLFdBQVUsK0lBQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdSO0FBQUEsWUFDL1F2RyxXQUFXSCxrQkFBa0IsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkcscUJBQVdILGtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLGVBSHBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlELDZCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRTtBQUFBLFlBQy9FLHVCQUFDLFVBQU8sV0FBVSxVQUFTLE9BQU9ULGFBQWFVLG9CQUFvQixVQUFVLENBQUNvRixVQUFVd0IscUJBQXFCLHNCQUFzQnhCLEtBQUssR0FBRyxNQUFLLFNBQzlJO0FBQUEscUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxPQUFNLHFCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGNBQ2hDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFBTyxzQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUNsQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFNBQVEsdUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUEsY0FDcEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxRQUFPLHNCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBLGlCQUpwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCw2QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0U7QUFBQSxZQUMvRSx1QkFBQyxVQUFPLFdBQVUsVUFBUyxPQUFPOUYsYUFBYVcsV0FBVyxVQUFVLENBQUNtRixVQUFVd0IscUJBQXFCLGFBQWF4QixLQUFLLEdBQUcsTUFBSyxTQUMzSCxXQUFDLFFBQVEsUUFBUSxPQUFPLEVBQUVXLElBQUksQ0FBQXVJLFNBQVEsdUJBQUMsT0FBTyxRQUFQLEVBQXlCLE9BQU9BLE1BQU9BLGtCQUFwQkEsTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkMsQ0FBZ0IsS0FEdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxRUE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sTUFBSyxVQUFTLE1BQUssYUFBWSxPQUFNLGNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxRQUN0RCx1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLGlCQUFnQixPQUFNLFNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUNyRCx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU0vUCxpQkFBaUIsS0FBSyxHQUFHLFdBQVUsNEZBQTJGLHNCQUFuSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5SztBQUFBLFVBQ3pLLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsb0dBQW1HLHlCQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0STtBQUFBLGFBRjlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2RUE7QUFBQSxTQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUZBLEtBdEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1RkE7QUFBQSxJQUdBLHVCQUFDLFNBQU0sV0FBV0MscUJBQXFCLFNBQVMsTUFBTTtBQUFFQyw2QkFBdUIsS0FBSztBQUFHTSxxQkFBZSxJQUFJO0FBQUEsSUFBRyxHQUMzRyxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLDJCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdFO0FBQUEsTUFDL0RELGVBQ0MsdUJBQUMsVUFBSyxVQUFVLENBQUNvRyxNQUFNO0FBQUVBLFVBQUVrQyxlQUFlO0FBQUdLLHlCQUFpQjtBQUFBLE1BQUcsR0FBRyxXQUFVLGFBQzVFO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLFlBQWEsdUJBQUMsVUFBSyxXQUFVLDBCQUEwQjNJLHNCQUFZVyxhQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLFlBQU87QUFBQSxZQUFzQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsZUFBMU07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaU47QUFBQSxVQUNqTix1QkFBQyxXQUFNLE1BQUssUUFBTyxJQUFHLG1CQUFrQixhQUFZLHVCQUFzQixVQUFRLE1BQUMsV0FBVSwrSEFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd047QUFBQSxhQUYxTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsd0dBQXVHLHNCQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZJO0FBQUEsV0FML0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQW1DQSx1QkFBQyxTQUFNLFdBQVdpQixjQUFjLFNBQVMsTUFBTUMsZ0JBQWdCLEtBQUssR0FDbEUsaUNBQUMsU0FBSSxXQUFVLCtGQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdGQUNiLGlDQUFDLFNBQUksV0FBVSxvQ0FDYixpQ0FBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG9EQUFtRCxtQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGLHVCQUFDLE9BQUUsV0FBVSwyQ0FBMEMsc0RBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxXQUYvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxxREFDYixpQ0FBQyxVQUFLLFVBQVU2TSxpQkFBaUIsWUFBVSxNQUN6QztBQUFBLCtCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUE2QztBQUFBO0FBQUEsY0FBUyx1QkFBQyxVQUFLLFdBQVUscUJBQW9CLGlCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGlCQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSDtBQUFBLFlBQ25IO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUNWLGNBQWMsQ0FBQ2UsT0FBT0MsV0FBV0EsT0FBT0MsU0FBU0MsU0FBUyxFQUFFQyxZQUFZLEVBQUVDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGdCQUN0RyxPQUFPcE0sa0JBQWtCc007QUFBQUEsZ0JBQ3pCLFVBQVU1QztBQUFBQSxnQkFFVHhJLGdCQUFNc0M7QUFBQUEsa0JBQUksQ0FBQXFHLFNBQ1QsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLEtBQUtsRyxLQUN2Q2tHO0FBQUFBLHlCQUFLQztBQUFBQSxvQkFBVTtBQUFBLG9CQUFJRCxLQUFLRztBQUFBQSxvQkFBYTtBQUFBLG9CQUFFSCxLQUFLRSxTQUFTLEtBQUtGLEtBQUtFLEtBQUs7QUFBQSx1QkFEbkRGLEtBQUtsRyxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUE7QUFBQSxZQUNDbkIsVUFBVXlILFlBQVksdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnpILG9CQUFVeUgsWUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxlQWhCdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUE2QztBQUFBO0FBQUEsY0FBZSx1QkFBQyxVQUFLLFdBQVUscUJBQW9CLGlCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGlCQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5SDtBQUFBLFlBQ3pIO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsYUFBWTtBQUFBLGdCQUNaLFVBQVVDO0FBQUFBLGdCQUNWLE9BQU94SjtBQUFBQSxnQkFDUCxXQUFVO0FBQUEsZ0JBQ1YsWUFBVTtBQUFBLGdCQUVUTjtBQUFBQSxzQ0FBb0JvRCxJQUFJLENBQUMrSSxPQUFPQyxRQUFRO0FBQ3ZDLDBCQUFNQyxZQUFZRixPQUFPckYsWUFBWUMsT0FBT3NCLGNBQWM7QUFDMUQsMEJBQU0vQixVQUFVNkYsT0FBT3JGLFlBQVlDLE9BQU94RCxPQUFPLFdBQVc2SSxHQUFHO0FBQy9ELDBCQUFNek4sU0FBU3dOLE9BQU9yRixZQUFZd0YsV0FBVztBQUM3QywyQkFBTyx1QkFBQyxPQUFPLFFBQVAsRUFBZ0QsT0FBTyxRQUFRaEcsT0FBTyxJQUFJM0gsTUFBTSxJQUN0RixpQ0FBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUEsNkNBQUMsVUFBSyxXQUFVLGVBQWUwTix1QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUM7QUFBQSxzQkFBTyx1QkFBQyxVQUFLLFdBQVUsV0FBVTtBQUFBO0FBQUEsd0JBQVMxTjtBQUFBQSx3QkFBTztBQUFBLDJCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRDtBQUFBLHlCQUFoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1SSxLQUQ5RyxRQUFRMkgsT0FBTyxJQUFJM0gsTUFBTSxJQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVQO0FBQUEsa0JBQ0YsQ0FBQztBQUFBLGtCQUNBdUIsZUFBZWtEO0FBQUFBLG9CQUFJLENBQUFtSixVQUNsQix1QkFBQyxPQUFPLFFBQVAsRUFBeUMsT0FBTyxTQUFTQSxNQUFNaEosR0FBRyxJQUFJZ0osTUFBTTNOLFlBQVkyTixNQUFNaEosR0FBRyxJQUNoRyxpQ0FBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUEsNkNBQUMsVUFBSyxXQUFVLGVBQWVnSixnQkFBTTNOLFlBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQThDO0FBQUEsc0JBQU8sdUJBQUMsVUFBSyxXQUFVLFdBQVU7QUFBQTtBQUFBLHdCQUFHMk4sTUFBTUM7QUFBQUEsd0JBQWU7QUFBQSwyQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMEQ7QUFBQSx5QkFBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUosS0FEbkksU0FBU0QsTUFBTWhKLEdBQUcsSUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUEsa0JBQ0FuRCxVQUFVZ0Q7QUFBQUEsb0JBQUksQ0FBQXFKLGFBQ2IsdUJBQUMsT0FBTyxRQUFQLEVBQTJDLE9BQU8sUUFBUUEsU0FBU2xKLEdBQUcsSUFBSWtKLFNBQVM1TixXQUFXNE4sU0FBU2xKLEdBQUcsSUFDekcsaUNBQUMsU0FBSSxXQUFVLGlCQUFnQjtBQUFBLDZDQUFDLFVBQUssV0FBVSxlQUFla0osbUJBQVM1TixXQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnRDtBQUFBLHNCQUFPLHVCQUFDLFVBQUssV0FBVSxXQUFVO0FBQUE7QUFBQSx3QkFBRzROLFNBQVNDO0FBQUFBLHdCQUFZO0FBQUEsMkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlEO0FBQUEseUJBQS9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNKLEtBRHBJLFFBQVFELFNBQVNsSixHQUFHLElBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF5QkE7QUFBQSxZQUNDbkIsVUFBVTJFLFNBQVMsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjNFLG9CQUFVMkUsU0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxlQTVCaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUE2QztBQUFBO0FBQUEsY0FDNUMsdUJBQUMsVUFBSyxXQUFVLHFCQUFvQixpQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxpQkFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU83RixZQUFZRTtBQUFBQSxrQkFDbkIsVUFBVTZJO0FBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNdUU7QUFBQSxjQUV2RTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUNQOUksZUFBZSxDQUFDNkMsVUFBVTtBQUFBLG9CQUN4QixHQUFHQTtBQUFBQSxvQkFDSDVDLGlCQUFpQixPQUFPbUssV0FBV0MsT0FBT0MsV0FBVyxFQUFFZCxRQUFRLE1BQU0sRUFBRSxFQUFFZSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsa0JBQ3ZGLEVBQUU7QUFBQSxrQkFFSixXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0I7QUFBQSxvQkFBRztBQUFBO0FBQUE7QUFBQSxnQkFWekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUE7QUFBQSxpQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzQkE7QUFBQSxZQUNDdEosVUFBVWhCLG1CQUFtQix1QkFBQyxPQUFFLFdBQVUsd0JBQXdCZ0Isb0JBQVVoQixtQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxlQTNCL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUE2QztBQUFBO0FBQUEsY0FBSyx1QkFBQyxVQUFLLFdBQVUscUJBQW9CLGlCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGlCQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRztBQUFBLFlBQy9HLHVCQUFDLFVBQU8sV0FBVSwwQkFBeUIsYUFBWSxpQkFBZ0IsT0FBT0YsWUFBWU8sYUFBYTVFLFdBQVdxUCxRQUFXLFVBQVUsQ0FBQ3pKLFVBQVVzSCxzQkFBc0IsZ0JBQWdCLFdBQVd0SCxLQUFLLEdBQ3JNN0IsMkJBQWlCd0MsSUFBSSxDQUFBQyxTQUFRLHVCQUFDLE9BQU8sUUFBUCxFQUFpQyxPQUFPQSxLQUFLeEcsU0FBVXdHO0FBQUFBLG1CQUFLdkc7QUFBQUEsY0FBVTtBQUFBLGNBQUd1RyxLQUFLeEc7QUFBQUEsY0FBUTtBQUFBLGlCQUFuRXdHLEtBQUt4RyxTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RixDQUFnQixLQUR4STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQ3VGLFVBQVUsc0JBQXNCLEtBQUssdUJBQUMsT0FBRSxXQUFVLHdCQUF3QkEsb0JBQVUsc0JBQXNCLEtBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsZUFML0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsOENBQTZDO0FBQUE7QUFBQSxjQUFrQix1QkFBQyxVQUFLLFdBQVUscUJBQW9CLGlCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGlCQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0SDtBQUFBLFlBQzVILHVCQUFDLFdBQU0sTUFBSyxrQkFBaUIsS0FBSzVCLG9CQUFvQixPQUFPVSxZQUFZUyxnQ0FBZ0MsVUFBVSxDQUFDWSxNQUFNcEIsZUFBZSxFQUFFLEdBQUdELGFBQWFTLGdDQUFnQ1ksRUFBRUMsT0FBT0MsTUFBTSxDQUFDLEdBQUcsV0FBVSx5REFBeE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNlE7QUFBQSxZQUM1UUwsVUFBVVQsa0NBQWtDLHVCQUFDLE9BQUUsV0FBVSx3QkFBd0JTLG9CQUFVVCxrQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxlQUg3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw4Q0FBNkM7QUFBQTtBQUFBLGNBQVksdUJBQUMsVUFBSyxXQUFVLHFCQUFvQixpQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxpQkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0g7QUFBQSxZQUN0SCx1QkFBQyxXQUFNLE1BQUssa0JBQWlCLEtBQUtqQixlQUFlLE9BQU9RLFlBQVlRLDBCQUEwQixVQUFVLENBQUNhLE1BQU1wQixlQUFlLEVBQUUsR0FBR0QsYUFBYVEsMEJBQTBCYSxFQUFFQyxPQUFPQyxNQUFNLENBQUMsR0FBRyxXQUFVLHlEQUF2TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0UDtBQUFBLFlBQzNQTCxVQUFVViw0QkFBNEIsdUJBQUMsT0FBRSxXQUFVLHdCQUF3QlUsb0JBQVVWLDRCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLGVBSGpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUE2QztBQUFBO0FBQUEsY0FBeUIsdUJBQUMsVUFBSyxXQUFVLHFCQUFvQixpQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxpQkFBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUk7QUFBQSxZQUNuSSx1QkFBQyxXQUFNLE1BQUssVUFBUyxPQUFPUixZQUFZWSxzQkFBc0JDLHNCQUFzQixVQUFVLENBQUNRLE1BQU13SCxzQkFBc0IseUJBQXlCLHdCQUF3QnhILEVBQUVDLE9BQU9DLEtBQUssR0FBRyxhQUFZLFFBQU8sV0FBVSx5REFBMU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1E7QUFBQSxZQUM5UUwsVUFBVSw0Q0FBNEMsS0FBSyx1QkFBQyxPQUFFLFdBQVUsd0JBQXdCQSxvQkFBVSw0Q0FBNEMsS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkY7QUFBQSxlQUgzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSxtQ0FBQyxTQUFJO0FBQUEscUNBQUMsVUFBSyxXQUFVLHVCQUFzQiwyQ0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUU7QUFBQSxjQUFPLHVCQUFDLFVBQUssV0FBVSxnQ0FBK0IsOENBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZFO0FBQUEsaUJBQTFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlLO0FBQUEsWUFDakssdUJBQUMsWUFBUyxTQUFTbEIsWUFBWVksc0JBQXNCRSw2QkFBNkIsVUFBVSxDQUFDTyxNQUFNd0gsc0JBQXNCLHlCQUF5QiwrQkFBK0J4SCxFQUFFQyxPQUFPbUssT0FBTyxLQUFqTTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtTTtBQUFBLGVBRnJNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUE2QywrQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxVQUFPLFdBQVUsZUFBYyxPQUFPekwsWUFBWVksc0JBQXNCRyxpQkFBaUIsVUFBUSxRQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRztBQUFBLGVBRnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUE2QyxxQ0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRix1QkFBQyxVQUFPLFdBQVUsZUFBYyxPQUFPLE9BQU8sVUFBUSxRQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLGVBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQXpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEhBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSxpQ0FBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1qRSxnQkFBZ0IsS0FBSyxHQUFHLFdBQVUsaUNBQWdDLHNCQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RztBQUFBLFVBQzdHLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUseUVBQXdFLGlDQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5SDtBQUFBLGFBRjNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBaElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpSUEsS0FsSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1JQTtBQUFBLFNBNUlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2SUEsS0E5SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStJQTtBQUFBLElBR0EsdUJBQUMsU0FBTSxXQUFXRyxrQkFBa0IsU0FBUyxNQUFNO0FBQUVDLDBCQUFvQixLQUFLO0FBQUdFLHdCQUFrQixJQUFJO0FBQUcyQywwQkFBb0IsS0FBSztBQUFBLElBQUcsR0FDcEksaUNBQUMsU0FBSSxXQUFVLCtGQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdGQUNiLGlDQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0RBQW1ELGlDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtGO0FBQUEsUUFDbEYsdUJBQUMsT0FBRSxXQUFVLDJDQUEwQyxtREFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRjtBQUFBLFdBRjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHFEQUNaRCw2QkFDQyx1QkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsUUFBSyxNQUFLLFNBQVEsS0FBSSxxQ0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RCxLQUQxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFFQTNDLGtCQUNFLHVCQUFDLFVBQUssVUFBVStJLHFCQUFxQixZQUFVLE1BQzdDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlDQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsOENBQTZDLHdCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLFlBQ3RFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU8sR0FBRy9JLGVBQWVnRCxrQkFBa0JDLGlCQUFpQixFQUFFLE1BQU1qRCxlQUFlZ0Qsa0JBQWtCRyxrQkFBa0IsRUFBRTtBQUFBLGdCQUN6SDtBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWdIO0FBQUEsZUFObEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsOENBQTZDO0FBQUE7QUFBQSxjQUFlLHVCQUFDLFVBQUssV0FBVSxxQkFBb0IsaUJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUEsaUJBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlIO0FBQUEsWUFDekg7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osVUFBVTBGO0FBQUFBLGdCQUNWLE9BQU9wSTtBQUFBQSxnQkFDUCxXQUFVO0FBQUEsZ0JBQ1YsWUFBVTtBQUFBLGdCQUVURTtBQUFBQSwwQ0FBd0JvRSxJQUFJLENBQUMrSSxPQUFPQyxRQUFRO0FBQzNDLDBCQUFNQyxZQUFZRixPQUFPckYsWUFBWUMsT0FBT3NCLGNBQWM7QUFDMUQsMEJBQU0vQixVQUFVNkYsT0FBT3JGLFlBQVlDLE9BQU94RCxPQUFPLFdBQVc2SSxHQUFHO0FBQy9ELDBCQUFNek4sU0FBU3dOLE9BQU9yRixZQUFZd0YsV0FBVztBQUM3QywyQkFDRSx1QkFBQyxPQUFPLFFBQVAsRUFBZ0QsT0FBTyxRQUFRaEcsT0FBTyxJQUFJM0gsTUFBTSxJQUMvRSxpQ0FBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUEsNkNBQUMsVUFBSyxXQUFVLGVBQWUwTix1QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUM7QUFBQSxzQkFBTyx1QkFBQyxVQUFLLFdBQVUsV0FBVTtBQUFBO0FBQUEsd0JBQVMxTjtBQUFBQSx3QkFBTztBQUFBLDJCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRDtBQUFBLHlCQUFoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1SSxLQURySCxRQUFRMkgsT0FBTyxJQUFJM0gsTUFBTSxJQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBRUosQ0FBQztBQUFBLGtCQUNBTyxtQkFBbUJrRTtBQUFBQSxvQkFBSSxDQUFBbUosVUFDdEIsdUJBQUMsT0FBTyxRQUFQLEVBQXlDLE9BQU8sU0FBU0EsTUFBTWhKLEdBQUcsSUFBSWdKLE1BQU0zTixZQUFZMk4sTUFBTWhKLEdBQUcsSUFDaEcsaUNBQUMsU0FBSSxXQUFVLGlCQUFnQjtBQUFBLDZDQUFDLFVBQUssV0FBVSxlQUFlZ0osZ0JBQU0zTixZQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4QztBQUFBLHNCQUFPLHVCQUFDLFVBQUssV0FBVSxXQUFVO0FBQUE7QUFBQSx3QkFBRzJOLE1BQU1DO0FBQUFBLHdCQUFlO0FBQUEsMkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTBEO0FBQUEseUJBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFKLEtBRG5JLFNBQVNELE1BQU1oSixHQUFHLElBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBLGtCQUNBbkUsY0FBY2dFO0FBQUFBLG9CQUFJLENBQUFxSixhQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBMkMsT0FBTyxRQUFRQSxTQUFTbEosR0FBRyxJQUFJa0osU0FBUzVOLFdBQVc0TixTQUFTbEosR0FBRyxJQUN6RyxpQ0FBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUEsNkNBQUMsVUFBSyxXQUFVLGVBQWVrSixtQkFBUzVOLFdBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdEO0FBQUEsc0JBQU8sdUJBQUMsVUFBSyxXQUFVLFdBQVU7QUFBQTtBQUFBLHdCQUFHNE4sU0FBU0M7QUFBQUEsd0JBQVk7QUFBQSwyQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUQ7QUFBQSx5QkFBL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0osS0FEcEksUUFBUUQsU0FBU2xKLEdBQUcsSUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBMUJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTJCQTtBQUFBLGVBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOEJBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw4Q0FBNkMsK0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsWUFDN0UsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT2xGLGVBQWUrQyxtQkFBbUIsSUFBSSxVQUFRLE1BQUMsV0FBVSx3R0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUw7QUFBQSxlQUZ6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw4Q0FBNkMsb0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFO0FBQUEsWUFDbEUsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBTy9DLGVBQWVvRCxjQUFjNUUsV0FBVyxJQUFJLFVBQVEsTUFBQyxXQUFVLHdHQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2TDtBQUFBLGVBRi9MO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUE2QyxpQ0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0U7QUFBQSxZQUMvRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPbUosbUJBQW1CM0gsZUFBZXNELDhCQUE4QjtBQUFBLGdCQUN2RTtBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWdIO0FBQUEsZUFObEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsOENBQTZDLDJCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RTtBQUFBLFlBQ3pFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9xRSxtQkFBbUIzSCxlQUFlcUQsd0JBQXdCO0FBQUEsZ0JBQ2pFO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJZ0g7QUFBQSxlQU5sSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw4Q0FBNkMsd0NBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsWUFDdEYsdUJBQUMsV0FBTSxNQUFLLFVBQVMsT0FBT3JELGVBQWV5RCx1QkFBdUJDLHdCQUF3QixJQUFJLFVBQVEsTUFBQyxXQUFVLHdHQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxTjtBQUFBLGVBRnZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSwyRUFDYjtBQUFBLG1DQUFDLFNBQUk7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsdUJBQXNCLDJDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRTtBQUFBLGNBQU8sdUJBQUMsVUFBSyxXQUFVLGdDQUErQiw4Q0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkU7QUFBQSxpQkFBMUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUs7QUFBQSxZQUNqSyx1QkFBQyxZQUFTLFNBQVMxRCxlQUFleUQsdUJBQXVCRSw2QkFBNkIsVUFBUSxRQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RjtBQUFBLGVBRmhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUE2QywrQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxVQUFPLFdBQVUsZUFBYyxPQUFPM0QsZUFBZXlELHVCQUF1QkcsbUJBQW1CLENBQUMsS0FBSyxHQUFHLFVBQVEsUUFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUg7QUFBQSxlQUZuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw4Q0FBNkMscUNBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1GO0FBQUEsWUFDbkYsdUJBQUMsVUFBTyxXQUFVLGVBQWMsT0FBTyxPQUFPLFVBQVEsUUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxlQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFyR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNHQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsaUNBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNO0FBQUU3RCxnQ0FBb0IsS0FBSztBQUFHRSw4QkFBa0IsSUFBSTtBQUFBLFVBQUcsR0FBRyxXQUFVLGlDQUFnQyxzQkFBekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0k7QUFBQSxVQUMvSSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHlFQUF3RSxtQ0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkg7QUFBQSxhQUY3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQTVHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkdBLEtBcEhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1SEE7QUFBQSxTQTlIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0hBLEtBaElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpSUE7QUFBQSxJQUdBLHVCQUFDLFNBQU0sV0FBV0wsb0JBQW9CLFNBQVMsTUFBTTtBQUFFQyw0QkFBc0IsS0FBSztBQUFHcUIsNkJBQXVCLElBQUk7QUFBQSxJQUFHLEdBQ2pILGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsbUNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0U7QUFBQSxNQUN2RUQsdUJBQ0MsdUJBQUMsVUFBSyxVQUFVLENBQUNpRCxNQUFNO0FBQUVBLFVBQUVrQyxlQUFlO0FBQUdzRyx3QkFBZ0I7QUFBQSxNQUFHLEdBQUcsV0FBVSxhQUMzRTtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxZQUFhLHVCQUFDLFVBQUssV0FBVSwwQkFBMEJ6TCw4QkFBb0I4QixtQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxZQUFPO0FBQUEsWUFBc0IsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLGVBQXhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStOO0FBQUEsVUFDL04sdUJBQUMsV0FBTSxNQUFLLFFBQU8sSUFBRyx1QkFBc0IsYUFBWSw2QkFBNEIsVUFBUSxNQUFDLFdBQVUscUZBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdMO0FBQUEsYUFGMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHdHQUF1RyxzQkFBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2STtBQUFBLFdBTC9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0Foa0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0Fpa0JBLEtBbGtCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbWtCQTtBQUVKO0FBQUV2RyxHQTE5Q0lELGVBQWE7QUFBQWdTLEtBQWJoUztBQTQ5Q04sZUFBZUE7QUFBYyxJQUFBZ1M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiVGFicyIsIkRyb3Bkb3duIiwiU2VsZWN0IiwiVG9vbHRpcCIsIkNoZWNrYm94IiwiU3BpbiIsIklvTWRNb3JlIiwiQ2hlY2tDaXJjbGVPdXRsaW5lZCIsIkNsb3NlQ2lyY2xlT3V0bGluZWQiLCJJbmZvQ2lyY2xlT3V0bGluZWQiLCJTeW5jT3V0bGluZWQiLCJTaWRlYmFyIiwiTW9kYWwiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydERpYWxvZyIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwiUmVmcmVzaEN3IiwiVGFiUGFuZSIsIlN1YnNjcmlwdGlvbnMiLCJfcyIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsInBsYW5zIiwic2V0UGxhbnMiLCJ0YWJsZVBsYW5zIiwic2V0VGFibGVQbGFucyIsInNob3dQbGFuTW9kYWwiLCJzZXRTaG93UGxhbk1vZGFsIiwic2hvd1BsYW5EZWxldGVNb2RhbCIsInNldFNob3dQbGFuRGVsZXRlTW9kYWwiLCJzaG93UGxhblZpZXdNb2RhbCIsInNldFNob3dQbGFuVmlld01vZGFsIiwidmlld1BsYW4iLCJzZXRWaWV3UGxhbiIsImN1cnJlbnRQbGFuIiwic2V0Q3VycmVudFBsYW4iLCJjdXJyZW50VXBkYXRlUGxhbiIsInNldEN1cnJlbnRVcGRhdGVQbGFuIiwicGxhblJlbG9hZFRyaWdnZXIiLCJzZXRQbGFuUmVsb2FkVHJpZ2dlciIsInBsYW5Jc0xvYWRpbmciLCJzZXRQbGFuSXNMb2FkaW5nIiwicGxhbkZvcm1EYXRhIiwic2V0UGxhbkZvcm1EYXRhIiwicGxhbl9pZCIsInBsYW5fbmFtZSIsInBsYW5fdHlwZSIsInBsYW5fY3VycmVuY3kiLCJwbGFuX3JlY3VycmluZ19hbW91bnQiLCJwbGFuX21heF9hbW91bnQiLCJwbGFuX21heF9jeWNsZXMiLCJwbGFuX2ludGVydmFscyIsInBsYW5faW50ZXJ2YWxfdHlwZSIsInBsYW5fbm90ZSIsInBsYW5FcnJvcnMiLCJzZXRQbGFuRXJyb3JzIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsInN1YnNjcmlwdGlvbnMiLCJzZXRTdWJzY3JpcHRpb25zIiwidGFibGVTdWJzY3JpcHRpb25zIiwic2V0VGFibGVTdWJzY3JpcHRpb25zIiwic2hvd1N1Yk1vZGFsIiwic2V0U2hvd1N1Yk1vZGFsIiwic2hvd1N1YkRlbGV0ZU1vZGFsIiwic2V0U2hvd1N1YkRlbGV0ZU1vZGFsIiwic2hvd1N1YkVkaXRNb2RhbCIsInNldFNob3dTdWJFZGl0TW9kYWwiLCJjdXJyZW50RWRpdFN1YiIsInNldEN1cnJlbnRFZGl0U3ViIiwiZWRpdFN1YlRhZ3MiLCJzZXRFZGl0U3ViVGFncyIsInBheV90eXBlIiwiZ3JvdXBfaWQiLCJ0aWNrZXQiLCJwaWdtZV9pZCIsImxvYW5faWQiLCJlZGl0R3JvdXBUaWNrZXRWYWx1ZSIsInNldEVkaXRHcm91cFRpY2tldFZhbHVlIiwiZWRpdEZpbHRlcmVkRW5yb2xsbWVudHMiLCJzZXRFZGl0RmlsdGVyZWRFbnJvbGxtZW50cyIsImVkaXRQaWdtZUN1c3RvbWVycyIsInNldEVkaXRQaWdtZUN1c3RvbWVycyIsImVkaXRCb3Jyb3dlcnMiLCJzZXRFZGl0Qm9ycm93ZXJzIiwiY3VycmVudFN1YnNjcmlwdGlvbiIsInNldEN1cnJlbnRTdWJzY3JpcHRpb24iLCJzdWJSZWxvYWRUcmlnZ2VyIiwic2V0U3ViUmVsb2FkVHJpZ2dlciIsInN1YklzTG9hZGluZyIsInNldFN1YklzTG9hZGluZyIsInNlbGVjdGVkVXNlcklkIiwic2V0U2VsZWN0ZWRVc2VySWQiLCJlbnJvbGxtZW50TG9hZGluZyIsInNldEVucm9sbG1lbnRMb2FkaW5nIiwiZmlsdGVyZWRFbnJvbGxtZW50cyIsInNldEZpbHRlcmVkRW5yb2xsbWVudHMiLCJwaWdtZUN1c3RvbWVycyIsInNldFBpZ21lQ3VzdG9tZXJzIiwiYm9ycm93ZXJzIiwic2V0Qm9ycm93ZXJzIiwic2VsZWN0ZWRHcm91cFRpY2tldFZhbHVlIiwic2V0U2VsZWN0ZWRHcm91cFRpY2tldFZhbHVlIiwiZmlyc3RDaGFyZ2VUaW1lTWluIiwic2V0Rmlyc3RDaGFyZ2VUaW1lTWluIiwiZXhwaXJ5VGltZU1pbiIsInNldEV4cGlyeVRpbWVNaW4iLCJwbGFuc0ZvckRyb3Bkb3duIiwic2V0UGxhbnNGb3JEcm9wZG93biIsInVzZXJzIiwic2V0VXNlcnMiLCJlZGl0TW9kYWxMb2FkaW5nIiwic2V0RWRpdE1vZGFsTG9hZGluZyIsInN1YkZvcm1EYXRhIiwic2V0U3ViRm9ybURhdGEiLCJzdWJzY3JpcHRpb25faWQiLCJjdXN0b21lcl9kZXRhaWxzIiwiY3VzdG9tZXJfbmFtZSIsImN1c3RvbWVyX2VtYWlsIiwiY3VzdG9tZXJfcGhvbmUiLCJwbGFuX2RldGFpbHMiLCJzdWJzY3JpcHRpb25fZXhwaXJ5X3RpbWUiLCJzdWJzY3JpcHRpb25fZmlyc3RfY2hhcmdlX3RpbWUiLCJzdWJzY3JpcHRpb25fbWV0YSIsIm5vdGlmaWNhdGlvbl9jaGFubmVsIiwiYXV0aG9yaXphdGlvbl9kZXRhaWxzIiwiYXV0aG9yaXphdGlvbl9hbW91bnQiLCJhdXRob3JpemF0aW9uX2Ftb3VudF9yZWZ1bmQiLCJwYXltZW50X21ldGhvZHMiLCJzdWJzY3JpcHRpb25fdGFncyIsInVzZXJfaWQiLCJzdWJFcnJvcnMiLCJzZXRTdWJFcnJvcnMiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJoYW5kbGVQbGFuVmlld01vZGFsT3BlbiIsInBsYW5JZCIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImZldGNoUGxhbnMiLCJwbGFuc0RhdGEiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwicGxhbiIsImluZGV4IiwiX2lkIiwiaWQiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlUGxhbkRlbGV0ZU1vZGFsT3BlbiIsImhhbmRsZVBsYW5DaGFuZ2UiLCJuYW1lIiwicHJldiIsImhhbmRsZVBsYW5BbnREU2VsZWN0IiwiZmllbGQiLCJ2YWxpZGF0ZVBsYW5Gb3JtIiwibmV3RXJyb3JzIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImhhbmRsZVBsYW5TdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInJlc3QiLCJwYXlsb2FkIiwiTnVtYmVyIiwicG9zdCIsImhhbmRsZVBsYW5EZWxldGUiLCJkZWxldGUiLCJmb3JtYXREYXRlVGltZSIsImlzb1N0cmluZyIsImRhdGUiLCJEYXRlIiwiZGF5IiwiU3RyaW5nIiwiZ2V0RGF0ZSIsInBhZFN0YXJ0IiwibW9udGgiLCJnZXRNb250aCIsInllYXIiLCJnZXRGdWxsWWVhciIsImhvdXJzIiwiZ2V0SG91cnMiLCJtaW51dGVzIiwiZ2V0TWludXRlcyIsImlzb1RvRGF0ZXRpbWVMb2NhbCIsImhhbmRsZVN1YkVkaXRNb2RhbE9wZW4iLCJzdWJJZCIsInN1YkRhdGEiLCJ0YWdzIiwicGF5VHlwZSIsImdyb3VwSWQiLCJwaWdtZUlkIiwibG9hbklkIiwidXNlcklkIiwiZW5yb2xsUmVzcCIsInZhbGlkRW5yb2xsbWVudHMiLCJmaWx0ZXIiLCJhdWN0aW9uIiwiZW5yb2xsbWVudCIsImdyb3VwIiwicGlnbWVSZXNwIiwibG9hblJlc3AiLCJoYW5kbGVFZGl0R3JvdXBUaWNrZXRTZWxlY3QiLCJzcGxpdCIsImhhbmRsZVN1YkVkaXRTdWJtaXQiLCJwYXRjaCIsImZldGNoU3Vic2NyaXB0aW9ucyIsInN1YnNEYXRhIiwic29ydCIsImEiLCJiIiwic3ViIiwiZ2V0U3RhdHVzRGlzcGxheSIsInN0YXR1cyIsInRvVXBwZXJDYXNlIiwiaWNvbiIsImNvbG9yIiwiYmciLCJzdGF0dXNEaXNwbGF5Iiwic3Vic2NyaXB0aW9uX3N0YXR1cyIsImdldEdyb3VwRGV0YWlscyIsImdyb3VwX25hbWUiLCJleHBpcnlfdGltZSIsImZpcnN0X2NoYXJnZV90aW1lIiwiam9pbiIsInJlZnVuZCIsIlN0YXR1cyIsImhhbmRsZVN1YkRlbGV0ZU1vZGFsT3BlbiIsImZldGNoVXNlcnMiLCJub3ciLCJ0b21vcnJvdyIsInNldERhdGUiLCJzZXRIb3VycyIsIm1pbkRhdGVUaW1lIiwiZmV0Y2hCb3Jyb3dlcnMiLCJlcnIiLCJmZXRjaFBpZ21lIiwiaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlIiwiaGFuZGxlQ3VzdG9tZXJTZWxlY3QiLCJzZWxlY3RlZFVzZXIiLCJmaW5kIiwidXNlciIsImZ1bGxfbmFtZSIsImVtYWlsIiwicGhvbmVfbnVtYmVyIiwiY3VzdG9tZXIiLCJoYW5kbGVHcm91cFRpY2tldFNlbGVjdCIsImhhbmRsZVN1Yk5lc3RlZENoYW5nZSIsInNlY3Rpb24iLCJoYW5kbGVTdWJDaGFuZ2UiLCJjb252ZXJ0VG9JU09XaXRoT2Zmc2V0IiwiZGF0ZXRpbWVMb2NhbCIsInR6T2Zmc2V0IiwiZ2V0VGltZXpvbmVPZmZzZXQiLCJzaWduIiwiTWF0aCIsImZsb29yIiwiYWJzIiwidG9JU09TdHJpbmciLCJyZXBsYWNlIiwidmFsaWRhdGVTdWJGb3JtIiwiaGFuZGxlU3ViU3VibWl0Iiwic3Vic2NyaXB0aW9uVGFncyIsImhhbmRsZVN1YkRlbGV0ZSIsInBsYW5Db2x1bW5zIiwiaGVhZGVyIiwic3ViQ29sdW1ucyIsIndpZHRoIiwiRXhjZWxDb2x1bW5zIiwiY3JlYXRlZEF0IiwidXBkYXRlZEF0IiwiZ2xvYmFsVGhpcyIsImNyeXB0byIsInJhbmRvbVVVSUQiLCJzbGljZSIsIm5vdGUiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwiZW50cnkiLCJpZHgiLCJncm91cE5hbWUiLCJ0aWNrZXRzIiwicGlnbWUiLCJwYXlhYmxlX2Ftb3VudCIsImJvcnJvd2VyIiwibG9hbl9hbW91bnQiLCJjaGVja2VkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU3Vic2NyaXB0aW9ucy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBUYWJzLCBEcm9wZG93biwgU2VsZWN0LCBUb29sdGlwLCBDaGVja2JveCwgU3BpbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCB7IENoZWNrQ2lyY2xlT3V0bGluZWQsIENsb3NlQ2lyY2xlT3V0bGluZWQsIEluZm9DaXJjbGVPdXRsaW5lZCwgU3luY091dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgUmVmcmVzaEN3IH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcclxuXHJcbmNvbnN0IHsgVGFiUGFuZSB9ID0gVGFicztcclxuXHJcbmNvbnN0IFN1YnNjcmlwdGlvbnMgPSAoKSA9PiB7XHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT0gR0xPQkFMIFNUQVRFID09PT09PT09PT09PT09PT09PT09XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwicGxhbnNcIik7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT0gUExBTlMgU1RBVEUgPT09PT09PT09PT09PT09PT09PT1cclxuICBjb25zdCBbcGxhbnMsIHNldFBsYW5zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdGFibGVQbGFucywgc2V0VGFibGVQbGFuc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3Nob3dQbGFuTW9kYWwsIHNldFNob3dQbGFuTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93UGxhbkRlbGV0ZU1vZGFsLCBzZXRTaG93UGxhbkRlbGV0ZU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAvLyBjb25zdCBbc2hvd1BsYW5VcGRhdGVNb2RhbCwgc2V0U2hvd1BsYW5VcGRhdGVNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dQbGFuVmlld01vZGFsLCBzZXRTaG93UGxhblZpZXdNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7IC8vIE5FVzogdmlldyBtb2RhbFxyXG4gIGNvbnN0IFt2aWV3UGxhbiwgc2V0Vmlld1BsYW5dID0gdXNlU3RhdGUobnVsbCk7IC8vIE5FVzogcGxhbiB0byB2aWV3XHJcbiAgY29uc3QgW2N1cnJlbnRQbGFuLCBzZXRDdXJyZW50UGxhbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZVBsYW4sIHNldEN1cnJlbnRVcGRhdGVQbGFuXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtwbGFuUmVsb2FkVHJpZ2dlciwgc2V0UGxhblJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3BsYW5Jc0xvYWRpbmcsIHNldFBsYW5Jc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtwbGFuRm9ybURhdGEsIHNldFBsYW5Gb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBwbGFuX2lkOiBcIlwiLFxyXG4gICAgcGxhbl9uYW1lOiBcIlwiLFxyXG4gICAgcGxhbl90eXBlOiBcIlBFUklPRElDXCIsXHJcbiAgICBwbGFuX2N1cnJlbmN5OiBcIklOUlwiLFxyXG4gICAgcGxhbl9yZWN1cnJpbmdfYW1vdW50OiBcIlwiLFxyXG4gICAgcGxhbl9tYXhfYW1vdW50OiBcIlwiLFxyXG4gICAgcGxhbl9tYXhfY3ljbGVzOiBcIlwiLFxyXG4gICAgcGxhbl9pbnRlcnZhbHM6IFwiXCIsXHJcbiAgICBwbGFuX2ludGVydmFsX3R5cGU6IFwiTU9OVEhcIixcclxuICAgIHBsYW5fbm90ZTogXCJDaGl0XCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3BsYW5FcnJvcnMsIHNldFBsYW5FcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoeyAuLi5wbGFuRm9ybURhdGEgfSk7XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09IFNVQlNDUklQVElPTlMgU1RBVEUgPT09PT09PT09PT09PT09PT09PT1cclxuICBjb25zdCBbc3Vic2NyaXB0aW9ucywgc2V0U3Vic2NyaXB0aW9uc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RhYmxlU3Vic2NyaXB0aW9ucywgc2V0VGFibGVTdWJzY3JpcHRpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd1N1Yk1vZGFsLCBzZXRTaG93U3ViTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93U3ViRGVsZXRlTW9kYWwsIHNldFNob3dTdWJEZWxldGVNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dTdWJFZGl0TW9kYWwsIHNldFNob3dTdWJFZGl0TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpOyAvLyBORVc6IGVkaXQgbW9kYWxcclxuICBjb25zdCBbY3VycmVudEVkaXRTdWIsIHNldEN1cnJlbnRFZGl0U3ViXSA9IHVzZVN0YXRlKG51bGwpOyAvLyBORVc6IHN1YnNjcmlwdGlvbiBiZWluZyBlZGl0ZWRcclxuICBjb25zdCBbZWRpdFN1YlRhZ3MsIHNldEVkaXRTdWJUYWdzXSA9IHVzZVN0YXRlKHsgLy8gTkVXOiBlZGl0YWJsZSB0YWdzIHN0YXRlXHJcbiAgICBwYXlfdHlwZTogXCJDSElUXCIsXHJcbiAgICBncm91cF9pZDogXCJcIixcclxuICAgIHRpY2tldDogXCJcIixcclxuICAgIHBpZ21lX2lkOiBcIlwiLFxyXG4gICAgbG9hbl9pZDogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbZWRpdEdyb3VwVGlja2V0VmFsdWUsIHNldEVkaXRHcm91cFRpY2tldFZhbHVlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtlZGl0RmlsdGVyZWRFbnJvbGxtZW50cywgc2V0RWRpdEZpbHRlcmVkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlZGl0UGlnbWVDdXN0b21lcnMsIHNldEVkaXRQaWdtZUN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VkaXRCb3Jyb3dlcnMsIHNldEVkaXRCb3Jyb3dlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjdXJyZW50U3Vic2NyaXB0aW9uLCBzZXRDdXJyZW50U3Vic2NyaXB0aW9uXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzdWJSZWxvYWRUcmlnZ2VyLCBzZXRTdWJSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtzdWJJc0xvYWRpbmcsIHNldFN1YklzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVXNlcklkLCBzZXRTZWxlY3RlZFVzZXJJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZW5yb2xsbWVudExvYWRpbmcsIHNldEVucm9sbG1lbnRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZmlsdGVyZWRFbnJvbGxtZW50cywgc2V0RmlsdGVyZWRFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3BpZ21lQ3VzdG9tZXJzLCBzZXRQaWdtZUN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2JvcnJvd2Vycywgc2V0Qm9ycm93ZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cFRpY2tldFZhbHVlLCBzZXRTZWxlY3RlZEdyb3VwVGlja2V0VmFsdWVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2ZpcnN0Q2hhcmdlVGltZU1pbiwgc2V0Rmlyc3RDaGFyZ2VUaW1lTWluXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtleHBpcnlUaW1lTWluLCBzZXRFeHBpcnlUaW1lTWluXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwbGFuc0ZvckRyb3Bkb3duLCBzZXRQbGFuc0ZvckRyb3Bkb3duXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZWRpdE1vZGFsTG9hZGluZywgc2V0RWRpdE1vZGFsTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIEZvcm0gc3RhdGUgZm9yIHN1YnNjcmlwdGlvbiBjcmVhdGVcclxuICBjb25zdCBbc3ViRm9ybURhdGEsIHNldFN1YkZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHN1YnNjcmlwdGlvbl9pZDogXCJcIixcclxuICAgIGN1c3RvbWVyX2RldGFpbHM6IHtcclxuICAgICAgY3VzdG9tZXJfbmFtZTogXCJcIixcclxuICAgICAgY3VzdG9tZXJfZW1haWw6IFwiXCIsXHJcbiAgICAgIGN1c3RvbWVyX3Bob25lOiBcIlwiLFxyXG4gICAgfSxcclxuICAgIHBsYW5fZGV0YWlsczoge1xyXG4gICAgICBwbGFuX2lkOiBcIlwiLFxyXG4gICAgfSxcclxuICAgIHN1YnNjcmlwdGlvbl9leHBpcnlfdGltZTogXCJcIixcclxuICAgIHN1YnNjcmlwdGlvbl9maXJzdF9jaGFyZ2VfdGltZTogXCJcIixcclxuICAgIHN1YnNjcmlwdGlvbl9tZXRhOiB7XHJcbiAgICAgIG5vdGlmaWNhdGlvbl9jaGFubmVsOiBbXCJTTVNcIl0sXHJcbiAgICB9LFxyXG4gICAgYXV0aG9yaXphdGlvbl9kZXRhaWxzOiB7XHJcbiAgICAgIGF1dGhvcml6YXRpb25fYW1vdW50OiBcIlwiLFxyXG4gICAgICBhdXRob3JpemF0aW9uX2Ftb3VudF9yZWZ1bmQ6IGZhbHNlLFxyXG4gICAgICBwYXltZW50X21ldGhvZHM6IFtcInVwaVwiXSxcclxuICAgIH0sXHJcbiAgICBzdWJzY3JpcHRpb25fdGFnczoge1xyXG4gICAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgICBwYXlfdHlwZTogXCJDSElUXCIsXHJcbiAgICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgICB0aWNrZXQ6IFwiXCIsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtzdWJFcnJvcnMsIHNldFN1YkVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09IFNIQVJFRCBIQU5ETEVSUyA9PT09PT09PT09PT09PT09PT09PVxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PSBQTEFOUyBMT0dJQyA9PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAvLyBORVc6IE9wZW4gdmlldyBwbGFuIG1vZGFsXHJcbiAgY29uc3QgaGFuZGxlUGxhblZpZXdNb2RhbE9wZW4gPSBhc3luYyAocGxhbklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9jYXNoZnJlZS1zdWJzY3JpcHRpb24vcGxhbnMvJHtwbGFuSWR9YCk7XHJcbiAgICAgIHNldFZpZXdQbGFuKHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgcmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dQbGFuVmlld01vZGFsKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBsYW4gZm9yIHZpZXc6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gZmV0Y2ggcGxhbiBkZXRhaWxzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBGZXRjaCBhbGwgcGxhbnNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hQbGFucyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRQbGFuSXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9jYXNoZnJlZS1zdWJzY3JpcHRpb24vcGxhbnNcIik7XHJcbiAgICAgICAgY29uc3QgcGxhbnNEYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhIHx8IFtdO1xyXG4gICAgICAgIHNldFBsYW5zKHBsYW5zRGF0YSk7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHBsYW5zRGF0YS5tYXAoKHBsYW4sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBwbGFuLl9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBwbGFuX2lkOiBwbGFuLnBsYW5faWQsXHJcbiAgICAgICAgICBwbGFuX25hbWU6IHBsYW4ucGxhbl9uYW1lLFxyXG4gICAgICAgICAgcGxhbl90eXBlOiBwbGFuLnBsYW5fdHlwZSxcclxuICAgICAgICAgIHBsYW5fY3VycmVuY3k6IHBsYW4ucGxhbl9jdXJyZW5jeSxcclxuICAgICAgICAgIHBsYW5fcmVjdXJyaW5nX2Ftb3VudDogcGxhbi5wbGFuX3JlY3VycmluZ19hbW91bnQsXHJcbiAgICAgICAgICBwbGFuX21heF9hbW91bnQ6IHBsYW4ucGxhbl9tYXhfYW1vdW50LFxyXG4gICAgICAgICAgcGxhbl9tYXhfY3ljbGVzOiBwbGFuLnBsYW5fbWF4X2N5Y2xlcyxcclxuICAgICAgICAgIHBsYW5faW50ZXJ2YWxzOiBwbGFuLnBsYW5faW50ZXJ2YWxzLFxyXG4gICAgICAgICAgcGxhbl9pbnRlcnZhbF90eXBlOiBwbGFuLnBsYW5faW50ZXJ2YWxfdHlwZSxcclxuICAgICAgICAgIHBsYW5fbm90ZTogcGxhbi5wbGFuX25vdGUsXHJcbiAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCIga2V5PXtwbGFuLl9pZH0+XHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgb25DbGljaz17KCkgPT4gaGFuZGxlUGxhblZpZXdNb2RhbE9wZW4ocGxhbi5faWQpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQbGFuRGVsZXRlTW9kYWxPcGVuKHBsYW4uX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkIGN1cnNvci1wb2ludGVyXCIgLz5cclxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFRhYmxlUGxhbnMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBsYW5zOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIHBsYW5zXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0UGxhbklzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFBsYW5zKCk7XHJcbiAgfSwgW3BsYW5SZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBsYW5DaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRQbGFuRm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdmFsdWUgfSkpO1xyXG4gICAgc2V0UGxhbkVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQbGFuQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldFBsYW5Gb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xyXG4gICAgc2V0UGxhbkVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVQbGFuRm9ybSA9ICgpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgaWYgKCFwbGFuRm9ybURhdGEucGxhbl9pZCkgbmV3RXJyb3JzLnBsYW5faWQgPSBcIlBsYW4gSUQgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghcGxhbkZvcm1EYXRhLnBsYW5fbmFtZSkgbmV3RXJyb3JzLnBsYW5fbmFtZSA9IFwiUGxhbiBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBpZiAoIXBsYW5Gb3JtRGF0YS5wbGFuX3JlY3VycmluZ19hbW91bnQgfHwgcGxhbkZvcm1EYXRhLnBsYW5fcmVjdXJyaW5nX2Ftb3VudCA8PSAwKVxyXG4gICAgICBuZXdFcnJvcnMucGxhbl9yZWN1cnJpbmdfYW1vdW50ID0gXCJSZWN1cnJpbmcgYW1vdW50IG11c3QgYmUgcG9zaXRpdmVcIjtcclxuICAgIGlmICghcGxhbkZvcm1EYXRhLnBsYW5fbWF4X2Ftb3VudCB8fCBwbGFuRm9ybURhdGEucGxhbl9tYXhfYW1vdW50IDw9IDApXHJcbiAgICAgIG5ld0Vycm9ycy5wbGFuX21heF9hbW91bnQgPSBcIk1heCBhbW91bnQgbXVzdCBiZSBwb3NpdGl2ZVwiO1xyXG4gICAgaWYgKCFwbGFuRm9ybURhdGEucGxhbl9pbnRlcnZhbHMgfHwgcGxhbkZvcm1EYXRhLnBsYW5faW50ZXJ2YWxzIDw9IDApXHJcbiAgICAgIG5ld0Vycm9ycy5wbGFuX2ludGVydmFscyA9IFwiSW50ZXJ2YWxzIG11c3QgYmUgcG9zaXRpdmVcIjtcclxuICAgIGlmICghcGxhbkZvcm1EYXRhLnBsYW5faW50ZXJ2YWxfdHlwZSlcclxuICAgICAgbmV3RXJyb3JzLnBsYW5faW50ZXJ2YWxfdHlwZSA9IFwiSW50ZXJ2YWwgdHlwZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFwbGFuRm9ybURhdGEucGxhbl9ub3RlKSBuZXdFcnJvcnMucGxhbl9ub3RlID0gXCJQbGFuIG5vdGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIHNldFBsYW5FcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQbGFuU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGVQbGFuRm9ybSgpKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB7IHBsYW5fbWF4X2N5Y2xlcywgLi4ucmVzdCB9ID0gcGxhbkZvcm1EYXRhO1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIC4uLnJlc3QsXHJcbiAgICAgICAgcGxhbl9yZWN1cnJpbmdfYW1vdW50OiBOdW1iZXIocGxhbkZvcm1EYXRhLnBsYW5fcmVjdXJyaW5nX2Ftb3VudCksXHJcbiAgICAgICAgcGxhbl9tYXhfYW1vdW50OiBOdW1iZXIocGxhbkZvcm1EYXRhLnBsYW5fbWF4X2Ftb3VudCksXHJcbiAgICAgICAgcGxhbl9pbnRlcnZhbHM6IE51bWJlcihwbGFuRm9ybURhdGEucGxhbl9pbnRlcnZhbHMpLFxyXG4gICAgICB9O1xyXG4gICAgICBpZiAocGxhbl9tYXhfY3ljbGVzICE9PSBcIlwiICYmIHBsYW5fbWF4X2N5Y2xlcyAhPT0gbnVsbCkge1xyXG4gICAgICAgIHBheWxvYWQucGxhbl9tYXhfY3ljbGVzID0gTnVtYmVyKHBsYW5fbWF4X2N5Y2xlcyk7XHJcbiAgICAgIH1cclxuICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvY2FzaGZyZWUtc3Vic2NyaXB0aW9uL3BsYW5zXCIsIHBheWxvYWQpO1xyXG4gICAgICBzZXRQbGFuUmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlBsYW4gYWRkZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93UGxhbk1vZGFsKGZhbHNlKTtcclxuICAgICAgc2V0UGxhbkZvcm1EYXRhKHtcclxuICAgICAgICBwbGFuX2lkOiBcIlwiLFxyXG4gICAgICAgIHBsYW5fbmFtZTogXCJcIixcclxuICAgICAgICBwbGFuX3R5cGU6IFwiUEVSSU9ESUNcIixcclxuICAgICAgICBwbGFuX2N1cnJlbmN5OiBcIklOUlwiLFxyXG4gICAgICAgIHBsYW5fcmVjdXJyaW5nX2Ftb3VudDogXCJcIixcclxuICAgICAgICBwbGFuX21heF9hbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgcGxhbl9tYXhfY3ljbGVzOiBcIlwiLFxyXG4gICAgICAgIHBsYW5faW50ZXJ2YWxzOiBcIlwiLFxyXG4gICAgICAgIHBsYW5faW50ZXJ2YWxfdHlwZTogXCJNT05USFwiLFxyXG4gICAgICAgIHBsYW5fbm90ZTogXCJDaGl0XCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFkZGluZyBwbGFuOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGFkZCBwbGFuXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQbGFuRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKHBsYW5JZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvY2FzaGZyZWUtc3Vic2NyaXB0aW9uL3BsYW5zLyR7cGxhbklkfWApO1xyXG4gICAgICBzZXRDdXJyZW50UGxhbihyZXNwb25zZS5kYXRhPy5kYXRhIHx8IHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93UGxhbkRlbGV0ZU1vZGFsKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBsYW4gZm9yIGRlbGV0ZTpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIGNvbnN0IGhhbmRsZVBsYW5VcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAocGxhbklkKSA9PiB7XHJcbiAgLy8gICB0cnkge1xyXG4gIC8vICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9jYXNoZnJlZS1zdWJzY3JpcHRpb24vcGxhbnMvJHtwbGFuSWR9YCk7XHJcbiAgLy8gICAgIGNvbnN0IHBsYW5EYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhO1xyXG4gIC8vICAgICBzZXRDdXJyZW50VXBkYXRlUGxhbihwbGFuRGF0YSk7XHJcbiAgLy8gICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAvLyAgICAgICBwbGFuX2lkOiBwbGFuRGF0YS5wbGFuX2lkIHx8IFwiXCIsXHJcbiAgLy8gICAgICAgcGxhbl9uYW1lOiBwbGFuRGF0YS5wbGFuX25hbWUgfHwgXCJcIixcclxuICAvLyAgICAgICBwbGFuX3R5cGU6IHBsYW5EYXRhLnBsYW5fdHlwZSB8fCBcIlBFUklPRElDXCIsXHJcbiAgLy8gICAgICAgcGxhbl9jdXJyZW5jeTogcGxhbkRhdGEucGxhbl9jdXJyZW5jeSB8fCBcIklOUlwiLFxyXG4gIC8vICAgICAgIHBsYW5fcmVjdXJyaW5nX2Ftb3VudDogcGxhbkRhdGEucGxhbl9yZWN1cnJpbmdfYW1vdW50IHx8IFwiXCIsXHJcbiAgLy8gICAgICAgcGxhbl9tYXhfYW1vdW50OiBwbGFuRGF0YS5wbGFuX21heF9hbW91bnQgfHwgXCJcIixcclxuICAvLyAgICAgICBwbGFuX21heF9jeWNsZXM6IHBsYW5EYXRhLnBsYW5fbWF4X2N5Y2xlcyB8fCBcIlwiLFxyXG4gIC8vICAgICAgIHBsYW5faW50ZXJ2YWxzOiBwbGFuRGF0YS5wbGFuX2ludGVydmFscyB8fCBcIlwiLFxyXG4gIC8vICAgICAgIHBsYW5faW50ZXJ2YWxfdHlwZTogcGxhbkRhdGEucGxhbl9pbnRlcnZhbF90eXBlIHx8IFwiTU9OVEhcIixcclxuICAvLyAgICAgICBwbGFuX25vdGU6IHBsYW5EYXRhLnBsYW5fbm90ZSB8fCBcIlwiLFxyXG4gIC8vICAgICB9KTtcclxuICAvLyAgICAgc2V0U2hvd1BsYW5VcGRhdGVNb2RhbCh0cnVlKTtcclxuICAvLyAgICAgc2V0UGxhbkVycm9ycyh7fSk7XHJcbiAgLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4gIC8vICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGxhbiBmb3IgdXBkYXRlOlwiLCBlcnJvcik7XHJcbiAgLy8gICB9XHJcbiAgLy8gfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGxhbkRlbGV0ZSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50UGxhbikge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9jYXNoZnJlZS1zdWJzY3JpcHRpb24vcGxhbnMvJHtjdXJyZW50UGxhbi5faWR9YCk7XHJcbiAgICAgICAgc2V0UGxhblJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIlBsYW4gZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRTaG93UGxhbkRlbGV0ZU1vZGFsKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50UGxhbihudWxsKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgcGxhbjpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGRlbGV0ZSBwbGFuXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gY29uc3QgaGFuZGxlUGxhblVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgLy8gICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgLy8gICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAvLyAgIGlmICghdXBkYXRlRm9ybURhdGEucGxhbl9pZCkgbmV3RXJyb3JzLnBsYW5faWQgPSBcIlBsYW4gSUQgaXMgcmVxdWlyZWRcIjtcclxuICAvLyAgIGlmICghdXBkYXRlRm9ybURhdGEucGxhbl9uYW1lKSBuZXdFcnJvcnMucGxhbl9uYW1lID0gXCJQbGFuIE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICAvLyAgIGlmICghdXBkYXRlRm9ybURhdGEucGxhbl9yZWN1cnJpbmdfYW1vdW50IHx8IHVwZGF0ZUZvcm1EYXRhLnBsYW5fcmVjdXJyaW5nX2Ftb3VudCA8PSAwKVxyXG4gIC8vICAgICBuZXdFcnJvcnMucGxhbl9yZWN1cnJpbmdfYW1vdW50ID0gXCJSZWN1cnJpbmcgYW1vdW50IG11c3QgYmUgcG9zaXRpdmVcIjtcclxuICAvLyAgIGlmICghdXBkYXRlRm9ybURhdGEucGxhbl9tYXhfYW1vdW50IHx8IHVwZGF0ZUZvcm1EYXRhLnBsYW5fbWF4X2Ftb3VudCA8PSAwKVxyXG4gIC8vICAgICBuZXdFcnJvcnMucGxhbl9tYXhfYW1vdW50ID0gXCJNYXggYW1vdW50IG11c3QgYmUgcG9zaXRpdmVcIjtcclxuICAvLyAgIGlmICghdXBkYXRlRm9ybURhdGEucGxhbl9pbnRlcnZhbHMgfHwgdXBkYXRlRm9ybURhdGEucGxhbl9pbnRlcnZhbHMgPD0gMClcclxuICAvLyAgICAgbmV3RXJyb3JzLnBsYW5faW50ZXJ2YWxzID0gXCJJbnRlcnZhbHMgbXVzdCBiZSBwb3NpdGl2ZVwiO1xyXG4gIC8vICAgaWYgKCF1cGRhdGVGb3JtRGF0YS5wbGFuX2ludGVydmFsX3R5cGUpXHJcbiAgLy8gICAgIG5ld0Vycm9ycy5wbGFuX2ludGVydmFsX3R5cGUgPSBcIkludGVydmFsIHR5cGUgaXMgcmVxdWlyZWRcIjtcclxuICAvLyAgIGlmICghdXBkYXRlRm9ybURhdGEucGxhbl9ub3RlKSBuZXdFcnJvcnMucGxhbl9ub3RlID0gXCJQbGFuIG5vdGUgaXMgcmVxdWlyZWRcIjtcclxuICAvLyAgIHNldFBsYW5FcnJvcnMobmV3RXJyb3JzKTtcclxuICAvLyAgIGlmIChPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA+IDApIHJldHVybjtcclxuXHJcbiAgLy8gICB0cnkge1xyXG4gIC8vICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gIC8vICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gIC8vICAgICAgIHBsYW5fcmVjdXJyaW5nX2Ftb3VudDogTnVtYmVyKHVwZGF0ZUZvcm1EYXRhLnBsYW5fcmVjdXJyaW5nX2Ftb3VudCksXHJcbiAgLy8gICAgICAgcGxhbl9tYXhfYW1vdW50OiBOdW1iZXIodXBkYXRlRm9ybURhdGEucGxhbl9tYXhfYW1vdW50KSxcclxuICAvLyAgICAgICBwbGFuX21heF9jeWNsZXM6IE51bWJlcih1cGRhdGVGb3JtRGF0YS5wbGFuX21heF9jeWNsZXMpLFxyXG4gIC8vICAgICAgIHBsYW5faW50ZXJ2YWxzOiBOdW1iZXIodXBkYXRlRm9ybURhdGEucGxhbl9pbnRlcnZhbHMpLFxyXG4gIC8vICAgICB9O1xyXG4gIC8vICAgICBhd2FpdCBhcGkucGF0Y2goYC9jYXNoZnJlZS1zdWJzY3JpcHRpb24vcGxhbnMvJHtjdXJyZW50VXBkYXRlUGxhbi5faWR9YCwgcGF5bG9hZCk7XHJcbiAgLy8gICAgIHNldFNob3dQbGFuVXBkYXRlTW9kYWwoZmFsc2UpO1xyXG4gIC8vICAgICBzZXRQbGFuUmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gIC8vICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgLy8gICAgICAgbWVzc2FnZTogXCJQbGFuIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgLy8gICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgLy8gICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAvLyAgICAgfSk7XHJcbiAgLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4gIC8vICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgcGxhbjpcIiwgZXJyb3IpO1xyXG4gIC8vICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgLy8gICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gdXBkYXRlIHBsYW5cIixcclxuICAvLyAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgLy8gICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAvLyAgICAgfSk7XHJcbiAgLy8gICB9XHJcbiAgLy8gfTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT0gU1VCU0NSSVBUSU9OUyBMT0dJQyA9PT09PT09PT09PT09PT09PT09PVxyXG4gIGNvbnN0IGZvcm1hdERhdGVUaW1lID0gKGlzb1N0cmluZykgPT4ge1xyXG4gICAgaWYgKCFpc29TdHJpbmcpIHJldHVybiBcIlwiO1xyXG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGlzb1N0cmluZyk7XHJcbiAgICBjb25zdCBkYXkgPSBTdHJpbmcoZGF0ZS5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICBjb25zdCBtb250aCA9IFN0cmluZyhkYXRlLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgY29uc3QgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IGhvdXJzID0gU3RyaW5nKGRhdGUuZ2V0SG91cnMoKSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICAgIGNvbnN0IG1pbnV0ZXMgPSBTdHJpbmcoZGF0ZS5nZXRNaW51dGVzKCkpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICByZXR1cm4gYCR7ZGF5fS0ke21vbnRofS0ke3llYXJ9ICR7aG91cnN9OiR7bWludXRlc31gO1xyXG4gIH07XHJcblxyXG4gIC8vIENvbnZlcnQgSVNPIHRvIGRhdGV0aW1lLWxvY2FsIHN0cmluZyBmb3IgaW5wdXRcclxuICBjb25zdCBpc29Ub0RhdGV0aW1lTG9jYWwgPSAoaXNvU3RyaW5nKSA9PiB7XHJcbiAgICBpZiAoIWlzb1N0cmluZykgcmV0dXJuIFwiXCI7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoaXNvU3RyaW5nKTtcclxuICAgIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtb250aCA9IFN0cmluZyhkYXRlLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgY29uc3QgZGF5ID0gU3RyaW5nKGRhdGUuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgY29uc3QgaG91cnMgPSBTdHJpbmcoZGF0ZS5nZXRIb3VycygpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgY29uc3QgbWludXRlcyA9IFN0cmluZyhkYXRlLmdldE1pbnV0ZXMoKSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1UJHtob3Vyc306JHttaW51dGVzfWA7XHJcbiAgfTtcclxuXHJcbiAgLy8gTkVXOiBPcGVuIGVkaXQgc3Vic2NyaXB0aW9uIG1vZGFsXHJcbiAgY29uc3QgaGFuZGxlU3ViRWRpdE1vZGFsT3BlbiA9IGFzeW5jIChzdWJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvY2FzaGZyZWUtc3Vic2NyaXB0aW9uL3N1YnNjcmlwdGlvbi8ke3N1YklkfWApO1xyXG4gICAgICBjb25zdCBzdWJEYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhO1xyXG4gICAgICBzZXRDdXJyZW50RWRpdFN1YihzdWJEYXRhKTtcclxuICAgICAgc2V0RWRpdE1vZGFsTG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0U2hvd1N1YkVkaXRNb2RhbCh0cnVlKTtcclxuICAgICAgY29uc3QgdGFncyA9IHN1YkRhdGEuc3Vic2NyaXB0aW9uX3RhZ3MgfHwge307XHJcbiAgICAgIGxldCBwYXlUeXBlID0gdGFncy5wYXlfdHlwZSB8fCBcIkNISVRcIjtcclxuICAgICAgbGV0IGdyb3VwSWQgPSB0YWdzLmdyb3VwX2lkPy5faWQgfHwgdGFncy5ncm91cF9pZCB8fCBcIlwiO1xyXG4gICAgICBsZXQgdGlja2V0ID0gdGFncy50aWNrZXQgfHwgXCJcIjtcclxuICAgICAgbGV0IHBpZ21lSWQgPSB0YWdzLnBpZ21lX2lkPy5waWdtZV9pZCB8fCBcIlwiO1xyXG4gICAgICBsZXQgbG9hbklkID0gdGFncy5sb2FuX2lkPy5sb2FuX2lkIHx8IFwiXCI7XHJcblxyXG4gICAgICBzZXRFZGl0U3ViVGFncyh7IHBheV90eXBlOiBwYXlUeXBlLCBncm91cF9pZDogZ3JvdXBJZCwgdGlja2V0LCBwaWdtZV9pZDogcGlnbWVJZCwgbG9hbl9pZDogbG9hbklkIH0pO1xyXG5cclxuICAgICAgLy8gRGVyaXZlIGNvbWJvIHZhbHVlIGZvciB0aGUgc2VsZWN0XHJcbiAgICAgIGlmIChwYXlUeXBlID09PSBcIkNISVRcIiAmJiBncm91cElkKSB7XHJcbiAgICAgICAgc2V0RWRpdEdyb3VwVGlja2V0VmFsdWUoYGNoaXR8JHtncm91cElkfXwke3RpY2tldH1gKTtcclxuICAgICAgfSBlbHNlIGlmIChwYXlUeXBlID09PSBcIlBpZ21lXCIgJiYgcGlnbWVJZCkge1xyXG4gICAgICAgIHNldEVkaXRHcm91cFRpY2tldFZhbHVlKGBwaWdtZXwke3BpZ21lSWR9YCk7XHJcbiAgICAgIH0gZWxzZSBpZiAocGF5VHlwZSA9PT0gXCJMb2FuXCIgJiYgbG9hbklkKSB7XHJcbiAgICAgICAgc2V0RWRpdEdyb3VwVGlja2V0VmFsdWUoYGxvYW58JHtsb2FuSWR9YCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0RWRpdEdyb3VwVGlja2V0VmFsdWUobnVsbCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIEZldGNoIGVucm9sbG1lbnRzL3BpZ21lL2JvcnJvd2VycyBmb3IgdGhlIHVzZXJcclxuICAgICAgY29uc3QgdXNlcklkID0gdGFncy51c2VyX2lkPy5faWQgfHwgdGFncy51c2VyX2lkIHx8IFwiXCI7XHJcbiAgICAgIGlmICh1c2VySWQpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgZW5yb2xsUmVzcCA9IGF3YWl0IGFwaS5wb3N0KGAvZW5yb2xsL2dldC11c2VyLXRpY2tldHMtcmVwb3J0LyR7dXNlcklkfWApO1xyXG4gICAgICAgICAgY29uc3QgdmFsaWRFbnJvbGxtZW50cyA9IChlbnJvbGxSZXNwLmRhdGEgfHwgW10pLmZpbHRlcihcclxuICAgICAgICAgICAgKGF1Y3Rpb24pID0+IGF1Y3Rpb24uZW5yb2xsbWVudCAmJiBhdWN0aW9uLmVucm9sbG1lbnQuZ3JvdXBcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBzZXRFZGl0RmlsdGVyZWRFbnJvbGxtZW50cyh2YWxpZEVucm9sbG1lbnRzKTtcclxuICAgICAgICB9IGNhdGNoIHsgc2V0RWRpdEZpbHRlcmVkRW5yb2xsbWVudHMoW10pOyB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBwaWdtZVJlc3AgPSBhd2FpdCBhcGkuZ2V0KGAvcGlnbWUvZ2V0LXBpZ21lLWN1c3RvbWVyLWJ5LXVzZXItaWQvJHt1c2VySWR9YCk7XHJcbiAgICAgICAgICBzZXRFZGl0UGlnbWVDdXN0b21lcnMocGlnbWVSZXNwLmRhdGEgfHwgW10pO1xyXG4gICAgICAgIH0gY2F0Y2ggeyBzZXRFZGl0UGlnbWVDdXN0b21lcnMoW10pOyB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBsb2FuUmVzcCA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9sb2Fucy9ib3Jyb3dlcnMvJHt1c2VySWR9YCk7XHJcbiAgICAgICAgICBzZXRFZGl0Qm9ycm93ZXJzKGxvYW5SZXNwLmRhdGE/LmRhdGEgfHwgW10pO1xyXG4gICAgICAgIH0gY2F0Y2ggeyBzZXRFZGl0Qm9ycm93ZXJzKFtdKTsgfVxyXG4gICAgICB9XHJcblxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHN1YnNjcmlwdGlvbiBmb3IgZWRpdDpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7IHZpc2liaWxpdHk6IHRydWUsIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIHN1YnNjcmlwdGlvbiBkZXRhaWxzXCIsIHR5cGU6IFwiZXJyb3JcIiB9KTtcclxuICAgIH1cclxuICAgIGZpbmFsbHkge1xyXG4gICAgICBzZXRFZGl0TW9kYWxMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFZGl0R3JvdXBUaWNrZXRTZWxlY3QgPSAodmFsdWUpID0+IHtcclxuICAgIHNldEVkaXRHcm91cFRpY2tldFZhbHVlKHZhbHVlKTtcclxuICAgIGlmICghdmFsdWUpIHtcclxuICAgICAgc2V0RWRpdFN1YlRhZ3MocHJldiA9PiAoeyAuLi5wcmV2LCBncm91cF9pZDogXCJcIiwgdGlja2V0OiBcIlwiLCBwaWdtZV9pZDogXCJcIiwgbG9hbl9pZDogXCJcIiwgcGF5X3R5cGU6IFwiQ0hJVFwiIH0pKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgY29uc3QgW3R5cGUsIGlkLCB0aWNrZXRdID0gdmFsdWUuc3BsaXQoJ3wnKTtcclxuICAgIGlmICh0eXBlID09PSAnY2hpdCcpIHtcclxuICAgICAgc2V0RWRpdFN1YlRhZ3MoeyBwYXlfdHlwZTogXCJDSElUXCIsIGdyb3VwX2lkOiBpZCwgdGlja2V0LCBwaWdtZV9pZDogXCJcIiwgbG9hbl9pZDogXCJcIiB9KTtcclxuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ3BpZ21lJykge1xyXG4gICAgICBzZXRFZGl0U3ViVGFncyh7IHBheV90eXBlOiBcIlBpZ21lXCIsIGdyb3VwX2lkOiBcIlwiLCB0aWNrZXQ6IFwiXCIsIHBpZ21lX2lkOiBpZCwgbG9hbl9pZDogXCJcIiB9KTtcclxuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ2xvYW4nKSB7XHJcbiAgICAgIHNldEVkaXRTdWJUYWdzKHsgcGF5X3R5cGU6IFwiTG9hblwiLCBncm91cF9pZDogXCJcIiwgdGlja2V0OiBcIlwiLCBwaWdtZV9pZDogXCJcIiwgbG9hbl9pZDogaWQgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3ViRWRpdFN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAoIWN1cnJlbnRFZGl0U3ViKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0geyBwYXlfdHlwZTogZWRpdFN1YlRhZ3MucGF5X3R5cGUgfTtcclxuICAgICAgaWYgKGVkaXRTdWJUYWdzLnBheV90eXBlID09PSBcIkNISVRcIikge1xyXG4gICAgICAgIHBheWxvYWQuZ3JvdXBfaWQgPSBlZGl0U3ViVGFncy5ncm91cF9pZDtcclxuICAgICAgICBwYXlsb2FkLnRpY2tldCA9IGVkaXRTdWJUYWdzLnRpY2tldDtcclxuICAgICAgfSBlbHNlIGlmIChlZGl0U3ViVGFncy5wYXlfdHlwZSA9PT0gXCJQaWdtZVwiKSB7XHJcbiAgICAgICAgcGF5bG9hZC5waWdtZV9pZCA9IGVkaXRTdWJUYWdzLnBpZ21lX2lkO1xyXG4gICAgICB9IGVsc2UgaWYgKGVkaXRTdWJUYWdzLnBheV90eXBlID09PSBcIkxvYW5cIikge1xyXG4gICAgICAgIHBheWxvYWQubG9hbl9pZCA9IGVkaXRTdWJUYWdzLmxvYW5faWQ7XHJcbiAgICAgIH1cclxuICAgICAgYXdhaXQgYXBpLnBhdGNoKGAvY2FzaGZyZWUtc3Vic2NyaXB0aW9uL3N1YnNjcmlwdGlvbi8ke2N1cnJlbnRFZGl0U3ViLl9pZH1gLCBwYXlsb2FkKTtcclxuICAgICAgc2V0U3ViUmVsb2FkVHJpZ2dlcihwcmV2ID0+IHByZXYgKyAxKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoeyB2aXNpYmlsaXR5OiB0cnVlLCBtZXNzYWdlOiBcIlN1YnNjcmlwdGlvbiB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiLCB0eXBlOiBcInN1Y2Nlc3NcIiB9KTtcclxuICAgICAgc2V0U2hvd1N1YkVkaXRNb2RhbChmYWxzZSk7XHJcbiAgICAgIHNldEN1cnJlbnRFZGl0U3ViKG51bGwpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHN1YnNjcmlwdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byB1cGRhdGUgc3Vic2NyaXB0aW9uXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBGZXRjaCBzdWJzY3JpcHRpb25zXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoU3Vic2NyaXB0aW9ucyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRTdWJJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2Nhc2hmcmVlLXN1YnNjcmlwdGlvbi9zdWJzY3JpcHRpb25cIik7XHJcbiAgICAgICAgbGV0IHN1YnNEYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhIHx8IFtdO1xyXG4gICAgICAgIHN1YnNEYXRhLnNvcnQoKGEsIGIpID0+IG5ldyBEYXRlKGIuc3Vic2NyaXB0aW9uX2ZpcnN0X2NoYXJnZV90aW1lKSAtIG5ldyBEYXRlKGEuc3Vic2NyaXB0aW9uX2ZpcnN0X2NoYXJnZV90aW1lKSk7XHJcbiAgICAgICAgc2V0U3Vic2NyaXB0aW9ucyhzdWJzRGF0YSk7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHN1YnNEYXRhLm1hcCgoc3ViLCBpbmRleCkgPT4ge1xyXG5cclxuICAgICAgICAgIGNvbnN0IGdldFN0YXR1c0Rpc3BsYXkgPSAoc3RhdHVzKSA9PiB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoc3RhdHVzPy50b1VwcGVyQ2FzZSgpKSB7XHJcbiAgICAgICAgICAgICAgY2FzZSBcIkFDVElWRVwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgaWNvbjogPENoZWNrQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi01MDAgdGV4dC1iYXNlXCIgLz4sIGNvbG9yOiBcInRleHQtZ3JlZW4tNzAwXCIsIGJnOiBcImJnLWdyZWVuLTEwMFwiLCBsYWJlbDogXCJBY3RpdmVcIiB9O1xyXG4gICAgICAgICAgICAgIGNhc2UgXCJJTklUSUFMSVpFRFwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgaWNvbjogPFN5bmNPdXRsaW5lZCBzcGluIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgdGV4dC1iYXNlXCIgLz4sIGNvbG9yOiBcInRleHQtYmx1ZS03MDBcIiwgYmc6IFwiYmctYmx1ZS0xMDBcIiwgbGFiZWw6IFwiSW5pdGlhbGl6ZWRcIiB9O1xyXG4gICAgICAgICAgICAgIGNhc2UgXCJDQU5DRUxMRURcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybiB7IGljb246IDxDbG9zZUNpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LWJhc2VcIiAvPiwgY29sb3I6IFwidGV4dC1yZWQtNzAwXCIsIGJnOiBcImJnLXJlZC0xMDBcIiwgbGFiZWw6IFwiQ2FuY2VsbGVkXCIgfTtcclxuICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgaWNvbjogPENsb3NlQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LWJhc2VcIiAvPiwgY29sb3I6IFwidGV4dC1ncmF5LTYwMFwiLCBiZzogXCJiZy1ncmF5LTEwMFwiLCBsYWJlbDogc3RhdHVzIHx8IFwiVW5rbm93blwiIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgY29uc3Qgc3RhdHVzRGlzcGxheSA9IGdldFN0YXR1c0Rpc3BsYXkoc3ViLnN1YnNjcmlwdGlvbl9zdGF0dXMpO1xyXG5cclxuICAgICAgICAgIGNvbnN0IGdldEdyb3VwRGV0YWlscyA9IHN1Yi5zdWJzY3JpcHRpb25fdGFncz8ubG9hbl9pZD8ubG9hbl9pZFxyXG4gICAgICAgICAgICB8fCAoc3ViLnN1YnNjcmlwdGlvbl90YWdzPy5ncm91cF9pZFxyXG4gICAgICAgICAgICAgID8gYCR7c3ViLnN1YnNjcmlwdGlvbl90YWdzLmdyb3VwX2lkLmdyb3VwX25hbWUgfHwgXCJHcm91cFwifSB8IFRpY2tldDogJHtzdWIuc3Vic2NyaXB0aW9uX3RhZ3MudGlja2V0IHx8IFwiP1wifWBcclxuICAgICAgICAgICAgICA6IHN1Yi5zdWJzY3JpcHRpb25fdGFncz8ucGlnbWVfaWQ/LnBpZ21lX2lkIHx8IFwi4oCUXCIpO1xyXG5cclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIF9pZDogc3ViLl9pZCxcclxuICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgc3Vic2NyaXB0aW9uX2lkOiBzdWIuc3Vic2NyaXB0aW9uX2lkLFxyXG4gICAgICAgICAgICBjdXN0b21lcl9uYW1lOiBzdWIuY3VzdG9tZXJfZGV0YWlscz8uY3VzdG9tZXJfbmFtZSxcclxuICAgICAgICAgICAgY3VzdG9tZXJfZW1haWw6IHN1Yi5jdXN0b21lcl9kZXRhaWxzPy5jdXN0b21lcl9lbWFpbCxcclxuICAgICAgICAgICAgY3VzdG9tZXJfcGhvbmU6IHN1Yi5jdXN0b21lcl9kZXRhaWxzPy5jdXN0b21lcl9waG9uZSxcclxuICAgICAgICAgICAgcGxhbl9pZDogc3ViLnBsYW5fZGV0YWlscz8ucGxhbl9pZCxcclxuICAgICAgICAgICAgZXhwaXJ5X3RpbWU6IGZvcm1hdERhdGVUaW1lKHN1Yi5zdWJzY3JpcHRpb25fZXhwaXJ5X3RpbWUpLFxyXG4gICAgICAgICAgICBmaXJzdF9jaGFyZ2VfdGltZTogZm9ybWF0RGF0ZVRpbWUoc3ViLnN1YnNjcmlwdGlvbl9maXJzdF9jaGFyZ2VfdGltZSksXHJcbiAgICAgICAgICAgIG5vdGlmaWNhdGlvbl9jaGFubmVsOiBzdWIuc3Vic2NyaXB0aW9uX21ldGE/Lm5vdGlmaWNhdGlvbl9jaGFubmVsPy5qb2luKFwiLCBcIiksXHJcbiAgICAgICAgICAgIGF1dGhvcml6YXRpb25fYW1vdW50OiBzdWIuYXV0aG9yaXphdGlvbl9kZXRhaWxzPy5hdXRob3JpemF0aW9uX2Ftb3VudCxcclxuICAgICAgICAgICAgcmVmdW5kOiBzdWIuYXV0aG9yaXphdGlvbl9kZXRhaWxzPy5hdXRob3JpemF0aW9uX2Ftb3VudF9yZWZ1bmQgPyBcIlllc1wiIDogXCJOb1wiLFxyXG4gICAgICAgICAgICBwYXltZW50X21ldGhvZHM6IHN1Yi5hdXRob3JpemF0aW9uX2RldGFpbHM/LnBheW1lbnRfbWV0aG9kcz8uam9pbihcIiwgXCIpLFxyXG4gICAgICAgICAgICB1c2VyX2lkOiBzdWIuc3Vic2NyaXB0aW9uX3RhZ3M/LnVzZXJfaWQsXHJcbiAgICAgICAgICAgIHBheV90eXBlOiBzdWIuc3Vic2NyaXB0aW9uX3RhZ3M/LnBheV90eXBlLFxyXG4gICAgICAgICAgICBncm91cF9pZDogZ2V0R3JvdXBEZXRhaWxzLFxyXG4gICAgICAgICAgICB0aWNrZXQ6IHN1Yi5zdWJzY3JpcHRpb25fdGFncz8udGlja2V0LFxyXG4gICAgICAgICAgICBTdGF0dXM6IHN1Yi5zdWJzY3JpcHRpb25fc3RhdHVzLFxyXG4gICAgICAgICAgICBzdGF0dXM6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1tZWRpdW0gJHtzdGF0dXNEaXNwbGF5LmJnfSAke3N0YXR1c0Rpc3BsYXkuY29sb3J9YH0+XHJcbiAgICAgICAgICAgICAgICB7c3RhdHVzRGlzcGxheS5pY29ufVxyXG4gICAgICAgICAgICAgICAgPHNwYW4+e3N0YXR1c0Rpc3BsYXkubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IG9uQ2xpY2s9eygpID0+IGhhbmRsZVN1YkVkaXRNb2RhbE9wZW4oc3ViLl9pZCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU3ViRGVsZXRlTW9kYWxPcGVuKHN1Yi5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZCBjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRUYWJsZVN1YnNjcmlwdGlvbnMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHN1YnNjcmlwdGlvbnM6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7IHZpc2liaWxpdHk6IHRydWUsIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIHN1YnNjcmlwdGlvbnNcIiwgdHlwZTogXCJlcnJvclwiIH0pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldFN1YklzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFN1YnNjcmlwdGlvbnMoKTtcclxuICB9LCBbc3ViUmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICAvLyBGZXRjaCBwbGFucyBmb3Igc3Vic2NyaXB0aW9uIGRyb3Bkb3duXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUGxhbnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2Nhc2hmcmVlLXN1YnNjcmlwdGlvbi9wbGFuc1wiKTtcclxuICAgICAgICBjb25zdCBwbGFuc0RhdGEgPSByZXNwb25zZS5kYXRhPy5kYXRhIHx8IHJlc3BvbnNlLmRhdGEgfHwgW107XHJcbiAgICAgICAgc2V0UGxhbnNGb3JEcm9wZG93bihwbGFuc0RhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwbGFuczpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hQbGFucygpO1xyXG4gIH0sIFtwbGFuUmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICAvLyBGZXRjaCB1c2Vyc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyczpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hVc2VycygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gU2V0IG1pbiBkYXRldGltZSBmb3Igc3Vic2NyaXB0aW9uIGZvcm1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IHRvbW9ycm93ID0gbmV3IERhdGUobm93KTtcclxuICAgIHRvbW9ycm93LnNldERhdGUobm93LmdldERhdGUoKSArIDEpO1xyXG4gICAgdG9tb3Jyb3cuc2V0SG91cnMoMCwgMCwgMCwgMCk7XHJcbiAgICBjb25zdCB5ZWFyID0gdG9tb3Jyb3cuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKHRvbW9ycm93LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgY29uc3QgZGF5ID0gU3RyaW5nKHRvbW9ycm93LmdldERhdGUoKSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICAgIGNvbnN0IG1pbkRhdGVUaW1lID0gYCR7eWVhcn0tJHttb250aH0tJHtkYXl9VDAwOjAwYDtcclxuICAgIHNldEZpcnN0Q2hhcmdlVGltZU1pbihtaW5EYXRlVGltZSk7XHJcbiAgICBzZXRFeHBpcnlUaW1lTWluKG1pbkRhdGVUaW1lKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc3ViRm9ybURhdGEuc3Vic2NyaXB0aW9uX2ZpcnN0X2NoYXJnZV90aW1lKSB7XHJcbiAgICAgIHNldEV4cGlyeVRpbWVNaW4oc3ViRm9ybURhdGEuc3Vic2NyaXB0aW9uX2ZpcnN0X2NoYXJnZV90aW1lKTtcclxuICAgICAgaWYgKHN1YkZvcm1EYXRhLnN1YnNjcmlwdGlvbl9leHBpcnlfdGltZSAmJiBzdWJGb3JtRGF0YS5zdWJzY3JpcHRpb25fZXhwaXJ5X3RpbWUgPD0gc3ViRm9ybURhdGEuc3Vic2NyaXB0aW9uX2ZpcnN0X2NoYXJnZV90aW1lKSB7XHJcbiAgICAgICAgc2V0U3ViRm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBzdWJzY3JpcHRpb25fZXhwaXJ5X3RpbWU6IFwiXCIgfSkpO1xyXG4gICAgICAgIHNldFN1YkVycm9ycyhwcmV2ID0+ICh7IC4uLnByZXYsIHN1YnNjcmlwdGlvbl9leHBpcnlfdGltZTogXCJFeHBpcnkgdGltZSBtdXN0IGJlIGdyZWF0ZXIgdGhhbiBmaXJzdCBjaGFyZ2UgdGltZVwiIH0pKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICAgICAgY29uc3QgdG9tb3Jyb3cgPSBuZXcgRGF0ZShub3cpO1xyXG4gICAgICB0b21vcnJvdy5zZXREYXRlKG5vdy5nZXREYXRlKCkgKyAxKTtcclxuICAgICAgY29uc3QgeWVhciA9IHRvbW9ycm93LmdldEZ1bGxZZWFyKCk7XHJcbiAgICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKHRvbW9ycm93LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgICBjb25zdCBkYXkgPSBTdHJpbmcodG9tb3Jyb3cuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgICBzZXRFeHBpcnlUaW1lTWluKGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fVQwMDowMGApO1xyXG4gICAgfVxyXG4gIH0sIFtzdWJGb3JtRGF0YS5zdWJzY3JpcHRpb25fZmlyc3RfY2hhcmdlX3RpbWVdKTtcclxuXHJcbiAgLy8gRmV0Y2ggYm9ycm93ZXJzIGFuZCBwaWdtZSBjdXN0b21lcnMgYmFzZWQgb24gc2VsZWN0ZWQgdXNlclxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkVXNlcklkKSByZXR1cm47XHJcbiAgICBjb25zdCBmZXRjaEJvcnJvd2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9sb2Fucy9ib3Jyb3dlcnMvJHtzZWxlY3RlZFVzZXJJZH1gKTtcclxuICAgICAgICBzZXRCb3Jyb3dlcnMocmVzcG9uc2UuZGF0YS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgc2V0Qm9ycm93ZXJzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGNvbnN0IGZldGNoUGlnbWUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGlnbWUvZ2V0LXBpZ21lLWN1c3RvbWVyLWJ5LXVzZXItaWQvJHtzZWxlY3RlZFVzZXJJZH1gKTtcclxuICAgICAgICBzZXRQaWdtZUN1c3RvbWVycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgc2V0UGlnbWVDdXN0b21lcnMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hCb3Jyb3dlcnMoKTtcclxuICAgIGZldGNoUGlnbWUoKTtcclxuICB9LCBbc2VsZWN0ZWRVc2VySWRdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgaWYgKCF1c2VySWQpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoYC9lbnJvbGwvZ2V0LXVzZXItdGlja2V0cy1yZXBvcnQvJHt1c2VySWR9YCk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIGNvbnN0IHZhbGlkRW5yb2xsbWVudHMgPSByZXNwb25zZS5kYXRhLmZpbHRlcihcclxuICAgICAgICAgIChhdWN0aW9uKSA9PiBhdWN0aW9uLmVucm9sbG1lbnQgJiYgYXVjdGlvbi5lbnJvbGxtZW50Lmdyb3VwXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKHZhbGlkRW5yb2xsbWVudHMpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEZpbHRlcmVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUN1c3RvbWVyU2VsZWN0ID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRVc2VySWQodXNlcklkKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkVXNlciA9IHVzZXJzLmZpbmQodXNlciA9PiB1c2VyLl9pZCA9PT0gdXNlcklkKTtcclxuICAgIGlmIChzZWxlY3RlZFVzZXIpIHtcclxuICAgICAgc2V0U3ViRm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgY3VzdG9tZXJfZGV0YWlsczoge1xyXG4gICAgICAgICAgY3VzdG9tZXJfbmFtZTogc2VsZWN0ZWRVc2VyLmZ1bGxfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJfZW1haWw6IHNlbGVjdGVkVXNlci5lbWFpbCB8fCBcIlwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJfcGhvbmU6IHNlbGVjdGVkVXNlci5waG9uZV9udW1iZXIgfHwgXCJcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHN1YnNjcmlwdGlvbl90YWdzOiB7IC4uLnByZXYuc3Vic2NyaXB0aW9uX3RhZ3MsIHVzZXJfaWQ6IHVzZXJJZCB9XHJcbiAgICAgIH0pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldFN1YkZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHN1YnNjcmlwdGlvbl90YWdzOiB7IC4uLnByZXYuc3Vic2NyaXB0aW9uX3RhZ3MsIHVzZXJfaWQ6IHVzZXJJZCB9XHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICAgIHNldFN1YkVycm9ycyhwcmV2ID0+ICh7IC4uLnByZXYsIGN1c3RvbWVyOiBcIlwiIH0pKTtcclxuICAgIHNldFNlbGVjdGVkR3JvdXBUaWNrZXRWYWx1ZShudWxsKTtcclxuICAgIGF3YWl0IGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSh1c2VySWQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwVGlja2V0U2VsZWN0ID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwVGlja2V0VmFsdWUodmFsdWUpO1xyXG4gICAgaWYgKCF2YWx1ZSkge1xyXG4gICAgICBzZXRTdWJGb3JtRGF0YShwcmV2ID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBzdWJzY3JpcHRpb25fdGFnczogeyAuLi5wcmV2LnN1YnNjcmlwdGlvbl90YWdzLCBncm91cF9pZDogXCJcIiwgdGlja2V0OiBcIlwiLCBwYXlfdHlwZTogXCJDSElUXCIgfVxyXG4gICAgICB9KSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IFt0eXBlLCBpZCwgdGlja2V0XSA9IHZhbHVlLnNwbGl0KCd8Jyk7XHJcbiAgICBpZiAodHlwZSA9PT0gJ2NoaXQnKSB7XHJcbiAgICAgIHNldFN1YkZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHN1YnNjcmlwdGlvbl90YWdzOiB7IC4uLnByZXYuc3Vic2NyaXB0aW9uX3RhZ3MsIGdyb3VwX2lkOiBpZCwgdGlja2V0LCBwYXlfdHlwZTogXCJDSElUXCIgfVxyXG4gICAgICB9KSk7XHJcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdwaWdtZScpIHtcclxuICAgICAgc2V0U3ViRm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgc3Vic2NyaXB0aW9uX3RhZ3M6IHsgLi4ucHJldi5zdWJzY3JpcHRpb25fdGFncywgcGlnbWVfaWQ6IGlkLCBwYXlfdHlwZTogXCJQaWdtZVwiIH1cclxuICAgICAgfSkpO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlID09PSAnbG9hbicpIHtcclxuICAgICAgc2V0U3ViRm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgc3Vic2NyaXB0aW9uX3RhZ3M6IHsgLi4ucHJldi5zdWJzY3JpcHRpb25fdGFncywgbG9hbl9pZDogaWQsIHBheV90eXBlOiBcIkxvYW5cIiB9XHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJOZXN0ZWRDaGFuZ2UgPSAoc2VjdGlvbiwgZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRTdWJGb3JtRGF0YShwcmV2ID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFtzZWN0aW9uXTogeyAuLi5wcmV2W3NlY3Rpb25dLCBbZmllbGRdOiB2YWx1ZSB9XHJcbiAgICB9KSk7XHJcbiAgICBzZXRTdWJFcnJvcnMocHJldiA9PiAoeyAuLi5wcmV2LCBbYCR7c2VjdGlvbn0uJHtmaWVsZH1gXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3ViQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U3ViRm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IHZhbHVlIH0pKTtcclxuICAgIHNldFN1YkVycm9ycyhwcmV2ID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29udmVydFRvSVNPV2l0aE9mZnNldCA9IChkYXRldGltZUxvY2FsKSA9PiB7XHJcbiAgICBpZiAoIWRhdGV0aW1lTG9jYWwpIHJldHVybiBcIlwiO1xyXG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGV0aW1lTG9jYWwpO1xyXG4gICAgY29uc3QgdHpPZmZzZXQgPSAtZGF0ZS5nZXRUaW1lem9uZU9mZnNldCgpO1xyXG4gICAgY29uc3Qgc2lnbiA9IHR6T2Zmc2V0ID49IDAgPyBcIitcIiA6IFwiLVwiO1xyXG4gICAgY29uc3QgaG91cnMgPSBTdHJpbmcoTWF0aC5mbG9vcihNYXRoLmFicyh0ek9mZnNldCkgLyA2MCkpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgIGNvbnN0IG1pbnV0ZXMgPSBTdHJpbmcoTWF0aC5hYnModHpPZmZzZXQpICUgNjApLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgIHJldHVybiBkYXRlLnRvSVNPU3RyaW5nKCkucmVwbGFjZShcIlpcIiwgYCR7c2lnbn0ke2hvdXJzfToke21pbnV0ZXN9YCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVTdWJGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbiAgICBpZiAoIXNlbGVjdGVkVXNlcklkKSBuZXdFcnJvcnMuY3VzdG9tZXIgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4gICAgaWYgKCFzZWxlY3RlZEdyb3VwVGlja2V0VmFsdWUpIG5ld0Vycm9ycy5ncm91cCA9IFwiUGxlYXNlIHNlbGVjdCBhIGdyb3VwIGFuZCB0aWNrZXRcIjtcclxuICAgIGlmICghc3ViRm9ybURhdGEuc3Vic2NyaXB0aW9uX2lkKSBuZXdFcnJvcnMuc3Vic2NyaXB0aW9uX2lkID0gXCJTdWJzY3JpcHRpb24gSUQgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghc3ViRm9ybURhdGEucGxhbl9kZXRhaWxzLnBsYW5faWQpIG5ld0Vycm9yc1tcInBsYW5fZGV0YWlscy5wbGFuX2lkXCJdID0gXCJQbGFuIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBpZiAoIXN1YkZvcm1EYXRhLnN1YnNjcmlwdGlvbl9leHBpcnlfdGltZSkgbmV3RXJyb3JzLnN1YnNjcmlwdGlvbl9leHBpcnlfdGltZSA9IFwiRXhwaXJ5IHRpbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghc3ViRm9ybURhdGEuc3Vic2NyaXB0aW9uX2ZpcnN0X2NoYXJnZV90aW1lKSBuZXdFcnJvcnMuc3Vic2NyaXB0aW9uX2ZpcnN0X2NoYXJnZV90aW1lID0gXCJGaXJzdCBjaGFyZ2UgdGltZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgaWYgKHN1YkZvcm1EYXRhLnN1YnNjcmlwdGlvbl9leHBpcnlfdGltZSAmJiBzdWJGb3JtRGF0YS5zdWJzY3JpcHRpb25fZmlyc3RfY2hhcmdlX3RpbWUgJiZcclxuICAgICAgc3ViRm9ybURhdGEuc3Vic2NyaXB0aW9uX2V4cGlyeV90aW1lIDw9IHN1YkZvcm1EYXRhLnN1YnNjcmlwdGlvbl9maXJzdF9jaGFyZ2VfdGltZSkge1xyXG4gICAgICBuZXdFcnJvcnMuc3Vic2NyaXB0aW9uX2V4cGlyeV90aW1lID0gXCJFeHBpcnkgdGltZSBtdXN0IGJlIGdyZWF0ZXIgdGhhbiBmaXJzdCBjaGFyZ2UgdGltZVwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFzdWJGb3JtRGF0YS5hdXRob3JpemF0aW9uX2RldGFpbHMuYXV0aG9yaXphdGlvbl9hbW91bnQgfHwgc3ViRm9ybURhdGEuYXV0aG9yaXphdGlvbl9kZXRhaWxzLmF1dGhvcml6YXRpb25fYW1vdW50IDw9IDApXHJcbiAgICAgIG5ld0Vycm9yc1tcImF1dGhvcml6YXRpb25fZGV0YWlscy5hdXRob3JpemF0aW9uX2Ftb3VudFwiXSA9IFwiQXV0aG9yaXphdGlvbiBhbW91bnQgbXVzdCBiZSBwb3NpdGl2ZVwiO1xyXG4gICAgc2V0U3ViRXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3ViU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGVTdWJGb3JtKCkpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCBzdWJzY3JpcHRpb25UYWdzID0geyB1c2VyX2lkOiBzZWxlY3RlZFVzZXJJZCwgcGF5X3R5cGU6IHN1YkZvcm1EYXRhLnN1YnNjcmlwdGlvbl90YWdzLnBheV90eXBlIH07XHJcbiAgICAgIGlmIChzdWJzY3JpcHRpb25UYWdzLnBheV90eXBlID09PSBcIkNISVRcIikge1xyXG4gICAgICAgIHN1YnNjcmlwdGlvblRhZ3MuZ3JvdXBfaWQgPSBzdWJGb3JtRGF0YS5zdWJzY3JpcHRpb25fdGFncy5ncm91cF9pZDtcclxuICAgICAgICBzdWJzY3JpcHRpb25UYWdzLnRpY2tldCA9IHN1YkZvcm1EYXRhLnN1YnNjcmlwdGlvbl90YWdzLnRpY2tldDtcclxuICAgICAgfSBlbHNlIGlmIChzdWJzY3JpcHRpb25UYWdzLnBheV90eXBlID09PSBcIlBpZ21lXCIpIHtcclxuICAgICAgICBzdWJzY3JpcHRpb25UYWdzLnBpZ21lX2lkID0gc3ViRm9ybURhdGEuc3Vic2NyaXB0aW9uX3RhZ3MucGlnbWVfaWQ7XHJcbiAgICAgIH0gZWxzZSBpZiAoc3Vic2NyaXB0aW9uVGFncy5wYXlfdHlwZSA9PT0gXCJMb2FuXCIpIHtcclxuICAgICAgICBzdWJzY3JpcHRpb25UYWdzLmxvYW5faWQgPSBzdWJGb3JtRGF0YS5zdWJzY3JpcHRpb25fdGFncy5sb2FuX2lkO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgc3Vic2NyaXB0aW9uX2lkOiBzdWJGb3JtRGF0YS5zdWJzY3JpcHRpb25faWQsXHJcbiAgICAgICAgY3VzdG9tZXJfZGV0YWlsczoge1xyXG4gICAgICAgICAgY3VzdG9tZXJfbmFtZTogc3ViRm9ybURhdGEuY3VzdG9tZXJfZGV0YWlscy5jdXN0b21lcl9uYW1lLFxyXG4gICAgICAgICAgY3VzdG9tZXJfZW1haWw6IHN1YkZvcm1EYXRhLmN1c3RvbWVyX2RldGFpbHMuY3VzdG9tZXJfZW1haWwgfHwgXCJhZG1pbkBteWNoaXRzLmNvLmluXCIsXHJcbiAgICAgICAgICBjdXN0b21lcl9waG9uZTogc3ViRm9ybURhdGEuY3VzdG9tZXJfZGV0YWlscy5jdXN0b21lcl9waG9uZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHBsYW5fZGV0YWlsczogeyBwbGFuX2lkOiBzdWJGb3JtRGF0YS5wbGFuX2RldGFpbHMucGxhbl9pZCB9LFxyXG4gICAgICAgIHN1YnNjcmlwdGlvbl9leHBpcnlfdGltZTogY29udmVydFRvSVNPV2l0aE9mZnNldChzdWJGb3JtRGF0YS5zdWJzY3JpcHRpb25fZXhwaXJ5X3RpbWUpLFxyXG4gICAgICAgIHN1YnNjcmlwdGlvbl9maXJzdF9jaGFyZ2VfdGltZTogY29udmVydFRvSVNPV2l0aE9mZnNldChzdWJGb3JtRGF0YS5zdWJzY3JpcHRpb25fZmlyc3RfY2hhcmdlX3RpbWUpLFxyXG4gICAgICAgIHN1YnNjcmlwdGlvbl9tZXRhOiB7IG5vdGlmaWNhdGlvbl9jaGFubmVsOiBbXCJTTVNcIl0gfSxcclxuICAgICAgICBhdXRob3JpemF0aW9uX2RldGFpbHM6IHtcclxuICAgICAgICAgIGF1dGhvcml6YXRpb25fYW1vdW50OiBOdW1iZXIoc3ViRm9ybURhdGEuYXV0aG9yaXphdGlvbl9kZXRhaWxzLmF1dGhvcml6YXRpb25fYW1vdW50KSxcclxuICAgICAgICAgIGF1dGhvcml6YXRpb25fYW1vdW50X3JlZnVuZDogc3ViRm9ybURhdGEuYXV0aG9yaXphdGlvbl9kZXRhaWxzLmF1dGhvcml6YXRpb25fYW1vdW50X3JlZnVuZCxcclxuICAgICAgICAgIHBheW1lbnRfbWV0aG9kczogc3ViRm9ybURhdGEuYXV0aG9yaXphdGlvbl9kZXRhaWxzLnBheW1lbnRfbWV0aG9kcyxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHN1YnNjcmlwdGlvbl90YWdzOiBzdWJzY3JpcHRpb25UYWdzLFxyXG4gICAgICB9O1xyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi9jYXNoZnJlZS1zdWJzY3JpcHRpb24vc3Vic2NyaXB0aW9uXCIsIHBheWxvYWQpO1xyXG4gICAgICBzZXRTdWJSZWxvYWRUcmlnZ2VyKHByZXYgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7IHZpc2liaWxpdHk6IHRydWUsIG1lc3NhZ2U6IFwiU3Vic2NyaXB0aW9uIGFkZGVkIHN1Y2Nlc3NmdWxseVwiLCB0eXBlOiBcInN1Y2Nlc3NcIiB9KTtcclxuICAgICAgc2V0U2hvd1N1Yk1vZGFsKGZhbHNlKTtcclxuICAgICAgc2V0U3ViRm9ybURhdGEoe1xyXG4gICAgICAgIHN1YnNjcmlwdGlvbl9pZDogXCJcIixcclxuICAgICAgICBjdXN0b21lcl9kZXRhaWxzOiB7IGN1c3RvbWVyX25hbWU6IFwiXCIsIGN1c3RvbWVyX2VtYWlsOiBcIlwiLCBjdXN0b21lcl9waG9uZTogXCJcIiB9LFxyXG4gICAgICAgIHBsYW5fZGV0YWlsczogeyBwbGFuX2lkOiBcIlwiIH0sXHJcbiAgICAgICAgc3Vic2NyaXB0aW9uX2V4cGlyeV90aW1lOiBcIlwiLFxyXG4gICAgICAgIHN1YnNjcmlwdGlvbl9maXJzdF9jaGFyZ2VfdGltZTogXCJcIixcclxuICAgICAgICBzdWJzY3JpcHRpb25fbWV0YTogeyBub3RpZmljYXRpb25fY2hhbm5lbDogW10gfSxcclxuICAgICAgICBhdXRob3JpemF0aW9uX2RldGFpbHM6IHsgYXV0aG9yaXphdGlvbl9hbW91bnQ6IFwiXCIsIGF1dGhvcml6YXRpb25fYW1vdW50X3JlZnVuZDogdHJ1ZSwgcGF5bWVudF9tZXRob2RzOiBbXCJ1cGlcIl0gfSxcclxuICAgICAgICBzdWJzY3JpcHRpb25fdGFnczogeyB1c2VyX2lkOiBcIlwiLCBwYXlfdHlwZTogXCJDSElUXCIsIGdyb3VwX2lkOiBcIlwiLCB0aWNrZXQ6IFwiXCIgfSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVXNlcklkKFwiXCIpO1xyXG4gICAgICBzZXRTZWxlY3RlZEdyb3VwVGlja2V0VmFsdWUobnVsbCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIHN1YnNjcmlwdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBhZGQgc3Vic2NyaXB0aW9uXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAoc3ViSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2Nhc2hmcmVlLXN1YnNjcmlwdGlvbi9zdWJzY3JpcHRpb24vJHtzdWJJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudFN1YnNjcmlwdGlvbihyZXNwb25zZS5kYXRhPy5kYXRhIHx8IHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93U3ViRGVsZXRlTW9kYWwodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgc3Vic2NyaXB0aW9uOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3ViRGVsZXRlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRTdWJzY3JpcHRpb24pIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvY2FzaGZyZWUtc3Vic2NyaXB0aW9uL3N1YnNjcmlwdGlvbi8ke2N1cnJlbnRTdWJzY3JpcHRpb24uX2lkfWApO1xyXG4gICAgICAgIHNldFN1YlJlbG9hZFRyaWdnZXIocHJldiA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoeyBtZXNzYWdlOiBcIlN1YnNjcmlwdGlvbiBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLCB0eXBlOiBcInN1Y2Nlc3NcIiwgdmlzaWJpbGl0eTogdHJ1ZSB9KTtcclxuICAgICAgICBzZXRTaG93U3ViRGVsZXRlTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHNldEN1cnJlbnRTdWJzY3JpcHRpb24obnVsbCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIHN1YnNjcmlwdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHsgbWVzc2FnZTogXCJGYWlsZWQgdG8gZGVsZXRlIHN1YnNjcmlwdGlvblwiLCB0eXBlOiBcImVycm9yXCIsIHZpc2liaWxpdHk6IHRydWUgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBUYWJsZSBjb2x1bW5zIGZvciBQbGFuc1xyXG4gIGNvbnN0IHBsYW5Db2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwbGFuX2lkXCIsIGhlYWRlcjogXCJQbGFuIElEXCIgfSxcclxuICAgIHsga2V5OiBcInBsYW5fbmFtZVwiLCBoZWFkZXI6IFwiUGxhbiBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBsYW5fdHlwZVwiLCBoZWFkZXI6IFwiVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJwbGFuX2N1cnJlbmN5XCIsIGhlYWRlcjogXCJDdXJyZW5jeVwiIH0sXHJcbiAgICB7IGtleTogXCJwbGFuX3JlY3VycmluZ19hbW91bnRcIiwgaGVhZGVyOiBcIlJlY3VycmluZyBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGxhbl9tYXhfYW1vdW50XCIsIGhlYWRlcjogXCJNYXggQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBsYW5fbWF4X2N5Y2xlc1wiLCBoZWFkZXI6IFwiTWF4IEN5Y2xlc1wiIH0sXHJcbiAgICB7IGtleTogXCJwbGFuX2ludGVydmFsc1wiLCBoZWFkZXI6IFwiSW50ZXJ2YWxzXCIgfSxcclxuICAgIHsga2V5OiBcInBsYW5faW50ZXJ2YWxfdHlwZVwiLCBoZWFkZXI6IFwiSW50ZXJ2YWwgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJwbGFuX25vdGVcIiwgaGVhZGVyOiBcIk5vdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIC8vIFRhYmxlIGNvbHVtbnMgZm9yIFN1YnNjcmlwdGlvbnNcclxuICBjb25zdCBzdWJDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJzdWJzY3JpcHRpb25faWRcIiwgaGVhZGVyOiBcIlN1YnNjcmlwdGlvbiBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyX2VtYWlsXCIsIGhlYWRlcjogXCJFbWFpbFwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9waG9uZVwiLCBoZWFkZXI6IFwiUGhvbmVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGxhbl9pZFwiLCBoZWFkZXI6IFwiUGxhbiBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfdHlwZVwiLCBoZWFkZXI6IFwiUGF5IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfaWRcIiwgaGVhZGVyOiBcIkdyb3VwIERldGFpbHNcIiB9LFxyXG4gICAgeyBrZXk6IFwiZmlyc3RfY2hhcmdlX3RpbWVcIiwgaGVhZGVyOiBcIkZpcnN0IENoYXJnZSBEYXRlXCIsIHdpZHRoOiAxOTAgfSxcclxuICAgIHsga2V5OiBcImV4cGlyeV90aW1lXCIsIGhlYWRlcjogXCJFeHBpcnkgRGF0ZVwiLCB3aWR0aDogMTgwIH0sXHJcbiAgICB7IGtleTogXCJhdXRob3JpemF0aW9uX2Ftb3VudFwiLCBoZWFkZXI6IFwiQXV0aCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IEV4Y2VsQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwic3Vic2NyaXB0aW9uX2lkXCIsIGhlYWRlcjogXCJTdWJzY3JpcHRpb24gSURcIiB9LFxyXG4gICAgeyBrZXk6IFwiU3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9lbWFpbFwiLCBoZWFkZXI6IFwiRW1haWxcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfcGhvbmVcIiwgaGVhZGVyOiBcIlBob25lXCIgfSxcclxuICAgIHsga2V5OiBcInBsYW5faWRcIiwgaGVhZGVyOiBcIlBsYW4gSURcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheSBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX2lkXCIsIGhlYWRlcjogXCJHcm91cCBEZXRhaWxzXCIgfSxcclxuICAgIHsga2V5OiBcImZpcnN0X2NoYXJnZV90aW1lXCIsIGhlYWRlcjogXCJGaXJzdCBDaGFyZ2UgRGF0ZVwiLCB3aWR0aDogMTkwIH0sXHJcbiAgICB7IGtleTogXCJleHBpcnlfdGltZVwiLCBoZWFkZXI6IFwiRXhwaXJ5IERhdGVcIiwgd2lkdGg6IDE4MCB9LFxyXG4gICAgeyBrZXk6IFwiYXV0aG9yaXphdGlvbl9hbW91bnRcIiwgaGVhZGVyOiBcIkF1dGggQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PSBSRU5ERVIgPT09PT09PT09PT09PT09PT09PT1cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gb3ZlcmZsb3cteC1oaWRkZW5cIj5cclxuICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfSAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBbGVydENvbmZpZyhwcmV2ID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTAgcC03IG92ZXJmbG93LXgtaGlkZGVuXCI+XHJcbiAgICAgICAgICAgIDxUYWJzIGFjdGl2ZUtleT17YWN0aXZlVGFifSBvbkNoYW5nZT17c2V0QWN0aXZlVGFifSBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgPFRhYlBhbmUgdGFiPVwiUGxhbnNcIiBrZXk9XCJwbGFuc1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlN1YnNjcmlwdGlvbiBQbGFuczwvaDE+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93UGxhbk1vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0UGxhbkVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICsgQWRkIFBsYW5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHt0YWJsZVBsYW5zLmxlbmd0aCA+IDAgJiYgIXBsYW5Jc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXtoYW5kbGVQbGFuVmlld01vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24odGFibGVQbGFucywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17cGxhbkNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiU3Vic2NyaXB0aW9uUGxhbnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJTdWJzY3JpcHRpb25QbGFucy5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17cGxhbklzTG9hZGluZ30gZGF0YT1cIlBsYW5zXCIgZmFpbHVyZT17dGFibGVQbGFucy5sZW5ndGggPD0gMH0gLz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9UYWJQYW5lPlxyXG5cclxuICAgICAgICAgICAgICA8VGFiUGFuZSB0YWI9XCJTdWJzY3JpcHRpb25zXCIga2V5PVwic3Vic2NyaXB0aW9uc1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlN1YnNjcmlwdGlvbnM8L2gxPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd1N1Yk1vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U3ViRXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtODAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgKyBBZGQgU3Vic2NyaXB0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7dGFibGVTdWJzY3JpcHRpb25zLmxlbmd0aCA+IDAgJiYgIXN1YklzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbih0YWJsZVN1YnNjcmlwdGlvbnMsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e3N1YkNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlSGFuZGxlcj17aGFuZGxlU3ViRWRpdE1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJTdWJzY3JpcHRpb25zXCJcclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiU3Vic2NyaXB0aW9ucy5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydENvbHM9e0V4Y2VsQ29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3N1YklzTG9hZGluZ30gZGF0YT1cIlN1YnNjcmlwdGlvbnNcIiBmYWlsdXJlPXt0YWJsZVN1YnNjcmlwdGlvbnMubGVuZ3RoIDw9IDB9IC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvVGFiUGFuZT5cclxuICAgICAgICAgICAgPC9UYWJzPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PSBQTEFOUyBNT0RBTFMgPT09PT09PT09PT09PT09PT09PT0gKi99XHJcblxyXG4gICAgICAgIHsvKiBWaWV3IFBsYW4gTW9kYWwgKE5FVykgKi99XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd1BsYW5WaWV3TW9kYWx9IG9uQ2xvc2U9eygpID0+IHsgc2V0U2hvd1BsYW5WaWV3TW9kYWwoZmFsc2UpOyBzZXRWaWV3UGxhbihudWxsKTsgfX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNiB0ZXh0LWxlZnQgYmctd2hpdGUgcm91bmRlZC0yeGwgbWF4LWgtWzkwdmhdIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02IGJvcmRlci1iIHBiLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+VmlldyBQbGFuPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+UGxhbiBkZXRhaWxzIChyZWFkLW9ubHkpPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge3ZpZXdQbGFuICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTVcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+UGxhbiBJRDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17dmlld1BsYW4ucGxhbl9pZCB8fCBcIlwifSByZWFkT25seSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktMTAwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBjdXJzb3Itbm90LWFsbG93ZWQgdGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+UGxhbiBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e3ZpZXdQbGFuLnBsYW5fbmFtZSB8fCBcIlwifSByZWFkT25seSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktMTAwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBjdXJzb3Itbm90LWFsbG93ZWQgdGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+UGxhbiBUeXBlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e3ZpZXdQbGFuLnBsYW5fdHlwZSB8fCBcIlwifSByZWFkT25seSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktMTAwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBjdXJzb3Itbm90LWFsbG93ZWQgdGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+Q3VycmVuY3k8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17dmlld1BsYW4ucGxhbl9jdXJyZW5jeSB8fCBcIlwifSByZWFkT25seSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktMTAwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBjdXJzb3Itbm90LWFsbG93ZWQgdGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+UmVjdXJyaW5nIEFtb3VudCAo4oK5KTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXt2aWV3UGxhbi5wbGFuX3JlY3VycmluZ19hbW91bnQgPz8gXCJcIn0gcmVhZE9ubHkgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy1ncmF5LTEwMCBweC00IHB5LTMgdGV4dC1zbSBvdXRsaW5lLW5vbmUgY3Vyc29yLW5vdC1hbGxvd2VkIHRleHQtZ3JheS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPk1heCBBbW91bnQgKOKCuSk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17dmlld1BsYW4ucGxhbl9tYXhfYW1vdW50ID8/IFwiXCJ9IHJlYWRPbmx5IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctZ3JheS0xMDAgcHgtNCBweS0zIHRleHQtc20gb3V0bGluZS1ub25lIGN1cnNvci1ub3QtYWxsb3dlZCB0ZXh0LWdyYXktNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5NYXggQ3ljbGVzPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e3ZpZXdQbGFuLnBsYW5fbWF4X2N5Y2xlcyA/PyBcIlwifSByZWFkT25seSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktMTAwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBjdXJzb3Itbm90LWFsbG93ZWQgdGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+SW50ZXJ2YWxzPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e3ZpZXdQbGFuLnBsYW5faW50ZXJ2YWxzID8/IFwiXCJ9IHJlYWRPbmx5IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctZ3JheS0xMDAgcHgtNCBweS0zIHRleHQtc20gb3V0bGluZS1ub25lIGN1cnNvci1ub3QtYWxsb3dlZCB0ZXh0LWdyYXktNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5JbnRlcnZhbCBUeXBlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e3ZpZXdQbGFuLnBsYW5faW50ZXJ2YWxfdHlwZSB8fCBcIlwifSByZWFkT25seSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktMTAwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBjdXJzb3Itbm90LWFsbG93ZWQgdGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+UGxhbiBDYXRlZ29yeTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXt2aWV3UGxhbi5wbGFuX25vdGUgfHwgXCJcIn0gcmVhZE9ubHkgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy1ncmF5LTEwMCBweC00IHB5LTMgdGV4dC1zbSBvdXRsaW5lLW5vbmUgY3Vyc29yLW5vdC1hbGxvd2VkIHRleHQtZ3JheS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPkNyZWF0ZWQgQXQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17dmlld1BsYW4uY3JlYXRlZEF0ID8gZm9ybWF0RGF0ZVRpbWUodmlld1BsYW4uY3JlYXRlZEF0KSA6IFwiXCJ9IHJlYWRPbmx5IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctZ3JheS0xMDAgcHgtNCBweS0zIHRleHQtc20gb3V0bGluZS1ub25lIGN1cnNvci1ub3QtYWxsb3dlZCB0ZXh0LWdyYXktNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5VcGRhdGVkIEF0PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e3ZpZXdQbGFuLnVwZGF0ZWRBdCA/IGZvcm1hdERhdGVUaW1lKHZpZXdQbGFuLnVwZGF0ZWRBdCkgOiBcIlwifSByZWFkT25seSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktMTAwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBjdXJzb3Itbm90LWFsbG93ZWQgdGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LThcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0U2hvd1BsYW5WaWV3TW9kYWwoZmFsc2UpOyBzZXRWaWV3UGxhbihudWxsKTsgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IHJvdW5kZWQteGwgYmctYmx1ZS05MDAgdGV4dC13aGl0ZSBmb250LW1lZGl1bSBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIHNoYWRvdy1sZ1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2xvc2VcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICB7LyogQWRkIFBsYW4gTW9kYWwgKi99XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd1BsYW5Nb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd1BsYW5Nb2RhbChmYWxzZSl9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTYgdGV4dC1sZWZ0IGJnLXdoaXRlIHJvdW5kZWQtMnhsIG1heC1oLVs5MHZoXSBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNiBib3JkZXItYiBwYi00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPkNyZWF0ZSBTdWJzY3JpcHRpb24gUGxhbjwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMVwiPkFkZCBuZXcgcmVjdXJyaW5nIHN1YnNjcmlwdGlvbiBwbGFuPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVBsYW5TdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC01XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsYW4gSUQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBsYW5faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BsYW5Gb3JtRGF0YS5wbGFuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBsYW5DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1DRi1QTC17e05VTUJFUn19LXt7QU1PVU5UfX1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy1ncmF5LTUwIHBsLTQgcHItMjggcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRQbGFuRm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFuX2lkOiBgTUNGLVBMLSR7Z2xvYmFsVGhpcy5jcnlwdG8ucmFuZG9tVVVJRCgpLnJlcGxhY2UoLy0vZywgJycpLnNsaWNlKDAsIDEyKX1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTEuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWxnIGJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcHgtMyBweS0yIHRleHQteHMgZm9udC1tZWRpdW0gaG92ZXI6YmctYmx1ZS03MDAgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBHZW5lcmF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAge3BsYW5FcnJvcnMucGxhbl9pZCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e3BsYW5FcnJvcnMucGxhbl9pZH08L3A+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlBsYW4gTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJwbGFuX25hbWVcIiB2YWx1ZT17cGxhbkZvcm1EYXRhLnBsYW5fbmFtZX0gb25DaGFuZ2U9e2hhbmRsZVBsYW5DaGFuZ2V9IHBsYWNlaG9sZGVyPVwiR29sZCBNb250aGx5IFBsYW5cIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktNTAgcHgtNCBweS0zIHRleHQtc20gb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTIwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtwbGFuRXJyb3JzLnBsYW5fbmFtZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e3BsYW5FcnJvcnMucGxhbl9uYW1lfTwvcD59XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlJlY3VycmluZyBBbW91bnQgKOKCuSkgPFRvb2x0aXAgdGl0bGU9XCJBbW91bnQgdGhhdCBjdXN0b21lciBuZWVkcyB0byBwYXkgcmVwZWF0ZWRseSBmb3IgZWFjaCBjeWNsZS5cIj48SW5mb0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgY3Vyc29yLXBvaW50ZXJcIiAvPjwvVG9vbHRpcD48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJwbGFuX3JlY3VycmluZ19hbW91bnRcIiB2YWx1ZT17cGxhbkZvcm1EYXRhLnBsYW5fcmVjdXJyaW5nX2Ftb3VudH0gb25DaGFuZ2U9e2hhbmRsZVBsYW5DaGFuZ2V9IHBsYWNlaG9sZGVyPVwiNTAwXCIgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy1ncmF5LTUwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICB7cGxhbkVycm9ycy5wbGFuX3JlY3VycmluZ19hbW91bnQgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntwbGFuRXJyb3JzLnBsYW5fcmVjdXJyaW5nX2Ftb3VudH08L3A+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5NYXggQW1vdW50ICjigrkpIDxUb29sdGlwIHRpdGxlPVwiTWF4aW11bSB0b3RhbCBhbW91bnQgYWxsb3dlZCB1bmRlciB0aGlzIHN1YnNjcmlwdGlvbiBwbGFuLlwiPjxJbmZvQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMCBjdXJzb3ItcG9pbnRlclwiIC8+PC9Ub29sdGlwPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbmFtZT1cInBsYW5fbWF4X2Ftb3VudFwiIHZhbHVlPXtwbGFuRm9ybURhdGEucGxhbl9tYXhfYW1vdW50fSBvbkNoYW5nZT17aGFuZGxlUGxhbkNoYW5nZX0gcGxhY2Vob2xkZXI9XCIxMDAwMFwiIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCBweC00IHB5LTMgdGV4dC1zbSBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtMjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAge3BsYW5FcnJvcnMucGxhbl9tYXhfYW1vdW50ICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57cGxhbkVycm9ycy5wbGFuX21heF9hbW91bnR9PC9wPn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+TWF4IEN5Y2xlcyAoT3B0aW9uYWwpIDxUb29sdGlwIHRpdGxlPVwiTWF4aW11bSBudW1iZXIgb2YgY3ljbGVzIGZvciB0aGlzIHN1YnNjcmlwdGlvbiBwbGFuLlwiPjxJbmZvQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMCBjdXJzb3ItcG9pbnRlclwiIC8+PC9Ub29sdGlwPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbmFtZT1cInBsYW5fbWF4X2N5Y2xlc1wiIHZhbHVlPXtwbGFuRm9ybURhdGEucGxhbl9tYXhfY3ljbGVzfSBvbkNoYW5nZT17aGFuZGxlUGxhbkNoYW5nZX0gcGxhY2Vob2xkZXI9XCIxMlwiIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCBweC00IHB5LTMgdGV4dC1zbSBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtMjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+SW50ZXJ2YWxzIDxUb29sdGlwIHRpdGxlPVwiVG90YWwgbnVtYmVyIG9mIEludGVydmFscyBmb3IgdGhpcyBzdWJzY3JpcHRpb24gcGxhbi5cIj48SW5mb0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgY3Vyc29yLXBvaW50ZXJcIiAvPjwvVG9vbHRpcD48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJwbGFuX2ludGVydmFsc1wiIHZhbHVlPXtwbGFuRm9ybURhdGEucGxhbl9pbnRlcnZhbHN9IG9uQ2hhbmdlPXtoYW5kbGVQbGFuQ2hhbmdlfSBwbGFjZWhvbGRlcj1cIjFcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktNTAgcHgtNCBweS0zIHRleHQtc20gb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTIwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtwbGFuRXJyb3JzLnBsYW5faW50ZXJ2YWxzICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57cGxhbkVycm9ycy5wbGFuX2ludGVydmFsc308L3A+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPkludGVydmFsIFR5cGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0IGNsYXNzTmFtZT1cInctZnVsbFwiIHZhbHVlPXtwbGFuRm9ybURhdGEucGxhbl9pbnRlcnZhbF90eXBlfSBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVQbGFuQW50RFNlbGVjdChcInBsYW5faW50ZXJ2YWxfdHlwZVwiLCB2YWx1ZSl9IHNpemU9XCJsYXJnZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiREFZXCI+RGFpbHk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJXRUVLXCI+V2Vla2x5PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiTU9OVEhcIj5Nb250aGx5PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiWUVBUlwiPlllYXJseTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+UGxhbiBDYXRlZ29yeTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QgY2xhc3NOYW1lPVwidy1mdWxsXCIgdmFsdWU9e3BsYW5Gb3JtRGF0YS5wbGFuX25vdGV9IG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZVBsYW5BbnREU2VsZWN0KFwicGxhbl9ub3RlXCIsIHZhbHVlKX0gc2l6ZT1cImxhcmdlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcIkNoaXRcIiwgXCJMb2FuXCIsIFwiUGlnbXlcIl0ubWFwKG5vdGUgPT4gPFNlbGVjdC5PcHRpb24ga2V5PXtub3RlfSB2YWx1ZT17bm90ZX0+e25vdGV9PC9TZWxlY3QuT3B0aW9uPil9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJoaWRkZW5cIiBuYW1lPVwicGxhbl90eXBlXCIgdmFsdWU9XCJQRVJJT0RJQ1wiIC8+XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJoaWRkZW5cIiBuYW1lPVwicGxhbl9jdXJyZW5jeVwiIHZhbHVlPVwiSU5SXCIgLz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgbXQtOFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd1BsYW5Nb2RhbChmYWxzZSl9IGNsYXNzTmFtZT1cInB4LTUgcHktMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb25cIj5DYW5jZWw8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IHJvdW5kZWQteGwgYmctYmx1ZS05MDAgdGV4dC13aGl0ZSBmb250LW1lZGl1bSBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIHNoYWRvdy1sZ1wiPlNhdmUgUGxhbjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICB7LyogRGVsZXRlIFBsYW4gTW9kYWwgKi99XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd1BsYW5EZWxldGVNb2RhbH0gb25DbG9zZT17KCkgPT4geyBzZXRTaG93UGxhbkRlbGV0ZU1vZGFsKGZhbHNlKTsgc2V0Q3VycmVudFBsYW4obnVsbCk7IH19PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPkRlbGV0ZSBQbGFuPC9oMz5cclxuICAgICAgICAgICAge2N1cnJlbnRQbGFuICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBoYW5kbGVQbGFuRGVsZXRlKCk7IH19IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+UGxlYXNlIGVudGVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj57Y3VycmVudFBsYW4ucGxhbl9uYW1lfTwvc3Bhbj4gdG8gY29uZmlybSBkZWxldGlvbi4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cInBsYW5OYW1lQ29uZmlybVwiIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIHBsYW4gbmFtZVwiIHJlcXVpcmVkIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCI+RGVsZXRlPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgey8qIFVwZGF0ZSBQbGFuIE1vZGFsICovfVxyXG4gICAgICAgIHsvKiA8TW9kYWwgaXNWaXNpYmxlPXtzaG93UGxhblVwZGF0ZU1vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93UGxhblVwZGF0ZU1vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNiB0ZXh0LWxlZnQgYmctd2hpdGUgcm91bmRlZC0yeGwgbWF4LWgtWzkwdmhdIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIG1iLTRcIj5VcGRhdGUgUGxhbjwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVQbGFuVXBkYXRlfT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJwbGFuX2lkXCIgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBsYW5faWR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXBkYXRlRm9ybURhdGEoeyAuLi51cGRhdGVGb3JtRGF0YSwgcGxhbl9pZDogZS50YXJnZXQudmFsdWUgfSl9IHBsYWNlaG9sZGVyPVwiUGxhbiBJRFwiIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPVwicGxhbl9uYW1lXCIgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBsYW5fbmFtZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRVcGRhdGVGb3JtRGF0YSh7IC4uLnVwZGF0ZUZvcm1EYXRhLCBwbGFuX25hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfSBwbGFjZWhvbGRlcj1cIlBsYW4gTmFtZVwiIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJwbGFuX3JlY3VycmluZ19hbW91bnRcIiB2YWx1ZT17dXBkYXRlRm9ybURhdGEucGxhbl9yZWN1cnJpbmdfYW1vdW50fSBvbkNoYW5nZT17KGUpID0+IHNldFVwZGF0ZUZvcm1EYXRhKHsgLi4udXBkYXRlRm9ybURhdGEsIHBsYW5fcmVjdXJyaW5nX2Ftb3VudDogZS50YXJnZXQudmFsdWUgfSl9IHBsYWNlaG9sZGVyPVwiUmVjdXJyaW5nIEFtb3VudFwiIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJwbGFuX21heF9hbW91bnRcIiB2YWx1ZT17dXBkYXRlRm9ybURhdGEucGxhbl9tYXhfYW1vdW50fSBvbkNoYW5nZT17KGUpID0+IHNldFVwZGF0ZUZvcm1EYXRhKHsgLi4udXBkYXRlRm9ybURhdGEsIHBsYW5fbWF4X2Ftb3VudDogZS50YXJnZXQudmFsdWUgfSl9IHBsYWNlaG9sZGVyPVwiTWF4IEFtb3VudFwiIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJwbGFuX21heF9jeWNsZXNcIiB2YWx1ZT17dXBkYXRlRm9ybURhdGEucGxhbl9tYXhfY3ljbGVzfSBvbkNoYW5nZT17KGUpID0+IHNldFVwZGF0ZUZvcm1EYXRhKHsgLi4udXBkYXRlRm9ybURhdGEsIHBsYW5fbWF4X2N5Y2xlczogZS50YXJnZXQudmFsdWUgfSl9IHBsYWNlaG9sZGVyPVwiTWF4IEN5Y2xlc1wiIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJwbGFuX2ludGVydmFsc1wiIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5wbGFuX2ludGVydmFsc30gb25DaGFuZ2U9eyhlKSA9PiBzZXRVcGRhdGVGb3JtRGF0YSh7IC4uLnVwZGF0ZUZvcm1EYXRhLCBwbGFuX2ludGVydmFsczogZS50YXJnZXQudmFsdWUgfSl9IHBsYWNlaG9sZGVyPVwiSW50ZXJ2YWxzXCIgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkXCIgcmVxdWlyZWQgLz5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBsYW5faW50ZXJ2YWxfdHlwZX0gb25DaGFuZ2U9eyh2YWwpID0+IHNldFVwZGF0ZUZvcm1EYXRhKHsgLi4udXBkYXRlRm9ybURhdGEsIHBsYW5faW50ZXJ2YWxfdHlwZTogdmFsIH0pfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJEQVlcIj5EYWlseTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJXRUVLXCI+V2Vla2x5PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIk1PTlRIXCI+TW9udGhseTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJZRUFSXCI+WWVhcmx5PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0IHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5wbGFuX25vdGV9IG9uQ2hhbmdlPXsodmFsKSA9PiBzZXRVcGRhdGVGb3JtRGF0YSh7IC4uLnVwZGF0ZUZvcm1EYXRhLCBwbGFuX25vdGU6IHZhbCB9KX0gY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtbXCJDaGl0XCIsIFwiTG9hblwiLCBcIlBpZ215XCJdLm1hcChuID0+IDxTZWxlY3QuT3B0aW9uIGtleT17bn0gdmFsdWU9e259PntufTwvU2VsZWN0Lk9wdGlvbj4pfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIG10LTZcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dQbGFuVXBkYXRlTW9kYWwoZmFsc2UpfSBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIHJvdW5kZWRcIj5DYW5jZWw8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWRcIj5VcGRhdGU8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD4gKi99XHJcblxyXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PSBTVUJTQ1JJUFRJT05TIE1PREFMUyA9PT09PT09PT09PT09PT09PT09PSAqL31cclxuXHJcbiAgICAgICAgey8qIEFkZCBTdWJzY3JpcHRpb24gTW9kYWwgKi99XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd1N1Yk1vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93U3ViTW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG14LWF1dG8gYmctd2hpdGUgcm91bmRlZC0zeGwgYm9yZGVyLXNsYXRlLTEwMCBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTggcHktNiBiZy1ncmFkaWVudC10by1yIGZyb20tc2xhdGUtNTAgdG8td2hpdGUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgdHJhY2tpbmctdGlnaHRcIj5DcmVhdGUgU3Vic2NyaXB0aW9uPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBtdC0xIGZvbnQtbWVkaXVtXCI+Q29uZmlndXJlIGEgbmV3IHJlY3VycmluZyBwYXltZW50IHBsYW48L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBweC04IHB5LTYgY3VzdG9tLXNjcm9sbGJhclwiPlxyXG4gICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+Q3VzdG9tZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIG1sLTFcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3Igc2VhcmNoIGN1c3RvbWVyLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4gb3B0aW9uLmNoaWxkcmVuLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFVzZXJJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ3VzdG9tZXJTZWxlY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCh1c2VyID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9IHwge3VzZXIucGhvbmVfbnVtYmVyfSB7dXNlci5lbWFpbCAmJiBgfCAke3VzZXIuZW1haWx9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAge3N1YkVycm9ycy5jdXN0b21lciAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e3N1YkVycm9ycy5jdXN0b21lcn08L3A+fVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMFwiPkdyb3VwICYgVGlja2V0IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBtbC0xXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwIHwgVGlja2V0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cFRpY2tldFNlbGVjdH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwVGlja2V0VmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMiByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRFbnJvbGxtZW50cy5tYXAoKGVudHJ5LCBpZHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBOYW1lID0gZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5ncm91cF9uYW1lIHx8IFwiVW5uYW1lZCBHcm91cFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBncm91cElkID0gZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5faWQgfHwgYG1pc3NpbmctJHtpZHh9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGlja2V0ID0gZW50cnk/LmVucm9sbG1lbnQ/LnRpY2tldHMgfHwgXCJVbmtub3duXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiA8U2VsZWN0Lk9wdGlvbiBrZXk9e2BjaGl0fCR7Z3JvdXBJZH18JHt0aWNrZXR9YH0gdmFsdWU9e2BjaGl0fCR7Z3JvdXBJZH18JHt0aWNrZXR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57Z3JvdXBOYW1lfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+VGlja2V0OiB7dGlja2V0fSAoQ0hJVCk8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj47XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZUN1c3RvbWVycy5tYXAocGlnbWUgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2BwaWdtZXwke3BpZ21lLl9pZH1gfSB2YWx1ZT17YHBpZ21lfCR7cGlnbWUuX2lkfXwke3BpZ21lLnBpZ21lX2lkIHx8IHBpZ21lLl9pZH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj48c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntwaWdtZS5waWdtZV9pZH08L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPuKCuSB7cGlnbWUucGF5YWJsZV9hbW91bnR9IChQSUdNWSk8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAge2JvcnJvd2Vycy5tYXAoYm9ycm93ZXIgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2Bsb2FufCR7Ym9ycm93ZXIuX2lkfWB9IHZhbHVlPXtgbG9hbnwke2JvcnJvd2VyLl9pZH18JHtib3Jyb3dlci5sb2FuX2lkIHx8IGJvcnJvd2VyLl9pZH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj48c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntib3Jyb3dlci5sb2FuX2lkfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+4oK5IHtib3Jyb3dlci5sb2FuX2Ftb3VudH0gKExPQU4pPC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICB7c3ViRXJyb3JzLmdyb3VwICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57c3ViRXJyb3JzLmdyb3VwfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU3Vic2NyaXB0aW9uIElEIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBtbC0xXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdWJzY3JpcHRpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3ViRm9ybURhdGEuc3Vic2NyaXB0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU3ViQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gU1VCXzAwMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcGwtNCBwci0yOFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTdWJGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWJzY3JpcHRpb25faWQ6IGBTVUJfJHtnbG9iYWxUaGlzLmNyeXB0by5yYW5kb21VVUlEKCkucmVwbGFjZSgvLS9nLCAnJykuc2xpY2UoMCwgMTIpfWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMS41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtbWQgYmctc2xhdGUtODAwIHRleHQtd2hpdGUgcHgtMyBweS0yIHRleHQteHMgZm9udC1tZWRpdW0gaG92ZXI6Ymctc2xhdGUtOTAwIGFjdGl2ZTpzY2FsZS05NSB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFJlZnJlc2hDdyBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgR2VuZXJhdGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHtzdWJFcnJvcnMuc3Vic2NyaXB0aW9uX2lkICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3N1YkVycm9ycy5zdWJzY3JpcHRpb25faWR9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5QbGFuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBtbC0xXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTIgcm91bmRlZC1sZ1wiIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGEgcGxhblwiIHZhbHVlPXtzdWJGb3JtRGF0YS5wbGFuX2RldGFpbHMucGxhbl9pZCB8fCB1bmRlZmluZWR9IG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZVN1Yk5lc3RlZENoYW5nZShcInBsYW5fZGV0YWlsc1wiLCBcInBsYW5faWRcIiwgdmFsdWUpfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwbGFuc0ZvckRyb3Bkb3duLm1hcChwbGFuID0+IDxTZWxlY3QuT3B0aW9uIGtleT17cGxhbi5wbGFuX2lkfSB2YWx1ZT17cGxhbi5wbGFuX2lkfT57cGxhbi5wbGFuX25hbWV9ICh7cGxhbi5wbGFuX2lkfSk8L1NlbGVjdC5PcHRpb24+KX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICB7c3ViRXJyb3JzW1wicGxhbl9kZXRhaWxzLnBsYW5faWRcIl0gJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHNcIj57c3ViRXJyb3JzW1wicGxhbl9kZXRhaWxzLnBsYW5faWRcIl19PC9wPn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5GaXJzdCBDaGFyZ2UgVGltZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgbWwtMVwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImRhdGV0aW1lLWxvY2FsXCIgbWluPXtmaXJzdENoYXJnZVRpbWVNaW59IHZhbHVlPXtzdWJGb3JtRGF0YS5zdWJzY3JpcHRpb25fZmlyc3RfY2hhcmdlX3RpbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3ViRm9ybURhdGEoeyAuLi5zdWJGb3JtRGF0YSwgc3Vic2NyaXB0aW9uX2ZpcnN0X2NoYXJnZV90aW1lOiBlLnRhcmdldC52YWx1ZSB9KX0gY2xhc3NOYW1lPVwidy1mdWxsIGgtMTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBweC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICB7c3ViRXJyb3JzLnN1YnNjcmlwdGlvbl9maXJzdF9jaGFyZ2VfdGltZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14c1wiPntzdWJFcnJvcnMuc3Vic2NyaXB0aW9uX2ZpcnN0X2NoYXJnZV90aW1lfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+RXhwaXJ5IFRpbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIG1sLTFcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJkYXRldGltZS1sb2NhbFwiIG1pbj17ZXhwaXJ5VGltZU1pbn0gdmFsdWU9e3N1YkZvcm1EYXRhLnN1YnNjcmlwdGlvbl9leHBpcnlfdGltZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRTdWJGb3JtRGF0YSh7IC4uLnN1YkZvcm1EYXRhLCBzdWJzY3JpcHRpb25fZXhwaXJ5X3RpbWU6IGUudGFyZ2V0LnZhbHVlIH0pfSBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHB4LTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzdWJFcnJvcnMuc3Vic2NyaXB0aW9uX2V4cGlyeV90aW1lICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3N1YkVycm9ycy5zdWJzY3JpcHRpb25fZXhwaXJ5X3RpbWV9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5BdXRob3JpemF0aW9uIEFtb3VudCAo4oK5KSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgbWwtMVwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHZhbHVlPXtzdWJGb3JtRGF0YS5hdXRob3JpemF0aW9uX2RldGFpbHMuYXV0aG9yaXphdGlvbl9hbW91bnR9IG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU3ViTmVzdGVkQ2hhbmdlKFwiYXV0aG9yaXphdGlvbl9kZXRhaWxzXCIsIFwiYXV0aG9yaXphdGlvbl9hbW91bnRcIiwgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIjAuMDBcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHB4LTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzdWJFcnJvcnNbXCJhdXRob3JpemF0aW9uX2RldGFpbHMuYXV0aG9yaXphdGlvbl9hbW91bnRcIl0gJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHNcIj57c3ViRXJyb3JzW1wiYXV0aG9yaXphdGlvbl9kZXRhaWxzLmF1dGhvcml6YXRpb25fYW1vdW50XCJdfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC00IGJnLXNsYXRlLTUwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5SZWZ1bmQgQXV0aG9yaXphdGlvbiBBbW91bnQ8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBibG9ja1wiPlJlZnVuZCB0aGUgaW5pdGlhbCBob2xkIGFtb3VudDwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tib3ggY2hlY2tlZD17c3ViRm9ybURhdGEuYXV0aG9yaXphdGlvbl9kZXRhaWxzLmF1dGhvcml6YXRpb25fYW1vdW50X3JlZnVuZH0gb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVTdWJOZXN0ZWRDaGFuZ2UoXCJhdXRob3JpemF0aW9uX2RldGFpbHNcIiwgXCJhdXRob3JpemF0aW9uX2Ftb3VudF9yZWZ1bmRcIiwgZS50YXJnZXQuY2hlY2tlZCl9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+UGF5bWVudCBNZXRob2RzPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCIgdmFsdWU9e3N1YkZvcm1EYXRhLmF1dGhvcml6YXRpb25fZGV0YWlscy5wYXltZW50X21ldGhvZHN9IGRpc2FibGVkIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+Tm90aWZpY2F0aW9uIENoYW5uZWxzPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCIgdmFsdWU9e1wiU01TXCJ9IGRpc2FibGVkIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtNCBtdC0xMCBwdC02IGJvcmRlci10XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dTdWJNb2RhbChmYWxzZSl9IGNsYXNzTmFtZT1cInB4LTYgcHktMi41IHJvdW5kZWQteGwgYm9yZGVyXCI+Q2FuY2VsPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInB4LTggcHktMi41IHJvdW5kZWQteGwgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHNoYWRvdy1sZ1wiPlNhdmUgU3Vic2NyaXB0aW9uPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgey8qIEVkaXQgU3Vic2NyaXB0aW9uIE1vZGFsIChORVcpICovfVxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dTdWJFZGl0TW9kYWx9IG9uQ2xvc2U9eygpID0+IHsgc2V0U2hvd1N1YkVkaXRNb2RhbChmYWxzZSk7IHNldEN1cnJlbnRFZGl0U3ViKG51bGwpOyBzZXRFZGl0TW9kYWxMb2FkaW5nKGZhbHNlKTsgfX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBteC1hdXRvIGJnLXdoaXRlIHJvdW5kZWQtM3hsIGJvcmRlci1zbGF0ZS0xMDAgb3ZlcmZsb3ctaGlkZGVuIGZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC04IHB5LTYgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNsYXRlLTUwIHRvLXdoaXRlIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCB0cmFja2luZy10aWdodFwiPkVkaXQgU3Vic2NyaXB0aW9uPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS01MDAgbXQtMSBmb250LW1lZGl1bVwiPk9ubHkgR3JvdXAgJiBUaWNrZXQgY2FuIGJlIG1vZGlmaWVkPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHB4LTggcHktNiBjdXN0b20tc2Nyb2xsYmFyXCI+XHJcbiAgICAgICAgICAgICAge2VkaXRNb2RhbExvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB5LTIwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxTcGluIHNpemU9XCJsYXJnZVwiIHRpcD1cIkxvYWRpbmcgc3Vic2NyaXB0aW9uIGRldGFpbHMuLi5cIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIGN1cnJlbnRFZGl0U3ViICYmIChcclxuICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1YkVkaXRTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIg4oCUIGRpc2FibGVkICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMFwiPkN1c3RvbWVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHtjdXJyZW50RWRpdFN1Yi5jdXN0b21lcl9kZXRhaWxzPy5jdXN0b21lcl9uYW1lIHx8IFwiXCJ9IHwgJHtjdXJyZW50RWRpdFN1Yi5jdXN0b21lcl9kZXRhaWxzPy5jdXN0b21lcl9waG9uZSB8fCBcIlwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTEwMCBweC00IHRleHQtc2xhdGUtNTAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogR3JvdXAgJiBUaWNrZXQg4oCUIEVESVRBQkxFICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMFwiPkdyb3VwICYgVGlja2V0IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBtbC0xXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR3JvdXAgfCBUaWNrZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVFZGl0R3JvdXBUaWNrZXRTZWxlY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRHcm91cFRpY2tldFZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlZGl0RmlsdGVyZWRFbnJvbGxtZW50cy5tYXAoKGVudHJ5LCBpZHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9IGVudHJ5Py5lbnJvbGxtZW50Py5ncm91cD8uZ3JvdXBfbmFtZSB8fCBcIlVubmFtZWQgR3JvdXBcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3VwSWQgPSBlbnRyeT8uZW5yb2xsbWVudD8uZ3JvdXA/Ll9pZCB8fCBgbWlzc2luZy0ke2lkeH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGlja2V0ID0gZW50cnk/LmVucm9sbG1lbnQ/LnRpY2tldHMgfHwgXCJVbmtub3duXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2BjaGl0fCR7Z3JvdXBJZH18JHt0aWNrZXR9YH0gdmFsdWU9e2BjaGl0fCR7Z3JvdXBJZH18JHt0aWNrZXR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57Z3JvdXBOYW1lfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+VGlja2V0OiB7dGlja2V0fSAoQ0hJVCk8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2VkaXRQaWdtZUN1c3RvbWVycy5tYXAocGlnbWUgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtgcGlnbWV8JHtwaWdtZS5faWR9YH0gdmFsdWU9e2BwaWdtZXwke3BpZ21lLl9pZH18JHtwaWdtZS5waWdtZV9pZCB8fCBwaWdtZS5faWR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e3BpZ21lLnBpZ21lX2lkfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+4oK5IHtwaWdtZS5wYXlhYmxlX2Ftb3VudH0gKFBJR01ZKTwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZWRpdEJvcnJvd2Vycy5tYXAoYm9ycm93ZXIgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtgbG9hbnwke2JvcnJvd2VyLl9pZH1gfSB2YWx1ZT17YGxvYW58JHtib3Jyb3dlci5faWR9fCR7Ym9ycm93ZXIubG9hbl9pZCB8fCBib3Jyb3dlci5faWR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e2JvcnJvd2VyLmxvYW5faWR9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInRleHQteHNcIj7igrkge2JvcnJvd2VyLmxvYW5fYW1vdW50fSAoTE9BTik8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFN1YnNjcmlwdGlvbiBJRCDigJQgZGlzYWJsZWQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+U3Vic2NyaXB0aW9uIElEPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2N1cnJlbnRFZGl0U3ViLnN1YnNjcmlwdGlvbl9pZCB8fCBcIlwifSByZWFkT25seSBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTEwMCBweC00IHRleHQtc2xhdGUtNTAwIGN1cnNvci1ub3QtYWxsb3dlZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogUGxhbiDigJQgZGlzYWJsZWQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+UGxhbjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtjdXJyZW50RWRpdFN1Yi5wbGFuX2RldGFpbHM/LnBsYW5faWQgfHwgXCJcIn0gcmVhZE9ubHkgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS0xMDAgcHgtNCB0ZXh0LXNsYXRlLTUwMCBjdXJzb3Itbm90LWFsbG93ZWRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEZpcnN0IENoYXJnZSBUaW1lIOKAlCBkaXNhYmxlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5GaXJzdCBDaGFyZ2UgVGltZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2lzb1RvRGF0ZXRpbWVMb2NhbChjdXJyZW50RWRpdFN1Yi5zdWJzY3JpcHRpb25fZmlyc3RfY2hhcmdlX3RpbWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS0xMDAgcHgtNCB0ZXh0LXNsYXRlLTUwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEV4cGlyeSBUaW1lIOKAlCBkaXNhYmxlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5FeHBpcnkgVGltZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2lzb1RvRGF0ZXRpbWVMb2NhbChjdXJyZW50RWRpdFN1Yi5zdWJzY3JpcHRpb25fZXhwaXJ5X3RpbWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS0xMDAgcHgtNCB0ZXh0LXNsYXRlLTUwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEF1dGhvcml6YXRpb24gQW1vdW50IOKAlCBkaXNhYmxlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5BdXRob3JpemF0aW9uIEFtb3VudCAo4oK5KTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgdmFsdWU9e2N1cnJlbnRFZGl0U3ViLmF1dGhvcml6YXRpb25fZGV0YWlscz8uYXV0aG9yaXphdGlvbl9hbW91bnQgPz8gXCJcIn0gcmVhZE9ubHkgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS0xMDAgcHgtNCB0ZXh0LXNsYXRlLTUwMCBjdXJzb3Itbm90LWFsbG93ZWRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFJlZnVuZCDigJQgZGlzYWJsZWQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTQgYmctc2xhdGUtNTAgcm91bmRlZC14bCBvcGFjaXR5LTYwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlJlZnVuZCBBdXRob3JpemF0aW9uIEFtb3VudDwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGJsb2NrXCI+UmVmdW5kIHRoZSBpbml0aWFsIGhvbGQgYW1vdW50PC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tib3ggY2hlY2tlZD17Y3VycmVudEVkaXRTdWIuYXV0aG9yaXphdGlvbl9kZXRhaWxzPy5hdXRob3JpemF0aW9uX2Ftb3VudF9yZWZ1bmR9IGRpc2FibGVkIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogUGF5bWVudCBNZXRob2RzIOKAlCBkaXNhYmxlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5QYXltZW50IE1ldGhvZHM8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCIgdmFsdWU9e2N1cnJlbnRFZGl0U3ViLmF1dGhvcml6YXRpb25fZGV0YWlscz8ucGF5bWVudF9tZXRob2RzIHx8IFtcInVwaVwiXX0gZGlzYWJsZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBOb3RpZmljYXRpb24g4oCUIGRpc2FibGVkICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMFwiPk5vdGlmaWNhdGlvbiBDaGFubmVsczwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTJcIiB2YWx1ZT17XCJTTVNcIn0gZGlzYWJsZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC00IG10LTEwIHB0LTYgYm9yZGVyLXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0U2hvd1N1YkVkaXRNb2RhbChmYWxzZSk7IHNldEN1cnJlbnRFZGl0U3ViKG51bGwpOyB9fSBjbGFzc05hbWU9XCJweC02IHB5LTIuNSByb3VuZGVkLXhsIGJvcmRlclwiPkNhbmNlbDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwicHgtOCBweS0yLjUgcm91bmRlZC14bCBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgc2hhZG93LWxnXCI+VXBkYXRlIFN1YnNjcmlwdGlvbjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICB7LyogRGVsZXRlIFN1YnNjcmlwdGlvbiBNb2RhbCAqL31cclxuICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93U3ViRGVsZXRlTW9kYWx9IG9uQ2xvc2U9eygpID0+IHsgc2V0U2hvd1N1YkRlbGV0ZU1vZGFsKGZhbHNlKTsgc2V0Q3VycmVudFN1YnNjcmlwdGlvbihudWxsKTsgfX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+RGVsZXRlIFN1YnNjcmlwdGlvbjwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50U3Vic2NyaXB0aW9uICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBoYW5kbGVTdWJEZWxldGUoKTsgfX0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5QbGVhc2UgZW50ZXIgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcHJpbWFyeVwiPntjdXJyZW50U3Vic2NyaXB0aW9uLnN1YnNjcmlwdGlvbl9pZH08L3NwYW4+IHRvIGNvbmZpcm0gZGVsZXRpb24uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgaWQ9XCJzdWJzY3JpcHRpb25Db25maXJtXCIgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgc3Vic2NyaXB0aW9uIElEXCIgcmVxdWlyZWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXJlZC03MDAgaG92ZXI6YmctcmVkLTgwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIj5EZWxldGU8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdWJzY3JpcHRpb25zO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvU3Vic2NyaXB0aW9ucy5qc3gifQ==