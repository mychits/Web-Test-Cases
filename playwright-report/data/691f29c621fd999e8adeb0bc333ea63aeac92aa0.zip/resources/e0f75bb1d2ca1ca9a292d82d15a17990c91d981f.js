import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AdminApprovalsMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, Briefcase, ChevronRight, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import __vite__cjsImport8_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport8_react["useEffect"]; const useState = __vite__cjsImport8_react["useState"];
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
const AdminApprovalMenu = () => {
  _s();
  const AdminApprovalCategories = [
    {
      id: 1,
      title: "Unverified Customers",
      description: "Manage Unverified Customers for approval",
      icon: /* @__PURE__ */ jsxDEV(Users, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
        lineNumber: 15,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/approval-menu/un-approved-customer",
      stats: "Unapproved Customers"
    },
    {
      id: 2,
      title: "Mobile Enrollments",
      description: "Manage Mobile Enrollments",
      icon: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
        lineNumber: 26,
        columnNumber: 11
      }, this),
      color: "from-amber-600 to-amber-700",
      lightColor: "bg-amber-50",
      borderColor: "border-amber-200",
      href: "/approval-menu/mobile-app-enroll",
      stats: "InActive Enrollments"
    },
    {
      id: 3,
      title: "Unapproved Loans",
      description: "Manage Mobile Enrollments",
      icon: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
        lineNumber: 37,
        columnNumber: 11
      }, this),
      color: "from-red-600 to-red-700",
      lightColor: "bg-red-50",
      borderColor: "border-red-200",
      href: "/approval-menu/un-approved-loans",
      stats: "Unapproved Loans"
    }
  ];
  const [pendingApprovals, setPendingApprovals] = useState();
  useEffect(() => {
    const fetchPendingApprovals = async () => {
      try {
        const response = await api.get("/approvals/count");
        setPendingApprovals(response?.data);
      } catch (error) {
        console.error("Error fetching pending approvals", error);
      }
    };
    fetchPendingApprovals();
  }, []);
  console.log("pending approvals", pendingApprovals?.data);
  const getPendingCount = (categoryId) => {
    if (!pendingApprovals?.data) return 0;
    switch (categoryId) {
      case 1:
        return pendingApprovals.data.unapproved_users;
      case 2:
        return pendingApprovals.data.unapproved_enrollments;
      case 3:
        return pendingApprovals.data.unapproved_loans;
      default:
        return 0;
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
      lineNumber: 84,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
        lineNumber: 86,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-gray-900", children: "Approval Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
            lineNumber: 89,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Manage and organize New Customers and Mobile Enrollment." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
            lineNumber: 92,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
          lineNumber: 88,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-6", children: !pendingApprovals?.data ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
          lineNumber: 99,
          columnNumber: 15
        }, this) : AdminApprovalCategories.map(
          (category) => /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `relative h-full overflow-hidden rounded-xl bg-white border ${category.borderColor} shadow-md hover:shadow-lg transition-all duration-300`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${category.color} opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 transition-all duration-300 blur-xl`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                    lineNumber: 106,
                    columnNumber: 9
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "relative p-7", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `inline-flex items-center justify-center w-14 h-14 ${category.lightColor} rounded-lg mb-5 group-hover:scale-105 transition-transform duration-300`,
                      children: /* @__PURE__ */ jsxDEV("div", { children: category.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                        lineNumber: 114,
                        columnNumber: 13
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                      lineNumber: 111,
                      columnNumber: 11
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-3 z-10", children: /* @__PURE__ */ jsxDEV("div", { className: "\r\n              min-w-[22px] h-[22px] px-1.5\r\n              rounded-full bg-red-500\r\n              text-white text-xs font-semibold\r\n              flex items-center justify-center\r\n              shadow-md ring-2 ring-white\r\n              group-hover:scale-105 transition-transform duration-300\r\n            ", children: getPendingCount(category.id) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                    lineNumber: 118,
                    columnNumber: 13
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                    lineNumber: 117,
                    columnNumber: 11
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-950 transition-colors", children: category.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                      lineNumber: 131,
                      columnNumber: 13
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 leading-relaxed", children: category.description }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                      lineNumber: 134,
                      columnNumber: 13
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                    lineNumber: 130,
                    columnNumber: 11
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-gray-100 group-hover:border-gray-200 transition-colors", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                      lineNumber: 140,
                      columnNumber: 13
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `p-1.5 rounded-lg bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-100 transform translate-x-1 group-hover:translate-x-0 transition-all duration-300`,
                        children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-white" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                          lineNumber: 146,
                          columnNumber: 15
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                        lineNumber: 143,
                        columnNumber: 13
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                    lineNumber: 139,
                    columnNumber: 11
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                  lineNumber: 110,
                  columnNumber: 9
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
                    lineNumber: 151,
                    columnNumber: 9
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
              lineNumber: 103,
              columnNumber: 7
            },
            this
          ) }, category.id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
            lineNumber: 102,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
          lineNumber: 97,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-16 p-8 bg-gradient-to-br from-violet-50 to-indigo-50 rounded-2xl border border-violet-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-violet-600 mt-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
            lineNumber: 163,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
            lineNumber: 162,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900 mb-2", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
              lineNumber: 166,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: "Use the Approval directory to approve new Customers from Mobile, update customer information  all in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
              lineNumber: 167,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: "Use the Approval directory to approve new Enrollments from Mobile update new Enrolled Customer information all in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
              lineNumber: 168,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: "Use the  Approval directory to approve new Loans from Mobile update new Loan Customer information all in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
              lineNumber: 169,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
            lineNumber: 165,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
          lineNumber: 161,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
          lineNumber: 160,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
        lineNumber: 87,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
      lineNumber: 85,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
    lineNumber: 83,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx",
    lineNumber: 82,
    columnNumber: 5
  }, this);
};
_s(AdminApprovalMenu, "QoIz8tQw2iYzp9t2IjnkkWShhBM=");
_c = AdminApprovalMenu;
export default AdminApprovalMenu;
var _c;
$RefreshReg$(_c, "AdminApprovalMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminApprovalsMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY1k7MkJBZFo7QUFBcUIsb0JBQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLE9BQU9BLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxPQUFPQyxXQUFXQyxjQUFjQyxXQUFXO0FBQ3BELE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLG9CQUFvQjtBQUUzQixNQUFNQyxvQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUM5QixRQUFNQywwQkFBMEI7QUFBQSxJQUM5QjtBQUFBLE1BQ0VDLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEI7QUFBQSxNQUNoQ0MsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VSLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEI7QUFBQSxNQUNwQ0MsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VSLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEI7QUFBQSxNQUNwQ0MsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxJQUNUO0FBQUEsRUFBQztBQUdILFFBQU0sQ0FBQ0Msa0JBQWtCQyxtQkFBbUIsSUFBSWYsU0FBUztBQUV6REQsWUFBVSxNQUFNO0FBQ2QsVUFBTWlCLHdCQUF3QixZQUFZO0FBQ3hDLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU1uQixJQUFJb0IsSUFBSSxrQkFBa0I7QUFDakRILDRCQUFvQkUsVUFBVUUsSUFBSTtBQUFBLE1BQ3BDLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sb0NBQW9DQSxLQUFLO0FBQUEsTUFDekQ7QUFBQSxJQUNGO0FBRUFKLDBCQUFzQjtBQUFBLEVBQ3hCLEdBQUcsRUFBRTtBQUVMSyxVQUFRQyxJQUFJLHFCQUFxQlIsa0JBQWtCSyxJQUFJO0FBR3ZELFFBQU1JLGtCQUFrQkEsQ0FBQ0MsZUFBZTtBQUN0QyxRQUFJLENBQUNWLGtCQUFrQkssS0FBTSxRQUFPO0FBRXBDLFlBQVFLLFlBQVU7QUFBQSxNQUNoQixLQUFLO0FBQ0gsZUFBT1YsaUJBQWlCSyxLQUFLTTtBQUFBQSxNQUMvQixLQUFLO0FBQ0gsZUFBT1gsaUJBQWlCSyxLQUFLTztBQUFBQSxNQUMvQixLQUFLO0FBQ0gsZUFBT1osaUJBQWlCSyxLQUFLUTtBQUFBQSxNQUMvQjtBQUNFLGVBQU87QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUlBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkJBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9DQUFtQyxtQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQix3RUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2hCLFdBQUNiLGtCQUFrQkssT0FDNUIsdUJBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDLElBRWhDZix3QkFBd0J3QjtBQUFBQSxVQUFJLENBQUNDLGFBQzNCLHVCQUFDLFFBQXVCLElBQUlBLFNBQVNqQixNQUFNLFdBQVUsU0FDbkQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsOERBQThEaUIsU0FBU2xCLFdBQVc7QUFBQSxjQUU3RjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsc0RBQXNEa0IsU0FBU3BCLEtBQUs7QUFBQTtBQUFBLGtCQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ29MO0FBQUEsZ0JBR3BMLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcscURBQXFEb0IsU0FBU25CLFVBQVU7QUFBQSxzQkFFbkYsaUNBQUMsU0FBS21CLG1CQUFTckIsUUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvQjtBQUFBO0FBQUEsb0JBSHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYixpQ0FBQyxTQUFJLFdBQVUscVVBUVplLDBCQUFnQk0sU0FBU3hCLEVBQUUsS0FSOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDJDQUFDLFFBQUcsV0FBVSxvRkFDWHdCLG1CQUFTdkIsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUNWdUIsbUJBQVN0QixlQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLGlIQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlHQUNic0IsbUJBQVNoQixTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLHNDQUFzQ2dCLFNBQVNwQixLQUFLO0FBQUEsd0JBRS9ELGlDQUFDLGdCQUFhLFdBQVUsd0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTRDO0FBQUE7QUFBQSxzQkFIOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlBO0FBQUEsdUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLHFCQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVDQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsd0RBQXdEb0IsU0FBU3BCLEtBQUs7QUFBQTtBQUFBLGtCQURuRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ3dKO0FBQUE7QUFBQTtBQUFBLFlBakQxSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtREEsS0FwRFNvQixTQUFTeEIsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxREE7QUFBQSxRQUNELEtBM0RTO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4REE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxnR0FDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxPQUFJLFdBQVUsa0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSw2Q0FBNEMsMEJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEUsdUJBQUMsT0FBRSxXQUFVLGtCQUFpQiwrSEFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkk7QUFBQSxZQUM3SSx1QkFBQyxPQUFFLFdBQVUsa0JBQWlCLDRJQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSjtBQUFBLFlBQzFKLHVCQUFDLE9BQUUsV0FBVSxrQkFBaUIsbUlBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlKO0FBQUEsZUFKbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsV0F0RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVGQTtBQUFBLFNBekZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwRkE7QUFBQSxPQTVGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkZBLEtBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErRkE7QUFFSjtBQUFFRixHQTFLSUQsbUJBQWlCO0FBQUE0QixLQUFqQjVCO0FBNEtOLGVBQWVBO0FBQWtCLElBQUE0QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTmF2YmFyIiwiU2lkZWJhciIsIlVzZXJzIiwiQnJpZWZjYXNlIiwiQ2hldnJvblJpZ2h0IiwiWmFwIiwiYXBpIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJDaXJjdWxhckxvYWRlciIsIkFkbWluQXBwcm92YWxNZW51IiwiX3MiLCJBZG1pbkFwcHJvdmFsQ2F0ZWdvcmllcyIsImlkIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImljb24iLCJjb2xvciIsImxpZ2h0Q29sb3IiLCJib3JkZXJDb2xvciIsImhyZWYiLCJzdGF0cyIsInBlbmRpbmdBcHByb3ZhbHMiLCJzZXRQZW5kaW5nQXBwcm92YWxzIiwiZmV0Y2hQZW5kaW5nQXBwcm92YWxzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIiwiZ2V0UGVuZGluZ0NvdW50IiwiY2F0ZWdvcnlJZCIsInVuYXBwcm92ZWRfdXNlcnMiLCJ1bmFwcHJvdmVkX2Vucm9sbG1lbnRzIiwidW5hcHByb3ZlZF9sb2FucyIsIm1hcCIsImNhdGVnb3J5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWRtaW5BcHByb3ZhbHNNZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgVXNlcnMsIEJyaWVmY2FzZSwgQ2hldnJvblJpZ2h0LCBaYXAgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5cclxuY29uc3QgQWRtaW5BcHByb3ZhbE1lbnUgPSAoKSA9PiB7XHJcbiAgY29uc3QgQWRtaW5BcHByb3ZhbENhdGVnb3JpZXMgPSBbXHJcbiAgICB7XHJcbiAgICAgIGlkOiAxLFxyXG4gICAgICB0aXRsZTogXCJVbnZlcmlmaWVkIEN1c3RvbWVyc1wiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgVW52ZXJpZmllZCBDdXN0b21lcnMgZm9yIGFwcHJvdmFsXCIsXHJcbiAgICAgIGljb246IDxVc2VycyBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz4sXHJcbiAgICAgIGNvbG9yOiBcImZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNzAwXCIsXHJcbiAgICAgIGxpZ2h0Q29sb3I6IFwiYmctdmlvbGV0LTUwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci12aW9sZXQtMjAwXCIsXHJcbiAgICAgIGhyZWY6IFwiL2FwcHJvdmFsLW1lbnUvdW4tYXBwcm92ZWQtY3VzdG9tZXJcIixcclxuICAgICAgc3RhdHM6IFwiVW5hcHByb3ZlZCBDdXN0b21lcnNcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAyLFxyXG4gICAgICB0aXRsZTogXCJNb2JpbGUgRW5yb2xsbWVudHNcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIE1vYmlsZSBFbnJvbGxtZW50c1wiLFxyXG4gICAgICBpY29uOiA8QnJpZWZjYXNlIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPixcclxuICAgICAgY29sb3I6IFwiZnJvbS1hbWJlci02MDAgdG8tYW1iZXItNzAwXCIsXHJcbiAgICAgIGxpZ2h0Q29sb3I6IFwiYmctYW1iZXItNTBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLWFtYmVyLTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9hcHByb3ZhbC1tZW51L21vYmlsZS1hcHAtZW5yb2xsXCIsXHJcbiAgICAgIHN0YXRzOiBcIkluQWN0aXZlIEVucm9sbG1lbnRzXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogMyxcclxuICAgICAgdGl0bGU6IFwiVW5hcHByb3ZlZCBMb2Fuc1wiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgTW9iaWxlIEVucm9sbG1lbnRzXCIsXHJcbiAgICAgIGljb246IDxCcmllZmNhc2UgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXJlZC02MDAgdG8tcmVkLTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLXJlZC01MFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItcmVkLTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9hcHByb3ZhbC1tZW51L3VuLWFwcHJvdmVkLWxvYW5zXCIsXHJcbiAgICAgIHN0YXRzOiBcIlVuYXBwcm92ZWQgTG9hbnNcIixcclxuICAgIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgW3BlbmRpbmdBcHByb3ZhbHMsIHNldFBlbmRpbmdBcHByb3ZhbHNdID0gdXNlU3RhdGUoKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUGVuZGluZ0FwcHJvdmFscyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYXBwcm92YWxzL2NvdW50XCIpO1xyXG4gICAgICAgIHNldFBlbmRpbmdBcHByb3ZhbHMocmVzcG9uc2U/LmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwZW5kaW5nIGFwcHJvdmFsc1wiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hQZW5kaW5nQXBwcm92YWxzKCk7XHJcbiAgfSwgW10pOyAvLyDinIUgcnVucyBPTkxZIG9uY2Ugb24gbW91bnRcclxuXHJcbiAgY29uc29sZS5sb2coJ3BlbmRpbmcgYXBwcm92YWxzJywgcGVuZGluZ0FwcHJvdmFscz8uZGF0YSk7XHJcblxyXG5cclxuICBjb25zdCBnZXRQZW5kaW5nQ291bnQgPSAoY2F0ZWdvcnlJZCkgPT4ge1xyXG4gICAgaWYgKCFwZW5kaW5nQXBwcm92YWxzPy5kYXRhKSByZXR1cm4gMFxyXG5cclxuICAgIHN3aXRjaCAoY2F0ZWdvcnlJZCkge1xyXG4gICAgICBjYXNlIDE6XHJcbiAgICAgICAgcmV0dXJuIHBlbmRpbmdBcHByb3ZhbHMuZGF0YS51bmFwcHJvdmVkX3VzZXJzXHJcbiAgICAgIGNhc2UgMjpcclxuICAgICAgICByZXR1cm4gcGVuZGluZ0FwcHJvdmFscy5kYXRhLnVuYXBwcm92ZWRfZW5yb2xsbWVudHNcclxuICAgICAgY2FzZSAzOlxyXG4gICAgICAgIHJldHVybiBwZW5kaW5nQXBwcm92YWxzLmRhdGEudW5hcHByb3ZlZF9sb2Fuc1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiAwXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctZ3JheS01MFwiPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgQXBwcm92YWwgTWFuYWdlbWVudFxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICBNYW5hZ2UgYW5kIG9yZ2FuaXplIE5ldyBDdXN0b21lcnMgYW5kIE1vYmlsZSBFbnJvbGxtZW50LlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuICAgICAgICAgIHshcGVuZGluZ0FwcHJvdmFscz8uZGF0YSA/IChcclxuICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4pIDogKFxyXG4gIEFkbWluQXBwcm92YWxDYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnkpID0+IChcclxuICAgIDxMaW5rIGtleT17Y2F0ZWdvcnkuaWR9IHRvPXtjYXRlZ29yeS5ocmVmfSBjbGFzc05hbWU9XCJncm91cFwiPlxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgaC1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJnLXdoaXRlIGJvcmRlciAke2NhdGVnb3J5LmJvcmRlckNvbG9yfSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctMzIgaC0zMiBiZy1ncmFkaWVudC10by1iciAke2NhdGVnb3J5LmNvbG9yfSBvcGFjaXR5LTUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMCByb3VuZGVkLWZ1bGwgLW1yLTE2IC1tdC0xNiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYmx1ci14bGB9XHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwLTdcIj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTQgaC0xNCAke2NhdGVnb3J5LmxpZ2h0Q29sb3J9IHJvdW5kZWQtbGcgbWItNSBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdj57Y2F0ZWdvcnkuaWNvbn08L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyB6LTEwXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXHJcbiAgICAgICAgICAgICAgbWluLXctWzIycHhdIGgtWzIycHhdIHB4LTEuNVxyXG4gICAgICAgICAgICAgIHJvdW5kZWQtZnVsbCBiZy1yZWQtNTAwXHJcbiAgICAgICAgICAgICAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcclxuICAgICAgICAgICAgICBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclxyXG4gICAgICAgICAgICAgIHNoYWRvdy1tZCByaW5nLTIgcmluZy13aGl0ZVxyXG4gICAgICAgICAgICAgIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcclxuICAgICAgICAgICAgXCI+XHJcbiAgICAgICAgICAgICAge2dldFBlbmRpbmdDb3VudChjYXRlZ29yeS5pZCl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTIgZ3JvdXAtaG92ZXI6dGV4dC1ncmF5LTk1MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgIHtjYXRlZ29yeS50aXRsZX1cclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgIHtjYXRlZ29yeS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZ3JvdXAtaG92ZXI6Ym9yZGVyLWdyYXktMjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBncm91cC1ob3Zlcjp0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAge2NhdGVnb3J5LnN0YXRzfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyICR7Y2F0ZWdvcnkuY29sb3J9IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2Zvcm0gdHJhbnNsYXRlLXgtMSBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT17YGFic29sdXRlIHRvcC0wIGxlZnQtMCByaWdodC0wIGgtMC41IGJnLWdyYWRpZW50LXRvLXIgJHtjYXRlZ29yeS5jb2xvcn0gb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi0zMDBgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9MaW5rPlxyXG4gICkpXHJcbil9XHJcblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xNiBwLTggYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdG8taW5kaWdvLTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItdmlvbGV0LTEwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXZpb2xldC02MDAgbXQtMVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMlwiPlF1aWNrIFRpcHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMFwiPlVzZSB0aGUgQXBwcm92YWwgZGlyZWN0b3J5IHRvIGFwcHJvdmUgbmV3IEN1c3RvbWVycyBmcm9tIE1vYmlsZSwgdXBkYXRlIGN1c3RvbWVyIGluZm9ybWF0aW9uICBhbGwgaW4gb25lIHBsYWNlLjwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDBcIj5Vc2UgdGhlIEFwcHJvdmFsIGRpcmVjdG9yeSB0byBhcHByb3ZlIG5ldyBFbnJvbGxtZW50cyBmcm9tIE1vYmlsZSB1cGRhdGUgbmV3IEVucm9sbGVkIEN1c3RvbWVyIGluZm9ybWF0aW9uIGFsbCBpbiBvbmUgcGxhY2UuPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMFwiPlVzZSB0aGUgIEFwcHJvdmFsIGRpcmVjdG9yeSB0byBhcHByb3ZlIG5ldyBMb2FucyBmcm9tIE1vYmlsZSB1cGRhdGUgbmV3IExvYW4gQ3VzdG9tZXIgaW5mb3JtYXRpb24gYWxsIGluIG9uZSBwbGFjZS48L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFkbWluQXBwcm92YWxNZW51OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9BZG1pbkFwcHJvdmFsc01lbnUuanN4In0=