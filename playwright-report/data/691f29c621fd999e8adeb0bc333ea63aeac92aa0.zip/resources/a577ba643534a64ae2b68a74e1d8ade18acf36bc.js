import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/HardTransfer.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import {
  Button,
  Select,
  Input,
  Drawer,
  Space,
  Form,
  Row,
  Col,
  Spin
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { LoadingOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const HardTransfer = () => {
  _s();
  const [loader, setLoader] = useState(false);
  const [allGroups, setAllGroups] = useState([]);
  const [transferData, setTransferData] = useState([]);
  const [isDataTableLoading, setIsDataTableLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [amountPaid, setAmountPaid] = useState(0);
  const [transferAmount, setTransferAmount] = useState("");
  const [sourceEnrollment, setSourceEnrollment] = useState([]);
  const [destinationEnrollment, setDestinationEnrollment] = useState([]);
  const [deletedEnrollments, setDeletedEnrollments] = useState([]);
  const [notDeletedEnrollments, setNotDeletedEnrollments] = useState([]);
  const fetchTransfers = async () => {
    try {
      setIsDataTableLoading(true);
      const res = await api.get("/enroll/transfer/get-all/Hard");
      const formattedData = (res.data || []).map((transfer, index) => {
        const fromGroupName = transfer?.fromGroup?.group_name || transfer?.fromGroup;
        const toGroupName = transfer?.toGroup?.group_name || transfer?.toGroup;
        const fromUser = transfer?.fromUser || {};
        const toUser = transfer?.toUser || {};
        return {
          _id: transfer._id,
          id: index + 1,
          voucher_id: transfer.voucher_id,
          from_group: fromGroupName,
          to_group: toGroupName,
          from_customer: fromUser.full_name || "-",
          from_phone: fromUser.phone_number || "-",
          from_ticket: transfer?.fromTicket || "-",
          to_customer: toUser.full_name || "-",
          to_phone: toUser.phone_number || "-",
          to_ticket: transfer?.toTicket || "-",
          transfer_amount: transfer?.transferAmount ?? 0,
          transfer_type: transfer?.transferType || "-",
          date: transfer?.createdAt?.split("T")[0] || "-"
        };
      });
      setTransferData(formattedData);
    } catch (err) {
      console.error("Failed to fetch transfers", err);
    } finally {
      setIsDataTableLoading(false);
    }
  };
  const fetchDeletedEnrollments = async () => {
    try {
      const res = await api.get("/enroll/deleted");
      const formattedData = (res.data?.data || []).map((enrollment, index) => {
        return {
          enroll_id: enrollment?._id,
          customer_name: enrollment?.user_id?.full_name,
          customer_phone: enrollment?.user_id?.phone_number,
          customer_id: enrollment?.user_id?.customer_id,
          group_name: enrollment.group_id?.group_name,
          ticket: enrollment.tickets
        };
      });
      setDeletedEnrollments(formattedData);
    } catch (err) {
      console.error("Failed to fetch transfers", err);
      setDeletedEnrollments([]);
    } finally {
    }
  };
  const fetchNotDeletedEnrollments = async () => {
    try {
      const res = await api.get("/enroll/not-deleted");
      const formattedData = (res.data?.data || []).map((enrollment, index) => {
        return {
          enroll_id: enrollment?._id,
          customer_name: enrollment?.user_id?.full_name,
          customer_phone: enrollment?.user_id?.phone_number,
          customer_id: enrollment?.user_id?.customer_id,
          group_name: enrollment.group_id?.group_name,
          ticket: enrollment.tickets
        };
      });
      setNotDeletedEnrollments(formattedData);
    } catch (err) {
      console.error("Failed to fetch transfers", err);
      setNotDeletedEnrollments([]);
    } finally {
    }
  };
  useEffect(() => {
    fetchDeletedEnrollments();
  }, []);
  useEffect(() => {
    fetchNotDeletedEnrollments();
  }, []);
  useEffect(() => {
    fetchTransfers();
  }, []);
  const handleAddTransferClick = () => {
    setShowModal(true);
  };
  const handleChange = (key, value) => {
    switch (key) {
      case "sourceEnrollment":
        setSourceEnrollment(value);
        break;
      case "destinationEnrollment":
        setDestinationEnrollment(value);
        break;
    }
  };
  const fetchAmountPaid = async () => {
    if (!sourceEnrollment) {
      alert("Please select Group, Enrolled Customer, and Ticket first.");
      return;
    }
    try {
      const res = await api.get(
        `/enroll/get-exact-amount-paid/${sourceEnrollment}`
      );
      setAmountPaid(res.data.amountPaid || 0);
      setTransferAmount(res.data.amountPaid || 0);
    } catch (error) {
      setAmountPaid(0);
      console.error("Failed to fetch amount paid", error);
      alert("Could not fetch amount paid.");
    }
  };
  const handleTransfer = async () => {
    if (!sourceEnrollment || !destinationEnrollment || !transferAmount || parseFloat(transferAmount) <= 0) {
      alert("Please fill all fields and enter a valid transfer amount.");
      return;
    }
    if (parseFloat(transferAmount) > amountPaid) {
      alert("Transfer amount cannot exceed amount paid.");
      return;
    }
    try {
      const payload = {
        fromEnrollId: sourceEnrollment,
        toEnrollId: destinationEnrollment,
        amountPaid,
        transferAmount: parseFloat(transferAmount),
        transferType: "Hard"
      };
      const res = await api.post("/enroll/hard-transfer-customer", payload);
      if (res.status === 200 || res.status === 201) {
        const transfer = res.data;
        const formatted = {
          _id: transfer._id,
          id: transferData.length + 1,
          from_enrollment: sourceEnrollment,
          to_enrollment: destinationEnrollment,
          transfer_amount: parseFloat(transferAmount),
          amount_paid: amountPaid,
          transfer_type: "Hard",
          date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
        };
        setTransferData((prev) => [...prev, formatted]);
        alert("Transfer successful!");
        resetForm();
        setShowModal(false);
      } else {
        alert("Transfer failed.");
      }
    } catch (error) {
      console.error("Transfer error:", error);
      alert("Transfer failed. Check console for details.");
    }
  };
  const resetForm = () => {
    setSourceEnrollment("");
    setDestinationEnrollment("");
    setTransferAmount("");
    setAmountPaid(0);
  };
  const columns = [
    { key: "id", header: "Sl No" },
    { key: "voucher_id", header: "Voucher ID" },
    { key: "from_group", header: "From Group" },
    { key: "from_customer", header: "From Customer" },
    { key: "from_ticket", header: "From Ticket" },
    { key: "to_group", header: "To Group" },
    { key: "to_customer", header: "To Customer" },
    { key: "to_ticket", header: "To Ticket" },
    { key: "transfer_amount", header: "Transfer Amount" },
    { key: "transfer_type", header: "Transfer Type" },
    { key: "date", header: "Transfer Date" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
          lineNumber: 233,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
        lineNumber: 237,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Hard Transfer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
            lineNumber: 240,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: handleAddTransferClick,
              className: "bg-violet-950 text-white px-5 py-5 rounded shadow-md hover:bg-violet-800 transition duration-200 text-lg",
              disabled: loader,
              children: loader ? /* @__PURE__ */ jsxDEV(Spin, { indicator: /* @__PURE__ */ jsxDEV(LoadingOutlined, { spin: true }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                lineNumber: 247,
                columnNumber: 32
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                lineNumber: 247,
                columnNumber: 15
              }, this) : "+ Add Transfer"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
              lineNumber: 241,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
          lineNumber: 239,
          columnNumber: 11
        }, this),
        transferData?.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(transferData, searchText),
            columns,
            exportedPdfName: "Hard Amount Transfer",
            exportedFileName: "Hard Amount Transfer.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
            lineNumber: 254,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading: isDataTableLoading,
            failure: transferData?.length === 0,
            data: "Transfers"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
            lineNumber: 261,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
        lineNumber: 238,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
      lineNumber: 232,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: "Add Hard Transfer",
        width: 840,
        onClose: () => setShowModal(false),
        open: showModal,
        styles: {
          body: { paddingBottom: 80, paddingTop: 16, fontSize: "16px" },
          header: { fontSize: "18px", fontWeight: "600" }
        },
        extra: /* @__PURE__ */ jsxDEV(Space, { children: [
          /* @__PURE__ */ jsxDEV(Button, { size: "large", onClick: () => setShowModal(false), children: "Cancel" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
            lineNumber: 281,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "large", type: "primary", onClick: handleTransfer, children: "Submit" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
            lineNumber: 284,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
          lineNumber: 280,
          columnNumber: 9
        }, this),
        children: /* @__PURE__ */ jsxDEV(Form, { layout: "vertical", size: "large", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 24], className: "px-2", children: [
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: [
                "From Customer | Group |Ticket",
                " "
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                lineNumber: 295,
                columnNumber: 17
              }, this),
              children: /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  placeholder: "Select Customer | Group | Ticket",
                  onChange: (value) => handleChange("sourceEnrollment", value),
                  showSearch: true,
                  optionFilterProp: "children",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  style: { fontSize: "16px", height: "52px" },
                  children: deletedEnrollments.filter((e) => e.customer_phone && e.group_name).map(
                    (e) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        className: `${e.deleted ? "text-red-500" : "text-black"}`,
                        value: `${e?.enroll_id}`,
                        children: `${e.customer_name} | ${e.customer_phone} | ${e.customer_id} | ${e.group_name} | Ticket: ${e.ticket}`
                      },
                      e?.enroll_id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                        lineNumber: 314,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                  lineNumber: 300,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
              lineNumber: 293,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
            lineNumber: 292,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "To Customer | Group | Ticket" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                lineNumber: 331,
                columnNumber: 17
              }, this),
              children: /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  placeholder: "Select Customer | Group | Ticket",
                  onChange: (value) => handleChange("destinationEnrollment", value),
                  showSearch: true,
                  optionFilterProp: "children",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  style: { fontSize: "16px", height: "52px" },
                  children: notDeletedEnrollments.filter((e) => e.customer_phone && e.group_name).map(
                    (e) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        className: `${e.deleted ? "text-red-500" : "text-black"}`,
                        value: `${e?.enroll_id}`,
                        children: `${e.customer_name} | ${e.customer_phone} | ${e.customer_id} | ${e.group_name} | Ticket: ${e.ticket}`
                      },
                      e?.enroll_id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                        lineNumber: 352,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                  lineNumber: 336,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
              lineNumber: 329,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
            lineNumber: 328,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: fetchAmountPaid,
              size: "large",
              type: "primary",
              style: {
                width: "100%",
                height: "52px",
                fontSize: "16px",
                fontWeight: "500",
                backgroundColor: "#1e40af"
              },
              children: "Check Total Amount Paid"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
              lineNumber: 367,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
            lineNumber: 366,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Transfer Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                lineNumber: 385,
                columnNumber: 24
              }, this),
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  size: "large",
                  placeholder: "Transfer Amount",
                  value: transferAmount || 0,
                  onChange: (e) => handleChange("transfer_amount", e.target.value),
                  style: { fontSize: "16px", height: "52px" },
                  disabled: true
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
                  lineNumber: 387,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
              lineNumber: 384,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
            lineNumber: 383,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
          lineNumber: 291,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
          lineNumber: 290,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
        lineNumber: 270,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx",
    lineNumber: 231,
    columnNumber: 5
  }, this);
};
_s(HardTransfer, "FchIT1VQSXk1ezdoDgE3ziDnQfU=");
_c = HardTransfer;
export default HardTransfer;
var _c;
$RefreshReg$(_c, "HardTransfer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HardTransfer.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc09JLG1CQUVJLGNBRko7MkJBdE9KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUNFQTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyx1QkFBdUI7QUFFaEMsTUFBTUMsZUFBZUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3pCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJVixTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDVyxXQUFXQyxZQUFZLElBQUlaLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNhLGNBQWNDLGVBQWUsSUFBSWQsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ2Usb0JBQW9CQyxxQkFBcUIsSUFBSWhCLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNpQixZQUFZQyxhQUFhLElBQUlsQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUIsV0FBV0MsWUFBWSxJQUFJcEIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3FCLFlBQVlDLGFBQWEsSUFBSXRCLFNBQVMsQ0FBQztBQUM5QyxRQUFNLENBQUN1QixnQkFBZ0JDLGlCQUFpQixJQUFJeEIsU0FBUyxFQUFFO0FBRXZELFFBQU0sQ0FBQ3lCLGtCQUFrQkMsbUJBQW1CLElBQUkxQixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDMkIsdUJBQXVCQyx3QkFBd0IsSUFBSTVCLFNBQVMsRUFBRTtBQUVyRSxRQUFNLENBQUM2QixvQkFBb0JDLHFCQUFxQixJQUFJOUIsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQytCLHVCQUF1QkMsd0JBQXdCLElBQUloQyxTQUFTLEVBQUU7QUFFckUsUUFBTWlDLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRmpCLDRCQUFzQixJQUFJO0FBQzFCLFlBQU1rQixNQUFNLE1BQU1qQyxJQUFJa0MsSUFBSSwrQkFBK0I7QUFFekQsWUFBTUMsaUJBQWlCRixJQUFJRyxRQUFRLElBQUlDLElBQUksQ0FBQ0MsVUFBVUMsVUFBVTtBQUM5RCxjQUFNQyxnQkFDSkYsVUFBVUcsV0FBV0MsY0FBY0osVUFBVUc7QUFDL0MsY0FBTUUsY0FBY0wsVUFBVU0sU0FBU0YsY0FBY0osVUFBVU07QUFDL0QsY0FBTUMsV0FBV1AsVUFBVU8sWUFBWSxDQUFDO0FBQ3hDLGNBQU1DLFNBQVNSLFVBQVVRLFVBQVUsQ0FBQztBQUVwQyxlQUFPO0FBQUEsVUFDTEMsS0FBS1QsU0FBU1M7QUFBQUEsVUFDZEMsSUFBSVQsUUFBUTtBQUFBLFVBQ1pVLFlBQVlYLFNBQVNXO0FBQUFBLFVBQ3JCQyxZQUFZVjtBQUFBQSxVQUNaVyxVQUFVUjtBQUFBQSxVQUNWUyxlQUFlUCxTQUFTUSxhQUFhO0FBQUEsVUFDckNDLFlBQVlULFNBQVNVLGdCQUFnQjtBQUFBLFVBQ3JDQyxhQUFhbEIsVUFBVW1CLGNBQWM7QUFBQSxVQUNyQ0MsYUFBYVosT0FBT08sYUFBYTtBQUFBLFVBQ2pDTSxVQUFVYixPQUFPUyxnQkFBZ0I7QUFBQSxVQUNqQ0ssV0FBV3RCLFVBQVV1QixZQUFZO0FBQUEsVUFDakNDLGlCQUFpQnhCLFVBQVVoQixrQkFBa0I7QUFBQSxVQUM3Q3lDLGVBQWV6QixVQUFVMEIsZ0JBQWdCO0FBQUEsVUFDekNDLE1BQU0zQixVQUFVNEIsV0FBV0MsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsUUFDOUM7QUFBQSxNQUNGLENBQUM7QUFDRHRELHNCQUFnQnNCLGFBQWE7QUFBQSxJQUMvQixTQUFTaUMsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDZCQUE2QkYsR0FBRztBQUFBLElBQ2hELFVBQUM7QUFDQ3JELDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUEsUUFBTXdELDBCQUEwQixZQUFZO0FBQzFDLFFBQUk7QUFDRixZQUFNdEMsTUFBTSxNQUFNakMsSUFBSWtDLElBQUksaUJBQWlCO0FBRTNDLFlBQU1DLGlCQUFpQkYsSUFBSUcsTUFBTUEsUUFBUSxJQUFJQyxJQUFJLENBQUNtQyxZQUFZakMsVUFBVTtBQUN0RSxlQUFPO0FBQUEsVUFDTGtDLFdBQVdELFlBQVl6QjtBQUFBQSxVQUN2QjJCLGVBQWVGLFlBQVlHLFNBQVN0QjtBQUFBQSxVQUNwQ3VCLGdCQUFnQkosWUFBWUcsU0FBU3BCO0FBQUFBLFVBQ3JDc0IsYUFBYUwsWUFBWUcsU0FBU0U7QUFBQUEsVUFDbENuQyxZQUFZOEIsV0FBV00sVUFBVXBDO0FBQUFBLFVBQ2pDcUMsUUFBUVAsV0FBV1E7QUFBQUEsUUFDckI7QUFBQSxNQUNGLENBQUM7QUFDRG5ELDRCQUFzQk0sYUFBYTtBQUFBLElBQ3JDLFNBQVNpQyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sNkJBQTZCRixHQUFHO0FBQzlDdkMsNEJBQXNCLEVBQUU7QUFBQSxJQUMxQixVQUFDO0FBQUEsSUFDRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNb0QsNkJBQTZCLFlBQVk7QUFDN0MsUUFBSTtBQUNGLFlBQU1oRCxNQUFNLE1BQU1qQyxJQUFJa0MsSUFBSSxxQkFBcUI7QUFFL0MsWUFBTUMsaUJBQWlCRixJQUFJRyxNQUFNQSxRQUFRLElBQUlDLElBQUksQ0FBQ21DLFlBQVlqQyxVQUFVO0FBQ3RFLGVBQU87QUFBQSxVQUNMa0MsV0FBV0QsWUFBWXpCO0FBQUFBLFVBQ3ZCMkIsZUFBZUYsWUFBWUcsU0FBU3RCO0FBQUFBLFVBQ3BDdUIsZ0JBQWdCSixZQUFZRyxTQUFTcEI7QUFBQUEsVUFDckNzQixhQUFhTCxZQUFZRyxTQUFTRTtBQUFBQSxVQUNsQ25DLFlBQVk4QixXQUFXTSxVQUFVcEM7QUFBQUEsVUFDakNxQyxRQUFRUCxXQUFXUTtBQUFBQSxRQUNyQjtBQUFBLE1BQ0YsQ0FBQztBQUNEakQsK0JBQXlCSSxhQUFhO0FBQUEsSUFDeEMsU0FBU2lDLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSw2QkFBNkJGLEdBQUc7QUFDOUNyQywrQkFBeUIsRUFBRTtBQUFBLElBQzdCLFVBQUM7QUFBQSxJQUNEO0FBQUEsRUFDRjtBQUVBakMsWUFBVSxNQUFNO0FBQ2R5RSw0QkFBd0I7QUFBQSxFQUMxQixHQUFHLEVBQUU7QUFFTHpFLFlBQVUsTUFBTTtBQUNkbUYsK0JBQTJCO0FBQUEsRUFDN0IsR0FBRyxFQUFFO0FBQ0xuRixZQUFVLE1BQU07QUFDZGtDLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBQ0wsUUFBTWtELHlCQUF5QkEsTUFBTTtBQUNuQy9ELGlCQUFhLElBQUk7QUFBQSxFQUNuQjtBQUNBLFFBQU1nRSxlQUFlQSxDQUFDQyxLQUFLQyxVQUFVO0FBQ25DLFlBQVFELEtBQUc7QUFBQSxNQUNULEtBQUs7QUFDSDNELDRCQUFvQjRELEtBQUs7QUFDekI7QUFBQSxNQUNGLEtBQUs7QUFDSDFELGlDQUF5QjBELEtBQUs7QUFDOUI7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUVBLFFBQU1DLGtCQUFrQixZQUFZO0FBQ2xDLFFBQUksQ0FBQzlELGtCQUFrQjtBQUNyQitELFlBQU0sMkRBQTJEO0FBQ2pFO0FBQUEsSUFDRjtBQUNBLFFBQUk7QUFDRixZQUFNdEQsTUFBTSxNQUFNakMsSUFBSWtDO0FBQUFBLFFBQ3BCLGlDQUFpQ1YsZ0JBQWdCO0FBQUEsTUFDbkQ7QUFDQUgsb0JBQWNZLElBQUlHLEtBQUtoQixjQUFjLENBQUM7QUFDdENHLHdCQUFrQlUsSUFBSUcsS0FBS2hCLGNBQWMsQ0FBQztBQUFBLElBQzVDLFNBQVNrRCxPQUFPO0FBQ2RqRCxvQkFBYyxDQUFDO0FBQ2ZnRCxjQUFRQyxNQUFNLCtCQUErQkEsS0FBSztBQUNsRGlCLFlBQU0sOEJBQThCO0FBQUEsSUFDdEM7QUFBQSxFQUNGO0FBRUEsUUFBTUMsaUJBQWlCLFlBQVk7QUFDakMsUUFDRSxDQUFDaEUsb0JBQ0QsQ0FBQ0UseUJBQ0QsQ0FBQ0osa0JBQ0RtRSxXQUFXbkUsY0FBYyxLQUFLLEdBQzlCO0FBQ0FpRSxZQUFNLDJEQUEyRDtBQUNqRTtBQUFBLElBQ0Y7QUFFQSxRQUFJRSxXQUFXbkUsY0FBYyxJQUFJRixZQUFZO0FBQzNDbUUsWUFBTSw0Q0FBNEM7QUFDbEQ7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGLFlBQU1HLFVBQVU7QUFBQSxRQUNkQyxjQUFjbkU7QUFBQUEsUUFDZG9FLFlBQVlsRTtBQUFBQSxRQUNaTjtBQUFBQSxRQUNBRSxnQkFBZ0JtRSxXQUFXbkUsY0FBYztBQUFBLFFBQ3pDMEMsY0FBYztBQUFBLE1BQ2hCO0FBQ0EsWUFBTS9CLE1BQU0sTUFBTWpDLElBQUk2RixLQUFLLGtDQUFrQ0gsT0FBTztBQUNwRSxVQUFJekQsSUFBSTZELFdBQVcsT0FBTzdELElBQUk2RCxXQUFXLEtBQUs7QUFDNUMsY0FBTXhELFdBQVdMLElBQUlHO0FBQ3JCLGNBQU0yRCxZQUFZO0FBQUEsVUFDaEJoRCxLQUFLVCxTQUFTUztBQUFBQSxVQUNkQyxJQUFJcEMsYUFBYW9GLFNBQVM7QUFBQSxVQUMxQkMsaUJBQWlCekU7QUFBQUEsVUFDakIwRSxlQUFleEU7QUFBQUEsVUFDZm9DLGlCQUFpQjJCLFdBQVduRSxjQUFjO0FBQUEsVUFDMUM2RSxhQUFhL0U7QUFBQUEsVUFDYjJDLGVBQWU7QUFBQSxVQUNmRSxPQUFNLG9CQUFJbUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVsQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDN0M7QUFDQXRELHdCQUFnQixDQUFDeUYsU0FBUyxDQUFDLEdBQUdBLE1BQU1QLFNBQVMsQ0FBQztBQUM5Q1IsY0FBTSxzQkFBc0I7QUFDNUJnQixrQkFBVTtBQUNWcEYscUJBQWEsS0FBSztBQUFBLE1BQ3BCLE9BQU87QUFDTG9FLGNBQU0sa0JBQWtCO0FBQUEsTUFDMUI7QUFBQSxJQUNGLFNBQVNqQixPQUFPO0FBQ2RELGNBQVFDLE1BQU0sbUJBQW1CQSxLQUFLO0FBQ3RDaUIsWUFBTSw2Q0FBNkM7QUFBQSxJQUNyRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0IsWUFBWUEsTUFBTTtBQUN0QjlFLHdCQUFvQixFQUFFO0FBQ3RCRSw2QkFBeUIsRUFBRTtBQUMzQkosc0JBQWtCLEVBQUU7QUFDcEJGLGtCQUFjLENBQUM7QUFBQSxFQUNqQjtBQUVBLFFBQU1tRixVQUFVO0FBQUEsSUFDZCxFQUFFcEIsS0FBSyxNQUFNcUIsUUFBUSxRQUFRO0FBQUEsSUFDN0IsRUFBRXJCLEtBQUssY0FBY3FCLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVyQixLQUFLLGNBQWNxQixRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFckIsS0FBSyxpQkFBaUJxQixRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUVyQixLQUFLLGVBQWVxQixRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFckIsS0FBSyxZQUFZcUIsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRXJCLEtBQUssZUFBZXFCLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVyQixLQUFLLGFBQWFxQixRQUFRLFlBQVk7QUFBQSxJQUN4QyxFQUFFckIsS0FBSyxtQkFBbUJxQixRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVyQixLQUFLLGlCQUFpQnFCLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRXJCLEtBQUssUUFBUXFCLFFBQVEsZ0JBQWdCO0FBQUEsRUFBQztBQUcxQyxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCLENBQUNDLE1BQU16RixjQUFjeUYsRUFBRUMsT0FBT3RCLEtBQUs7QUFBQSxVQUNoRSxZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLDZCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQ3BEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTSDtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUNWLFVBQVUxRTtBQUFBQSxjQUVUQSxtQkFDQyx1QkFBQyxRQUFLLFdBQVcsdUJBQUMsbUJBQWdCLE1BQUksUUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUIsS0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEMsSUFFMUM7QUFBQTtBQUFBLFlBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0NJLGNBQWNvRixTQUFTLElBQ3RCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNNUYsYUFBYVEsY0FBY0ksVUFBVTtBQUFBLFlBQzNDO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBaUI7QUFBQTtBQUFBLFVBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk2QyxJQUc3QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBV0Y7QUFBQUEsWUFDWCxTQUFTRixjQUFjb0YsV0FBVztBQUFBLFlBQ2xDLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR2tCO0FBQUEsV0ExQnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxTQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0NBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sT0FBTztBQUFBLFFBQ1AsU0FBUyxNQUFNN0UsYUFBYSxLQUFLO0FBQUEsUUFDakMsTUFBTUQ7QUFBQUEsUUFDTixRQUFRO0FBQUEsVUFDTjBGLE1BQU0sRUFBRUMsZUFBZSxJQUFJQyxZQUFZLElBQUlDLFVBQVUsT0FBTztBQUFBLFVBQzVETixRQUFRLEVBQUVNLFVBQVUsUUFBUUMsWUFBWSxNQUFNO0FBQUEsUUFDaEQ7QUFBQSxRQUNBLE9BQ0UsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVMsTUFBTTdGLGFBQWEsS0FBSyxHQUFHLHNCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLE1BQUssU0FBUSxNQUFLLFdBQVUsU0FBU3FFLGdCQUFnQixzQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFHRixpQ0FBQyxRQUFLLFFBQU8sWUFBVyxNQUFLLFNBQzNCLGlDQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQUFHLFdBQVUsUUFDL0I7QUFBQSxpQ0FBQyxPQUFJLE1BQU0sSUFDVDtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQ0UsdUJBQUMsVUFBSyxXQUFVLGVBQWM7QUFBQTtBQUFBLGdCQUNFO0FBQUEsbUJBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUdGO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxhQUFZO0FBQUEsa0JBQ1osVUFBVSxDQUFDSCxVQUFVRixhQUFhLG9CQUFvQkUsS0FBSztBQUFBLGtCQUMzRDtBQUFBLGtCQUNBLGtCQUFpQjtBQUFBLGtCQUNqQixjQUFjLENBQUM0QixPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0MsWUFBWSxFQUFFQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxrQkFFNUQsT0FBTyxFQUFFTCxVQUFVLFFBQVFPLFFBQVEsT0FBTztBQUFBLGtCQUV6QzFGLDZCQUNFMkYsT0FBTyxDQUFDYixNQUFNQSxFQUFFOUIsa0JBQWtCOEIsRUFBRWhFLFVBQVUsRUFDOUNMO0FBQUFBLG9CQUFJLENBQUNxRSxNQUNKO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBQ0MsV0FBVyxHQUNUQSxFQUFFYyxVQUFVLGlCQUFpQixZQUFZO0FBQUEsd0JBRzNDLE9BQU8sR0FBR2QsR0FBR2pDLFNBQVM7QUFBQSx3QkFFckIsYUFBR2lDLEVBQUVoQyxhQUFhLE1BQU1nQyxFQUFFOUIsY0FBYyxNQUFNOEIsRUFBRTdCLFdBQVcsTUFBTTZCLEVBQUVoRSxVQUFVLGNBQWNnRSxFQUFFM0IsTUFBTTtBQUFBO0FBQUEsc0JBSC9GMkIsR0FBR2pDO0FBQUFBLHNCQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBdkJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXdCQTtBQUFBO0FBQUEsWUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZ0NBLEtBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0NBO0FBQUEsVUFFQSx1QkFBQyxPQUFJLE1BQU0sSUFDVDtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQ0UsdUJBQUMsVUFBSyxXQUFVLGVBQWMsNENBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUdGO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxhQUFZO0FBQUEsa0JBQ1osVUFBVSxDQUFDWSxVQUNURixhQUFhLHlCQUF5QkUsS0FBSztBQUFBLGtCQUU3QztBQUFBLGtCQUNBLGtCQUFpQjtBQUFBLGtCQUNqQixjQUFjLENBQUM0QixPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0MsWUFBWSxFQUFFQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxrQkFFNUQsT0FBTyxFQUFFTCxVQUFVLFFBQVFPLFFBQVEsT0FBTztBQUFBLGtCQUV6Q3hGLGdDQUNFeUYsT0FBTyxDQUFDYixNQUFNQSxFQUFFOUIsa0JBQWtCOEIsRUFBRWhFLFVBQVUsRUFDOUNMO0FBQUFBLG9CQUFJLENBQUNxRSxNQUNKO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBQ0MsV0FBVyxHQUNUQSxFQUFFYyxVQUFVLGlCQUFpQixZQUFZO0FBQUEsd0JBRzNDLE9BQU8sR0FBR2QsR0FBR2pDLFNBQVM7QUFBQSx3QkFFckIsYUFBR2lDLEVBQUVoQyxhQUFhLE1BQU1nQyxFQUFFOUIsY0FBYyxNQUFNOEIsRUFBRTdCLFdBQVcsTUFBTTZCLEVBQUVoRSxVQUFVLGNBQWNnRSxFQUFFM0IsTUFBTTtBQUFBO0FBQUEsc0JBSC9GMkIsR0FBR2pDO0FBQUFBLHNCQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBekJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTBCQTtBQUFBO0FBQUEsWUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0NBO0FBQUEsVUFFQSx1QkFBQyxPQUFJLE1BQU0sSUFDVDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU2E7QUFBQUEsY0FDVCxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPO0FBQUEsZ0JBQ0xtQyxPQUFPO0FBQUEsZ0JBQ1BILFFBQVE7QUFBQSxnQkFDUlAsVUFBVTtBQUFBLGdCQUNWQyxZQUFZO0FBQUEsZ0JBQ1pVLGlCQUFpQjtBQUFBLGNBQ25CO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUVBLHVCQUFDLE9BQUksTUFBTSxJQUNUO0FBQUEsWUFBQyxLQUFLO0FBQUEsWUFBTDtBQUFBLGNBQ0MsT0FBTyx1QkFBQyxVQUFLLFdBQVUsZUFBYywrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkM7QUFBQSxjQUVwRDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLE9BQU9wRyxrQkFBa0I7QUFBQSxrQkFDekIsVUFBVSxDQUFDb0YsTUFDVHZCLGFBQWEsbUJBQW1CdUIsRUFBRUMsT0FBT3RCLEtBQUs7QUFBQSxrQkFFaEQsT0FBTyxFQUFFMEIsVUFBVSxRQUFRTyxRQUFRLE9BQU87QUFBQSxrQkFDMUMsVUFBUTtBQUFBO0FBQUEsZ0JBUlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUVU7QUFBQTtBQUFBLFlBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsYUEzR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRHQSxLQTdHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEdBO0FBQUE7QUFBQSxNQWxJRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFtSUE7QUFBQSxPQTFLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMktBO0FBRUo7QUFBRS9HLEdBL1hJRCxjQUFZO0FBQUFxSCxLQUFackg7QUFpWU4sZUFBZUE7QUFBYSxJQUFBcUg7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsIlNlbGVjdCIsIklucHV0IiwiRHJhd2VyIiwiU3BhY2UiLCJGb3JtIiwiUm93IiwiQ29sIiwiU3BpbiIsIlNpZGViYXIiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImFwaSIsIk5hdmJhciIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiZmlsdGVyT3B0aW9uIiwiTG9hZGluZ091dGxpbmVkIiwiSGFyZFRyYW5zZmVyIiwiX3MiLCJsb2FkZXIiLCJzZXRMb2FkZXIiLCJhbGxHcm91cHMiLCJzZXRBbGxHcm91cHMiLCJ0cmFuc2ZlckRhdGEiLCJzZXRUcmFuc2ZlckRhdGEiLCJpc0RhdGFUYWJsZUxvYWRpbmciLCJzZXRJc0RhdGFUYWJsZUxvYWRpbmciLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsImFtb3VudFBhaWQiLCJzZXRBbW91bnRQYWlkIiwidHJhbnNmZXJBbW91bnQiLCJzZXRUcmFuc2ZlckFtb3VudCIsInNvdXJjZUVucm9sbG1lbnQiLCJzZXRTb3VyY2VFbnJvbGxtZW50IiwiZGVzdGluYXRpb25FbnJvbGxtZW50Iiwic2V0RGVzdGluYXRpb25FbnJvbGxtZW50IiwiZGVsZXRlZEVucm9sbG1lbnRzIiwic2V0RGVsZXRlZEVucm9sbG1lbnRzIiwibm90RGVsZXRlZEVucm9sbG1lbnRzIiwic2V0Tm90RGVsZXRlZEVucm9sbG1lbnRzIiwiZmV0Y2hUcmFuc2ZlcnMiLCJyZXMiLCJnZXQiLCJmb3JtYXR0ZWREYXRhIiwiZGF0YSIsIm1hcCIsInRyYW5zZmVyIiwiaW5kZXgiLCJmcm9tR3JvdXBOYW1lIiwiZnJvbUdyb3VwIiwiZ3JvdXBfbmFtZSIsInRvR3JvdXBOYW1lIiwidG9Hcm91cCIsImZyb21Vc2VyIiwidG9Vc2VyIiwiX2lkIiwiaWQiLCJ2b3VjaGVyX2lkIiwiZnJvbV9ncm91cCIsInRvX2dyb3VwIiwiZnJvbV9jdXN0b21lciIsImZ1bGxfbmFtZSIsImZyb21fcGhvbmUiLCJwaG9uZV9udW1iZXIiLCJmcm9tX3RpY2tldCIsImZyb21UaWNrZXQiLCJ0b19jdXN0b21lciIsInRvX3Bob25lIiwidG9fdGlja2V0IiwidG9UaWNrZXQiLCJ0cmFuc2Zlcl9hbW91bnQiLCJ0cmFuc2Zlcl90eXBlIiwidHJhbnNmZXJUeXBlIiwiZGF0ZSIsImNyZWF0ZWRBdCIsInNwbGl0IiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiZmV0Y2hEZWxldGVkRW5yb2xsbWVudHMiLCJlbnJvbGxtZW50IiwiZW5yb2xsX2lkIiwiY3VzdG9tZXJfbmFtZSIsInVzZXJfaWQiLCJjdXN0b21lcl9waG9uZSIsImN1c3RvbWVyX2lkIiwiZ3JvdXBfaWQiLCJ0aWNrZXQiLCJ0aWNrZXRzIiwiZmV0Y2hOb3REZWxldGVkRW5yb2xsbWVudHMiLCJoYW5kbGVBZGRUcmFuc2ZlckNsaWNrIiwiaGFuZGxlQ2hhbmdlIiwia2V5IiwidmFsdWUiLCJmZXRjaEFtb3VudFBhaWQiLCJhbGVydCIsImhhbmRsZVRyYW5zZmVyIiwicGFyc2VGbG9hdCIsInBheWxvYWQiLCJmcm9tRW5yb2xsSWQiLCJ0b0Vucm9sbElkIiwicG9zdCIsInN0YXR1cyIsImZvcm1hdHRlZCIsImxlbmd0aCIsImZyb21fZW5yb2xsbWVudCIsInRvX2Vucm9sbG1lbnQiLCJhbW91bnRfcGFpZCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInByZXYiLCJyZXNldEZvcm0iLCJjb2x1bW5zIiwiaGVhZGVyIiwiZSIsInRhcmdldCIsImJvZHkiLCJwYWRkaW5nQm90dG9tIiwicGFkZGluZ1RvcCIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiaGVpZ2h0IiwiZmlsdGVyIiwiZGVsZXRlZCIsIndpZHRoIiwiYmFja2dyb3VuZENvbG9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSGFyZFRyYW5zZmVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gIEJ1dHRvbixcclxuICBTZWxlY3QsXHJcbiAgSW5wdXQsXHJcbiAgRHJhd2VyLFxyXG4gIFNwYWNlLFxyXG4gIEZvcm0sXHJcbiAgUm93LFxyXG4gIENvbCxcclxuICBTcGluLFxyXG59IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCB7IExvYWRpbmdPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5cclxuY29uc3QgSGFyZFRyYW5zZmVyID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtsb2FkZXIsIHNldExvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FsbEdyb3Vwcywgc2V0QWxsR3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdHJhbnNmZXJEYXRhLCBzZXRUcmFuc2ZlckRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0RhdGFUYWJsZUxvYWRpbmcsIHNldElzRGF0YVRhYmxlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYW1vdW50UGFpZCwgc2V0QW1vdW50UGFpZF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbdHJhbnNmZXJBbW91bnQsIHNldFRyYW5zZmVyQW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBbc291cmNlRW5yb2xsbWVudCwgc2V0U291cmNlRW5yb2xsbWVudF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2Rlc3RpbmF0aW9uRW5yb2xsbWVudCwgc2V0RGVzdGluYXRpb25FbnJvbGxtZW50XSA9IHVzZVN0YXRlKFtdKTtcclxuICAvL2tub3duIGVub2xsbWVudHNcclxuICBjb25zdCBbZGVsZXRlZEVucm9sbG1lbnRzLCBzZXREZWxldGVkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtub3REZWxldGVkRW5yb2xsbWVudHMsIHNldE5vdERlbGV0ZWRFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoVHJhbnNmZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNEYXRhVGFibGVMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2Vucm9sbC90cmFuc2Zlci9nZXQtYWxsL0hhcmRcIik7XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gKHJlcy5kYXRhIHx8IFtdKS5tYXAoKHRyYW5zZmVyLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGZyb21Hcm91cE5hbWUgPVxyXG4gICAgICAgICAgdHJhbnNmZXI/LmZyb21Hcm91cD8uZ3JvdXBfbmFtZSB8fCB0cmFuc2Zlcj8uZnJvbUdyb3VwO1xyXG4gICAgICAgIGNvbnN0IHRvR3JvdXBOYW1lID0gdHJhbnNmZXI/LnRvR3JvdXA/Lmdyb3VwX25hbWUgfHwgdHJhbnNmZXI/LnRvR3JvdXA7XHJcbiAgICAgICAgY29uc3QgZnJvbVVzZXIgPSB0cmFuc2Zlcj8uZnJvbVVzZXIgfHwge307XHJcbiAgICAgICAgY29uc3QgdG9Vc2VyID0gdHJhbnNmZXI/LnRvVXNlciB8fCB7fTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIF9pZDogdHJhbnNmZXIuX2lkLFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgIHZvdWNoZXJfaWQ6IHRyYW5zZmVyLnZvdWNoZXJfaWQsXHJcbiAgICAgICAgICBmcm9tX2dyb3VwOiBmcm9tR3JvdXBOYW1lLFxyXG4gICAgICAgICAgdG9fZ3JvdXA6IHRvR3JvdXBOYW1lLFxyXG4gICAgICAgICAgZnJvbV9jdXN0b21lcjogZnJvbVVzZXIuZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgZnJvbV9waG9uZTogZnJvbVVzZXIucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgZnJvbV90aWNrZXQ6IHRyYW5zZmVyPy5mcm9tVGlja2V0IHx8IFwiLVwiLFxyXG4gICAgICAgICAgdG9fY3VzdG9tZXI6IHRvVXNlci5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICB0b19waG9uZTogdG9Vc2VyLnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgIHRvX3RpY2tldDogdHJhbnNmZXI/LnRvVGlja2V0IHx8IFwiLVwiLFxyXG4gICAgICAgICAgdHJhbnNmZXJfYW1vdW50OiB0cmFuc2Zlcj8udHJhbnNmZXJBbW91bnQgPz8gMCxcclxuICAgICAgICAgIHRyYW5zZmVyX3R5cGU6IHRyYW5zZmVyPy50cmFuc2ZlclR5cGUgfHwgXCItXCIsXHJcbiAgICAgICAgICBkYXRlOiB0cmFuc2Zlcj8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF0gfHwgXCItXCIsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFRyYW5zZmVyRGF0YShmb3JtYXR0ZWREYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRyYW5zZmVyc1wiLCBlcnIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNEYXRhVGFibGVMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaERlbGV0ZWRFbnJvbGxtZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvZW5yb2xsL2RlbGV0ZWRcIik7XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gKHJlcy5kYXRhPy5kYXRhIHx8IFtdKS5tYXAoKGVucm9sbG1lbnQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGVucm9sbF9pZDogZW5yb2xsbWVudD8uX2lkLFxyXG4gICAgICAgICAgY3VzdG9tZXJfbmFtZTogZW5yb2xsbWVudD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgY3VzdG9tZXJfcGhvbmU6IGVucm9sbG1lbnQ/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgIGN1c3RvbWVyX2lkOiBlbnJvbGxtZW50Py51c2VyX2lkPy5jdXN0b21lcl9pZCxcclxuICAgICAgICAgIGdyb3VwX25hbWU6IGVucm9sbG1lbnQuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICB0aWNrZXQ6IGVucm9sbG1lbnQudGlja2V0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuICAgICAgc2V0RGVsZXRlZEVucm9sbG1lbnRzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggdHJhbnNmZXJzXCIsIGVycik7XHJcbiAgICAgIHNldERlbGV0ZWRFbnJvbGxtZW50cyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgZmV0Y2hOb3REZWxldGVkRW5yb2xsbWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2Vucm9sbC9ub3QtZGVsZXRlZFwiKTtcclxuXHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSAocmVzLmRhdGE/LmRhdGEgfHwgW10pLm1hcCgoZW5yb2xsbWVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgZW5yb2xsX2lkOiBlbnJvbGxtZW50Py5faWQsXHJcbiAgICAgICAgICBjdXN0b21lcl9uYW1lOiBlbnJvbGxtZW50Py51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICBjdXN0b21lcl9waG9uZTogZW5yb2xsbWVudD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgY3VzdG9tZXJfaWQ6IGVucm9sbG1lbnQ/LnVzZXJfaWQ/LmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgZ3JvdXBfbmFtZTogZW5yb2xsbWVudC5ncm91cF9pZD8uZ3JvdXBfbmFtZSxcclxuICAgICAgICAgIHRpY2tldDogZW5yb2xsbWVudC50aWNrZXRzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXROb3REZWxldGVkRW5yb2xsbWVudHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0cmFuc2ZlcnNcIiwgZXJyKTtcclxuICAgICAgc2V0Tm90RGVsZXRlZEVucm9sbG1lbnRzKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGVsZXRlZEVucm9sbG1lbnRzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hOb3REZWxldGVkRW5yb2xsbWVudHMoKTtcclxuICB9LCBbXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoVHJhbnNmZXJzKCk7XHJcbiAgfSwgW10pO1xyXG4gIGNvbnN0IGhhbmRsZUFkZFRyYW5zZmVyQ2xpY2sgPSAoKSA9PiB7XHJcbiAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoa2V5LCB2YWx1ZSkgPT4ge1xyXG4gICAgc3dpdGNoIChrZXkpIHtcclxuICAgICAgY2FzZSBcInNvdXJjZUVucm9sbG1lbnRcIjpcclxuICAgICAgICBzZXRTb3VyY2VFbnJvbGxtZW50KHZhbHVlKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSBcImRlc3RpbmF0aW9uRW5yb2xsbWVudFwiOlxyXG4gICAgICAgIHNldERlc3RpbmF0aW9uRW5yb2xsbWVudCh2YWx1ZSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBbW91bnRQYWlkID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFzb3VyY2VFbnJvbGxtZW50KSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBHcm91cCwgRW5yb2xsZWQgQ3VzdG9tZXIsIGFuZCBUaWNrZXQgZmlyc3QuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvZW5yb2xsL2dldC1leGFjdC1hbW91bnQtcGFpZC8ke3NvdXJjZUVucm9sbG1lbnR9YFxyXG4gICAgICApO1xyXG4gICAgICBzZXRBbW91bnRQYWlkKHJlcy5kYXRhLmFtb3VudFBhaWQgfHwgMCk7XHJcbiAgICAgIHNldFRyYW5zZmVyQW1vdW50KHJlcy5kYXRhLmFtb3VudFBhaWQgfHwgMCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRBbW91bnRQYWlkKDApO1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFtb3VudCBwYWlkXCIsIGVycm9yKTtcclxuICAgICAgYWxlcnQoXCJDb3VsZCBub3QgZmV0Y2ggYW1vdW50IHBhaWQuXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVRyYW5zZmVyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKFxyXG4gICAgICAhc291cmNlRW5yb2xsbWVudCB8fFxyXG4gICAgICAhZGVzdGluYXRpb25FbnJvbGxtZW50IHx8XHJcbiAgICAgICF0cmFuc2ZlckFtb3VudCB8fFxyXG4gICAgICBwYXJzZUZsb2F0KHRyYW5zZmVyQW1vdW50KSA8PSAwXHJcbiAgICApIHtcclxuICAgICAgYWxlcnQoXCJQbGVhc2UgZmlsbCBhbGwgZmllbGRzIGFuZCBlbnRlciBhIHZhbGlkIHRyYW5zZmVyIGFtb3VudC5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAocGFyc2VGbG9hdCh0cmFuc2ZlckFtb3VudCkgPiBhbW91bnRQYWlkKSB7XHJcbiAgICAgIGFsZXJ0KFwiVHJhbnNmZXIgYW1vdW50IGNhbm5vdCBleGNlZWQgYW1vdW50IHBhaWQuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICBmcm9tRW5yb2xsSWQ6IHNvdXJjZUVucm9sbG1lbnQsXHJcbiAgICAgICAgdG9FbnJvbGxJZDogZGVzdGluYXRpb25FbnJvbGxtZW50LFxyXG4gICAgICAgIGFtb3VudFBhaWQsXHJcbiAgICAgICAgdHJhbnNmZXJBbW91bnQ6IHBhcnNlRmxvYXQodHJhbnNmZXJBbW91bnQpLFxyXG4gICAgICAgIHRyYW5zZmVyVHlwZTogXCJIYXJkXCIsXHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5wb3N0KFwiL2Vucm9sbC9oYXJkLXRyYW5zZmVyLWN1c3RvbWVyXCIsIHBheWxvYWQpO1xyXG4gICAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjAwIHx8IHJlcy5zdGF0dXMgPT09IDIwMSkge1xyXG4gICAgICAgIGNvbnN0IHRyYW5zZmVyID0gcmVzLmRhdGE7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID0ge1xyXG4gICAgICAgICAgX2lkOiB0cmFuc2Zlci5faWQsXHJcbiAgICAgICAgICBpZDogdHJhbnNmZXJEYXRhLmxlbmd0aCArIDEsXHJcbiAgICAgICAgICBmcm9tX2Vucm9sbG1lbnQ6IHNvdXJjZUVucm9sbG1lbnQsXHJcbiAgICAgICAgICB0b19lbnJvbGxtZW50OiBkZXN0aW5hdGlvbkVucm9sbG1lbnQsXHJcbiAgICAgICAgICB0cmFuc2Zlcl9hbW91bnQ6IHBhcnNlRmxvYXQodHJhbnNmZXJBbW91bnQpLFxyXG4gICAgICAgICAgYW1vdW50X3BhaWQ6IGFtb3VudFBhaWQsXHJcbiAgICAgICAgICB0cmFuc2Zlcl90eXBlOiBcIkhhcmRcIixcclxuICAgICAgICAgIGRhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgfTtcclxuICAgICAgICBzZXRUcmFuc2ZlckRhdGEoKHByZXYpID0+IFsuLi5wcmV2LCBmb3JtYXR0ZWRdKTtcclxuICAgICAgICBhbGVydChcIlRyYW5zZmVyIHN1Y2Nlc3NmdWwhXCIpO1xyXG4gICAgICAgIHJlc2V0Rm9ybSgpO1xyXG4gICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYWxlcnQoXCJUcmFuc2ZlciBmYWlsZWQuXCIpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiVHJhbnNmZXIgZXJyb3I6XCIsIGVycm9yKTtcclxuICAgICAgYWxlcnQoXCJUcmFuc2ZlciBmYWlsZWQuIENoZWNrIGNvbnNvbGUgZm9yIGRldGFpbHMuXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlc2V0Rm9ybSA9ICgpID0+IHtcclxuICAgIHNldFNvdXJjZUVucm9sbG1lbnQoXCJcIik7XHJcbiAgICBzZXREZXN0aW5hdGlvbkVucm9sbG1lbnQoXCJcIik7XHJcbiAgICBzZXRUcmFuc2ZlckFtb3VudChcIlwiKTtcclxuICAgIHNldEFtb3VudFBhaWQoMCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJ2b3VjaGVyX2lkXCIsIGhlYWRlcjogXCJWb3VjaGVyIElEXCIgfSxcclxuICAgIHsga2V5OiBcImZyb21fZ3JvdXBcIiwgaGVhZGVyOiBcIkZyb20gR3JvdXBcIiB9LFxyXG4gICAgeyBrZXk6IFwiZnJvbV9jdXN0b21lclwiLCBoZWFkZXI6IFwiRnJvbSBDdXN0b21lclwiIH0sXHJcbiAgICB7IGtleTogXCJmcm9tX3RpY2tldFwiLCBoZWFkZXI6IFwiRnJvbSBUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG9fZ3JvdXBcIiwgaGVhZGVyOiBcIlRvIEdyb3VwXCIgfSxcclxuICAgIHsga2V5OiBcInRvX2N1c3RvbWVyXCIsIGhlYWRlcjogXCJUbyBDdXN0b21lclwiIH0sXHJcbiAgICB7IGtleTogXCJ0b190aWNrZXRcIiwgaGVhZGVyOiBcIlRvIFRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2Zlcl9hbW91bnRcIiwgaGVhZGVyOiBcIlRyYW5zZmVyIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2Zlcl90eXBlXCIsIGhlYWRlcjogXCJUcmFuc2ZlciBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlRyYW5zZmVyIERhdGVcIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9eyhlKSA9PiBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkhhcmQgVHJhbnNmZXI8L2gxPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQWRkVHJhbnNmZXJDbGlja31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtOTUwIHRleHQtd2hpdGUgcHgtNSBweS01IHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXZpb2xldC04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgdGV4dC1sZ1wiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRlcn1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtsb2FkZXIgPyAoXHJcbiAgICAgICAgICAgICAgICA8U3BpbiBpbmRpY2F0b3I9ezxMb2FkaW5nT3V0bGluZWQgc3BpbiAvPn0gLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgXCIrIEFkZCBUcmFuc2ZlclwiXHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIHt0cmFuc2ZlckRhdGE/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24odHJhbnNmZXJEYXRhLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkhhcmQgQW1vdW50IFRyYW5zZmVyXCJcclxuICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiSGFyZCBBbW91bnQgVHJhbnNmZXIuY3N2XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgIGlzTG9hZGluZz17aXNEYXRhVGFibGVMb2FkaW5nfVxyXG4gICAgICAgICAgICAgIGZhaWx1cmU9e3RyYW5zZmVyRGF0YT8ubGVuZ3RoID09PSAwfVxyXG4gICAgICAgICAgICAgIGRhdGE9XCJUcmFuc2ZlcnNcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8RHJhd2VyXHJcbiAgICAgICAgdGl0bGU9XCJBZGQgSGFyZCBUcmFuc2ZlclwiXHJcbiAgICAgICAgd2lkdGg9ezg0MH1cclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfVxyXG4gICAgICAgIG9wZW49e3Nob3dNb2RhbH1cclxuICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgIGJvZHk6IHsgcGFkZGluZ0JvdHRvbTogODAsIHBhZGRpbmdUb3A6IDE2LCBmb250U2l6ZTogXCIxNnB4XCIgfSxcclxuICAgICAgICAgIGhlYWRlcjogeyBmb250U2l6ZTogXCIxOHB4XCIsIGZvbnRXZWlnaHQ6IFwiNjAwXCIgfSxcclxuICAgICAgICB9fVxyXG4gICAgICAgIGV4dHJhPXtcclxuICAgICAgICAgIDxTcGFjZT5cclxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibGFyZ2VcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cImxhcmdlXCIgdHlwZT1cInByaW1hcnlcIiBvbkNsaWNrPXtoYW5kbGVUcmFuc2Zlcn0+XHJcbiAgICAgICAgICAgICAgU3VibWl0XHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9TcGFjZT5cclxuICAgICAgICB9XHJcbiAgICAgID5cclxuICAgICAgICA8Rm9ybSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIHNpemU9XCJsYXJnZVwiPlxyXG4gICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMjRdfSBjbGFzc05hbWU9XCJweC0yXCI+XHJcbiAgICAgICAgICAgIDxDb2wgc3Bhbj17MjR9PlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPXtcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICBGcm9tIEN1c3RvbWVyIHwgR3JvdXAgfFRpY2tldHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ3VzdG9tZXIgfCBHcm91cCB8IFRpY2tldFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUNoYW5nZShcInNvdXJjZUVucm9sbG1lbnRcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogXCIxNnB4XCIsIGhlaWdodDogXCI1MnB4XCIgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2RlbGV0ZWRFbnJvbGxtZW50c1xyXG4gICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGUpID0+IGUuY3VzdG9tZXJfcGhvbmUgJiYgZS5ncm91cF9uYW1lKVxyXG4gICAgICAgICAgICAgICAgICAgIC5tYXAoKGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS5kZWxldGVkID8gXCJ0ZXh0LXJlZC01MDBcIiA6IFwidGV4dC1ibGFja1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2U/LmVucm9sbF9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake2U/LmVucm9sbF9pZH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YCR7ZS5jdXN0b21lcl9uYW1lfSB8ICR7ZS5jdXN0b21lcl9waG9uZX0gfCAke2UuY3VzdG9tZXJfaWR9IHwgJHtlLmdyb3VwX25hbWV9IHwgVGlja2V0OiAke2UudGlja2V0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgPC9Db2w+XHJcblxyXG4gICAgICAgICAgICA8Q29sIHNwYW49ezI0fT5cclxuICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG8gQ3VzdG9tZXIgfCBHcm91cCB8IFRpY2tldFxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDdXN0b21lciB8IEdyb3VwIHwgVGlja2V0XCJcclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoXCJkZXN0aW5hdGlvbkVucm9sbG1lbnRcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IFwiMTZweFwiLCBoZWlnaHQ6IFwiNTJweFwiIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtub3REZWxldGVkRW5yb2xsbWVudHNcclxuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKChlKSA9PiBlLmN1c3RvbWVyX3Bob25lICYmIGUuZ3JvdXBfbmFtZSlcclxuICAgICAgICAgICAgICAgICAgICAubWFwKChlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Ake1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUuZGVsZXRlZCA/IFwidGV4dC1yZWQtNTAwXCIgOiBcInRleHQtYmxhY2tcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtlPy5lbnJvbGxfaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHtlPy5lbnJvbGxfaWR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Ake2UuY3VzdG9tZXJfbmFtZX0gfCAke2UuY3VzdG9tZXJfcGhvbmV9IHwgJHtlLmN1c3RvbWVyX2lkfSB8ICR7ZS5ncm91cF9uYW1lfSB8IFRpY2tldDogJHtlLnRpY2tldH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICAgICAgPENvbCBzcGFuPXsyNH0+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17ZmV0Y2hBbW91bnRQYWlkfVxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBcIjUycHhcIixcclxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTZweFwiLFxyXG4gICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjUwMFwiLFxyXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiIzFlNDBhZlwiLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDaGVjayBUb3RhbCBBbW91bnQgUGFpZFxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgICAgIDxDb2wgc3Bhbj17MjR9PlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPXs8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlRyYW5zZmVyIEFtb3VudDwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVHJhbnNmZXIgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RyYW5zZmVyQW1vdW50IHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoXCJ0cmFuc2Zlcl9hbW91bnRcIiwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IFwiMTZweFwiLCBoZWlnaHQ6IFwiNTJweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgIDwvRm9ybT5cclxuICAgICAgPC9EcmF3ZXI+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSGFyZFRyYW5zZmVyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvSGFyZFRyYW5zZmVyLmpzeCJ9