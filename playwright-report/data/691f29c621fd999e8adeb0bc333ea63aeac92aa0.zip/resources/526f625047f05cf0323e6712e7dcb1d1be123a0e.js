import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/GroupReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"];
import { Select, Tabs, Card, Descriptions, Tag, Skeleton, Empty, Statistic, Tooltip, Badge, Button, Space, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { RiWhatsappLine } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import { FiDownload } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import html2canvas from "/node_modules/.vite/deps/html2canvas.js?v=819e0a34";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip as RechartTooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend
} from "/node_modules/.vite/deps/recharts.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const REPORT_COLUMNS = [
  { key: "id", header: "SL. NO" },
  { key: "customerId", header: "Customer ID" },
  { key: "name", header: "Customer Name" },
  { key: "phoneNumber", header: "Phone Number" },
  { key: "ticket", header: "Ticket" },
  { key: "status", header: "Status" },
  { key: "amountToBePaid", header: "Amount to be Paid" },
  { key: "amountPaid", header: "Amount Paid" },
  { key: "balance", header: "Balance" },
  { key: "nextAuctionDate", header: "Next Auction Date" }
];
const STATUS_COLORS = {
  Active: "green",
  Closed: "default",
  Defaulted: "red",
  Prized: "gold"
};
const AUCTION_COLUMNS = [
  { key: "id", header: "SL. NO" },
  { key: "auctionCode", header: "Auction Code" },
  { key: "auctionDate", header: "Auction Date" },
  { key: "nextDate", header: "Next Date" },
  { key: "name", header: "Customer Name" },
  { key: "customerId", header: "Customer ID" },
  { key: "ticket", header: "Ticket" },
  { key: "bidAmount", header: "Bid Amount" },
  { key: "winAmount", header: "Win Amount" },
  { key: "auctionType", header: "Auction Type" },
  { key: "prized", header: "Prized" }
];
const AUCTION_STATUS_COLORS = {
  Pending: "orange",
  Completed: "green",
  Cancelled: "red"
};
const SEAT_ROW_SIZE = 10;
const formatGroupType = (groupType) => groupType ? `${groupType.charAt(0).toUpperCase()}${groupType.slice(1)} Auction` : "-";
const formatCurrency = (amount) => `₹${Number(amount || 0).toLocaleString("en-IN")}`;
const SummaryStat = ({ title, amount, valueClassName }) => /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100", bodyStyle: { padding: "20px 24px" }, children: [
  /* @__PURE__ */ jsxDEV(
    Statistic,
    {
      title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 font-medium", children: title }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 79,
        columnNumber: 12
      }, this),
      value: amount,
      formatter: (value) => formatCurrency(value),
      valueStyle: { fontSize: 26, fontWeight: 700 },
      className: valueClassName
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 78,
      columnNumber: 5
    },
    this
  ),
  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 font-mono mt-1", children: numberToIndianWords(amount) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 85,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
  lineNumber: 77,
  columnNumber: 1
}, this);
_c = SummaryStat;
const GroupDetailsTab = ({ groupInfo, loading }) => {
  if (loading) return /* @__PURE__ */ jsxDEV(Skeleton, { active: true, paragraph: { rows: 4 }, className: "mt-6" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 90,
    columnNumber: 23
  }, this);
  if (!groupInfo) return /* @__PURE__ */ jsxDEV(Empty, { description: "No group data available", className: "mt-16" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 91,
    columnNumber: 26
  }, this);
  return /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100 mt-2", children: /* @__PURE__ */ jsxDEV(
    Descriptions,
    {
      title: /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: groupInfo.group_name }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 96,
        columnNumber: 16
      }, this),
      column: { xs: 1, sm: 2, lg: 3 },
      bordered: true,
      size: "middle",
      children: [
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Group Type", children: /* @__PURE__ */ jsxDEV(Tag, { color: "purple", children: formatGroupType(groupInfo.group_type) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 102,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 101,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Group Value", children: formatCurrency(groupInfo.group_value) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 104,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Installment Amount", children: formatCurrency(groupInfo.group_install) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 107,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Monthly Installment", children: formatCurrency(groupInfo.monthly_installment) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 110,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Registration Fee", children: formatCurrency(groupInfo.reg_fee) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 113,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Relationship Manager", children: [
          groupInfo.relationship_manager?.name || "-",
          groupInfo.relationship_manager?.phone_number && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 ml-2", children: [
            "(",
            groupInfo.relationship_manager.phone_number,
            ")"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 119,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 116,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 95,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 94,
    columnNumber: 5
  }, this);
};
_c2 = GroupDetailsTab;
const CustomerOverviewTab = ({ tableData, summary, groupInfo, loading, searchText }) => {
  if (loading) return /* @__PURE__ */ jsxDEV(Skeleton, { active: true, paragraph: { rows: 6 }, className: "mt-6" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 130,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV(SummaryStat, { title: "Paid Amount", amount: summary.amountPaid, valueClassName: "text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 135,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(SummaryStat, { title: "Amount to be Paid", amount: summary.amountToBePaid }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 136,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(SummaryStat, { title: "Balance Amount", amount: summary.balance, valueClassName: "text-red-500" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 137,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 134,
      columnNumber: 7
    }, this),
    tableData.length > 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100", bodyStyle: { padding: 0 }, children: /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        data: filterOption(tableData, searchText),
        columns: REPORT_COLUMNS,
        exportedPdfName: "Group Report",
        printHeaderKeys: ["Group Name", "Group Type", "Group Value", "Amount to be Paid", "Paid Amount", "Balance Amount"],
        printHeaderValues: [
          groupInfo?.group_name,
          formatGroupType(groupInfo?.group_type),
          groupInfo?.group_value,
          formatCurrency(summary.amountToBePaid),
          formatCurrency(summary.amountPaid),
          formatCurrency(summary.balance)
        ],
        exportedFileName: `GroupReport-${groupInfo?.group_name || "group"}.csv`
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 142,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 141,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Empty, { description: "No customer records found for this group", className: "mt-16" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 159,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 133,
    columnNumber: 5
  }, this);
};
_c3 = CustomerOverviewTab;
const AuctionDetailsTab = ({ rows, loading, searchText, groupName }) => {
  if (loading) return /* @__PURE__ */ jsxDEV(Skeleton, { active: true, paragraph: { rows: 8 }, className: "mt-6" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 171,
    columnNumber: 23
  }, this);
  const tableData = rows.map((row, index) => ({
    id: index + 1,
    auctionCode: row.auction_code || "-",
    ticket: row.ticket || "-",
    customerId: row.user_id?.customer_id || "-",
    name: row.user_id?.full_name || "-",
    auctionType: row.auction_type ? `${row.auction_type.charAt(0).toUpperCase()}${row.auction_type.slice(1)}` : "-",
    auctionDate: row.auction_date || "-",
    nextDate: row.next_date || "-",
    bidAmount: (parseInt(row.divident) || 0) + (parseInt(row.commission) || 0) || "-",
    winAmount: row.win_amount ? formatCurrency(row.win_amount || 0) : "-",
    status: /* @__PURE__ */ jsxDEV(Tag, { color: AUCTION_STATUS_COLORS[row.status] || "default", children: row.status || "-" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 188,
      columnNumber: 13
    }, this),
    prized: /* @__PURE__ */ jsxDEV(Tag, { color: row.isPrized === "true" ? "gold" : "default", children: row.isPrized === "true" ? "Prized" : "Not Prized" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 190,
      columnNumber: 5
    }, this)
  }));
  if (tableData.length === 0) {
    return /* @__PURE__ */ jsxDEV(Empty, { description: "No auction records found for this group", className: "mt-16" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 197,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100 mt-2", bodyStyle: { padding: 0 }, children: /* @__PURE__ */ jsxDEV(
    DataTable,
    {
      data: filterOption(tableData, searchText),
      columns: AUCTION_COLUMNS,
      exportedPdfName: "Auction Details",
      exportedFileName: `AuctionDetails-${groupName || "group"}.csv`
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 202,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 201,
    columnNumber: 5
  }, this);
};
_c4 = AuctionDetailsTab;
const captureNode = async (node) => {
  const prevMaxHeight = node.style.maxHeight;
  const prevOverflow = node.style.overflow;
  const prevPaddingTop = node.style.paddingTop;
  node.style.maxHeight = "none";
  node.style.overflow = "visible";
  node.style.paddingTop = "12px";
  try {
    return await html2canvas(node, { backgroundColor: "#ffffff", scale: 2, useCORS: true });
  } finally {
    node.style.maxHeight = prevMaxHeight;
    node.style.overflow = prevOverflow;
    node.style.paddingTop = prevPaddingTop;
  }
};
const downloadBlob = (blob, filename) => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
};
const exportCard = async (targetRef, filename, mode) => {
  if (!targetRef.current) return;
  let canvas;
  try {
    canvas = await captureNode(targetRef.current);
  } catch (error) {
    console.error("Error generating image:", error);
    message.error("Couldn't generate the image. Please try again.");
    return;
  }
  canvas.toBlob(async (blob) => {
    if (!blob) return;
    if (mode === "download") {
      downloadBlob(blob, filename);
      return;
    }
    const file = new File([blob], filename, { type: "image/png" });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: filename });
        return;
      } catch (error) {
        if (error?.name === "AbortError") return;
      }
    }
    downloadBlob(blob, filename);
    message.info("Image downloaded — attach it in the WhatsApp chat that just opened.");
    window.open(
      `https://wa.me/?text=${encodeURIComponent("Sharing " + filename)}`,
      "_blank",
      "noopener,noreferrer"
    );
  }, "image/png");
};
const CardShareActions = ({ targetRef, filename }) => /* @__PURE__ */ jsxDEV(Space, { size: 2, children: [
  /* @__PURE__ */ jsxDEV(Tooltip, { title: "Download as image", children: /* @__PURE__ */ jsxDEV(
    Button,
    {
      size: "small",
      type: "text",
      icon: /* @__PURE__ */ jsxDEV(FiDownload, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 295,
        columnNumber: 13
      }, this),
      onClick: () => exportCard(targetRef, filename, "download")
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 292,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 291,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV(Tooltip, { title: "Share on WhatsApp", children: /* @__PURE__ */ jsxDEV(
    Button,
    {
      size: "small",
      type: "text",
      className: "text-emerald-600",
      icon: /* @__PURE__ */ jsxDEV(RiWhatsappLine, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 304,
        columnNumber: 13
      }, this),
      onClick: () => exportCard(targetRef, filename, "whatsapp")
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 300,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 299,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
  lineNumber: 290,
  columnNumber: 1
}, this);
_c5 = CardShareActions;
const sanitizeFilename = (value) => (value || "group").toString().trim().replace(/[^a-zA-Z0-9-_]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
const ExportHeader = ({ groupName, label }) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3 pb-2 pt-1 border-b border-gray-100", children: [
  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 truncate leading-6", children: groupName }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 324,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 shrink-0 ml-2 leading-6", children: label }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 325,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
  lineNumber: 323,
  columnNumber: 1
}, this);
_c6 = ExportHeader;
const SEAT_STYLES = {
  filled: "bg-indigo-600 border-indigo-600 text-white shadow-sm hover:bg-indigo-500 hover:ring-2 hover:ring-indigo-300",
  vacant: "bg-white border-dashed border-gray-300 text-gray-300 hover:border-emerald-400 hover:text-emerald-500 hover:ring-2 hover:ring-emerald-200",
  reserved: "bg-amber-50 border-amber-300 text-amber-600 hover:bg-amber-100 hover:ring-2 hover:ring-amber-200"
};
const Ticket = ({ ticket }) => {
  const isFilled = ticket.seat_type === "Filled";
  const hasCustomer = Boolean(ticket.user_id);
  const variant = !isFilled ? "vacant" : hasCustomer ? "filled" : "reserved";
  const tooltipContent = !isFilled ? /* @__PURE__ */ jsxDEV("span", { children: [
    "Ticket ",
    ticket.tickets,
    " · Available"
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 341,
    columnNumber: 3
  }, this) : hasCustomer ? /* @__PURE__ */ jsxDEV("div", { className: "leading-5", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "font-semibold", children: ticket.user_id.full_name }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 344,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-xs opacity-80", children: ticket.user_id.customer_id }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 345,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-xs opacity-80", children: ticket.user_id.phone_number }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 346,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 343,
    columnNumber: 3
  }, this) : /* @__PURE__ */ jsxDEV("span", { children: [
    "Ticket ",
    ticket.tickets,
    " · Mapped (no customer linked)"
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 349,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV(Tooltip, { title: tooltipContent, placement: "top", mouseEnterDelay: 0.05, mouseLeaveDelay: 0.05, children: /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `aspect-square w-full min-w-[28px] rounded-md border flex items-center justify-center
          text-[11px] font-semibold cursor-default select-none transition-colors duration-150
          ring-offset-1 ${SEAT_STYLES[variant]}`,
      children: ticket.tickets
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 354,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 353,
    columnNumber: 5
  }, this);
};
_c7 = Ticket;
const SeatMap = ({ tickets }) => {
  _s();
  const rows = useMemo(() => {
    const chunks = [];
    for (let i = 0; i < tickets.length; i += SEAT_ROW_SIZE) {
      chunks.push(tickets.slice(i, i + SEAT_ROW_SIZE));
    }
    return chunks;
  }, [tickets]);
  return /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto overflow-y-visible p-1", children: /* @__PURE__ */ jsxDEV("div", { className: "min-w-[520px]", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto mb-6 w-4/5 h-2 rounded-full bg-gradient-to-r from-transparent via-gray-300 to-transparent" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 378,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2", children: rows.map(
      (row, rowIndex) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "w-5 text-[10px] font-semibold text-gray-400", children: String.fromCharCode(65 + rowIndex) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 382,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-10 gap-2 flex-1", children: row.map(
          (ticket) => /* @__PURE__ */ jsxDEV(Ticket, { ticket }, ticket.tickets, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 387,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 385,
          columnNumber: 15
        }, this)
      ] }, rowIndex, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 381,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 379,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 376,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 375,
    columnNumber: 5
  }, this);
};
_s(SeatMap, "LHVMCglWcQeRoCgUufL/A5uf67g=");
_c8 = SeatMap;
const SeatLegend = ({ hasReserved }) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-5 mt-6 text-xs text-gray-500", children: [
  /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "w-4 h-4 rounded bg-indigo-600 inline-block" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 401,
      columnNumber: 7
    }, this),
    " Mapped"
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 400,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "w-4 h-4 rounded border border-dashed border-gray-300 inline-block" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 404,
      columnNumber: 7
    }, this),
    " Available"
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 403,
    columnNumber: 5
  }, this),
  hasReserved && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "w-4 h-4 rounded bg-amber-50 border border-amber-300 inline-block" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 408,
      columnNumber: 9
    }, this),
    " Mapped · unlinked"
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 407,
    columnNumber: 3
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
  lineNumber: 399,
  columnNumber: 1
}, this);
_c9 = SeatLegend;
const FillRateDonut = ({ filled, vacant }) => {
  const total = filled + vacant || 1;
  const data = [
    { name: "Mapped", value: filled },
    { name: "Available", value: vacant }
  ];
  const colors = ["#4f46e5", "#e5e7eb"];
  return /* @__PURE__ */ jsxDEV("div", { className: "relative h-64", children: [
    /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(PieChart, { children: [
      /* @__PURE__ */ jsxDEV(
        Pie,
        {
          data,
          dataKey: "value",
          innerRadius: "68%",
          outerRadius: "90%",
          startAngle: 90,
          endAngle: -270,
          paddingAngle: 2,
          children: data.map(
            (entry, index) => /* @__PURE__ */ jsxDEV(Cell, { fill: colors[index], stroke: "none" }, entry.name, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 436,
              columnNumber: 13
            }, this)
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 426,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(RechartTooltip, { formatter: (value, name) => [`${value} Tickets`, name] }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 439,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Legend, { verticalAlign: "bottom", height: 24, iconType: "circle" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 440,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 425,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 424,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 flex flex-col items-center justify-center pointer-events-none -translate-y-3", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-gray-800", children: [
        Math.round(filled / total * 100),
        "%"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 444,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "Filled" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 445,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 443,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 423,
    columnNumber: 5
  }, this);
};
_c10 = FillRateDonut;
const TopHoldersChart = ({ customers }) => {
  if (customers.length === 0) {
    return /* @__PURE__ */ jsxDEV(Empty, { description: "No bookings yet", className: "py-10" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 453,
      columnNumber: 12
    }, this);
  }
  const chartHeight = Math.max(280, customers.length * 30);
  return /* @__PURE__ */ jsxDEV("div", { className: "max-h-[520px] overflow-y-auto pr-1", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: chartHeight, children: /* @__PURE__ */ jsxDEV(BarChart, { data: customers, layout: "vertical", margin: { left: 12, right: 24, top: 4, bottom: 4 }, children: [
    /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", horizontal: false, stroke: "#f1f5f9" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 460,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(XAxis, { type: "number", allowDecimals: false, tick: { fontSize: 11, fill: "#94a3b8" } }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 461,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      YAxis,
      {
        type: "category",
        dataKey: "name",
        width: 130,
        tick: { fontSize: 11, fill: "#475569" },
        interval: 0
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 462,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      RechartTooltip,
      {
        formatter: (value) => [`${value} ticket${value > 1 ? "s" : ""}`, "Held"],
        cursor: { fill: "#f8fafc" }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 469,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Bar, { dataKey: "count", fill: "#4f46e5", radius: [0, 6, 6, 0], barSize: 16 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 473,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 459,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 458,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 457,
    columnNumber: 5
  }, this);
};
_c11 = TopHoldersChart;
const TopHoldersMini = ({ customers }) => {
  const top = customers.slice(0, 5);
  if (top.length === 0) {
    return /* @__PURE__ */ jsxDEV(Empty, { description: "No bookings yet", className: "py-6" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 483,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2", children: top.map(
    (holder, index) => /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "flex items-center justify-between rounded-md bg-emerald-50 border border-emerald-100 px-3 py-2",
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-emerald-600 w-4 shrink-0", children: index + 1 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 493,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-emerald-700 truncate", children: holder.name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 494,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 492,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-emerald-600 shrink-0", children: [
            holder.count,
            " ticket",
            holder.count > 1 ? "s" : ""
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 496,
            columnNumber: 11
          }, this)
        ]
      },
      holder.name + index,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 488,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 486,
    columnNumber: 5
  }, this);
};
_c12 = TopHoldersMini;
const TicketAllocationTab = ({ ticketsInfo, loading }) => {
  _s2();
  const seatMapRef = useRef(null);
  const fillRateRef = useRef(null);
  const holdersRef = useRef(null);
  const tickets = ticketsInfo?.overallTickets || [];
  const allHolders = useMemo(() => {
    const byCustomer = /* @__PURE__ */ new Map();
    tickets.forEach((t) => {
      if (t.seat_type !== "Filled" || !t.user_id) return;
      const key = t.user_id.customer_id;
      const existing = byCustomer.get(key);
      if (existing) {
        existing.count += 1;
      } else {
        byCustomer.set(key, { name: t.user_id.full_name, count: 1 });
      }
    });
    return Array.from(byCustomer.values()).sort((a, b) => b.count - a.count);
  }, [tickets]);
  const uniqueCustomers = useMemo(() => {
    const ids = new Set(
      tickets.filter((t) => t.user_id).map((t) => t.user_id.customer_id)
    );
    return ids.size;
  }, [tickets]);
  if (loading) return /* @__PURE__ */ jsxDEV(Skeleton, { active: true, paragraph: { rows: 8 }, className: "mt-6" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 536,
    columnNumber: 23
  }, this);
  if (!ticketsInfo) return /* @__PURE__ */ jsxDEV(Empty, { description: "No ticket data available", className: "mt-16" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 537,
    columnNumber: 28
  }, this);
  const filled = tickets.filter((t) => t.seat_type === "Filled").length;
  const vacant = tickets.length - filled;
  const hasReserved = tickets.some((t) => t.seat_type === "Filled" && !t.user_id);
  const groupName = ticketsInfo.group?.group_name || "group";
  const safeGroupName = sanitizeFilename(groupName);
  return /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100", bodyStyle: { padding: "18px 20px" }, children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500 mb-1", children: "Total Tickets" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 549,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: tickets.length }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 550,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 548,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100", bodyStyle: { padding: "18px 20px" }, children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500 mb-1", children: "Mapped" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 553,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-indigo-600", children: filled }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 554,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 552,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100", bodyStyle: { padding: "18px 20px" }, children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500 mb-1", children: "Available" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 557,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-emerald-500", children: vacant }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 558,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 556,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100", bodyStyle: { padding: "18px 20px" }, children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500 mb-1", children: "Unique Customers" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 561,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: uniqueCustomers }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 562,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 560,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 547,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-4", children: [
      /* @__PURE__ */ jsxDEV(
        Card,
        {
          className: "shadow-sm border-gray-100 lg:col-span-2",
          title: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Ticket Map" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 569,
            columnNumber: 18
          }, this),
          extra: /* @__PURE__ */ jsxDEV(Space, { size: 12, children: [
            /* @__PURE__ */ jsxDEV(Badge, { color: "#4f46e5", text: `${filled}/${tickets.length} mapped` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 572,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CardShareActions, { targetRef: seatMapRef, filename: `${safeGroupName}-seat-map.png` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 573,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 571,
            columnNumber: 11
          }, this),
          children: /* @__PURE__ */ jsxDEV("div", { ref: seatMapRef, className: "bg-white", children: [
            /* @__PURE__ */ jsxDEV(ExportHeader, { groupName, label: "Ticket Map" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 578,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(SeatMap, { tickets }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 579,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(SeatLegend, { hasReserved }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 580,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 577,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 567,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: [
        /* @__PURE__ */ jsxDEV(
          Card,
          {
            className: "shadow-sm border-gray-100",
            title: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Fill Rate" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 587,
              columnNumber: 20
            }, this),
            extra: /* @__PURE__ */ jsxDEV(CardShareActions, { targetRef: fillRateRef, filename: `${safeGroupName}-fill-rate.png` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 588,
              columnNumber: 20
            }, this),
            children: /* @__PURE__ */ jsxDEV("div", { ref: fillRateRef, className: "bg-white", children: [
              /* @__PURE__ */ jsxDEV(ExportHeader, { groupName, label: "Fill Rate" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
                lineNumber: 591,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(FillRateDonut, { filled, vacant }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
                lineNumber: 592,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
              lineNumber: 590,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 585,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100", title: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Top Ticket Holders" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 595,
          columnNumber: 62
        }, this), children: /* @__PURE__ */ jsxDEV(TopHoldersMini, { customers: allHolders }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 596,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 595,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 584,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 566,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Card,
      {
        className: "shadow-sm border-gray-100 mt-4",
        title: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Ticket Holders" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 603,
          columnNumber: 16
        }, this),
        extra: /* @__PURE__ */ jsxDEV(CardShareActions, { targetRef: holdersRef, filename: `${safeGroupName}-ticket-holders.png` }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 604,
          columnNumber: 16
        }, this),
        children: /* @__PURE__ */ jsxDEV("div", { ref: holdersRef, className: "bg-white", children: [
          /* @__PURE__ */ jsxDEV(ExportHeader, { groupName, label: "Ticket Holders" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 607,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(TopHoldersChart, { customers: allHolders }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 608,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 606,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 601,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 546,
    columnNumber: 5
  }, this);
};
_s2(TicketAllocationTab, "dKbmjklVh/X3xpuWkXHxHYuQrAQ=");
_c13 = TicketAllocationTab;
const GroupReport = () => {
  _s3();
  const [groups, setGroups] = useState([]);
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [reportRows, setReportRows] = useState([]);
  const [ticketsInfo, setTicketsInfo] = useState(null);
  const [auctionRows, setAuctionRows] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [isGroupsLoading, setIsGroupsLoading] = useState(true);
  const [isReportLoading, setIsReportLoading] = useState(false);
  const [isTicketsLoading, setIsTicketsLoading] = useState(false);
  const [isAuctionLoading, setIsAuctionLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("groupDetails");
  const latestRequestId = useRef(0);
  const fetchedAuctionGroupRef = useRef(null);
  const onGlobalSearchChangeHandler = (e) => setSearchText(e.target.value);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching groups:", error);
      } finally {
        setIsGroupsLoading(false);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    setReportRows([]);
    setTicketsInfo(null);
    setAuctionRows([]);
    fetchedAuctionGroupRef.current = null;
    if (!selectedGroupId) return;
    const requestId = ++latestRequestId.current;
    setIsReportLoading(true);
    setIsTicketsLoading(true);
    const fetchGroupReport = async () => {
      try {
        const response = await api.get("/v1/admin/groups/group-report", {
          params: { group_id: selectedGroupId }
        });
        if (requestId === latestRequestId.current) {
          setReportRows(response.data?.data || []);
        }
      } catch (error) {
        console.error("Error fetching group report:", error);
        if (requestId === latestRequestId.current) {
          setReportRows([]);
        }
      } finally {
        if (requestId === latestRequestId.current) {
          setIsReportLoading(false);
        }
      }
    };
    const fetchTicketAllocation = async () => {
      try {
        const response = await api.get("/v1/admin/groups/tickets", {
          params: { group_id: selectedGroupId }
        });
        if (requestId === latestRequestId.current) {
          setTicketsInfo(response.data?.data || null);
        }
      } catch (error) {
        console.error("Error fetching ticket allocation:", error);
        if (requestId === latestRequestId.current) {
          setTicketsInfo(null);
        }
      } finally {
        if (requestId === latestRequestId.current) {
          setIsTicketsLoading(false);
        }
      }
    };
    fetchGroupReport();
    fetchTicketAllocation();
  }, [selectedGroupId]);
  useEffect(() => {
    if (activeTab !== "auctionDetails" || !selectedGroupId) return;
    if (fetchedAuctionGroupRef.current === selectedGroupId) return;
    let cancelled = false;
    const fetchAuctionDetails = async () => {
      setIsAuctionLoading(true);
      try {
        const response = await api.get(`/auction/group-auction/${selectedGroupId}`);
        const payload = response.data;
        const rows = Array.isArray(payload) ? payload : payload?.data || [];
        if (!cancelled) {
          setAuctionRows(rows);
          fetchedAuctionGroupRef.current = selectedGroupId;
        }
      } catch (error) {
        console.error("Error fetching auction details:", error);
        if (!cancelled) setAuctionRows([]);
      } finally {
        if (!cancelled) setIsAuctionLoading(false);
      }
    };
    fetchAuctionDetails();
    return () => {
      cancelled = true;
    };
  }, [activeTab, selectedGroupId]);
  const groupInfo = reportRows[0]?.group_id || ticketsInfo?.group || null;
  const summary = useMemo(
    () => reportRows.reduce(
      (totals, row) => ({
        amountToBePaid: totals.amountToBePaid + (Number(row.total_payable) || 0),
        amountPaid: totals.amountPaid + (Number(row.total_investment) || 0),
        balance: totals.balance + (Number(row.total_balance) || 0)
      }),
      { amountToBePaid: 0, amountPaid: 0, balance: 0 }
    ),
    [reportRows]
  );
  const tableData = useMemo(
    () => reportRows.map((row, index) => ({
      id: index + 1,
      customerId: row.user_id?.customer_id || "-",
      name: row.user_id?.full_name || "-",
      phoneNumber: row.user_id?.phone_number || "-",
      ticket: row.tickets,
      status: /* @__PURE__ */ jsxDEV(Tag, { color: STATUS_COLORS[row.customer_status] || "default", children: row.customer_status || "-" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 763,
        columnNumber: 7
      }, this),
      amountToBePaid: formatCurrency(row.total_payable),
      amountPaid: formatCurrency(row.total_investment),
      balance: formatCurrency(row.total_balance),
      nextAuctionDate: row.next_auction_date || "-"
    })),
    [reportRows]
  );
  const tabItems = [
    {
      key: "groupDetails",
      label: "Group Details",
      children: /* @__PURE__ */ jsxDEV(GroupDetailsTab, { groupInfo, loading: isReportLoading }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 780,
        columnNumber: 15
      }, this)
    },
    {
      key: "ticketAllocation",
      label: "Ticket Allocation",
      children: /* @__PURE__ */ jsxDEV(TicketAllocationTab, { ticketsInfo, loading: isTicketsLoading }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 785,
        columnNumber: 15
      }, this)
    },
    {
      key: "groupOverview",
      label: "Group Overview",
      children: /* @__PURE__ */ jsxDEV(
        CustomerOverviewTab,
        {
          tableData,
          summary,
          groupInfo,
          loading: isReportLoading,
          searchText
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 791,
          columnNumber: 5
        },
        this
      )
    },
    {
      key: "auctionDetails",
      label: "Auction Details",
      children: /* @__PURE__ */ jsxDEV(
        AuctionDetailsTab,
        {
          rows: auctionRows,
          loading: isAuctionLoading,
          searchText,
          groupName: groupInfo?.group_name
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 805,
          columnNumber: 5
        },
        this
      )
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-50", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-30", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { onGlobalSearchChangeHandler, visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 818,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow w-80 p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800 mb-6", children: "Group Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 821,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-semibold text-gray-600 whitespace-nowrap", htmlFor: "group-select", children: "Select Group" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 825,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            id: "group-select",
            showSearch: true,
            loading: isGroupsLoading,
            popupMatchSelectWidth: false,
            style: { height: 44, width: "100%", maxWidth: 480 },
            placeholder: "Search or select a group",
            value: selectedGroupId || void 0,
            filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
            onChange: setSelectedGroupId,
            children: groups.map(
              (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
                lineNumber: 842,
                columnNumber: 17
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
            lineNumber: 828,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 824,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 823,
        columnNumber: 11
      }, this),
      selectedGroupId ? /* @__PURE__ */ jsxDEV(
        Tabs,
        {
          activeKey: activeTab,
          onChange: setActiveTab,
          items: tabItems,
          type: "card",
          className: "group-report-tabs"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
          lineNumber: 851,
          columnNumber: 11
        },
        this
      ) : /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border-gray-100", children: /* @__PURE__ */ jsxDEV(Empty, { description: "Select a group above to view its report", className: "py-10" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 860,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
        lineNumber: 859,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
      lineNumber: 820,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 817,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx",
    lineNumber: 816,
    columnNumber: 5
  }, this);
};
_s3(GroupReport, "+2cMlNVsFE/ilkaKjwg/nNOA3Lo=");
_c14 = GroupReport;
export default GroupReport;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14;
$RefreshReg$(_c, "SummaryStat");
$RefreshReg$(_c2, "GroupDetailsTab");
$RefreshReg$(_c3, "CustomerOverviewTab");
$RefreshReg$(_c4, "AuctionDetailsTab");
$RefreshReg$(_c5, "CardShareActions");
$RefreshReg$(_c6, "ExportHeader");
$RefreshReg$(_c7, "Ticket");
$RefreshReg$(_c8, "SeatMap");
$RefreshReg$(_c9, "SeatLegend");
$RefreshReg$(_c10, "FillRateDonut");
$RefreshReg$(_c11, "TopHoldersChart");
$RefreshReg$(_c12, "TopHoldersMini");
$RefreshReg$(_c13, "TicketAllocationTab");
$RefreshReg$(_c14, "GroupReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEVhOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVFYixTQUFTQSxXQUFXQyxVQUFVQyxTQUFTQyxjQUFjO0FBQ3JELFNBQVNDLFFBQVFDLE1BQU1DLE1BQU1DLGNBQWNDLEtBQUtDLFVBQVVDLE9BQU9DLFdBQVdDLFNBQVNDLE9BQU9DLFFBQVFDLE9BQU9DLGVBQWU7QUFFMUgsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGtCQUFrQjtBQUMzQixPQUFPQyxpQkFBaUI7QUFDeEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBVixXQUFXVztBQUFBQSxFQUNYQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLFNBQVNDLDJCQUEyQjtBQUVwQyxNQUFNQyxpQkFBaUI7QUFBQSxFQUNyQixFQUFFQyxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLEVBQzlCLEVBQUVELEtBQUssY0FBY0MsUUFBUSxjQUFjO0FBQUEsRUFDM0MsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGdCQUFnQjtBQUFBLEVBQ3ZDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxlQUFlO0FBQUEsRUFDN0MsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUNsQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLEVBQ2xDLEVBQUVELEtBQUssa0JBQWtCQyxRQUFRLG9CQUFvQjtBQUFBLEVBQ3JELEVBQUVELEtBQUssY0FBY0MsUUFBUSxjQUFjO0FBQUEsRUFDM0MsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxFQUNwQyxFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxvQkFBb0I7QUFBQztBQUd6RCxNQUFNQyxnQkFBZ0I7QUFBQSxFQUNwQkMsUUFBUTtBQUFBLEVBQ1JDLFFBQVE7QUFBQSxFQUNSQyxXQUFXO0FBQUEsRUFDWEMsUUFBUTtBQUNWO0FBRUEsTUFBTUMsa0JBQWtCO0FBQUEsRUFDdEIsRUFBRVAsS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxFQUM5QixFQUFFRCxLQUFLLGVBQWVDLFFBQVEsZUFBZTtBQUFBLEVBQzdDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxlQUFlO0FBQUEsRUFDN0MsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLFlBQVk7QUFBQSxFQUN2QyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsZ0JBQWdCO0FBQUEsRUFDdkMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGNBQWM7QUFBQSxFQUMzQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLEVBQ2xDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsRUFDekMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGFBQWE7QUFBQSxFQUN6QyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsZUFBZTtBQUFBLEVBQzdDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUM7QUFJckMsTUFBTU8sd0JBQXdCO0FBQUEsRUFDNUJDLFNBQVM7QUFBQSxFQUNUQyxXQUFXO0FBQUEsRUFDWEMsV0FBVztBQUNiO0FBRUEsTUFBTUMsZ0JBQWdCO0FBRXRCLE1BQU1DLGtCQUFrQkEsQ0FBQ0MsY0FDdkJBLFlBQVksR0FBR0EsVUFBVUMsT0FBTyxDQUFDLEVBQUVDLFlBQVksQ0FBQyxHQUFHRixVQUFVRyxNQUFNLENBQUMsQ0FBQyxhQUFhO0FBRXBGLE1BQU1DLGlCQUFpQkEsQ0FBQ0MsV0FBVyxJQUFJQyxPQUFPRCxVQUFVLENBQUMsRUFBRUUsZUFBZSxPQUFPLENBQUM7QUFFbEYsTUFBTUMsY0FBY0EsQ0FBQyxFQUFFQyxPQUFPSixRQUFRSyxlQUFlLE1BQ25ELHVCQUFDLFFBQUssV0FBVSw2QkFBNEIsV0FBVyxFQUFFQyxTQUFTLFlBQVksR0FDNUU7QUFBQTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsT0FBTyx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCRixtQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLE1BQzFELE9BQU9KO0FBQUFBLE1BQ1AsV0FBVyxDQUFDTyxVQUFVUixlQUFlUSxLQUFLO0FBQUEsTUFDMUMsWUFBWSxFQUFFQyxVQUFVLElBQUlDLFlBQVksSUFBSTtBQUFBLE1BQzVDLFdBQVdKO0FBQUFBO0FBQUFBLElBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSzRCO0FBQUEsRUFFNUIsdUJBQUMsT0FBRSxXQUFVLHdDQUF3QzFCLDhCQUFvQnFCLE1BQU0sS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpRjtBQUFBLEtBUm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FTQTtBQUNBVSxLQVhJUDtBQWFOLE1BQU1RLGtCQUFrQkEsQ0FBQyxFQUFFQyxXQUFXQyxRQUFRLE1BQU07QUFDbEQsTUFBSUEsUUFBUyxRQUFPLHVCQUFDLFlBQVMsUUFBTSxNQUFDLFdBQVcsRUFBRUMsTUFBTSxFQUFFLEdBQUcsV0FBVSxVQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlEO0FBQzdFLE1BQUksQ0FBQ0YsVUFBVyxRQUFPLHVCQUFDLFNBQU0sYUFBWSwyQkFBMEIsV0FBVSxXQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThEO0FBRXJGLFNBQ0UsdUJBQUMsUUFBSyxXQUFVLGtDQUNkO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxPQUFPLHVCQUFDLFVBQUssV0FBVSx5QkFBeUJBLG9CQUFVRyxjQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDckUsUUFBUSxFQUFFQyxJQUFJLEdBQUdDLElBQUksR0FBR0MsSUFBSSxFQUFFO0FBQUEsTUFDOUI7QUFBQSxNQUNBLE1BQUs7QUFBQSxNQUVMO0FBQUEsK0JBQUMsYUFBYSxNQUFiLEVBQWtCLE9BQU0sY0FDdkIsaUNBQUMsT0FBSSxPQUFNLFVBQVV4QiwwQkFBZ0JrQixVQUFVTyxVQUFVLEtBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQsS0FEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxhQUFhLE1BQWIsRUFBa0IsT0FBTSxlQUN0QnBCLHlCQUFlYSxVQUFVUSxXQUFXLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsYUFBYSxNQUFiLEVBQWtCLE9BQU0sc0JBQ3RCckIseUJBQWVhLFVBQVVTLGFBQWEsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxhQUFhLE1BQWIsRUFBa0IsT0FBTSx1QkFDdEJ0Qix5QkFBZWEsVUFBVVUsbUJBQW1CLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsYUFBYSxNQUFiLEVBQWtCLE9BQU0sb0JBQ3RCdkIseUJBQWVhLFVBQVVXLE9BQU8sS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxhQUFhLE1BQWIsRUFBa0IsT0FBTSx3QkFDdEJYO0FBQUFBLG9CQUFVWSxzQkFBc0JDLFFBQVE7QUFBQSxVQUN4Q2IsVUFBVVksc0JBQXNCRSxnQkFDL0IsdUJBQUMsVUFBSyxXQUFVLHNCQUFxQjtBQUFBO0FBQUEsWUFDakNkLFVBQVVZLHFCQUFxQkU7QUFBQUEsWUFBYTtBQUFBLGVBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBO0FBQUE7QUFBQSxJQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE2QkEsS0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStCQTtBQUVKO0FBQUVDLE1BdENJaEI7QUF3Q04sTUFBTWlCLHNCQUFzQkEsQ0FBQyxFQUFFQyxXQUFXQyxTQUFTbEIsV0FBV0MsU0FBU2tCLFdBQVcsTUFBTTtBQUN0RixNQUFJbEIsUUFBUyxRQUFPLHVCQUFDLFlBQVMsUUFBTSxNQUFDLFdBQVcsRUFBRUMsTUFBTSxFQUFFLEdBQUcsV0FBVSxVQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlEO0FBRTdFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSw2QkFBQyxlQUFZLE9BQU0sZUFBYyxRQUFRZ0IsUUFBUUUsWUFBWSxnQkFBZSxvQkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RjtBQUFBLE1BQzVGLHVCQUFDLGVBQVksT0FBTSxxQkFBb0IsUUFBUUYsUUFBUUcsa0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUN0RSx1QkFBQyxlQUFZLE9BQU0sa0JBQWlCLFFBQVFILFFBQVFJLFNBQVMsZ0JBQWUsa0JBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEY7QUFBQSxTQUg1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUVDTCxVQUFVTSxTQUFTLElBQ2xCLHVCQUFDLFFBQUssV0FBVSw2QkFBNEIsV0FBVyxFQUFFN0IsU0FBUyxFQUFFLEdBQ2xFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNNUIsYUFBYW1ELFdBQVdFLFVBQVU7QUFBQSxRQUN4QyxTQUFTbkQ7QUFBQUEsUUFDVCxpQkFBZ0I7QUFBQSxRQUNoQixpQkFBaUIsQ0FBQyxjQUFjLGNBQWMsZUFBZSxxQkFBcUIsZUFBZSxnQkFBZ0I7QUFBQSxRQUNqSCxtQkFBbUI7QUFBQSxVQUNqQmdDLFdBQVdHO0FBQUFBLFVBQ1hyQixnQkFBZ0JrQixXQUFXTyxVQUFVO0FBQUEsVUFDckNQLFdBQVdRO0FBQUFBLFVBQ1hyQixlQUFlK0IsUUFBUUcsY0FBYztBQUFBLFVBQ3JDbEMsZUFBZStCLFFBQVFFLFVBQVU7QUFBQSxVQUNqQ2pDLGVBQWUrQixRQUFRSSxPQUFPO0FBQUEsUUFBQztBQUFBLFFBRWpDLGtCQUFrQixlQUFldEIsV0FBV0csY0FBYyxPQUFPO0FBQUE7QUFBQSxNQWJuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFhMEUsS0FkNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQSxJQUVBLHVCQUFDLFNBQU0sYUFBWSw0Q0FBMkMsV0FBVSxXQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStFO0FBQUEsT0ExQm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0QkE7QUFFSjtBQUtBcUIsTUF2Q01SO0FBeUNOLE1BQU1TLG9CQUFvQkEsQ0FBQyxFQUFFdkIsTUFBTUQsU0FBU2tCLFlBQVlPLFVBQVUsTUFBTTtBQUN0RSxNQUFJekIsUUFBUyxRQUFPLHVCQUFDLFlBQVMsUUFBTSxNQUFDLFdBQVcsRUFBRUMsTUFBTSxFQUFFLEdBQUcsV0FBVSxVQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlEO0FBRTdFLFFBQU1lLFlBQVlmLEtBQUt5QixJQUFJLENBQUNDLEtBQUtDLFdBQVc7QUFBQSxJQUMxQ0MsSUFBSUQsUUFBUTtBQUFBLElBQ1pFLGFBQWFILElBQUlJLGdCQUFnQjtBQUFBLElBQ2pDQyxRQUFRTCxJQUFJSyxVQUFVO0FBQUEsSUFDdEJDLFlBQVlOLElBQUlPLFNBQVNDLGVBQWU7QUFBQSxJQUN4Q3ZCLE1BQU1lLElBQUlPLFNBQVNFLGFBQWE7QUFBQSxJQUNoQ0MsYUFBYVYsSUFBSVcsZUFDYixHQUFHWCxJQUFJVyxhQUFhdkQsT0FBTyxDQUFDLEVBQUVDLFlBQVksQ0FBQyxHQUFHMkMsSUFBSVcsYUFBYXJELE1BQU0sQ0FBQyxDQUFDLEtBQ3ZFO0FBQUEsSUFDSnNELGFBQWFaLElBQUlhLGdCQUFnQjtBQUFBLElBQ2pDQyxVQUFVZCxJQUFJZSxhQUFhO0FBQUEsSUFDM0JDLFlBQVlDLFNBQVNqQixJQUFJa0IsUUFBUSxLQUFLLE1BQU1ELFNBQVNqQixJQUFJbUIsVUFBVSxLQUFLLE1BQU07QUFBQSxJQUM5RUMsV0FBVXBCLElBQUlxQixhQUFjOUQsZUFBZXlDLElBQUlxQixjQUFjLENBQUMsSUFBSTtBQUFBLElBR2xFQyxRQUFRLHVCQUFDLE9BQUksT0FBT3pFLHNCQUFzQm1ELElBQUlzQixNQUFNLEtBQUssV0FBWXRCLGNBQUlzQixVQUFVLE9BQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0U7QUFBQSxJQUN2RkMsUUFDRSx1QkFBQyxPQUFJLE9BQU92QixJQUFJd0IsYUFBYSxTQUFTLFNBQVMsV0FDNUN4QixjQUFJd0IsYUFBYSxTQUFTLFdBQVcsZ0JBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUosRUFBRTtBQUVGLE1BQUluQyxVQUFVTSxXQUFXLEdBQUc7QUFDMUIsV0FBTyx1QkFBQyxTQUFNLGFBQVksMkNBQTBDLFdBQVUsV0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RTtBQUFBLEVBQ3ZGO0FBRUEsU0FDRSx1QkFBQyxRQUFLLFdBQVUsa0NBQWlDLFdBQVcsRUFBRTdCLFNBQVMsRUFBRSxHQUN2RTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBTTVCLGFBQWFtRCxXQUFXRSxVQUFVO0FBQUEsTUFDeEMsU0FBUzNDO0FBQUFBLE1BQ1QsaUJBQWdCO0FBQUEsTUFDaEIsa0JBQWtCLGtCQUFrQmtELGFBQWEsT0FBTztBQUFBO0FBQUEsSUFKMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSWlFLEtBTG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQTtBQUVKO0FBT0EyQixNQS9DTTVCO0FBaUROLE1BQU02QixjQUFjLE9BQU9DLFNBQVM7QUFLbEMsUUFBTUMsZ0JBQWdCRCxLQUFLRSxNQUFNQztBQUNqQyxRQUFNQyxlQUFlSixLQUFLRSxNQUFNRztBQUNoQyxRQUFNQyxpQkFBaUJOLEtBQUtFLE1BQU1LO0FBQ2xDUCxPQUFLRSxNQUFNQyxZQUFZO0FBQ3ZCSCxPQUFLRSxNQUFNRyxXQUFXO0FBQ3RCTCxPQUFLRSxNQUFNSyxhQUFhO0FBQ3hCLE1BQUk7QUFDRixXQUFPLE1BQU0vRyxZQUFZd0csTUFBTSxFQUFFUSxpQkFBaUIsV0FBV0MsT0FBTyxHQUFHQyxTQUFTLEtBQUssQ0FBQztBQUFBLEVBQ3hGLFVBQUM7QUFDQ1YsU0FBS0UsTUFBTUMsWUFBWUY7QUFDdkJELFNBQUtFLE1BQU1HLFdBQVdEO0FBQ3RCSixTQUFLRSxNQUFNSyxhQUFhRDtBQUFBQSxFQUMxQjtBQUNGO0FBRUEsTUFBTUssZUFBZUEsQ0FBQ0MsTUFBTUMsYUFBYTtBQUN2QyxRQUFNQyxNQUFNQyxJQUFJQyxnQkFBZ0JKLElBQUk7QUFDcEMsUUFBTUssT0FBT0MsU0FBU0MsY0FBYyxHQUFHO0FBQ3ZDRixPQUFLRyxPQUFPTjtBQUNaRyxPQUFLSSxXQUFXUjtBQUNoQkksT0FBS0ssTUFBTTtBQUNYUCxNQUFJUSxnQkFBZ0JULEdBQUc7QUFDekI7QUFFQSxNQUFNVSxhQUFhLE9BQU9DLFdBQVdaLFVBQVVhLFNBQVM7QUFDdEQsTUFBSSxDQUFDRCxVQUFVRSxRQUFTO0FBQ3hCLE1BQUlDO0FBQ0osTUFBSTtBQUNGQSxhQUFTLE1BQU03QixZQUFZMEIsVUFBVUUsT0FBTztBQUFBLEVBQzlDLFNBQVNFLE9BQU87QUFDZEMsWUFBUUQsTUFBTSwyQkFBMkJBLEtBQUs7QUFDOUN4SSxZQUFRd0ksTUFBTSxnREFBZ0Q7QUFDOUQ7QUFBQSxFQUNGO0FBRUFELFNBQU9HLE9BQU8sT0FBT25CLFNBQVM7QUFDNUIsUUFBSSxDQUFDQSxLQUFNO0FBRVgsUUFBSWMsU0FBUyxZQUFZO0FBQ3ZCZixtQkFBYUMsTUFBTUMsUUFBUTtBQUMzQjtBQUFBLElBQ0Y7QUFJQSxVQUFNbUIsT0FBTyxJQUFJQyxLQUFLLENBQUNyQixJQUFJLEdBQUdDLFVBQVUsRUFBRXFCLE1BQU0sWUFBWSxDQUFDO0FBQzdELFFBQUlDLFVBQVVDLFlBQVlELFVBQVVDLFNBQVMsRUFBRUMsT0FBTyxDQUFDTCxJQUFJLEVBQUUsQ0FBQyxHQUFHO0FBQy9ELFVBQUk7QUFDRixjQUFNRyxVQUFVRyxNQUFNLEVBQUVELE9BQU8sQ0FBQ0wsSUFBSSxHQUFHL0YsT0FBTzRFLFNBQVMsQ0FBQztBQUN4RDtBQUFBLE1BQ0YsU0FBU2dCLE9BQU87QUFDZCxZQUFJQSxPQUFPdkUsU0FBUyxhQUFjO0FBQUEsTUFDcEM7QUFBQSxJQUNGO0FBRUFxRCxpQkFBYUMsTUFBTUMsUUFBUTtBQUMzQnhILFlBQVFrSixLQUFLLHFFQUFxRTtBQUNsRkMsV0FBT0M7QUFBQUEsTUFDTCx1QkFBdUJDLG1CQUFtQixhQUFhN0IsUUFBUSxDQUFDO0FBQUEsTUFDaEU7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxXQUFXO0FBQ2hCO0FBRUEsTUFBTThCLG1CQUFtQkEsQ0FBQyxFQUFFbEIsV0FBV1osU0FBUyxNQUM5Qyx1QkFBQyxTQUFNLE1BQU0sR0FDWDtBQUFBLHlCQUFDLFdBQVEsT0FBTSxxQkFDYjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0wsTUFBSztBQUFBLE1BQ0wsTUFBTSx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUNqQixTQUFTLE1BQU1XLFdBQVdDLFdBQVdaLFVBQVUsVUFBVTtBQUFBO0FBQUEsSUFKM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSTZELEtBTC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQTtBQUFBLEVBQ0EsdUJBQUMsV0FBUSxPQUFNLHFCQUNiO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFLO0FBQUEsTUFDTCxNQUFLO0FBQUEsTUFDTCxXQUFVO0FBQUEsTUFDVixNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ3JCLFNBQVMsTUFBTVcsV0FBV0MsV0FBV1osVUFBVSxVQUFVO0FBQUE7QUFBQSxJQUwzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLNkQsS0FOL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBQUEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQWtCQTtBQUNBK0IsTUFwQklEO0FBc0JOLE1BQU1FLG1CQUFtQkEsQ0FBQ3pHLFdBQ3ZCQSxTQUFTLFNBQ1AwRyxTQUFTLEVBQ1RDLEtBQUssRUFDTEMsUUFBUSxvQkFBb0IsR0FBRyxFQUMvQkEsUUFBUSxPQUFPLEdBQUcsRUFDbEJBLFFBQVEsVUFBVSxFQUFFO0FBS3pCLE1BQU1DLGVBQWVBLENBQUMsRUFBRTlFLFdBQVcrRSxNQUFNLE1BQ3ZDLHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLHlCQUFDLFVBQUssV0FBVSwwREFBMEQvRSx1QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFvRjtBQUFBLEVBQ3BGLHVCQUFDLFVBQUssV0FBVSxxREFBcUQrRSxtQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyRTtBQUFBLEtBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FHQTtBQUNBQyxNQUxJRjtBQU9OLE1BQU1HLGNBQWM7QUFBQSxFQUNsQkMsUUFBUTtBQUFBLEVBQ1JDLFFBQVE7QUFBQSxFQUNSQyxVQUFVO0FBQ1o7QUFFQSxNQUFNQyxTQUFTQSxDQUFDLEVBQUU5RSxPQUFPLE1BQU07QUFDN0IsUUFBTStFLFdBQVcvRSxPQUFPZ0YsY0FBYztBQUN0QyxRQUFNQyxjQUFjQyxRQUFRbEYsT0FBT0UsT0FBTztBQUMxQyxRQUFNaUYsVUFBVSxDQUFDSixXQUFXLFdBQVdFLGNBQWMsV0FBVztBQUVoRSxRQUFNRyxpQkFBaUIsQ0FBQ0wsV0FDdEIsdUJBQUMsVUFBSztBQUFBO0FBQUEsSUFBUS9FLE9BQU9xRjtBQUFBQSxJQUFRO0FBQUEsT0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5QyxJQUN2Q0osY0FDRix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxpQkFBaUJqRixpQkFBT0UsUUFBUUUsYUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RDtBQUFBLElBQ3pELHVCQUFDLFNBQUksV0FBVSxzQkFBc0JKLGlCQUFPRSxRQUFRQyxlQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdFO0FBQUEsSUFDaEUsdUJBQUMsU0FBSSxXQUFVLHNCQUFzQkgsaUJBQU9FLFFBQVFyQixnQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRTtBQUFBLE9BSG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQSxJQUVBLHVCQUFDLFVBQUs7QUFBQTtBQUFBLElBQVFtQixPQUFPcUY7QUFBQUEsSUFBUTtBQUFBLE9BQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkQ7QUFHN0QsU0FDRSx1QkFBQyxXQUFRLE9BQU9ELGdCQUFnQixXQUFVLE9BQU0saUJBQWlCLE1BQU0saUJBQWlCLE1BQ3RGO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXO0FBQUE7QUFBQSwwQkFFT1YsWUFBWVMsT0FBTyxDQUFDO0FBQUEsTUFFckNuRixpQkFBT3FGO0FBQUFBO0FBQUFBLElBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFSjtBQUFFQyxNQTVCSVI7QUE4Qk4sTUFBTVMsVUFBVUEsQ0FBQyxFQUFFRixRQUFRLE1BQU07QUFBQUcsS0FBQTtBQUMvQixRQUFNdkgsT0FBT3BFLFFBQVEsTUFBTTtBQUN6QixVQUFNNEwsU0FBUztBQUNmLGFBQVNDLElBQUksR0FBR0EsSUFBSUwsUUFBUS9GLFFBQVFvRyxLQUFLOUksZUFBZTtBQUN0RDZJLGFBQU9FLEtBQUtOLFFBQVFwSSxNQUFNeUksR0FBR0EsSUFBSTlJLGFBQWEsQ0FBQztBQUFBLElBQ2pEO0FBQ0EsV0FBTzZJO0FBQUFBLEVBQ1QsR0FBRyxDQUFDSixPQUFPLENBQUM7QUFFWixTQUNFLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxTQUFJLFdBQVUsaUJBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsdUdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrSDtBQUFBLElBQ2xILHVCQUFDLFNBQUksV0FBVSx1QkFDWnBILGVBQUt5QjtBQUFBQSxNQUFJLENBQUNDLEtBQUtpRyxhQUNkLHVCQUFDLFNBQW1CLFdBQVUsMkJBQzVCO0FBQUEsK0JBQUMsVUFBSyxXQUFVLCtDQUNiQyxpQkFBT0MsYUFBYSxLQUFLRixRQUFRLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNaakcsY0FBSUQ7QUFBQUEsVUFBSSxDQUFDTSxXQUNSLHVCQUFDLFVBQTRCLFVBQWhCQSxPQUFPcUYsU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEM7QUFBQSxRQUM3QyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBUlFPLFVBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsSUFDRCxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLE9BaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUVKLEdBL0JJRCxTQUFPO0FBQUFRLE1BQVBSO0FBaUNOLE1BQU1TLGFBQWFBLENBQUMsRUFBRUMsWUFBWSxNQUNoQyx1QkFBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSx5QkFBQyxVQUFLLFdBQVUsMkJBQ2Q7QUFBQSwyQkFBQyxVQUFLLFdBQVUsZ0RBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQ7QUFBQSxJQUFHO0FBQUEsT0FEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBQUEsRUFDQSx1QkFBQyxVQUFLLFdBQVUsMkJBQ2Q7QUFBQSwyQkFBQyxVQUFLLFdBQVUsdUVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUY7QUFBQSxJQUFHO0FBQUEsT0FEeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBQUEsRUFDQ0EsZUFDQyx1QkFBQyxVQUFLLFdBQVUsMkJBQ2Q7QUFBQSwyQkFBQyxVQUFLLFdBQVUsc0VBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0Y7QUFBQSxJQUFHO0FBQUEsT0FEdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBQUEsS0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BWUE7QUFDQUMsTUFkSUY7QUFnQk4sTUFBTUcsZ0JBQWdCQSxDQUFDLEVBQUV4QixRQUFRQyxPQUFPLE1BQU07QUFDNUMsUUFBTXdCLFFBQVF6QixTQUFTQyxVQUFVO0FBQ2pDLFFBQU15QixPQUFPO0FBQUEsSUFDWCxFQUFFekgsTUFBTSxVQUFVbEIsT0FBT2lILE9BQU87QUFBQSxJQUNoQyxFQUFFL0YsTUFBTSxhQUFhbEIsT0FBT2tILE9BQU87QUFBQSxFQUFDO0FBRXRDLFFBQU0wQixTQUFTLENBQUMsV0FBVyxTQUFTO0FBRXBDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsMkJBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFPLFFBQ3ZDLGlDQUFDLFlBQ0M7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFNBQVE7QUFBQSxVQUNSLGFBQVk7QUFBQSxVQUNaLGFBQVk7QUFBQSxVQUNaLFlBQVk7QUFBQSxVQUNaLFVBQVU7QUFBQSxVQUNWLGNBQWM7QUFBQSxVQUViRCxlQUFLM0c7QUFBQUEsWUFBSSxDQUFDNkcsT0FBTzNHLFVBQ2hCLHVCQUFDLFFBQXNCLE1BQU0wRyxPQUFPMUcsS0FBSyxHQUFHLFFBQU8sVUFBeEMyRyxNQUFNM0gsTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQ7QUFBQSxVQUMxRDtBQUFBO0FBQUEsUUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFZQTtBQUFBLE1BQ0EsdUJBQUMsa0JBQWUsV0FBVyxDQUFDbEIsT0FBT2tCLFNBQVMsQ0FBQyxHQUFHbEIsS0FBSyxZQUFZa0IsSUFBSSxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFO0FBQUEsTUFDdkUsdUJBQUMsVUFBTyxlQUFjLFVBQVMsUUFBUSxJQUFJLFVBQVMsWUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLFNBZjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLGlHQUNiO0FBQUEsNkJBQUMsVUFBSyxXQUFVLG9DQUFvQzRIO0FBQUFBLGFBQUtDLE1BQU85QixTQUFTeUIsUUFBUyxHQUFHO0FBQUEsUUFBRTtBQUFBLFdBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Y7QUFBQSxNQUN4Rix1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLHNCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtEO0FBQUEsU0FGcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQTtBQUVKO0FBQUVNLE9BbkNJUDtBQXFDTixNQUFNUSxrQkFBa0JBLENBQUMsRUFBRUMsVUFBVSxNQUFNO0FBQ3pDLE1BQUlBLFVBQVV0SCxXQUFXLEdBQUc7QUFDMUIsV0FBTyx1QkFBQyxTQUFNLGFBQVksbUJBQWtCLFdBQVUsV0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLEVBQy9EO0FBQ0EsUUFBTXVILGNBQWNMLEtBQUtNLElBQUksS0FBS0YsVUFBVXRILFNBQVMsRUFBRTtBQUN2RCxTQUNFLHVCQUFDLFNBQUksV0FBVSxzQ0FDYixpQ0FBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVF1SCxhQUN4QyxpQ0FBQyxZQUFTLE1BQU1ELFdBQVcsUUFBTyxZQUFXLFFBQVEsRUFBRUcsTUFBTSxJQUFJQyxPQUFPLElBQUlDLEtBQUssR0FBR0MsUUFBUSxFQUFFLEdBQzVGO0FBQUEsMkJBQUMsaUJBQWMsaUJBQWdCLE9BQU0sWUFBWSxPQUFPLFFBQU8sYUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RTtBQUFBLElBQ3hFLHVCQUFDLFNBQU0sTUFBSyxVQUFTLGVBQWUsT0FBTyxNQUFNLEVBQUV2SixVQUFVLElBQUl3SixNQUFNLFVBQVUsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRjtBQUFBLElBQ25GO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxNQUFNLEVBQUV4SixVQUFVLElBQUl3SixNQUFNLFVBQVU7QUFBQSxRQUN0QyxVQUFVO0FBQUE7QUFBQSxNQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtjO0FBQUEsSUFFZDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVyxDQUFDekosVUFBVSxDQUFDLEdBQUdBLEtBQUssVUFBVUEsUUFBUSxJQUFJLE1BQU0sRUFBRSxJQUFJLE1BQU07QUFBQSxRQUN2RSxRQUFRLEVBQUV5SixNQUFNLFVBQVU7QUFBQTtBQUFBLE1BRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUU4QjtBQUFBLElBRTlCLHVCQUFDLE9BQUksU0FBUSxTQUFRLE1BQUssV0FBVSxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLFNBQVMsTUFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRTtBQUFBLE9BZHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkE7QUFFSjtBQUFFQyxPQTNCSVQ7QUE2Qk4sTUFBTVUsaUJBQWlCQSxDQUFDLEVBQUVULFVBQVUsTUFBTTtBQUN4QyxRQUFNSyxNQUFNTCxVQUFVM0osTUFBTSxHQUFHLENBQUM7QUFDaEMsTUFBSWdLLElBQUkzSCxXQUFXLEdBQUc7QUFDcEIsV0FBTyx1QkFBQyxTQUFNLGFBQVksbUJBQWtCLFdBQVUsVUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRDtBQUFBLEVBQzlEO0FBQ0EsU0FDRSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1oySCxjQUFJdkg7QUFBQUEsSUFBSSxDQUFDNEgsUUFBUTFILFVBQ2hCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFFQyxXQUFVO0FBQUEsUUFFVjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSx1REFBdURBLGtCQUFRLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsWUFDakYsdUJBQUMsVUFBSyxXQUFVLGlEQUFpRDBILGlCQUFPMUksUUFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxlQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsK0NBQ2IwSTtBQUFBQSxtQkFBT0M7QUFBQUEsWUFBTTtBQUFBLFlBQVFELE9BQU9DLFFBQVEsSUFBSSxNQUFNO0FBQUEsZUFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBO0FBQUE7QUFBQSxNQVRLRCxPQUFPMUksT0FBT2dCO0FBQUFBLE1BRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFXQTtBQUFBLEVBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZUE7QUFFSjtBQUFFNEgsT0F2QklIO0FBeUJOLE1BQU1JLHNCQUFzQkEsQ0FBQyxFQUFFQyxhQUFhMUosUUFBUSxNQUFNO0FBQUEySixNQUFBO0FBQ3hELFFBQU1DLGFBQWE5TixPQUFPLElBQUk7QUFDOUIsUUFBTStOLGNBQWMvTixPQUFPLElBQUk7QUFDL0IsUUFBTWdPLGFBQWFoTyxPQUFPLElBQUk7QUFJOUIsUUFBTXVMLFVBQVVxQyxhQUFhSyxrQkFBa0I7QUFFL0MsUUFBTUMsYUFBYW5PLFFBQVEsTUFBTTtBQUMvQixVQUFNb08sYUFBYSxvQkFBSUMsSUFBSTtBQUMzQjdDLFlBQVE4QyxRQUFRLENBQUNDLE1BQU07QUFDckIsVUFBSUEsRUFBRXBELGNBQWMsWUFBWSxDQUFDb0QsRUFBRWxJLFFBQVM7QUFDNUMsWUFBTWxFLE1BQU1vTSxFQUFFbEksUUFBUUM7QUFDdEIsWUFBTWtJLFdBQVdKLFdBQVdLLElBQUl0TSxHQUFHO0FBQ25DLFVBQUlxTSxVQUFVO0FBQ1pBLGlCQUFTZCxTQUFTO0FBQUEsTUFDcEIsT0FBTztBQUNMVSxtQkFBV00sSUFBSXZNLEtBQUssRUFBRTRDLE1BQU13SixFQUFFbEksUUFBUUUsV0FBV21ILE9BQU8sRUFBRSxDQUFDO0FBQUEsTUFDN0Q7QUFBQSxJQUNGLENBQUM7QUFDRCxXQUFPaUIsTUFBTUMsS0FBS1IsV0FBV1MsT0FBTyxDQUFDLEVBQUVDLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRXRCLFFBQVFxQixFQUFFckIsS0FBSztBQUFBLEVBQ3pFLEdBQUcsQ0FBQ2xDLE9BQU8sQ0FBQztBQUVaLFFBQU15RCxrQkFBa0JqUCxRQUFRLE1BQU07QUFDcEMsVUFBTWtQLE1BQU0sSUFBSUM7QUFBQUEsTUFDZDNELFFBQVE0RCxPQUFPLENBQUNiLE1BQU1BLEVBQUVsSSxPQUFPLEVBQUVSLElBQUksQ0FBQzBJLE1BQU1BLEVBQUVsSSxRQUFRQyxXQUFXO0FBQUEsSUFDbkU7QUFDQSxXQUFPNEksSUFBSUc7QUFBQUEsRUFDYixHQUFHLENBQUM3RCxPQUFPLENBQUM7QUFFWixNQUFJckgsUUFBUyxRQUFPLHVCQUFDLFlBQVMsUUFBTSxNQUFDLFdBQVcsRUFBRUMsTUFBTSxFQUFFLEdBQUcsV0FBVSxVQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlEO0FBQzdFLE1BQUksQ0FBQ3lKLFlBQWEsUUFBTyx1QkFBQyxTQUFNLGFBQVksNEJBQTJCLFdBQVUsV0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUErRDtBQUV4RixRQUFNL0MsU0FBU1UsUUFBUTRELE9BQU8sQ0FBQ2IsTUFBTUEsRUFBRXBELGNBQWMsUUFBUSxFQUFFMUY7QUFDL0QsUUFBTXNGLFNBQVNTLFFBQVEvRixTQUFTcUY7QUFDaEMsUUFBTXNCLGNBQWNaLFFBQVE4RCxLQUFLLENBQUNmLE1BQU1BLEVBQUVwRCxjQUFjLFlBQVksQ0FBQ29ELEVBQUVsSSxPQUFPO0FBQzlFLFFBQU1ULFlBQVlpSSxZQUFZMEIsT0FBT2xMLGNBQWM7QUFDbkQsUUFBTW1MLGdCQUFnQmxGLGlCQUFpQjFFLFNBQVM7QUFFaEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLDZCQUFDLFFBQUssV0FBVSw2QkFBNEIsV0FBVyxFQUFFaEMsU0FBUyxZQUFZLEdBQzVFO0FBQUEsK0JBQUMsT0FBRSxXQUFVLDBDQUF5Qyw2QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQ25FLHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0M0SCxrQkFBUS9GLFVBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0U7QUFBQSxXQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBVSw2QkFBNEIsV0FBVyxFQUFFN0IsU0FBUyxZQUFZLEdBQzVFO0FBQUEsK0JBQUMsT0FBRSxXQUFVLDBDQUF5QyxzQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFFBQzVELHVCQUFDLE9BQUUsV0FBVSxzQ0FBc0NrSCxvQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFdBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxXQUFVLDZCQUE0QixXQUFXLEVBQUVsSCxTQUFTLFlBQVksR0FDNUU7QUFBQSwrQkFBQyxPQUFFLFdBQVUsMENBQXlDLHlCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsUUFDL0QsdUJBQUMsT0FBRSxXQUFVLHVDQUF1Q21ILG9CQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsV0FGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVUsNkJBQTRCLFdBQVcsRUFBRW5ILFNBQVMsWUFBWSxHQUM1RTtBQUFBLCtCQUFDLE9BQUUsV0FBVSwwQ0FBeUMsZ0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUN0RSx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DcUwsNkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxXQUZuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBTyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQztBQUFBLFVBQ2pELE9BQ0UsdUJBQUMsU0FBTSxNQUFNLElBQ1g7QUFBQSxtQ0FBQyxTQUFNLE9BQU0sV0FBVSxNQUFNLEdBQUduRSxNQUFNLElBQUlVLFFBQVEvRixNQUFNLGFBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFO0FBQUEsWUFDbEUsdUJBQUMsb0JBQWlCLFdBQVdzSSxZQUFZLFVBQVUsR0FBR3lCLGFBQWEsbUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1GO0FBQUEsZUFGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBR0YsaUNBQUMsU0FBSSxLQUFLekIsWUFBWSxXQUFVLFlBQzlCO0FBQUEsbUNBQUMsZ0JBQWEsV0FBc0IsT0FBTSxnQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUN0RCx1QkFBQyxXQUFRLFdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEI7QUFBQSxZQUMxQix1QkFBQyxjQUFXLGVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxlQUh2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUE7QUFBQSxRQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsT0FBTyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLHlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBLFlBQ2hELE9BQU8sdUJBQUMsb0JBQWlCLFdBQVdDLGFBQWEsVUFBVSxHQUFHd0IsYUFBYSxvQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxZQUU1RixpQ0FBQyxTQUFJLEtBQUt4QixhQUFhLFdBQVUsWUFDL0I7QUFBQSxxQ0FBQyxnQkFBYSxXQUFzQixPQUFNLGVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFEO0FBQUEsY0FDckQsdUJBQUMsaUJBQWMsUUFBZ0IsVUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQSxpQkFGaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBO0FBQUEsVUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxXQUFVLDZCQUE0QixPQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0Isa0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0QsR0FDbkcsaUNBQUMsa0JBQWUsV0FBV0csY0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQ0E7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixPQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsOEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUNyRCxPQUFPLHVCQUFDLG9CQUFpQixXQUFXRixZQUFZLFVBQVUsR0FBR3VCLGFBQWEseUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxRQUVoRyxpQ0FBQyxTQUFJLEtBQUt2QixZQUFZLFdBQVUsWUFDOUI7QUFBQSxpQ0FBQyxnQkFBYSxXQUFzQixPQUFNLG9CQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLFVBQzFELHVCQUFDLG1CQUFnQixXQUFXRSxjQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLGFBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBO0FBQUEsTUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTQTtBQUFBLE9BaEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpRUE7QUFFSjtBQUFFTCxJQTVHSUYscUJBQW1CO0FBQUE2QixPQUFuQjdCO0FBOEdOLE1BQU04QixjQUFjQSxNQUFNO0FBQUFDLE1BQUE7QUFDeEIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUk5UCxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDK1AsaUJBQWlCQyxrQkFBa0IsSUFBSWhRLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNpUSxZQUFZQyxhQUFhLElBQUlsUSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDOE4sYUFBYXFDLGNBQWMsSUFBSW5RLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUNvUSxhQUFhQyxjQUFjLElBQUlyUSxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDc0YsWUFBWWdMLGFBQWEsSUFBSXRRLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN1USxpQkFBaUJDLGtCQUFrQixJQUFJeFEsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ3lRLGlCQUFpQkMsa0JBQWtCLElBQUkxUSxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDMlEsa0JBQWtCQyxtQkFBbUIsSUFBSTVRLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUM2USxrQkFBa0JDLG1CQUFtQixJQUFJOVEsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQytRLFdBQVdDLFlBQVksSUFBSWhSLFNBQVMsY0FBYztBQUd6RCxRQUFNaVIsa0JBQWtCL1EsT0FBTyxDQUFDO0FBR2hDLFFBQU1nUix5QkFBeUJoUixPQUFPLElBQUk7QUFFMUMsUUFBTWlSLDhCQUE4QkEsQ0FBQ0MsTUFBTWQsY0FBY2MsRUFBRUMsT0FBT3ZOLEtBQUs7QUFFdkUvRCxZQUFVLE1BQU07QUFDZCxVQUFNdVIsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU16UCxJQUFJNE0sSUFBSSx3QkFBd0I7QUFDdkRvQixrQkFBVXlCLFNBQVM5RSxJQUFJO0FBQUEsTUFDekIsU0FBU2xELE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBQUEsTUFDL0MsVUFBQztBQUNDaUgsMkJBQW1CLEtBQUs7QUFBQSxNQUMxQjtBQUFBLElBQ0Y7QUFDQWMsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMdlIsWUFBVSxNQUFNO0FBR2RtUSxrQkFBYyxFQUFFO0FBQ2hCQyxtQkFBZSxJQUFJO0FBQ25CRSxtQkFBZSxFQUFFO0FBQ2pCYSwyQkFBdUI3SCxVQUFVO0FBRWpDLFFBQUksQ0FBQzBHLGdCQUFpQjtBQUV0QixVQUFNeUIsWUFBWSxFQUFFUCxnQkFBZ0I1SDtBQUNwQ3FILHVCQUFtQixJQUFJO0FBQ3ZCRSx3QkFBb0IsSUFBSTtBQUV4QixVQUFNYSxtQkFBbUIsWUFBWTtBQUNuQyxVQUFJO0FBQ0YsY0FBTUYsV0FBVyxNQUFNelAsSUFBSTRNLElBQUksaUNBQWlDO0FBQUEsVUFDOURnRCxRQUFRLEVBQUVDLFVBQVU1QixnQkFBZ0I7QUFBQSxRQUN0QyxDQUFDO0FBQ0QsWUFBSXlCLGNBQWNQLGdCQUFnQjVILFNBQVM7QUFDekM2Ryx3QkFBY3FCLFNBQVM5RSxNQUFNQSxRQUFRLEVBQUU7QUFBQSxRQUN6QztBQUFBLE1BQ0YsU0FBU2xELE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25ELFlBQUlpSSxjQUFjUCxnQkFBZ0I1SCxTQUFTO0FBQ3pDNkcsd0JBQWMsRUFBRTtBQUFBLFFBQ2xCO0FBQUEsTUFDRixVQUFDO0FBQ0MsWUFBSXNCLGNBQWNQLGdCQUFnQjVILFNBQVM7QUFDekNxSCw2QkFBbUIsS0FBSztBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxVQUFNa0Isd0JBQXdCLFlBQVk7QUFDeEMsVUFBSTtBQUNGLGNBQU1MLFdBQVcsTUFBTXpQLElBQUk0TSxJQUFJLDRCQUE0QjtBQUFBLFVBQ3pEZ0QsUUFBUSxFQUFFQyxVQUFVNUIsZ0JBQWdCO0FBQUEsUUFDdEMsQ0FBQztBQUNELFlBQUl5QixjQUFjUCxnQkFBZ0I1SCxTQUFTO0FBQ3pDOEcseUJBQWVvQixTQUFTOUUsTUFBTUEsUUFBUSxJQUFJO0FBQUEsUUFDNUM7QUFBQSxNQUNGLFNBQVNsRCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHFDQUFxQ0EsS0FBSztBQUN4RCxZQUFJaUksY0FBY1AsZ0JBQWdCNUgsU0FBUztBQUN6QzhHLHlCQUFlLElBQUk7QUFBQSxRQUNyQjtBQUFBLE1BQ0YsVUFBQztBQUNDLFlBQUlxQixjQUFjUCxnQkFBZ0I1SCxTQUFTO0FBQ3pDdUgsOEJBQW9CLEtBQUs7QUFBQSxRQUMzQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUFhLHFCQUFpQjtBQUNqQkcsMEJBQXNCO0FBQUEsRUFDeEIsR0FBRyxDQUFDN0IsZUFBZSxDQUFDO0FBSXBCaFEsWUFBVSxNQUFNO0FBQ2QsUUFBSWdSLGNBQWMsb0JBQW9CLENBQUNoQixnQkFBaUI7QUFDeEQsUUFBSW1CLHVCQUF1QjdILFlBQVkwRyxnQkFBaUI7QUFFeEQsUUFBSThCLFlBQVk7QUFDaEIsVUFBTUMsc0JBQXNCLFlBQVk7QUFDdENoQiwwQkFBb0IsSUFBSTtBQUN4QixVQUFJO0FBQ0YsY0FBTVMsV0FBVyxNQUFNelAsSUFBSTRNLElBQUksMEJBQTBCcUIsZUFBZSxFQUFFO0FBQzFFLGNBQU1nQyxVQUFVUixTQUFTOUU7QUFDekIsY0FBTXBJLE9BQU91SyxNQUFNb0QsUUFBUUQsT0FBTyxJQUFJQSxVQUFVQSxTQUFTdEYsUUFBUTtBQUNqRSxZQUFJLENBQUNvRixXQUFXO0FBQ2R4Qix5QkFBZWhNLElBQUk7QUFDbkI2TSxpQ0FBdUI3SCxVQUFVMEc7QUFBQUEsUUFDbkM7QUFBQSxNQUNGLFNBQVN4RyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RCxZQUFJLENBQUNzSSxVQUFXeEIsZ0JBQWUsRUFBRTtBQUFBLE1BQ25DLFVBQUM7QUFDQyxZQUFJLENBQUN3QixVQUFXZixxQkFBb0IsS0FBSztBQUFBLE1BQzNDO0FBQUEsSUFDRjtBQUVBZ0Isd0JBQW9CO0FBQ3BCLFdBQU8sTUFBTTtBQUNYRCxrQkFBWTtBQUFBLElBQ2Q7QUFBQSxFQUNGLEdBQUcsQ0FBQ2QsV0FBV2hCLGVBQWUsQ0FBQztBQUUvQixRQUFNNUwsWUFBWThMLFdBQVcsQ0FBQyxHQUFHMEIsWUFBWTdELGFBQWEwQixTQUFTO0FBRW5FLFFBQU1uSyxVQUFVcEY7QUFBQUEsSUFDZCxNQUNFZ1EsV0FBV2dDO0FBQUFBLE1BQ1QsQ0FBQ0MsUUFBUW5NLFNBQVM7QUFBQSxRQUNoQlAsZ0JBQWdCME0sT0FBTzFNLGtCQUFrQmhDLE9BQU91QyxJQUFJb00sYUFBYSxLQUFLO0FBQUEsUUFDdEU1TSxZQUFZMk0sT0FBTzNNLGNBQWMvQixPQUFPdUMsSUFBSXFNLGdCQUFnQixLQUFLO0FBQUEsUUFDakUzTSxTQUFTeU0sT0FBT3pNLFdBQVdqQyxPQUFPdUMsSUFBSXNNLGFBQWEsS0FBSztBQUFBLE1BQzFEO0FBQUEsTUFDQSxFQUFFN00sZ0JBQWdCLEdBQUdELFlBQVksR0FBR0UsU0FBUyxFQUFFO0FBQUEsSUFDakQ7QUFBQSxJQUNGLENBQUN3SyxVQUFVO0FBQUEsRUFDYjtBQUVBLFFBQU03SyxZQUFZbkY7QUFBQUEsSUFDaEIsTUFDRWdRLFdBQVduSyxJQUFJLENBQUNDLEtBQUtDLFdBQVc7QUFBQSxNQUM5QkMsSUFBSUQsUUFBUTtBQUFBLE1BQ1pLLFlBQVlOLElBQUlPLFNBQVNDLGVBQWU7QUFBQSxNQUN4Q3ZCLE1BQU1lLElBQUlPLFNBQVNFLGFBQWE7QUFBQSxNQUNoQzhMLGFBQWF2TSxJQUFJTyxTQUFTckIsZ0JBQWdCO0FBQUEsTUFDMUNtQixRQUFRTCxJQUFJMEY7QUFBQUEsTUFDWnBFLFFBQ0UsdUJBQUMsT0FBSSxPQUFPL0UsY0FBY3lELElBQUl3TSxlQUFlLEtBQUssV0FDL0N4TSxjQUFJd00sbUJBQW1CLE9BRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUYvTSxnQkFBZ0JsQyxlQUFleUMsSUFBSW9NLGFBQWE7QUFBQSxNQUNoRDVNLFlBQVlqQyxlQUFleUMsSUFBSXFNLGdCQUFnQjtBQUFBLE1BQy9DM00sU0FBU25DLGVBQWV5QyxJQUFJc00sYUFBYTtBQUFBLE1BQ3pDRyxpQkFBaUJ6TSxJQUFJME0scUJBQXFCO0FBQUEsSUFDNUMsRUFBRTtBQUFBLElBQ0osQ0FBQ3hDLFVBQVU7QUFBQSxFQUNiO0FBR0EsUUFBTXlDLFdBQVc7QUFBQSxJQUNmO0FBQUEsTUFDRXRRLEtBQUs7QUFBQSxNQUNMd0ksT0FBTztBQUFBLE1BQ1ArSCxVQUFVLHVCQUFDLG1CQUFnQixXQUFzQixTQUFTbEMsbUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxJQUM1RTtBQUFBLElBQ0M7QUFBQSxNQUNDck8sS0FBSztBQUFBLE1BQ0x3SSxPQUFPO0FBQUEsTUFDUCtILFVBQVUsdUJBQUMsdUJBQW9CLGFBQTBCLFNBQVNoQyxvQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLElBQ3JGO0FBQUEsSUFDQTtBQUFBLE1BQ0V2TyxLQUFLO0FBQUEsTUFDTHdJLE9BQU87QUFBQSxNQUNQK0gsVUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsU0FBU2xDO0FBQUFBLFVBQ1Q7QUFBQTtBQUFBLFFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3lCO0FBQUEsSUFHN0I7QUFBQSxJQUVBO0FBQUEsTUFDRXJPLEtBQUs7QUFBQSxNQUNMd0ksT0FBTztBQUFBLE1BQ1ArSCxVQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNdkM7QUFBQUEsVUFDTixTQUFTUztBQUFBQSxVQUNUO0FBQUEsVUFDQSxXQUFXMU0sV0FBV0c7QUFBQUE7QUFBQUEsUUFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSW1DO0FBQUEsSUFHdkM7QUFBQSxFQUFDO0FBR0gsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2IsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQkFBQyxVQUFPLDZCQUEwRCxZQUFZLFFBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUY7QUFBQSxJQUVuRix1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUseUNBQXdDLDRCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsTUFFbEUsdUJBQUMsUUFBSyxXQUFVLGtDQUNkLGlDQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSx5REFBd0QsU0FBUSxnQkFBZSw0QkFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0g7QUFBQSxZQUNBLFNBQVNpTTtBQUFBQSxZQUNULHVCQUF1QjtBQUFBLFlBQ3ZCLE9BQU8sRUFBRXFDLFFBQVEsSUFBSUMsT0FBTyxRQUFRQyxVQUFVLElBQUk7QUFBQSxZQUNsRCxhQUFZO0FBQUEsWUFDWixPQUFPL0MsbUJBQW1CZ0Q7QUFBQUEsWUFDMUIsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT04sU0FBU25JLFNBQVMsRUFBRTBJLFlBQVksRUFBRUMsU0FBU0gsTUFBTUUsWUFBWSxDQUFDO0FBQUEsWUFFdkUsVUFBVWxEO0FBQUFBLFlBRVRILGlCQUFPL0o7QUFBQUEsY0FBSSxDQUFDMEosVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTTRELEtBQ3pDNUQsZ0JBQU1sTCxjQURXa0wsTUFBTTRELEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxZQUNEO0FBQUE7QUFBQSxVQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFrQkE7QUFBQSxXQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBLEtBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkE7QUFBQSxNQUVDckQsa0JBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVdnQjtBQUFBQSxVQUNYLFVBQVVDO0FBQUFBLFVBQ1YsT0FBTzBCO0FBQUFBLFVBQ1AsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBO0FBQUEsUUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLK0IsSUFHL0IsdUJBQUMsUUFBSyxXQUFVLDZCQUNkLGlDQUFDLFNBQU0sYUFBWSwyQ0FBMEMsV0FBVSxXQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThFLEtBRGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQ0E7QUFBQSxPQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0NBLEtBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpREE7QUFFSjtBQUFFOUMsSUE1UElELGFBQVc7QUFBQTBELE9BQVgxRDtBQThQTixlQUFlQTtBQUFZLElBQUExTCxJQUFBaUIsS0FBQVMsS0FBQTZCLEtBQUE4QyxLQUFBTyxLQUFBYSxLQUFBUyxLQUFBRyxLQUFBUSxNQUFBVSxNQUFBSSxNQUFBOEIsTUFBQTJEO0FBQUFDLGFBQUFyUCxJQUFBO0FBQUFxUCxhQUFBcE8sS0FBQTtBQUFBb08sYUFBQTNOLEtBQUE7QUFBQTJOLGFBQUE5TCxLQUFBO0FBQUE4TCxhQUFBaEosS0FBQTtBQUFBZ0osYUFBQXpJLEtBQUE7QUFBQXlJLGFBQUE1SCxLQUFBO0FBQUE0SCxhQUFBbkgsS0FBQTtBQUFBbUgsYUFBQWhILEtBQUE7QUFBQWdILGFBQUF4RyxNQUFBO0FBQUF3RyxhQUFBOUYsTUFBQTtBQUFBOEYsYUFBQTFGLE1BQUE7QUFBQTBGLGFBQUE1RCxNQUFBO0FBQUE0RCxhQUFBRCxNQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwidXNlUmVmIiwiU2VsZWN0IiwiVGFicyIsIkNhcmQiLCJEZXNjcmlwdGlvbnMiLCJUYWciLCJTa2VsZXRvbiIsIkVtcHR5IiwiU3RhdGlzdGljIiwiVG9vbHRpcCIsIkJhZGdlIiwiQnV0dG9uIiwiU3BhY2UiLCJtZXNzYWdlIiwiUmlXaGF0c2FwcExpbmUiLCJGaURvd25sb2FkIiwiaHRtbDJjYW52YXMiLCJQaWVDaGFydCIsIlBpZSIsIkNlbGwiLCJSZWNoYXJ0VG9vbHRpcCIsIlJlc3BvbnNpdmVDb250YWluZXIiLCJCYXJDaGFydCIsIkJhciIsIlhBeGlzIiwiWUF4aXMiLCJDYXJ0ZXNpYW5HcmlkIiwiTGVnZW5kIiwiYXBpIiwiRGF0YVRhYmxlIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIlJFUE9SVF9DT0xVTU5TIiwia2V5IiwiaGVhZGVyIiwiU1RBVFVTX0NPTE9SUyIsIkFjdGl2ZSIsIkNsb3NlZCIsIkRlZmF1bHRlZCIsIlByaXplZCIsIkFVQ1RJT05fQ09MVU1OUyIsIkFVQ1RJT05fU1RBVFVTX0NPTE9SUyIsIlBlbmRpbmciLCJDb21wbGV0ZWQiLCJDYW5jZWxsZWQiLCJTRUFUX1JPV19TSVpFIiwiZm9ybWF0R3JvdXBUeXBlIiwiZ3JvdXBUeXBlIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzbGljZSIsImZvcm1hdEN1cnJlbmN5IiwiYW1vdW50IiwiTnVtYmVyIiwidG9Mb2NhbGVTdHJpbmciLCJTdW1tYXJ5U3RhdCIsInRpdGxlIiwidmFsdWVDbGFzc05hbWUiLCJwYWRkaW5nIiwidmFsdWUiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJfYyIsIkdyb3VwRGV0YWlsc1RhYiIsImdyb3VwSW5mbyIsImxvYWRpbmciLCJyb3dzIiwiZ3JvdXBfbmFtZSIsInhzIiwic20iLCJsZyIsImdyb3VwX3R5cGUiLCJncm91cF92YWx1ZSIsImdyb3VwX2luc3RhbGwiLCJtb250aGx5X2luc3RhbGxtZW50IiwicmVnX2ZlZSIsInJlbGF0aW9uc2hpcF9tYW5hZ2VyIiwibmFtZSIsInBob25lX251bWJlciIsIl9jMiIsIkN1c3RvbWVyT3ZlcnZpZXdUYWIiLCJ0YWJsZURhdGEiLCJzdW1tYXJ5Iiwic2VhcmNoVGV4dCIsImFtb3VudFBhaWQiLCJhbW91bnRUb0JlUGFpZCIsImJhbGFuY2UiLCJsZW5ndGgiLCJfYzMiLCJBdWN0aW9uRGV0YWlsc1RhYiIsImdyb3VwTmFtZSIsIm1hcCIsInJvdyIsImluZGV4IiwiaWQiLCJhdWN0aW9uQ29kZSIsImF1Y3Rpb25fY29kZSIsInRpY2tldCIsImN1c3RvbWVySWQiLCJ1c2VyX2lkIiwiY3VzdG9tZXJfaWQiLCJmdWxsX25hbWUiLCJhdWN0aW9uVHlwZSIsImF1Y3Rpb25fdHlwZSIsImF1Y3Rpb25EYXRlIiwiYXVjdGlvbl9kYXRlIiwibmV4dERhdGUiLCJuZXh0X2RhdGUiLCJiaWRBbW91bnQiLCJwYXJzZUludCIsImRpdmlkZW50IiwiY29tbWlzc2lvbiIsIndpbkFtb3VudCIsIndpbl9hbW91bnQiLCJzdGF0dXMiLCJwcml6ZWQiLCJpc1ByaXplZCIsIl9jNCIsImNhcHR1cmVOb2RlIiwibm9kZSIsInByZXZNYXhIZWlnaHQiLCJzdHlsZSIsIm1heEhlaWdodCIsInByZXZPdmVyZmxvdyIsIm92ZXJmbG93IiwicHJldlBhZGRpbmdUb3AiLCJwYWRkaW5nVG9wIiwiYmFja2dyb3VuZENvbG9yIiwic2NhbGUiLCJ1c2VDT1JTIiwiZG93bmxvYWRCbG9iIiwiYmxvYiIsImZpbGVuYW1lIiwidXJsIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwibGluayIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsImNsaWNrIiwicmV2b2tlT2JqZWN0VVJMIiwiZXhwb3J0Q2FyZCIsInRhcmdldFJlZiIsIm1vZGUiLCJjdXJyZW50IiwiY2FudmFzIiwiZXJyb3IiLCJjb25zb2xlIiwidG9CbG9iIiwiZmlsZSIsIkZpbGUiLCJ0eXBlIiwibmF2aWdhdG9yIiwiY2FuU2hhcmUiLCJmaWxlcyIsInNoYXJlIiwiaW5mbyIsIndpbmRvdyIsIm9wZW4iLCJlbmNvZGVVUklDb21wb25lbnQiLCJDYXJkU2hhcmVBY3Rpb25zIiwiX2M1Iiwic2FuaXRpemVGaWxlbmFtZSIsInRvU3RyaW5nIiwidHJpbSIsInJlcGxhY2UiLCJFeHBvcnRIZWFkZXIiLCJsYWJlbCIsIl9jNiIsIlNFQVRfU1RZTEVTIiwiZmlsbGVkIiwidmFjYW50IiwicmVzZXJ2ZWQiLCJUaWNrZXQiLCJpc0ZpbGxlZCIsInNlYXRfdHlwZSIsImhhc0N1c3RvbWVyIiwiQm9vbGVhbiIsInZhcmlhbnQiLCJ0b29sdGlwQ29udGVudCIsInRpY2tldHMiLCJfYzciLCJTZWF0TWFwIiwiX3MiLCJjaHVua3MiLCJpIiwicHVzaCIsInJvd0luZGV4IiwiU3RyaW5nIiwiZnJvbUNoYXJDb2RlIiwiX2M4IiwiU2VhdExlZ2VuZCIsImhhc1Jlc2VydmVkIiwiX2M5IiwiRmlsbFJhdGVEb251dCIsInRvdGFsIiwiZGF0YSIsImNvbG9ycyIsImVudHJ5IiwiTWF0aCIsInJvdW5kIiwiX2MxMCIsIlRvcEhvbGRlcnNDaGFydCIsImN1c3RvbWVycyIsImNoYXJ0SGVpZ2h0IiwibWF4IiwibGVmdCIsInJpZ2h0IiwidG9wIiwiYm90dG9tIiwiZmlsbCIsIl9jMTEiLCJUb3BIb2xkZXJzTWluaSIsImhvbGRlciIsImNvdW50IiwiX2MxMiIsIlRpY2tldEFsbG9jYXRpb25UYWIiLCJ0aWNrZXRzSW5mbyIsIl9zMiIsInNlYXRNYXBSZWYiLCJmaWxsUmF0ZVJlZiIsImhvbGRlcnNSZWYiLCJvdmVyYWxsVGlja2V0cyIsImFsbEhvbGRlcnMiLCJieUN1c3RvbWVyIiwiTWFwIiwiZm9yRWFjaCIsInQiLCJleGlzdGluZyIsImdldCIsInNldCIsIkFycmF5IiwiZnJvbSIsInZhbHVlcyIsInNvcnQiLCJhIiwiYiIsInVuaXF1ZUN1c3RvbWVycyIsImlkcyIsIlNldCIsImZpbHRlciIsInNpemUiLCJzb21lIiwiZ3JvdXAiLCJzYWZlR3JvdXBOYW1lIiwiX2MxMyIsIkdyb3VwUmVwb3J0IiwiX3MzIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwic2VsZWN0ZWRHcm91cElkIiwic2V0U2VsZWN0ZWRHcm91cElkIiwicmVwb3J0Um93cyIsInNldFJlcG9ydFJvd3MiLCJzZXRUaWNrZXRzSW5mbyIsImF1Y3Rpb25Sb3dzIiwic2V0QXVjdGlvblJvd3MiLCJzZXRTZWFyY2hUZXh0IiwiaXNHcm91cHNMb2FkaW5nIiwic2V0SXNHcm91cHNMb2FkaW5nIiwiaXNSZXBvcnRMb2FkaW5nIiwic2V0SXNSZXBvcnRMb2FkaW5nIiwiaXNUaWNrZXRzTG9hZGluZyIsInNldElzVGlja2V0c0xvYWRpbmciLCJpc0F1Y3Rpb25Mb2FkaW5nIiwic2V0SXNBdWN0aW9uTG9hZGluZyIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImxhdGVzdFJlcXVlc3RJZCIsImZldGNoZWRBdWN0aW9uR3JvdXBSZWYiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidGFyZ2V0IiwiZmV0Y2hHcm91cHMiLCJyZXNwb25zZSIsInJlcXVlc3RJZCIsImZldGNoR3JvdXBSZXBvcnQiLCJwYXJhbXMiLCJncm91cF9pZCIsImZldGNoVGlja2V0QWxsb2NhdGlvbiIsImNhbmNlbGxlZCIsImZldGNoQXVjdGlvbkRldGFpbHMiLCJwYXlsb2FkIiwiaXNBcnJheSIsInJlZHVjZSIsInRvdGFscyIsInRvdGFsX3BheWFibGUiLCJ0b3RhbF9pbnZlc3RtZW50IiwidG90YWxfYmFsYW5jZSIsInBob25lTnVtYmVyIiwiY3VzdG9tZXJfc3RhdHVzIiwibmV4dEF1Y3Rpb25EYXRlIiwibmV4dF9hdWN0aW9uX2RhdGUiLCJ0YWJJdGVtcyIsImNoaWxkcmVuIiwiaGVpZ2h0Iiwid2lkdGgiLCJtYXhXaWR0aCIsInVuZGVmaW5lZCIsImlucHV0Iiwib3B0aW9uIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsIl9pZCIsIl9jMTQiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR3JvdXBSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbywgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgVGFicywgQ2FyZCwgRGVzY3JpcHRpb25zLCBUYWcsIFNrZWxldG9uLCBFbXB0eSwgU3RhdGlzdGljLCBUb29sdGlwLCBCYWRnZSwgQnV0dG9uLCBTcGFjZSwgbWVzc2FnZSB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5pbXBvcnQgeyBSaVdoYXRzYXBwTGluZSB9IGZyb20gXCJyZWFjdC1pY29ucy9yaVwiO1xyXG5pbXBvcnQgeyBGaURvd25sb2FkIH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbmltcG9ydCBodG1sMmNhbnZhcyBmcm9tIFwiaHRtbDJjYW52YXNcIjtcclxuaW1wb3J0IHtcclxuICBQaWVDaGFydCxcclxuICBQaWUsXHJcbiAgQ2VsbCxcclxuICBUb29sdGlwIGFzIFJlY2hhcnRUb29sdGlwLFxyXG4gIFJlc3BvbnNpdmVDb250YWluZXIsXHJcbiAgQmFyQ2hhcnQsXHJcbiAgQmFyLFxyXG4gIFhBeGlzLFxyXG4gIFlBeGlzLFxyXG4gIENhcnRlc2lhbkdyaWQsXHJcbiAgTGVnZW5kLFxyXG59IGZyb20gXCJyZWNoYXJ0c1wiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiO1xyXG5cclxuY29uc3QgUkVQT1JUX0NPTFVNTlMgPSBbXHJcbiAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgeyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSURcIiB9LFxyXG4gIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gIHsga2V5OiBcInBob25lTnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgeyBrZXk6IFwiYW1vdW50VG9CZVBhaWRcIiwgaGVhZGVyOiBcIkFtb3VudCB0byBiZSBQYWlkXCIgfSxcclxuICB7IGtleTogXCJhbW91bnRQYWlkXCIsIGhlYWRlcjogXCJBbW91bnQgUGFpZFwiIH0sXHJcbiAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgeyBrZXk6IFwibmV4dEF1Y3Rpb25EYXRlXCIsIGhlYWRlcjogXCJOZXh0IEF1Y3Rpb24gRGF0ZVwiIH0sXHJcbl07XHJcblxyXG5jb25zdCBTVEFUVVNfQ09MT1JTID0ge1xyXG4gIEFjdGl2ZTogXCJncmVlblwiLFxyXG4gIENsb3NlZDogXCJkZWZhdWx0XCIsXHJcbiAgRGVmYXVsdGVkOiBcInJlZFwiLFxyXG4gIFByaXplZDogXCJnb2xkXCIsXHJcbn07XHJcblxyXG5jb25zdCBBVUNUSU9OX0NPTFVNTlMgPSBbXHJcbiAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgeyBrZXk6IFwiYXVjdGlvbkNvZGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gQ29kZVwiIH0sXHJcbiAgeyBrZXk6IFwiYXVjdGlvbkRhdGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gRGF0ZVwiIH0sXHJcbiAgeyBrZXk6IFwibmV4dERhdGVcIiwgaGVhZGVyOiBcIk5leHQgRGF0ZVwiIH0sXHJcbiAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgeyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSURcIiB9LFxyXG4gIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICB7IGtleTogXCJiaWRBbW91bnRcIiwgaGVhZGVyOiBcIkJpZCBBbW91bnRcIiB9LFxyXG4gIHsga2V5OiBcIndpbkFtb3VudFwiLCBoZWFkZXI6IFwiV2luIEFtb3VudFwiIH0sXHJcbiAgeyBrZXk6IFwiYXVjdGlvblR5cGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gVHlwZVwiIH0sXHJcbiAgeyBrZXk6IFwicHJpemVkXCIsIGhlYWRlcjogXCJQcml6ZWRcIiB9LFxyXG5cclxuXTtcclxuXHJcbmNvbnN0IEFVQ1RJT05fU1RBVFVTX0NPTE9SUyA9IHtcclxuICBQZW5kaW5nOiBcIm9yYW5nZVwiLFxyXG4gIENvbXBsZXRlZDogXCJncmVlblwiLFxyXG4gIENhbmNlbGxlZDogXCJyZWRcIixcclxufTtcclxuXHJcbmNvbnN0IFNFQVRfUk9XX1NJWkUgPSAxMDtcclxuXHJcbmNvbnN0IGZvcm1hdEdyb3VwVHlwZSA9IChncm91cFR5cGUpID0+XHJcbiAgZ3JvdXBUeXBlID8gYCR7Z3JvdXBUeXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfSR7Z3JvdXBUeXBlLnNsaWNlKDEpfSBBdWN0aW9uYCA6IFwiLVwiO1xyXG5cclxuY29uc3QgZm9ybWF0Q3VycmVuY3kgPSAoYW1vdW50KSA9PiBg4oK5JHtOdW1iZXIoYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YDtcclxuXHJcbmNvbnN0IFN1bW1hcnlTdGF0ID0gKHsgdGl0bGUsIGFtb3VudCwgdmFsdWVDbGFzc05hbWUgfSkgPT4gKFxyXG4gIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItZ3JheS0xMDBcIiBib2R5U3R5bGU9e3sgcGFkZGluZzogXCIyMHB4IDI0cHhcIiB9fT5cclxuICAgIDxTdGF0aXN0aWNcclxuICAgICAgdGl0bGU9ezxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj57dGl0bGV9PC9zcGFuPn1cclxuICAgICAgdmFsdWU9e2Ftb3VudH1cclxuICAgICAgZm9ybWF0dGVyPXsodmFsdWUpID0+IGZvcm1hdEN1cnJlbmN5KHZhbHVlKX1cclxuICAgICAgdmFsdWVTdHlsZT17eyBmb250U2l6ZTogMjYsIGZvbnRXZWlnaHQ6IDcwMCB9fVxyXG4gICAgICBjbGFzc05hbWU9e3ZhbHVlQ2xhc3NOYW1lfVxyXG4gICAgLz5cclxuICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMCBmb250LW1vbm8gbXQtMVwiPntudW1iZXJUb0luZGlhbldvcmRzKGFtb3VudCl9PC9wPlxyXG4gIDwvQ2FyZD5cclxuKTtcclxuXHJcbmNvbnN0IEdyb3VwRGV0YWlsc1RhYiA9ICh7IGdyb3VwSW5mbywgbG9hZGluZyB9KSA9PiB7XHJcbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8U2tlbGV0b24gYWN0aXZlIHBhcmFncmFwaD17eyByb3dzOiA0IH19IGNsYXNzTmFtZT1cIm10LTZcIiAvPjtcclxuICBpZiAoIWdyb3VwSW5mbykgcmV0dXJuIDxFbXB0eSBkZXNjcmlwdGlvbj1cIk5vIGdyb3VwIGRhdGEgYXZhaWxhYmxlXCIgY2xhc3NOYW1lPVwibXQtMTZcIiAvPjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItZ3JheS0xMDAgbXQtMlwiPlxyXG4gICAgICA8RGVzY3JpcHRpb25zXHJcbiAgICAgICAgdGl0bGU9ezxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPntncm91cEluZm8uZ3JvdXBfbmFtZX08L3NwYW4+fVxyXG4gICAgICAgIGNvbHVtbj17eyB4czogMSwgc206IDIsIGxnOiAzIH19XHJcbiAgICAgICAgYm9yZGVyZWRcclxuICAgICAgICBzaXplPVwibWlkZGxlXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxEZXNjcmlwdGlvbnMuSXRlbSBsYWJlbD1cIkdyb3VwIFR5cGVcIj5cclxuICAgICAgICAgIDxUYWcgY29sb3I9XCJwdXJwbGVcIj57Zm9ybWF0R3JvdXBUeXBlKGdyb3VwSW5mby5ncm91cF90eXBlKX08L1RhZz5cclxuICAgICAgICA8L0Rlc2NyaXB0aW9ucy5JdGVtPlxyXG4gICAgICAgIDxEZXNjcmlwdGlvbnMuSXRlbSBsYWJlbD1cIkdyb3VwIFZhbHVlXCI+XHJcbiAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koZ3JvdXBJbmZvLmdyb3VwX3ZhbHVlKX1cclxuICAgICAgICA8L0Rlc2NyaXB0aW9ucy5JdGVtPlxyXG4gICAgICAgIDxEZXNjcmlwdGlvbnMuSXRlbSBsYWJlbD1cIkluc3RhbGxtZW50IEFtb3VudFwiPlxyXG4gICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KGdyb3VwSW5mby5ncm91cF9pbnN0YWxsKX1cclxuICAgICAgICA8L0Rlc2NyaXB0aW9ucy5JdGVtPlxyXG4gICAgICAgIDxEZXNjcmlwdGlvbnMuSXRlbSBsYWJlbD1cIk1vbnRobHkgSW5zdGFsbG1lbnRcIj5cclxuICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShncm91cEluZm8ubW9udGhseV9pbnN0YWxsbWVudCl9XHJcbiAgICAgICAgPC9EZXNjcmlwdGlvbnMuSXRlbT5cclxuICAgICAgICA8RGVzY3JpcHRpb25zLkl0ZW0gbGFiZWw9XCJSZWdpc3RyYXRpb24gRmVlXCI+XHJcbiAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koZ3JvdXBJbmZvLnJlZ19mZWUpfVxyXG4gICAgICAgIDwvRGVzY3JpcHRpb25zLkl0ZW0+XHJcbiAgICAgICAgPERlc2NyaXB0aW9ucy5JdGVtIGxhYmVsPVwiUmVsYXRpb25zaGlwIE1hbmFnZXJcIj5cclxuICAgICAgICAgIHtncm91cEluZm8ucmVsYXRpb25zaGlwX21hbmFnZXI/Lm5hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICB7Z3JvdXBJbmZvLnJlbGF0aW9uc2hpcF9tYW5hZ2VyPy5waG9uZV9udW1iZXIgJiYgKFxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIG1sLTJcIj5cclxuICAgICAgICAgICAgICAoe2dyb3VwSW5mby5yZWxhdGlvbnNoaXBfbWFuYWdlci5waG9uZV9udW1iZXJ9KVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvRGVzY3JpcHRpb25zLkl0ZW0+XHJcbiAgICAgIDwvRGVzY3JpcHRpb25zPlxyXG4gICAgPC9DYXJkPlxyXG4gICk7XHJcbn07XHJcblxyXG5jb25zdCBDdXN0b21lck92ZXJ2aWV3VGFiID0gKHsgdGFibGVEYXRhLCBzdW1tYXJ5LCBncm91cEluZm8sIGxvYWRpbmcsIHNlYXJjaFRleHQgfSkgPT4ge1xyXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPFNrZWxldG9uIGFjdGl2ZSBwYXJhZ3JhcGg9e3sgcm93czogNiB9fSBjbGFzc05hbWU9XCJtdC02XCIgLz47XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTJcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IG1iLTZcIj5cclxuICAgICAgICA8U3VtbWFyeVN0YXQgdGl0bGU9XCJQYWlkIEFtb3VudFwiIGFtb3VudD17c3VtbWFyeS5hbW91bnRQYWlkfSB2YWx1ZUNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICA8U3VtbWFyeVN0YXQgdGl0bGU9XCJBbW91bnQgdG8gYmUgUGFpZFwiIGFtb3VudD17c3VtbWFyeS5hbW91bnRUb0JlUGFpZH0gLz5cclxuICAgICAgICA8U3VtbWFyeVN0YXQgdGl0bGU9XCJCYWxhbmNlIEFtb3VudFwiIGFtb3VudD17c3VtbWFyeS5iYWxhbmNlfSB2YWx1ZUNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiIC8+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge3RhYmxlRGF0YS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItZ3JheS0xMDBcIiBib2R5U3R5bGU9e3sgcGFkZGluZzogMCB9fT5cclxuICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKHRhYmxlRGF0YSwgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgIGNvbHVtbnM9e1JFUE9SVF9DT0xVTU5TfVxyXG4gICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJHcm91cCBSZXBvcnRcIlxyXG4gICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcIkdyb3VwIE5hbWVcIiwgXCJHcm91cCBUeXBlXCIsIFwiR3JvdXAgVmFsdWVcIiwgXCJBbW91bnQgdG8gYmUgUGFpZFwiLCBcIlBhaWQgQW1vdW50XCIsIFwiQmFsYW5jZSBBbW91bnRcIl19XHJcbiAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgZ3JvdXBJbmZvPy5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICAgIGZvcm1hdEdyb3VwVHlwZShncm91cEluZm8/Lmdyb3VwX3R5cGUpLFxyXG4gICAgICAgICAgICAgIGdyb3VwSW5mbz8uZ3JvdXBfdmFsdWUsXHJcbiAgICAgICAgICAgICAgZm9ybWF0Q3VycmVuY3koc3VtbWFyeS5hbW91bnRUb0JlUGFpZCksXHJcbiAgICAgICAgICAgICAgZm9ybWF0Q3VycmVuY3koc3VtbWFyeS5hbW91bnRQYWlkKSxcclxuICAgICAgICAgICAgICBmb3JtYXRDdXJyZW5jeShzdW1tYXJ5LmJhbGFuY2UpLFxyXG4gICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgR3JvdXBSZXBvcnQtJHtncm91cEluZm8/Lmdyb3VwX25hbWUgfHwgXCJncm91cFwifS5jc3ZgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPEVtcHR5IGRlc2NyaXB0aW9uPVwiTm8gY3VzdG9tZXIgcmVjb3JkcyBmb3VuZCBmb3IgdGhpcyBncm91cFwiIGNsYXNzTmFtZT1cIm10LTE2XCIgLz5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gQXVjdGlvbiBEZXRhaWxzIHRhYiDigJQgcGxhaW4gdGFibGUgb2YgdGhlIGdyb3VwJ3MgYXVjdGlvbiBoaXN0b3J5LCBmZXRjaGVkXHJcbi8vIG9uIGRlbWFuZCAob25seSB3aGVuIHRoaXMgdGFiIGlzIG9wZW5lZCwgbm90IHVwZnJvbnQgd2l0aCB0aGUgb3RoZXJzKS5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5jb25zdCBBdWN0aW9uRGV0YWlsc1RhYiA9ICh7IHJvd3MsIGxvYWRpbmcsIHNlYXJjaFRleHQsIGdyb3VwTmFtZSB9KSA9PiB7XHJcbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8U2tlbGV0b24gYWN0aXZlIHBhcmFncmFwaD17eyByb3dzOiA4IH19IGNsYXNzTmFtZT1cIm10LTZcIiAvPjtcclxuXHJcbiAgY29uc3QgdGFibGVEYXRhID0gcm93cy5tYXAoKHJvdywgaW5kZXgpID0+ICh7XHJcbiAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgYXVjdGlvbkNvZGU6IHJvdy5hdWN0aW9uX2NvZGUgfHwgXCItXCIsXHJcbiAgICB0aWNrZXQ6IHJvdy50aWNrZXQgfHwgXCItXCIsXHJcbiAgICBjdXN0b21lcklkOiByb3cudXNlcl9pZD8uY3VzdG9tZXJfaWQgfHwgXCItXCIsXHJcbiAgICBuYW1lOiByb3cudXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgYXVjdGlvblR5cGU6IHJvdy5hdWN0aW9uX3R5cGVcclxuICAgICAgPyBgJHtyb3cuYXVjdGlvbl90eXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfSR7cm93LmF1Y3Rpb25fdHlwZS5zbGljZSgxKX1gXHJcbiAgICAgIDogXCItXCIsXHJcbiAgICBhdWN0aW9uRGF0ZTogcm93LmF1Y3Rpb25fZGF0ZSB8fCBcIi1cIixcclxuICAgIG5leHREYXRlOiByb3cubmV4dF9kYXRlIHx8IFwiLVwiLFxyXG4gICAgYmlkQW1vdW50OiAocGFyc2VJbnQocm93LmRpdmlkZW50KSB8fCAwKSArIChwYXJzZUludChyb3cuY29tbWlzc2lvbikgfHwgMCkgfHwgXCItXCIsXHJcbiAgICB3aW5BbW91bnQ6cm93Lndpbl9hbW91bnQgPyAgZm9ybWF0Q3VycmVuY3kocm93Lndpbl9hbW91bnQgfHwgMCkgOiBcIi1cIixcclxuXHJcbiAgXHJcbiAgICBzdGF0dXM6IDxUYWcgY29sb3I9e0FVQ1RJT05fU1RBVFVTX0NPTE9SU1tyb3cuc3RhdHVzXSB8fCBcImRlZmF1bHRcIn0+e3Jvdy5zdGF0dXMgfHwgXCItXCJ9PC9UYWc+LFxyXG4gICAgcHJpemVkOiAoXHJcbiAgICAgIDxUYWcgY29sb3I9e3Jvdy5pc1ByaXplZCA9PT0gXCJ0cnVlXCIgPyBcImdvbGRcIiA6IFwiZGVmYXVsdFwifT5cclxuICAgICAgICB7cm93LmlzUHJpemVkID09PSBcInRydWVcIiA/IFwiUHJpemVkXCIgOiBcIk5vdCBQcml6ZWRcIn1cclxuICAgICAgPC9UYWc+XHJcbiAgICApLFxyXG4gIH0pKTtcclxuXHJcbiAgaWYgKHRhYmxlRGF0YS5sZW5ndGggPT09IDApIHtcclxuICAgIHJldHVybiA8RW1wdHkgZGVzY3JpcHRpb249XCJObyBhdWN0aW9uIHJlY29yZHMgZm91bmQgZm9yIHRoaXMgZ3JvdXBcIiBjbGFzc05hbWU9XCJtdC0xNlwiIC8+O1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItZ3JheS0xMDAgbXQtMlwiIGJvZHlTdHlsZT17eyBwYWRkaW5nOiAwIH19PlxyXG4gICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKHRhYmxlRGF0YSwgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgY29sdW1ucz17QVVDVElPTl9DT0xVTU5TfVxyXG4gICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkF1Y3Rpb24gRGV0YWlsc1wiXHJcbiAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEF1Y3Rpb25EZXRhaWxzLSR7Z3JvdXBOYW1lIHx8IFwiZ3JvdXBcIn0uY3N2YH1cclxuICAgICAgLz5cclxuICAgIDwvQ2FyZD5cclxuICApO1xyXG59O1xyXG4vLyBwbHVzIGEgZmlsbC1yYXRlIGRvbnV0IGFuZCBhIFwidG9wIHRpY2tldCBob2xkZXJzXCIgYmFyIGNoYXJ0LlxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyBTaGFyZSAvIGRvd25sb2FkIGhlbHBlcnMg4oCUIHR1cm4gYW55IGNhcmQgaW50byBhIFBORywgdGhlbiBlaXRoZXIgaGFuZCBpdCB0b1xyXG4vLyB0aGUgbmF0aXZlIHNoYXJlIHNoZWV0IChXaGF0c0FwcCBzaG93cyB1cCB0aGVyZSBvbiBtb2JpbGUpIG9yIGRvd25sb2FkIGl0LlxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmNvbnN0IGNhcHR1cmVOb2RlID0gYXN5bmMgKG5vZGUpID0+IHtcclxuICAvLyBUZW1wb3JhcmlseSBsaWZ0IGhlaWdodC9vdmVyZmxvdyBsaW1pdHMgc28gc2Nyb2xsLWNsaXBwZWQgY29udGVudFxyXG4gIC8vIChlLmcuIHRoZSB0aWNrZXQgaG9sZGVycyBsaXN0KSBpcyBjYXB0dXJlZCBpbiBmdWxsLCBhbmQgYWRkIGEgdG91Y2ggb2ZcclxuICAvLyB0b3AgcGFkZGluZyBzbyB0aGUgaGVhZGVyIHRleHQgaXNuJ3QgZmx1c2ggYWdhaW5zdCB0aGUgY2FudmFzIGVkZ2Ug4oCUXHJcbiAgLy8gaHRtbDJjYW52YXMgY2FuIGNsaXAgYSBzbGl2ZXIgb2ZmIGNvbnRlbnQgc2l0dGluZyByaWdodCBhdCByb3cgMC5cclxuICBjb25zdCBwcmV2TWF4SGVpZ2h0ID0gbm9kZS5zdHlsZS5tYXhIZWlnaHQ7XHJcbiAgY29uc3QgcHJldk92ZXJmbG93ID0gbm9kZS5zdHlsZS5vdmVyZmxvdztcclxuICBjb25zdCBwcmV2UGFkZGluZ1RvcCA9IG5vZGUuc3R5bGUucGFkZGluZ1RvcDtcclxuICBub2RlLnN0eWxlLm1heEhlaWdodCA9IFwibm9uZVwiO1xyXG4gIG5vZGUuc3R5bGUub3ZlcmZsb3cgPSBcInZpc2libGVcIjtcclxuICBub2RlLnN0eWxlLnBhZGRpbmdUb3AgPSBcIjEycHhcIjtcclxuICB0cnkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGh0bWwyY2FudmFzKG5vZGUsIHsgYmFja2dyb3VuZENvbG9yOiBcIiNmZmZmZmZcIiwgc2NhbGU6IDIsIHVzZUNPUlM6IHRydWUgfSk7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIG5vZGUuc3R5bGUubWF4SGVpZ2h0ID0gcHJldk1heEhlaWdodDtcclxuICAgIG5vZGUuc3R5bGUub3ZlcmZsb3cgPSBwcmV2T3ZlcmZsb3c7XHJcbiAgICBub2RlLnN0eWxlLnBhZGRpbmdUb3AgPSBwcmV2UGFkZGluZ1RvcDtcclxuICB9XHJcbn07XHJcblxyXG5jb25zdCBkb3dubG9hZEJsb2IgPSAoYmxvYiwgZmlsZW5hbWUpID0+IHtcclxuICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYVwiKTtcclxuICBsaW5rLmhyZWYgPSB1cmw7XHJcbiAgbGluay5kb3dubG9hZCA9IGZpbGVuYW1lO1xyXG4gIGxpbmsuY2xpY2soKTtcclxuICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XHJcbn07XHJcblxyXG5jb25zdCBleHBvcnRDYXJkID0gYXN5bmMgKHRhcmdldFJlZiwgZmlsZW5hbWUsIG1vZGUpID0+IHtcclxuICBpZiAoIXRhcmdldFJlZi5jdXJyZW50KSByZXR1cm47XHJcbiAgbGV0IGNhbnZhcztcclxuICB0cnkge1xyXG4gICAgY2FudmFzID0gYXdhaXQgY2FwdHVyZU5vZGUodGFyZ2V0UmVmLmN1cnJlbnQpO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZ2VuZXJhdGluZyBpbWFnZTpcIiwgZXJyb3IpO1xyXG4gICAgbWVzc2FnZS5lcnJvcihcIkNvdWxkbid0IGdlbmVyYXRlIHRoZSBpbWFnZS4gUGxlYXNlIHRyeSBhZ2Fpbi5cIik7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICBjYW52YXMudG9CbG9iKGFzeW5jIChibG9iKSA9PiB7XHJcbiAgICBpZiAoIWJsb2IpIHJldHVybjtcclxuXHJcbiAgICBpZiAobW9kZSA9PT0gXCJkb3dubG9hZFwiKSB7XHJcbiAgICAgIGRvd25sb2FkQmxvYihibG9iLCBmaWxlbmFtZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBtb2RlID09PSBcIndoYXRzYXBwXCI6IHByZWZlciB0aGUgbmF0aXZlIHNoYXJlIHNoZWV0IChXaGF0c0FwcCBzaG93cyB1cFxyXG4gICAgLy8gdGhlcmUgb24gbW9iaWxlKTsgZmFsbCBiYWNrIHRvIGEgZG93bmxvYWQgKyBXaGF0c0FwcCBXZWIgY29tcG9zZS5cclxuICAgIGNvbnN0IGZpbGUgPSBuZXcgRmlsZShbYmxvYl0sIGZpbGVuYW1lLCB7IHR5cGU6IFwiaW1hZ2UvcG5nXCIgfSk7XHJcbiAgICBpZiAobmF2aWdhdG9yLmNhblNoYXJlICYmIG5hdmlnYXRvci5jYW5TaGFyZSh7IGZpbGVzOiBbZmlsZV0gfSkpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBuYXZpZ2F0b3Iuc2hhcmUoeyBmaWxlczogW2ZpbGVdLCB0aXRsZTogZmlsZW5hbWUgfSk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGlmIChlcnJvcj8ubmFtZSA9PT0gXCJBYm9ydEVycm9yXCIpIHJldHVybjsgLy8gdXNlciBjYW5jZWxsZWQgdGhlIHNoYXJlIHNoZWV0XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBkb3dubG9hZEJsb2IoYmxvYiwgZmlsZW5hbWUpO1xyXG4gICAgbWVzc2FnZS5pbmZvKFwiSW1hZ2UgZG93bmxvYWRlZCDigJQgYXR0YWNoIGl0IGluIHRoZSBXaGF0c0FwcCBjaGF0IHRoYXQganVzdCBvcGVuZWQuXCIpO1xyXG4gICAgd2luZG93Lm9wZW4oXHJcbiAgICAgIGBodHRwczovL3dhLm1lLz90ZXh0PSR7ZW5jb2RlVVJJQ29tcG9uZW50KFwiU2hhcmluZyBcIiArIGZpbGVuYW1lKX1gLFxyXG4gICAgICBcIl9ibGFua1wiLFxyXG4gICAgICBcIm5vb3BlbmVyLG5vcmVmZXJyZXJcIlxyXG4gICAgKTtcclxuICB9LCBcImltYWdlL3BuZ1wiKTtcclxufTtcclxuXHJcbmNvbnN0IENhcmRTaGFyZUFjdGlvbnMgPSAoeyB0YXJnZXRSZWYsIGZpbGVuYW1lIH0pID0+IChcclxuICA8U3BhY2Ugc2l6ZT17Mn0+XHJcbiAgICA8VG9vbHRpcCB0aXRsZT1cIkRvd25sb2FkIGFzIGltYWdlXCI+XHJcbiAgICAgIDxCdXR0b25cclxuICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBpY29uPXs8RmlEb3dubG9hZCAvPn1cclxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBleHBvcnRDYXJkKHRhcmdldFJlZiwgZmlsZW5hbWUsIFwiZG93bmxvYWRcIil9XHJcbiAgICAgIC8+XHJcbiAgICA8L1Rvb2x0aXA+XHJcbiAgICA8VG9vbHRpcCB0aXRsZT1cIlNoYXJlIG9uIFdoYXRzQXBwXCI+XHJcbiAgICAgIDxCdXR0b25cclxuICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwXCJcclxuICAgICAgICBpY29uPXs8UmlXaGF0c2FwcExpbmUgLz59XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZXhwb3J0Q2FyZCh0YXJnZXRSZWYsIGZpbGVuYW1lLCBcIndoYXRzYXBwXCIpfVxyXG4gICAgICAvPlxyXG4gICAgPC9Ub29sdGlwPlxyXG4gIDwvU3BhY2U+XHJcbik7XHJcblxyXG5jb25zdCBzYW5pdGl6ZUZpbGVuYW1lID0gKHZhbHVlKSA9PlxyXG4gICh2YWx1ZSB8fCBcImdyb3VwXCIpXHJcbiAgICAudG9TdHJpbmcoKVxyXG4gICAgLnRyaW0oKVxyXG4gICAgLnJlcGxhY2UoL1teYS16QS1aMC05LV9dKy9nLCBcIi1cIilcclxuICAgIC5yZXBsYWNlKC8tKy9nLCBcIi1cIilcclxuICAgIC5yZXBsYWNlKC9eLXwtJC9nLCBcIlwiKTtcclxuXHJcbi8vIFByaW50ZWQgaW5zaWRlIGV2ZXJ5IGV4cG9ydGVkIGNhcmQgc28gdGhlIGdyb3VwIHN0YXlzIGlkZW50aWZpYWJsZSBldmVuXHJcbi8vIGFmdGVyIHRoZSBpbWFnZSBsZWF2ZXMgdGhlIGFwcCAoZS5nLiBvbmNlIHNoYXJlZCBvbiBXaGF0c0FwcCwgd2hlcmUgdGhlXHJcbi8vIGZpbGVuYW1lIGlzIHN0cmlwcGVkIGFuZCBvbmx5IHRoZSBwaWN0dXJlIGl0c2VsZiBpcyB2aXNpYmxlKS5cclxuY29uc3QgRXhwb3J0SGVhZGVyID0gKHsgZ3JvdXBOYW1lLCBsYWJlbCB9KSA9PiAoXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMyBwYi0yIHB0LTEgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCB0cnVuY2F0ZSBsZWFkaW5nLTZcIj57Z3JvdXBOYW1lfTwvc3Bhbj5cclxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgc2hyaW5rLTAgbWwtMiBsZWFkaW5nLTZcIj57bGFiZWx9PC9zcGFuPlxyXG4gIDwvZGl2PlxyXG4pO1xyXG5cclxuY29uc3QgU0VBVF9TVFlMRVMgPSB7XHJcbiAgZmlsbGVkOiBcImJnLWluZGlnby02MDAgYm9yZGVyLWluZGlnby02MDAgdGV4dC13aGl0ZSBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTUwMCBob3ZlcjpyaW5nLTIgaG92ZXI6cmluZy1pbmRpZ28tMzAwXCIsXHJcbiAgdmFjYW50OiBcImJnLXdoaXRlIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS0zMDAgaG92ZXI6Ym9yZGVyLWVtZXJhbGQtNDAwIGhvdmVyOnRleHQtZW1lcmFsZC01MDAgaG92ZXI6cmluZy0yIGhvdmVyOnJpbmctZW1lcmFsZC0yMDBcIixcclxuICByZXNlcnZlZDogXCJiZy1hbWJlci01MCBib3JkZXItYW1iZXItMzAwIHRleHQtYW1iZXItNjAwIGhvdmVyOmJnLWFtYmVyLTEwMCBob3ZlcjpyaW5nLTIgaG92ZXI6cmluZy1hbWJlci0yMDBcIixcclxufTtcclxuXHJcbmNvbnN0IFRpY2tldCA9ICh7IHRpY2tldCB9KSA9PiB7XHJcbiAgY29uc3QgaXNGaWxsZWQgPSB0aWNrZXQuc2VhdF90eXBlID09PSBcIkZpbGxlZFwiO1xyXG4gIGNvbnN0IGhhc0N1c3RvbWVyID0gQm9vbGVhbih0aWNrZXQudXNlcl9pZCk7XHJcbiAgY29uc3QgdmFyaWFudCA9ICFpc0ZpbGxlZCA/IFwidmFjYW50XCIgOiBoYXNDdXN0b21lciA/IFwiZmlsbGVkXCIgOiBcInJlc2VydmVkXCI7XHJcblxyXG4gIGNvbnN0IHRvb2x0aXBDb250ZW50ID0gIWlzRmlsbGVkID8gKFxyXG4gICAgPHNwYW4+VGlja2V0IHt0aWNrZXQudGlja2V0c30gwrcgQXZhaWxhYmxlPC9zcGFuPlxyXG4gICkgOiBoYXNDdXN0b21lciA/IChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibGVhZGluZy01XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPnt0aWNrZXQudXNlcl9pZC5mdWxsX25hbWV9PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBvcGFjaXR5LTgwXCI+e3RpY2tldC51c2VyX2lkLmN1c3RvbWVyX2lkfTwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgb3BhY2l0eS04MFwiPnt0aWNrZXQudXNlcl9pZC5waG9uZV9udW1iZXJ9PC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApIDogKFxyXG4gICAgPHNwYW4+VGlja2V0IHt0aWNrZXQudGlja2V0c30gwrcgTWFwcGVkIChubyBjdXN0b21lciBsaW5rZWQpPC9zcGFuPlxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8VG9vbHRpcCB0aXRsZT17dG9vbHRpcENvbnRlbnR9IHBsYWNlbWVudD1cInRvcFwiIG1vdXNlRW50ZXJEZWxheT17MC4wNX0gbW91c2VMZWF2ZURlbGF5PXswLjA1fT5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIGNsYXNzTmFtZT17YGFzcGVjdC1zcXVhcmUgdy1mdWxsIG1pbi13LVsyOHB4XSByb3VuZGVkLW1kIGJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclxyXG4gICAgICAgICAgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCBjdXJzb3ItZGVmYXVsdCBzZWxlY3Qtbm9uZSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcclxuICAgICAgICAgIHJpbmctb2Zmc2V0LTEgJHtTRUFUX1NUWUxFU1t2YXJpYW50XX1gfVxyXG4gICAgICA+XHJcbiAgICAgICAge3RpY2tldC50aWNrZXRzfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvVG9vbHRpcD5cclxuICApO1xyXG59O1xyXG5cclxuY29uc3QgU2VhdE1hcCA9ICh7IHRpY2tldHMgfSkgPT4ge1xyXG4gIGNvbnN0IHJvd3MgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGNodW5rcyA9IFtdO1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aWNrZXRzLmxlbmd0aDsgaSArPSBTRUFUX1JPV19TSVpFKSB7XHJcbiAgICAgIGNodW5rcy5wdXNoKHRpY2tldHMuc2xpY2UoaSwgaSArIFNFQVRfUk9XX1NJWkUpKTtcclxuICAgIH1cclxuICAgIHJldHVybiBjaHVua3M7XHJcbiAgfSwgW3RpY2tldHNdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIG92ZXJmbG93LXktdmlzaWJsZSBwLTFcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bNTIwcHhdXCI+XHJcbiAgICAgICAgey8qIFwiU2NyZWVuXCIgc3R5bGUgaGVhZGVyLCBlY2hvaW5nIGEgYm9va2luZy1oYWxsIHNlYXQgY2hhcnQgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1iLTYgdy00LzUgaC0yIHJvdW5kZWQtZnVsbCBiZy1ncmFkaWVudC10by1yIGZyb20tdHJhbnNwYXJlbnQgdmlhLWdyYXktMzAwIHRvLXRyYW5zcGFyZW50XCIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cclxuICAgICAgICAgIHtyb3dzLm1hcCgocm93LCByb3dJbmRleCkgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2IGtleT17cm93SW5kZXh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAge1N0cmluZy5mcm9tQ2hhckNvZGUoNjUgKyByb3dJbmRleCl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMTAgZ2FwLTIgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICB7cm93Lm1hcCgodGlja2V0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxUaWNrZXQga2V5PXt0aWNrZXQudGlja2V0c30gdGlja2V0PXt0aWNrZXR9IC8+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuY29uc3QgU2VhdExlZ2VuZCA9ICh7IGhhc1Jlc2VydmVkIH0pID0+IChcclxuICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtNSBtdC02IHRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy00IGgtNCByb3VuZGVkIGJnLWluZGlnby02MDAgaW5saW5lLWJsb2NrXCIgLz4gTWFwcGVkXHJcbiAgICA8L3NwYW4+XHJcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTQgaC00IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMzAwIGlubGluZS1ibG9ja1wiIC8+IEF2YWlsYWJsZVxyXG4gICAgPC9zcGFuPlxyXG4gICAge2hhc1Jlc2VydmVkICYmIChcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTQgaC00IHJvdW5kZWQgYmctYW1iZXItNTAgYm9yZGVyIGJvcmRlci1hbWJlci0zMDAgaW5saW5lLWJsb2NrXCIgLz4gTWFwcGVkIMK3IHVubGlua2VkXHJcbiAgICAgIDwvc3Bhbj5cclxuICAgICl9XHJcbiAgPC9kaXY+XHJcbik7XHJcblxyXG5jb25zdCBGaWxsUmF0ZURvbnV0ID0gKHsgZmlsbGVkLCB2YWNhbnQgfSkgPT4ge1xyXG4gIGNvbnN0IHRvdGFsID0gZmlsbGVkICsgdmFjYW50IHx8IDE7XHJcbiAgY29uc3QgZGF0YSA9IFtcclxuICAgIHsgbmFtZTogXCJNYXBwZWRcIiwgdmFsdWU6IGZpbGxlZCB9LFxyXG4gICAgeyBuYW1lOiBcIkF2YWlsYWJsZVwiLCB2YWx1ZTogdmFjYW50IH0sXHJcbiAgXTtcclxuICBjb25zdCBjb2xvcnMgPSBbXCIjNGY0NmU1XCIsIFwiI2U1ZTdlYlwiXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC02NFwiPlxyXG4gICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+XHJcbiAgICAgICAgPFBpZUNoYXJ0PlxyXG4gICAgICAgICAgPFBpZVxyXG4gICAgICAgICAgICBkYXRhPXtkYXRhfVxyXG4gICAgICAgICAgICBkYXRhS2V5PVwidmFsdWVcIlxyXG4gICAgICAgICAgICBpbm5lclJhZGl1cz1cIjY4JVwiXHJcbiAgICAgICAgICAgIG91dGVyUmFkaXVzPVwiOTAlXCJcclxuICAgICAgICAgICAgc3RhcnRBbmdsZT17OTB9XHJcbiAgICAgICAgICAgIGVuZEFuZ2xlPXstMjcwfVxyXG4gICAgICAgICAgICBwYWRkaW5nQW5nbGU9ezJ9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtkYXRhLm1hcCgoZW50cnksIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgPENlbGwga2V5PXtlbnRyeS5uYW1lfSBmaWxsPXtjb2xvcnNbaW5kZXhdfSBzdHJva2U9XCJub25lXCIgLz5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L1BpZT5cclxuICAgICAgICAgIDxSZWNoYXJ0VG9vbHRpcCBmb3JtYXR0ZXI9eyh2YWx1ZSwgbmFtZSkgPT4gW2Ake3ZhbHVlfSBUaWNrZXRzYCwgbmFtZV19IC8+XHJcbiAgICAgICAgICA8TGVnZW5kIHZlcnRpY2FsQWxpZ249XCJib3R0b21cIiBoZWlnaHQ9ezI0fSBpY29uVHlwZT1cImNpcmNsZVwiIC8+XHJcbiAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZSAtdHJhbnNsYXRlLXktM1wiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e01hdGgucm91bmQoKGZpbGxlZCAvIHRvdGFsKSAqIDEwMCl9JTwvc3Bhbj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+RmlsbGVkPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5jb25zdCBUb3BIb2xkZXJzQ2hhcnQgPSAoeyBjdXN0b21lcnMgfSkgPT4ge1xyXG4gIGlmIChjdXN0b21lcnMubGVuZ3RoID09PSAwKSB7XHJcbiAgICByZXR1cm4gPEVtcHR5IGRlc2NyaXB0aW9uPVwiTm8gYm9va2luZ3MgeWV0XCIgY2xhc3NOYW1lPVwicHktMTBcIiAvPjtcclxuICB9XHJcbiAgY29uc3QgY2hhcnRIZWlnaHQgPSBNYXRoLm1heCgyODAsIGN1c3RvbWVycy5sZW5ndGggKiAzMCk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtWzUyMHB4XSBvdmVyZmxvdy15LWF1dG8gcHItMVwiPlxyXG4gICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9e2NoYXJ0SGVpZ2h0fT5cclxuICAgICAgICA8QmFyQ2hhcnQgZGF0YT17Y3VzdG9tZXJzfSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIG1hcmdpbj17eyBsZWZ0OiAxMiwgcmlnaHQ6IDI0LCB0b3A6IDQsIGJvdHRvbTogNCB9fT5cclxuICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIGhvcml6b250YWw9e2ZhbHNlfSBzdHJva2U9XCIjZjFmNWY5XCIgLz5cclxuICAgICAgICAgIDxYQXhpcyB0eXBlPVwibnVtYmVyXCIgYWxsb3dEZWNpbWFscz17ZmFsc2V9IHRpY2s9e3sgZm9udFNpemU6IDExLCBmaWxsOiBcIiM5NGEzYjhcIiB9fSAvPlxyXG4gICAgICAgICAgPFlBeGlzXHJcbiAgICAgICAgICAgIHR5cGU9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgIGRhdGFLZXk9XCJuYW1lXCJcclxuICAgICAgICAgICAgd2lkdGg9ezEzMH1cclxuICAgICAgICAgICAgdGljaz17eyBmb250U2l6ZTogMTEsIGZpbGw6IFwiIzQ3NTU2OVwiIH19XHJcbiAgICAgICAgICAgIGludGVydmFsPXswfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxSZWNoYXJ0VG9vbHRpcFxyXG4gICAgICAgICAgICBmb3JtYXR0ZXI9eyh2YWx1ZSkgPT4gW2Ake3ZhbHVlfSB0aWNrZXQke3ZhbHVlID4gMSA/IFwic1wiIDogXCJcIn1gLCBcIkhlbGRcIl19XHJcbiAgICAgICAgICAgIGN1cnNvcj17eyBmaWxsOiBcIiNmOGZhZmNcIiB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxCYXIgZGF0YUtleT1cImNvdW50XCIgZmlsbD1cIiM0ZjQ2ZTVcIiByYWRpdXM9e1swLCA2LCA2LCAwXX0gYmFyU2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgPC9CYXJDaGFydD5cclxuICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmNvbnN0IFRvcEhvbGRlcnNNaW5pID0gKHsgY3VzdG9tZXJzIH0pID0+IHtcclxuICBjb25zdCB0b3AgPSBjdXN0b21lcnMuc2xpY2UoMCwgNSk7XHJcbiAgaWYgKHRvcC5sZW5ndGggPT09IDApIHtcclxuICAgIHJldHVybiA8RW1wdHkgZGVzY3JpcHRpb249XCJObyBib29raW5ncyB5ZXRcIiBjbGFzc05hbWU9XCJweS02XCIgLz47XHJcbiAgfVxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cclxuICAgICAge3RvcC5tYXAoKGhvbGRlciwgaW5kZXgpID0+IChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBrZXk9e2hvbGRlci5uYW1lICsgaW5kZXh9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC1tZCBiZy1lbWVyYWxkLTUwIGJvcmRlciBib3JkZXItZW1lcmFsZC0xMDAgcHgtMyBweS0yXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtZW1lcmFsZC02MDAgdy00IHNocmluay0wXCI+e2luZGV4ICsgMX08L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1lbWVyYWxkLTcwMCB0cnVuY2F0ZVwiPntob2xkZXIubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZW1lcmFsZC02MDAgc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAge2hvbGRlci5jb3VudH0gdGlja2V0e2hvbGRlci5jb3VudCA+IDEgPyBcInNcIiA6IFwiXCJ9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkpfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmNvbnN0IFRpY2tldEFsbG9jYXRpb25UYWIgPSAoeyB0aWNrZXRzSW5mbywgbG9hZGluZyB9KSA9PiB7XHJcbiAgY29uc3Qgc2VhdE1hcFJlZiA9IHVzZVJlZihudWxsKTtcclxuICBjb25zdCBmaWxsUmF0ZVJlZiA9IHVzZVJlZihudWxsKTtcclxuICBjb25zdCBob2xkZXJzUmVmID0gdXNlUmVmKG51bGwpO1xyXG5cclxuICAvLyBIb29rcyBtdXN0IHJ1biB1bmNvbmRpdGlvbmFsbHkgb24gZXZlcnkgcmVuZGVyLCBzbyBjb21wdXRlIG9mZiBhIHNhZmVcclxuICAvLyBmYWxsYmFjayBoZXJlIHJhdGhlciB0aGFuIGVhcmx5LXJldHVybmluZyBiZWZvcmUgdGhlc2UgYXJlIGRlY2xhcmVkLlxyXG4gIGNvbnN0IHRpY2tldHMgPSB0aWNrZXRzSW5mbz8ub3ZlcmFsbFRpY2tldHMgfHwgW107XHJcblxyXG4gIGNvbnN0IGFsbEhvbGRlcnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGJ5Q3VzdG9tZXIgPSBuZXcgTWFwKCk7XHJcbiAgICB0aWNrZXRzLmZvckVhY2goKHQpID0+IHtcclxuICAgICAgaWYgKHQuc2VhdF90eXBlICE9PSBcIkZpbGxlZFwiIHx8ICF0LnVzZXJfaWQpIHJldHVybjtcclxuICAgICAgY29uc3Qga2V5ID0gdC51c2VyX2lkLmN1c3RvbWVyX2lkO1xyXG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ5Q3VzdG9tZXIuZ2V0KGtleSk7XHJcbiAgICAgIGlmIChleGlzdGluZykge1xyXG4gICAgICAgIGV4aXN0aW5nLmNvdW50ICs9IDE7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYnlDdXN0b21lci5zZXQoa2V5LCB7IG5hbWU6IHQudXNlcl9pZC5mdWxsX25hbWUsIGNvdW50OiAxIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBBcnJheS5mcm9tKGJ5Q3VzdG9tZXIudmFsdWVzKCkpLnNvcnQoKGEsIGIpID0+IGIuY291bnQgLSBhLmNvdW50KTtcclxuICB9LCBbdGlja2V0c10pO1xyXG5cclxuICBjb25zdCB1bmlxdWVDdXN0b21lcnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGlkcyA9IG5ldyBTZXQoXHJcbiAgICAgIHRpY2tldHMuZmlsdGVyKCh0KSA9PiB0LnVzZXJfaWQpLm1hcCgodCkgPT4gdC51c2VyX2lkLmN1c3RvbWVyX2lkKVxyXG4gICAgKTtcclxuICAgIHJldHVybiBpZHMuc2l6ZTtcclxuICB9LCBbdGlja2V0c10pO1xyXG5cclxuICBpZiAobG9hZGluZykgcmV0dXJuIDxTa2VsZXRvbiBhY3RpdmUgcGFyYWdyYXBoPXt7IHJvd3M6IDggfX0gY2xhc3NOYW1lPVwibXQtNlwiIC8+O1xyXG4gIGlmICghdGlja2V0c0luZm8pIHJldHVybiA8RW1wdHkgZGVzY3JpcHRpb249XCJObyB0aWNrZXQgZGF0YSBhdmFpbGFibGVcIiBjbGFzc05hbWU9XCJtdC0xNlwiIC8+O1xyXG5cclxuICBjb25zdCBmaWxsZWQgPSB0aWNrZXRzLmZpbHRlcigodCkgPT4gdC5zZWF0X3R5cGUgPT09IFwiRmlsbGVkXCIpLmxlbmd0aDtcclxuICBjb25zdCB2YWNhbnQgPSB0aWNrZXRzLmxlbmd0aCAtIGZpbGxlZDtcclxuICBjb25zdCBoYXNSZXNlcnZlZCA9IHRpY2tldHMuc29tZSgodCkgPT4gdC5zZWF0X3R5cGUgPT09IFwiRmlsbGVkXCIgJiYgIXQudXNlcl9pZCk7XHJcbiAgY29uc3QgZ3JvdXBOYW1lID0gdGlja2V0c0luZm8uZ3JvdXA/Lmdyb3VwX25hbWUgfHwgXCJncm91cFwiO1xyXG4gIGNvbnN0IHNhZmVHcm91cE5hbWUgPSBzYW5pdGl6ZUZpbGVuYW1lKGdyb3VwTmFtZSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTJcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cclxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLWdyYXktMTAwXCIgYm9keVN0eWxlPXt7IHBhZGRpbmc6IFwiMThweCAyMHB4XCIgfX0+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMVwiPlRvdGFsIFRpY2tldHM8L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPnt0aWNrZXRzLmxlbmd0aH08L3A+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItZ3JheS0xMDBcIiBib2R5U3R5bGU9e3sgcGFkZGluZzogXCIxOHB4IDIwcHhcIiB9fT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtYi0xXCI+TWFwcGVkPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtaW5kaWdvLTYwMFwiPntmaWxsZWR9PC9wPlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLWdyYXktMTAwXCIgYm9keVN0eWxlPXt7IHBhZGRpbmc6IFwiMThweCAyMHB4XCIgfX0+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMVwiPkF2YWlsYWJsZTwvcD5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNTAwXCI+e3ZhY2FudH08L3A+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItZ3JheS0xMDBcIiBib2R5U3R5bGU9e3sgcGFkZGluZzogXCIxOHB4IDIwcHhcIiB9fT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtYi0xXCI+VW5pcXVlIEN1c3RvbWVyczwvcD5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3VuaXF1ZUN1c3RvbWVyc308L3A+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgIDxDYXJkXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLWdyYXktMTAwIGxnOmNvbC1zcGFuLTJcIlxyXG4gICAgICAgICAgdGl0bGU9ezxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5UaWNrZXQgTWFwPC9zcGFuPn1cclxuICAgICAgICAgIGV4dHJhPXtcclxuICAgICAgICAgICAgPFNwYWNlIHNpemU9ezEyfT5cclxuICAgICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCIjNGY0NmU1XCIgdGV4dD17YCR7ZmlsbGVkfS8ke3RpY2tldHMubGVuZ3RofSBtYXBwZWRgfSAvPlxyXG4gICAgICAgICAgICAgIDxDYXJkU2hhcmVBY3Rpb25zIHRhcmdldFJlZj17c2VhdE1hcFJlZn0gZmlsZW5hbWU9e2Ake3NhZmVHcm91cE5hbWV9LXNlYXQtbWFwLnBuZ2B9IC8+XHJcbiAgICAgICAgICAgIDwvU3BhY2U+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiByZWY9e3NlYXRNYXBSZWZ9IGNsYXNzTmFtZT1cImJnLXdoaXRlXCI+XHJcbiAgICAgICAgICAgIDxFeHBvcnRIZWFkZXIgZ3JvdXBOYW1lPXtncm91cE5hbWV9IGxhYmVsPVwiVGlja2V0IE1hcFwiIC8+XHJcbiAgICAgICAgICAgIDxTZWF0TWFwIHRpY2tldHM9e3RpY2tldHN9IC8+XHJcbiAgICAgICAgICAgIDxTZWF0TGVnZW5kIGhhc1Jlc2VydmVkPXtoYXNSZXNlcnZlZH0gLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00XCI+XHJcbiAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgdGl0bGU9ezxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5GaWxsIFJhdGU8L3NwYW4+fVxyXG4gICAgICAgICAgICBleHRyYT17PENhcmRTaGFyZUFjdGlvbnMgdGFyZ2V0UmVmPXtmaWxsUmF0ZVJlZn0gZmlsZW5hbWU9e2Ake3NhZmVHcm91cE5hbWV9LWZpbGwtcmF0ZS5wbmdgfSAvPn1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiByZWY9e2ZpbGxSYXRlUmVmfSBjbGFzc05hbWU9XCJiZy13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIDxFeHBvcnRIZWFkZXIgZ3JvdXBOYW1lPXtncm91cE5hbWV9IGxhYmVsPVwiRmlsbCBSYXRlXCIgLz5cclxuICAgICAgICAgICAgICA8RmlsbFJhdGVEb251dCBmaWxsZWQ9e2ZpbGxlZH0gdmFjYW50PXt2YWNhbnR9IC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LXNtIGJvcmRlci1ncmF5LTEwMFwiIHRpdGxlPXs8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+VG9wIFRpY2tldCBIb2xkZXJzPC9zcGFuPn0+XHJcbiAgICAgICAgICAgIDxUb3BIb2xkZXJzTWluaSBjdXN0b21lcnM9e2FsbEhvbGRlcnN9IC8+XHJcbiAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPENhcmRcclxuICAgICAgICBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLWdyYXktMTAwIG10LTRcIlxyXG4gICAgICAgIHRpdGxlPXs8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+VGlja2V0IEhvbGRlcnM8L3NwYW4+fVxyXG4gICAgICAgIGV4dHJhPXs8Q2FyZFNoYXJlQWN0aW9ucyB0YXJnZXRSZWY9e2hvbGRlcnNSZWZ9IGZpbGVuYW1lPXtgJHtzYWZlR3JvdXBOYW1lfS10aWNrZXQtaG9sZGVycy5wbmdgfSAvPn1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgcmVmPXtob2xkZXJzUmVmfSBjbGFzc05hbWU9XCJiZy13aGl0ZVwiPlxyXG4gICAgICAgICAgPEV4cG9ydEhlYWRlciBncm91cE5hbWU9e2dyb3VwTmFtZX0gbGFiZWw9XCJUaWNrZXQgSG9sZGVyc1wiIC8+XHJcbiAgICAgICAgICA8VG9wSG9sZGVyc0NoYXJ0IGN1c3RvbWVycz17YWxsSG9sZGVyc30gLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9DYXJkPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmNvbnN0IEdyb3VwUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyZXBvcnRSb3dzLCBzZXRSZXBvcnRSb3dzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdGlja2V0c0luZm8sIHNldFRpY2tldHNJbmZvXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFthdWN0aW9uUm93cywgc2V0QXVjdGlvblJvd3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0dyb3Vwc0xvYWRpbmcsIHNldElzR3JvdXBzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbaXNSZXBvcnRMb2FkaW5nLCBzZXRJc1JlcG9ydExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc1RpY2tldHNMb2FkaW5nLCBzZXRJc1RpY2tldHNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNBdWN0aW9uTG9hZGluZywgc2V0SXNBdWN0aW9uTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwiZ3JvdXBEZXRhaWxzXCIpO1xyXG5cclxuICAvLyBHdWFyZHMgYWdhaW5zdCBhIHN0YWxlL3Nsb3cgcmVxdWVzdCBvdmVyd3JpdGluZyBhIG5ld2VyIG9uZSdzIGRhdGFcclxuICBjb25zdCBsYXRlc3RSZXF1ZXN0SWQgPSB1c2VSZWYoMCk7XHJcbiAgLy8gVHJhY2tzIHdoaWNoIGdyb3VwJ3MgYXVjdGlvbiBkZXRhaWxzIGhhdmUgYWxyZWFkeSBiZWVuIGZldGNoZWQsIHNpbmNlXHJcbiAgLy8gdGhhdCB0YWIgbG9hZHMgbGF6aWx5IChvbmx5IHdoZW4gb3BlbmVkKSByYXRoZXIgdGhhbiB1cGZyb250LlxyXG4gIGNvbnN0IGZldGNoZWRBdWN0aW9uR3JvdXBSZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cHM6XCIsIGVycm9yKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0dyb3Vwc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyBDbGVhciBzdGFsZSBkYXRhIGltbWVkaWF0ZWx5IHNvIHRoZSBwcmV2aW91cyBncm91cCdzIGRldGFpbHMvdGFibGVcclxuICAgIC8vIG5ldmVyIGxpbmdlciBvbiBzY3JlZW4gd2hpbGUgdGhlIG5ldyBncm91cCdzIHJlcG9ydCBpcyBsb2FkaW5nLlxyXG4gICAgc2V0UmVwb3J0Um93cyhbXSk7XHJcbiAgICBzZXRUaWNrZXRzSW5mbyhudWxsKTtcclxuICAgIHNldEF1Y3Rpb25Sb3dzKFtdKTtcclxuICAgIGZldGNoZWRBdWN0aW9uR3JvdXBSZWYuY3VycmVudCA9IG51bGw7XHJcblxyXG4gICAgaWYgKCFzZWxlY3RlZEdyb3VwSWQpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCByZXF1ZXN0SWQgPSArK2xhdGVzdFJlcXVlc3RJZC5jdXJyZW50O1xyXG4gICAgc2V0SXNSZXBvcnRMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0SXNUaWNrZXRzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICBjb25zdCBmZXRjaEdyb3VwUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi9ncm91cHMvZ3JvdXAtcmVwb3J0XCIsIHtcclxuICAgICAgICAgIHBhcmFtczogeyBncm91cF9pZDogc2VsZWN0ZWRHcm91cElkIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKHJlcXVlc3RJZCA9PT0gbGF0ZXN0UmVxdWVzdElkLmN1cnJlbnQpIHtcclxuICAgICAgICAgIHNldFJlcG9ydFJvd3MocmVzcG9uc2UuZGF0YT8uZGF0YSB8fCBbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCByZXBvcnQ6XCIsIGVycm9yKTtcclxuICAgICAgICBpZiAocmVxdWVzdElkID09PSBsYXRlc3RSZXF1ZXN0SWQuY3VycmVudCkge1xyXG4gICAgICAgICAgc2V0UmVwb3J0Um93cyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIGlmIChyZXF1ZXN0SWQgPT09IGxhdGVzdFJlcXVlc3RJZC5jdXJyZW50KSB7XHJcbiAgICAgICAgICBzZXRJc1JlcG9ydExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBmZXRjaFRpY2tldEFsbG9jYXRpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL2dyb3Vwcy90aWNrZXRzXCIsIHtcclxuICAgICAgICAgIHBhcmFtczogeyBncm91cF9pZDogc2VsZWN0ZWRHcm91cElkIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKHJlcXVlc3RJZCA9PT0gbGF0ZXN0UmVxdWVzdElkLmN1cnJlbnQpIHtcclxuICAgICAgICAgIHNldFRpY2tldHNJbmZvKHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgbnVsbCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0aWNrZXQgYWxsb2NhdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgICAgIGlmIChyZXF1ZXN0SWQgPT09IGxhdGVzdFJlcXVlc3RJZC5jdXJyZW50KSB7XHJcbiAgICAgICAgICBzZXRUaWNrZXRzSW5mbyhudWxsKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgaWYgKHJlcXVlc3RJZCA9PT0gbGF0ZXN0UmVxdWVzdElkLmN1cnJlbnQpIHtcclxuICAgICAgICAgIHNldElzVGlja2V0c0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaEdyb3VwUmVwb3J0KCk7XHJcbiAgICBmZXRjaFRpY2tldEFsbG9jYXRpb24oKTtcclxuICB9LCBbc2VsZWN0ZWRHcm91cElkXSk7XHJcblxyXG4gIC8vIEF1Y3Rpb24gRGV0YWlscyBsb2FkcyBsYXppbHkg4oCUIG9ubHkgZmlyZXMgdGhlIGZpcnN0IHRpbWUgdGhhdCB0YWIgaXNcclxuICAvLyBvcGVuZWQgZm9yIHRoZSBjdXJyZW50bHkgc2VsZWN0ZWQgZ3JvdXAsIG5vdCBhbG9uZ3NpZGUgdGhlIG90aGVycy5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGFjdGl2ZVRhYiAhPT0gXCJhdWN0aW9uRGV0YWlsc1wiIHx8ICFzZWxlY3RlZEdyb3VwSWQpIHJldHVybjtcclxuICAgIGlmIChmZXRjaGVkQXVjdGlvbkdyb3VwUmVmLmN1cnJlbnQgPT09IHNlbGVjdGVkR3JvdXBJZCkgcmV0dXJuO1xyXG5cclxuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcclxuICAgIGNvbnN0IGZldGNoQXVjdGlvbkRldGFpbHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHNldElzQXVjdGlvbkxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9ncm91cC1hdWN0aW9uLyR7c2VsZWN0ZWRHcm91cElkfWApO1xyXG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgIGNvbnN0IHJvd3MgPSBBcnJheS5pc0FycmF5KHBheWxvYWQpID8gcGF5bG9hZCA6IHBheWxvYWQ/LmRhdGEgfHwgW107XHJcbiAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHtcclxuICAgICAgICAgIHNldEF1Y3Rpb25Sb3dzKHJvd3MpO1xyXG4gICAgICAgICAgZmV0Y2hlZEF1Y3Rpb25Hcm91cFJlZi5jdXJyZW50ID0gc2VsZWN0ZWRHcm91cElkO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYXVjdGlvbiBkZXRhaWxzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHNldEF1Y3Rpb25Sb3dzKFtdKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBpZiAoIWNhbmNlbGxlZCkgc2V0SXNBdWN0aW9uTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hBdWN0aW9uRGV0YWlscygpO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgY2FuY2VsbGVkID0gdHJ1ZTtcclxuICAgIH07XHJcbiAgfSwgW2FjdGl2ZVRhYiwgc2VsZWN0ZWRHcm91cElkXSk7XHJcblxyXG4gIGNvbnN0IGdyb3VwSW5mbyA9IHJlcG9ydFJvd3NbMF0/Lmdyb3VwX2lkIHx8IHRpY2tldHNJbmZvPy5ncm91cCB8fCBudWxsO1xyXG5cclxuICBjb25zdCBzdW1tYXJ5ID0gdXNlTWVtbyhcclxuICAgICgpID0+XHJcbiAgICAgIHJlcG9ydFJvd3MucmVkdWNlKFxyXG4gICAgICAgICh0b3RhbHMsIHJvdykgPT4gKHtcclxuICAgICAgICAgIGFtb3VudFRvQmVQYWlkOiB0b3RhbHMuYW1vdW50VG9CZVBhaWQgKyAoTnVtYmVyKHJvdy50b3RhbF9wYXlhYmxlKSB8fCAwKSxcclxuICAgICAgICAgIGFtb3VudFBhaWQ6IHRvdGFscy5hbW91bnRQYWlkICsgKE51bWJlcihyb3cudG90YWxfaW52ZXN0bWVudCkgfHwgMCksXHJcbiAgICAgICAgICBiYWxhbmNlOiB0b3RhbHMuYmFsYW5jZSArIChOdW1iZXIocm93LnRvdGFsX2JhbGFuY2UpIHx8IDApLFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIHsgYW1vdW50VG9CZVBhaWQ6IDAsIGFtb3VudFBhaWQ6IDAsIGJhbGFuY2U6IDAgfVxyXG4gICAgICApLFxyXG4gICAgW3JlcG9ydFJvd3NdXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgdGFibGVEYXRhID0gdXNlTWVtbyhcclxuICAgICgpID0+XHJcbiAgICAgIHJlcG9ydFJvd3MubWFwKChyb3csIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgY3VzdG9tZXJJZDogcm93LnVzZXJfaWQ/LmN1c3RvbWVyX2lkIHx8IFwiLVwiLFxyXG4gICAgICAgIG5hbWU6IHJvdy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgcGhvbmVOdW1iZXI6IHJvdy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgdGlja2V0OiByb3cudGlja2V0cyxcclxuICAgICAgICBzdGF0dXM6IChcclxuICAgICAgICAgIDxUYWcgY29sb3I9e1NUQVRVU19DT0xPUlNbcm93LmN1c3RvbWVyX3N0YXR1c10gfHwgXCJkZWZhdWx0XCJ9PlxyXG4gICAgICAgICAgICB7cm93LmN1c3RvbWVyX3N0YXR1cyB8fCBcIi1cIn1cclxuICAgICAgICAgIDwvVGFnPlxyXG4gICAgICAgICksXHJcbiAgICAgICAgYW1vdW50VG9CZVBhaWQ6IGZvcm1hdEN1cnJlbmN5KHJvdy50b3RhbF9wYXlhYmxlKSxcclxuICAgICAgICBhbW91bnRQYWlkOiBmb3JtYXRDdXJyZW5jeShyb3cudG90YWxfaW52ZXN0bWVudCksXHJcbiAgICAgICAgYmFsYW5jZTogZm9ybWF0Q3VycmVuY3kocm93LnRvdGFsX2JhbGFuY2UpLFxyXG4gICAgICAgIG5leHRBdWN0aW9uRGF0ZTogcm93Lm5leHRfYXVjdGlvbl9kYXRlIHx8IFwiLVwiLFxyXG4gICAgICB9KSksXHJcbiAgICBbcmVwb3J0Um93c11cclxuICApO1xyXG5cclxuICAvLyBBZGQgbmV3IHRhYnMgaGVyZSBsYXRlciDigJQgZWFjaCBqdXN0IG5lZWRzIGEga2V5LCBsYWJlbCwgYW5kIGNoaWxkcmVuLlxyXG4gIGNvbnN0IHRhYkl0ZW1zID0gW1xyXG4gICAge1xyXG4gICAgICBrZXk6IFwiZ3JvdXBEZXRhaWxzXCIsXHJcbiAgICAgIGxhYmVsOiBcIkdyb3VwIERldGFpbHNcIixcclxuICAgICAgY2hpbGRyZW46IDxHcm91cERldGFpbHNUYWIgZ3JvdXBJbmZvPXtncm91cEluZm99IGxvYWRpbmc9e2lzUmVwb3J0TG9hZGluZ30gLz4sXHJcbiAgICB9LFxyXG4gICAgIHtcclxuICAgICAga2V5OiBcInRpY2tldEFsbG9jYXRpb25cIixcclxuICAgICAgbGFiZWw6IFwiVGlja2V0IEFsbG9jYXRpb25cIixcclxuICAgICAgY2hpbGRyZW46IDxUaWNrZXRBbGxvY2F0aW9uVGFiIHRpY2tldHNJbmZvPXt0aWNrZXRzSW5mb30gbG9hZGluZz17aXNUaWNrZXRzTG9hZGluZ30gLz4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiZ3JvdXBPdmVydmlld1wiLFxyXG4gICAgICBsYWJlbDogXCJHcm91cCBPdmVydmlld1wiLFxyXG4gICAgICBjaGlsZHJlbjogKFxyXG4gICAgICAgIDxDdXN0b21lck92ZXJ2aWV3VGFiXHJcbiAgICAgICAgICB0YWJsZURhdGE9e3RhYmxlRGF0YX1cclxuICAgICAgICAgIHN1bW1hcnk9e3N1bW1hcnl9XHJcbiAgICAgICAgICBncm91cEluZm89e2dyb3VwSW5mb31cclxuICAgICAgICAgIGxvYWRpbmc9e2lzUmVwb3J0TG9hZGluZ31cclxuICAgICAgICAgIHNlYXJjaFRleHQ9e3NlYXJjaFRleHR9XHJcbiAgICAgICAgLz5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgIFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiYXVjdGlvbkRldGFpbHNcIixcclxuICAgICAgbGFiZWw6IFwiQXVjdGlvbiBEZXRhaWxzXCIsXHJcbiAgICAgIGNoaWxkcmVuOiAoXHJcbiAgICAgICAgPEF1Y3Rpb25EZXRhaWxzVGFiXHJcbiAgICAgICAgICByb3dzPXthdWN0aW9uUm93c31cclxuICAgICAgICAgIGxvYWRpbmc9e2lzQXVjdGlvbkxvYWRpbmd9XHJcbiAgICAgICAgICBzZWFyY2hUZXh0PXtzZWFyY2hUZXh0fVxyXG4gICAgICAgICAgZ3JvdXBOYW1lPXtncm91cEluZm8/Lmdyb3VwX25hbWV9XHJcbiAgICAgICAgLz5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWdyYXktNTBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTMwXCI+XHJcbiAgICAgICAgPE5hdmJhciBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn0gdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgdy04MCBwLTdcIj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtYi02XCI+R3JvdXAgUmVwb3J0PC9oMT5cclxuXHJcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLWdyYXktMTAwIG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiIGh0bWxGb3I9XCJncm91cC1zZWxlY3RcIj5cclxuICAgICAgICAgICAgICAgIFNlbGVjdCBHcm91cFxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgaWQ9XCJncm91cC1zZWxlY3RcIlxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgbG9hZGluZz17aXNHcm91cHNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogNDQsIHdpZHRoOiBcIjEwMCVcIiwgbWF4V2lkdGg6IDQ4MCB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3Igc2VsZWN0IGEgZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRHcm91cElkfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgICB7c2VsZWN0ZWRHcm91cElkID8gKFxyXG4gICAgICAgICAgICA8VGFic1xyXG4gICAgICAgICAgICAgIGFjdGl2ZUtleT17YWN0aXZlVGFifVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRBY3RpdmVUYWJ9XHJcbiAgICAgICAgICAgICAgaXRlbXM9e3RhYkl0ZW1zfVxyXG4gICAgICAgICAgICAgIHR5cGU9XCJjYXJkXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cC1yZXBvcnQtdGFic1wiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgPEVtcHR5IGRlc2NyaXB0aW9uPVwiU2VsZWN0IGEgZ3JvdXAgYWJvdmUgdG8gdmlldyBpdHMgcmVwb3J0XCIgY2xhc3NOYW1lPVwicHktMTBcIiAvPlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBHcm91cFJlcG9ydDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvR3JvdXBSZXBvcnQuanN4In0=