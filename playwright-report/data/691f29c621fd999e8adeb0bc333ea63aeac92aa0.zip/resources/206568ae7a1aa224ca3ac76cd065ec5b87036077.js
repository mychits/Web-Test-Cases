import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerRewards.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select, Table, Checkbox, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { header } from "/node_modules/.vite/deps/framer-motion_client.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Search, Calendar, Award, TrendingUp, Star, Gift, Trophy, Users } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const CustomerRewards = () => {
  _s();
  const [customers, setCustomers] = useState([]);
  const [customerId, setCustomerId] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [rewardTable, setRewardTable] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const todayString = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedToDate, setSelectedToDate] = useState(todayString);
  const [showFilterField, setShowFilterField] = useState(false);
  const [summary, setSummary] = useState({
    point_value: 1,
    //  total_earned_points: 0,
    total_earned_points: 0,
    // wallet earned (after redemption)
    total_redeemed_points: 0,
    balance_points: 0,
    total_redeemed_amount: 0,
    sum_previous_earned_points: 0,
    // lifetime
    sum_previous_redeemed_points: 0
  });
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  const [rewardState, setRewardState] = useState({
    rewards: [],
    activeRewards: [],
    totalPointsAll: 0,
    totalAmountAll: 0,
    totalEmplyees: 0
  });
  const [redeemPoints, setRedeemPoints] = useState("");
  const [redeemType, setRedeemType] = useState("Cash");
  const [redeemAmount, setRedeemAmount] = useState(0);
  const [redeemDesc, setRedeemDesc] = useState("");
  useEffect(() => {
    fetchCustomers();
  }, []);
  const fetchCustomers = async () => {
    try {
      const res = await api.get("/user/get-user");
      setCustomers(res.data || []);
    } catch {
      console.error("Failed to fetch customers");
    }
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [employeeRes, empRewardsRes] = await Promise.all(
          [
            api.get("/agent/get-employee"),
            api.get(`/reward-points/rewards/top-employees?from_date=${selectedFromDate}&to_date=${selectedToDate}`)
          ]
        );
        console.log(empRewardsRes.data.count, "empRewardsRes");
        const rewardData = empRewardsRes.data?.data || [];
        const filtered = rewardData.filter(
          (item) => item.total_points > 0
        );
        const sorted = [...filtered].sort(
          (a, b) => b.total_points - a.total_points
        );
        const totalPoints = rewardData.reduce(
          (sum, item) => sum + item.total_points,
          0
        );
        const totalAmount = rewardData.reduce(
          (sum, item) => sum + item.total_amount,
          0
        );
        setRewardState({
          rewards: filtered,
          activeRewards: sorted,
          totalPointsAll: totalPoints,
          totalAmountAll: totalAmount,
          totalEmplyees: empRewardsRes.data?.count || 0
        });
        setEmployees(employeeRes.data.employee || []);
        setRewards([empRewardsRes.data?.data]);
      } catch (e) {
        console.error(e);
      }
    };
    fetchData();
    setIsLoading(false);
  }, [selectedFromDate, selectedToDate]);
  const fetchRewardSummary = async (custId) => {
    try {
      const res = await api.get(
        `/customer-rewards/customer-reward-points/${custId}`
      );
      if (res.data?.success) {
        setSummary(res.data);
      }
    } catch (err) {
      console.error("Failed to fetch reward summary", err);
    }
  };
  const fetchRewardPoints = async (custId) => {
    if (!custId) return;
    setIsLoading(true);
    try {
      const res = await api.get(
        `/customer-rewards/customer-reward-list/${custId}`
      );
      const formatted = res.data?.data?.map((reward, index) => ({
        _id: reward._id,
        slNo: index + 1,
        customerName: reward?.customer_name || "-",
        phone: reward?.customer_phone || "-",
        groupName: reward?.group_name || "-",
        sourceType: reward?.source_type || "-",
        rewardPoints: reward?.reward_points || 0,
        rewardAmount: reward?.rewarded_amount || 0,
        status: reward?.status || "Active",
        remarks: reward?.remarks || "-"
      }));
      setRewardTable(formatted);
    } catch (err) {
      console.error("Failed to fetch reward list", err);
    } finally {
      setIsLoading(false);
    }
  };
  const createRewardPoints = async () => {
    if (!customerId) return alert("Select customer");
    if (!fromDate || !toDate) return alert("Select From & To dates");
    if (new Date(fromDate) > new Date(toDate)) {
      return alert("From Date cannot be after To Date");
    }
    setIsLoading(true);
    try {
      await api.post("/customer-rewards/customer-reward-points/create", {
        customer_id: customerId,
        from_date: fromDate,
        to_date: toDate,
        remarks: ""
      });
      await fetchRewardSummary(customerId);
      await fetchRewardPoints(customerId);
    } catch (err) {
      alert(err.response?.data?.message || "Failed to create rewards");
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    if (redeemType === "Cash") {
      setRedeemAmount(Number(redeemPoints || 0) * summary.point_value);
    } else {
      setRedeemAmount(0);
    }
  }, [redeemPoints, redeemType, summary.point_value]);
  const redeemRewardPoints = async () => {
    if (!customerId) return alert("Select customer");
    if (!redeemPoints) return alert("Enter points");
    if (Number(redeemPoints) > summary.balance_points) {
      return alert("Redeem points exceed available balance");
    }
    setIsLoading(true);
    try {
      await api.post("/customer-rewards/customer-reward-points/redeem", {
        customer_id: customerId,
        redeem_points: Number(redeemPoints),
        redemption_type: redeemType,
        description: redeemDesc
      });
      setRedeemPoints("");
      setRedeemDesc("");
      await fetchRewardSummary(customerId);
      await fetchRewardPoints(customerId);
    } catch (err) {
      alert(err.response?.data?.message || "Redeem failed");
    } finally {
      setIsLoading(false);
    }
  };
  const rewardColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "customerName", header: "Customer Name" },
    { key: "phone", header: "Phone" },
    { key: "groupName", header: "Group" },
    { key: "sourceType", header: "Source" },
    { key: "rewardPoints", header: "Points" },
    { key: "rewardAmount", header: "Amount" },
    { key: "status", header: "Status" },
    { key: "remarks", header: "Remarks" }
  ];
  const groupOptions = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
      lineNumber: 840,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
        lineNumber: 842,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-6", children: "Customer Reward Points" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
          lineNumber: 845,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-8 mb-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "Total Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 852,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Users, { className: "h-8 w-8 text-blue-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 853,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 851,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-gray-800", children: rewardState?.totalEmplyees }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 855,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-6", children: "Across all department" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 856,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 850,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "Total Amount/Rewards" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 860,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Award, { className: "h-8 w-8 text-blue-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 861,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 859,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-gray-800", children: rewardState?.totalAmountAll }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 863,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-2", children: "Across all employees" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 864,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 858,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "Total Points" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 869,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Star, { className: "h-8 w-8 text-yellow-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 870,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 868,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-gray-800", children: rewardState?.totalPointsAll }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 872,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-6", children: "Points awarded in total" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 873,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 867,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "Top Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 878,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Trophy, { className: "h-8 w-8 text-green-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 879,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 877,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-800", children: rewardState?.activeRewards.length > 0 ? rewardState.activeRewards[0]?.employee_name : "N/A" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 881,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-7", children: rewardState?.activeRewards.length > 0 ? `${rewardState.activeRewards[0].total_points} points` : "No data available" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 884,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 876,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
          lineNumber: 849,
          columnNumber: 18
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative mb-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-r from-indigo-100 via-blue-100 to-purple-100 rounded-3xl blur-xl opacity-40" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 893,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative bg-white/80 backdrop-blur-xl \r\n                  border border-gray-200 \r\n                  rounded-3xl shadow-lg \r\n                  p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6 items-end", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-600", children: "Filter Option" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 904,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  popupMatchSelectWidth: false,
                  onChange: handleSelectFilter,
                  value: selectedLabel,
                  placeholder: "Search or Select Filter",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  className: "w-full custom-select",
                  children: groupOptions.map(
                    (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                      lineNumber: 923,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 908,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 903,
              columnNumber: 21
            }, this),
            showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-600", children: "From Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 934,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    value: selectedFromDate,
                    onChange: (e) => setSelectedFromDate(e.target.value),
                    className: "w-full h-10 bg-white \r\n                         border border-gray-300 \r\n                         rounded-xl px-4 \r\n                         focus:ring-2 focus:ring-indigo-500 \r\n                         focus:border-indigo-500 \r\n                         shadow-sm \r\n                         transition-all duration-300 \r\n                         hover:border-indigo-400"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 937,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 933,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-600", children: "To Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 954,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    value: selectedToDate,
                    onChange: (e) => setSelectedToDate(e.target.value),
                    className: "w-full h-12 bg-white \r\n                         border border-gray-300 \r\n                         rounded-xl px-4 \r\n                         focus:ring-2 focus:ring-indigo-500 \r\n                         focus:border-indigo-500 \r\n                         shadow-sm \r\n                         transition-all duration-300 \r\n                         hover:border-indigo-400"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 957,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 953,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 932,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 900,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 895,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
          lineNumber: 890,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-2 bg-gray-50 border-b border-gray-200", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-gray-800", children: "Customer Rewards Summary" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 981,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto mb-3", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Sl no" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 987,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 988,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Department" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 989,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Points" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 990,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Rewards / Ammount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 991,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Trend" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 992,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 986,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 985,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: rewardState.activeRewards?.slice(0, 5)?.map(
              (employee, key) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50 ", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-blue-600 font-medium", children: key + 1 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 1001,
                  columnNumber: 35
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 1e3,
                  columnNumber: 33
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 999,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 998,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500", children: employee.employee_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 1005,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500", children: employee.department || "Sales" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 1006,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: employee.total_points }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 1009,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-xs text-gray-500", children: "pts" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 1010,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 1008,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 1007,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500", children: employee.total_amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 1013,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap", children: [
                  employee.total_points > 2e3 && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center text-sm text-green-600", children: [
                    /* @__PURE__ */ jsxDEV(TrendingUp, { className: "h-4 w-4 mr-1" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                      lineNumber: 1017,
                      columnNumber: 35
                    }, this),
                    "Up"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 1016,
                    columnNumber: 25
                  }, this),
                  employee.total_points < 2e3 && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center text-sm text-red-600", children: [
                    /* @__PURE__ */ jsxDEV(TrendingUp, { className: "h-4 w-4 mr-1 rotate-180" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                      lineNumber: 1023,
                      columnNumber: 35
                    }, this),
                    "Down"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 1022,
                    columnNumber: 25
                  }, this),
                  employee.trend === "same" && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center text-sm text-gray-600", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-4 mr-1 bg-gray-400 rounded-full" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                      lineNumber: 1029,
                      columnNumber: 35
                    }, this),
                    "Same"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 1028,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                  lineNumber: 1014,
                  columnNumber: 29
                }, this)
              ] }, employee.id, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 997,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 995,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 984,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 983,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
          lineNumber: 980,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
          lineNumber: 979,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-4 mt-4 mb-5 items-end", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 1044,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-64",
                placeholder: "Select Customer",
                popupMatchSelectWidth: false,
                showSearch: true,
                optionFilterProp: "children",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                value: customerId || void 0,
                onChange: (value) => {
                  setCustomerId(value);
                  setRewardTable([]);
                  if (value) {
                    fetchRewardSummary(value);
                    fetchRewardPoints(value);
                  }
                },
                children: customers.map(
                  (c) => /* @__PURE__ */ jsxDEV(Select.Option, { value: c._id, children: [
                    c.full_name,
                    " - ",
                    c.phone_number
                  ] }, c._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 1070,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 1046,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 1043,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm mb-1", children: "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 1078,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "border px-4 py-2 rounded",
                value: fromDate,
                onChange: (e) => setFromDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 1079,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 1077,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm mb-1", children: "To Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 1088,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "border px-4 py-2 rounded",
                value: toDate,
                onChange: (e) => setToDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 1089,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 1087,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: createRewardPoints,
              disabled: isLoading,
              className: `px-6 py-2 rounded ${isLoading ? "bg-gray-400" : "bg-blue-600 text-white hover:bg-blue-700"}`,
              children: isLoading ? "Processing..." : "Create Reward"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 1097,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
          lineNumber: 1042,
          columnNumber: 11
        }, this),
        customerId && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV(
            SummaryCard,
            {
              label: "Earned Points",
              value: summary.total_earned_points
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 1112,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            SummaryCard,
            {
              label: "Redeemed Points",
              value: summary.total_redeemed_points
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 1116,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            SummaryCard,
            {
              label: "Redeemed Amount",
              value: summary.total_redeemed_amount
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 1120,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
          lineNumber: 1111,
          columnNumber: 11
        }, this),
        customerId && /* @__PURE__ */ jsxDEV("div", { className: "border rounded p-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "font-semibold mb-4", children: "Redeem Reward Points" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 1130,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                placeholder: "Reward Points",
                className: "border px-3 py-2 rounded",
                value: redeemPoints,
                onChange: (e) => setRedeemPoints(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 1133,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "border px-3 py-2 rounded",
                value: redeemType,
                onChange: (e) => setRedeemType(e.target.value),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "Cash", children: "Cash" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 1146,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Gift", children: "Gift" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 1147,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Other", children: "Other" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                    lineNumber: 1148,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 1141,
                columnNumber: 17
              },
              this
            ),
            redeemType === "Cash" && /* @__PURE__ */ jsxDEV(
              "input",
              {
                disabled: true,
                className: "border px-3 py-2 rounded bg-gray-100",
                value: `₹ ${redeemAmount}`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 1152,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: "Remarks",
                className: "border px-3 py-2 rounded col-span-2",
                value: redeemDesc,
                onChange: (e) => setRedeemDesc(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
                lineNumber: 1159,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 1132,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              disabled: summary.balance_points <= 0,
              onClick: redeemRewardPoints,
              className: `mt-4 px-6 py-2 rounded ${summary.balance_points <= 0 ? "bg-gray-400 cursor-not-allowed" : "bg-green-600 text-white"}`,
              children: "Redeem Points"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
              lineNumber: 1168,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
          lineNumber: 1129,
          columnNumber: 11
        }, this),
        rewardTable.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            columns: rewardColumns,
            data: rewardTable,
            exportedPdfName: "Customer Rewards",
            exportedFileName: `Customer Rewards.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 1184,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            data: "Customer Reward",
            failure: !isLoading && rewardTable.length === 0
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
            lineNumber: 1187,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
        lineNumber: 844,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
      lineNumber: 841,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
    lineNumber: 839,
    columnNumber: 5
  }, this);
};
_s(CustomerRewards, "7FBKnPEQSf1fZZtbyycoRcbHS4E=");
_c = CustomerRewards;
const SummaryCard = ({ label, value }) => /* @__PURE__ */ jsxDEV("div", { className: "border rounded p-4 bg-white shadow-sm", children: [
  /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: label }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
    lineNumber: 1201,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-semibold mt-1", children: value }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
    lineNumber: 1202,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx",
  lineNumber: 1200,
  columnNumber: 1
}, this);
_c2 = SummaryCard;
export default CustomerRewards;
var _c, _c2;
$RefreshReg$(_c, "CustomerRewards");
$RefreshReg$(_c2, "SummaryCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerRewards.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdTBCTSxTQTRGZ0IsVUE1RmhCOzJCQXYwQk47QUFBZ0JBLE1BQVdDLGNBQVVDLE9BQU8sc0JBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0QsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLFNBQVNDLFFBQVFDLE9BQU9DLFVBQVVDLGVBQWU7QUFDakQsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLGFBQWE7QUFDcEIsU0FBU0MsUUFBUUMsVUFBVUMsT0FBT0MsWUFBWUMsTUFBTUMsTUFBTUMsUUFBUUMsYUFBYTtBQStoQi9FLE1BQU1DLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJekIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzBCLFlBQVlDLGFBQWEsSUFBSTNCLFNBQVMsRUFBRTtBQUcvQyxRQUFNLENBQUM0QixVQUFVQyxXQUFXLElBQUk3QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDOEIsUUFBUUMsU0FBUyxJQUFJL0IsU0FBUyxFQUFFO0FBRXZDLFFBQU0sQ0FBQ2dDLGFBQWFDLGNBQWMsSUFBSWpDLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNrQyxXQUFXQyxZQUFZLElBQUluQyxTQUFTLEtBQUs7QUFDaEQsUUFBTW9DLGVBQWMsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3pELFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUl6QyxTQUFTLE9BQU87QUFDMUQsUUFBTSxDQUFDMEMsa0JBQWtCQyxtQkFBbUIsSUFBSTNDLFNBQVNvQyxXQUFXO0FBQ3BFLFFBQU0sQ0FBQ1EsZ0JBQWdCQyxpQkFBaUIsSUFBSTdDLFNBQVNvQyxXQUFXO0FBQzlELFFBQU0sQ0FBQ1UsaUJBQWlCQyxrQkFBa0IsSUFBSS9DLFNBQVMsS0FBSztBQUk5RCxRQUFNLENBQUNnRCxTQUFTQyxVQUFVLElBQUlqRCxTQUFTO0FBQUEsSUFDckNrRCxhQUFhO0FBQUE7QUFBQSxJQUViQyxxQkFBcUI7QUFBQTtBQUFBLElBQ3JCQyx1QkFBdUI7QUFBQSxJQUN2QkMsZ0JBQWdCO0FBQUEsSUFDaEJDLHVCQUF1QjtBQUFBLElBQ3ZCQyw0QkFBNEI7QUFBQTtBQUFBLElBQzVCQyw4QkFBOEI7QUFBQSxFQUNoQyxDQUFDO0FBRUQsUUFBTUMsd0JBQXdCQSxDQUFDQyxPQUFPQyxVQUFVO0FBQzlDQyxzQkFBa0IsQ0FBQ0MsY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0gsS0FBSyxHQUFHQztBQUFBQSxJQUNYLEVBQUU7QUFFRkcsY0FBVSxFQUFFLEdBQUdDLFFBQVEsQ0FBQ0wsS0FBSyxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBRUUsUUFBTSxDQUFDTSxhQUFhQyxjQUFjLElBQUlqRSxTQUFTO0FBQUEsSUFDL0NrRSxTQUFTO0FBQUEsSUFDVEMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFHRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSXhFLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUN5RSxZQUFZQyxhQUFhLElBQUkxRSxTQUFTLE1BQU07QUFDbkQsUUFBTSxDQUFDMkUsY0FBY0MsZUFBZSxJQUFJNUUsU0FBUyxDQUFDO0FBQ2xELFFBQU0sQ0FBQzZFLFlBQVlDLGFBQWEsSUFBSTlFLFNBQVMsRUFBRTtBQUcvQ0QsWUFBVSxNQUFNO0FBQ2RnRixtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMLFFBQU1BLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRixZQUFNQyxNQUFNLE1BQU05RSxJQUFJK0UsSUFBSSxnQkFBZ0I7QUFDMUN4RCxtQkFBYXVELElBQUlFLFFBQVEsRUFBRTtBQUFBLElBQzdCLFFBQVE7QUFDTkMsY0FBUUMsTUFBTSwyQkFBMkI7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFDRXJGLFlBQVUsTUFBTTtBQUNoQixVQUFNc0YsWUFBWSxZQUFZO0FBQzVCLFVBQUk7QUFDRixjQUFNLENBQUNDLGFBQWFDLGFBQWEsSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxVQUFJO0FBQUEsWUFDckR2RixJQUFJK0UsSUFBSSxxQkFBcUI7QUFBQSxZQUM3Qi9FLElBQUkrRSxJQUFJLGtEQUFrRHZDLGdCQUFnQixZQUFZRSxjQUFjLEVBQUU7QUFBQSxVQUFDO0FBQUEsUUFDeEc7QUFDRHVDLGdCQUFRTyxJQUFJSCxjQUFjTCxLQUFLUyxPQUFPLGVBQWU7QUFFckQsY0FBTUMsYUFBYUwsY0FBY0wsTUFBTUEsUUFBUTtBQUcvQyxjQUFNVyxXQUFXRCxXQUFXRTtBQUFBQSxVQUMxQixDQUFDQyxTQUFTQSxLQUFLQyxlQUFlO0FBQUEsUUFDaEM7QUFHQSxjQUFNQyxTQUFTLENBQUMsR0FBR0osUUFBUSxFQUFFSztBQUFBQSxVQUMzQixDQUFDQyxHQUFHQyxNQUFNQSxFQUFFSixlQUFlRyxFQUFFSDtBQUFBQSxRQUMvQjtBQUdBLGNBQU1LLGNBQWNULFdBQVdVO0FBQUFBLFVBQzdCLENBQUNDLEtBQUtSLFNBQVNRLE1BQU1SLEtBQUtDO0FBQUFBLFVBQzFCO0FBQUEsUUFDRjtBQUVBLGNBQU1RLGNBQWNaLFdBQVdVO0FBQUFBLFVBQzdCLENBQUNDLEtBQUtSLFNBQVNRLE1BQU1SLEtBQUtVO0FBQUFBLFVBQzFCO0FBQUEsUUFDRjtBQUdBeEMsdUJBQWU7QUFBQSxVQUNiQyxTQUFTMkI7QUFBQUEsVUFDVDFCLGVBQWU4QjtBQUFBQSxVQUNmN0IsZ0JBQWdCaUM7QUFBQUEsVUFDaEJoQyxnQkFBZ0JtQztBQUFBQSxVQUNoQmxDLGVBQWVpQixjQUFjTCxNQUFNUyxTQUFTO0FBQUEsUUFDOUMsQ0FBQztBQUNEZSxxQkFBYXBCLFlBQVlKLEtBQUt5QixZQUFZLEVBQUU7QUFDNUNDLG1CQUFXLENBQUNyQixjQUFjTCxNQUFNQSxJQUFJLENBQU87QUFBQSxNQUM3QyxTQUFTMkIsR0FBRztBQUNWMUIsZ0JBQVFDLE1BQU15QixDQUFDO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBQ0F4QixjQUFVO0FBQ1ZsRCxpQkFBYSxLQUFLO0FBQUEsRUFDcEIsR0FBRyxDQUFDTyxrQkFBaUJFLGNBQWMsQ0FBQztBQUdwQyxRQUFNa0UscUJBQXFCLE9BQU9DLFdBQVc7QUFDM0MsUUFBSTtBQUNGLFlBQU0vQixNQUFNLE1BQU05RSxJQUFJK0U7QUFBQUEsUUFDcEIsNENBQTRDOEIsTUFBTTtBQUFBLE1BQ3BEO0FBQ0EsVUFBSS9CLElBQUlFLE1BQU04QixTQUFTO0FBQ3JCL0QsbUJBQVcrQixJQUFJRSxJQUFJO0FBQUEsTUFDckI7QUFBQSxJQUNGLFNBQVMrQixLQUFLO0FBQ1o5QixjQUFRQyxNQUFNLGtDQUFrQzZCLEdBQUc7QUFBQSxJQUNyRDtBQUFBLEVBQ0Y7QUFHQSxRQUFNQyxvQkFBb0IsT0FBT0gsV0FBVztBQUMxQyxRQUFJLENBQUNBLE9BQVE7QUFFYjVFLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU02QyxNQUFNLE1BQU05RSxJQUFJK0U7QUFBQUEsUUFDcEIsMENBQTBDOEIsTUFBTTtBQUFBLE1BQ2xEO0FBRUEsWUFBTUksWUFBWW5DLElBQUlFLE1BQU1BLE1BQU1rQyxJQUFJLENBQUNDLFFBQVFDLFdBQVc7QUFBQSxRQUN4REMsS0FBS0YsT0FBT0U7QUFBQUEsUUFDWkMsTUFBTUYsUUFBUTtBQUFBLFFBQ2RHLGNBQWNKLFFBQVFLLGlCQUFpQjtBQUFBLFFBQ3ZDQyxPQUFPTixRQUFRTyxrQkFBa0I7QUFBQSxRQUNqQ0MsV0FBV1IsUUFBUVMsY0FBYztBQUFBLFFBQ2pDQyxZQUFZVixRQUFRVyxlQUFlO0FBQUEsUUFDbkNDLGNBQWNaLFFBQVFhLGlCQUFpQjtBQUFBLFFBQ3ZDQyxjQUFjZCxRQUFRZSxtQkFBbUI7QUFBQSxRQUN6Q0MsUUFBUWhCLFFBQVFnQixVQUFVO0FBQUEsUUFDMUJDLFNBQVNqQixRQUFRaUIsV0FBVztBQUFBLE1BQzlCLEVBQUU7QUFFRnJHLHFCQUFla0YsU0FBUztBQUFBLElBQzFCLFNBQVNGLEtBQUs7QUFDWjlCLGNBQVFDLE1BQU0sK0JBQStCNkIsR0FBRztBQUFBLElBQ2xELFVBQUM7QUFDQzlFLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNb0cscUJBQXFCLFlBQVk7QUFDckMsUUFBSSxDQUFDN0csV0FBWSxRQUFPOEcsTUFBTSxpQkFBaUI7QUFDL0MsUUFBSSxDQUFDNUcsWUFBWSxDQUFDRSxPQUFRLFFBQU8wRyxNQUFNLHdCQUF3QjtBQUMvRCxRQUFJLElBQUluRyxLQUFLVCxRQUFRLElBQUksSUFBSVMsS0FBS1AsTUFBTSxHQUFHO0FBQ3pDLGFBQU8wRyxNQUFNLG1DQUFtQztBQUFBLElBQ2xEO0FBRUFyRyxpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNakMsSUFBSXVJLEtBQUssbURBQW1EO0FBQUEsUUFDaEVDLGFBQWFoSDtBQUFBQSxRQUNiaUgsV0FBVy9HO0FBQUFBLFFBQ1hnSCxTQUFTOUc7QUFBQUEsUUFDVHdHLFNBQVM7QUFBQSxNQUNYLENBQUM7QUFFRCxZQUFNeEIsbUJBQW1CcEYsVUFBVTtBQUNuQyxZQUFNd0Ysa0JBQWtCeEYsVUFBVTtBQUFBLElBQ3BDLFNBQVN1RixLQUFLO0FBQ1p1QixZQUFNdkIsSUFBSTRCLFVBQVUzRCxNQUFNM0UsV0FBVywwQkFBMEI7QUFBQSxJQUNqRSxVQUFDO0FBQ0M0QixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBR0FwQyxZQUFVLE1BQU07QUFDZCxRQUFJMEUsZUFBZSxRQUFRO0FBQ3pCRyxzQkFBZ0JrRSxPQUFPdkUsZ0JBQWdCLENBQUMsSUFBSXZCLFFBQVFFLFdBQVc7QUFBQSxJQUNqRSxPQUFPO0FBQ0wwQixzQkFBZ0IsQ0FBQztBQUFBLElBQ25CO0FBQUEsRUFDRixHQUFHLENBQUNMLGNBQWNFLFlBQVl6QixRQUFRRSxXQUFXLENBQUM7QUFHbEQsUUFBTTZGLHFCQUFxQixZQUFZO0FBQ3JDLFFBQUksQ0FBQ3JILFdBQVksUUFBTzhHLE1BQU0saUJBQWlCO0FBQy9DLFFBQUksQ0FBQ2pFLGFBQWMsUUFBT2lFLE1BQU0sY0FBYztBQUU5QyxRQUFJTSxPQUFPdkUsWUFBWSxJQUFJdkIsUUFBUUssZ0JBQWdCO0FBQ2pELGFBQU9tRixNQUFNLHdDQUF3QztBQUFBLElBQ3ZEO0FBRUFyRyxpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNakMsSUFBSXVJLEtBQUssbURBQW1EO0FBQUEsUUFDaEVDLGFBQWFoSDtBQUFBQSxRQUNic0gsZUFBZUYsT0FBT3ZFLFlBQVk7QUFBQSxRQUNsQzBFLGlCQUFpQnhFO0FBQUFBLFFBQ2pCeUUsYUFBYXJFO0FBQUFBLE1BQ2YsQ0FBQztBQUVETCxzQkFBZ0IsRUFBRTtBQUNsQk0sb0JBQWMsRUFBRTtBQUVoQixZQUFNZ0MsbUJBQW1CcEYsVUFBVTtBQUNuQyxZQUFNd0Ysa0JBQWtCeEYsVUFBVTtBQUFBLElBQ3BDLFNBQVN1RixLQUFLO0FBQ1p1QixZQUFNdkIsSUFBSTRCLFVBQVUzRCxNQUFNM0UsV0FBVyxlQUFlO0FBQUEsSUFDdEQsVUFBQztBQUNDNEIsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBLFFBQU1nSCxnQkFBZ0I7QUFBQSxJQUNwQixFQUFFQyxLQUFLLFFBQVF4SSxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFd0ksS0FBSyxnQkFBZ0J4SSxRQUFRLGdCQUFnQjtBQUFBLElBQy9DLEVBQUV3SSxLQUFLLFNBQVN4SSxRQUFRLFFBQVE7QUFBQSxJQUNoQyxFQUFFd0ksS0FBSyxhQUFheEksUUFBUSxRQUFRO0FBQUEsSUFDcEMsRUFBRXdJLEtBQUssY0FBY3hJLFFBQVEsU0FBUztBQUFBLElBQ3RDLEVBQUV3SSxLQUFLLGdCQUFnQnhJLFFBQVEsU0FBUztBQUFBLElBQ3hDLEVBQUV3SSxLQUFLLGdCQUFnQnhJLFFBQVEsU0FBUztBQUFBLElBQ3hDLEVBQUV3SSxLQUFLLFVBQVV4SSxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFd0ksS0FBSyxXQUFXeEksUUFBUSxVQUFVO0FBQUEsRUFBQztBQUVyQyxRQUFNeUksZUFBZTtBQUFBLElBQ3JCLEVBQUUxRixPQUFPLFNBQVMyRixPQUFPLFFBQVE7QUFBQSxJQUNqQyxFQUFFM0YsT0FBTyxhQUFhMkYsT0FBTyxZQUFZO0FBQUEsSUFDekMsRUFBRTNGLE9BQU8sYUFBYTJGLE9BQU8sYUFBYTtBQUFBLElBQzFDLEVBQUUzRixPQUFPLGFBQWEyRixPQUFPLGFBQWE7QUFBQSxJQUMxQyxFQUFFM0YsT0FBTyxZQUFZMkYsT0FBTyxZQUFZO0FBQUEsSUFDeEMsRUFBRTNGLE9BQU8sVUFBVTJGLE9BQU8sU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTUMscUJBQXFCQSxDQUFDNUYsVUFBVTtBQUNyQ2xCLHFCQUFpQmtCLEtBQUs7QUFFdEJaLHVCQUFtQixLQUFLO0FBRXhCLFVBQU15RyxRQUFRLG9CQUFJbkgsS0FBSztBQUN2QixVQUFNb0gsYUFBYUEsQ0FBQ0MsU0FBU0EsS0FBS0MsbUJBQW1CLE9BQU87QUFFNUQsUUFBSWhHLFVBQVUsU0FBUztBQUNyQixZQUFNd0QsWUFBWXNDLFdBQVdELEtBQUs7QUFDbEM3RywwQkFBb0J3RSxTQUFTO0FBQzdCdEUsd0JBQWtCc0UsU0FBUztBQUFBLElBQzdCLFdBQVd4RCxVQUFVLGFBQWE7QUFDaEMsWUFBTWlHLFlBQVksSUFBSXZILEtBQUttSCxLQUFLO0FBQ2hDSSxnQkFBVUMsUUFBUUQsVUFBVUUsUUFBUSxJQUFJLENBQUM7QUFDekMsWUFBTTNDLFlBQVlzQyxXQUFXRyxTQUFTO0FBQ3RDakgsMEJBQW9Cd0UsU0FBUztBQUM3QnRFLHdCQUFrQnNFLFNBQVM7QUFBQSxJQUM3QixXQUFXeEQsVUFBVSxhQUFhO0FBQ2hDLFlBQU1vRyxRQUFRLElBQUkxSCxLQUFLbUgsTUFBTVEsWUFBWSxHQUFHUixNQUFNUyxTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUk3SCxLQUFLbUgsTUFBTVEsWUFBWSxHQUFHUixNQUFNUyxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFdEgsMEJBQW9COEcsV0FBV00sS0FBSyxDQUFDO0FBQ3JDbEgsd0JBQWtCNEcsV0FBV1MsR0FBRyxDQUFDO0FBQUEsSUFDbkMsV0FBV3ZHLFVBQVUsYUFBYTtBQUNoQyxZQUFNb0csUUFBUSxJQUFJMUgsS0FBS21ILE1BQU1RLFlBQVksR0FBR1IsTUFBTVMsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNuRSxZQUFNQyxNQUFNLElBQUk3SCxLQUFLbUgsTUFBTVEsWUFBWSxHQUFHUixNQUFNUyxTQUFTLEdBQUcsQ0FBQztBQUM3RHRILDBCQUFvQjhHLFdBQVdNLEtBQUssQ0FBQztBQUNyQ2xILHdCQUFrQjRHLFdBQVdTLEdBQUcsQ0FBQztBQUFBLElBQ25DLFdBQVd2RyxVQUFVLFlBQVk7QUFDL0IsWUFBTW9HLFFBQVEsSUFBSTFILEtBQUttSCxNQUFNUSxZQUFZLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQU1FLE1BQU0sSUFBSTdILEtBQUttSCxNQUFNUSxZQUFZLEdBQUcsSUFBSSxFQUFFO0FBQ2hEckgsMEJBQW9COEcsV0FBV00sS0FBSyxDQUFDO0FBQ3JDbEgsd0JBQWtCNEcsV0FBV1MsR0FBRyxDQUFDO0FBQUEsSUFDbkMsV0FBV3ZHLFVBQVUsVUFBVTtBQUM3QloseUJBQW1CLElBQUk7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxVQUFPLFlBQVUsUUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQjtBQUFBLElBQ2xCLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUVSLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSwrQkFBOEIsc0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRU8sdUJBQUMsU0FBSSxXQUFVLDRFQUNwQjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSx1Q0FBc0MsK0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1FO0FBQUEsY0FDbkUsdUJBQUMsU0FBTSxXQUFVLDJCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGlCQUYxQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DaUIsdUJBQWFNLGlCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RTtBQUFBLFlBQzVFLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIscUNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStEO0FBQUEsZUFOakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLHVDQUFzQyxvQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0U7QUFBQSxjQUN4RSx1QkFBQyxTQUFNLFdBQVUsMkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdDO0FBQUEsaUJBRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0NOLHVCQUFhSyxrQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLG9DQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLGVBTmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSx1Q0FBc0MsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFO0FBQUEsY0FDaEUsdUJBQUMsUUFBSyxXQUFVLDZCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGlCQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DTCx1QkFBYUksa0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsWUFDN0UsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qix1Q0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQSxlQU5uRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRTtBQUFBLGNBQ2hFLHVCQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEM7QUFBQSxpQkFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLG1DQUNWSix1QkFBYUcsY0FBY2dHLFNBQVMsSUFBSW5HLFlBQVlHLGNBQWMsQ0FBQyxHQUFHaUcsZ0JBQWdCLFNBRHpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDVnBHLHVCQUFhRyxjQUFjZ0csU0FBUyxJQUFJLEdBQUduRyxZQUFZRyxjQUFjLENBQUMsRUFBRTZCLFlBQVksWUFBWSx1QkFEbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBdENLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1Q1A7QUFBQSxRQUVJLHVCQUFDLFNBQUksV0FBVSxpQkFHYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpSEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2SDtBQUFBLFVBRTdILHVCQUFDLFNBQUksV0FBVSw0SkFLYixpQ0FBQyxTQUFJLFdBQVUsbURBR2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2Q0FBNEMsNkJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDO0FBQUEsa0JBQ0EsdUJBQXVCO0FBQUEsa0JBQ3ZCLFVBQVV1RDtBQUFBQSxrQkFDVixPQUFPL0c7QUFBQUEsa0JBQ1AsYUFBWTtBQUFBLGtCQUNaLGNBQWMsQ0FBQzZILE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsa0JBRWpDLFdBQVU7QUFBQSxrQkFFVHBCLHVCQUFhakM7QUFBQUEsb0JBQUksQ0FBQ3VELFNBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUErQixPQUFPQSxLQUFLaEgsT0FDekNnSCxlQUFLckIsU0FEWXFCLEtBQUtoSCxPQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkE7QUFBQSxpQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxZQUdDYixtQkFDQyxtQ0FDRTtBQUFBLHFDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDZDQUE0Qyx5QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPSjtBQUFBQSxvQkFDUCxVQUFVLENBQUNtRSxNQUFNbEUsb0JBQW9Ca0UsRUFBRStELE9BQU9qSCxLQUFLO0FBQUEsb0JBQ25ELFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXdUI7QUFBQSxtQkFmekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDZDQUE0Qyx1QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPZjtBQUFBQSxvQkFDUCxVQUFVLENBQUNpRSxNQUFNaEUsa0JBQWtCZ0UsRUFBRStELE9BQU9qSCxLQUFLO0FBQUEsb0JBQ2pELFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXdUI7QUFBQSxtQkFmekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkF0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1Q0E7QUFBQSxlQXZFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBFQSxLQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdGQTtBQUFBLGFBckZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzRkE7QUFBQSxRQUdVLHVCQUFDLFNBQUksV0FBVSxpREFDdkIsaUNBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHVDQUFzQyx3Q0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxVQUU1RSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2IsaUNBQUMsV0FBTSxXQUFVLFVBQ2Y7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FDZixpQ0FBQyxRQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLGtGQUFpRixxQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0c7QUFBQSxjQUNwRyx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLHdCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RztBQUFBLGNBQ3ZHLHVCQUFDLFFBQUcsV0FBVSxrRkFBaUYsMEJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlHO0FBQUEsY0FDekcsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRixzQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUc7QUFBQSxjQUNyRyx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLGlDQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnSDtBQUFBLGNBQ2hILHVCQUFDLFFBQUcsV0FBVSxrRkFBaUYscUJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9HO0FBQUEsaUJBTnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ2RLLHNCQUFZRyxlQUFlMEcsTUFBTSxHQUFHLENBQUMsR0FBR3pEO0FBQUFBLGNBQUksQ0FBQ1QsVUFBVXlDLFFBQ3RELHVCQUFDLFFBQXFCLFdBQVUscUJBQzlCO0FBQUEsdUNBQUMsUUFBRyxXQUFVLCtCQUNaLGlDQUFDLFNBQUksV0FBVSxxQkFDYixpQ0FBQyxTQUFJLFdBQVUsbUZBQ2IsaUNBQUMsVUFBSyxXQUFVLDZCQUE2QkEsZ0JBQU0sS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUQsS0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHFEQUFxRHpDLG1CQUFTeUQsaUJBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBGO0FBQUEsZ0JBQzFGLHVCQUFDLFFBQUcsV0FBVSxxREFBcUR6RCxtQkFBU21FLGNBQWMsV0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0c7QUFBQSxnQkFDbEcsdUJBQUMsUUFBRyxXQUFVLCtCQUNaLGlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSxxQ0FBcUNuRSxtQkFBU1gsZ0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJFO0FBQUEsa0JBQzNFLHVCQUFDLFVBQUssV0FBVSw4QkFBNkIsbUJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdEO0FBQUEscUJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHFEQUFxRFcsbUJBQVNGLGdCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RjtBQUFBLGdCQUN6Rix1QkFBQyxRQUFHLFdBQVUsK0JBQ1hFO0FBQUFBLDJCQUFTWCxlQUFlLE9BQ3ZCLHVCQUFDLFVBQUssV0FBVSw0Q0FDZDtBQUFBLDJDQUFDLGNBQVcsV0FBVSxrQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0M7QUFBQSxvQkFBRztBQUFBLHVCQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBRURXLFNBQVNYLGVBQWUsT0FDdkIsdUJBQUMsVUFBSyxXQUFVLDBDQUNkO0FBQUEsMkNBQUMsY0FBVyxXQUFVLDZCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQztBQUFBLG9CQUFHO0FBQUEsdUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFFRFcsU0FBU29FLFVBQVUsVUFDbEIsdUJBQUMsVUFBSyxXQUFVLDJDQUNkO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDJDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVEO0FBQUEsb0JBQU07QUFBQSx1QkFEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLG1CQXBDT3BFLFNBQVNxRSxJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFDQTtBQUFBLFlBQ0QsS0F4Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5Q0E7QUFBQSxlQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFEQSxLQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVEQTtBQUFBLGFBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyRGQsS0E1RHNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2RHBCO0FBQUEsUUFFTSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtDQUFpQyx3QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUUxRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osdUJBQXVCO0FBQUEsZ0JBQ3ZCO0FBQUEsZ0JBQ0Esa0JBQWlCO0FBQUEsZ0JBQ2pCLGNBQWMsQ0FBQ1gsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsT0FBTy9JLGNBQWN1SjtBQUFBQSxnQkFDckIsVUFBVSxDQUFDdEgsVUFBVTtBQUNuQmhDLGdDQUFjZ0MsS0FBSztBQUNuQjFCLGlDQUFlLEVBQUU7QUFFakIsc0JBQUkwQixPQUFPO0FBQ1RtRCx1Q0FBbUJuRCxLQUFLO0FBQ3hCdUQsc0NBQWtCdkQsS0FBSztBQUFBLGtCQUN6QjtBQUFBLGdCQUNGO0FBQUEsZ0JBRUNuQyxvQkFBVTRGO0FBQUFBLGtCQUFJLENBQUM4RCxNQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxFQUFFM0QsS0FDakMyRDtBQUFBQSxzQkFBRUM7QUFBQUEsb0JBQVU7QUFBQSxvQkFBSUQsRUFBRUU7QUFBQUEsdUJBRERGLEVBQUUzRCxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBM0JIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTRCQTtBQUFBLGVBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0NBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHNCQUFxQix5QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0M7QUFBQSxZQUMvQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsT0FBTzNGO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2lGLE1BQU1oRixZQUFZZ0YsRUFBRStELE9BQU9qSCxLQUFLO0FBQUE7QUFBQSxjQUo3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJK0M7QUFBQSxlQU5qRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHNCQUFxQix1QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUM3QztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsT0FBTzdCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQytFLE1BQU05RSxVQUFVOEUsRUFBRStELE9BQU9qSCxLQUFLO0FBQUE7QUFBQSxjQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJNkM7QUFBQSxlQU4vQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUzRFO0FBQUFBLGNBQ1QsVUFBVXJHO0FBQUFBLGNBQ1YsV0FBVyxxQkFDVEEsWUFDSSxnQkFDQSwwQ0FBMEM7QUFBQSxjQUcvQ0Esc0JBQVksa0JBQWtCO0FBQUE7QUFBQSxZQVRqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrRUE7QUFBQSxRQUVDUixjQUNDLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPc0IsUUFBUUc7QUFBQUE7QUFBQUEsWUFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRXFDO0FBQUEsVUFFckM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU9ILFFBQVFJO0FBQUFBO0FBQUFBLFlBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUV1QztBQUFBLFVBRXZDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPSixRQUFRTTtBQUFBQTtBQUFBQSxZQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFdUM7QUFBQSxhQVh6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUlENUIsY0FDQyx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsc0JBQXFCLG9DQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLFVBRXZELHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUEsZ0JBQ1YsT0FBTzZDO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ3NDLE1BQU1yQyxnQkFBZ0JxQyxFQUFFK0QsT0FBT2pILEtBQUs7QUFBQTtBQUFBLGNBTGpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUttRDtBQUFBLFlBR25EO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU9jO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ29DLE1BQU1uQyxjQUFjbUMsRUFBRStELE9BQU9qSCxLQUFLO0FBQUEsZ0JBRTdDO0FBQUEseUNBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlCO0FBQUEsa0JBQ3pCLHVCQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QjtBQUFBLGtCQUN6Qix1QkFBQyxZQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQTtBQUFBO0FBQUEsY0FQN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxZQUVDYyxlQUFlLFVBQ2Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFDVixPQUFPLEtBQUtFLFlBQVk7QUFBQTtBQUFBLGNBSDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUc2QjtBQUFBLFlBSS9CO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUEsZ0JBQ1YsT0FBT0U7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDZ0MsTUFBTS9CLGNBQWMrQixFQUFFK0QsT0FBT2pILEtBQUs7QUFBQTtBQUFBLGNBTC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtpRDtBQUFBLGVBaENuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtDQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVVYLFFBQVFLLGtCQUFrQjtBQUFBLGNBQ3BDLFNBQVMwRjtBQUFBQSxjQUNULFdBQVcsMEJBQ1QvRixRQUFRSyxrQkFBa0IsSUFDdEIsbUNBQ0EseUJBQXlCO0FBQUEsY0FDNUI7QUFBQTtBQUFBLFlBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0RBO0FBQUEsUUFJRHJCLFlBQVltSSxTQUFTLEtBQUssQ0FBQ2pJLFlBQzFCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFBVSxTQUFTaUg7QUFBQUEsWUFBZSxNQUFNbkg7QUFBQUEsWUFBYSxpQkFBZ0I7QUFBQSxZQUM3RCxrQkFBa0I7QUFBQTtBQUFBLFVBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUNrRCxJQUVsRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLE1BQUs7QUFBQSxZQUNMLFNBQVMsQ0FBQ0UsYUFBYUYsWUFBWW1JLFdBQVc7QUFBQTtBQUFBLFVBSGhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdrRDtBQUFBLFdBMVZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNlZBO0FBQUEsU0FoV0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlXQTtBQUFBLE9BbldGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvV0E7QUFFSjtBQUFFNUksR0Fub0JJRCxpQkFBZTtBQUFBK0osS0FBZi9KO0FBcW9CTixNQUFNZ0ssY0FBY0EsQ0FBQyxFQUFFaEMsT0FBTzNGLE1BQU0sTUFDbEMsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEseUJBQUMsT0FBRSxXQUFVLHlCQUF5QjJGLG1CQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTRDO0FBQUEsRUFDNUMsdUJBQUMsT0FBRSxXQUFVLDhCQUE4QjNGLG1CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlEO0FBQUEsS0FGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUdBO0FBQ0E0SCxNQUxJRDtBQU9OLGVBQWVoSztBQUFnQixJQUFBK0osSUFBQUU7QUFBQUMsYUFBQUgsSUFBQTtBQUFBRyxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwiYXBpIiwiRGF0YVRhYmxlIiwiU2VsZWN0IiwiVGFibGUiLCJDaGVja2JveCIsIm1lc3NhZ2UiLCJOYXZiYXIiLCJDaXJjdWxhckxvYWRlciIsIlNldHRpbmdTaWRlYmFyIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJoZWFkZXIiLCJTaWRlYmFyIiwiU2VhcmNoIiwiQ2FsZW5kYXIiLCJBd2FyZCIsIlRyZW5kaW5nVXAiLCJTdGFyIiwiR2lmdCIsIlRyb3BoeSIsIlVzZXJzIiwiQ3VzdG9tZXJSZXdhcmRzIiwiX3MiLCJjdXN0b21lcnMiLCJzZXRDdXN0b21lcnMiLCJjdXN0b21lcklkIiwic2V0Q3VzdG9tZXJJZCIsImZyb21EYXRlIiwic2V0RnJvbURhdGUiLCJ0b0RhdGUiLCJzZXRUb0RhdGUiLCJyZXdhcmRUYWJsZSIsInNldFJld2FyZFRhYmxlIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwidG9kYXlTdHJpbmciLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInNlbGVjdGVkTGFiZWwiLCJzZXRTZWxlY3RlZExhYmVsIiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZFRvRGF0ZSIsInNldFNlbGVjdGVkVG9EYXRlIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwic3VtbWFyeSIsInNldFN1bW1hcnkiLCJwb2ludF92YWx1ZSIsInRvdGFsX2Vhcm5lZF9wb2ludHMiLCJ0b3RhbF9yZWRlZW1lZF9wb2ludHMiLCJiYWxhbmNlX3BvaW50cyIsInRvdGFsX3JlZGVlbWVkX2Ftb3VudCIsInN1bV9wcmV2aW91c19lYXJuZWRfcG9pbnRzIiwic3VtX3ByZXZpb3VzX3JlZGVlbWVkX3BvaW50cyIsImhhbmRsZUFudElucHV0RFNlbGVjdCIsImZpZWxkIiwidmFsdWUiLCJzZXRVcGRhdGVGb3JtRGF0YSIsInByZXZEYXRhIiwic2V0RXJyb3JzIiwiZXJyb3JzIiwicmV3YXJkU3RhdGUiLCJzZXRSZXdhcmRTdGF0ZSIsInJld2FyZHMiLCJhY3RpdmVSZXdhcmRzIiwidG90YWxQb2ludHNBbGwiLCJ0b3RhbEFtb3VudEFsbCIsInRvdGFsRW1wbHllZXMiLCJyZWRlZW1Qb2ludHMiLCJzZXRSZWRlZW1Qb2ludHMiLCJyZWRlZW1UeXBlIiwic2V0UmVkZWVtVHlwZSIsInJlZGVlbUFtb3VudCIsInNldFJlZGVlbUFtb3VudCIsInJlZGVlbURlc2MiLCJzZXRSZWRlZW1EZXNjIiwiZmV0Y2hDdXN0b21lcnMiLCJyZXMiLCJnZXQiLCJkYXRhIiwiY29uc29sZSIsImVycm9yIiwiZmV0Y2hEYXRhIiwiZW1wbG95ZWVSZXMiLCJlbXBSZXdhcmRzUmVzIiwiUHJvbWlzZSIsImFsbCIsImxvZyIsImNvdW50IiwicmV3YXJkRGF0YSIsImZpbHRlcmVkIiwiZmlsdGVyIiwiaXRlbSIsInRvdGFsX3BvaW50cyIsInNvcnRlZCIsInNvcnQiLCJhIiwiYiIsInRvdGFsUG9pbnRzIiwicmVkdWNlIiwic3VtIiwidG90YWxBbW91bnQiLCJ0b3RhbF9hbW91bnQiLCJzZXRFbXBsb3llZXMiLCJlbXBsb3llZSIsInNldFJld2FyZHMiLCJlIiwiZmV0Y2hSZXdhcmRTdW1tYXJ5IiwiY3VzdElkIiwic3VjY2VzcyIsImVyciIsImZldGNoUmV3YXJkUG9pbnRzIiwiZm9ybWF0dGVkIiwibWFwIiwicmV3YXJkIiwiaW5kZXgiLCJfaWQiLCJzbE5vIiwiY3VzdG9tZXJOYW1lIiwiY3VzdG9tZXJfbmFtZSIsInBob25lIiwiY3VzdG9tZXJfcGhvbmUiLCJncm91cE5hbWUiLCJncm91cF9uYW1lIiwic291cmNlVHlwZSIsInNvdXJjZV90eXBlIiwicmV3YXJkUG9pbnRzIiwicmV3YXJkX3BvaW50cyIsInJld2FyZEFtb3VudCIsInJld2FyZGVkX2Ftb3VudCIsInN0YXR1cyIsInJlbWFya3MiLCJjcmVhdGVSZXdhcmRQb2ludHMiLCJhbGVydCIsInBvc3QiLCJjdXN0b21lcl9pZCIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJyZXNwb25zZSIsIk51bWJlciIsInJlZGVlbVJld2FyZFBvaW50cyIsInJlZGVlbV9wb2ludHMiLCJyZWRlbXB0aW9uX3R5cGUiLCJkZXNjcmlwdGlvbiIsInJld2FyZENvbHVtbnMiLCJrZXkiLCJncm91cE9wdGlvbnMiLCJsYWJlbCIsImhhbmRsZVNlbGVjdEZpbHRlciIsInRvZGF5IiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInN0YXJ0IiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImVuZCIsImxlbmd0aCIsImVtcGxveWVlX25hbWUiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidGltZSIsInRhcmdldCIsInNsaWNlIiwiZGVwYXJ0bWVudCIsInRyZW5kIiwiaWQiLCJ1bmRlZmluZWQiLCJjIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiX2MiLCJTdW1tYXJ5Q2FyZCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDdXN0b21lclJld2FyZHMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIFRhYmxlLCBDaGVja2JveCwgbWVzc2FnZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IFNldHRpbmdTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2V0dGluZ1NpZGViYXJcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgeyBoZWFkZXIgfSBmcm9tIFwiZnJhbWVyLW1vdGlvbi9jbGllbnRcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IFNlYXJjaCwgQ2FsZW5kYXIsIEF3YXJkLCBUcmVuZGluZ1VwLCBTdGFyLCBHaWZ0LCBUcm9waHksIFVzZXJzIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcclxuXHJcbi8vIGNvbnN0IEN1c3RvbWVyUmV3YXJkcyA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbc2NyZWVuTG9hZGluZywgc2V0U2NyZWVuTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuLy8gICBjb25zdCBbZ3JvdXBGaWx0ZXIsIHNldEdyb3VwRmlsdGVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW3JlY2VpdmVkUmV3YXJkLCBzZXRSZWNlaXZlZFJld2FyZF0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2dyb3VwT3B0aW9ucywgc2V0R3JvdXBPcHRpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbZW5yb2xsSWQsIHNldEVucm9sbElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgICAgY29uc3QgW1RhYmxlRW5yb2xsc0RhdGUsIHNldFRhYmxlRW5yb2xsc0RhdGVdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuLy8gICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4vLyAgICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbi8vICAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4vLyAgICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuLy8gICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hHcm91cCA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9ncm91cC9nZXQtZ3JvdXAtYWRtaW5gKTtcclxuLy8gICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZS5kYXRhLCBcInJlc3BqbnNlIGhkaGFraGFramhhXCIpO1xyXG4vLyAgICAgICAgIHNldEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5hYmxlIHRvIGZldGNoIGVucm9sbCBkYXRhOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcblxyXG4vLyAgICAgZmV0Y2hHcm91cCgpO1xyXG4vLyAgIH0sIFtdKTtcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hDdXN0b21lclJld2FyZHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgc2V0U2NyZWVuTG9hZGluZyh0cnVlKTtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbi8vICAgICAgICAgICBgL2Vucm9sbC9yZXdhcmQvc3RhdHVzLyR7Z3JvdXBGaWx0ZXJ9YFxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlPy5kYXRhPy5yZXdhcmQsIFwiaGdzaGpmZ2hzamtmZ2hqa3NmZ2hqa3NmZ2hcIik7XHJcblxyXG4vLyAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZT8uZGF0YT8ucmV3YXJkPy5tYXAoKGdpZnQsIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAgICAgaWQ6IGdpZnQ/Ll9pZCxcclxuLy8gICAgICAgICAgIHNsbm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIGdyb3VwTmFtZTogZ2lmdD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICB1c2VyTmFtZTogZ2lmdD8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgdGlja2V0czogZ2lmdD8udGlja2V0cyB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIGdpZnRSZWNlaXZlZDogZ2lmdD8uZ2lmdF9yZWNlaXZlZCB8fCBmYWxzZSxcclxuLy8gICAgICAgICB9KSk7XHJcbi8vICAgICAgICAgY29uc29sZS5pbmZvKGZvcm1hdHRlZERhdGEsIFwia2tra2tra2traGZzZGpoZmJkc2poZnNqaGRmdlwiKVxyXG5cclxuLy8gICAgICAgICBzZXRSZWNlaXZlZFJld2FyZChmb3JtYXR0ZWREYXRhKTtcclxuLy8gICAgICAgICBzZXRUYWJsZUVucm9sbHNEYXRlKGZvcm1hdHRlZERhdGEpO1xyXG5cclxuLy8gICAgICAgICAvLyBQb3B1bGF0ZSBncm91cCBmaWx0ZXJzXHJcbi8vICAgICAgICAgY29uc3QgdW5pcXVlR3JvdXBzID0gW1xyXG4vLyAgICAgICAgICAgLi4ubmV3IFNldChmb3JtYXR0ZWREYXRhLm1hcCgoaXRlbSkgPT4gaXRlbS5ncm91cE5hbWUpKSxcclxuLy8gICAgICAgICBdO1xyXG4vLyAgICAgICAgIHNldEdyb3VwT3B0aW9ucyh1bmlxdWVHcm91cHMpO1xyXG5cclxuLy8gICAgICAgICAvLyAvLyBUb3RhbHNcclxuLy8gICAgICAgICAvLyBjb25zdCByZWNlaXZlZCA9IGZvcm1hdHRlZERhdGEuZmlsdGVyKChyKSA9PiByLmdpZnRSZWNlaXZlZCkubGVuZ3RoO1xyXG4vLyAgICAgICAgIC8vIGNvbnN0IHBlbmRpbmcgPSBmb3JtYXR0ZWREYXRhLmxlbmd0aCAtIHJlY2VpdmVkO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJVbmFibGUgdG8gZmV0Y2ggcmV3YXJkczpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCByZXdhcmQgZGF0YVwiKTtcclxuLy8gICAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgICBzZXRTY3JlZW5Mb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuXHJcbi8vICAgICBmZXRjaEN1c3RvbWVyUmV3YXJkcygpO1xyXG4vLyAgIH0sIFtncm91cEZpbHRlcl0pO1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVDaGVja2JveENoYW5nZSA9IGFzeW5jIChpZCwgY2hlY2tlZCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgYXdhaXQgYXBpLnB1dChgL2Vucm9sbC91cGRhdGUtcmV3YXJkLWdpZnQtc3RhdHVzLyR7aWR9YCwge1xyXG4vLyAgICAgICAgIGdpZnRfcmVjZWl2ZWQ6IGNoZWNrZWQsXHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgc2V0UmVjZWl2ZWRSZXdhcmQoKHByZXYpID0+XHJcbi8vICAgICAgICAgcHJldi5tYXAoKGl0ZW0pID0+XHJcbi8vICAgICAgICAgICBpdGVtLmlkID09PSBpZCA/IHsgLi4uaXRlbSwgZ2lmdFJlY2VpdmVkOiBjaGVja2VkIH0gOiBpdGVtXHJcbi8vICAgICAgICAgKVxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgbWVzc2FnZS5zdWNjZXNzKGBHaWZ0IG1hcmtlZCBhcyAke2NoZWNrZWQgPyBcIlJlY2VpdmVkXCIgOiBcIlBlbmRpbmdcIn1gKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIGdpZnQgc3RhdHVzOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJVbmFibGUgdG8gdXBkYXRlIGdpZnQgc3RhdHVzXCIpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyBjb25zdCBnaWZ0Q29sdW1ucyA9IFtcclxuLy8gICB7IGtleTogXCJzbG5vXCIsIGhlYWRlcjogXCJTTC4gTm9cIiB9LFxyXG4vLyAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbi8vICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIlVzZXIgTmFtZVwiIH0sXHJcbi8vICAgeyBrZXk6IFwidGlja2V0c1wiLCBoZWFkZXI6IFwiVGlja2V0c1wiIH0sXHJcbi8vICAgIHtcclxuXHJcbi8vICAgICBrZXk6IFwiZ2lmdFJlY2VpdmVkXCIsXHJcbi8vICAgICByZW5kZXI6IChfLCByZWNvcmQpID0+IChcclxuLy8gICAgICAgPENoZWNrYm94XHJcbi8vICAgICAgICAgY2hlY2tlZD17cmVjb3JkLmdpZnRSZWNlaXZlZH1cclxuLy8gICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoZWNrYm94Q2hhbmdlKHJlY29yZC5pZCwgZS50YXJnZXQuY2hlY2tlZCl9XHJcbi8vICAgICAgIC8+XHJcbi8vICAgICApLFxyXG4vLyAgICAgaGVhZGVyOiBcIkNoZWNrQm94XCJcclxuLy8gICB9LFxyXG4vLyBdO1xyXG5cclxuLy8gICBjb25zdCBmaWx0ZXJlZFJld2FyZHMgPSByZWNlaXZlZFJld2FyZC5maWx0ZXIoKHJld2FyZCkgPT4ge1xyXG4vLyAgICAgcmV0dXJuIGdyb3VwRmlsdGVyID8gcmV3YXJkLmdyb3VwTmFtZSA9PT0gZ3JvdXBGaWx0ZXIgOiB0cnVlO1xyXG4vLyAgIH0pO1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlblwiPlxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMzBcIj5cclxuLy8gICAgICAgICA8TmF2YmFyXHJcbi8vICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuLy8gICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbi8vICAgICAgICAgLz5cclxuLy8gICAgICAgICA8U2V0dGluZ1NpZGViYXIgLz5cclxuLy8gICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuLy8gICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbi8vICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbi8vICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4vLyAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuLy8gICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKVxyXG4vLyAgICAgICAgICAgfVxyXG4vLyAgICAgICAgIC8+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkluc3VyYW5jZTwvaDE+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICB7c2NyZWVuTG9hZGluZyA/IChcclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgY29sb3I9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbi8vICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgUmVwb3J0cyAtIEN1c3RvbWVyIFJld2FyZHNcclxuLy8gICAgICAgICAgICAgICA8L2gxPlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogRmlsdGVycyAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBHcm91cCBGaWx0ZXJcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAyMDAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiLS1BbGwgZ3JvdXBzLS1cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0R3JvdXBGaWx0ZXIodmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwRmlsdGVyIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cD8uX2lkfSB2YWx1ZT17Z3JvdXA/Ll9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwPy5ncm91cF9uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgICB7LyogU3VtbWFyeSBDYXJkcyAqL31cclxuXHJcbi8vICAgICAgICAgICAgICAgICB7LyogRGF0YSBUYWJsZSAqL31cclxuLy8gICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuLy8gICBjb2x1bW5zPXtnaWZ0Q29sdW1uc31cclxuLy8gICBkYXRhPXtUYWJsZUVucm9sbHNEYXRlfVxyXG4vLyAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICl9XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbi8vIGNvbnN0IEN1c3RvbWVyUmV3YXJkcyA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbc2NyZWVuTG9hZGluZywgc2V0U2NyZWVuTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuLy8gICBjb25zdCBbZ3JvdXBGaWx0ZXIsIHNldEdyb3VwRmlsdGVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW3JlY2VpdmVkUmV3YXJkLCBzZXRSZWNlaXZlZFJld2FyZF0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbi8vICAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuLy8gICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4vLyAgICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbi8vICAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4vLyAgICAgdHlwZTogXCJpbmZvXCIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIC8vIEZldGNoIGdyb3Vwc1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEdyb3VwID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2dyb3VwL2dldC1ncm91cC1hZG1pbmApO1xyXG4vLyAgICAgICAgIHNldEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5hYmxlIHRvIGZldGNoIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuLy8gICAgIGZldGNoR3JvdXAoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8vIEZldGNoIHJld2FyZCBkYXRhXHJcbi8vICAgLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgIC8vICAgICBjb25zdCBmZXRjaEN1c3RvbWVyUmV3YXJkcyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAvLyAgICAgICB0cnkge1xyXG4vLyAgIC8vICAgICAgICAgc2V0U2NyZWVuTG9hZGluZyh0cnVlKTtcclxuLy8gICAvLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2Vucm9sbC9yZXdhcmQvc3RhdHVzLyR7Z3JvdXBGaWx0ZXJ9YCk7XHJcblxyXG4vLyAgIC8vICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlPy5kYXRhPy5yZXdhcmQ/Lm1hcCgoZ2lmdCwgaW5kZXgpID0+ICh7XHJcbi8vICAgLy8gICAgICAgICAgIF9pZDogZ2lmdD8uX2lkLFxyXG4vLyAgIC8vICAgICAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4vLyAgIC8vICAgICAgICAgICBncm91cE5hbWU6IGdpZnQ/Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgICAgICBncm91cEluc3RhbGxNZW50OiBnaWZ0Py5ncm91cF9pZD8uZ3JvdXBfaW5zdGFsbG1lbnQgfHwgXCItXCIsXHJcbi8vICAgLy8gICAgICAgICAgIHBheW1lbnRUeXBlOiBnaWZ0Py5wYXltZW50X3R5cGUsXHJcbi8vICAgLy8gICAgICAgICAgIHVzZXJOYW1lOiBnaWZ0Py51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbi8vICAgLy8gICAgICAgICAgIHRpY2tldHM6IGdpZnQ/LnRpY2tldHMgfHwgXCItXCIsXHJcbi8vICAgLy8gICAgICAgICAgIGdpZnRSZWNlaXZlZDogZ2lmdD8uZ2lmdF9yZWNlaXZlZCB8fCBmYWxzZSxcclxuLy8gICAvLyAgICAgICAgIH0pKTtcclxuXHJcbi8vICAgLy8gICAgICAgICBzZXRSZWNlaXZlZFJld2FyZChmb3JtYXR0ZWREYXRhKTtcclxuXHJcbi8vICAgLy8gICAgICAgICAvLyBpbml0aWFsaXplIGFjdGl2ZVVzZXJEYXRhIG1hcFxyXG4vLyAgIC8vICAgICAgICAgY29uc3QgYWN0aXZlTWFwID0ge307XHJcbi8vICAgLy8gICAgICAgICBmb3JtYXR0ZWREYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuLy8gICAvLyAgICAgICAgICAgYWN0aXZlTWFwW2l0ZW0uX2lkXSA9IHtcclxuLy8gICAvLyAgICAgICAgICAgICBpbmZvOiB7XHJcbi8vICAgLy8gICAgICAgICAgICAgICBzdGF0dXM6IGl0ZW0uZ2lmdFJlY2VpdmVkLFxyXG4vLyAgIC8vICAgICAgICAgICAgIH0sXHJcbi8vICAgLy8gICAgICAgICAgIH07XHJcbi8vICAgLy8gICAgICAgICB9KTtcclxuLy8gICAvLyAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKGFjdGl2ZU1hcCk7XHJcbi8vICAgLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAvLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJVbmFibGUgdG8gZmV0Y2ggcmV3YXJkczpcIiwgZXJyb3IpO1xyXG4vLyAgIC8vICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBsb2FkIHJld2FyZCBkYXRhXCIpO1xyXG4vLyAgIC8vICAgICAgIH0gZmluYWxseSB7XHJcbi8vICAgLy8gICAgICAgICBzZXRTY3JlZW5Mb2FkaW5nKGZhbHNlKTtcclxuLy8gICAvLyAgICAgICB9XHJcbi8vICAgLy8gICAgIH07XHJcblxyXG4vLyAgIC8vICAgICBmZXRjaEN1c3RvbWVyUmV3YXJkcygpO1xyXG4vLyAgIC8vICAgfSwgW2dyb3VwRmlsdGVyXSk7XHJcblxyXG4vLyAgIC8vIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgLy8gICBjb25zdCBmZXRjaEN1c3RvbWVyUmV3YXJkcyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAvLyAgICAgdHJ5IHtcclxuLy8gICAvLyAgICAgICBzZXRTY3JlZW5Mb2FkaW5nKHRydWUpO1xyXG4vLyAgIC8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2Vucm9sbC9yZXdhcmQvc3RhdHVzLyR7Z3JvdXBGaWx0ZXJ9YCk7XHJcbi8vICAgLy8gICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlLmRhdGEucmV3YXJkLCBcImZ2ZHNqaGZ2amhzZGZ2amhzZGZ2XCIpO1xyXG4vLyAgIC8vICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZT8uZGF0YT8ucmV3YXJkPy5tYXAoKGdpZnQsIGluZGV4KSA9PiB7XHJcbi8vICAgLy8gICAgICAgICAvLyBsZXQgaW5zdGFsbG1lbnRWYWx1ZSA9IFwiLVwiO1xyXG5cclxuLy8gICAvLyAgICAgICAgIC8vIGlmIChnaWZ0Py5wYXltZW50X3R5cGUgPT09IFwiV2Vla2x5XCIpIHtcclxuLy8gICAvLyAgICAgICAgIC8vICAgaW5zdGFsbG1lbnRWYWx1ZSA9IGdpZnQ/Lmdyb3VwX2lkPy53ZWVrbHlfaW5zdGFsbG1lbnQgfHwgXCItXCI7XHJcbi8vICAgLy8gICAgICAgICAvLyB9IGVsc2UgaWYgKGdpZnQ/LnBheW1lbnRfdHlwZSA9PT0gXCJEYWlseVwiKSB7XHJcbi8vICAgLy8gICAgICAgICAvLyAgIGluc3RhbGxtZW50VmFsdWUgPSBnaWZ0Py5ncm91cF9pZD8uZGFpbHlfaW5zdGFsbG1lbnQgfHwgXCItXCI7XHJcbi8vICAgLy8gICAgICAgICAvLyB9IGVsc2UgaWYgKGdpZnQ/LnBheW1lbnRfdHlwZSA9PT0gXCJNb250aGx5XCIpIHtcclxuLy8gICAvLyAgICAgICAgIC8vICAgaW5zdGFsbG1lbnRWYWx1ZSA9IGdpZnQ/Lmdyb3VwX2lkPy5tb250aGx5X2luc3RhbGxtZW50IHx8IFwiLVwiO1xyXG4vLyAgIC8vICAgICAgICAgLy8gfSBlbHNlIHtcclxuLy8gICAvLyAgICAgICAgIC8vICAgaW5zdGFsbG1lbnRWYWx1ZSA9IGdpZnQ/Lmdyb3VwX2lkPy5ncm91cF9pbnN0YWxsbWVudCB8fCBcIi1cIjtcclxuLy8gICAvLyAgICAgICAgIC8vIH1cclxuXHJcbi8vICAgLy8gICAgICAgICByZXR1cm4ge1xyXG4vLyAgIC8vICAgICAgICAgICBfaWQ6IGdpZnQ/Ll9pZCxcclxuLy8gICAvLyAgICAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuLy8gICAvLyAgICAgICAgICAgZ3JvdXBOYW1lOiBnaWZ0Py5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIixcclxuLy8gICAvLyAgICAgICAgIC8vICBncm91cEluc3RhbGxNZW50OiBpbnN0YWxsbWVudFZhbHVlLFxyXG4vLyAgIC8vICAgICAgICAgICBwYWlkSW5zdGFsbG1lbnQ6IGdpZnQ/LnJlbWFpbmluZ19maXJzdF9pbnN0YWxsbWVudHMgfHwgXCJcIixcclxuLy8gICAvLyAgICAgICAgICAgcmVsZXNlR2lmdCA6IGdpZnQ/LnJlbGVhc2VfZ2lmdCB8fCBcIlwiLFxyXG4vLyAgIC8vICAgICAgICAgICBwYXltZW50VHlwZTogZ2lmdD8ucGF5bWVudF90eXBlLFxyXG4vLyAgIC8vICAgICAgICAgICB1c2VyTmFtZTogZ2lmdD8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgICAgICB0aWNrZXRzOiBnaWZ0Py50aWNrZXRzIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgICAgICBnaWZ0UmVjZWl2ZWQ6IGdpZnQ/LmdpZnRfcmVjZWl2ZWQgfHwgZmFsc2UsXHJcbi8vICAgLy8gICAgICAgICB9O1xyXG4vLyAgIC8vICAgICAgIH0pO1xyXG5cclxuLy8gICAvLyAgICAgICBzZXRSZWNlaXZlZFJld2FyZChmb3JtYXR0ZWREYXRhKTtcclxuXHJcbi8vICAgLy8gICAgICAgLy8gaW5pdGlhbGl6ZSBhY3RpdmVVc2VyRGF0YSBtYXBcclxuLy8gICAvLyAgICAgICBjb25zdCBhY3RpdmVNYXAgPSB7fTtcclxuLy8gICAvLyAgICAgICBmb3JtYXR0ZWREYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuLy8gICAvLyAgICAgICAgIGFjdGl2ZU1hcFtpdGVtLl9pZF0gPSB7XHJcbi8vICAgLy8gICAgICAgICAgIGluZm86IHtcclxuLy8gICAvLyAgICAgICAgICAgICBzdGF0dXM6IGl0ZW0uZ2lmdFJlY2VpdmVkLFxyXG4vLyAgIC8vICAgICAgICAgICB9LFxyXG4vLyAgIC8vICAgICAgICAgfTtcclxuLy8gICAvLyAgICAgICB9KTtcclxuLy8gICAvLyAgICAgICBzZXRBY3RpdmVVc2VyRGF0YShhY3RpdmVNYXApO1xyXG4vLyAgIC8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgIC8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJVbmFibGUgdG8gZmV0Y2ggcmV3YXJkczpcIiwgZXJyb3IpO1xyXG4vLyAgIC8vICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCByZXdhcmQgZGF0YVwiKTtcclxuLy8gICAvLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAvLyAgICAgICBzZXRTY3JlZW5Mb2FkaW5nKGZhbHNlKTtcclxuLy8gICAvLyAgICAgfVxyXG4vLyAgIC8vICAgfTtcclxuXHJcbi8vICAgLy8gICBmZXRjaEN1c3RvbWVyUmV3YXJkcygpO1xyXG4vLyAgIC8vIH0sIFtncm91cEZpbHRlcl0pO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hDdXN0b21lclJld2FyZHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgc2V0U2NyZWVuTG9hZGluZyh0cnVlKTtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9lbnJvbGwvcmV3YXJkL3N0YXR1cy8ke2dyb3VwRmlsdGVyfWApO1xyXG4vLyAgICAgICAgIGNvbnNvbGUuaW5mbyhyZXNwb25zZS5kYXRhLnJld2FyZCwgXCJmdmRzamhmdmpoc2Rmdmpoc2RmdlwiKTtcclxuXHJcbi8vICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlPy5kYXRhPy5yZXdhcmQubWFwKChnaWZ0LCBpbmRleCkgPT4gKHtcclxuLy8gICAgICAgICAgIF9pZDogZ2lmdD8uX2lkLFxyXG4vLyAgICAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIGdyb3VwTmFtZTogZ2lmdD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICByZW1haW5pbmdJbnN0YWxsbWVudDogZ2lmdD8ucmVtYWluaW5nX2ZpcnN0X2luc3RhbGxtZW50cyB8fCBcIlwiLFxyXG4vLyAgICAgICAgICAgcmVsZWFzZUdpZnQ6XHJcbi8vICAgICAgICAgICAgIGdpZnQ/LnJlbGVhc2VfZ2lmdCA9PT0gdHJ1ZSA/IFwiRWxpZ2libGVcIiA6IFwiTm90IEVsaWdpYmxlXCIsXHJcbi8vICAgICAgICAgICBUb3RhbFBhaWRBbW91bnQ6IGdpZnQ/LnRvdGFsX3BhaWRfYW1vdW50IHx8IFwiXCIsXHJcbi8vICAgICAgICAgICB1c2VyTmFtZTogZ2lmdD8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgdGlja2V0czogZ2lmdD8udGlja2V0cyB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIGdpZnRSZWNlaXZlZDogZ2lmdD8uZ2lmdF9yZWNlaXZlZCB8fCBmYWxzZSxcclxuLy8gICAgICAgICB9KSk7XHJcblxyXG4vLyAgICAgICAgIHNldFJlY2VpdmVkUmV3YXJkKGZvcm1hdHRlZERhdGEpO1xyXG5cclxuLy8gICAgICAgICBjb25zdCBhY3RpdmVNYXAgPSB7fTtcclxuLy8gICAgICAgICBmb3JtYXR0ZWREYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuLy8gICAgICAgICAgIGFjdGl2ZU1hcFtpdGVtLl9pZF0gPSB7XHJcbi8vICAgICAgICAgICAgIGluZm86IHtcclxuLy8gICAgICAgICAgICAgICBzdGF0dXM6IGl0ZW0uZ2lmdFJlY2VpdmVkLFxyXG4vLyAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgfTtcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YShhY3RpdmVNYXApO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJVbmFibGUgdG8gZmV0Y2ggcmV3YXJkczpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCByZXdhcmQgZGF0YVwiKTtcclxuLy8gICAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgICBzZXRTY3JlZW5Mb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuXHJcbi8vICAgICBmZXRjaEN1c3RvbWVyUmV3YXJkcygpO1xyXG4vLyAgIH0sIFtncm91cEZpbHRlcl0pO1xyXG5cclxuLy8gICAvLyBIYW5kbGUgaW5kaXZpZHVhbCBjaGVja2JveCBjaGFuZ2VcclxuLy8gICBjb25zdCBoYW5kbGVDaGVja2JveENoYW5nZSA9IGFzeW5jIChpZCwgY2hlY2tlZCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgYXdhaXQgYXBpLnB1dChgL2Vucm9sbC91cGRhdGUtcmV3YXJkLWdpZnQtc3RhdHVzLyR7aWR9YCwge1xyXG4vLyAgICAgICAgIGdpZnRfcmVjZWl2ZWQ6IGNoZWNrZWQsXHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgc2V0QWN0aXZlVXNlckRhdGEoKHByZXYpID0+ICh7XHJcbi8vICAgICAgICAgLi4ucHJldixcclxuLy8gICAgICAgICBbaWRdOiB7XHJcbi8vICAgICAgICAgICBpbmZvOiB7XHJcbi8vICAgICAgICAgICAgIHN0YXR1czogY2hlY2tlZCxcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgfSxcclxuLy8gICAgICAgfSkpO1xyXG5cclxuLy8gICAgICAgbWVzc2FnZS5zdWNjZXNzKGBHaWZ0IG1hcmtlZCBhcyAke2NoZWNrZWQgPyBcIlJlY2VpdmVkXCIgOiBcIlBlbmRpbmdcIn1gKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIGdpZnQgc3RhdHVzOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJVbmFibGUgdG8gdXBkYXRlIGdpZnQgc3RhdHVzXCIpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIEZpbHRlcmVkIHVzZXJzXHJcbi8vICAgY29uc3QgZmlsdGVyZWRSZXdhcmRzID0gdXNlTWVtbygoKSA9PiB7XHJcbi8vICAgICByZXR1cm4gcmVjZWl2ZWRSZXdhcmQubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gISFhY3RpdmVVc2VyRGF0YVtpdGVtLl9pZF0/LmluZm8/LnN0YXR1cztcclxuXHJcbi8vICAgICAgIHJldHVybiB7XHJcbi8vICAgICAgICAgLi4uaXRlbSxcclxuLy8gICAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4vLyAgICAgICAgIGNoZWNrQm94czogKFxyXG4vLyAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbi8vICAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbi8vICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hlY2tib3hDaGFuZ2UoaXRlbS5faWQsIGUudGFyZ2V0LmNoZWNrZWQpfVxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICApLFxyXG4vLyAgICAgICAgIGlzU2VsZWN0ZWQsXHJcbi8vICAgICAgIH07XHJcbi8vICAgICB9KTtcclxuLy8gICB9LCBbcmVjZWl2ZWRSZXdhcmQsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBpZiAoZmlsdGVyZWRSZXdhcmRzLmxlbmd0aCA+IDApIHtcclxuLy8gICAgICAgY29uc3QgYWxsU2VsZWN0ZWQgPSBmaWx0ZXJlZFJld2FyZHMuZXZlcnkoKGl0ZW0pID0+IGl0ZW0uaXNTZWxlY3RlZCk7XHJcbi8vICAgICAgIHNldFNlbGVjdEFsbChhbGxTZWxlY3RlZCk7XHJcbi8vICAgICB9IGVsc2Uge1xyXG4vLyAgICAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtmaWx0ZXJlZFJld2FyZHNdKTtcclxuXHJcbi8vICAgLy8gSGFuZGxlIHNlbGVjdCBhbGwgY2hlY2tib3hcclxuLy8gICBjb25zdCBoYW5kbGVTZWxlY3RBbGwgPSBhc3luYyAoY2hlY2tlZCkgPT4ge1xyXG4vLyAgICAgc2V0U2VsZWN0QWxsKGNoZWNrZWQpO1xyXG4vLyAgICAgY29uc3QgdXBkYXRlZCA9IHt9O1xyXG5cclxuLy8gICAgIGZvciAoY29uc3QgaXRlbSBvZiBmaWx0ZXJlZFJld2FyZHMpIHtcclxuLy8gICAgICAgdXBkYXRlZFtpdGVtLl9pZF0gPSB7IGluZm86IHsgc3RhdHVzOiBjaGVja2VkIH0gfTtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBhd2FpdCBhcGkucHV0KGAvZW5yb2xsL3VwZGF0ZS1yZXdhcmQtZ2lmdC1zdGF0dXMvJHtpdGVtLl9pZH1gLCB7XHJcbi8vICAgICAgICAgICBnaWZ0X3JlY2VpdmVkOiBjaGVja2VkLFxyXG4vLyAgICAgICAgIH0pO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIGJ1bGsgdXBkYXRlOlwiLCBlcnIpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgc2V0QWN0aXZlVXNlckRhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIC4uLnVwZGF0ZWQgfSkpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGdpZnRDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIlVzZXIgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ0aWNrZXRzXCIsIGhlYWRlcjogXCJUaWNrZXRzXCIgfSxcclxuLy8gICAgIC8vIHsga2V5OiBcInBheW1lbnRUeXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4vLyAgICAgLy8geyBrZXk6IFwiZ3JvdXBJbnN0YWxsTWVudFwiLCBoZWFkZXI6IFwiSW5zdGFsbG1lbnRcIiB9LFxyXG4vLyAgICAge2tleTogXCJUb3RhbFBhaWRBbW91bnRcIiwgaGVhZGVyOiBcIlRvdGFsIFBhaWQgQW1vdW50XCJ9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVtYWluaW5nSW5zdGFsbG1lbnRcIiwgaGVhZGVyOiBcIlJlbWFpbmluZyBJbnN0YWxsbWVudFwiIH0sXHJcblxyXG4vLyAgICAgeyBrZXk6IFwicmVsZWFzZUdpZnRcIiwgaGVhZGVyOiBcIlJlbGVhc2UgR2lmdFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJjaGVja0JveHNcIiwgaGVhZGVyOiBcIkdpZnQgUmVjZWl2ZWRcIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cInctc2NyZWVuXCI+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0zMFwiPlxyXG4vLyAgICAgICAgIDxOYXZiYXJcclxuLy8gICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4vLyAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuLy8gICAgICAgICAvPlxyXG4vLyAgICAgICAgIDxTZXR0aW5nU2lkZWJhciAvPlxyXG4vLyAgICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4vLyAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuLy8gICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuLy8gICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbi8vICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4vLyAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgLz5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkN1c3RvbWVyIFJld2FyZHM8L2gxPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIHtzY3JlZW5Mb2FkaW5nID8gKFxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuLy8gICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICBDdXN0b21lciBSZXdhcmRzXHJcbi8vICAgICAgICAgICAgICAgPC9oMT5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIEZpbHRlcnMgKi99XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgRmlsdGVyXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tQWxsIGdyb3Vwcy0tXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEdyb3VwRmlsdGVyKHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cEZpbHRlciB8fCB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXA/Ll9pZH0gdmFsdWU9e2dyb3VwPy5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cD8uZ3JvdXBfbmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgey8qIFNlbGVjdCBBbGwgQ2hlY2tib3ggKi99XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbXQtNlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdEFsbH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VsZWN0QWxsKGUudGFyZ2V0LmNoZWNrZWQpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXItMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgICB7LyogU2hvdyBtZXNzYWdlIGJlZm9yZSBzZWxlY3RpbmcgYSBncm91cCAqL31cclxuLy8gICAgICAgICAgICAgICAgIHshZ3JvdXBGaWx0ZXIgPyAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTYwMCB0ZXh0LWxnIGZvbnQtbWVkaXVtXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgUGxlYXNlIHNlbGVjdCBhIGdyb3VwIHRvIGNoZWNrIGN1c3RvbWVyIHJld2FyZGVkIG9yIG5vdC5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICApIDogZmlsdGVyZWRSZXdhcmRzLmxlbmd0aCA9PT0gMCA/IChcclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNjAwIHRleHQtbGcgZm9udC1tZWRpdW1cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBObyByZXdhcmQgZGF0YSBmb3VuZCBmb3IgdGhpcyBncm91cC5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRSZXdhcmRzfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2dpZnRDb2x1bW5zfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkN1c3RvbWVyIFJld2FyZHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDdXN0b21lclJld2FyZHMuY3N2YH1cclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgKX1cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuY29uc3QgQ3VzdG9tZXJSZXdhcmRzID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtjdXN0b21lcnMsIHNldEN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2N1c3RvbWVySWQsIHNldEN1c3RvbWVySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIC8qID09PT09PT09PT09PT09PT09IERBVEUgUkFOR0UgPT09PT09PT09PT09PT09PT0gKi9cclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0b0RhdGUsIHNldFRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgW3Jld2FyZFRhYmxlLCBzZXRSZXdhcmRUYWJsZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCB0b2RheVN0cmluZyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW3NlbGVjdGVkTGFiZWwsIHNldFNlbGVjdGVkTGFiZWxdID0gdXNlU3RhdGUoXCJUb2RheVwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVG9EYXRlLCBzZXRTZWxlY3RlZFRvRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbiAgICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuXHJcbiAgLyogPT09PT09PT09PT09PT09PT0gU1VNTUFSWSA9PT09PT09PT09PT09PT09PSAqL1xyXG4gIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuICAgIHBvaW50X3ZhbHVlOiAxLFxyXG4gICAgLy8gIHRvdGFsX2Vhcm5lZF9wb2ludHM6IDAsXHJcbiAgICB0b3RhbF9lYXJuZWRfcG9pbnRzOiAwLCAvLyB3YWxsZXQgZWFybmVkIChhZnRlciByZWRlbXB0aW9uKVxyXG4gICAgdG90YWxfcmVkZWVtZWRfcG9pbnRzOiAwLFxyXG4gICAgYmFsYW5jZV9wb2ludHM6IDAsXHJcbiAgICB0b3RhbF9yZWRlZW1lZF9hbW91bnQ6IDAsXHJcbiAgICBzdW1fcHJldmlvdXNfZWFybmVkX3BvaW50czogMCwgLy8gbGlmZXRpbWVcclxuICAgIHN1bV9wcmV2aW91c19yZWRlZW1lZF9wb2ludHM6IDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudElucHV0RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycyh7IC4uLmVycm9ycywgW2ZpZWxkXTogXCJcIiB9KTtcclxuICB9O1xyXG5cclxuICAgIGNvbnN0IFtyZXdhcmRTdGF0ZSwgc2V0UmV3YXJkU3RhdGVdID0gdXNlU3RhdGUoe1xyXG4gICAgcmV3YXJkczogW10sXHJcbiAgICBhY3RpdmVSZXdhcmRzOiBbXSxcclxuICAgIHRvdGFsUG9pbnRzQWxsOiAwLFxyXG4gICAgdG90YWxBbW91bnRBbGw6IDAsXHJcbiAgICB0b3RhbEVtcGx5ZWVzOiAwLFxyXG4gIH0pO1xyXG5cclxuICAvKiA9PT09PT09PT09PT09PT09PSBSRURFRU0gPT09PT09PT09PT09PT09PT0gKi9cclxuICBjb25zdCBbcmVkZWVtUG9pbnRzLCBzZXRSZWRlZW1Qb2ludHNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3JlZGVlbVR5cGUsIHNldFJlZGVlbVR5cGVdID0gdXNlU3RhdGUoXCJDYXNoXCIpO1xyXG4gIGNvbnN0IFtyZWRlZW1BbW91bnQsIHNldFJlZGVlbUFtb3VudF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbcmVkZWVtRGVzYywgc2V0UmVkZWVtRGVzY10gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgLyogPT09PT09PT09PT09PT09PT0gRkVUQ0ggQ1VTVE9NRVJTID09PT09PT09PT09PT09PT09ICovXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoQ3VzdG9tZXJzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaEN1c3RvbWVycyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgc2V0Q3VzdG9tZXJzKHJlcy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGN1c3RvbWVyc1wiKTtcclxuICAgIH1cclxuICB9O1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBbZW1wbG95ZWVSZXMsIGVtcFJld2FyZHNSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgYXBpLmdldChcIi9hZ2VudC9nZXQtZW1wbG95ZWVcIiksXHJcbiAgICAgICAgICBhcGkuZ2V0KGAvcmV3YXJkLXBvaW50cy9yZXdhcmRzL3RvcC1lbXBsb3llZXM/ZnJvbV9kYXRlPSR7c2VsZWN0ZWRGcm9tRGF0ZX0mdG9fZGF0ZT0ke3NlbGVjdGVkVG9EYXRlfWApLFxyXG4gICAgICAgIF0pO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVtcFJld2FyZHNSZXMuZGF0YS5jb3VudCwgXCJlbXBSZXdhcmRzUmVzXCIpO1xyXG4gICAgICAgIC8vIHNldFRvdGFsRW1wbG95ZWVzKGVtcFJld2FyZHNSZXMuZGF0YS5jb3VudCB8fCAwKTtcclxuICAgICAgICBjb25zdCByZXdhcmREYXRhID0gZW1wUmV3YXJkc1Jlcy5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgICAvLyAx77iP4oOjIFJlbW92ZSB6ZXJvIHBvaW50c1xyXG4gICAgICAgIGNvbnN0IGZpbHRlcmVkID0gcmV3YXJkRGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAoaXRlbSkgPT4gaXRlbS50b3RhbF9wb2ludHMgPiAwXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgLy8gMu+4j+KDoyBTb3J0IGRlc2NlbmRpbmdcclxuICAgICAgICBjb25zdCBzb3J0ZWQgPSBbLi4uZmlsdGVyZWRdLnNvcnQoXHJcbiAgICAgICAgICAoYSwgYikgPT4gYi50b3RhbF9wb2ludHMgLSBhLnRvdGFsX3BvaW50c1xyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIDPvuI/ig6MgQ2FsY3VsYXRlIHRvdGFscyAoYWxsIGRhdGEpXHJcbiAgICAgICAgY29uc3QgdG90YWxQb2ludHMgPSByZXdhcmREYXRhLnJlZHVjZShcclxuICAgICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIGl0ZW0udG90YWxfcG9pbnRzLFxyXG4gICAgICAgICAgMFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGNvbnN0IHRvdGFsQW1vdW50ID0gcmV3YXJkRGF0YS5yZWR1Y2UoXHJcbiAgICAgICAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyBpdGVtLnRvdGFsX2Ftb3VudCxcclxuICAgICAgICAgIDBcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICAvLyA077iP4oOjIFVwZGF0ZSBzaW5nbGUgc3RhdGVcclxuICAgICAgICBzZXRSZXdhcmRTdGF0ZSh7XHJcbiAgICAgICAgICByZXdhcmRzOiBmaWx0ZXJlZCxcclxuICAgICAgICAgIGFjdGl2ZVJld2FyZHM6IHNvcnRlZCxcclxuICAgICAgICAgIHRvdGFsUG9pbnRzQWxsOiB0b3RhbFBvaW50cyxcclxuICAgICAgICAgIHRvdGFsQW1vdW50QWxsOiB0b3RhbEFtb3VudCxcclxuICAgICAgICAgIHRvdGFsRW1wbHllZXM6IGVtcFJld2FyZHNSZXMuZGF0YT8uY291bnQgfHwgMCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRFbXBsb3llZXMoZW1wbG95ZWVSZXMuZGF0YS5lbXBsb3llZSB8fCBbXSk7XHJcbiAgICAgICAgc2V0UmV3YXJkcyhbZW1wUmV3YXJkc1Jlcy5kYXRhPy5kYXRhXSB8fCBbXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gIH0sIFtzZWxlY3RlZEZyb21EYXRlLHNlbGVjdGVkVG9EYXRlXSk7XHJcblxyXG4gIC8qID09PT09PT09PT09PT09PT09IEZFVENIIFNVTU1BUlkgPT09PT09PT09PT09PT09PT0gKi9cclxuICBjb25zdCBmZXRjaFJld2FyZFN1bW1hcnkgPSBhc3luYyAoY3VzdElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvY3VzdG9tZXItcmV3YXJkcy9jdXN0b21lci1yZXdhcmQtcG9pbnRzLyR7Y3VzdElkfWAsXHJcbiAgICAgICk7XHJcbiAgICAgIGlmIChyZXMuZGF0YT8uc3VjY2Vzcykge1xyXG4gICAgICAgIHNldFN1bW1hcnkocmVzLmRhdGEpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCByZXdhcmQgc3VtbWFyeVwiLCBlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8qID09PT09PT09PT09PT09PT09IEZFVENIIFJFV0FSRCBMSVNUID09PT09PT09PT09PT09PT09ICovXHJcbiAgY29uc3QgZmV0Y2hSZXdhcmRQb2ludHMgPSBhc3luYyAoY3VzdElkKSA9PiB7XHJcbiAgICBpZiAoIWN1c3RJZCkgcmV0dXJuO1xyXG5cclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9jdXN0b21lci1yZXdhcmRzL2N1c3RvbWVyLXJld2FyZC1saXN0LyR7Y3VzdElkfWAsXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSByZXMuZGF0YT8uZGF0YT8ubWFwKChyZXdhcmQsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIF9pZDogcmV3YXJkLl9pZCxcclxuICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgY3VzdG9tZXJOYW1lOiByZXdhcmQ/LmN1c3RvbWVyX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgcGhvbmU6IHJld2FyZD8uY3VzdG9tZXJfcGhvbmUgfHwgXCItXCIsXHJcbiAgICAgICAgZ3JvdXBOYW1lOiByZXdhcmQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgc291cmNlVHlwZTogcmV3YXJkPy5zb3VyY2VfdHlwZSB8fCBcIi1cIixcclxuICAgICAgICByZXdhcmRQb2ludHM6IHJld2FyZD8ucmV3YXJkX3BvaW50cyB8fCAwLFxyXG4gICAgICAgIHJld2FyZEFtb3VudDogcmV3YXJkPy5yZXdhcmRlZF9hbW91bnQgfHwgMCxcclxuICAgICAgICBzdGF0dXM6IHJld2FyZD8uc3RhdHVzIHx8IFwiQWN0aXZlXCIsXHJcbiAgICAgICAgcmVtYXJrczogcmV3YXJkPy5yZW1hcmtzIHx8IFwiLVwiLFxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICBzZXRSZXdhcmRUYWJsZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcmV3YXJkIGxpc3RcIiwgZXJyKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLyogPT09PT09PT09PT09PT09PT0gQ1JFQVRFIFJFV0FSRCA9PT09PT09PT09PT09PT09PSAqL1xyXG4gIGNvbnN0IGNyZWF0ZVJld2FyZFBvaW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghY3VzdG9tZXJJZCkgcmV0dXJuIGFsZXJ0KFwiU2VsZWN0IGN1c3RvbWVyXCIpO1xyXG4gICAgaWYgKCFmcm9tRGF0ZSB8fCAhdG9EYXRlKSByZXR1cm4gYWxlcnQoXCJTZWxlY3QgRnJvbSAmIFRvIGRhdGVzXCIpO1xyXG4gICAgaWYgKG5ldyBEYXRlKGZyb21EYXRlKSA+IG5ldyBEYXRlKHRvRGF0ZSkpIHtcclxuICAgICAgcmV0dXJuIGFsZXJ0KFwiRnJvbSBEYXRlIGNhbm5vdCBiZSBhZnRlciBUbyBEYXRlXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL2N1c3RvbWVyLXJld2FyZHMvY3VzdG9tZXItcmV3YXJkLXBvaW50cy9jcmVhdGVcIiwge1xyXG4gICAgICAgIGN1c3RvbWVyX2lkOiBjdXN0b21lcklkLFxyXG4gICAgICAgIGZyb21fZGF0ZTogZnJvbURhdGUsXHJcbiAgICAgICAgdG9fZGF0ZTogdG9EYXRlLFxyXG4gICAgICAgIHJlbWFya3M6IFwiXCIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgYXdhaXQgZmV0Y2hSZXdhcmRTdW1tYXJ5KGN1c3RvbWVySWQpO1xyXG4gICAgICBhd2FpdCBmZXRjaFJld2FyZFBvaW50cyhjdXN0b21lcklkKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBhbGVydChlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gY3JlYXRlIHJld2FyZHNcIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8qID09PT09PT09PT09PT09PT09IEFVVE8gQ0FMQ1VMQVRFIENBU0ggPT09PT09PT09PT09PT09PT0gKi9cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHJlZGVlbVR5cGUgPT09IFwiQ2FzaFwiKSB7XHJcbiAgICAgIHNldFJlZGVlbUFtb3VudChOdW1iZXIocmVkZWVtUG9pbnRzIHx8IDApICogc3VtbWFyeS5wb2ludF92YWx1ZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRSZWRlZW1BbW91bnQoMCk7XHJcbiAgICB9XHJcbiAgfSwgW3JlZGVlbVBvaW50cywgcmVkZWVtVHlwZSwgc3VtbWFyeS5wb2ludF92YWx1ZV0pO1xyXG5cclxuICAvKiA9PT09PT09PT09PT09PT09PSBSRURFRU0gPT09PT09PT09PT09PT09PT0gKi9cclxuICBjb25zdCByZWRlZW1SZXdhcmRQb2ludHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWN1c3RvbWVySWQpIHJldHVybiBhbGVydChcIlNlbGVjdCBjdXN0b21lclwiKTtcclxuICAgIGlmICghcmVkZWVtUG9pbnRzKSByZXR1cm4gYWxlcnQoXCJFbnRlciBwb2ludHNcIik7XHJcblxyXG4gICAgaWYgKE51bWJlcihyZWRlZW1Qb2ludHMpID4gc3VtbWFyeS5iYWxhbmNlX3BvaW50cykge1xyXG4gICAgICByZXR1cm4gYWxlcnQoXCJSZWRlZW0gcG9pbnRzIGV4Y2VlZCBhdmFpbGFibGUgYmFsYW5jZVwiKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi9jdXN0b21lci1yZXdhcmRzL2N1c3RvbWVyLXJld2FyZC1wb2ludHMvcmVkZWVtXCIsIHtcclxuICAgICAgICBjdXN0b21lcl9pZDogY3VzdG9tZXJJZCxcclxuICAgICAgICByZWRlZW1fcG9pbnRzOiBOdW1iZXIocmVkZWVtUG9pbnRzKSxcclxuICAgICAgICByZWRlbXB0aW9uX3R5cGU6IHJlZGVlbVR5cGUsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IHJlZGVlbURlc2MsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0UmVkZWVtUG9pbnRzKFwiXCIpO1xyXG4gICAgICBzZXRSZWRlZW1EZXNjKFwiXCIpO1xyXG5cclxuICAgICAgYXdhaXQgZmV0Y2hSZXdhcmRTdW1tYXJ5KGN1c3RvbWVySWQpO1xyXG4gICAgICBhd2FpdCBmZXRjaFJld2FyZFBvaW50cyhjdXN0b21lcklkKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBhbGVydChlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJSZWRlZW0gZmFpbGVkXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvKiA9PT09PT09PT09PT09PT09PSBUQUJMRSBDT0xVTU5TID09PT09PT09PT09PT09PT09ICovXHJcbiAgY29uc3QgcmV3YXJkQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsTm9cIiwgaGVhZGVyOiBcIlNsIE5vXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cFwiIH0sXHJcbiAgICB7IGtleTogXCJzb3VyY2VUeXBlXCIsIGhlYWRlcjogXCJTb3VyY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwicmV3YXJkUG9pbnRzXCIsIGhlYWRlcjogXCJQb2ludHNcIiB9LFxyXG4gICAgeyBrZXk6IFwicmV3YXJkQW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVtYXJrc1wiLCBoZWFkZXI6IFwiUmVtYXJrc1wiIH0sXHJcbiAgXTtcclxuICAgIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIHsgdmFsdWU6IFwiVG9kYXlcIiwgbGFiZWw6IFwiVG9kYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4gIF07XHJcblxyXG4gICBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkTGFiZWwodmFsdWUpO1xyXG4gICAgLy9jb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNob3dGaWx0ZXJGaWVsZChmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbiAgICAgIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgeWVzdGVyZGF5LnNldERhdGUoeWVzdGVyZGF5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHllc3RlcmRheSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0dGVkKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZm9ybWF0dGVkKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdE1vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpIC0gMSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuICAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKHRydWUpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8TmF2YmFyIHZpc2liaWxpdHkgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi02XCI+XHJcbiAgICAgICAgICAgIEN1c3RvbWVyIFJld2FyZCBQb2ludHNcclxuICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCB4bDpncmlkLWNvbHMtNSBnYXAtOCBtYi0yXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+VG90YWwgQ3VzdG9tZXJzPC9oMz5cclxuICAgICAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtYmx1ZS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3Jld2FyZFN0YXRlPy50b3RhbEVtcGx5ZWVzfTwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtNlwiPkFjcm9zcyBhbGwgZGVwYXJ0bWVudDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+VG90YWwgQW1vdW50L1Jld2FyZHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgPEF3YXJkIGNsYXNzTmFtZT1cImgtOCB3LTggdGV4dC1ibHVlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57cmV3YXJkU3RhdGU/LnRvdGFsQW1vdW50QWxsfTwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMlwiPkFjcm9zcyBhbGwgZW1wbG95ZWVzPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+VG90YWwgUG9pbnRzPC9oMz5cclxuICAgICAgICAgICAgICAgIDxTdGFyIGNsYXNzTmFtZT1cImgtOCB3LTggdGV4dC15ZWxsb3ctNTAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPntyZXdhcmRTdGF0ZT8udG90YWxQb2ludHNBbGx9PC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC02XCI+UG9pbnRzIGF3YXJkZWQgaW4gdG90YWw8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBwLTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5Ub3AgQ3VzdG9tZXI8L2gzPlxyXG4gICAgICAgICAgICAgICAgPFRyb3BoeSBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtZ3JlZW4tNTAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICB7cmV3YXJkU3RhdGU/LmFjdGl2ZVJld2FyZHMubGVuZ3RoID4gMCA/IHJld2FyZFN0YXRlLmFjdGl2ZVJld2FyZHNbMF0/LmVtcGxveWVlX25hbWUgOiAnTi9BJ31cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTdcIj5cclxuICAgICAgICAgICAgICAgIHtyZXdhcmRTdGF0ZT8uYWN0aXZlUmV3YXJkcy5sZW5ndGggPiAwID8gYCR7cmV3YXJkU3RhdGUuYWN0aXZlUmV3YXJkc1swXS50b3RhbF9wb2ludHN9IHBvaW50c2AgOiAnTm8gZGF0YSBhdmFpbGFibGUnfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtYi0zXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEJhY2tncm91bmQgR2xvdyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ncmFkaWVudC10by1yIGZyb20taW5kaWdvLTEwMCB2aWEtYmx1ZS0xMDAgdG8tcHVycGxlLTEwMCByb3VuZGVkLTN4bCBibHVyLXhsIG9wYWNpdHktNDBcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlLzgwIGJhY2tkcm9wLWJsdXIteGwgXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlciBib3JkZXItZ3JheS0yMDAgXHJcbiAgICAgICAgICAgICAgICAgIHJvdW5kZWQtM3hsIHNoYWRvdy1sZyBcclxuICAgICAgICAgICAgICAgICAgcC02XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTYgaXRlbXMtZW5kXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBGaWx0ZXIgU2VsZWN0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRmlsdGVyIE9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNlbGVjdEZpbHRlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIG9yIFNlbGVjdCBGaWx0ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgY3VzdG9tLXNlbGVjdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKCh0aW1lKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt0aW1lLnZhbHVlfSB2YWx1ZT17dGltZS52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGltZS5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBGcm9tIERhdGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAge3Nob3dGaWx0ZXJGaWVsZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRnJvbSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEZyb21EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIGJnLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIHJvdW5kZWQteGwgcHgtNCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIHNoYWRvdy1zbSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGhvdmVyOmJvcmRlci1pbmRpZ28tNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBUbyBEYXRlICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVG8gRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRUb0RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkVG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyIGJnLXdoaXRlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIHJvdW5kZWQteGwgcHgtNCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIHNoYWRvdy1zbSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGhvdmVyOmJvcmRlci1pbmRpZ28tNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktMiBiZy1ncmF5LTUwIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5DdXN0b21lciBSZXdhcmRzIFN1bW1hcnk8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+U2wgbm88L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5DdXN0b21lcjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkRlcGFydG1lbnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Qb2ludHM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5SZXdhcmRzIC8gQW1tb3VudDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlRyZW5kPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZXdhcmRTdGF0ZS5hY3RpdmVSZXdhcmRzPy5zbGljZSgwLCA1KT8ubWFwKChlbXBsb3llZSwga2V5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17ZW1wbG95ZWUuaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktNTAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgaC02IHctNiByb3VuZGVkLWZ1bGwgYmctYmx1ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgZm9udC1tZWRpdW1cIj57a2V5ICsgMX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e2VtcGxveWVlLmVtcGxveWVlX25hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e2VtcGxveWVlLmRlcGFydG1lbnQgfHwgXCJTYWxlc1wifTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57ZW1wbG95ZWUudG90YWxfcG9pbnRzfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQteHMgdGV4dC1ncmF5LTUwMFwiPnB0czwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57ZW1wbG95ZWUudG90YWxfYW1vdW50fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZS50b3RhbF9wb2ludHMgPiAyMDAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LXNtIHRleHQtZ3JlZW4tNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJlbmRpbmdVcCBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVXBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZS50b3RhbF9wb2ludHMgPCAyMDAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgY2xhc3NOYW1lPVwiaC00IHctNCBtci0xIHJvdGF0ZS0xODBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRG93blxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlLnRyZW5kID09PSAnc2FtZScgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTEgYmctZ3JheS00MDAgcm91bmRlZC1mdWxsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBGSUxURVIgPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC00IG10LTQgbWItNSBpdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+Q3VzdG9tZXI8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LTY0XCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbWVySWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRDdXN0b21lcklkKHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgc2V0UmV3YXJkVGFibGUoW10pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmV0Y2hSZXdhcmRTdW1tYXJ5KHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICBmZXRjaFJld2FyZFBvaW50cyh2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2N1c3RvbWVycy5tYXAoKGMpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtjLl9pZH0gdmFsdWU9e2MuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICB7Yy5mdWxsX25hbWV9IC0ge2MucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIG1iLTFcIj5Gcm9tIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTQgcHktMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtmcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBtYi0xXCI+VG8gRGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtNCBweS0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3RvRGF0ZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtjcmVhdGVSZXdhcmRQb2ludHN9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC02IHB5LTIgcm91bmRlZCAke1xyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nXHJcbiAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLWJsdWUtNzAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyBcIlByb2Nlc3NpbmcuLi5cIiA6IFwiQ3JlYXRlIFJld2FyZFwifVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFNVTU1BUlkgPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgICB7Y3VzdG9tZXJJZCAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPFN1bW1hcnlDYXJkXHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkVhcm5lZCBQb2ludHNcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3N1bW1hcnkudG90YWxfZWFybmVkX3BvaW50c31cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxTdW1tYXJ5Q2FyZFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJSZWRlZW1lZCBQb2ludHNcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3N1bW1hcnkudG90YWxfcmVkZWVtZWRfcG9pbnRzfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPFN1bW1hcnlDYXJkXHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIlJlZGVlbWVkIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c3VtbWFyeS50b3RhbF9yZWRlZW1lZF9hbW91bnR9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBSRURFRU0gPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgICB7Y3VzdG9tZXJJZCAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCBtYi00XCI+UmVkZWVtIFJld2FyZCBQb2ludHM8L2gyPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZXdhcmQgUG9pbnRzXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3JlZGVlbVBvaW50c31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWRlZW1Qb2ludHMoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZWRlZW1UeXBlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlZGVlbVR5cGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ2FzaFwiPkNhc2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkdpZnRcIj5HaWZ0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPdGhlclwiPk90aGVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgICB7cmVkZWVtVHlwZSA9PT0gXCJDYXNoXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgcm91bmRlZCBiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2DigrkgJHtyZWRlZW1BbW91bnR9YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZW1hcmtzXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiByb3VuZGVkIGNvbC1zcGFuLTJcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cmVkZWVtRGVzY31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWRlZW1EZXNjKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzdW1tYXJ5LmJhbGFuY2VfcG9pbnRzIDw9IDB9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtyZWRlZW1SZXdhcmRQb2ludHN9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtdC00IHB4LTYgcHktMiByb3VuZGVkICR7XHJcbiAgICAgICAgICAgICAgICAgIHN1bW1hcnkuYmFsYW5jZV9wb2ludHMgPD0gMFxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTQwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmVlbi02MDAgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBSZWRlZW0gUG9pbnRzXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gVEFCTEUgPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgICB7cmV3YXJkVGFibGUubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICA8RGF0YVRhYmxlIGNvbHVtbnM9e3Jld2FyZENvbHVtbnN9IGRhdGE9e3Jld2FyZFRhYmxlfSBleHBvcnRlZFBkZk5hbWU9XCJDdXN0b21lciBSZXdhcmRzXCJcclxuICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEN1c3RvbWVyIFJld2FyZHMuY3N2YH0vPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgZGF0YT1cIkN1c3RvbWVyIFJld2FyZFwiXHJcbiAgICAgICAgICAgICAgZmFpbHVyZT17IWlzTG9hZGluZyAmJiByZXdhcmRUYWJsZS5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5jb25zdCBTdW1tYXJ5Q2FyZCA9ICh7IGxhYmVsLCB2YWx1ZSB9KSA9PiAoXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBwLTQgYmctd2hpdGUgc2hhZG93LXNtXCI+XHJcbiAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj57bGFiZWx9PC9wPlxyXG4gICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIG10LTFcIj57dmFsdWV9PC9wPlxyXG4gIDwvZGl2PlxyXG4pO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ3VzdG9tZXJSZXdhcmRzO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQ3VzdG9tZXJSZXdhcmRzLmpzeCJ9