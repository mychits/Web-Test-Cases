import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Supports.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import API from "/src/instance/TokenInstance.js";
import { notification, Pagination, Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Users, ChevronRight, Zap, ClipboardCheck, X, Eye, UserPlus, AlertCircle } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import BaseURL from "/src/instance/BaseUrl.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { MdAssignmentInd } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
function Supports() {
  _s();
  const [api, contextHolder] = notification.useNotification();
  const [isLoading, setIsLoading] = useState(false);
  const [initialLoad, setInitialLoad] = useState(true);
  const [allComplaintsForCounts, setAllComplaintsForCounts] = useState([]);
  const [imagePreviewOpen, setImagePreviewOpen] = useState(false);
  const [previewImageSrc, setPreviewImageSrc] = useState("");
  const [complaints, setComplaints] = useState([]);
  const [allComplaints, setAllComplaints] = useState([]);
  const [totalComplaints, setTotalComplaints] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [activeTab, setActiveTab] = useState(null);
  const [agents, setAgents] = useState([]);
  const [loadingAgents, setLoadingAgents] = useState(false);
  const [openActionId, setOpenActionId] = useState(null);
  const [viewMode, setViewMode] = useState("view");
  const [viewEditModalOpen, setViewEditModalOpen] = useState(false);
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [selectedAgent, setSelectedAgent] = useState("");
  const [filters, setFilters] = useState({
    subject: "",
    assignedTo: "",
    status: "",
    fromDate: "",
    toDate: ""
  });
  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };
  const getAssigneeName = (item) => {
    if (item.assignedToName) return item.assignedToName;
    if (!item.assignedTo) return "Unassigned";
    if (typeof item.assignedTo === "object" && item.assignedTo.name) {
      return item.assignedTo.name;
    }
    if (typeof item.assignedTo === "string") {
      const agent = agents.find((a) => String(a._id) === String(item.assignedTo));
      return agent ? agent.name : "Unknown Admin";
    }
    return "Unassigned";
  };
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({
      ...prev,
      [name]: value
    }));
    setCurrentPage(1);
  };
  const handleCardClick = (status) => {
    setFilters((prev) => ({
      ...prev,
      status: prev.status === status ? "" : status
    }));
    setCurrentPage(1);
  };
  const handleAttachmentClick = (url, fileName) => {
    if (!url) {
      notify("error", "Error", "No attachment URL found");
      return;
    }
    if (fileName && fileName.toLowerCase().endsWith(".pdf")) {
      window.open(url, "_blank");
    } else if (url.match(/\.(jpeg|jpg|gif|png|webp)$/i) || url.includes("amazonaws.com")) {
      setPreviewImageSrc(url);
      setImagePreviewOpen(true);
    } else {
      window.open(url, "_blank");
    }
  };
  const notify = (type, title, description) => {
    api[type]({
      title,
      description,
      placement: "top",
      duration: 2
    });
  };
  const fetchAllComplaints = async () => {
    try {
      const res = await API.get(`complaints/all-paginated?page=1&limit=1000`);
      if (res.data.success) {
        setAllComplaints(res.data.data || []);
        setAllComplaintsForCounts(res.data.data || []);
      }
    } catch (error) {
      console.error("Fetch all complaints error:", error);
      setAllComplaints([]);
    }
  };
  const fetchComplaints = async (page = 1) => {
    if (activeTab !== "assign") {
      setInitialLoad(false);
      return;
    }
    try {
      setIsLoading(true);
      const params = new URLSearchParams();
      params.append("page", page);
      params.append("limit", 10);
      if (filters.subject && filters.subject !== "") {
        params.append("subject", filters.subject);
      }
      if (filters.status && filters.status !== "") {
        params.append("status", filters.status);
      }
      if (filters.assignedTo && filters.assignedTo !== "") {
        params.append("assignedTo", filters.assignedTo);
      }
      if (filters.fromDate) {
        params.append("fromDate", filters.fromDate);
      }
      if (filters.toDate) {
        params.append("toDate", filters.toDate);
      }
      const res = await API.get(`complaints/all-paginated?${params.toString()}`);
      if (res.data.success) {
        setComplaints(res.data.data || []);
        setTotalComplaints(res.data.total || 0);
        setTotalPages(res.data.totalPages || 1);
        setCurrentPage(res.data.page || 1);
      }
    } catch (error) {
      console.error("Fetch error:", error);
      notify("error", "Error", "Failed to load complaints");
      setComplaints([]);
    } finally {
      setIsLoading(false);
      setInitialLoad(false);
    }
  };
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        setLoadingAgents(true);
        const res = await API.get("/admin/get-sub-admins");
        const agentsList = Array.isArray(res.data) ? res.data : [];
        setAgents(agentsList);
      } catch (error) {
        console.error("Fetch agents error:", error);
        setAgents([]);
      } finally {
        setLoadingAgents(false);
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    if (activeTab === "assign") {
      fetchAllComplaints();
    }
  }, [activeTab]);
  useEffect(() => {
    if (activeTab === "assign") {
      fetchComplaints(currentPage);
    } else {
      setComplaints([]);
      setInitialLoad(false);
    }
  }, [currentPage, filters, activeTab]);
  useEffect(() => {
    const fetchComplaintsForCounts = async () => {
      try {
        const res = await API.get("complaints/all-paginated?page=1&limit=1000");
        if (res.data.success) {
          setAllComplaintsForCounts(res.data.data || []);
        }
      } catch (error) {
        console.error("Fetch counts error:", error);
      } finally {
        setInitialLoad(false);
      }
    };
    fetchComplaintsForCounts();
  }, []);
  const handleView = async (id) => {
    try {
      const res = await API.get(`/complaints/${id}`);
      setSelectedComplaint(res.data);
      setViewMode("view");
      setViewEditModalOpen(true);
    } catch (err) {
      console.error("Fetch complaint failed", err);
      notify("error", "Error", "Failed to load complaint details");
    }
  };
  const updateComplaint = async (id, data) => {
    try {
      const res = await API.put(`complaints/update/${id}`, data);
      return res.data;
    } catch (error) {
      console.error("Update Complaint Error:", error?.response?.data || error.message);
      throw error;
    }
  };
  const confirmAssign = async () => {
    if (!selectedComplaint || !selectedAgent) return;
    const agent = agents.find((a) => a._id === selectedAgent);
    if (!agent) {
      notify("error", "Error", "Selected Admin not found in list");
      return;
    }
    try {
      await updateComplaint(selectedComplaint._id, {
        assignedTo: agent._id,
        assignedToName: agent.name,
        status: "is Pending"
      });
      notify("success", "Assigned Successfully", `Complaint assigned to ${agent.name}`);
      setAssignModalOpen(false);
      setViewEditModalOpen(false);
      setSelectedAgent("");
      setSelectedComplaint(null);
      if (activeTab === "assign") {
        fetchComplaints(currentPage);
        fetchAllComplaints();
      }
    } catch (error) {
      console.error("Update Complaint Error:", error);
      notify("error", "Error", "Failed to assign complaint");
    }
  };
  const resetFilters = () => {
    setFilters({
      subject: "",
      assignedTo: "",
      status: "",
      fromDate: "",
      toDate: ""
    });
    setCurrentPage(1);
  };
  const counts = useMemo(() => ({
    assigned: allComplaintsForCounts.filter((c) => c.assignedTo).length,
    unassigned: allComplaintsForCounts.filter((c) => !c.assignedTo).length,
    open: allComplaintsForCounts.filter((c) => c.status === "Open").length,
    pending: allComplaintsForCounts.filter((c) => c.status === "is Pending").length,
    closed: allComplaintsForCounts.filter((c) => c.status === "Closed").length,
    total: allComplaintsForCounts.length
  }), [allComplaintsForCounts]);
  const tableData1 = useMemo(() => {
    return complaints.map((item, index) => ({
      _id: item._id,
      complaint_code: item.complaint_code || "N/A",
      sl: (currentPage - 1) * 10 + index + 1,
      userName: item?.userId?.name || item.name,
      subject: item.subject,
      assignedName: getAssigneeName(item),
      status: item.status,
      date: formatDate(item.createdAt),
      action: /* @__PURE__ */ jsxDEV("div", { className: "relative text-center", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: (e) => {
              e.stopPropagation();
              setOpenActionId(openActionId === item._id ? null : item._id);
            },
            className: "p-2 rounded-full hover:bg-gray-200",
            children: "⋮"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1306,
            columnNumber: 11
          },
          this
        ),
        openActionId === item._id && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-6 top-10 bg-white border rounded-lg shadow-lg w-40 z-50", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                handleView(item._id);
                setOpenActionId(null);
              },
              className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-green-600",
              children: [
                /* @__PURE__ */ jsxDEV(Eye, { size: 18 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1325,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "View" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1326,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1317,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                setSelectedComplaint(item);
                setSelectedAgent("");
                setViewMode("assign");
                setViewEditModalOpen(true);
                setOpenActionId(null);
              },
              className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-blue-600",
              children: [
                /* @__PURE__ */ jsxDEV(UserPlus, { size: 18 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1339,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "Assign" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1340,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1328,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1316,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
        lineNumber: 1305,
        columnNumber: 7
      }, this)
    }));
  }, [complaints, currentPage, openActionId, agents]);
  if (initialLoad && activeTab !== "assign") {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      contextHolder,
      /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
        lineNumber: 1353,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex w-screen mt-14", children: [
        /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1355,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-col w-full p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center mb-4", children: /* @__PURE__ */ jsxDEV("h2", { className: "mx-auto text-2xl font-bold my-5", children: "Admin Support" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1358,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1357,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6", children: /* @__PURE__ */ jsxDEV("div", { onClick: () => setActiveTab("assign"), className: "group cursor-pointer", children: /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden rounded-xl bg-white border border-blue-200 shadow-md hover:shadow-lg transition-all duration-300", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-600 to-green-700 opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 blur-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1363,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative p-9", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-green-50 rounded-lg", children: /* @__PURE__ */ jsxDEV("span", { className: "text-2xl", children: /* @__PURE__ */ jsxDEV(MdAssignmentInd, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1369,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1368,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1367,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900", children: "Assign" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1373,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Assign tickets to staff" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1374,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1372,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1366,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 text-right", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-600", children: counts.assigned }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1379,
                    columnNumber: 26
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Assigned" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1380,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1378,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-red-500", children: counts.unassigned }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1383,
                    columnNumber: 10
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Unassigned" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1384,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1382,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1377,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1365,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1364,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1362,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1361,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1360,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1356,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
        lineNumber: 1354,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
      lineNumber: 1351,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
      lineNumber: 1401,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-screen mt-14", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
        lineNumber: 1403,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-col w-full p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center mb-4", children: [
          activeTab && /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setActiveTab(null);
                resetFilters();
                setCurrentPage(1);
                setComplaints([]);
              },
              className: "absolute left-0 px-3 py-1 rounded-md bg-gray-200 hover:bg-gray-300 text-sm",
              children: "← Back"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1407,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("h2", { className: "mx-auto text-2xl font-bold my-5", children: "Admin Support" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1419,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1405,
          columnNumber: 9
        }, this),
        !activeTab && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { onClick: () => setActiveTab("assign"), className: "group cursor-pointer", children: /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden rounded-xl bg-white border border-blue-200 shadow-md hover:shadow-lg transition-all duration-300", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-600 to-green-700 opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 blur-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1426,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative p-9", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-green-50 rounded-lg", children: /* @__PURE__ */ jsxDEV("span", { className: "text-2xl", children: /* @__PURE__ */ jsxDEV(MdAssignmentInd, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1432,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1431,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1430,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900", children: "Assign" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1436,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Assign tickets to staff" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1437,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1435,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1429,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 text-right", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-600", children: counts.assigned }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1442,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Assigned" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1443,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1441,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-red-500", children: counts.unassigned }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1446,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Unassigned" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1447,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1445,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1440,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1428,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-3 mt-4 border-t border-gray-100", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase", children: "Staff Assignment" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1452,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-1.5 rounded-lg bg-gradient-to-br from-green-600 to-green-700 opacity-0 group-hover:opacity-100 transition", children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-white" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1454,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1453,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1451,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1427,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1425,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1424,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-8 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border border-blue-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-blue-600 mt-1" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1463,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1462,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900", children: "Quick Tips" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1466,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("ul", { className: "list-disc list-inside text-slate-700 space-y-1", children: [
                /* @__PURE__ */ jsxDEV("li", { className: "flex gap-2", children: "View and manage all support requests in one place" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1468,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("li", { className: "flex gap-2", children: "Assign complaints to staff easily" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1469,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("li", { className: "flex gap-2", children: "Track complaint status and resolution progress" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1470,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1467,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1465,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1461,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1460,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1423,
          columnNumber: 11
        }, this),
        activeTab === "assign" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6 mb-6", children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => handleCardClick(""),
                className: `relative overflow-hidden rounded-xl bg-white shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer border-2 ${filters.status === "" ? "border-blue-500 ring-1 ring-blue-500" : "border-transparent"}`,
                children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-blue-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-blue-100 text-blue-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(Users, { size: 24 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1494,
                      columnNumber: 27
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1493,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900", children: "Total" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1497,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "All tickets" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1498,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1496,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1492,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-blue-600", children: counts.total }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1502,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1501,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1491,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1490,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1484,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => handleCardClick("Open"),
                className: `relative overflow-hidden rounded-xl bg-white shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer border-2 ${filters.status === "Open" ? "border-orange-500 ring-1 ring-orange-500" : "border-transparent"}`,
                children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-orange-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-orange-100 text-orange-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(AlertCircle, { size: 24 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1519,
                      columnNumber: 27
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1518,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900", children: "Open" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1522,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "New complaints" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1523,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1521,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1517,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-orange-600", children: counts.open }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1527,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1526,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1516,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1515,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1509,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => handleCardClick("is Pending"),
                className: `relative overflow-hidden rounded-xl bg-white shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer border-2 ${filters.status === "is Pending" ? "border-yellow-500 ring-1 ring-yellow-500" : "border-transparent"}`,
                children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-yellow-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-yellow-100 text-yellow-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(Zap, { size: 24 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1544,
                      columnNumber: 27
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1543,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900", children: "Pending" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1547,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "In progress" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1548,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1546,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1542,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-yellow-600", children: counts.pending }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1552,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1551,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1541,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1540,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1534,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => handleCardClick("Closed"),
                className: `relative overflow-hidden rounded-xl bg-white shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer border-2 ${filters.status === "Closed" ? "border-green-500 ring-1 ring-green-500" : "border-transparent"}`,
                children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-green-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-green-100 text-green-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(ClipboardCheck, { size: 24 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1569,
                      columnNumber: 27
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1568,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900", children: "Closed" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1572,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Resolved issues" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1573,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1571,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1567,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-600", children: counts.closed }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1577,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1576,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1566,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1565,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1559,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1482,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 border rounded-lg p-4 bg-gray-50", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-5 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 pb-2", children: "Subject" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1588,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "subject",
                    value: filters.subject,
                    onChange: handleFilterChange,
                    className: "border rounded px-3 py-2 text-sm",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "All Subjects" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1595,
                        columnNumber: 23
                      }, this),
                      [...new Set(allComplaints.map((c) => c.subject))].map(
                        (subject) => /* @__PURE__ */ jsxDEV("option", { value: subject, children: subject }, subject, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                          lineNumber: 1597,
                          columnNumber: 21
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1589,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1587,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 pb-2", children: "Assigned To" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1602,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "assignedTo",
                    value: filters.assignedTo,
                    onChange: handleFilterChange,
                    className: "border rounded px-3 py-2 text-sm",
                    disabled: loadingAgents,
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "All Assignees" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1610,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Unassigned", children: "Unassigned" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1611,
                        columnNumber: 23
                      }, this),
                      agents.map(
                        (agent) => /* @__PURE__ */ jsxDEV("option", { value: agent._id, children: agent.name }, agent._id, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                          lineNumber: 1613,
                          columnNumber: 21
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1603,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1601,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 pb-2", children: "Status" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1618,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "status",
                    value: filters.status,
                    onChange: handleFilterChange,
                    className: "border rounded px-3 py-2 text-sm",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "All Status" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1625,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Open", children: "Open" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1626,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "is Pending", children: "Pending" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1627,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Closed", children: "Closed" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1628,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1619,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1617,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 pb-2", children: "From Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1632,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "fromDate",
                    value: filters.fromDate,
                    onChange: handleFilterChange,
                    className: "border rounded px-3 py-2 text-sm"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1633,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1631,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 pb-2", children: "To Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1642,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "toDate",
                    value: filters.toDate,
                    onChange: handleFilterChange,
                    className: "border rounded px-3 py-2 text-sm"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1643,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1641,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1586,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: resetFilters,
                className: "px-4 py-2 bg-blue-200 rounded text-sm hover:bg-blue-300",
                children: "Reset Filters"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1653,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1652,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1585,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow border border-gray-300 w-full overflow-x-auto p-4", children: isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(Spin, { size: "large", tip: "Loading complaints..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1666,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1665,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm mb-4", children: [
              "Showing ",
              tableData1.length,
              " of ",
              totalComplaints,
              " complaints (Page ",
              currentPage,
              " of ",
              totalPages,
              ")"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1670,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: tableData1,
                columns: [
                  { key: "complaint_code", header: "complaint code" },
                  { key: "userName", header: "Name" },
                  { key: "subject", header: "Subject" },
                  { key: "assignedName", header: "Assigned To" },
                  { key: "status", header: "Status" },
                  { key: "date", header: "Date" },
                  { key: "action", header: "Action" }
                ],
                catcher: "_id",
                isExportEnabled: true,
                exportedFileName: "Complaints",
                exportedPdfName: "Complaints Report"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1673,
                columnNumber: 21
              },
              this
            ),
            totalPages > 1 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center mt-4", children: /* @__PURE__ */ jsxDEV(
              Pagination,
              {
                current: currentPage,
                total: totalComplaints,
                pageSize: 10,
                onChange: (page) => setCurrentPage(page),
                showSizeChanger: false
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1691,
                columnNumber: 25
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1690,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1669,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1663,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1480,
          columnNumber: 11
        }, this),
        assignModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/40 flex items-center justify-center z-50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg p-6 w-[400px]", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold mb-4", children: "Assign Complaint" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1710,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              className: "w-full border rounded px-3 py-2 mb-4",
              value: selectedAgent,
              onChange: (e) => setSelectedAgent(e.target.value),
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Employee" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1716,
                  columnNumber: 19
                }, this),
                agents.map(
                  (agent) => /* @__PURE__ */ jsxDEV("option", { value: agent._id, children: [
                    agent.name,
                    " ",
                    agent.email ? `| ${agent.email}` : ""
                  ] }, agent._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1718,
                    columnNumber: 17
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1711,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setAssignModalOpen(false),
                className: "px-4 py-2 bg-gray-200 rounded",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1724,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: confirmAssign,
                className: "px-4 py-2 bg-blue-600 text-white rounded",
                disabled: !selectedAgent,
                children: "Assign"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1730,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1723,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1709,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1708,
          columnNumber: 11
        }, this),
        viewEditModalOpen && selectedComplaint && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/40 flex items-center justify-center z-50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-lg w-[95%] max-w-4xl max-h-[90vh] overflow-auto p-6 relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-semibold text-gray-800", children: "Complaint Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1747,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setViewEditModalOpen(false),
                className: "text-gray-500 hover:text-black",
                children: /* @__PURE__ */ jsxDEV(X, { size: 24 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1752,
                  columnNumber: 11
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1748,
                columnNumber: 9
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1746,
            columnNumber: 7
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1759,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedComplaint.name || selectedComplaint.userId?.name || "N/A",
                  readOnly: true,
                  className: "w-full border rounded-md px-3 py-2 bg-gray-100 text-gray-700 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1760,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1758,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Mobile" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1769,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedComplaint.mobile || selectedComplaint.userId?.phone_number || "N/A",
                  readOnly: true,
                  className: "w-full border rounded-md px-3 py-2 bg-gray-100 text-gray-700 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1770,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1768,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Subject" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1779,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedComplaint.subject || "",
                  readOnly: true,
                  className: "w-full border rounded-md px-3 py-2 bg-gray-100 text-gray-700 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1780,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1778,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Department" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1789,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: typeof selectedComplaint.designation === "object" ? selectedComplaint.designation?.title || "" : selectedComplaint.designation || "",
                  readOnly: true,
                  className: "w-full border rounded-md px-3 py-2 bg-gray-100 text-gray-700 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1790,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1788,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Assigned To" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1801,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: getAssigneeName(selectedComplaint),
                  readOnly: true,
                  className: "w-full border rounded-md px-3 py-2 bg-gray-100 text-gray-700 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1802,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1800,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Status" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1811,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedComplaint.status || "",
                  readOnly: true,
                  className: "w-full border rounded-md px-3 py-2 bg-gray-100 text-gray-700 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1812,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1810,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1821,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: formatDate(selectedComplaint.createdAt),
                  readOnly: true,
                  className: "w-full border rounded-md px-3 py-2 bg-gray-100 text-gray-700 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1822,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1820,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Message" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1831,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  rows: 4,
                  value: selectedComplaint.message || "",
                  readOnly: true,
                  className: "w-full border rounded-md px-3 py-2 bg-gray-100 text-gray-700 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1832,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1830,
              columnNumber: 9
            }, this),
            selectedComplaint.complaint_uploads && selectedComplaint.complaint_uploads.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
                "Attachments (",
                selectedComplaint.complaint_uploads.length,
                ")"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1843,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4", children: selectedComplaint.complaint_uploads.map((file, index) => {
                let fileUrl = "";
                let fileName = `Attachment ${index + 1}`;
                if (typeof file === "object") {
                  fileUrl = file.url || "";
                  fileName = file.name || `Attachment ${index + 1}`;
                } else if (typeof file === "string") {
                  fileUrl = file;
                  fileName = `Attachment ${index + 1}`;
                }
                if (!fileUrl) return null;
                const isImage = fileUrl.match(/\.(jpeg|jpg|gif|png|webp)$/i) || fileUrl.includes("amazonaws.com") || fileName.match(/\.(jpeg|jpg|gif|png|webp)$/i);
                return /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    onClick: () => handleAttachmentClick(fileUrl, fileName),
                    className: "border rounded-lg p-3 bg-gray-50 flex flex-col items-center cursor-pointer hover:shadow-md transition group",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "relative w-full h-32 flex items-center justify-center overflow-hidden rounded bg-gray-100", children: [
                        isImage ? /* @__PURE__ */ jsxDEV(
                          "img",
                          {
                            src: fileUrl,
                            alt: fileName,
                            className: "h-full w-full object-contain group-hover:scale-105 transition-transform duration-300",
                            onError: (e) => {
                              console.error("Image failed to load:", fileUrl);
                              e.target.onerror = null;
                              e.target.src = "https://via.placeholder.com/150?text=Failed+to+Load";
                            }
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                            lineNumber: 1876,
                            columnNumber: 29
                          },
                          this
                        ) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center text-gray-500", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "text-4xl mb-2", children: "📄" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                            lineNumber: 1888,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-center", children: fileName }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                            lineNumber: 1889,
                            columnNumber: 27
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                          lineNumber: 1887,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-white text-xs bg-black/50 px-2 py-1 rounded", children: [
                          "Click to ",
                          isImage ? "View" : "Open"
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                          lineNumber: 1893,
                          columnNumber: 25
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                          lineNumber: 1892,
                          columnNumber: 23
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1874,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-700 truncate w-full text-center mt-2", title: fileName, children: fileName.length > 30 ? fileName.substring(0, 27) + "..." : fileName }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1898,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  index,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1869,
                    columnNumber: 25
                  },
                  this
                );
              }) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1846,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1842,
              columnNumber: 17
            }, this),
            viewMode === "assign" && /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Assign To" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1911,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: selectedAgent,
                  onChange: (e) => setSelectedAgent(e.target.value),
                  className: "w-full border rounded-md px-3 py-2",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Employee" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                      lineNumber: 1917,
                      columnNumber: 15
                    }, this),
                    agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV("option", { value: agent._id, children: [
                        agent.name,
                        " | ",
                        agent.email
                      ] }, agent._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                        lineNumber: 1919,
                        columnNumber: 21
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1912,
                  columnNumber: 13
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
              lineNumber: 1910,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1755,
            columnNumber: 7
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-6 gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setViewEditModalOpen(false),
                className: "px-4 py-2 border rounded-md hover:bg-gray-100",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1928,
                columnNumber: 9
              },
              this
            ),
            viewMode === "assign" && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: confirmAssign,
                disabled: !selectedAgent,
                className: "px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50",
                children: "Assign"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                lineNumber: 1935,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1927,
            columnNumber: 7
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1745,
          columnNumber: 5
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
          lineNumber: 1744,
          columnNumber: 11
        }, this),
        imagePreviewOpen && /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "fixed inset-0 z-[60] bg-black/90 flex items-center justify-center p-4 backdrop-blur-sm",
            onClick: () => setImagePreviewOpen(false),
            children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: (e) => {
                    e.stopPropagation();
                    setImagePreviewOpen(false);
                  },
                  className: "absolute top-4 right-4 text-white hover:text-gray-300 bg-black/50 rounded-full p-2",
                  children: /* @__PURE__ */ jsxDEV(X, { size: 32 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                    lineNumber: 1958,
                    columnNumber: 17
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1954,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "img",
                {
                  src: previewImageSrc,
                  alt: "Full Preview",
                  className: "max-w-full max-h-[90vh] object-contain rounded shadow-2xl",
                  onError: (e) => {
                    console.error("Preview image failed to load:", previewImageSrc);
                    notify("error", "Error", "Failed to load image");
                    setImagePreviewOpen(false);
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
                  lineNumber: 1960,
                  columnNumber: 15
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
            lineNumber: 1950,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
        lineNumber: 1404,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
      lineNumber: 1402,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx",
    lineNumber: 1399,
    columnNumber: 5
  }, this);
}
_s(Supports, "4WL2BNAjquN8DbbCbsUM2KMUYtE=", false, function() {
  return [notification.useNotification];
});
_c = Supports;
export default Supports;
var _c;
$RefreshReg$(_c, "Supports");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Supports.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeXhDVSxTQTZDSixVQTdDSTsyQkF6eENWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBazlCQSxTQUFTQSxXQUFXQyxVQUFVQyxlQUFlO0FBQzdDLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsY0FBY0MsWUFBWUMsWUFBWTtBQUMvQyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFlBQVk7QUFDbkIsU0FBU0MsT0FBT0MsY0FBY0MsS0FBS0MsZ0JBQWdCQyxHQUFHQyxLQUFLQyxVQUFVQyxtQkFBbUI7QUFDeEYsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyx1QkFBdUI7QUFFaEMsU0FBU0MsV0FBVztBQUFBQyxLQUFBO0FBQ2xCLFFBQU0sQ0FBQ0MsS0FBS0MsYUFBYSxJQUFJcEIsYUFBYXFCLGdCQUFnQjtBQUcxRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyQixhQUFhQyxjQUFjLElBQUk1QixTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDNkIsd0JBQXdCQyx5QkFBeUIsSUFBSTlCLFNBQVMsRUFBRTtBQUd2RSxRQUFNLENBQUMrQixrQkFBa0JDLG1CQUFtQixJQUFJaEMsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ2lDLGlCQUFpQkMsa0JBQWtCLElBQUlsQyxTQUFTLEVBQUU7QUFHekQsUUFBTSxDQUFDbUMsWUFBWUMsYUFBYSxJQUFJcEMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3FDLGVBQWVDLGdCQUFnQixJQUFJdEMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3VDLGlCQUFpQkMsa0JBQWtCLElBQUl4QyxTQUFTLENBQUM7QUFDeEQsUUFBTSxDQUFDeUMsYUFBYUMsY0FBYyxJQUFJMUMsU0FBUyxDQUFDO0FBQ2hELFFBQU0sQ0FBQzJDLFlBQVlDLGFBQWEsSUFBSTVDLFNBQVMsQ0FBQztBQUM5QyxRQUFNLENBQUM2QyxXQUFXQyxZQUFZLElBQUk5QyxTQUFTLElBQUk7QUFHL0MsUUFBTSxDQUFDK0MsUUFBUUMsU0FBUyxJQUFJaEQsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2lELGVBQWVDLGdCQUFnQixJQUFJbEQsU0FBUyxLQUFLO0FBR3hELFFBQU0sQ0FBQ21ELGNBQWNDLGVBQWUsSUFBSXBELFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNxRCxVQUFVQyxXQUFXLElBQUl0RCxTQUFTLE1BQU07QUFDL0MsUUFBTSxDQUFDdUQsbUJBQW1CQyxvQkFBb0IsSUFBSXhELFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUN5RCxpQkFBaUJDLGtCQUFrQixJQUFJMUQsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzJELG1CQUFtQkMsb0JBQW9CLElBQUk1RCxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDNkQsZUFBZUMsZ0JBQWdCLElBQUk5RCxTQUFTLEVBQUU7QUFHckQsUUFBTSxDQUFDK0QsU0FBU0MsVUFBVSxJQUFJaEUsU0FBUztBQUFBLElBQ3JDaUUsU0FBUztBQUFBLElBQ1RDLFlBQVk7QUFBQSxJQUNaQyxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFHRCxRQUFNQyxhQUFhQSxDQUFDQyxlQUFlO0FBQ2pDLFFBQUksQ0FBQ0EsV0FBWSxRQUFPO0FBQ3hCLFVBQU1DLE9BQU8sSUFBSUMsS0FBS0YsVUFBVTtBQUNoQyxVQUFNRyxNQUFNQyxPQUFPSCxLQUFLSSxRQUFRLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDbEQsVUFBTUMsUUFBUUgsT0FBT0gsS0FBS08sU0FBUyxJQUFJLENBQUMsRUFBRUYsU0FBUyxHQUFHLEdBQUc7QUFDekQsVUFBTUcsT0FBT1IsS0FBS1MsWUFBWTtBQUM5QixXQUFPLEdBQUdQLEdBQUcsSUFBSUksS0FBSyxJQUFJRSxJQUFJO0FBQUEsRUFDaEM7QUFHQSxRQUFNRSxrQkFBa0JBLENBQUNDLFNBQVM7QUFDaEMsUUFBSUEsS0FBS0MsZUFBZ0IsUUFBT0QsS0FBS0M7QUFDckMsUUFBSSxDQUFDRCxLQUFLakIsV0FBWSxRQUFPO0FBQzdCLFFBQUksT0FBT2lCLEtBQUtqQixlQUFlLFlBQVlpQixLQUFLakIsV0FBV21CLE1BQU07QUFDL0QsYUFBT0YsS0FBS2pCLFdBQVdtQjtBQUFBQSxJQUN6QjtBQUNBLFFBQUksT0FBT0YsS0FBS2pCLGVBQWUsVUFBVTtBQUN2QyxZQUFNb0IsUUFBUXZDLE9BQU93QyxLQUFLLENBQUFDLE1BQUtiLE9BQU9hLEVBQUVDLEdBQUcsTUFBTWQsT0FBT1EsS0FBS2pCLFVBQVUsQ0FBQztBQUN4RSxhQUFPb0IsUUFBUUEsTUFBTUQsT0FBTztBQUFBLElBQzlCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFHQSxRQUFNSyxxQkFBcUJBLENBQUNDLE1BQU07QUFDaEMsVUFBTSxFQUFFTixNQUFNTyxNQUFNLElBQUlELEVBQUVFO0FBQzFCN0IsZUFBVyxDQUFBOEIsVUFBUztBQUFBLE1BQ2xCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ1QsSUFBSSxHQUFHTztBQUFBQSxJQUNWLEVBQUU7QUFDRmxELG1CQUFlLENBQUM7QUFBQSxFQUNsQjtBQUdBLFFBQU1xRCxrQkFBa0JBLENBQUM1QixXQUFXO0FBQ2xDSCxlQUFXLENBQUE4QixVQUFTO0FBQUEsTUFDbEIsR0FBR0E7QUFBQUEsTUFDSDNCLFFBQVEyQixLQUFLM0IsV0FBV0EsU0FBUyxLQUFLQTtBQUFBQSxJQUN4QyxFQUFFO0FBQ0Z6QixtQkFBZSxDQUFDO0FBQUEsRUFDbEI7QUFHQSxRQUFNc0Qsd0JBQXdCQSxDQUFDQyxLQUFLQyxhQUFhO0FBQy9DLFFBQUksQ0FBQ0QsS0FBSztBQUNSRSxhQUFPLFNBQVMsU0FBUyx5QkFBeUI7QUFDbEQ7QUFBQSxJQUNGO0FBR0EsUUFBSUQsWUFBWUEsU0FBU0UsWUFBWSxFQUFFQyxTQUFTLE1BQU0sR0FBRztBQUN2REMsYUFBT0MsS0FBS04sS0FBSyxRQUFRO0FBQUEsSUFDM0IsV0FFU0EsSUFBSU8sTUFBTSw2QkFBNkIsS0FBS1AsSUFBSVEsU0FBUyxlQUFlLEdBQUc7QUFDbEZ2RSx5QkFBbUIrRCxHQUFHO0FBQ3RCakUsMEJBQW9CLElBQUk7QUFBQSxJQUMxQixPQUNLO0FBRUhzRSxhQUFPQyxLQUFLTixLQUFLLFFBQVE7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNRSxTQUFTQSxDQUFDTyxNQUFNQyxPQUFPQyxnQkFBZ0I7QUFDM0N0RixRQUFJb0YsSUFBSSxFQUFFO0FBQUEsTUFDUkM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUMsV0FBVztBQUFBLE1BQ1hDLFVBQVU7QUFBQSxJQUNaLENBQUM7QUFBQSxFQUNIO0FBR0EsUUFBTUMscUJBQXFCLFlBQVk7QUFDckMsUUFBSTtBQUNGLFlBQU1DLE1BQU0sTUFBTTlHLElBQUkrRyxJQUFJLDRDQUE0QztBQUN0RSxVQUFJRCxJQUFJRSxLQUFLQyxTQUFTO0FBQ3BCN0UseUJBQWlCMEUsSUFBSUUsS0FBS0EsUUFBUSxFQUFFO0FBQ3BDcEYsa0NBQTBCa0YsSUFBSUUsS0FBS0EsUUFBUSxFQUFFO0FBQUEsTUFDL0M7QUFBQSxJQUNGLFNBQVNFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwrQkFBK0JBLEtBQUs7QUFDbEQ5RSx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUdBLFFBQU1nRixrQkFBa0IsT0FBT0MsT0FBTyxNQUFNO0FBQzFDLFFBQUkxRSxjQUFjLFVBQVU7QUFDMUJqQixxQkFBZSxLQUFLO0FBQ3BCO0FBQUEsSUFDRjtBQUNBLFFBQUk7QUFDRkYsbUJBQWEsSUFBSTtBQUNqQixZQUFNOEYsU0FBUyxJQUFJQyxnQkFBZ0I7QUFDbkNELGFBQU9FLE9BQU8sUUFBUUgsSUFBSTtBQUMxQkMsYUFBT0UsT0FBTyxTQUFTLEVBQUU7QUFFekIsVUFBSTNELFFBQVFFLFdBQVdGLFFBQVFFLFlBQVksSUFBSTtBQUM3Q3VELGVBQU9FLE9BQU8sV0FBVzNELFFBQVFFLE9BQU87QUFBQSxNQUMxQztBQUVBLFVBQUlGLFFBQVFJLFVBQVVKLFFBQVFJLFdBQVcsSUFBSTtBQUMzQ3FELGVBQU9FLE9BQU8sVUFBVTNELFFBQVFJLE1BQU07QUFBQSxNQUN4QztBQUNBLFVBQUlKLFFBQVFHLGNBQWNILFFBQVFHLGVBQWUsSUFBSTtBQUNuRHNELGVBQU9FLE9BQU8sY0FBYzNELFFBQVFHLFVBQVU7QUFBQSxNQUNoRDtBQUNBLFVBQUlILFFBQVFLLFVBQVU7QUFDcEJvRCxlQUFPRSxPQUFPLFlBQVkzRCxRQUFRSyxRQUFRO0FBQUEsTUFDNUM7QUFDQSxVQUFJTCxRQUFRTSxRQUFRO0FBQ2xCbUQsZUFBT0UsT0FBTyxVQUFVM0QsUUFBUU0sTUFBTTtBQUFBLE1BQ3hDO0FBRUEsWUFBTTJDLE1BQU0sTUFBTTlHLElBQUkrRyxJQUFJLDRCQUE0Qk8sT0FBT0csU0FBUyxDQUFDLEVBQUU7QUFDekUsVUFBSVgsSUFBSUUsS0FBS0MsU0FBUztBQUNwQi9FLHNCQUFjNEUsSUFBSUUsS0FBS0EsUUFBUSxFQUFFO0FBQ2pDMUUsMkJBQW1Cd0UsSUFBSUUsS0FBS1UsU0FBUyxDQUFDO0FBQ3RDaEYsc0JBQWNvRSxJQUFJRSxLQUFLdkUsY0FBYyxDQUFDO0FBQ3RDRCx1QkFBZXNFLElBQUlFLEtBQUtLLFFBQVEsQ0FBQztBQUFBLE1BQ25DO0FBQUEsSUFDRixTQUFTSCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sZ0JBQWdCQSxLQUFLO0FBQ25DakIsYUFBTyxTQUFTLFNBQVMsMkJBQTJCO0FBQ3BEL0Qsb0JBQWMsRUFBRTtBQUFBLElBQ2xCLFVBQUM7QUFDQ1YsbUJBQWEsS0FBSztBQUNsQkUscUJBQWUsS0FBSztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUdBN0IsWUFBVSxNQUFNO0FBQ2QsVUFBTThILGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YzRSx5QkFBaUIsSUFBSTtBQUNyQixjQUFNOEQsTUFBTSxNQUFNOUcsSUFBSStHLElBQUksdUJBQXVCO0FBQ2pELGNBQU1hLGFBQWFDLE1BQU1DLFFBQVFoQixJQUFJRSxJQUFJLElBQUlGLElBQUlFLE9BQU87QUFDeERsRSxrQkFBVThFLFVBQVU7QUFBQSxNQUN0QixTQUFTVixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHVCQUF1QkEsS0FBSztBQUMxQ3BFLGtCQUFVLEVBQUU7QUFBQSxNQUNkLFVBQUM7QUFDQ0UseUJBQWlCLEtBQUs7QUFBQSxNQUN4QjtBQUFBLElBQ0Y7QUFDQTJFLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFHTDlILFlBQVUsTUFBTTtBQUNkLFFBQUk4QyxjQUFjLFVBQVU7QUFDMUJrRSx5QkFBbUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0YsR0FBRyxDQUFDbEUsU0FBUyxDQUFDO0FBR2Q5QyxZQUFVLE1BQU07QUFDZCxRQUFJOEMsY0FBYyxVQUFVO0FBQzFCeUUsc0JBQWdCN0UsV0FBVztBQUFBLElBQzdCLE9BQU87QUFDTEwsb0JBQWMsRUFBRTtBQUNoQlIscUJBQWUsS0FBSztBQUFBLElBQ3RCO0FBQUEsRUFDRixHQUFHLENBQUNhLGFBQWFzQixTQUFTbEIsU0FBUyxDQUFDO0FBRXBDOUMsWUFBVSxNQUFNO0FBQ2QsVUFBTWtJLDJCQUEyQixZQUFZO0FBQzNDLFVBQUk7QUFDRixjQUFNakIsTUFBTSxNQUFNOUcsSUFBSStHLElBQUksNENBQTRDO0FBQ3RFLFlBQUlELElBQUlFLEtBQUtDLFNBQVM7QUFDcEJyRixvQ0FBMEJrRixJQUFJRSxLQUFLQSxRQUFRLEVBQUU7QUFBQSxRQUMvQztBQUFBLE1BQ0YsU0FBU0UsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx1QkFBdUJBLEtBQUs7QUFBQSxNQUM1QyxVQUFDO0FBQ0N4Rix1QkFBZSxLQUFLO0FBQUEsTUFDdEI7QUFBQSxJQUNGO0FBRUFxRyw2QkFBeUI7QUFBQSxFQUMzQixHQUFHLEVBQUU7QUFHTCxRQUFNQyxhQUFhLE9BQU9DLE9BQU87QUFDL0IsUUFBSTtBQUNGLFlBQU1uQixNQUFNLE1BQU05RyxJQUFJK0csSUFBSSxlQUFla0IsRUFBRSxFQUFFO0FBQzdDdkUsMkJBQXFCb0QsSUFBSUUsSUFBSTtBQUM3QjVELGtCQUFZLE1BQU07QUFDbEJFLDJCQUFxQixJQUFJO0FBQUEsSUFDM0IsU0FBUzRFLEtBQUs7QUFDWmYsY0FBUUQsTUFBTSwwQkFBMEJnQixHQUFHO0FBQzNDakMsYUFBTyxTQUFTLFNBQVMsa0NBQWtDO0FBQUEsSUFDN0Q7QUFBQSxFQUNGO0FBR0EsUUFBTWtDLGtCQUFrQixPQUFPRixJQUFJakIsU0FBUztBQUMxQyxRQUFJO0FBQ0YsWUFBTUYsTUFBTSxNQUFNOUcsSUFBSW9JLElBQUkscUJBQXFCSCxFQUFFLElBQUlqQixJQUFJO0FBQ3pELGFBQU9GLElBQUlFO0FBQUFBLElBQ2IsU0FBU0UsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDJCQUEyQkEsT0FBT21CLFVBQVVyQixRQUFRRSxNQUFNb0IsT0FBTztBQUMvRSxZQUFNcEI7QUFBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFHQSxRQUFNcUIsZ0JBQWdCLFlBQVk7QUFDaEMsUUFBSSxDQUFDOUUscUJBQXFCLENBQUNFLGNBQWU7QUFDMUMsVUFBTXlCLFFBQVF2QyxPQUFPd0MsS0FBSyxDQUFDQyxNQUFNQSxFQUFFQyxRQUFRNUIsYUFBYTtBQUN4RCxRQUFJLENBQUN5QixPQUFPO0FBQ1ZhLGFBQU8sU0FBUyxTQUFTLGtDQUFrQztBQUMzRDtBQUFBLElBQ0Y7QUFDQSxRQUFJO0FBQ0YsWUFBTWtDLGdCQUFnQjFFLGtCQUFrQjhCLEtBQUs7QUFBQSxRQUMzQ3ZCLFlBQVlvQixNQUFNRztBQUFBQSxRQUNsQkwsZ0JBQWdCRSxNQUFNRDtBQUFBQSxRQUN0QmxCLFFBQVE7QUFBQSxNQUNWLENBQUM7QUFDRGdDLGFBQU8sV0FBVyx5QkFBeUIseUJBQXlCYixNQUFNRCxJQUFJLEVBQUU7QUFDaEYzQix5QkFBbUIsS0FBSztBQUN4QkYsMkJBQXFCLEtBQUs7QUFDMUJNLHVCQUFpQixFQUFFO0FBQ25CRiwyQkFBcUIsSUFBSTtBQUN6QixVQUFJZixjQUFjLFVBQVU7QUFDMUJ5RSx3QkFBZ0I3RSxXQUFXO0FBQzNCc0UsMkJBQW1CO0FBQUEsTUFDckI7QUFBQSxJQUNGLFNBQVNLLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwyQkFBMkJBLEtBQUs7QUFDOUNqQixhQUFPLFNBQVMsU0FBUyw0QkFBNEI7QUFBQSxJQUN2RDtBQUFBLEVBQ0Y7QUFHQSxRQUFNdUMsZUFBZUEsTUFBTTtBQUN6QjFFLGVBQVc7QUFBQSxNQUNUQyxTQUFTO0FBQUEsTUFDVEMsWUFBWTtBQUFBLE1BQ1pDLFFBQVE7QUFBQSxNQUNSQyxVQUFVO0FBQUEsTUFDVkMsUUFBUTtBQUFBLElBQ1YsQ0FBQztBQUNEM0IsbUJBQWUsQ0FBQztBQUFBLEVBQ2xCO0FBR0EsUUFBTWlHLFNBQVMxSSxRQUFRLE9BQU87QUFBQSxJQUM1QjJJLFVBQVUvRyx1QkFBdUJnSCxPQUFPLENBQUFDLE1BQUtBLEVBQUU1RSxVQUFVLEVBQUU2RTtBQUFBQSxJQUMzREMsWUFBWW5ILHVCQUF1QmdILE9BQU8sQ0FBQUMsTUFBSyxDQUFDQSxFQUFFNUUsVUFBVSxFQUFFNkU7QUFBQUEsSUFDOUR4QyxNQUFNMUUsdUJBQXVCZ0gsT0FBTyxDQUFBQyxNQUFLQSxFQUFFM0UsV0FBVyxNQUFNLEVBQUU0RTtBQUFBQSxJQUM5REUsU0FBU3BILHVCQUF1QmdILE9BQU8sQ0FBQUMsTUFBS0EsRUFBRTNFLFdBQVcsWUFBWSxFQUFFNEU7QUFBQUEsSUFDdkVHLFFBQVFySCx1QkFBdUJnSCxPQUFPLENBQUFDLE1BQUtBLEVBQUUzRSxXQUFXLFFBQVEsRUFBRTRFO0FBQUFBLElBQ2xFbkIsT0FBTy9GLHVCQUF1QmtIO0FBQUFBLEVBQ2hDLElBQUksQ0FBQ2xILHNCQUFzQixDQUFDO0FBRzVCLFFBQU1zSCxhQUFhbEosUUFBUSxNQUFNO0FBQy9CLFdBQU9rQyxXQUFXaUgsSUFBSSxDQUFDakUsTUFBTWtFLFdBQVc7QUFBQSxNQUN0QzVELEtBQUtOLEtBQUtNO0FBQUFBLE1BQ1Y2RCxnQkFBZ0JuRSxLQUFLbUUsa0JBQWtCO0FBQUEsTUFDdkNDLEtBQUs5RyxjQUFjLEtBQUssS0FBSzRHLFFBQVE7QUFBQSxNQUNyQ0csVUFBVXJFLE1BQU1zRSxRQUFRcEUsUUFBUUYsS0FBS0U7QUFBQUEsTUFDckNwQixTQUFTa0IsS0FBS2xCO0FBQUFBLE1BQ2R5RixjQUFjeEUsZ0JBQWdCQyxJQUFJO0FBQUEsTUFDbENoQixRQUFRZ0IsS0FBS2hCO0FBQUFBLE1BQ2JLLE1BQU1GLFdBQVdhLEtBQUt3RSxTQUFTO0FBQUEsTUFDL0JDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsQ0FBQ2pFLE1BQU07QUFDZEEsZ0JBQUVrRSxnQkFBZ0I7QUFDbEJ6Ryw4QkFBZ0JELGlCQUFpQmdDLEtBQUtNLE1BQU0sT0FBT04sS0FBS00sR0FBRztBQUFBLFlBQzdEO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFBb0M7QUFBQTtBQUFBLFVBTGhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsUUFDQ3RDLGlCQUFpQmdDLEtBQUtNLE9BQ3JCLHVCQUFDLFNBQUksV0FBVSwwRUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLENBQUNFLE1BQU07QUFDZEEsa0JBQUVrRSxnQkFBZ0I7QUFDbEIzQiwyQkFBVy9DLEtBQUtNLEdBQUc7QUFDbkJyQyxnQ0FBZ0IsSUFBSTtBQUFBLGNBQ3RCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLE9BQUksTUFBTSxNQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWM7QUFBQSxnQkFDZCx1QkFBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVU7QUFBQTtBQUFBO0FBQUEsWUFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQ3VDLE1BQU07QUFDZEEsa0JBQUVrRSxnQkFBZ0I7QUFDbEJqRyxxQ0FBcUJ1QixJQUFJO0FBQ3pCckIsaUNBQWlCLEVBQUU7QUFDbkJSLDRCQUFZLFFBQVE7QUFDcEJFLHFDQUFxQixJQUFJO0FBQ3pCSixnQ0FBZ0IsSUFBSTtBQUFBLGNBQ3RCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQjtBQUFBLGdCQUNuQix1QkFBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVk7QUFBQTtBQUFBO0FBQUEsWUFaZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxXQXJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsSUFFSixFQUFFO0FBQUEsRUFDSixHQUFHLENBQUNqQixZQUFZTSxhQUFhVSxjQUFjSixNQUFNLENBQUM7QUFFbEQsTUFBSXBCLGVBQWVrQixjQUFjLFVBQVU7QUFDekMsV0FDRSxtQ0FDR3RCO0FBQUFBO0FBQUFBLE1BQ0QsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU87QUFBQSxNQUNQLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLCtCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFRO0FBQUEsUUFDUix1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbUNBQ2IsaUNBQUMsUUFBRyxXQUFVLG1DQUFrQyw2QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQsS0FEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiLGlDQUFDLFNBQUksU0FBUyxNQUFNdUIsYUFBYSxRQUFRLEdBQUcsV0FBVSx3QkFDcEQsaUNBQUMsU0FBSSxXQUFVLDZIQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdKQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1LO0FBQUEsWUFDbkssdUJBQUMsU0FBSSxXQUFVLGdCQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw0RUFDYixpQ0FBQyxVQUFLLFdBQVUsWUFDZCxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsbUNBQWtDLHNCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRDtBQUFBLGtCQUN0RCx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLHVDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RDtBQUFBLHFCQUY5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsdUNBQUMsU0FDQTtBQUFBLHlDQUFDLE9BQUUsV0FBVSxxQ0FBcUM2RixpQkFBT0MsWUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0U7QUFBQSxrQkFDakUsdUJBQUMsT0FBRSxXQUFVLHlCQUF3Qix3QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkM7QUFBQSxxQkFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ2hCO0FBQUEseUNBQUMsT0FBRSxXQUFVLG1DQUFtQ0QsaUJBQU9LLGNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtFO0FBQUEsa0JBQ2pELHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStDO0FBQUEscUJBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsZUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkEsS0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkE7QUFBQSxhQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0NBO0FBQUEsV0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVDQTtBQUFBLFNBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQ0E7QUFBQSxFQUVKO0FBRUQsU0FDQyxtQ0FDR3pIO0FBQUFBO0FBQUFBLElBQ0QsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUNQLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUNBQ1pzQjtBQUFBQSx1QkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2JDLDZCQUFhLElBQUk7QUFDakI0Riw2QkFBYTtBQUNiaEcsK0JBQWUsQ0FBQztBQUNoQk4sOEJBQWMsRUFBRTtBQUFBLGNBQ2xCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBNEU7QUFBQTtBQUFBLFlBUHhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFFRix1QkFBQyxRQUFHLFdBQVUsbUNBQWtDLDZCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLGFBZC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBRUMsQ0FBQ1MsYUFDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSxpQ0FBQyxTQUFJLFNBQVMsTUFBTUMsYUFBYSxRQUFRLEdBQUcsV0FBVSx3QkFDcEQsaUNBQUMsU0FBSSxXQUFVLDZIQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdKQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1LO0FBQUEsWUFDbkssdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDRFQUNiLGlDQUFDLFVBQUssV0FBVSxZQUNkLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdCLEtBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFFBQUcsV0FBVSxtQ0FBa0Msc0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNEO0FBQUEsb0JBQ3RELHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsdUNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTREO0FBQUEsdUJBRjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLE9BQUUsV0FBVSxxQ0FBcUM2RixpQkFBT0MsWUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0U7QUFBQSxvQkFDbEUsdUJBQUMsT0FBRSxXQUFVLHlCQUF3Qix3QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkM7QUFBQSx1QkFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxPQUFFLFdBQVUsbUNBQW1DRCxpQkFBT0ssY0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0U7QUFBQSxvQkFDbEUsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSx1QkFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSwrQ0FBOEMsZ0NBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThFO0FBQUEsZ0JBQzlFLHVCQUFDLFNBQUksV0FBVSwrR0FDYixpQ0FBQyxnQkFBYSxXQUFVLHdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGlCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQTtBQUFBLGVBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBLEtBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUNBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsc0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsT0FBSSxXQUFVLGdDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDLEtBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDBCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBLGNBQy9ELHVCQUFDLFFBQUcsV0FBVSxrREFDWjtBQUFBLHVDQUFDLFFBQUcsV0FBVSxjQUFhLGlFQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RTtBQUFBLGdCQUM1RSx1QkFBQyxRQUFHLFdBQVUsY0FBYSxpREFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEQ7QUFBQSxnQkFDNUQsdUJBQUMsUUFBRyxXQUFVLGNBQWEsOERBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlFO0FBQUEsbUJBSDNFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLGFBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvREE7QUFBQSxRQUlDbkcsY0FBYyxZQUNiLG1DQUVFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDhDQUVmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxTQUFTLE1BQU1rRCxnQkFBZ0IsRUFBRTtBQUFBLGdCQUNqQyxXQUFXLDhIQUNUaEMsUUFBUUksV0FBVyxLQUFLLHlDQUF5QyxvQkFBb0I7QUFBQSxnQkFHdkYsaUNBQUMsU0FBSSxXQUFVLG1CQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSwwRkFDYixpQ0FBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FDQztBQUFBLDZDQUFDLFFBQUcsV0FBVSxtQ0FBa0MscUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXFEO0FBQUEsc0JBQ3JELHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsMkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdEO0FBQUEseUJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSx1QkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsT0FBRSxXQUFVLG9DQUFvQ3dFLGlCQUFPZixTQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RCxLQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQTtBQUFBLGNBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXNCRTtBQUFBLFlBR0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU03QixnQkFBZ0IsTUFBTTtBQUFBLGdCQUNyQyxXQUFXLDhIQUNUaEMsUUFBUUksV0FBVyxTQUFTLDZDQUE2QyxvQkFBb0I7QUFBQSxnQkFHL0YsaUNBQUMsU0FBSSxXQUFVLHFCQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSw4RkFDYixpQ0FBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0IsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxRQUFHLFdBQVUsbUNBQWtDLG9CQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvRDtBQUFBLHNCQUNwRCx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLDhCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtRDtBQUFBLHlCQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLE9BQUUsV0FBVSxzQ0FBc0N3RSxpQkFBT3BDLFFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStELEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFlQTtBQUFBO0FBQUEsY0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBc0JBO0FBQUEsWUFHQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTVIsZ0JBQWdCLFlBQVk7QUFBQSxnQkFDM0MsV0FBVyw4SEFDVGhDLFFBQVFJLFdBQVcsZUFBZSw2Q0FBNkMsb0JBQW9CO0FBQUEsZ0JBR3JHLGlDQUFDLFNBQUksV0FBVSxxQkFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsOEZBQ2IsaUNBQUMsT0FBSSxNQUFNLE1BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBYyxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FDQztBQUFBLDZDQUFDLFFBQUcsV0FBVSxtQ0FBa0MsdUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVEO0FBQUEsc0JBQ3ZELHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsMkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdEO0FBQUEseUJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSx1QkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsT0FBRSxXQUFVLHNDQUFzQ3dFLGlCQUFPTSxXQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrRSxLQURwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQTtBQUFBLGNBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXNCQTtBQUFBLFlBR0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1sRCxnQkFBZ0IsUUFBUTtBQUFBLGdCQUN2QyxXQUFXLDhIQUNUaEMsUUFBUUksV0FBVyxXQUFXLDJDQUEyQyxvQkFBb0I7QUFBQSxnQkFHL0YsaUNBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSw0RkFDYixpQ0FBQyxrQkFBZSxNQUFNLE1BQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlCLEtBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUNDO0FBQUEsNkNBQUMsUUFBRyxXQUFVLG1DQUFrQyxzQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBc0Q7QUFBQSxzQkFDdEQsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0Q7QUFBQSx5QkFGdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxPQUFFLFdBQVUscUNBQXFDd0UsaUJBQU9PLFVBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdFLEtBRGxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFlQTtBQUFBO0FBQUEsY0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBc0JBO0FBQUEsZUFuR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvR0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFO0FBQUEsZ0JBQ3ZFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPbkYsUUFBUUU7QUFBQUEsb0JBQ2YsVUFBVXlCO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxJQUFHLDRCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBLHNCQUM1QixDQUFDLEdBQUcsSUFBSW9FLElBQUl6SCxjQUFjK0csSUFBSSxDQUFBTixNQUFLQSxFQUFFN0UsT0FBTyxDQUFDLENBQUMsRUFBRW1GO0FBQUFBLHdCQUFJLENBQUFuRixZQUNuRCx1QkFBQyxZQUFxQixPQUFPQSxTQUFVQSxxQkFBMUJBLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0M7QUFBQSxzQkFDaEQ7QUFBQTtBQUFBO0FBQUEsa0JBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVVBO0FBQUEsbUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQywyQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkU7QUFBQSxnQkFDM0U7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU9GLFFBQVFHO0FBQUFBLG9CQUNmLFVBQVV3QjtBQUFBQSxvQkFDVixXQUFVO0FBQUEsb0JBQ1YsVUFBVXpDO0FBQUFBLG9CQUVWO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcsNkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQThCO0FBQUEsc0JBQzlCLHVCQUFDLFlBQU8sT0FBTSxjQUFhLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxQztBQUFBLHNCQUNwQ0YsT0FBT3FHO0FBQUFBLHdCQUFJLENBQUE5RCxVQUNWLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU1HLEtBQU1ILGdCQUFNRCxRQUFwQ0MsTUFBTUcsS0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBc0Q7QUFBQSxzQkFDdkQ7QUFBQTtBQUFBO0FBQUEsa0JBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyxzQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQSxnQkFDdEU7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU8xQixRQUFRSTtBQUFBQSxvQkFDZixVQUFVdUI7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcsMEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJCO0FBQUEsc0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QjtBQUFBLHNCQUN6Qix1QkFBQyxZQUFPLE9BQU0sY0FBYSx1QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBa0M7QUFBQSxzQkFDbEMsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUE7QUFBQTtBQUFBLGtCQVQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVUE7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHlCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RTtBQUFBLGdCQUN6RTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU8zQixRQUFRSztBQUFBQSxvQkFDZixVQUFVc0I7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBO0FBQUEsa0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUs4QztBQUFBLG1CQVBoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RTtBQUFBLGdCQUN2RTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU8zQixRQUFRTTtBQUFBQSxvQkFDZixVQUFVcUI7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBO0FBQUEsa0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUs4QztBQUFBLG1CQVBoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBaEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNnRDtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQXlEO0FBQUE7QUFBQSxjQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQTFFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJFQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLGdGQUNaakgsc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHlDQUNiLGlDQUFDLFFBQUssTUFBSyxTQUFRLEtBQUksMkJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsSUFFQSxtQ0FDRTtBQUFBLG1DQUFDLE9BQUUsV0FBVSw4QkFBNkI7QUFBQTtBQUFBLGNBQy9CMEgsV0FBV0o7QUFBQUEsY0FBTztBQUFBLGNBQUt4RztBQUFBQSxjQUFnQjtBQUFBLGNBQW1CRTtBQUFBQSxjQUFZO0FBQUEsY0FBS0U7QUFBQUEsY0FBVztBQUFBLGlCQURqRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU13RztBQUFBQSxnQkFDTixTQUFTO0FBQUEsa0JBQ1AsRUFBRVksS0FBSyxrQkFBa0JDLFFBQVEsaUJBQWlCO0FBQUEsa0JBQ2xELEVBQUVELEtBQUssWUFBWUMsUUFBUSxPQUFPO0FBQUEsa0JBQ2xDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsa0JBQ3BDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGNBQWM7QUFBQSxrQkFDN0MsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxrQkFDbEMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLE9BQU87QUFBQSxrQkFDOUIsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxnQkFBQztBQUFBLGdCQUVyQyxTQUFRO0FBQUEsZ0JBQ1IsaUJBQWlCO0FBQUEsZ0JBQ2pCLGtCQUFpQjtBQUFBLGdCQUNqQixpQkFBZ0I7QUFBQTtBQUFBLGNBZGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWNxQztBQUFBLFlBRXBDckgsYUFBYSxLQUNaLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNGO0FBQUFBLGdCQUNULE9BQU9GO0FBQUFBLGdCQUNQLFVBQVU7QUFBQSxnQkFDVixVQUFVLENBQUNnRixTQUFTN0UsZUFBZTZFLElBQUk7QUFBQSxnQkFDdkMsaUJBQWlCO0FBQUE7QUFBQSxjQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLeUIsS0FOM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBLEtBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUNBO0FBQUEsYUE5TkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStOQTtBQUFBLFFBSUQ5RCxtQkFDQyx1QkFBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBCQUF5QixnQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxVQUN2RDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBT0k7QUFBQUEsY0FDUCxVQUFVLENBQUM4QixNQUFNN0IsaUJBQWlCNkIsRUFBRUUsT0FBT0QsS0FBSztBQUFBLGNBRWhEO0FBQUEsdUNBQUMsWUFBTyxPQUFNLElBQUcsK0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsZ0JBQy9CN0MsT0FBT3FHO0FBQUFBLGtCQUFJLENBQUM5RCxVQUNYLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU1HLEtBQ2xDSDtBQUFBQSwwQkFBTUQ7QUFBQUEsb0JBQUs7QUFBQSxvQkFBRUMsTUFBTTJFLFFBQVEsS0FBSzNFLE1BQU0yRSxLQUFLLEtBQUs7QUFBQSx1QkFEdEMzRSxNQUFNRyxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBO0FBQUEsWUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU0vQixtQkFBbUIsS0FBSztBQUFBLGdCQUN2QyxXQUFVO0FBQUEsZ0JBQStCO0FBQUE7QUFBQSxjQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTK0U7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUNWLFVBQVUsQ0FBQzVFO0FBQUFBLGdCQUFjO0FBQUE7QUFBQSxjQUgzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLGFBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2QkEsS0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQTtBQUFBLFFBSUZOLHFCQUFxQkkscUJBQzdCLHVCQUFDLFNBQUksV0FBVSxtRUFDYixpQ0FBQyxTQUFJLFdBQVUsMkZBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLGlDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLFlBQ3JFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNSCxxQkFBcUIsS0FBSztBQUFBLGdCQUN6QyxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBWTtBQUFBO0FBQUEsY0FKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHlDQUdkO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0Msb0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsY0FDcEU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT0csa0JBQWtCMEIsUUFBUTFCLGtCQUFrQjhGLFFBQVFwRSxRQUFRO0FBQUEsa0JBQ25FO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRzZGO0FBQUEsaUJBTC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGNBQ3RFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU8xQixrQkFBa0J1RyxVQUFVdkcsa0JBQWtCOEYsUUFBUVUsZ0JBQWdCO0FBQUEsa0JBQzdFO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRzZGO0FBQUEsaUJBTC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RTtBQUFBLGNBQ3ZFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU94RyxrQkFBa0JNLFdBQVc7QUFBQSxrQkFDcEM7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHNkY7QUFBQSxpQkFML0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBR0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBFO0FBQUEsY0FDMUU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTyxPQUFPTixrQkFBa0J5RyxnQkFBZ0IsV0FDNUN6RyxrQkFBa0J5RyxhQUFhekQsU0FBUyxLQUN4Q2hELGtCQUFrQnlHLGVBQWU7QUFBQSxrQkFDckM7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLNkY7QUFBQSxpQkFQL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBR0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsMkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJFO0FBQUEsY0FDM0U7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT2xGLGdCQUFnQnZCLGlCQUFpQjtBQUFBLGtCQUN4QztBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUc2RjtBQUFBLGlCQUwvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFHQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyxzQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0U7QUFBQSxjQUN0RTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPQSxrQkFBa0JRLFVBQVU7QUFBQSxrQkFDbkM7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHNkY7QUFBQSxpQkFML0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBR0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0Msb0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsY0FDcEU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT0csV0FBV1gsa0JBQWtCZ0csU0FBUztBQUFBLGtCQUM3QztBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUc2RjtBQUFBLGlCQUwvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RTtBQUFBLGNBQ3ZFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU07QUFBQSxrQkFDTixPQUFPaEcsa0JBQWtCNkUsV0FBVztBQUFBLGtCQUNwQztBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUk2RjtBQUFBLGlCQU4vRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFHQzdFLGtCQUFrQjBHLHFCQUFxQjFHLGtCQUFrQjBHLGtCQUFrQnRCLFNBQVMsS0FDbkYsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsZ0JBQ2hEcEYsa0JBQWtCMEcsa0JBQWtCdEI7QUFBQUEsZ0JBQU87QUFBQSxtQkFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNacEYsNEJBQWtCMEcsa0JBQWtCakIsSUFBSSxDQUFDa0IsTUFBTWpCLFVBQVU7QUFFeEQsb0JBQUlrQixVQUFVO0FBQ2Qsb0JBQUlyRSxXQUFXLGNBQWNtRCxRQUFRLENBQUM7QUFFdEMsb0JBQUksT0FBT2lCLFNBQVMsVUFBVTtBQUM1QkMsNEJBQVVELEtBQUtyRSxPQUFPO0FBQ3RCQyw2QkFBV29FLEtBQUtqRixRQUFRLGNBQWNnRSxRQUFRLENBQUM7QUFBQSxnQkFDakQsV0FBVyxPQUFPaUIsU0FBUyxVQUFVO0FBQ25DQyw0QkFBVUQ7QUFDVnBFLDZCQUFXLGNBQWNtRCxRQUFRLENBQUM7QUFBQSxnQkFDcEM7QUFHQSxvQkFBSSxDQUFDa0IsUUFBUyxRQUFPO0FBR3JCLHNCQUFNQyxVQUFVRCxRQUFRL0QsTUFBTSw2QkFBNkIsS0FDNUMrRCxRQUFROUQsU0FBUyxlQUFlLEtBQ2hDUCxTQUFTTSxNQUFNLDZCQUE2QjtBQUUzRCx1QkFDRTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFFQyxTQUFTLE1BQU1SLHNCQUFzQnVFLFNBQVNyRSxRQUFRO0FBQUEsb0JBQ3RELFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFNBQUksV0FBVSw2RkFDWnNFO0FBQUFBLGtDQUNDO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLEtBQUtEO0FBQUFBLDRCQUNMLEtBQUtyRTtBQUFBQSw0QkFDTCxXQUFVO0FBQUEsNEJBQ1YsU0FBUyxDQUFDUCxNQUFNO0FBQ2QwQixzQ0FBUUQsTUFBTSx5QkFBeUJtRCxPQUFPO0FBQzlDNUUsZ0NBQUVFLE9BQU80RSxVQUFVO0FBQ25COUUsZ0NBQUVFLE9BQU82RSxNQUFNO0FBQUEsNEJBQ2pCO0FBQUE7QUFBQSwwQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUUksSUFHSix1QkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSxpREFBQyxTQUFJLFdBQVUsaUJBQWdCLGtCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFpQztBQUFBLDBCQUNqQyx1QkFBQyxVQUFLLFdBQVUsdUJBQXVCeEUsc0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdEO0FBQUEsNkJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBR0E7QUFBQSx3QkFFRix1QkFBQyxTQUFJLFdBQVUsOEdBQ2IsaUNBQUMsVUFBSyxXQUFVLG9EQUFtRDtBQUFBO0FBQUEsMEJBQ3ZEc0UsVUFBVSxTQUFTO0FBQUEsNkJBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsMkJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBdUJBO0FBQUEsc0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDBEQUF5RCxPQUFPdEUsVUFDMUVBLG1CQUFTNkMsU0FBUyxLQUFLN0MsU0FBU3lFLFVBQVUsR0FBRyxFQUFFLElBQUksUUFBUXpFLFlBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQTtBQUFBO0FBQUEsa0JBOUJLbUQ7QUFBQUEsa0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFnQ0E7QUFBQSxjQUVKLENBQUMsS0F6REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwREE7QUFBQSxpQkE5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErREE7QUFBQSxZQUlEaEcsYUFBYSxZQUNaLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MseUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlFO0FBQUEsY0FDekU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT1E7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDOEIsTUFBTTdCLGlCQUFpQjZCLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxrQkFDaEQsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsWUFBTyxPQUFNLElBQUcsK0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsb0JBQy9CN0MsT0FBT3FHO0FBQUFBLHNCQUFJLENBQUE5RCxVQUNWLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU1HLEtBQ2xDSDtBQUFBQSw4QkFBTUQ7QUFBQUEsd0JBQUs7QUFBQSx3QkFBSUMsTUFBTTJFO0FBQUFBLDJCQURYM0UsTUFBTUcsS0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLGVBektKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMktBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTWpDLHFCQUFxQixLQUFLO0FBQUEsZ0JBQ3pDLFdBQVU7QUFBQSxnQkFBK0M7QUFBQTtBQUFBLGNBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQ0gsYUFBYSxZQUNaO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBU29GO0FBQUFBLGdCQUNULFVBQVUsQ0FBQzVFO0FBQUFBLGdCQUNYLFdBQVU7QUFBQSxnQkFBOEQ7QUFBQTtBQUFBLGNBSDFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLGFBdE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1TUEsS0F4TUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlNQTtBQUFBLFFBSVM5QixvQkFDQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNQyxvQkFBb0IsS0FBSztBQUFBLFlBRXhDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxDQUFDMkQsTUFBTTtBQUFFQSxzQkFBRWtFLGdCQUFnQjtBQUFHN0gsd0NBQW9CLEtBQUs7QUFBQSxrQkFBRztBQUFBLGtCQUNuRSxXQUFVO0FBQUEsa0JBRVYsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBWTtBQUFBO0FBQUEsZ0JBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLEtBQUtDO0FBQUFBLGtCQUNMLEtBQUk7QUFBQSxrQkFDSixXQUFVO0FBQUEsa0JBQ1YsU0FBUyxDQUFDMEQsTUFBTTtBQUNkMEIsNEJBQVFELE1BQU0saUNBQWlDbkYsZUFBZTtBQUM5RGtFLDJCQUFPLFNBQVMsU0FBUyxzQkFBc0I7QUFDL0NuRSx3Q0FBb0IsS0FBSztBQUFBLGtCQUMzQjtBQUFBO0FBQUEsZ0JBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUk7QUFBQTtBQUFBO0FBQUEsVUFsQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0JBO0FBQUEsV0F0akJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3akJFO0FBQUEsU0ExakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyakJFO0FBQUEsT0E5akJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErakJFO0FBRUo7QUFBQ1gsR0ExOUJRRCxVQUFRO0FBQUEsVUFDY2pCLGFBQWFxQixlQUFlO0FBQUE7QUFBQW9KLEtBRGxEeEo7QUE0OUJULGVBQWVBO0FBQVMsSUFBQXdKO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJBUEkiLCJub3RpZmljYXRpb24iLCJQYWdpbmF0aW9uIiwiU3BpbiIsIlNpZGViYXIiLCJOYXZiYXIiLCJVc2VycyIsIkNoZXZyb25SaWdodCIsIlphcCIsIkNsaXBib2FyZENoZWNrIiwiWCIsIkV5ZSIsIlVzZXJQbHVzIiwiQWxlcnRDaXJjbGUiLCJEYXRhVGFibGUiLCJCYXNlVVJMIiwiQ2lyY3VsYXJMb2FkZXIiLCJNZEFzc2lnbm1lbnRJbmQiLCJTdXBwb3J0cyIsIl9zIiwiYXBpIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImluaXRpYWxMb2FkIiwic2V0SW5pdGlhbExvYWQiLCJhbGxDb21wbGFpbnRzRm9yQ291bnRzIiwic2V0QWxsQ29tcGxhaW50c0ZvckNvdW50cyIsImltYWdlUHJldmlld09wZW4iLCJzZXRJbWFnZVByZXZpZXdPcGVuIiwicHJldmlld0ltYWdlU3JjIiwic2V0UHJldmlld0ltYWdlU3JjIiwiY29tcGxhaW50cyIsInNldENvbXBsYWludHMiLCJhbGxDb21wbGFpbnRzIiwic2V0QWxsQ29tcGxhaW50cyIsInRvdGFsQ29tcGxhaW50cyIsInNldFRvdGFsQ29tcGxhaW50cyIsImN1cnJlbnRQYWdlIiwic2V0Q3VycmVudFBhZ2UiLCJ0b3RhbFBhZ2VzIiwic2V0VG90YWxQYWdlcyIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImFnZW50cyIsInNldEFnZW50cyIsImxvYWRpbmdBZ2VudHMiLCJzZXRMb2FkaW5nQWdlbnRzIiwib3BlbkFjdGlvbklkIiwic2V0T3BlbkFjdGlvbklkIiwidmlld01vZGUiLCJzZXRWaWV3TW9kZSIsInZpZXdFZGl0TW9kYWxPcGVuIiwic2V0Vmlld0VkaXRNb2RhbE9wZW4iLCJhc3NpZ25Nb2RhbE9wZW4iLCJzZXRBc3NpZ25Nb2RhbE9wZW4iLCJzZWxlY3RlZENvbXBsYWludCIsInNldFNlbGVjdGVkQ29tcGxhaW50Iiwic2VsZWN0ZWRBZ2VudCIsInNldFNlbGVjdGVkQWdlbnQiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsInN1YmplY3QiLCJhc3NpZ25lZFRvIiwic3RhdHVzIiwiZnJvbURhdGUiLCJ0b0RhdGUiLCJmb3JtYXREYXRlIiwiZGF0ZVN0cmluZyIsImRhdGUiLCJEYXRlIiwiZGF5IiwiU3RyaW5nIiwiZ2V0RGF0ZSIsInBhZFN0YXJ0IiwibW9udGgiLCJnZXRNb250aCIsInllYXIiLCJnZXRGdWxsWWVhciIsImdldEFzc2lnbmVlTmFtZSIsIml0ZW0iLCJhc3NpZ25lZFRvTmFtZSIsIm5hbWUiLCJhZ2VudCIsImZpbmQiLCJhIiwiX2lkIiwiaGFuZGxlRmlsdGVyQ2hhbmdlIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwicHJldiIsImhhbmRsZUNhcmRDbGljayIsImhhbmRsZUF0dGFjaG1lbnRDbGljayIsInVybCIsImZpbGVOYW1lIiwibm90aWZ5IiwidG9Mb3dlckNhc2UiLCJlbmRzV2l0aCIsIndpbmRvdyIsIm9wZW4iLCJtYXRjaCIsImluY2x1ZGVzIiwidHlwZSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJwbGFjZW1lbnQiLCJkdXJhdGlvbiIsImZldGNoQWxsQ29tcGxhaW50cyIsInJlcyIsImdldCIsImRhdGEiLCJzdWNjZXNzIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hDb21wbGFpbnRzIiwicGFnZSIsInBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsImFwcGVuZCIsInRvU3RyaW5nIiwidG90YWwiLCJmZXRjaEFnZW50cyIsImFnZW50c0xpc3QiLCJBcnJheSIsImlzQXJyYXkiLCJmZXRjaENvbXBsYWludHNGb3JDb3VudHMiLCJoYW5kbGVWaWV3IiwiaWQiLCJlcnIiLCJ1cGRhdGVDb21wbGFpbnQiLCJwdXQiLCJyZXNwb25zZSIsIm1lc3NhZ2UiLCJjb25maXJtQXNzaWduIiwicmVzZXRGaWx0ZXJzIiwiY291bnRzIiwiYXNzaWduZWQiLCJmaWx0ZXIiLCJjIiwibGVuZ3RoIiwidW5hc3NpZ25lZCIsInBlbmRpbmciLCJjbG9zZWQiLCJ0YWJsZURhdGExIiwibWFwIiwiaW5kZXgiLCJjb21wbGFpbnRfY29kZSIsInNsIiwidXNlck5hbWUiLCJ1c2VySWQiLCJhc3NpZ25lZE5hbWUiLCJjcmVhdGVkQXQiLCJhY3Rpb24iLCJzdG9wUHJvcGFnYXRpb24iLCJTZXQiLCJrZXkiLCJoZWFkZXIiLCJlbWFpbCIsIm1vYmlsZSIsInBob25lX251bWJlciIsImRlc2lnbmF0aW9uIiwiY29tcGxhaW50X3VwbG9hZHMiLCJmaWxlIiwiZmlsZVVybCIsImlzSW1hZ2UiLCJvbmVycm9yIiwic3JjIiwic3Vic3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU3VwcG9ydHMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIC8qIGVzbGludC1kaXNhYmxlIHJlYWN0L3Byb3AtdHlwZXMgKi9cclxuLy8gaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG4vLyBpbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbi8vIGltcG9ydCB7IG5vdGlmaWNhdGlvbiwgUGFnaW5hdGlvbiwgU3BpbiB9IGZyb20gXCJhbnRkXCI7XHJcbi8vIGltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG4vLyBpbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbi8vIGltcG9ydCB7IFVzZXJzLCBDaGV2cm9uUmlnaHQsIFphcCwgQ2xpcGJvYXJkQ2hlY2ssIFgsIEV5ZSwgVXNlclBsdXMsIEFsZXJ0Q2lyY2xlIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG4vLyBpbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbi8vIGltcG9ydCBCYXNlVVJMIGZyb20gXCIuLi9pbnN0YW5jZS9CYXNlVXJsXCI7XHJcbi8vIGltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbi8vIGltcG9ydCB7IE1kQXNzaWdubWVudEluZCB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5cclxuLy8gZnVuY3Rpb24gU3VwcG9ydHMoKSB7XHJcbi8vICAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcbiAgXHJcbi8vICAgLy8gLS0tIExPQURJTkcgU1RBVEUgLS0tXHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbaW5pdGlhbExvYWQsIHNldEluaXRpYWxMb2FkXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4vLyAgIGNvbnN0IFthbGxDb21wbGFpbnRzRm9yQ291bnRzLCBzZXRBbGxDb21wbGFpbnRzRm9yQ291bnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBcclxuLy8gICAvLyAtLS0gSU1BR0UgUFJFVklFVyBTVEFURSAtLS1cclxuLy8gICBjb25zdCBbaW1hZ2VQcmV2aWV3T3Blbiwgc2V0SW1hZ2VQcmV2aWV3T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3ByZXZpZXdJbWFnZVNyYywgc2V0UHJldmlld0ltYWdlU3JjXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIFxyXG4vLyAgIC8vIC0tLSBEQVRBIFNUQVRFIC0tLVxyXG4vLyAgIGNvbnN0IFtjb21wbGFpbnRzLCBzZXRDb21wbGFpbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbYWxsQ29tcGxhaW50cywgc2V0QWxsQ29tcGxhaW50c10gPSB1c2VTdGF0ZShbXSk7IFxyXG4vLyAgIGNvbnN0IFt0b3RhbENvbXBsYWludHMsIHNldFRvdGFsQ29tcGxhaW50c10gPSB1c2VTdGF0ZSgwKTtcclxuLy8gICBjb25zdCBbY3VycmVudFBhZ2UsIHNldEN1cnJlbnRQYWdlXSA9IHVzZVN0YXRlKDEpO1xyXG4vLyAgIGNvbnN0IFt0b3RhbFBhZ2VzLCBzZXRUb3RhbFBhZ2VzXSA9IHVzZVN0YXRlKDEpO1xyXG4vLyAgIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBcclxuLy8gICAvLyAtLS0gQUdFTlRTIFNUQVRFIC0tLVxyXG4vLyAgIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2xvYWRpbmdBZ2VudHMsIHNldExvYWRpbmdBZ2VudHNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIFxyXG4vLyAgIC8vIC0tLSBNT0RBTCAmIEFDVElPTiBTVEFURSAtLS1cclxuLy8gICBjb25zdCBbb3BlbkFjdGlvbklkLCBzZXRPcGVuQWN0aW9uSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW3ZpZXdNb2RlLCBzZXRWaWV3TW9kZV0gPSB1c2VTdGF0ZShcInZpZXdcIik7XHJcbi8vICAgY29uc3QgW3ZpZXdFZGl0TW9kYWxPcGVuLCBzZXRWaWV3RWRpdE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2Fzc2lnbk1vZGFsT3Blbiwgc2V0QXNzaWduTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRDb21wbGFpbnQsIHNldFNlbGVjdGVkQ29tcGxhaW50XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEFnZW50LCBzZXRTZWxlY3RlZEFnZW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIFxyXG4vLyAgIC8vIC0tLSBGSUxURVJTIFNUQVRFIC0tLVxyXG4vLyAgIGNvbnN0IFtmaWx0ZXJzLCBzZXRGaWx0ZXJzXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHN1YmplY3Q6IFwiXCIsXHJcbi8vICAgICBhc3NpZ25lZFRvOiBcIlwiLFxyXG4vLyAgICAgc3RhdHVzOiBcIlwiLFxyXG4vLyAgICAgZnJvbURhdGU6IFwiXCIsXHJcbi8vICAgICB0b0RhdGU6IFwiXCIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIC8vIC0tLSBIRUxQRVI6IEZvcm1hdCBEYXRlIC0tLVxyXG4vLyAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4vLyAgICAgaWYgKCFkYXRlU3RyaW5nKSByZXR1cm4gXCJcIjtcclxuLy8gICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyaW5nKTtcclxuLy8gICAgIGNvbnN0IGRheSA9IFN0cmluZyhkYXRlLmdldERhdGUoKSkucGFkU3RhcnQoMiwgJzAnKTtcclxuLy8gICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbi8vICAgICBjb25zdCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xyXG4vLyAgICAgcmV0dXJuIGAke2RheX0vJHttb250aH0vJHt5ZWFyfWA7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gLS0tIEhFTFBFUjogR0VUIEFTU0lHTkVFIE5BTUUgLS0tXHJcbi8vICAgY29uc3QgZ2V0QXNzaWduZWVOYW1lID0gKGl0ZW0pID0+IHtcclxuLy8gICAgIGlmIChpdGVtLmFzc2lnbmVkVG9OYW1lKSByZXR1cm4gaXRlbS5hc3NpZ25lZFRvTmFtZTtcclxuLy8gICAgIGlmICghaXRlbS5hc3NpZ25lZFRvKSByZXR1cm4gXCJVbmFzc2lnbmVkXCI7XHJcbi8vICAgICBpZiAodHlwZW9mIGl0ZW0uYXNzaWduZWRUbyA9PT0gXCJvYmplY3RcIiAmJiBpdGVtLmFzc2lnbmVkVG8ubmFtZSkge1xyXG4vLyAgICAgICByZXR1cm4gaXRlbS5hc3NpZ25lZFRvLm5hbWU7XHJcbi8vICAgICB9XHJcbi8vICAgICBpZiAodHlwZW9mIGl0ZW0uYXNzaWduZWRUbyA9PT0gXCJzdHJpbmdcIikge1xyXG4vLyAgICAgICBjb25zdCBhZ2VudCA9IGFnZW50cy5maW5kKGEgPT4gU3RyaW5nKGEuX2lkKSA9PT0gU3RyaW5nKGl0ZW0uYXNzaWduZWRUbykpO1xyXG4vLyAgICAgICByZXR1cm4gYWdlbnQgPyBhZ2VudC5uYW1lIDogXCJVbmtub3duIEFkbWluXCI7XHJcbi8vICAgICB9XHJcbi8vICAgICByZXR1cm4gXCJVbmFzc2lnbmVkXCI7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gLS0tIEZJTFRFUiBDSEFOR0UgSEFORExFUiAtLS1cclxuLy8gICBjb25zdCBoYW5kbGVGaWx0ZXJDaGFuZ2UgPSAoZSkgPT4ge1xyXG4vLyAgICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbi8vICAgICBzZXRGaWx0ZXJzKHByZXYgPT4gKHtcclxuLy8gICAgICAgLi4ucHJldixcclxuLy8gICAgICAgW25hbWVdOiB2YWx1ZSxcclxuLy8gICAgIH0pKTtcclxuLy8gICAgIHNldEN1cnJlbnRQYWdlKDEpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIC0tLSBEQVNIQk9BUkQgQ0FSRCBDTElDSyBIQU5ETEVSIC0tLVxyXG4vLyAgIGNvbnN0IGhhbmRsZUNhcmRDbGljayA9IChzdGF0dXMpID0+IHtcclxuLy8gICAgIHNldEZpbHRlcnMocHJldiA9PiAoe1xyXG4vLyAgICAgICAuLi5wcmV2LFxyXG4vLyAgICAgICBzdGF0dXM6IHByZXYuc3RhdHVzID09PSBzdGF0dXMgPyBcIlwiIDogc3RhdHVzXHJcbi8vICAgICB9KSk7XHJcbi8vICAgICBzZXRDdXJyZW50UGFnZSgxKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyAtLS0gQVRUQUNITUVOVCBDTElDSyBIQU5ETEVSIC0tLVxyXG4vLyAgIGNvbnN0IGhhbmRsZUF0dGFjaG1lbnRDbGljayA9ICh1cmwsIGZpbGVOYW1lKSA9PiB7XHJcbi8vICAgICBpZiAoZmlsZU5hbWUgJiYgZmlsZU5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnBkZicpKSB7XHJcbi8vICAgICAgIHdpbmRvdy5vcGVuKHVybCwgJ19ibGFuaycpO1xyXG4vLyAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgc2V0UHJldmlld0ltYWdlU3JjKHVybCk7XHJcbi8vICAgICAgIHNldEltYWdlUHJldmlld09wZW4odHJ1ZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gLS0tIE5PVElGSUNBVElPTiBIRUxQRVIgLS0tXHJcbi8vICAgY29uc3Qgbm90aWZ5ID0gKHR5cGUsIHRpdGxlLCBkZXNjcmlwdGlvbikgPT4ge1xyXG4vLyAgICAgYXBpW3R5cGVdKHtcclxuLy8gICAgICAgdGl0bGUsXHJcbi8vICAgICAgIGRlc2NyaXB0aW9uLFxyXG4vLyAgICAgICBwbGFjZW1lbnQ6IFwidG9wXCIsXHJcbi8vICAgICAgIGR1cmF0aW9uOiAyLFxyXG4vLyAgICAgfSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gLS0tIEZFVENIIEFMTCBDT01QTEFJTlRTIChmb3IgY291bnRzIC0gbm8gZmlsdGVycykgLS0tXHJcbi8vICAgY29uc3QgZmV0Y2hBbGxDb21wbGFpbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLmdldChgY29tcGxhaW50cy9hbGwtcGFnaW5hdGVkP3BhZ2U9MSZsaW1pdD0xMDAwYCk7XHJcbi8vICAgICAgIGlmIChyZXMuZGF0YS5zdWNjZXNzKSB7XHJcbi8vICAgICAgICAgc2V0QWxsQ29tcGxhaW50cyhyZXMuZGF0YS5kYXRhIHx8IFtdKTtcclxuLy8gICAgICAgICBzZXRBbGxDb21wbGFpbnRzRm9yQ291bnRzKHJlcy5kYXRhLmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRmV0Y2ggYWxsIGNvbXBsYWludHMgZXJyb3I6XCIsIGVycm9yKTtcclxuLy8gICAgICAgc2V0QWxsQ29tcGxhaW50cyhbXSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gLS0tIEZFVENIIENPTVBMQUlOVFMgKHdpdGggZmlsdGVycykgLS0tXHJcbi8vICAgY29uc3QgZmV0Y2hDb21wbGFpbnRzID0gYXN5bmMgKHBhZ2UgPSAxKSA9PiB7XHJcbi8vICAgICBpZiAoYWN0aXZlVGFiICE9PSBcImFzc2lnblwiKSB7XHJcbi8vICAgICAgIHNldEluaXRpYWxMb2FkKGZhbHNlKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XHJcbi8vICAgICAgIHBhcmFtcy5hcHBlbmQoJ3BhZ2UnLCBwYWdlKTtcclxuLy8gICAgICAgcGFyYW1zLmFwcGVuZCgnbGltaXQnLCAxMCk7XHJcbiAgICAgIFxyXG4vLyAgICAgICBpZiAoZmlsdGVycy5zdWJqZWN0ICYmIGZpbHRlcnMuc3ViamVjdCAhPT0gJycpIHtcclxuLy8gICAgICAgICBwYXJhbXMuYXBwZW5kKCdzdWJqZWN0JywgZmlsdGVycy5zdWJqZWN0KTtcclxuLy8gICAgICAgfVxyXG5cclxuLy8gICAgICAgaWYgKGZpbHRlcnMuc3RhdHVzICYmIGZpbHRlcnMuc3RhdHVzICE9PSAnJykge1xyXG4vLyAgICAgICAgIHBhcmFtcy5hcHBlbmQoJ3N0YXR1cycsIGZpbHRlcnMuc3RhdHVzKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgICBpZiAoZmlsdGVycy5hc3NpZ25lZFRvICYmIGZpbHRlcnMuYXNzaWduZWRUbyAhPT0gJycpIHtcclxuLy8gICAgICAgICBwYXJhbXMuYXBwZW5kKCdhc3NpZ25lZFRvJywgZmlsdGVycy5hc3NpZ25lZFRvKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgICBpZiAoZmlsdGVycy5mcm9tRGF0ZSkge1xyXG4vLyAgICAgICAgIHBhcmFtcy5hcHBlbmQoJ2Zyb21EYXRlJywgZmlsdGVycy5mcm9tRGF0ZSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgICAgaWYgKGZpbHRlcnMudG9EYXRlKSB7XHJcbi8vICAgICAgICAgcGFyYW1zLmFwcGVuZCgndG9EYXRlJywgZmlsdGVycy50b0RhdGUpO1xyXG4vLyAgICAgICB9XHJcbiAgICAgIFxyXG4vLyAgICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkuZ2V0KGBjb21wbGFpbnRzL2FsbC1wYWdpbmF0ZWQ/JHtwYXJhbXMudG9TdHJpbmcoKX1gKTtcclxuLy8gICAgICAgaWYgKHJlcy5kYXRhLnN1Y2Nlc3MpIHtcclxuLy8gICAgICAgICBzZXRDb21wbGFpbnRzKHJlcy5kYXRhLmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICAgIHNldFRvdGFsQ29tcGxhaW50cyhyZXMuZGF0YS50b3RhbCB8fCAwKTtcclxuLy8gICAgICAgICBzZXRUb3RhbFBhZ2VzKHJlcy5kYXRhLnRvdGFsUGFnZXMgfHwgMSk7XHJcbi8vICAgICAgICAgc2V0Q3VycmVudFBhZ2UocmVzLmRhdGEucGFnZSB8fCAxKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkZldGNoIGVycm9yOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIG5vdGlmeShcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJGYWlsZWQgdG8gbG9hZCBjb21wbGFpbnRzXCIpO1xyXG4vLyAgICAgICBzZXRDb21wbGFpbnRzKFtdKTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICAgIHNldEluaXRpYWxMb2FkKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyAtLS0gRkVUQ0ggQUdFTlRTIC0tLVxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBzZXRMb2FkaW5nQWdlbnRzKHRydWUpO1xyXG4vLyAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoXCIvYWRtaW4vZ2V0LXN1Yi1hZG1pbnNcIik7XHJcbi8vICAgICAgICAgY29uc3QgYWdlbnRzTGlzdCA9IEFycmF5LmlzQXJyYXkocmVzLmRhdGEpID8gcmVzLmRhdGEgOiBbXTtcclxuLy8gICAgICAgICBzZXRBZ2VudHMoYWdlbnRzTGlzdCk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcIkZldGNoIGFnZW50cyBlcnJvcjpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICAgIHNldEFnZW50cyhbXSk7XHJcbi8vICAgICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgICAgc2V0TG9hZGluZ0FnZW50cyhmYWxzZSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaEFnZW50cygpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgLy8gLS0tIEZFVENIIEFMTCBDT01QTEFJTlRTIEZPUiBDT1VOVFMgLS0tXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGlmIChhY3RpdmVUYWIgPT09IFwiYXNzaWduXCIpIHtcclxuLy8gICAgICAgZmV0Y2hBbGxDb21wbGFpbnRzKCk7XHJcbi8vICAgICB9XHJcbi8vICAgfSwgW2FjdGl2ZVRhYl0pO1xyXG5cclxuLy8gICAvLyAtLS0gRkVUQ0ggQ09NUExBSU5UUyBPTiBUQUIvRklMVEVSIENIQU5HRSAtLS1cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJhc3NpZ25cIikge1xyXG4vLyAgICAgICBmZXRjaENvbXBsYWludHMoY3VycmVudFBhZ2UpO1xyXG4vLyAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgc2V0Q29tcGxhaW50cyhbXSk7XHJcbi8vICAgICAgIHNldEluaXRpYWxMb2FkKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9LCBbY3VycmVudFBhZ2UsIGZpbHRlcnMsIGFjdGl2ZVRhYl0pO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hDb21wbGFpbnRzRm9yQ291bnRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoJ2NvbXBsYWludHMvYWxsLXBhZ2luYXRlZD9wYWdlPTEmbGltaXQ9MTAwMCcpO1xyXG4vLyAgICAgICAgIGlmIChyZXMuZGF0YS5zdWNjZXNzKSB7XHJcbi8vICAgICAgICAgICBzZXRBbGxDb21wbGFpbnRzRm9yQ291bnRzKHJlcy5kYXRhLmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRmV0Y2ggY291bnRzIGVycm9yOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgICAgc2V0SW5pdGlhbExvYWQoZmFsc2UpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG4gICAgXHJcbi8vICAgICBmZXRjaENvbXBsYWludHNGb3JDb3VudHMoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8vIC0tLSBWSUVXIENPTVBMQUlOVCAtLS1cclxuLy8gICBjb25zdCBoYW5kbGVWaWV3ID0gYXN5bmMgKGlkKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkuZ2V0KGAvY29tcGxhaW50cy8ke2lkfWApO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZENvbXBsYWludChyZXMuZGF0YSk7XHJcbi8vICAgICAgIHNldFZpZXdNb2RlKFwidmlld1wiKTtcclxuLy8gICAgICAgc2V0Vmlld0VkaXRNb2RhbE9wZW4odHJ1ZSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkZldGNoIGNvbXBsYWludCBmYWlsZWRcIiwgZXJyKTtcclxuLy8gICAgICAgbm90aWZ5KFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIkZhaWxlZCB0byBsb2FkIGNvbXBsYWludCBkZXRhaWxzXCIpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIC0tLSBVUERBVEUgQ09NUExBSU5UIC0tLVxyXG4vLyAgIGNvbnN0IHVwZGF0ZUNvbXBsYWludCA9IGFzeW5jIChpZCwgZGF0YSkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLnB1dChgY29tcGxhaW50cy91cGRhdGUvJHtpZH1gLCBkYXRhKTtcclxuLy8gICAgICAgcmV0dXJuIHJlcy5kYXRhO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIlVwZGF0ZSBDb21wbGFpbnQgRXJyb3I6XCIsIGVycm9yPy5yZXNwb25zZT8uZGF0YSB8fCBlcnJvci5tZXNzYWdlKTtcclxuLy8gICAgICAgdGhyb3cgZXJyb3I7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gLS0tIENPTkZJUk0gQVNTSUdOIC0tLVxyXG4vLyAgIGNvbnN0IGNvbmZpcm1Bc3NpZ24gPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICBpZiAoIXNlbGVjdGVkQ29tcGxhaW50IHx8ICFzZWxlY3RlZEFnZW50KSByZXR1cm47XHJcbi8vICAgICBjb25zdCBhZ2VudCA9IGFnZW50cy5maW5kKChhKSA9PiBhLl9pZCA9PT0gc2VsZWN0ZWRBZ2VudCk7XHJcbi8vICAgICBpZiAoIWFnZW50KSB7XHJcbi8vICAgICAgIG5vdGlmeShcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJTZWxlY3RlZCBBZG1pbiBub3QgZm91bmQgaW4gbGlzdFwiKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgYXdhaXQgdXBkYXRlQ29tcGxhaW50KHNlbGVjdGVkQ29tcGxhaW50Ll9pZCwge1xyXG4vLyAgICAgICAgIGFzc2lnbmVkVG86IGFnZW50Ll9pZCxcclxuLy8gICAgICAgICBhc3NpZ25lZFRvTmFtZTogYWdlbnQubmFtZSxcclxuLy8gICAgICAgICBzdGF0dXM6IFwiaXMgUGVuZGluZ1wiLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgbm90aWZ5KFwic3VjY2Vzc1wiLCBcIkFzc2lnbmVkIFN1Y2Nlc3NmdWxseVwiLCBgQ29tcGxhaW50IGFzc2lnbmVkIHRvICR7YWdlbnQubmFtZX1gKTtcclxuLy8gICAgICAgc2V0QXNzaWduTW9kYWxPcGVuKGZhbHNlKTtcclxuLy8gICAgICAgc2V0Vmlld0VkaXRNb2RhbE9wZW4oZmFsc2UpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEFnZW50KFwiXCIpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZENvbXBsYWludChudWxsKTtcclxuLy8gICAgICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJhc3NpZ25cIikge1xyXG4vLyAgICAgICAgIGZldGNoQ29tcGxhaW50cyhjdXJyZW50UGFnZSk7XHJcbi8vICAgICAgICAgZmV0Y2hBbGxDb21wbGFpbnRzKCk7IFxyXG4vLyAgICAgICB9XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiVXBkYXRlIENvbXBsYWludCBFcnJvcjpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICBub3RpZnkoXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRmFpbGVkIHRvIGFzc2lnbiBjb21wbGFpbnRcIik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gLS0tIFJFU0VUIEZJTFRFUlMgLS0tXHJcbi8vICAgY29uc3QgcmVzZXRGaWx0ZXJzID0gKCkgPT4ge1xyXG4vLyAgICAgc2V0RmlsdGVycyh7XHJcbi8vICAgICAgIHN1YmplY3Q6IFwiXCIsXHJcbi8vICAgICAgIGFzc2lnbmVkVG86IFwiXCIsXHJcbi8vICAgICAgIHN0YXR1czogXCJcIixcclxuLy8gICAgICAgZnJvbURhdGU6IFwiXCIsXHJcbi8vICAgICAgIHRvRGF0ZTogXCJcIixcclxuLy8gICAgIH0pO1xyXG4vLyAgICAgc2V0Q3VycmVudFBhZ2UoMSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gLS0tIENBTENVTEFURSBDT1VOVFMgLS0tXHJcbi8vICAgY29uc3QgY291bnRzID0gdXNlTWVtbygoKSA9PiAoe1xyXG4vLyAgICAgYXNzaWduZWQ6IGFsbENvbXBsYWludHNGb3JDb3VudHMuZmlsdGVyKGMgPT4gYy5hc3NpZ25lZFRvKS5sZW5ndGgsXHJcbi8vICAgICB1bmFzc2lnbmVkOiBhbGxDb21wbGFpbnRzRm9yQ291bnRzLmZpbHRlcihjID0+ICFjLmFzc2lnbmVkVG8pLmxlbmd0aCxcclxuLy8gICAgIG9wZW46IGFsbENvbXBsYWludHNGb3JDb3VudHMuZmlsdGVyKGMgPT4gYy5zdGF0dXMgPT09IFwiT3BlblwiKS5sZW5ndGgsXHJcbi8vICAgICBwZW5kaW5nOiBhbGxDb21wbGFpbnRzRm9yQ291bnRzLmZpbHRlcihjID0+IGMuc3RhdHVzID09PSBcImlzIFBlbmRpbmdcIikubGVuZ3RoLFxyXG4vLyAgICAgY2xvc2VkOiBhbGxDb21wbGFpbnRzRm9yQ291bnRzLmZpbHRlcihjID0+IGMuc3RhdHVzID09PSBcIkNsb3NlZFwiKS5sZW5ndGgsXHJcbi8vICAgICB0b3RhbDogYWxsQ29tcGxhaW50c0ZvckNvdW50cy5sZW5ndGhcclxuLy8gICB9KSwgW2FsbENvbXBsYWludHNGb3JDb3VudHNdKTtcclxuXHJcbi8vICAgLy8gLS0tIFRBQkxFIERBVEEgLS0tXHJcbi8vICAgY29uc3QgdGFibGVEYXRhMSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4vLyAgICAgcmV0dXJuIGNvbXBsYWludHMubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuLy8gICAgICAgX2lkOiBpdGVtLl9pZCxcclxuLy8gICAgICAgY29tcGxhaW50X2NvZGU6IGl0ZW0uY29tcGxhaW50X2NvZGUgfHwgXCJOL0FcIiwgXHJcbi8vICAgICAgIHNsOiAoY3VycmVudFBhZ2UgLSAxKSAqIDEwICsgaW5kZXggKyAxLFxyXG4vLyAgICAgICB1c2VyTmFtZTogaXRlbT8udXNlcklkPy5uYW1lIHx8IGl0ZW0ubmFtZSwgLy8gRmFsbGJhY2sgdG8gaXRlbS5uYW1lIGlmIHVzZXJJZCBub3QgcG9wdWxhdGVkXHJcbiAgXHJcbi8vICAgICAgIHN1YmplY3Q6IGl0ZW0uc3ViamVjdCxcclxuLy8gICAgICAgYXNzaWduZWROYW1lOiBnZXRBc3NpZ25lZU5hbWUoaXRlbSksXHJcbi8vICAgICAgIHN0YXR1czogaXRlbS5zdGF0dXMsXHJcbi8vICAgICAgIGRhdGU6IGZvcm1hdERhdGUoaXRlbS5jcmVhdGVkQXQpLFxyXG4vLyAgICAgICBhY3Rpb246IChcclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuLy8gICAgICAgICAgICAgICBzZXRPcGVuQWN0aW9uSWQob3BlbkFjdGlvbklkID09PSBpdGVtLl9pZCA/IG51bGwgOiBpdGVtLl9pZCk7XHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLWZ1bGwgaG92ZXI6YmctZ3JheS0yMDBcIlxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICDii65cclxuLy8gICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAge29wZW5BY3Rpb25JZCA9PT0gaXRlbS5faWQgJiYgKFxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTYgdG9wLTEwIGJnLXdoaXRlIGJvcmRlciByb3VuZGVkLWxnIHNoYWRvdy1sZyB3LTQwIHotNTBcIj5cclxuLy8gICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4vLyAgICAgICAgICAgICAgICAgICBoYW5kbGVWaWV3KGl0ZW0uX2lkKTtcclxuLy8gICAgICAgICAgICAgICAgICAgc2V0T3BlbkFjdGlvbklkKG51bGwpO1xyXG4vLyAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHctZnVsbCBweC00IHB5LTIgaG92ZXI6YmctZ3JheS0xMDAgdGV4dC1ncmVlbi02MDBcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxFeWUgc2l6ZT17MTh9IC8+XHJcbi8vICAgICAgICAgICAgICAgICA8c3Bhbj5WaWV3PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbi8vICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQ29tcGxhaW50KGl0ZW0pO1xyXG4vLyAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEFnZW50KFwiXCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgICBzZXRWaWV3TW9kZShcImFzc2lnblwiKTtcclxuLy8gICAgICAgICAgICAgICAgICAgc2V0Vmlld0VkaXRNb2RhbE9wZW4odHJ1ZSk7XHJcbi8vICAgICAgICAgICAgICAgICAgIHNldE9wZW5BY3Rpb25JZChudWxsKTtcclxuLy8gICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgcHgtNCBweS0yIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtYmx1ZS02MDBcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxVc2VyUGx1cyBzaXplPXsxOH0gLz5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuPkFzc2lnbjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICApfVxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICApLFxyXG4vLyAgICAgfSkpO1xyXG4vLyAgIH0sIFtjb21wbGFpbnRzLCBjdXJyZW50UGFnZSwgb3BlbkFjdGlvbklkLCBhZ2VudHNdKTtcclxuXHJcbi8vICAgaWYgKGluaXRpYWxMb2FkICYmIGFjdGl2ZVRhYiAhPT0gXCJhc3NpZ25cIikge1xyXG4vLyAgICAgcmV0dXJuIChcclxuLy8gICAgICAgPD5cclxuLy8gICAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuLy8gICAgICAgICA8TmF2YmFyIC8+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctc2NyZWVuIG10LTE0XCI+XHJcbi8vICAgICAgICAgICA8U2lkZWJhciAvPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWNvbCB3LWZ1bGwgcC00XCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJteC1hdXRvIHRleHQtMnhsIGZvbnQtYm9sZCBteS01XCI+QWRtaW4gU3VwcG9ydDwvaDI+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTYgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwiYXNzaWduXCIpfSBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTMyIGgtMzIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmVlbi02MDAgdG8tZ3JlZW4tNzAwIG9wYWNpdHktNSBncm91cC1ob3ZlcjpvcGFjaXR5LTEwIHJvdW5kZWQtZnVsbCAtbXItMTYgLW10LTE2IGJsdXIteGxcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtOVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy1ncmVlbi01MCByb3VuZGVkLWxnXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGxcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZEFzc2lnbm1lbnRJbmQgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+QXNzaWduPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5Bc3NpZ24gdGlja2V0cyB0byBzdGFmZjwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNiB0ZXh0LXJpZ2h0XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmVlbi02MDBcIj57Y291bnRzLmFzc2lnbmVkfTwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5Bc3NpZ25lZDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXJlZC01MDBcIj57Y291bnRzLnVuYXNzaWduZWR9PC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlVuYXNzaWduZWQ8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvPlxyXG4vLyAgICAgKTtcclxuLy8gICB9XHJcblxyXG4vLyAgcmV0dXJuIChcclxuLy8gICA8PlxyXG4vLyAgICAge2NvbnRleHRIb2xkZXJ9XHJcbi8vICAgICA8TmF2YmFyIC8+XHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1zY3JlZW4gbXQtMTRcIj5cclxuLy8gICAgICAgPFNpZGViYXIgLz5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWNvbCB3LWZ1bGwgcC00XCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbi8vICAgICAgICAgICB7YWN0aXZlVGFiICYmIChcclxuLy8gICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYihudWxsKTtcclxuLy8gICAgICAgICAgICAgICAgIHJlc2V0RmlsdGVycygpO1xyXG4vLyAgICAgICAgICAgICAgICAgc2V0Q3VycmVudFBhZ2UoMSk7XHJcbi8vICAgICAgICAgICAgICAgICBzZXRDb21wbGFpbnRzKFtdKTtcclxuLy8gICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMCBweC0zIHB5LTEgcm91bmRlZC1tZCBiZy1ncmF5LTIwMCBob3ZlcjpiZy1ncmF5LTMwMCB0ZXh0LXNtXCJcclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIOKGkCBCYWNrXHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJteC1hdXRvIHRleHQtMnhsIGZvbnQtYm9sZCBteS01XCI+QWRtaW4gU3VwcG9ydDwvaDI+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbi8vICAgICAgICAgeyFhY3RpdmVUYWIgJiYgKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC02IG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoXCJhc3NpZ25cIil9IGNsYXNzTmFtZT1cImdyb3VwIGN1cnNvci1wb2ludGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy0zMiBoLTMyIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNjAwIHRvLWdyZWVuLTcwMCBvcGFjaXR5LTUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMCByb3VuZGVkLWZ1bGwgLW1yLTE2IC1tdC0xNiBibHVyLXhsXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC05XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xMiBoLTEyIGJnLWdyZWVuLTUwIHJvdW5kZWQtbGdcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGxcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8TWRBc3NpZ25tZW50SW5kIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5Bc3NpZ248L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5Bc3NpZ24gdGlja2V0cyB0byBzdGFmZjwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNiB0ZXh0LXJpZ2h0XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmVlbi02MDBcIj57Y291bnRzLmFzc2lnbmVkfTwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+QXNzaWduZWQ8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXJlZC01MDBcIj57Y291bnRzLnVuYXNzaWduZWR9PC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5VbmFzc2lnbmVkPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC0zIG10LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlN0YWZmIEFzc2lnbm1lbnQ8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNjAwIHRvLWdyZWVuLTcwMCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvblwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtd2hpdGVcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTggYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwIHRvLWluZGlnby01MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWJsdWUtMTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtYmx1ZS02MDAgbXQtMVwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5RdWljayBUaXBzPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBsaXN0LWluc2lkZSB0ZXh0LXNsYXRlLTcwMCBzcGFjZS15LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlZpZXcgYW5kIG1hbmFnZSBhbGwgc3VwcG9ydCByZXF1ZXN0cyBpbiBvbmUgcGxhY2U8L2xpPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+QXNzaWduIGNvbXBsYWludHMgdG8gc3RhZmYgZWFzaWx5PC9saT5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlRyYWNrIGNvbXBsYWludCBzdGF0dXMgYW5kIHJlc29sdXRpb24gcHJvZ3Jlc3M8L2xpPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICB7LyogLS0tIEFTU0lHTiBUQUIgQ09OVEVOVCAtLS0gKi99XHJcbi8vICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcImFzc2lnblwiICYmIChcclxuLy8gICAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAgICB7LyogRGFzaGJvYXJkIENhcmRzICovfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtNiBtYi02XCI+XHJcblxyXG4vLyAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2FyZENsaWNrKFwiXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy13aGl0ZSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlciBib3JkZXItMiAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGZpbHRlcnMuc3RhdHVzID09PSBcIlwiID8gXCJib3JkZXItYmx1ZS01MDAgcmluZy0xIHJpbmctYmx1ZS01MDBcIiA6IFwiYm9yZGVyLXRyYW5zcGFyZW50XCJcclxuLy8gICAgICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLWJsdWUtMzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xMiBoLTEyIGJnLWJsdWUtMTAwIHRleHQtYmx1ZS02MDAgcm91bmRlZC1sZ1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxVc2VycyBzaXplPXsyNH0gLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5Ub3RhbDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+QWxsIHRpY2tldHM8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtYmx1ZS02MDBcIj57Y291bnRzLnRvdGFsfTwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHsvKiBPcGVuIENhcmQgKi99XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhcmRDbGljayhcIk9wZW5cIil9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJnLXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGN1cnNvci1wb2ludGVyIGJvcmRlci0yICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgZmlsdGVycy5zdGF0dXMgPT09IFwiT3BlblwiID8gXCJib3JkZXItb3JhbmdlLTUwMCByaW5nLTEgcmluZy1vcmFuZ2UtNTAwXCIgOiBcImJvcmRlci10cmFuc3BhcmVudFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBiZy1vcmFuZ2UtMzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xMiBoLTEyIGJnLW9yYW5nZS0xMDAgdGV4dC1vcmFuZ2UtNjAwIHJvdW5kZWQtbGdcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgc2l6ZT17MjR9IC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+T3BlbjwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+TmV3IGNvbXBsYWludHM8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtb3JhbmdlLTYwMFwiPntjb3VudHMub3Blbn08L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgICB7LyogUGVuZGluZyBDYXJkICovfVxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDYXJkQ2xpY2soXCJpcyBQZW5kaW5nXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy13aGl0ZSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlciBib3JkZXItMiAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGZpbHRlcnMuc3RhdHVzID09PSBcImlzIFBlbmRpbmdcIiA/IFwiYm9yZGVyLXllbGxvdy01MDAgcmluZy0xIHJpbmcteWVsbG93LTUwMFwiIDogXCJib3JkZXItdHJhbnNwYXJlbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYmcteWVsbG93LTMwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTYwMCByb3VuZGVkLWxnXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPFphcCBzaXplPXsyNH0gLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5QZW5kaW5nPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5JbiBwcm9ncmVzczwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC15ZWxsb3ctNjAwXCI+e2NvdW50cy5wZW5kaW5nfTwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHsvKiBDbG9zZWQgQ2FyZCAqL31cclxuLy8gICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2FyZENsaWNrKFwiQ2xvc2VkXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy13aGl0ZSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlciBib3JkZXItMiAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGZpbHRlcnMuc3RhdHVzID09PSBcIkNsb3NlZFwiID8gXCJib3JkZXItZ3JlZW4tNTAwIHJpbmctMSByaW5nLWdyZWVuLTUwMFwiIDogXCJib3JkZXItdHJhbnNwYXJlbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYmctZ3JlZW4tMzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xMiBoLTEyIGJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTYwMCByb3VuZGVkLWxnXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPENsaXBib2FyZENoZWNrIHNpemU9ezI0fSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNsb3NlZDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+UmVzb2x2ZWQgaXNzdWVzPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTYwMFwiPntjb3VudHMuY2xvc2VkfTwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogRmlsdGVycyBTZWN0aW9uICovfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBib3JkZXIgcm91bmRlZC1sZyBwLTQgYmctZ3JheS01MFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy01IGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgcGItMlwiPlN1YmplY3Q8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdWJqZWN0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLnN1YmplY3R9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsdGVyQ2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIHRleHQtc21cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGwgU3ViamVjdHM8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtbLi4ubmV3IFNldChhbGxDb21wbGFpbnRzLm1hcChjID0+IGMuc3ViamVjdCkpXS5tYXAoc3ViamVjdCA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtzdWJqZWN0fSB2YWx1ZT17c3ViamVjdH0+e3N1YmplY3R9PC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgcGItMlwiPkFzc2lnbmVkIFRvPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYXNzaWduZWRUb1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5hc3NpZ25lZFRvfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbHRlckNoYW5nZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHB4LTMgcHktMiB0ZXh0LXNtXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nQWdlbnRzfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGwgQXNzaWduZWVzPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVW5hc3NpZ25lZFwiPlVuYXNzaWduZWQ8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKGFnZW50ID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2FnZW50Ll9pZH0gdmFsdWU9e2FnZW50Ll9pZH0+e2FnZW50Lm5hbWV9PC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgcGItMlwiPlN0YXR1czwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN0YXR1c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5zdGF0dXN9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsdGVyQ2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIHRleHQtc21cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGwgU3RhdHVzPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT3BlblwiPk9wZW48L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJpcyBQZW5kaW5nXCI+UGVuZGluZzwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNsb3NlZFwiPkNsb3NlZDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBwYi0yXCI+RnJvbSBEYXRlPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJmcm9tRGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5mcm9tRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWx0ZXJDaGFuZ2V9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBweC0zIHB5LTIgdGV4dC1zbVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgcGItMlwiPlRvIERhdGU8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRvRGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy50b0RhdGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsdGVyQ2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIHRleHQtc21cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3Jlc2V0RmlsdGVyc31cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYmx1ZS0yMDAgcm91bmRlZCB0ZXh0LXNtIGhvdmVyOmJnLWJsdWUtMzAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFJlc2V0IEZpbHRlcnNcclxuLy8gICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIERhdGEgVGFibGUgKi99XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHctZnVsbCBvdmVyZmxvdy14LWF1dG8gcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGgtNjRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8U3BpbiBzaXplPVwibGFyZ2VcIiB0aXA9XCJMb2FkaW5nIGNvbXBsYWludHMuLi5cIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtIG1iLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIFNob3dpbmcge3RhYmxlRGF0YTEubGVuZ3RofSBvZiB7dG90YWxDb21wbGFpbnRzfSBjb21wbGFpbnRzIChQYWdlIHtjdXJyZW50UGFnZX0gb2Yge3RvdGFsUGFnZXN9KVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXt0YWJsZURhdGExfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17W1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJjb21wbGFpbnRfY29kZVwiLCBoZWFkZXI6IFwiY29tcGxhaW50IGNvZGVcIiB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiTmFtZVwiIH0sXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiBcInN1YmplY3RcIiwgaGVhZGVyOiBcIlN1YmplY3RcIiB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJhc3NpZ25lZE5hbWVcIiwgaGVhZGVyOiBcIkFzc2lnbmVkIFRvXCIgfSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJEYXRlXCIgfSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgaXNFeHBvcnRFbmFibGVkPXt0cnVlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkNvbXBsYWludHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ29tcGxhaW50cyBSZXBvcnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge3RvdGFsUGFnZXMgPiAxICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBtdC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxQYWdpbmF0aW9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudD17Y3VycmVudFBhZ2V9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWw9e3RvdGFsQ29tcGxhaW50c31cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBwYWdlU2l6ZT17MTB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhwYWdlKSA9PiBzZXRDdXJyZW50UGFnZShwYWdlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2l6ZUNoYW5nZXI9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC8+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgey8qIC0tLSBBU1NJR04gTU9EQUwgLS0tICovfVxyXG4vLyAgICAgICAgICAge2Fzc2lnbk1vZGFsT3BlbiAmJiAoXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay80MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTUwXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHAtNiB3LVs0MDBweF1cIj5cclxuLy8gICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCBtYi00XCI+QXNzaWduIENvbXBsYWludDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZCBweC0zIHB5LTIgbWItNFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEFnZW50fVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkQWdlbnQoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEVtcGxveWVlPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHthZ2VudC5lbWFpbCA/IGB8ICR7YWdlbnQuZW1haWx9YCA6ICcnfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBc3NpZ25Nb2RhbE9wZW4oZmFsc2UpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1ncmF5LTIwMCByb3VuZGVkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2NvbmZpcm1Bc3NpZ259XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcm91bmRlZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFzZWxlY3RlZEFnZW50fVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgQXNzaWduXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICB7LyogLS0tIFZJRVcvRURJVCBNT0RBTCAoV0lUSCBGSVhFUykgLS0tICovfVxyXG4vLyAgICAgICAgICB7dmlld0VkaXRNb2RhbE9wZW4gJiYgc2VsZWN0ZWRDb21wbGFpbnQgJiYgKFxyXG4vLyAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay80MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTUwXCI+XHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LWxnIHctWzk1JV0gbWF4LXctNHhsIG1heC1oLVs5MHZoXSBvdmVyZmxvdy1hdXRvIHAtNiByZWxhdGl2ZVwiPlxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbi8vICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+Q29tcGxhaW50IERldGFpbHM8L2gzPlxyXG4vLyAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdFZGl0TW9kYWxPcGVuKGZhbHNlKX1cclxuLy8gICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ibGFja1wiXHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPFggc2l6ZT17MjR9IC8+XHJcbi8vICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgXHJcbi8vICAgICAgICAgey8qIC0tLSBGSVg6IE5hbWUgTG9naWMgLS0tICovfVxyXG4vLyAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5OYW1lPC9sYWJlbD5cclxuLy8gICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAvLyBQcmlvcml0eTogRGlyZWN0IE5hbWUgLT4gUG9wdWxhdGVkIFVzZXIgTmFtZSAtPiBOL0FcclxuLy8gICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ29tcGxhaW50Lm5hbWUgfHwgc2VsZWN0ZWRDb21wbGFpbnQudXNlcklkPy5uYW1lIHx8IFwiTi9BXCJ9XHJcbi8vICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZC1tZCBweC0zIHB5LTIgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgey8qIC0tLSBGSVg6IE1vYmlsZSBMb2dpYyAtLS0gKi99XHJcbi8vICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPk1vYmlsZTwvbGFiZWw+XHJcbi8vICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ29tcGxhaW50Lm1vYmlsZSB8fCBcIk4vQVwifVxyXG4vLyAgICAgICAgICAgICByZWFkT25seVxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHJvdW5kZWQtbWQgcHgtMyBweS0yIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDAgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuLy8gICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlN1YmplY3Q8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZENvbXBsYWludC5zdWJqZWN0IHx8IFwiXCJ9XHJcbi8vICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZC1tZCBweC0zIHB5LTIgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+RGVwYXJ0bWVudDwvbGFiZWw+XHJcbi8vICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgdmFsdWU9e3R5cGVvZiBzZWxlY3RlZENvbXBsYWludC5kZXNpZ25hdGlvbiA9PT0gJ29iamVjdCcgXHJcbi8vICAgICAgICAgICAgICAgPyBzZWxlY3RlZENvbXBsYWludC5kZXNpZ25hdGlvbj8udGl0bGUgfHwgXCJcIiBcclxuLy8gICAgICAgICAgICAgICA6IHNlbGVjdGVkQ29tcGxhaW50LmRlc2lnbmF0aW9uIHx8IFwiXCJ9XHJcbi8vICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZC1tZCBweC0zIHB5LTIgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPkFzc2lnbmVkIFRvPC9sYWJlbD5cclxuLy8gICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICB2YWx1ZT17Z2V0QXNzaWduZWVOYW1lKHNlbGVjdGVkQ29tcGxhaW50KX1cclxuLy8gICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkLW1kIHB4LTMgcHktMiBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5TdGF0dXM8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZENvbXBsYWludC5zdGF0dXMgfHwgXCJcIn1cclxuLy8gICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkLW1kIHB4LTMgcHktMiBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5EYXRlPC9sYWJlbD5cclxuLy8gICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICB2YWx1ZT17Zm9ybWF0RGF0ZShzZWxlY3RlZENvbXBsYWludC5jcmVhdGVkQXQpfVxyXG4vLyAgICAgICAgICAgICByZWFkT25seVxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHJvdW5kZWQtbWQgcHgtMyBweS0yIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDAgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuLy8gICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPGRpdj48L2Rpdj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cclxuLy8gICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPk1lc3NhZ2U8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgPHRleHRhcmVhXHJcbi8vICAgICAgICAgICAgIHJvd3M9ezR9XHJcbi8vICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZENvbXBsYWludC5tZXNzYWdlIHx8IFwiXCJ9XHJcbi8vICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZC1tZCBweC0zIHB5LTIgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuLy8gICAgICAgICB7LyogLS0tIEZJWDogQVRUQUNITUVOVFMgU0VDVElPTiAtLS0gKi99XHJcbi8vICAgICAgICAgeygoKSA9PiB7XHJcbi8vICAgICAgICAgICBjb25zdCBmaWxlcyA9IHNlbGVjdGVkQ29tcGxhaW50LmNvbXBsYWludF91cGxvYWRzIHx8IFtdO1xyXG4vLyAgICAgICAgICAgcmV0dXJuIGZpbGVzLmxlbmd0aCA+IDA7XHJcbi8vICAgICAgICAgfSkoKSAmJiAoXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cclxuLy8gICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbi8vICAgICAgICAgICAgICAgQXR0YWNobWVudHMgKENsaWNrIHRvIFZpZXcpXHJcbi8vICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgIHsoc2VsZWN0ZWRDb21wbGFpbnQuY29tcGxhaW50X3VwbG9hZHMgfHwgW10pLm1hcCgoZmlsZSwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgIC8vIEhhbmRsZSBib3RoIE9iamVjdCAobmV3KSBhbmQgU3RyaW5nIChvbGQpIGZvcm1hdHNcclxuLy8gICAgICAgICAgICAgICAgIGxldCBmaWxlTmFtZSA9IFwiQXR0YWNobWVudFwiO1xyXG4vLyAgICAgICAgICAgICAgICAgbGV0IGZpbGVVcmwgPSBcIlwiO1xyXG5cclxuLy8gICAgICAgICAgICAgICAgIC8vIGlmICh0eXBlb2YgZmlsZSA9PT0gJ29iamVjdCcgJiYgZmlsZS51cmwpIHtcclxuLy8gICAgICAgICAgICAgICAgIC8vICAgIGZpbGVOYW1lID0gZmlsZS5uYW1lIHx8IFwiRmlsZVwiO1xyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgZmlsZVVybCA9IGZpbGUudXJsOyAvLyBEaXJlY3QgUzMgVVJMXHJcbi8vICAgICAgICAgICAgICAgICAvLyB9IFxyXG4vLyAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGZpbGUgPT09ICdvYmplY3QnKSB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWUgPSBmaWxlLm5hbWUgfHwgZmlsZS5vcmlnaW5hbG5hbWUgfHwgXCJGaWxlXCI7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgZmlsZVVybCA9IGZpbGUudXJsIHx8IGZpbGUuZmlsZV9wYXRoIHx8IGZpbGUucGF0aCB8fCBcIlwiO1xyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgZmlsZSA9PT0gJ3N0cmluZycpIHtcclxuLy8gICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lID0gXCJGaWxlXCI7XHJcbi8vICAgICAgICAgICAgICAgICAgICBmaWxlVXJsID0gZmlsZTsgLy8gRGlyZWN0IFN0cmluZyBVUkxcclxuLy8gICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAvLyBGYWxsYmFjayB0byBBUEkgcm91dGUgaWYgc3RydWN0dXJlIGlzIGRpZmZlcmVudFxyXG4vLyAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWUgPSBmaWxlLm9yaWdpbmFsbmFtZSB8fCBmaWxlLm5hbWUgfHwgXCJGaWxlXCI7XHJcbi8vICAgICAgICAgICAgICAgICAgICBmaWxlVXJsID0gYCR7QmFzZVVSTH0vY29tcGxhaW50cy8ke3NlbGVjdGVkQ29tcGxhaW50Ll9pZH0vYXR0YWNobWVudC8ke2luZGV4fWA7XHJcbi8vICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUF0dGFjaG1lbnRDbGljayhmaWxlVXJsLCBmaWxlTmFtZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQtbGcgcC0zIGJnLWdyYXktNTAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24gZ3JvdXBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgaC0zMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZCBiZy13aGl0ZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aW1nXHJcbi8vICAgc3JjPXtmaWxlVXJsfVxyXG4vLyAgIGFsdD17ZmlsZU5hbWV9XHJcbi8vICAgY2xhc3NOYW1lPVwiaC1mdWxsIG9iamVjdC1jb250YWluIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIlxyXG4vLyAgIG9uTG9hZD17KCkgPT4gY29uc29sZS5sb2coXCJJbWFnZSBsb2FkZWQ6XCIsIGZpbGVVcmwpfVxyXG4vLyAgIG9uRXJyb3I9eyhlKSA9PiB7XHJcbi8vICAgICBjb25zb2xlLmxvZyhcIkltYWdlIGZhaWxlZDpcIiwgZmlsZVVybCk7XHJcbi8vICAgICBjb25zb2xlLmxvZyhlKTtcclxuLy8gICB9fVxyXG4vLyAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzEwIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC14cyBiZy1ibGFjay81MCBweC0yIHB5LTEgcm91bmRlZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWNrIHRvIE9wZW5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwIHRydW5jYXRlIHctZnVsbCB0ZXh0LWNlbnRlciBtdC0yXCIgdGl0bGU9e2ZpbGVOYW1lfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIPCfk44ge2ZpbGVOYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICApO1xyXG4vLyAgICAgICAgICAgICAgIH0pfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICl9XHJcbiAgICAgICAgXHJcbi8vICAgICAgICAgey8qIC4uLiBSZXN0IG9mIG1vZGFsIGNvZGUgKEFzc2lnbiBUbyBzZWxlY3QsIEJ1dHRvbnMpIC4uLiAqL31cclxuLy8gICAgICAgICAge3ZpZXdNb2RlID09PSBcImFzc2lnblwiICYmIChcclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yXCI+XHJcbi8vICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+QXNzaWduIFRvPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBZ2VudH1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRBZ2VudChlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHJvdW5kZWQtbWQgcHgtMyBweS0yXCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEVtcGxveWVlPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcChhZ2VudCA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfSB8IHthZ2VudC5lbWFpbH1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICApfVxyXG4vLyAgICAgICA8L2Zvcm0+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBtdC02IGdhcC0zXCI+XHJcbi8vICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdFZGl0TW9kYWxPcGVuKGZhbHNlKX1cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciByb3VuZGVkLW1kIGhvdmVyOmJnLWdyYXktMTAwXCJcclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgQ2FuY2VsXHJcbi8vICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgIHt2aWV3TW9kZSA9PT0gXCJhc3NpZ25cIiAmJiAoXHJcbi8vICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXtjb25maXJtQXNzaWdufVxyXG4vLyAgICAgICAgICAgICAgIGRpc2FibGVkPXshc2VsZWN0ZWRBZ2VudH1cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgQXNzaWduXHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgKX1cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgIDwvZGl2PlxyXG4vLyApfVxyXG5cclxuLy8gICAgICAgICAgIHsvKiAtLS0gSU1BR0UgUFJFVklFVyBNT0RBTCAtLS0gKi99XHJcbi8vICAgICAgICAgICB7aW1hZ2VQcmV2aWV3T3BlbiAmJiAoXHJcbi8vICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzYwXSBiZy1ibGFjay85MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmFja2Ryb3AtYmx1ci1zbVwiXHJcbi8vICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW1hZ2VQcmV2aWV3T3BlbihmYWxzZSl9XHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4geyBlLnN0b3BQcm9wYWdhdGlvbigpOyBzZXRJbWFnZVByZXZpZXdPcGVuKGZhbHNlKTsgfX1cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IHJpZ2h0LTQgdGV4dC13aGl0ZSBob3Zlcjp0ZXh0LWdyYXktMzAwIGJnLWJsYWNrLzUwIHJvdW5kZWQtZnVsbCBwLTJcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxYIHNpemU9ezMyfSAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgIDxpbWdcclxuLy8gICAgICAgICAgICAgICAgIHNyYz17cHJldmlld0ltYWdlU3JjfVxyXG4vLyAgICAgICAgICAgICAgICAgYWx0PVwiRnVsbCBQcmV2aWV3XCJcclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1heC13LWZ1bGwgbWF4LWgtWzkwdmhdIG9iamVjdC1jb250YWluIHJvdW5kZWQgc2hhZG93LTJ4bFwiXHJcbi8vICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICApfVxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvPlxyXG4vLyAgICk7XHJcbi8vIH1cclxuXHJcbi8vIGV4cG9ydCBkZWZhdWx0IFN1cHBvcnRzO1xyXG5cclxuXHJcblxyXG4vKiBlc2xpbnQtZGlzYWJsZSByZWFjdC9wcm9wLXR5cGVzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb24sIFBhZ2luYXRpb24sIFNwaW4gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBVc2VycywgQ2hldnJvblJpZ2h0LCBaYXAsIENsaXBib2FyZENoZWNrLCBYLCBFeWUsIFVzZXJQbHVzLCBBbGVydENpcmNsZSB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQmFzZVVSTCBmcm9tIFwiLi4vaW5zdGFuY2UvQmFzZVVybFwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBNZEFzc2lnbm1lbnRJbmQgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuXHJcbmZ1bmN0aW9uIFN1cHBvcnRzKCkge1xyXG4gIGNvbnN0IFthcGksIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIFxyXG4gIC8vIC0tLSBMT0FESU5HIFNUQVRFIC0tLVxyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2luaXRpYWxMb2FkLCBzZXRJbml0aWFsTG9hZF0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbYWxsQ29tcGxhaW50c0ZvckNvdW50cywgc2V0QWxsQ29tcGxhaW50c0ZvckNvdW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgXHJcbiAgLy8gLS0tIElNQUdFIFBSRVZJRVcgU1RBVEUgLS0tXHJcbiAgY29uc3QgW2ltYWdlUHJldmlld09wZW4sIHNldEltYWdlUHJldmlld09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtwcmV2aWV3SW1hZ2VTcmMsIHNldFByZXZpZXdJbWFnZVNyY10gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBcclxuICAvLyAtLS0gREFUQSBTVEFURSAtLS1cclxuICBjb25zdCBbY29tcGxhaW50cywgc2V0Q29tcGxhaW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FsbENvbXBsYWludHMsIHNldEFsbENvbXBsYWludHNdID0gdXNlU3RhdGUoW10pOyBcclxuICBjb25zdCBbdG90YWxDb21wbGFpbnRzLCBzZXRUb3RhbENvbXBsYWludHNdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2N1cnJlbnRQYWdlLCBzZXRDdXJyZW50UGFnZV0gPSB1c2VTdGF0ZSgxKTtcclxuICBjb25zdCBbdG90YWxQYWdlcywgc2V0VG90YWxQYWdlc10gPSB1c2VTdGF0ZSgxKTtcclxuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgXHJcbiAgLy8gLS0tIEFHRU5UUyBTVEFURSAtLS1cclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nQWdlbnRzLCBzZXRMb2FkaW5nQWdlbnRzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICAvLyAtLS0gTU9EQUwgJiBBQ1RJT04gU1RBVEUgLS0tXHJcbiAgY29uc3QgW29wZW5BY3Rpb25JZCwgc2V0T3BlbkFjdGlvbklkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt2aWV3TW9kZSwgc2V0Vmlld01vZGVdID0gdXNlU3RhdGUoXCJ2aWV3XCIpO1xyXG4gIGNvbnN0IFt2aWV3RWRpdE1vZGFsT3Blbiwgc2V0Vmlld0VkaXRNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthc3NpZ25Nb2RhbE9wZW4sIHNldEFzc2lnbk1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkQ29tcGxhaW50LCBzZXRTZWxlY3RlZENvbXBsYWludF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBZ2VudCwgc2V0U2VsZWN0ZWRBZ2VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBcclxuICAvLyAtLS0gRklMVEVSUyBTVEFURSAtLS1cclxuICBjb25zdCBbZmlsdGVycywgc2V0RmlsdGVyc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBzdWJqZWN0OiBcIlwiLFxyXG4gICAgYXNzaWduZWRUbzogXCJcIixcclxuICAgIHN0YXR1czogXCJcIixcclxuICAgIGZyb21EYXRlOiBcIlwiLFxyXG4gICAgdG9EYXRlOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICAvLyAtLS0gSEVMUEVSOiBGb3JtYXQgRGF0ZSAtLS1cclxuICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGlmICghZGF0ZVN0cmluZykgcmV0dXJuIFwiXCI7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XHJcbiAgICBjb25zdCBkYXkgPSBTdHJpbmcoZGF0ZS5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICBjb25zdCBtb250aCA9IFN0cmluZyhkYXRlLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgY29uc3QgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuICAgIHJldHVybiBgJHtkYXl9LyR7bW9udGh9LyR7eWVhcn1gO1xyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBIRUxQRVI6IEdFVCBBU1NJR05FRSBOQU1FIC0tLVxyXG4gIGNvbnN0IGdldEFzc2lnbmVlTmFtZSA9IChpdGVtKSA9PiB7XHJcbiAgICBpZiAoaXRlbS5hc3NpZ25lZFRvTmFtZSkgcmV0dXJuIGl0ZW0uYXNzaWduZWRUb05hbWU7XHJcbiAgICBpZiAoIWl0ZW0uYXNzaWduZWRUbykgcmV0dXJuIFwiVW5hc3NpZ25lZFwiO1xyXG4gICAgaWYgKHR5cGVvZiBpdGVtLmFzc2lnbmVkVG8gPT09IFwib2JqZWN0XCIgJiYgaXRlbS5hc3NpZ25lZFRvLm5hbWUpIHtcclxuICAgICAgcmV0dXJuIGl0ZW0uYXNzaWduZWRUby5uYW1lO1xyXG4gICAgfVxyXG4gICAgaWYgKHR5cGVvZiBpdGVtLmFzc2lnbmVkVG8gPT09IFwic3RyaW5nXCIpIHtcclxuICAgICAgY29uc3QgYWdlbnQgPSBhZ2VudHMuZmluZChhID0+IFN0cmluZyhhLl9pZCkgPT09IFN0cmluZyhpdGVtLmFzc2lnbmVkVG8pKTtcclxuICAgICAgcmV0dXJuIGFnZW50ID8gYWdlbnQubmFtZSA6IFwiVW5rbm93biBBZG1pblwiO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIFwiVW5hc3NpZ25lZFwiO1xyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBGSUxURVIgQ0hBTkdFIEhBTkRMRVIgLS0tXHJcbiAgY29uc3QgaGFuZGxlRmlsdGVyQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0RmlsdGVycyhwcmV2ID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRDdXJyZW50UGFnZSgxKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0gREFTSEJPQVJEIENBUkQgQ0xJQ0sgSEFORExFUiAtLS1cclxuICBjb25zdCBoYW5kbGVDYXJkQ2xpY2sgPSAoc3RhdHVzKSA9PiB7XHJcbiAgICBzZXRGaWx0ZXJzKHByZXYgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgc3RhdHVzOiBwcmV2LnN0YXR1cyA9PT0gc3RhdHVzID8gXCJcIiA6IHN0YXR1c1xyXG4gICAgfSkpO1xyXG4gICAgc2V0Q3VycmVudFBhZ2UoMSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gLS0tIEZJWEVEOiBBVFRBQ0hNRU5UIENMSUNLIEhBTkRMRVIgLS0tXHJcbiAgY29uc3QgaGFuZGxlQXR0YWNobWVudENsaWNrID0gKHVybCwgZmlsZU5hbWUpID0+IHtcclxuICAgIGlmICghdXJsKSB7XHJcbiAgICAgIG5vdGlmeShcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJObyBhdHRhY2htZW50IFVSTCBmb3VuZFwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvLyBDaGVjayBpZiBpdCdzIGEgUERGXHJcbiAgICBpZiAoZmlsZU5hbWUgJiYgZmlsZU5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnBkZicpKSB7XHJcbiAgICAgIHdpbmRvdy5vcGVuKHVybCwgJ19ibGFuaycpO1xyXG4gICAgfSBcclxuICAgIC8vIENoZWNrIGlmIGl0J3MgYW4gaW1hZ2VcclxuICAgIGVsc2UgaWYgKHVybC5tYXRjaCgvXFwuKGpwZWd8anBnfGdpZnxwbmd8d2VicCkkL2kpIHx8IHVybC5pbmNsdWRlcygnYW1hem9uYXdzLmNvbScpKSB7XHJcbiAgICAgIHNldFByZXZpZXdJbWFnZVNyYyh1cmwpO1xyXG4gICAgICBzZXRJbWFnZVByZXZpZXdPcGVuKHRydWUpO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIC8vIEZvciBvdGhlciBmaWxlIHR5cGVzLCB0cnkgdG8gb3BlbiBpbiBuZXcgdGFiXHJcbiAgICAgIHdpbmRvdy5vcGVuKHVybCwgJ19ibGFuaycpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBOT1RJRklDQVRJT04gSEVMUEVSIC0tLVxyXG4gIGNvbnN0IG5vdGlmeSA9ICh0eXBlLCB0aXRsZSwgZGVzY3JpcHRpb24pID0+IHtcclxuICAgIGFwaVt0eXBlXSh7XHJcbiAgICAgIHRpdGxlLFxyXG4gICAgICBkZXNjcmlwdGlvbixcclxuICAgICAgcGxhY2VtZW50OiBcInRvcFwiLFxyXG4gICAgICBkdXJhdGlvbjogMixcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBGRVRDSCBBTEwgQ09NUExBSU5UUyAoZm9yIGNvdW50cyAtIG5vIGZpbHRlcnMpIC0tLVxyXG4gIGNvbnN0IGZldGNoQWxsQ29tcGxhaW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoYGNvbXBsYWludHMvYWxsLXBhZ2luYXRlZD9wYWdlPTEmbGltaXQ9MTAwMGApO1xyXG4gICAgICBpZiAocmVzLmRhdGEuc3VjY2Vzcykge1xyXG4gICAgICAgIHNldEFsbENvbXBsYWludHMocmVzLmRhdGEuZGF0YSB8fCBbXSk7XHJcbiAgICAgICAgc2V0QWxsQ29tcGxhaW50c0ZvckNvdW50cyhyZXMuZGF0YS5kYXRhIHx8IFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZldGNoIGFsbCBjb21wbGFpbnRzIGVycm9yOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsbENvbXBsYWludHMoW10pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBGRVRDSCBDT01QTEFJTlRTICh3aXRoIGZpbHRlcnMpIC0tLVxyXG4gIGNvbnN0IGZldGNoQ29tcGxhaW50cyA9IGFzeW5jIChwYWdlID0gMSkgPT4ge1xyXG4gICAgaWYgKGFjdGl2ZVRhYiAhPT0gXCJhc3NpZ25cIikge1xyXG4gICAgICBzZXRJbml0aWFsTG9hZChmYWxzZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xyXG4gICAgICBwYXJhbXMuYXBwZW5kKCdwYWdlJywgcGFnZSk7XHJcbiAgICAgIHBhcmFtcy5hcHBlbmQoJ2xpbWl0JywgMTApO1xyXG4gICAgICBcclxuICAgICAgaWYgKGZpbHRlcnMuc3ViamVjdCAmJiBmaWx0ZXJzLnN1YmplY3QgIT09ICcnKSB7XHJcbiAgICAgICAgcGFyYW1zLmFwcGVuZCgnc3ViamVjdCcsIGZpbHRlcnMuc3ViamVjdCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChmaWx0ZXJzLnN0YXR1cyAmJiBmaWx0ZXJzLnN0YXR1cyAhPT0gJycpIHtcclxuICAgICAgICBwYXJhbXMuYXBwZW5kKCdzdGF0dXMnLCBmaWx0ZXJzLnN0YXR1cyk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGZpbHRlcnMuYXNzaWduZWRUbyAmJiBmaWx0ZXJzLmFzc2lnbmVkVG8gIT09ICcnKSB7XHJcbiAgICAgICAgcGFyYW1zLmFwcGVuZCgnYXNzaWduZWRUbycsIGZpbHRlcnMuYXNzaWduZWRUbyk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGZpbHRlcnMuZnJvbURhdGUpIHtcclxuICAgICAgICBwYXJhbXMuYXBwZW5kKCdmcm9tRGF0ZScsIGZpbHRlcnMuZnJvbURhdGUpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChmaWx0ZXJzLnRvRGF0ZSkge1xyXG4gICAgICAgIHBhcmFtcy5hcHBlbmQoJ3RvRGF0ZScsIGZpbHRlcnMudG9EYXRlKTtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLmdldChgY29tcGxhaW50cy9hbGwtcGFnaW5hdGVkPyR7cGFyYW1zLnRvU3RyaW5nKCl9YCk7XHJcbiAgICAgIGlmIChyZXMuZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgc2V0Q29tcGxhaW50cyhyZXMuZGF0YS5kYXRhIHx8IFtdKTtcclxuICAgICAgICBzZXRUb3RhbENvbXBsYWludHMocmVzLmRhdGEudG90YWwgfHwgMCk7XHJcbiAgICAgICAgc2V0VG90YWxQYWdlcyhyZXMuZGF0YS50b3RhbFBhZ2VzIHx8IDEpO1xyXG4gICAgICAgIHNldEN1cnJlbnRQYWdlKHJlcy5kYXRhLnBhZ2UgfHwgMSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGZXRjaCBlcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgICBub3RpZnkoXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRmFpbGVkIHRvIGxvYWQgY29tcGxhaW50c1wiKTtcclxuICAgICAgc2V0Q29tcGxhaW50cyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICBzZXRJbml0aWFsTG9hZChmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gLS0tIEZFVENIIEFHRU5UUyAtLS1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hBZ2VudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0TG9hZGluZ0FnZW50cyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkuZ2V0KFwiL2FkbWluL2dldC1zdWItYWRtaW5zXCIpO1xyXG4gICAgICAgIGNvbnN0IGFnZW50c0xpc3QgPSBBcnJheS5pc0FycmF5KHJlcy5kYXRhKSA/IHJlcy5kYXRhIDogW107XHJcbiAgICAgICAgc2V0QWdlbnRzKGFnZW50c0xpc3QpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGZXRjaCBhZ2VudHMgZXJyb3I6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRBZ2VudHMoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldExvYWRpbmdBZ2VudHMoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIC0tLSBGRVRDSCBBTEwgQ09NUExBSU5UUyBGT1IgQ09VTlRTIC0tLVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSBcImFzc2lnblwiKSB7XHJcbiAgICAgIGZldGNoQWxsQ29tcGxhaW50cygpO1xyXG4gICAgfVxyXG4gIH0sIFthY3RpdmVUYWJdKTtcclxuXHJcbiAgLy8gLS0tIEZFVENIIENPTVBMQUlOVFMgT04gVEFCL0ZJTFRFUiBDSEFOR0UgLS0tXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChhY3RpdmVUYWIgPT09IFwiYXNzaWduXCIpIHtcclxuICAgICAgZmV0Y2hDb21wbGFpbnRzKGN1cnJlbnRQYWdlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldENvbXBsYWludHMoW10pO1xyXG4gICAgICBzZXRJbml0aWFsTG9hZChmYWxzZSk7XHJcbiAgICB9XHJcbiAgfSwgW2N1cnJlbnRQYWdlLCBmaWx0ZXJzLCBhY3RpdmVUYWJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQ29tcGxhaW50c0ZvckNvdW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkuZ2V0KCdjb21wbGFpbnRzL2FsbC1wYWdpbmF0ZWQ/cGFnZT0xJmxpbWl0PTEwMDAnKTtcclxuICAgICAgICBpZiAocmVzLmRhdGEuc3VjY2Vzcykge1xyXG4gICAgICAgICAgc2V0QWxsQ29tcGxhaW50c0ZvckNvdW50cyhyZXMuZGF0YS5kYXRhIHx8IFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZldGNoIGNvdW50cyBlcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldEluaXRpYWxMb2FkKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIFxyXG4gICAgZmV0Y2hDb21wbGFpbnRzRm9yQ291bnRzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyAtLS0gVklFVyBDT01QTEFJTlQgLS0tXHJcbiAgY29uc3QgaGFuZGxlVmlldyA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLmdldChgL2NvbXBsYWludHMvJHtpZH1gKTtcclxuICAgICAgc2V0U2VsZWN0ZWRDb21wbGFpbnQocmVzLmRhdGEpO1xyXG4gICAgICBzZXRWaWV3TW9kZShcInZpZXdcIik7XHJcbiAgICAgIHNldFZpZXdFZGl0TW9kYWxPcGVuKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGZXRjaCBjb21wbGFpbnQgZmFpbGVkXCIsIGVycik7XHJcbiAgICAgIG5vdGlmeShcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJGYWlsZWQgdG8gbG9hZCBjb21wbGFpbnQgZGV0YWlsc1wiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyAtLS0gVVBEQVRFIENPTVBMQUlOVCAtLS1cclxuICBjb25zdCB1cGRhdGVDb21wbGFpbnQgPSBhc3luYyAoaWQsIGRhdGEpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5wdXQoYGNvbXBsYWludHMvdXBkYXRlLyR7aWR9YCwgZGF0YSk7XHJcbiAgICAgIHJldHVybiByZXMuZGF0YTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJVcGRhdGUgQ29tcGxhaW50IEVycm9yOlwiLCBlcnJvcj8ucmVzcG9uc2U/LmRhdGEgfHwgZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgIHRocm93IGVycm9yO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBDT05GSVJNIEFTU0lHTiAtLS1cclxuICBjb25zdCBjb25maXJtQXNzaWduID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZENvbXBsYWludCB8fCAhc2VsZWN0ZWRBZ2VudCkgcmV0dXJuO1xyXG4gICAgY29uc3QgYWdlbnQgPSBhZ2VudHMuZmluZCgoYSkgPT4gYS5faWQgPT09IHNlbGVjdGVkQWdlbnQpO1xyXG4gICAgaWYgKCFhZ2VudCkge1xyXG4gICAgICBub3RpZnkoXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiU2VsZWN0ZWQgQWRtaW4gbm90IGZvdW5kIGluIGxpc3RcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IHVwZGF0ZUNvbXBsYWludChzZWxlY3RlZENvbXBsYWludC5faWQsIHtcclxuICAgICAgICBhc3NpZ25lZFRvOiBhZ2VudC5faWQsXHJcbiAgICAgICAgYXNzaWduZWRUb05hbWU6IGFnZW50Lm5hbWUsXHJcbiAgICAgICAgc3RhdHVzOiBcImlzIFBlbmRpbmdcIixcclxuICAgICAgfSk7XHJcbiAgICAgIG5vdGlmeShcInN1Y2Nlc3NcIiwgXCJBc3NpZ25lZCBTdWNjZXNzZnVsbHlcIiwgYENvbXBsYWludCBhc3NpZ25lZCB0byAke2FnZW50Lm5hbWV9YCk7XHJcbiAgICAgIHNldEFzc2lnbk1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICAgIHNldFZpZXdFZGl0TW9kYWxPcGVuKGZhbHNlKTtcclxuICAgICAgc2V0U2VsZWN0ZWRBZ2VudChcIlwiKTtcclxuICAgICAgc2V0U2VsZWN0ZWRDb21wbGFpbnQobnVsbCk7XHJcbiAgICAgIGlmIChhY3RpdmVUYWIgPT09IFwiYXNzaWduXCIpIHtcclxuICAgICAgICBmZXRjaENvbXBsYWludHMoY3VycmVudFBhZ2UpO1xyXG4gICAgICAgIGZldGNoQWxsQ29tcGxhaW50cygpOyBcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIlVwZGF0ZSBDb21wbGFpbnQgRXJyb3I6XCIsIGVycm9yKTtcclxuICAgICAgbm90aWZ5KFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIkZhaWxlZCB0byBhc3NpZ24gY29tcGxhaW50XCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBSRVNFVCBGSUxURVJTIC0tLVxyXG4gIGNvbnN0IHJlc2V0RmlsdGVycyA9ICgpID0+IHtcclxuICAgIHNldEZpbHRlcnMoe1xyXG4gICAgICBzdWJqZWN0OiBcIlwiLFxyXG4gICAgICBhc3NpZ25lZFRvOiBcIlwiLFxyXG4gICAgICBzdGF0dXM6IFwiXCIsXHJcbiAgICAgIGZyb21EYXRlOiBcIlwiLFxyXG4gICAgICB0b0RhdGU6IFwiXCIsXHJcbiAgICB9KTtcclxuICAgIHNldEN1cnJlbnRQYWdlKDEpO1xyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBDQUxDVUxBVEUgQ09VTlRTIC0tLVxyXG4gIGNvbnN0IGNvdW50cyA9IHVzZU1lbW8oKCkgPT4gKHtcclxuICAgIGFzc2lnbmVkOiBhbGxDb21wbGFpbnRzRm9yQ291bnRzLmZpbHRlcihjID0+IGMuYXNzaWduZWRUbykubGVuZ3RoLFxyXG4gICAgdW5hc3NpZ25lZDogYWxsQ29tcGxhaW50c0ZvckNvdW50cy5maWx0ZXIoYyA9PiAhYy5hc3NpZ25lZFRvKS5sZW5ndGgsXHJcbiAgICBvcGVuOiBhbGxDb21wbGFpbnRzRm9yQ291bnRzLmZpbHRlcihjID0+IGMuc3RhdHVzID09PSBcIk9wZW5cIikubGVuZ3RoLFxyXG4gICAgcGVuZGluZzogYWxsQ29tcGxhaW50c0ZvckNvdW50cy5maWx0ZXIoYyA9PiBjLnN0YXR1cyA9PT0gXCJpcyBQZW5kaW5nXCIpLmxlbmd0aCxcclxuICAgIGNsb3NlZDogYWxsQ29tcGxhaW50c0ZvckNvdW50cy5maWx0ZXIoYyA9PiBjLnN0YXR1cyA9PT0gXCJDbG9zZWRcIikubGVuZ3RoLFxyXG4gICAgdG90YWw6IGFsbENvbXBsYWludHNGb3JDb3VudHMubGVuZ3RoXHJcbiAgfSksIFthbGxDb21wbGFpbnRzRm9yQ291bnRzXSk7XHJcblxyXG4gIC8vIC0tLSBUQUJMRSBEQVRBIC0tLVxyXG4gIGNvbnN0IHRhYmxlRGF0YTEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBjb21wbGFpbnRzLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICAgIF9pZDogaXRlbS5faWQsXHJcbiAgICAgIGNvbXBsYWludF9jb2RlOiBpdGVtLmNvbXBsYWludF9jb2RlIHx8IFwiTi9BXCIsIFxyXG4gICAgICBzbDogKGN1cnJlbnRQYWdlIC0gMSkgKiAxMCArIGluZGV4ICsgMSxcclxuICAgICAgdXNlck5hbWU6IGl0ZW0/LnVzZXJJZD8ubmFtZSB8fCBpdGVtLm5hbWUsIFxyXG4gICAgICBzdWJqZWN0OiBpdGVtLnN1YmplY3QsXHJcbiAgICAgIGFzc2lnbmVkTmFtZTogZ2V0QXNzaWduZWVOYW1lKGl0ZW0pLFxyXG4gICAgICBzdGF0dXM6IGl0ZW0uc3RhdHVzLFxyXG4gICAgICBkYXRlOiBmb3JtYXREYXRlKGl0ZW0uY3JlYXRlZEF0KSxcclxuICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgc2V0T3BlbkFjdGlvbklkKG9wZW5BY3Rpb25JZCA9PT0gaXRlbS5faWQgPyBudWxsIDogaXRlbS5faWQpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWdyYXktMjAwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAg4ouuXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIHtvcGVuQWN0aW9uSWQgPT09IGl0ZW0uX2lkICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC02IHRvcC0xMCBiZy13aGl0ZSBib3JkZXIgcm91bmRlZC1sZyBzaGFkb3ctbGcgdy00MCB6LTUwXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlVmlldyhpdGVtLl9pZCk7XHJcbiAgICAgICAgICAgICAgICAgIHNldE9wZW5BY3Rpb25JZChudWxsKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgcHgtNCBweS0yIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8RXllIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+Vmlldzwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZENvbXBsYWludChpdGVtKTtcclxuICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRBZ2VudChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgc2V0Vmlld01vZGUoXCJhc3NpZ25cIik7XHJcbiAgICAgICAgICAgICAgICAgIHNldFZpZXdFZGl0TW9kYWxPcGVuKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRPcGVuQWN0aW9uSWQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIHB4LTQgcHktMiBob3ZlcjpiZy1ncmF5LTEwMCB0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8VXNlclBsdXMgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5Bc3NpZ248L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxuICAgIH0pKTtcclxuICB9LCBbY29tcGxhaW50cywgY3VycmVudFBhZ2UsIG9wZW5BY3Rpb25JZCwgYWdlbnRzXSk7XHJcblxyXG4gIGlmIChpbml0aWFsTG9hZCAmJiBhY3RpdmVUYWIgIT09IFwiYXNzaWduXCIpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDw+XHJcbiAgICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbiAgICAgICAgPE5hdmJhciAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LXNjcmVlbiBtdC0xNFwiPlxyXG4gICAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1jb2wgdy1mdWxsIHAtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwibXgtYXV0byB0ZXh0LTJ4bCBmb250LWJvbGQgbXktNVwiPkFkbWluIFN1cHBvcnQ8L2gyPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC02IG1iLTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYihcImFzc2lnblwiKX0gY2xhc3NOYW1lPVwiZ3JvdXAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy0zMiBoLTMyIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNjAwIHRvLWdyZWVuLTcwMCBvcGFjaXR5LTUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMCByb3VuZGVkLWZ1bGwgLW1yLTE2IC1tdC0xNiBibHVyLXhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwLTlcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEyIGgtMTIgYmctZ3JlZW4tNTAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWRBc3NpZ25tZW50SW5kIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPkFzc2lnbjwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+QXNzaWduIHRpY2tldHMgdG8gc3RhZmY8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTYgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+e2NvdW50cy5hc3NpZ25lZH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+QXNzaWduZWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1yZWQtNTAwXCI+e2NvdW50cy51bmFzc2lnbmVkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5VbmFzc2lnbmVkPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8Lz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuIHJldHVybiAoXHJcbiAgPD5cclxuICAgIHtjb250ZXh0SG9sZGVyfVxyXG4gICAgPE5hdmJhciAvPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctc2NyZWVuIG10LTE0XCI+XHJcbiAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1jb2wgdy1mdWxsIHAtNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAge2FjdGl2ZVRhYiAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRBY3RpdmVUYWIobnVsbCk7XHJcbiAgICAgICAgICAgICAgICByZXNldEZpbHRlcnMoKTtcclxuICAgICAgICAgICAgICAgIHNldEN1cnJlbnRQYWdlKDEpO1xyXG4gICAgICAgICAgICAgICAgc2V0Q29tcGxhaW50cyhbXSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTAgcHgtMyBweS0xIHJvdW5kZWQtbWQgYmctZ3JheS0yMDAgaG92ZXI6YmctZ3JheS0zMDAgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICDihpAgQmFja1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwibXgtYXV0byB0ZXh0LTJ4bCBmb250LWJvbGQgbXktNVwiPkFkbWluIFN1cHBvcnQ8L2gyPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgIHshYWN0aXZlVGFiICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNiBtYi02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwiYXNzaWduXCIpfSBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctMzIgaC0zMiBiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTYwMCB0by1ncmVlbi03MDAgb3BhY2l0eS01IGdyb3VwLWhvdmVyOm9wYWNpdHktMTAgcm91bmRlZC1mdWxsIC1tci0xNiAtbXQtMTYgYmx1ci14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtOVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy1ncmVlbi01MCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kQXNzaWdubWVudEluZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+QXNzaWduPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+QXNzaWduIHRpY2tldHMgdG8gc3RhZmY8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTYgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+e2NvdW50cy5hc3NpZ25lZH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPkFzc2lnbmVkPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1yZWQtNTAwXCI+e2NvdW50cy51bmFzc2lnbmVkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+VW5hc3NpZ25lZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtMyBtdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5TdGFmZiBBc3NpZ25tZW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTYwMCB0by1ncmVlbi03MDAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ibHVlLTEwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWJsdWUtNjAwIG10LTFcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+UXVpY2sgVGlwczwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LWRpc2MgbGlzdC1pbnNpZGUgdGV4dC1zbGF0ZS03MDAgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5WaWV3IGFuZCBtYW5hZ2UgYWxsIHN1cHBvcnQgcmVxdWVzdHMgaW4gb25lIHBsYWNlPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPkFzc2lnbiBjb21wbGFpbnRzIHRvIHN0YWZmIGVhc2lseTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5UcmFjayBjb21wbGFpbnQgc3RhdHVzIGFuZCByZXNvbHV0aW9uIHByb2dyZXNzPC9saT5cclxuICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIC0tLSBBU1NJR04gVEFCIENPTlRFTlQgLS0tICovfVxyXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJhc3NpZ25cIiAmJiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgey8qIERhc2hib2FyZCBDYXJkcyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTYgbWItNlwiPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhcmRDbGljayhcIlwiKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYmctd2hpdGUgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgYm9yZGVyLTIgJHtcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJzLnN0YXR1cyA9PT0gXCJcIiA/IFwiYm9yZGVyLWJsdWUtNTAwIHJpbmctMSByaW5nLWJsdWUtNTAwXCIgOiBcImJvcmRlci10cmFuc3BhcmVudFwiXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBiZy1ibHVlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNjAwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlcnMgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+VG90YWw8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPkFsbCB0aWNrZXRzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwXCI+e2NvdW50cy50b3RhbH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogT3BlbiBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDYXJkQ2xpY2soXCJPcGVuXCIpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy13aGl0ZSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlciBib3JkZXItMiAke1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlcnMuc3RhdHVzID09PSBcIk9wZW5cIiA/IFwiYm9yZGVyLW9yYW5nZS01MDAgcmluZy0xIHJpbmctb3JhbmdlLTUwMFwiIDogXCJib3JkZXItdHJhbnNwYXJlbnRcIlxyXG4gICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYmctb3JhbmdlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy1vcmFuZ2UtMTAwIHRleHQtb3JhbmdlLTYwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPk9wZW48L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPk5ldyBjb21wbGFpbnRzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS02MDBcIj57Y291bnRzLm9wZW59PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFBlbmRpbmcgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2FyZENsaWNrKFwiaXMgUGVuZGluZ1wiKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYmctd2hpdGUgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgYm9yZGVyLTIgJHtcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJzLnN0YXR1cyA9PT0gXCJpcyBQZW5kaW5nXCIgPyBcImJvcmRlci15ZWxsb3ctNTAwIHJpbmctMSByaW5nLXllbGxvdy01MDBcIiA6IFwiYm9yZGVyLXRyYW5zcGFyZW50XCJcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLXllbGxvdy0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEyIGgtMTIgYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy02MDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxaYXAgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+UGVuZGluZzwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+SW4gcHJvZ3Jlc3M8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQteWVsbG93LTYwMFwiPntjb3VudHMucGVuZGluZ308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ2xvc2VkIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhcmRDbGljayhcIkNsb3NlZFwiKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYmctd2hpdGUgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgYm9yZGVyLTIgJHtcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJzLnN0YXR1cyA9PT0gXCJDbG9zZWRcIiA/IFwiYm9yZGVyLWdyZWVuLTUwMCByaW5nLTEgcmluZy1ncmVlbi01MDBcIiA6IFwiYm9yZGVyLXRyYW5zcGFyZW50XCJcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLWdyZWVuLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi02MDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDbGlwYm9hcmRDaGVjayBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5DbG9zZWQ8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlJlc29sdmVkIGlzc3VlczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmVlbi02MDBcIj57Y291bnRzLmNsb3NlZH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEZpbHRlcnMgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgYm9yZGVyIHJvdW5kZWQtbGcgcC00IGJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNSBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIHBiLTJcIj5TdWJqZWN0PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3ViamVjdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5zdWJqZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbHRlckNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHB4LTMgcHktMiB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsIFN1YmplY3RzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Wy4uLm5ldyBTZXQoYWxsQ29tcGxhaW50cy5tYXAoYyA9PiBjLnN1YmplY3QpKV0ubWFwKHN1YmplY3QgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17c3ViamVjdH0gdmFsdWU9e3N1YmplY3R9PntzdWJqZWN0fTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIHBiLTJcIj5Bc3NpZ25lZCBUbzwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFzc2lnbmVkVG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMuYXNzaWduZWRUb31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWx0ZXJDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBweC0zIHB5LTIgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ0FnZW50c31cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsIEFzc2lnbmVlczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlVuYXNzaWduZWRcIj5VbmFzc2lnbmVkPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcChhZ2VudCA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PnthZ2VudC5uYW1lfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIHBiLTJcIj5TdGF0dXM8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMuc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbHRlckNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHB4LTMgcHktMiB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsIFN0YXR1czwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk9wZW5cIj5PcGVuPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiaXMgUGVuZGluZ1wiPlBlbmRpbmc8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDbG9zZWRcIj5DbG9zZWQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgcGItMlwiPkZyb20gRGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZnJvbURhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMuZnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsdGVyQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIHBiLTJcIj5UbyBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0b0RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMudG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbHRlckNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHB4LTMgcHktMiB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtyZXNldEZpbHRlcnN9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWJsdWUtMjAwIHJvdW5kZWQgdGV4dC1zbSBob3ZlcjpiZy1ibHVlLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBSZXNldCBGaWx0ZXJzXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBEYXRhIFRhYmxlICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3cgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB3LWZ1bGwgb3ZlcmZsb3cteC1hdXRvIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBoLTY0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNwaW4gc2l6ZT1cImxhcmdlXCIgdGlwPVwiTG9hZGluZyBjb21wbGFpbnRzLi4uXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbSBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTaG93aW5nIHt0YWJsZURhdGExLmxlbmd0aH0gb2Yge3RvdGFsQ29tcGxhaW50c30gY29tcGxhaW50cyAoUGFnZSB7Y3VycmVudFBhZ2V9IG9mIHt0b3RhbFBhZ2VzfSlcclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YT17dGFibGVEYXRhMX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiY29tcGxhaW50X2NvZGVcIiwgaGVhZGVyOiBcImNvbXBsYWludCBjb2RlXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIk5hbWVcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJzdWJqZWN0XCIsIGhlYWRlcjogXCJTdWJqZWN0XCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiYXNzaWduZWROYW1lXCIsIGhlYWRlcjogXCJBc3NpZ25lZCBUb1wiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiRGF0ZVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGlzRXhwb3J0RW5hYmxlZD17dHJ1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDb21wbGFpbnRzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkNvbXBsYWludHMgUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0b3RhbFBhZ2VzID4gMSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnaW5hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnQ9e2N1cnJlbnRQYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsPXt0b3RhbENvbXBsYWludHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGFnZVNpemU9ezEwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsocGFnZSkgPT4gc2V0Q3VycmVudFBhZ2UocGFnZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NpemVDaGFuZ2VyPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiAtLS0gQVNTSUdOIE1PREFMIC0tLSAqL31cclxuICAgICAgICAgIHthc3NpZ25Nb2RhbE9wZW4gJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei01MFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBwLTYgdy1bNDAwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgbWItNFwiPkFzc2lnbiBDb21wbGFpbnQ8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIG1iLTRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBZ2VudH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEFnZW50KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBFbXBsb3llZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfSB7YWdlbnQuZW1haWwgPyBgfCAke2FnZW50LmVtYWlsfWAgOiAnJ31cclxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QXNzaWduTW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctZ3JheS0yMDAgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjb25maXJtQXNzaWdufVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshc2VsZWN0ZWRBZ2VudH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEFzc2lnblxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIC0tLSBGSVhFRDogVklFVy9FRElUIE1PREFMIC0tLSAqL31cclxuICAgICAgICAge3ZpZXdFZGl0TW9kYWxPcGVuICYmIHNlbGVjdGVkQ29tcGxhaW50ICYmIChcclxuICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei01MFwiPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1sZyB3LVs5NSVdIG1heC13LTR4bCBtYXgtaC1bOTB2aF0gb3ZlcmZsb3ctYXV0byBwLTYgcmVsYXRpdmVcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPkNvbXBsYWludCBEZXRhaWxzPC9oMz5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3RWRpdE1vZGFsT3BlbihmYWxzZSl9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtYmxhY2tcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxYIHNpemU9ezI0fSAvPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgIFxyXG4gICAgICAgIHsvKiBOYW1lIEZpZWxkICovfVxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5OYW1lPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDb21wbGFpbnQubmFtZSB8fCBzZWxlY3RlZENvbXBsYWludC51c2VySWQ/Lm5hbWUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkLW1kIHB4LTMgcHktMiBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogTW9iaWxlIEZpZWxkICovfVxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5Nb2JpbGU8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZENvbXBsYWludC5tb2JpbGUgfHwgc2VsZWN0ZWRDb21wbGFpbnQudXNlcklkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkLW1kIHB4LTMgcHktMiBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogU3ViamVjdCBGaWVsZCAqL31cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+U3ViamVjdDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ29tcGxhaW50LnN1YmplY3QgfHwgXCJcIn1cclxuICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkLW1kIHB4LTMgcHktMiBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRGVwYXJ0bWVudCBGaWVsZCAqL31cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+RGVwYXJ0bWVudDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdmFsdWU9e3R5cGVvZiBzZWxlY3RlZENvbXBsYWludC5kZXNpZ25hdGlvbiA9PT0gJ29iamVjdCcgXHJcbiAgICAgICAgICAgICAgPyBzZWxlY3RlZENvbXBsYWludC5kZXNpZ25hdGlvbj8udGl0bGUgfHwgXCJcIiBcclxuICAgICAgICAgICAgICA6IHNlbGVjdGVkQ29tcGxhaW50LmRlc2lnbmF0aW9uIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZC1tZCBweC0zIHB5LTIgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEFzc2lnbmVkIFRvIEZpZWxkICovfVxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5Bc3NpZ25lZCBUbzwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdmFsdWU9e2dldEFzc2lnbmVlTmFtZShzZWxlY3RlZENvbXBsYWludCl9XHJcbiAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZC1tZCBweC0zIHB5LTIgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFN0YXR1cyBGaWVsZCAqL31cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+U3RhdHVzPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDb21wbGFpbnQuc3RhdHVzIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZC1tZCBweC0zIHB5LTIgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIERhdGUgRmllbGQgKi99XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPkRhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHZhbHVlPXtmb3JtYXREYXRlKHNlbGVjdGVkQ29tcGxhaW50LmNyZWF0ZWRBdCl9XHJcbiAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZC1tZCBweC0zIHB5LTIgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICB7LyogTWVzc2FnZSBGaWVsZCAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPk1lc3NhZ2U8L2xhYmVsPlxyXG4gICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgIHJvd3M9ezR9XHJcbiAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZENvbXBsYWludC5tZXNzYWdlIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZC1tZCBweC0zIHB5LTIgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICB7LyogRklYRUQ6IEF0dGFjaG1lbnRzIFNlY3Rpb24gKi99XHJcbiAgICAgICAge3NlbGVjdGVkQ29tcGxhaW50LmNvbXBsYWludF91cGxvYWRzICYmIHNlbGVjdGVkQ29tcGxhaW50LmNvbXBsYWludF91cGxvYWRzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgIEF0dGFjaG1lbnRzICh7c2VsZWN0ZWRDb21wbGFpbnQuY29tcGxhaW50X3VwbG9hZHMubGVuZ3RofSlcclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkQ29tcGxhaW50LmNvbXBsYWludF91cGxvYWRzLm1hcCgoZmlsZSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIEdldCB0aGUgVVJMIC0gaGFuZGxlIGJvdGggb2JqZWN0IGFuZCBzdHJpbmcgZm9ybWF0c1xyXG4gICAgICAgICAgICAgICAgbGV0IGZpbGVVcmwgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgbGV0IGZpbGVOYW1lID0gYEF0dGFjaG1lbnQgJHtpbmRleCArIDF9YDtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBmaWxlID09PSAnb2JqZWN0Jykge1xyXG4gICAgICAgICAgICAgICAgICBmaWxlVXJsID0gZmlsZS51cmwgfHwgXCJcIjtcclxuICAgICAgICAgICAgICAgICAgZmlsZU5hbWUgPSBmaWxlLm5hbWUgfHwgYEF0dGFjaG1lbnQgJHtpbmRleCArIDF9YDtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGZpbGUgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgICAgICAgICAgIGZpbGVVcmwgPSBmaWxlO1xyXG4gICAgICAgICAgICAgICAgICBmaWxlTmFtZSA9IGBBdHRhY2htZW50ICR7aW5kZXggKyAxfWA7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIC8vIFNraXAgaWYgbm8gVVJMXHJcbiAgICAgICAgICAgICAgICBpZiAoIWZpbGVVcmwpIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvLyBEZXRlcm1pbmUgaWYgaXQncyBhbiBpbWFnZVxyXG4gICAgICAgICAgICAgICAgY29uc3QgaXNJbWFnZSA9IGZpbGVVcmwubWF0Y2goL1xcLihqcGVnfGpwZ3xnaWZ8cG5nfHdlYnApJC9pKSB8fCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVVcmwuaW5jbHVkZXMoJ2FtYXpvbmF3cy5jb20nKSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWUubWF0Y2goL1xcLihqcGVnfGpwZ3xnaWZ8cG5nfHdlYnApJC9pKTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQXR0YWNobWVudENsaWNrKGZpbGVVcmwsIGZpbGVOYW1lKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZC1sZyBwLTMgYmctZ3JheS01MCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlciBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbiBncm91cFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBoLTMyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkIGJnLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXNJbWFnZSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17ZmlsZVVybH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2ZpbGVOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCB3LWZ1bGwgb2JqZWN0LWNvbnRhaW4gZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25FcnJvcj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJJbWFnZSBmYWlsZWQgdG8gbG9hZDpcIiwgZmlsZVVybCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5vbmVycm9yID0gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnNyYyA9ICdodHRwczovL3ZpYS5wbGFjZWhvbGRlci5jb20vMTUwP3RleHQ9RmFpbGVkK3RvK0xvYWQnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtNHhsIG1iLTJcIj7wn5OEPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWNlbnRlclwiPntmaWxlTmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay8xMCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQteHMgYmctYmxhY2svNTAgcHgtMiBweS0xIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDbGljayB0byB7aXNJbWFnZSA/ICdWaWV3JyA6ICdPcGVuJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwIHRydW5jYXRlIHctZnVsbCB0ZXh0LWNlbnRlciBtdC0yXCIgdGl0bGU9e2ZpbGVOYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtmaWxlTmFtZS5sZW5ndGggPiAzMCA/IGZpbGVOYW1lLnN1YnN0cmluZygwLCAyNykgKyAnLi4uJyA6IGZpbGVOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgXHJcbiAgICAgICAgey8qIEFzc2lnbiBTZWN0aW9uIChpZiBpbiBhc3NpZ24gbW9kZSkgKi99XHJcbiAgICAgICAge3ZpZXdNb2RlID09PSBcImFzc2lnblwiICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5Bc3NpZ24gVG88L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQWdlbnR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEFnZW50KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHJvdW5kZWQtbWQgcHgtMyBweS0yXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgRW1wbG95ZWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICB7YWdlbnRzLm1hcChhZ2VudCA9PiAoXHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHwge2FnZW50LmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9mb3JtPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbXQtNiBnYXAtM1wiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdFZGl0TW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZC1tZCBob3ZlcjpiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAge3ZpZXdNb2RlID09PSBcImFzc2lnblwiICYmIChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17Y29uZmlybUFzc2lnbn1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9eyFzZWxlY3RlZEFnZW50fVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBBc3NpZ25cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbil9XHJcblxyXG4gICAgICAgICAgey8qIC0tLSBJTUFHRSBQUkVWSUVXIE1PREFMIC0tLSAqL31cclxuICAgICAgICAgIHtpbWFnZVByZXZpZXdPcGVuICYmIChcclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bNjBdIGJnLWJsYWNrLzkwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiYWNrZHJvcC1ibHVyLXNtXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJbWFnZVByZXZpZXdPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IHNldEltYWdlUHJldmlld09wZW4oZmFsc2UpOyB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCB0ZXh0LXdoaXRlIGhvdmVyOnRleHQtZ3JheS0zMDAgYmctYmxhY2svNTAgcm91bmRlZC1mdWxsIHAtMlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFggc2l6ZT17MzJ9IC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgc3JjPXtwcmV2aWV3SW1hZ2VTcmN9XHJcbiAgICAgICAgICAgICAgICBhbHQ9XCJGdWxsIFByZXZpZXdcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LXctZnVsbCBtYXgtaC1bOTB2aF0gb2JqZWN0LWNvbnRhaW4gcm91bmRlZCBzaGFkb3ctMnhsXCJcclxuICAgICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJQcmV2aWV3IGltYWdlIGZhaWxlZCB0byBsb2FkOlwiLCBwcmV2aWV3SW1hZ2VTcmMpO1xyXG4gICAgICAgICAgICAgICAgICBub3RpZnkoXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRmFpbGVkIHRvIGxvYWQgaW1hZ2VcIik7XHJcbiAgICAgICAgICAgICAgICAgIHNldEltYWdlUHJldmlld09wZW4oZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgU3VwcG9ydHM7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1N1cHBvcnRzLmpzeCJ9