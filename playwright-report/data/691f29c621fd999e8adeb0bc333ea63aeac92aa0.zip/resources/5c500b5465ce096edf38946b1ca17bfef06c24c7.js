import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CollectionExecutiveReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import { Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import {
  FiFilter,
  FiCalendar,
  FiUsers,
  FiCreditCard
} from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const CollectionExecutiveReport = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableDaybook, setTableDaybook] = useState([]);
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [receiptNo, setReceiptNo] = useState("");
  const [paymentMode, setPaymentMode] = useState("cash");
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showFilterField, setShowFilterField] = useState(false);
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const now = /* @__PURE__ */ new Date();
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const todayString = now.toISOString().split("T")[0];
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedDate, setSelectedDate] = useState(todayString);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState("");
  const [hideAccountType, setHideAccountType] = useState("");
  const [selectedAccountType, setSelectedAccountType] = useState("");
  const [selectedCustomers, setSelectedCustomers] = useState("");
  const [selectedCollectionExecutive, setSelectedCollectionExecutive] = useState("");
  const [payments, setPayments] = useState([]);
  const [showAllPaymentModes, setShowAllPaymentModes] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    ticket: "",
    receipt_no: "",
    pay_date: "",
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    collection_executive: ""
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const handleModalClose = () => setShowUploadModal(false);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const showPaymentsModes = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setShowAllPaymentModes(showPaymentsModes);
    }
  }, []);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const isModify = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setHideAccountType(isModify);
    }
  }, []);
  useEffect(() => {
    (async () => {
      try {
        const [emplys] = await Promise.all(
          [
            api.get("/agent/collection-executive")
          ]
        );
        const emps = emplys?.data?.collectionExecutive.map((emp) => ({
          _id: emp?._id?._id,
          full_name: emp?._id?.name,
          phone_number: emp?._id?.phone_number,
          selected_type: "agent_type"
        }));
        setEmployees(emps);
      } catch (error) {
        setEmployees([]);
      }
    })();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchReceipt = async () => {
      try {
        const response = await api.get("/payment/get-latest-receipt");
        setReceiptNo(response.data);
      } catch (error) {
        console.error("Error fetching receipt data:", error);
      }
    };
    fetchReceipt();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setFilteredUsers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    if (receiptNo) {
      setFormData((prevData) => ({
        ...prevData,
        receipt_no: receiptNo.receipt_no
      }));
    }
  }, [receiptNo]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleChangeUser = (e) => {
    const { name, value } = e.target;
    const [user_id, ticket] = value.split("-");
    setFormData((prevData) => ({
      ...prevData,
      user_id,
      ticket
    }));
  };
  const handleGroup = async (event) => {
    const groupId = event.target.value;
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      group_id: groupId
    }));
    handleGroupChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        console.error("Error fetching group data:", error);
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const groupOptions = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
  };
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  const formatPayDate = (dateString) => {
    const date = new Date(dateString);
    const options = { day: "numeric", month: "long", year: "numeric" };
    return date.toLocaleDateString("en-US", options).replace(",", "");
  };
  useEffect(
    () => {
      const abortController = new AbortController();
      const fetchPayments = async () => {
        try {
          setIsLoading(true);
          const response = await api.get(`/payment/collection/report`, {
            params: {
              from_date: selectedFromDate,
              to_date: selectedDate,
              groupId: selectedAuctionGroupId,
              userId: selectedCustomers,
              pay_type: selectedPaymentMode,
              account_type: selectedAccountType,
              collection_executive: selectedCollectionExecutive
            },
            signal: abortController.signal
          });
          console.info(response.data, "testing account type");
          if (response.data && response.data.length > 0) {
            const validPayments = response.data.filter(
              (payment) => payment.group_id !== null
            );
            setFilteredAuction(validPayments);
            const totalAmount = validPayments.reduce(
              (sum, payment) => sum + Number(payment.amount || 0),
              0
            );
            console.info(totalAmount, "check amount");
            setPayments(totalAmount);
            const formattedData = validPayments.map((group, index) => ({
              _id: group?._id,
              id: index + 1,
              date: group?.pay_date,
              group: group?.group_id?.group_name || group.pay_for,
              name: group?.user_id?.full_name,
              category: group?.pay_for || "Chit",
              phone_number: group?.user_id?.phone_number,
              receipt_no: group?.receipt_no,
              old_receipt_no: group?.old_receipt_no,
              ticket: group?.ticket,
              amount: group?.amount,
              transaction_date: group?.createdAt?.split("T")?.[0],
              mode: group?.pay_type,
              account_type: group?.account_type,
              collected_by: group?.collected_by?.name || group?.admin_type?.admin_name || "Super Admin",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          Link,
                          {
                            target: "_blank",
                            to: `/print/${group._id}`,
                            className: "text-violet-600 ",
                            children: "Print"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                            lineNumber: 331,
                            columnNumber: 21
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 344,
                    columnNumber: 19
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 324,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 323,
                columnNumber: 13
              }, this)
            }));
            setTableDaybook(formattedData);
          } else {
            setFilteredAuction([]);
          }
        } catch (error) {
          console.error("Error fetching payment data:", error);
          setFilteredAuction([]);
          setPayments(0);
        } finally {
          setIsLoading(false);
        }
      };
      fetchPayments();
      return () => {
        abortController.abort();
      };
    },
    [
      selectedAuctionGroupId,
      selectedDate,
      selectedPaymentMode,
      selectedCustomers,
      selectedFromDate,
      selectedAccountType,
      selectedCollectionExecutive
    ]
  );
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "group", header: "Group Name" },
    { key: "name", header: "Customer Name" },
    { key: "category", header: "Category" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "receipt_no", header: "Receipt Number" },
    { key: "old_receipt_no", header: "Old Receipt" },
    { key: "ticket", header: "Ticket" },
    { key: "amount", header: "Amount" },
    { key: "mode", header: "Payment Mode" },
    ...hideAccountType ? [{ key: "account_type", header: "Account Type" }] : [],
    { key: "collected_by", header: "Collected By" },
    { key: "action", header: "Action" }
  ];
  useEffect(() => {
    if (groupInfo && formData.bid_amount) {
      const commission = groupInfo.group_value * 5 / 100 || 0;
      const win_amount = (groupInfo.group_value || 0) - (formData.bid_amount || 0);
      const divident = (formData.bid_amount || 0) - commission;
      const divident_head = groupInfo.group_members ? divident / groupInfo.group_members : 0;
      const payable = (groupInfo.group_install || 0) - divident_head;
      setFormData((prevData) => ({
        ...prevData,
        group_id: groupInfo._id,
        commission,
        win_amount,
        divident,
        divident_head,
        payable
      }));
    }
  }, [groupInfo, formData.bid_amount]);
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" ? prevData.transaction_id : ""
    }));
  };
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/payment/get-payment-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleDeleteAuction = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/payment/delete-payment/${currentGroup._id}`);
        alert("Payment deleted successfully");
        setShowModalDelete(false);
        setCurrentGroup(null);
        window.location.reload();
      } catch (error) {
        console.error("Error deleting auction:", error);
      }
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/auction/get-auction-by-id/${groupId}`);
      setCurrentUpdateGroup(response.data);
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching auction:", error);
    }
  };
  const handleFileSubmit = async (e) => {
    e.preventDefault();
    const formDatas = new FormData();
    const fileInput = e.target.file;
    if (fileInput && fileInput.files[0]) {
      formDatas.append("file", fileInput.files[0]);
      try {
        const response = await api.post(`/payment/payment-excel`, formDatas, {
          headers: { "Content-Type": "multipart/form-data" }
        });
        if (response.status === 200) {
          alert("File uploaded successfully!");
          window.location.reload();
          setShowUploadModal(false);
        }
      } catch (error) {
        console.error("Error uploading file:", error);
        alert("Failed to upload file.");
      }
    } else {
      alert("Please select a file to upload.");
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "min-w-screen bg-gray-50 min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-30", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 509,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 513,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-6 lg:p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8 pb-6 border-b border-gray-200", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-900 mb-2", children: "Collection Executive Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 521,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm", children: "View and manage collection reports with advanced filters" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 524,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 520,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
          /* @__PURE__ */ jsxDEV(FiFilter, { className: "text-violet-600", size: 20 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 532,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-900", children: "Filters" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 533,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 531,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
              /* @__PURE__ */ jsxDEV(FiCalendar, { className: "inline mr-2" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 540,
                columnNumber: 21
              }, this),
              "Filter Option"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 539,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                onChange: handleSelectFilter,
                value: selectedLabel,
                placeholder: "Select Filter",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full",
                size: "large",
                children: groupOptions.map(
                  (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 559,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 543,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 538,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Collection Executive" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 566,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedCollectionExecutive || null,
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                placeholder: "Select Collection Executive",
                onChange: (groupId) => setSelectedCollectionExecutive(groupId),
                className: "w-full",
                size: "large",
                children: employees.map(
                  (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group?._id, children: [
                    group?.full_name,
                    " - ",
                    group.phone_number
                  ] }, group?._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 586,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 569,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 565,
            columnNumber: 17
          }, this),
          showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "From Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 597,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedFromDate,
                  onChange: (e) => setSelectedFromDate(e.target.value),
                  className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-violet-500 outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 600,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 596,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "To Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 608,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedDate,
                  onChange: (e) => setSelectedDate(e.target.value),
                  className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-violet-500 outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 611,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 607,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 595,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
              /* @__PURE__ */ jsxDEV(FiUsers, { className: "inline mr-2" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 624,
                columnNumber: 21
              }, this),
              "Group"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 623,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedAuctionGroupId,
                onChange: handleGroupPayment,
                placeholder: "Select Group",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full",
                size: "large",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 642,
                    columnNumber: 21
                  }, this),
                  groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                      lineNumber: 644,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 627,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 622,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 652,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedCustomers,
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                placeholder: "Select Customer",
                onChange: (groupId) => setSelectedCustomers(groupId),
                className: "w-full",
                size: "large",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 670,
                    columnNumber: 21
                  }, this),
                  filteredUsers.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group?._id, children: [
                      group?.full_name,
                      " - ",
                      group.phone_number
                    ] }, group?._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                      lineNumber: 672,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 655,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 651,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
              /* @__PURE__ */ jsxDEV(FiCreditCard, { className: "inline mr-2" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 682,
                columnNumber: 21
              }, this),
              "Payment Mode"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 681,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedPaymentMode,
                showSearch: true,
                placeholder: "Select Payment Mode",
                popupMatchSelectWidth: false,
                onChange: (groupId) => setSelectedPaymentMode(groupId),
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full",
                size: "large",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 700,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: "Cash" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 701,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: "Online" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 702,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 685,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 680,
            columnNumber: 17
          }, this),
          showAllPaymentModes && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Account Type" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 709,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedAccountType,
                showSearch: true,
                placeholder: "Select Account Type",
                popupMatchSelectWidth: false,
                onChange: (groupId) => setSelectedAccountType(groupId),
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full",
                size: "large",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 727,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "suspense", children: "Suspense" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 728,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "credit", children: "Credit" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 729,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "adjustment", children: "Adjustment" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 730,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "others", children: "Others" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 733,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 712,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 708,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 536,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 530,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-white to-gray-50 rounded-2xl shadow-md border border-gray-100 p-6 mb-6 hover:shadow-lg transition-all duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 tracking-widest uppercase mb-3", children: "Total Amount" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 744,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold text-gray-900 leading-none", children: [
            "₹",
            payments || 0
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 749,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-green-700 mt-2 leading-relaxed max-w-md", children: numberToIndianWords(payments || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 754,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 mt-4", children: [
            "Updated as of ",
            (/* @__PURE__ */ new Date()).toLocaleDateString()
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 759,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 742,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 766,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 741,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 740,
        columnNumber: 13
      }, this),
      filteredAuction && filteredAuction.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(TableDaybook, searchText),
            columns,
            exportedPdfName: `Receipt Report`,
            exportedFileName: `Collection Executive Report.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 773,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end p-6 border-t border-gray-200 bg-gray-50", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-600", children: "Total Amount:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 781,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-gray-900", children: [
            "₹",
            payments
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 784,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 780,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 779,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 772,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-200 p-12", children: /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          failure: filteredAuction.length <= 0,
          data: "Collection Executive Report Data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 792,
          columnNumber: 17
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 791,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
      lineNumber: 518,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "View Auction" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 957,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: () => {
          }, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "Group"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 962,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "group_id",
                  value: currentUpdateGroup?.group_id?.group_name,
                  onChange: () => {
                  },
                  id: "name",
                  placeholder: "Enter the Group Name",
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 968,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 961,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_value",
                    children: "Group Value"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 981,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "group_value",
                    value: currentUpdateGroup?.group_id?.group_value,
                    id: "group_value",
                    placeholder: "select group to check",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 987,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 980,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_install",
                    children: "Group Installment"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 998,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "group_install",
                    value: currentUpdateGroup?.group_id?.group_install,
                    id: "group_install",
                    placeholder: "select group to check",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1004,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 997,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 979,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "User"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 1016,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "group_id",
                  value: `${currentUpdateGroup?.user_id?.full_name} | ${currentUpdateGroup?.ticket}`,
                  onChange: () => {
                  },
                  id: "name",
                  placeholder: "Enter the User Name",
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 1022,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 1015,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "Bid Amount"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 1035,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "bid_amount",
                  value: currentUpdateGroup?.group_id?.group_value - currentUpdateGroup?.win_amount,
                  onChange: () => {
                  },
                  id: "name",
                  placeholder: "Enter the Bid Amount",
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 1041,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 1034,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_value",
                    children: "Commission"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1057,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "commission",
                    value: currentUpdateGroup?.commission,
                    id: "commission",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1063,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 1056,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_install",
                    children: "Winning Amount"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1074,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "win_amount",
                    value: currentUpdateGroup?.win_amount,
                    id: "win_amount",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1080,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 1073,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 1055,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_value",
                    children: "Divident"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1093,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "divident",
                    value: currentUpdateGroup?.divident,
                    id: "divident",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1099,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 1092,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_install",
                    children: "Divident per Head"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1110,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "divident_head",
                    value: currentUpdateGroup?.divident_head,
                    id: "divident_head",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1116,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 1109,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_install",
                    children: "Next Payable"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1127,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "payable",
                    value: currentUpdateGroup?.payable,
                    id: "payable",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1133,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 1126,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 1091,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Auction Date"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1146,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "auction_date",
                    value: currentUpdateGroup?.auction_date,
                    onChange: () => {
                    },
                    id: "date",
                    placeholder: "Enter the Date",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1152,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 1145,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Next Date"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1164,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "next_date",
                    value: currentUpdateGroup?.next_date,
                    onChange: () => {
                    },
                    id: "date",
                    placeholder: "Enter the Date",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                    lineNumber: 1170,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                lineNumber: 1163,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 1144,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 960,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 956,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 952,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Sure want to delete this Payment ?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
            lineNumber: 1193,
            columnNumber: 15
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteAuction();
              },
              className: "space-y-6",
              children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-full text-white bg-red-700 hover:bg-red-800\r\n                    focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                  children: "Delete"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
                  lineNumber: 1204,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
              lineNumber: 1197,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
          lineNumber: 1192,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
        lineNumber: 1185,
        columnNumber: 11
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
    lineNumber: 508,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
    lineNumber: 507,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx",
    lineNumber: 506,
    columnNumber: 5
  }, this);
};
_s(CollectionExecutiveReport, "Fwgyo0EEEihGb+kR/sN6KLrtkV8=");
_c = CollectionExecutiveReport;
export default CollectionExecutiveReport;
var _c;
$RefreshReg$(_c, "CollectionExecutiveReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionExecutiveReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMFUwQixTQXdRUixVQXhRUTsyQkExVTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxRQUFRQyxnQkFBZ0I7QUFDakMsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxZQUFZO0FBQ3JCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLDJCQUEyQjtBQUVwQyxNQUFNQyw0QkFBNEJBLE1BQU07QUFBQUMsS0FBQTtBQUN0QyxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSXBCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNxQixjQUFjQyxlQUFlLElBQUl0QixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDdUIsaUJBQWlCQyxrQkFBa0IsSUFBSXhCLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUN5Qix3QkFBd0JDLHlCQUF5QixJQUFJMUIsU0FBUyxFQUFFO0FBQ3ZFLFFBQU0sQ0FBQzJCLGVBQWVDLGdCQUFnQixJQUFJNUIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzZCLGlCQUFpQkMsa0JBQWtCLElBQUk5QixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDK0IsV0FBV0MsWUFBWSxJQUFJaEMsU0FBUyxDQUFDLENBQUM7QUFDN0MsUUFBTSxDQUFDaUMsV0FBV0MsWUFBWSxJQUFJbEMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ21DLGlCQUFpQkMsa0JBQWtCLElBQUlwQyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDcUMsY0FBY0MsZUFBZSxJQUFJdEMsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ3VDLGlCQUFpQkMsa0JBQWtCLElBQUl4QyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDeUMsb0JBQW9CQyxxQkFBcUIsSUFBSTFDLFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUMyQyxpQkFBaUJDLGtCQUFrQixJQUFJNUMsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzZDLFdBQVdDLFlBQVksSUFBSTlDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUMrQyxhQUFhQyxjQUFjLElBQUloRCxTQUFTLE1BQU07QUFDckQsUUFBTSxDQUFDaUQsWUFBWUMsYUFBYSxJQUFJbEQsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ21ELFdBQVdDLFlBQVksSUFBSXBELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNxRCxpQkFBaUJDLGtCQUFrQixJQUFJdEQsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3VELGVBQWVDLGdCQUFnQixJQUFJeEQsU0FBUyxPQUFPO0FBRTFELFFBQU15RCxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFFBQU1DLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6Q1Ysa0JBQWNVLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxFQUM5QjtBQUNBLFFBQU1DLGNBQWNOLElBQUlPLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNsRCxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUluRSxTQUFTK0QsV0FBVztBQUNwRSxRQUFNLENBQUNLLGNBQWNDLGVBQWUsSUFBSXJFLFNBQVMrRCxXQUFXO0FBQzVELFFBQU0sQ0FBQ08scUJBQXFCQyxzQkFBc0IsSUFBSXZFLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUN3RSxpQkFBaUJDLGtCQUFrQixJQUFJekUsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQzBFLHFCQUFxQkMsc0JBQXNCLElBQUkzRSxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDNEUsbUJBQW1CQyxvQkFBb0IsSUFBSTdFLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUM4RSw2QkFBNkJDLDhCQUE4QixJQUFJL0UsU0FBUyxFQUFFO0FBQ2pGLFFBQU0sQ0FBQ2dGLFVBQVVDLFdBQVcsSUFBSWpGLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNrRixxQkFBcUJDLHNCQUFzQixJQUFJbkYsU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQ29GLFdBQVdDLFlBQVksSUFBSXJGLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNzRixVQUFVQyxXQUFXLElBQUl2RixTQUFTO0FBQUEsSUFDdkN3RixVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLFFBQVE7QUFBQSxJQUNSQyxZQUFZO0FBQUEsSUFDWkMsVUFBVTtBQUFBLElBQ1ZDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLHNCQUFzQjtBQUFBLEVBQ3hCLENBQUM7QUFDRCxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSWxHLFNBQVM7QUFBQSxJQUM3Q21HLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU1DLG1CQUFtQkEsTUFBTTFELG1CQUFtQixLQUFLO0FBRXZEN0MsWUFBVSxNQUFNO0FBQ2QsVUFBTXdHLE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBRS9CLFFBQ0VHLFdBQ0FBLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxjQUNuRDtBQUNBLFlBQU1DLG9CQUNKTixRQUFRRyx1QkFBdUJDLG9CQUFvQkMsaUJBQ2pELFNBQ0UsT0FDQTtBQUNONUIsNkJBQXVCNkIsaUJBQWlCO0FBQUEsSUFDMUM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMakgsWUFBVSxNQUFNO0FBQ2QsVUFBTXdHLE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBRS9CLFFBQ0VHLFdBQ0FBLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxjQUNuRDtBQUNBLFlBQU1FLFdBQ0pQLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxpQkFDakQsU0FDRSxPQUNBO0FBQ050Qyx5QkFBbUJ3QyxRQUFRO0FBQUEsSUFDN0I7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUNMbEgsWUFBVSxNQUFNO0FBQ2QsS0FBQyxZQUFZO0FBQ1gsVUFBSTtBQUNGLGNBQU0sQ0FBQ21ILE1BQU0sSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxVQUFJO0FBQUEsWUFDakNuSCxJQUFJb0gsSUFBSSw2QkFBNkI7QUFBQSxVQUFDO0FBQUEsUUFFdkM7QUFDRCxjQUFNQyxPQUFPSixRQUFRSyxNQUFNQyxvQkFBb0JDLElBQUksQ0FBQ0MsU0FBUztBQUFBLFVBQzNEQyxLQUFLRCxLQUFLQyxLQUFLQTtBQUFBQSxVQUNmQyxXQUFXRixLQUFLQyxLQUFLRTtBQUFBQSxVQUNyQkMsY0FBY0osS0FBS0MsS0FBS0c7QUFBQUEsVUFDeEJDLGVBQWU7QUFBQSxRQUNqQixFQUFFO0FBQ0YxQyxxQkFBYWlDLElBQUk7QUFBQSxNQUVuQixTQUFTVSxPQUFPO0FBRWQzQyxxQkFBYSxFQUFFO0FBQUEsTUFDakI7QUFBQSxJQUNGLEdBQUc7QUFBQSxFQUNMLEdBQUcsRUFBRTtBQUNMdEYsWUFBVSxNQUFNO0FBQ2QsVUFBTWtJLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNakksSUFBSW9ILElBQUksd0JBQXdCO0FBQ3ZEakcsa0JBQVU4RyxTQUFTWCxJQUFJO0FBQUEsTUFDekIsU0FBU1MsT0FBTztBQUNkRyxnQkFBUUgsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUMsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMbEksWUFBVSxNQUFNO0FBQ2QsVUFBTXFJLGVBQWUsWUFBWTtBQUMvQixVQUFJO0FBQ0YsY0FBTUYsV0FBVyxNQUFNakksSUFBSW9ILElBQUksNkJBQTZCO0FBQzVEdkUscUJBQWFvRixTQUFTWCxJQUFJO0FBQUEsTUFDNUIsU0FBU1MsT0FBTztBQUNkRyxnQkFBUUgsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFDQUksaUJBQWE7QUFBQSxFQUNmLEdBQUcsRUFBRTtBQUVMckksWUFBVSxNQUFNO0FBQ2QsVUFBTWtJLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNakksSUFBSW9ILElBQUksZ0JBQWdCO0FBQy9DekYseUJBQWlCc0csU0FBU1gsSUFBSTtBQUFBLE1BQ2hDLFNBQVNTLE9BQU87QUFDZEcsZ0JBQVFILE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FDLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFFTGxJLFlBQVUsTUFBTTtBQUNkLFFBQUk4QyxXQUFXO0FBQ2IwQyxrQkFBWSxDQUFDOEMsY0FBYztBQUFBLFFBQ3pCLEdBQUdBO0FBQUFBLFFBQ0gxQyxZQUFZOUMsVUFBVThDO0FBQUFBLE1BQ3hCLEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRixHQUFHLENBQUM5QyxTQUFTLENBQUM7QUFFZCxRQUFNeUYsZUFBZUEsQ0FBQzFFLE1BQU07QUFDMUIsVUFBTSxFQUFFaUUsTUFBTS9ELE1BQU0sSUFBSUYsRUFBRUM7QUFDMUIwQixnQkFBWSxDQUFDOEMsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ1IsSUFBSSxHQUFHL0Q7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU15RSxtQkFBbUJBLENBQUMzRSxNQUFNO0FBQzlCLFVBQU0sRUFBRWlFLE1BQU0vRCxNQUFNLElBQUlGLEVBQUVDO0FBQzFCLFVBQU0sQ0FBQzRCLFNBQVNDLE1BQU0sSUFBSTVCLE1BQU1HLE1BQU0sR0FBRztBQUN6Q3NCLGdCQUFZLENBQUM4QyxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSDVDO0FBQUFBLE1BQ0FDO0FBQUFBLElBQ0YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNOEMsY0FBYyxPQUFPQyxVQUFVO0FBQ25DLFVBQU1DLFVBQVVELE1BQU01RSxPQUFPQztBQUM3QnRDLHVCQUFtQmtILE9BQU87QUFDMUJuRCxnQkFBWSxDQUFDb0Qsa0JBQWtCO0FBQUEsTUFDN0IsR0FBR0E7QUFBQUEsTUFDSG5ELFVBQVVrRDtBQUFBQSxJQUNaLEVBQUU7QUFFRkUsc0JBQWtCRixPQUFPO0FBRXpCLFFBQUlBLFNBQVM7QUFDWCxVQUFJO0FBQ0YsY0FBTVIsV0FBVyxNQUFNakksSUFBSW9ILElBQUksMEJBQTBCcUIsT0FBTyxFQUFFO0FBQ2xFMUcscUJBQWFrRyxTQUFTWCxRQUFRLENBQUMsQ0FBQztBQUFBLE1BQ2xDLFNBQVNTLE9BQU87QUFDZEcsZ0JBQVFILE1BQU0sOEJBQThCQSxLQUFLO0FBQ2pEaEcscUJBQWEsQ0FBQyxDQUFDO0FBQUEsTUFDakI7QUFBQSxJQUNGLE9BQU87QUFDTEEsbUJBQWEsQ0FBQyxDQUFDO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTTZHLGVBQWU7QUFBQSxJQUNuQixFQUFFL0UsT0FBTyxTQUFTZ0YsT0FBTyxRQUFRO0FBQUEsSUFDakMsRUFBRWhGLE9BQU8sYUFBYWdGLE9BQU8sWUFBWTtBQUFBLElBQ3pDLEVBQUVoRixPQUFPLGFBQWFnRixPQUFPLGFBQWE7QUFBQSxJQUMxQyxFQUFFaEYsT0FBTyxhQUFhZ0YsT0FBTyxhQUFhO0FBQUEsSUFDMUMsRUFBRWhGLE9BQU8sWUFBWWdGLE9BQU8sWUFBWTtBQUFBLElBQ3hDLEVBQUVoRixPQUFPLFVBQVVnRixPQUFPLFNBQVM7QUFBQSxFQUFDO0FBR3RDLFFBQU1DLHFCQUFxQixPQUFPTCxZQUFZO0FBQzVDaEgsOEJBQTBCZ0gsT0FBTztBQUFBLEVBQ25DO0FBRUEsUUFBTU0scUJBQXFCQSxDQUFDbEYsVUFBVTtBQUNwQ04scUJBQWlCTSxLQUFLO0FBQ3RCUix1QkFBbUIsS0FBSztBQUV4QixVQUFNMkYsUUFBUSxvQkFBSXZGLEtBQUs7QUFDdkIsVUFBTXdGLGFBQWFBLENBQUNDLFNBQVNBLEtBQUtDLG1CQUFtQixPQUFPO0FBRTVELFFBQUl0RixVQUFVLFNBQVM7QUFDckIsWUFBTXVGLFlBQVlILFdBQVdELEtBQUs7QUFDbEM5RSwwQkFBb0JrRixTQUFTO0FBQzdCaEYsc0JBQWdCZ0YsU0FBUztBQUFBLElBQzNCLFdBQVd2RixVQUFVLGFBQWE7QUFDaEMsWUFBTXdGLFlBQVksSUFBSTVGLEtBQUt1RixLQUFLO0FBQ2hDSyxnQkFBVUMsUUFBUUQsVUFBVUUsUUFBUSxJQUFJLENBQUM7QUFDekMsWUFBTUgsWUFBWUgsV0FBV0ksU0FBUztBQUN0Q25GLDBCQUFvQmtGLFNBQVM7QUFDN0JoRixzQkFBZ0JnRixTQUFTO0FBQUEsSUFDM0IsV0FBV3ZGLFVBQVUsYUFBYTtBQUNoQyxZQUFNMkYsUUFBUSxJQUFJL0YsS0FBS3VGLE1BQU1TLFlBQVksR0FBR1QsTUFBTVUsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTUMsTUFBTSxJQUFJbEcsS0FBS3VGLE1BQU1TLFlBQVksR0FBR1QsTUFBTVUsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNqRXhGLDBCQUFvQitFLFdBQVdPLEtBQUssQ0FBQztBQUNyQ3BGLHNCQUFnQjZFLFdBQVdVLEdBQUcsQ0FBQztBQUFBLElBQ2pDLFdBQVc5RixVQUFVLGFBQWE7QUFDaEMsWUFBTTJGLFFBQVEsSUFBSS9GLEtBQUt1RixNQUFNUyxZQUFZLEdBQUdULE1BQU1VLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbkUsWUFBTUMsTUFBTSxJQUFJbEcsS0FBS3VGLE1BQU1TLFlBQVksR0FBR1QsTUFBTVUsU0FBUyxHQUFHLENBQUM7QUFDN0R4RiwwQkFBb0IrRSxXQUFXTyxLQUFLLENBQUM7QUFDckNwRixzQkFBZ0I2RSxXQUFXVSxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXOUYsVUFBVSxZQUFZO0FBQy9CLFlBQU0yRixRQUFRLElBQUkvRixLQUFLdUYsTUFBTVMsWUFBWSxHQUFHLEdBQUcsQ0FBQztBQUNoRCxZQUFNRSxNQUFNLElBQUlsRyxLQUFLdUYsTUFBTVMsWUFBWSxHQUFHLElBQUksRUFBRTtBQUNoRHZGLDBCQUFvQitFLFdBQVdPLEtBQUssQ0FBQztBQUNyQ3BGLHNCQUFnQjZFLFdBQVdVLEdBQUcsQ0FBQztBQUFBLElBQ2pDLFdBQVc5RixVQUFVLFVBQVU7QUFDN0JSLHlCQUFtQixJQUFJO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBRUEsUUFBTXVHLGdCQUFnQkEsQ0FBQ0MsZUFBZTtBQUNwQyxVQUFNWCxPQUFPLElBQUl6RixLQUFLb0csVUFBVTtBQUNoQyxVQUFNQyxVQUFVLEVBQUVDLEtBQUssV0FBV0MsT0FBTyxRQUFRQyxNQUFNLFVBQVU7QUFDakUsV0FBT2YsS0FBS0MsbUJBQW1CLFNBQVNXLE9BQU8sRUFBRUksUUFBUSxLQUFLLEVBQUU7QUFBQSxFQUNsRTtBQUVBcEs7QUFBQUEsSUFBVSxNQUFNO0FBQ2QsWUFBTXFLLGtCQUFrQixJQUFJQyxnQkFBZ0I7QUFDNUMsWUFBTUMsZ0JBQWdCLFlBQVk7QUFDaEMsWUFBSTtBQUNGbEgsdUJBQWEsSUFBSTtBQUNqQixnQkFBTThFLFdBQVcsTUFBTWpJLElBQUlvSCxJQUFJLDhCQUE4QjtBQUFBLFlBQzNEa0QsUUFBUTtBQUFBLGNBQ05DLFdBQVd0RztBQUFBQSxjQUNYdUcsU0FBU3JHO0FBQUFBLGNBQ1RzRSxTQUFTakg7QUFBQUEsY0FDVGlKLFFBQVE5RjtBQUFBQSxjQUNSa0IsVUFBVXhCO0FBQUFBLGNBQ1ZxRyxjQUFjakc7QUFBQUEsY0FDZHNCLHNCQUFzQmxCO0FBQUFBLFlBQ3hCO0FBQUEsWUFDQThGLFFBQVFSLGdCQUFnQlE7QUFBQUEsVUFDMUIsQ0FBQztBQUNEekMsa0JBQVEwQyxLQUFLM0MsU0FBU1gsTUFBTSxzQkFBc0I7QUFDbEQsY0FBSVcsU0FBU1gsUUFBUVcsU0FBU1gsS0FBS3VELFNBQVMsR0FBRztBQUM3QyxrQkFBTUMsZ0JBQWdCN0MsU0FBU1gsS0FBS3lEO0FBQUFBLGNBQ2xDLENBQUNDLFlBQVlBLFFBQVF6RixhQUFhO0FBQUEsWUFDcEM7QUFFQTFELCtCQUFtQmlKLGFBQWE7QUFFaEMsa0JBQU1HLGNBQWNILGNBQWNJO0FBQUFBLGNBQ2hDLENBQUNDLEtBQUtILFlBQVlHLE1BQU1DLE9BQU9KLFFBQVFwRixVQUFVLENBQUM7QUFBQSxjQUNsRDtBQUFBLFlBQ0Y7QUFDQXNDLG9CQUFRMEMsS0FBS0ssYUFBYSxjQUFjO0FBQ3hDakcsd0JBQVlpRyxXQUFXO0FBRXZCLGtCQUFNSSxnQkFBZ0JQLGNBQWN0RCxJQUFJLENBQUM4RCxPQUFPQyxXQUFXO0FBQUEsY0FDekQ3RCxLQUFLNEQsT0FBTzVEO0FBQUFBLGNBQ1o4RCxJQUFJRCxRQUFRO0FBQUEsY0FDWnJDLE1BQU1vQyxPQUFPM0Y7QUFBQUEsY0FDYjJGLE9BQU9BLE9BQU8vRixVQUFVa0csY0FBY0gsTUFBTUk7QUFBQUEsY0FDNUM5RCxNQUFNMEQsT0FBTzlGLFNBQVNtQztBQUFBQSxjQUN0QmdFLFVBQVVMLE9BQU9JLFdBQVc7QUFBQSxjQUM1QjdELGNBQWN5RCxPQUFPOUYsU0FBU3FDO0FBQUFBLGNBQzlCbkMsWUFBWTRGLE9BQU81RjtBQUFBQSxjQUNuQmtHLGdCQUFnQk4sT0FBT007QUFBQUEsY0FDdkJuRyxRQUFRNkYsT0FBTzdGO0FBQUFBLGNBQ2ZHLFFBQVEwRixPQUFPMUY7QUFBQUEsY0FDZmlHLGtCQUFrQlAsT0FBT1EsV0FBVzlILE1BQU0sR0FBRyxJQUFJLENBQUM7QUFBQSxjQUNsRCtILE1BQU1ULE9BQU96RjtBQUFBQSxjQUNiNkUsY0FBY1ksT0FBT1o7QUFBQUEsY0FDckJzQixjQUNFVixPQUFPVSxjQUFjcEUsUUFDckIwRCxPQUFPVyxZQUFZQyxjQUNuQjtBQUFBLGNBQ0ZDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsa0JBQ2pCLE1BQU07QUFBQSxvQkFDSkMsT0FBTztBQUFBLHNCQUNMO0FBQUEsd0JBQ0VDLEtBQUs7QUFBQSx3QkFDTHhELE9BQ0U7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsUUFBTztBQUFBLDRCQUNQLElBQUksVUFBVXlDLE1BQU01RCxHQUFHO0FBQUEsNEJBQ3ZCLFdBQVU7QUFBQSw0QkFBa0I7QUFBQTtBQUFBLDBCQUg5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBTUE7QUFBQSxzQkFFSjtBQUFBLG9CQUFDO0FBQUEsa0JBRUw7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBRVYsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUE7QUFBQSxnQkFwQmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLFlBRUosRUFBRTtBQUVGckcsNEJBQWdCZ0ssYUFBYTtBQUFBLFVBQy9CLE9BQU87QUFDTHhKLCtCQUFtQixFQUFFO0FBQUEsVUFDdkI7QUFBQSxRQUNGLFNBQVNrRyxPQUFPO0FBQ2RHLGtCQUFRSCxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRGxHLDZCQUFtQixFQUFFO0FBQ3JCbUQsc0JBQVksQ0FBQztBQUFBLFFBQ2YsVUFBQztBQUNDN0IsdUJBQWEsS0FBSztBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUVBa0gsb0JBQWM7QUFDZCxhQUFPLE1BQU07QUFDWEYsd0JBQWdCbUMsTUFBTTtBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUFBLElBQUc7QUFBQSxNQUNEOUs7QUFBQUEsTUFDQTJDO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FNO0FBQUFBLE1BQ0FWO0FBQUFBLE1BQ0FRO0FBQUFBLE1BQ0FJO0FBQUFBLElBQTJCO0FBQUEsRUFDNUI7QUFFRCxRQUFNMEgsVUFBVTtBQUFBLElBQ2QsRUFBRUYsS0FBSyxNQUFNRyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFSCxLQUFLLFFBQVFHLFFBQVEsWUFBWTtBQUFBLElBQ25DLEVBQUVILEtBQUssb0JBQW9CRyxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUVILEtBQUssU0FBU0csUUFBUSxhQUFhO0FBQUEsSUFDckMsRUFBRUgsS0FBSyxRQUFRRyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUVILEtBQUssWUFBWUcsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRUgsS0FBSyxnQkFBZ0JHLFFBQVEsd0JBQXdCO0FBQUEsSUFDdkQsRUFBRUgsS0FBSyxjQUFjRyxRQUFRLGlCQUFpQjtBQUFBLElBQzlDLEVBQUVILEtBQUssa0JBQWtCRyxRQUFRLGNBQWM7QUFBQSxJQUMvQyxFQUFFSCxLQUFLLFVBQVVHLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVILEtBQUssVUFBVUcsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUgsS0FBSyxRQUFRRyxRQUFRLGVBQWU7QUFBQSxJQUN0QyxHQUFJakksa0JBQ0EsQ0FBQyxFQUFFOEgsS0FBSyxnQkFBZ0JHLFFBQVEsZUFBZSxDQUFDLElBQ2hEO0FBQUEsSUFDSixFQUFFSCxLQUFLLGdCQUFnQkcsUUFBUSxlQUFlO0FBQUEsSUFFOUMsRUFBRUgsS0FBSyxVQUFVRyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDMU0sWUFBVSxNQUFNO0FBQ2QsUUFBSWdDLGFBQWF1RCxTQUFTb0gsWUFBWTtBQUNwQyxZQUFNQyxhQUFjNUssVUFBVTZLLGNBQWMsSUFBSyxPQUFPO0FBQ3hELFlBQU1DLGNBQ0g5SyxVQUFVNkssZUFBZSxNQUFNdEgsU0FBU29ILGNBQWM7QUFDekQsWUFBTUksWUFBWXhILFNBQVNvSCxjQUFjLEtBQUtDO0FBQzlDLFlBQU1JLGdCQUFnQmhMLFVBQVVpTCxnQkFDNUJGLFdBQVcvSyxVQUFVaUwsZ0JBQ3JCO0FBQ0osWUFBTUMsV0FBV2xMLFVBQVVtTCxpQkFBaUIsS0FBS0g7QUFFakR4SCxrQkFBWSxDQUFDOEMsY0FBYztBQUFBLFFBQ3pCLEdBQUdBO0FBQUFBLFFBQ0g3QyxVQUFVekQsVUFBVTRGO0FBQUFBLFFBQ3BCZ0Y7QUFBQUEsUUFDQUU7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUU7QUFBQUEsTUFDRixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0YsR0FBRyxDQUFDbEwsV0FBV3VELFNBQVNvSCxVQUFVLENBQUM7QUFFbkMsUUFBTVMsMEJBQTBCQSxDQUFDdkosTUFBTTtBQUNyQyxVQUFNd0osZUFBZXhKLEVBQUVDLE9BQU9DO0FBQzlCZCxtQkFBZW9LLFlBQVk7QUFDM0I3SCxnQkFBWSxDQUFDOEMsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0h2QyxVQUFVc0g7QUFBQUEsTUFDVnJILGdCQUFnQnFILGlCQUFpQixXQUFXL0UsU0FBU3RDLGlCQUFpQjtBQUFBLElBQ3hFLEVBQUU7QUFBQSxFQUNKO0FBZUEsUUFBTXNILHdCQUF3QixPQUFPM0UsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTVIsV0FBVyxNQUFNakksSUFBSW9ILElBQUksOEJBQThCcUIsT0FBTyxFQUFFO0FBQ3RFcEcsc0JBQWdCNEYsU0FBU1gsSUFBSTtBQUM3Qm5GLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBUzRGLE9BQU87QUFDZEcsY0FBUUgsTUFBTSwwQkFBMEJBLEtBQUs7QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxRQUFNc0Ysc0JBQXNCLFlBQVk7QUFDdEMsUUFBSWpMLGNBQWM7QUFDaEIsVUFBSTtBQUNGLGNBQU1wQyxJQUFJc04sT0FBTywyQkFBMkJsTCxhQUFhc0YsR0FBRyxFQUFFO0FBQzlENkYsY0FBTSw4QkFBOEI7QUFDcENwTCwyQkFBbUIsS0FBSztBQUN4QkUsd0JBQWdCLElBQUk7QUFDcEJtTCxlQUFPQyxTQUFTQyxPQUFPO0FBQUEsTUFDekIsU0FBUzNGLE9BQU87QUFDZEcsZ0JBQVFILE1BQU0sMkJBQTJCQSxLQUFLO0FBQUEsTUFDaEQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU00Rix3QkFBd0IsT0FBT2xGLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1SLFdBQVcsTUFBTWpJLElBQUlvSCxJQUFJLDhCQUE4QnFCLE9BQU8sRUFBRTtBQUN0RWhHLDRCQUFzQndGLFNBQVNYLElBQUk7QUFDbkMvRSx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVN3RixPQUFPO0FBQ2RHLGNBQVFILE1BQU0sMkJBQTJCQSxLQUFLO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBRUEsUUFBTTZGLG1CQUFtQixPQUFPakssTUFBTTtBQUNwQ0EsTUFBRWtLLGVBQWU7QUFFakIsVUFBTUMsWUFBWSxJQUFJQyxTQUFTO0FBQy9CLFVBQU1DLFlBQVlySyxFQUFFQyxPQUFPcUs7QUFDM0IsUUFBSUQsYUFBYUEsVUFBVUUsTUFBTSxDQUFDLEdBQUc7QUFDbkNKLGdCQUFVSyxPQUFPLFFBQVFILFVBQVVFLE1BQU0sQ0FBQyxDQUFDO0FBRTNDLFVBQUk7QUFDRixjQUFNakcsV0FBVyxNQUFNakksSUFBSW9PLEtBQUssMEJBQTBCTixXQUFXO0FBQUEsVUFDbkVPLFNBQVMsRUFBRSxnQkFBZ0Isc0JBQXNCO0FBQUEsUUFDbkQsQ0FBQztBQUVELFlBQUlwRyxTQUFTcUcsV0FBVyxLQUFLO0FBQzNCZixnQkFBTSw2QkFBNkI7QUFDbkNDLGlCQUFPQyxTQUFTQyxPQUFPO0FBQ3ZCL0ssNkJBQW1CLEtBQUs7QUFBQSxRQUMxQjtBQUFBLE1BQ0YsU0FBU29GLE9BQU87QUFDZEcsZ0JBQVFILE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDd0YsY0FBTSx3QkFBd0I7QUFBQSxNQUNoQztBQUFBLElBQ0YsT0FBTztBQUNMQSxZQUFNLGlDQUFpQztBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUVBLFNBQ0UsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLHdDQUNiLGlDQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTXZILFlBQVlJO0FBQUFBLFFBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBO0FBQUFBLE1BSHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUcrQjtBQUFBLElBRS9CLHVCQUFDLFNBQUksV0FBVSx3QkFFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSx5Q0FBd0MsMkNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLHlCQUF3Qix3RUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLGlDQUFDLFlBQVMsV0FBVSxtQkFBa0IsTUFBTSxNQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQztBQUFBLFVBQy9DLHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsdUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJEO0FBQUEsYUFGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsdUVBRWI7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUNmO0FBQUEscUNBQUMsY0FBVyxXQUFVLGlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQztBQUFBLGNBQUc7QUFBQSxpQkFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLHVCQUF1QjtBQUFBLGdCQUN2QixVQUFVNEM7QUFBQUEsZ0JBQ1YsT0FBT3pGO0FBQUFBLGdCQUNQLGFBQVk7QUFBQSxnQkFDWixjQUFjLENBQUNpTCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxXQUFVO0FBQUEsZ0JBQ1YsTUFBSztBQUFBLGdCQUVKL0YsdUJBQWFwQjtBQUFBQSxrQkFBSSxDQUFDcUgsU0FDakIsdUJBQUMsT0FBTyxRQUFQLEVBQStCLE9BQU9BLEtBQUtoTCxPQUN6Q2dMLGVBQUtoRyxTQURZZ0csS0FBS2hMLE9BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLG9DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLE9BQU9nQiwrQkFBK0I7QUFBQSxnQkFDdEMsY0FBYyxDQUFDMEosT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsYUFBWTtBQUFBLGdCQUNaLFVBQVUsQ0FBQ2xHLFlBQVkzRCwrQkFBK0IyRCxPQUFPO0FBQUEsZ0JBQzdELFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBR0p0RCxvQkFBVXFDO0FBQUFBLGtCQUFJLENBQUM4RCxVQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUErQixPQUFPQSxPQUFPNUQsS0FDM0M0RDtBQUFBQSwyQkFBTzNEO0FBQUFBLG9CQUFVO0FBQUEsb0JBQUkyRCxNQUFNekQ7QUFBQUEsdUJBRFZ5RCxPQUFPNUQsS0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFxQkE7QUFBQSxlQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLFVBR0N0RSxtQkFDQyxtQ0FDRTtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHlCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2E7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDTixNQUFNTyxvQkFBb0JQLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxrQkFDbkQsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXdJO0FBQUEsaUJBUjFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT007QUFBQUEsa0JBQ1AsVUFBVSxDQUFDUixNQUFNUyxnQkFBZ0JULEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxrQkFDL0MsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXdJO0FBQUEsaUJBUjFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLFVBSUYsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFDZjtBQUFBLHFDQUFDLFdBQVEsV0FBVSxpQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUFHO0FBQUEsaUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSx1QkFBdUI7QUFBQSxnQkFDdkIsT0FBT3JDO0FBQUFBLGdCQUNQLFVBQVVzSDtBQUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osY0FBYyxDQUFDeUYsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFFTDtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU8sSUFBSSxtQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQSxrQkFDNUJ6TixPQUFPc0c7QUFBQUEsb0JBQUksQ0FBQzhELFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU01RCxLQUN6QzRELGdCQUFNRyxjQURXSCxNQUFNNUQsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXFCQTtBQUFBLGVBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkJBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyx3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLHVCQUF1QjtBQUFBLGdCQUN2QixPQUFPL0M7QUFBQUEsZ0JBQ1AsY0FBYyxDQUFDNEosT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsYUFBWTtBQUFBLGdCQUNaLFVBQVUsQ0FBQ2xHLFlBQVk3RCxxQkFBcUI2RCxPQUFPO0FBQUEsZ0JBQ25ELFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBRUw7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCO0FBQUEsa0JBQzFCL0csY0FBYzhGO0FBQUFBLG9CQUFJLENBQUM4RCxVQUNsQix1QkFBQyxPQUFPLFFBQVAsRUFBK0IsT0FBT0EsT0FBTzVELEtBQzNDNEQ7QUFBQUEsNkJBQU8zRDtBQUFBQSxzQkFBVTtBQUFBLHNCQUFJMkQsTUFBTXpEO0FBQUFBLHlCQURWeUQsT0FBTzVELEtBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFxQkE7QUFBQSxlQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFDZjtBQUFBLHFDQUFDLGdCQUFhLFdBQVUsaUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUEsY0FBRztBQUFBLGlCQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9yRDtBQUFBQSxnQkFDUDtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWix1QkFBdUI7QUFBQSxnQkFDdkIsVUFBVSxDQUFDb0UsWUFBWW5FLHVCQUF1Qm1FLE9BQU87QUFBQSxnQkFDckQsY0FBYyxDQUFDOEYsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFFTDtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQSxrQkFDM0IsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxRQUFPLG9CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLGtCQUNoQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUE7QUFBQTtBQUFBLGNBakJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFrQkE7QUFBQSxlQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLFVBR0MxSix1QkFDQyx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPUjtBQUFBQSxnQkFDUDtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWix1QkFBdUI7QUFBQSxnQkFDdkIsVUFBVSxDQUFDZ0UsWUFBWS9ELHVCQUF1QitELE9BQU87QUFBQSxnQkFDckQsY0FBYyxDQUFDOEYsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFFTDtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQSxrQkFDM0IsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxZQUFXLHdCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3QztBQUFBLGtCQUN4Qyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUEsa0JBQ3BDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sY0FBYSwwQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFBUyxzQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0M7QUFBQTtBQUFBO0FBQUEsY0FyQnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXNCQTtBQUFBLGVBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkJBO0FBQUEsYUF2TUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlNQTtBQUFBLFdBL01GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnTkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw2SUFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsaUJBRWI7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsc0VBQXFFLDRCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHQSx1QkFBQyxPQUFFLFdBQVUsaURBQWdEO0FBQUE7QUFBQSxZQUN6RDVKLFlBQVk7QUFBQSxlQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHQSx1QkFBQyxPQUFFLFdBQVUsd0RBQ1ZoRSw4QkFBb0JnRSxZQUFZLENBQUMsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBR0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsYUFDekIsb0JBQUl0QixLQUFLLEdBQUUwRixtQkFBbUI7QUFBQSxlQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBSUEsdUJBQUMsU0FBSSxXQUFVLGNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFdBekI1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBLEtBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxNQUdDdkgsbUJBQW1CQSxnQkFBZ0JpSixTQUFTLEtBQUssQ0FBQzNILFlBQ2pELHVCQUFDLFNBQ0M7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTTFDLGFBQWFZLGNBQWM0QixVQUFVO0FBQUEsWUFDM0M7QUFBQSxZQUNBLGlCQUFpQjtBQUFBLFlBQ2pCLGtCQUFrQjtBQUFBO0FBQUEsVUFKcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXNEO0FBQUEsUUFFdEQsdUJBQUMsU0FBSSxXQUFVLDREQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLFlBQzlDK0I7QUFBQUEsZUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsU0FBU25ELGdCQUFnQmlKLFVBQVU7QUFBQSxVQUNuQyxNQUFLO0FBQUE7QUFBQSxRQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUd5QyxLQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQXZSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeVJBO0FBQUEsSUF5SkE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVd2STtBQUFBQSxRQUNYLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxRQUV2QyxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVLE1BQU07QUFBQSxVQUFFLEdBQzVDO0FBQUEsbUNBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLGdCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPQyxvQkFBb0IrQyxVQUFVa0c7QUFBQUEsa0JBQ3JDLFVBQVUsTUFBTTtBQUFBLGtCQUFFO0FBQUEsa0JBQ2xCLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRMkk7QUFBQSxpQkFmN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBYTtBQUFBO0FBQUEsa0JBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT2pKLG9CQUFvQitDLFVBQVVvSDtBQUFBQSxvQkFDckMsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBZTtBQUFBO0FBQUEsa0JBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT25LLG9CQUFvQitDLFVBQVUwSDtBQUFBQSxvQkFDckMsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxpQkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQ0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFPO0FBQUE7QUFBQSxnQkFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBTyxHQUFHekssb0JBQW9CZ0QsU0FBU21DLFNBQVMsTUFBTW5GLG9CQUFvQmlELE1BQU07QUFBQSxrQkFDaEYsVUFBVSxNQUFNO0FBQUEsa0JBQUU7QUFBQSxrQkFDbEIsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVEySTtBQUFBLGlCQWY3STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLGdCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUNFakQsb0JBQW9CK0MsVUFBVW9ILGNBQzlCbkssb0JBQW9Cb0s7QUFBQUEsa0JBRXRCLFVBQVUsTUFBTTtBQUFBLGtCQUFFO0FBQUEsa0JBQ2xCLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXMkk7QUFBQSxpQkFsQjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWE7QUFBQTtBQUFBLGtCQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9wSyxvQkFBb0JrSztBQUFBQSxvQkFDM0IsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBZTtBQUFBO0FBQUEsa0JBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT2xLLG9CQUFvQm9LO0FBQUFBLG9CQUMzQixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU8ySTtBQUFBLG1CQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGlCQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1DQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFhO0FBQUE7QUFBQSxrQkFGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPcEssb0JBQW9CcUs7QUFBQUEsb0JBQzNCLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTzJJO0FBQUEsbUJBZDdJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWU7QUFBQTtBQUFBLGtCQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9ySyxvQkFBb0JzSztBQUFBQSxvQkFDM0IsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBZTtBQUFBO0FBQUEsa0JBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3RLLG9CQUFvQndLO0FBQUFBLG9CQUMzQixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU8ySTtBQUFBLG1CQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGlCQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9EQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPeEssb0JBQW9Cc007QUFBQUEsb0JBQzNCLFVBQVUsTUFBTTtBQUFBLG9CQUFFO0FBQUEsb0JBQ2xCLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTJJO0FBQUEsbUJBZjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLGtCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU90TSxvQkFBb0J1TTtBQUFBQSxvQkFDM0IsVUFBVSxNQUFNO0FBQUEsb0JBQUU7QUFBQSxvQkFDbEIsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRMkk7QUFBQSxtQkFmN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQ0E7QUFBQSxlQTdORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThOQTtBQUFBLGFBbE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtT0E7QUFBQTtBQUFBLE1Bdk9GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXdPQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVc3TTtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkUsMEJBQWdCLElBQUk7QUFBQSxRQUN0QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxrREFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NELGdCQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUN1QixNQUFNO0FBQ2ZBLGtCQUFFa0ssZUFBZTtBQUNqQlIsb0NBQW9CO0FBQUEsY0FDdEI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ21HO0FBQUE7QUFBQSxnQkFIL0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQTtBQUFBLFlBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0E7QUFBQSxhQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUE7QUFBQSxNQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUE2QkE7QUFBQSxPQWxzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1zQkEsS0Fwc0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0Fxc0JBLEtBdHNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdXNCQTtBQUVKO0FBQUVwTSxHQTlxQ0lELDJCQUF5QjtBQUFBZ08sS0FBekJoTztBQWdyQ04sZUFBZUE7QUFBMEIsSUFBQWdPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImFwaSIsIk1vZGFsIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkNpcmN1bGFyTG9hZGVyIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiSW9NZE1vcmUiLCJMaW5rIiwiRmlGaWx0ZXIiLCJGaUNhbGVuZGFyIiwiRmlVc2VycyIsIkZpQ3JlZGl0Q2FyZCIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJDb2xsZWN0aW9uRXhlY3V0aXZlUmVwb3J0IiwiX3MiLCJncm91cHMiLCJzZXRHcm91cHMiLCJUYWJsZURheWJvb2siLCJzZXRUYWJsZURheWJvb2siLCJzZWxlY3RlZEdyb3VwSWQiLCJzZXRTZWxlY3RlZEdyb3VwSWQiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWRBdWN0aW9uIiwic2V0RmlsdGVyZWRBdWN0aW9uIiwiZ3JvdXBJbmZvIiwic2V0R3JvdXBJbmZvIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwiY3VycmVudEdyb3VwIiwic2V0Q3VycmVudEdyb3VwIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudFVwZGF0ZUdyb3VwIiwic2V0Q3VycmVudFVwZGF0ZUdyb3VwIiwic2hvd1VwbG9hZE1vZGFsIiwic2V0U2hvd1VwbG9hZE1vZGFsIiwicmVjZWlwdE5vIiwic2V0UmVjZWlwdE5vIiwicGF5bWVudE1vZGUiLCJzZXRQYXltZW50TW9kZSIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwic2VsZWN0ZWRMYWJlbCIsInNldFNlbGVjdGVkTGFiZWwiLCJub3ciLCJEYXRlIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsInZhbHVlIiwidG9kYXlTdHJpbmciLCJ0b0lTT1N0cmluZyIsInNwbGl0Iiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJzZWxlY3RlZFBheW1lbnRNb2RlIiwic2V0U2VsZWN0ZWRQYXltZW50TW9kZSIsImhpZGVBY2NvdW50VHlwZSIsInNldEhpZGVBY2NvdW50VHlwZSIsInNlbGVjdGVkQWNjb3VudFR5cGUiLCJzZXRTZWxlY3RlZEFjY291bnRUeXBlIiwic2VsZWN0ZWRDdXN0b21lcnMiLCJzZXRTZWxlY3RlZEN1c3RvbWVycyIsInNlbGVjdGVkQ29sbGVjdGlvbkV4ZWN1dGl2ZSIsInNldFNlbGVjdGVkQ29sbGVjdGlvbkV4ZWN1dGl2ZSIsInBheW1lbnRzIiwic2V0UGF5bWVudHMiLCJzaG93QWxsUGF5bWVudE1vZGVzIiwic2V0U2hvd0FsbFBheW1lbnRNb2RlcyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJncm91cF9pZCIsInVzZXJfaWQiLCJ0aWNrZXQiLCJyZWNlaXB0X25vIiwicGF5X2RhdGUiLCJhbW91bnQiLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwiY29sbGVjdGlvbl9leGVjdXRpdmUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiaGFuZGxlTW9kYWxDbG9zZSIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsImFjY2Vzc19wZXJtaXNzaW9ucyIsImVkaXRfcGF5bWVudCIsInNob3dQYXltZW50c01vZGVzIiwiaXNNb2RpZnkiLCJlbXBseXMiLCJQcm9taXNlIiwiYWxsIiwiZ2V0IiwiZW1wcyIsImRhdGEiLCJjb2xsZWN0aW9uRXhlY3V0aXZlIiwibWFwIiwiZW1wIiwiX2lkIiwiZnVsbF9uYW1lIiwibmFtZSIsInBob25lX251bWJlciIsInNlbGVjdGVkX3R5cGUiLCJlcnJvciIsImZldGNoR3JvdXBzIiwicmVzcG9uc2UiLCJjb25zb2xlIiwiZmV0Y2hSZWNlaXB0IiwicHJldkRhdGEiLCJoYW5kbGVDaGFuZ2UiLCJoYW5kbGVDaGFuZ2VVc2VyIiwiaGFuZGxlR3JvdXAiLCJldmVudCIsImdyb3VwSWQiLCJwcmV2Rm9ybURhdGEiLCJoYW5kbGVHcm91cENoYW5nZSIsImdyb3VwT3B0aW9ucyIsImxhYmVsIiwiaGFuZGxlR3JvdXBQYXltZW50IiwiaGFuZGxlU2VsZWN0RmlsdGVyIiwidG9kYXkiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImZvcm1hdHRlZCIsInllc3RlcmRheSIsInNldERhdGUiLCJnZXREYXRlIiwic3RhcnQiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZW5kIiwiZm9ybWF0UGF5RGF0ZSIsImRhdGVTdHJpbmciLCJvcHRpb25zIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwicmVwbGFjZSIsImFib3J0Q29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsImZldGNoUGF5bWVudHMiLCJwYXJhbXMiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwidXNlcklkIiwiYWNjb3VudF90eXBlIiwic2lnbmFsIiwiaW5mbyIsImxlbmd0aCIsInZhbGlkUGF5bWVudHMiLCJmaWx0ZXIiLCJwYXltZW50IiwidG90YWxBbW91bnQiLCJyZWR1Y2UiLCJzdW0iLCJOdW1iZXIiLCJmb3JtYXR0ZWREYXRhIiwiZ3JvdXAiLCJpbmRleCIsImlkIiwiZ3JvdXBfbmFtZSIsInBheV9mb3IiLCJjYXRlZ29yeSIsIm9sZF9yZWNlaXB0X25vIiwidHJhbnNhY3Rpb25fZGF0ZSIsImNyZWF0ZWRBdCIsIm1vZGUiLCJjb2xsZWN0ZWRfYnkiLCJhZG1pbl90eXBlIiwiYWRtaW5fbmFtZSIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwiYWJvcnQiLCJjb2x1bW5zIiwiaGVhZGVyIiwiYmlkX2Ftb3VudCIsImNvbW1pc3Npb24iLCJncm91cF92YWx1ZSIsIndpbl9hbW91bnQiLCJkaXZpZGVudCIsImRpdmlkZW50X2hlYWQiLCJncm91cF9tZW1iZXJzIiwicGF5YWJsZSIsImdyb3VwX2luc3RhbGwiLCJoYW5kbGVQYXltZW50TW9kZUNoYW5nZSIsInNlbGVjdGVkTW9kZSIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZUF1Y3Rpb24iLCJkZWxldGUiLCJhbGVydCIsIndpbmRvdyIsImxvY2F0aW9uIiwicmVsb2FkIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRmlsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiZm9ybURhdGFzIiwiRm9ybURhdGEiLCJmaWxlSW5wdXQiLCJmaWxlIiwiZmlsZXMiLCJhcHBlbmQiLCJwb3N0IiwiaGVhZGVycyIsInN0YXR1cyIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ0aW1lIiwiYXVjdGlvbl9kYXRlIiwibmV4dF9kYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29sbGVjdGlvbkV4ZWN1dGl2ZVJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0IGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydFwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIEZpRmlsdGVyLFxyXG4gIEZpQ2FsZW5kYXIsXHJcbiAgRmlVc2VycyxcclxuICBGaUNyZWRpdENhcmQsXHJcbn0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCJcclxuXHJcbmNvbnN0IENvbGxlY3Rpb25FeGVjdXRpdmVSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVEYXlib29rLCBzZXRUYWJsZURheWJvb2tdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwSWQsIHNldFNlbGVjdGVkR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZmlsdGVyZWRVc2Vycywgc2V0RmlsdGVyZWRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkQXVjdGlvbiwgc2V0RmlsdGVyZWRBdWN0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBJbmZvLCBzZXRHcm91cEluZm9dID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwLCBzZXRDdXJyZW50R3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dVcGxvYWRNb2RhbCwgc2V0U2hvd1VwbG9hZE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVjZWlwdE5vLCBzZXRSZWNlaXB0Tm9dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3BheW1lbnRNb2RlLCBzZXRQYXltZW50TW9kZV0gPSB1c2VTdGF0ZShcImNhc2hcIik7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiVG9kYXlcIik7XHJcblxyXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgdG9kYXlTdHJpbmcgPSBub3cudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUodG9kYXlTdHJpbmcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGF5bWVudE1vZGUsIHNldFNlbGVjdGVkUGF5bWVudE1vZGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2hpZGVBY2NvdW50VHlwZSwgc2V0SGlkZUFjY291bnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEFjY291bnRUeXBlLCBzZXRTZWxlY3RlZEFjY291bnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVycywgc2V0U2VsZWN0ZWRDdXN0b21lcnNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkQ29sbGVjdGlvbkV4ZWN1dGl2ZSwgc2V0U2VsZWN0ZWRDb2xsZWN0aW9uRXhlY3V0aXZlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXltZW50cywgc2V0UGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93QWxsUGF5bWVudE1vZGVzLCBzZXRTaG93QWxsUGF5bWVudE1vZGVzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgdGlja2V0OiBcIlwiLFxyXG4gICAgcmVjZWlwdF9ubzogXCJcIixcclxuICAgIHBheV9kYXRlOiBcIlwiLFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICBjb2xsZWN0aW9uX2V4ZWN1dGl2ZTogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IGhhbmRsZU1vZGFsQ2xvc2UgPSAoKSA9PiBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG5cclxuICAgIGlmIChcclxuICAgICAgdXNlck9iaiAmJlxyXG4gICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnRcclxuICAgICkge1xyXG4gICAgICBjb25zdCBzaG93UGF5bWVudHNNb2RlcyA9XHJcbiAgICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50ID09PVxyXG4gICAgICAgICAgXCJ0cnVlXCJcclxuICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgc2V0U2hvd0FsbFBheW1lbnRNb2RlcyhzaG93UGF5bWVudHNNb2Rlcyk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG5cclxuICAgIGlmIChcclxuICAgICAgdXNlck9iaiAmJlxyXG4gICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnRcclxuICAgICkge1xyXG4gICAgICBjb25zdCBpc01vZGlmeSA9XHJcbiAgICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50ID09PVxyXG4gICAgICAgICAgXCJ0cnVlXCJcclxuICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgc2V0SGlkZUFjY291bnRUeXBlKGlzTW9kaWZ5KTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIChhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgW2VtcGx5c10gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL2FnZW50L2NvbGxlY3Rpb24tZXhlY3V0aXZlXCIpLFxyXG5cclxuICAgICAgICBdKTtcclxuICAgICAgICBjb25zdCBlbXBzID0gZW1wbHlzPy5kYXRhPy5jb2xsZWN0aW9uRXhlY3V0aXZlLm1hcCgoZW1wKSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBlbXA/Ll9pZD8uX2lkLFxyXG4gICAgICAgICAgZnVsbF9uYW1lOiBlbXA/Ll9pZD8ubmFtZSxcclxuICAgICAgICAgIHBob25lX251bWJlcjogZW1wPy5faWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgIHNlbGVjdGVkX3R5cGU6IFwiYWdlbnRfdHlwZVwiLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRFbXBsb3llZXMoZW1wcyk7XHJcblxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG5cclxuICAgICAgICBzZXRFbXBsb3llZXMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9KSgpO1xyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuICAgICAgICBzZXRHcm91cHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hSZWNlaXB0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9wYXltZW50L2dldC1sYXRlc3QtcmVjZWlwdFwiKTtcclxuICAgICAgICBzZXRSZWNlaXB0Tm8ocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHJlY2VpcHQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hSZWNlaXB0KCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocmVjZWlwdE5vKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICByZWNlaXB0X25vOiByZWNlaXB0Tm8ucmVjZWlwdF9ubyxcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtyZWNlaXB0Tm9dKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2VVc2VyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgY29uc3QgW3VzZXJfaWQsIHRpY2tldF0gPSB2YWx1ZS5zcGxpdChcIi1cIik7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICB1c2VyX2lkLFxyXG4gICAgICB0aWNrZXQsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXAgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGNvbnN0IGdyb3VwSWQgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkZvcm1EYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2Rm9ybURhdGEsXHJcbiAgICAgIGdyb3VwX2lkOiBncm91cElkLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIGhhbmRsZUdyb3VwQ2hhbmdlKGdyb3VwSWQpO1xyXG5cclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZ3JvdXAvZ2V0LWJ5LWlkLWdyb3VwLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgICBzZXRHcm91cEluZm8ocmVzcG9uc2UuZGF0YSB8fCB7fSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIHsgdmFsdWU6IFwiVG9kYXlcIiwgbGFiZWw6IFwiVG9kYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwUGF5bWVudCA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkKGdyb3VwSWQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcbiAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0dGVkKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuICAgICAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4gICAgICB5ZXN0ZXJkYXkuc2V0RGF0ZSh5ZXN0ZXJkYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUoeWVzdGVyZGF5KTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0dGVkKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuICAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKHRydWUpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdFBheURhdGUgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgY29uc3Qgb3B0aW9ucyA9IHsgZGF5OiBcIm51bWVyaWNcIiwgbW9udGg6IFwibG9uZ1wiLCB5ZWFyOiBcIm51bWVyaWNcIiB9O1xyXG4gICAgcmV0dXJuIGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tVVNcIiwgb3B0aW9ucykucmVwbGFjZShcIixcIiwgXCJcIik7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcclxuICAgIGNvbnN0IGZldGNoUGF5bWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvY29sbGVjdGlvbi9yZXBvcnRgLCB7XHJcbiAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgZnJvbV9kYXRlOiBzZWxlY3RlZEZyb21EYXRlLFxyXG4gICAgICAgICAgICB0b19kYXRlOiBzZWxlY3RlZERhdGUsXHJcbiAgICAgICAgICAgIGdyb3VwSWQ6IHNlbGVjdGVkQXVjdGlvbkdyb3VwSWQsXHJcbiAgICAgICAgICAgIHVzZXJJZDogc2VsZWN0ZWRDdXN0b21lcnMsXHJcbiAgICAgICAgICAgIHBheV90eXBlOiBzZWxlY3RlZFBheW1lbnRNb2RlLFxyXG4gICAgICAgICAgICBhY2NvdW50X3R5cGU6IHNlbGVjdGVkQWNjb3VudFR5cGUsXHJcbiAgICAgICAgICAgIGNvbGxlY3Rpb25fZXhlY3V0aXZlOiBzZWxlY3RlZENvbGxlY3Rpb25FeGVjdXRpdmVcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWwsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlLmRhdGEsIFwidGVzdGluZyBhY2NvdW50IHR5cGVcIik7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCB2YWxpZFBheW1lbnRzID0gcmVzcG9uc2UuZGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgIChwYXltZW50KSA9PiBwYXltZW50Lmdyb3VwX2lkICE9PSBudWxsXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbih2YWxpZFBheW1lbnRzKTtcclxuXHJcbiAgICAgICAgICBjb25zdCB0b3RhbEFtb3VudCA9IHZhbGlkUGF5bWVudHMucmVkdWNlKFxyXG4gICAgICAgICAgICAoc3VtLCBwYXltZW50KSA9PiBzdW0gKyBOdW1iZXIocGF5bWVudC5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgIDBcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBjb25zb2xlLmluZm8odG90YWxBbW91bnQsIFwiY2hlY2sgYW1vdW50XCIpO1xyXG4gICAgICAgICAgc2V0UGF5bWVudHModG90YWxBbW91bnQpO1xyXG5cclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSB2YWxpZFBheW1lbnRzLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICBfaWQ6IGdyb3VwPy5faWQsXHJcbiAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIGRhdGU6IGdyb3VwPy5wYXlfZGF0ZSxcclxuICAgICAgICAgICAgZ3JvdXA6IGdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBncm91cC5wYXlfZm9yLFxyXG4gICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICBjYXRlZ29yeTogZ3JvdXA/LnBheV9mb3IgfHwgXCJDaGl0XCIsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgcmVjZWlwdF9ubzogZ3JvdXA/LnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgIG9sZF9yZWNlaXB0X25vOiBncm91cD8ub2xkX3JlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgIHRpY2tldDogZ3JvdXA/LnRpY2tldCxcclxuICAgICAgICAgICAgYW1vdW50OiBncm91cD8uYW1vdW50LFxyXG4gICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBncm91cD8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIik/LlswXSxcclxuICAgICAgICAgICAgbW9kZTogZ3JvdXA/LnBheV90eXBlLFxyXG4gICAgICAgICAgICBhY2NvdW50X3R5cGU6IGdyb3VwPy5hY2NvdW50X3R5cGUsXHJcbiAgICAgICAgICAgIGNvbGxlY3RlZF9ieTpcclxuICAgICAgICAgICAgICBncm91cD8uY29sbGVjdGVkX2J5Py5uYW1lIHx8XHJcbiAgICAgICAgICAgICAgZ3JvdXA/LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHxcclxuICAgICAgICAgICAgICBcIlN1cGVyIEFkbWluXCIsXHJcbiAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtgL3ByaW50LyR7Z3JvdXAuX2lkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcmludFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgICBzZXRUYWJsZURheWJvb2soZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIHNldFBheW1lbnRzKDApO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hQYXltZW50cygpO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgYWJvcnRDb250cm9sbGVyLmFib3J0KCk7XHJcbiAgICB9O1xyXG4gIH0sIFtcclxuICAgIHNlbGVjdGVkQXVjdGlvbkdyb3VwSWQsXHJcbiAgICBzZWxlY3RlZERhdGUsXHJcbiAgICBzZWxlY3RlZFBheW1lbnRNb2RlLFxyXG4gICAgc2VsZWN0ZWRDdXN0b21lcnMsXHJcbiAgICBzZWxlY3RlZEZyb21EYXRlLFxyXG4gICAgc2VsZWN0ZWRBY2NvdW50VHlwZSxcclxuICAgIHNlbGVjdGVkQ29sbGVjdGlvbkV4ZWN1dGl2ZVxyXG4gIF0pO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJQYWlkIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cFwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImNhdGVnb3J5XCIsIGhlYWRlcjogXCJDYXRlZ29yeVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0X25vXCIsIGhlYWRlcjogXCJSZWNlaXB0IE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJvbGRfcmVjZWlwdF9ub1wiLCBoZWFkZXI6IFwiT2xkIFJlY2VpcHRcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwibW9kZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBNb2RlXCIgfSxcclxuICAgIC4uLihoaWRlQWNjb3VudFR5cGVcclxuICAgICAgPyBbeyBrZXk6IFwiYWNjb3VudF90eXBlXCIsIGhlYWRlcjogXCJBY2NvdW50IFR5cGVcIiB9XVxyXG4gICAgICA6IFtdKSxcclxuICAgIHsga2V5OiBcImNvbGxlY3RlZF9ieVwiLCBoZWFkZXI6IFwiQ29sbGVjdGVkIEJ5XCIgfSxcclxuXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChncm91cEluZm8gJiYgZm9ybURhdGEuYmlkX2Ftb3VudCkge1xyXG4gICAgICBjb25zdCBjb21taXNzaW9uID0gKGdyb3VwSW5mby5ncm91cF92YWx1ZSAqIDUpIC8gMTAwIHx8IDA7XHJcbiAgICAgIGNvbnN0IHdpbl9hbW91bnQgPVxyXG4gICAgICAgIChncm91cEluZm8uZ3JvdXBfdmFsdWUgfHwgMCkgLSAoZm9ybURhdGEuYmlkX2Ftb3VudCB8fCAwKTtcclxuICAgICAgY29uc3QgZGl2aWRlbnQgPSAoZm9ybURhdGEuYmlkX2Ftb3VudCB8fCAwKSAtIGNvbW1pc3Npb247XHJcbiAgICAgIGNvbnN0IGRpdmlkZW50X2hlYWQgPSBncm91cEluZm8uZ3JvdXBfbWVtYmVyc1xyXG4gICAgICAgID8gZGl2aWRlbnQgLyBncm91cEluZm8uZ3JvdXBfbWVtYmVyc1xyXG4gICAgICAgIDogMDtcclxuICAgICAgY29uc3QgcGF5YWJsZSA9IChncm91cEluZm8uZ3JvdXBfaW5zdGFsbCB8fCAwKSAtIGRpdmlkZW50X2hlYWQ7XHJcblxyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgICAgZ3JvdXBfaWQ6IGdyb3VwSW5mby5faWQsXHJcbiAgICAgICAgY29tbWlzc2lvbixcclxuICAgICAgICB3aW5fYW1vdW50LFxyXG4gICAgICAgIGRpdmlkZW50LFxyXG4gICAgICAgIGRpdmlkZW50X2hlYWQsXHJcbiAgICAgICAgcGF5YWJsZSxcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtncm91cEluZm8sIGZvcm1EYXRhLmJpZF9hbW91bnRdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGF5bWVudE1vZGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRNb2RlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRQYXltZW50TW9kZShzZWxlY3RlZE1vZGUpO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgcGF5X3R5cGU6IHNlbGVjdGVkTW9kZSxcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IHNlbGVjdGVkTW9kZSA9PT0gXCJvbmxpbmVcIiA/IHByZXZEYXRhLnRyYW5zYWN0aW9uX2lkIDogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICAvLyBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gIC8vICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIC8vICAgdHJ5IHtcclxuICAvLyAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi9wYXltZW50L2FkZC1wYXltZW50XCIsIGZvcm1EYXRhKTtcclxuICAvLyAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAxKSB7XHJcbiAgLy8gICAgICAgYWxlcnQoXCJQYXltZW50IEFkZGVkIFN1Y2Nlc3NmdWxseVwiKTtcclxuICAvLyAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4gIC8vICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc3VibWl0dGluZyBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAvLyAgIH1cclxuICAvLyB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9nZXQtcGF5bWVudC1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUF1Y3Rpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudEdyb3VwKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL3BheW1lbnQvZGVsZXRlLXBheW1lbnQvJHtjdXJyZW50R3JvdXAuX2lkfWApO1xyXG4gICAgICAgIGFsZXJ0KFwiUGF5bWVudCBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGF1Y3Rpb246XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9hdWN0aW9uL2dldC1hdWN0aW9uLWJ5LWlkLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudFVwZGF0ZUdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYXVjdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUZpbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IGZvcm1EYXRhcyA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgY29uc3QgZmlsZUlucHV0ID0gZS50YXJnZXQuZmlsZTtcclxuICAgIGlmIChmaWxlSW5wdXQgJiYgZmlsZUlucHV0LmZpbGVzWzBdKSB7XHJcbiAgICAgIGZvcm1EYXRhcy5hcHBlbmQoXCJmaWxlXCIsIGZpbGVJbnB1dC5maWxlc1swXSk7XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoYC9wYXltZW50L3BheW1lbnQtZXhjZWxgLCBmb3JtRGF0YXMsIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICAgICAgICBhbGVydChcIkZpbGUgdXBsb2FkZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcclxuICAgICAgICAgIHNldFNob3dVcGxvYWRNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGxvYWRpbmcgZmlsZTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIGFsZXJ0KFwiRmFpbGVkIHRvIHVwbG9hZCBmaWxlLlwiKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYWxlcnQoXCJQbGVhc2Ugc2VsZWN0IGEgZmlsZSB0byB1cGxvYWQuXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LXNjcmVlbiBiZy1ncmF5LTUwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG10LTMwXCI+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxDdXN0b21BbGVydFxyXG4gICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC02IGxnOnAtOFwiPlxyXG4gICAgICAgICAgICB7LyogSGVhZGVyIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOCBwYi02IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBDb2xsZWN0aW9uIEV4ZWN1dGl2ZSBSZXBvcnRcclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgVmlldyBhbmQgbWFuYWdlIGNvbGxlY3Rpb24gcmVwb3J0cyB3aXRoIGFkdmFuY2VkIGZpbHRlcnNcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEZpbHRlcnMgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHAtNiBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICA8RmlGaWx0ZXIgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5GaWx0ZXJzPC9oMj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIHhsOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogRmlsdGVyIE9wdGlvbiAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGaUNhbGVuZGFyIGNsYXNzTmFtZT1cImlubGluZSBtci0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICBGaWx0ZXIgT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0RmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEZpbHRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKHRpbWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dGltZS52YWx1ZX0gdmFsdWU9e3RpbWUudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dGltZS5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENvbGxlY3Rpb24gRXhlY3V0aXZlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDb2xsZWN0aW9uRXhlY3V0aXZlIHx8IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ29sbGVjdGlvbiBFeGVjdXRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZ3JvdXBJZCkgPT4gc2V0U2VsZWN0ZWRDb2xsZWN0aW9uRXhlY3V0aXZlKGdyb3VwSWQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXA/Ll9pZH0gdmFsdWU9e2dyb3VwPy5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXA/LmZ1bGxfbmFtZX0gLSB7Z3JvdXAucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBDdXN0b20gRGF0ZSBSYW5nZSAqL31cclxuICAgICAgICAgICAgICAgIHtzaG93RmlsdGVyRmllbGQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRnJvbSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUbyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIG91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEdyb3VwIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGaVVzZXJzIGNsYXNzTmFtZT1cImlubGluZSBtci0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQXVjdGlvbkdyb3VwSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9e1wiXCJ9PkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEN1c3RvbWVyc31cclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhncm91cElkKSA9PiBzZXRTZWxlY3RlZEN1c3RvbWVycyhncm91cElkKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRVc2Vycy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwPy5faWR9IHZhbHVlPXtncm91cD8uX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwPy5mdWxsX25hbWV9IC0ge2dyb3VwLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogUGF5bWVudCBNb2RlIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGaUNyZWRpdENhcmQgY2xhc3NOYW1lPVwiaW5saW5lIG1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUGF5bWVudE1vZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFBheW1lbnQgTW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGdyb3VwSWQpID0+IHNldFNlbGVjdGVkUGF5bWVudE1vZGUoZ3JvdXBJZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjYXNoXCI+Q2FzaDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPk9ubGluZTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQWNjb3VudCBUeXBlIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIHtzaG93QWxsUGF5bWVudE1vZGVzICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEFjY291bnQgVHlwZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQWNjb3VudFR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBBY2NvdW50IFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZ3JvdXBJZCkgPT4gc2V0U2VsZWN0ZWRBY2NvdW50VHlwZShncm91cElkKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJzdXNwZW5zZVwiPlN1c3BlbnNlPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjcmVkaXRcIj5DcmVkaXQ8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImFkanVzdG1lbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRqdXN0bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJvdGhlcnNcIj5PdGhlcnM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUgdG8tZ3JheS01MCByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTYgbWItNiBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogTGFiZWwgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2UgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRvdGFsIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogQW1vdW50ICovfVxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBsZWFkaW5nLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICDigrl7cGF5bWVudHMgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEFtb3VudCBpbiBXb3JkcyAqL31cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyZWVuLTcwMCBtdC0yIGxlYWRpbmctcmVsYXhlZCBtYXgtdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHBheW1lbnRzIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogRGF0ZSAqL31cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICBVcGRhdGVkIGFzIG9mIHtuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj48L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRGF0YSBUYWJsZSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICB7ZmlsdGVyZWRBdWN0aW9uICYmIGZpbHRlcmVkQXVjdGlvbi5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlRGF5Ym9vaywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT17YFJlY2VpcHQgUmVwb3J0YH1cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YENvbGxlY3Rpb24gRXhlY3V0aXZlIFJlcG9ydC5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBwLTYgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVG90YWwgQW1vdW50OlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICDigrl7cGF5bWVudHN9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTEyXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e2ZpbHRlcmVkQXVjdGlvbi5sZW5ndGggPD0gMH1cclxuICAgICAgICAgICAgICAgICAgZGF0YT1cIkNvbGxlY3Rpb24gRXhlY3V0aXZlIFJlcG9ydCBEYXRhXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIHsvKiA8TW9kYWwgaXNWaXNpYmxlPXtzaG93TW9kYWx9IG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgIEFkZCBQYXltZW50XHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXBcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgR3JvdXA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBDdXN0b21lcnNcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ1c2VyX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YCR7Zm9ybURhdGEudXNlcl9pZH0tJHtmb3JtRGF0YS50aWNrZXR9YH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlVXNlcn1cclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgQ3VzdG9tZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRVc2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtgJHt1c2VyPy51c2VyX2lkPy5faWR9LSR7dXNlci50aWNrZXRzfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHt1c2VyPy51c2VyX2lkPy5faWR9LSR7dXNlci50aWNrZXRzfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyPy51c2VyX2lkPy5mdWxsX25hbWV9IHwge3VzZXIudGlja2V0c31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZWNlaXB0IE5vLlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVjZWlwdF9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucmVjZWlwdF9ub31cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwicmVjZWlwdF9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJlY2VpcHQgTm8uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IERhdGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGF5X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlfbW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50TW9kZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvbmxpbmVcIj5PbmxpbmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHtwYXltZW50TW9kZSA9PT0gXCJvbmxpbmVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSURcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgVHJhbnNhY3Rpb24gSURcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBZGRcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L01vZGFsPiAqL31cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBWaWV3IEF1Y3Rpb25cclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXsoKSA9PiB7IH19PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4geyB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgR3JvdXAgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXAgVmFsdWVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBfdmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJzZWxlY3QgZ3JvdXAgdG8gY2hlY2tcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX2luc3RhbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIEluc3RhbGxtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9pbnN0YWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cF9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwic2VsZWN0IGdyb3VwIHRvIGNoZWNrXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgVXNlclxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YCR7Y3VycmVudFVwZGF0ZUdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWV9IHwgJHtjdXJyZW50VXBkYXRlR3JvdXA/LnRpY2tldH1gfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7IH19XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBVc2VyIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBCaWQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJiaWRfYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXBkYXRlR3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSAtXHJcbiAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXBkYXRlR3JvdXA/Lndpbl9hbW91bnRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHsgfX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEJpZCBBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfdmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIENvbW1pc3Npb25cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvbW1pc3Npb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8uY29tbWlzc2lvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29tbWlzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgV2lubmluZyBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIndpbl9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8ud2luX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwid2luX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfdmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIERpdmlkZW50XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkaXZpZGVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy5kaXZpZGVudH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZGl2aWRlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX2luc3RhbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIERpdmlkZW50IHBlciBIZWFkXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkaXZpZGVudF9oZWFkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/LmRpdmlkZW50X2hlYWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImRpdmlkZW50X2hlYWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX2luc3RhbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIE5leHQgUGF5YWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5YWJsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy5wYXlhYmxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwYXlhYmxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIERhdGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImF1Y3Rpb25fZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy5hdWN0aW9uX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4geyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIE5leHQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibmV4dF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/Lm5leHRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBTdXJlIHdhbnQgdG8gZGVsZXRlIHRoaXMgUGF5bWVudCA/XHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwICYmIChcclxuICAgICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVBdWN0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDBcclxuICAgICAgICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ29sbGVjdGlvbkV4ZWN1dGl2ZVJlcG9ydDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0NvbGxlY3Rpb25FeGVjdXRpdmVSZXBvcnQuanN4In0=