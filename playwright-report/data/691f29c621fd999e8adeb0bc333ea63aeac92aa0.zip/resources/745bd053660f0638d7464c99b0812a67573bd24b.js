import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UserRegistrationSourceSummaryReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const UserRegistrationSourceSummaryReport = () => {
  _s();
  const [trackTableData, setTracktableData] = useState([]);
  const [agents, setAgents] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [filterType, setFilterType] = useState("all");
  const [selectedId, setSelectedId] = useState("all");
  const today = /* @__PURE__ */ new Date();
  const formatDate = (date) => date.toLocaleDateString("en-CA");
  const todayStr = formatDate(today);
  const [selectedFromDate, setSelectedFromDate] = useState(todayStr);
  const [selectedDate, setSelectedDate] = useState(todayStr);
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const [showFilterField, setShowFilterField] = useState(false);
  const getTopDisplayFilter = () => {
    if (filterType === "agent") {
      if (selectedId === "all") return "All Employees";
      const found = agents.find((a) => a._id === selectedId);
      return found ? found.name : "Employee";
    }
    return "All";
  };
  const dateOptions = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const onGlobalSearchChangeHandler = (e) => setSearchText(e.target.value);
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today2 = /* @__PURE__ */ new Date();
    if (value === "Today") {
      const formatted = formatDate(today2);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "Yesterday") {
      const y = new Date(today2);
      y.setDate(y.getDate() - 1);
      const formatted = formatDate(y);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today2.getFullYear(), today2.getMonth(), 1);
      const end = new Date(today2.getFullYear(), today2.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today2.getFullYear(), today2.getMonth() - 1, 1);
      const end = new Date(today2.getFullYear(), today2.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today2.getFullYear(), 0, 1);
      const end = new Date(today2.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  useEffect(() => {
    const fetchAgent = async () => {
      try {
        const resp = await api.get("/agent/get-agent");
        setAgents(resp?.data || []);
      } catch (err) {
        console.error("Unable to fetch agents", err);
      }
    };
    fetchAgent();
  }, []);
  useEffect(() => {
    const fetchReport = async () => {
      try {
        setIsLoading(true);
        let params = {
          start_date: selectedFromDate,
          end_date: selectedDate
        };
        if (filterType === "agent" && selectedId !== "all") {
          params.agentId = selectedId;
        }
        const response = await api.get("/user/installed/agents", { params });
        const formatted = response?.data?.data?.map((item, index) => ({
          _id: item?._id,
          slNo: index + 1,
          userName: item?.full_name || "-",
          userPhone: item?.phone_number || "-",
          referredType: item?.referral_type || "-",
          referredBy: item?.agent?.name || "Admin"
        }));
        setTracktableData(formatted);
      } catch (err) {
        console.error("Error fetching report", err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchReport();
  }, [filterType, selectedId, selectedFromDate, selectedDate]);
  const trackColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "userName", header: "Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "referredType", header: "Referred Type" },
    { key: "referredBy", header: "Referred By" }
  ];
  const totalCustomers = trackTableData.length;
  const referredTypeCount = {};
  trackTableData.forEach((item) => {
    const key = item.referredType || "Unknown";
    referredTypeCount[key] = (referredTypeCount[key] || 0) + 1;
  });
  const referredByCount = {};
  trackTableData.forEach((item) => {
    const key = item.referredBy || "Unknown";
    referredByCount[key] = (referredByCount[key] || 0) + 1;
  });
  const calculateDaysBetween = () => {
    const fromDate = new Date(selectedFromDate);
    const toDate = new Date(selectedDate);
    const diffTime = Math.abs(toDate - fromDate);
    const diffDays = Math.ceil(diffTime / (1e3 * 60 * 60 * 24)) + 1;
    return diffDays;
  };
  const avgCustomersPerDay = calculateDaysBetween() > 0 ? (totalCustomers / calculateDaysBetween()).toFixed(1) : 0;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
        lineNumber: 1352,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: [
        "Reports —",
        " ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-violet-600", children: "User Mobile Tracking Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1361,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
        lineNumber: 1359,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
        lineNumber: 1358,
        columnNumber: 13
      }, this),
      trackTableData.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4 text-gray-800", children: "Report Summary" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1370,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-violet-500 to-violet-600 text-white p-6 rounded-xl shadow-lg mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-violet-100 text-sm uppercase tracking-wide", children: "Total Customers Added" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1376,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold mt-1", children: totalCustomers }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1379,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-violet-100 text-sm mt-1", children: getTopDisplayFilter() }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1380,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1375,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white bg-opacity-20 p-3 rounded-full", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-8 w-8", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1386,
            columnNumber: 25
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1385,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1384,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1374,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1373,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800", children: "Referral Types" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1398,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "bg-violet-100 text-violet-800 text-xs font-medium px-2.5 py-0.5 rounded", children: [
                Object.keys(referredTypeCount).length,
                " Types"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1399,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1397,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
              Object.entries(referredTypeCount).sort((a, b) => b[1] - a[1]).slice(0, 5).map(
                ([type, count]) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-2 h-2 bg-violet-500 rounded-full mr-3" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                      lineNumber: 1410,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm truncate max-w-xs", children: type }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                      lineNumber: 1411,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                    lineNumber: 1409,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-24 bg-gray-200 rounded-full h-2 mr-3", children: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "bg-violet-500 h-2 rounded-full",
                        style: { width: `${count / totalCustomers * 100}%` }
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                        lineNumber: 1415,
                        columnNumber: 33
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                      lineNumber: 1414,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 w-8 text-right", children: count }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                      lineNumber: 1420,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                    lineNumber: 1413,
                    columnNumber: 29
                  }, this)
                ] }, type, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                  lineNumber: 1408,
                  columnNumber: 21
                }, this)
              ),
              Object.keys(referredTypeCount).length > 5 && /* @__PURE__ */ jsxDEV("div", { className: "text-center pt-2", children: /* @__PURE__ */ jsxDEV("button", { className: "text-violet-600 text-sm font-medium", children: "View All Types" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1426,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1425,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1403,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1396,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800", children: "Referral Sources" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1435,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded", children: [
                Object.keys(referredByCount).length,
                " Sources"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1436,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1434,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
              Object.entries(referredByCount).sort((a, b) => b[1] - a[1]).slice(0, 5).map(
                ([source, count]) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-2 h-2 bg-green-500 rounded-full mr-3" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                      lineNumber: 1447,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm truncate max-w-xs", children: source }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                      lineNumber: 1448,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                    lineNumber: 1446,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-24 bg-gray-200 rounded-full h-2 mr-3", children: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "bg-green-500 h-2 rounded-full",
                        style: { width: `${count / totalCustomers * 100}%` }
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                        lineNumber: 1452,
                        columnNumber: 33
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                      lineNumber: 1451,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 w-8 text-right", children: count }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                      lineNumber: 1457,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                    lineNumber: 1450,
                    columnNumber: 29
                  }, this)
                ] }, source, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                  lineNumber: 1445,
                  columnNumber: 21
                }, this)
              ),
              Object.keys(referredByCount).length > 5 && /* @__PURE__ */ jsxDEV("div", { className: "text-center pt-2", children: /* @__PURE__ */ jsxDEV("button", { className: "text-green-600 text-sm font-medium", children: "View All Sources" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1463,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1462,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1440,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1433,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1393,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-full bg-purple-100 text-purple-600 mr-4", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-6 w-6", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1476,
              columnNumber: 27
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1475,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1474,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Selected Period" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1480,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: selectedLabel }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1481,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1479,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1473,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1472,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-full bg-amber-100 text-amber-600 mr-4", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-6 w-6", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1490,
              columnNumber: 27
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1489,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1488,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Avg. Customers/Day" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1494,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: avgCustomersPerDay }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1495,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1493,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1487,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1486,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-full bg-red-100 text-red-600 mr-4", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-6 w-6", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1504,
              columnNumber: 27
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1503,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1502,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Active Referrers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1508,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: Object.keys(referredByCount).length }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1509,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1507,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1501,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1500,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1471,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
        lineNumber: 1369,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 mb-6 items-end", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Date Filter" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1520,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-300 rounded-lg w-48", children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-10",
              value: selectedLabel,
              onChange: (value) => handleSelectFilter(value),
              children: dateOptions.map(
                (option) => /* @__PURE__ */ jsxDEV(Select.Option, { value: option.value, children: option.label }, option.value, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                  lineNumber: 1529,
                  columnNumber: 21
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1523,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1522,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1519,
          columnNumber: 15
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 items-end", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "From" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1541,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg h-10 p-2.5",
                value: selectedFromDate,
                onChange: (e) => setSelectedFromDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1542,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1540,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "To" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1551,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg h-10 p-2.5",
                value: selectedDate,
                onChange: (e) => setSelectedDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                lineNumber: 1552,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1550,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1539,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Employee Filter" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1564,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-300 rounded-lg w-48", children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-10",
              value: filterType,
              onChange: (value) => {
                setFilterType(value);
                setSelectedId("all");
              },
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "all", children: "All" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                  lineNumber: 1577,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "agent", children: "Employee" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                  lineNumber: 1578,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1569,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1568,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1563,
          columnNumber: 15
        }, this),
        filterType === "agent" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Select Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1586,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-300 rounded-lg w-64", children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-10",
              showSearch: true,
              placeholder: "Select Employee",
              popupMatchSelectWidth: false,
              value: selectedId !== "all" ? selectedId : void 0,
              onChange: (value) => setSelectedId(value),
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "all", children: "All Employees" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                  lineNumber: 1599,
                  columnNumber: 23
                }, this),
                agents.map(
                  (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                    agent.name,
                    " | ",
                    agent.phone_number
                  ] }, agent._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
                    lineNumber: 1601,
                    columnNumber: 21
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
              lineNumber: 1591,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
            lineNumber: 1590,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1585,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
        lineNumber: 1517,
        columnNumber: 13
      }, this),
      trackTableData && !isLoading ? /* @__PURE__ */ jsxDEV(DataTable, { data: trackTableData, columns: trackColumns, exportedFileName: "User Registration Source Summary Report.csv", exportedPdfName: "User Registration Source Summary Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
        lineNumber: 1613,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          failure: trackTableData.length <= 0,
          data: "user tracking data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
          lineNumber: 1616,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
      lineNumber: 1357,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
    lineNumber: 1351,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
    lineNumber: 1350,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx",
    lineNumber: 1349,
    columnNumber: 5
  }, this);
};
_s(UserRegistrationSourceSummaryReport, "knd7U2CwPjHw3X5TzY+10RZHUw4=");
_c = UserRegistrationSourceSummaryReport;
export default UserRegistrationSourceSummaryReport;
var _c;
$RefreshReg$(_c, "UserRegistrationSourceSummaryReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserRegistrationSourceSummaryReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbzBDSSxtQkFHTSxjQUhOOzJCQXAwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUEybUJBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLGNBQWM7QUFzaUJ2QixNQUFNQyxzQ0FBc0NBLE1BQU07QUFBQUMsS0FBQTtBQUNoRCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUlaLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNhLFFBQVFDLFNBQVMsSUFBSWQsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2UsV0FBV0MsWUFBWSxJQUFJaEIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2lCLFlBQVlDLGFBQWEsSUFBSWxCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNtQixhQUFhQyxjQUFjLElBQUlwQixTQUFTO0FBQUEsSUFDN0NxQixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFHRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSXpCLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTLEtBQUs7QUFDbEQsUUFBTTRCLFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsUUFBTUMsYUFBYUEsQ0FBQ0MsU0FBU0EsS0FBS0MsbUJBQW1CLE9BQU87QUFDNUQsUUFBTUMsV0FBV0gsV0FBV0YsS0FBSztBQUNqQyxRQUFNLENBQUNNLGtCQUFrQkMsbUJBQW1CLElBQUluQyxTQUFTaUMsUUFBUTtBQUNqRSxRQUFNLENBQUNHLGNBQWNDLGVBQWUsSUFBSXJDLFNBQVNpQyxRQUFRO0FBQ3pELFFBQU0sQ0FBQ0ssZUFBZUMsZ0JBQWdCLElBQUl2QyxTQUFTLE9BQU87QUFDMUQsUUFBTSxDQUFDd0MsaUJBQWlCQyxrQkFBa0IsSUFBSXpDLFNBQVMsS0FBSztBQUc1RCxRQUFNMEMsc0JBQXNCQSxNQUFNO0FBQ2hDLFFBQUlsQixlQUFlLFNBQVM7QUFDMUIsVUFBSUUsZUFBZSxNQUFPLFFBQU87QUFFakMsWUFBTWlCLFFBQVE5QixPQUFPK0IsS0FBSyxDQUFDQyxNQUFNQSxFQUFFQyxRQUFRcEIsVUFBVTtBQUNyRCxhQUFPaUIsUUFBUUEsTUFBTUksT0FBTztBQUFBLElBQzlCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNQyxjQUFjO0FBQUEsSUFDbEIsRUFBRUMsT0FBTyxTQUFTQyxPQUFPLFFBQVE7QUFBQSxJQUNqQyxFQUFFRCxPQUFPLGFBQWFDLE9BQU8sWUFBWTtBQUFBLElBQ3pDLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxhQUFhO0FBQUEsSUFDMUMsRUFBRUQsT0FBTyxhQUFhQyxPQUFPLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxPQUFPLFlBQVlDLE9BQU8sWUFBWTtBQUFBLElBQ3hDLEVBQUVELE9BQU8sVUFBVUMsT0FBTyxTQUFTO0FBQUEsRUFBQztBQUd0QyxRQUFNQyw4QkFBOEJBLENBQUNDLE1BQU1sQyxjQUFja0MsRUFBRUMsT0FBT0osS0FBSztBQUV2RSxRQUFNSyxxQkFBcUJBLENBQUNMLFVBQVU7QUFDcENWLHFCQUFpQlUsS0FBSztBQUN0QlIsdUJBQW1CLEtBQUs7QUFFeEIsVUFBTWIsU0FBUSxvQkFBSUMsS0FBSztBQUV2QixRQUFJb0IsVUFBVSxTQUFTO0FBQ3JCLFlBQU1NLFlBQVl6QixXQUFXRixNQUFLO0FBQ2xDTywwQkFBb0JvQixTQUFTO0FBQzdCbEIsc0JBQWdCa0IsU0FBUztBQUFBLElBQzNCLFdBQVdOLFVBQVUsYUFBYTtBQUNoQyxZQUFNTyxJQUFJLElBQUkzQixLQUFLRCxNQUFLO0FBQ3hCNEIsUUFBRUMsUUFBUUQsRUFBRUUsUUFBUSxJQUFJLENBQUM7QUFDekIsWUFBTUgsWUFBWXpCLFdBQVcwQixDQUFDO0FBQzlCckIsMEJBQW9Cb0IsU0FBUztBQUM3QmxCLHNCQUFnQmtCLFNBQVM7QUFBQSxJQUMzQixXQUFXTixVQUFVLGFBQWE7QUFDaEMsWUFBTVUsUUFBUSxJQUFJOUIsS0FBS0QsT0FBTWdDLFlBQVksR0FBR2hDLE9BQU1pQyxTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUlqQyxLQUFLRCxPQUFNZ0MsWUFBWSxHQUFHaEMsT0FBTWlDLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakUxQiwwQkFBb0JMLFdBQVc2QixLQUFLLENBQUM7QUFDckN0QixzQkFBZ0JQLFdBQVdnQyxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXYixVQUFVLGFBQWE7QUFDaEMsWUFBTVUsUUFBUSxJQUFJOUIsS0FBS0QsT0FBTWdDLFlBQVksR0FBR2hDLE9BQU1pQyxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ25FLFlBQU1DLE1BQU0sSUFBSWpDLEtBQUtELE9BQU1nQyxZQUFZLEdBQUdoQyxPQUFNaUMsU0FBUyxHQUFHLENBQUM7QUFDN0QxQiwwQkFBb0JMLFdBQVc2QixLQUFLLENBQUM7QUFDckN0QixzQkFBZ0JQLFdBQVdnQyxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXYixVQUFVLFlBQVk7QUFDL0IsWUFBTVUsUUFBUSxJQUFJOUIsS0FBS0QsT0FBTWdDLFlBQVksR0FBRyxHQUFHLENBQUM7QUFDaEQsWUFBTUUsTUFBTSxJQUFJakMsS0FBS0QsT0FBTWdDLFlBQVksR0FBRyxJQUFJLEVBQUU7QUFDaER6QiwwQkFBb0JMLFdBQVc2QixLQUFLLENBQUM7QUFDckN0QixzQkFBZ0JQLFdBQVdnQyxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXYixVQUFVLFVBQVU7QUFDN0JSLHlCQUFtQixJQUFJO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBR0ExQyxZQUFVLE1BQU07QUFDZCxVQUFNZ0UsYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNQyxPQUFPLE1BQU0vRCxJQUFJZ0UsSUFBSSxrQkFBa0I7QUFDN0NuRCxrQkFBVWtELE1BQU1FLFFBQVEsRUFBRTtBQUFBLE1BQzVCLFNBQVNDLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0sMEJBQTBCRixHQUFHO0FBQUEsTUFDN0M7QUFBQSxJQUNGO0FBQ0FKLGVBQVc7QUFBQSxFQUNiLEdBQUcsRUFBRTtBQUdMaEUsWUFBVSxNQUFNO0FBQ2QsVUFBTXVFLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0Z0RCxxQkFBYSxJQUFJO0FBRWpCLFlBQUl1RCxTQUFTO0FBQUEsVUFDWEMsWUFBWXRDO0FBQUFBLFVBQ1p1QyxVQUFVckM7QUFBQUEsUUFDWjtBQUVBLFlBQUlaLGVBQWUsV0FBV0UsZUFBZSxPQUFPO0FBQ2xENkMsaUJBQU9HLFVBQVVoRDtBQUFBQSxRQUNuQjtBQUVBLGNBQU1pRCxXQUFXLE1BQU0xRSxJQUFJZ0UsSUFBSSwwQkFBMEIsRUFBRU0sT0FBTyxDQUFDO0FBRW5FLGNBQU1oQixZQUFZb0IsVUFBVVQsTUFBTUEsTUFBTVUsSUFBSSxDQUFDQyxNQUFNQyxXQUFXO0FBQUEsVUFDNURoQyxLQUFLK0IsTUFBTS9CO0FBQUFBLFVBQ1hpQyxNQUFNRCxRQUFRO0FBQUEsVUFDZEUsVUFBVUgsTUFBTUksYUFBYTtBQUFBLFVBQzdCQyxXQUFXTCxNQUFNTSxnQkFBZ0I7QUFBQSxVQUNqQ0MsY0FBY1AsTUFBTVEsaUJBQWlCO0FBQUEsVUFDckNDLFlBQVlULE1BQU1VLE9BQU94QyxRQUFRO0FBQUEsUUFDbkMsRUFBRTtBQUVGbkMsMEJBQWtCMkMsU0FBUztBQUFBLE1BQzdCLFNBQVNZLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0seUJBQXlCRixHQUFHO0FBQUEsTUFDNUMsVUFBQztBQUNDbkQscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUVBc0QsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQzlDLFlBQVlFLFlBQVlRLGtCQUFrQkUsWUFBWSxDQUFDO0FBRzNELFFBQU1vRCxlQUFlO0FBQUEsSUFDbkIsRUFBRUMsS0FBSyxRQUFRQyxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFRCxLQUFLLFlBQVlDLFFBQVEsT0FBTztBQUFBLElBQ2xDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGNBQWM7QUFBQSxFQUFDO0FBSTlDLFFBQU1DLGlCQUFpQmhGLGVBQWVpRjtBQUd0QyxRQUFNQyxvQkFBb0IsQ0FBQztBQUMzQmxGLGlCQUFlbUYsUUFBUSxDQUFDakIsU0FBUztBQUMvQixVQUFNWSxNQUFNWixLQUFLTyxnQkFBZ0I7QUFDakNTLHNCQUFrQkosR0FBRyxLQUFLSSxrQkFBa0JKLEdBQUcsS0FBSyxLQUFLO0FBQUEsRUFDM0QsQ0FBQztBQUdELFFBQU1NLGtCQUFrQixDQUFDO0FBQ3pCcEYsaUJBQWVtRixRQUFRLENBQUNqQixTQUFTO0FBQy9CLFVBQU1ZLE1BQU1aLEtBQUtTLGNBQWM7QUFDL0JTLG9CQUFnQk4sR0FBRyxLQUFLTSxnQkFBZ0JOLEdBQUcsS0FBSyxLQUFLO0FBQUEsRUFDdkQsQ0FBQztBQUdELFFBQU1PLHVCQUF1QkEsTUFBTTtBQUNqQyxVQUFNQyxXQUFXLElBQUlwRSxLQUFLSyxnQkFBZ0I7QUFDMUMsVUFBTWdFLFNBQVMsSUFBSXJFLEtBQUtPLFlBQVk7QUFDcEMsVUFBTStELFdBQVdDLEtBQUtDLElBQUlILFNBQVNELFFBQVE7QUFDM0MsVUFBTUssV0FBV0YsS0FBS0csS0FBS0osWUFBWSxNQUFPLEtBQUssS0FBSyxHQUFHLElBQUk7QUFDL0QsV0FBT0c7QUFBQUEsRUFDVDtBQUdBLFFBQU1FLHFCQUFxQlIscUJBQXFCLElBQUksS0FDL0NMLGlCQUFpQksscUJBQXFCLEdBQUdTLFFBQVEsQ0FBQyxJQUNuRDtBQUVKLFNBQ0UsbUNBQ0UsaUNBQUMsU0FDQyxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUduQix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxRQUMzQjtBQUFBLFFBQ1YsdUJBQUMsVUFBSyxXQUFVLG1CQUFrQiwyQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUdDOUYsZUFBZWlGLFNBQVMsS0FDdkIsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNENBQTJDLDhCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFHdkUsdUJBQUMsU0FBSSxXQUFVLDJGQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsbURBQWtELHFDQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsMkJBQTJCRCw0QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxZQUN2RCx1QkFBQyxPQUFFLFdBQVUsZ0NBQ1ZqRCw4QkFBb0IsS0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiLGlDQUFDLFNBQUksT0FBTSw4QkFBNkIsV0FBVSxXQUFVLE1BQUssUUFBTyxTQUFRLGFBQVksUUFBTyxnQkFDakcsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFhLEdBQUcsR0FBRSw0UUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNlUsS0FEL1U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsOENBR2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRTtBQUFBLGNBQ2xFLHVCQUFDLFVBQUssV0FBVSwyRUFDYmdFO0FBQUFBLHVCQUFPQyxLQUFLZCxpQkFBaUIsRUFBRUQ7QUFBQUEsZ0JBQU87QUFBQSxtQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNaYztBQUFBQSxxQkFBT0UsUUFBUWYsaUJBQWlCLEVBQzlCZ0IsS0FBSyxDQUFDaEUsR0FBR2lFLE1BQU1BLEVBQUUsQ0FBQyxJQUFJakUsRUFBRSxDQUFDLENBQUMsRUFDMUJrRSxNQUFNLEdBQUcsQ0FBQyxFQUNWbkM7QUFBQUEsZ0JBQUksQ0FBQyxDQUFDckQsTUFBTXlGLEtBQUssTUFDaEIsdUJBQUMsU0FBZSxXQUFVLHFDQUN4QjtBQUFBLHlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSw2Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5RDtBQUFBLG9CQUN6RCx1QkFBQyxVQUFLLFdBQVUsMkNBQTJDekYsa0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdFO0FBQUEsdUJBRmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLE9BQU8sRUFBRTBGLE9BQU8sR0FBSUQsUUFBUXJCLGlCQUFrQixHQUFHLElBQUk7QUFBQTtBQUFBLHNCQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBR0MsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDhDQUE4Q3FCLG1CQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvRTtBQUFBLHVCQVB0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEscUJBYlF6RixNQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBY0E7QUFBQSxjQUNEO0FBQUEsY0FDRm1GLE9BQU9DLEtBQUtkLGlCQUFpQixFQUFFRCxTQUFTLEtBQ3ZDLHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxZQUFPLFdBQVUsdUNBQXNDLDhCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRSxLQUR4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsZUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQ0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSx1Q0FBc0MsZ0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsY0FDcEUsdUJBQUMsVUFBSyxXQUFVLHlFQUNiYztBQUFBQSx1QkFBT0MsS0FBS1osZUFBZSxFQUFFSDtBQUFBQSxnQkFBTztBQUFBLG1CQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ1pjO0FBQUFBLHFCQUFPRSxRQUFRYixlQUFlLEVBQzVCYyxLQUFLLENBQUNoRSxHQUFHaUUsTUFBTUEsRUFBRSxDQUFDLElBQUlqRSxFQUFFLENBQUMsQ0FBQyxFQUMxQmtFLE1BQU0sR0FBRyxDQUFDLEVBQ1ZuQztBQUFBQSxnQkFBSSxDQUFDLENBQUNzQyxRQUFRRixLQUFLLE1BQ2xCLHVCQUFDLFNBQWlCLFdBQVUscUNBQzFCO0FBQUEseUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDRDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdEO0FBQUEsb0JBQ3hELHVCQUFDLFVBQUssV0FBVSwyQ0FBMkNFLG9CQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRTtBQUFBLHVCQUZwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixPQUFPLEVBQUVELE9BQU8sR0FBSUQsUUFBUXJCLGlCQUFrQixHQUFHLElBQUk7QUFBQTtBQUFBLHNCQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBR0MsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDhDQUE4Q3FCLG1CQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvRTtBQUFBLHVCQVB0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEscUJBYlFFLFFBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLGNBQ0Q7QUFBQSxjQUNGUixPQUFPQyxLQUFLWixlQUFlLEVBQUVILFNBQVMsS0FDckMsdUJBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLFlBQU8sV0FBVSxzQ0FBcUMsZ0NBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFLEtBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxlQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtDQTtBQUFBLGFBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyRUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSw0REFDYixpQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsdURBQ2IsaUNBQUMsU0FBSSxPQUFNLDhCQUE2QixXQUFVLFdBQVUsTUFBSyxRQUFPLFNBQVEsYUFBWSxRQUFPLGdCQUNqRyxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLDRGQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2SixLQUQvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSx5QkFBd0IsK0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9EO0FBQUEsY0FDcEQsdUJBQUMsT0FBRSxXQUFVLCtCQUErQnRELDJCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGlCQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNiLGlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxxREFDYixpQ0FBQyxTQUFJLE9BQU0sOEJBQTZCLFdBQVUsV0FBVSxNQUFLLFFBQU8sU0FBUSxhQUFZLFFBQU8sZ0JBQ2pHLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBYSxHQUFHLEdBQUUsaURBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtILEtBRHBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLHlCQUF3QixrQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQSxjQUN2RCx1QkFBQyxPQUFFLFdBQVUsK0JBQStCa0UsZ0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsaUJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2IsaUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlEQUNiLGlDQUFDLFNBQUksT0FBTSw4QkFBNkIsV0FBVSxXQUFVLE1BQUssUUFBTyxTQUFRLGFBQVksUUFBTyxnQkFDakcsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFhLEdBQUcsR0FBRSxvQ0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUcsS0FEdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUseUJBQXdCLGdDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRDtBQUFBLGNBQ3JELHVCQUFDLE9BQUUsV0FBVSwrQkFBK0JFLGlCQUFPQyxLQUFLWixlQUFlLEVBQUVILFVBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdGO0FBQUEsaUJBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsYUF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBDQTtBQUFBLFdBaEpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpSkE7QUFBQSxNQUdGLHVCQUFDLFNBQUksV0FBVSw2QkFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSw0QkFBMkIsMkJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFFdkQsdUJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixPQUFPdEQ7QUFBQUEsY0FDUCxVQUFVLENBQUNXLFVBQVVLLG1CQUFtQkwsS0FBSztBQUFBLGNBRTVDRCxzQkFBWTRCO0FBQUFBLGdCQUFJLENBQUN1QyxXQUNoQix1QkFBQyxPQUFPLFFBQVAsRUFBaUMsT0FBT0EsT0FBT2xFLE9BQzdDa0UsaUJBQU9qRSxTQURVaUUsT0FBT2xFLE9BQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQSxZQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBR0NULG1CQUNDLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw0QkFBMkIsb0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdEO0FBQUEsWUFDaEQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLE9BQU9OO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2tCLE1BQU1qQixvQkFBb0JpQixFQUFFQyxPQUFPSixLQUFLO0FBQUE7QUFBQSxjQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJdUQ7QUFBQSxlQU56RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLGtCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixPQUFPYjtBQUFBQSxnQkFDUCxVQUFVLENBQUNnQixNQUFNZixnQkFBZ0JlLEVBQUVDLE9BQU9KLEtBQUs7QUFBQTtBQUFBLGNBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUltRDtBQUFBLGVBTnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFJRix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLCtCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUscURBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU96QjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ3lCLFVBQVU7QUFDbkJ4Qiw4QkFBY3dCLEtBQUs7QUFDbkJ0Qiw4QkFBYyxLQUFLO0FBQUEsY0FDckI7QUFBQSxjQUVBO0FBQUEsdUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxPQUFNLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QjtBQUFBLGdCQUM5Qix1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFNBQVEsd0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUE7QUFBQTtBQUFBLFlBVHZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUdDSCxlQUFlLFdBQ2QsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDRCQUEyQiwrQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVjtBQUFBLGNBQ0EsYUFBWTtBQUFBLGNBQ1osdUJBQXVCO0FBQUEsY0FDdkIsT0FBT0UsZUFBZSxRQUFRQSxhQUFhMEY7QUFBQUEsY0FDM0MsVUFBVSxDQUFDbkUsVUFBVXRCLGNBQWNzQixLQUFLO0FBQUEsY0FFeEM7QUFBQSx1Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLE9BQU0sNkJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdDO0FBQUEsZ0JBQ3ZDcEMsT0FBTytEO0FBQUFBLGtCQUFJLENBQUNXLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU16QyxLQUN6Q3lDO0FBQUFBLDBCQUFNeEM7QUFBQUEsb0JBQUs7QUFBQSxvQkFBSXdDLE1BQU1KO0FBQUFBLHVCQURKSSxNQUFNekMsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQTtBQUFBLFlBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLGFBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxXQTFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEZBO0FBQUEsTUFHQ25DLGtCQUFrQixDQUFDSSxZQUNaLHVCQUFDLGFBQVUsTUFBTUosZ0JBQWdCLFNBQVM2RSxjQUFjLGtCQUFpQiwrQ0FBOEMsaUJBQWdCLDZDQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdMLElBR3RMO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsU0FBUzdFLGVBQWVpRixVQUFVO0FBQUEsVUFDbEMsTUFBSztBQUFBO0FBQUEsUUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHMkI7QUFBQSxTQXRRL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlRQTtBQUFBLE9BL1FGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnUkEsS0FqUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtSQSxLQW5SRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb1JBO0FBRUo7QUFBRWxGLEdBamNJRCxxQ0FBbUM7QUFBQTRHLEtBQW5DNUc7QUFtY04sZUFBZUE7QUFBb0MsSUFBQTRHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImFwaSIsIkRhdGFUYWJsZSIsIk5hdmJhciIsIkNpcmN1bGFyTG9hZGVyIiwiU2V0dGluZ1NpZGViYXIiLCJDdXN0b21BbGVydERpYWxvZyIsIm1vbWVudCIsIlNlbGVjdCIsIlVzZXJSZWdpc3RyYXRpb25Tb3VyY2VTdW1tYXJ5UmVwb3J0IiwiX3MiLCJ0cmFja1RhYmxlRGF0YSIsInNldFRyYWNrdGFibGVEYXRhIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiZmlsdGVyVHlwZSIsInNldEZpbHRlclR5cGUiLCJzZWxlY3RlZElkIiwic2V0U2VsZWN0ZWRJZCIsInRvZGF5IiwiRGF0ZSIsImZvcm1hdERhdGUiLCJkYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwidG9kYXlTdHIiLCJzZWxlY3RlZEZyb21EYXRlIiwic2V0U2VsZWN0ZWRGcm9tRGF0ZSIsInNlbGVjdGVkRGF0ZSIsInNldFNlbGVjdGVkRGF0ZSIsInNlbGVjdGVkTGFiZWwiLCJzZXRTZWxlY3RlZExhYmVsIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwiZ2V0VG9wRGlzcGxheUZpbHRlciIsImZvdW5kIiwiZmluZCIsImEiLCJfaWQiLCJuYW1lIiwiZGF0ZU9wdGlvbnMiLCJ2YWx1ZSIsImxhYmVsIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsImhhbmRsZVNlbGVjdEZpbHRlciIsImZvcm1hdHRlZCIsInkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInN0YXJ0IiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImVuZCIsImZldGNoQWdlbnQiLCJyZXNwIiwiZ2V0IiwiZGF0YSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImZldGNoUmVwb3J0IiwicGFyYW1zIiwic3RhcnRfZGF0ZSIsImVuZF9kYXRlIiwiYWdlbnRJZCIsInJlc3BvbnNlIiwibWFwIiwiaXRlbSIsImluZGV4Iiwic2xObyIsInVzZXJOYW1lIiwiZnVsbF9uYW1lIiwidXNlclBob25lIiwicGhvbmVfbnVtYmVyIiwicmVmZXJyZWRUeXBlIiwicmVmZXJyYWxfdHlwZSIsInJlZmVycmVkQnkiLCJhZ2VudCIsInRyYWNrQ29sdW1ucyIsImtleSIsImhlYWRlciIsInRvdGFsQ3VzdG9tZXJzIiwibGVuZ3RoIiwicmVmZXJyZWRUeXBlQ291bnQiLCJmb3JFYWNoIiwicmVmZXJyZWRCeUNvdW50IiwiY2FsY3VsYXRlRGF5c0JldHdlZW4iLCJmcm9tRGF0ZSIsInRvRGF0ZSIsImRpZmZUaW1lIiwiTWF0aCIsImFicyIsImRpZmZEYXlzIiwiY2VpbCIsImF2Z0N1c3RvbWVyc1BlckRheSIsInRvRml4ZWQiLCJPYmplY3QiLCJrZXlzIiwiZW50cmllcyIsInNvcnQiLCJiIiwic2xpY2UiLCJjb3VudCIsIndpZHRoIiwic291cmNlIiwib3B0aW9uIiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVXNlclJlZ2lzdHJhdGlvblNvdXJjZVN1bW1hcnlSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIGltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuLy8gaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG4vLyBpbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbi8vIGltcG9ydCBtb21lbnQgZnJvbSBcIm1vbWVudFwiO1xyXG5cclxuLy8gY29uc3QgVXNlclJlZ2lzdHJhdGlvblNvdXJjZVN1bW1hcnlSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW3RyYWNrVGFibGVEYXRhLCBzZXRUcmFja3RhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtmaWx0ZXJUeXBlLCBzZXRGaWx0ZXJUeXBlXSA9IHVzZVN0YXRlKFwiQWxsXCIpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEFnZW50cywgc2V0U2VsZWN0ZWRBZ2VudHNdID0gdXNlU3RhdGUoXCJBbGxcIik7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkSWQsIHNldFNlbGVjdGVkSWRdID0gdXNlU3RhdGUoXCJhbGxcIik7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEFnZW50ID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID1hd2FpdCAgYXBpLmdldChcIi9hZ2VudC9nZXRcIik7XHJcbi8vICAgICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlLCBcImFnZW50ZmRhZGZhZlwiKTtcclxuLy8gICAgICAgICBzZXRBZ2VudHMocmVzcG9uc2U/LmRhdGE/LmFnZW50IHx8IFtdKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwidW5hYmxlIHRvIGZldGNoIGFnZW50c1wiLCBlcnJvcik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaEFnZW50KCk7XHJcbi8vICAgfSwgW10pO1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEVtcGxveWVlID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZVwiKTtcclxuLy8gICAgICAgICBjb25zb2xlLmluZm8ocmVzcG9uc2UsIFwiZW1wbG95ZWVmZGFkZmFmXCIpO1xyXG4vLyAgICAgICAgIHNldEVtcGxveWVlcyhyZXNwb25zZT8uZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJ1bmFibGUgdG8gZmV0Y2ggZW1wbG95ZWVcIiwgZXJyb3IubWVzc2FnZSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaEVtcGxveWVlKCk7XHJcbi8vICAgfSwgW10pO1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaFVzZXJSZWdpc3RyYXRpb25Tb3VyY2VTdW1tYXJ5UmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHBhcmFtcyA9IHt9O1xyXG5cclxuLy8gICAgICAgICBpZiAoZmlsdGVyVHlwZSA9PT0gXCJhZ2VudFwiICYmIHNlbGVjdGVkSWQgIT09IFwiYWxsXCIpIHtcclxuLy8gICAgICAgICAgIHBhcmFtcy5hZ2VudElkID0gc2VsZWN0ZWRJZDtcclxuLy8gICAgICAgICB9XHJcblxyXG4vLyAgICAgICAgIGlmIChmaWx0ZXJUeXBlID09PSBcImVtcGxveWVlXCIgJiYgc2VsZWN0ZWRJZCAhPT0gXCJhbGxcIikge1xyXG4vLyAgICAgICAgICAgcGFyYW1zLmVtcGxveWVlSWQgPSBzZWxlY3RlZElkO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9pbnN0YWxsZWQvYWdlbnRzXCIsIHtwYXJhbXN9KTtcclxuXHJcbi8vICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlPy5kYXRhPy5kYXRhPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAgICAgX2lkOiBpdGVtPy5faWQsXHJcbi8vICAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbi8vICAgICAgICAgICB1c2VyTmFtZTogaXRlbT8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgdXNlclBob25lOiBpdGVtPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZFR5cGU6IGl0ZW0/LnJlZmVycmFsX3R5cGUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZEJ5OiBpdGVtPy5hZ2VudD8ubmFtZSB8fCBpdGVtPy5lbXBsb3llZT8ubmFtZSB8fCBcIkFkbWluXCIsXHJcbi8vICAgICAgICAgfSkpO1xyXG4vLyAgICAgICAgIHNldFRyYWNrdGFibGVEYXRhKGZvcm1hdHRlZERhdGEpO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXHJcbi8vICAgICAgICAgICBcInVuYWJsZSB0byBmZXRjaCB0cmFjayBzb3VyY2Ugb2YgcmVnaXN0cmF0aW9uIG9mIHVzZXJcIixcclxuLy8gICAgICAgICAgIGVycm9yLm1lc3NhZ2VcclxuLy8gICAgICAgICApO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICAgIC8vIH1maW5hbGx5e1xyXG4vLyAgICAgICAvL1xyXG4vLyAgICAgICAvLyB9XHJcbi8vICAgICB9O1xyXG4vLyAgICAgZmV0Y2hVc2VyUmVnaXN0cmF0aW9uU291cmNlU3VtbWFyeVJlcG9ydCgpO1xyXG4vLyAgIH0sIFtmaWx0ZXJUeXBlLCBzZWxlY3RlZElkXSk7XHJcblxyXG4vLyAgIGNvbnN0IHRyYWNrQ29sdW1ucyA9IFtcclxuLy8gICAgIHsga2V5OiBcInNsTm9cIiwgaGVhZGVyOiBcIlNsIE5vXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInJlZmVycmVkVHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJyZWZlcnJlZEJ5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbi8vICAgXTtcclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTNcIj5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMFwiPlxyXG4vLyAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgUmVwb3J0cyDigJR7XCIgXCJ9XHJcbi8vICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDBcIj5Vc2VyIE1vYmlsZSBUcmFja2luZyBSZXBvcnQ8L3NwYW4+XHJcbi8vICAgICAgICAgPC9oMT5cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICB7LyogRmlsdGVycyAqL31cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zIG1iLTVcIj5cclxuLy8gICAgICAgICB7LyogRmlsdGVyIFR5cGUgKi99XHJcbi8vICAgICAgICAgPHNlbGVjdFxyXG4vLyAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuLy8gICAgICAgICAgIHZhbHVlPXtmaWx0ZXJUeXBlfVxyXG4vLyAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgIHNldEZpbHRlclR5cGUoZS50YXJnZXQudmFsdWUpO1xyXG4vLyAgICAgICAgICAgICBzZXRTZWxlY3RlZElkKFwiYWxsXCIpO1xyXG4vLyAgICAgICAgICAgfX1cclxuLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsPC9vcHRpb24+XHJcbi8vICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWdlbnRcIj5BZ2VudDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImVtcGxveWVlXCI+RW1wbG95ZWU8L29wdGlvbj5cclxuLy8gICAgICAgICA8L3NlbGVjdD5cclxuXHJcbi8vICAgICAgICAgey8qIER5bmFtaWMgU2VsZWN0IChBZ2VudCAvIEVtcGxveWVlKSAqL31cclxuLy8gICAgICAgICB7ZmlsdGVyVHlwZSAhPT0gXCJhbGxcIiAmJiAoXHJcbi8vICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiXHJcbi8vICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZElkfVxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkSWQoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsPC9vcHRpb24+XHJcblxyXG4vLyAgICAgICAgICAgICB7ZmlsdGVyVHlwZSA9PT0gXCJhZ2VudFwiICYmXHJcbi8vICAgICAgICAgICAgICAgYWdlbnRzLm1hcCgoYSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2EuX2lkfSB2YWx1ZT17YS5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICB7YS5uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgKSl9XHJcblxyXG4vLyAgICAgICAgICAgICB7ZmlsdGVyVHlwZSA9PT0gXCJlbXBsb3llZVwiICYmXHJcbi8vICAgICAgICAgICAgICAgZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9XHJcbi8vICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgIDwvc2VsZWN0PlxyXG4vLyAgICAgICAgICl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgey8qIFRhYmxlICovfVxyXG4vLyAgICAgICA8RGF0YVRhYmxlIGNvbHVtbnM9e3RyYWNrQ29sdW1uc30gZGF0YT17dHJhY2tUYWJsZURhdGF9IC8+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuLy8gY29uc3QgVXNlclJlZ2lzdHJhdGlvblNvdXJjZVN1bW1hcnlSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW3RyYWNrVGFibGVEYXRhLCBzZXRUcmFja3RhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuLy8gICBjb25zdCBbZmlsdGVyVHlwZSwgc2V0RmlsdGVyVHlwZV0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRJZCwgc2V0U2VsZWN0ZWRJZF0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuXHJcbi8vICAgLy8gRGF0ZSBGaWx0ZXJzXHJcbi8vICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuXHJcbi8vICAgY29uc3QgdG9kYXlTdHJpbmcgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyaW5nKTtcclxuXHJcbi8vICAgY29uc3QgW3NlbGVjdGVkTGFiZWwsIHNldFNlbGVjdGVkTGFiZWxdID0gdXNlU3RhdGUoXCJUb2RheVwiKTtcclxuLy8gICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICBjb25zdCBncm91cE9wdGlvbnMgPSBbXHJcbi8vICAgICB7IHZhbHVlOiBcIlRvZGF5XCIsIGxhYmVsOiBcIlRvZGF5XCIgfSxcclxuLy8gICAgIHsgdmFsdWU6IFwiWWVzdGVyZGF5XCIsIGxhYmVsOiBcIlllc3RlcmRheVwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIlRoaXNNb250aFwiLCBsYWJlbDogXCJUaGlzIE1vbnRoXCIgfSxcclxuLy8gICAgIHsgdmFsdWU6IFwiTGFzdE1vbnRoXCIsIGxhYmVsOiBcIkxhc3QgTW9udGhcIiB9LFxyXG4vLyAgICAgeyB2YWx1ZTogXCJUaGlzWWVhclwiLCBsYWJlbDogXCJUaGlzIFllYXJcIiB9LFxyXG4vLyAgICAgeyB2YWx1ZTogXCJDdXN0b21cIiwgbGFiZWw6IFwiQ3VzdG9tXCIgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcbi8vICAgLy8gQVBQTFkgREFURSBGSUxURVJTXHJcbi8vICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAvL1xyXG4vLyAgIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcbi8vICAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuLy8gICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuXHJcbi8vICAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4vLyAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4vLyAgICAgICB5ZXN0ZXJkYXkuc2V0RGF0ZSh5ZXN0ZXJkYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcbi8vICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUoeWVzdGVyZGF5KTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuLy8gICAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKHRydWUpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gLy9cclxuLy8gICAvLyBGRVRDSCBBR0VOVFMgKyBFTVBMT1lFRVNcclxuLy8gICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEFnZW50ID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXRcIik7XHJcbi8vICAgICAgICAgc2V0QWdlbnRzKHJlc3BvbnNlPy5kYXRhPy5hZ2VudCB8fCBbXSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcInVuYWJsZSB0byBmZXRjaCBhZ2VudHNcIiwgZXJyb3IpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG4vLyAgICAgZmV0Y2hBZ2VudCgpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoRW1wbG95ZWUgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4vLyAgICAgICAgIHNldEVtcGxveWVlcyhyZXNwb25zZT8uZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJ1bmFibGUgdG8gZmV0Y2ggZW1wbG95ZWVcIiwgZXJyb3IpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG4vLyAgICAgZmV0Y2hFbXBsb3llZSgpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAvL1xyXG4vLyAgIC8vIEZFVENIIFVTRVIgTU9CSUxFIFRSQUNLIFJFUE9SVFxyXG4vLyAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gLy9cclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoVXNlclJlZ2lzdHJhdGlvblNvdXJjZVN1bW1hcnlSZXBvcnQgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuLy8gICAgICAgICAgIHN0YXJ0X2RhdGU6IHNlbGVjdGVkRnJvbURhdGUsXHJcbi8vICAgICAgICAgICBlbmRfZGF0ZTogc2VsZWN0ZWREYXRlLFxyXG4vLyAgICAgICAgIH07XHJcblxyXG4vLyAgICAgICAgIGlmIChmaWx0ZXJUeXBlID09PSBcImFnZW50XCIgJiYgc2VsZWN0ZWRJZCAhPT0gXCJhbGxcIikge1xyXG4vLyAgICAgICAgICAgcGFyYW1zLmFnZW50SWQgPSBzZWxlY3RlZElkO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgICBpZiAoZmlsdGVyVHlwZSA9PT0gXCJlbXBsb3llZVwiICYmIHNlbGVjdGVkSWQgIT09IFwiYWxsXCIpIHtcclxuLy8gICAgICAgICAgIHBhcmFtcy5lbXBsb3llZUlkID0gc2VsZWN0ZWRJZDtcclxuLy8gICAgICAgICB9XHJcblxyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2luc3RhbGxlZC9hZ2VudHNcIiwgeyBwYXJhbXMgfSk7XHJcblxyXG4vLyAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZT8uZGF0YT8uZGF0YT8ubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuLy8gICAgICAgICAgIF9pZDogaXRlbT8uX2lkLFxyXG4vLyAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4vLyAgICAgICAgICAgdXNlck5hbWU6IGl0ZW0/LmZ1bGxfbmFtZSB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIHVzZXJQaG9uZTogaXRlbT8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgcmVmZXJyZWRUeXBlOiBpdGVtPy5yZWZlcnJhbF90eXBlIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgcmVmZXJyZWRCeTogaXRlbT8uYWdlbnQ/Lm5hbWUgfHwgaXRlbT8uZW1wbG95ZWU/Lm5hbWUgfHwgXCJBZG1pblwiLFxyXG4vLyAgICAgICAgIH0pKTtcclxuXHJcbi8vICAgICAgICAgc2V0VHJhY2t0YWJsZURhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcInVuYWJsZSB0byBmZXRjaCB0cmFjayBzb3VyY2Ugb2YgcmVnaXN0cmF0aW9uXCIsIGVycm9yKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuXHJcbi8vICAgICBmZXRjaFVzZXJSZWdpc3RyYXRpb25Tb3VyY2VTdW1tYXJ5UmVwb3J0KCk7XHJcbi8vICAgfSwgW2ZpbHRlclR5cGUsIHNlbGVjdGVkSWQsIHNlbGVjdGVkRnJvbURhdGUsIHNlbGVjdGVkRGF0ZV0pO1xyXG5cclxuLy8gICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcbi8vICAgLy8gVEFCTEUgQ09MVU1OU1xyXG4vLyAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gLy9cclxuXHJcbi8vICAgY29uc3QgdHJhY2tDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIk5hbWVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVmZXJyZWRUeXBlXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBUeXBlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInJlZmVycmVkQnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcbi8vICAgLy8gVUkgUkVUVVJOXHJcbi8vICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAvL1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTNcIj5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMFwiPlxyXG4vLyAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgUmVwb3J0cyDigJQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwXCI+VXNlciBNb2JpbGUgVHJhY2tpbmcgUmVwb3J0PC9zcGFuPlxyXG4vLyAgICAgICAgIDwvaDE+XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgey8qIEZJTFRFUlMgKi99XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBtYi01IGl0ZW1zLWNlbnRlclwiPlxyXG5cclxuLy8gICAgICAgICB7LyogVFlQRSBGSUxURVIgKi99XHJcbi8vICAgICAgICAgPHNlbGVjdFxyXG4vLyAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtNiByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgIHZhbHVlPXtmaWx0ZXJUeXBlfVxyXG4vLyAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgIHNldEZpbHRlclR5cGUoZS50YXJnZXQudmFsdWUpO1xyXG4vLyAgICAgICAgICAgICBzZXRTZWxlY3RlZElkKFwiYWxsXCIpO1xyXG4vLyAgICAgICAgICAgfX1cclxuLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsPC9vcHRpb24+XHJcbi8vICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWdlbnRcIj5BZ2VudDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImVtcGxveWVlXCI+RW1wbG95ZWU8L29wdGlvbj5cclxuLy8gICAgICAgICA8L3NlbGVjdD5cclxuXHJcbi8vICAgICAgICAgey8qIEFHRU5UIC8gRU1QTE9ZRUUgRFJPUERPV04gKi99XHJcbi8vICAgICAgICAge2ZpbHRlclR5cGUgIT09IFwiYWxsXCIgJiYgKFxyXG4vLyAgICAgICAgICAgPHNlbGVjdFxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgIHJvdW5kZWQtbWQgcC02XCJcclxuLy8gICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkSWR9XHJcbi8vICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRJZChlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhbGxcIj5BbGw8L29wdGlvbj5cclxuXHJcbi8vICAgICAgICAgICAgIHtmaWx0ZXJUeXBlID09PSBcImFnZW50XCIgJiZcclxuLy8gICAgICAgICAgICAgICBhZ2VudHMubWFwKChhKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17YS5faWR9IHZhbHVlPXthLl9pZH0+e2EubmFtZX08L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICApKX1cclxuXHJcbi8vICAgICAgICAgICAgIHtmaWx0ZXJUeXBlID09PSBcImVtcGxveWVlXCIgJiZcclxuLy8gICAgICAgICAgICAgICBlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuLy8gICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+e2VtcC5uYW1lfTwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgPC9zZWxlY3Q+XHJcbi8vICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgey8qIERBVEUgRklMVEVSICovfVxyXG4vLyAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTYgcm91bmRlZC1tZFwiXHJcbi8vICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuLy8gICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VsZWN0RmlsdGVyKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgobykgPT4gKFxyXG4vLyAgICAgICAgICAgICA8b3B0aW9uIGtleT17by52YWx1ZX0gdmFsdWU9e28udmFsdWV9PntvLmxhYmVsfTwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4vLyAgICAgICAgIHsvKiBDVVNUT00gREFURSBSQU5HRSAqL31cclxuLy8gICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuLy8gICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEZyb21EYXRlfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgIC8+XHJcblxyXG4vLyAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXRlfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDwvPlxyXG4vLyAgICAgICAgICl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgey8qIFRBQkxFICovfVxyXG4vLyAgICAgICA8RGF0YVRhYmxlIGNvbHVtbnM9e3RyYWNrQ29sdW1uc30gZGF0YT17dHJhY2tUYWJsZURhdGF9IC8+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuLy8gY29uc3QgVXNlclJlZ2lzdHJhdGlvblNvdXJjZVN1bW1hcnlSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW3RyYWNrVGFibGVEYXRhLCBzZXRUcmFja3RhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuLy8gICBjb25zdCBbZmlsdGVyVHlwZSwgc2V0RmlsdGVyVHlwZV0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRJZCwgc2V0U2VsZWN0ZWRJZF0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuXHJcbi8vICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAvL1xyXG4vLyAgIC8vIERBVEUgRklMVEVSU1xyXG4vLyAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gLy9cclxuLy8gICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbi8vICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpOyAvLyBSZXR1cm5zIFlZWVktTU0tRERcclxuXHJcbi8vICAgY29uc3QgdG9kYXlTdHIgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cik7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyKTtcclxuXHJcbi8vICAgY29uc3QgW3NlbGVjdGVkTGFiZWwsIHNldFNlbGVjdGVkTGFiZWxdID0gdXNlU3RhdGUoXCJUb2RheVwiKTtcclxuLy8gICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICBjb25zdCBkYXRlT3B0aW9ucyA9IFtcclxuLy8gICAgIHsgdmFsdWU6IFwiVG9kYXlcIiwgbGFiZWw6IFwiVG9kYXlcIiB9LFxyXG4vLyAgICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIgfSxcclxuLy8gICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4vLyAgICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcbi8vICAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuLy8gICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuXHJcbi8vICAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4vLyAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgeSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuLy8gICAgICAgeS5zZXREYXRlKHkuZ2V0RGF0ZSgpIC0gMSk7XHJcbi8vICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUoeSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdHRlZCk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbi8vICAgICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcbi8vICAgLy8gRkVUQ0ggQUdFTlRTXHJcbi8vICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAvL1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEFnZW50ID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1hZ2VudFwiKTtcclxuLy8gICAgICAgICBzZXRBZ2VudHMocmVzcD8uZGF0YSB8fCBbXSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJVbmFibGUgdG8gZmV0Y2ggYWdlbnRzXCIsIGVycik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaEFnZW50KCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcbi8vICAgLy8gRkVUQ0ggVVNFUiBUUkFDS0lORyBSRVBPUlRcclxuLy8gICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcbi8vICAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAvLyAgIGNvbnN0IGZldGNoUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgIC8vICAgICB0cnkge1xyXG4vLyAgIC8vICAgICAgIC8vIEJ1aWxkIHBhcmFtcyBvYmplY3RcclxuLy8gICAvLyAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4vLyAgIC8vICAgICAgICAgc3RhcnRfZGF0ZTogc2VsZWN0ZWRGcm9tRGF0ZSxcclxuLy8gICAvLyAgICAgICAgIGVuZF9kYXRlOiBzZWxlY3RlZERhdGUsXHJcbi8vICAgLy8gICAgICAgfTtcclxuXHJcbi8vICAgLy8gICAgICAgLy8gQWRkIGFnZW50IGZpbHRlciBpZiBhcHBsaWNhYmxlXHJcbi8vICAgLy8gICAgICAgaWYgKGZpbHRlclR5cGUgPT09IFwiYWdlbnRcIiAmJiBzZWxlY3RlZElkICE9PSBcImFsbFwiKSB7XHJcbi8vICAgLy8gICAgICAgICBwYXJhbXMuYWdlbnRJZCA9IHNlbGVjdGVkSWQ7XHJcbi8vICAgLy8gICAgICAgfVxyXG5cclxuLy8gICAvLyAgICAgICBjb25zb2xlLmxvZyhcIkZldGNoaW5nIHJlcG9ydCB3aXRoIHBhcmFtczpcIiwgcGFyYW1zKTsgLy8gRGVidWcgbG9nXHJcblxyXG4vLyAgIC8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2luc3RhbGxlZC9hZ2VudHNcIiwgeyBwYXJhbXMgfSk7XHJcblxyXG4vLyAgIC8vICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJlc3BvbnNlPy5kYXRhPy5kYXRhPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4vLyAgIC8vICAgICAgICAgX2lkOiBpdGVtPy5faWQsXHJcbi8vICAgLy8gICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbi8vICAgLy8gICAgICAgICB1c2VyTmFtZTogaXRlbT8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgICAgdXNlclBob25lOiBpdGVtPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbi8vICAgLy8gICAgICAgICByZWZlcnJlZFR5cGU6IGl0ZW0/LnJlZmVycmFsX3R5cGUgfHwgXCItXCIsXHJcbi8vICAgLy8gICAgICAgICByZWZlcnJlZEJ5OlxyXG4vLyAgIC8vICAgICAgICAgICBpdGVtPy5hZ2VudD8ubmFtZSB8fCBcIkFkbWluXCIsXHJcbi8vICAgLy8gICAgICAgfSkpO1xyXG5cclxuLy8gICAvLyAgICAgICBzZXRUcmFja3RhYmxlRGF0YShmb3JtYXR0ZWQpO1xyXG4vLyAgIC8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAvLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcmVwb3J0XCIsIGVycik7XHJcbi8vICAgLy8gICAgIH1cclxuLy8gICAvLyAgIH07XHJcblxyXG4vLyAgIC8vICAgZmV0Y2hSZXBvcnQoKTtcclxuLy8gICAvLyB9LCBbZmlsdGVyVHlwZSwgc2VsZWN0ZWRJZCwgc2VsZWN0ZWRGcm9tRGF0ZSwgc2VsZWN0ZWREYXRlXSk7XHJcblxyXG4vLyAgICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIC8vIEJ1aWxkIHBhcmFtcyBvYmplY3Qgd2l0aCBvbmx5IHRoZSBkYXRlIGZpbHRlcnMgaW5pdGlhbGx5XHJcbi8vICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuLy8gICAgICAgICAgIHN0YXJ0X2RhdGU6IHNlbGVjdGVkRnJvbURhdGUsXHJcbi8vICAgICAgICAgICBlbmRfZGF0ZTogc2VsZWN0ZWREYXRlLFxyXG4vLyAgICAgICAgIH07XHJcblxyXG4vLyAgICAgICAgIC8vIEFkZCBhZ2VudCBmaWx0ZXIgb25seSBpZiBmaWx0ZXJUeXBlIGlzIFwiYWdlbnRcIiBhbmQgYSBzcGVjaWZpYyBhZ2VudCBpcyBzZWxlY3RlZFxyXG4vLyAgICAgICAgIGlmIChmaWx0ZXJUeXBlID09PSBcImFnZW50XCIgJiYgc2VsZWN0ZWRJZCAhPT0gXCJhbGxcIikge1xyXG4vLyAgICAgICAgICAgcGFyYW1zLmFnZW50SWQgPSBzZWxlY3RlZElkO1xyXG4vLyAgICAgICAgIH1cclxuXHJcbi8vICAgICAgICAgY29uc29sZS5sb2coXCJGZXRjaGluZyByZXBvcnQgd2l0aCBwYXJhbXM6XCIsIHBhcmFtcyk7IC8vIERlYnVnIGxvZ1xyXG5cclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9pbnN0YWxsZWQvYWdlbnRzXCIsIHsgcGFyYW1zIH0pO1xyXG5cclxuLy8gICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSByZXNwb25zZT8uZGF0YT8uZGF0YT8ubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuLy8gICAgICAgICAgIF9pZDogaXRlbT8uX2lkLFxyXG4vLyAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4vLyAgICAgICAgICAgdXNlck5hbWU6IGl0ZW0/LmZ1bGxfbmFtZSB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIHVzZXJQaG9uZTogaXRlbT8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgcmVmZXJyZWRUeXBlOiBpdGVtPy5yZWZlcnJhbF90eXBlIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgcmVmZXJyZWRCeTpcclxuLy8gICAgICAgICAgICAgaXRlbT8uYWdlbnQ/Lm5hbWUgfHwgXCJBZG1pblwiLFxyXG4vLyAgICAgICAgIH0pKTtcclxuXHJcbi8vICAgICAgICAgc2V0VHJhY2t0YWJsZURhdGEoZm9ybWF0dGVkKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHJlcG9ydFwiLCBlcnIpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG5cclxuLy8gICAgIGZldGNoUmVwb3J0KCk7XHJcbi8vICAgfSwgW2ZpbHRlclR5cGUsIHNlbGVjdGVkSWQsIHNlbGVjdGVkRnJvbURhdGUsIHNlbGVjdGVkRGF0ZV0pO1xyXG5cclxuLy8gICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcbi8vICAgLy8gVEFCTEUgQ09MVU1OU1xyXG4vLyAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gLy9cclxuLy8gICBjb25zdCB0cmFja0NvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJzbE5vXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ1c2VyUGhvbmVcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbi8vICAgICB7IGtleTogXCJyZWZlcnJlZFR5cGVcIiwgaGVhZGVyOiBcIlJlZmVycmVkIFR5cGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVmZXJyZWRCeVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gLy9cclxuLy8gICAvLyBVSSBSRVRVUk5cclxuLy8gICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtM1wiPlxyXG4vLyAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItOFwiPlxyXG4vLyAgICAgICAgIFJlcG9ydHMg4oCUIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMFwiPlVzZXIgTW9iaWxlIFRyYWNraW5nIFJlcG9ydDwvc3Bhbj5cclxuLy8gICAgICAgPC9oMT5cclxuXHJcbi8vICAgICAgIHsvKiBGSUxURVJTICovfVxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTMgbWItNiBpdGVtcy1jZW50ZXJcIj5cclxuLy8gICAgICAgICB7LyogVFlQRSBGSUxURVIgKi99XHJcbi8vICAgICAgICAgPHNlbGVjdFxyXG4vLyAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgIHZhbHVlPXtmaWx0ZXJUeXBlfVxyXG4vLyAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgIHNldEZpbHRlclR5cGUoZS50YXJnZXQudmFsdWUpO1xyXG4vLyAgICAgICAgICAgICBzZXRTZWxlY3RlZElkKFwiYWxsXCIpO1xyXG4vLyAgICAgICAgICAgfX1cclxuLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsPC9vcHRpb24+XHJcbi8vICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWdlbnRcIj5FbXBsb3llZTwvb3B0aW9uPlxyXG4vLyAgICAgICAgIDwvc2VsZWN0PlxyXG5cclxuLy8gICAgICAgICB7LyogQUdFTlQgRklMVEVSICovfVxyXG4vLyAgICAgICAgIHtmaWx0ZXJUeXBlICE9PSBcImFsbFwiICYmIChcclxuLy8gICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkSWR9XHJcbi8vICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRJZChlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhbGxcIj5BbGw8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAge2FnZW50cy5tYXAoKGEpID0+IChcclxuLy8gICAgICAgICAgICAgICA8b3B0aW9uIGtleT17YS5faWR9IHZhbHVlPXthLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICB7YS5uYW1lfSB8IHthLnBob25lX251bWJlcn1cclxuLy8gICAgICAgICAgICAgICA8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICB7LyogREFURSBGSUxURVIgKi99XHJcbi8vICAgICAgICAgPHNlbGVjdFxyXG4vLyAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExhYmVsfVxyXG4vLyAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVTZWxlY3RGaWx0ZXIoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgID5cclxuLy8gICAgICAgICAgIHtkYXRlT3B0aW9ucy5tYXAoKG8pID0+IChcclxuLy8gICAgICAgICAgICAgPG9wdGlvbiBrZXk9e28udmFsdWV9IHZhbHVlPXtvLnZhbHVlfT5cclxuLy8gICAgICAgICAgICAgICB7by5sYWJlbH1cclxuLy8gICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICApKX1cclxuLy8gICAgICAgICA8L3NlbGVjdD5cclxuXHJcbi8vICAgICAgICAgey8qIENVU1RPTSBEQVRFIFJBTkdFICovfVxyXG4vLyAgICAgICAgIHtzaG93RmlsdGVyRmllbGQgJiYgKFxyXG4vLyAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZFwiXHJcbi8vICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgLz5cclxuXHJcbi8vICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGV9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgPC8+XHJcbi8vICAgICAgICAgKX1cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICB7LyogVEFCTEUgKi99XHJcbi8vICAgICAgIDxEYXRhVGFibGUgY29sdW1ucz17dHJhY2tDb2x1bW5zfSBkYXRhPXt0cmFja1RhYmxlRGF0YX0gLz5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBTZXR0aW5nU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NldHRpbmdTaWRlYmFyXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IG1vbWVudCBmcm9tIFwibW9tZW50XCI7XHJcbmltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG4vLyBjb25zdCBVc2VyUmVnaXN0cmF0aW9uU291cmNlU3VtbWFyeVJlcG9ydCA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbdHJhY2tUYWJsZURhdGEsIHNldFRyYWNrdGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuLy8gICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbi8vICAgICB0eXBlOiBcImluZm9cIixcclxuLy8gICB9KTtcclxuXHJcbi8vICAgLy8gRmlsdGVyIHN0YXRlc1xyXG4vLyAgIGNvbnN0IFtmaWx0ZXJUeXBlLCBzZXRGaWx0ZXJUeXBlXSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZElkLCBzZXRTZWxlY3RlZElkXSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xyXG4vLyAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuLy8gICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7IC8vIFJldHVybnMgWVlZWS1NTS1ERFxyXG4vLyAgIGNvbnN0IHRvZGF5U3RyID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUodG9kYXlTdHIpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cik7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkTGFiZWwsIHNldFNlbGVjdGVkTGFiZWxdID0gdXNlU3RhdGUoXCJUb2RheVwiKTtcclxuLy8gICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICBjb25zdCBkYXRlT3B0aW9ucyA9IFtcclxuLy8gICAgIHsgdmFsdWU6IFwiVG9kYXlcIiwgbGFiZWw6IFwiVG9kYXlcIiB9LFxyXG4vLyAgICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIgfSxcclxuLy8gICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4vLyAgICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbi8vICAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuLy8gICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcbi8vICAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuLy8gICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuXHJcbi8vICAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4vLyAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgeSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuLy8gICAgICAgeS5zZXREYXRlKHkuZ2V0RGF0ZSgpIC0gMSk7XHJcbi8vICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUoeSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdHRlZCk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbi8vICAgICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBGZXRjaCBhZ2VudHNcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hBZ2VudCA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXNwID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXQtYWdlbnRcIik7XHJcbi8vICAgICAgICAgc2V0QWdlbnRzKHJlc3A/LmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5hYmxlIHRvIGZldGNoIGFnZW50c1wiLCBlcnIpO1xyXG4vLyAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuLy8gICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbi8vICAgICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBmZXRjaCBhZ2VudHNcIixcclxuLy8gICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuLy8gICAgIGZldGNoQWdlbnQoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8vIEZldGNoIHVzZXIgdHJhY2tpbmcgcmVwb3J0XHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbi8vICAgICAgICAgLy8gQnVpbGQgcGFyYW1zIG9iamVjdCB3aXRoIG9ubHkgdGhlIGRhdGUgZmlsdGVycyBpbml0aWFsbHlcclxuLy8gICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4vLyAgICAgICAgICAgc3RhcnRfZGF0ZTogc2VsZWN0ZWRGcm9tRGF0ZSxcclxuLy8gICAgICAgICAgIGVuZF9kYXRlOiBzZWxlY3RlZERhdGUsXHJcbi8vICAgICAgICAgfTtcclxuXHJcbi8vICAgICAgICAgLy8gQWRkIGFnZW50IGZpbHRlciBvbmx5IGlmIGZpbHRlclR5cGUgaXMgXCJhZ2VudFwiIGFuZCBhIHNwZWNpZmljIGFnZW50IGlzIHNlbGVjdGVkXHJcbi8vICAgICAgICAgaWYgKGZpbHRlclR5cGUgPT09IFwiYWdlbnRcIiAmJiBzZWxlY3RlZElkICE9PSBcImFsbFwiKSB7XHJcbi8vICAgICAgICAgICBwYXJhbXMuYWdlbnRJZCA9IHNlbGVjdGVkSWQ7XHJcbi8vICAgICAgICAgfVxyXG5cclxuLy8gICAgICAgICBjb25zb2xlLmxvZyhcIkZldGNoaW5nIHJlcG9ydCB3aXRoIHBhcmFtczpcIiwgcGFyYW1zKTsgLy8gRGVidWcgbG9nXHJcblxyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2luc3RhbGxlZC9hZ2VudHNcIiwgeyBwYXJhbXMgfSk7XHJcblxyXG4vLyAgICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJlc3BvbnNlPy5kYXRhPy5kYXRhPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAgICAgX2lkOiBpdGVtPy5faWQsXHJcbi8vICAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbi8vICAgICAgICAgICB1c2VyTmFtZTogaXRlbT8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgdXNlclBob25lOiBpdGVtPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZFR5cGU6IGl0ZW0/LnJlZmVycmFsX3R5cGUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZEJ5OiBpdGVtPy5hZ2VudD8ubmFtZSB8fCBcIkFkbWluXCIsXHJcbi8vICAgICAgICAgfSkpO1xyXG5cclxuLy8gICAgICAgICBzZXRUcmFja3RhYmxlRGF0YShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcmVwb3J0XCIsIGVycik7XHJcbi8vICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4vLyAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuLy8gICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIHVzZXIgdHJhY2tpbmcgcmVwb3J0XCIsXHJcbi8vICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuXHJcbi8vICAgICBmZXRjaFJlcG9ydCgpO1xyXG4vLyAgIH0sIFtmaWx0ZXJUeXBlLCBzZWxlY3RlZElkLCBzZWxlY3RlZEZyb21EYXRlLCBzZWxlY3RlZERhdGVdKTtcclxuXHJcbi8vICAgLy8gVGFibGUgY29sdW1uc1xyXG4vLyAgIGNvbnN0IHRyYWNrQ29sdW1ucyA9IFtcclxuLy8gICAgIHsga2V5OiBcInNsTm9cIiwgaGVhZGVyOiBcIlNsIE5vXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInJlZmVycmVkVHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJyZWZlcnJlZEJ5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDw+XHJcbi8vICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbi8vICAgICAgICAgICA8TmF2YmFyXHJcbi8vICAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4vLyAgICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4vLyAgICAgICAgICAgLz5cclxuXHJcbi8vICAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuLy8gICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuLy8gICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4vLyAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4vLyAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4vLyAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuLy8gICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgUmVwb3J0cyDigJR7XCIgXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFVzZXIgTW9iaWxlIFRyYWNraW5nIFJlcG9ydFxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2gxPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBtYi02IGl0ZW1zLWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgIHsvKiBUWVBFIEZJTFRFUiAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHctNDhcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVyVHlwZX1cclxuLy8gICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRmlsdGVyIFR5cGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2V0RmlsdGVyVHlwZSh2YWx1ZSk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJZChcImFsbFwiKTtcclxuLy8gICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJhbGxcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiYWdlbnRcIj5FbXBsb3llZTwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogQUdFTlQgRklMVEVSICovfVxyXG4vLyAgICAgICAgICAgICAgIHtmaWx0ZXJUeXBlID09PSBcImFnZW50XCIgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB3LTY0XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBBZ2VudFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRJZCAhPT0gXCJhbGxcIiA/IHNlbGVjdGVkSWQgOiB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0U2VsZWN0ZWRJZCh2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImFsbFwiPkFsbCBBZ2VudHM8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2FnZW50Ll9pZH0gdmFsdWU9e2FnZW50Ll9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfSB8IHthZ2VudC5waG9uZV9udW1iZXJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIERBVEUgRklMVEVSICovfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdy00OFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExhYmVsfVxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBEYXRlIFJhbmdlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlU2VsZWN0RmlsdGVyKHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAge2RhdGVPcHRpb25zLm1hcCgob3B0aW9uKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtvcHRpb24udmFsdWV9IHZhbHVlPXtvcHRpb24udmFsdWV9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBDVVNUT00gREFURSBSQU5HRSAqL31cclxuLy8gICAgICAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIGgtMTAgcC0yLjVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEZyb21EYXRlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBoLTEwIHAtMi41XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXRlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvPlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAge3RyYWNrVGFibGVEYXRhICYmICFpc0xvYWRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgPERhdGFUYWJsZSBkYXRhPXt0cmFja1RhYmxlRGF0YX0gY29sdW1ucz17dHJhY2tDb2x1bW5zfSAvPlxyXG4vLyAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4vLyAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbi8vICAgICAgICAgICAgICAgICBmYWlsdXJlPXt0cmFja1RhYmxlRGF0YS5sZW5ndGggPD0gMH1cclxuLy8gICAgICAgICAgICAgICAgIGRhdGE9XCJ1c2VyIHRyYWNraW5nIGRhdGFcIlxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8Lz5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuLy8gY29uc3QgVXNlclJlZ2lzdHJhdGlvblNvdXJjZVN1bW1hcnlSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW3RyYWNrVGFibGVEYXRhLCBzZXRUcmFja3RhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4vLyAgICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbi8vICAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4vLyAgICAgdHlwZTogXCJpbmZvXCIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIC8vIEZpbHRlciBzdGF0ZXNcclxuLy8gICBjb25zdCBbZmlsdGVyVHlwZSwgc2V0RmlsdGVyVHlwZV0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRJZCwgc2V0U2VsZWN0ZWRJZF0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuLy8gICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbi8vICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG4vLyAgIGNvbnN0IHRvZGF5U3RyID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUodG9kYXlTdHIpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cik7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkTGFiZWwsIHNldFNlbGVjdGVkTGFiZWxdID0gdXNlU3RhdGUoXCJUb2RheVwiKTtcclxuLy8gICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICAvLyBEaXNwbGF5IGFnZW50L2VtcGxveWVlIG5hbWUgb24gdG9wXHJcbi8vICAgY29uc3QgZ2V0VG9wRGlzcGxheUZpbHRlciA9ICgpID0+IHtcclxuLy8gICAgIGlmIChmaWx0ZXJUeXBlID09PSBcImFnZW50XCIpIHtcclxuLy8gICAgICAgaWYgKHNlbGVjdGVkSWQgPT09IFwiYWxsXCIpIHJldHVybiBcIkFsbCBFbXBsb3llZXNcIjtcclxuXHJcbi8vICAgICAgIGNvbnN0IGZvdW5kID0gYWdlbnRzLmZpbmQoKGEpID0+IGEuX2lkID09PSBzZWxlY3RlZElkKTtcclxuLy8gICAgICAgcmV0dXJuIGZvdW5kID8gZm91bmQubmFtZSA6IFwiRW1wbG95ZWVcIjtcclxuLy8gICAgIH1cclxuLy8gICAgIHJldHVybiBcIkFsbFwiO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGRhdGVPcHRpb25zID0gW1xyXG4vLyAgICAgeyB2YWx1ZTogXCJUb2RheVwiLCBsYWJlbDogXCJUb2RheVwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIlllc3RlcmRheVwiLCBsYWJlbDogXCJZZXN0ZXJkYXlcIiB9LFxyXG4vLyAgICAgeyB2YWx1ZTogXCJUaGlzTW9udGhcIiwgbGFiZWw6IFwiVGhpcyBNb250aFwiIH0sXHJcbi8vICAgICB7IHZhbHVlOiBcIkxhc3RNb250aFwiLCBsYWJlbDogXCJMYXN0IE1vbnRoXCIgfSxcclxuLy8gICAgIHsgdmFsdWU6IFwiVGhpc1llYXJcIiwgbGFiZWw6IFwiVGhpcyBZZWFyXCIgfSxcclxuLy8gICAgIHsgdmFsdWU6IFwiQ3VzdG9tXCIsIGxhYmVsOiBcIkN1c3RvbVwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuLy8gICAgIHNldFNlbGVjdGVkTGFiZWwodmFsdWUpO1xyXG4vLyAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKGZhbHNlKTtcclxuXHJcbi8vICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcblxyXG4vLyAgICAgaWYgKHZhbHVlID09PSBcIlRvZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0dGVkKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdHRlZCk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbi8vICAgICAgIHkuc2V0RGF0ZSh5LmdldERhdGUoKSAtIDEpO1xyXG4vLyAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdE1vbnRoXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpIC0gMSwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDApO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAwLCAxKTtcclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMTEsIDMxKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4vLyAgICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gRmV0Y2ggYWdlbnRzXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoQWdlbnQgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpO1xyXG4vLyAgICAgICAgIHNldEFnZW50cyhyZXNwPy5kYXRhIHx8IFtdKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcIlVuYWJsZSB0byBmZXRjaCBhZ2VudHNcIiwgZXJyKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuLy8gICAgIGZldGNoQWdlbnQoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8vIEZldGNoIHJlcG9ydFxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaFJlcG9ydCA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4vLyAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbi8vICAgICAgICAgICBzdGFydF9kYXRlOiBzZWxlY3RlZEZyb21EYXRlLFxyXG4vLyAgICAgICAgICAgZW5kX2RhdGU6IHNlbGVjdGVkRGF0ZSxcclxuLy8gICAgICAgICB9O1xyXG5cclxuLy8gICAgICAgICBpZiAoZmlsdGVyVHlwZSA9PT0gXCJhZ2VudFwiICYmIHNlbGVjdGVkSWQgIT09IFwiYWxsXCIpIHtcclxuLy8gICAgICAgICAgIHBhcmFtcy5hZ2VudElkID0gc2VsZWN0ZWRJZDtcclxuLy8gICAgICAgICB9XHJcblxyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2luc3RhbGxlZC9hZ2VudHNcIiwgeyBwYXJhbXMgfSk7XHJcblxyXG4vLyAgICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJlc3BvbnNlPy5kYXRhPy5kYXRhPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAgICAgX2lkOiBpdGVtPy5faWQsXHJcbi8vICAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbi8vICAgICAgICAgICB1c2VyTmFtZTogaXRlbT8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgdXNlclBob25lOiBpdGVtPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZFR5cGU6IGl0ZW0/LnJlZmVycmFsX3R5cGUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZEJ5OiBpdGVtPy5hZ2VudD8ubmFtZSB8fCBcIkFkbWluXCIsXHJcbi8vICAgICAgICAgfSkpO1xyXG5cclxuLy8gICAgICAgICBzZXRUcmFja3RhYmxlRGF0YShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcmVwb3J0XCIsIGVycik7XHJcbi8vICAgICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuXHJcbi8vICAgICBmZXRjaFJlcG9ydCgpO1xyXG4vLyAgIH0sIFtmaWx0ZXJUeXBlLCBzZWxlY3RlZElkLCBzZWxlY3RlZEZyb21EYXRlLCBzZWxlY3RlZERhdGVdKTtcclxuXHJcbi8vICAgLy8gVGFibGUgY29sdW1uc1xyXG4vLyAgIGNvbnN0IHRyYWNrQ29sdW1ucyA9IFtcclxuLy8gICAgIHsga2V5OiBcInNsTm9cIiwgaGVhZGVyOiBcIlNsIE5vXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInJlZmVycmVkVHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJyZWZlcnJlZEJ5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDw+XHJcbi8vICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbi8vICAgICAgICAgICA8TmF2YmFyXHJcbi8vICAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4vLyAgICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4vLyAgICAgICAgICAgLz5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuLy8gICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgUmVwb3J0cyDigJR7XCIgXCJ9XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgVXNlciBNb2JpbGUgVHJhY2tpbmcgUmVwb3J0XHJcbi8vICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgPC9oMT5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogVE9QIENVU1RPTUVSIENPVU5UIEJBUiAqL31cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01IHAtNCBiZy12aW9sZXQtNTAgYm9yZGVyIGJvcmRlci12aW9sZXQtMzAwIHJvdW5kZWQtbGdcIj5cclxuLy8gICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgVG90YWwgQ3VzdG9tZXJzIEFkZGVkOiB7dHJhY2tUYWJsZURhdGEubGVuZ3RofXtcIiBcIn1cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDAgdGV4dC1sZ1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAoe2dldFRvcERpc3BsYXlGaWx0ZXIoKX0pXHJcbi8vICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgPC9oMj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTYgbWItNiBpdGVtcy1lbmRcIj5cclxuLy8gICAgICAgICAgICAgICB7LyogREFURSBGSUxURVIgKi99XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+RGF0ZSBGaWx0ZXI8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdy00OFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExhYmVsfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZVNlbGVjdEZpbHRlcih2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7ZGF0ZU9wdGlvbnMubWFwKChvcHRpb24pID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17b3B0aW9uLnZhbHVlfSB2YWx1ZT17b3B0aW9uLnZhbHVlfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIENVU1RPTSBEQVRFIFJBTkdFICovfVxyXG4vLyAgICAgICAgICAgICAgIHtzaG93RmlsdGVyRmllbGQgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zIGl0ZW1zLWVuZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+RnJvbTwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgaC0xMCBwLTIuNVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRGcm9tRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+VG88L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGgtMTAgcC0yLjVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBFTVBMT1lFRSBGSUxURVIgVFlQRSAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgRW1wbG95ZWUgRmlsdGVyXHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdy00OFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJUeXBlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHNldEZpbHRlclR5cGUodmFsdWUpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJZChcImFsbFwiKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJhbGxcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJhZ2VudFwiPkVtcGxveWVlPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogRU1QTE9ZRUUgRFJPUERPV04gKFZJU0lCTEUgT05MWSBJRiBFbXBsb3llZSBmaWx0ZXIgc2VsZWN0ZWQpICovfVxyXG4vLyAgICAgICAgICAgICAgIHtmaWx0ZXJUeXBlID09PSBcImFnZW50XCIgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBTZWxlY3QgRW1wbG95ZWVcclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdy02NFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEVtcGxveWVlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRJZCAhPT0gXCJhbGxcIiA/IHNlbGVjdGVkSWQgOiB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRTZWxlY3RlZElkKHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImFsbFwiPkFsbCBFbXBsb3llZXM8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfSB8IHthZ2VudC5waG9uZV9udW1iZXJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIFRBQkxFICovfVxyXG4vLyAgICAgICAgICAgICB7dHJhY2tUYWJsZURhdGEgJiYgIWlzTG9hZGluZyA/IChcclxuLy8gICAgICAgICAgICAgICA8RGF0YVRhYmxlIGRhdGE9e3RyYWNrVGFibGVEYXRhfSBjb2x1bW5zPXt0cmFja0NvbHVtbnN9IC8+XHJcbi8vICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbi8vICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuLy8gICAgICAgICAgICAgICAgIGZhaWx1cmU9e3RyYWNrVGFibGVEYXRhLmxlbmd0aCA8PSAwfVxyXG4vLyAgICAgICAgICAgICAgICAgZGF0YT1cInVzZXIgdHJhY2tpbmcgZGF0YVwiXHJcbi8vICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvPlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG5jb25zdCBVc2VyUmVnaXN0cmF0aW9uU291cmNlU3VtbWFyeVJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbdHJhY2tUYWJsZURhdGEsIHNldFRyYWNrdGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgLy8gRmlsdGVyIHN0YXRlc1xyXG4gIGNvbnN0IFtmaWx0ZXJUeXBlLCBzZXRGaWx0ZXJUeXBlXSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZElkLCBzZXRTZWxlY3RlZElkXSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcbiAgY29uc3QgdG9kYXlTdHIgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cik7XHJcbiAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyKTtcclxuICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIlRvZGF5XCIpO1xyXG4gIGNvbnN0IFtzaG93RmlsdGVyRmllbGQsIHNldFNob3dGaWx0ZXJGaWVsZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIERpc3BsYXkgYWdlbnQvZW1wbG95ZWUgbmFtZSBvbiB0b3BcclxuICBjb25zdCBnZXRUb3BEaXNwbGF5RmlsdGVyID0gKCkgPT4ge1xyXG4gICAgaWYgKGZpbHRlclR5cGUgPT09IFwiYWdlbnRcIikge1xyXG4gICAgICBpZiAoc2VsZWN0ZWRJZCA9PT0gXCJhbGxcIikgcmV0dXJuIFwiQWxsIEVtcGxveWVlc1wiO1xyXG5cclxuICAgICAgY29uc3QgZm91bmQgPSBhZ2VudHMuZmluZCgoYSkgPT4gYS5faWQgPT09IHNlbGVjdGVkSWQpO1xyXG4gICAgICByZXR1cm4gZm91bmQgPyBmb3VuZC5uYW1lIDogXCJFbXBsb3llZVwiO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIFwiQWxsXCI7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZGF0ZU9wdGlvbnMgPSBbXHJcbiAgICB7IHZhbHVlOiBcIlRvZGF5XCIsIGxhYmVsOiBcIlRvZGF5XCIgfSxcclxuICAgIHsgdmFsdWU6IFwiWWVzdGVyZGF5XCIsIGxhYmVsOiBcIlllc3RlcmRheVwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlRoaXNNb250aFwiLCBsYWJlbDogXCJUaGlzIE1vbnRoXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiTGFzdE1vbnRoXCIsIGxhYmVsOiBcIkxhc3QgTW9udGhcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJUaGlzWWVhclwiLCBsYWJlbDogXCJUaGlzIFllYXJcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJDdXN0b21cIiwgbGFiZWw6IFwiQ3VzdG9tXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcbiAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0dGVkKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuICAgICAgY29uc3QgeSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgeS5zZXREYXRlKHkuZ2V0RGF0ZSgpIC0gMSk7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUoeSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0dGVkKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdHRlZCk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBGZXRjaCBhZ2VudHNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hBZ2VudCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXQtYWdlbnRcIik7XHJcbiAgICAgICAgc2V0QWdlbnRzKHJlc3A/LmRhdGEgfHwgW10pO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5hYmxlIHRvIGZldGNoIGFnZW50c1wiLCBlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZ2VudCgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gRmV0Y2ggcmVwb3J0XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgIHN0YXJ0X2RhdGU6IHNlbGVjdGVkRnJvbURhdGUsXHJcbiAgICAgICAgICBlbmRfZGF0ZTogc2VsZWN0ZWREYXRlLFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmIChmaWx0ZXJUeXBlID09PSBcImFnZW50XCIgJiYgc2VsZWN0ZWRJZCAhPT0gXCJhbGxcIikge1xyXG4gICAgICAgICAgcGFyYW1zLmFnZW50SWQgPSBzZWxlY3RlZElkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvaW5zdGFsbGVkL2FnZW50c1wiLCB7IHBhcmFtcyB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gcmVzcG9uc2U/LmRhdGE/LmRhdGE/Lm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGl0ZW0/Ll9pZCxcclxuICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgIHVzZXJOYW1lOiBpdGVtPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICB1c2VyUGhvbmU6IGl0ZW0/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgIHJlZmVycmVkVHlwZTogaXRlbT8ucmVmZXJyYWxfdHlwZSB8fCBcIi1cIixcclxuICAgICAgICAgIHJlZmVycmVkQnk6IGl0ZW0/LmFnZW50Py5uYW1lIHx8IFwiQWRtaW5cIixcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIHNldFRyYWNrdGFibGVEYXRhKGZvcm1hdHRlZCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyByZXBvcnRcIiwgZXJyKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoUmVwb3J0KCk7XHJcbiAgfSwgW2ZpbHRlclR5cGUsIHNlbGVjdGVkSWQsIHNlbGVjdGVkRnJvbURhdGUsIHNlbGVjdGVkRGF0ZV0pO1xyXG5cclxuICAvLyBUYWJsZSBjb2x1bW5zXHJcbiAgY29uc3QgdHJhY2tDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIk5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRUeXBlXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkQnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuICBdO1xyXG5cclxuICAvLyBDYWxjdWxhdGUgc3VtbWFyeSBkYXRhXHJcbiAgY29uc3QgdG90YWxDdXN0b21lcnMgPSB0cmFja1RhYmxlRGF0YS5sZW5ndGg7XHJcbiAgXHJcbiAgLy8gQ291bnQgYnkgUmVmZXJyZWQgVHlwZVxyXG4gIGNvbnN0IHJlZmVycmVkVHlwZUNvdW50ID0ge307XHJcbiAgdHJhY2tUYWJsZURhdGEuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgY29uc3Qga2V5ID0gaXRlbS5yZWZlcnJlZFR5cGUgfHwgXCJVbmtub3duXCI7XHJcbiAgICByZWZlcnJlZFR5cGVDb3VudFtrZXldID0gKHJlZmVycmVkVHlwZUNvdW50W2tleV0gfHwgMCkgKyAxO1xyXG4gIH0pO1xyXG5cclxuICAvLyBDb3VudCBieSBSZWZlcnJlZCBCeVxyXG4gIGNvbnN0IHJlZmVycmVkQnlDb3VudCA9IHt9O1xyXG4gIHRyYWNrVGFibGVEYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgIGNvbnN0IGtleSA9IGl0ZW0ucmVmZXJyZWRCeSB8fCBcIlVua25vd25cIjtcclxuICAgIHJlZmVycmVkQnlDb3VudFtrZXldID0gKHJlZmVycmVkQnlDb3VudFtrZXldIHx8IDApICsgMTtcclxuICB9KTtcclxuXHJcbiAgLy8gQ2FsY3VsYXRlIGRheXMgYmV0d2VlbiBzZWxlY3RlZCBkYXRlc1xyXG4gIGNvbnN0IGNhbGN1bGF0ZURheXNCZXR3ZWVuID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZnJvbURhdGUgPSBuZXcgRGF0ZShzZWxlY3RlZEZyb21EYXRlKTtcclxuICAgIGNvbnN0IHRvRGF0ZSA9IG5ldyBEYXRlKHNlbGVjdGVkRGF0ZSk7XHJcbiAgICBjb25zdCBkaWZmVGltZSA9IE1hdGguYWJzKHRvRGF0ZSAtIGZyb21EYXRlKTtcclxuICAgIGNvbnN0IGRpZmZEYXlzID0gTWF0aC5jZWlsKGRpZmZUaW1lIC8gKDEwMDAgKiA2MCAqIDYwICogMjQpKSArIDE7IC8vICsxIHRvIGluY2x1ZGUgYm90aCBzdGFydCBhbmQgZW5kIGRhdGVcclxuICAgIHJldHVybiBkaWZmRGF5cztcclxuICB9O1xyXG5cclxuICAvLyBDYWxjdWxhdGUgYXZlcmFnZSBjdXN0b21lcnMgcGVyIGRheVxyXG4gIGNvbnN0IGF2Z0N1c3RvbWVyc1BlckRheSA9IGNhbGN1bGF0ZURheXNCZXR3ZWVuKCkgPiAwIFxyXG4gICAgPyAodG90YWxDdXN0b21lcnMgLyBjYWxjdWxhdGVEYXlzQmV0d2VlbigpKS50b0ZpeGVkKDEpIFxyXG4gICAgOiAwO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICBSZXBvcnRzIOKAlHtcIiBcIn1cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBVc2VyIE1vYmlsZSBUcmFja2luZyBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBFTkhBTkNFRCBTVU1NQVJZIENBUkRTICovfVxyXG4gICAgICAgICAgICB7dHJhY2tUYWJsZURhdGEubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIG1iLTQgdGV4dC1ncmF5LTgwMFwiPlJlcG9ydCBTdW1tYXJ5PC9oMj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgey8qIFRPVEFMIENVU1RPTUVSUyBDQVJEICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tdmlvbGV0LTUwMCB0by12aW9sZXQtNjAwIHRleHQtd2hpdGUgcC02IHJvdW5kZWQteGwgc2hhZG93LWxnIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtMTAwIHRleHQtc20gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgQ3VzdG9tZXJzIEFkZGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgbXQtMVwiPnt0b3RhbEN1c3RvbWVyc308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC0xMDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRUb3BEaXNwbGF5RmlsdGVyKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBiZy1vcGFjaXR5LTIwIHAtMyByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIGNsYXNzTmFtZT1cImgtOCB3LThcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTE3IDIwaDV2LTJhMyAzIDAgMDAtNS4zNTYtMS44NTdNMTcgMjBIN20xMCAwdi0yYzAtLjY1Ni0uMTI2LTEuMjgzLS4zNTYtMS44NTdNNyAyMEgydi0yYTMgMyAwIDAxNS4zNTYtMS44NTdNNyAyMHYtMmMwLS42NTYuMTI2LTEuMjgzLjM1Ni0xLjg1N20wIDBhNS4wMDIgNS4wMDIgMCAwMTkuMjg4IDBNMTUgN2EzIDMgMCAxMS02IDAgMyAzIDAgMDE2IDB6bTYgM2EyIDIgMCAxMS00IDAgMiAyIDAgMDE0IDB6TTcgMTBhMiAyIDAgMTEtNCAwIDIgMiAwIDAxNCAwelwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogU1VNTUFSWSBHUklEICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC02IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBSRUZFUlJBTCBUWVBFIENPVU5UICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+UmVmZXJyYWwgVHlwZXM8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctdmlvbGV0LTEwMCB0ZXh0LXZpb2xldC04MDAgdGV4dC14cyBmb250LW1lZGl1bSBweC0yLjUgcHktMC41IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge09iamVjdC5rZXlzKHJlZmVycmVkVHlwZUNvdW50KS5sZW5ndGh9IFR5cGVzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhyZWZlcnJlZFR5cGVDb3VudClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnNvcnQoKGEsIGIpID0+IGJbMV0gLSBhWzFdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuc2xpY2UoMCwgNSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgLm1hcCgoW3R5cGUsIGNvdW50XSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXt0eXBlfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIgaC0yIGJnLXZpb2xldC01MDAgcm91bmRlZC1mdWxsIG1yLTNcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCB0ZXh0LXNtIHRydW5jYXRlIG1heC13LXhzXCI+e3R5cGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yNCBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgaC0yIG1yLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTUwMCBoLTIgcm91bmRlZC1mdWxsXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7KGNvdW50IC8gdG90YWxDdXN0b21lcnMpICogMTAwfSVgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHctOCB0ZXh0LXJpZ2h0XCI+e2NvdW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHtPYmplY3Qua2V5cyhyZWZlcnJlZFR5cGVDb3VudCkubGVuZ3RoID4gNSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIHRleHQtc20gZm9udC1tZWRpdW1cIj5WaWV3IEFsbCBUeXBlczwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFJFRkVSUkFMIFNPVVJDRSBDT1VOVCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlJlZmVycmFsIFNvdXJjZXM8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwIHRleHQteHMgZm9udC1tZWRpdW0gcHgtMi41IHB5LTAuNSByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtPYmplY3Qua2V5cyhyZWZlcnJlZEJ5Q291bnQpLmxlbmd0aH0gU291cmNlc1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMocmVmZXJyZWRCeUNvdW50KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYlsxXSAtIGFbMV0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5zbGljZSgwLCA1KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKChbc291cmNlLCBjb3VudF0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17c291cmNlfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIgaC0yIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgbXItM1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIHRleHQtc20gdHJ1bmNhdGUgbWF4LXcteHNcIj57c291cmNlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjQgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIGgtMiBtci0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMCBoLTIgcm91bmRlZC1mdWxsXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7KGNvdW50IC8gdG90YWxDdXN0b21lcnMpICogMTAwfSVgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHctOCB0ZXh0LXJpZ2h0XCI+e2NvdW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHtPYmplY3Qua2V5cyhyZWZlcnJlZEJ5Q291bnQpLmxlbmd0aCA+IDUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB0LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtc20gZm9udC1tZWRpdW1cIj5WaWV3IEFsbCBTb3VyY2VzPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgey8qIEFERElUSU9OQUwgTUVUUklDUyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC1mdWxsIGJnLXB1cnBsZS0xMDAgdGV4dC1wdXJwbGUtNjAwIG1yLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgY2xhc3NOYW1lPVwiaC02IHctNlwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk04IDdWM204IDRWM20tOSA4aDEwTTUgMjFoMTRhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJ6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPlNlbGVjdGVkIFBlcmlvZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+e3NlbGVjdGVkTGFiZWx9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQtZnVsbCBiZy1hbWJlci0xMDAgdGV4dC1hbWJlci02MDAgbXItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBjbGFzc05hbWU9XCJoLTYgdy02XCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTEyIDh2NGwzIDNtNi0zYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj5BdmcuIEN1c3RvbWVycy9EYXk8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPnthdmdDdXN0b21lcnNQZXJEYXl9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQtZnVsbCBiZy1yZWQtMTAwIHRleHQtcmVkLTYwMCBtci00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIGNsYXNzTmFtZT1cImgtNiB3LTZcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9ezJ9IGQ9XCJNMTMgN2g4bTAgMHY4bTAtOGwtOCA4LTQtNC02IDZcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtXCI+QWN0aXZlIFJlZmVycmVyczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+e09iamVjdC5rZXlzKHJlZmVycmVkQnlDb3VudCkubGVuZ3RofTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC02IG1iLTYgaXRlbXMtZW5kXCI+XHJcbiAgICAgICAgICAgICAgey8qIERBVEUgRklMVEVSICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPkRhdGUgRmlsdGVyPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHctNDhcIj5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVTZWxlY3RGaWx0ZXIodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2RhdGVPcHRpb25zLm1hcCgob3B0aW9uKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e29wdGlvbi52YWx1ZX0gdmFsdWU9e29wdGlvbi52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb24ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBDVVNUT00gREFURSBSQU5HRSAqL31cclxuICAgICAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBpdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPkZyb208L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGgtMTAgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPlRvPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBoLTEwIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7LyogRU1QTE9ZRUUgRklMVEVSIFRZUEUgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVtcGxveWVlIEZpbHRlclxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHctNDhcIj5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVyVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJUeXBlKHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkSWQoXCJhbGxcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiYWdlbnRcIj5FbXBsb3llZTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEVNUExPWUVFIERST1BET1dOIChWSVNJQkxFIE9OTFkgSUYgRW1wbG95ZWUgZmlsdGVyIHNlbGVjdGVkKSAqL31cclxuICAgICAgICAgICAgICB7ZmlsdGVyVHlwZSA9PT0gXCJhZ2VudFwiICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0IEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHctNjRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkSWQgIT09IFwiYWxsXCIgPyBzZWxlY3RlZElkIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0U2VsZWN0ZWRJZCh2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJhbGxcIj5BbGwgRW1wbG95ZWVzPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQubmFtZX0gfCB7YWdlbnQucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUQUJMRSAqL31cclxuICAgICAgICAgICAge3RyYWNrVGFibGVEYXRhICYmICFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZSBkYXRhPXt0cmFja1RhYmxlRGF0YX0gY29sdW1ucz17dHJhY2tDb2x1bW5zfSBleHBvcnRlZEZpbGVOYW1lPVwiVXNlciBSZWdpc3RyYXRpb24gU291cmNlIFN1bW1hcnkgUmVwb3J0LmNzdlwiIGV4cG9ydGVkUGRmTmFtZT1cIlVzZXIgUmVnaXN0cmF0aW9uIFNvdXJjZSBTdW1tYXJ5IFJlcG9ydFwiIC8+XHJcblxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXt0cmFja1RhYmxlRGF0YS5sZW5ndGggPD0gMH1cclxuICAgICAgICAgICAgICAgIGRhdGE9XCJ1c2VyIHRyYWNraW5nIGRhdGFcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVXNlclJlZ2lzdHJhdGlvblNvdXJjZVN1bW1hcnlSZXBvcnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Vc2VyUmVnaXN0cmF0aW9uU291cmNlU3VtbWFyeVJlcG9ydC5qc3gifQ==