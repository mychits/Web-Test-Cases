import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AdministrativePrivileges.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import { Input, Dropdown, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const AdministrativePrivileges = () => {
  _s();
  const [admins, setAdmins] = useState([]);
  const [TableGroups, setTableGroups] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentAdmin, setCurrentAdmin] = useState(null);
  const [currentUpdateAdmin, setCurrentUpdateAdmin] = useState(null);
  const [allAccessRights, setAllAccessRights] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    admin_code: "",
    name: "",
    password: "",
    phoneNumber: "",
    email: "",
    admin_access_right_id: ""
  });
  const [errors, setErrors] = useState({});
  const [updateFormData, setUpdateFormData] = useState({
    name: "",
    phoneNumber: "",
    password: "",
    admin_access_right_id: ""
  });
  useEffect(() => {
    const fetchAllAdminRights = async () => {
      try {
        const response = await api.get("/admin-access-rights/get-all");
        setAllAccessRights(response.data);
      } catch (err) {
        console.error("Failed to fetch Access Rights");
        setAllAccessRights([]);
      }
    };
    fetchAllAdminRights();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchSubAdmins = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/admin/get-sub-admins");
        setAdmins(response.data);
        const formattedData = response.data.map((admin, index) => ({
          _id: admin?._id,
          id: index + 1,
          admin_code: admin?.admin_code,
          name: admin?.name,
          phoneNumber: admin?.phoneNumber,
          password: admin?.password,
          admin_access_right: admin?.admin_access_right_id?.title,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(admin?._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                        lineNumber: 92,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(admin?._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                        lineNumber: 103,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                lineNumber: 116,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 85,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 84,
            columnNumber: 11
          }, this)
        }));
        setTableGroups(formattedData);
      } catch (error) {
        console.error("Error fetching Admin data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchSubAdmins();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [field]: "" }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addAdmin" ? formData : updateFormData;
    if (!data.name?.trim()) {
      newErrors.name = "Admin Name is required";
    }
    if (!data.password) {
      newErrors.password = "Password is required";
    }
    if (!data.phoneNumber || isNaN(data.phoneNumber)) {
      newErrors.phoneNumber = "Phone Number is required";
    }
    if (type === "addAdmin") {
      if (!data.email || !data.email.trim()) {
        newErrors.email = "Email is required";
      } else if (!/\S+@\S+\.\S+/.test(data.email)) {
        newErrors.email = "Email is invalid";
      }
    }
    if (!data.admin_access_right_id) {
      newErrors.admin_access_right_id = "Select Admin Access Right";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm("addAdmin");
    try {
      if (isValid) {
        const response = await api.post("/admin/add-sub-admin", formData, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Sub Admin Added Successfully",
          type: "success"
        });
        setShowModal(false);
        setFormData({
          name: "",
          phoneNumber: "",
          password: "",
          email: "",
          admin_access_right_id: ""
        });
      } else {
        console.log(errors);
      }
    } catch (error) {
      console.error("Error adding sub admin:", error);
      if (error.response && error.response.data && error.response.data.message && error.response.data.message.toLowerCase().includes("phone")) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          phoneNumber: "Phone number already exists"
        }));
      }
    }
  };
  const handleDeleteModalOpen = async (adminId) => {
    try {
      console.info(adminId, "adminid");
      const response = await api.get(`/admin/get-admin/${adminId}`);
      setCurrentAdmin(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error deleting Sub Admin:", error);
    }
  };
  const handleUpdateModalOpen = async (adminId) => {
    try {
      const response = await api.get(`/admin/get-admin/${adminId}`);
      setCurrentUpdateAdmin(response.data);
      setUpdateFormData({
        name: response?.data?.name,
        phoneNumber: response?.data?.phoneNumber,
        password: response?.data?.password,
        admin_access_right_id: response?.data?.admin_access_right_id?._id
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching admin:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors({ ...errors, [name]: "" });
  };
  const handleDeleteAdmin = async () => {
    if (currentAdmin) {
      try {
        await api.delete(`/admin/delete-admin/${currentAdmin._id}`);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Admin deleted successfully",
          type: "success",
          visibility: true
        });
        setShowModalDelete(false);
        setCurrentAdmin(null);
      } catch (error) {
        console.error("Error deleting admin:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm("updateAdmin");
    try {
      if (isValid) {
        console.info(currentUpdateAdmin, updateFormData, "updation form");
        await api.put(
          `/admin/update-admin/${currentUpdateAdmin._id}`,
          updateFormData
        );
        setShowModalUpdate(false);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Admin updated successfully",
          type: "success",
          visibility: true
        });
      } else {
        console.log("Validation errors:", errors);
      }
    } catch (error) {
      console.error("Error updating Admin:", error);
      setAlertConfig({
        message: error.response?.data?.message || "Error updating admin",
        type: "error",
        visibility: true
      });
    }
  };
  const columns = [
    { key: "id", header: "Sl No" },
    { key: "admin_code", header: "Admin Code" },
    { key: "name", header: "Admin Name" },
    { key: "password", header: "Password" },
    { key: "phoneNumber", header: "Phone Number" },
    { key: "admin_access_right", header: "Admin Access Role" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: true,
        onGlobalSearchChangeHandler
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
        lineNumber: 408,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
        lineNumber: 412,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(SettingSidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
        lineNumber: 421,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Administrative Privileges" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 426,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
                setErrors({});
              },
              className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Add Sub Admin"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 429,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 425,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 424,
          columnNumber: 15
        }, this),
        TableGroups.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableGroups, searchText),
            columns,
            exportedPdfName: `Administrative Privileges`,
            exportedFileName: `Administrative Privileges.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 442,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableGroups.length <= 0,
            data: "Sub Admin Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 451,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8", children: " " }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 458,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
        lineNumber: 423,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
      lineNumber: 420,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Sub Admin" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
        lineNumber: 465,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "name",
              children: [
                "Sub Admin Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 474,
                  columnNumber: 36
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 470,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "name",
              value: formData.name,
              onChange: handleChange,
              id: "name",
              placeholder: "Enter Sub Admin Name",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 476,
              columnNumber: 19
            },
            this
          ),
          errors.name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 487,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 469,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "phoneNumber",
              children: [
                "Phone Number ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 497,
                  columnNumber: 34
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 493,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "phoneNumber",
              value: formData.phoneNumber,
              onChange: handleChange,
              id: "phoneNumber",
              placeholder: "Enter Sub Admin Phone Number",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 499,
              columnNumber: 19
            },
            this
          ),
          errors.phoneNumber && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.phoneNumber }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 510,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 492,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "password",
              children: [
                "Password ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 520,
                  columnNumber: 30
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 516,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "password",
              value: formData.password,
              onChange: handleChange,
              id: "password",
              placeholder: "Enter Password",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 522,
              columnNumber: 19
            },
            this
          ),
          errors.password && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.password }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 533,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 515,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Email ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 542,
                  columnNumber: 27
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 538,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "email",
              name: "email",
              value: formData.email,
              onChange: handleChange,
              id: "email",
              placeholder: "Enter Sub Admin Email",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 544,
              columnNumber: 19
            },
            this
          ),
          errors.email && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.email }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 555,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 537,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Admin Access Rights ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 567,
                  columnNumber: 41
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 563,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
              placeholder: "Select Admin Access Role",
              popupMatchSelectWidth: false,
              showSearch: true,
              name: "admin_access_right_id",
              filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
              value: formData?.admin_access_right_id || void 0,
              onChange: (value) => handleAntDSelect("admin_access_right_id", value),
              children: allAccessRights.map(
                (accessRight) => /* @__PURE__ */ jsxDEV(Select.Option, { value: accessRight?._id, children: accessRight?.title }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 595,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 580,
              columnNumber: 19
            },
            this
          ),
          errors.admin_access_right_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.admin_access_right_id }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 601,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 562,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800\r\n                focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
            children: "Save Sub Admin"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 608,
            columnNumber: 19
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 607,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
        lineNumber: 468,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
      lineNumber: 464,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
      lineNumber: 463,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Sub Admin" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 624,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "name",
                  children: [
                    "Admin Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                      lineNumber: 633,
                      columnNumber: 32
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 629,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "name",
                  value: updateFormData.name,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Admin Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 635,
                  columnNumber: 19
                },
                this
              ),
              errors.name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                lineNumber: 646,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 628,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "phone_number",
                  children: [
                    "Phone Number ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                      lineNumber: 656,
                      columnNumber: 34
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 652,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "phoneNumber",
                  value: updateFormData.phoneNumber,
                  onChange: handleInputChange,
                  id: "phone_number",
                  placeholder: "Enter Sub Admin Phone Number",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 658,
                  columnNumber: 19
                },
                this
              ),
              errors.phoneNumber && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.phoneNumber }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                lineNumber: 669,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 651,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "password",
                  children: [
                    "Password ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                      lineNumber: 679,
                      columnNumber: 30
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 675,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "password",
                  value: updateFormData.password,
                  onChange: handleInputChange,
                  id: "password",
                  placeholder: "Enter Password",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 681,
                  columnNumber: 19
                },
                this
              ),
              errors.password && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.password }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                lineNumber: 692,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 674,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Admin Access Role ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                      lineNumber: 700,
                      columnNumber: 39
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 696,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Admin Access Role",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "admin_access_right_id",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.admin_access_right_id || void 0,
                  onChange: (value) => handleAntInputDSelect("admin_access_right_id", value),
                  children: allAccessRights.map(
                    (accessRight) => /* @__PURE__ */ jsxDEV(Select.Option, { value: accessRight?._id, children: accessRight?.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                      lineNumber: 731,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 716,
                  columnNumber: 19
                },
                this
              ),
              errors.admin_access_right_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.admin_access_right_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                lineNumber: 737,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 695,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800\r\n                focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                lineNumber: 742,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 627,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 623,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
        lineNumber: 619,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentAdmin(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Sub Admin" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
            lineNumber: 760,
            columnNumber: 15
          }, this),
          currentAdmin && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteAdmin();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "adminname",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentAdmin.name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                          lineNumber: 777,
                          columnNumber: 23
                        }, this),
                        " ",
                        "to confirm deletion. ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                          lineNumber: 780,
                          columnNumber: 44
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                      lineNumber: 772,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "adminname",
                      placeholder: "Enter the Admin Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                      lineNumber: 782,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                  lineNumber: 771,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n            focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
                    lineNumber: 791,
                    columnNumber: 19
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
              lineNumber: 764,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
          lineNumber: 759,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
        lineNumber: 752,
        columnNumber: 11
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
    lineNumber: 407,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx",
    lineNumber: 406,
    columnNumber: 5
  }, this);
};
_s(AdministrativePrivileges, "aUtoAhsUL1YaIgKHT97+qh28kvo=");
_c = AdministrativePrivileges;
export default AdministrativePrivileges;
var _c;
$RefreshReg$(_c, "AdministrativePrivileges");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdministrativePrivileges.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkYwQixTQTBUcEIsVUExVG9COzJCQTNGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLE9BQU9DLFVBQVVDLGNBQWM7QUFDeEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQVNDLGlCQUFpQjtBQUUxQixNQUFNQywyQkFBMkJBLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWxCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNtQixhQUFhQyxjQUFjLElBQUlwQixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDcUIsV0FBV0MsWUFBWSxJQUFJdEIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3VCLGlCQUFpQkMsa0JBQWtCLElBQUl4QixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDeUIsaUJBQWlCQyxrQkFBa0IsSUFBSTFCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMyQixjQUFjQyxlQUFlLElBQUk1QixTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDNkIsb0JBQW9CQyxxQkFBcUIsSUFBSTlCLFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUMrQixpQkFBaUJDLGtCQUFrQixJQUFJaEMsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ2lDLFlBQVlDLGFBQWEsSUFBSWxDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNtQyxXQUFXQyxZQUFZLElBQUlwQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDcUMsZUFBZUMsZ0JBQWdCLElBQUl0QyxTQUFTLENBQUM7QUFFcEQsUUFBTXVDLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJSLGtCQUFjTyxLQUFLO0FBQUEsRUFDckI7QUFFQSxRQUFNLENBQUNFLGFBQWFDLGNBQWMsSUFBSTVDLFNBQVM7QUFBQSxJQUM3QzZDLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJakQsU0FBUztBQUFBLElBQ3ZDa0QsWUFBWTtBQUFBLElBQ1pDLE1BQU07QUFBQSxJQUNOQyxVQUFVO0FBQUEsSUFDVkMsYUFBYTtBQUFBLElBQ2JDLE9BQU87QUFBQSxJQUNQQyx1QkFBdUI7QUFBQSxFQUN6QixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUl6RCxTQUFTLENBQUMsQ0FBQztBQUV2QyxRQUFNLENBQUMwRCxnQkFBZ0JDLGlCQUFpQixJQUFJM0QsU0FBUztBQUFBLElBQ25EbUQsTUFBTTtBQUFBLElBQ05FLGFBQWE7QUFBQSxJQUNiRCxVQUFVO0FBQUEsSUFDVkcsdUJBQXVCO0FBQUEsRUFDekIsQ0FBQztBQUVDeEQsWUFBVSxNQUFNO0FBQ2hCLFVBQU02RCxzQkFBc0IsWUFBWTtBQUN0QyxVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNM0QsSUFBSTRELElBQUksOEJBQThCO0FBQzdEOUIsMkJBQW1CNkIsU0FBU0UsSUFBSTtBQUFBLE1BQ2xDLFNBQVNDLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0sK0JBQStCO0FBQzdDbEMsMkJBQW1CLEVBQUU7QUFBQSxNQUN2QjtBQUFBLElBQ0Y7QUFDQTRCLHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsQ0FBQ3ZCLGFBQWEsQ0FBQztBQUNsQnRDLFlBQVUsTUFBTTtBQUNkLFVBQU1vRSxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YvQixxQkFBYSxJQUFJO0FBQ2pCLGNBQU15QixXQUFXLE1BQU0zRCxJQUFJNEQsSUFBSSx1QkFBdUI7QUFDdEQ1QyxrQkFBVTJDLFNBQVNFLElBQUk7QUFDdkIsY0FBTUssZ0JBQWdCUCxTQUFTRSxLQUFLTSxJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxVQUN6REMsS0FBS0YsT0FBT0U7QUFBQUEsVUFDWkMsSUFBSUYsUUFBUTtBQUFBLFVBQ1pyQixZQUFZb0IsT0FBT3BCO0FBQUFBLFVBQ25CQyxNQUFNbUIsT0FBT25CO0FBQUFBLFVBQ2JFLGFBQWFpQixPQUFPakI7QUFBQUEsVUFDcEJELFVBQVVrQixPQUFPbEI7QUFBQUEsVUFDakJzQixvQkFBb0JKLE9BQU9mLHVCQUF1Qm9CO0FBQUFBLFVBQ2xEQyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0QsU0FBUyxDQUFDLE9BQU87QUFBQSxjQUNmLE1BQU07QUFBQSxnQkFDSkMsT0FBTztBQUFBLGtCQUNMO0FBQUEsb0JBQ0VDLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNQyxzQkFBc0JWLE9BQU9FLEdBQUc7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRU0sS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU1FLHNCQUFzQlgsT0FBT0UsR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxnQkFBQztBQUFBLGNBR0w7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBO0FBQUEsWUEvQmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWdDQSxLQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtDQTtBQUFBLFFBRUosRUFBRTtBQUNGcEQsdUJBQWVnRCxhQUFhO0FBQUEsTUFDOUIsU0FBU0YsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRCxVQUFDO0FBQ0M5QixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0ErQixtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQzlCLGFBQWEsQ0FBQztBQUVsQixRQUFNNkMsZUFBZUEsQ0FBQzFDLE1BQU07QUFDMUIsVUFBTSxFQUFFVyxNQUFNVixNQUFNLElBQUlELEVBQUVFO0FBRTFCTyxnQkFBWSxDQUFDa0MsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2hDLElBQUksR0FBR1Y7QUFBQUEsSUFDVixFQUFFO0FBRUZnQixjQUFVLENBQUMwQixjQUFjO0FBQUEsTUFDdkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDaEMsSUFBSSxHQUFHO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUNBLFFBQU1pQyxtQkFBbUJBLENBQUNDLE9BQU81QyxVQUFVO0FBQ3pDUSxnQkFBWSxDQUFDa0MsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0UsS0FBSyxHQUFHNUM7QUFBQUEsSUFDWCxFQUFFO0FBRUZnQixjQUFVLENBQUM2QixnQkFBZ0I7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNELEtBQUssR0FBRztBQUFBLElBQ1gsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNRSx3QkFBd0JBLENBQUNGLE9BQU81QyxVQUFVO0FBQzlDa0Isc0JBQWtCLENBQUN3QixjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRSxLQUFLLEdBQUc1QztBQUFBQSxJQUNYLEVBQUU7QUFFRmdCLGNBQVUsQ0FBQzZCLGdCQUFnQixFQUFFLEdBQUdBLFlBQVksQ0FBQ0QsS0FBSyxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQzVEO0FBRUEsUUFBTUcsZUFBZUEsQ0FBQ3pDLFNBQVM7QUFDakMsVUFBTTBDLFlBQVksQ0FBQztBQUNuQixVQUFNMUIsT0FBT2hCLFNBQVMsYUFBYUMsV0FBV1U7QUFFOUMsUUFBSSxDQUFDSyxLQUFLWixNQUFNdUMsS0FBSyxHQUFHO0FBQ3RCRCxnQkFBVXRDLE9BQU87QUFBQSxJQUNuQjtBQUVBLFFBQUksQ0FBQ1ksS0FBS1gsVUFBVTtBQUNsQnFDLGdCQUFVckMsV0FBVztBQUFBLElBQ3ZCO0FBRUEsUUFBSSxDQUFDVyxLQUFLVixlQUFlc0MsTUFBTTVCLEtBQUtWLFdBQVcsR0FBRztBQUNoRG9DLGdCQUFVcEMsY0FBYztBQUFBLElBQzFCO0FBR0EsUUFBSU4sU0FBUyxZQUFZO0FBQ3ZCLFVBQUksQ0FBQ2dCLEtBQUtULFNBQVMsQ0FBQ1MsS0FBS1QsTUFBTW9DLEtBQUssR0FBRztBQUNyQ0Qsa0JBQVVuQyxRQUFRO0FBQUEsTUFDcEIsV0FBVyxDQUFDLGVBQWVzQyxLQUFLN0IsS0FBS1QsS0FBSyxHQUFHO0FBQzNDbUMsa0JBQVVuQyxRQUFRO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBRUEsUUFBSSxDQUFDUyxLQUFLUix1QkFBdUI7QUFDL0JrQyxnQkFBVWxDLHdCQUF3QjtBQUFBLElBQ3BDO0FBRUFFLGNBQVVnQyxTQUFTO0FBQ25CLFdBQU9JLE9BQU9DLEtBQUtMLFNBQVMsRUFBRU0sV0FBVztBQUFBLEVBQzNDO0FBaUNJLFFBQU1DLGVBQWUsT0FBT3hELE1BQU07QUFFaENBLE1BQUV5RCxlQUFlO0FBRWpCLFVBQU1DLFVBQVVWLGFBQWEsVUFBVTtBQUN2QyxRQUFJO0FBQ0YsVUFBSVUsU0FBUztBQUNYLGNBQU1yQyxXQUFXLE1BQU0zRCxJQUFJaUcsS0FBSyx3QkFBd0JuRCxVQUFVO0FBQUEsVUFDaEVvRCxTQUFTO0FBQUEsWUFDUCxnQkFBZ0I7QUFBQSxVQUNsQjtBQUFBLFFBQ0YsQ0FBQztBQUNEOUQseUJBQWlCLENBQUMrRCxTQUFTQSxPQUFPLENBQUM7QUFDbkN6RCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUVEekIscUJBQWEsS0FBSztBQUNsQjJCLG9CQUFZO0FBQUEsVUFDVkUsTUFBTTtBQUFBLFVBQ05FLGFBQWE7QUFBQSxVQUNiRCxVQUFVO0FBQUEsVUFDVkUsT0FBTztBQUFBLFVBQ1BDLHVCQUF1QjtBQUFBLFFBQ3pCLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTFUsZ0JBQVFxQyxJQUFJOUMsTUFBTTtBQUFBLE1BQ3BCO0FBQUEsSUFDRixTQUFTVSxPQUFPO0FBQ2xCRCxjQUFRQyxNQUFNLDJCQUEyQkEsS0FBSztBQUU5QyxVQUNFQSxNQUFNTCxZQUNOSyxNQUFNTCxTQUFTRSxRQUNmRyxNQUFNTCxTQUFTRSxLQUFLakIsV0FDcEJvQixNQUFNTCxTQUFTRSxLQUFLakIsUUFBUXlELFlBQVksRUFBRUMsU0FBUyxPQUFPLEdBQzFEO0FBQ0EvQyxrQkFBVSxDQUFDNkIsZ0JBQWdCO0FBQUEsVUFDekIsR0FBR0E7QUFBQUEsVUFDSGpDLGFBQWE7QUFBQSxRQUNmLEVBQUU7QUFBQSxNQUNKO0FBQUEsSUFDRjtBQUFBLEVBRUU7QUFHQSxRQUFNNEIsd0JBQXdCLE9BQU93QixZQUFZO0FBQy9DLFFBQUk7QUFDRnhDLGNBQVF5QyxLQUFLRCxTQUFRLFNBQVM7QUFDOUIsWUFBTTVDLFdBQVcsTUFBTTNELElBQUk0RCxJQUFJLG9CQUFvQjJDLE9BQU8sRUFBRTtBQUM1RDdFLHNCQUFnQmlDLFNBQVNFLElBQUk7QUFDN0J2Qyx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVMwQyxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBRUEsUUFBTWMsd0JBQXdCLE9BQU95QixZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNNUMsV0FBVyxNQUFNM0QsSUFBSTRELElBQUksb0JBQW9CMkMsT0FBTyxFQUFFO0FBRTVEM0UsNEJBQXNCK0IsU0FBU0UsSUFBSTtBQUNuQ0osd0JBQWtCO0FBQUEsUUFDaEJSLE1BQU1VLFVBQVVFLE1BQU1aO0FBQUFBLFFBQ3RCRSxhQUFhUSxVQUFVRSxNQUFNVjtBQUFBQSxRQUM3QkQsVUFBVVMsVUFBVUUsTUFBTVg7QUFBQUEsUUFDMUJHLHVCQUF1Qk0sVUFBVUUsTUFBTVIsdUJBQXVCaUI7QUFBQUEsTUFDaEUsQ0FBQztBQUNEOUMseUJBQW1CLElBQUk7QUFDdkIrQixnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkLFNBQVNTLE9BQU87QUFDZEQsY0FBUUMsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNeUMsb0JBQW9CQSxDQUFDbkUsTUFBTTtBQUMvQixVQUFNLEVBQUVXLE1BQU1WLE1BQU0sSUFBSUQsRUFBRUU7QUFFMUJpQixzQkFBa0IsQ0FBQ3dCLGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUNoQyxJQUFJLEdBQUdWO0FBQUFBLElBQ1YsRUFBRTtBQUNGZ0IsY0FBVSxFQUFFLEdBQUdELFFBQVEsQ0FBQ0wsSUFBSSxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQ3JDO0FBRUEsUUFBTXlELG9CQUFvQixZQUFZO0FBRXBDLFFBQUlqRixjQUFjO0FBRWhCLFVBQUk7QUFDRixjQUFNekIsSUFBSTJHLE9BQU8sdUJBQXVCbEYsYUFBYTZDLEdBQUcsRUFBRTtBQUUxRGxDLHlCQUFpQixDQUFDK0QsU0FBU0EsT0FBTyxDQUFDO0FBQ25DekQsdUJBQWU7QUFBQSxVQUNiRSxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFVBQ05GLFlBQVk7QUFBQSxRQUNkLENBQUM7QUFDRHJCLDJCQUFtQixLQUFLO0FBQ3hCSSx3QkFBZ0IsSUFBSTtBQUFBLE1BQ3RCLFNBQVNzQyxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEMsZUFBZSxPQUFPdEUsTUFBTTtBQUNwQ0EsTUFBRXlELGVBQWU7QUFDakIsVUFBTUMsVUFBVVYsYUFBYSxhQUFhO0FBRTFDLFFBQUk7QUFDRixVQUFJVSxTQUFTO0FBQ1hqQyxnQkFBUXlDLEtBQUs3RSxvQkFBb0I2QixnQkFBZ0IsZUFBZTtBQUNoRSxjQUFNeEQsSUFBSTZHO0FBQUFBLFVBQ1IsdUJBQXVCbEYsbUJBQW1CMkMsR0FBRztBQUFBLFVBQzdDZDtBQUFBQSxRQUNGO0FBQ0FoQywyQkFBbUIsS0FBSztBQUN4QlkseUJBQWlCLENBQUMrRCxTQUFTQSxPQUFPLENBQUM7QUFDbkN6RCx1QkFBZTtBQUFBLFVBQ2JFLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsVUFDTkYsWUFBWTtBQUFBLFFBQ2QsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMb0IsZ0JBQVFxQyxJQUFJLHNCQUFzQjlDLE1BQU07QUFBQSxNQUMxQztBQUFBLElBQ0YsU0FBU1UsT0FBTztBQUNkRCxjQUFRQyxNQUFNLHlCQUF5QkEsS0FBSztBQUM1Q3RCLHFCQUFlO0FBQUEsUUFDYkUsU0FBU29CLE1BQU1MLFVBQVVFLE1BQU1qQixXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxRQUNORixZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUE0QkksUUFBTW1FLFVBQVU7QUFBQSxJQUNkLEVBQUNsQyxLQUFLLE1BQU1tQyxRQUFRLFFBQU87QUFBQSxJQUMzQixFQUFDbkMsS0FBSyxjQUFjbUMsUUFBUSxhQUFZO0FBQUEsSUFDeEMsRUFBRW5DLEtBQUssUUFBUW1DLFFBQVEsYUFBYTtBQUFBLElBQ3BDLEVBQUVuQyxLQUFLLFlBQVltQyxRQUFRLFdBQVc7QUFBQSxJQUN0QyxFQUFFbkMsS0FBSyxlQUFlbUMsUUFBUSxlQUFlO0FBQUEsSUFDN0MsRUFBRW5DLEtBQUssc0JBQXNCbUMsUUFBUSxvQkFBb0I7QUFBQSxJQUN6RCxFQUFFbkMsS0FBSyxVQUFVbUMsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxTQUNFLG1DQUNFLGlDQUFDLFNBQ0M7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsWUFBWTtBQUFBLFFBQ1o7QUFBQTtBQUFBLE1BRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRTJEO0FBQUEsSUFFN0Q7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQU10RSxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQ3lELFVBQVUsRUFBRSxHQUFHQSxNQUFNeEQsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLE1BTC9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1LO0FBQUEsSUFFSCx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BRWYsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBCQUF5Qix5Q0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTtBQUNidkIsNkJBQWEsSUFBSTtBQUNqQm1DLDBCQUFVLENBQUMsQ0FBQztBQUFBLGNBQ2Q7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUFtRztBQUFBO0FBQUEsWUFML0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBRUV0QyxZQUFZNEUsU0FBUyxLQUFLLENBQUM1RCxZQUMzQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsZUFBZTZDO0FBQUFBLFlBQ2YsTUFBTXRFLGFBQWFTLGFBQWFjLFVBQVU7QUFBQSxZQUMxQztBQUFBLFlBQ0EsaUJBQWlCO0FBQUEsWUFDakIsa0JBQWtCO0FBQUE7QUFBQSxVQU5wQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNb0QsSUFHcEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTZCxZQUFZNEUsVUFBVTtBQUFBLFlBQy9CLE1BQU07QUFBQTtBQUFBLFVBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3lCO0FBQUEsUUFJM0IsdUJBQUMsU0FBSSxXQUFVLHVFQUNaLGlCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxTQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBO0FBQUEsSUFDQSx1QkFBQyxTQUFNLFdBQVcxRSxXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVTBFLGNBQWMsWUFBVSxNQUM1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQU07QUFBQTtBQUFBLGdCQUVDLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUE7QUFBQTtBQUFBLFlBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBT2hELFNBQVNHO0FBQUFBLGNBQ2hCLFVBQVUrQjtBQUFBQSxjQUNWLElBQUc7QUFBQSxjQUNILGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxXQUFXLHFDQUFxQ3BFLFVBQVVvRyxNQUFNO0FBQUE7QUFBQSxZQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRNko7QUFBQSxVQUU1SjFELE9BQU9MLFFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWSyxpQkFBT0wsUUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBYTtBQUFBO0FBQUEsZ0JBRVIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQTtBQUFBO0FBQUEsWUFKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPSCxTQUFTSztBQUFBQSxjQUNoQixVQUFVNkI7QUFBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVyxxQ0FBcUNwRSxVQUFVb0csTUFBTTtBQUFBO0FBQUEsWUFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUTZKO0FBQUEsVUFFNUoxRCxPQUFPSCxlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVkcsaUJBQU9ILGVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQVU7QUFBQTtBQUFBLGdCQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUE7QUFBQTtBQUFBLFlBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBT0wsU0FBU0k7QUFBQUEsY0FDaEIsVUFBVThCO0FBQUFBLGNBQ1YsSUFBRztBQUFBLGNBQ0gsYUFBWTtBQUFBLGNBQ1o7QUFBQSxjQUNBLFdBQVcscUNBQXFDcEUsVUFBVW9HLE1BQU07QUFBQTtBQUFBLFlBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVE2SjtBQUFBLFVBRTVKMUQsT0FBT0osWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCSSxpQkFBT0osWUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxhQWxCOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBTztBQUFBO0FBQUEsZ0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQTtBQUFBO0FBQUEsWUFKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPSixTQUFTTTtBQUFBQSxjQUNoQixVQUFVNEI7QUFBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVyxxQ0FBcUNwRSxVQUFVb0csTUFBTTtBQUFBO0FBQUEsWUFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUTZKO0FBQUEsVUFFNUoxRCxPQUFPRixTQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVkUsaUJBQU9GLFNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxRQUdBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQU87QUFBQTtBQUFBLGdCQUVLLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUE7QUFBQTtBQUFBLFlBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFZQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osdUJBQXVCO0FBQUEsY0FDdkI7QUFBQSxjQUNBLE1BQUs7QUFBQSxjQUNMLGNBQWMsQ0FBQzZELE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTZCxZQUFZLEVBQUVDLFNBQVNXLE1BQU1aLFlBQVksQ0FBQztBQUFBLGNBRTVELE9BQU92RCxVQUFVTyx5QkFBeUIrRDtBQUFBQSxjQUMxQyxVQUFVLENBQUM3RSxVQUNUMkMsaUJBQWlCLHlCQUF5QjNDLEtBQUs7QUFBQSxjQUdoRFYsMEJBQWdCc0M7QUFBQUEsZ0JBQUksQ0FBQ2tELGdCQUNwQix1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFPQSxhQUFhL0MsS0FDaEMrQyx1QkFBYTVDLFNBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQSxZQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtQkE7QUFBQSxVQUNDbkIsT0FBT0QseUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWQyxpQkFBT0QseUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQ0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ21IO0FBQUE7QUFBQSxVQUgvSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBbkpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvSkE7QUFBQSxTQXhKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUpBLEtBMUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EySkE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXOUI7QUFBQUEsUUFDWCxTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFFdkMsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxnQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVW9GLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFNO0FBQUE7QUFBQSxvQkFFSCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBO0FBQUE7QUFBQSxnQkFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT3BELGVBQWVQO0FBQUFBLGtCQUN0QixVQUFVd0Q7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDN0YsVUFBVW9HLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNko7QUFBQSxjQUU1SjFELE9BQU9MLFFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWSyxpQkFBT0wsUUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBYztBQUFBO0FBQUEsb0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9PLGVBQWVMO0FBQUFBLGtCQUN0QixVQUFVc0Q7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDN0YsVUFBVW9HLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNko7QUFBQSxjQUU1SjFELE9BQU9ILGVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWRyxpQkFBT0gsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsb0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9LLGVBQWVOO0FBQUFBLGtCQUN0QixVQUFVdUQ7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDN0YsVUFBVW9HLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNko7QUFBQSxjQUU1SjFELE9BQU9KLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkksaUJBQU9KLFlBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBEO0FBQUEsaUJBbEI5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLG9CQUVHLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBZUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDK0QsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNkLFlBQVksRUFBRUMsU0FBU1csTUFBTVosWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU83QyxnQkFBZ0JILHlCQUF5QitEO0FBQUFBLGtCQUNoRCxVQUFVLENBQUM3RSxVQUNUOEMsc0JBQXNCLHlCQUF5QjlDLEtBQUs7QUFBQSxrQkFHckRWLDBCQUFnQnNDO0FBQUFBLG9CQUFJLENBQUNrRCxnQkFDcEIsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBT0EsYUFBYS9DLEtBQ2hDK0MsdUJBQWE1QyxTQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkE7QUFBQSxjQUNDbkIsT0FBT0QseUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWQyxpQkFBT0QseUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThDQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNxSDtBQUFBO0FBQUEsY0FIakk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQXpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBIQTtBQUFBLGFBOUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErSEE7QUFBQTtBQUFBLE1BbklGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW9JQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdoQztBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkksMEJBQWdCLElBQUk7QUFBQSxRQUN0QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxnQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NELGdCQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUNhLE1BQU07QUFDZkEsa0JBQUV5RCxlQUFlO0FBQ2pCVyxrQ0FBa0I7QUFBQSxjQUNwQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVztBQUFBO0FBQUEsd0JBRU47QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2JqRix1QkFBYXdCLFFBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFBUTtBQUFBLHdCQUFJO0FBQUEsd0JBQ1MsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUM7QUFBQTtBQUFBO0FBQUEsb0JBUnhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVyxxQ0FBcUNyQyxVQUFVb0csTUFBTTtBQUFBO0FBQUEsb0JBTGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLNko7QUFBQSxxQkFoQi9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDeUY7QUFBQTtBQUFBLGtCQUhyRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQTtBQUFBO0FBQUEsWUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0NBO0FBQUEsYUF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlDQTtBQUFBO0FBQUEsTUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBaURBO0FBQUEsT0ExWUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJZQSxLQTVZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNllBO0FBRUo7QUFBRWxHLEdBcnhCSUQsMEJBQXdCO0FBQUF5RyxLQUF4QnpHO0FBdXhCTixlQUFlQTtBQUF5QixJQUFBeUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTW9kYWwiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIklucHV0IiwiRHJvcGRvd24iLCJTZWxlY3QiLCJJb01kTW9yZSIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwiU2V0dGluZ1NpZGViYXIiLCJDdXN0b21BbGVydERpYWxvZyIsImZpZWxkU2l6ZSIsIkFkbWluaXN0cmF0aXZlUHJpdmlsZWdlcyIsIl9zIiwiYWRtaW5zIiwic2V0QWRtaW5zIiwiVGFibGVHcm91cHMiLCJzZXRUYWJsZUdyb3VwcyIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRBZG1pbiIsInNldEN1cnJlbnRBZG1pbiIsImN1cnJlbnRVcGRhdGVBZG1pbiIsInNldEN1cnJlbnRVcGRhdGVBZG1pbiIsImFsbEFjY2Vzc1JpZ2h0cyIsInNldEFsbEFjY2Vzc1JpZ2h0cyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImFkbWluX2NvZGUiLCJuYW1lIiwicGFzc3dvcmQiLCJwaG9uZU51bWJlciIsImVtYWlsIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsImZldGNoQWxsQWRtaW5SaWdodHMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJmZXRjaFN1YkFkbWlucyIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJhZG1pbiIsImluZGV4IiwiX2lkIiwiaWQiLCJhZG1pbl9hY2Nlc3NfcmlnaHQiLCJ0aXRsZSIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJoYW5kbGVDaGFuZ2UiLCJwcmV2RGF0YSIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInByZXZFcnJvcnMiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3QiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJ0cmltIiwiaXNOYU4iLCJ0ZXN0IiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZCIsInBvc3QiLCJoZWFkZXJzIiwicHJldiIsImxvZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJhZG1pbklkIiwiaW5mbyIsImhhbmRsZUlucHV0Q2hhbmdlIiwiaGFuZGxlRGVsZXRlQWRtaW4iLCJkZWxldGUiLCJoYW5kbGVVcGRhdGUiLCJwdXQiLCJjb2x1bW5zIiwiaGVhZGVyIiwiaGVpZ2h0IiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInVuZGVmaW5lZCIsImFjY2Vzc1JpZ2h0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWRtaW5pc3RyYXRpdmVQcml2aWxlZ2VzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIgIC8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbiAgaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG4gIGltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuICBpbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbiAgaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG4gIGltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuICBpbXBvcnQgeyBJbnB1dCwgRHJvcGRvd24sIFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbiAgaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuICBpbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbiAgaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuICBpbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG4gIGltcG9ydCBTZXR0aW5nU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NldHRpbmdTaWRlYmFyXCI7XHJcbiAgaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG4gIGltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5cclxuICBjb25zdCBBZG1pbmlzdHJhdGl2ZVByaXZpbGVnZXMgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbYWRtaW5zLCBzZXRBZG1pbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW1RhYmxlR3JvdXBzLCBzZXRUYWJsZUdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtzaG93TW9kYWxVcGRhdGUsIHNldFNob3dNb2RhbFVwZGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbY3VycmVudEFkbWluLCBzZXRDdXJyZW50QWRtaW5dID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICBjb25zdCBbY3VycmVudFVwZGF0ZUFkbWluLCBzZXRDdXJyZW50VXBkYXRlQWRtaW5dID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICBjb25zdCBbYWxsQWNjZXNzUmlnaHRzLCBzZXRBbGxBY2Nlc3NSaWdodHNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gICAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgIGFkbWluX2NvZGU6IFwiXCIsXHJcbiAgICAgIG5hbWU6IFwiXCIsXHJcbiAgICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgICBwaG9uZU51bWJlcjogXCJcIixcclxuICAgICAgZW1haWw6IFwiXCIsXHJcbiAgICAgIGFkbWluX2FjY2Vzc19yaWdodF9pZDogXCJcIixcclxuICAgIH0pO1xyXG4gICAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuXHJcbiAgICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgICAgbmFtZTogXCJcIixcclxuICAgICAgcGhvbmVOdW1iZXI6IFwiXCIsXHJcbiAgICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgICBhZG1pbl9hY2Nlc3NfcmlnaHRfaWQ6IFwiXCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGZldGNoQWxsQWRtaW5SaWdodHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZG1pbi1hY2Nlc3MtcmlnaHRzL2dldC1hbGxcIik7XHJcbiAgICAgICAgICBzZXRBbGxBY2Nlc3NSaWdodHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIEFjY2VzcyBSaWdodHNcIik7XHJcbiAgICAgICAgICBzZXRBbGxBY2Nlc3NSaWdodHMoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuICAgICAgZmV0Y2hBbGxBZG1pblJpZ2h0cygpO1xyXG4gICAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGZldGNoU3ViQWRtaW5zID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWRtaW4vZ2V0LXN1Yi1hZG1pbnNcIik7XHJcbiAgICAgICAgICBzZXRBZG1pbnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGFkbWluLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgX2lkOiBhZG1pbj8uX2lkLFxyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBhZG1pbl9jb2RlOiBhZG1pbj8uYWRtaW5fY29kZSxcclxuICAgICAgICAgICAgbmFtZTogYWRtaW4/Lm5hbWUsXHJcbiAgICAgICAgICAgIHBob25lTnVtYmVyOiBhZG1pbj8ucGhvbmVOdW1iZXIsXHJcbiAgICAgICAgICAgIHBhc3N3b3JkOiBhZG1pbj8ucGFzc3dvcmQsXHJcbiAgICAgICAgICAgIGFkbWluX2FjY2Vzc19yaWdodDogYWRtaW4/LmFkbWluX2FjY2Vzc19yaWdodF9pZD8udGl0bGUsXHJcbiAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbJ2NsaWNrJ119XHJcbiAgICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbihhZG1pbj8uX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVNb2RhbE9wZW4oYWRtaW4/Ll9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgc2V0VGFibGVHcm91cHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBBZG1pbiBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9O1xyXG4gICAgICBmZXRjaFN1YkFkbWlucygpO1xyXG4gICAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuXHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgIFtuYW1lXTogXCJcIixcclxuICAgICAgfSkpO1xyXG4gICAgfTtcclxuICAgIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZFcnJvcnMsXHJcbiAgICAgICAgW2ZpZWxkXTogXCJcIixcclxuICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVBbnRJbnB1dERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoeyAuLi5wcmV2RXJyb3JzLCBbZmllbGRdOiBcIlwiIH0pKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICBjb25zdCBkYXRhID0gdHlwZSA9PT0gXCJhZGRBZG1pblwiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuXHJcbiAgaWYgKCFkYXRhLm5hbWU/LnRyaW0oKSkge1xyXG4gICAgbmV3RXJyb3JzLm5hbWUgPSBcIkFkbWluIE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICB9XHJcblxyXG4gIGlmICghZGF0YS5wYXNzd29yZCkge1xyXG4gICAgbmV3RXJyb3JzLnBhc3N3b3JkID0gXCJQYXNzd29yZCBpcyByZXF1aXJlZFwiO1xyXG4gIH1cclxuXHJcbiAgaWYgKCFkYXRhLnBob25lTnVtYmVyIHx8IGlzTmFOKGRhdGEucGhvbmVOdW1iZXIpKSB7XHJcbiAgICBuZXdFcnJvcnMucGhvbmVOdW1iZXIgPSBcIlBob25lIE51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gIH1cclxuXHJcbiAgLy8g4pyFIE9ubHkgdmFsaWRhdGUgZW1haWwgZm9yIGFkZEFkbWluIGZvcm1cclxuICBpZiAodHlwZSA9PT0gXCJhZGRBZG1pblwiKSB7XHJcbiAgICBpZiAoIWRhdGEuZW1haWwgfHwgIWRhdGEuZW1haWwudHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5lbWFpbCA9IFwiRW1haWwgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoIS9cXFMrQFxcUytcXC5cXFMrLy50ZXN0KGRhdGEuZW1haWwpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5lbWFpbCA9IFwiRW1haWwgaXMgaW52YWxpZFwiO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaWYgKCFkYXRhLmFkbWluX2FjY2Vzc19yaWdodF9pZCkge1xyXG4gICAgbmV3RXJyb3JzLmFkbWluX2FjY2Vzc19yaWdodF9pZCA9IFwiU2VsZWN0IEFkbWluIEFjY2VzcyBSaWdodFwiO1xyXG4gIH1cclxuICBcclxuICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbn07XHJcblxyXG4gICAgLy8gY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIC8vICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcblxyXG4gICAgLy8gICBjb25zdCBkYXRhID0gdHlwZSA9PT0gXCJhZGRBZG1pblwiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuXHJcbiAgICAvLyAgIGlmICghZGF0YS5uYW1lLnRyaW0oKSkge1xyXG4gICAgLy8gICAgIG5ld0Vycm9ycy5uYW1lID0gXCJBZG1pbiBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAvLyAgIH1cclxuXHJcbiAgICAvLyAgIGlmICghZGF0YS5wYXNzd29yZCkge1xyXG4gICAgLy8gICAgIG5ld0Vycm9ycy5wYXNzd29yZCA9IFwiUGFzc3dvcmQgaXMgcmVxdWlyZWRcIjtcclxuICAgIC8vICAgfVxyXG5cclxuICAgIC8vICAgaWYgKCFkYXRhLnBob25lTnVtYmVyIHx8IGlzTmFOKGRhdGEucGhvbmVOdW1iZXIpKSB7XHJcbiAgICAvLyAgICAgbmV3RXJyb3JzLnBob25lTnVtYmVyID0gXCJQaG9uZSBOdW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIC8vICAgfVxyXG5cclxuICAgIC8vICAgaWYgKCFkYXRhLmVtYWlsIHx8ICFkYXRhLmVtYWlsLnRyaW0oKSkge1xyXG4gICAgLy8gICAgIG5ld0Vycm9ycy5lbWFpbCA9IFwiRW1haWwgaXMgcmVxdWlyZWRcIjtcclxuICAgIC8vICAgfSBlbHNlIGlmICghL1xcUytAXFxTK1xcLlxcUysvLnRlc3QoZGF0YS5lbWFpbCkpIHtcclxuICAgIC8vICAgICAvLyBCYXNpYyByZWdleCBmb3IgZW1haWwgZm9ybWF0XHJcbiAgICAvLyAgICAgbmV3RXJyb3JzLmVtYWlsID0gXCJFbWFpbCBpcyBpbnZhbGlkXCI7XHJcbiAgICAvLyAgIH1cclxuXHJcbiAgICAvLyAgIGlmICghZGF0YS5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQpIHtcclxuICAgIC8vICAgICBuZXdFcnJvcnMuYWRtaW5fYWNjZXNzX3JpZ2h0X2lkID0gXCJTZWxlY3QgQWRtaW4gQWNjZXNzIFJpZ2h0XCI7XHJcbiAgICAvLyAgIH1cclxuICAgIC8vICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICAvLyAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICAgIC8vIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgICAgXHJcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJhZGRBZG1pblwiKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi9hZG1pbi9hZGQtc3ViLWFkbWluXCIsIGZvcm1EYXRhLCB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIlN1YiBBZG1pbiBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICBuYW1lOiBcIlwiLFxyXG4gICAgICAgICAgICBwaG9uZU51bWJlcjogXCJcIixcclxuICAgICAgICAgICAgcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgICAgICAgICBhZG1pbl9hY2Nlc3NfcmlnaHRfaWQ6IFwiXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coZXJyb3JzKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIHN1YiBhZG1pbjpcIiwgZXJyb3IpO1xyXG5cclxuICAgIGlmIChcclxuICAgICAgZXJyb3IucmVzcG9uc2UgJiZcclxuICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YSAmJlxyXG4gICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2UgJiZcclxuICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJwaG9uZVwiKVxyXG4gICAgKSB7XHJcbiAgICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICAgIHBob25lTnVtYmVyOiBcIlBob25lIG51bWJlciBhbHJlYWR5IGV4aXN0c1wiLFxyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gICAgICBcclxuICAgIH07XHJcblxyXG5cclxuICAgIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jIChhZG1pbklkKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKGFkbWluSWQsXCJhZG1pbmlkXCIpXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYWRtaW4vZ2V0LWFkbWluLyR7YWRtaW5JZH1gKTtcclxuICAgICAgICBzZXRDdXJyZW50QWRtaW4ocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBTdWIgQWRtaW46XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAoYWRtaW5JZCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2FkbWluL2dldC1hZG1pbi8ke2FkbWluSWR9YCk7XHJcblxyXG4gICAgICAgIHNldEN1cnJlbnRVcGRhdGVBZG1pbihyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICBuYW1lOiByZXNwb25zZT8uZGF0YT8ubmFtZSxcclxuICAgICAgICAgIHBob25lTnVtYmVyOiByZXNwb25zZT8uZGF0YT8ucGhvbmVOdW1iZXIsXHJcbiAgICAgICAgICBwYXNzd29yZDogcmVzcG9uc2U/LmRhdGE/LnBhc3N3b3JkLFxyXG4gICAgICAgICAgYWRtaW5fYWNjZXNzX3JpZ2h0X2lkOiByZXNwb25zZT8uZGF0YT8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5faWQsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFkbWluOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuXHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldEVycm9ycyh7IC4uLmVycm9ycywgW25hbWVdOiBcIlwiIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVEZWxldGVBZG1pbiA9IGFzeW5jICgpID0+IHtcclxuICAgIFxyXG4gICAgICBpZiAoY3VycmVudEFkbWluKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9hZG1pbi9kZWxldGUtYWRtaW4vJHtjdXJyZW50QWRtaW4uX2lkfWApO1xyXG4gICAgICAgICAgLy8gYWxlcnQoXCJHcm91cCBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJBZG1pbiBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgIHNldEN1cnJlbnRBZG1pbihudWxsKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGFkbWluOlwiLCBlcnJvcik7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJ1cGRhdGVBZG1pblwiKTsgLy8g4pyFIFBhc3MgdGhlIHR5cGUgcGFyYW1ldGVyXHJcbiAgXHJcbiAgdHJ5IHtcclxuICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgIGNvbnNvbGUuaW5mbyhjdXJyZW50VXBkYXRlQWRtaW4sIHVwZGF0ZUZvcm1EYXRhLCBcInVwZGF0aW9uIGZvcm1cIik7XHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgYC9hZG1pbi91cGRhdGUtYWRtaW4vJHtjdXJyZW50VXBkYXRlQWRtaW4uX2lkfWAsXHJcbiAgICAgICAgdXBkYXRlRm9ybURhdGFcclxuICAgICAgKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgbWVzc2FnZTogXCJBZG1pbiB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0aW9uIGVycm9yczpcIiwgZXJyb3JzKTtcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIEFkbWluOlwiLCBlcnJvcik7XHJcbiAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRXJyb3IgdXBkYXRpbmcgYWRtaW5cIixcclxuICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgfSk7XHJcbiAgfVxyXG59O1xyXG5cclxuICAgIC8vIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICAvLyAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIC8vICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG5cclxuICAgIC8vICAgdHJ5IHtcclxuICAgIC8vICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgLy8gICAgICAgY29uc29sZS5pbmZvKGN1cnJlbnRVcGRhdGVBZG1pbix1cGRhdGVGb3JtRGF0YSxcInVwZGF0aW9uIGZvcm1cIilcclxuICAgIC8vICAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAvLyAgICAgICAgIGAvYWRtaW4vdXBkYXRlLWFkbWluLyR7Y3VycmVudFVwZGF0ZUFkbWluLl9pZH1gLFxyXG4gICAgLy8gICAgICAgICB1cGRhdGVGb3JtRGF0YVxyXG4gICAgLy8gICAgICAgKTtcclxuICAgIC8vICAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAvLyAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAvLyAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAvLyAgICAgICAgIG1lc3NhZ2U6IFwiQWRtaW4gdXBkYXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgIC8vICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAvLyAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAvLyAgICAgICB9KTtcclxuXHJcbiAgICAvLyAgICAgICAvL1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIC8vICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgQWRtaW46XCIsIGVycm9yKTtcclxuICAgIC8vICAgfVxyXG4gICAgLy8gfTtcclxuXHJcbiAgICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgICB7a2V5OiBcImlkXCIsIGhlYWRlcjogXCJTbCBOb1wifSxcclxuICAgICAge2tleTogXCJhZG1pbl9jb2RlXCIsIGhlYWRlcjogXCJBZG1pbiBDb2RlXCJ9LFxyXG4gICAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJBZG1pbiBOYW1lXCIgfSxcclxuICAgICAgeyBrZXk6IFwicGFzc3dvcmRcIiwgaGVhZGVyOiBcIlBhc3N3b3JkXCIgfSxcclxuICAgICAgeyBrZXk6IFwicGhvbmVOdW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICAgIHsga2V5OiBcImFkbWluX2FjY2Vzc19yaWdodFwiLCBoZWFkZXI6IFwiQWRtaW4gQWNjZXNzIFJvbGVcIiB9LFxyXG4gICAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgICBdO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDw+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICAgIDxTZXR0aW5nU2lkZWJhciAvPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEFkbWluaXN0cmF0aXZlIFByaXZpbGVnZXNcclxuICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICsgQWRkIFN1YiBBZG1pblxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7KFRhYmxlR3JvdXBzLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZykgPyAoXHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXtoYW5kbGVVcGRhdGVNb2RhbE9wZW59XHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZUdyb3Vwcywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT17YEFkbWluaXN0cmF0aXZlIFByaXZpbGVnZXNgfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgQWRtaW5pc3RyYXRpdmUgUHJpdmlsZWdlcy5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICBmYWlsdXJlPXtUYWJsZUdyb3Vwcy5sZW5ndGggPD0gMH1cclxuICAgICAgICAgICAgICAgICAgZGF0YT17XCJTdWIgQWRtaW4gRGF0YVwifVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTQgZ2FwLThcIj5cclxuICAgICAgICAgICAgICAgIHtcIiBcIn1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgQWRkIFN1YiBBZG1pblxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBTdWIgQWRtaW4gTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBTdWIgQWRtaW4gTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGhvbmVOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBob25lTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGhvbmVOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInBob25lTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFN1YiBBZG1pbiBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5waG9uZU51bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waG9uZU51bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGFzc3dvcmQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMucGFzc3dvcmR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBFbWFpbCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgU3ViIEFkbWluIEVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1haWwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBBZG1pbiBBY2Nlc3MgUmlnaHRzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFkbWluX2FjY2Vzc19yaWdodF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgQWRtaW4gUm9sZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHthbGxBY2Nlc3NSaWdodHMubWFwKChhZG1pblJvbGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9e2FkbWluUm9sZS5faWR9PnthZG1pblJvbGUudGl0bGV9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQWRtaW4gQWNjZXNzIFJvbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZG1pbl9hY2Nlc3NfcmlnaHRfaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmFkbWluX2FjY2Vzc19yaWdodF9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJhZG1pbl9hY2Nlc3NfcmlnaHRfaWRcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2FsbEFjY2Vzc1JpZ2h0cy5tYXAoKGFjY2Vzc1JpZ2h0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT17YWNjZXNzUmlnaHQ/Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthY2Nlc3NSaWdodD8udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkbWluX2FjY2Vzc19yaWdodF9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZG1pbl9hY2Nlc3NfcmlnaHRfaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMFxyXG4gICAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlciBib3JkZXItMiBib3JkZXItYmxhY2tcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU2F2ZSBTdWIgQWRtaW5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBVcGRhdGUgU3ViIEFkbWluXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEFkbWluIE5hbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQWRtaW4gTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGhvbmVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaG9uZU51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBob25lTnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInBob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBTdWIgQWRtaW4gUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVOdW1iZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBhc3N3b3JkIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMucGFzc3dvcmR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEFkbWluIEFjY2VzcyBSb2xlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZG1pbl9hY2Nlc3NfcmlnaHRfaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcblxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17XCJcIn0+U2VsZWN0IEFkbWluIEFjY2VzcyBSb2xlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge2FsbEFjY2Vzc1JpZ2h0cy5tYXAoKGFjY2Vzc1JpZ2h0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXthY2Nlc3NSaWdodD8uX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FjY2Vzc1JpZ2h0Py50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEFkbWluIEFjY2VzcyBSb2xlXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJhZG1pbl9hY2Nlc3NfcmlnaHRfaWRcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2FsbEFjY2Vzc1JpZ2h0cy5tYXAoKGFjY2Vzc1JpZ2h0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT17YWNjZXNzUmlnaHQ/Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthY2Nlc3NSaWdodD8udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkbWluX2FjY2Vzc19yaWdodF9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZG1pbl9hY2Nlc3NfcmlnaHRfaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwXHJcbiAgICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyIGJvcmRlci0yIGJvcmRlci1ibGFja1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFVwZGF0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgIHNldEN1cnJlbnRBZG1pbihudWxsKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBEZWxldGUgU3ViIEFkbWluXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICB7Y3VycmVudEFkbWluICYmIChcclxuICAgICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVBZG1pbigpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFkbWlubmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5IGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEFkbWluLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYWRtaW5uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEFkbWluIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC8+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGV4cG9ydCBkZWZhdWx0IEFkbWluaXN0cmF0aXZlUHJpdmlsZWdlcztcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0FkbWluaXN0cmF0aXZlUHJpdmlsZWdlcy5qc3gifQ==