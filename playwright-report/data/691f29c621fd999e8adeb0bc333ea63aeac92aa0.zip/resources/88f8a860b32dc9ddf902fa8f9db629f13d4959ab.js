import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/User.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Input, Select, Dropdown, Radio, Checkbox } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import handleEnrollmentRequestPrint from "/src/components/printFormats/enrollmentRequestPrint.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import { CloudUpload, X, Download, Check } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import PageWrapper from "/src/components/modals/PageWrapper.jsx";
import __vite__cjsImport18_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport18_dayjs.__esModule ? __vite__cjsImport18_dayjs.default : __vite__cjsImport18_dayjs;
import ReConfirmModal from "/src/components/modals/ReConfirmModal.jsx";
import { Modal as AntModal } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
const { confirm } = AntModal;
const STEPS = [
  { id: 1, label: "Basic Details" },
  { id: 2, label: "Additional & Payment" }
];
const User = ({ showUserModal, setShowUserModal }) => {
  _s();
  const [users, setUsers] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [TableUsers, setTableUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentUpdateUser, setCurrentUpdateUser] = useState(null);
  const [selectedGroup, setSelectedGroup] = useState({});
  const [groups, setGroups] = useState([]);
  const [areas, setAreas] = useState([]);
  const [files, setFiles] = useState({});
  const [districts, setDistricts] = useState([]);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [attachments, setAttachments] = useState([]);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [errors, setErrors] = useState({});
  const [showConfirm, setShowConfirm] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [sameAsAddress, setSameAsAddress] = useState(false);
  const [confirmData, setConfirmData] = useState({});
  const photoInputRef = useRef(null);
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone_number: "",
    password: "",
    address: "",
    permanent_address: "",
    pincode: "",
    adhaar_no: "",
    pan_no: "",
    track_source: "admin_panel",
    collection_area: "",
    referral_type: "",
    referred_employee: "",
    referred_agent: "",
    referred_customer: "",
    family_code: "",
    installment_type: "Daily",
    installment_amount: "",
    customer_relationship_manager: ""
  });
  const [updateFormData, setUpdateFormData] = useState({
    full_name: "",
    email: "",
    phone_number: "",
    password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    pan_no: "",
    title: "",
    gender: "",
    marital_status: "",
    dateofbirth: "",
    nationality: "",
    village: "",
    taluk: "",
    father_name: "",
    district: "",
    state: "",
    collection_area: "",
    customer_relationship_manager: "",
    alternate_number: "",
    referral_name: "",
    nominee_name: "",
    nominee_dateofbirth: "",
    nominee_phone_number: "",
    nominee_relationship: "",
    aadhar_frontphoto: "",
    aadhar_backphoto: "",
    pan_frontphoto: "",
    pan_backphoto: "",
    profilephoto: "",
    bank_name: "",
    bank_branch_name: "",
    bank_account_number: "",
    bank_IFSC_code: "",
    selected_plan: "",
    referral_type: "",
    referred_employee: "",
    referred_agent: "",
    referred_customer: "",
    installment_type: "",
    installment_amount: ""
  });
  const [searchText, setSearchText] = useState("");
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const location = useLocation();
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get("openModal") === "true") {
      setShowUserModal(true);
      window.history.replaceState({}, document.title, "/customer-menu/user");
    }
  }, [location]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setCustomers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get("/agent/get");
        setAgents(response.data?.agent);
      } catch (err) {
        console.error("Failed to fetch Leads", err);
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await api.get("/employee");
        setEmployees(response?.data?.employee);
      } catch (error) {
        console.error("failed to fetch employees", error);
      }
    };
    fetchEmployees();
  }, []);
  useEffect(() => {
    const fetchCollectionArea = async () => {
      try {
        const response = await api.get(
          "/collection-area-request/get-collection-area-data"
        );
        setAreas(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchCollectionArea();
    setAttachments([]);
  }, [reloadTrigger]);
  useEffect(() => {
    if (sameAsAddress) {
      setFormData((prev) => ({ ...prev, permanent_address: prev.address }));
    }
  }, [sameAsAddress, formData.address]);
  const handleSameAddressToggle = (e) => {
    const checked = e.target.checked;
    setSameAsAddress(checked);
    setFormData((prev) => ({
      ...prev,
      permanent_address: checked ? prev.address : ""
    }));
    setErrors((prev) => ({ ...prev, permanent_address: "" }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/user/get-new-user");
        setUsers(response.data);
        const formattedData = response.data.map((group, index) => ({
          _id: group._id,
          id: index + 1,
          customer_code: group?.customer_code,
          name: group.full_name,
          phone_number: group.phone_number,
          createdAt: group?.createdAt?.split("T")[0].split("-").reverse().join("-"),
          address: group.address,
          pincode: group.pincode,
          customer_id: group.customer_id,
          referral_type: group?.referral_type,
          referredBy: group?.referred_agent?.name && group?.referred_agent?.phone_number ? `${group.referred_agent.name} | ${group.referred_agent.phone_number}` : group?.referred_customer?.full_name && group?.referred_customer?.phone_number ? `${group.referred_customer.full_name} | ${group?.referred_customer?.phone_number}` : group?.referred_employee?.name && group?.referred_employee?.phone_number ? `${group.referred_employee.name} | ${group.referred_employee.phone_number}` : "N/A",
          trackSource: group?.track_source === "chit-customer-app" ? "Chit Customer" : group?.track_source === "admin_panel" ? "Chit Admin" : "Unknown",
          // referral_code: group?.referral_code,
          collection_area: group.collection_area?.route_name,
          customer_relationship_manager: group.customer_relationship_manager?.name,
          progressValue: group?.percentage,
          dob: group?.dateofbirth ? dayjs(group?.dateofbirth).format("YYYY-MM-DD") : "",
          progress: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "relative flex items-center justify-center w-12 h-12 rounded-full",
              style: {
                background: `conic-gradient(${group.percentage === 100 ? "#22c55e" : "#4f46e5"} ${group.percentage * 3.6}deg, #e5e7eb ${group.percentage * 3.6}deg)`
              },
              children: /* @__PURE__ */ jsxDEV("div", { className: "absolute flex items-center justify-center w-10 h-10 bg-white rounded-full shadow-sm", children: /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `text-xs font-semibold ${group.percentage === 100 ? "text-green-600" : "text-indigo-600"}`,
                  children: [
                    group?.percentage,
                    "%"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 294,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                lineNumber: 293,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
              lineNumber: 285,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
            lineNumber: 284,
            columnNumber: 11
          }, this),
          approval_status: group.approval_status === "true" ? "Approved" : group.approval_status === "false" ? "Pending" : "Approved",
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group?._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 321,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group?._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 332,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        onClick: () => handleEnrollmentRequestPrint(group?._id),
                        className: " text-blue-600 ",
                        children: "Print"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 343,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "4",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `cursor-pointer ${group?.approval_status !== "true" ? "text-green-600" : "text-red-600"}`,
                        onClick: () => handleCustomerStatusWithConfirm(
                          group?._id,
                          group?.approval_status !== "true" ? "true" : "false"
                        ),
                        children: group?.approval_status !== "true" ? "Approve Customer" : "Un Approve Customer"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 356,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                lineNumber: 380,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
              lineNumber: 314,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
            lineNumber: 313,
            columnNumber: 11
          }, this)
        }));
        let fData = formattedData.map((ele) => {
          if (ele?.address && typeof ele.address === "string" && ele?.address?.includes(","))
            ele.address = ele.address.replaceAll(",", " ");
          return ele;
        });
        if (!fData) setTableUsers(formattedData);
        if (!fData) setTableUsers(formattedData);
        setTableUsers(fData);
      } catch (error) {
        console.error("Error fetching user data:", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUsers();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchGroupData = async () => {
      try {
        const res = await api.get("group/get-group-admin");
        setGroups(res.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchGroupData();
  }, [reloadTrigger]);
  const handleAntDSelect = (field, value, option) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value,
      ...field === "collection_area" ? { collection_area_select: option } : {}
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const handleAntDSelectGroup = async (groupId) => {
    try {
      const response = await api.get(`/group/get-by-id-group/${groupId}`);
      setSelectedGroup(response.data);
    } catch (err) {
      console.error("Failed to fetch group:", err);
    }
  };
  const validateForm = (type, step = "all") => {
    const newErrors = {};
    const data = type === "addCustomer" ? formData : updateFormData;
    const regex = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[6-9]\d{9}$/,
      pincode: /^\d{6}$/,
      adhaar: /^\d{12}$/,
      pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/
    };
    const validateBasicDetails = () => {
      if (!data.full_name?.trim()) {
        newErrors.full_name = "Full Name is required";
      }
      if (data.email && !regex.email.test(data.email)) {
        newErrors.email = "Invalid email format";
      }
      if (!data.phone_number) {
        newErrors.phone_number = "Phone number is required";
      } else if (!regex.phone.test(data.phone_number)) {
        newErrors.phone_number = "Invalid  phone number";
      }
      if (type === "addCustomer" && !data.password) {
        newErrors.password = "Password is required";
      }
      if (!data.pincode) {
        newErrors.pincode = "Pincode is required";
      } else if (!regex.pincode.test(data.pincode)) {
        newErrors.pincode = "Invalid pincode (6 digits required)";
      }
      if (!data.adhaar_no) {
        newErrors.adhaar_no = "Aadhar number is required";
      } else if (!regex.adhaar.test(data.adhaar_no)) {
        newErrors.adhaar_no = "Invalid Aadhar number (12 digits required)";
      }
      if (data.pan_no && !regex.pan.test(data.pan_no.toUpperCase())) {
        newErrors.pan_no = "Invalid PAN format (e.g., ABCDE1234F)";
      }
      if (!data.address?.trim()) {
        newErrors.address = "Address is required";
      } else if (data.address.trim().length < 3) {
        newErrors.address = "Address should be at least 3 characters";
      }
      if (type === "addCustomer" && !sameAsAddress && !data.permanent_address?.trim()) {
        newErrors.permanent_address = "Permanent address is required";
      }
    };
    const validatePaymentDetails = () => {
      if (type === "addCustomer") {
        if (!data.installment_type) {
          newErrors.installment_type = "Payment type is required";
        }
        if (!data.installment_amount) {
          newErrors.installment_amount = "Payment amount is required";
        } else if (isNaN(data.installment_amount) || Number(data.installment_amount) <= 0) {
          newErrors.installment_amount = "Enter a valid amount";
        }
      }
    };
    if (type === "addCustomer") {
      if (step === 1) {
        validateBasicDetails();
      } else if (step === 2) {
        validatePaymentDetails();
      } else {
        validateBasicDetails();
        validatePaymentDetails();
      }
    } else {
      validateBasicDetails();
    }
    setErrors((prev) => ({ ...prev, ...newErrors }));
    return Object.keys(newErrors).length === 0;
  };
  const handleOpenConfirm = () => {
    const selectedEmployee = employees.find(
      (employee) => employee._id === formData.referred_employee
    );
    const selectedAgent = agents.find(
      (agent) => agent._id === formData.referred_agent
    );
    const selectedCustomer = customers.find(
      (customer) => customer._id === formData.referred_customer
    );
    const selectedCRM = employees.find(
      (employee) => employee._id === formData.customer_relationship_manager
    );
    setConfirmData({
      ...formData,
      referred_employee_select: formData.referral_type === "Employee" ? selectedEmployee ? `${selectedEmployee.name} | ${selectedEmployee.phone_number}` : "-" : void 0,
      referred_agent_select: formData.referral_type === "Agent" ? selectedAgent ? `${selectedAgent.name} | ${selectedAgent.phone_number}` : "-" : void 0,
      referred_customer_select: formData.referral_type === "Customer" ? selectedCustomer ? `${selectedCustomer.full_name} | ${selectedCustomer.phone_number}` : "-" : void 0,
      customer_relationship_manager_select: selectedCRM ? `${selectedCRM.name} | ${selectedCRM.phone_number}` : "-",
      collection_area_select: formData.collection_area_select || "-"
    });
    setShowConfirm(true);
  };
  const handleReconfirmation = (e) => {
    e.preventDefault();
    const isValid = validateForm("addCustomer", "all");
    if (!isValid) return;
    setShowConfirm(true);
    handleOpenConfirm();
  };
  const handleSaveAndContinue = (e) => {
    e.preventDefault();
    const isValid = validateForm("addCustomer", 1);
    if (!isValid) return;
    setCurrentStep(2);
  };
  const handleSaveAndExit = async (e) => {
    e.preventDefault();
    const isValid = validateForm("addCustomer", currentStep);
    if (!isValid) return;
    await handleSubmit(e);
  };
  const handleSubmit = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    try {
      const payload = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        payload.append(key, value);
      });
      if (attachments[0]) {
        payload.append("profilephoto", attachments[0]);
      }
      const response = await api.post("/user/add-new-user-admin", payload);
      if (response.status === 201) {
        setAlertConfig({
          visibility: true,
          message: "Customer added successfully",
          type: "success"
        });
        setFormData({
          full_name: "",
          email: "",
          phone_number: "",
          password: "",
          address: "",
          permanent_address: "",
          pincode: "",
          adhaar_no: "",
          pan_no: "",
          track_source: "admin_panel",
          collection_area: "",
          customer_relationship_manager: "",
          profilephoto: null,
          referral_type: "",
          referred_employee: "",
          referred_agent: "",
          referred_customer: "",
          family_code: "",
          installment_type: "Daily",
          installment_amount: ""
        });
        setAttachments([]);
        setShowConfirm(false);
        setSameAsAddress(false);
        setCurrentStep(1);
        setShowUserModal(false);
        setReloadTrigger((prev) => prev + 1);
      } else {
        setAlertConfig({
          visibility: true,
          message: response.data?.message || "Something went wrong",
          type: "error"
        });
      }
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || error.message || "Something went wrong",
        type: "error"
      });
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "createdAt", header: "Joined On" },
    { key: "customer_code", header: "Customer Code" },
    { key: "approval_status", header: "Approval Status" },
    { key: "customer_id", header: "Customer Id" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "address", header: "Customer Address" },
    { key: "pincode", header: "Customer Pincode" },
    { key: "referral_type", header: "Referred Type" },
    { key: "referredBy", header: "Referred By" },
    { key: "trackSource", header: "Track Source" },
    //  {key: "referral_code", header: "Referral Code"},
    { key: "collection_area", header: "Area" },
    { key: "customer_relationship_manager", header: "Relationship manager" },
    { key: "progress", header: "Progress" },
    { key: "action", header: "Action" }
  ];
  const printtableColumns = [
    { key: "id", header: "SL. NO" },
    { key: "approval_status", header: "Approval Status" },
    { key: "customer_id", header: "Customer Id" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "createdAt", header: "Joined On" },
    { key: "address", header: "Customer Address" },
    { key: "pincode", header: "Customer Pincode" },
    { key: "referral_type", header: "Referred Type" },
    { key: "referredBy", header: "Referred By" },
    { key: "trackSource", header: "Track Source" },
    { key: "dob", header: "DOB" },
    //  {key: "referral_code", header: "Referral Code"},
    { key: "collection_area", header: "Area" },
    { key: "progressValue", header: "Progress" },
    { key: "action", header: "Action" }
  ];
  const filteredUsers = users.filter(
    (user) => user.full_name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(`/user/get-user-by-id/${userId}`);
      setCurrentUser(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(`/user/get-user-by-id/${userId}`);
      setCurrentUpdateUser(response.data);
      setSelectedGroup(response?.data?.selected_plan);
      setUpdateFormData({
        full_name: response?.data?.full_name,
        email: response?.data?.email,
        phone_number: response?.data?.phone_number,
        password: response?.data?.password,
        pincode: response?.data?.pincode,
        adhaar_no: response?.data?.adhaar_no,
        pan_no: response?.data?.pan_no,
        address: response?.data?.address,
        selected_plan: response?.data?.selected_plan?._id || "",
        title: response?.data?.title,
        father_name: response?.data?.father_name,
        gender: response?.data?.gender,
        marital_status: response?.data?.marital_status,
        dateofbirth: response?.data?.dateofbirth?.split("T")[0],
        nationality: response?.data?.nationality,
        village: response?.data?.village,
        taluk: response?.data?.taluk,
        district: response?.data?.district,
        state: response?.data?.state,
        collection_area: response?.data?.collection_area?._id || "",
        customer_relationship_manager: response?.data?.customer_relationship_manager?._id || "",
        alternate_number: response?.data?.alternate_number,
        referral_name: response?.data?.referral_name,
        nominee_name: response?.data?.nominee_name,
        nominee_dateofbirth: response?.data?.nominee_dateofbirth?.split("T")[0],
        nominee_relationship: response?.data?.nominee_relationship,
        nominee_phone_number: response?.data?.nominee_phone_number,
        bank_name: response?.data?.bank_name,
        bank_branch_name: response?.data?.bank_branch_name,
        bank_account_number: response?.data?.bank_account_number,
        bank_IFSC_code: response?.data?.bank_IFSC_code,
        aadhar_frontphoto: response?.data?.aadhar_frontphoto,
        aadhar_backphoto: response?.data?.aadhar_backphoto,
        pan_frontphoto: response?.data?.pan_frontphoto,
        pan_backphoto: response?.data?.pan_backphoto,
        profilephoto: response?.data?.profilephoto,
        referral_type: response?.data?.referral_type,
        referred_employee: response?.data?.referred_employee || "",
        referred_agent: response?.data?.referred_agent || "",
        referred_customer: response?.data?.referred_customer || "",
        installment_type: response?.data?.installment_type || "",
        installment_amount: response?.data?.installment_amount || ""
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const handleDeleteUser = async () => {
    if (currentUser) {
      try {
        await api.delete(`/user/delete-user/${currentUser._id}`);
        setAlertConfig({
          visibility: true,
          message: "User deleted successfully",
          type: "success"
        });
        setReloadTrigger((prev) => prev + 1);
        setShowModalDelete(false);
        setCurrentUser(null);
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    }
  };
  const handleFileChange = (e) => {
    const { name, files: files2 } = e.target;
    const file = files2[0];
    if (file) {
      setUpdateFormData((prevState) => ({
        ...prevState,
        [name]: file
      }));
    }
  };
  const handleCustomerStatus = async (id, newStatus) => {
    try {
      if (!id) {
        console.warn("No user ID provided");
        return;
      }
      const response = await api.put(`/user/update-user/${id}`, {
        approval_status: newStatus
      });
      if (response.status === 200) {
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: `User status has been successfully updated to ${newStatus === "true" ? "Approved" : "Unapproved"}`,
          type: "success"
        });
        console.info(
          `Approval status updated to ${newStatus} for user ID:`,
          id
        );
      } else {
        console.warn("Failed to update customer status:", response?.data);
      }
    } catch (err) {
      console.error("Error updating customer status:", err.message);
    }
  };
  const handleCustomerStatusWithConfirm = (id, currentStatus) => {
    const isApproving = currentStatus === "true";
    const actionText = isApproving ? "approve" : "unapprove";
    confirm({
      title: `Are you sure?`,
      content: `Do you want to ${actionText} this customer?`,
      okText: "Yes",
      cancelText: "No",
      async onOk() {
        await handleCustomerStatus(id, currentStatus);
      }
    });
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const fmData = new FormData();
      Object.entries(updateFormData).forEach(([key, value]) => {
        if (key === "selected_plan" && selectedGroup?._id) {
          fmData.append("selected_plan", selectedGroup._id);
        } else if (value) {
          fmData.append(key, value);
        }
      });
      if (attachments[0]) {
        fmData.append("profilephoto", attachments[0]);
      }
      await api.put(`/user/update-user/${currentUpdateUser?._id}`, fmData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "User Updated Successfully",
        type: "success"
      });
      setErrors({});
    } catch (error) {
      console.error("Error updating user:", error);
      if (error.response && error.response.data && error.response.data.message && error.response.data.message.toLowerCase().includes("phone number already exists")) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          phone_number: "Phone number already exists"
        }));
      } else if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          type: "error",
          message: `${error?.response?.data?.message}`,
          visibility: true
        });
      } else {
        setAlertConfig({
          type: "error",
          message: "An unexpected error occurred. Please try again.",
          visibility: true
        });
      }
    }
  };
  const StepStatusBar = () => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center mb-6", children: STEPS.map(
    (step, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center", children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `w-9 h-9 flex items-center justify-center rounded-full border-2 text-sm font-semibold transition-colors ${currentStep === step.id ? "bg-blue-700 border-blue-700 text-white" : currentStep > step.id ? "bg-green-500 border-green-500 text-white" : "bg-white border-gray-300 text-gray-400"}`,
            children: currentStep > step.id ? /* @__PURE__ */ jsxDEV(Check, { size: 18 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
              lineNumber: 977,
              columnNumber: 40
            }, this) : step.id
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
            lineNumber: 969,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: `mt-1 text-xs font-medium whitespace-nowrap ${currentStep === step.id ? "text-blue-700" : "text-gray-400"}`,
            children: step.label
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
            lineNumber: 979,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
        lineNumber: 968,
        columnNumber: 11
      }, this),
      idx < STEPS.length - 1 && /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `w-16 h-0.5 mx-2 mb-5 ${currentStep > step.id ? "bg-green-500" : "bg-gray-300"}`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
          lineNumber: 987,
          columnNumber: 7
        },
        this
      )
    ] }, step.id, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
      lineNumber: 967,
      columnNumber: 5
    }, this)
  ) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
    lineNumber: 965,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-2", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
          lineNumber: 1002,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
          lineNumber: 1006,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-2 overflow-x-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: " mb-1 min-w-max", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Customers" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
          lineNumber: 1019,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
          lineNumber: 1018,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
          lineNumber: 1017,
          columnNumber: 13
        }, this),
        TableUsers?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableUsers, searchText),
            columns,
            exportCols: printtableColumns,
            isExportEnabled: true,
            exportedPdfName: "Customers",
            exportedFileName: `Customers.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
            lineNumber: 1034,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableUsers.length <= 0,
            data: "Customer Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
            lineNumber: 1045,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
        lineNumber: 1016,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
      lineNumber: 1e3,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showUserModal,
        onClose: () => {
          setShowUserModal(false);
          setCurrentStep(1);
        },
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
              lineNumber: 1062,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(StepStatusBar, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
              lineNumber: 1067,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "form",
              {
                className: "space-y-6",
                onSubmit: handleReconfirmation,
                noValidate: true,
                children: [
                  currentStep === 1 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV(
                        "label",
                        {
                          className: "block mb-2 text-sm font-medium text-gray-900",
                          htmlFor: "email",
                          children: [
                            "Full Name ",
                            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1082,
                              columnNumber: 33
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1078,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "full_name",
                          value: formData?.full_name,
                          onChange: handleChange,
                          id: "name",
                          placeholder: "Enter the Full Name",
                          required: true,
                          className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1084,
                          columnNumber: 21
                        },
                        this
                      ),
                      errors.full_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.full_name }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1095,
                        columnNumber: 19
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1077,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "date",
                            children: "Email"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1102,
                            columnNumber: 23
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            type: "email",
                            name: "email",
                            value: formData.email,
                            onChange: handleChange,
                            id: "text",
                            placeholder: "Enter Email",
                            required: true,
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1108,
                            columnNumber: 23
                          },
                          this
                        ),
                        errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1119,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1101,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "date",
                            children: [
                              "Phone Number ",
                              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1127,
                                columnNumber: 38
                              }, this)
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1123,
                            columnNumber: 23
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            type: "number",
                            name: "phone_number",
                            value: formData.phone_number,
                            onChange: handleChange,
                            id: "text",
                            placeholder: "Enter Phone Number",
                            required: true,
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1129,
                            columnNumber: 23
                          },
                          this
                        ),
                        errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1140,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1122,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1100,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "date",
                            children: [
                              "Password ",
                              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1152,
                                columnNumber: 34
                              }, this)
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1148,
                            columnNumber: 23
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            type: "text",
                            name: "password",
                            value: formData.password,
                            onChange: handleChange,
                            id: "text",
                            placeholder: "Enter Password",
                            required: true,
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1154,
                            columnNumber: 23
                          },
                          this
                        ),
                        errors.password && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.password }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1165,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1147,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "date",
                            children: [
                              "Pincode ",
                              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1175,
                                columnNumber: 33
                              }, this)
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1171,
                            columnNumber: 23
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            type: "number",
                            name: "pincode",
                            value: formData.pincode,
                            onChange: handleChange,
                            id: "text",
                            placeholder: "Enter Pincode",
                            required: true,
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1177,
                            columnNumber: 23
                          },
                          this
                        ),
                        errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1188,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1170,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1146,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "date",
                            children: [
                              "Adhaar Number ",
                              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1200,
                                columnNumber: 39
                              }, this)
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1196,
                            columnNumber: 23
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            type: "number",
                            name: "adhaar_no",
                            value: formData.adhaar_no,
                            onChange: handleChange,
                            id: "text",
                            placeholder: "Enter Adhaar Number",
                            required: true,
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1202,
                            columnNumber: 23
                          },
                          this
                        ),
                        errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1213,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1195,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "date",
                            children: "Pan Number"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1219,
                            columnNumber: 23
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            type: "text",
                            name: "pan_no",
                            value: formData?.pan_no,
                            onChange: handleChange,
                            id: "text",
                            placeholder: "Enter Pan Number",
                            required: true,
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1225,
                            columnNumber: 23
                          },
                          this
                        ),
                        errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1236,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1218,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1194,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV(
                        "label",
                        {
                          className: "block mb-2 text-sm font-medium text-gray-900",
                          htmlFor: "email",
                          children: [
                            "Address (Communication) ",
                            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1245,
                              columnNumber: 47
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1241,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "address",
                          value: formData.address,
                          onChange: handleChange,
                          id: "name",
                          placeholder: "Enter the Address",
                          required: true,
                          className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1247,
                          columnNumber: 21
                        },
                        this
                      ),
                      errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1258,
                        columnNumber: 19
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1240,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2 flex-wrap gap-2", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block text-sm font-medium text-gray-900",
                            htmlFor: "permanent_address",
                            children: [
                              "Permanent Address ",
                              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1269,
                                columnNumber: 43
                              }, this)
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1265,
                            columnNumber: 23
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Checkbox,
                          {
                            checked: sameAsAddress,
                            onChange: handleSameAddressToggle,
                            children: "Same as Communication Address"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1271,
                            columnNumber: 23
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1264,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "permanent_address",
                          value: formData.permanent_address,
                          onChange: handleChange,
                          disabled: sameAsAddress,
                          id: "permanent_address",
                          placeholder: "Enter the Permanent Address",
                          className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full ${sameAsAddress ? "opacity-60 cursor-not-allowed" : ""}`
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1278,
                          columnNumber: 21
                        },
                        this
                      ),
                      errors.permanent_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.permanent_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1290,
                        columnNumber: 19
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1263,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1076,
                    columnNumber: 15
                  }, this),
                  currentStep === 2 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: "Family Code" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1304,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            type: "text",
                            name: "family_code",
                            value: formData?.family_code,
                            onChange: handleChange,
                            placeholder: "Enter Family Code",
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1307,
                            columnNumber: 23
                          },
                          this
                        ),
                        errors.family_code && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.family_code }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1316,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1303,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                          "Referred Type ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1323,
                            columnNumber: 39
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1322,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`,
                            placeholder: "Select Referred Type",
                            popupMatchSelectWidth: false,
                            showSearch: true,
                            name: "referral_type",
                            filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                            value: formData?.referral_type || void 0,
                            onChange: (value) => handleAntDSelect("referral_type", value),
                            children: [
                              "Self Joining",
                              "Customer",
                              "Employee",
                              "Agent",
                              "Others"
                            ].map(
                              (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1344,
                                columnNumber: 23
                              }, this)
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1325,
                            columnNumber: 23
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1321,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1301,
                      columnNumber: 19
                    }, this),
                    formData.referral_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV(
                        "label",
                        {
                          className: "block mb-2 text-sm font-medium text-gray-900",
                          htmlFor: "category",
                          children: [
                            "Select Referred Customer",
                            " ",
                            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1359,
                              columnNumber: 25
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1354,
                          columnNumber: 23
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                          placeholder: "Select Or Search Referred Customer",
                          popupMatchSelectWidth: false,
                          showSearch: true,
                          name: "referred_customer",
                          filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                          value: formData?.referred_customer || void 0,
                          onChange: (value) => handleAntDSelect("referred_customer", value),
                          children: customers.map(
                            (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                              user.full_name,
                              " |",
                              " ",
                              user.phone_number ? user.phone_number : "No Number"
                            ] }, user._id, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1380,
                              columnNumber: 21
                            }, this)
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1362,
                          columnNumber: 23
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1353,
                      columnNumber: 17
                    }, this),
                    formData.referral_type === "Agent" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                        "Select Referred Agent",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1392,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1390,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                          placeholder: "Select or Search Referred Agent",
                          popupMatchSelectWidth: false,
                          showSearch: true,
                          name: "referred_agent",
                          filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                          value: formData.referred_agent || void 0,
                          onChange: (value) => handleAntDSelect("referred_agent", value),
                          children: agents.map(
                            (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                              agent.name,
                              " | ",
                              agent.phone_number
                            ] }, agent._id, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1412,
                              columnNumber: 21
                            }, this)
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1394,
                          columnNumber: 23
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1389,
                      columnNumber: 17
                    }, this),
                    formData.referral_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV(
                        "label",
                        {
                          className: "block mb-2 text-sm font-medium text-gray-900",
                          htmlFor: "category",
                          children: [
                            "Select Referred Employee",
                            " ",
                            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1426,
                              columnNumber: 25
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1421,
                          columnNumber: 23
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                          placeholder: "Select Or Search Referred Employee",
                          popupMatchSelectWidth: false,
                          showSearch: true,
                          name: "referred_employee",
                          filterOption: (input, option) => {
                            if (!option || !option.children) return false;
                            return option.children.toString().toLowerCase().includes(input.toLowerCase());
                          },
                          value: formData?.referred_employee || void 0,
                          onChange: (value) => handleAntDSelect("referred_employee", value),
                          children: employees.map(
                            (employee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: employee._id, children: [
                              employee.name,
                              " | ",
                              employee.phone_number
                            ] }, employee._id, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1449,
                              columnNumber: 21
                            }, this)
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1429,
                          columnNumber: 23
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1420,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "area",
                            children: "Collection Area"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1458,
                            columnNumber: 23
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                            placeholder: "Select Or Search Collection Area",
                            popupMatchSelectWidth: false,
                            name: "collection_area",
                            showSearch: true,
                            filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                            value: formData?.collection_area || void 0,
                            onChange: (value, option) => handleAntDSelect("collection_area", value, option.children),
                            children: areas.map(
                              (area) => /* @__PURE__ */ jsxDEV(Select.Option, { value: area._id, children: area.route_name }, area._id, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1482,
                                columnNumber: 23
                              }, this)
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1464,
                            columnNumber: 23
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1457,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "customer_relationship_manager",
                            children: "Customer Relationship Manager"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1490,
                            columnNumber: 23
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                            placeholder: "Select Or Search Customer Relationship Manager",
                            popupMatchSelectWidth: false,
                            name: "customer_relationship_manager",
                            showSearch: true,
                            filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                            value: formData?.customer_relationship_manager || void 0,
                            onChange: (value, option) => handleAntDSelect(
                              "customer_relationship_manager",
                              value,
                              option.children
                            ),
                            children: employees.map(
                              (employee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: employee._id, children: [
                                employee.name,
                                " | ",
                                employee.phone_number
                              ] }, employee._id, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1522,
                                columnNumber: 23
                              }, this)
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1497,
                            columnNumber: 23
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1489,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1456,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                          "Payment Frequency ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1533,
                            columnNumber: 43
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1532,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Radio.Group,
                          {
                            name: "installment_type",
                            value: formData.installment_type,
                            onChange: (e) => handleAntDSelect("installment_type", e.target.value),
                            children: [
                              /* @__PURE__ */ jsxDEV(Radio, { value: "daily", children: "Daily" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1542,
                                columnNumber: 25
                              }, this),
                              /* @__PURE__ */ jsxDEV(Radio, { value: "weekly", children: "Weekly" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1543,
                                columnNumber: 25
                              }, this),
                              /* @__PURE__ */ jsxDEV(Radio, { value: "monthly", children: "Monthly" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1544,
                                columnNumber: 25
                              }, this)
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1535,
                            columnNumber: 23
                          },
                          this
                        ),
                        errors.installment_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.installment_type }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1547,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1531,
                        columnNumber: 21
                      }, this),
                      formData.installment_type && /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                          formData.installment_type.charAt(0).toUpperCase() + formData.installment_type.slice(1),
                          " ",
                          "Installment Amount ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1558,
                            columnNumber: 46
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1555,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            type: "number",
                            name: "installment_amount",
                            value: formData.installment_amount,
                            onChange: handleChange,
                            placeholder: `Enter ${formData.installment_type} installment amount`,
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1560,
                            columnNumber: 25
                          },
                          this
                        ),
                        errors.installment_amount && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.installment_amount }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1569,
                          columnNumber: 21
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1554,
                        columnNumber: 19
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1530,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4", children: [
                      /* @__PURE__ */ jsxDEV(
                        "label",
                        {
                          className: "block  text-sm font-semibold text-gray-700",
                          htmlFor: "collection_area",
                          children: "Photo"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1579,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "label",
                        {
                          htmlFor: "attachment",
                          className: "relative flex flex-col items-center justify-center h-32 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 overflow-hidden",
                          children: [
                            /* @__PURE__ */ jsxDEV(
                              "input",
                              {
                                id: "attachment",
                                type: "file",
                                accept: ".jpeg,.jpg",
                                className: "hidden",
                                onChange: (e) => {
                                  const file = e.target.files[0];
                                  if (!file) return;
                                  if (!file.type.startsWith("image/jpeg") && !file.type.startsWith("image/jpg")) {
                                    alert("Only JPEG images are allowed!");
                                    return;
                                  }
                                  setAttachments([file]);
                                }
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1590,
                                columnNumber: 23
                              },
                              this
                            ),
                            attachments.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center z-10 pointer-events-none", children: [
                              /* @__PURE__ */ jsxDEV(CloudUpload, { size: 40, className: "text-gray-400 mb-2" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1615,
                                columnNumber: 27
                              }, this),
                              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-700", children: "Attach Photo" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1616,
                                columnNumber: 27
                              }, this),
                              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "JPEG only (Max 5MB)" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1619,
                                columnNumber: 27
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1614,
                              columnNumber: 21
                            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "relative h-32 w-full flex items-center justify-center", children: [
                              /* @__PURE__ */ jsxDEV(
                                "img",
                                {
                                  src: URL.createObjectURL(attachments[0]),
                                  alt: "preview",
                                  className: "h-full object-cover rounded"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                  lineNumber: 1625,
                                  columnNumber: 27
                                },
                                this
                              ),
                              /* @__PURE__ */ jsxDEV("div", { className: "absolute top-1 right-1 flex space-x-1", children: [
                                /* @__PURE__ */ jsxDEV(
                                  "button",
                                  {
                                    type: "button",
                                    onClick: () => setAttachments([]),
                                    className: "bg-red-500 text-white rounded-full p-1 hover:bg-red-600 shadow-sm",
                                    children: /* @__PURE__ */ jsxDEV(X, { size: 12 }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                      lineNumber: 1637,
                                      columnNumber: 31
                                    }, this)
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                    lineNumber: 1632,
                                    columnNumber: 29
                                  },
                                  this
                                ),
                                /* @__PURE__ */ jsxDEV(
                                  "a",
                                  {
                                    href: URL.createObjectURL(attachments[0]),
                                    download: attachments[0].name,
                                    className: "bg-blue-500 text-white rounded-full p-1 hover:bg-blue-600 shadow-sm",
                                    children: /* @__PURE__ */ jsxDEV(Download, { size: 12 }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                      lineNumber: 1646,
                                      columnNumber: 31
                                    }, this)
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                    lineNumber: 1641,
                                    columnNumber: 29
                                  },
                                  this
                                )
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 1630,
                                columnNumber: 27
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1624,
                              columnNumber: 21
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1586,
                          columnNumber: 21
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1578,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1300,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end gap-3 flex-wrap", children: [
                    currentStep === 2 && /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => setCurrentStep(1),
                        className: "text-gray-700 bg-white border-2 border-gray-300 hover:bg-gray-100 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                        children: "Back"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1659,
                        columnNumber: 17
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: handleSaveAndExit,
                        className: "text-gray-700 bg-white border-2 border-gray-400 hover:bg-gray-100 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                        children: "Save & Exit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1667,
                        columnNumber: 17
                      },
                      this
                    ),
                    currentStep === 1 ? /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: handleSaveAndContinue,
                        className: "text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                        children: "Save & Continue"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1675,
                        columnNumber: 17
                      },
                      this
                    ) : /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "submit",
                        className: "text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                        children: "Save Customer"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1684,
                        columnNumber: 17
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1657,
                    columnNumber: 15
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                lineNumber: 1069,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
            lineNumber: 1061,
            columnNumber: 11
          }, this),
          showConfirm && /* @__PURE__ */ jsxDEV(
            ReConfirmModal,
            {
              isOpen: showConfirm,
              title: "Confirm Details",
              data: confirmData,
              onCancel: () => setShowConfirm(false),
              onConfirm: handleSubmit
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
              lineNumber: 1696,
              columnNumber: 11
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
        lineNumber: 1054,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `py-6 px-5 lg:px-8 text-left ${!updateFormData || Object.keys(updateFormData).length === 0 ? "bg-red-50" : ""}`,
            children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                lineNumber: 1718,
                columnNumber: 13
              }, this),
              !updateFormData || Object.keys(updateFormData).length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-lg", children: "No customer data available" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                lineNumber: 1723,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                lineNumber: 1722,
                columnNumber: 13
              }, this) : /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "title",
                        children: "Title"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1731,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: `${!updateFormData?.title || updateFormData?.title.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full`,
                        placeholder: "Select Title",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "title",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData?.title || void 0,
                        onChange: (value) => handleAntInputDSelect("title", value),
                        children: [
                          /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "Select Title" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1758,
                            columnNumber: 23
                          }, this),
                          ["Mr", "Ms", "Mrs", "M/S", "Dr"].map(
                            (cTitle) => /* @__PURE__ */ jsxDEV(Select.Option, { value: cTitle, children: cTitle }, cTitle, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 1760,
                              columnNumber: 21
                            }, this)
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1738,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1730,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "email",
                        children: [
                          "Full Name ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1772,
                            columnNumber: 33
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1768,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "full_name",
                        value: updateFormData?.full_name,
                        onChange: handleInputChange,
                        id: "name",
                        placeholder: "Enter the Full Name",
                        required: true,
                        className: `${!updateFormData?.full_name || updateFormData?.full_name.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1774,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.full_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.full_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1790,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1767,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 1729,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: "Email"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1798,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "email",
                        name: "email",
                        value: updateFormData?.email,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Email",
                        required: true,
                        className: `${!updateFormData?.email || updateFormData?.email.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1804,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1820,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1797,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Phone Number ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1830,
                            columnNumber: 36
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1826,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "number",
                        name: "phone_number",
                        value: updateFormData?.phone_number,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Phone Number",
                        required: true,
                        className: `${!updateFormData?.phone_number || updateFormData?.phone_number.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1832,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1848,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1825,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 1796,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Aadhar Number ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1860,
                            columnNumber: 37
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1856,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "adhaar_no",
                        value: updateFormData?.adhaar_no,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Adhaar Number",
                        required: true,
                        className: `${!updateFormData?.adhaar_no || updateFormData?.adhaar_no.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1862,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1878,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1855,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: "Pan Number"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1884,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "pan_no",
                        value: updateFormData?.pan_no,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Pan Number",
                        required: true,
                        className: `${!updateFormData?.pan_no || updateFormData?.pan_no.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1890,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1906,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1883,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 1854,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "address",
                      children: [
                        "Address ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 1917,
                          columnNumber: 29
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1913,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      name: "address",
                      value: updateFormData?.address,
                      onChange: handleInputChange,
                      id: "address",
                      placeholder: "Enter the Address",
                      required: true,
                      className: `${!updateFormData?.address || updateFormData?.address.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1919,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1935,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 1912,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Pincode ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 1946,
                            columnNumber: 31
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1942,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "pincode",
                        value: updateFormData?.pincode,
                        onChange: handleInputChange,
                        id: "text",
                        placeholder: "Enter Pincode",
                        required: true,
                        className: `${!updateFormData?.pincode || updateFormData?.pincode.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1948,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1964,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1941,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "email",
                        children: "Father Name"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1971,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "father_name",
                        value: updateFormData?.father_name,
                        onChange: handleInputChange,
                        id: "father-name",
                        placeholder: "Enter the Father name",
                        className: `${!updateFormData?.father_name || updateFormData?.father_name.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 1977,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1970,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 1940,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                    "Referred Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1995,
                      columnNumber: 35
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 1994,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`,
                      placeholder: "Select Referred Type",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "referral_type",
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      value: updateFormData?.referral_type || void 0,
                      onChange: (value) => handleAntInputDSelect("referral_type", value),
                      children: [
                        "Self Joining",
                        "Customer",
                        "Employee",
                        "Agent",
                        "Others"
                      ].map(
                        (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2020,
                          columnNumber: 19
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 1997,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 1993,
                  columnNumber: 17
                }, this),
                updateFormData.referral_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "category",
                      children: [
                        "Select Referred Customer",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2033,
                          columnNumber: 23
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2028,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                      placeholder: "Select Or Search Referred Customer",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "referred_customer",
                      filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                      value: updateFormData?.referred_customer || void 0,
                      onChange: (value) => handleAntInputDSelect("referred_customer", value),
                      children: customers?.map(
                        (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                          user.full_name,
                          " |",
                          " ",
                          user.phone_number ? user.phone_number : "No Number"
                        ] }, user._id, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2054,
                          columnNumber: 19
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2036,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2027,
                  columnNumber: 15
                }, this),
                updateFormData.referral_type === "Agent" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Select Referred Agent",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2066,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2064,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                      placeholder: "Select or Search Referred Agent",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "referred_agent",
                      filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                      value: updateFormData.referred_agent || void 0,
                      onChange: (value) => handleAntInputDSelect("referred_agent", value),
                      children: agents.map(
                        (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                          agent.name,
                          " | ",
                          agent.phone_number
                        ] }, agent._id, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2086,
                          columnNumber: 19
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2068,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2063,
                  columnNumber: 15
                }, this),
                updateFormData.referral_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "category",
                      children: [
                        "Select Referred Employee",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2100,
                          columnNumber: 23
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2095,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                      placeholder: "Select Or Search Referred Employee",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "referred_employee",
                      filterOption: (input, option) => {
                        if (!option || !option.children) return false;
                        return option.children.toString().toLowerCase().includes(input.toLowerCase());
                      },
                      value: updateFormData?.referred_employee || void 0,
                      onChange: (value) => handleAntInputDSelect("referred_employee", value),
                      children: employees.map(
                        (employee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: employee._id, children: [
                          employee.name,
                          " | ",
                          employee.phone_number
                        ] }, employee._id, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2123,
                          columnNumber: 19
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2103,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2094,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "area",
                      children: "Collection Area"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2132,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: `${!updateFormData?.father_name || updateFormData?.father_name.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full`,
                      placeholder: "Select Or Search Collection Area",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "collection_area",
                      filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                      value: updateFormData?.collection_area || void 0,
                      onChange: (value) => handleAntInputDSelect("collection_area", value),
                      children: [
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "Select or Search Collection Area" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2160,
                          columnNumber: 23
                        }, this),
                        areas.map(
                          (area) => /* @__PURE__ */ jsxDEV(Select.Option, { value: area._id, children: area.route_name }, area._id, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2164,
                            columnNumber: 21
                          }, this)
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2139,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2131,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2130,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "customer_relationship_manager",
                      children: "Customer Relationship Manager"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2173,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select Or Search Customer Relationship Manager",
                      popupMatchSelectWidth: false,
                      name: "customer_relationship_manager",
                      showSearch: true,
                      filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                      value: updateFormData?.customer_relationship_manager || void 0,
                      onChange: (value, option) => handleAntInputDSelect(
                        "customer_relationship_manager",
                        value,
                        option.children
                      ),
                      children: employees.map(
                        (employee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: employee._id, children: [
                          employee.name,
                          " | ",
                          employee.phone_number
                        ] }, employee._id, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2204,
                          columnNumber: 19
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2180,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2172,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: "Customer Date of Birth"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2212,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "date",
                        name: "dateofbirth",
                        value: updateFormData?.dateofbirth ? new Date(updateFormData?.dateofbirth || "").toISOString().split("T")[0] : "",
                        className: `${!updateFormData?.dateofbirth || updateFormData?.dateofbirth.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                        onChange: handleInputChange,
                        id: "date",
                        placeholder: "Enter the Date of Birth"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2218,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2211,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "gender",
                        children: "Gender"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2241,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: `${!updateFormData?.gender || updateFormData?.gender.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full`,
                        placeholder: "Select Gender",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "gender",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData?.gender || void 0,
                        onChange: (value) => handleAntInputDSelect("gender", value),
                        children: ["Male", "Female"].map(
                          (gType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: gType, children: gType }, gType, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2269,
                            columnNumber: 21
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2248,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2240,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2210,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "marital-status",
                        children: "Marital Status"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2278,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: `${!updateFormData?.marital_status || updateFormData?.marital_status.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full`,
                        placeholder: "Select Marital Status",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "marital_status",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData?.marital_status || void 0,
                        onChange: (value) => handleAntInputDSelect("marital_status", value),
                        children: ["Married", "Unmarried", "Widow", "Divorced"].map(
                          (mStatus) => /* @__PURE__ */ jsxDEV(Select.Option, { value: mStatus, children: mStatus }, mStatus, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2307,
                            columnNumber: 23
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2285,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2277,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "referral-name",
                        children: "Referral Name"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2316,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "referral_name",
                        value: updateFormData?.referral_name,
                        onChange: handleInputChange,
                        id: "referral-name",
                        placeholder: "Enter the Referral Name",
                        className: `${!updateFormData?.referral_name || updateFormData?.referral_name.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2322,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2315,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2276,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "nationality",
                        children: "Nationality"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2340,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: `${!updateFormData?.nationality || updateFormData?.nationality.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full`,
                        placeholder: "Select Nationality",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "nationality",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData?.nationality || void 0,
                        onChange: (value) => handleAntInputDSelect("nationality", value),
                        children: ["Indian", "Other"].map(
                          (nation) => /* @__PURE__ */ jsxDEV(Select.Option, { value: nation, children: nation }, nation, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2368,
                            columnNumber: 21
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2347,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2339,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "alternate-number",
                        children: "Alternate Phone Number"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2376,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "number",
                        name: "alternate_number",
                        value: updateFormData?.alternate_number,
                        onChange: handleInputChange,
                        id: "alternate-number",
                        placeholder: "Enter the Alternate Phone number",
                        className: `${!updateFormData?.alternate_number || updateFormData?.alternate_number.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2382,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2375,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2338,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "village",
                        children: "Village"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2400,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "village",
                        value: updateFormData?.village,
                        onChange: handleInputChange,
                        id: "village",
                        placeholder: "Enter the Village",
                        className: `${!updateFormData?.village || updateFormData?.village.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2406,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2399,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "taluk",
                        children: "Taluk"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2423,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "taluk",
                        value: updateFormData?.taluk,
                        onChange: handleInputChange,
                        id: "taluk",
                        placeholder: "Enter the taluk",
                        className: `${!updateFormData?.taluk || updateFormData?.taluk.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2429,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2422,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2398,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "state",
                        children: "State"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2447,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: `${!updateFormData?.taluk || updateFormData?.taluk.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full`,
                        placeholder: "Select State",
                        showSearch: true,
                        name: "state",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData?.state || void 0,
                        onChange: (value) => handleAntInputDSelect("state", value),
                        children: ["Karnataka", "Maharashtra", "Tamil Nadu"].map(
                          (state) => /* @__PURE__ */ jsxDEV(Select.Option, { value: state, children: state }, state, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2475,
                            columnNumber: 23
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2454,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2446,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "district",
                        children: "District"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2484,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "district",
                        value: updateFormData?.district,
                        onChange: handleInputChange,
                        placeholder: "Enter District",
                        className: `${!updateFormData?.district || updateFormData?.district.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2491,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2483,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2445,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "nominee",
                        children: "Nominee Name"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2509,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "nominee_name",
                        value: updateFormData?.nominee_name,
                        onChange: handleInputChange,
                        id: "nominee",
                        placeholder: "Enter the Nominee Name",
                        className: `${!updateFormData?.nominee_name || updateFormData?.nominee_name.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2515,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2508,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "nominee-date",
                        children: "Nominee Date of Birth"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2532,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "date",
                        name: "nominee_dateofbirth",
                        value: updateFormData?.nominee_dateofbirth ? new Date(updateFormData?.nominee_dateofbirth).toISOString().split("T")[0] : "",
                        onChange: handleInputChange,
                        id: "nominee-date",
                        placeholder: "Enter the Nominee Date of Birth",
                        className: `${!updateFormData?.nominee_dateofbirth || updateFormData?.nominee_dateofbirth.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2538,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2531,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2507,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "nominee-relationship",
                        children: "Nominee Relationship"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2562,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: `${!updateFormData?.nominee_relationship || updateFormData?.nominee_relationship.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full`,
                        placeholder: "Select Nominee Relationship",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "nominee_relationship",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData?.nominee_relationship || void 0,
                        onChange: (value) => handleAntInputDSelect("nominee_relationship", value),
                        children: [
                          "Father",
                          "Mother",
                          "Brother/Sister",
                          "Spouse",
                          "Son/Daughter",
                          "Other"
                        ].map(
                          (nominee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: nominee, children: nominee }, nominee, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2597,
                            columnNumber: 21
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2569,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2561,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "nominee-phone-number",
                        children: "Nominee Phone Number"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2605,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "number",
                        name: "nominee_phone_number",
                        value: updateFormData?.nominee_phone_number,
                        onChange: handleInputChange,
                        id: "nominee-phone-number",
                        placeholder: "Enter the Nominee Phone number",
                        className: `${!updateFormData?.nominee_phone_number || updateFormData?.nominee_phone_number.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2611,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2604,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2560,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "bank-name",
                        children: "Bank Name"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2629,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "bank_name",
                        value: updateFormData?.bank_name,
                        onChange: handleInputChange,
                        id: "bank-name",
                        placeholder: "Enter the Customer Bank Name",
                        className: `${!updateFormData?.bank_name || updateFormData?.bank_name.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2635,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2628,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "bank-branch-name",
                        children: "Bank Branch Name"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2652,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "bank_branch_name",
                        value: updateFormData?.bank_branch_name,
                        onChange: handleInputChange,
                        id: "bank-branch-name",
                        placeholder: "Enter the Bank Branch Name",
                        className: `${!updateFormData?.bank_branch_name || updateFormData?.bank_branch_name.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2658,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2651,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2627,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "account-number",
                        children: "Bank Account Number"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2676,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "bank_account_number",
                        value: updateFormData?.bank_account_number,
                        onChange: handleInputChange,
                        id: "account-number",
                        placeholder: "Enter the Customer Bank Account Number",
                        className: `${!updateFormData?.bank_account_number || updateFormData?.bank_account_number.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2682,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2675,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "ifsc",
                        children: "Bank IFSC Code"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2699,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "bank_IFSC_code",
                        value: updateFormData?.bank_IFSC_code,
                        onChange: handleInputChange,
                        id: "ifsc",
                        placeholder: "Enter the Bank IFSC Code",
                        className: `${!updateFormData?.bank_IFSC_code || updateFormData?.bank_IFSC_code.trim() === "" ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2705,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2698,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2674,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Type" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2725,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Radio.Group,
                      {
                        name: "installment_type",
                        value: updateFormData?.installment_type,
                        onChange: (e) => handleAntInputDSelect("installment_type", e.target.value),
                        children: [
                          /* @__PURE__ */ jsxDEV(Radio, { value: "daily", children: "Daily" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2735,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV(Radio, { value: "weekly", children: "Weekly" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2736,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV(Radio, { value: "monthly", children: "Monthly" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2737,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2728,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2724,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "installment_amount",
                        children: "Payment Amount"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2742,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "number",
                        name: "installment_amount",
                        value: updateFormData?.installment_amount,
                        onChange: handleInputChange,
                        id: "installment_amount",
                        placeholder: "Enter Payment Amount",
                        className: `${!updateFormData?.installment_amount ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-300"} ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                        lineNumber: 2748,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2741,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2723,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block text-sm font-semibold text-gray-700",
                      htmlFor: "photo",
                      children: "Photo"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2767,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "relative h-32 w-full border-2 border-dashed rounded-lg overflow-hidden flex items-center justify-center cursor-pointer bg-gray-50 hover:bg-gray-100",
                      onClick: () => photoInputRef.current?.click(),
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            ref: photoInputRef,
                            id: "photo",
                            type: "file",
                            accept: ".jpeg,.jpg",
                            className: "hidden",
                            onChange: (e) => {
                              const file = e.target.files[0];
                              if (!file) return;
                              if (!file.type.startsWith("image/jpeg") && !file.type.startsWith("image/jpg")) {
                                alert("Only JPEG images are allowed!");
                                return;
                              }
                              setAttachments([file]);
                            }
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2777,
                            columnNumber: 21
                          },
                          this
                        ),
                        attachments.length === 0 && !updateFormData?.profilephoto ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center pointer-events-none", children: [
                          /* @__PURE__ */ jsxDEV(CloudUpload, { size: 40, className: "text-gray-400 mb-2" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2801,
                            columnNumber: 25
                          }, this),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-700", children: "Attach Photo" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2802,
                            columnNumber: 25
                          }, this),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "JPEG only (Max 5MB)" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2805,
                            columnNumber: 25
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2800,
                          columnNumber: 19
                        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "relative h-full w-full flex items-center justify-center", children: [
                          /* @__PURE__ */ jsxDEV(
                            "img",
                            {
                              src: attachments?.length > 0 ? URL.createObjectURL(attachments[0]) : updateFormData?.profilephoto,
                              alt: "preview",
                              className: "h-full w-full object-contain rounded",
                              onClick: () => setShowPreview(true)
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 2811,
                              columnNumber: 25
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-1 right-1 flex space-x-1", children: (attachments?.length > 0 || updateFormData?.profilephoto) && /* @__PURE__ */ jsxDEV(
                            "a",
                            {
                              href: attachments?.length > 0 ? URL.createObjectURL(attachments[0]) : updateFormData?.profilephoto,
                              download: attachments?.length > 0 ? attachments[0].name : void 0,
                              className: "bg-blue-500 text-white rounded-full p-1 hover:bg-blue-600 shadow-sm",
                              children: /* @__PURE__ */ jsxDEV(Download, { size: 12 }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 2839,
                                columnNumber: 33
                              }, this)
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                              lineNumber: 2826,
                              columnNumber: 23
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                            lineNumber: 2823,
                            columnNumber: 25
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2810,
                          columnNumber: 19
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2775,
                      columnNumber: 19
                    },
                    this
                  ),
                  showPreview && /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50",
                      onClick: () => setShowPreview(false),
                      children: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "relative",
                          onClick: (e) => e.stopPropagation(),
                          children: [
                            /* @__PURE__ */ jsxDEV(
                              "button",
                              {
                                onClick: () => setShowPreview(false),
                                className: "absolute top-2 right-2 text-white bg-gray-800 bg-opacity-70 hover:bg-gray-700 rounded-full p-2 shadow-lg z-10",
                                children: /* @__PURE__ */ jsxDEV(X, { size: 20 }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                  lineNumber: 2862,
                                  columnNumber: 27
                                }, this)
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 2858,
                                columnNumber: 25
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              "img",
                              {
                                src: attachments?.length > 0 ? URL.createObjectURL(attachments[0]) : updateFormData?.profilephoto,
                                alt: "large preview",
                                className: "max-h-[90vh] max-w-[90vw] rounded-lg shadow-lg"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                                lineNumber: 2866,
                                columnNumber: 25
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2853,
                          columnNumber: 23
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2849,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2765,
                  columnNumber: 17
                }, this),
                " ",
                /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Update"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2880,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2879,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                lineNumber: 1728,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
            lineNumber: 1712,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
        lineNumber: 1708,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentUser(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
            lineNumber: 2900,
            columnNumber: 13
          }, this),
          currentUser && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteUser();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentUser.full_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2917,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                          lineNumber: 2921,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2912,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the User Full Name",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                      lineNumber: 2923,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                  lineNumber: 2911,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
                    lineNumber: 2931,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
              lineNumber: 2904,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
          lineNumber: 2899,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
        lineNumber: 2892,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
    lineNumber: 999,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx",
    lineNumber: 998,
    columnNumber: 5
  }, this);
};
_s(User, "TzTKTzpqiZlQ8dWGagnS//7jtvc=", false, function() {
  return [useLocation];
});
_c = User;
export default User;
var _c;
$RefreshReg$(_c, "User");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/User.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcVNrQixTQTh3QkYsVUE5d0JFOzJCQXJTbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxPQUFPQyxRQUFRQyxVQUFVQyxPQUFPQyxnQkFBZ0I7QUFDekQsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxrQ0FBa0M7QUFDekMsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxhQUFhQyxHQUFHQyxVQUFVQyxhQUFhO0FBQ2hELE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTckIsU0FBU3NCLGdCQUFnQjtBQUNsQyxTQUFTQyxtQkFBbUI7QUFHNUIsTUFBTSxFQUFFQyxRQUFRLElBQUlGO0FBR3BCLE1BQU1HLFFBQVE7QUFBQSxFQUNaLEVBQUVDLElBQUksR0FBR0MsT0FBTyxnQkFBZ0I7QUFBQSxFQUNoQyxFQUFFRCxJQUFJLEdBQUdDLE9BQU8sdUJBQXVCO0FBQUM7QUFHMUMsTUFBTUMsT0FBT0EsQ0FBQyxFQUFFQyxlQUFlQyxpQkFBaUIsTUFBTTtBQUFBQyxLQUFBO0FBQ3BELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJbkMsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ29DLFdBQVdDLFlBQVksSUFBSXJDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNzQyxRQUFRQyxTQUFTLElBQUl2QyxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDd0MsV0FBV0MsWUFBWSxJQUFJekMsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzBDLFlBQVlDLGFBQWEsSUFBSTNDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM0QyxZQUFZQyxhQUFhLElBQUk3QyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDOEMsV0FBV0MsWUFBWSxJQUFJL0MsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2dELGlCQUFpQkMsa0JBQWtCLElBQUlqRCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDa0QsaUJBQWlCQyxrQkFBa0IsSUFBSW5ELFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNvRCxhQUFhQyxjQUFjLElBQUlyRCxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDc0QsV0FBV0MsWUFBWSxJQUFJdkQsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3dELG1CQUFtQkMsb0JBQW9CLElBQUl6RCxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDMEQsZUFBZUMsZ0JBQWdCLElBQUkzRCxTQUFTLENBQUMsQ0FBQztBQUNyRCxRQUFNLENBQUM0RCxRQUFRQyxTQUFTLElBQUk3RCxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDOEQsT0FBT0MsUUFBUSxJQUFJL0QsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2dFLE9BQU9DLFFBQVEsSUFBSWpFLFNBQVMsQ0FBQyxDQUFDO0FBQ3JDLFFBQU0sQ0FBQ2tFLFdBQVdDLFlBQVksSUFBSW5FLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNvRSxlQUFlQyxnQkFBZ0IsSUFBSXJFLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUNzRSxhQUFhQyxjQUFjLElBQUl2RSxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDd0UsYUFBYUMsY0FBYyxJQUFJekUsU0FBUztBQUFBLElBQzdDMEUsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUk5RSxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUMrRSxhQUFhQyxjQUFjLElBQUloRixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDaUYsYUFBYUMsY0FBYyxJQUFJbEYsU0FBUyxLQUFLO0FBR3BELFFBQU0sQ0FBQ21GLGFBQWFDLGNBQWMsSUFBSXBGLFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUNxRixlQUFlQyxnQkFBZ0IsSUFBSXRGLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUN1RixhQUFhQyxjQUFjLElBQUl4RixTQUFTLENBQUMsQ0FBQztBQUNqRCxRQUFNeUYsZ0JBQWdCMUYsT0FBTyxJQUFJO0FBRWpDLFFBQU0sQ0FBQzJGLFVBQVVDLFdBQVcsSUFBSTNGLFNBQVM7QUFBQSxJQUN2QzRGLFdBQVc7QUFBQSxJQUNYQyxPQUFPO0FBQUEsSUFDUEMsY0FBYztBQUFBLElBQ2RDLFVBQVU7QUFBQSxJQUNWQyxTQUFTO0FBQUEsSUFDVEMsbUJBQW1CO0FBQUEsSUFDbkJDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsUUFBUTtBQUFBLElBQ1JDLGNBQWM7QUFBQSxJQUNkQyxpQkFBaUI7QUFBQSxJQUNqQkMsZUFBZTtBQUFBLElBQ2ZDLG1CQUFtQjtBQUFBLElBQ25CQyxnQkFBZ0I7QUFBQSxJQUNoQkMsbUJBQW1CO0FBQUEsSUFDbkJDLGFBQWE7QUFBQSxJQUNiQyxrQkFBa0I7QUFBQSxJQUNsQkMsb0JBQW9CO0FBQUEsSUFDcEJDLCtCQUErQjtBQUFBLEVBQ2pDLENBQUM7QUFFRCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUloSCxTQUFTO0FBQUEsSUFDbkQ0RixXQUFXO0FBQUEsSUFDWEMsT0FBTztBQUFBLElBQ1BDLGNBQWM7QUFBQSxJQUNkQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RFLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsUUFBUTtBQUFBLElBQ1JhLE9BQU87QUFBQSxJQUNQQyxRQUFRO0FBQUEsSUFDUkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGFBQWE7QUFBQSxJQUNiQyxhQUFhO0FBQUEsSUFDYkMsU0FBUztBQUFBLElBQ1RDLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxJQUNQcEIsaUJBQWlCO0FBQUEsSUFDakJRLCtCQUErQjtBQUFBLElBQy9CYSxrQkFBa0I7QUFBQSxJQUNsQkMsZUFBZTtBQUFBLElBQ2ZDLGNBQWM7QUFBQSxJQUNkQyxxQkFBcUI7QUFBQSxJQUNyQkMsc0JBQXNCO0FBQUEsSUFDdEJDLHNCQUFzQjtBQUFBLElBQ3RCQyxtQkFBbUI7QUFBQSxJQUNuQkMsa0JBQWtCO0FBQUEsSUFDbEJDLGdCQUFnQjtBQUFBLElBQ2hCQyxlQUFlO0FBQUEsSUFDZkMsY0FBYztBQUFBLElBQ2RDLFdBQVc7QUFBQSxJQUNYQyxrQkFBa0I7QUFBQSxJQUNsQkMscUJBQXFCO0FBQUEsSUFDckJDLGdCQUFnQjtBQUFBLElBQ2hCQyxlQUFlO0FBQUEsSUFDZm5DLGVBQWU7QUFBQSxJQUNmQyxtQkFBbUI7QUFBQSxJQUNuQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLG1CQUFtQjtBQUFBLElBQ25CRSxrQkFBa0I7QUFBQSxJQUNsQkMsb0JBQW9CO0FBQUEsRUFDdEIsQ0FBQztBQUVELFFBQU0sQ0FBQzhCLFlBQVlDLGFBQWEsSUFBSTVJLFNBQVMsRUFBRTtBQUMvQyxRQUFNNkksNEJBQTRCQSxDQUFDQyxNQUFNO0FBQ3ZDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQkosa0JBQWNHLEtBQUs7QUFBQSxFQUNyQjtBQUNBLFFBQU1FLFdBQVd4SCxZQUFZO0FBRTdCM0IsWUFBVSxNQUFNO0FBQ2QsVUFBTW9KLFNBQVMsSUFBSUMsZ0JBQWdCRixTQUFTRyxNQUFNO0FBQ2xELFFBQUlGLE9BQU9HLElBQUksV0FBVyxNQUFNLFFBQVE7QUFDdENySCx1QkFBaUIsSUFBSTtBQUVyQnNILGFBQU9DLFFBQVFDLGFBQWEsQ0FBQyxHQUFHQyxTQUFTeEMsT0FBTyxxQkFBcUI7QUFBQSxJQUN2RTtBQUFBLEVBQ0YsR0FBRyxDQUFDZ0MsUUFBUSxDQUFDO0FBRWJuSixZQUFVLE1BQU07QUFDZCxVQUFNNEosYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU14SixJQUFJa0osSUFBSSxnQkFBZ0I7QUFDL0NoSCxxQkFBYXNILFNBQVNDLElBQUk7QUFBQSxNQUM1QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUNBSCxlQUFXO0FBQUEsRUFDYixHQUFHLEVBQUU7QUFDTDVKLFlBQVUsTUFBTTtBQUNkLFVBQU1pSyxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU1KLFdBQVcsTUFBTXhKLElBQUlrSixJQUFJLFlBQVk7QUFDM0M5RyxrQkFBVW9ILFNBQVNDLE1BQU1JLEtBQUs7QUFBQSxNQUNoQyxTQUFTQyxLQUFLO0FBQ1pILGdCQUFRRCxNQUFNLHlCQUF5QkksR0FBRztBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUNBRixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBQ0xqSyxZQUFVLE1BQU07QUFDZCxVQUFNb0ssaUJBQWlCLFlBQVk7QUFDakMsVUFBSTtBQUNGLGNBQU1QLFdBQVcsTUFBTXhKLElBQUlrSixJQUFJLFdBQVc7QUFDMUM1RyxxQkFBYWtILFVBQVVDLE1BQU1PLFFBQVE7QUFBQSxNQUN2QyxTQUFTTixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUNBSyxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMcEssWUFBVSxNQUFNO0FBQ2QsVUFBTXNLLHNCQUFzQixZQUFZO0FBQ3RDLFVBQUk7QUFDRixjQUFNVCxXQUFXLE1BQU14SixJQUFJa0o7QUFBQUEsVUFDekI7QUFBQSxRQUNGO0FBRUF0RixpQkFBUzRGLFNBQVNDLElBQUk7QUFBQSxNQUN4QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUNBTyx3QkFBb0I7QUFDcEI3RixtQkFBZSxFQUFFO0FBQUEsRUFDbkIsR0FBRyxDQUFDSCxhQUFhLENBQUM7QUFnQmxCdEUsWUFBVSxNQUFNO0FBQ2QsUUFBSXVGLGVBQWU7QUFDakJNLGtCQUFZLENBQUMwRSxVQUFVLEVBQUUsR0FBR0EsTUFBTXBFLG1CQUFtQm9FLEtBQUtyRSxRQUFRLEVBQUU7QUFBQSxJQUN0RTtBQUFBLEVBRUYsR0FBRyxDQUFDWCxlQUFlSyxTQUFTTSxPQUFPLENBQUM7QUFFcEMsUUFBTXNFLDBCQUEwQkEsQ0FBQ3hCLE1BQU07QUFDckMsVUFBTXlCLFVBQVV6QixFQUFFRSxPQUFPdUI7QUFDekJqRixxQkFBaUJpRixPQUFPO0FBQ3hCNUUsZ0JBQVksQ0FBQzBFLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIcEUsbUJBQW1Cc0UsVUFBVUYsS0FBS3JFLFVBQVU7QUFBQSxJQUM5QyxFQUFFO0FBQ0ZsQixjQUFVLENBQUN1RixVQUFVLEVBQUUsR0FBR0EsTUFBTXBFLG1CQUFtQixHQUFHLEVBQUU7QUFBQSxFQUMxRDtBQUVBLFFBQU11RSx3QkFBd0JBLENBQUNDLE9BQU8xQixVQUFVO0FBQzlDL0Isc0JBQWtCLENBQUMwRCxjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUcxQjtBQUFBQSxJQUNYLEVBQUU7QUFFRmpFLGNBQVUsRUFBRSxHQUFHRCxRQUFRLENBQUM0RixLQUFLLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFFQTNLLFlBQVUsTUFBTTtBQUNkLFVBQU00SixhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGbkcscUJBQWEsSUFBSTtBQUNqQixjQUFNb0csV0FBVyxNQUFNeEosSUFBSWtKLElBQUksb0JBQW9CO0FBR25EbEgsaUJBQVN3SCxTQUFTQyxJQUFJO0FBQ3RCLGNBQU1lLGdCQUFnQmhCLFNBQVNDLEtBQUtnQixJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxVQUN6REMsS0FBS0YsTUFBTUU7QUFBQUEsVUFDWG5KLElBQUlrSixRQUFRO0FBQUEsVUFDWkUsZUFBZUgsT0FBT0c7QUFBQUEsVUFDdEJDLE1BQU1KLE1BQU1qRjtBQUFBQSxVQUNaRSxjQUFjK0UsTUFBTS9FO0FBQUFBLFVBQ3BCb0YsV0FBV0wsT0FBT0ssV0FBV0MsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUN0Q0EsTUFBTSxHQUFHLEVBQ1RDLFFBQVEsRUFDUkMsS0FBSyxHQUFHO0FBQUEsVUFDWHJGLFNBQVM2RSxNQUFNN0U7QUFBQUEsVUFDZkUsU0FBUzJFLE1BQU0zRTtBQUFBQSxVQUNmb0YsYUFBYVQsTUFBTVM7QUFBQUEsVUFDbkIvRSxlQUFlc0UsT0FBT3RFO0FBQUFBLFVBQ3RCZ0YsWUFDRVYsT0FBT3BFLGdCQUFnQndFLFFBQVFKLE9BQU9wRSxnQkFBZ0JYLGVBQ2xELEdBQUcrRSxNQUFNcEUsZUFBZXdFLElBQUksTUFBTUosTUFBTXBFLGVBQWVYLFlBQVksS0FDbkUrRSxPQUFPbkUsbUJBQW1CZCxhQUMxQmlGLE9BQU9uRSxtQkFBbUJaLGVBQ3hCLEdBQUcrRSxNQUFNbkUsa0JBQWtCZCxTQUFTLE1BQU1pRixPQUFPbkUsbUJBQW1CWixZQUFZLEtBQ2hGK0UsT0FBT3JFLG1CQUFtQnlFLFFBQVFKLE9BQU9yRSxtQkFBbUJWLGVBQzFELEdBQUcrRSxNQUFNckUsa0JBQWtCeUUsSUFBSSxNQUFNSixNQUFNckUsa0JBQWtCVixZQUFZLEtBQ3pFO0FBQUEsVUFDVjBGLGFBQ0VYLE9BQU94RSxpQkFBaUIsc0JBQ3BCLGtCQUNBd0UsT0FBT3hFLGlCQUFpQixnQkFDdEIsZUFDQTtBQUFBO0FBQUEsVUFFUkMsaUJBQWlCdUUsTUFBTXZFLGlCQUFpQm1GO0FBQUFBLFVBQ3hDM0UsK0JBQStCK0QsTUFBTS9ELCtCQUErQm1FO0FBQUFBLFVBQ3BFUyxlQUFlYixPQUFPYztBQUFBQSxVQUN0QkMsS0FBS2YsT0FBT3pELGNBQ1I5RixNQUFNdUosT0FBT3pELFdBQVcsRUFBRXlFLE9BQU8sWUFBWSxJQUM3QztBQUFBLFVBQ0pDLFVBQ0UsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixPQUFPO0FBQUEsZ0JBQ0xDLFlBQVksa0JBQWtCbEIsTUFBTWMsZUFBZSxNQUFNLFlBQVksU0FBUyxJQUN4RWQsTUFBTWMsYUFBYSxHQUFHLGdCQUFnQmQsTUFBTWMsYUFBYSxHQUFHO0FBQUEsY0FFcEU7QUFBQSxjQUVBLGlDQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHlCQUF5QmQsTUFBTWMsZUFBZSxNQUNyRCxtQkFDQSxpQkFBaUI7QUFBQSxrQkFHcEJkO0FBQUFBLDJCQUFPYztBQUFBQSxvQkFBVztBQUFBO0FBQUE7QUFBQSxnQkFOckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUE7QUFBQSxZQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUVGSyxpQkFDRW5CLE1BQU1tQixvQkFBb0IsU0FDdEIsYUFDQW5CLE1BQU1tQixvQkFBb0IsVUFDeEIsWUFDQTtBQUFBLFVBQ1JDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLENBQUMsT0FBTztBQUFBLGNBQ2pCLE1BQU07QUFBQSxnQkFDSkMsT0FBTztBQUFBLGtCQUNMO0FBQUEsb0JBQ0VDLEtBQUs7QUFBQSxvQkFDTHRLLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTXVLLHNCQUFzQnZCLE9BQU9FLEdBQUc7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRW9CLEtBQUs7QUFBQSxvQkFDTHRLLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTXdLLHNCQUFzQnhCLE9BQU9FLEdBQUc7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRW9CLEtBQUs7QUFBQSxvQkFDTHRLLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsU0FBUyxNQUNQZiw2QkFBNkIrSixPQUFPRSxHQUFHO0FBQUEsd0JBRXpDLFdBQVU7QUFBQSx3QkFBaUI7QUFBQTtBQUFBLHNCQUo3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSxrQkFFSjtBQUFBLGtCQUNBO0FBQUEsb0JBQ0VvQixLQUFLO0FBQUEsb0JBQ0x0SyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVcsa0JBQWtCZ0osT0FBT21CLG9CQUFvQixTQUNwRCxtQkFDQSxjQUFjO0FBQUEsd0JBRWxCLFNBQVMsTUFDUE07QUFBQUEsMEJBQ0V6QixPQUFPRTtBQUFBQSwwQkFDUEYsT0FBT21CLG9CQUFvQixTQUN2QixTQUNBO0FBQUEsd0JBQ047QUFBQSx3QkFHRG5CLGlCQUFPbUIsb0JBQW9CLFNBQ3hCLHFCQUNBO0FBQUE7QUFBQSxzQkFoQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWlCQTtBQUFBLGtCQUVKO0FBQUEsZ0JBQUM7QUFBQSxjQUVMO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQTtBQUFBLFlBbEVqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtRUEsS0FwRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxRUE7QUFBQSxRQUVKLEVBQUU7QUFDRixZQUFJTyxRQUFRNUIsY0FBY0MsSUFBSSxDQUFDNEIsUUFBUTtBQUNyQyxjQUNFQSxLQUFLeEcsV0FDTCxPQUFPd0csSUFBSXhHLFlBQVksWUFDdkJ3RyxLQUFLeEcsU0FBU3lHLFNBQVMsR0FBRztBQUUxQkQsZ0JBQUl4RyxVQUFVd0csSUFBSXhHLFFBQVEwRyxXQUFXLEtBQUssR0FBRztBQUMvQyxpQkFBT0Y7QUFBQUEsUUFDVCxDQUFDO0FBQ0QsWUFBSSxDQUFDRCxNQUFPNUosZUFBY2dJLGFBQWE7QUFDdkMsWUFBSSxDQUFDNEIsTUFBTzVKLGVBQWNnSSxhQUFhO0FBQ3ZDaEksc0JBQWM0SixLQUFLO0FBQUEsTUFDckIsU0FBUzFDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sNkJBQTZCQSxNQUFNbEYsT0FBTztBQUFBLE1BQzFELFVBQUM7QUFDQ3BCLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQW1HLGVBQVc7QUFBQSxFQUNiLEdBQUcsQ0FBQ3RGLGFBQWEsQ0FBQztBQUVsQnRFLFlBQVUsTUFBTTtBQUNkLFVBQU02TSxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTUMsTUFBTSxNQUFNek0sSUFBSWtKLElBQUksdUJBQXVCO0FBQ2pEeEYsa0JBQVUrSSxJQUFJaEQsSUFBSTtBQUFBLE1BQ3BCLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsTUFDN0M7QUFBQSxJQUNGO0FBQ0E4QyxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQ3ZJLGFBQWEsQ0FBQztBQUNsQixRQUFNeUksbUJBQW1CQSxDQUFDcEMsT0FBTzFCLE9BQU8rRCxXQUFXO0FBQ2pEbkgsZ0JBQVksQ0FBQytFLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNELEtBQUssR0FBRzFCO0FBQUFBLE1BQ1QsR0FBSTBCLFVBQVUsb0JBQ1YsRUFBRXNDLHdCQUF3QkQsT0FBTyxJQUNqQyxDQUFDO0FBQUEsSUFDUCxFQUFFO0FBRUZoSSxjQUFVLENBQUNrSSxnQkFBZ0I7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUN2QyxLQUFLLEdBQUc7QUFBQSxJQUNYLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTXdDLGVBQWVBLENBQUNuRSxNQUFNO0FBQzFCLFVBQU0sRUFBRW1DLE1BQU1sQyxNQUFNLElBQUlELEVBQUVFO0FBQzFCckQsZ0JBQVksQ0FBQytFLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNPLElBQUksR0FBR2xDO0FBQUFBLElBQ1YsRUFBRTtBQUNGakUsY0FBVSxDQUFDNEYsY0FBYztBQUFBLE1BQ3ZCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ08sSUFBSSxHQUFHO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUNBLFFBQU1pQyx3QkFBd0IsT0FBT0MsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTXhELFdBQVcsTUFBTXhKLElBQUlrSixJQUFJLDBCQUEwQjhELE9BQU8sRUFBRTtBQUNsRXhKLHVCQUFpQmdHLFNBQVNDLElBQUk7QUFBQSxJQUNoQyxTQUFTSyxLQUFLO0FBQ1pILGNBQVFELE1BQU0sMEJBQTBCSSxHQUFHO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBTUEsUUFBTW1ELGVBQWVBLENBQUN4SSxNQUFNeUksT0FBTyxVQUFVO0FBQzNDLFVBQU1DLFlBQVksQ0FBQztBQUNuQixVQUFNMUQsT0FBT2hGLFNBQVMsZ0JBQWdCYyxXQUFXcUI7QUFDakQsVUFBTXdHLFFBQVE7QUFBQSxNQUNaMUgsT0FBTztBQUFBLE1BQ1AySCxPQUFPO0FBQUEsTUFDUHRILFNBQVM7QUFBQSxNQUNUdUgsUUFBUTtBQUFBLE1BQ1JDLEtBQUs7QUFBQSxJQUNQO0FBRUEsVUFBTUMsdUJBQXVCQSxNQUFNO0FBQ2pDLFVBQUksQ0FBQy9ELEtBQUtoRSxXQUFXZ0ksS0FBSyxHQUFHO0FBQzNCTixrQkFBVTFILFlBQVk7QUFBQSxNQUN4QjtBQUVBLFVBQUlnRSxLQUFLL0QsU0FBUyxDQUFDMEgsTUFBTTFILE1BQU1nSSxLQUFLakUsS0FBSy9ELEtBQUssR0FBRztBQUMvQ3lILGtCQUFVekgsUUFBUTtBQUFBLE1BQ3BCO0FBRUEsVUFBSSxDQUFDK0QsS0FBSzlELGNBQWM7QUFDdEJ3SCxrQkFBVXhILGVBQWU7QUFBQSxNQUMzQixXQUFXLENBQUN5SCxNQUFNQyxNQUFNSyxLQUFLakUsS0FBSzlELFlBQVksR0FBRztBQUMvQ3dILGtCQUFVeEgsZUFBZTtBQUFBLE1BQzNCO0FBRUEsVUFBSWxCLFNBQVMsaUJBQWlCLENBQUNnRixLQUFLN0QsVUFBVTtBQUM1Q3VILGtCQUFVdkgsV0FBVztBQUFBLE1BQ3ZCO0FBRUEsVUFBSSxDQUFDNkQsS0FBSzFELFNBQVM7QUFDakJvSCxrQkFBVXBILFVBQVU7QUFBQSxNQUN0QixXQUFXLENBQUNxSCxNQUFNckgsUUFBUTJILEtBQUtqRSxLQUFLMUQsT0FBTyxHQUFHO0FBQzVDb0gsa0JBQVVwSCxVQUFVO0FBQUEsTUFDdEI7QUFFQSxVQUFJLENBQUMwRCxLQUFLekQsV0FBVztBQUNuQm1ILGtCQUFVbkgsWUFBWTtBQUFBLE1BQ3hCLFdBQVcsQ0FBQ29ILE1BQU1FLE9BQU9JLEtBQUtqRSxLQUFLekQsU0FBUyxHQUFHO0FBQzdDbUgsa0JBQVVuSCxZQUFZO0FBQUEsTUFDeEI7QUFDQSxVQUFJeUQsS0FBS3hELFVBQVUsQ0FBQ21ILE1BQU1HLElBQUlHLEtBQUtqRSxLQUFLeEQsT0FBTzBILFlBQVksQ0FBQyxHQUFHO0FBQzdEUixrQkFBVWxILFNBQVM7QUFBQSxNQUNyQjtBQUVBLFVBQUksQ0FBQ3dELEtBQUs1RCxTQUFTNEgsS0FBSyxHQUFHO0FBQ3pCTixrQkFBVXRILFVBQVU7QUFBQSxNQUN0QixXQUFXNEQsS0FBSzVELFFBQVE0SCxLQUFLLEVBQUVHLFNBQVMsR0FBRztBQUN6Q1Qsa0JBQVV0SCxVQUFVO0FBQUEsTUFDdEI7QUFFQSxVQUFJcEIsU0FBUyxpQkFBaUIsQ0FBQ1MsaUJBQWlCLENBQUN1RSxLQUFLM0QsbUJBQW1CMkgsS0FBSyxHQUFHO0FBQy9FTixrQkFBVXJILG9CQUFvQjtBQUFBLE1BQ2hDO0FBQUEsSUFDRjtBQUVBLFVBQU0rSCx5QkFBeUJBLE1BQU07QUFDbkMsVUFBSXBKLFNBQVMsZUFBZTtBQUMxQixZQUFJLENBQUNnRixLQUFLaEQsa0JBQWtCO0FBQzFCMEcsb0JBQVUxRyxtQkFBbUI7QUFBQSxRQUMvQjtBQUNBLFlBQUksQ0FBQ2dELEtBQUsvQyxvQkFBb0I7QUFDNUJ5RyxvQkFBVXpHLHFCQUFxQjtBQUFBLFFBQ2pDLFdBQ0VvSCxNQUFNckUsS0FBSy9DLGtCQUFrQixLQUM3QnFILE9BQU90RSxLQUFLL0Msa0JBQWtCLEtBQUssR0FDbkM7QUFDQXlHLG9CQUFVekcscUJBQXFCO0FBQUEsUUFDakM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFFBQUlqQyxTQUFTLGVBQWU7QUFDMUIsVUFBSXlJLFNBQVMsR0FBRztBQUNkTSw2QkFBcUI7QUFBQSxNQUN2QixXQUFXTixTQUFTLEdBQUc7QUFDckJXLCtCQUF1QjtBQUFBLE1BQ3pCLE9BQU87QUFDTEwsNkJBQXFCO0FBQ3JCSywrQkFBdUI7QUFBQSxNQUN6QjtBQUFBLElBQ0YsT0FBTztBQUVMTCwyQkFBcUI7QUFBQSxJQUN2QjtBQUVBN0ksY0FBVSxDQUFDdUYsVUFBVSxFQUFFLEdBQUdBLE1BQU0sR0FBR2lELFVBQVUsRUFBRTtBQUMvQyxXQUFPYSxPQUFPQyxLQUFLZCxTQUFTLEVBQUVTLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU1NLG9CQUFvQkEsTUFBTTtBQUM5QixVQUFNQyxtQkFBbUI5TCxVQUFVK0w7QUFBQUEsTUFDakMsQ0FBQ3BFLGFBQWFBLFNBQVNZLFFBQVFyRixTQUFTYztBQUFBQSxJQUMxQztBQUVBLFVBQU1nSSxnQkFBZ0JsTSxPQUFPaU07QUFBQUEsTUFDM0IsQ0FBQ3ZFLFVBQVVBLE1BQU1lLFFBQVFyRixTQUFTZTtBQUFBQSxJQUNwQztBQUVBLFVBQU1nSSxtQkFBbUJyTSxVQUFVbU07QUFBQUEsTUFDakMsQ0FBQ0csYUFBYUEsU0FBUzNELFFBQVFyRixTQUFTZ0I7QUFBQUEsSUFDMUM7QUFFQSxVQUFNaUksY0FBY25NLFVBQVUrTDtBQUFBQSxNQUM1QixDQUFDcEUsYUFDQ0EsU0FBU1ksUUFBUXJGLFNBQVNvQjtBQUFBQSxJQUM5QjtBQUVBdEIsbUJBQWU7QUFBQSxNQUNiLEdBQUdFO0FBQUFBLE1BRUhrSiwwQkFDRWxKLFNBQVNhLGtCQUFrQixhQUN2QitILG1CQUNFLEdBQUdBLGlCQUFpQnJELElBQUksTUFBTXFELGlCQUFpQnhJLFlBQVksS0FDM0QsTUFDRitJO0FBQUFBLE1BRU5DLHVCQUNFcEosU0FBU2Esa0JBQWtCLFVBQ3ZCaUksZ0JBQ0UsR0FBR0EsY0FBY3ZELElBQUksTUFBTXVELGNBQWMxSSxZQUFZLEtBQ3JELE1BQ0YrSTtBQUFBQSxNQUVORSwwQkFDRXJKLFNBQVNhLGtCQUFrQixhQUN2QmtJLG1CQUNFLEdBQUdBLGlCQUFpQjdJLFNBQVMsTUFBTTZJLGlCQUFpQjNJLFlBQVksS0FDaEUsTUFDRitJO0FBQUFBLE1BRU5HLHNDQUFzQ0wsY0FDbEMsR0FBR0EsWUFBWTFELElBQUksTUFBTTBELFlBQVk3SSxZQUFZLEtBQ2pEO0FBQUEsTUFFSmlILHdCQUF3QnJILFNBQVNxSCwwQkFBMEI7QUFBQSxJQUM3RCxDQUFDO0FBRUQvSCxtQkFBZSxJQUFJO0FBQUEsRUFDckI7QUFFQSxRQUFNaUssdUJBQXVCQSxDQUFDbkcsTUFBTTtBQUNsQ0EsTUFBRW9HLGVBQWU7QUFFakIsVUFBTUMsVUFBVS9CLGFBQWEsZUFBZSxLQUFLO0FBQ2pELFFBQUksQ0FBQytCLFFBQVM7QUFHZG5LLG1CQUFlLElBQUk7QUFFbkJxSixzQkFBa0I7QUFBQSxFQUNwQjtBQUdBLFFBQU1lLHdCQUF3QkEsQ0FBQ3RHLE1BQU07QUFDbkNBLE1BQUVvRyxlQUFlO0FBQ2pCLFVBQU1DLFVBQVUvQixhQUFhLGVBQWUsQ0FBQztBQUM3QyxRQUFJLENBQUMrQixRQUFTO0FBQ2QvSixtQkFBZSxDQUFDO0FBQUEsRUFDbEI7QUFHQSxRQUFNaUssb0JBQW9CLE9BQU92RyxNQUFNO0FBQ3JDQSxNQUFFb0csZUFBZTtBQUNqQixVQUFNQyxVQUFVL0IsYUFBYSxlQUFlakksV0FBVztBQUN2RCxRQUFJLENBQUNnSyxRQUFTO0FBQ2QsVUFBTUcsYUFBYXhHLENBQUM7QUFBQSxFQUN0QjtBQUVBLFFBQU13RyxlQUFlLE9BQU94RyxNQUFNO0FBQ2hDLFFBQUlBLEtBQUtBLEVBQUVvRyxlQUFnQnBHLEdBQUVvRyxlQUFlO0FBQzVDLFFBQUk7QUFDRixZQUFNSyxVQUFVLElBQUlDLFNBQVM7QUFHN0JyQixhQUFPc0IsUUFBUS9KLFFBQVEsRUFBRWdLLFFBQVEsQ0FBQyxDQUFDdkQsS0FBS3BELEtBQUssTUFBTTtBQUNqRHdHLGdCQUFRSSxPQUFPeEQsS0FBS3BELEtBQUs7QUFBQSxNQUMzQixDQUFDO0FBR0QsVUFBSXpFLFlBQVksQ0FBQyxHQUFHO0FBQ2xCaUwsZ0JBQVFJLE9BQU8sZ0JBQWdCckwsWUFBWSxDQUFDLENBQUM7QUFBQSxNQUMvQztBQUNBLFlBQU1xRixXQUFXLE1BQU14SixJQUFJeVAsS0FBSyw0QkFBNEJMLE9BQU87QUFFbkUsVUFBSTVGLFNBQVNrRyxXQUFXLEtBQUs7QUFDM0JwTCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUdEZSxvQkFBWTtBQUFBLFVBQ1ZDLFdBQVc7QUFBQSxVQUNYQyxPQUFPO0FBQUEsVUFDUEMsY0FBYztBQUFBLFVBQ2RDLFVBQVU7QUFBQSxVQUNWQyxTQUFTO0FBQUEsVUFDVEMsbUJBQW1CO0FBQUEsVUFDbkJDLFNBQVM7QUFBQSxVQUNUQyxXQUFXO0FBQUEsVUFDWEMsUUFBUTtBQUFBLFVBQ1JDLGNBQWM7QUFBQSxVQUNkQyxpQkFBaUI7QUFBQSxVQUNqQlEsK0JBQStCO0FBQUEsVUFDL0J1QixjQUFjO0FBQUEsVUFDZDlCLGVBQWU7QUFBQSxVQUNmQyxtQkFBbUI7QUFBQSxVQUNuQkMsZ0JBQWdCO0FBQUEsVUFDaEJDLG1CQUFtQjtBQUFBLFVBQ25CQyxhQUFhO0FBQUEsVUFDYkMsa0JBQWtCO0FBQUEsVUFDbEJDLG9CQUFvQjtBQUFBLFFBQ3RCLENBQUM7QUFDRHRDLHVCQUFlLEVBQUU7QUFDakJTLHVCQUFlLEtBQUs7QUFDcEJNLHlCQUFpQixLQUFLO0FBQ3RCRix1QkFBZSxDQUFDO0FBRWhCcEQseUJBQWlCLEtBQUs7QUFDdEJxQyx5QkFBaUIsQ0FBQ2dHLFNBQVNBLE9BQU8sQ0FBQztBQUFBLE1BQ3JDLE9BQU87QUFFTDVGLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVNnRixTQUFTQyxNQUFNakYsV0FBVztBQUFBLFVBQ25DQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU2lGLE9BQU87QUFFZHBGLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQ0VrRixNQUFNRixVQUFVQyxNQUFNakYsV0FDdEJrRixNQUFNbEYsV0FDTjtBQUFBLFFBQ0ZDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1rTCxVQUFVO0FBQUEsSUFDZCxFQUFFM0QsS0FBSyxNQUFNNEQsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRTVELEtBQUssYUFBYTRELFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUU1RCxLQUFLLGlCQUFpQjRELFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRTVELEtBQUssbUJBQW1CNEQsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFNUQsS0FBSyxlQUFlNEQsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRTVELEtBQUssUUFBUTRELFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRTVELEtBQUssZ0JBQWdCNEQsUUFBUSx3QkFBd0I7QUFBQSxJQUN2RCxFQUFFNUQsS0FBSyxXQUFXNEQsUUFBUSxtQkFBbUI7QUFBQSxJQUM3QyxFQUFFNUQsS0FBSyxXQUFXNEQsUUFBUSxtQkFBbUI7QUFBQSxJQUM3QyxFQUFFNUQsS0FBSyxpQkFBaUI0RCxRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUU1RCxLQUFLLGNBQWM0RCxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFNUQsS0FBSyxlQUFlNEQsUUFBUSxlQUFlO0FBQUE7QUFBQSxJQUU3QyxFQUFFNUQsS0FBSyxtQkFBbUI0RCxRQUFRLE9BQU87QUFBQSxJQUN6QyxFQUFFNUQsS0FBSyxpQ0FBaUM0RCxRQUFRLHVCQUF1QjtBQUFBLElBQ3ZFLEVBQUU1RCxLQUFLLFlBQVk0RCxRQUFRLFdBQVc7QUFBQSxJQUV0QyxFQUFFNUQsS0FBSyxVQUFVNEQsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyxvQkFBb0I7QUFBQSxJQUN4QixFQUFFN0QsS0FBSyxNQUFNNEQsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRTVELEtBQUssbUJBQW1CNEQsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFNUQsS0FBSyxlQUFlNEQsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRTVELEtBQUssUUFBUTRELFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRTVELEtBQUssZ0JBQWdCNEQsUUFBUSx3QkFBd0I7QUFBQSxJQUN2RCxFQUFFNUQsS0FBSyxhQUFhNEQsUUFBUSxZQUFZO0FBQUEsSUFDeEMsRUFBRTVELEtBQUssV0FBVzRELFFBQVEsbUJBQW1CO0FBQUEsSUFDN0MsRUFBRTVELEtBQUssV0FBVzRELFFBQVEsbUJBQW1CO0FBQUEsSUFDN0MsRUFBRTVELEtBQUssaUJBQWlCNEQsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFNUQsS0FBSyxjQUFjNEQsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRTVELEtBQUssZUFBZTRELFFBQVEsZUFBZTtBQUFBLElBQzdDLEVBQUU1RCxLQUFLLE9BQU80RCxRQUFRLE1BQU07QUFBQTtBQUFBLElBRTVCLEVBQUU1RCxLQUFLLG1CQUFtQjRELFFBQVEsT0FBTztBQUFBLElBQ3pDLEVBQUU1RCxLQUFLLGlCQUFpQjRELFFBQVEsV0FBVztBQUFBLElBQzNDLEVBQUU1RCxLQUFLLFVBQVU0RCxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1FLGdCQUFnQi9OLE1BQU1nTztBQUFBQSxJQUFPLENBQUNDLFNBQ2xDQSxLQUFLdkssVUFBVXdLLFlBQVksRUFBRTNELFNBQVM3SixXQUFXd04sWUFBWSxDQUFDO0FBQUEsRUFDaEU7QUFFQSxRQUFNL0Qsd0JBQXdCLE9BQU9nRSxXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNMUcsV0FBVyxNQUFNeEosSUFBSWtKLElBQUksd0JBQXdCZ0gsTUFBTSxFQUFFO0FBQy9EaE4scUJBQWVzRyxTQUFTQyxJQUFJO0FBQzVCM0cseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTNEcsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUVBLFFBQU11Qyx3QkFBd0IsT0FBT2lFLFdBQVc7QUFDOUMsUUFBSTtBQUNGLFlBQU0xRyxXQUFXLE1BQU14SixJQUFJa0osSUFBSSx3QkFBd0JnSCxNQUFNLEVBQUU7QUFFL0Q1TSwyQkFBcUJrRyxTQUFTQyxJQUFJO0FBQ2xDakcsdUJBQWlCZ0csVUFBVUMsTUFBTWxCLGFBQWE7QUFDOUMxQix3QkFBa0I7QUFBQSxRQUNoQnBCLFdBQVcrRCxVQUFVQyxNQUFNaEU7QUFBQUEsUUFDM0JDLE9BQU84RCxVQUFVQyxNQUFNL0Q7QUFBQUEsUUFDdkJDLGNBQWM2RCxVQUFVQyxNQUFNOUQ7QUFBQUEsUUFDOUJDLFVBQVU0RCxVQUFVQyxNQUFNN0Q7QUFBQUEsUUFDMUJHLFNBQVN5RCxVQUFVQyxNQUFNMUQ7QUFBQUEsUUFDekJDLFdBQVd3RCxVQUFVQyxNQUFNekQ7QUFBQUEsUUFDM0JDLFFBQVF1RCxVQUFVQyxNQUFNeEQ7QUFBQUEsUUFDeEJKLFNBQVMyRCxVQUFVQyxNQUFNNUQ7QUFBQUEsUUFDekIwQyxlQUFlaUIsVUFBVUMsTUFBTWxCLGVBQWVxQyxPQUFPO0FBQUEsUUFDckQ5RCxPQUFPMEMsVUFBVUMsTUFBTTNDO0FBQUFBLFFBQ3ZCTyxhQUFhbUMsVUFBVUMsTUFBTXBDO0FBQUFBLFFBQzdCTixRQUFReUMsVUFBVUMsTUFBTTFDO0FBQUFBLFFBQ3hCQyxnQkFBZ0J3QyxVQUFVQyxNQUFNekM7QUFBQUEsUUFDaENDLGFBQWF1QyxVQUFVQyxNQUFNeEMsYUFBYStELE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxRQUN0RDlELGFBQWFzQyxVQUFVQyxNQUFNdkM7QUFBQUEsUUFDN0JDLFNBQVNxQyxVQUFVQyxNQUFNdEM7QUFBQUEsUUFDekJDLE9BQU9vQyxVQUFVQyxNQUFNckM7QUFBQUEsUUFDdkJFLFVBQVVrQyxVQUFVQyxNQUFNbkM7QUFBQUEsUUFDMUJDLE9BQU9pQyxVQUFVQyxNQUFNbEM7QUFBQUEsUUFDdkJwQixpQkFBaUJxRCxVQUFVQyxNQUFNdEQsaUJBQWlCeUUsT0FBTztBQUFBLFFBQ3pEakUsK0JBQStCNkMsVUFBVUMsTUFBTTlDLCtCQUErQmlFLE9BQU87QUFBQSxRQUNyRnBELGtCQUFrQmdDLFVBQVVDLE1BQU1qQztBQUFBQSxRQUNsQ0MsZUFBZStCLFVBQVVDLE1BQU1oQztBQUFBQSxRQUMvQkMsY0FBYzhCLFVBQVVDLE1BQU0vQjtBQUFBQSxRQUM5QkMscUJBQXFCNkIsVUFBVUMsTUFBTTlCLHFCQUFxQnFELE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxRQUN0RW5ELHNCQUFzQjJCLFVBQVVDLE1BQU01QjtBQUFBQSxRQUN0Q0Qsc0JBQXNCNEIsVUFBVUMsTUFBTTdCO0FBQUFBLFFBQ3RDTyxXQUFXcUIsVUFBVUMsTUFBTXRCO0FBQUFBLFFBQzNCQyxrQkFBa0JvQixVQUFVQyxNQUFNckI7QUFBQUEsUUFDbENDLHFCQUFxQm1CLFVBQVVDLE1BQU1wQjtBQUFBQSxRQUNyQ0MsZ0JBQWdCa0IsVUFBVUMsTUFBTW5CO0FBQUFBLFFBQ2hDUixtQkFBbUIwQixVQUFVQyxNQUFNM0I7QUFBQUEsUUFDbkNDLGtCQUFrQnlCLFVBQVVDLE1BQU0xQjtBQUFBQSxRQUNsQ0MsZ0JBQWdCd0IsVUFBVUMsTUFBTXpCO0FBQUFBLFFBQ2hDQyxlQUFldUIsVUFBVUMsTUFBTXhCO0FBQUFBLFFBQy9CQyxjQUFjc0IsVUFBVUMsTUFBTXZCO0FBQUFBLFFBQzlCOUIsZUFBZW9ELFVBQVVDLE1BQU1yRDtBQUFBQSxRQUMvQkMsbUJBQW1CbUQsVUFBVUMsTUFBTXBELHFCQUFxQjtBQUFBLFFBQ3hEQyxnQkFBZ0JrRCxVQUFVQyxNQUFNbkQsa0JBQWtCO0FBQUEsUUFDbERDLG1CQUFtQmlELFVBQVVDLE1BQU1sRCxxQkFBcUI7QUFBQSxRQUN4REUsa0JBQWtCK0MsVUFBVUMsTUFBTWhELG9CQUFvQjtBQUFBLFFBQ3REQyxvQkFBb0I4QyxVQUFVQyxNQUFNL0Msc0JBQXNCO0FBQUEsTUFDNUQsQ0FBQztBQUNEMUQseUJBQW1CLElBQUk7QUFDdkIyQixnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkLFNBQVMrRSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBQ0EsUUFBTXlHLG9CQUFvQkEsQ0FBQ3hILE1BQU07QUFDL0IsVUFBTSxFQUFFbUMsTUFBTWxDLE1BQU0sSUFBSUQsRUFBRUU7QUFDMUJoQyxzQkFBa0IsQ0FBQzBELGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUNPLElBQUksR0FBR2xDO0FBQUFBLElBQ1YsRUFBRTtBQUNGakUsY0FBVSxDQUFDNEYsY0FBYztBQUFBLE1BQ3ZCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ08sSUFBSSxHQUFHO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1zRixtQkFBbUIsWUFBWTtBQUNuQyxRQUFJbk4sYUFBYTtBQUNmLFVBQUk7QUFDRixjQUFNakQsSUFBSXFRLE9BQU8scUJBQXFCcE4sWUFBWTJILEdBQUcsRUFBRTtBQUV2RHRHLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQ0RQLHlCQUFpQixDQUFDZ0csU0FBU0EsT0FBTyxDQUFDO0FBQ25DcEgsMkJBQW1CLEtBQUs7QUFDeEJJLHVCQUFlLElBQUk7QUFBQSxNQUNyQixTQUFTd0csT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxNQUM3QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTTRHLG1CQUFtQkEsQ0FBQzNILE1BQU07QUFDOUIsVUFBTSxFQUFFbUMsTUFBTWpILGNBQU0sSUFBSThFLEVBQUVFO0FBQzFCLFVBQU0wSCxPQUFPMU0sT0FBTSxDQUFDO0FBRXBCLFFBQUkwTSxNQUFNO0FBQ1IxSix3QkFBa0IsQ0FBQzJKLGVBQWU7QUFBQSxRQUNoQyxHQUFHQTtBQUFBQSxRQUNILENBQUMxRixJQUFJLEdBQUd5RjtBQUFBQSxNQUNWLEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUdBLFFBQU1FLHVCQUF1QixPQUFPaFAsSUFBSWlQLGNBQWM7QUFDcEQsUUFBSTtBQUNGLFVBQUksQ0FBQ2pQLElBQUk7QUFDUGtJLGdCQUFRZ0gsS0FBSyxxQkFBcUI7QUFDbEM7QUFBQSxNQUNGO0FBRUEsWUFBTW5ILFdBQVcsTUFBTXhKLElBQUk0USxJQUFJLHFCQUFxQm5QLEVBQUUsSUFBSTtBQUFBLFFBQ3hEb0ssaUJBQWlCNkU7QUFBQUEsTUFDbkIsQ0FBQztBQUVELFVBQUlsSCxTQUFTa0csV0FBVyxLQUFLO0FBQzNCeEwseUJBQWlCLENBQUNnRyxTQUFTQSxPQUFPLENBQUM7QUFDbkM1Rix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTLGdEQUFnRGtNLGNBQWMsU0FBUyxhQUFhLFlBQVk7QUFBQSxVQUN6R2pNLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRGtGLGdCQUFRa0g7QUFBQUEsVUFDTiw4QkFBOEJILFNBQVM7QUFBQSxVQUN2Q2pQO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTGtJLGdCQUFRZ0gsS0FBSyxxQ0FBcUNuSCxVQUFVQyxJQUFJO0FBQUEsTUFDbEU7QUFBQSxJQUNGLFNBQVNLLEtBQUs7QUFDWkgsY0FBUUQsTUFBTSxtQ0FBbUNJLElBQUl0RixPQUFPO0FBQUEsSUFDOUQ7QUFBQSxFQUNGO0FBR0EsUUFBTTJILGtDQUFrQ0EsQ0FBQzFLLElBQUlxUCxrQkFBa0I7QUFDN0QsVUFBTUMsY0FBY0Qsa0JBQWtCO0FBQ3RDLFVBQU1FLGFBQWFELGNBQWMsWUFBWTtBQUU3Q3hQLFlBQVE7QUFBQSxNQUNOdUYsT0FBTztBQUFBLE1BQ1BtSyxTQUFTLGtCQUFrQkQsVUFBVTtBQUFBLE1BQ3JDRSxRQUFRO0FBQUEsTUFDUkMsWUFBWTtBQUFBLE1BQ1osTUFBTUMsT0FBTztBQUNYLGNBQU1YLHFCQUFxQmhQLElBQUlxUCxhQUFhO0FBQUEsTUFDOUM7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTU8sZUFBZSxPQUFPMUksTUFBTTtBQUNoQ0EsTUFBRW9HLGVBQWU7QUFFakIsUUFBSTtBQUNGLFlBQU11QyxTQUFTLElBQUlqQyxTQUFTO0FBRTVCckIsYUFBT3NCLFFBQVExSSxjQUFjLEVBQUUySSxRQUFRLENBQUMsQ0FBQ3ZELEtBQUtwRCxLQUFLLE1BQU07QUFDdkQsWUFBSW9ELFFBQVEsbUJBQW1CekksZUFBZXFILEtBQUs7QUFDakQwRyxpQkFBTzlCLE9BQU8saUJBQWlCak0sY0FBY3FILEdBQUc7QUFBQSxRQUNsRCxXQUFXaEMsT0FBTztBQUNoQjBJLGlCQUFPOUIsT0FBT3hELEtBQUtwRCxLQUFLO0FBQUEsUUFDMUI7QUFBQSxNQUNGLENBQUM7QUFFRCxVQUFJekUsWUFBWSxDQUFDLEdBQUc7QUFDbEJtTixlQUFPOUIsT0FBTyxnQkFBZ0JyTCxZQUFZLENBQUMsQ0FBQztBQUFBLE1BQzlDO0FBRUEsWUFBTW5FLElBQUk0USxJQUFJLHFCQUFxQnZOLG1CQUFtQnVILEdBQUcsSUFBSTBHLFFBQVE7QUFBQSxRQUNuRUMsU0FBUyxFQUFFLGdCQUFnQixzQkFBc0I7QUFBQSxNQUNuRCxDQUFDO0FBRUR2Tyx5QkFBbUIsS0FBSztBQUN4QmtCLHVCQUFpQixDQUFDZ0csU0FBU0EsT0FBTyxDQUFDO0FBQ25DNUYscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDREUsZ0JBQVUsQ0FBQyxDQUFDO0FBQUEsSUFDZCxTQUFTK0UsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUMzQyxVQUNFQSxNQUFNRixZQUNORSxNQUFNRixTQUFTQyxRQUNmQyxNQUFNRixTQUFTQyxLQUFLakYsV0FDcEJrRixNQUFNRixTQUFTQyxLQUFLakYsUUFDakJ5TCxZQUFZLEVBQ1ozRCxTQUFTLDZCQUE2QixHQUN6QztBQUNBM0gsa0JBQVUsQ0FBQ2tJLGdCQUFnQjtBQUFBLFVBQ3pCLEdBQUdBO0FBQUFBLFVBQ0hsSCxjQUFjO0FBQUEsUUFDaEIsRUFBRTtBQUFBLE1BQ0osV0FDRStELE1BQU1GLFlBQ05FLE1BQU1GLFNBQVNDLFFBQ2ZDLE1BQU1GLFNBQVNDLEtBQUtqRixTQUNwQjtBQUNBRix1QkFBZTtBQUFBLFVBQ2JHLE1BQU07QUFBQSxVQUNORCxTQUFTLEdBQUdrRixPQUFPRixVQUFVQyxNQUFNakYsT0FBTztBQUFBLFVBQzFDRCxZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0xELHVCQUFlO0FBQUEsVUFDYkcsTUFBTTtBQUFBLFVBQ05ELFNBQVM7QUFBQSxVQUNURCxZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBR0EsUUFBTWlOLGdCQUFnQkEsTUFDcEIsdUJBQUMsU0FBSSxXQUFVLHlDQUNaaFEsZ0JBQU1pSjtBQUFBQSxJQUFJLENBQUN5QyxNQUFNdUUsUUFDaEIsdUJBQUMsU0FBa0IsV0FBVSxxQkFDM0I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVywwR0FBMEd6TSxnQkFBZ0JrSSxLQUFLekwsS0FDdEksMkNBQ0F1RCxjQUFja0ksS0FBS3pMLEtBQ2pCLDZDQUNBLHdDQUF3QztBQUFBLFlBRzdDdUQsd0JBQWNrSSxLQUFLekwsS0FBSyx1QkFBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQixJQUFNeUwsS0FBS3pMO0FBQUFBO0FBQUFBLFVBUnREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVyw4Q0FBOEN1RCxnQkFBZ0JrSSxLQUFLekwsS0FBSyxrQkFBa0IsZUFBZTtBQUFBLFlBR25IeUwsZUFBS3hMO0FBQUFBO0FBQUFBLFVBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsTUFDQytQLE1BQU1qUSxNQUFNb00sU0FBUyxLQUNwQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVyx3QkFBd0I1SSxjQUFja0ksS0FBS3pMLEtBQUssaUJBQWlCLGFBQWE7QUFBQTtBQUFBLFFBRDNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVPO0FBQUEsU0F0QkR5TCxLQUFLekwsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsRUFDRCxLQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkJBO0FBR0YsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGFBRWI7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCaUg7QUFBQUEsVUFDN0IsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTXJFLFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDNEYsVUFBVSxFQUFFLEdBQUdBLE1BQU0zRixZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUlILHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxTQUFJLFdBQVUsNENBQ2IsaUNBQUMsUUFBRyxXQUFVLDBCQUF5Qix5QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRCxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNDaEMsWUFBWXFMLFNBQVMsS0FBSyxDQUFDekssWUFDMUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLGVBQWU4STtBQUFBQSxZQUNmLE1BQU14TCxhQUFhOEIsWUFBWWlHLFVBQVU7QUFBQSxZQUN6QztBQUFBLFlBQ0EsWUFBWXFIO0FBQUFBLFlBQ1osaUJBQWlCO0FBQUEsWUFDakIsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWtCO0FBQUE7QUFBQSxVQVJwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRb0MsSUFHcEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTdE4sV0FBV3FMLFVBQVU7QUFBQSxZQUM5QixNQUFLO0FBQUE7QUFBQSxVQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdzQjtBQUFBLFdBaEMxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUNBO0FBQUEsU0FuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9EQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdoTTtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQywyQkFBaUIsS0FBSztBQUN0Qm9ELHlCQUFlLENBQUM7QUFBQSxRQUNsQjtBQUFBLFFBRUE7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHQSx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjO0FBQUEsWUFFZDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixVQUFVNko7QUFBQUEsZ0JBQ1YsWUFBVTtBQUFBLGdCQUdUOUo7QUFBQUEsa0NBQWdCLEtBQ2YsbUNBQ0U7QUFBQSwyQ0FBQyxTQUNDO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLFNBQVE7QUFBQSwwQkFBTztBQUFBO0FBQUEsNEJBRUwsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBaUM7QUFBQTtBQUFBO0FBQUEsd0JBSjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBT08sVUFBVUU7QUFBQUEsMEJBQ2pCLFVBQVVxSDtBQUFBQSwwQkFDVixJQUFHO0FBQUEsMEJBQ0gsYUFBWTtBQUFBLDBCQUNaO0FBQUEsMEJBQ0EsV0FBVyxxQ0FBcUNqTSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsd0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFRNko7QUFBQSxzQkFFNUpoTixPQUFPZSxhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmYsaUJBQU9lLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXNCQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVE7QUFBQSw0QkFBTTtBQUFBO0FBQUEsMEJBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxNQUFLO0FBQUEsNEJBQ0wsT0FBT0YsU0FBU0c7QUFBQUEsNEJBQ2hCLFVBQVVvSDtBQUFBQSw0QkFDVixJQUFHO0FBQUEsNEJBQ0gsYUFBWTtBQUFBLDRCQUNaO0FBQUEsNEJBQ0EsV0FBVyxxQ0FBcUNqTSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsMEJBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFRNko7QUFBQSx3QkFFNUpoTixPQUFPZ0IsU0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCaEIsaUJBQU9nQixTQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF1RDtBQUFBLDJCQWxCM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFvQkE7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFRO0FBQUEsNEJBQU07QUFBQTtBQUFBLDhCQUVELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBQWlDO0FBQUE7QUFBQTtBQUFBLDBCQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBS0E7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxNQUFLO0FBQUEsNEJBQ0wsTUFBSztBQUFBLDRCQUNMLE9BQU9ILFNBQVNJO0FBQUFBLDRCQUNoQixVQUFVbUg7QUFBQUEsNEJBQ1YsSUFBRztBQUFBLDRCQUNILGFBQVk7QUFBQSw0QkFDWjtBQUFBLDRCQUNBLFdBQVcscUNBQXFDak0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLDBCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUTZKO0FBQUEsd0JBRTVKaE4sT0FBT2lCLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmpCLGlCQUFPaUIsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXNCQTtBQUFBLHlCQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQTZDQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVE7QUFBQSw0QkFBTTtBQUFBO0FBQUEsOEJBRUwsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBaUM7QUFBQTtBQUFBO0FBQUEsMEJBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxNQUFLO0FBQUEsNEJBQ0wsT0FBT0osU0FBU0s7QUFBQUEsNEJBQ2hCLFVBQVVrSDtBQUFBQSw0QkFDVixJQUFHO0FBQUEsNEJBQ0gsYUFBWTtBQUFBLDRCQUNaO0FBQUEsNEJBQ0EsV0FBVyxxQ0FBcUNqTSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsMEJBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFRNko7QUFBQSx3QkFFNUpoTixPQUFPa0IsWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZsQixpQkFBT2tCLFlBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXNCQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVE7QUFBQSw0QkFBTTtBQUFBO0FBQUEsOEJBRU4sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBaUM7QUFBQTtBQUFBO0FBQUEsMEJBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxNQUFLO0FBQUEsNEJBQ0wsT0FBT0wsU0FBU1E7QUFBQUEsNEJBQ2hCLFVBQVUrRztBQUFBQSw0QkFDVixJQUFHO0FBQUEsNEJBQ0gsYUFBWTtBQUFBLDRCQUNaO0FBQUEsNEJBQ0EsV0FBVyxxQ0FBcUNqTSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsMEJBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFRNko7QUFBQSx3QkFFNUpoTixPQUFPcUIsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZyQixpQkFBT3FCLFdBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXNCQTtBQUFBLHlCQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQStDQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVE7QUFBQSw0QkFBTTtBQUFBO0FBQUEsOEJBRUEsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBaUM7QUFBQTtBQUFBO0FBQUEsMEJBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxNQUFLO0FBQUEsNEJBQ0wsT0FBT1IsU0FBU1M7QUFBQUEsNEJBQ2hCLFVBQVU4RztBQUFBQSw0QkFDVixJQUFHO0FBQUEsNEJBQ0gsYUFBWTtBQUFBLDRCQUNaO0FBQUEsNEJBQ0EsV0FBVyxxQ0FBcUNqTSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsMEJBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFRNko7QUFBQSx3QkFFNUpoTixPQUFPc0IsYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z0QixpQkFBT3NCLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXNCQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVE7QUFBQSw0QkFBTTtBQUFBO0FBQUEsMEJBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxNQUFLO0FBQUEsNEJBQ0wsT0FBT1QsVUFBVVU7QUFBQUEsNEJBQ2pCLFVBQVU2RztBQUFBQSw0QkFDVixJQUFHO0FBQUEsNEJBQ0gsYUFBWTtBQUFBLDRCQUNaO0FBQUEsNEJBQ0EsV0FBVyxxQ0FBcUNqTSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsMEJBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFRNko7QUFBQSx3QkFFNUpoTixPQUFPdUIsVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCdkIsaUJBQU91QixVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF3RDtBQUFBLDJCQWxCNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFvQkE7QUFBQSx5QkE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkE2Q0E7QUFBQSxvQkFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLFNBQVE7QUFBQSwwQkFBTztBQUFBO0FBQUEsNEJBRVMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBaUM7QUFBQTtBQUFBO0FBQUEsd0JBSjNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBT1YsU0FBU007QUFBQUEsMEJBQ2hCLFVBQVVpSDtBQUFBQSwwQkFDVixJQUFHO0FBQUEsMEJBQ0gsYUFBWTtBQUFBLDBCQUNaO0FBQUEsMEJBQ0EsV0FBVyxxQkFBcUJqTSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsd0JBUmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFRNkc7QUFBQSxzQkFFNUdoTixPQUFPbUIsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCbkIsaUJBQU9tQixXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5RDtBQUFBLHlCQWxCN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFvQkE7QUFBQSxvQkFHQSx1QkFBQyxTQUNDO0FBQUEsNkNBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVE7QUFBQSw0QkFBbUI7QUFBQTtBQUFBLDhCQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBQWlDO0FBQUE7QUFBQTtBQUFBLDBCQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBS0E7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxTQUFTWDtBQUFBQSw0QkFDVCxVQUFVaUY7QUFBQUEsNEJBQXdCO0FBQUE7QUFBQSwwQkFGcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsMkJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFhQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBTzVFLFNBQVNPO0FBQUFBLDBCQUNoQixVQUFVZ0g7QUFBQUEsMEJBQ1YsVUFBVTVIO0FBQUFBLDBCQUNWLElBQUc7QUFBQSwwQkFDSCxhQUFZO0FBQUEsMEJBQ1osV0FBVyxxQkFBcUJyRSxVQUFVNlEsTUFBTSw0REFBNER4TSxnQkFBZ0Isa0NBQWtDLEVBQUU7QUFBQTtBQUFBLHdCQVJsSztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBU087QUFBQSxzQkFFTlIsT0FBT29CLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnBCLGlCQUFPb0IscUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQStCQTtBQUFBLHVCQTFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTJOQTtBQUFBLGtCQUlEZCxnQkFBZ0IsS0FDZixtQ0FDRTtBQUFBLDJDQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLDZDQUFDLFNBQ0M7QUFBQSwrQ0FBQyxXQUFNLFdBQVUsa0RBQWlELDJCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsTUFBSztBQUFBLDRCQUNMLE1BQUs7QUFBQSw0QkFDTCxPQUFPTyxVQUFVaUI7QUFBQUEsNEJBQ2pCLFVBQVVzRztBQUFBQSw0QkFDVixhQUFZO0FBQUEsNEJBQ1osV0FBVyxxQ0FBcUNqTSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsMEJBTmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFNaUk7QUFBQSx3QkFFaEloTixPQUFPOEIsZUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCOUIsaUJBQU84QixlQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2RDtBQUFBLDJCQWJqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWVBO0FBQUEsc0JBR0EsdUJBQUMsU0FDQztBQUFBLCtDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLDBCQUNsRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUEsNkJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFXLHFDQUFxQzNGLFVBQVU2USxNQUFNO0FBQUEsNEJBQ2hFLGFBQVk7QUFBQSw0QkFDWix1QkFBdUI7QUFBQSw0QkFDdkI7QUFBQSw0QkFDQSxNQUFLO0FBQUEsNEJBQ0wsY0FBYyxDQUFDQyxPQUFPaEYsV0FDcEJBLE9BQU9pRixTQUFTM0IsWUFBWSxFQUFFM0QsU0FBU3FGLE1BQU0xQixZQUFZLENBQUM7QUFBQSw0QkFFNUQsT0FBTzFLLFVBQVVhLGlCQUFpQnNJO0FBQUFBLDRCQUNsQyxVQUFVLENBQUM5RixVQUFVOEQsaUJBQWlCLGlCQUFpQjlELEtBQUs7QUFBQSw0QkFFM0Q7QUFBQSw4QkFDQztBQUFBLDhCQUNBO0FBQUEsOEJBQ0E7QUFBQSw4QkFDQTtBQUFBLDhCQUNBO0FBQUEsNEJBQVEsRUFDUjZCO0FBQUFBLDhCQUFJLENBQUNvSCxZQUNMLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxTQUNqQ0EscUJBRGlCQSxTQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUVBO0FBQUEsNEJBQ0Q7QUFBQTtBQUFBLDBCQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBdUJBO0FBQUEsMkJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBNEJBO0FBQUEseUJBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaURBO0FBQUEsb0JBRUN0TSxTQUFTYSxrQkFBa0IsY0FDMUIsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUTtBQUFBLDBCQUFVO0FBQUE7QUFBQSw0QkFFTztBQUFBLDRCQUN6Qix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFpQztBQUFBO0FBQUE7QUFBQSx3QkFMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU1BO0FBQUEsc0JBRUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVyxxQ0FBcUN2RixVQUFVNlEsTUFBTTtBQUFBLDBCQUNoRSxhQUFZO0FBQUEsMEJBQ1osdUJBQXVCO0FBQUEsMEJBQ3ZCO0FBQUEsMEJBQ0EsTUFBSztBQUFBLDBCQUNMLGNBQWMsQ0FBQ0MsT0FBT2hGLFdBQ3BCQSxPQUFPaUYsU0FDSkUsU0FBUyxFQUNUN0IsWUFBWSxFQUNaM0QsU0FBU3FGLE1BQU0xQixZQUFZLENBQUM7QUFBQSwwQkFFakMsT0FBTzFLLFVBQVVnQixxQkFBcUJtSTtBQUFBQSwwQkFDdEMsVUFBVSxDQUFDOUYsVUFDVDhELGlCQUFpQixxQkFBcUI5RCxLQUFLO0FBQUEsMEJBRzVDM0csb0JBQVV3STtBQUFBQSw0QkFBSSxDQUFDdUYsU0FDZCx1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS3BGLEtBQ3ZDb0Y7QUFBQUEsbUNBQUt2SztBQUFBQSw4QkFBVTtBQUFBLDhCQUFHO0FBQUEsOEJBQ2xCdUssS0FBS3JLLGVBQWVxSyxLQUFLckssZUFBZTtBQUFBLGlDQUZ2QnFLLEtBQUtwRixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUdBO0FBQUEsMEJBQ0Q7QUFBQTtBQUFBLHdCQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBdUJBO0FBQUEseUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUNBO0FBQUEsb0JBRURyRixTQUFTYSxrQkFBa0IsV0FDMUIsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSx3QkFDeEM7QUFBQSx3QkFDdEIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBLDJCQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVyxxQ0FBcUN2RixVQUFVNlEsTUFBTTtBQUFBLDBCQUNoRSxhQUFZO0FBQUEsMEJBQ1osdUJBQXVCO0FBQUEsMEJBQ3ZCO0FBQUEsMEJBQ0EsTUFBSztBQUFBLDBCQUNMLGNBQWMsQ0FBQ0MsT0FBT2hGLFdBQ3BCQSxPQUFPaUYsU0FDSkUsU0FBUyxFQUNUN0IsWUFBWSxFQUNaM0QsU0FBU3FGLE1BQU0xQixZQUFZLENBQUM7QUFBQSwwQkFFakMsT0FBTzFLLFNBQVNlLGtCQUFrQm9JO0FBQUFBLDBCQUNsQyxVQUFVLENBQUM5RixVQUNUOEQsaUJBQWlCLGtCQUFrQjlELEtBQUs7QUFBQSwwQkFHekN6RyxpQkFBT3NJO0FBQUFBLDRCQUFJLENBQUNaLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1lLEtBQ3pDZjtBQUFBQSxvQ0FBTWlCO0FBQUFBLDhCQUFLO0FBQUEsOEJBQUlqQixNQUFNbEU7QUFBQUEsaUNBREprRSxNQUFNZSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsMEJBQ0Q7QUFBQTtBQUFBLHdCQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBc0JBO0FBQUEseUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBNEJBO0FBQUEsb0JBRURyRixTQUFTYSxrQkFBa0IsY0FDMUIsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUTtBQUFBLDBCQUFVO0FBQUE7QUFBQSw0QkFFTztBQUFBLDRCQUN6Qix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFpQztBQUFBO0FBQUE7QUFBQSx3QkFMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU1BO0FBQUEsc0JBRUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVyxxQ0FBcUN2RixVQUFVNlEsTUFBTTtBQUFBLDBCQUNoRSxhQUFZO0FBQUEsMEJBQ1osdUJBQXVCO0FBQUEsMEJBQ3ZCO0FBQUEsMEJBQ0EsTUFBSztBQUFBLDBCQUNMLGNBQWMsQ0FBQ0MsT0FBT2hGLFdBQVc7QUFDL0IsZ0NBQUksQ0FBQ0EsVUFBVSxDQUFDQSxPQUFPaUYsU0FBVSxRQUFPO0FBRXhDLG1DQUFPakYsT0FBT2lGLFNBQ1hFLFNBQVMsRUFDVDdCLFlBQVksRUFDWjNELFNBQVNxRixNQUFNMUIsWUFBWSxDQUFDO0FBQUEsMEJBQ2pDO0FBQUEsMEJBQ0EsT0FBTzFLLFVBQVVjLHFCQUFxQnFJO0FBQUFBLDBCQUN0QyxVQUFVLENBQUM5RixVQUNUOEQsaUJBQWlCLHFCQUFxQjlELEtBQUs7QUFBQSwwQkFHNUN2RyxvQkFBVW9JO0FBQUFBLDRCQUFJLENBQUNULGFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQWlDLE9BQU9BLFNBQVNZLEtBQy9DWjtBQUFBQSx1Q0FBU2M7QUFBQUEsOEJBQUs7QUFBQSw4QkFBSWQsU0FBU3JFO0FBQUFBLGlDQURWcUUsU0FBU1ksS0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDBCQUNEO0FBQUE7QUFBQSx3QkF2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXdCQTtBQUFBLHlCQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWtDQTtBQUFBLG9CQUVGLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUTtBQUFBLDRCQUFNO0FBQUE7QUFBQSwwQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLGFBQVk7QUFBQSw0QkFDWix1QkFBdUI7QUFBQSw0QkFDdkIsTUFBSztBQUFBLDRCQUNMO0FBQUEsNEJBQ0EsY0FBYyxDQUFDK0csT0FBT2hGLFdBQ3BCQSxPQUFPaUYsU0FDSkUsU0FBUyxFQUNUN0IsWUFBWSxFQUNaM0QsU0FBU3FGLE1BQU0xQixZQUFZLENBQUM7QUFBQSw0QkFFakMsT0FBTzFLLFVBQVVZLG1CQUFtQnVJO0FBQUFBLDRCQUNwQyxVQUFVLENBQUM5RixPQUFPK0QsV0FDaEJELGlCQUFpQixtQkFBbUI5RCxPQUFPK0QsT0FBT2lGLFFBQVE7QUFBQSw0QkFHM0RqTyxnQkFBTThHO0FBQUFBLDhCQUFJLENBQUNzSCxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLbkgsS0FDdkNtSCxlQUFLekcsY0FEWXlHLEtBQUtuSCxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUVBO0FBQUEsNEJBQ0Q7QUFBQTtBQUFBLDBCQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBc0JBO0FBQUEsMkJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBOEJBO0FBQUEsc0JBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUTtBQUFBLDRCQUErQjtBQUFBO0FBQUEsMEJBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHdCQUVBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixhQUFZO0FBQUEsNEJBQ1osdUJBQXVCO0FBQUEsNEJBQ3ZCLE1BQUs7QUFBQSw0QkFDTDtBQUFBLDRCQUNBLGNBQWMsQ0FBQytHLE9BQU9oRixXQUNwQkEsT0FBT2lGLFNBQ0pFLFNBQVMsRUFDVDdCLFlBQVksRUFDWjNELFNBQVNxRixNQUFNMUIsWUFBWSxDQUFDO0FBQUEsNEJBRWpDLE9BQ0UxSyxVQUFVb0IsaUNBQWlDK0g7QUFBQUEsNEJBRTdDLFVBQVUsQ0FBQzlGLE9BQU8rRCxXQUNoQkQ7QUFBQUEsOEJBQ0U7QUFBQSw4QkFDQTlEO0FBQUFBLDhCQUNBK0QsT0FBT2lGO0FBQUFBLDRCQUNUO0FBQUEsNEJBSUR2UCxvQkFBVW9JO0FBQUFBLDhCQUFJLENBQUNULGFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQWlDLE9BQU9BLFNBQVNZLEtBQy9DWjtBQUFBQSx5Q0FBU2M7QUFBQUEsZ0NBQUs7QUFBQSxnQ0FBSWQsU0FBU3JFO0FBQUFBLG1DQURWcUUsU0FBU1ksS0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FFQTtBQUFBLDRCQUNEO0FBQUE7QUFBQSwwQkE1Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQTZCQTtBQUFBLDJCQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXNDQTtBQUFBLHlCQXZFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXdFQTtBQUFBLG9CQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZDQUFDLFNBQ0M7QUFBQSwrQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSwwQkFDOUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFnQztBQUFBLDZCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQyxNQUFNO0FBQUEsMEJBQU47QUFBQSw0QkFDQyxNQUFLO0FBQUEsNEJBQ0wsT0FBT3JGLFNBQVNrQjtBQUFBQSw0QkFDaEIsVUFBVSxDQUFDa0MsTUFDVCtELGlCQUFpQixvQkFBb0IvRCxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsNEJBR3JEO0FBQUEscURBQUMsU0FBTSxPQUFNLFNBQVEscUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBQTBCO0FBQUEsOEJBQzFCLHVCQUFDLFNBQU0sT0FBTSxVQUFTLHNCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUE0QjtBQUFBLDhCQUM1Qix1QkFBQyxTQUFNLE9BQU0sV0FBVSx1QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBOEI7QUFBQTtBQUFBO0FBQUEsMEJBVGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFVQTtBQUFBLHdCQUNDbEUsT0FBTytCLG9CQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVi9CLGlCQUFPK0Isb0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQW9CQTtBQUFBLHNCQUVDbEIsU0FBU2tCLG9CQUNSLHVCQUFDLFNBQ0M7QUFBQSwrQ0FBQyxXQUFNLFdBQVUsa0RBQ2RsQjtBQUFBQSxtQ0FBU2tCLGlCQUFpQnVMLE9BQU8sQ0FBQyxFQUFFckUsWUFBWSxJQUMvQ3BJLFNBQVNrQixpQkFBaUJ3TCxNQUFNLENBQUM7QUFBQSwwQkFBRztBQUFBLDBCQUFJO0FBQUEsMEJBQ3ZCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBZ0M7QUFBQSw2QkFIckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFJQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxNQUFLO0FBQUEsNEJBQ0wsT0FBTzFNLFNBQVNtQjtBQUFBQSw0QkFDaEIsVUFBVW9HO0FBQUFBLDRCQUNWLGFBQWEsU0FBU3ZILFNBQVNrQixnQkFBZ0I7QUFBQSw0QkFDL0MsV0FBVyxxQ0FBcUM1RixVQUFVNlEsTUFBTTtBQUFBO0FBQUEsMEJBTmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFNaUk7QUFBQSx3QkFFaEloTixPQUFPZ0Msc0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEMsaUJBQU9nQyxzQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsMkJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBbUJBO0FBQUEseUJBM0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBNkNBO0FBQUEsb0JBR0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLFNBQVE7QUFBQSwwQkFBaUI7QUFBQTtBQUFBLHdCQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxzQkFFQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxTQUFRO0FBQUEsMEJBQ1IsV0FBVTtBQUFBLDBCQUVWO0FBQUE7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0MsSUFBRztBQUFBLGdDQUNILE1BQUs7QUFBQSxnQ0FDTCxRQUFPO0FBQUEsZ0NBQ1AsV0FBVTtBQUFBLGdDQUNWLFVBQVUsQ0FBQ2lDLE1BQU07QUFDZix3Q0FBTTRILE9BQU81SCxFQUFFRSxPQUFPaEYsTUFBTSxDQUFDO0FBQzdCLHNDQUFJLENBQUMwTSxLQUFNO0FBR1gsc0NBQ0UsQ0FBQ0EsS0FBSzlMLEtBQUt5TixXQUFXLFlBQVksS0FDbEMsQ0FBQzNCLEtBQUs5TCxLQUFLeU4sV0FBVyxXQUFXLEdBQ2pDO0FBQ0FDLDBDQUFNLCtCQUErQjtBQUNyQztBQUFBLGtDQUNGO0FBR0EvTixpREFBZSxDQUFDbU0sSUFBSSxDQUFDO0FBQUEsZ0NBQ3ZCO0FBQUE7QUFBQSw4QkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQW9CSTtBQUFBLDRCQUdIcE0sWUFBWXlKLFdBQVcsSUFDdEIsdUJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEscURBQUMsZUFBWSxNQUFNLElBQUksV0FBVSx3QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBcUQ7QUFBQSw4QkFDckQsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQyw0QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FFQTtBQUFBLDhCQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsbUNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBRUE7QUFBQSxpQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQVFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUE7QUFBQSxnQ0FBQztBQUFBO0FBQUEsa0NBQ0MsS0FBS3dFLElBQUlDLGdCQUFnQmxPLFlBQVksQ0FBQyxDQUFDO0FBQUEsa0NBQ3ZDLEtBQUk7QUFBQSxrQ0FDSixXQUFVO0FBQUE7QUFBQSxnQ0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBR3lDO0FBQUEsOEJBRXpDLHVCQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBO0FBQUEsa0NBQUM7QUFBQTtBQUFBLG9DQUNDLE1BQUs7QUFBQSxvQ0FDTCxTQUFTLE1BQU1DLGVBQWUsRUFBRTtBQUFBLG9DQUNoQyxXQUFVO0FBQUEsb0NBRVYsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FBWTtBQUFBO0FBQUEsa0NBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQU1BO0FBQUEsZ0NBR0E7QUFBQSxrQ0FBQztBQUFBO0FBQUEsb0NBQ0MsTUFBTWdPLElBQUlDLGdCQUFnQmxPLFlBQVksQ0FBQyxDQUFDO0FBQUEsb0NBQ3hDLFVBQVVBLFlBQVksQ0FBQyxFQUFFMkc7QUFBQUEsb0NBQ3pCLFdBQVU7QUFBQSxvQ0FFVixpQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FBbUI7QUFBQTtBQUFBLGtDQUxyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBTUE7QUFBQSxtQ0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FrQkE7QUFBQSxpQ0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0F5QkE7QUFBQTtBQUFBO0FBQUEsd0JBL0RKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFpRUE7QUFBQSx5QkF6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkEwRUE7QUFBQSx1QkFoV0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpV0E7QUFBQSxrQkFJRix1QkFBQyxTQUFJLFdBQVUsMkNBQ1o5RjtBQUFBQSxvQ0FBZ0IsS0FDZjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsU0FBUyxNQUFNQyxlQUFlLENBQUM7QUFBQSx3QkFDL0IsV0FBVTtBQUFBLHdCQUEwSDtBQUFBO0FBQUEsc0JBSHRJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLG9CQUVGO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFTaUs7QUFBQUEsd0JBQ1QsV0FBVTtBQUFBLHdCQUEwSDtBQUFBO0FBQUEsc0JBSHRJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLG9CQUNDbEssZ0JBQWdCLElBQ2Y7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFNBQVNpSztBQUFBQSx3QkFDVCxXQUFVO0FBQUEsd0JBQzJGO0FBQUE7QUFBQSxzQkFKdkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9BLElBRUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDMkY7QUFBQTtBQUFBLHNCQUh2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTUE7QUFBQSx1QkFqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQ0E7QUFBQTtBQUFBO0FBQUEsY0EvbUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWduQkE7QUFBQSxlQXhuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5bkJBO0FBQUEsVUFDQ3JLLGVBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFFBQVFBO0FBQUFBLGNBQ1IsT0FBTTtBQUFBLGNBQ04sTUFBTVE7QUFBQUEsY0FDTixVQUFVLE1BQU1QLGVBQWUsS0FBSztBQUFBLGNBQ3BDLFdBQVdzSztBQUFBQTtBQUFBQSxZQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUswQjtBQUFBO0FBQUE7QUFBQSxNQXZvQjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTBvQkE7QUFBQSxJQUlBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXcE07QUFBQUEsUUFDWCxTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFFdkM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVcsK0JBQStCLENBQUM0RCxrQkFBa0JvSCxPQUFPQyxLQUFLckgsY0FBYyxFQUFFZ0gsV0FBVyxJQUNoRyxjQUNBLEVBQUU7QUFBQSxZQUdOO0FBQUEscUNBQUMsUUFBRyxXQUFVLHdDQUF1QywrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0MsQ0FBQ2hILGtCQUFrQm9ILE9BQU9DLEtBQUtySCxjQUFjLEVBQUVnSCxXQUFXLElBQ3pELHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxPQUFFLFdBQVUseUJBQXdCLDBDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVV5RCxjQUFjLFlBQVUsTUFDNUQ7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU87QUFBQTtBQUFBLHNCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLEdBQUcsQ0FBQ3pLLGdCQUFnQkUsU0FDN0JGLGdCQUFnQkUsTUFBTTJHLEtBQUssTUFBTSxLQUMvQiw2QkFDQSw0QkFBNEI7QUFBQSx3QkFFaEMsYUFBWTtBQUFBLHdCQUNaLHVCQUF1QjtBQUFBLHdCQUN2QjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUNrRSxPQUFPaEYsV0FDcEJBLE9BQU9pRixTQUNKM0IsWUFBWSxFQUNaM0QsU0FBU3FGLE1BQU0xQixZQUFZLENBQUM7QUFBQSx3QkFFakMsT0FBT3JKLGdCQUFnQkUsU0FBUzRIO0FBQUFBLHdCQUNoQyxVQUFVLENBQUM5RixVQUNUeUIsc0JBQXNCLFNBQVN6QixLQUFLO0FBQUEsd0JBR3RDO0FBQUEsaURBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFvQztBQUFBLDBCQUNuQyxDQUFDLE1BQU0sTUFBTSxPQUFPLE9BQU8sSUFBSSxFQUFFNkI7QUFBQUEsNEJBQUksQ0FBQzZILFdBQ3JDLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxRQUNoQ0Esb0JBRGlCQSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsMEJBQ0Q7QUFBQTtBQUFBO0FBQUEsc0JBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkEwQkE7QUFBQSx1QkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQ0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU87QUFBQTtBQUFBLDBCQUVMLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUE7QUFBQTtBQUFBLHNCQUo3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU8xTCxnQkFBZ0JuQjtBQUFBQSx3QkFDdkIsVUFBVTBLO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFXLEdBQUcsQ0FBQ3ZKLGdCQUFnQm5CLGFBQzdCbUIsZ0JBQWdCbkIsVUFBVWdJLEtBQUssTUFBTSxLQUNuQyw2QkFDQSw0QkFBNEIsSUFDMUI1TSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsc0JBWnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFhK0Y7QUFBQSxvQkFFOUZoTixPQUFPZSxhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmYsaUJBQU9lLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTJCQTtBQUFBLHFCQWpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBTTtBQUFBO0FBQUEsc0JBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT21CLGdCQUFnQmxCO0FBQUFBLHdCQUN2QixVQUFVeUs7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVcsR0FBRyxDQUFDdkosZ0JBQWdCbEIsU0FDN0JrQixnQkFBZ0JsQixNQUFNK0gsS0FBSyxNQUFNLEtBQy9CLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUE7QUFBQSxzQkFaeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWErRjtBQUFBLG9CQUU5RmhOLE9BQU9nQixTQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmhCLGlCQUFPZ0IsU0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFNO0FBQUE7QUFBQSwwQkFFRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFpQztBQUFBO0FBQUE7QUFBQSxzQkFKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPa0IsZ0JBQWdCakI7QUFBQUEsd0JBQ3ZCLFVBQVV3SztBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxHQUFHLENBQUN2SixnQkFBZ0JqQixnQkFDN0JpQixnQkFBZ0JqQixhQUFhOEgsS0FBSyxNQUFNLEtBQ3RDLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUE7QUFBQSxzQkFaeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWErRjtBQUFBLG9CQUU5RmhOLE9BQU9pQixnQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZqQixpQkFBT2lCLGdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEyQkE7QUFBQSxxQkF4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5REE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLDBCQUVBLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUE7QUFBQTtBQUFBLHNCQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9pQixnQkFBZ0JaO0FBQUFBLHdCQUN2QixVQUFVbUs7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVcsR0FBRyxDQUFDdkosZ0JBQWdCWixhQUM3QlksZ0JBQWdCWixVQUFVeUgsS0FBSyxNQUFNLEtBQ25DLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUE7QUFBQSxzQkFaeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWErRjtBQUFBLG9CQUU5RmhOLE9BQU9zQixhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnRCLGlCQUFPc0IsYUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFNO0FBQUE7QUFBQSxzQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPWSxnQkFBZ0JYO0FBQUFBLHdCQUN2QixVQUFVa0s7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVcsR0FBRyxDQUFDdkosZ0JBQWdCWCxVQUM3QlcsZ0JBQWdCWCxPQUFPd0gsS0FBSyxNQUFNLEtBQ2hDLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUE7QUFBQSxzQkFaeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWErRjtBQUFBLG9CQUU5RmhOLE9BQU91QixVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnZCLGlCQUFPdUIsVUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEscUJBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeURBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVM7QUFBQTtBQUFBLHdCQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLE9BQU9XLGdCQUFnQmY7QUFBQUEsc0JBQ3ZCLFVBQVVzSztBQUFBQSxzQkFDVixJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVyxHQUFHLENBQUN2SixnQkFBZ0JmLFdBQzdCZSxnQkFBZ0JmLFFBQVE0SCxLQUFLLE1BQU0sS0FDakMsNkJBQ0EsNEJBQTRCLElBQzFCNU0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLG9CQVp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBYStGO0FBQUEsa0JBRTlGaE4sT0FBT21CLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWbkIsaUJBQU9tQixXQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEyQkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLDBCQUVOLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUE7QUFBQTtBQUFBLHNCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9lLGdCQUFnQmI7QUFBQUEsd0JBQ3ZCLFVBQVVvSztBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxHQUFHLENBQUN2SixnQkFBZ0JiLFdBQzdCYSxnQkFBZ0JiLFFBQVEwSCxLQUFLLE1BQU0sS0FDakMsNkJBQ0EsNEJBQTRCLElBQzFCNU0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLHNCQVp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBYStGO0FBQUEsb0JBRTlGaE4sT0FBT3FCLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWckIsaUJBQU9xQixXQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEyQkE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU87QUFBQTtBQUFBLHNCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9hLGdCQUFnQlM7QUFBQUEsd0JBQ3ZCLFVBQVU4STtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaLFdBQVcsR0FBRyxDQUFDdkosZ0JBQWdCUyxlQUM3QlQsZ0JBQWdCUyxZQUFZb0csS0FBSyxNQUFNLEtBQ3JDLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUE7QUFBQSxzQkFYeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVkrRjtBQUFBLHVCQW5Cakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFxQkE7QUFBQSxxQkFuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFvREE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsb0JBQ2xELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcscUNBQXFDN1EsVUFBVTZRLE1BQU07QUFBQSxzQkFDaEUsYUFBWTtBQUFBLHNCQUNaLHVCQUF1QjtBQUFBLHNCQUN2QjtBQUFBLHNCQUNBLE1BQUs7QUFBQSxzQkFDTCxjQUFjLENBQUNDLE9BQU9oRixXQUNwQkEsT0FBT2lGLFNBQ0ozQixZQUFZLEVBQ1ozRCxTQUFTcUYsTUFBTTFCLFlBQVksQ0FBQztBQUFBLHNCQUVqQyxPQUFPckosZ0JBQWdCUixpQkFBaUJzSTtBQUFBQSxzQkFDeEMsVUFBVSxDQUFDOUYsVUFDVHlCLHNCQUFzQixpQkFBaUJ6QixLQUFLO0FBQUEsc0JBRzdDO0FBQUEsd0JBQ0M7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQTtBQUFBLHNCQUFRLEVBQ1I2QjtBQUFBQSx3QkFBSSxDQUFDb0gsWUFDTCx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsU0FDakNBLHFCQURpQkEsU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNEO0FBQUE7QUFBQSxvQkExQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQTJCQTtBQUFBLHFCQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdDQTtBQUFBLGdCQUNDakwsZUFBZVIsa0JBQWtCLGNBQ2hDLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVTtBQUFBO0FBQUEsd0JBRU87QUFBQSx3QkFDekIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUM7QUFBQTtBQUFBO0FBQUEsb0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcscUNBQXFDdkYsVUFBVTZRLE1BQU07QUFBQSxzQkFDaEUsYUFBWTtBQUFBLHNCQUNaLHVCQUF1QjtBQUFBLHNCQUN2QjtBQUFBLHNCQUNBLE1BQUs7QUFBQSxzQkFDTCxjQUFjLENBQUNDLE9BQU9oRixXQUNwQkEsT0FBT2lGLFNBQ0pFLFNBQVMsRUFDVDdCLFlBQVksRUFDWjNELFNBQVNxRixNQUFNMUIsWUFBWSxDQUFDO0FBQUEsc0JBRWpDLE9BQU9ySixnQkFBZ0JMLHFCQUFxQm1JO0FBQUFBLHNCQUM1QyxVQUFVLENBQUM5RixVQUNUeUIsc0JBQXNCLHFCQUFxQnpCLEtBQUs7QUFBQSxzQkFHakQzRyxxQkFBV3dJO0FBQUFBLHdCQUFJLENBQUN1RixTQUNmLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLcEYsS0FDdkNvRjtBQUFBQSwrQkFBS3ZLO0FBQUFBLDBCQUFVO0FBQUEsMEJBQUc7QUFBQSwwQkFDbEJ1SyxLQUFLckssZUFBZXFLLEtBQUtySyxlQUFlO0FBQUEsNkJBRnZCcUssS0FBS3BGLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBR0E7QUFBQSxzQkFDRDtBQUFBO0FBQUEsb0JBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkF1QkE7QUFBQSxxQkFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQ0E7QUFBQSxnQkFFRGhFLGVBQWVSLGtCQUFrQixXQUNoQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLG9CQUN4QztBQUFBLG9CQUN0Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsdUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLHFDQUFxQ3ZGLFVBQVU2USxNQUFNO0FBQUEsc0JBQ2hFLGFBQVk7QUFBQSxzQkFDWix1QkFBdUI7QUFBQSxzQkFDdkI7QUFBQSxzQkFDQSxNQUFLO0FBQUEsc0JBQ0wsY0FBYyxDQUFDQyxPQUFPaEYsV0FDcEJBLE9BQU9pRixTQUNKRSxTQUFTLEVBQ1Q3QixZQUFZLEVBQ1ozRCxTQUFTcUYsTUFBTTFCLFlBQVksQ0FBQztBQUFBLHNCQUVqQyxPQUFPckosZUFBZU4sa0JBQWtCb0k7QUFBQUEsc0JBQ3hDLFVBQVUsQ0FBQzlGLFVBQ1R5QixzQkFBc0Isa0JBQWtCekIsS0FBSztBQUFBLHNCQUc5Q3pHLGlCQUFPc0k7QUFBQUEsd0JBQUksQ0FBQ1osVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTWUsS0FDekNmO0FBQUFBLGdDQUFNaUI7QUFBQUEsMEJBQUs7QUFBQSwwQkFBSWpCLE1BQU1sRTtBQUFBQSw2QkFESmtFLE1BQU1lLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFDRDtBQUFBO0FBQUEsb0JBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFzQkE7QUFBQSxxQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0QkE7QUFBQSxnQkFFRGhFLGVBQWVSLGtCQUFrQixjQUNoQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVU7QUFBQTtBQUFBLHdCQUVPO0FBQUEsd0JBQ3pCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLHFDQUFxQ3ZGLFVBQVU2USxNQUFNO0FBQUEsc0JBQ2hFLGFBQVk7QUFBQSxzQkFDWix1QkFBdUI7QUFBQSxzQkFDdkI7QUFBQSxzQkFDQSxNQUFLO0FBQUEsc0JBQ0wsY0FBYyxDQUFDQyxPQUFPaEYsV0FBVztBQUMvQiw0QkFBSSxDQUFDQSxVQUFVLENBQUNBLE9BQU9pRixTQUFVLFFBQU87QUFFeEMsK0JBQU9qRixPQUFPaUYsU0FDWEUsU0FBUyxFQUNUN0IsWUFBWSxFQUNaM0QsU0FBU3FGLE1BQU0xQixZQUFZLENBQUM7QUFBQSxzQkFDakM7QUFBQSxzQkFDQSxPQUFPckosZ0JBQWdCUCxxQkFBcUJxSTtBQUFBQSxzQkFDNUMsVUFBVSxDQUFDOUYsVUFDVHlCLHNCQUFzQixxQkFBcUJ6QixLQUFLO0FBQUEsc0JBR2pEdkcsb0JBQVVvSTtBQUFBQSx3QkFBSSxDQUFDVCxhQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUFpQyxPQUFPQSxTQUFTWSxLQUMvQ1o7QUFBQUEsbUNBQVNjO0FBQUFBLDBCQUFLO0FBQUEsMEJBQUlkLFNBQVNyRTtBQUFBQSw2QkFEVnFFLFNBQVNZLEtBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFDRDtBQUFBO0FBQUEsb0JBdkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkF3QkE7QUFBQSxxQkFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQ0E7QUFBQSxnQkFFRix1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFNO0FBQUE7QUFBQSxvQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyxHQUFHLENBQUNoRSxnQkFBZ0JTLGVBQzdCVCxnQkFBZ0JTLFlBQVlvRyxLQUFLLE1BQU0sS0FDckMsNkJBQ0EsNEJBQTRCO0FBQUEsc0JBRWhDLGFBQVk7QUFBQSxzQkFDWix1QkFBdUI7QUFBQSxzQkFDdkI7QUFBQSxzQkFDQSxNQUFLO0FBQUEsc0JBQ0wsY0FBYyxDQUFDa0UsT0FBT2hGLFdBQ3BCQSxPQUFPaUYsU0FDSkUsU0FBUyxFQUNUN0IsWUFBWSxFQUNaM0QsU0FBU3FGLE1BQU0xQixZQUFZLENBQUM7QUFBQSxzQkFFakMsT0FBT3JKLGdCQUFnQlQsbUJBQW1CdUk7QUFBQUEsc0JBQzFDLFVBQVUsQ0FBQzlGLFVBQ1R5QixzQkFBc0IsbUJBQW1CekIsS0FBSztBQUFBLHNCQUdoRDtBQUFBLCtDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxnREFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNDakYsTUFBTThHO0FBQUFBLDBCQUFJLENBQUNzSCxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLbkgsS0FDdkNtSCxlQUFLekcsY0FEWXlHLEtBQUtuSCxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBO0FBQUEsb0JBNUJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkE2QkE7QUFBQSxxQkFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzQ0EsS0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF3Q0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQStCO0FBQUE7QUFBQSxvQkFGekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWix1QkFBdUI7QUFBQSxzQkFDdkIsTUFBSztBQUFBLHNCQUNMO0FBQUEsc0JBQ0EsY0FBYyxDQUFDK0csT0FBT2hGLFdBQ3BCQSxPQUFPaUYsU0FDSkUsU0FBUyxFQUNUN0IsWUFBWSxFQUNaM0QsU0FBU3FGLE1BQU0xQixZQUFZLENBQUM7QUFBQSxzQkFFakMsT0FDRXJKLGdCQUFnQkQsaUNBQWlDK0g7QUFBQUEsc0JBRW5ELFVBQVUsQ0FBQzlGLE9BQU8rRCxXQUNoQnRDO0FBQUFBLHdCQUNFO0FBQUEsd0JBQ0F6QjtBQUFBQSx3QkFDQStELE9BQU9pRjtBQUFBQSxzQkFDVDtBQUFBLHNCQUdEdlAsb0JBQVVvSTtBQUFBQSx3QkFBSSxDQUFDVCxhQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUFpQyxPQUFPQSxTQUFTWSxLQUMvQ1o7QUFBQUEsbUNBQVNjO0FBQUFBLDBCQUFLO0FBQUEsMEJBQUlkLFNBQVNyRTtBQUFBQSw2QkFEVnFFLFNBQVNZLEtBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFDRDtBQUFBO0FBQUEsb0JBM0JIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkE0QkE7QUFBQSxxQkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQ0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLHNCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQ0VoRSxnQkFBZ0JLLGNBQ1osSUFBSXNMLEtBQUszTCxnQkFBZ0JLLGVBQWUsRUFBRSxFQUN6Q3VMLFlBQVksRUFDWnhILE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDYjtBQUFBLHdCQUVOLFdBQVcsR0FBRyxDQUFDcEUsZ0JBQWdCSyxlQUM3QkwsZ0JBQWdCSyxZQUFZd0csS0FBSyxNQUFNLEtBQ3JDLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUEsd0JBRXRCLFVBQVV2QjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBO0FBQUEsc0JBbEJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFrQnVDO0FBQUEsdUJBekJ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTJCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBUTtBQUFBO0FBQUEsc0JBRmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVcsR0FBRyxDQUFDdkosZ0JBQWdCRyxVQUM3QkgsZ0JBQWdCRyxPQUFPMEcsS0FBSyxNQUFNLEtBQ2hDLDZCQUNBLDRCQUE0QjtBQUFBLHdCQUVoQyxhQUFZO0FBQUEsd0JBQ1osdUJBQXVCO0FBQUEsd0JBQ3ZCO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQ2tFLE9BQU9oRixXQUNwQkEsT0FBT2lGLFNBQ0ozQixZQUFZLEVBQ1ozRCxTQUFTcUYsTUFBTTFCLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPckosZ0JBQWdCRyxVQUFVMkg7QUFBQUEsd0JBQ2pDLFVBQVUsQ0FBQzlGLFVBQ1R5QixzQkFBc0IsVUFBVXpCLEtBQUs7QUFBQSx3QkFHdEMsV0FBQyxRQUFRLFFBQVEsRUFBRTZCO0FBQUFBLDBCQUFJLENBQUNnSSxVQUN2Qix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLHdCQUNEO0FBQUE7QUFBQSxzQkF4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXlCQTtBQUFBLHVCQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtDQTtBQUFBLHFCQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBZ0I7QUFBQTtBQUFBLHNCQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLEdBQUcsQ0FBQzdMLGdCQUFnQkksa0JBQzdCSixnQkFBZ0JJLGVBQWV5RyxLQUFLLE1BQU0sS0FDeEMsNkJBQ0EsNEJBQTRCO0FBQUEsd0JBRWhDLGFBQVk7QUFBQSx3QkFDWix1QkFBdUI7QUFBQSx3QkFDdkI7QUFBQSx3QkFDQSxNQUFLO0FBQUEsd0JBQ0wsY0FBYyxDQUFDa0UsT0FBT2hGLFdBQ3BCQSxPQUFPaUYsU0FDSjNCLFlBQVksRUFDWjNELFNBQVNxRixNQUFNMUIsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQU9ySixnQkFBZ0JJLGtCQUFrQjBIO0FBQUFBLHdCQUN6QyxVQUFVLENBQUM5RixVQUNUeUIsc0JBQXNCLGtCQUFrQnpCLEtBQUs7QUFBQSx3QkFHOUMsV0FBQyxXQUFXLGFBQWEsU0FBUyxVQUFVLEVBQUU2QjtBQUFBQSwwQkFDN0MsQ0FBQ2lJLFlBQ0MsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLFNBQ2pDQSxxQkFEaUJBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSx3QkFFSjtBQUFBO0FBQUEsc0JBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkEyQkE7QUFBQSx1QkFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFvQ0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQWU7QUFBQTtBQUFBLHNCQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU85TCxnQkFBZ0JhO0FBQUFBLHdCQUN2QixVQUFVMEk7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWixXQUFXLEdBQUcsQ0FBQ3ZKLGdCQUFnQmEsaUJBQzdCYixnQkFBZ0JhLGNBQWNnRyxLQUFLLE1BQU0sS0FDdkMsNkJBQ0EsNEJBQTRCLElBQzFCNU0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLHNCQVh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBWStGO0FBQUEsdUJBbkJqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFCQTtBQUFBLHFCQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTZEQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBYTtBQUFBO0FBQUEsc0JBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVcsR0FBRyxDQUFDOUssZ0JBQWdCTSxlQUM3Qk4sZ0JBQWdCTSxZQUFZdUcsS0FBSyxNQUFNLEtBQ3JDLDZCQUNBLDRCQUE0QjtBQUFBLHdCQUVoQyxhQUFZO0FBQUEsd0JBQ1osdUJBQXVCO0FBQUEsd0JBQ3ZCO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQ2tFLE9BQU9oRixXQUNwQkEsT0FBT2lGLFNBQ0ozQixZQUFZLEVBQ1ozRCxTQUFTcUYsTUFBTTFCLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPckosZ0JBQWdCTSxlQUFld0g7QUFBQUEsd0JBQ3RDLFVBQVUsQ0FBQzlGLFVBQ1R5QixzQkFBc0IsZUFBZXpCLEtBQUs7QUFBQSx3QkFHM0MsV0FBQyxVQUFVLE9BQU8sRUFBRTZCO0FBQUFBLDBCQUFJLENBQUNrSSxXQUN4Qix1QkFBQyxPQUFPLFFBQVAsRUFBMkIsT0FBT0EsUUFDaENBLG9CQURpQkEsUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLHdCQUNEO0FBQUE7QUFBQSxzQkF4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXlCQTtBQUFBLHVCQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtDQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBa0I7QUFBQTtBQUFBLHNCQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU8vTCxnQkFBZ0JZO0FBQUFBLHdCQUN2QixVQUFVMkk7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWixXQUFXLEdBQUcsQ0FBQ3ZKLGdCQUFnQlksb0JBQzdCWixnQkFBZ0JZLGlCQUFpQmlHLEtBQUssTUFBTSxLQUMxQyw2QkFDQSw0QkFBNEIsSUFDMUI1TSxVQUFVNlEsTUFBTTtBQUFBO0FBQUEsc0JBWHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFZK0Y7QUFBQSx1QkFuQmpHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBcUJBO0FBQUEscUJBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMkRBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFTO0FBQUE7QUFBQSxzQkFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPOUssZ0JBQWdCTztBQUFBQSx3QkFDdkIsVUFBVWdKO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1osV0FBVyxHQUFHLENBQUN2SixnQkFBZ0JPLFdBQzdCUCxnQkFBZ0JPLFFBQVFzRyxLQUFLLE1BQU0sS0FDakMsNkJBQ0EsNEJBQTRCLElBQzFCNU0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLHNCQVh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBWStGO0FBQUEsdUJBbkJqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBTztBQUFBO0FBQUEsc0JBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBTzlLLGdCQUFnQlE7QUFBQUEsd0JBQ3ZCLFVBQVUrSTtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaLFdBQVcsR0FBRyxDQUFDdkosZ0JBQWdCUSxTQUM3QlIsZ0JBQWdCUSxNQUFNcUcsS0FBSyxNQUFNLEtBQy9CLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUE7QUFBQSxzQkFYeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVkrRjtBQUFBLHVCQW5Cakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFxQkE7QUFBQSxxQkE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4Q0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU87QUFBQTtBQUFBLHNCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLEdBQUcsQ0FBQzlLLGdCQUFnQlEsU0FDN0JSLGdCQUFnQlEsTUFBTXFHLEtBQUssTUFBTSxLQUMvQiw2QkFDQSw0QkFBNEI7QUFBQSx3QkFFaEMsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQ2tFLE9BQU9oRixXQUNwQkEsT0FBT2lGLFNBQ0ozQixZQUFZLEVBQ1ozRCxTQUFTcUYsTUFBTTFCLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPckosZ0JBQWdCVyxTQUFTbUg7QUFBQUEsd0JBQ2hDLFVBQVUsQ0FBQzlGLFVBQ1R5QixzQkFBc0IsU0FBU3pCLEtBQUs7QUFBQSx3QkFHckMsV0FBQyxhQUFhLGVBQWUsWUFBWSxFQUFFNkI7QUFBQUEsMEJBQzFDLENBQUNsRCxVQUNDLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBRUo7QUFBQTtBQUFBLHNCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBMEJBO0FBQUEsdUJBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbUNBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFVO0FBQUE7QUFBQSxzQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBRUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPWCxnQkFBZ0JVO0FBQUFBLHdCQUN2QixVQUFVNkk7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVcsR0FBRyxDQUFDdkosZ0JBQWdCVSxZQUM3QlYsZ0JBQWdCVSxTQUFTbUcsS0FBSyxNQUFNLEtBQ2xDLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUE7QUFBQSxzQkFWeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVcrRjtBQUFBLHVCQW5Cakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFzQkE7QUFBQSxxQkE1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE2REE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQVM7QUFBQTtBQUFBLHNCQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU85SyxnQkFBZ0JjO0FBQUFBLHdCQUN2QixVQUFVeUk7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWixXQUFXLEdBQUcsQ0FBQ3ZKLGdCQUFnQmMsZ0JBQzdCZCxnQkFBZ0JjLGFBQWErRixLQUFLLE1BQU0sS0FDdEMsNkJBQ0EsNEJBQTRCLElBQzFCNU0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLHNCQVh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBWStGO0FBQUEsdUJBbkJqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBYztBQUFBO0FBQUEsc0JBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FDRTlLLGdCQUFnQmUsc0JBQ1osSUFBSTRLLEtBQUszTCxnQkFBZ0JlLG1CQUFtQixFQUMzQzZLLFlBQVksRUFDWnhILE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDYjtBQUFBLHdCQUVOLFVBQVVtRjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaLFdBQVcsR0FBRyxDQUFDdkosZ0JBQWdCZSx1QkFDN0JmLGdCQUFnQmUsb0JBQW9COEYsS0FBSyxNQUFNLEtBQzdDLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUE7QUFBQSxzQkFqQnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFrQitGO0FBQUEsdUJBekJqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTJCQTtBQUFBLHFCQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW9EQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBc0I7QUFBQTtBQUFBLHNCQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLEdBQUcsQ0FBQzlLLGdCQUFnQmlCLHdCQUM3QmpCLGdCQUFnQmlCLHFCQUFxQjRGLEtBQUssTUFBTSxLQUM5Qyw2QkFDQSw0QkFBNEI7QUFBQSx3QkFFaEMsYUFBWTtBQUFBLHdCQUNaLHVCQUF1QjtBQUFBLHdCQUN2QjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUNrRSxPQUFPaEYsV0FDcEJBLE9BQU9pRixTQUNKM0IsWUFBWSxFQUNaM0QsU0FBU3FGLE1BQU0xQixZQUFZLENBQUM7QUFBQSx3QkFFakMsT0FBT3JKLGdCQUFnQmlCLHdCQUF3QjZHO0FBQUFBLHdCQUMvQyxVQUFVLENBQUM5RixVQUNUeUIsc0JBQXNCLHdCQUF3QnpCLEtBQUs7QUFBQSx3QkFHcEQ7QUFBQSwwQkFDQztBQUFBLDBCQUNBO0FBQUEsMEJBQ0E7QUFBQSwwQkFDQTtBQUFBLDBCQUNBO0FBQUEsMEJBQ0E7QUFBQSx3QkFBTyxFQUNQNkI7QUFBQUEsMEJBQUksQ0FBQ21JLFlBQ0wsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLFNBQ2pDQSxxQkFEaUJBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSx3QkFDRDtBQUFBO0FBQUEsc0JBL0JIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFnQ0E7QUFBQSx1QkF4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF5Q0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQXNCO0FBQUE7QUFBQSxzQkFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPaE0sZ0JBQWdCZ0I7QUFBQUEsd0JBQ3ZCLFVBQVV1STtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaLFdBQVcsR0FBRyxDQUFDdkosZ0JBQWdCZ0Isd0JBQzdCaEIsZ0JBQWdCZ0IscUJBQXFCNkYsS0FBSyxNQUFNLEtBQzlDLDZCQUNBLDRCQUE0QixJQUMxQjVNLFVBQVU2USxNQUFNO0FBQUE7QUFBQSxzQkFYeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVkrRjtBQUFBLHVCQW5Cakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFxQkE7QUFBQSxxQkFqRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQVc7QUFBQTtBQUFBLHNCQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU85SyxnQkFBZ0J1QjtBQUFBQSx3QkFDdkIsVUFBVWdJO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1osV0FBVyxHQUFHLENBQUN2SixnQkFBZ0J1QixhQUM3QnZCLGdCQUFnQnVCLFVBQVVzRixLQUFLLE1BQU0sS0FDbkMsNkJBQ0EsNEJBQTRCLElBQzFCNU0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLHNCQVh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBWStGO0FBQUEsdUJBbkJqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBa0I7QUFBQTtBQUFBLHNCQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU85SyxnQkFBZ0J3QjtBQUFBQSx3QkFDdkIsVUFBVStIO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1osV0FBVyxHQUFHLENBQUN2SixnQkFBZ0J3QixvQkFDN0J4QixnQkFBZ0J3QixpQkFBaUJxRixLQUFLLE1BQU0sS0FDMUMsNkJBQ0EsNEJBQTRCLElBQzFCNU0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLHNCQVh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBWStGO0FBQUEsdUJBbkJqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFCQTtBQUFBLHFCQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQThDQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBZ0I7QUFBQTtBQUFBLHNCQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU85SyxnQkFBZ0J5QjtBQUFBQSx3QkFDdkIsVUFBVThIO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1osV0FBVyxHQUFHLENBQUN2SixnQkFBZ0J5Qix1QkFDN0J6QixnQkFBZ0J5QixvQkFBb0JvRixLQUFLLE1BQU0sS0FDN0MsNkJBQ0EsNEJBQTRCLElBQzFCNU0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLHNCQVh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBWStGO0FBQUEsdUJBbkJqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBTTtBQUFBO0FBQUEsc0JBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBTzlLLGdCQUFnQjBCO0FBQUFBLHdCQUN2QixVQUFVNkg7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWixXQUFXLEdBQUcsQ0FBQ3ZKLGdCQUFnQjBCLGtCQUM3QjFCLGdCQUFnQjBCLGVBQWVtRixLQUFLLE1BQU0sS0FDeEMsNkJBQ0EsNEJBQTRCLElBQzFCNU0sVUFBVTZRLE1BQU07QUFBQTtBQUFBLHNCQVh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBWStGO0FBQUEsdUJBbkJqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFCQTtBQUFBLHFCQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQThDQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHlDQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQyxNQUFNO0FBQUEsc0JBQU47QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsT0FBTzlLLGdCQUFnQkg7QUFBQUEsd0JBQ3ZCLFVBQVUsQ0FBQ2tDLE1BQ1QwQixzQkFBc0Isb0JBQW9CMUIsRUFBRUUsT0FBT0QsS0FBSztBQUFBLHdCQUcxRDtBQUFBLGlEQUFDLFNBQU0sT0FBTSxTQUFRLHFCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUEwQjtBQUFBLDBCQUMxQix1QkFBQyxTQUFNLE9BQU0sVUFBUyxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBNEI7QUFBQSwwQkFDNUIsdUJBQUMsU0FBTSxPQUFNLFdBQVUsdUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQThCO0FBQUE7QUFBQTtBQUFBLHNCQVRoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBVUE7QUFBQSx1QkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWVBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQW9CO0FBQUE7QUFBQSxzQkFGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPaEMsZ0JBQWdCRjtBQUFBQSx3QkFDdkIsVUFBVXlKO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1osV0FBVyxHQUFHLENBQUN2SixnQkFBZ0JGLHFCQUMzQiw2QkFDQSw0QkFBNEIsSUFDMUI3RixVQUFVNlEsTUFBTTtBQUFBO0FBQUEsc0JBVnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXK0Y7QUFBQSx1QkFsQmpHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBb0JBO0FBQUEscUJBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUNBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLDBCQUViO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBTztBQUFBO0FBQUEsb0JBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUdBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUFJLFdBQVU7QUFBQSxzQkFDYixTQUFTLE1BQU1wTSxjQUFjdU4sU0FBU0MsTUFBTTtBQUFBLHNCQUM1QztBQUFBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLEtBQUt4TjtBQUFBQSw0QkFDTCxJQUFHO0FBQUEsNEJBQ0gsTUFBSztBQUFBLDRCQUNMLFFBQU87QUFBQSw0QkFDUCxXQUFVO0FBQUEsNEJBQ1YsVUFBVSxDQUFDcUQsTUFBTTtBQUNmLG9DQUFNNEgsT0FBTzVILEVBQUVFLE9BQU9oRixNQUFNLENBQUM7QUFDN0Isa0NBQUksQ0FBQzBNLEtBQU07QUFDWCxrQ0FDRSxDQUFDQSxLQUFLOUwsS0FBS3lOLFdBQVcsWUFBWSxLQUNsQyxDQUFDM0IsS0FBSzlMLEtBQUt5TixXQUFXLFdBQVcsR0FDakM7QUFDQUMsc0NBQU0sK0JBQStCO0FBQ3JDO0FBQUEsOEJBQ0Y7QUFDQS9OLDZDQUFlLENBQUNtTSxJQUFJLENBQUM7QUFBQSw0QkFDdkI7QUFBQTtBQUFBLDBCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBaUJJO0FBQUEsd0JBSUhwTSxZQUFZeUosV0FBVyxLQUN0QixDQUFDaEgsZ0JBQWdCc0IsZUFDakIsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsaURBQUMsZUFBWSxNQUFNLElBQUksV0FBVSx3QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBcUQ7QUFBQSwwQkFDckQsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQyw0QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsbUNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsS0FDRS9ELGFBQWF5SixTQUFTLElBQ2xCd0UsSUFBSUMsZ0JBQWdCbE8sWUFBWSxDQUFDLENBQUMsSUFDbEN5QyxnQkFBZ0JzQjtBQUFBQSw4QkFFdEIsS0FBSTtBQUFBLDhCQUNKLFdBQVU7QUFBQSw4QkFDVixTQUFTLE1BQU1uRCxlQUFlLElBQUk7QUFBQTtBQUFBLDRCQVJwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBUXNDO0FBQUEsMEJBSXRDLHVCQUFDLFNBQUksV0FBVSx5Q0FDWFosd0JBQWF5SixTQUFTLEtBQ3RCaEgsZ0JBQWdCc0IsaUJBQ2Q7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsTUFDRS9ELGFBQWF5SixTQUFTLElBQ2xCd0UsSUFBSUMsZ0JBQWdCbE8sWUFBWSxDQUFDLENBQUMsSUFDbEN5QyxnQkFBZ0JzQjtBQUFBQSw4QkFFdEIsVUFDRS9ELGFBQWF5SixTQUFTLElBQ2xCekosWUFBWSxDQUFDLEVBQUUyRyxPQUNmNEQ7QUFBQUEsOEJBRU4sV0FBVTtBQUFBLDhCQUVWLGlDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUFtQjtBQUFBO0FBQUEsNEJBYnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFjQSxLQWpCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQW1CQTtBQUFBLDZCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQWlDQTtBQUFBO0FBQUE7QUFBQSxvQkFwRUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXNFQTtBQUFBLGtCQUdDNUosZUFDQztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUyxNQUFNQyxlQUFlLEtBQUs7QUFBQSxzQkFFbkM7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLFNBQVMsQ0FBQzRELE1BQU1BLEVBQUVvSyxnQkFBZ0I7QUFBQSwwQkFHbEM7QUFBQTtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxTQUFTLE1BQU1oTyxlQUFlLEtBQUs7QUFBQSxnQ0FDbkMsV0FBVTtBQUFBLGdDQUVWLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQVk7QUFBQTtBQUFBLDhCQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFLQTtBQUFBLDRCQUdBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLEtBQ0VaLGFBQWF5SixTQUFTLElBQ2xCd0UsSUFBSUMsZ0JBQWdCbE8sWUFBWSxDQUFDLENBQUMsSUFDbEN5QyxnQkFBZ0JzQjtBQUFBQSxnQ0FFdEIsS0FBSTtBQUFBLGdDQUNKLFdBQVU7QUFBQTtBQUFBLDhCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFPNEQ7QUFBQTtBQUFBO0FBQUEsd0JBcEI5RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBc0JBO0FBQUE7QUFBQSxvQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQTJCQTtBQUFBLHFCQS9HSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlIQTtBQUFBLGdCQUFPO0FBQUEsZ0JBQ1AsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQzJGO0FBQUE7QUFBQSxrQkFIdkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLG1CQXZvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3b0NBO0FBQUE7QUFBQTtBQUFBLFVBeHBDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUEwcENBO0FBQUE7QUFBQSxNQTlwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBK3BDQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdyRjtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkkseUJBQWUsSUFBSTtBQUFBLFFBQ3JCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0QsZUFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsVUFBVSxDQUFDMEYsTUFBTTtBQUNmQSxrQkFBRW9HLGVBQWU7QUFDakJxQixpQ0FBaUI7QUFBQSxjQUNuQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVztBQUFBO0FBQUEsd0JBRU47QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2JuTixzQkFBWXdDLGFBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUFRO0FBQUEsd0JBQUk7QUFBQSx3QkFDUztBQUFBLHdCQUNyQix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpQztBQUFBO0FBQUE7QUFBQSxvQkFUbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxhQUFZO0FBQUEsc0JBQ1o7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS3VJO0FBQUEscUJBakJ6STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ3lGO0FBQUE7QUFBQSxrQkFIckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUE7QUFBQTtBQUFBLFlBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtDQTtBQUFBLGFBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0E7QUFBQTtBQUFBLE1BaERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlEQTtBQUFBLE9BdDVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdTVEQSxLQXg1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXk1REE7QUFFSjtBQUFFM0QsR0FsMkZJSCxNQUFJO0FBQUEsVUEyR1NMLFdBQVc7QUFBQTtBQUFBMFIsS0EzR3hCclI7QUFvMkZOLGVBQWVBO0FBQUssSUFBQXFSO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIklucHV0IiwiU2VsZWN0IiwiRHJvcGRvd24iLCJSYWRpbyIsIkNoZWNrYm94IiwiSW9NZE1vcmUiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJDaXJjdWxhckxvYWRlciIsImhhbmRsZUVucm9sbG1lbnRSZXF1ZXN0UHJpbnQiLCJDdXN0b21BbGVydERpYWxvZyIsImZpZWxkU2l6ZSIsIkNsb3VkVXBsb2FkIiwiWCIsIkRvd25sb2FkIiwiQ2hlY2siLCJQYWdlV3JhcHBlciIsImRheWpzIiwiUmVDb25maXJtTW9kYWwiLCJBbnRNb2RhbCIsInVzZUxvY2F0aW9uIiwiY29uZmlybSIsIlNURVBTIiwiaWQiLCJsYWJlbCIsIlVzZXIiLCJzaG93VXNlck1vZGFsIiwic2V0U2hvd1VzZXJNb2RhbCIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsImN1c3RvbWVycyIsInNldEN1c3RvbWVycyIsImFnZW50cyIsInNldEFnZW50cyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsIlRhYmxlVXNlcnMiLCJzZXRUYWJsZVVzZXJzIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJjdXJyZW50VXNlciIsInNldEN1cnJlbnRVc2VyIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiY3VycmVudFVwZGF0ZVVzZXIiLCJzZXRDdXJyZW50VXBkYXRlVXNlciIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiYXJlYXMiLCJzZXRBcmVhcyIsImZpbGVzIiwic2V0RmlsZXMiLCJkaXN0cmljdHMiLCJzZXREaXN0cmljdHMiLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsImF0dGFjaG1lbnRzIiwic2V0QXR0YWNobWVudHMiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwic2hvd0NvbmZpcm0iLCJzZXRTaG93Q29uZmlybSIsInNob3dQcmV2aWV3Iiwic2V0U2hvd1ByZXZpZXciLCJjdXJyZW50U3RlcCIsInNldEN1cnJlbnRTdGVwIiwic2FtZUFzQWRkcmVzcyIsInNldFNhbWVBc0FkZHJlc3MiLCJjb25maXJtRGF0YSIsInNldENvbmZpcm1EYXRhIiwicGhvdG9JbnB1dFJlZiIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJmdWxsX25hbWUiLCJlbWFpbCIsInBob25lX251bWJlciIsInBhc3N3b3JkIiwiYWRkcmVzcyIsInBlcm1hbmVudF9hZGRyZXNzIiwicGluY29kZSIsImFkaGFhcl9ubyIsInBhbl9ubyIsInRyYWNrX3NvdXJjZSIsImNvbGxlY3Rpb25fYXJlYSIsInJlZmVycmFsX3R5cGUiLCJyZWZlcnJlZF9lbXBsb3llZSIsInJlZmVycmVkX2FnZW50IiwicmVmZXJyZWRfY3VzdG9tZXIiLCJmYW1pbHlfY29kZSIsImluc3RhbGxtZW50X3R5cGUiLCJpbnN0YWxsbWVudF9hbW91bnQiLCJjdXN0b21lcl9yZWxhdGlvbnNoaXBfbWFuYWdlciIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJ0aXRsZSIsImdlbmRlciIsIm1hcml0YWxfc3RhdHVzIiwiZGF0ZW9mYmlydGgiLCJuYXRpb25hbGl0eSIsInZpbGxhZ2UiLCJ0YWx1ayIsImZhdGhlcl9uYW1lIiwiZGlzdHJpY3QiLCJzdGF0ZSIsImFsdGVybmF0ZV9udW1iZXIiLCJyZWZlcnJhbF9uYW1lIiwibm9taW5lZV9uYW1lIiwibm9taW5lZV9kYXRlb2ZiaXJ0aCIsIm5vbWluZWVfcGhvbmVfbnVtYmVyIiwibm9taW5lZV9yZWxhdGlvbnNoaXAiLCJhYWRoYXJfZnJvbnRwaG90byIsImFhZGhhcl9iYWNrcGhvdG8iLCJwYW5fZnJvbnRwaG90byIsInBhbl9iYWNrcGhvdG8iLCJwcm9maWxlcGhvdG8iLCJiYW5rX25hbWUiLCJiYW5rX2JyYW5jaF9uYW1lIiwiYmFua19hY2NvdW50X251bWJlciIsImJhbmtfSUZTQ19jb2RlIiwic2VsZWN0ZWRfcGxhbiIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImxvY2F0aW9uIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwic2VhcmNoIiwiZ2V0Iiwid2luZG93IiwiaGlzdG9yeSIsInJlcGxhY2VTdGF0ZSIsImRvY3VtZW50IiwiZmV0Y2hVc2VycyIsInJlc3BvbnNlIiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImZldGNoQWdlbnRzIiwiYWdlbnQiLCJlcnIiLCJmZXRjaEVtcGxveWVlcyIsImVtcGxveWVlIiwiZmV0Y2hDb2xsZWN0aW9uQXJlYSIsInByZXYiLCJoYW5kbGVTYW1lQWRkcmVzc1RvZ2dsZSIsImNoZWNrZWQiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3QiLCJmaWVsZCIsInByZXZEYXRhIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJfaWQiLCJjdXN0b21lcl9jb2RlIiwibmFtZSIsImNyZWF0ZWRBdCIsInNwbGl0IiwicmV2ZXJzZSIsImpvaW4iLCJjdXN0b21lcl9pZCIsInJlZmVycmVkQnkiLCJ0cmFja1NvdXJjZSIsInJvdXRlX25hbWUiLCJwcm9ncmVzc1ZhbHVlIiwicGVyY2VudGFnZSIsImRvYiIsImZvcm1hdCIsInByb2dyZXNzIiwiYmFja2dyb3VuZCIsImFwcHJvdmFsX3N0YXR1cyIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiaGFuZGxlQ3VzdG9tZXJTdGF0dXNXaXRoQ29uZmlybSIsImZEYXRhIiwiZWxlIiwiaW5jbHVkZXMiLCJyZXBsYWNlQWxsIiwiZmV0Y2hHcm91cERhdGEiLCJyZXMiLCJoYW5kbGVBbnREU2VsZWN0Iiwib3B0aW9uIiwiY29sbGVjdGlvbl9hcmVhX3NlbGVjdCIsInByZXZFcnJvcnMiLCJoYW5kbGVDaGFuZ2UiLCJoYW5kbGVBbnREU2VsZWN0R3JvdXAiLCJncm91cElkIiwidmFsaWRhdGVGb3JtIiwic3RlcCIsIm5ld0Vycm9ycyIsInJlZ2V4IiwicGhvbmUiLCJhZGhhYXIiLCJwYW4iLCJ2YWxpZGF0ZUJhc2ljRGV0YWlscyIsInRyaW0iLCJ0ZXN0IiwidG9VcHBlckNhc2UiLCJsZW5ndGgiLCJ2YWxpZGF0ZVBheW1lbnREZXRhaWxzIiwiaXNOYU4iLCJOdW1iZXIiLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlT3BlbkNvbmZpcm0iLCJzZWxlY3RlZEVtcGxveWVlIiwiZmluZCIsInNlbGVjdGVkQWdlbnQiLCJzZWxlY3RlZEN1c3RvbWVyIiwiY3VzdG9tZXIiLCJzZWxlY3RlZENSTSIsInJlZmVycmVkX2VtcGxveWVlX3NlbGVjdCIsInVuZGVmaW5lZCIsInJlZmVycmVkX2FnZW50X3NlbGVjdCIsInJlZmVycmVkX2N1c3RvbWVyX3NlbGVjdCIsImN1c3RvbWVyX3JlbGF0aW9uc2hpcF9tYW5hZ2VyX3NlbGVjdCIsImhhbmRsZVJlY29uZmlybWF0aW9uIiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwiaGFuZGxlU2F2ZUFuZENvbnRpbnVlIiwiaGFuZGxlU2F2ZUFuZEV4aXQiLCJoYW5kbGVTdWJtaXQiLCJwYXlsb2FkIiwiRm9ybURhdGEiLCJlbnRyaWVzIiwiZm9yRWFjaCIsImFwcGVuZCIsInBvc3QiLCJzdGF0dXMiLCJjb2x1bW5zIiwiaGVhZGVyIiwicHJpbnR0YWJsZUNvbHVtbnMiLCJmaWx0ZXJlZFVzZXJzIiwiZmlsdGVyIiwidXNlciIsInRvTG93ZXJDYXNlIiwidXNlcklkIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJoYW5kbGVEZWxldGVVc2VyIiwiZGVsZXRlIiwiaGFuZGxlRmlsZUNoYW5nZSIsImZpbGUiLCJwcmV2U3RhdGUiLCJoYW5kbGVDdXN0b21lclN0YXR1cyIsIm5ld1N0YXR1cyIsIndhcm4iLCJwdXQiLCJpbmZvIiwiY3VycmVudFN0YXR1cyIsImlzQXBwcm92aW5nIiwiYWN0aW9uVGV4dCIsImNvbnRlbnQiLCJva1RleHQiLCJjYW5jZWxUZXh0Iiwib25PayIsImhhbmRsZVVwZGF0ZSIsImZtRGF0YSIsImhlYWRlcnMiLCJTdGVwU3RhdHVzQmFyIiwiaWR4IiwiaGVpZ2h0IiwiaW5wdXQiLCJjaGlsZHJlbiIsInJlZlR5cGUiLCJ0b1N0cmluZyIsImFyZWEiLCJjaGFyQXQiLCJzbGljZSIsInN0YXJ0c1dpdGgiLCJhbGVydCIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsImNUaXRsZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsImdUeXBlIiwibVN0YXR1cyIsIm5hdGlvbiIsIm5vbWluZWUiLCJjdXJyZW50IiwiY2xpY2siLCJzdG9wUHJvcGFnYXRpb24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc2VyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCB7IElucHV0LCBTZWxlY3QsIERyb3Bkb3duLCBSYWRpbywgQ2hlY2tib3ggfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBoYW5kbGVFbnJvbGxtZW50UmVxdWVzdFByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9lbnJvbGxtZW50UmVxdWVzdFByaW50XCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCB7IENsb3VkVXBsb2FkLCBYLCBEb3dubG9hZCwgQ2hlY2sgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCBQYWdlV3JhcHBlciBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvUGFnZVdyYXBwZXJcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5pbXBvcnQgUmVDb25maXJtTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL1JlQ29uZmlybU1vZGFsXCI7XHJcbmltcG9ydCB7IE1vZGFsIGFzIEFudE1vZGFsIH0gZnJvbSBcImFudGRcIjsgLy8gcmVuYW1lZFxyXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbi8vIGltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcblxyXG5jb25zdCB7IGNvbmZpcm0gfSA9IEFudE1vZGFsO1xyXG5cclxuLy8gU3RlcHMgdXNlZCBPTkxZIGJ5IHRoZSBBZGQgQ3VzdG9tZXIgd2l6YXJkXHJcbmNvbnN0IFNURVBTID0gW1xyXG4gIHsgaWQ6IDEsIGxhYmVsOiBcIkJhc2ljIERldGFpbHNcIiB9LFxyXG4gIHsgaWQ6IDIsIGxhYmVsOiBcIkFkZGl0aW9uYWwgJiBQYXltZW50XCIgfSxcclxuXTtcclxuXHJcbmNvbnN0IFVzZXIgPSAoeyBzaG93VXNlck1vZGFsLCBzZXRTaG93VXNlck1vZGFsIH0pID0+IHtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY3VzdG9tZXJzLCBzZXRDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVVc2Vycywgc2V0VGFibGVVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsRGVsZXRlLCBzZXRTaG93TW9kYWxEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxVcGRhdGUsIHNldFNob3dNb2RhbFVwZGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRVc2VyLCBzZXRDdXJyZW50VXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlVXNlciwgc2V0Q3VycmVudFVwZGF0ZVVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FyZWFzLCBzZXRBcmVhc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbGVzLCBzZXRGaWxlc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2Rpc3RyaWN0cywgc2V0RGlzdHJpY3RzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbYXR0YWNobWVudHMsIHNldEF0dGFjaG1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3Nob3dDb25maXJtLCBzZXRTaG93Q29uZmlybV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dQcmV2aWV3LCBzZXRTaG93UHJldmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIC0tLS0gTkVXOiB3aXphcmQgc3RlcCArIFwic2FtZSBhcyBjb21tdW5pY2F0aW9uIGFkZHJlc3NcIiBzdGF0ZSAoQWRkIG1vZGFsIG9ubHkpIC0tLS1cclxuICBjb25zdCBbY3VycmVudFN0ZXAsIHNldEN1cnJlbnRTdGVwXSA9IHVzZVN0YXRlKDEpO1xyXG4gIGNvbnN0IFtzYW1lQXNBZGRyZXNzLCBzZXRTYW1lQXNBZGRyZXNzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY29uZmlybURhdGEsIHNldENvbmZpcm1EYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBwaG90b0lucHV0UmVmID0gdXNlUmVmKG51bGwpO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGZ1bGxfbmFtZTogXCJcIixcclxuICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgcGhvbmVfbnVtYmVyOiBcIlwiLFxyXG4gICAgcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICBhZGRyZXNzOiBcIlwiLFxyXG4gICAgcGVybWFuZW50X2FkZHJlc3M6IFwiXCIsXHJcbiAgICBwaW5jb2RlOiBcIlwiLFxyXG4gICAgYWRoYWFyX25vOiBcIlwiLFxyXG4gICAgcGFuX25vOiBcIlwiLFxyXG4gICAgdHJhY2tfc291cmNlOiBcImFkbWluX3BhbmVsXCIsXHJcbiAgICBjb2xsZWN0aW9uX2FyZWE6IFwiXCIsXHJcbiAgICByZWZlcnJhbF90eXBlOiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfZW1wbG95ZWU6IFwiXCIsXHJcbiAgICByZWZlcnJlZF9hZ2VudDogXCJcIixcclxuICAgIHJlZmVycmVkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgZmFtaWx5X2NvZGU6IFwiXCIsXHJcbiAgICBpbnN0YWxsbWVudF90eXBlOiBcIkRhaWx5XCIsXHJcbiAgICBpbnN0YWxsbWVudF9hbW91bnQ6IFwiXCIsXHJcbiAgICBjdXN0b21lcl9yZWxhdGlvbnNoaXBfbWFuYWdlcjogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBmdWxsX25hbWU6IFwiXCIsXHJcbiAgICBlbWFpbDogXCJcIixcclxuICAgIHBob25lX251bWJlcjogXCJcIixcclxuICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgYWRkcmVzczogXCJcIixcclxuICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICBhZGhhYXJfbm86IFwiXCIsXHJcbiAgICBwYW5fbm86IFwiXCIsXHJcbiAgICB0aXRsZTogXCJcIixcclxuICAgIGdlbmRlcjogXCJcIixcclxuICAgIG1hcml0YWxfc3RhdHVzOiBcIlwiLFxyXG4gICAgZGF0ZW9mYmlydGg6IFwiXCIsXHJcbiAgICBuYXRpb25hbGl0eTogXCJcIixcclxuICAgIHZpbGxhZ2U6IFwiXCIsXHJcbiAgICB0YWx1azogXCJcIixcclxuICAgIGZhdGhlcl9uYW1lOiBcIlwiLFxyXG4gICAgZGlzdHJpY3Q6IFwiXCIsXHJcbiAgICBzdGF0ZTogXCJcIixcclxuICAgIGNvbGxlY3Rpb25fYXJlYTogXCJcIixcclxuICAgIGN1c3RvbWVyX3JlbGF0aW9uc2hpcF9tYW5hZ2VyOiBcIlwiLFxyXG4gICAgYWx0ZXJuYXRlX251bWJlcjogXCJcIixcclxuICAgIHJlZmVycmFsX25hbWU6IFwiXCIsXHJcbiAgICBub21pbmVlX25hbWU6IFwiXCIsXHJcbiAgICBub21pbmVlX2RhdGVvZmJpcnRoOiBcIlwiLFxyXG4gICAgbm9taW5lZV9waG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICBub21pbmVlX3JlbGF0aW9uc2hpcDogXCJcIixcclxuICAgIGFhZGhhcl9mcm9udHBob3RvOiBcIlwiLFxyXG4gICAgYWFkaGFyX2JhY2twaG90bzogXCJcIixcclxuICAgIHBhbl9mcm9udHBob3RvOiBcIlwiLFxyXG4gICAgcGFuX2JhY2twaG90bzogXCJcIixcclxuICAgIHByb2ZpbGVwaG90bzogXCJcIixcclxuICAgIGJhbmtfbmFtZTogXCJcIixcclxuICAgIGJhbmtfYnJhbmNoX25hbWU6IFwiXCIsXHJcbiAgICBiYW5rX2FjY291bnRfbnVtYmVyOiBcIlwiLFxyXG4gICAgYmFua19JRlNDX2NvZGU6IFwiXCIsXHJcbiAgICBzZWxlY3RlZF9wbGFuOiBcIlwiLFxyXG4gICAgcmVmZXJyYWxfdHlwZTogXCJcIixcclxuICAgIHJlZmVycmVkX2VtcGxveWVlOiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfYWdlbnQ6IFwiXCIsXHJcbiAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAgIGluc3RhbGxtZW50X3R5cGU6IFwiXCIsXHJcbiAgICBpbnN0YWxsbWVudF9hbW91bnQ6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IEdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKTtcclxuICAgIGlmIChwYXJhbXMuZ2V0KFwib3Blbk1vZGFsXCIpID09PSBcInRydWVcIikge1xyXG4gICAgICBzZXRTaG93VXNlck1vZGFsKHRydWUpO1xyXG4gICAgICAvLyBSZW1vdmUgdGhlIHF1ZXJ5IHBhcmFtZXRlciBmcm9tIHRoZSBVUkwgdG8gcHJldmVudCByZeKAkW9wZW5pbmcgb24gcmVmcmVzaFxyXG4gICAgICB3aW5kb3cuaGlzdG9yeS5yZXBsYWNlU3RhdGUoe30sIGRvY3VtZW50LnRpdGxlLCBcIi9jdXN0b21lci1tZW51L3VzZXJcIik7XHJcbiAgICB9XHJcbiAgfSwgW2xvY2F0aW9uXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgIHNldEN1c3RvbWVycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW10pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0XCIpO1xyXG4gICAgICAgIHNldEFnZW50cyhyZXNwb25zZS5kYXRhPy5hZ2VudCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggTGVhZHNcIiwgZXJyKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQWdlbnRzKCk7XHJcbiAgfSwgW10pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZW1wbG95ZWVcIik7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcImZhaWxlZCB0byBmZXRjaCBlbXBsb3llZXNcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaENvbGxlY3Rpb25BcmVhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIFwiL2NvbGxlY3Rpb24tYXJlYS1yZXF1ZXN0L2dldC1jb2xsZWN0aW9uLWFyZWEtZGF0YVwiLFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIHNldEFyZWFzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQ29sbGVjdGlvbkFyZWEoKTtcclxuICAgIHNldEF0dGFjaG1lbnRzKFtdKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gIC8vICAgY29uc3QgZmV0Y2hEaXN0cmljdHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgLy8gICAgIHRyeSB7XHJcbiAgLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZGlzdHJpY3RcIik7XHJcbiAgLy8gICAgICAgc2V0RGlzdHJpY3RzKHJlc3BvbnNlLmRhdGE/LmRhdGE/LmRpc3RyaWN0cyk7XHJcbiAgLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRpc3RyaWN0czpcIiwgZXJyb3IpO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9O1xyXG5cclxuICAvLyAgIGZldGNoRGlzdHJpY3RzKCk7XHJcbiAgLy8gfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgLy8gS2VlcCBwZXJtYW5lbnRfYWRkcmVzcyBpbiBzeW5jIHdpdGggYWRkcmVzcyB3aGlsZSBcInNhbWUgYXNcIiBpcyBjaGVja2VkXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzYW1lQXNBZGRyZXNzKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBwZXJtYW5lbnRfYWRkcmVzczogcHJldi5hZGRyZXNzIH0pKTtcclxuICAgIH1cclxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcclxuICB9LCBbc2FtZUFzQWRkcmVzcywgZm9ybURhdGEuYWRkcmVzc10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTYW1lQWRkcmVzc1RvZ2dsZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBjaGVja2VkID0gZS50YXJnZXQuY2hlY2tlZDtcclxuICAgIHNldFNhbWVBc0FkZHJlc3MoY2hlY2tlZCk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgcGVybWFuZW50X2FkZHJlc3M6IGNoZWNrZWQgPyBwcmV2LmFkZHJlc3MgOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBwZXJtYW5lbnRfYWRkcmVzczogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKHsgLi4uZXJyb3JzLCBbZmllbGRdOiBcIlwiIH0pO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtbmV3LXVzZXJcIik7XHJcblxyXG5cclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgIGN1c3RvbWVyX2NvZGU6IGdyb3VwPy5jdXN0b21lcl9jb2RlLFxyXG4gICAgICAgICAgbmFtZTogZ3JvdXAuZnVsbF9uYW1lLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cC5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6IGdyb3VwPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAuc3BsaXQoXCItXCIpXHJcbiAgICAgICAgICAgIC5yZXZlcnNlKClcclxuICAgICAgICAgICAgLmpvaW4oXCItXCIpLFxyXG4gICAgICAgICAgYWRkcmVzczogZ3JvdXAuYWRkcmVzcyxcclxuICAgICAgICAgIHBpbmNvZGU6IGdyb3VwLnBpbmNvZGUsXHJcbiAgICAgICAgICBjdXN0b21lcl9pZDogZ3JvdXAuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICByZWZlcnJhbF90eXBlOiBncm91cD8ucmVmZXJyYWxfdHlwZSxcclxuICAgICAgICAgIHJlZmVycmVkQnk6XHJcbiAgICAgICAgICAgIGdyb3VwPy5yZWZlcnJlZF9hZ2VudD8ubmFtZSAmJiBncm91cD8ucmVmZXJyZWRfYWdlbnQ/LnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgID8gYCR7Z3JvdXAucmVmZXJyZWRfYWdlbnQubmFtZX0gfCAke2dyb3VwLnJlZmVycmVkX2FnZW50LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgOiBncm91cD8ucmVmZXJyZWRfY3VzdG9tZXI/LmZ1bGxfbmFtZSAmJlxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LnJlZmVycmVkX2N1c3RvbWVyPy5waG9uZV9udW1iZXJcclxuICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAucmVmZXJyZWRfY3VzdG9tZXIuZnVsbF9uYW1lfSB8ICR7Z3JvdXA/LnJlZmVycmVkX2N1c3RvbWVyPy5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgICAgOiBncm91cD8ucmVmZXJyZWRfZW1wbG95ZWU/Lm5hbWUgJiYgZ3JvdXA/LnJlZmVycmVkX2VtcGxveWVlPy5waG9uZV9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgPyBgJHtncm91cC5yZWZlcnJlZF9lbXBsb3llZS5uYW1lfSB8ICR7Z3JvdXAucmVmZXJyZWRfZW1wbG95ZWUucGhvbmVfbnVtYmVyfWBcclxuICAgICAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgdHJhY2tTb3VyY2U6XHJcbiAgICAgICAgICAgIGdyb3VwPy50cmFja19zb3VyY2UgPT09IFwiY2hpdC1jdXN0b21lci1hcHBcIlxyXG4gICAgICAgICAgICAgID8gXCJDaGl0IEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICA6IGdyb3VwPy50cmFja19zb3VyY2UgPT09IFwiYWRtaW5fcGFuZWxcIlxyXG4gICAgICAgICAgICAgICAgPyBcIkNoaXQgQWRtaW5cIlxyXG4gICAgICAgICAgICAgICAgOiBcIlVua25vd25cIixcclxuICAgICAgICAgIC8vIHJlZmVycmFsX2NvZGU6IGdyb3VwPy5yZWZlcnJhbF9jb2RlLFxyXG4gICAgICAgICAgY29sbGVjdGlvbl9hcmVhOiBncm91cC5jb2xsZWN0aW9uX2FyZWE/LnJvdXRlX25hbWUsXHJcbiAgICAgICAgICBjdXN0b21lcl9yZWxhdGlvbnNoaXBfbWFuYWdlcjogZ3JvdXAuY3VzdG9tZXJfcmVsYXRpb25zaGlwX21hbmFnZXI/Lm5hbWUsXHJcbiAgICAgICAgICBwcm9ncmVzc1ZhbHVlOiBncm91cD8ucGVyY2VudGFnZSxcclxuICAgICAgICAgIGRvYjogZ3JvdXA/LmRhdGVvZmJpcnRoXHJcbiAgICAgICAgICAgID8gZGF5anMoZ3JvdXA/LmRhdGVvZmJpcnRoKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpXHJcbiAgICAgICAgICAgIDogXCJcIixcclxuICAgICAgICAgIHByb2dyZXNzOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEyIGgtMTIgcm91bmRlZC1mdWxsXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGBjb25pYy1ncmFkaWVudCgke2dyb3VwLnBlcmNlbnRhZ2UgPT09IDEwMCA/IFwiIzIyYzU1ZVwiIDogXCIjNGY0NmU1XCJcclxuICAgICAgICAgICAgICAgICAgICB9ICR7Z3JvdXAucGVyY2VudGFnZSAqIDMuNn1kZWcsICNlNWU3ZWIgJHtncm91cC5wZXJjZW50YWdlICogMy42XHJcbiAgICAgICAgICAgICAgICAgICAgfWRlZylgLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTAgaC0xMCBiZy13aGl0ZSByb3VuZGVkLWZ1bGwgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC14cyBmb250LXNlbWlib2xkICR7Z3JvdXAucGVyY2VudGFnZSA9PT0gMTAwXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtaW5kaWdvLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtncm91cD8ucGVyY2VudGFnZX0lXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgICBhcHByb3ZhbF9zdGF0dXM6XHJcbiAgICAgICAgICAgIGdyb3VwLmFwcHJvdmFsX3N0YXR1cyA9PT0gXCJ0cnVlXCJcclxuICAgICAgICAgICAgICA/IFwiQXBwcm92ZWRcIlxyXG4gICAgICAgICAgICAgIDogZ3JvdXAuYXBwcm92YWxfc3RhdHVzID09PSBcImZhbHNlXCJcclxuICAgICAgICAgICAgICAgID8gXCJQZW5kaW5nXCJcclxuICAgICAgICAgICAgICAgIDogXCJBcHByb3ZlZFwiLFxyXG4gICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGdyb3VwPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUVucm9sbG1lbnRSZXF1ZXN0UHJpbnQoZ3JvdXA/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIHRleHQtYmx1ZS02MDAgXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFByaW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCI0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY3Vyc29yLXBvaW50ZXIgJHtncm91cD8uYXBwcm92YWxfc3RhdHVzICE9PSBcInRydWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUN1c3RvbWVyU3RhdHVzV2l0aENvbmZpcm0oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5hcHByb3ZhbF9zdGF0dXMgIT09IFwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRydWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJmYWxzZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cD8uYXBwcm92YWxfc3RhdHVzICE9PSBcInRydWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkFwcHJvdmUgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlVuIEFwcHJvdmUgQ3VzdG9tZXJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBsZXQgZkRhdGEgPSBmb3JtYXR0ZWREYXRhLm1hcCgoZWxlKSA9PiB7XHJcbiAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIGVsZT8uYWRkcmVzcyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgZWxlLmFkZHJlc3MgPT09IFwic3RyaW5nXCIgJiZcclxuICAgICAgICAgICAgZWxlPy5hZGRyZXNzPy5pbmNsdWRlcyhcIixcIilcclxuICAgICAgICAgIClcclxuICAgICAgICAgICAgZWxlLmFkZHJlc3MgPSBlbGUuYWRkcmVzcy5yZXBsYWNlQWxsKFwiLFwiLCBcIiBcIik7XHJcbiAgICAgICAgICByZXR1cm4gZWxlO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmICghZkRhdGEpIHNldFRhYmxlVXNlcnMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgaWYgKCFmRGF0YSkgc2V0VGFibGVVc2Vycyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICBzZXRUYWJsZVVzZXJzKGZEYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvci5tZXNzYWdlKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hVc2VycygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICAgIHNldEdyb3VwcyhyZXMuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoR3JvdXBEYXRhKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuICBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSwgb3B0aW9uKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgICAgLi4uKGZpZWxkID09PSBcImNvbGxlY3Rpb25fYXJlYVwiXHJcbiAgICAgICAgPyB7IGNvbGxlY3Rpb25fYXJlYV9zZWxlY3Q6IG9wdGlvbiB9XHJcbiAgICAgICAgOiB7fSksXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICBbZmllbGRdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdEdyb3VwID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2dyb3VwL2dldC1ieS1pZC1ncm91cC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldFNlbGVjdGVkR3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBncm91cDpcIiwgZXJyKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyAtLS0tIHZhbGlkYXRlRm9ybSBub3cgdW5kZXJzdGFuZHMgd2l6YXJkIHN0ZXBzIGZvciB0aGUgQWRkIEN1c3RvbWVyIGZvcm0gLS0tLVxyXG4gIC8vIHN0ZXA6IDEgLT4gdmFsaWRhdGUgb25seSBTdGVwIDEgZmllbGRzXHJcbiAgLy8gICAgICAgMiAtPiB2YWxpZGF0ZSBvbmx5IFN0ZXAgMiAocGF5bWVudCkgZmllbGRzXHJcbiAgLy8gICAgICAgXCJhbGxcIiAtPiB2YWxpZGF0ZSBldmVyeXRoaW5nICh1c2VkIGJlZm9yZSBmaW5hbCBzdWJtaXQpXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUsIHN0ZXAgPSBcImFsbFwiKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGNvbnN0IGRhdGEgPSB0eXBlID09PSBcImFkZEN1c3RvbWVyXCIgPyBmb3JtRGF0YSA6IHVwZGF0ZUZvcm1EYXRhO1xyXG4gICAgY29uc3QgcmVnZXggPSB7XHJcbiAgICAgIGVtYWlsOiAvXlteXFxzQF0rQFteXFxzQF0rXFwuW15cXHNAXSskLyxcclxuICAgICAgcGhvbmU6IC9eWzYtOV1cXGR7OX0kLyxcclxuICAgICAgcGluY29kZTogL15cXGR7Nn0kLyxcclxuICAgICAgYWRoYWFyOiAvXlxcZHsxMn0kLyxcclxuICAgICAgcGFuOiAvXltBLVpdezV9WzAtOV17NH1bQS1aXXsxfSQvLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCB2YWxpZGF0ZUJhc2ljRGV0YWlscyA9ICgpID0+IHtcclxuICAgICAgaWYgKCFkYXRhLmZ1bGxfbmFtZT8udHJpbSgpKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLmZ1bGxfbmFtZSA9IFwiRnVsbCBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChkYXRhLmVtYWlsICYmICFyZWdleC5lbWFpbC50ZXN0KGRhdGEuZW1haWwpKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLmVtYWlsID0gXCJJbnZhbGlkIGVtYWlsIGZvcm1hdFwiO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoIWRhdGEucGhvbmVfbnVtYmVyKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLnBob25lX251bWJlciA9IFwiUGhvbmUgbnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgIH0gZWxzZSBpZiAoIXJlZ2V4LnBob25lLnRlc3QoZGF0YS5waG9uZV9udW1iZXIpKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLnBob25lX251bWJlciA9IFwiSW52YWxpZCAgcGhvbmUgbnVtYmVyXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh0eXBlID09PSBcImFkZEN1c3RvbWVyXCIgJiYgIWRhdGEucGFzc3dvcmQpIHtcclxuICAgICAgICBuZXdFcnJvcnMucGFzc3dvcmQgPSBcIlBhc3N3b3JkIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICghZGF0YS5waW5jb2RlKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLnBpbmNvZGUgPSBcIlBpbmNvZGUgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgfSBlbHNlIGlmICghcmVnZXgucGluY29kZS50ZXN0KGRhdGEucGluY29kZSkpIHtcclxuICAgICAgICBuZXdFcnJvcnMucGluY29kZSA9IFwiSW52YWxpZCBwaW5jb2RlICg2IGRpZ2l0cyByZXF1aXJlZClcIjtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKCFkYXRhLmFkaGFhcl9ubykge1xyXG4gICAgICAgIG5ld0Vycm9ycy5hZGhhYXJfbm8gPSBcIkFhZGhhciBudW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgfSBlbHNlIGlmICghcmVnZXguYWRoYWFyLnRlc3QoZGF0YS5hZGhhYXJfbm8pKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLmFkaGFhcl9ubyA9IFwiSW52YWxpZCBBYWRoYXIgbnVtYmVyICgxMiBkaWdpdHMgcmVxdWlyZWQpXCI7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGRhdGEucGFuX25vICYmICFyZWdleC5wYW4udGVzdChkYXRhLnBhbl9uby50b1VwcGVyQ2FzZSgpKSkge1xyXG4gICAgICAgIG5ld0Vycm9ycy5wYW5fbm8gPSBcIkludmFsaWQgUEFOIGZvcm1hdCAoZS5nLiwgQUJDREUxMjM0RilcIjtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKCFkYXRhLmFkZHJlc3M/LnRyaW0oKSkge1xyXG4gICAgICAgIG5ld0Vycm9ycy5hZGRyZXNzID0gXCJBZGRyZXNzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgIH0gZWxzZSBpZiAoZGF0YS5hZGRyZXNzLnRyaW0oKS5sZW5ndGggPCAzKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLmFkZHJlc3MgPSBcIkFkZHJlc3Mgc2hvdWxkIGJlIGF0IGxlYXN0IDMgY2hhcmFjdGVyc1wiO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAodHlwZSA9PT0gXCJhZGRDdXN0b21lclwiICYmICFzYW1lQXNBZGRyZXNzICYmICFkYXRhLnBlcm1hbmVudF9hZGRyZXNzPy50cmltKCkpIHtcclxuICAgICAgICBuZXdFcnJvcnMucGVybWFuZW50X2FkZHJlc3MgPSBcIlBlcm1hbmVudCBhZGRyZXNzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgdmFsaWRhdGVQYXltZW50RGV0YWlscyA9ICgpID0+IHtcclxuICAgICAgaWYgKHR5cGUgPT09IFwiYWRkQ3VzdG9tZXJcIikge1xyXG4gICAgICAgIGlmICghZGF0YS5pbnN0YWxsbWVudF90eXBlKSB7XHJcbiAgICAgICAgICBuZXdFcnJvcnMuaW5zdGFsbG1lbnRfdHlwZSA9IFwiUGF5bWVudCB0eXBlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghZGF0YS5pbnN0YWxsbWVudF9hbW91bnQpIHtcclxuICAgICAgICAgIG5ld0Vycm9ycy5pbnN0YWxsbWVudF9hbW91bnQgPSBcIlBheW1lbnQgYW1vdW50IGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgfSBlbHNlIGlmIChcclxuICAgICAgICAgIGlzTmFOKGRhdGEuaW5zdGFsbG1lbnRfYW1vdW50KSB8fFxyXG4gICAgICAgICAgTnVtYmVyKGRhdGEuaW5zdGFsbG1lbnRfYW1vdW50KSA8PSAwXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBuZXdFcnJvcnMuaW5zdGFsbG1lbnRfYW1vdW50ID0gXCJFbnRlciBhIHZhbGlkIGFtb3VudFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAodHlwZSA9PT0gXCJhZGRDdXN0b21lclwiKSB7XHJcbiAgICAgIGlmIChzdGVwID09PSAxKSB7XHJcbiAgICAgICAgdmFsaWRhdGVCYXNpY0RldGFpbHMoKTtcclxuICAgICAgfSBlbHNlIGlmIChzdGVwID09PSAyKSB7XHJcbiAgICAgICAgdmFsaWRhdGVQYXltZW50RGV0YWlscygpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHZhbGlkYXRlQmFzaWNEZXRhaWxzKCk7XHJcbiAgICAgICAgdmFsaWRhdGVQYXltZW50RGV0YWlscygpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyB1cGRhdGUgZm9ybSBrZWVwcyB0aGUgb3JpZ2luYWwgc2luZ2xlLXBhc3MgdmFsaWRhdGlvblxyXG4gICAgICB2YWxpZGF0ZUJhc2ljRGV0YWlscygpO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgLi4ubmV3RXJyb3JzIH0pKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPcGVuQ29uZmlybSA9ICgpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkRW1wbG95ZWUgPSBlbXBsb3llZXMuZmluZChcclxuICAgICAgKGVtcGxveWVlKSA9PiBlbXBsb3llZS5faWQgPT09IGZvcm1EYXRhLnJlZmVycmVkX2VtcGxveWVlXHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IHNlbGVjdGVkQWdlbnQgPSBhZ2VudHMuZmluZChcclxuICAgICAgKGFnZW50KSA9PiBhZ2VudC5faWQgPT09IGZvcm1EYXRhLnJlZmVycmVkX2FnZW50XHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IHNlbGVjdGVkQ3VzdG9tZXIgPSBjdXN0b21lcnMuZmluZChcclxuICAgICAgKGN1c3RvbWVyKSA9PiBjdXN0b21lci5faWQgPT09IGZvcm1EYXRhLnJlZmVycmVkX2N1c3RvbWVyXHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IHNlbGVjdGVkQ1JNID0gZW1wbG95ZWVzLmZpbmQoXHJcbiAgICAgIChlbXBsb3llZSkgPT5cclxuICAgICAgICBlbXBsb3llZS5faWQgPT09IGZvcm1EYXRhLmN1c3RvbWVyX3JlbGF0aW9uc2hpcF9tYW5hZ2VyXHJcbiAgICApO1xyXG5cclxuICAgIHNldENvbmZpcm1EYXRhKHtcclxuICAgICAgLi4uZm9ybURhdGEsXHJcblxyXG4gICAgICByZWZlcnJlZF9lbXBsb3llZV9zZWxlY3Q6XHJcbiAgICAgICAgZm9ybURhdGEucmVmZXJyYWxfdHlwZSA9PT0gXCJFbXBsb3llZVwiXHJcbiAgICAgICAgICA/IHNlbGVjdGVkRW1wbG95ZWVcclxuICAgICAgICAgICAgPyBgJHtzZWxlY3RlZEVtcGxveWVlLm5hbWV9IHwgJHtzZWxlY3RlZEVtcGxveWVlLnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgIDogXCItXCJcclxuICAgICAgICAgIDogdW5kZWZpbmVkLFxyXG5cclxuICAgICAgcmVmZXJyZWRfYWdlbnRfc2VsZWN0OlxyXG4gICAgICAgIGZvcm1EYXRhLnJlZmVycmFsX3R5cGUgPT09IFwiQWdlbnRcIlxyXG4gICAgICAgICAgPyBzZWxlY3RlZEFnZW50XHJcbiAgICAgICAgICAgID8gYCR7c2VsZWN0ZWRBZ2VudC5uYW1lfSB8ICR7c2VsZWN0ZWRBZ2VudC5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICA6IFwiLVwiXHJcbiAgICAgICAgICA6IHVuZGVmaW5lZCxcclxuXHJcbiAgICAgIHJlZmVycmVkX2N1c3RvbWVyX3NlbGVjdDpcclxuICAgICAgICBmb3JtRGF0YS5yZWZlcnJhbF90eXBlID09PSBcIkN1c3RvbWVyXCJcclxuICAgICAgICAgID8gc2VsZWN0ZWRDdXN0b21lclxyXG4gICAgICAgICAgICA/IGAke3NlbGVjdGVkQ3VzdG9tZXIuZnVsbF9uYW1lfSB8ICR7c2VsZWN0ZWRDdXN0b21lci5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICA6IFwiLVwiXHJcbiAgICAgICAgICA6IHVuZGVmaW5lZCxcclxuXHJcbiAgICAgIGN1c3RvbWVyX3JlbGF0aW9uc2hpcF9tYW5hZ2VyX3NlbGVjdDogc2VsZWN0ZWRDUk1cclxuICAgICAgICA/IGAke3NlbGVjdGVkQ1JNLm5hbWV9IHwgJHtzZWxlY3RlZENSTS5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgIDogXCItXCIsXHJcblxyXG4gICAgICBjb2xsZWN0aW9uX2FyZWFfc2VsZWN0OiBmb3JtRGF0YS5jb2xsZWN0aW9uX2FyZWFfc2VsZWN0IHx8IFwiLVwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0U2hvd0NvbmZpcm0odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVjb25maXJtYXRpb24gPSAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJhZGRDdXN0b21lclwiLCBcImFsbFwiKTtcclxuICAgIGlmICghaXNWYWxpZCkgcmV0dXJuO1xyXG5cclxuICAgIC8vIOKchSBKdXN0IG9wZW4gcmVjb25maXJtIG1vZGFsXHJcbiAgICBzZXRTaG93Q29uZmlybSh0cnVlKTtcclxuXHJcbiAgICBoYW5kbGVPcGVuQ29uZmlybSgpO1xyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0gTkVXOiBTdGVwIDEgXCJTYXZlIGFuZCBDb250aW51ZVwiIC0+IHZhbGlkYXRlIHN0ZXAgMSB0aGVuIG1vdmUgdG8gc3RlcCAyIC0tLS1cclxuICBjb25zdCBoYW5kbGVTYXZlQW5kQ29udGludWUgPSAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybShcImFkZEN1c3RvbWVyXCIsIDEpO1xyXG4gICAgaWYgKCFpc1ZhbGlkKSByZXR1cm47XHJcbiAgICBzZXRDdXJyZW50U3RlcCgyKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0tIE5FVzogXCJTYXZlIGFuZCBFeGl0XCIgLT4gdmFsaWRhdGUgb25seSB0aGUgY3VycmVudCBzdGVwLCBzdWJtaXQgd2hhdGV2ZXIgaXMgZmlsbGVkLCBhbmQgY2xvc2UgLS0tLVxyXG4gIGNvbnN0IGhhbmRsZVNhdmVBbmRFeGl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJhZGRDdXN0b21lclwiLCBjdXJyZW50U3RlcCk7XHJcbiAgICBpZiAoIWlzVmFsaWQpIHJldHVybjtcclxuICAgIGF3YWl0IGhhbmRsZVN1Ym1pdChlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgaWYgKGUgJiYgZS5wcmV2ZW50RGVmYXVsdCkgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgICAgLy8gQXBwZW5kIGFsbCBmaWVsZHMgZnJvbSBmb3JtRGF0YVxyXG4gICAgICBPYmplY3QuZW50cmllcyhmb3JtRGF0YSkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XHJcbiAgICAgICAgcGF5bG9hZC5hcHBlbmQoa2V5LCB2YWx1ZSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gQXBwZW5kIGZpcnN0IGF0dGFjaG1lbnQgYXMgXCJwcm9maWxlcGhvdG9cIlxyXG4gICAgICBpZiAoYXR0YWNobWVudHNbMF0pIHtcclxuICAgICAgICBwYXlsb2FkLmFwcGVuZChcInByb2ZpbGVwaG90b1wiLCBhdHRhY2htZW50c1swXSk7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi91c2VyL2FkZC1uZXctdXNlci1hZG1pblwiLCBwYXlsb2FkKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwMSkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkN1c3RvbWVyIGFkZGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIFJlc2V0IGZvcm0gb25seSBhZnRlciBzdWNjZXNzXHJcbiAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgZnVsbF9uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgZW1haWw6IFwiXCIsXHJcbiAgICAgICAgICBwaG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICAgICAgICBwYXNzd29yZDogXCJcIixcclxuICAgICAgICAgIGFkZHJlc3M6IFwiXCIsXHJcbiAgICAgICAgICBwZXJtYW5lbnRfYWRkcmVzczogXCJcIixcclxuICAgICAgICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICAgICAgICBhZGhhYXJfbm86IFwiXCIsXHJcbiAgICAgICAgICBwYW5fbm86IFwiXCIsXHJcbiAgICAgICAgICB0cmFja19zb3VyY2U6IFwiYWRtaW5fcGFuZWxcIixcclxuICAgICAgICAgIGNvbGxlY3Rpb25fYXJlYTogXCJcIixcclxuICAgICAgICAgIGN1c3RvbWVyX3JlbGF0aW9uc2hpcF9tYW5hZ2VyOiBcIlwiLFxyXG4gICAgICAgICAgcHJvZmlsZXBob3RvOiBudWxsLFxyXG4gICAgICAgICAgcmVmZXJyYWxfdHlwZTogXCJcIixcclxuICAgICAgICAgIHJlZmVycmVkX2VtcGxveWVlOiBcIlwiLFxyXG4gICAgICAgICAgcmVmZXJyZWRfYWdlbnQ6IFwiXCIsXHJcbiAgICAgICAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAgICAgICAgIGZhbWlseV9jb2RlOiBcIlwiLFxyXG4gICAgICAgICAgaW5zdGFsbG1lbnRfdHlwZTogXCJEYWlseVwiLFxyXG4gICAgICAgICAgaW5zdGFsbG1lbnRfYW1vdW50OiBcIlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldEF0dGFjaG1lbnRzKFtdKTtcclxuICAgICAgICBzZXRTaG93Q29uZmlybShmYWxzZSk7XHJcbiAgICAgICAgc2V0U2FtZUFzQWRkcmVzcyhmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudFN0ZXAoMSk7XHJcbiAgICAgICAgLy8gc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICBzZXRTaG93VXNlck1vZGFsKGZhbHNlKTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gQVBJIHJldHVybmVkIG5vbi0yMDEgYnV0IHN0aWxsIGRpZG4ndCB0aHJvd1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiByZXNwb25zZS5kYXRhPy5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIixcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgLy8gT25seSBzaG93IGVycm9yIGlmIHJlcXVlc3QgdHJ1bHkgZmFpbGVkXHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6XHJcbiAgICAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fFxyXG4gICAgICAgICAgZXJyb3IubWVzc2FnZSB8fFxyXG4gICAgICAgICAgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3JlYXRlZEF0XCIsIGhlYWRlcjogXCJKb2luZWQgT25cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfY29kZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJhcHByb3ZhbF9zdGF0dXNcIiwgaGVhZGVyOiBcIkFwcHJvdmFsIFN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9pZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJhZGRyZXNzXCIsIGhlYWRlcjogXCJDdXN0b21lciBBZGRyZXNzXCIgfSxcclxuICAgIHsga2V5OiBcInBpbmNvZGVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBpbmNvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyYWxfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZEJ5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFja1NvdXJjZVwiLCBoZWFkZXI6IFwiVHJhY2sgU291cmNlXCIgfSxcclxuICAgIC8vICB7a2V5OiBcInJlZmVycmFsX2NvZGVcIiwgaGVhZGVyOiBcIlJlZmVycmFsIENvZGVcIn0sXHJcbiAgICB7IGtleTogXCJjb2xsZWN0aW9uX2FyZWFcIiwgaGVhZGVyOiBcIkFyZWFcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfcmVsYXRpb25zaGlwX21hbmFnZXJcIiwgaGVhZGVyOiBcIlJlbGF0aW9uc2hpcCBtYW5hZ2VyXCIgfSxcclxuICAgIHsga2V5OiBcInByb2dyZXNzXCIsIGhlYWRlcjogXCJQcm9ncmVzc1wiIH0sXHJcblxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHByaW50dGFibGVDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJhcHByb3ZhbF9zdGF0dXNcIiwgaGVhZGVyOiBcIkFwcHJvdmFsIFN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9pZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJjcmVhdGVkQXRcIiwgaGVhZGVyOiBcIkpvaW5lZCBPblwiIH0sXHJcbiAgICB7IGtleTogXCJhZGRyZXNzXCIsIGhlYWRlcjogXCJDdXN0b21lciBBZGRyZXNzXCIgfSxcclxuICAgIHsga2V5OiBcInBpbmNvZGVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBpbmNvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyYWxfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZEJ5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFja1NvdXJjZVwiLCBoZWFkZXI6IFwiVHJhY2sgU291cmNlXCIgfSxcclxuICAgIHsga2V5OiBcImRvYlwiLCBoZWFkZXI6IFwiRE9CXCIgfSxcclxuICAgIC8vICB7a2V5OiBcInJlZmVycmFsX2NvZGVcIiwgaGVhZGVyOiBcIlJlZmVycmFsIENvZGVcIn0sXHJcbiAgICB7IGtleTogXCJjb2xsZWN0aW9uX2FyZWFcIiwgaGVhZGVyOiBcIkFyZWFcIiB9LFxyXG4gICAgeyBrZXk6IFwicHJvZ3Jlc3NWYWx1ZVwiLCBoZWFkZXI6IFwiUHJvZ3Jlc3NcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkVXNlcnMgPSB1c2Vycy5maWx0ZXIoKHVzZXIpID0+XHJcbiAgICB1c2VyLmZ1bGxfbmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSksXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdXNlci9nZXQtdXNlci1ieS1pZC8ke3VzZXJJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudFVzZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdXNlci9nZXQtdXNlci1ieS1pZC8ke3VzZXJJZH1gKTtcclxuXHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVVc2VyKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTZWxlY3RlZEdyb3VwKHJlc3BvbnNlPy5kYXRhPy5zZWxlY3RlZF9wbGFuKTtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIGZ1bGxfbmFtZTogcmVzcG9uc2U/LmRhdGE/LmZ1bGxfbmFtZSxcclxuICAgICAgICBlbWFpbDogcmVzcG9uc2U/LmRhdGE/LmVtYWlsLFxyXG4gICAgICAgIHBob25lX251bWJlcjogcmVzcG9uc2U/LmRhdGE/LnBob25lX251bWJlcixcclxuICAgICAgICBwYXNzd29yZDogcmVzcG9uc2U/LmRhdGE/LnBhc3N3b3JkLFxyXG4gICAgICAgIHBpbmNvZGU6IHJlc3BvbnNlPy5kYXRhPy5waW5jb2RlLFxyXG4gICAgICAgIGFkaGFhcl9ubzogcmVzcG9uc2U/LmRhdGE/LmFkaGFhcl9ubyxcclxuICAgICAgICBwYW5fbm86IHJlc3BvbnNlPy5kYXRhPy5wYW5fbm8sXHJcbiAgICAgICAgYWRkcmVzczogcmVzcG9uc2U/LmRhdGE/LmFkZHJlc3MsXHJcbiAgICAgICAgc2VsZWN0ZWRfcGxhbjogcmVzcG9uc2U/LmRhdGE/LnNlbGVjdGVkX3BsYW4/Ll9pZCB8fCBcIlwiLFxyXG4gICAgICAgIHRpdGxlOiByZXNwb25zZT8uZGF0YT8udGl0bGUsXHJcbiAgICAgICAgZmF0aGVyX25hbWU6IHJlc3BvbnNlPy5kYXRhPy5mYXRoZXJfbmFtZSxcclxuICAgICAgICBnZW5kZXI6IHJlc3BvbnNlPy5kYXRhPy5nZW5kZXIsXHJcbiAgICAgICAgbWFyaXRhbF9zdGF0dXM6IHJlc3BvbnNlPy5kYXRhPy5tYXJpdGFsX3N0YXR1cyxcclxuICAgICAgICBkYXRlb2ZiaXJ0aDogcmVzcG9uc2U/LmRhdGE/LmRhdGVvZmJpcnRoPy5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgbmF0aW9uYWxpdHk6IHJlc3BvbnNlPy5kYXRhPy5uYXRpb25hbGl0eSxcclxuICAgICAgICB2aWxsYWdlOiByZXNwb25zZT8uZGF0YT8udmlsbGFnZSxcclxuICAgICAgICB0YWx1azogcmVzcG9uc2U/LmRhdGE/LnRhbHVrLFxyXG4gICAgICAgIGRpc3RyaWN0OiByZXNwb25zZT8uZGF0YT8uZGlzdHJpY3QsXHJcbiAgICAgICAgc3RhdGU6IHJlc3BvbnNlPy5kYXRhPy5zdGF0ZSxcclxuICAgICAgICBjb2xsZWN0aW9uX2FyZWE6IHJlc3BvbnNlPy5kYXRhPy5jb2xsZWN0aW9uX2FyZWE/Ll9pZCB8fCBcIlwiLFxyXG4gICAgICAgIGN1c3RvbWVyX3JlbGF0aW9uc2hpcF9tYW5hZ2VyOiByZXNwb25zZT8uZGF0YT8uY3VzdG9tZXJfcmVsYXRpb25zaGlwX21hbmFnZXI/Ll9pZCB8fCBcIlwiLFxyXG4gICAgICAgIGFsdGVybmF0ZV9udW1iZXI6IHJlc3BvbnNlPy5kYXRhPy5hbHRlcm5hdGVfbnVtYmVyLFxyXG4gICAgICAgIHJlZmVycmFsX25hbWU6IHJlc3BvbnNlPy5kYXRhPy5yZWZlcnJhbF9uYW1lLFxyXG4gICAgICAgIG5vbWluZWVfbmFtZTogcmVzcG9uc2U/LmRhdGE/Lm5vbWluZWVfbmFtZSxcclxuICAgICAgICBub21pbmVlX2RhdGVvZmJpcnRoOiByZXNwb25zZT8uZGF0YT8ubm9taW5lZV9kYXRlb2ZiaXJ0aD8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgIG5vbWluZWVfcmVsYXRpb25zaGlwOiByZXNwb25zZT8uZGF0YT8ubm9taW5lZV9yZWxhdGlvbnNoaXAsXHJcbiAgICAgICAgbm9taW5lZV9waG9uZV9udW1iZXI6IHJlc3BvbnNlPy5kYXRhPy5ub21pbmVlX3Bob25lX251bWJlcixcclxuICAgICAgICBiYW5rX25hbWU6IHJlc3BvbnNlPy5kYXRhPy5iYW5rX25hbWUsXHJcbiAgICAgICAgYmFua19icmFuY2hfbmFtZTogcmVzcG9uc2U/LmRhdGE/LmJhbmtfYnJhbmNoX25hbWUsXHJcbiAgICAgICAgYmFua19hY2NvdW50X251bWJlcjogcmVzcG9uc2U/LmRhdGE/LmJhbmtfYWNjb3VudF9udW1iZXIsXHJcbiAgICAgICAgYmFua19JRlNDX2NvZGU6IHJlc3BvbnNlPy5kYXRhPy5iYW5rX0lGU0NfY29kZSxcclxuICAgICAgICBhYWRoYXJfZnJvbnRwaG90bzogcmVzcG9uc2U/LmRhdGE/LmFhZGhhcl9mcm9udHBob3RvLFxyXG4gICAgICAgIGFhZGhhcl9iYWNrcGhvdG86IHJlc3BvbnNlPy5kYXRhPy5hYWRoYXJfYmFja3Bob3RvLFxyXG4gICAgICAgIHBhbl9mcm9udHBob3RvOiByZXNwb25zZT8uZGF0YT8ucGFuX2Zyb250cGhvdG8sXHJcbiAgICAgICAgcGFuX2JhY2twaG90bzogcmVzcG9uc2U/LmRhdGE/LnBhbl9iYWNrcGhvdG8sXHJcbiAgICAgICAgcHJvZmlsZXBob3RvOiByZXNwb25zZT8uZGF0YT8ucHJvZmlsZXBob3RvLFxyXG4gICAgICAgIHJlZmVycmFsX3R5cGU6IHJlc3BvbnNlPy5kYXRhPy5yZWZlcnJhbF90eXBlLFxyXG4gICAgICAgIHJlZmVycmVkX2VtcGxveWVlOiByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfZW1wbG95ZWUgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJlZF9hZ2VudDogcmVzcG9uc2U/LmRhdGE/LnJlZmVycmVkX2FnZW50IHx8IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IHJlc3BvbnNlPy5kYXRhPy5yZWZlcnJlZF9jdXN0b21lciB8fCBcIlwiLFxyXG4gICAgICAgIGluc3RhbGxtZW50X3R5cGU6IHJlc3BvbnNlPy5kYXRhPy5pbnN0YWxsbWVudF90eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgaW5zdGFsbG1lbnRfYW1vdW50OiByZXNwb25zZT8uZGF0YT8uaW5zdGFsbG1lbnRfYW1vdW50IHx8IFwiXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVVc2VyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRVc2VyKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL3VzZXIvZGVsZXRlLXVzZXIvJHtjdXJyZW50VXNlci5faWR9YCk7XHJcblxyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIlVzZXIgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgIHNldEN1cnJlbnRVc2VyKG51bGwpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyB1c2VyOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZUZpbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCBmaWxlcyB9ID0gZS50YXJnZXQ7XHJcbiAgICBjb25zdCBmaWxlID0gZmlsZXNbMF07XHJcblxyXG4gICAgaWYgKGZpbGUpIHtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZTdGF0ZSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2U3RhdGUsXHJcbiAgICAgICAgW25hbWVdOiBmaWxlLFxyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gQVBJIGNhbGwgdG8gdXBkYXRlIGN1c3RvbWVyIHN0YXR1c1xyXG4gIGNvbnN0IGhhbmRsZUN1c3RvbWVyU3RhdHVzID0gYXN5bmMgKGlkLCBuZXdTdGF0dXMpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmICghaWQpIHtcclxuICAgICAgICBjb25zb2xlLndhcm4oXCJObyB1c2VyIElEIHByb3ZpZGVkXCIpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucHV0KGAvdXNlci91cGRhdGUtdXNlci8ke2lkfWAsIHtcclxuICAgICAgICBhcHByb3ZhbF9zdGF0dXM6IG5ld1N0YXR1cyxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDApIHtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGBVc2VyIHN0YXR1cyBoYXMgYmVlbiBzdWNjZXNzZnVsbHkgdXBkYXRlZCB0byAke25ld1N0YXR1cyA9PT0gXCJ0cnVlXCIgPyBcIkFwcHJvdmVkXCIgOiBcIlVuYXBwcm92ZWRcIn1gLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKFxyXG4gICAgICAgICAgYEFwcHJvdmFsIHN0YXR1cyB1cGRhdGVkIHRvICR7bmV3U3RhdHVzfSBmb3IgdXNlciBJRDpgLFxyXG4gICAgICAgICAgaWQsXHJcbiAgICAgICAgKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zb2xlLndhcm4oXCJGYWlsZWQgdG8gdXBkYXRlIGN1c3RvbWVyIHN0YXR1czpcIiwgcmVzcG9uc2U/LmRhdGEpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGN1c3RvbWVyIHN0YXR1czpcIiwgZXJyLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZXMgYm90aCBBcHByb3ZlIGFuZCBVbmFwcHJvdmUgd2l0aCBjb25maXJtYXRpb25cclxuICBjb25zdCBoYW5kbGVDdXN0b21lclN0YXR1c1dpdGhDb25maXJtID0gKGlkLCBjdXJyZW50U3RhdHVzKSA9PiB7XHJcbiAgICBjb25zdCBpc0FwcHJvdmluZyA9IGN1cnJlbnRTdGF0dXMgPT09IFwidHJ1ZVwiOyAvLyBuZXcgc3RhdHVzIHRvIGFwcGx5XHJcbiAgICBjb25zdCBhY3Rpb25UZXh0ID0gaXNBcHByb3ZpbmcgPyBcImFwcHJvdmVcIiA6IFwidW5hcHByb3ZlXCI7XHJcblxyXG4gICAgY29uZmlybSh7XHJcbiAgICAgIHRpdGxlOiBgQXJlIHlvdSBzdXJlP2AsXHJcbiAgICAgIGNvbnRlbnQ6IGBEbyB5b3Ugd2FudCB0byAke2FjdGlvblRleHR9IHRoaXMgY3VzdG9tZXI/YCxcclxuICAgICAgb2tUZXh0OiBcIlllc1wiLFxyXG4gICAgICBjYW5jZWxUZXh0OiBcIk5vXCIsXHJcbiAgICAgIGFzeW5jIG9uT2soKSB7XHJcbiAgICAgICAgYXdhaXQgaGFuZGxlQ3VzdG9tZXJTdGF0dXMoaWQsIGN1cnJlbnRTdGF0dXMpO1xyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBmbURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuXHJcbiAgICAgIE9iamVjdC5lbnRyaWVzKHVwZGF0ZUZvcm1EYXRhKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcclxuICAgICAgICBpZiAoa2V5ID09PSBcInNlbGVjdGVkX3BsYW5cIiAmJiBzZWxlY3RlZEdyb3VwPy5faWQpIHtcclxuICAgICAgICAgIGZtRGF0YS5hcHBlbmQoXCJzZWxlY3RlZF9wbGFuXCIsIHNlbGVjdGVkR3JvdXAuX2lkKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICBmbURhdGEuYXBwZW5kKGtleSwgdmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIC8vIEFwcGVuZCBmaXJzdCBhdHRhY2htZW50IGFzIFwicHJvZmlsZXBob3RvXCJcclxuICAgICAgaWYgKGF0dGFjaG1lbnRzWzBdKSB7XHJcbiAgICAgICAgZm1EYXRhLmFwcGVuZChcInByb2ZpbGVwaG90b1wiLCBhdHRhY2htZW50c1swXSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoYC91c2VyL3VwZGF0ZS11c2VyLyR7Y3VycmVudFVwZGF0ZVVzZXI/Ll9pZH1gLCBmbURhdGEsIHtcclxuICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlVzZXIgVXBkYXRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlXHJcbiAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgLmluY2x1ZGVzKFwicGhvbmUgbnVtYmVyIGFscmVhZHkgZXhpc3RzXCIpXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHtcclxuICAgICAgICAgIC4uLnByZXZFcnJvcnMsXHJcbiAgICAgICAgICBwaG9uZV9udW1iZXI6IFwiUGhvbmUgbnVtYmVyIGFscmVhZHkgZXhpc3RzXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICB9IGVsc2UgaWYgKFxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZVxyXG4gICAgICApIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2V9YCxcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0gTkVXOiBzbWFsbCBzdGF0dXMvc3RlcCBiYXIgc2hvd24gb25seSBpbnNpZGUgdGhlIEFkZCBDdXN0b21lciBtb2RhbCAtLS0tXHJcbiAgY29uc3QgU3RlcFN0YXR1c0JhciA9ICgpID0+IChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItNlwiPlxyXG4gICAgICB7U1RFUFMubWFwKChzdGVwLCBpZHgpID0+IChcclxuICAgICAgICA8ZGl2IGtleT17c3RlcC5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctOSBoLTkgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlci0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyAke2N1cnJlbnRTdGVwID09PSBzdGVwLmlkXHJcbiAgICAgICAgICAgICAgICA/IFwiYmctYmx1ZS03MDAgYm9yZGVyLWJsdWUtNzAwIHRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgOiBjdXJyZW50U3RlcCA+IHN0ZXAuaWRcclxuICAgICAgICAgICAgICAgICAgPyBcImJnLWdyZWVuLTUwMCBib3JkZXItZ3JlZW4tNTAwIHRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiYmctd2hpdGUgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS00MDBcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7Y3VycmVudFN0ZXAgPiBzdGVwLmlkID8gPENoZWNrIHNpemU9ezE4fSAvPiA6IHN0ZXAuaWR9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YG10LTEgdGV4dC14cyBmb250LW1lZGl1bSB3aGl0ZXNwYWNlLW5vd3JhcCAke2N1cnJlbnRTdGVwID09PSBzdGVwLmlkID8gXCJ0ZXh0LWJsdWUtNzAwXCIgOiBcInRleHQtZ3JheS00MDBcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7c3RlcC5sYWJlbH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB7aWR4IDwgU1RFUFMubGVuZ3RoIC0gMSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTE2IGgtMC41IG14LTIgbWItNSAke2N1cnJlbnRTdGVwID4gc3RlcC5pZCA/IFwiYmctZ3JlZW4tNTAwXCIgOiBcImJnLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMlwiPlxyXG4gICAgICAgICAgey8qIDxTaWRlYmFyIC8+ICovfVxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e0dsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcblxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtMiBvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCIgbWItMSBtaW4tdy1tYXhcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+Q3VzdG9tZXJzPC9oMT5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICsgQWRkIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7VGFibGVVc2Vycz8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgdXBkYXRlSGFuZGxlcj17aGFuZGxlVXBkYXRlTW9kYWxPcGVufVxyXG4gICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlVXNlcnMsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydENvbHM9e3ByaW50dGFibGVDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgaXNFeHBvcnRFbmFibGVkPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ3VzdG9tZXJzXCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDdXN0b21lcnMuY3N2YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXtUYWJsZVVzZXJzLmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgZGF0YT1cIkN1c3RvbWVyIERhdGFcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gQUREIENVU1RPTUVSIE1PREFMIChTdGVwcGVyKSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd1VzZXJNb2RhbH1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd1VzZXJNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRTdGVwKDEpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgQWRkIEN1c3RvbWVyXHJcbiAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICB7LyogU3RlcCBzdGF0dXMgYmFyIC0gQWRkIEN1c3RvbWVyIG1vZGFsIG9ubHkgKi99XHJcbiAgICAgICAgICAgIDxTdGVwU3RhdHVzQmFyIC8+XHJcblxyXG4gICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVJlY29uZmlybWF0aW9ufVxyXG4gICAgICAgICAgICAgIG5vVmFsaWRhdGVcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHsvKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIFNURVAgMTogQkFTSUMgREVUQUlMUyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovfVxyXG4gICAgICAgICAgICAgIHtjdXJyZW50U3RlcCA9PT0gMSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBGdWxsIE5hbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJmdWxsX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEZ1bGwgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZnVsbF9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1haWwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5lbWFpbH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQYXNzd29yZCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFzc3dvcmQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBpbmNvZGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRoYWFyIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZGhhYXJfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkaGFhciBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRoYWFyX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGFuIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYW5fbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnBhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQYW4gTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhbl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnBhbl9ub308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQWRkcmVzcyAoQ29tbXVuaWNhdGlvbikgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciAke2ZpZWxkU2l6ZS5oZWlnaHR9IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmFkZHJlc3N9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIE5FVzogUGVybWFuZW50IEFkZHJlc3MgKyBcIlNhbWUgYXMgQ29tbXVuaWNhdGlvbiBBZGRyZXNzXCIgY2hlY2tib3ggKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMiBmbGV4LXdyYXAgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGVybWFuZW50X2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQZXJtYW5lbnQgQWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2FtZUFzQWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNhbWVBZGRyZXNzVG9nZ2xlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTYW1lIGFzIENvbW11bmljYXRpb24gQWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9DaGVja2JveD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwZXJtYW5lbnRfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGVybWFuZW50X2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhbWVBc0FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBlcm1hbmVudF9hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIFBlcm1hbmVudCBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyICR7ZmllbGRTaXplLmhlaWdodH0gYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCAke3NhbWVBc0FkZHJlc3MgPyBcIm9wYWNpdHktNjAgY3Vyc29yLW5vdC1hbGxvd2VkXCIgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wZXJtYW5lbnRfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGVybWFuZW50X2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7LyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBTVEVQIDI6IEFERElUSU9OQUwgREVUQUlMUyArIFBBWU1FTlQgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL31cclxuICAgICAgICAgICAgICB7Y3VycmVudFN0ZXAgPT09IDIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBGYW1pbHkgQ29kZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJmYW1pbHlfY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZmFtaWx5X2NvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRmFtaWx5IENvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5mYW1pbHlfY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmZhbWlseV9jb2RlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBSZWZlcnJlZCBUeXBlICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBSZWZlcnJlZCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJhbF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ucmVmZXJyYWxfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJyZWZlcnJhbF90eXBlXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlNlbGYgSm9pbmluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiQ3VzdG9tZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIkVtcGxveWVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJBZ2VudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiT3RoZXJzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChyZWZUeXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWZUeXBlfSB2YWx1ZT17cmVmVHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVmVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnJlZmVycmFsX3R5cGUgPT09IFwiQ3VzdG9tZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBDdXN0b21lcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX2N1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5yZWZlcnJlZF9jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcInJlZmVycmVkX2N1c3RvbWVyXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX0gfHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnBob25lX251bWJlciA/IHVzZXIucGhvbmVfbnVtYmVyIDogXCJObyBOdW1iZXJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5yZWZlcnJhbF90eXBlID09PSBcIkFnZW50XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEFnZW50e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9yIFNlYXJjaCBSZWZlcnJlZCBBZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX2FnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnJlZmVycmVkX2FnZW50IHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfYWdlbnRcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHwge2FnZW50LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5yZWZlcnJhbF90eXBlID09PSBcIkVtcGxveWVlXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgRW1wbG95ZWV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggUmVmZXJyZWQgRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9lbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIW9wdGlvbiB8fCAhb3B0aW9uLmNoaWxkcmVuKSByZXR1cm4gZmFsc2U7IC8vIEVuc3VyZSBvcHRpb24gYW5kIGNoaWxkcmVuIGV4aXN0XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnJlZmVycmVkX2VtcGxveWVlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfZW1wbG95ZWVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcGxveWVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXBsb3llZS5faWR9IHZhbHVlPXtlbXBsb3llZS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlLm5hbWV9IHwge2VtcGxveWVlLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJhcmVhXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ29sbGVjdGlvbiBBcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggQ29sbGVjdGlvbiBBcmVhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvbGxlY3Rpb25fYXJlYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5jb2xsZWN0aW9uX2FyZWEgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlLCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImNvbGxlY3Rpb25fYXJlYVwiLCB2YWx1ZSwgb3B0aW9uLmNoaWxkcmVuKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthcmVhcy5tYXAoKGFyZWEpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2FyZWEuX2lkfSB2YWx1ZT17YXJlYS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2FyZWEucm91dGVfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIGN1c3RvbWVyIHJlbGF0aW9uc2hpcCBtYW5hZ2VyKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImN1c3RvbWVyX3JlbGF0aW9uc2hpcF9tYW5hZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgUmVsYXRpb25zaGlwIE1hbmFnZXJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggQ3VzdG9tZXIgUmVsYXRpb25zaGlwIE1hbmFnZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY3VzdG9tZXJfcmVsYXRpb25zaGlwX21hbmFnZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YT8uY3VzdG9tZXJfcmVsYXRpb25zaGlwX21hbmFnZXIgfHwgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImN1c3RvbWVyX3JlbGF0aW9uc2hpcF9tYW5hZ2VyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcGxveWVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXBsb3llZS5faWR9IHZhbHVlPXtlbXBsb3llZS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlLm5hbWV9IHwge2VtcGxveWVlLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICB7LyogTkVXOiBQYXltZW50IFR5cGUgKyBQYXltZW50IEFtb3VudCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRnJlcXVlbmN5IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFJhZGlvLkdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJpbnN0YWxsbWVudF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmluc3RhbGxtZW50X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwiaW5zdGFsbG1lbnRfdHlwZVwiLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UmFkaW8gdmFsdWU9XCJkYWlseVwiPkRhaWx5PC9SYWRpbz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFJhZGlvIHZhbHVlPVwid2Vla2x5XCI+V2Vla2x5PC9SYWRpbz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFJhZGlvIHZhbHVlPVwibW9udGhseVwiPk1vbnRobHk8L1JhZGlvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9SYWRpby5Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuaW5zdGFsbG1lbnRfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmluc3RhbGxtZW50X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5pbnN0YWxsbWVudF90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmluc3RhbGxtZW50X3R5cGUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuaW5zdGFsbG1lbnRfdHlwZS5zbGljZSgxKX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgSW5zdGFsbG1lbnQgQW1vdW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJpbnN0YWxsbWVudF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5pbnN0YWxsbWVudF9hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17YEVudGVyICR7Zm9ybURhdGEuaW5zdGFsbG1lbnRfdHlwZX0gaW5zdGFsbG1lbnQgYW1vdW50YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuaW5zdGFsbG1lbnRfYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmluc3RhbGxtZW50X2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBBVFRBQ0ggRE9DVU1FTlQgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjb2xsZWN0aW9uX2FyZWFcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFBob3RvXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiYXR0YWNobWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLTMyIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlciBiZy1ncmF5LTUwIGhvdmVyOmJnLWdyYXktMTAwIG92ZXJmbG93LWhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYXR0YWNobWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiLmpwZWcsLmpwZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWZpbGUpIHJldHVybjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ2hlY2sgZmlsZSB0eXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIWZpbGUudHlwZS5zdGFydHNXaXRoKFwiaW1hZ2UvanBlZ1wiKSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIWZpbGUudHlwZS5zdGFydHNXaXRoKFwiaW1hZ2UvanBnXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGVydChcIk9ubHkgSlBFRyBpbWFnZXMgYXJlIGFsbG93ZWQhXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gT25seSBhbGxvdyAxIGZpbGUgYXQgYSB0aW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXR0YWNobWVudHMoW2ZpbGVdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAge2F0dGFjaG1lbnRzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTEwIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvdWRVcGxvYWQgc2l6ZT17NDB9IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgbWItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBdHRhY2ggUGhvdG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBKUEVHIG9ubHkgKE1heCA1TUIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC0zMiB3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e1VSTC5jcmVhdGVPYmplY3RVUkwoYXR0YWNobWVudHNbMF0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwicHJldmlld1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgb2JqZWN0LWNvdmVyIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMSByaWdodC0xIGZsZXggc3BhY2UteC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUmVtb3ZlIEJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEF0dGFjaG1lbnRzKFtdKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctcmVkLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCBwLTEgaG92ZXI6YmctcmVkLTYwMCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBzaXplPXsxMn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEb3dubG9hZCBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXtVUkwuY3JlYXRlT2JqZWN0VVJMKGF0dGFjaG1lbnRzWzBdKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWQ9e2F0dGFjaG1lbnRzWzBdLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNTAwIHRleHQtd2hpdGUgcm91bmRlZC1mdWxsIHAtMSBob3ZlcjpiZy1ibHVlLTYwMCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgc2l6ZT17MTJ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIFdJWkFSRCBBQ1RJT04gQlVUVE9OUyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmQgZ2FwLTMgZmxleC13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICB7Y3VycmVudFN0ZXAgPT09IDIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFN0ZXAoMSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXItMiBib3JkZXItZ3JheS0zMDAgaG92ZXI6YmctZ3JheS0xMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEJhY2tcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZUFuZEV4aXR9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyLTIgYm9yZGVyLWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNhdmUgJiBFeGl0XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIHtjdXJyZW50U3RlcCA9PT0gMSA/IChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmVBbmRDb250aW51ZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU2F2ZSAmIENvbnRpbnVlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgYmctYmx1ZS03MDAgaG92ZXI6YmctYmx1ZS04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBTYXZlIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB7c2hvd0NvbmZpcm0gJiYgKFxyXG4gICAgICAgICAgICA8UmVDb25maXJtTW9kYWxcclxuICAgICAgICAgICAgICBpc09wZW49e3Nob3dDb25maXJtfVxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiQ29uZmlybSBEZXRhaWxzXCJcclxuICAgICAgICAgICAgICBkYXRhPXtjb25maXJtRGF0YX1cclxuICAgICAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0U2hvd0NvbmZpcm0oZmFsc2UpfVxyXG4gICAgICAgICAgICAgIG9uQ29uZmlybT17aGFuZGxlU3VibWl0fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIHsvKiA8L1BhZ2VXcmFwcGVyPiAqL31cclxuXHJcbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09IFVQREFURSBDVVNUT01FUiBNT0RBTCAobm8gc3RlcHBlcikgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnQgJHshdXBkYXRlRm9ybURhdGEgfHwgT2JqZWN0LmtleXModXBkYXRlRm9ybURhdGEpLmxlbmd0aCA9PT0gMFxyXG4gICAgICAgICAgICAgID8gXCJiZy1yZWQtNTBcIlxyXG4gICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgVXBkYXRlIEN1c3RvbWVyXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHshdXBkYXRlRm9ybURhdGEgfHwgT2JqZWN0LmtleXModXBkYXRlRm9ybURhdGEpLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LThcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICBObyBjdXN0b21lciBkYXRhIGF2YWlsYWJsZVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFRpdGxlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHshdXBkYXRlRm9ybURhdGE/LnRpdGxlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy50aXRsZS50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBUaXRsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRpdGxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnRpdGxlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcInRpdGxlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IFRpdGxlPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAge1tcIk1yXCIsIFwiTXNcIiwgXCJNcnNcIiwgXCJNL1NcIiwgXCJEclwiXS5tYXAoKGNUaXRsZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2NUaXRsZX0gdmFsdWU9e2NUaXRsZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NUaXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBGdWxsIE5hbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJmdWxsX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRnVsbCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8uZnVsbF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5mdWxsX25hbWUudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmZ1bGxfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRW1haWxcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5lbWFpbCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uZW1haWwudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtYWlsICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGhvbmVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8ucGhvbmVfbnVtYmVyIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5waG9uZV9udW1iZXIudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQWFkaGFyIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFkaGFhcl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmFkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkaGFhciBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5hZGhhYXJfbm8gfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LmFkaGFhcl9uby50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gJHtmaWVsZFNpemUuaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRoYWFyX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQYW4gTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYW5fbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5wYW5fbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQYW4gTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8ucGFuX25vIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5wYW5fbm8udHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhbl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFuX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmFkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8uYWRkcmVzcyB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LmFkZHJlc3MudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcmVkLTUwIGJvcmRlci1yZWQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQaW5jb2RlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnBpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8ucGluY29kZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8ucGluY29kZS50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gJHtmaWVsZFNpemUuaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRmF0aGVyIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImZhdGhlcl9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZmF0aGVyX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImZhdGhlci1uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEZhdGhlciBuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5mYXRoZXJfbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uZmF0aGVyX25hbWUudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVmZXJyZWQgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJhbF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnJlZmVycmFsX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJyZWZlcnJhbF90eXBlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlNlbGYgSm9pbmluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJBZ2VudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJPdGhlcnNcIixcclxuICAgICAgICAgICAgICAgICAgICBdLm1hcCgocmVmVHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWZUeXBlfSB2YWx1ZT17cmVmVHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZWZUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnJlZmVycmFsX3R5cGUgPT09IFwiQ3VzdG9tZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBDdXN0b21lcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5yZWZlcnJlZF9jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJyZWZlcnJlZF9jdXN0b21lclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJzPy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9IHx7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIucGhvbmVfbnVtYmVyID8gdXNlci5waG9uZV9udW1iZXIgOiBcIk5vIE51bWJlclwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnJlZmVycmFsX3R5cGUgPT09IFwiQWdlbnRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgQWdlbnR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggUmVmZXJyZWQgQWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9hZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEucmVmZXJyZWRfYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwicmVmZXJyZWRfYWdlbnRcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQubmFtZX0gfCB7YWdlbnQucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnJlZmVycmFsX3R5cGUgPT09IFwiRW1wbG95ZWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBFbXBsb3llZXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfZW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIW9wdGlvbiB8fCAhb3B0aW9uLmNoaWxkcmVuKSByZXR1cm4gZmFsc2U7IC8vIEVuc3VyZSBvcHRpb24gYW5kIGNoaWxkcmVuIGV4aXN0XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnJlZmVycmVkX2VtcGxveWVlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcInJlZmVycmVkX2VtcGxveWVlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXBsb3llZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VtcGxveWVlLl9pZH0gdmFsdWU9e2VtcGxveWVlLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlLm5hbWV9IHwge2VtcGxveWVlLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiYXJlYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ29sbGVjdGlvbiBBcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHshdXBkYXRlRm9ybURhdGE/LmZhdGhlcl9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5mYXRoZXJfbmFtZS50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggQ29sbGVjdGlvbiBBcmVhXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29sbGVjdGlvbl9hcmVhXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uY29sbGVjdGlvbl9hcmVhIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcImNvbGxlY3Rpb25fYXJlYVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3Qgb3IgU2VhcmNoIENvbGxlY3Rpb24gQXJlYVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FyZWFzLm1hcCgoYXJlYSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2FyZWEuX2lkfSB2YWx1ZT17YXJlYS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHthcmVhLnJvdXRlX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgey8qIGN1c3RvbWVyIHJlbGF0aW9uc2hpcCBtYW5hZ2VyKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY3VzdG9tZXJfcmVsYXRpb25zaGlwX21hbmFnZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgUmVsYXRpb25zaGlwIE1hbmFnZXJcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBDdXN0b21lciBSZWxhdGlvbnNoaXAgTWFuYWdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY3VzdG9tZXJfcmVsYXRpb25zaGlwX21hbmFnZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uY3VzdG9tZXJfcmVsYXRpb25zaGlwX21hbmFnZXIgfHwgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJjdXN0b21lcl9yZWxhdGlvbnNoaXBfbWFuYWdlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcGxveWVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VtcGxveWVlLl9pZH0gdmFsdWU9e2VtcGxveWVlLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZS5uYW1lfSB8IHtlbXBsb3llZS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgRGF0ZSBvZiBCaXJ0aFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGF0ZW9mYmlydGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uZGF0ZW9mYmlydGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKHVwZGF0ZUZvcm1EYXRhPy5kYXRlb2ZiaXJ0aCB8fCBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5kYXRlb2ZiaXJ0aCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uZGF0ZW9mYmlydGgudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZSBvZiBCaXJ0aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBHZW5kZXJcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8uZ2VuZGVyIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5nZW5kZXIudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmdlbmRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJnZW5kZXJcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge1tcIk1hbGVcIiwgXCJGZW1hbGVcIl0ubWFwKChnVHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dUeXBlfSB2YWx1ZT17Z1R5cGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtnVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwibWFyaXRhbC1zdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIE1hcml0YWwgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHshdXBkYXRlRm9ybURhdGE/Lm1hcml0YWxfc3RhdHVzIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5tYXJpdGFsX3N0YXR1cy50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBNYXJpdGFsIFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1hcml0YWxfc3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/Lm1hcml0YWxfc3RhdHVzIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcIm1hcml0YWxfc3RhdHVzXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtbXCJNYXJyaWVkXCIsIFwiVW5tYXJyaWVkXCIsIFwiV2lkb3dcIiwgXCJEaXZvcmNlZFwiXS5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChtU3RhdHVzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXttU3RhdHVzfSB2YWx1ZT17bVN0YXR1c30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bVN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJyZWZlcnJhbC1uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZWZlcnJhbCBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJhbF9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucmVmZXJyYWxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwicmVmZXJyYWwtbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBSZWZlcnJhbCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5yZWZlcnJhbF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5yZWZlcnJhbF9uYW1lLnRyaW0oKSA9PT0gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcmVkLTUwIGJvcmRlci1yZWQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSAke2ZpZWxkU2l6ZS5oZWlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwibmF0aW9uYWxpdHlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIE5hdGlvbmFsaXR5XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHshdXBkYXRlRm9ybURhdGE/Lm5hdGlvbmFsaXR5IHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5uYXRpb25hbGl0eS50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBOYXRpb25hbGl0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5hdGlvbmFsaXR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/Lm5hdGlvbmFsaXR5IHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcIm5hdGlvbmFsaXR5XCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtbXCJJbmRpYW5cIiwgXCJPdGhlclwiXS5tYXAoKG5hdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e25hdGlvbn0gdmFsdWU9e25hdGlvbn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge25hdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFsdGVybmF0ZS1udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEFsdGVybmF0ZSBQaG9uZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWx0ZXJuYXRlX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmFsdGVybmF0ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImFsdGVybmF0ZS1udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQWx0ZXJuYXRlIFBob25lIG51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8uYWx0ZXJuYXRlX251bWJlciB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uYWx0ZXJuYXRlX251bWJlci50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gJHtmaWVsZFNpemUuaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInZpbGxhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFZpbGxhZ2VcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInZpbGxhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy52aWxsYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ2aWxsYWdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIFZpbGxhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHshdXBkYXRlRm9ybURhdGE/LnZpbGxhZ2UgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LnZpbGxhZ2UudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidGFsdWtcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFRhbHVrXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0YWx1a1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnRhbHVrfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0YWx1a1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSB0YWx1a1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8udGFsdWsgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LnRhbHVrLnRyaW0oKSA9PT0gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcmVkLTUwIGJvcmRlci1yZWQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSAke2ZpZWxkU2l6ZS5oZWlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic3RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFN0YXRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHshdXBkYXRlRm9ybURhdGE/LnRhbHVrIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy50YWx1ay50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBTdGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uc3RhdGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwic3RhdGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge1tcIkthcm5hdGFrYVwiLCBcIk1haGFyYXNodHJhXCIsIFwiVGFtaWwgTmFkdVwiXS5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChzdGF0ZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3RhdGV9IHZhbHVlPXtzdGF0ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGlzdHJpY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIERpc3RyaWN0XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGlzdHJpY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5kaXN0cmljdH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRGlzdHJpY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHshdXBkYXRlRm9ybURhdGE/LmRpc3RyaWN0IHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5kaXN0cmljdC50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gJHtmaWVsZFNpemUuaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiApfSAqL31cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJub21pbmVlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBOb21pbmVlIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vbWluZWVfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/Lm5vbWluZWVfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibm9taW5lZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBOb21pbmVlIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHshdXBkYXRlRm9ybURhdGE/Lm5vbWluZWVfbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8ubm9taW5lZV9uYW1lLnRyaW0oKSA9PT0gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcmVkLTUwIGJvcmRlci1yZWQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSAke2ZpZWxkU2l6ZS5oZWlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm5vbWluZWUtZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTm9taW5lZSBEYXRlIG9mIEJpcnRoXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub21pbmVlX2RhdGVvZmJpcnRoXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/Lm5vbWluZWVfZGF0ZW9mYmlydGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKHVwZGF0ZUZvcm1EYXRhPy5ub21pbmVlX2RhdGVvZmJpcnRoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibm9taW5lZS1kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIE5vbWluZWUgRGF0ZSBvZiBCaXJ0aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8ubm9taW5lZV9kYXRlb2ZiaXJ0aCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8ubm9taW5lZV9kYXRlb2ZiaXJ0aC50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gJHtmaWVsZFNpemUuaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm5vbWluZWUtcmVsYXRpb25zaGlwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBOb21pbmVlIFJlbGF0aW9uc2hpcFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5ub21pbmVlX3JlbGF0aW9uc2hpcCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8ubm9taW5lZV9yZWxhdGlvbnNoaXAudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTm9taW5lZSBSZWxhdGlvbnNoaXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub21pbmVlX3JlbGF0aW9uc2hpcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5ub21pbmVlX3JlbGF0aW9uc2hpcCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJub21pbmVlX3JlbGF0aW9uc2hpcFwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBcIkZhdGhlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcIk1vdGhlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcIkJyb3RoZXIvU2lzdGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiU3BvdXNlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiU29uL0RhdWdodGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChub21pbmVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bm9taW5lZX0gdmFsdWU9e25vbWluZWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtub21pbmVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwibm9taW5lZS1waG9uZS1udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIE5vbWluZWUgUGhvbmUgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vbWluZWVfcGhvbmVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ubm9taW5lZV9waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIm5vbWluZWUtcGhvbmUtbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIE5vbWluZWUgUGhvbmUgbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5ub21pbmVlX3Bob25lX251bWJlciB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8ubm9taW5lZV9waG9uZV9udW1iZXIudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJiYW5rLW5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEJhbmsgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uYmFua19uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJiYW5rLW5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQ3VzdG9tZXIgQmFuayBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5iYW5rX25hbWUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LmJhbmtfbmFtZS50cmltKCkgPT09IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJlZC01MCBib3JkZXItcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gJHtmaWVsZFNpemUuaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJiYW5rLWJyYW5jaC1uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBCYW5rIEJyYW5jaCBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJiYW5rX2JyYW5jaF9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uYmFua19icmFuY2hfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYmFuay1icmFuY2gtbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBCYW5rIEJyYW5jaCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5iYW5rX2JyYW5jaF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5iYW5rX2JyYW5jaF9uYW1lLnRyaW0oKSA9PT0gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcmVkLTUwIGJvcmRlci1yZWQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSAke2ZpZWxkU2l6ZS5oZWlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiYWNjb3VudC1udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEJhbmsgQWNjb3VudCBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImJhbmtfYWNjb3VudF9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5iYW5rX2FjY291bnRfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJhY2NvdW50LW51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBDdXN0b21lciBCYW5rIEFjY291bnQgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5iYW5rX2FjY291bnRfbnVtYmVyIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5iYW5rX2FjY291bnRfbnVtYmVyLnRyaW0oKSA9PT0gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcmVkLTUwIGJvcmRlci1yZWQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSAke2ZpZWxkU2l6ZS5oZWlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlmc2NcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEJhbmsgSUZTQyBDb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJiYW5rX0lGU0NfY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmJhbmtfSUZTQ19jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpZnNjXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEJhbmsgSUZTQyBDb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7IXVwZGF0ZUZvcm1EYXRhPy5iYW5rX0lGU0NfY29kZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uYmFua19JRlNDX2NvZGUudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogTkVXOiBQYXltZW50IFR5cGUgKyBQYXltZW50IEFtb3VudCAoVXBkYXRlIG1vZGFsIOKAlCBubyBzdGVwcGVyKSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8UmFkaW8uR3JvdXBcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJpbnN0YWxsbWVudF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uaW5zdGFsbG1lbnRfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiaW5zdGFsbG1lbnRfdHlwZVwiLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8UmFkaW8gdmFsdWU9XCJkYWlseVwiPkRhaWx5PC9SYWRpbz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSYWRpbyB2YWx1ZT1cIndlZWtseVwiPldlZWtseTwvUmFkaW8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8UmFkaW8gdmFsdWU9XCJtb250aGx5XCI+TW9udGhseTwvUmFkaW8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9SYWRpby5Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImluc3RhbGxtZW50X2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiaW5zdGFsbG1lbnRfYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uaW5zdGFsbG1lbnRfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnN0YWxsbWVudF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQYXltZW50IEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2AkeyF1cGRhdGVGb3JtRGF0YT8uaW5zdGFsbG1lbnRfYW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICR7ZmllbGRTaXplLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQVRUQUNIIERPQ1VNRU5UICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBMYWJlbCAqL31cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwaG90b1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQaG90b1xyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFVwbG9hZCAvIFByZXZpZXcgQm94ICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMzIgdy1mdWxsIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgcm91bmRlZC1sZyBvdmVyZmxvdy1oaWRkZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcGhvdG9JbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfT5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHJlZj17cGhvdG9JbnB1dFJlZn1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiLmpwZWcsLmpwZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFmaWxlKSByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAhZmlsZS50eXBlLnN0YXJ0c1dpdGgoXCJpbWFnZS9qcGVnXCIpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIWZpbGUudHlwZS5zdGFydHNXaXRoKFwiaW1hZ2UvanBnXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFsZXJ0KFwiT25seSBKUEVHIGltYWdlcyBhcmUgYWxsb3dlZCFcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEF0dGFjaG1lbnRzKFtmaWxlXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBQbGFjZWhvbGRlciBvciBJbWFnZSBQcmV2aWV3ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIHthdHRhY2htZW50cy5sZW5ndGggPT09IDAgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICF1cGRhdGVGb3JtRGF0YT8ucHJvZmlsZXBob3RvID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwb2ludGVyLWV2ZW50cy1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDbG91ZFVwbG9hZCBzaXplPXs0MH0gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBtYi0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQXR0YWNoIFBob3RvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgSlBFRyBvbmx5IChNYXggNU1CKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLWZ1bGwgdy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0YWNobWVudHM/Lmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBVUkwuY3JlYXRlT2JqZWN0VVJMKGF0dGFjaG1lbnRzWzBdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHVwZGF0ZUZvcm1EYXRhPy5wcm9maWxlcGhvdG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwicHJldmlld1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHctZnVsbCBvYmplY3QtY29udGFpbiByb3VuZGVkXCIgLy8gPC0tIGNoYW5nZWQgb2JqZWN0LWNvdmVyIHRvIG9iamVjdC1jb250YWluXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1ByZXZpZXcodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogUmVtb3ZlICYgRG93bmxvYWQgQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMSByaWdodC0xIGZsZXggc3BhY2UteC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhhdHRhY2htZW50cz8ubGVuZ3RoID4gMCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LnByb2ZpbGVwaG90bykgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0YWNobWVudHM/Lmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBVUkwuY3JlYXRlT2JqZWN0VVJMKGF0dGFjaG1lbnRzWzBdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHVwZGF0ZUZvcm1EYXRhPy5wcm9maWxlcGhvdG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0YWNobWVudHM/Lmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBhdHRhY2htZW50c1swXS5uYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNTAwIHRleHQtd2hpdGUgcm91bmRlZC1mdWxsIHAtMSBob3ZlcjpiZy1ibHVlLTYwMCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERvd25sb2FkIHNpemU9ezEyfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEZ1bGxzY3JlZW4gTW9kYWwgUHJldmlldyAqL31cclxuICAgICAgICAgICAgICAgICAge3Nob3dQcmV2aWV3ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrIGJnLW9wYWNpdHktNzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei01MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UHJldmlldyhmYWxzZSl9IC8vIGNsb3NlIG9uIGJhY2tncm91bmQgY2xpY2tcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDbG9zZSBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UHJldmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIgcmlnaHQtMiB0ZXh0LXdoaXRlIGJnLWdyYXktODAwIGJnLW9wYWNpdHktNzAgaG92ZXI6YmctZ3JheS03MDAgcm91bmRlZC1mdWxsIHAtMiBzaGFkb3ctbGcgei0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRnVsbHNjcmVlbiBJbWFnZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRhY2htZW50cz8ubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFVSTC5jcmVhdGVPYmplY3RVUkwoYXR0YWNobWVudHNbMF0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdXBkYXRlRm9ybURhdGE/LnByb2ZpbGVwaG90b1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJsYXJnZSBwcmV2aWV3XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYXgtaC1bOTB2aF0gbWF4LXctWzkwdnddIHJvdW5kZWQtbGcgc2hhZG93LWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFVwZGF0ZVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBEZWxldGUgQ3VzdG9tZXJcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAge2N1cnJlbnRVc2VyICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlVXNlcigpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB0byBjb25maXJtIGRlbGV0aW9uLntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBVc2VyIEZ1bGwgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVc2VyOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Vc2VyLmpzeCJ9