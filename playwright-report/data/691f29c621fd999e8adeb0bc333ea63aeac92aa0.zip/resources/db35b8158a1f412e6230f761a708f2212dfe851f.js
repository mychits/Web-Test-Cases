import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PaymentLink.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Input, Select, Checkbox } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { FaMoneyBillWave } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const User = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [TableUsers, setTableUsers] = useState([]);
  const [showPaymentLinkModal, setShowPaymentLinkModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [groups, setGroups] = useState([]);
  const [areas, setAreas] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [searchText, setSearchText] = useState("");
  const [selectedCustomers, setSelectedCustomers] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [showAllCustomers, setShowAllCustomers] = useState(false);
  const [paymentLinkData, setPaymentLinkData] = useState({
    amount: "",
    purpose: "",
    expiry: "86400",
    notify_customer: true,
    send_sms: true,
    send_email: true
  });
  const [paymentLinkLoading, setPaymentLinkLoading] = useState(false);
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    const fetchCollectionArea = async () => {
      try {
        const response = await api.get(
          "/collection-area-request/get-collection-area-data"
        );
        setAreas(response.data);
      } catch (error) {
        console.error("Error fetching user ", error);
      }
    };
    fetchCollectionArea();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchDistricts = async () => {
      try {
        const response = await api.get("/user/district");
        setDistricts(response.data?.data?.districts);
      } catch (error) {
        console.error("Error fetching districts:", error);
      }
    };
    fetchDistricts();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/user/get-user");
        setUsers(response.data);
        const formattedData = response.data.map((group, index) => ({
          _id: group._id,
          id: index + 1,
          name: group.full_name,
          phone_number: group.phone_number,
          email: group.email,
          address: group.address,
          pincode: group.pincode,
          customer_id: group.customer_id,
          collection_area: group.collection_area?.route_name,
          approval_status: group.approval_status === "true" ? /* @__PURE__ */ jsxDEV("div", { className: "inline-block px-3 py-1 text-sm font-medium text-green-800 bg-green-100 rounded-full shadow-sm", children: "Approved" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
            lineNumber: 90,
            columnNumber: 11
          }, this) : group.approval_status === "false" ? /* @__PURE__ */ jsxDEV("div", { className: "inline-block px-3 py-1 text-sm font-medium text-red-800 bg-red-100 rounded-full shadow-sm", children: "Pending" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
            lineNumber: 94,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "inline-block px-3 py-1 text-sm font-medium text-green-800 bg-green-100  rounded-full shadow-sm", children: "Approved" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
            lineNumber: 98,
            columnNumber: 11
          }, this)
        }));
        let fData = formattedData.map((ele) => {
          if (ele?.address && typeof ele.address === "string" && ele?.address?.includes(","))
            ele.address = ele.address.replaceAll(",", " ");
          return ele;
        });
        setTableUsers(fData);
      } catch (error) {
        console.error("Error fetching user ", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUsers();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchGroupData = async () => {
      try {
        const res = await api.get("group/get-group-admin");
        setGroups(res.data);
      } catch (error) {
        console.error("Error fetching ", error);
      }
    };
    fetchGroupData();
  }, [reloadTrigger]);
  const getSelectedCustomerDetails = () => {
    return selectedCustomers.map((id) => {
      const customer = users.find((user) => user._id === id);
      return customer ? {
        phone_number: customer.phone_number,
        full_name: customer.full_name,
        email: customer.email,
        id: customer._id
      } : null;
    }).filter((customer) => customer);
  };
  const columns = [
    {
      key: "select",
      header: /* @__PURE__ */ jsxDEV(Checkbox, { checked: selectAll, onChange: (e) => handleSelectAll(e) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
        lineNumber: 153,
        columnNumber: 5
      }, this)
    },
    { key: "id", header: "SL. NO" },
    { key: "approval_status", header: "Approval Status" },
    { key: "customer_id", header: "Customer Id" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "address", header: "Customer Address" },
    { key: "pincode", header: "Customer Pincode" },
    { key: "collection_area", header: "Area" }
  ];
  const handleSelectCustomer = (customerId) => {
    setSelectedCustomers(
      (prev) => prev.includes(customerId) ? prev.filter((id) => id !== customerId) : [...prev, customerId]
    );
  };
  const handleSelectAll = (e) => {
    if (e.target.checked) {
      const allCustomerIds = TableUsers.map((user) => user._id);
      setSelectedCustomers(allCustomerIds);
    } else {
      setSelectedCustomers([]);
    }
    setSelectAll(e.target.checked);
    setShowAllCustomers(false);
  };
  const handlePaymentLinkChange = (e) => {
    const { name, value, type, checked } = e.target;
    setPaymentLinkData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };
  const handleGeneratePaymentLink = async () => {
    if (!paymentLinkData.amount || isNaN(paymentLinkData.amount) || paymentLinkData.amount <= 0) {
      setAlertConfig({
        visibility: true,
        message: "Please enter a valid amount",
        type: "error"
      });
      return;
    }
    if (!paymentLinkData.purpose.trim()) {
      setAlertConfig({
        visibility: true,
        message: "Purpose is required for payment link",
        type: "error"
      });
      return;
    }
    const customerDetails = getSelectedCustomerDetails();
    if (customerDetails.length === 0) {
      setAlertConfig({
        visibility: true,
        message: "No valid customers selected",
        type: "error"
      });
      return;
    }
    setPaymentLinkLoading(true);
    try {
      const response = await api.post("/paymentapi/create-payment", {
        customers: customerDetails,
        // Now includes phone_number, full_name, and email
        amount: paymentLinkData.amount,
        purpose: paymentLinkData.purpose,
        expiry: paymentLinkData.expiry,
        notify_customer: paymentLinkData.notify_customer,
        send_sms: paymentLinkData.send_sms,
        send_email: paymentLinkData.send_email
      });
      if (response.data.success) {
        setAlertConfig({
          visibility: true,
          message: `Payment links generated and sent to ${customerDetails.length} customer(s)`,
          type: "success"
        });
        setSelectedCustomers([]);
        setSelectAll(false);
        setShowPaymentLinkModal(false);
        setShowAllCustomers(false);
      } else {
        throw new Error(
          response.data.message || "Failed to generate payment links"
        );
      }
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: error.message || "Failed to generate payment links. Please try again.",
        type: "error"
      });
    } finally {
      setPaymentLinkLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
          lineNumber: 270,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
          lineNumber: 274,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Customers" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
            lineNumber: 285,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex space-x-4", children: selectedCustomers.length > 0 && /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setShowPaymentLinkModal(true),
              className: "bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                /* @__PURE__ */ jsxDEV(FaMoneyBillWave, { className: "mr-2" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                  lineNumber: 292,
                  columnNumber: 23
                }, this),
                "Generate Payment Links (",
                selectedCustomers.length,
                ")"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
              lineNumber: 288,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
            lineNumber: 286,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
          lineNumber: 284,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
          lineNumber: 283,
          columnNumber: 13
        }, this),
        TableUsers?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            data: TableUsers.map((user) => ({
              ...user,
              select: /* @__PURE__ */ jsxDEV(
                Checkbox,
                {
                  checked: selectedCustomers.includes(user._id),
                  onChange: () => handleSelectCustomer(user._id)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                  lineNumber: 305,
                  columnNumber: 17
                },
                this
              )
            })),
            columns,
            exportedPdfName: "Payment Link",
            exportedFileName: `Payment Link.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
            lineNumber: 300,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableUsers.length <= 0,
            data: "Customer Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
            lineNumber: 316,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
        lineNumber: 282,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
      lineNumber: 269,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showPaymentLinkModal,
        onClose: () => {
          setShowPaymentLinkModal(false);
          setShowAllCustomers(false);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-4", children: [
            /* @__PURE__ */ jsxDEV(FaMoneyBillWave, { className: "text-2xl text-green-600 mr-2" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
              lineNumber: 333,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Generate Payment Links" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
              lineNumber: 334,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
            lineNumber: 332,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 max-h-60 overflow-y-auto pr-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mb-2", children: [
              selectedCustomers.length,
              " customer",
              selectedCustomers.length !== 1 ? "s" : "",
              " selected:"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
              lineNumber: 341,
              columnNumber: 15
            }, this),
            getSelectedCustomerDetails().slice(0, showAllCustomers ? getSelectedCustomerDetails().length : 5).map(
              (customer, index) => /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "flex justify-between items-center bg-gray-50 border border-gray-200 rounded-lg p-3 mb-2",
                  children: /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-800", children: customer.full_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 352,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: [
                      "Phone: ",
                      customer.phone_number
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 353,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: [
                      "Email: ",
                      customer.email || "Not provided"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 354,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                    lineNumber: 351,
                    columnNumber: 19
                  }, this)
                },
                customer.id,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                  lineNumber: 347,
                  columnNumber: 15
                },
                this
              )
            ),
            getSelectedCustomerDetails().length > 5 && !showAllCustomers && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowAllCustomers(true),
                className: "text-violet-600 hover:text-violet-800 text-sm font-medium mt-2 flex items-center",
                children: [
                  "Show all ",
                  getSelectedCustomerDetails().length,
                  " customers"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                lineNumber: 361,
                columnNumber: 15
              },
              this
            ),
            showAllCustomers && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowAllCustomers(false),
                className: "text-gray-500 hover:text-gray-700 text-sm font-medium mt-2 flex items-center",
                children: "Show less"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                lineNumber: 371,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
            lineNumber: 340,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "form",
            {
              className: "space-y-6",
              onSubmit: (e) => {
                e.preventDefault();
                handleGeneratePaymentLink();
              },
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "amount",
                      children: [
                        "Amount (INR) ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                          lineNumber: 392,
                          columnNumber: 32
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 388,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      name: "amount",
                      value: paymentLinkData.amount,
                      onChange: handlePaymentLinkChange,
                      id: "amount",
                      placeholder: "Enter amount",
                      min: "1",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 394,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                  lineNumber: 387,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "purpose",
                      children: [
                        "Purpose ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                          lineNumber: 411,
                          columnNumber: 27
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 407,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      name: "purpose",
                      value: paymentLinkData.purpose,
                      onChange: handlePaymentLinkChange,
                      id: "purpose",
                      placeholder: "Enter payment purpose",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 413,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                  lineNumber: 406,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "expiry",
                      children: "Link Expiry"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 425,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select Expiry Time",
                      value: paymentLinkData.expiry,
                      onChange: (value) => setPaymentLinkData((prev) => ({ ...prev, expiry: value })),
                      children: [
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "86400", children: "24 hours" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                          lineNumber: 439,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "172800", children: "48 hours" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                          lineNumber: 440,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "259200", children: "72 hours" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                          lineNumber: 441,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "604800", children: "7 days" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                          lineNumber: 442,
                          columnNumber: 19
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 431,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Payment link will expire after selected time period" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                    lineNumber: 444,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                  lineNumber: 424,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "font-medium text-gray-900", children: "Notification Settings" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                    lineNumber: 449,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "pl-4 space-y-2", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                      /* @__PURE__ */ jsxDEV(
                        Checkbox,
                        {
                          checked: paymentLinkData.notify_customer,
                          onChange: handlePaymentLinkChange,
                          name: "notify_customer"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                          lineNumber: 454,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("label", { className: "ml-2 text-sm text-gray-700", children: "Notify customer about payment link" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                        lineNumber: 459,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 453,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                      /* @__PURE__ */ jsxDEV(
                        Checkbox,
                        {
                          checked: paymentLinkData.send_sms,
                          onChange: handlePaymentLinkChange,
                          name: "send_sms"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                          lineNumber: 464,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("label", { className: "ml-2 text-sm text-gray-700", children: "Send via SMS" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                        lineNumber: 469,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 463,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                      /* @__PURE__ */ jsxDEV(
                        Checkbox,
                        {
                          checked: paymentLinkData.send_email,
                          onChange: handlePaymentLinkChange,
                          name: "send_email"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                          lineNumber: 474,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("label", { className: "ml-2 text-sm text-gray-700", children: "Send via Email" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                        lineNumber: 479,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 473,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                    lineNumber: 452,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                  lineNumber: 448,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end space-x-3", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setShowPaymentLinkModal(false);
                        setShowAllCustomers(false);
                      },
                      className: "px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50",
                      children: "Cancel"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 486,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "submit",
                      disabled: paymentLinkLoading,
                      className: `w-auto px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${paymentLinkLoading ? "bg-violet-400" : "bg-violet-600 hover:bg-violet-700"} focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-violet-500`,
                      children: paymentLinkLoading ? /* @__PURE__ */ jsxDEV("span", { className: "flex items-center", children: [
                        /* @__PURE__ */ jsxDEV(
                          "svg",
                          {
                            className: "animate-spin -ml-1 mr-2 h-4 w-4 text-white",
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            children: [
                              /* @__PURE__ */ jsxDEV(
                                "circle",
                                {
                                  className: "opacity-25",
                                  cx: "12",
                                  cy: "12",
                                  r: "10",
                                  stroke: "currentColor",
                                  strokeWidth: "4"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                                  lineNumber: 513,
                                  columnNumber: 25
                                },
                                this
                              ),
                              /* @__PURE__ */ jsxDEV(
                                "path",
                                {
                                  className: "opacity-75",
                                  fill: "currentColor",
                                  d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                                  lineNumber: 521,
                                  columnNumber: 25
                                },
                                this
                              )
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                            lineNumber: 507,
                            columnNumber: 23
                          },
                          this
                        ),
                        "Generating..."
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                        lineNumber: 506,
                        columnNumber: 19
                      }, this) : "Generate & Send Links"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                      lineNumber: 496,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
                  lineNumber: 485,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
              lineNumber: 380,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
          lineNumber: 331,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
        lineNumber: 324,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
    lineNumber: 268,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx",
    lineNumber: 267,
    columnNumber: 5
  }, this);
};
_s(User, "eUzezYScvbJcDjtdOWsaO7lLeqw=");
_c = User;
export default User;
var _c;
$RefreshReg$(_c, "User");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLink.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUZjLFNBaUxWLFVBakxVOzJCQXpGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxPQUFPQyxRQUFRQyxnQkFBZ0I7QUFDeEMsU0FBU0MsdUJBQXVCO0FBQ2hDLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxpQkFBaUI7QUFFMUIsTUFBTUMsT0FBT0EsTUFBTTtBQUFBQyxLQUFBO0FBQ2pCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJZixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0IsWUFBWUMsYUFBYSxJQUFJakIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2tCLHNCQUFzQkMsdUJBQXVCLElBQUluQixTQUFTLEtBQUs7QUFDdEUsUUFBTSxDQUFDb0IsV0FBV0MsWUFBWSxJQUFJckIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3NCLFFBQVFDLFNBQVMsSUFBSXZCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUN3QixPQUFPQyxRQUFRLElBQUl6QixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDMEIsV0FBV0MsWUFBWSxJQUFJM0IsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzRCLGVBQWVDLGdCQUFnQixJQUFJN0IsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQzhCLGFBQWFDLGNBQWMsSUFBSS9CLFNBQVM7QUFBQSxJQUM3Q2dDLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJcEMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3FDLG1CQUFtQkMsb0JBQW9CLElBQUl0QyxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDdUMsV0FBV0MsWUFBWSxJQUFJeEMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3lDLGtCQUFrQkMsbUJBQW1CLElBQUkxQyxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDMkMsaUJBQWlCQyxrQkFBa0IsSUFBSTVDLFNBQVM7QUFBQSxJQUNyRDZDLFFBQVE7QUFBQSxJQUNSQyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLGlCQUFpQjtBQUFBLElBQ2pCQyxVQUFVO0FBQUEsSUFDVkMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUNELFFBQU0sQ0FBQ0Msb0JBQW9CQyxxQkFBcUIsSUFBSXBELFNBQVMsS0FBSztBQUVsRSxRQUFNcUQsNEJBQTRCQSxDQUFDQyxNQUFNO0FBQ3ZDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQnBCLGtCQUFjbUIsS0FBSztBQUFBLEVBQ3JCO0FBRUF4RCxZQUFVLE1BQU07QUFDZCxVQUFNMEQsc0JBQXNCLFlBQVk7QUFDdEMsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTXhELElBQUl5RDtBQUFBQSxVQUN6QjtBQUFBLFFBQ0Y7QUFDQWxDLGlCQUFTaUMsU0FBU0UsSUFBSTtBQUFBLE1BQ3hCLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsTUFDN0M7QUFBQSxJQUNGO0FBQ0FKLHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsQ0FBQzdCLGFBQWEsQ0FBQztBQUVsQjdCLFlBQVUsTUFBTTtBQUNkLFVBQU1nRSxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTUwsV0FBVyxNQUFNeEQsSUFBSXlELElBQUksZ0JBQWdCO0FBQy9DaEMscUJBQWErQixTQUFTRSxNQUFNQSxNQUFNbEMsU0FBUztBQUFBLE1BQzdDLFNBQVNtQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUNBRSxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQ25DLGFBQWEsQ0FBQztBQUVsQjdCLFlBQVUsTUFBTTtBQUNkLFVBQU1pRSxhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGM0MscUJBQWEsSUFBSTtBQUNqQixjQUFNcUMsV0FBVyxNQUFNeEQsSUFBSXlELElBQUksZ0JBQWdCO0FBQy9DNUMsaUJBQVMyQyxTQUFTRSxJQUFJO0FBQ3RCLGNBQU1LLGdCQUFnQlAsU0FBU0UsS0FBS00sSUFBSSxDQUFDQyxPQUFPQyxXQUFXO0FBQUEsVUFDekRDLEtBQUtGLE1BQU1FO0FBQUFBLFVBQ1hDLElBQUlGLFFBQVE7QUFBQSxVQUNaRyxNQUFNSixNQUFNSztBQUFBQSxVQUNaQyxjQUFjTixNQUFNTTtBQUFBQSxVQUNwQkMsT0FBT1AsTUFBTU87QUFBQUEsVUFDYkMsU0FBU1IsTUFBTVE7QUFBQUEsVUFDZkMsU0FBU1QsTUFBTVM7QUFBQUEsVUFDZkMsYUFBYVYsTUFBTVU7QUFBQUEsVUFDbkJDLGlCQUFpQlgsTUFBTVcsaUJBQWlCQztBQUFBQSxVQUN4Q0MsaUJBQ0ViLE1BQU1hLG9CQUFvQixTQUN4Qix1QkFBQyxTQUFJLFdBQVUsaUdBQWdHLHdCQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBQ0ViLE1BQU1hLG9CQUFvQixVQUM1Qix1QkFBQyxTQUFJLFdBQVUsNkZBQTRGLHVCQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtHQUFpRyx3QkFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFFBRU4sRUFBRTtBQUNGLFlBQUlDLFFBQVFoQixjQUFjQyxJQUFJLENBQUNnQixRQUFRO0FBQ3JDLGNBQ0VBLEtBQUtQLFdBQ0wsT0FBT08sSUFBSVAsWUFBWSxZQUN2Qk8sS0FBS1AsU0FBU1EsU0FBUyxHQUFHO0FBRTFCRCxnQkFBSVAsVUFBVU8sSUFBSVAsUUFBUVMsV0FBVyxLQUFLLEdBQUc7QUFDL0MsaUJBQU9GO0FBQUFBLFFBQ1QsQ0FBQztBQUNEakUsc0JBQWNnRSxLQUFLO0FBQUEsTUFDckIsU0FBU3BCLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0JBQXdCQSxNQUFNNUIsT0FBTztBQUFBLE1BQ3JELFVBQUM7QUFDQ1oscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBMkMsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDcEMsYUFBYSxDQUFDO0FBRWxCN0IsWUFBVSxNQUFNO0FBQ2QsVUFBTXNGLGlCQUFpQixZQUFZO0FBQ2pDLFVBQUk7QUFDRixjQUFNQyxNQUFNLE1BQU1wRixJQUFJeUQsSUFBSSx1QkFBdUI7QUFDakRwQyxrQkFBVStELElBQUkxQixJQUFJO0FBQUEsTUFDcEIsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxtQkFBbUJBLEtBQUs7QUFBQSxNQUN4QztBQUFBLElBQ0Y7QUFDQXdCLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxDQUFDekQsYUFBYSxDQUFDO0FBR2xCLFFBQU0yRCw2QkFBNkJBLE1BQU07QUFDdkMsV0FBT2xELGtCQUNKNkIsSUFBSSxDQUFBSSxPQUFNO0FBQ1QsWUFBTWtCLFdBQVcxRSxNQUFNMkUsS0FBSyxDQUFBQyxTQUFRQSxLQUFLckIsUUFBUUMsRUFBRTtBQUNuRCxhQUFPa0IsV0FBVztBQUFBLFFBQ2hCZixjQUFjZSxTQUFTZjtBQUFBQSxRQUN2QkQsV0FBV2dCLFNBQVNoQjtBQUFBQSxRQUNwQkUsT0FBT2MsU0FBU2Q7QUFBQUEsUUFDaEJKLElBQUlrQixTQUFTbkI7QUFBQUEsTUFDZixJQUFJO0FBQUEsSUFDTixDQUFDLEVBQ0FzQixPQUFPLENBQUFILGFBQVlBLFFBQVE7QUFBQSxFQUNoQztBQUVBLFFBQU1JLFVBQVU7QUFBQSxJQUNkO0FBQUEsTUFDRUMsS0FBSztBQUFBLE1BQ0xDLFFBQ0UsdUJBQUMsWUFBUyxTQUFTdkQsV0FBVyxVQUFVLENBQUNlLE1BQU15QyxnQkFBZ0J6QyxDQUFDLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0U7QUFBQSxJQUV0RTtBQUFBLElBQ0EsRUFBRXVDLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsd0JBQXdCO0FBQUEsSUFDdkQsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLG1CQUFtQjtBQUFBLElBQzdDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxtQkFBbUI7QUFBQSxJQUM3QyxFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxPQUFPO0FBQUEsRUFBQztBQUc1QyxRQUFNRSx1QkFBdUJBLENBQUNDLGVBQWU7QUFDM0MzRDtBQUFBQSxNQUFxQixDQUFDNEQsU0FDcEJBLEtBQUtmLFNBQVNjLFVBQVUsSUFDcEJDLEtBQUtQLE9BQU8sQ0FBQ3JCLE9BQU9BLE9BQU8yQixVQUFVLElBQ3JDLENBQUMsR0FBR0MsTUFBTUQsVUFBVTtBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUVBLFFBQU1GLGtCQUFrQkEsQ0FBQ3pDLE1BQU07QUFDN0IsUUFBSUEsRUFBRUUsT0FBTzJDLFNBQVM7QUFDcEIsWUFBTUMsaUJBQWlCcEYsV0FBV2tELElBQUksQ0FBQ3dCLFNBQVNBLEtBQUtyQixHQUFHO0FBQ3hEL0IsMkJBQXFCOEQsY0FBYztBQUFBLElBQ3JDLE9BQU87QUFDTDlELDJCQUFxQixFQUFFO0FBQUEsSUFDekI7QUFDQUUsaUJBQWFjLEVBQUVFLE9BQU8yQyxPQUFPO0FBQzdCekQsd0JBQW9CLEtBQUs7QUFBQSxFQUMzQjtBQUVBLFFBQU0yRCwwQkFBMEJBLENBQUMvQyxNQUFNO0FBQ3JDLFVBQU0sRUFBRWlCLE1BQU1oQixPQUFPckIsTUFBTWlFLFFBQVEsSUFBSTdDLEVBQUVFO0FBQ3pDWix1QkFBbUIsQ0FBQ3NELFVBQVU7QUFBQSxNQUM1QixHQUFHQTtBQUFBQSxNQUNILENBQUMzQixJQUFJLEdBQUdyQyxTQUFTLGFBQWFpRSxVQUFVNUM7QUFBQUEsSUFDMUMsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNK0MsNEJBQTRCLFlBQVk7QUFDNUMsUUFDRSxDQUFDM0QsZ0JBQWdCRSxVQUNqQjBELE1BQU01RCxnQkFBZ0JFLE1BQU0sS0FDNUJGLGdCQUFnQkUsVUFBVSxHQUMxQjtBQUNBZCxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQ1MsZ0JBQWdCRyxRQUFRMEQsS0FBSyxHQUFHO0FBQ25DekUscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFFQSxVQUFNdUUsa0JBQWtCbEIsMkJBQTJCO0FBRW5ELFFBQUlrQixnQkFBZ0JDLFdBQVcsR0FBRztBQUNoQzNFLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0Q7QUFBQSxJQUNGO0FBRUFrQiwwQkFBc0IsSUFBSTtBQUMxQixRQUFJO0FBQ0YsWUFBTU0sV0FBVyxNQUFNeEQsSUFBSXlHLEtBQUssOEJBQThCO0FBQUEsUUFDNURDLFdBQVdIO0FBQUFBO0FBQUFBLFFBQ1g1RCxRQUFRRixnQkFBZ0JFO0FBQUFBLFFBQ3hCQyxTQUFTSCxnQkFBZ0JHO0FBQUFBLFFBQ3pCQyxRQUFRSixnQkFBZ0JJO0FBQUFBLFFBQ3hCQyxpQkFBaUJMLGdCQUFnQks7QUFBQUEsUUFDakNDLFVBQVVOLGdCQUFnQk07QUFBQUEsUUFDMUJDLFlBQVlQLGdCQUFnQk87QUFBQUEsTUFDOUIsQ0FBQztBQUVELFVBQUlRLFNBQVNFLEtBQUtpRCxTQUFTO0FBQ3pCOUUsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUyx1Q0FBdUN3RSxnQkFBZ0JDLE1BQU07QUFBQSxVQUN0RXhFLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDREksNkJBQXFCLEVBQUU7QUFDdkJFLHFCQUFhLEtBQUs7QUFDbEJyQixnQ0FBd0IsS0FBSztBQUM3QnVCLDRCQUFvQixLQUFLO0FBQUEsTUFDM0IsT0FBTztBQUNMLGNBQU0sSUFBSW9FO0FBQUFBLFVBQ1JwRCxTQUFTRSxLQUFLM0IsV0FBVztBQUFBLFFBQzNCO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBUzRCLE9BQU87QUFDZDlCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQ0U0QixNQUFNNUIsV0FDTjtBQUFBLFFBQ0ZDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ2tCLDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCQztBQUFBQSxVQUM3QixZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNdkIsWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUNtRSxVQUFVLEVBQUUsR0FBR0EsTUFBTWxFLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNRztBQUFBLE1BRUgsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBCQUF5Qix5QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUNoRCx1QkFBQyxTQUFJLFdBQVUsa0JBQ1pLLDRCQUFrQnFFLFNBQVMsS0FDMUI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTXZGLHdCQUF3QixJQUFJO0FBQUEsY0FDM0MsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxtQkFBZ0IsV0FBVSxVQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBLGdCQUFHO0FBQUEsZ0JBQ1hrQixrQkFBa0JxRTtBQUFBQSxnQkFBTztBQUFBO0FBQUE7QUFBQSxZQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQSxLQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBQ0MxRixZQUFZMEYsU0FBUyxLQUFLLENBQUN0RixZQUMxQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsTUFBTUosV0FBV2tELElBQUksQ0FBQ3dCLFVBQVU7QUFBQSxjQUM5QixHQUFHQTtBQUFBQSxjQUNIcUIsUUFDRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTMUUsa0JBQWtCOEMsU0FBU08sS0FBS3JCLEdBQUc7QUFBQSxrQkFDNUMsVUFBVSxNQUFNMkIscUJBQXFCTixLQUFLckIsR0FBRztBQUFBO0FBQUEsZ0JBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUVpRDtBQUFBLFlBR3JELEVBQUU7QUFBQSxZQUNGO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBa0I7QUFBQTtBQUFBLFVBYnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWF1QyxJQUd2QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFNBQVNyRCxXQUFXMEYsVUFBVTtBQUFBLFlBQzlCLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3NCO0FBQUEsV0FyQzFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3Q0E7QUFBQSxTQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0RBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3hGO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLGtDQUF3QixLQUFLO0FBQzdCdUIsOEJBQW9CLEtBQUs7QUFBQSxRQUMzQjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsbUNBQUMsbUJBQWdCLFdBQVUsa0NBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQsdUJBQUMsUUFBRyxXQUFVLG1DQUFrQyxzQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHNCQUNWTDtBQUFBQSxnQ0FBa0JxRTtBQUFBQSxjQUFPO0FBQUEsY0FBVXJFLGtCQUFrQnFFLFdBQVcsSUFBSSxNQUFNO0FBQUEsY0FBRztBQUFBLGlCQURoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHQ25CLDJCQUEyQixFQUFFeUIsTUFBTSxHQUFHdkUsbUJBQW1COEMsMkJBQTJCLEVBQUVtQixTQUFTLENBQUMsRUFBRXhDO0FBQUFBLGNBQUksQ0FBQ3NCLFVBQVVwQixVQUNoSDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxXQUFVO0FBQUEsa0JBRVYsaUNBQUMsU0FDQztBQUFBLDJDQUFDLFNBQUksV0FBVSw2QkFBNkJvQixtQkFBU2hCLGFBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStEO0FBQUEsb0JBQy9ELHVCQUFDLFNBQUksV0FBVSx5QkFBd0I7QUFBQTtBQUFBLHNCQUFRZ0IsU0FBU2Y7QUFBQUEseUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFFO0FBQUEsb0JBQ3JFLHVCQUFDLFNBQUksV0FBVSx5QkFBd0I7QUFBQTtBQUFBLHNCQUFRZSxTQUFTZCxTQUFTO0FBQUEseUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdGO0FBQUEsdUJBSGxGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQTtBQUFBLGdCQVBLYyxTQUFTbEI7QUFBQUEsZ0JBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLFlBQ0Q7QUFBQSxZQUdBaUIsMkJBQTJCLEVBQUVtQixTQUFTLEtBQUssQ0FBQ2pFLG9CQUMzQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUMsb0JBQW9CLElBQUk7QUFBQSxnQkFDdkMsV0FBVTtBQUFBLGdCQUFrRjtBQUFBO0FBQUEsa0JBRWxGNkMsMkJBQTJCLEVBQUVtQjtBQUFBQSxrQkFBTztBQUFBO0FBQUE7QUFBQSxjQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBSURqRSxvQkFDQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUMsb0JBQW9CLEtBQUs7QUFBQSxnQkFDeEMsV0FBVTtBQUFBLGdCQUE4RTtBQUFBO0FBQUEsY0FGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQXBDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNDQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFVBQVUsQ0FBQ1ksTUFBTTtBQUNmQSxrQkFBRTJELGVBQWU7QUFDakJYLDBDQUEwQjtBQUFBLGNBQzVCO0FBQUEsY0FFQTtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFRO0FBQUE7QUFBQSx3QkFFSCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdDO0FBQUE7QUFBQTtBQUFBLG9CQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLE9BQU8zRCxnQkFBZ0JFO0FBQUFBLHNCQUN2QixVQUFVd0Q7QUFBQUEsc0JBQ1YsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWixLQUFJO0FBQUEsc0JBQ0o7QUFBQSxzQkFDQSxXQUFXLHFDQUFxQzFGLFVBQVV1RyxNQUFNO0FBQUE7QUFBQSxvQkFUbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNpSztBQUFBLHFCQWhCbks7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQkE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBUztBQUFBO0FBQUEsd0JBRVQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBO0FBQUE7QUFBQSxvQkFKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxPQUFPdkUsZ0JBQWdCRztBQUFBQSxzQkFDdkIsVUFBVXVEO0FBQUFBLHNCQUNWLElBQUc7QUFBQSxzQkFDSCxhQUFZO0FBQUEsc0JBQ1o7QUFBQSxzQkFDQSxXQUFXLHFDQUFxQzFGLFVBQVV1RyxNQUFNO0FBQUE7QUFBQSxvQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVFpSztBQUFBLHFCQWZuSztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFRO0FBQUE7QUFBQSxvQkFGbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixPQUFPdkUsZ0JBQWdCSTtBQUFBQSxzQkFDdkIsVUFBVSxDQUFDUSxVQUNUWCxtQkFBbUIsQ0FBQ3NELFVBQVUsRUFBRSxHQUFHQSxNQUFNbkQsUUFBUVEsTUFBTSxFQUFFO0FBQUEsc0JBRzNEO0FBQUEsK0NBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxTQUFRLHdCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxQztBQUFBLHdCQUNyQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsd0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXNDO0FBQUEsd0JBQ3RDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFBUyx3QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBc0M7QUFBQSx3QkFDdEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFvQztBQUFBO0FBQUE7QUFBQSxvQkFYdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVlBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixtRUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVCQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLDZCQUE0QixxQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFNBQVNaLGdCQUFnQks7QUFBQUEsMEJBQ3pCLFVBQVVxRDtBQUFBQSwwQkFDVixNQUFLO0FBQUE7QUFBQSx3QkFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBR3dCO0FBQUEsc0JBRXhCLHVCQUFDLFdBQU0sV0FBVSw4QkFBNkIsa0RBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsU0FBUzFELGdCQUFnQk07QUFBQUEsMEJBQ3pCLFVBQVVvRDtBQUFBQSwwQkFDVixNQUFLO0FBQUE7QUFBQSx3QkFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBR2lCO0FBQUEsc0JBRWpCLHVCQUFDLFdBQU0sV0FBVSw4QkFBNkIsNEJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsU0FBUzFELGdCQUFnQk87QUFBQUEsMEJBQ3pCLFVBQVVtRDtBQUFBQSwwQkFDVixNQUFLO0FBQUE7QUFBQSx3QkFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBR21CO0FBQUEsc0JBRW5CLHVCQUFDLFdBQU0sV0FBVSw4QkFBNkIsOEJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBO0FBQUEsdUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0JBO0FBQUEscUJBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0NBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTTtBQUNibEYsZ0RBQXdCLEtBQUs7QUFDN0J1Qiw0Q0FBb0IsS0FBSztBQUFBLHNCQUMzQjtBQUFBLHNCQUNBLFdBQVU7QUFBQSxzQkFBZ0c7QUFBQTtBQUFBLG9CQU41RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsVUFBVVM7QUFBQUEsc0JBQ1YsV0FBVyxrR0FDVEEscUJBQ0ksa0JBQ0EsbUNBQW1DO0FBQUEsc0JBR3hDQSwrQkFDQyx1QkFBQyxVQUFLLFdBQVUscUJBQ2Q7QUFBQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsT0FBTTtBQUFBLDRCQUNOLE1BQUs7QUFBQSw0QkFDTCxTQUFRO0FBQUEsNEJBRVI7QUFBQTtBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FDQyxXQUFVO0FBQUEsa0NBQ1YsSUFBRztBQUFBLGtDQUNILElBQUc7QUFBQSxrQ0FDSCxHQUFFO0FBQUEsa0NBQ0YsUUFBTztBQUFBLGtDQUNQLGFBQVk7QUFBQTtBQUFBLGdDQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFPQztBQUFBLDhCQUNEO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLFdBQVU7QUFBQSxrQ0FDVixNQUFLO0FBQUEsa0NBQ0wsR0FBRTtBQUFBO0FBQUEsZ0NBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUlDO0FBQUE7QUFBQTtBQUFBLDBCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBbUJBO0FBQUEsd0JBQU07QUFBQSwyQkFwQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFzQkEsSUFFQTtBQUFBO0FBQUEsb0JBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFvQ0E7QUFBQSxxQkEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnREE7QUFBQTtBQUFBO0FBQUEsWUF6SkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBMEpBO0FBQUEsYUEzTUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRNQTtBQUFBO0FBQUEsTUFuTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBb05BO0FBQUEsT0E1UUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZRQSxLQTlRRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK1FBO0FBRUo7QUFBRXRDLEdBL2dCSUQsTUFBSTtBQUFBdUcsS0FBSnZHO0FBaWhCTixlQUFlQTtBQUFLLElBQUF1RztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIklucHV0IiwiU2VsZWN0IiwiQ2hlY2tib3giLCJGYU1vbmV5QmlsbFdhdmUiLCJOYXZiYXIiLCJDaXJjdWxhckxvYWRlciIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiZmllbGRTaXplIiwiVXNlciIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsIlRhYmxlVXNlcnMiLCJzZXRUYWJsZVVzZXJzIiwic2hvd1BheW1lbnRMaW5rTW9kYWwiLCJzZXRTaG93UGF5bWVudExpbmtNb2RhbCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImdyb3VwcyIsInNldEdyb3VwcyIsImFyZWFzIiwic2V0QXJlYXMiLCJkaXN0cmljdHMiLCJzZXREaXN0cmljdHMiLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInNlbGVjdGVkQ3VzdG9tZXJzIiwic2V0U2VsZWN0ZWRDdXN0b21lcnMiLCJzZWxlY3RBbGwiLCJzZXRTZWxlY3RBbGwiLCJzaG93QWxsQ3VzdG9tZXJzIiwic2V0U2hvd0FsbEN1c3RvbWVycyIsInBheW1lbnRMaW5rRGF0YSIsInNldFBheW1lbnRMaW5rRGF0YSIsImFtb3VudCIsInB1cnBvc2UiLCJleHBpcnkiLCJub3RpZnlfY3VzdG9tZXIiLCJzZW5kX3NtcyIsInNlbmRfZW1haWwiLCJwYXltZW50TGlua0xvYWRpbmciLCJzZXRQYXltZW50TGlua0xvYWRpbmciLCJHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwiZmV0Y2hDb2xsZWN0aW9uQXJlYSIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImZldGNoRGlzdHJpY3RzIiwiZmV0Y2hVc2VycyIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJncm91cCIsImluZGV4IiwiX2lkIiwiaWQiLCJuYW1lIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZW1haWwiLCJhZGRyZXNzIiwicGluY29kZSIsImN1c3RvbWVyX2lkIiwiY29sbGVjdGlvbl9hcmVhIiwicm91dGVfbmFtZSIsImFwcHJvdmFsX3N0YXR1cyIsImZEYXRhIiwiZWxlIiwiaW5jbHVkZXMiLCJyZXBsYWNlQWxsIiwiZmV0Y2hHcm91cERhdGEiLCJyZXMiLCJnZXRTZWxlY3RlZEN1c3RvbWVyRGV0YWlscyIsImN1c3RvbWVyIiwiZmluZCIsInVzZXIiLCJmaWx0ZXIiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwiaGFuZGxlU2VsZWN0QWxsIiwiaGFuZGxlU2VsZWN0Q3VzdG9tZXIiLCJjdXN0b21lcklkIiwicHJldiIsImNoZWNrZWQiLCJhbGxDdXN0b21lcklkcyIsImhhbmRsZVBheW1lbnRMaW5rQ2hhbmdlIiwiaGFuZGxlR2VuZXJhdGVQYXltZW50TGluayIsImlzTmFOIiwidHJpbSIsImN1c3RvbWVyRGV0YWlscyIsImxlbmd0aCIsInBvc3QiLCJjdXN0b21lcnMiLCJzdWNjZXNzIiwiRXJyb3IiLCJzZWxlY3QiLCJzbGljZSIsInByZXZlbnREZWZhdWx0IiwiaGVpZ2h0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGF5bWVudExpbmsuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgSW5wdXQsIFNlbGVjdCwgQ2hlY2tib3ggfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBGYU1vbmV5QmlsbFdhdmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5cclxuY29uc3QgVXNlciA9ICgpID0+IHtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVVc2Vycywgc2V0VGFibGVVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3Nob3dQYXltZW50TGlua01vZGFsLCBzZXRTaG93UGF5bWVudExpbmtNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthcmVhcywgc2V0QXJlYXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtkaXN0cmljdHMsIHNldERpc3RyaWN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRDdXN0b21lcnMsIHNldFNlbGVjdGVkQ3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0QWxsLCBzZXRTZWxlY3RBbGxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93QWxsQ3VzdG9tZXJzLCBzZXRTaG93QWxsQ3VzdG9tZXJzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGF5bWVudExpbmtEYXRhLCBzZXRQYXltZW50TGlua0RhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcHVycG9zZTogXCJcIixcclxuICAgIGV4cGlyeTogXCI4NjQwMFwiLFxyXG4gICAgbm90aWZ5X2N1c3RvbWVyOiB0cnVlLFxyXG4gICAgc2VuZF9zbXM6IHRydWUsXHJcbiAgICBzZW5kX2VtYWlsOiB0cnVlLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtwYXltZW50TGlua0xvYWRpbmcsIHNldFBheW1lbnRMaW5rTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgXHJcbiAgY29uc3QgR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaENvbGxlY3Rpb25BcmVhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIFwiL2NvbGxlY3Rpb24tYXJlYS1yZXF1ZXN0L2dldC1jb2xsZWN0aW9uLWFyZWEtZGF0YVwiXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRBcmVhcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hDb2xsZWN0aW9uQXJlYSgpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaERpc3RyaWN0cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9kaXN0cmljdFwiKTtcclxuICAgICAgICBzZXREaXN0cmljdHMocmVzcG9uc2UuZGF0YT8uZGF0YT8uZGlzdHJpY3RzKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZGlzdHJpY3RzOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaERpc3RyaWN0cygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgIG5hbWU6IGdyb3VwLmZ1bGxfbmFtZSxcclxuICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXAucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgZW1haWw6IGdyb3VwLmVtYWlsLFxyXG4gICAgICAgICAgYWRkcmVzczogZ3JvdXAuYWRkcmVzcyxcclxuICAgICAgICAgIHBpbmNvZGU6IGdyb3VwLnBpbmNvZGUsXHJcbiAgICAgICAgICBjdXN0b21lcl9pZDogZ3JvdXAuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICBjb2xsZWN0aW9uX2FyZWE6IGdyb3VwLmNvbGxlY3Rpb25fYXJlYT8ucm91dGVfbmFtZSxcclxuICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czpcclxuICAgICAgICAgICAgZ3JvdXAuYXBwcm92YWxfc3RhdHVzID09PSBcInRydWVcIiA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0zIHB5LTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTgwMCBiZy1ncmVlbi0xMDAgcm91bmRlZC1mdWxsIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgQXBwcm92ZWRcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IGdyb3VwLmFwcHJvdmFsX3N0YXR1cyA9PT0gXCJmYWxzZVwiID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTMgcHktMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcmVkLTgwMCBiZy1yZWQtMTAwIHJvdW5kZWQtZnVsbCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIFBlbmRpbmdcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0zIHB5LTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTgwMCBiZy1ncmVlbi0xMDAgIHJvdW5kZWQtZnVsbCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIEFwcHJvdmVkXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIGxldCBmRGF0YSA9IGZvcm1hdHRlZERhdGEubWFwKChlbGUpID0+IHtcclxuICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgZWxlPy5hZGRyZXNzICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBlbGUuYWRkcmVzcyA9PT0gXCJzdHJpbmdcIiAmJlxyXG4gICAgICAgICAgICBlbGU/LmFkZHJlc3M/LmluY2x1ZGVzKFwiLFwiKVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgICAgICBlbGUuYWRkcmVzcyA9IGVsZS5hZGRyZXNzLnJlcGxhY2VBbGwoXCIsXCIsIFwiIFwiKTtcclxuICAgICAgICAgIHJldHVybiBlbGU7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0VGFibGVVc2VycyhmRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgXCIsIGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCJncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlcy5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgXCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoR3JvdXBEYXRhKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuICBcclxuICAvLyBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IGNvbXBsZXRlIGN1c3RvbWVyIGRldGFpbHMgZm9yIHNlbGVjdGVkIElEc1xyXG4gIGNvbnN0IGdldFNlbGVjdGVkQ3VzdG9tZXJEZXRhaWxzID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIHNlbGVjdGVkQ3VzdG9tZXJzXHJcbiAgICAgIC5tYXAoaWQgPT4ge1xyXG4gICAgICAgIGNvbnN0IGN1c3RvbWVyID0gdXNlcnMuZmluZCh1c2VyID0+IHVzZXIuX2lkID09PSBpZCk7XHJcbiAgICAgICAgcmV0dXJuIGN1c3RvbWVyID8geyBcclxuICAgICAgICAgIHBob25lX251bWJlcjogY3VzdG9tZXIucGhvbmVfbnVtYmVyLCBcclxuICAgICAgICAgIGZ1bGxfbmFtZTogY3VzdG9tZXIuZnVsbF9uYW1lLFxyXG4gICAgICAgICAgZW1haWw6IGN1c3RvbWVyLmVtYWlsLFxyXG4gICAgICAgICAgaWQ6IGN1c3RvbWVyLl9pZFxyXG4gICAgICAgIH0gOiBudWxsO1xyXG4gICAgICB9KVxyXG4gICAgICAuZmlsdGVyKGN1c3RvbWVyID0+IGN1c3RvbWVyKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAge1xyXG4gICAgICBrZXk6IFwic2VsZWN0XCIsXHJcbiAgICAgIGhlYWRlcjogKFxyXG4gICAgICAgIDxDaGVja2JveCBjaGVja2VkPXtzZWxlY3RBbGx9IG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VsZWN0QWxsKGUpfSAvPlxyXG4gICAgICApLFxyXG4gICAgfSxcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYXBwcm92YWxfc3RhdHVzXCIsIGhlYWRlcjogXCJBcHByb3ZhbCBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfaWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRkcmVzc1wiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgQWRkcmVzc1wiIH0sXHJcbiAgICB7IGtleTogXCJwaW5jb2RlXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaW5jb2RlXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25fYXJlYVwiLCBoZWFkZXI6IFwiQXJlYVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0Q3VzdG9tZXIgPSAoY3VzdG9tZXJJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRDdXN0b21lcnMoKHByZXYpID0+XHJcbiAgICAgIHByZXYuaW5jbHVkZXMoY3VzdG9tZXJJZClcclxuICAgICAgICA/IHByZXYuZmlsdGVyKChpZCkgPT4gaWQgIT09IGN1c3RvbWVySWQpXHJcbiAgICAgICAgOiBbLi4ucHJldiwgY3VzdG9tZXJJZF1cclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0QWxsID0gKGUpID0+IHtcclxuICAgIGlmIChlLnRhcmdldC5jaGVja2VkKSB7XHJcbiAgICAgIGNvbnN0IGFsbEN1c3RvbWVySWRzID0gVGFibGVVc2Vycy5tYXAoKHVzZXIpID0+IHVzZXIuX2lkKTtcclxuICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcnMoYWxsQ3VzdG9tZXJJZHMpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcnMoW10pO1xyXG4gICAgfVxyXG4gICAgc2V0U2VsZWN0QWxsKGUudGFyZ2V0LmNoZWNrZWQpO1xyXG4gICAgc2V0U2hvd0FsbEN1c3RvbWVycyhmYWxzZSk7IC8vIFJlc2V0IHNob3cgYWxsIHN0YXRlIHdoZW4gc2VsZWN0aW9uIGNoYW5nZXNcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TGlua0NoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlLCB0eXBlLCBjaGVja2VkIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFBheW1lbnRMaW5rRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgW25hbWVdOiB0eXBlID09PSBcImNoZWNrYm94XCIgPyBjaGVja2VkIDogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR2VuZXJhdGVQYXltZW50TGluayA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChcclxuICAgICAgIXBheW1lbnRMaW5rRGF0YS5hbW91bnQgfHxcclxuICAgICAgaXNOYU4ocGF5bWVudExpbmtEYXRhLmFtb3VudCkgfHxcclxuICAgICAgcGF5bWVudExpbmtEYXRhLmFtb3VudCA8PSAwXHJcbiAgICApIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBhbW91bnRcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBpZiAoIXBheW1lbnRMaW5rRGF0YS5wdXJwb3NlLnRyaW0oKSkge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlB1cnBvc2UgaXMgcmVxdWlyZWQgZm9yIHBheW1lbnQgbGlua1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIFxyXG4gICAgY29uc3QgY3VzdG9tZXJEZXRhaWxzID0gZ2V0U2VsZWN0ZWRDdXN0b21lckRldGFpbHMoKTtcclxuICAgIFxyXG4gICAgaWYgKGN1c3RvbWVyRGV0YWlscy5sZW5ndGggPT09IDApIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJObyB2YWxpZCBjdXN0b21lcnMgc2VsZWN0ZWRcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0UGF5bWVudExpbmtMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi9wYXltZW50YXBpL2NyZWF0ZS1wYXltZW50XCIsIHtcclxuICAgICAgICBjdXN0b21lcnM6IGN1c3RvbWVyRGV0YWlscywgIC8vIE5vdyBpbmNsdWRlcyBwaG9uZV9udW1iZXIsIGZ1bGxfbmFtZSwgYW5kIGVtYWlsXHJcbiAgICAgICAgYW1vdW50OiBwYXltZW50TGlua0RhdGEuYW1vdW50LFxyXG4gICAgICAgIHB1cnBvc2U6IHBheW1lbnRMaW5rRGF0YS5wdXJwb3NlLFxyXG4gICAgICAgIGV4cGlyeTogcGF5bWVudExpbmtEYXRhLmV4cGlyeSxcclxuICAgICAgICBub3RpZnlfY3VzdG9tZXI6IHBheW1lbnRMaW5rRGF0YS5ub3RpZnlfY3VzdG9tZXIsXHJcbiAgICAgICAgc2VuZF9zbXM6IHBheW1lbnRMaW5rRGF0YS5zZW5kX3NtcyxcclxuICAgICAgICBzZW5kX2VtYWlsOiBwYXltZW50TGlua0RhdGEuc2VuZF9lbWFpbCxcclxuICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGBQYXltZW50IGxpbmtzIGdlbmVyYXRlZCBhbmQgc2VudCB0byAke2N1c3RvbWVyRGV0YWlscy5sZW5ndGh9IGN1c3RvbWVyKHMpYCxcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gICAgICAgIHNldFNob3dQYXltZW50TGlua01vZGFsKGZhbHNlKTtcclxuICAgICAgICBzZXRTaG93QWxsQ3VzdG9tZXJzKGZhbHNlKTsgLy8gUmVzZXQgc2hvdyBhbGwgc3RhdGVcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgICAgICByZXNwb25zZS5kYXRhLm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gZ2VuZXJhdGUgcGF5bWVudCBsaW5rc1wiXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTpcclxuICAgICAgICAgIGVycm9yLm1lc3NhZ2UgfHxcclxuICAgICAgICAgIFwiRmFpbGVkIHRvIGdlbmVyYXRlIHBheW1lbnQgbGlua3MuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFBheW1lbnRMaW5rTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17R2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5DdXN0b21lcnM8L2gxPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDdXN0b21lcnMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1BheW1lbnRMaW5rTW9kYWwodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctZ3JlZW4tNzAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwIGZsZXggaXRlbXMtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8RmFNb25leUJpbGxXYXZlIGNsYXNzTmFtZT1cIm1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR2VuZXJhdGUgUGF5bWVudCBMaW5rcyAoe3NlbGVjdGVkQ3VzdG9tZXJzLmxlbmd0aH0pXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtUYWJsZVVzZXJzPy5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICBkYXRhPXtUYWJsZVVzZXJzLm1hcCgodXNlcikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgLi4udXNlcixcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0OiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RlZEN1c3RvbWVycy5pbmNsdWRlcyh1c2VyLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gaGFuZGxlU2VsZWN0Q3VzdG9tZXIodXNlci5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiUGF5bWVudCBMaW5rXCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BQYXltZW50IExpbmsuY3N2YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXtUYWJsZVVzZXJzLmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgZGF0YT1cIkN1c3RvbWVyIERhdGFcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd1BheW1lbnRMaW5rTW9kYWx9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dQYXltZW50TGlua01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0U2hvd0FsbEN1c3RvbWVycyhmYWxzZSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxGYU1vbmV5QmlsbFdhdmUgY2xhc3NOYW1lPVwidGV4dC0yeGwgdGV4dC1ncmVlbi02MDAgbXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgIEdlbmVyYXRlIFBheW1lbnQgTGlua3NcclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHsvKiBEaXNwbGF5IGxpbWl0ZWQgY3VzdG9tZXIgZGV0YWlscyBpbml0aWFsbHkgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBtYXgtaC02MCBvdmVyZmxvdy15LWF1dG8gcHItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkQ3VzdG9tZXJzLmxlbmd0aH0gY3VzdG9tZXJ7c2VsZWN0ZWRDdXN0b21lcnMubGVuZ3RoICE9PSAxID8gJ3MnIDogJyd9IHNlbGVjdGVkOlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICB7LyogU2hvdyBsaW1pdGVkIGN1c3RvbWVycyAoZmlyc3QgNSkgKi99XHJcbiAgICAgICAgICAgICAge2dldFNlbGVjdGVkQ3VzdG9tZXJEZXRhaWxzKCkuc2xpY2UoMCwgc2hvd0FsbEN1c3RvbWVycyA/IGdldFNlbGVjdGVkQ3VzdG9tZXJEZXRhaWxzKCkubGVuZ3RoIDogNSkubWFwKChjdXN0b21lciwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgIDxkaXYgXHJcbiAgICAgICAgICAgICAgICAgIGtleT17Y3VzdG9tZXIuaWR9IFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcC0zIG1iLTJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPntjdXN0b21lci5mdWxsX25hbWV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5QaG9uZToge2N1c3RvbWVyLnBob25lX251bWJlcn08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPkVtYWlsOiB7Y3VzdG9tZXIuZW1haWwgfHwgJ05vdCBwcm92aWRlZCd9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgey8qIFNob3cgXCJTaG93IEFsbFwiIGJ1dHRvbiBpZiB0aGVyZSBhcmUgbW9yZSB0aGFuIDUgY3VzdG9tZXJzICovfVxyXG4gICAgICAgICAgICAgIHtnZXRTZWxlY3RlZEN1c3RvbWVyRGV0YWlscygpLmxlbmd0aCA+IDUgJiYgIXNob3dBbGxDdXN0b21lcnMgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FsbEN1c3RvbWVycyh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIGhvdmVyOnRleHQtdmlvbGV0LTgwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIG10LTIgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTaG93IGFsbCB7Z2V0U2VsZWN0ZWRDdXN0b21lckRldGFpbHMoKS5sZW5ndGh9IGN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICB7LyogU2hvdyBcIlNob3cgTGVzc1wiIGJ1dHRvbiBpZiBzaG93aW5nIGFsbCBjdXN0b21lcnMgKi99XHJcbiAgICAgICAgICAgICAge3Nob3dBbGxDdXN0b21lcnMgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FsbEN1c3RvbWVycyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIG10LTIgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTaG93IGxlc3NcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgaGFuZGxlR2VuZXJhdGVQYXltZW50TGluaygpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEFtb3VudCAoSU5SKSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50TGlua0RhdGEuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGF5bWVudExpbmtDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICBtaW49XCIxXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwicHVycG9zZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFB1cnBvc2UgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicHVycG9zZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50TGlua0RhdGEucHVycG9zZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRMaW5rQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cInB1cnBvc2VcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHBheW1lbnQgcHVycG9zZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImV4cGlyeVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIExpbmsgRXhwaXJ5XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFeHBpcnkgVGltZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50TGlua0RhdGEuZXhwaXJ5fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRMaW5rRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgZXhwaXJ5OiB2YWx1ZSB9KSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIjg2NDAwXCI+MjQgaG91cnM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiMTcyODAwXCI+NDggaG91cnM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiMjU5MjAwXCI+NzIgaG91cnM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiNjA0ODAwXCI+NyBkYXlzPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBQYXltZW50IGxpbmsgd2lsbCBleHBpcmUgYWZ0ZXIgc2VsZWN0ZWQgdGltZSBwZXJpb2RcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgTm90aWZpY2F0aW9uIFNldHRpbmdzXHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC00IHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtwYXltZW50TGlua0RhdGEubm90aWZ5X2N1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRMaW5rQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vdGlmeV9jdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE5vdGlmeSBjdXN0b21lciBhYm91dCBwYXltZW50IGxpbmtcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cGF5bWVudExpbmtEYXRhLnNlbmRfc21zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRMaW5rQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInNlbmRfc21zXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtbC0yIHRleHQtc20gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VuZCB2aWEgU01TXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3BheW1lbnRMaW5rRGF0YS5zZW5kX2VtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRMaW5rQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInNlbmRfZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZW5kIHZpYSBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93UGF5bWVudExpbmtNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd0FsbEN1c3RvbWVycyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BheW1lbnRMaW5rTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1hdXRvIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSAke1xyXG4gICAgICAgICAgICAgICAgICAgIHBheW1lbnRMaW5rTG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXZpb2xldC00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXZpb2xldC02MDAgaG92ZXI6YmctdmlvbGV0LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgIH0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLW9mZnNldC0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMGB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtwYXltZW50TGlua0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIC1tbC0xIG1yLTIgaC00IHctNCB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTI1XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjeD1cIjEyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjeT1cIjEyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByPVwiMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCI0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvY2lyY2xlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm9wYWNpdHktNzVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNNCAxMmE4IDggMCAwMTgtOFYwQzUuMzczIDAgMCA1LjM3MyAwIDEyaDR6bTIgNS4yOTFBNy45NjIgNy45NjIgMCAwMTQgMTJIMGMwIDMuMDQyIDEuMTM1IDUuODI0IDMgNy45MzhsMy0yLjY0N3pcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC9wYXRoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICBHZW5lcmF0aW5nLi4uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIFwiR2VuZXJhdGUgJiBTZW5kIExpbmtzXCJcclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVc2VyOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9QYXltZW50TGluay5qc3gifQ==