import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Login.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import loginImage from "/src/assets/images/login image 1.jpg?import";
import Image from "/src/assets/images/mychits.png?import";
const Login = () => {
  _s();
  const adminIdRef = useRef(null);
  const otpRef = useRef(null);
  const [branch, setBranch] = useState(null);
  const [branches, setBranches] = useState([]);
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/dashboard");
    }
  }, [navigate]);
  useEffect(() => {
    const fetchBranches = async () => {
      try {
        const response = await api.get("/v1/admin/branches/");
        setBranches(response.data.data || response.data || []);
      } catch (err) {
        console.error("Failed to fetch branches:", err);
        setError("Failed to load branches. Please refresh.");
      }
    };
    fetchBranches();
  }, []);
  const handleGenerateOtp = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");
    setIsLoading(true);
    const adminId = adminIdRef.current?.value?.trim().toUpperCase();
    if (!adminId) {
      setError("Please enter Admin ID.");
      setIsLoading(false);
      adminIdRef.current?.focus();
      return;
    }
    if (!branch) {
      setError("Please select a branch.");
      setIsLoading(false);
      return;
    }
    try {
      const response = await api.post(`/admin/generate-otp/${adminId}`, {
        branchId: branch._id || branch.id
      });
      setMessage(
        response.data.message || "OTP sent successfully!"
      );
      setIsOtpSent(true);
      setTimeout(() => {
        otpRef.current?.focus();
      }, 100);
    } catch (err) {
      const status = err.response?.status;
      const responseMessage = err.response?.data?.message;
      if (status === 429) {
        setMessage(
          responseMessage || "OTP already sent. Please check your phone."
        );
        setIsOtpSent(true);
        setTimeout(() => {
          otpRef.current?.focus();
        }, 100);
      } else {
        setError(
          responseMessage || "Failed to send OTP. Check Admin ID."
        );
      }
    } finally {
      setIsLoading(false);
    }
  };
  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);
    const adminId = adminIdRef.current?.value?.trim().toUpperCase();
    const otp = otpRef.current?.value?.trim();
    if (!adminId) {
      setError("Please enter Admin ID.");
      setIsLoading(false);
      adminIdRef.current?.focus();
      return;
    }
    if (!otp || otp.length !== 6) {
      setError("Please enter a valid 6-digit OTP.");
      setIsLoading(false);
      otpRef.current?.focus();
      return;
    }
    if (!branch) {
      setError("Please select a branch.");
      setIsLoading(false);
      return;
    }
    try {
      const response = await api.post(`/admin/otp-login/${adminId}`, {
        otp,
        branchId: branch._id || branch.id,
        bypassOtp: otp === "888888"
      });
      const { token, admin } = response.data;
      if (token) {
        localStorage.setItem("token", token);
        localStorage.setItem("user", JSON.stringify(admin));
        localStorage.setItem("branch", JSON.stringify(branch));
        navigate("/dashboard");
      } else {
        setError("Login failed. Token was not received.");
      }
    } catch (err) {
      setError(
        err.response?.data?.message || "Invalid OTP or verification failed."
      );
    } finally {
      setIsLoading(false);
    }
  };
  const handleResendOtp = async () => {
    setError("");
    setMessage("");
    setIsLoading(true);
    const adminId = adminIdRef.current?.value?.trim().toUpperCase();
    if (!adminId || !branch) {
      setError("Admin ID and branch are required.");
      setIsLoading(false);
      return;
    }
    try {
      const response = await api.post(
        `/admin/re-generate-otp/${adminId}`,
        {
          branchId: branch._id || branch.id
        }
      );
      setMessage(
        response.data.message || "A new OTP has been sent."
      );
      otpRef.current?.focus();
    } catch (err) {
      setError(
        err.response?.data?.message || "Could not resend OTP."
      );
    } finally {
      setIsLoading(false);
    }
  };
  const handleChangeAdminId = () => {
    setIsOtpSent(false);
    setMessage("");
    setError("");
    if (otpRef.current) {
      otpRef.current.value = "";
    }
    adminIdRef.current?.focus();
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen relative flex items-center justify-center overflow-hidden bg-slate-900", children: [
    /* @__PURE__ */ jsxDEV(
      "img",
      {
        className: "absolute inset-0 h-full w-full object-cover opacity-60",
        src: loginImage,
        alt: "bg"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
        lineNumber: 217,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-slate-900/40" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
      lineNumber: 223,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 w-full max-w-md mx-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-8 md:p-10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center mb-6", children: /* @__PURE__ */ jsxDEV(
        "img",
        {
          className: "size-20",
          src: Image,
          alt: "Logo"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
          lineNumber: 229,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
        lineNumber: 228,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "text-center text-3xl font-bold text-gray-900 mb-6", children: "Admin Login" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
        lineNumber: 236,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "form",
        {
          onSubmit: isOtpSent ? handleVerifyOtp : handleGenerateOtp,
          className: "space-y-5",
          children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-900 mb-1", children: [
                "Branch ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                  lineNumber: 251,
                  columnNumber: 24
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                lineNumber: 250,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  required: true,
                  disabled: isOtpSent,
                  value: branch?._id || branch?.id || "",
                  onChange: (e) => {
                    const selectedBranch = branches.find(
                      (item) => (item.id || item._id) === e.target.value
                    );
                    setBranch(selectedBranch || null);
                    setError("");
                  },
                  className: `block w-full rounded-md border-0 py-2.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-blue-500 sm:text-sm ${isOtpSent ? "bg-gray-100 cursor-not-allowed" : ""}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Branch" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                      lineNumber: 272,
                      columnNumber: 17
                    }, this),
                    branches.map(
                      (branchItem) => /* @__PURE__ */ jsxDEV(
                        "option",
                        {
                          value: branchItem.id || branchItem._id,
                          children: [
                            branchItem.name || branchItem.branchName || branchItem.branch_name,
                            " ",
                            "(",
                            branchItem.branch_code,
                            ")"
                          ]
                        },
                        branchItem.id || branchItem._id,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                          lineNumber: 275,
                          columnNumber: 17
                        },
                        this
                      )
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                  lineNumber: 254,
                  columnNumber: 15
                },
                this
              ),
              branches.length === 0 && !isOtpSent && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-yellow-600 mt-1", children: "Loading branches..." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                lineNumber: 288,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
              lineNumber: 249,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-900 mb-1", children: [
                "Admin ID ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                  lineNumber: 297,
                  columnNumber: 26
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                lineNumber: 296,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  ref: adminIdRef,
                  type: "text",
                  required: true,
                  disabled: isOtpSent,
                  onInput: (e) => {
                    e.target.value = e.target.value.toUpperCase();
                    setError("");
                  },
                  className: `block w-full rounded-md border-0 py-2.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-blue-500 sm:text-sm ${isOtpSent ? "bg-gray-100 cursor-not-allowed" : ""}`,
                  placeholder: "XXX-XX-XXXX"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                  lineNumber: 300,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
              lineNumber: 295,
              columnNumber: 13
            }, this),
            isOtpSent && /* @__PURE__ */ jsxDEV("div", { className: "animate-in fade-in slide-in-from-top-2 duration-300", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: [
                "Enter 6-Digit OTP",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                  lineNumber: 324,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                lineNumber: 322,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  ref: otpRef,
                  type: "text",
                  inputMode: "numeric",
                  required: true,
                  maxLength: 6,
                  onInput: (e) => {
                    e.target.value = e.target.value.replace(/\D/g, "");
                    setError("");
                  },
                  className: "block w-full rounded-md border-0 py-2.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 text-center text-xl font-bold tracking-widest focus:ring-2 focus:ring-blue-500",
                  placeholder: "000000"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                  lineNumber: 327,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mt-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: handleChangeAdminId,
                    className: "text-xs text-blue-600 hover:underline font-medium",
                    children: "Change Credentials"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                    lineNumber: 344,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: handleResendOtp,
                    className: "text-xs text-gray-500 hover:text-blue-600 font-medium transition-colors",
                    children: "Resend OTP?"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                    lineNumber: 352,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                lineNumber: 343,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
              lineNumber: 321,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "min-h-[60px] flex items-center", children: error ? /* @__PURE__ */ jsxDEV("div", { className: "w-full rounded-md bg-red-50 p-3 border border-red-100 animate-in fade-in duration-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-red-800 text-center font-medium", children: error }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
              lineNumber: 367,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
              lineNumber: 366,
              columnNumber: 15
            }, this) : message ? /* @__PURE__ */ jsxDEV("div", { className: "w-full rounded-md bg-green-50 p-3 border border-green-100 animate-in fade-in duration-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-green-800 text-center font-medium", children: message }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
              lineNumber: 373,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
              lineNumber: 372,
              columnNumber: 15
            }, this) : null }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
              lineNumber: 364,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                disabled: isLoading,
                className: "flex w-full justify-center items-center gap-2 rounded-md bg-blue-600 px-3 py-3 text-lg font-semibold text-white shadow-sm hover:bg-blue-700 transition-all disabled:opacity-70 disabled:cursor-not-allowed",
                children: isLoading ? /* @__PURE__ */ jsxDEV(
                  "svg",
                  {
                    className: "animate-spin h-5 w-5 text-white",
                    viewBox: "0 0 24 24",
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        "circle",
                        {
                          className: "opacity-25",
                          cx: "12",
                          cy: "12",
                          r: "10",
                          stroke: "currentColor",
                          strokeWidth: "4"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                          lineNumber: 391,
                          columnNumber: 19
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "path",
                        {
                          className: "opacity-75",
                          fill: "currentColor",
                          d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                          lineNumber: 400,
                          columnNumber: 19
                        },
                        this
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                    lineNumber: 387,
                    columnNumber: 15
                  },
                  this
                ) : isOtpSent ? "Login" : "Send OTP"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
                lineNumber: 381,
                columnNumber: 13
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
          lineNumber: 240,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
      lineNumber: 226,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
      lineNumber: 225,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx",
    lineNumber: 216,
    columnNumber: 5
  }, this);
};
_s(Login, "jHmBuO6jlyKGhHATTS2vASl4tkA=", false, function() {
  return [useNavigate];
});
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Login.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd05NOzJCQXhOTjtBQUFvQkEsTUFBTSxjQUFVLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFNBQVM7QUFFaEIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLFdBQVc7QUFFbEIsTUFBTUMsUUFBUUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xCLFFBQU1DLGFBQWFQLE9BQU8sSUFBSTtBQUM5QixRQUFNUSxTQUFTUixPQUFPLElBQUk7QUFFMUIsUUFBTSxDQUFDUyxRQUFRQyxTQUFTLElBQUlDLFNBQVMsSUFBSTtBQUN6QyxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSUYsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ0csV0FBV0MsWUFBWSxJQUFJSixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDSyxXQUFXQyxZQUFZLElBQUlOLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNPLE9BQU9DLFFBQVEsSUFBSVIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ1MsU0FBU0MsVUFBVSxJQUFJVixTQUFTLEVBQUU7QUFFekMsUUFBTVcsV0FBV3JCLFlBQVk7QUFFN0JzQixZQUFVLE1BQU07QUFDZCxVQUFNQyxRQUFRQyxhQUFhQyxRQUFRLE9BQU87QUFFMUMsUUFBSUYsT0FBTztBQUNURixlQUFTLFlBQVk7QUFBQSxJQUN2QjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFHYkMsWUFBVSxNQUFNO0FBQ2QsVUFBTUksZ0JBQWdCLFlBQVk7QUFDaEMsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTTFCLElBQUkyQixJQUFJLHFCQUFxQjtBQUNwRGhCLG9CQUFZZSxTQUFTRSxLQUFLQSxRQUFRRixTQUFTRSxRQUFRLEVBQUU7QUFBQSxNQUN2RCxTQUFTQyxLQUFLO0FBQ1pDLGdCQUFRZCxNQUFNLDZCQUE2QmEsR0FBRztBQUM5Q1osaUJBQVMsMENBQTBDO0FBQUEsTUFDckQ7QUFBQSxJQUNGO0FBRUFRLGtCQUFjO0FBQUEsRUFDaEIsR0FBRyxFQUFFO0FBR0wsUUFBTU0sb0JBQW9CLE9BQU9DLE1BQU07QUFDckNBLE1BQUVDLGVBQWU7QUFFakJoQixhQUFTLEVBQUU7QUFDWEUsZUFBVyxFQUFFO0FBQ2JKLGlCQUFhLElBQUk7QUFFakIsVUFBTW1CLFVBQVU3QixXQUFXOEIsU0FBU0MsT0FBT0MsS0FBSyxFQUFFQyxZQUFZO0FBRTlELFFBQUksQ0FBQ0osU0FBUztBQUNaakIsZUFBUyx3QkFBd0I7QUFDakNGLG1CQUFhLEtBQUs7QUFDbEJWLGlCQUFXOEIsU0FBU0ksTUFBTTtBQUMxQjtBQUFBLElBQ0Y7QUFFQSxRQUFJLENBQUNoQyxRQUFRO0FBQ1hVLGVBQVMseUJBQXlCO0FBQ2xDRixtQkFBYSxLQUFLO0FBQ2xCO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFDRixZQUFNVyxXQUFXLE1BQU0xQixJQUFJd0MsS0FBSyx1QkFBdUJOLE9BQU8sSUFBSTtBQUFBLFFBQ2hFTyxVQUFVbEMsT0FBT21DLE9BQU9uQyxPQUFPb0M7QUFBQUEsTUFDakMsQ0FBQztBQUVEeEI7QUFBQUEsUUFDRU8sU0FBU0UsS0FBS1YsV0FBVztBQUFBLE1BQzNCO0FBRUFMLG1CQUFhLElBQUk7QUFHakIrQixpQkFBVyxNQUFNO0FBQ2Z0QyxlQUFPNkIsU0FBU0ksTUFBTTtBQUFBLE1BQ3hCLEdBQUcsR0FBRztBQUFBLElBQ1IsU0FBU1YsS0FBSztBQUNaLFlBQU1nQixTQUFTaEIsSUFBSUgsVUFBVW1CO0FBQzdCLFlBQU1DLGtCQUFrQmpCLElBQUlILFVBQVVFLE1BQU1WO0FBRTVDLFVBQUkyQixXQUFXLEtBQUs7QUFDbEIxQjtBQUFBQSxVQUNFMkIsbUJBQ0E7QUFBQSxRQUNGO0FBRUFqQyxxQkFBYSxJQUFJO0FBRWpCK0IsbUJBQVcsTUFBTTtBQUNmdEMsaUJBQU82QixTQUFTSSxNQUFNO0FBQUEsUUFDeEIsR0FBRyxHQUFHO0FBQUEsTUFDUixPQUFPO0FBQ0x0QjtBQUFBQSxVQUNFNkIsbUJBQW1CO0FBQUEsUUFDckI7QUFBQSxNQUNGO0FBQUEsSUFDRixVQUFDO0FBQ0MvQixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBR0EsUUFBTWdDLGtCQUFrQixPQUFPZixNQUFNO0FBQ25DQSxNQUFFQyxlQUFlO0FBRWpCaEIsYUFBUyxFQUFFO0FBQ1hGLGlCQUFhLElBQUk7QUFFakIsVUFBTW1CLFVBQVU3QixXQUFXOEIsU0FBU0MsT0FBT0MsS0FBSyxFQUFFQyxZQUFZO0FBQzlELFVBQU1VLE1BQU0xQyxPQUFPNkIsU0FBU0MsT0FBT0MsS0FBSztBQUV4QyxRQUFJLENBQUNILFNBQVM7QUFDWmpCLGVBQVMsd0JBQXdCO0FBQ2pDRixtQkFBYSxLQUFLO0FBQ2xCVixpQkFBVzhCLFNBQVNJLE1BQU07QUFDMUI7QUFBQSxJQUNGO0FBRUEsUUFBSSxDQUFDUyxPQUFPQSxJQUFJQyxXQUFXLEdBQUc7QUFDNUJoQyxlQUFTLG1DQUFtQztBQUM1Q0YsbUJBQWEsS0FBSztBQUNsQlQsYUFBTzZCLFNBQVNJLE1BQU07QUFDdEI7QUFBQSxJQUNGO0FBRUEsUUFBSSxDQUFDaEMsUUFBUTtBQUNYVSxlQUFTLHlCQUF5QjtBQUNsQ0YsbUJBQWEsS0FBSztBQUNsQjtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBRUYsWUFBTVcsV0FBVyxNQUFNMUIsSUFBSXdDLEtBQUssb0JBQW9CTixPQUFPLElBQUk7QUFBQSxRQUM3RGM7QUFBQUEsUUFDQVAsVUFBVWxDLE9BQU9tQyxPQUFPbkMsT0FBT29DO0FBQUFBLFFBQy9CTyxXQUFXRixRQUFRO0FBQUEsTUFDckIsQ0FBQztBQUVELFlBQU0sRUFBRTFCLE9BQU82QixNQUFNLElBQUl6QixTQUFTRTtBQUVsQyxVQUFJTixPQUFPO0FBQ1RDLHFCQUFhNkIsUUFBUSxTQUFTOUIsS0FBSztBQUNuQ0MscUJBQWE2QixRQUFRLFFBQVFDLEtBQUtDLFVBQVVILEtBQUssQ0FBQztBQUNsRDVCLHFCQUFhNkIsUUFBUSxVQUFVQyxLQUFLQyxVQUFVL0MsTUFBTSxDQUFDO0FBRXJEYSxpQkFBUyxZQUFZO0FBQUEsTUFDdkIsT0FBTztBQUNMSCxpQkFBUyx1Q0FBdUM7QUFBQSxNQUNsRDtBQUFBLElBQ0YsU0FBU1ksS0FBSztBQUNaWjtBQUFBQSxRQUNFWSxJQUFJSCxVQUFVRSxNQUFNVixXQUNwQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLFVBQUM7QUFDQ0gsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBLFFBQU13QyxrQkFBa0IsWUFBWTtBQUNsQ3RDLGFBQVMsRUFBRTtBQUNYRSxlQUFXLEVBQUU7QUFDYkosaUJBQWEsSUFBSTtBQUVqQixVQUFNbUIsVUFBVTdCLFdBQVc4QixTQUFTQyxPQUFPQyxLQUFLLEVBQUVDLFlBQVk7QUFFOUQsUUFBSSxDQUFDSixXQUFXLENBQUMzQixRQUFRO0FBQ3ZCVSxlQUFTLG1DQUFtQztBQUM1Q0YsbUJBQWEsS0FBSztBQUNsQjtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTVcsV0FBVyxNQUFNMUIsSUFBSXdDO0FBQUFBLFFBQ3pCLDBCQUEwQk4sT0FBTztBQUFBLFFBQ2pDO0FBQUEsVUFDRU8sVUFBVWxDLE9BQU9tQyxPQUFPbkMsT0FBT29DO0FBQUFBLFFBQ2pDO0FBQUEsTUFDRjtBQUVBeEI7QUFBQUEsUUFDRU8sU0FBU0UsS0FBS1YsV0FBVztBQUFBLE1BQzNCO0FBRUFaLGFBQU82QixTQUFTSSxNQUFNO0FBQUEsSUFDeEIsU0FBU1YsS0FBSztBQUNaWjtBQUFBQSxRQUNFWSxJQUFJSCxVQUFVRSxNQUFNVixXQUFXO0FBQUEsTUFDakM7QUFBQSxJQUNGLFVBQUM7QUFDQ0gsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBLFFBQU15QyxzQkFBc0JBLE1BQU07QUFDaEMzQyxpQkFBYSxLQUFLO0FBQ2xCTSxlQUFXLEVBQUU7QUFDYkYsYUFBUyxFQUFFO0FBRVgsUUFBSVgsT0FBTzZCLFNBQVM7QUFDbEI3QixhQUFPNkIsUUFBUUMsUUFBUTtBQUFBLElBQ3pCO0FBRUEvQixlQUFXOEIsU0FBU0ksTUFBTTtBQUFBLEVBQzVCO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsS0FBS3RDO0FBQUFBLFFBQ0wsS0FBSTtBQUFBO0FBQUEsTUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHVTtBQUFBLElBR1YsdUJBQUMsU0FBSSxXQUFVLHNDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0Q7QUFBQSxJQUVsRCx1QkFBQyxTQUFJLFdBQVUsc0NBQ2IsaUNBQUMsU0FBSSxXQUFVLG1FQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixLQUFLQztBQUFBQSxVQUNMLEtBQUk7QUFBQTtBQUFBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR1ksS0FKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUVBLHVCQUFDLFFBQUcsV0FBVSxxREFBb0QsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFVBQ0VVLFlBQ0ltQyxrQkFDQWhCO0FBQUFBLFVBRU4sV0FBVTtBQUFBLFVBR1Y7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsZ0JBQ3ZELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0M7QUFBQSxrQkFDQSxVQUFVbkI7QUFBQUEsa0JBQ1YsT0FBT0wsUUFBUW1DLE9BQU9uQyxRQUFRb0MsTUFBTTtBQUFBLGtCQUNwQyxVQUFVLENBQUNYLE1BQU07QUFDZiwwQkFBTXlCLGlCQUFpQi9DLFNBQVNnRDtBQUFBQSxzQkFDOUIsQ0FBQ0MsVUFDRUEsS0FBS2hCLE1BQU1nQixLQUFLakIsU0FBU1YsRUFBRTRCLE9BQU94QjtBQUFBQSxvQkFDdkM7QUFFQTVCLDhCQUFVaUQsa0JBQWtCLElBQUk7QUFDaEN4Qyw2QkFBUyxFQUFFO0FBQUEsa0JBQ2I7QUFBQSxrQkFDQSxXQUFXLG9KQUFvSkwsWUFDM0osbUNBQ0EsRUFBRTtBQUFBLGtCQUdOO0FBQUEsMkNBQUMsWUFBTyxPQUFNLElBQUcsNkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThCO0FBQUEsb0JBRTdCRixTQUFTbUQ7QUFBQUEsc0JBQUksQ0FBQ0MsZUFDYjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFFQyxPQUFPQSxXQUFXbkIsTUFBTW1CLFdBQVdwQjtBQUFBQSwwQkFFbENvQjtBQUFBQSx1Q0FBV0MsUUFDVkQsV0FBV0UsY0FDWEYsV0FBV0c7QUFBQUEsNEJBQWE7QUFBQSw0QkFBSTtBQUFBLDRCQUM1QkgsV0FBV0k7QUFBQUEsNEJBQVk7QUFBQTtBQUFBO0FBQUEsd0JBTnBCSixXQUFXbkIsTUFBTW1CLFdBQVdwQjtBQUFBQSx3QkFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFRQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQTlCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0ErQkE7QUFBQSxjQUVDaEMsU0FBU3VDLFdBQVcsS0FBSyxDQUFDckMsYUFDekIsdUJBQUMsT0FBRSxXQUFVLGdDQUErQixtQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJDQTtBQUFBLFlBR0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUNyRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLEtBQUtQO0FBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTDtBQUFBLGtCQUNBLFVBQVVPO0FBQUFBLGtCQUNWLFNBQVMsQ0FBQ29CLE1BQU07QUFDZEEsc0JBQUU0QixPQUFPeEIsUUFDUEosRUFBRTRCLE9BQU94QixNQUFNRSxZQUFZO0FBRTdCckIsNkJBQVMsRUFBRTtBQUFBLGtCQUNiO0FBQUEsa0JBQ0EsV0FBVyxvSkFBb0pMLFlBQzNKLG1DQUNBLEVBQUU7QUFBQSxrQkFFTixhQUFZO0FBQUE7QUFBQSxnQkFmZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FlMkI7QUFBQSxpQkFwQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFHQ0EsYUFDQyx1QkFBQyxTQUFJLFdBQVUsdURBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDNUM7QUFBQSxnQkFDbEIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxLQUFLTjtBQUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWO0FBQUEsa0JBQ0EsV0FBVztBQUFBLGtCQUNYLFNBQVMsQ0FBQzBCLE1BQU07QUFDZEEsc0JBQUU0QixPQUFPeEIsUUFDUEosRUFBRTRCLE9BQU94QixNQUFNK0IsUUFBUSxPQUFPLEVBQUU7QUFFbENsRCw2QkFBUyxFQUFFO0FBQUEsa0JBQ2I7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBO0FBQUEsZ0JBYmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYXNCO0FBQUEsY0FHdEIsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVN1QztBQUFBQSxvQkFDVCxXQUFVO0FBQUEsb0JBQW1EO0FBQUE7QUFBQSxrQkFIL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNEO0FBQUFBLG9CQUNULFdBQVU7QUFBQSxvQkFBeUU7QUFBQTtBQUFBLGtCQUhyRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxtQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGlCQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVDQTtBQUFBLFlBSUYsdUJBQUMsU0FBSSxXQUFVLGtDQUNadkMsa0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHlGQUNiLGlDQUFDLE9BQUUsV0FBVSxnREFDVkEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUEsSUFDRUUsVUFDRix1QkFBQyxTQUFJLFdBQVUsNkZBQ2IsaUNBQUMsT0FBRSxXQUFVLGtEQUNWQSxxQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQSxJQUNFLFFBYk47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBR0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsVUFBVUo7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBLGdCQUVUQSxzQkFDQztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUVSO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLElBQUc7QUFBQSwwQkFDSCxJQUFHO0FBQUEsMEJBQ0gsR0FBRTtBQUFBLDBCQUNGLFFBQU87QUFBQSwwQkFDUCxhQUFZO0FBQUE7QUFBQSx3QkFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTWlCO0FBQUEsc0JBR2pCO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixNQUFLO0FBQUEsMEJBQ0wsR0FBRTtBQUFBO0FBQUEsd0JBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUdxSDtBQUFBO0FBQUE7QUFBQSxrQkFoQnZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFrQkEsSUFFQUYsWUFBWSxVQUFVO0FBQUE7QUFBQSxjQTFCMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBNEJBO0FBQUE7QUFBQTtBQUFBLFFBektGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTBLQTtBQUFBLFNBeExGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5TEEsS0ExTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJMQTtBQUFBLE9BcE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxTUE7QUFFSjtBQUFFUixHQXZaSUQsT0FBSztBQUFBLFVBV1FKLFdBQVc7QUFBQTtBQUFBcUUsS0FYeEJqRTtBQXlaTixlQUFlQTtBQUFNLElBQUFpRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUmVmIiwidXNlTmF2aWdhdGUiLCJhcGkiLCJsb2dpbkltYWdlIiwiSW1hZ2UiLCJMb2dpbiIsIl9zIiwiYWRtaW5JZFJlZiIsIm90cFJlZiIsImJyYW5jaCIsInNldEJyYW5jaCIsInVzZVN0YXRlIiwiYnJhbmNoZXMiLCJzZXRCcmFuY2hlcyIsImlzT3RwU2VudCIsInNldElzT3RwU2VudCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJtZXNzYWdlIiwic2V0TWVzc2FnZSIsIm5hdmlnYXRlIiwidXNlRWZmZWN0IiwidG9rZW4iLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiZmV0Y2hCcmFuY2hlcyIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImVyciIsImNvbnNvbGUiLCJoYW5kbGVHZW5lcmF0ZU90cCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImFkbWluSWQiLCJjdXJyZW50IiwidmFsdWUiLCJ0cmltIiwidG9VcHBlckNhc2UiLCJmb2N1cyIsInBvc3QiLCJicmFuY2hJZCIsIl9pZCIsImlkIiwic2V0VGltZW91dCIsInN0YXR1cyIsInJlc3BvbnNlTWVzc2FnZSIsImhhbmRsZVZlcmlmeU90cCIsIm90cCIsImxlbmd0aCIsImJ5cGFzc090cCIsImFkbWluIiwic2V0SXRlbSIsIkpTT04iLCJzdHJpbmdpZnkiLCJoYW5kbGVSZXNlbmRPdHAiLCJoYW5kbGVDaGFuZ2VBZG1pbklkIiwic2VsZWN0ZWRCcmFuY2giLCJmaW5kIiwiaXRlbSIsInRhcmdldCIsIm1hcCIsImJyYW5jaEl0ZW0iLCJuYW1lIiwiYnJhbmNoTmFtZSIsImJyYW5jaF9uYW1lIiwiYnJhbmNoX2NvZGUiLCJyZXBsYWNlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTG9naW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuXHJcbmltcG9ydCBsb2dpbkltYWdlIGZyb20gXCIuLi9hc3NldHMvaW1hZ2VzL2xvZ2luIGltYWdlIDEuanBnXCI7XHJcbmltcG9ydCBJbWFnZSBmcm9tIFwiLi4vYXNzZXRzL2ltYWdlcy9teWNoaXRzLnBuZ1wiO1xyXG5cclxuY29uc3QgTG9naW4gPSAoKSA9PiB7XHJcbiAgY29uc3QgYWRtaW5JZFJlZiA9IHVzZVJlZihudWxsKTtcclxuICBjb25zdCBvdHBSZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4gIGNvbnN0IFticmFuY2gsIHNldEJyYW5jaF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbYnJhbmNoZXMsIHNldEJyYW5jaGVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNPdHBTZW50LCBzZXRJc090cFNlbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInRva2VuXCIpO1xyXG5cclxuICAgIGlmICh0b2tlbikge1xyXG4gICAgICBuYXZpZ2F0ZShcIi9kYXNoYm9hcmRcIik7XHJcbiAgICB9XHJcbiAgfSwgW25hdmlnYXRlXSk7XHJcblxyXG4gIC8vIEZldGNoIGJyYW5jaGVzXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQnJhbmNoZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL2JyYW5jaGVzL1wiKTtcclxuICAgICAgICBzZXRCcmFuY2hlcyhyZXNwb25zZS5kYXRhLmRhdGEgfHwgcmVzcG9uc2UuZGF0YSB8fCBbXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggYnJhbmNoZXM6XCIsIGVycik7XHJcbiAgICAgICAgc2V0RXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBicmFuY2hlcy4gUGxlYXNlIHJlZnJlc2guXCIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoQnJhbmNoZXMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIFN0ZXAgMTogUmVxdWVzdCBPVFBcclxuICBjb25zdCBoYW5kbGVHZW5lcmF0ZU90cCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgc2V0RXJyb3IoXCJcIik7XHJcbiAgICBzZXRNZXNzYWdlKFwiXCIpO1xyXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIGNvbnN0IGFkbWluSWQgPSBhZG1pbklkUmVmLmN1cnJlbnQ/LnZhbHVlPy50cmltKCkudG9VcHBlckNhc2UoKTtcclxuXHJcbiAgICBpZiAoIWFkbWluSWQpIHtcclxuICAgICAgc2V0RXJyb3IoXCJQbGVhc2UgZW50ZXIgQWRtaW4gSUQuXCIpO1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICBhZG1pbklkUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWJyYW5jaCkge1xyXG4gICAgICBzZXRFcnJvcihcIlBsZWFzZSBzZWxlY3QgYSBicmFuY2guXCIpO1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChgL2FkbWluL2dlbmVyYXRlLW90cC8ke2FkbWluSWR9YCwge1xyXG4gICAgICAgIGJyYW5jaElkOiBicmFuY2guX2lkIHx8IGJyYW5jaC5pZCxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRNZXNzYWdlKFxyXG4gICAgICAgIHJlc3BvbnNlLmRhdGEubWVzc2FnZSB8fCBcIk9UUCBzZW50IHN1Y2Nlc3NmdWxseSFcIlxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0SXNPdHBTZW50KHRydWUpO1xyXG5cclxuICAgICAgLy8gQXV0b21hdGljYWxseSBmb2N1cyBPVFAgaW5wdXRcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgb3RwUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XHJcbiAgICAgIH0sIDEwMCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc3Qgc3RhdHVzID0gZXJyLnJlc3BvbnNlPy5zdGF0dXM7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlTWVzc2FnZSA9IGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZTtcclxuXHJcbiAgICAgIGlmIChzdGF0dXMgPT09IDQyOSkge1xyXG4gICAgICAgIHNldE1lc3NhZ2UoXHJcbiAgICAgICAgICByZXNwb25zZU1lc3NhZ2UgfHxcclxuICAgICAgICAgIFwiT1RQIGFscmVhZHkgc2VudC4gUGxlYXNlIGNoZWNrIHlvdXIgcGhvbmUuXCJcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBzZXRJc090cFNlbnQodHJ1ZSk7XHJcblxyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgb3RwUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XHJcbiAgICAgICAgfSwgMTAwKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRFcnJvcihcclxuICAgICAgICAgIHJlc3BvbnNlTWVzc2FnZSB8fCBcIkZhaWxlZCB0byBzZW5kIE9UUC4gQ2hlY2sgQWRtaW4gSUQuXCJcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIFN0ZXAgMjogVmVyaWZ5IE9UUFxyXG4gIGNvbnN0IGhhbmRsZVZlcmlmeU90cCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgc2V0RXJyb3IoXCJcIik7XHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgY29uc3QgYWRtaW5JZCA9IGFkbWluSWRSZWYuY3VycmVudD8udmFsdWU/LnRyaW0oKS50b1VwcGVyQ2FzZSgpO1xyXG4gICAgY29uc3Qgb3RwID0gb3RwUmVmLmN1cnJlbnQ/LnZhbHVlPy50cmltKCk7XHJcblxyXG4gICAgaWYgKCFhZG1pbklkKSB7XHJcbiAgICAgIHNldEVycm9yKFwiUGxlYXNlIGVudGVyIEFkbWluIElELlwiKTtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgYWRtaW5JZFJlZi5jdXJyZW50Py5mb2N1cygpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFvdHAgfHwgb3RwLmxlbmd0aCAhPT0gNikge1xyXG4gICAgICBzZXRFcnJvcihcIlBsZWFzZSBlbnRlciBhIHZhbGlkIDYtZGlnaXQgT1RQLlwiKTtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgb3RwUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWJyYW5jaCkge1xyXG4gICAgICBzZXRFcnJvcihcIlBsZWFzZSBzZWxlY3QgYSBicmFuY2guXCIpO1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoYC9hZG1pbi9vdHAtbG9naW4vJHthZG1pbklkfWAsIHtcclxuICAgICAgICBvdHAsXHJcbiAgICAgICAgYnJhbmNoSWQ6IGJyYW5jaC5faWQgfHwgYnJhbmNoLmlkLFxyXG4gICAgICAgIGJ5cGFzc090cDogb3RwID09PSBcIjg4ODg4OFwiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHsgdG9rZW4sIGFkbWluIH0gPSByZXNwb25zZS5kYXRhO1xyXG5cclxuICAgICAgaWYgKHRva2VuKSB7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJ0b2tlblwiLCB0b2tlbik7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJ1c2VyXCIsIEpTT04uc3RyaW5naWZ5KGFkbWluKSk7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJicmFuY2hcIiwgSlNPTi5zdHJpbmdpZnkoYnJhbmNoKSk7XHJcblxyXG4gICAgICAgIG5hdmlnYXRlKFwiL2Rhc2hib2FyZFwiKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRFcnJvcihcIkxvZ2luIGZhaWxlZC4gVG9rZW4gd2FzIG5vdCByZWNlaXZlZC5cIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihcclxuICAgICAgICBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHxcclxuICAgICAgICBcIkludmFsaWQgT1RQIG9yIHZlcmlmaWNhdGlvbiBmYWlsZWQuXCJcclxuICAgICAgKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gUmVzZW5kIE9UUFxyXG4gIGNvbnN0IGhhbmRsZVJlc2VuZE90cCA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldEVycm9yKFwiXCIpO1xyXG4gICAgc2V0TWVzc2FnZShcIlwiKTtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICBjb25zdCBhZG1pbklkID0gYWRtaW5JZFJlZi5jdXJyZW50Py52YWx1ZT8udHJpbSgpLnRvVXBwZXJDYXNlKCk7XHJcblxyXG4gICAgaWYgKCFhZG1pbklkIHx8ICFicmFuY2gpIHtcclxuICAgICAgc2V0RXJyb3IoXCJBZG1pbiBJRCBhbmQgYnJhbmNoIGFyZSByZXF1aXJlZC5cIik7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFxyXG4gICAgICAgIGAvYWRtaW4vcmUtZ2VuZXJhdGUtb3RwLyR7YWRtaW5JZH1gLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGJyYW5jaElkOiBicmFuY2guX2lkIHx8IGJyYW5jaC5pZCxcclxuICAgICAgICB9XHJcbiAgICAgICk7XHJcblxyXG4gICAgICBzZXRNZXNzYWdlKFxyXG4gICAgICAgIHJlc3BvbnNlLmRhdGEubWVzc2FnZSB8fCBcIkEgbmV3IE9UUCBoYXMgYmVlbiBzZW50LlwiXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBvdHBSZWYuY3VycmVudD8uZm9jdXMoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihcclxuICAgICAgICBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJDb3VsZCBub3QgcmVzZW5kIE9UUC5cIlxyXG4gICAgICApO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBSZXNldFxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZUFkbWluSWQgPSAoKSA9PiB7XHJcbiAgICBzZXRJc090cFNlbnQoZmFsc2UpO1xyXG4gICAgc2V0TWVzc2FnZShcIlwiKTtcclxuICAgIHNldEVycm9yKFwiXCIpO1xyXG5cclxuICAgIGlmIChvdHBSZWYuY3VycmVudCkge1xyXG4gICAgICBvdHBSZWYuY3VycmVudC52YWx1ZSA9IFwiXCI7XHJcbiAgICB9XHJcblxyXG4gICAgYWRtaW5JZFJlZi5jdXJyZW50Py5mb2N1cygpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiByZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gYmctc2xhdGUtOTAwXCI+XHJcbiAgICAgIDxpbWdcclxuICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGgtZnVsbCB3LWZ1bGwgb2JqZWN0LWNvdmVyIG9wYWNpdHktNjBcIlxyXG4gICAgICAgIHNyYz17bG9naW5JbWFnZX1cclxuICAgICAgICBhbHQ9XCJiZ1wiXHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctc2xhdGUtOTAwLzQwXCI+PC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgdy1mdWxsIG1heC13LW1kIG14LTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlLzk1IGJhY2tkcm9wLWJsdXItc20gcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBwLTggbWQ6cC0xMFwiPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaXplLTIwXCJcclxuICAgICAgICAgICAgICBzcmM9e0ltYWdlfVxyXG4gICAgICAgICAgICAgIGFsdD1cIkxvZ29cIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTZcIj5cclxuICAgICAgICAgICAgQWRtaW4gTG9naW5cclxuICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgb25TdWJtaXQ9e1xyXG4gICAgICAgICAgICAgIGlzT3RwU2VudFxyXG4gICAgICAgICAgICAgICAgPyBoYW5kbGVWZXJpZnlPdHBcclxuICAgICAgICAgICAgICAgIDogaGFuZGxlR2VuZXJhdGVPdHBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTVcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7LyogQnJhbmNoICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgQnJhbmNoIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc090cFNlbnR9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YnJhbmNoPy5faWQgfHwgYnJhbmNoPy5pZCB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkQnJhbmNoID0gYnJhbmNoZXMuZmluZChcclxuICAgICAgICAgICAgICAgICAgICAoaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIChpdGVtLmlkIHx8IGl0ZW0uX2lkKSA9PT0gZS50YXJnZXQudmFsdWVcclxuICAgICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgIHNldEJyYW5jaChzZWxlY3RlZEJyYW5jaCB8fCBudWxsKTtcclxuICAgICAgICAgICAgICAgICAgc2V0RXJyb3IoXCJcIik7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmxvY2sgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyLTAgcHktMi41IHB4LTMgdGV4dC1ncmF5LTkwMCBzaGFkb3ctc20gcmluZy0xIHJpbmctaW5zZXQgcmluZy1ncmF5LTMwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBzbTp0ZXh0LXNtICR7aXNPdHBTZW50XHJcbiAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTEwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBCcmFuY2g8L29wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICB7YnJhbmNoZXMubWFwKChicmFuY2hJdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb25cclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2JyYW5jaEl0ZW0uaWQgfHwgYnJhbmNoSXRlbS5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2JyYW5jaEl0ZW0uaWQgfHwgYnJhbmNoSXRlbS5faWR9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7YnJhbmNoSXRlbS5uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICBicmFuY2hJdGVtLmJyYW5jaE5hbWUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgIGJyYW5jaEl0ZW0uYnJhbmNoX25hbWV9e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICh7YnJhbmNoSXRlbS5icmFuY2hfY29kZX0pXHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgIHticmFuY2hlcy5sZW5ndGggPT09IDAgJiYgIWlzT3RwU2VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQteWVsbG93LTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIExvYWRpbmcgYnJhbmNoZXMuLi5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBBZG1pbiBJRCAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIEFkbWluIElEIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICByZWY9e2FkbWluSWRSZWZ9XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzT3RwU2VudH1cclxuICAgICAgICAgICAgICAgIG9uSW5wdXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID1cclxuICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZS50b1VwcGVyQ2FzZSgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgc2V0RXJyb3IoXCJcIik7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmxvY2sgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyLTAgcHktMi41IHB4LTMgdGV4dC1ncmF5LTkwMCBzaGFkb3ctc20gcmluZy0xIHJpbmctaW5zZXQgcmluZy1ncmF5LTMwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBzbTp0ZXh0LXNtICR7aXNPdHBTZW50XHJcbiAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTEwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlhYWC1YWC1YWFhYXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBPVFAgKi99XHJcbiAgICAgICAgICAgIHtpc090cFNlbnQgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1pbiBmYWRlLWluIHNsaWRlLWluLWZyb20tdG9wLTIgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgRW50ZXIgNi1EaWdpdCBPVFB7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICByZWY9e290cFJlZn1cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJudW1lcmljXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs2fVxyXG4gICAgICAgICAgICAgICAgICBvbklucHV0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID1cclxuICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlLnJlcGxhY2UoL1xcRC9nLCBcIlwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3IoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCByb3VuZGVkLW1kIGJvcmRlci0wIHB5LTIuNSBweC0zIHRleHQtZ3JheS05MDAgc2hhZG93LXNtIHJpbmctMSByaW5nLWluc2V0IHJpbmctZ3JheS0zMDAgdGV4dC1jZW50ZXIgdGV4dC14bCBmb250LWJvbGQgdHJhY2tpbmctd2lkZXN0IGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwMDAwMDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDaGFuZ2VBZG1pbklkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ibHVlLTYwMCBob3Zlcjp1bmRlcmxpbmUgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2hhbmdlIENyZWRlbnRpYWxzXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlc2VuZE90cH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ibHVlLTYwMCBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBSZXNlbmQgT1RQP1xyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIE5vdGlmaWNhdGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1bNjBweF0gZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICB7ZXJyb3IgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJnLXJlZC01MCBwLTMgYm9yZGVyIGJvcmRlci1yZWQtMTAwIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXJlZC04MDAgdGV4dC1jZW50ZXIgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiBtZXNzYWdlID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1tZCBiZy1ncmVlbi01MCBwLTMgYm9yZGVyIGJvcmRlci1ncmVlbi0xMDAgYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JlZW4tODAwIHRleHQtY2VudGVyIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge21lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdWJtaXQgKi99XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLW1kIGJnLWJsdWUtNjAwIHB4LTMgcHktMyB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctc20gaG92ZXI6YmctYmx1ZS03MDAgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS03MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIGgtNSB3LTUgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8Y2lyY2xlXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwib3BhY2l0eS0yNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY3g9XCIxMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgY3k9XCIxMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgcj1cIjEwXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiNFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm9wYWNpdHktNzVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNNCAxMmE4IDggMCAwMTgtOFYwQzUuMzczIDAgMCA1LjM3MyAwIDEyaDR6bTIgNS4yOTFBNy45NjIgNy45NjIgMCAwMTQgMTJIMGMwIDMuMDQyIDEuMTM1IDUuODI0IDMgNy45MzhsMy0yLjY0N3pcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIGlzT3RwU2VudCA/IFwiTG9naW5cIiA6IFwiU2VuZCBPVFBcIlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMb2dpbjsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvTG9naW4uanN4In0=