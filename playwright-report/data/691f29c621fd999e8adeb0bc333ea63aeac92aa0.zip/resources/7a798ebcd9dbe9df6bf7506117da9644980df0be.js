import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/BidRequest.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import {
  Form,
  Input,
  DatePicker,
  TimePicker,
  Button,
  Select,
  notification,
  Popconfirm,
  Spin,
  Modal,
  Radio,
  message,
  Switch
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  EditOutlined,
  DeleteOutlined,
  CheckCircleOutlined,
  PrinterOutlined,
  DownOutlined,
  UpOutlined,
  AppstoreOutlined,
  UnorderedListOutlined,
  StopOutlined,
  ShareAltOutlined,
  CloseOutlined,
  ClockCircleOutlined,
  DollarOutlined,
  SafetyOutlined,
  RiseOutlined,
  WhatsAppOutlined,
  ExclamationCircleOutlined,
  TrophyOutlined,
  SearchOutlined,
  FileTextOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import ModalComponent from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import __vite__cjsImport11_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport11_dayjs.__esModule ? __vite__cjsImport11_dayjs.default : __vite__cjsImport11_dayjs;
import API from "/src/instance/TokenInstance.js";
import image from "/src/assets/images/logoWB.png?import";
const { Option } = Select;
const user = JSON.parse(localStorage.getItem("user") || "{}");
const userRole = user?.admin_access_right_id?.title;
const canAccessBidRequest = userRole === "Super Administrator" || userRole === "Branch Manager";
function BidRequest() {
  _s();
  const isSuperAdmin = user?.role === "SUPER_ADMIN";
  const [api, contextHolder] = notification.useNotification();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editForm] = Form.useForm();
  const [openActionId, setOpenActionId] = useState(null);
  const [users, setUsers] = useState([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editGroups, setEditGroups] = useState([]);
  const [selectedEditGroupIndex, setSelectedEditGroupIndex] = useState(0);
  const [isGroupStatsOpen, setIsGroupStatsOpen] = useState(false);
  const [groupViewMode, setGroupViewMode] = useState("grid");
  const [viewType, setViewType] = useState("upcoming");
  const [rawBidRequests, setRawBidRequests] = useState([]);
  const [loadingTable, setLoadingTable] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [customerBalance, setCustomerBalance] = useState(null);
  const [loadingBalance, setLoadingBalance] = useState(false);
  const [showBalance, setShowBalance] = useState(false);
  const [permissions, setPermissions] = useState({});
  const [dropdownPosition, setDropdownPosition] = useState({
    visible: false,
    x: 0,
    y: 0,
    item: null
  });
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedGroupFilter, setSelectedGroupFilter] = useState("all");
  const [selectedPaymentStatus, setSelectedPaymentStatus] = useState("all");
  const [inputFromDate, setInputFromDate] = useState(null);
  const [inputToDate, setInputToDate] = useState(null);
  const [activeFromDate, setActiveFromDate] = useState(null);
  const [activeToDate, setActiveToDate] = useState(null);
  const [activeUserData, setActiveUserData] = useState({});
  const [selectAll, setSelectAll] = useState(false);
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [openStatusId, setOpenStatusId] = useState(null);
  useEffect(() => {
    const fetchPermissions = async () => {
      try {
        const response = await API.get("/user/get-permissions");
        setPermissions(response.data.access_permissions || {});
      } catch (error) {
        console.error("Failed to fetch permissions:", error);
        setPermissions({});
      }
    };
    if (isSuperAdmin) {
      fetchPermissions();
    }
  }, []);
  const handleOpenCreatePage = () => {
    window.open("/bid-request/create", "_blank", "noopener,noreferrer");
  };
  useEffect(() => {
    const handleFocus = () => {
      fetchBidRequests();
    };
    window.addEventListener("focus", handleFocus);
    return () => {
      window.removeEventListener("focus", handleFocus);
    };
  }, [viewType]);
  const fetchCustomerBalance = async (enrollmentId) => {
    if (!enrollmentId) return;
    setLoadingBalance(true);
    try {
      const response = await API.get(
        `/bid-request/get-balance/${enrollmentId}`
      );
      if (response.data?.data?.length > 0) {
        setCustomerBalance(response.data.data[0].balance);
      } else {
        setCustomerBalance(0);
      }
    } catch (error) {
      setCustomerBalance(0);
    } finally {
      setLoadingBalance(false);
    }
  };
  const fetchUsers = async () => {
    try {
      setLoadingUsers(true);
      const response = await API.get("/user/get-user");
      setUsers(response.data || []);
      setLoadingUsers(false);
    } catch (error) {
      setLoadingUsers(false);
    }
  };
  const fetchAuctionCount = async (groupId) => {
    if (!groupId) return 0;
    try {
      const response = await API.get(`/auction/get-group-auction/${groupId}`);
      return response.data.length;
    } catch (error) {
      return 0;
    }
  };
  const handleSingleStatusUpdate = async (id, newStatus) => {
    setOpenStatusId(null);
    setOpenActionId(null);
    try {
      setLoading(true);
      const item = rawBidRequests.find((r) => r._id === id);
      if (!item) return;
      const payload = {
        status: newStatus,
        enrollmentId: item.enrollmentId?._id || item.enrollmentId,
        groupId: item.groupId?._id || item.groupId
      };
      await API.put(`/bid-request/update/${id}`, payload);
      const statusMessages = {
        Pending: "Status updated to Pending",
        Accept: "Bid Request accepted successfully",
        Reject: "Bid Request reject successfully",
        NextAuction: "Posted to Next Auction successfully",
        Prized: "Bid Request marked as Prized successfully"
      };
      api.success({
        message: "Success",
        description: statusMessages[newStatus] || `Status updated to ${newStatus}`
      });
      fetchBidRequests();
    } catch (error) {
      console.error("Status update error:", error);
      api.error({
        message: "Error",
        description: error.response?.data?.message || "Failed to update status"
      });
    } finally {
      setLoading(false);
    }
  };
  const fetchEditCustomerDetails = async (userId, selectedEnrollmentId = null) => {
    try {
      const response = await API.post(
        `/enroll/get-user-tickets-report/${userId}`
      );
      if (response.data && response.data.length > 0) {
        const groupsDataPromise = response.data.map(async (item) => {
          const enrollment = item?.enrollment;
          const groupData = enrollment?.group;
          const groupId = groupData?._id;
          const auctionsDone = await fetchAuctionCount(groupId);
          const referredBy = groupData?.agent?.name && groupData?.agent?.phone_number ? `${groupData.agent.name} | ${groupData.agent.phone_number}` : groupData?.referred_customer?.full_name && groupData?.referred_customer?.phone_number ? `${groupData.referred_customer.full_name} | ${groupData.referred_customer.phone_number}` : groupData?.referred_lead?.lead_name && groupData?.referred_lead?.agent_number ? `${groupData.referred_lead.lead_name} | ${groupData.referred_lead.agent_number}` : "N/A";
          return {
            id: groupId,
            bid_request_code: groupData?.bid_request_code,
            groupName: groupData?.group_name || "No Group Name",
            ticketNumber: enrollment?.tickets || enrollment?.ticket_number || "N/A",
            startDate: groupData?.start_date ? groupData.start_date.split("T")[0] : "N/A",
            endDate: groupData?.end_date ? groupData.end_date.split("T")[0] : "N/A",
            auctionsDone,
            fullEnrollment: enrollment,
            enrollmentId: enrollment?._id,
            referredBy
          };
        });
        const groupsData = await Promise.all(groupsDataPromise);
        setEditGroups(groupsData);
        if (groupsData.length > 0) {
          let defaultIndex = 0;
          if (selectedEnrollmentId) {
            const foundIndex = groupsData.findIndex(
              (g) => g.enrollmentId === selectedEnrollmentId
            );
            if (foundIndex !== -1) {
              defaultIndex = foundIndex;
            }
          }
          setSelectedEditGroupIndex(defaultIndex);
          const selectedGroup = groupsData[defaultIndex];
          editForm.setFieldsValue({
            groupName: selectedGroup.groupName,
            ticketNumber: selectedGroup.ticketNumber,
            selectedGroupIndex: defaultIndex,
            startDate: selectedGroup.startDate,
            endDate: selectedGroup.endDate,
            auctionsDone: selectedGroup.auctionsDone,
            referredBy: selectedGroup.referredBy
          });
        }
      } else {
        setEditGroups([]);
        editForm.setFieldsValue({
          groupName: "No Groups Found",
          ticketNumber: "N/A",
          selectedGroupIndex: void 0,
          referredBy: "N/A"
        });
      }
    } catch (error) {
      console.error("Error fetching customer details:", error);
      api.error({
        message: "Error",
        description: "Failed to fetch customer group details."
      });
    }
  };
  const handleEditGroupSelect = async (index) => {
    setSelectedEditGroupIndex(index);
    const selectedGroup = editGroups[index];
    if (selectedGroup) {
      editForm.setFieldsValue({
        groupName: selectedGroup.groupName,
        ticketNumber: selectedGroup.ticketNumber,
        selectedGroupIndex: index,
        startDate: selectedGroup.startDate,
        endDate: selectedGroup.endDate,
        auctionsDone: selectedGroup.auctionsDone,
        referredBy: selectedGroup.referredBy
      });
      await fetchCustomerBalance(selectedGroup.enrollmentId);
    }
  };
  const handleOpenEditModal = async (item) => {
    setOpenActionId(null);
    setDropdownPosition({ ...dropdownPosition, visible: false });
    setEditingId(item._id);
    setShowBalance(true);
    setIsEditModalOpen(true);
    const userObj = typeof item.subscriberId === "object" ? item.subscriberId : {};
    const userId = userObj._id || item.subscriberId;
    const nameToDisplay = userObj.full_name || userObj.name || item.subscriberName || item.userName || "";
    const phoneToDisplay = userObj.phone_number || userObj.mobile || item.mobileNumber || item.mobileNumberRaw || "";
    const customerIdToDisplay = typeof userObj === "object" ? userObj.customer_id || "N/A" : "N/A";
    const adminObject = item.adminUserDetails || {};
    const adminName = adminObject.name || adminObject.full_name || item.adminName || "N/A";
    const adminPhone = item.adminPhone || "N/A";
    const adminDisplay = adminName !== "N/A" ? adminName : adminPhone !== "N/A" ? `Mobile: ${adminPhone}` : "N/A";
    const referredByFromTable = item?.agent?.name && item?.agent?.phone_number ? `${item.agent.name} | ${item.agent.phone_number}` : item?.referred_customer?.full_name && item?.referred_customer?.phone_number ? `${item.referred_customer.full_name} | ${item.referred_customer.phone_number}` : item?.referred_lead?.lead_name && item?.referred_lead?.agent_number ? `${item.referred_lead.lead_name} | ${item.referred_lead.agent_number}` : item.referredBy || "N/A";
    editForm.setFieldsValue({
      subscriberId: userId,
      subscriberName: nameToDisplay,
      mobileNumber: phoneToDisplay,
      customerId: customerIdToDisplay,
      bid_request_code: item.bid_request_code || "-",
      adminName: adminDisplay,
      auctionDate: item.auctionDate ? dayjs(item.auctionDate) : null,
      auctionTime: item.auction_time ? dayjs(item.auction_time, "HH:mm") : null,
      referredBy: referredByFromTable,
      requestDate: item.createdAt ? dayjs(item.createdAt) : dayjs(),
      groupName: item.groupName,
      ticketNumber: item.ticketNumber,
      enrollmentId: item.enrollmentId,
      groupId: item.groupId?._id || item.groupId || item.groupId?.id
    });
    setCustomerBalance(item.auctions?.balance || 0);
    if (users.length === 0) await fetchUsers();
    await fetchEditCustomerDetails(userId, item.enrollmentId);
    if (item.enrollmentId) {
      await fetchCustomerBalance(item.enrollmentId);
    }
  };
  const handleShare = async (item) => {
    setOpenActionId(null);
    setDropdownPosition({ ...dropdownPosition, visible: false });
    const bidRequestId = item._id;
    if (!bidRequestId) {
      console.error("No bid request ID found");
      message.error("Unable to share: Request information not found");
      return;
    }
    const frontendUrl = window.location.origin;
    const fullUrl = `${frontendUrl}/bid-request/share/${bidRequestId}`;
    window.open(fullUrl, "_blank");
  };
  const handleCloseEditModal = () => {
    setIsEditModalOpen(false);
    editForm.resetFields();
    setEditGroups([]);
    setCustomerBalance(null);
    setShowBalance(false);
    setEditingId(null);
  };
  const updateStatus = async (newStatus) => {
    try {
      setLoading(true);
      const values = await editForm.validateFields();
      const groupIndex = values.selectedGroupIndex ?? selectedEditGroupIndex;
      const selectedGroup = editGroups[groupIndex];
      if (!selectedGroup) {
        api.error({
          message: "Error",
          description: "Group details not found. Please select a valid group."
        });
        setLoading(false);
        return;
      }
      const auctionDate = values.auctionDate?.format("YYYY-MM-DD");
      const auctionTime = values.auctionTime?.format("HH:mm");
      const requestDate = values.requestDate?.format("YYYY-MM-DD");
      const payload = {
        subscriberId: values.subscriberId,
        subscriberName: values.subscriberName,
        mobileNumber: values.mobileNumber,
        customerId: values.customerId,
        groupName: selectedGroup.groupName,
        ticketNumber: selectedGroup.ticketNumber,
        auctionDate,
        auction_time: auctionTime,
        auctionTime,
        referredBy: values.referredBy,
        referred_by: values.referredBy,
        groupId: selectedGroup.id,
        enrollmentId: selectedGroup.enrollmentId,
        status: newStatus,
        requestDate,
        updatedBy: users.find((u) => u._id === values.subscriberId)?._id
      };
      await API.put(`/bid-request/update/${editingId}`, payload);
      const statusMessages = {
        Pending: "Bid Request moved to Pending successfully",
        Accept: "Bid Request accepted successfully",
        Reject: "Bid Request Rejected successfully",
        NextAuction: "Post to Next Auction successfully",
        Prized: "Bid Request marked as Prized successfully"
      };
      api.success({
        message: "Status Updated",
        description: statusMessages[newStatus] || `Status updated to ${newStatus}`
      });
      handleCloseEditModal();
      fetchBidRequests();
    } catch (error) {
      console.error("❌ Update Error:", error);
      let errorMessage = "Failed to update status.";
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.errors) {
        errorMessage = Object.values(error.response.data.errors).flat().join(", ");
      } else if (error.errorFields) {
        errorMessage = error.errorFields.map((f) => `${f.name.join(".")}: ${f.errors.join(", ")}`).join("; ");
      }
      api.error({ message: "Update Failed", description: errorMessage });
    } finally {
      setLoading(false);
    }
  };
  const handleSetPending = async () => {
    await updateStatus("Pending");
  };
  const handleSetAccept = async () => {
    await updateStatus("Accept");
  };
  const handleSetReject = async () => {
    await updateStatus("Reject");
  };
  const handleSetNextauction = async () => {
    await updateStatus("NextAuction");
  };
  const handleSetPrized = async () => {
    await updateStatus("Prized");
  };
  const handleBulkStatusUpdate = (newStatus) => {
    const selectedItems = filteredBidRequests.filter(
      (item) => activeUserData[item._id]?.info?.status
    );
    if (selectedItems.length === 0) return;
    Modal.confirm({
      title: `Bulk Update Confirmation`,
      icon: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
        lineNumber: 512,
        columnNumber: 13
      }, this),
      content: `You are about to update status to "${newStatus}" for ${selectedItems.length} requests. Are you sure?`,
      okText: "Yes, Update",
      cancelText: "No",
      onOk: async () => {
        setLoading(true);
        try {
          const promises = selectedItems.map((item) => {
            const payload = {
              status: newStatus,
              enrollmentId: item.enrollmentId?._id || item.enrollmentId,
              groupId: item.groupId?._id || item.groupId
            };
            return API.put(`/bid-request/update/${item._id}`, payload);
          });
          await Promise.all(promises);
          api.success({
            message: "Success",
            description: `${selectedItems.length} requests updated to ${newStatus}`
          });
          setActiveUserData({});
          setSelectAll(false);
          fetchBidRequests();
        } catch (err) {
          api.error({
            message: "Error",
            description: "Failed to update some requests."
          });
        } finally {
          setLoading(false);
        }
      }
    });
  };
  const handleDateSearch = () => {
    setActiveFromDate(inputFromDate);
    setActiveToDate(inputToDate);
  };
  const handleClearFilters = () => {
    setSelectedStatus("all");
    setSelectedGroupFilter("all");
    setSelectedPaymentStatus("all");
    setInputFromDate(null);
    setInputToDate(null);
    setActiveFromDate(null);
    setActiveToDate(null);
  };
  const handleOpenVerifyModal = () => setIsVerifyModalOpen(true);
  const handleCloseVerifyModal = () => setIsVerifyModalOpen(false);
  const handleSendWhatsApp = async () => {
    setIsSending(true);
    try {
      const selectedItems = filteredBidRequests.filter(
        (item) => activeUserData[item._id]?.info?.status
      );
      const receivers = {};
      selectedItems.forEach((item) => {
        const userObj = typeof item.subscriberId === "object" ? item.subscriberId : {};
        const groupObj = typeof item.groupId === "object" ? item.groupId : {};
        const enrollmentId = item.enrollmentId?._id || item.enrollmentId || item.enrollment?._id || item.enrollment;
        receivers[item._id] = {
          info: {
            status: true,
            subscriberName: item.subscriberName || userObj.full_name || "N/A",
            mobileNumber: item.mobileNumber || userObj.phone_number || "N/A",
            groupName: item.groupName || groupObj.group_name || "N/A",
            ticketNumber: item.ticketNumber || "N/A",
            bidRequestId: item._id,
            enrollmentId,
            groupId: groupObj._id || item.groupId,
            subscriberId: userObj._id || item.subscriberId
          }
        };
      });
      await API.post("/whatsapp/bid-request-balance-check", receivers);
      api.success({
        message: "Success",
        description: "WhatsApp messages initiated successfully!"
      });
      const newActiveData = { ...activeUserData };
      selectedItems.forEach((item) => delete newActiveData[item._id]);
      setActiveUserData(newActiveData);
      setIsVerifyModalOpen(false);
    } catch (err) {
      console.error(err);
      api.error({
        message: "Error",
        description: err.response?.data?.message || "Failed to send messages."
      });
    } finally {
      setIsSending(false);
    }
  };
  const handleDelete = async (id) => {
    setOpenActionId(null);
    setDropdownPosition({ ...dropdownPosition, visible: false });
    try {
      await API.delete(`/bid-request/delete/${id}`);
      api.success({ message: "Deleted", description: "Deleted successfully." });
      fetchBidRequests();
    } catch (error) {
      api.error({ message: "Error", description: "Failed to delete." });
    }
  };
  const confirmDelete = (id) => {
    Modal.confirm({
      title: "Are you sure delete this bid request?",
      content: "This action cannot be undone.",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete(id);
      }
    });
  };
  const handlePrint = (item) => {
    setOpenActionId(null);
    setDropdownPosition({ ...dropdownPosition, visible: false });
    const userObj = typeof item.subscriberId === "object" ? item.subscriberId : {};
    const userName = item.subscriberName || userObj.full_name || "N/A";
    const userPhone = item.mobileNumber || userObj.phone_number || "N/A";
    const groupName = item.groupName || item.groupId?.group_name || "N/A";
    const balance = item.auctions?.balance || 0;
    const ticketNumber = item.ticketNumber || "N/A";
    const customerId = typeof userObj === "object" ? userObj.customer_id || userObj._id || "N/A" : "N/A";
    const requestDate = item.createdAt ? new Date(item.createdAt).toLocaleDateString("en-GB", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).replace(/\//g, "-") : "N/A";
    const auctionDate = item.auctionDate ? new Date(item.auctionDate).toLocaleDateString("en-GB", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).replace(/\//g, "-") : "N/A";
    const printWindow = window.open("", "_blank");
    const generateForm = () => `
      <div class="flex flex-col h-full p-3 font-serif text-[11px] text-black">
        <div class="flex justify-between items-center border-b-2 border-black pb-2 mb-3">
          <div class="flex items-center gap-2">
            <img src="${image}" alt="Logo" class="h-12 w-auto" />
            <div class="">
              <h1 class="text-sm font-bold text-blue-900 uppercase leading-tight ml-6">VIJAYA VINAYAK CHIT FUNDS (P) LTD</h1>
              <h1 class="text-xl font-extrabold text-yellow-600 uppercase text-center ml-3">Bid Requesting Letter</h1>
            </div>
          </div>
        </div>
        <div class="flex-grow space-y-3">
          <div class="grid grid-cols-4 gap-3">
            <div class="flex items-center">
              <span class="w-10 font-semibold">Date:</span>
              <div class="border-b border-black flex-grow h-4 pl-1 text-black">${requestDate}</div>
            </div>
            <div class="col-span-3 flex items-center ml-40">
              <span class="w-10 font-semibold">Place:</span>
              <div class="border-b border-black flex-grow h-4 pl-1 text-black">Bangalore</div>
            </div>
          </div>
          <div class="flex items-center py-1 px-1 rounded">
            <span class="w-32 font-bold text-black">Subscriber Name:</span>
            <div class="border-b border-black flex-grow h-4 pl-1 text-black">${userName}</div>
          </div>
          <div class="flex items-center py-1 px-1 rounded">
            <span class="w-32 font-bold text-black">Subscriber ID:</span>
            <div class="border-b border-black flex-grow h-4 pl-1 text-black">${customerId}</div>
          </div>
          <div class="flex items-center">
            <span class="w-32 font-semibold">Mobile Number:</span>
            <div class="border-b border-black flex-grow h-4 pl-1 text-black">${userPhone}</div>
          </div>
          <div class="flex items-center">
            <span class="w-32 font-semibold">Group Name:</span>
            <div class="border-b border-black flex-grow h-4 pl-1 text-black">${groupName}</div>
          </div>
          <div class="flex items-center">
            <span class="w-32 font-semibold">Ticket No:</span>
            <div class="border-b border-black flex-grow h-4 pl-1 text-black">${ticketNumber}</div>
          </div>
          <div class="flex items-center text-[10px] text-black">
            <span class="w-32 font-semibold">Current Status:</span>
            <span class="ml-2">
              <span class="font-bold ${balance <= 0 ? "text-green-700" : "text-red-600"}">
                ${balance <= 0 ? "Excess: " : "Due: "}₹ ${Math.abs(balance)}
              </span>
            </span>
          </div>
          <div class="border border-gray-400 rounded p-2 bg-gray-50">
            <div class="font-bold text-xs mb-1 uppercase text-yellow-600 border-b border-gray-300 pb-0.5">Chit Requesting Details</div>
            <div class="grid grid-cols-3 gap-2">
              <div>
                <span class="font-semibold block text-[10px]">Installment</span>
                <div class="border-b border-black h-4 pl-1 text-black"></div>
              </div>
              <div>
                <span class="font-semibold block text-[10px]">Month</span>
                <div class="border-b border-black h-4 pl-1 text-black">${auctionDate !== "N/A" ? new Date(auctionDate).toLocaleString("default", { month: "long" }) : "N/A"}</div>
              </div>
              <div>
                <span class="font-semibold block text-[10px]">Date</span>
                <div class="border-b border-black h-4 pl-1 text-black">${auctionDate}</div>
              </div>
            </div>
          </div>
          <div class="mt-4 pt-2 border-t border-gray-300">
            <div class="flex justify-between items-end">
              <div>
                <div class="h-8 border-b border-black w-48 mb-1"></div>
                <span class="font-bold text-xs">Employee Signature</span>
              </div>
              <div class="text-[9px] italic">
                <div class="h-8 border-b border-black w-48 mb-1"></div>
                <span class="font-bold text-xs">Customer Signature</span>
              </div>
            </div>
          </div>
        </div>
        <div class="mt-2 pt-2 border-t-2 border-dashed border-gray-400 bg-gray-100 p-2 rounded text-[10px]">
          <div class="flex justify-between items-center mb-1">
            <span class="font-bold uppercase text-black">For Office Use Only</span>
            <span class="text-black">ID: ${customerId}</span>
          </div>
          <div class="grid grid-cols-2 gap-2">
            <div class="border border-gray-300 bg-white p-1 rounded">
              <span class="block text-[9px] text-black">Check:</span>
              <div class="h-3"></div>
            </div>
            <div class="border border-gray-300 bg-white p-1 rounded">
              <span class="block text-[9px] text-black">Auth:</span>
              <div class="h-3"></div>
            </div>
          </div>
        </div>
      </div>
    `;
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Bid Request Form</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <style>
          @media print {
            @page { size: A4 landscape; margin: 0.5cm; }
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; margin: 0; padding: 0; }
          }
          body { background: #e5e7eb; font-family: 'Times New Roman', serif; }
          .landscape-page {
            width: 29.7cm;
            height: 20cm;
            background: white;
            display: flex;
            margin: 0 auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
          }
          .split-page {
            flex: 1;
            border-right: 2px dashed #ccc;
            padding: 0.5cm;
            box-sizing: border-box;
          }
          .split-page:last-child { border-right: none; }
        </style>
      </head>
      <body>
        <div class="landscape-page">
          <div class="split-page">${generateForm()}</div>
          <div class="split-page">${generateForm()}</div>
        </div>
        <script>
          window.onload = function() {
            window.print();
            setTimeout(function() { window.close(); }, 1000);
          };
        <\/script>
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
  };
  const fetchBidRequests = async () => {
    try {
      setLoadingTable(true);
      const response = await API.get(`/bid-request/get-all?type=${viewType}`);
      setRawBidRequests(response.data?.data || []);
      const tempActive = {};
      response.data?.data?.forEach((item) => {
        const id = item._id;
        const userObj = typeof item.subscriberId === "object" ? item.subscriberId : {};
        tempActive[id] = {
          info: {
            status: false,
            userName: item.subscriberName || userObj.full_name,
            userPhone: item.mobileNumber || userObj.phone_number
          }
        };
      });
      setActiveUserData(tempActive);
    } catch (error) {
      setRawBidRequests([]);
    } finally {
      setLoadingTable(false);
    }
  };
  const uniqueGroups = useMemo(() => {
    const groups = rawBidRequests.map((item) => {
      const groupObject = item?.groupId || {};
      return item.groupName || (typeof groupObject === "object" ? groupObject.group_name : "N/A");
    }).filter((value, index, self2) => value && self2.indexOf(value) === index);
    return groups;
  }, [rawBidRequests]);
  const statsBaseData = useMemo(
    () => {
      return rawBidRequests.filter((item) => {
        if (selectedStatus !== "all" && item.status !== selectedStatus)
          return false;
        if (selectedGroupFilter !== "all") {
          const groupObject = item?.groupId || {};
          const groupName = item.groupName || (typeof groupObject === "object" ? groupObject.group_name : "N/A");
          if (groupName !== selectedGroupFilter) return false;
        }
        if (activeFromDate || activeToDate) {
          const itemDate = item.createdAt ? dayjs(item.createdAt) : null;
          if (!itemDate) return false;
          if (activeFromDate && itemDate.isBefore(dayjs(activeFromDate), "day"))
            return false;
          if (activeToDate && itemDate.isAfter(dayjs(activeToDate), "day"))
            return false;
        }
        return true;
      });
    },
    [
      rawBidRequests,
      selectedStatus,
      selectedGroupFilter,
      activeFromDate,
      activeToDate
    ]
  );
  const filteredBidRequests = useMemo(() => {
    if (selectedPaymentStatus === "all") return statsBaseData;
    return statsBaseData.filter((item) => {
      const balance = item.auctions?.balance || 0;
      if (selectedPaymentStatus === "pending") return balance > 0;
      if (selectedPaymentStatus === "uptodate") return balance <= 0;
      return true;
    });
  }, [statsBaseData, selectedPaymentStatus]);
  const summaryStats = useMemo(() => {
    const dataToAnalyze = statsBaseData;
    const totalRequests = dataToAnalyze?.length || 0;
    const pendingRequests = dataToAnalyze?.filter((item) => item?.status === "Pending")?.length || 0;
    const acceptRequests = dataToAnalyze?.filter((item) => item?.status === "Accept")?.length || 0;
    const rejectRequests = dataToAnalyze?.filter((item) => item?.status === "Reject")?.length || 0;
    const nextauctionRequests = dataToAnalyze?.filter((item) => item?.status === "NextAuction")?.length || 0;
    const prizedRequests = dataToAnalyze?.filter((item) => item?.status === "Prized")?.length || 0;
    const totalBalance = dataToAnalyze?.reduce(
      (sum, item) => sum + (item?.auctions?.balance || 0),
      0
    ) || 0;
    const totalAmountPaid = dataToAnalyze?.reduce(
      (sum, item) => sum + (item?.auctions?.amount_paid || item?.amount_paid || 0),
      0
    ) || 0;
    const groupStats = {};
    (dataToAnalyze || []).forEach((item) => {
      if (!item) return;
      const groupObject = item?.groupId || {};
      const groupName = item?.groupName || (typeof groupObject === "object" ? groupObject?.group_name : "Unknown");
      if (!groupName) return;
      if (!groupStats[groupName]) {
        groupStats[groupName] = {
          total: 0,
          pending: 0,
          accept: 0,
          nextauction: 0,
          reject: 0,
          prized: 0,
          next_auction_date: null,
          next_auction_display: "N/A",
          last_auction_date: null,
          bidding_open_count: 0,
          total_balance: 0,
          groupId: groupObject?._id || item.groupId?._id || item.groupId
        };
      }
      groupStats[groupName].total++;
      groupStats[groupName].total_balance += item.auctions?.balance || 0;
      if (item.status === "Pending") groupStats[groupName].pending++;
      if (item.status === "Accept") groupStats[groupName].accept++;
      if (item.status === "Reject") groupStats[groupName].reject++;
      if (item.status === "NextAuction") groupStats[groupName].nextauction++;
      if (item.status === "Prized") groupStats[groupName].prized++;
      const nextDate = item.auctionDate;
      if (nextDate) {
        const currentStoredDate = groupStats[groupName].next_auction_date;
        const nextDateObj = dayjs(nextDate);
        if (!currentStoredDate || nextDateObj.isBefore(dayjs(currentStoredDate))) {
          groupStats[groupName].next_auction_date = nextDate;
          groupStats[groupName].next_auction_display = nextDateObj.isValid() ? nextDateObj.format("DD-MM-YYYY") : "N/A";
        }
      }
      if (item.bid_status === "bidding_open") {
        groupStats[groupName].bidding_open_count++;
      }
    });
    const paymentStats = {
      pending: { count: 0, amount: 0 },
      upToDate: { count: 0 }
    };
    (dataToAnalyze || []).forEach((item) => {
      const balance = item?.auctions?.balance || 0;
      if (balance > 0) {
        paymentStats.pending.count++;
        paymentStats.pending.amount += balance;
      } else {
        paymentStats.upToDate.count++;
      }
    });
    return {
      totalRequests: totalRequests || 0,
      pendingRequests: pendingRequests || 0,
      acceptRequests: acceptRequests || 0,
      rejectRequests: rejectRequests || 0,
      nextauctionRequests: nextauctionRequests || 0,
      prizedRequests: prizedRequests || 0,
      totalBalance: totalBalance || 0,
      totalAmountPaid: totalAmountPaid || 0,
      groupStats: groupStats || {},
      paymentStats: paymentStats || {
        pending: { count: 0, amount: 0 },
        upToDate: { count: 0 }
      }
    };
  }, [statsBaseData]);
  const selectedCount = useMemo(() => {
    return filteredBidRequests.filter(
      (item) => activeUserData[item._id]?.info?.status
    ).length;
  }, [filteredBidRequests, activeUserData]);
  const formattedBidData = useMemo(() => {
    return filteredBidRequests.map((item, index) => {
      const userObject = item?.subscriberId || {};
      const groupObject = item?.groupId || {};
      const userName = item.subscriberName || (typeof userObject === "object" ? userObject.full_name : "N/A");
      const userPhone = item.mobileNumber || (typeof userObject === "object" ? userObject.phone_number : "N/A");
      const userId = typeof userObject === "object" ? userObject._id : userObject;
      const customerId = typeof userObject === "object" ? userObject.customer_id || "N/A" : "N/A";
      const groupName = item.groupName || (typeof groupObject === "object" ? groupObject.group_name : "N/A");
      const instanceBalance = item?.instanceBalance || 0;
      const currentBalance = item?.auctions?.balance || 0;
      const amountPaid = item?.auctions?.amount_paid || item?.amount_paid || 0;
      const totalToBePaid = item?.auctions?.total_to_be_paid || 0;
      let createdBy = "N/A";
      const adminObject = item.adminUserDetails || {};
      const adminNameFromLookup = adminObject.name || adminObject.full_name;
      const adminNameStored = item.adminName;
      if (adminNameStored) {
        createdBy = adminNameStored;
      } else if (adminNameFromLookup) {
        createdBy = adminNameFromLookup;
      } else {
        createdBy = item.subscriberName || userName || userPhone || "Customer";
      }
      const referredBy = item?.agent?.name && item?.agent?.phone_number ? `${item.agent.name} | ${item.agent.phone_number}` : item?.referred_customer?.full_name && item?.referred_customer?.phone_number ? `${item.referred_customer.full_name} | ${item.referred_customer.phone_number}` : item?.referred_lead?.lead_name && item?.referred_lead?.agent_number ? `${item.referred_lead.lead_name} | ${item.referred_lead.agent_number}` : "N/A";
      const enrollmentId = item.enrollmentId?._id || item.enrollmentId;
      const bidRequestCode = item.bid_request_code || "-";
      const isSelected = !!activeUserData[item._id]?.info?.status;
      const requestSource = item?.source || "Chit-Admin";
      let auctionDateDisplay = "-";
      let auctionDateRaw = null;
      if (item.auctionDate) {
        auctionDateRaw = item.auctionDate;
        auctionDateDisplay = dayjs(item.auctionDate).format("DD-MM-YYYY");
      }
      return {
        key: item._id,
        _id: item._id,
        id: index + 1,
        userName,
        groupName,
        customerId,
        mobileNumber: userPhone,
        phoneNumber: userPhone,
        date: item.createdAt ? item.createdAt.split("T")[0] : "-",
        ticketNumber: item.ticketNumber || "-",
        bid_request_code: bidRequestCode,
        source: requestSource,
        auctionDateDisplay,
        // This will show the next_date
        auctionDate: auctionDateRaw,
        auctionTime: item.auction_time ? dayjs(item.auction_time, "HH:mm").format("h:mm A") : "-",
        enable_bid_request: item.enable_bid_request || false,
        bid_status: item.bid_status || "unknown",
        days_until_auction: item.days_until_auction || 0,
        referredBy,
        instanceBalanceValue_raw: instanceBalance || 0,
        instanceBalanceValue: /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: instanceBalance <= 0 ? "text-green-600 font-semibold" : "text-red-600 font-semibold",
            children: [
              "₹ ",
              instanceBalance.toLocaleString("en-IN")
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1109,
            columnNumber: 9
          },
          this
        ),
        currentBalanceValue_raw: currentBalance || 0,
        currentBalanceValue: /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: currentBalance <= 0 ? "text-green-600 font-semibold" : "text-red-600 font-semibold",
            children: [
              "₹ ",
              currentBalance.toLocaleString("en-IN")
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1122,
            columnNumber: 9
          },
          this
        ),
        amountPaidValue_raw: amountPaid || 0,
        amountPaidValue: /* @__PURE__ */ jsxDEV("span", { className: "text-blue-600 font-semibold", children: [
          "₹ ",
          amountPaid.toLocaleString("en-IN")
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1135,
          columnNumber: 9
        }, this),
        enrollmentId,
        checkBox: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [item._id]: {
                  info: {
                    status: e.target.checked,
                    userName,
                    userPhone
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1142,
            columnNumber: 9
          },
          this
        ),
        status: item.status || "Pending",
        subscriberName: item.subscriberName || userName,
        subscriberId: userId,
        mobileNumberRaw: item.mobileNumber || userPhone,
        action: /* @__PURE__ */ jsxDEV("div", { className: "relative text-center dropdown-trigger", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: (e) => {
              e.stopPropagation();
              const rect = e.currentTarget.getBoundingClientRect();
              setDropdownPosition({
                visible: !dropdownPosition.visible || dropdownPosition.item?._id !== item._id,
                x: rect.right - 160,
                y: rect.bottom + 5,
                item: dropdownPosition.visible && dropdownPosition.item?._id === item._id ? null : item
              });
              setOpenStatusId(null);
            },
            className: "p-2 rounded-full hover:bg-gray-200 relative",
            style: { zIndex: 100 },
            children: "⋮"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1165,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1164,
          columnNumber: 9
        }, this)
      };
    });
  }, [filteredBidRequests, dropdownPosition, activeUserData]);
  useEffect(() => {
    const allChecked = filteredBidRequests.length > 0 && filteredBidRequests.every(
      (item) => activeUserData[item._id]?.info?.status
    );
    setSelectAll(allChecked);
  }, [filteredBidRequests, activeUserData]);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".dropdown-trigger") && !event.target.closest(".dropdown-menu")) {
        setOpenActionId(null);
        setOpenStatusId(null);
        setDropdownPosition({ ...dropdownPosition, visible: false });
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [dropdownPosition]);
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "bid_request_code", header: "Bid Request Code" },
    { key: "date", header: "Request Date" },
    { key: "auctionTime", header: "Request Time" },
    { key: "userName", header: "Subscriber Name" },
    { key: "phoneNumber", header: "Phone Number" },
    { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" },
    { key: "ticketNumber", header: "Ticket" },
    { key: "auctionDateDisplay", header: "Auction Date" },
    { key: "referredBy", header: "Referred By" },
    { key: "source", header: "Track Source" },
    { key: "amountPaidValue", header: "Amount Paid" },
    // { key: "instanceBalanceValue", header: "Balance (At Request)" },
    { key: "currentBalanceValue", header: "Current Balance" },
    { key: "checkBox", header: "Select" },
    { key: "status", header: "Status" },
    { key: "action", header: "Action", width: 180 }
  ];
  const excelcolumns = [
    { key: "id", header: "SL. NO" },
    { key: "bid_request_code", header: "Bid Request Code" },
    { key: "date", header: "Request Date" },
    { key: "auctionTime", header: "Request Time" },
    { key: "userName", header: "Subscriber Name" },
    { key: "phoneNumber", header: "Phone Number" },
    { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" },
    { key: "ticketNumber", header: "Ticket" },
    { key: "auctionDateDisplay", header: "Auction Date" },
    { key: "referredBy", header: "Referred By" },
    { key: "source", header: "Track Source" },
    { key: "amountPaidValue_raw", header: "Amount Paid" },
    { key: "instanceBalanceValue_raw", header: "Balance (At Request)" },
    { key: "currentBalanceValue_raw", header: "Current Balance" },
    { key: "status", header: "Status" },
    { key: "action", header: "Action", width: 180 }
  ];
  useEffect(() => {
    fetchBidRequests();
  }, [viewType]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
      lineNumber: 1268,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-screen mt-14", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
        lineNumber: 1270,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "w-full p-4 min-h-[80vh]", children: [
        isSuperAdmin && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg shadow p-4 mb-6 border border-purple-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between flex-wrap gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-600 text-white rounded-full h-10 w-10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(SafetyOutlined, { className: "text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1278,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1277,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-800", children: "Super Admin Settings" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1281,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Configure feature permissions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1282,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1280,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1276,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 flex-wrap", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-700", children: "Bid Request Access:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1288,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Switch,
              {
                checked: permissions?.bid_request || false,
                onChange: async (checked) => {
                  try {
                    await API.post("/user/update-permissions", {
                      bid_request: checked
                    });
                    setPermissions((prev) => ({ ...prev, bid_request: checked }));
                    message.success(`Bid request access ${checked ? "enabled" : "disabled"}`);
                  } catch (error) {
                    message.error("Failed to update permissions");
                  }
                },
                className: "bg-purple-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1289,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1287,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1286,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1275,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1274,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center gap-4 mb-8 mt-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-center md:text-left space-y-2 ml-4", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-800", children: "Bid Management" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1313,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "Submit a new bid request for an auction" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1316,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1312,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "default",
                size: "large",
                onClick: () => window.open(
                  "/reports/bid-request-report",
                  "_blank",
                  "noopener,noreferrer"
                ),
                className: "h-10 px-6 text-lg font-semibold bg-green-600 hover:bg-green-700 text-white rounded-md shadow-lg",
                icon: /* @__PURE__ */ jsxDEV(FileTextOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1332,
                  columnNumber: 23
                }, this),
                children: "View Report"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1321,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                size: "large",
                onClick: handleOpenCreatePage,
                className: "h-10 px-6 text-lg font-semibold bg-blue-800 hover:bg-blue-700 rounded-md shadow-lg",
                children: "+ Bid Request"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1336,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1320,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1311,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(SearchOutlined, { className: "text-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1351,
                  columnNumber: 19
                }, this),
                "Search Filter"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1350,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "Filter bid requests by status, group, payment, or date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1354,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1349,
              columnNumber: 15
            }, this),
            (selectedStatus !== "all" || selectedGroupFilter !== "all" || selectedPaymentStatus !== "all" || activeFromDate || activeToDate) && /* @__PURE__ */ jsxDEV(
              Button,
              {
                onClick: handleClearFilters,
                className: "text-white bg-blue-500 hover:bg-blue-600",
                children: "Clear All Filters"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1363,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1348,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[280px]", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Date Range" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1374,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  DatePicker,
                  {
                    style: { width: "100%" },
                    value: inputFromDate,
                    onChange: setInputFromDate,
                    format: "DD-MM-YYYY",
                    placeholder: "From Date",
                    size: "large"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1378,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  DatePicker,
                  {
                    style: { width: "100%" },
                    value: inputToDate,
                    onChange: setInputToDate,
                    format: "DD-MM-YYYY",
                    placeholder: "To Date",
                    size: "large"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1386,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1377,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1373,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[150px]", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Request Status" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1398,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: selectedStatus,
                  onChange: setSelectedStatus,
                  className: "w-full",
                  size: "large",
                  children: [
                    /* @__PURE__ */ jsxDEV(Option, { value: "all", children: "All Status" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1407,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Option, { value: "Pending", children: "Pending" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1408,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Option, { value: "Accept", children: "Accept" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1409,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Option, { value: "Reject", children: "Rejected" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1410,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Option, { value: "NextAuction", children: "Next Auction" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1411,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Option, { value: "Prized", children: "Prized" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1412,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1401,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1397,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[150px]", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Payment Status" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1417,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: selectedPaymentStatus,
                  onChange: setSelectedPaymentStatus,
                  className: "w-full",
                  size: "large",
                  children: [
                    /* @__PURE__ */ jsxDEV(Option, { value: "all", children: "All Payments" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1426,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Option, { value: "pending", children: "Payment Pending" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1427,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Option, { value: "uptodate", children: "Up to Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1428,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Option, { value: "excess", children: "Excess" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1429,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1420,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1416,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[150px]", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Group Filter" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1434,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: selectedGroupFilter,
                  onChange: setSelectedGroupFilter,
                  className: "w-full",
                  size: "large",
                  showSearch: true,
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  children: [
                    /* @__PURE__ */ jsxDEV(Option, { value: "all", children: "All Groups" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1447,
                      columnNumber: 19
                    }, this),
                    uniqueGroups.map(
                      (group) => /* @__PURE__ */ jsxDEV(Option, { value: group, children: group }, group, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 1449,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1437,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1433,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 min-w-[100px]", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1 text-center", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1457,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-10", children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  className: "w-5 h-5 cursor-pointer accent-blue-600",
                  checked: selectAll,
                  onChange: (e) => {
                    const checked = e.target.checked;
                    setSelectAll(checked);
                    const updated = { ...activeUserData };
                    filteredBidRequests.forEach((item) => {
                      const userObject = item?.subscriberId || {};
                      const userName = item.subscriberName || (typeof userObject === "object" ? userObject.full_name : "N/A");
                      const userPhone = item.mobileNumber || (typeof userObject === "object" ? userObject.phone_number : "N/A");
                      updated[item._id] = {
                        info: { status: checked, userName, userPhone }
                      };
                    });
                    setActiveUserData(updated);
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1461,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1460,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1456,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                size: "large",
                icon: /* @__PURE__ */ jsxDEV(SearchOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1494,
                  columnNumber: 23
                }, this),
                onClick: handleDateSearch,
                children: "Search"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1491,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1372,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1347,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700 mb-3", children: "Auction Winner" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1503,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `bg-white rounded-lg shadow p-4 border-l-4 border-purple-500 cursor-pointer hover:shadow-lg transition-all ${selectedStatus === "Prized" ? "ring-2 ring-purple-500 bg-purple-50" : ""}`,
              onClick: () => setSelectedStatus(
                selectedStatus === "Prized" ? "all" : "Prized"
              ),
              children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Bid Prized " }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1517,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-purple-600", children: summaryStats.prizedRequests || 0 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1518,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1516,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-purple-100 rounded-full", children: /* @__PURE__ */ jsxDEV(TrophyOutlined, { className: "text-purple-600 text-xl" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1523,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1522,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1515,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1507,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1506,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1502,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700 mb-3", children: "Bid Request's" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1531,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-5 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-blue-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Total Requests" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1538,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold", children: summaryStats.totalRequests }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1539,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1537,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-blue-100 rounded-full", children: /* @__PURE__ */ jsxDEV(
                "svg",
                {
                  className: "w-6 h-6 text-blue-600",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                  children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1550,
                      columnNumber: 23
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1544,
                  columnNumber: 21
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1543,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1536,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1535,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `bg-white rounded-lg shadow p-4 border-l-4 border-yellow-500 cursor-pointer hover:shadow-lg transition-all ${selectedStatus === "Pending" ? "ring-2 ring-yellow-500 bg-yellow-50" : ""}`,
                onClick: () => setSelectedStatus(
                  selectedStatus === "Pending" ? "all" : "Pending"
                ),
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Pending Requests" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1570,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-yellow-600", children: summaryStats.pendingRequests }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1571,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1569,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-yellow-100 rounded-full", children: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { className: "text-yellow-600 text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1576,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1575,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1568,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1560,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `bg-white rounded-lg shadow p-4 border-l-4 border-green-500 cursor-pointer hover:shadow-lg transition-all ${selectedStatus === "Accept" ? "ring-2 ring-green-500 bg-green-50" : ""}`,
                onClick: () => setSelectedStatus(
                  selectedStatus === "Accept" ? "all" : "Accept"
                ),
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Accept Requests" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1590,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-green-600", children: summaryStats.acceptRequests }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1591,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1589,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-green-100 rounded-full", children: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, { className: "text-green-600 text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1596,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1595,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1588,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1580,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `bg-white rounded-lg shadow p-4 border-l-4 border-red-500 cursor-pointer hover:shadow-lg transition-all ${selectedStatus === "Reject" ? "ring-2 ring-red-500 bg-red-50" : ""}`,
                onClick: () => setSelectedStatus(
                  selectedStatus === "Reject" ? "all" : "Reject"
                ),
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Rejected Requests" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1610,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-red-600", children: summaryStats.rejectRequests }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1611,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1609,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-red-100 rounded-full", children: /* @__PURE__ */ jsxDEV(CloseOutlined, { className: "text-red-600 text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1616,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1615,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1608,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1600,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `bg-white rounded-lg shadow p-4 border-l-4 border-orange-500 cursor-pointer hover:shadow-lg transition-all ${selectedStatus === "NextAuction" ? "ring-2 ring-orange-500 bg-orange-50" : ""}`,
                onClick: () => setSelectedStatus(
                  selectedStatus === "NextAuction" ? "all" : "NextAuction"
                ),
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Post To Next Auction" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1630,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-orange-600", children: summaryStats.nextauctionRequests }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1633,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1629,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-orange-100 rounded-full", children: /* @__PURE__ */ jsxDEV(StopOutlined, { className: "text-orange-600 text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1638,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1637,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1628,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1620,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1534,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1530,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700 mb-3", children: [
            "Payment Status Overview",
            " "
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1646,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-5", children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => setSelectedPaymentStatus(
                  selectedPaymentStatus === "pending" ? "all" : "pending"
                ),
                className: `bg-white rounded-lg shadow p-3 border-l-4 border-rose-500 hover:shadow-md transition-all cursor-pointer ${selectedPaymentStatus === "pending" ? "ring-2 ring-rose-500 bg-rose-50" : ""}`,
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Payment Pending" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1660,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-rose-600 mt-0.5", children: summaryStats?.paymentStats?.pending?.count || 0 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1663,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1659,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-rose-100 rounded-full", children: /* @__PURE__ */ jsxDEV(DollarOutlined, { className: "text-rose-600 text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1668,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1667,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1658,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1650,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => setSelectedPaymentStatus(
                  selectedPaymentStatus === "uptodate" ? "all" : "uptodate"
                ),
                className: `bg-white rounded-lg shadow p-3 border-l-4 border-teal-500 hover:shadow-md transition-all cursor-pointer ${selectedPaymentStatus === "uptodate" ? "ring-2 ring-teal-500 bg-teal-50" : ""}`,
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Up To Date & Excess" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1682,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-teal-600 mt-0.5", children: summaryStats?.paymentStats?.upToDate?.count || 0 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1685,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1681,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-teal-100 rounded-full", children: /* @__PURE__ */ jsxDEV(SafetyOutlined, { className: "text-teal-600 text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1690,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1689,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1680,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1672,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1649,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1645,
          columnNumber: 11
        }, this),
        summaryStats?.groupStats && Object.keys(summaryStats.groupStats || {}).length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "flex items-center cursor-pointer",
                onClick: () => setIsGroupStatsOpen(!isGroupStatsOpen),
                children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold mr-2", children: "Group-wise Statistics" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1705,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("button", { className: "p-1 rounded-full hover:bg-gray-100 transition-colors", children: isGroupStatsOpen ? /* @__PURE__ */ jsxDEV(UpOutlined, { className: "text-gray-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1710,
                    columnNumber: 19
                  }, this) : /* @__PURE__ */ jsxDEV(DownOutlined, { className: "text-gray-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1712,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1708,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1701,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 bg-gray-100 p-1 rounded-md", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: `p-2 rounded ${groupViewMode === "grid" ? "bg-white shadow text-blue-600" : "text-gray-500 hover:text-gray-700"}`,
                  onClick: () => setGroupViewMode("grid"),
                  children: /* @__PURE__ */ jsxDEV(AppstoreOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1721,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1717,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: `p-2 rounded ${groupViewMode === "list" ? "bg-white shadow text-blue-600" : "text-gray-500 hover:text-gray-700"}`,
                  onClick: () => setGroupViewMode("list"),
                  children: /* @__PURE__ */ jsxDEV(UnorderedListOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1727,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1723,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1716,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1700,
            columnNumber: 17
          }, this),
          isGroupStatsOpen && groupViewMode === "grid" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4", children: Object.entries(summaryStats.groupStats || {}).map(
            ([groupName, stats]) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `relative bg-gradient-to-br from-white to-gray-50 rounded-xl border-2 transition-all duration-200 cursor-pointer overflow-hidden ${selectedGroupFilter === groupName ? "border-blue-500 shadow-lg shadow-blue-100 bg-blue-50/50" : "border-gray-200 hover:border-blue-300 hover:shadow-md"}`,
                onClick: () => setSelectedGroupFilter(
                  selectedGroupFilter === groupName ? "all" : groupName
                ),
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `h-1.5 w-full ${selectedGroupFilter === groupName ? "bg-blue-500" : "bg-gradient-to-r from-blue-400 to-purple-400"}`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1746,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-3", children: [
                      /* @__PURE__ */ jsxDEV(
                        "p",
                        {
                          className: "text-sm font-semibold text-gray-800 truncate max-w-[140px] pr-2",
                          title: groupName,
                          children: groupName
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1751,
                          columnNumber: 31
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `px-2 py-1 rounded-full text-xs font-bold ${stats.total > 5 ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"}`,
                          children: [
                            "Total: ",
                            stats.total
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1757,
                          columnNumber: 31
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1750,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-5 gap-1 mt-2 text-center", children: [
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `p-1 rounded ${stats.pending > 0 ? "bg-yellow-50" : "bg-gray-50"}`,
                          children: [
                            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-500", children: "Pend" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 1767,
                              columnNumber: 33
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              "div",
                              {
                                className: `text-sm font-bold ${stats.pending > 0 ? "text-yellow-600" : "text-gray-400"}`,
                                children: stats.pending
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                                lineNumber: 1770,
                                columnNumber: 33
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1764,
                          columnNumber: 31
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `p-1 rounded ${stats.accept > 0 ? "bg-green-50" : "bg-gray-50"}`,
                          children: [
                            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-500", children: "Acce" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 1779,
                              columnNumber: 33
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              "div",
                              {
                                className: `text-sm font-bold ${stats.accept > 0 ? "text-green-600" : "text-gray-400"}`,
                                children: stats.accept
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                                lineNumber: 1782,
                                columnNumber: 33
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1776,
                          columnNumber: 31
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `p-1 rounded ${stats.reject > 0 ? "bg-red-50" : "bg-gray-50"}`,
                          children: [
                            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-500", children: "Rejct" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 1791,
                              columnNumber: 33
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              "div",
                              {
                                className: `text-sm font-bold ${stats.reject > 0 ? "text-red-600" : "text-gray-400"}`,
                                children: stats.reject
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                                lineNumber: 1794,
                                columnNumber: 33
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1788,
                          columnNumber: 31
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `p-1 rounded ${stats.prized > 0 ? "bg-purple-50" : "bg-gray-50"}`,
                          children: [
                            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-500", children: "Przd" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 1803,
                              columnNumber: 33
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              "div",
                              {
                                className: `text-sm font-bold ${stats.prized > 0 ? "text-purple-600" : "text-gray-400"}`,
                                children: stats.prized
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                                lineNumber: 1806,
                                columnNumber: 33
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1800,
                          columnNumber: 31
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `p-1 rounded ${stats.nextauction > 0 ? "bg-orange-50" : "bg-gray-50"}`,
                          children: [
                            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-500", children: "Next" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 1815,
                              columnNumber: 33
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              "div",
                              {
                                className: `text-sm font-bold ${stats.nextauction > 0 ? "text-orange-600" : "text-gray-400"}`,
                                children: stats.nextauction
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                                lineNumber: 1818,
                                columnNumber: 33
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1812,
                          columnNumber: 31
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1763,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 pt-3 border-t border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 flex items-center gap-1", children: [
                        /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { className: "text-blue-500" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1828,
                          columnNumber: 35
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Next Auction Date:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1829,
                          columnNumber: 35
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 1827,
                        columnNumber: 33
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "span",
                        {
                          className: `text-xs font-bold px-2 py-1 rounded-full ${stats.next_auction_display !== "N/A" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-500"}`,
                          children: stats.next_auction_display !== "N/A" ? stats.next_auction_display : "Not Scheduled"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 1833,
                          columnNumber: 33
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1826,
                      columnNumber: 31
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1825,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 1749,
                    columnNumber: 27
                  }, this)
                ]
              },
              groupName,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1735,
                columnNumber: 17
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1732,
            columnNumber: 13
          }, this),
          isGroupStatsOpen && groupViewMode === "list" && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-200 overflow-hidden", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
            /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider", children: "Group Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1853,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider", children: "Total" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1856,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider", children: "Pending" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1859,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider", children: "Accept" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1862,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider", children: "Reject" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1865,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider", children: "Prized" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1868,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider", children: "Next Auction Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1871,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1852,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1851,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: Object.entries(summaryStats.groupStats || {}).map(
              ([groupName, stats]) => /* @__PURE__ */ jsxDEV(
                "tr",
                {
                  className: `${selectedGroupFilter === groupName ? "bg-blue-50" : ""} hover:bg-gray-50 cursor-pointer transition-colors`,
                  onClick: () => setSelectedGroupFilter(
                    selectedGroupFilter === groupName ? "all" : groupName
                  ),
                  children: [
                    /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900", children: groupName }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1890,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-center", children: /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 inline-flex text-sm font-bold leading-5 text-blue-700 bg-blue-100 rounded-full", children: stats.total }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1894,
                      columnNumber: 33
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1893,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-center", children: /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `px-3 py-1 inline-flex text-sm font-bold leading-5 rounded-full ${stats.pending > 0 ? "text-yellow-700 bg-yellow-100" : "text-gray-500 bg-gray-100"}`,
                        children: stats.pending
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 1899,
                        columnNumber: 33
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1898,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-center", children: /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `px-3 py-1 inline-flex text-sm font-bold leading-5 rounded-full ${stats.accept > 0 ? "text-green-700 bg-green-100" : "text-gray-500 bg-gray-100"}`,
                        children: stats.accept
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 1906,
                        columnNumber: 33
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1905,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-center", children: /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `px-3 py-1 inline-flex text-sm font-bold leading-5 rounded-full ${stats.reject > 0 ? "text-red-700 bg-red-100" : "text-gray-500 bg-gray-100"}`,
                        children: stats.reject
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 1913,
                        columnNumber: 33
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1912,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-center", children: /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `px-3 py-1 inline-flex text-sm font-bold leading-5 rounded-full ${stats.prized > 0 ? "text-purple-700 bg-purple-100" : "text-gray-500 bg-gray-100"}`,
                        children: stats.prized
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 1920,
                        columnNumber: 33
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1919,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-center", children: stats.next_auction_display !== "N/A" ? /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 inline-flex text-sm font-semibold leading-5 text-blue-700 bg-blue-50 rounded-full border border-blue-200", children: stats.next_auction_display }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1928,
                      columnNumber: 25
                    }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: "No upcoming auction" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1932,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 1926,
                      columnNumber: 31
                    }, this)
                  ]
                },
                groupName,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1879,
                  columnNumber: 21
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1876,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1850,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1849,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1699,
          columnNumber: 11
        }, this),
        selectedCount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg shadow p-4 mb-6 transition-all duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-600 text-white rounded-full h-10 w-10 flex items-center justify-center font-bold text-lg shadow-md", children: selectedCount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1951,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-lg", children: "Items Selected" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 1954,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1950,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-3 justify-center", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(WhatsAppOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1961,
                  columnNumber: 25
                }, this),
                size: "large",
                className: "bg-green-600 hover:bg-green-700 border-green-600",
                onClick: handleOpenVerifyModal,
                children: "Send WhatsApp"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1959,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "large",
                className: "bg-green-100 text-green-700 border-green-200 hover:bg-green-200 font-semibold",
                onClick: () => handleBulkStatusUpdate("Accept"),
                children: "Accept All"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1968,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "large",
                className: "bg-purple-100 text-purple-700 border-purple-200 hover:bg-purple-200 font-semibold",
                icon: /* @__PURE__ */ jsxDEV(TrophyOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 1978,
                  columnNumber: 25
                }, this),
                onClick: () => handleBulkStatusUpdate("Prized"),
                children: "Mark as Prized"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1975,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "large",
                className: "bg-red-100 text-red-700 border-red-200 hover:bg-red-200 font-semibold",
                onClick: () => handleBulkStatusUpdate("Reject"),
                children: "Rejected All"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1983,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "large",
                className: "bg-yellow-100 text-yellow-700 border-yellow-200 hover:bg-yellow-200 font-semibold",
                onClick: () => handleBulkStatusUpdate("Pending"),
                children: "Mark Pending"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1990,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "large",
                className: "bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 font-semibold",
                onClick: () => handleBulkStatusUpdate("NextAuction"),
                children: "Post to Next auction"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 1997,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 1958,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1949,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
          lineNumber: 1948,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "bg-white rounded-lg shadow p-4 min-h-[400px]",
            style: { overflow: "visible" },
            children: loadingTable ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 2014,
              columnNumber: 13
            }, this) : filteredBidRequests.length === 0 ? /* @__PURE__ */ jsxDEV(
              CircularLoader,
              {
                isLoading: false,
                failure: true,
                data: "Bid Requests"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2016,
                columnNumber: 13
              },
              this
            ) : /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: formattedBidData,
                columns,
                exportCols: excelcolumns,
                exportedFileName: "Bid Requests.csv",
                exportedPdfName: "Bid Requests",
                printHeaderKeys: [
                  "Total Requests",
                  "Total Balance",
                  "Pending Requests",
                  "Accept Requests",
                  "Reject Requests"
                ],
                printHeaderValues: [
                  summaryStats.totalRequests.toString(),
                  `₹ ${summaryStats.totalBalance.toLocaleString("en-IN")}`,
                  summaryStats.pendingRequests.toString(),
                  summaryStats.acceptRequests.toString(),
                  summaryStats.rejectRequests.toString()
                ]
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2022,
                columnNumber: 13
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 2009,
            columnNumber: 11
          },
          this
        ),
        dropdownPosition.visible && dropdownPosition.item && /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "dropdown-menu bg-white border rounded-lg shadow-lg w-40",
            style: {
              position: "fixed",
              zIndex: 9999,
              left: `${dropdownPosition.x}px`,
              top: `${dropdownPosition.y}px`
            },
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: (e) => {
                      e.stopPropagation();
                      setOpenStatusId(
                        openStatusId === dropdownPosition.item._id ? null : dropdownPosition.item._id
                      );
                    },
                    className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-purple-600",
                    children: [
                      /* @__PURE__ */ jsxDEV(RiseOutlined, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2069,
                        columnNumber: 19
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Change Status" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2070,
                        columnNumber: 19
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "ml-auto text-xs", children: "▶" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2071,
                        columnNumber: 19
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2058,
                    columnNumber: 17
                  },
                  this
                ),
                openStatusId === dropdownPosition.item._id && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "absolute right-full top-0 mr-2 bg-white border rounded-lg shadow-lg w-40",
                    style: { zIndex: 1e4 },
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: (e) => {
                            e.stopPropagation();
                            handleSingleStatusUpdate(
                              dropdownPosition.item._id,
                              "Pending"
                            );
                            setDropdownPosition({
                              ...dropdownPosition,
                              visible: false
                            });
                          },
                          className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-yellow-50 text-yellow-700 border-b border-gray-100",
                          children: [
                            /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { className: "text-yellow-500" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2092,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { children: "Pending" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2093,
                              columnNumber: 23
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2078,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: (e) => {
                            e.stopPropagation();
                            handleSingleStatusUpdate(
                              dropdownPosition.item._id,
                              "Accept"
                            );
                            setDropdownPosition({
                              ...dropdownPosition,
                              visible: false
                            });
                          },
                          className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-green-50 text-green-700 border-b border-gray-100",
                          children: [
                            /* @__PURE__ */ jsxDEV(CheckCircleOutlined, { className: "text-green-500" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2109,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { children: "Accept" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2110,
                              columnNumber: 23
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2095,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: (e) => {
                            e.stopPropagation();
                            handleSingleStatusUpdate(
                              dropdownPosition.item._id,
                              "Prized"
                            );
                            setDropdownPosition({
                              ...dropdownPosition,
                              visible: false
                            });
                          },
                          className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-purple-50 text-purple-700 border-b border-gray-100",
                          children: [
                            /* @__PURE__ */ jsxDEV(TrophyOutlined, { className: "text-purple-500" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2126,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { children: "Prized" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2127,
                              columnNumber: 23
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2112,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: (e) => {
                            e.stopPropagation();
                            handleSingleStatusUpdate(
                              dropdownPosition.item._id,
                              "Reject"
                            );
                            setDropdownPosition({
                              ...dropdownPosition,
                              visible: false
                            });
                          },
                          className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-red-50 text-red-700 border-b border-gray-100",
                          children: [
                            /* @__PURE__ */ jsxDEV(CloseOutlined, { className: "text-red-500" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2143,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { children: "Reject" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2144,
                              columnNumber: 23
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2129,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: (e) => {
                            e.stopPropagation();
                            handleSingleStatusUpdate(
                              dropdownPosition.item._id,
                              "NextAuction"
                            );
                            setDropdownPosition({
                              ...dropdownPosition,
                              visible: false
                            });
                          },
                          className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-orange-50 text-orange-700",
                          children: [
                            /* @__PURE__ */ jsxDEV(StopOutlined, { className: "text-orange-500" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2160,
                              columnNumber: 23
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { children: "Next Auction" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2161,
                              columnNumber: 23
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2146,
                          columnNumber: 21
                        },
                        this
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2074,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2057,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: (e) => {
                    e.stopPropagation();
                    handleOpenEditModal(dropdownPosition.item);
                    setDropdownPosition({ ...dropdownPosition, visible: false });
                  },
                  className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-blue-600",
                  children: [
                    /* @__PURE__ */ jsxDEV(EditOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2174,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Edit" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2175,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2166,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: (e) => {
                    e.stopPropagation();
                    handleShare(dropdownPosition.item);
                    setDropdownPosition({ ...dropdownPosition, visible: false });
                  },
                  className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-orange-600",
                  children: [
                    /* @__PURE__ */ jsxDEV(ShareAltOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2185,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Share" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2186,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2177,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: (e) => {
                    e.stopPropagation();
                    handlePrint(dropdownPosition.item);
                    setDropdownPosition({ ...dropdownPosition, visible: false });
                  },
                  className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-green-600",
                  children: [
                    /* @__PURE__ */ jsxDEV(PrinterOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2196,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Print" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2197,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2188,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: (e) => {
                    e.stopPropagation();
                    confirmDelete(dropdownPosition.item._id);
                    setDropdownPosition({ ...dropdownPosition, visible: false });
                  },
                  className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-red-600 border-t border-gray-100",
                  children: [
                    /* @__PURE__ */ jsxDEV(DeleteOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2207,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Delete" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2208,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2199,
                  columnNumber: 15
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 2047,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          ModalComponent,
          {
            isVisible: isEditModalOpen,
            onClose: handleCloseEditModal,
            children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-6xl bg-white shadow-inner font-sans text-sm text-gray-800 rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "border-b-2 border-blue-900 p-6 mb-6", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-center text-2xl font-bold text-blue-900 uppercase tracking-wider", children: "Edit Bid Request" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2219,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2218,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Form, { form: editForm, layout: "vertical", className: "px-8", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-3 border-b pb-1", children: "Subscriber Details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2225,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 bg-gray-50 p-4 rounded-lg border border-gray-200 mb-4", children: [
                    /* @__PURE__ */ jsxDEV(Form.Item, { name: "subscriberId", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2230,
                      columnNumber: 23
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2229,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Bid Request Code" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2233,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Form.Item, { name: "bid_request_code", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          readOnly: true,
                          className: "bg-gray-100 border-gray-300 font-semibold"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2237,
                          columnNumber: 25
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2236,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2232,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Created By (Admin)" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2244,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Form.Item, { name: "adminName", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          readOnly: true,
                          className: "bg-gray-100 border-gray-300 font-semibold"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2248,
                          columnNumber: 25
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2247,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2243,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Subscriber Name" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2255,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Form.Item, { name: "subscriberName", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          readOnly: true,
                          className: "bg-gray-100 border-gray-300 font-semibold"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2259,
                          columnNumber: 25
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2258,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2254,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Mobile Number" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2266,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Form.Item, { name: "mobileNumber", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          readOnly: true,
                          className: "bg-gray-100 border-gray-300 font-semibold"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2270,
                          columnNumber: 25
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2269,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2265,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Customer ID" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2277,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Form.Item, { name: "customerId", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          readOnly: true,
                          className: "bg-gray-100 border-gray-300 font-semibold"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2281,
                          columnNumber: 25
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2280,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2276,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2228,
                    columnNumber: 19
                  }, this),
                  editGroups.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700", children: [
                      "Select Group for Bid Request",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2292,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2290,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: /* @__PURE__ */ jsxDEV(
                      Form.Item,
                      {
                        name: "selectedGroupIndex",
                        rules: [{ required: true, message: "Required!" }],
                        className: "mb-3",
                        children: /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            placeholder: "Choose which group...",
                            onChange: handleEditGroupSelect,
                            value: selectedEditGroupIndex,
                            className: "w-full",
                            size: "large",
                            children: editGroups.map(
                              (group, index) => /* @__PURE__ */ jsxDEV(Option, { value: index, children: [
                                group.groupName,
                                " (Ticket: ",
                                group.ticketNumber,
                                ")"
                              ] }, group.id, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                                lineNumber: 2308,
                                columnNumber: 27
                              }, this)
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2300,
                            columnNumber: 27
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2295,
                        columnNumber: 25
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2294,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Group Start Date" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2317,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(Form.Item, { name: "startDate", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            readOnly: true,
                            className: "bg-blue-50 border-blue-200 text-blue-900 font-semibold h-10"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2321,
                            columnNumber: 29
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2320,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2316,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Group End Date" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2328,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(Form.Item, { name: "endDate", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            readOnly: true,
                            className: "bg-blue-50 border-blue-200 text-blue-900 font-semibold h-10"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2332,
                            columnNumber: 29
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2331,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2327,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Auctions Done" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2339,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(Form.Item, { name: "auctionsDone", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            readOnly: true,
                            className: "bg-green-50 border-green-200 text-green-900 font-bold text-center h-10"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2343,
                            columnNumber: 29
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2342,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2338,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Ticket Number" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2350,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(Form.Item, { name: "ticketNumber", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            readOnly: true,
                            className: "bg-gray-100 border-gray-300 font-semibold h-10"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2354,
                            columnNumber: 29
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2353,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2349,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2315,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Group Name" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2362,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV(Form.Item, { name: "groupName", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          readOnly: true,
                          className: "bg-gray-100 border-gray-300 font-semibold h-10"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2366,
                          columnNumber: 27
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2365,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2361,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2289,
                    columnNumber: 19
                  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-4 flex justify-center items-center", children: /* @__PURE__ */ jsxDEV(Spin, { size: "large" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2375,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2374,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2224,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-3 border-b pb-1", children: "Auction Details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2380,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                        "Auction Date ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2386,
                          columnNumber: 38
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2385,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Form.Item,
                        {
                          name: "auctionDate",
                          rules: [{ required: true, message: "Required!" }],
                          className: "mb-0",
                          children: /* @__PURE__ */ jsxDEV(
                            DatePicker,
                            {
                              style: { width: "100%" },
                              className: "border-gray-400 h-10",
                              format: "DD-MM-YYYY"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2393,
                              columnNumber: 25
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2388,
                          columnNumber: 23
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2384,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                        "Request Time ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2402,
                          columnNumber: 38
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2401,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Form.Item,
                        {
                          name: "auctionTime",
                          rules: [{ required: true, message: "Required!" }],
                          className: "mb-0",
                          children: /* @__PURE__ */ jsxDEV(
                            TimePicker,
                            {
                              style: { width: "100%" },
                              className: "border-gray-400 h-10",
                              format: "h:mm A",
                              use12Hours: true
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2409,
                              columnNumber: 25
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2404,
                          columnNumber: 23
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2400,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Request Date" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2418,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Form.Item, { name: "requestDate", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                        DatePicker,
                        {
                          style: { width: "100%" },
                          className: "border-gray-400 h-10",
                          format: "DD-MM-YYYY"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                          lineNumber: 2422,
                          columnNumber: 25
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2421,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2417,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2383,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2379,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 border rounded-lg flex justify-between items-center", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-700 text-lg", children: "Current Due Balance:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2433,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: `font-bold text-2xl ${customerBalance <= 0 ? "text-green-600" : "text-red-600"}`,
                      children: customerBalance !== null ? `₹ ${customerBalance.toLocaleString("en-IN")}` : "Loading..."
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                      lineNumber: 2436,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2432,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2431,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "enrollmentId", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2446,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2445,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "groupId", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2449,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2448,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-3 border-b pb-1", children: "Update Status" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2452,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-6 gap-3", children: [
                    /* @__PURE__ */ jsxDEV(
                      Popconfirm,
                      {
                        title: "Set to Pending?",
                        onConfirm: handleSetPending,
                        okText: "Yes",
                        cancelText: "No",
                        children: /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            type: "default",
                            loading,
                            className: "h-14 font-bold border-yellow-500 text-yellow-600 hover:bg-yellow-50",
                            icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2466,
                              columnNumber: 31
                            }, this),
                            disabled: editGroups.length === 0,
                            block: true,
                            children: "Pending"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2462,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2456,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Popconfirm,
                      {
                        title: "Approve Request?",
                        onConfirm: handleSetAccept,
                        okText: "Yes",
                        cancelText: "No",
                        children: /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            type: "primary",
                            loading,
                            disabled: editGroups.length === 0,
                            className: "h-14 font-bold bg-green-600 hover:bg-green-700 border-green-600",
                            icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2484,
                              columnNumber: 31
                            }, this),
                            block: true,
                            children: "Accept"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2479,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2473,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Popconfirm,
                      {
                        title: "Mark as Prized?",
                        onConfirm: handleSetPrized,
                        okText: "Yes",
                        cancelText: "No",
                        children: /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            type: "primary",
                            loading,
                            disabled: editGroups.length === 0,
                            className: "h-14 font-bold bg-purple-600 hover:bg-purple-700 border-purple-600",
                            icon: /* @__PURE__ */ jsxDEV(TrophyOutlined, {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2501,
                              columnNumber: 31
                            }, this),
                            block: true,
                            children: "Prized"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2496,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2490,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Popconfirm,
                      {
                        title: "Reject Request?",
                        onConfirm: handleSetReject,
                        okText: "Yes",
                        cancelText: "No",
                        children: /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            type: "primary",
                            danger: true,
                            loading,
                            className: "h-14 font-bold",
                            icon: /* @__PURE__ */ jsxDEV(CloseOutlined, {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2518,
                              columnNumber: 31
                            }, this),
                            disabled: editGroups.length === 0,
                            block: true,
                            children: "Reject"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2513,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2507,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Popconfirm,
                      {
                        title: "Post to next auction?",
                        onConfirm: handleSetNextauction,
                        okText: "Yes",
                        cancelText: "No",
                        children: /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            type: "primary",
                            danger: true,
                            loading,
                            className: "h-14 font-bold bg-orange-600 hover:bg-orange-700 border-orange-600",
                            icon: /* @__PURE__ */ jsxDEV(StopOutlined, {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                              lineNumber: 2536,
                              columnNumber: 31
                            }, this),
                            disabled: editGroups.length === 0,
                            block: true,
                            children: [
                              "Next",
                              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                                lineNumber: 2541,
                                columnNumber: 25
                              }, this),
                              "Auction"
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                            lineNumber: 2531,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2525,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        onClick: handleCloseEditModal,
                        className: "h-14 font-semibold border-gray-400",
                        block: true,
                        children: "Cancel"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                        lineNumber: 2545,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2455,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2451,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2223,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 2217,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 2213,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Modal,
          {
            visible: isVerifyModalOpen,
            onCancel: handleCloseVerifyModal,
            footer: null,
            centered: true,
            width: 500,
            children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 text-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 rounded-full p-4", children: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-4xl text-red-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2568,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2567,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2566,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800 mb-2", children: "Are You Sure?" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2571,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mb-6", children: [
                "You are about to send WhatsApp messages to",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-blue-600", children: [
                  selectedCount,
                  " contacts"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2576,
                  columnNumber: 17
                }, this),
                ".",
                /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                  lineNumber: 2580,
                  columnNumber: 17
                }, this),
                "This action cannot be undone once initiated."
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2574,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-4", children: [
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    size: "large",
                    onClick: handleCloseVerifyModal,
                    className: "w-32",
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2584,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "primary",
                    size: "large",
                    loading: isSending,
                    onClick: handleSendWhatsApp,
                    className: "w-32 bg-green-600 hover:bg-green-700",
                    children: "Yes, Send"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                    lineNumber: 2591,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
                lineNumber: 2583,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
              lineNumber: 2565,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
            lineNumber: 2558,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
        lineNumber: 1271,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
      lineNumber: 1269,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx",
    lineNumber: 1266,
    columnNumber: 5
  }, this);
}
_s(BidRequest, "NECh04Z/sMzwhhqmK0j44uO5dEg=", false, function() {
  return [notification.useNotification, Form.useForm];
});
_c = BidRequest;
export default BidRequest;
var _c;
$RefreshReg$(_c, "BidRequest");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequest.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK2ZZLFNBa3ZCUixVQWx2QlE7MkJBL2ZaO0FBQW1CQSxvQkFBa0IsT0FBUSxzQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNwRDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxXQUFXO0FBRWxCLE1BQU0sRUFBRUMsT0FBTyxJQUFJcEM7QUFDbkIsTUFBTXFDLE9BQU9DLEtBQUtDLE1BQU1DLGFBQWFDLFFBQVEsTUFBTSxLQUFLLElBQUk7QUFDNUQsTUFBTUMsV0FBV0wsTUFBTU0sdUJBQXVCQztBQUM5QyxNQUFNQyxzQkFBc0JILGFBQWEseUJBQXlCQSxhQUFhO0FBRS9FLFNBQVNJLGFBQWE7QUFBQUMsS0FBQTtBQUVwQixRQUFNQyxlQUFlWCxNQUFNWSxTQUFTO0FBQ3BDLFFBQU0sQ0FBQ0MsS0FBS0MsYUFBYSxJQUFJbEQsYUFBYW1ELGdCQUFnQjtBQUMxRCxRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUlDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNDLFFBQVEsSUFBSTdELEtBQUs4RCxRQUFRO0FBQ2hDLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJSixTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDSyxPQUFPQyxRQUFRLElBQUlOLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNPLGNBQWNDLGVBQWUsSUFBSVIsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ1MsU0FBU0MsVUFBVSxJQUFJVixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDVyxZQUFZQyxhQUFhLElBQUlaLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNhLHdCQUF3QkMseUJBQXlCLElBQUlkLFNBQVMsQ0FBQztBQUN0RSxRQUFNLENBQUNlLGtCQUFrQkMsbUJBQW1CLElBQUloQixTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDaUIsZUFBZUMsZ0JBQWdCLElBQUlsQixTQUFTLE1BQU07QUFDekQsUUFBTSxDQUFDbUIsVUFBVUMsV0FBVyxJQUFJcEIsU0FBUyxVQUFVO0FBQ25ELFFBQU0sQ0FBQ3FCLGdCQUFnQkMsaUJBQWlCLElBQUl0QixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDdUIsY0FBY0MsZUFBZSxJQUFJeEIsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ3lCLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUMyQixpQkFBaUJDLGtCQUFrQixJQUFJNUIsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQzZCLGdCQUFnQkMsaUJBQWlCLElBQUk5QixTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDK0IsYUFBYUMsY0FBYyxJQUFJaEMsU0FBUyxLQUFLO0FBR3BELFFBQU0sQ0FBQ2lDLGFBQWFDLGNBQWMsSUFBSWxDLFNBQVMsQ0FBQyxDQUFDO0FBRWpELFFBQU0sQ0FBQ21DLGtCQUFrQkMsbUJBQW1CLElBQUlwQyxTQUFTO0FBQUEsSUFDdkRxQyxTQUFTO0FBQUEsSUFDVEMsR0FBRztBQUFBLElBQ0hDLEdBQUc7QUFBQSxJQUNIQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJMUMsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQzJDLHFCQUFxQkMsc0JBQXNCLElBQUk1QyxTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDNkMsdUJBQXVCQyx3QkFBd0IsSUFBSTlDLFNBQVMsS0FBSztBQUN4RSxRQUFNLENBQUMrQyxlQUFlQyxnQkFBZ0IsSUFBSWhELFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUNpRCxhQUFhQyxjQUFjLElBQUlsRCxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDbUQsZ0JBQWdCQyxpQkFBaUIsSUFBSXBELFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUNxRCxjQUFjQyxlQUFlLElBQUl0RCxTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDdUQsZ0JBQWdCQyxpQkFBaUIsSUFBSXhELFNBQVMsQ0FBQyxDQUFDO0FBQ3ZELFFBQU0sQ0FBQ3lELFdBQVdDLFlBQVksSUFBSTFELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyRCxtQkFBbUJDLG9CQUFvQixJQUFJNUQsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzZELFdBQVdDLFlBQVksSUFBSTlELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMrRCxjQUFjQyxlQUFlLElBQUloRSxTQUFTLElBQUk7QUFFckQ3RCxZQUFVLE1BQU07QUFDZCxVQUFNOEgsbUJBQW1CLFlBQVk7QUFDbkMsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTXZGLElBQUl3RixJQUFJLHVCQUF1QjtBQUN0RGpDLHVCQUFlZ0MsU0FBU0UsS0FBS0Msc0JBQXNCLENBQUMsQ0FBQztBQUFBLE1BQ3ZELFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25EcEMsdUJBQWUsQ0FBQyxDQUFDO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBRUEsUUFBSXpDLGNBQWM7QUFDaEJ3RSx1QkFBaUI7QUFBQSxJQUNuQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTU8sdUJBQXVCQSxNQUFNO0FBQ2pDQyxXQUFPQyxLQUFLLHVCQUF1QixVQUFVLHFCQUFxQjtBQUFBLEVBQ3BFO0FBRUF2SSxZQUFVLE1BQU07QUFDZCxVQUFNd0ksY0FBY0EsTUFBTTtBQUN4QkMsdUJBQWlCO0FBQUEsSUFDbkI7QUFDQUgsV0FBT0ksaUJBQWlCLFNBQVNGLFdBQVc7QUFDNUMsV0FBTyxNQUFNO0FBQ1hGLGFBQU9LLG9CQUFvQixTQUFTSCxXQUFXO0FBQUEsSUFDakQ7QUFBQSxFQUNGLEdBQUcsQ0FBQ3hELFFBQVEsQ0FBQztBQUViLFFBQU00RCx1QkFBdUIsT0FBT0MsaUJBQWlCO0FBQ25ELFFBQUksQ0FBQ0EsYUFBYztBQUNuQmxELHNCQUFrQixJQUFJO0FBQ3RCLFFBQUk7QUFDRixZQUFNb0MsV0FBVyxNQUFNdkYsSUFBSXdGO0FBQUFBLFFBQ3pCLDRCQUE0QmEsWUFBWTtBQUFBLE1BQzFDO0FBQ0EsVUFBSWQsU0FBU0UsTUFBTUEsTUFBTWEsU0FBUyxHQUFHO0FBQ25DckQsMkJBQW1Cc0MsU0FBU0UsS0FBS0EsS0FBSyxDQUFDLEVBQUVjLE9BQU87QUFBQSxNQUNsRCxPQUFPO0FBQ0x0RCwyQkFBbUIsQ0FBQztBQUFBLE1BQ3RCO0FBQUEsSUFDRixTQUFTMEMsT0FBTztBQUNkMUMseUJBQW1CLENBQUM7QUFBQSxJQUN0QixVQUFDO0FBQ0NFLHdCQUFrQixLQUFLO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBRUEsUUFBTXFELGFBQWEsWUFBWTtBQUM3QixRQUFJO0FBQ0YzRSxzQkFBZ0IsSUFBSTtBQUNwQixZQUFNMEQsV0FBVyxNQUFNdkYsSUFBSXdGLElBQUksZ0JBQWdCO0FBQy9DN0QsZUFBUzRELFNBQVNFLFFBQVEsRUFBRTtBQUM1QjVELHNCQUFnQixLQUFLO0FBQUEsSUFDdkIsU0FBUzhELE9BQU87QUFDZDlELHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTTRFLG9CQUFvQixPQUFPQyxZQUFZO0FBQzNDLFFBQUksQ0FBQ0EsUUFBUyxRQUFPO0FBQ3JCLFFBQUk7QUFDRixZQUFNbkIsV0FBVyxNQUFNdkYsSUFBSXdGLElBQUksOEJBQThCa0IsT0FBTyxFQUFFO0FBQ3RFLGFBQU9uQixTQUFTRSxLQUFLYTtBQUFBQSxJQUN2QixTQUFTWCxPQUFPO0FBQ2QsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTWdCLDJCQUEyQixPQUFPQyxJQUFJQyxjQUFjO0FBQ3hEeEIsb0JBQWdCLElBQUk7QUFDcEI1RCxvQkFBZ0IsSUFBSTtBQUNwQixRQUFJO0FBQ0ZNLGlCQUFXLElBQUk7QUFDZixZQUFNOEIsT0FBT25CLGVBQWVvRSxLQUFLLENBQUNDLE1BQU1BLEVBQUVDLFFBQVFKLEVBQUU7QUFDcEQsVUFBSSxDQUFDL0MsS0FBTTtBQUVYLFlBQU1vRCxVQUFVO0FBQUEsUUFDZEMsUUFBUUw7QUFBQUEsUUFDUlIsY0FBY3hDLEtBQUt3QyxjQUFjVyxPQUFPbkQsS0FBS3dDO0FBQUFBLFFBQzdDSyxTQUFTN0MsS0FBSzZDLFNBQVNNLE9BQU9uRCxLQUFLNkM7QUFBQUEsTUFDckM7QUFFQSxZQUFNMUcsSUFBSW1ILElBQUksdUJBQXVCUCxFQUFFLElBQUlLLE9BQU87QUFFbEQsWUFBTUcsaUJBQWlCO0FBQUEsUUFDckJDLFNBQVM7QUFBQSxRQUNUQyxRQUFRO0FBQUEsUUFDUkMsUUFBUTtBQUFBLFFBQ1JDLGFBQWE7QUFBQSxRQUNiQyxRQUFRO0FBQUEsTUFDVjtBQUVBekcsVUFBSTBHLFFBQVE7QUFBQSxRQUNWdEosU0FBUztBQUFBLFFBQ1R1SixhQUNFUCxlQUFlUCxTQUFTLEtBQUsscUJBQXFCQSxTQUFTO0FBQUEsTUFDL0QsQ0FBQztBQUVEWix1QkFBaUI7QUFBQSxJQUNuQixTQUFTTixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQzNDM0UsVUFBSTJFLE1BQU07QUFBQSxRQUNSdkgsU0FBUztBQUFBLFFBQ1R1SixhQUFhaEMsTUFBTUosVUFBVUUsTUFBTXJILFdBQVc7QUFBQSxNQUNoRCxDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0MyRCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTTZGLDJCQUEyQixPQUMvQkMsUUFDQUMsdUJBQXVCLFNBQ3BCO0FBQ0gsUUFBSTtBQUNGLFlBQU12QyxXQUFXLE1BQU12RixJQUFJK0g7QUFBQUEsUUFDekIsbUNBQW1DRixNQUFNO0FBQUEsTUFDM0M7QUFDQSxVQUFJdEMsU0FBU0UsUUFBUUYsU0FBU0UsS0FBS2EsU0FBUyxHQUFHO0FBQzdDLGNBQU0wQixvQkFBb0J6QyxTQUFTRSxLQUFLd0MsSUFBSSxPQUFPcEUsU0FBUztBQUMxRCxnQkFBTXFFLGFBQWFyRSxNQUFNcUU7QUFDekIsZ0JBQU1DLFlBQVlELFlBQVlFO0FBQzlCLGdCQUFNMUIsVUFBVXlCLFdBQVduQjtBQUMzQixnQkFBTXFCLGVBQWUsTUFBTTVCLGtCQUFrQkMsT0FBTztBQUNwRCxnQkFBTTRCLGFBQ0pILFdBQVdJLE9BQU9DLFFBQVFMLFdBQVdJLE9BQU9FLGVBQ3hDLEdBQUdOLFVBQVVJLE1BQU1DLElBQUksTUFBTUwsVUFBVUksTUFBTUUsWUFBWSxLQUN6RE4sV0FBV08sbUJBQW1CQyxhQUM1QlIsV0FBV08sbUJBQW1CRCxlQUM5QixHQUFHTixVQUFVTyxrQkFBa0JDLFNBQVMsTUFBTVIsVUFBVU8sa0JBQWtCRCxZQUFZLEtBQ3RGTixXQUFXUyxlQUFlQyxhQUN4QlYsV0FBV1MsZUFBZUUsZUFDMUIsR0FBR1gsVUFBVVMsY0FBY0MsU0FBUyxNQUFNVixVQUFVUyxjQUFjRSxZQUFZLEtBQzlFO0FBRVYsaUJBQU87QUFBQSxZQUNMbEMsSUFBSUY7QUFBQUEsWUFDSnFDLGtCQUFrQlosV0FBV1k7QUFBQUEsWUFDN0JDLFdBQVdiLFdBQVdjLGNBQWM7QUFBQSxZQUNwQ0MsY0FDRWhCLFlBQVlpQixXQUFXakIsWUFBWWtCLGlCQUFpQjtBQUFBLFlBQ3REQyxXQUFXbEIsV0FBV21CLGFBQ2xCbkIsVUFBVW1CLFdBQVdDLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDakM7QUFBQSxZQUNKQyxTQUFTckIsV0FBV3NCLFdBQ2hCdEIsVUFBVXNCLFNBQVNGLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDL0I7QUFBQSxZQUNKbEI7QUFBQUEsWUFDQXFCLGdCQUFnQnhCO0FBQUFBLFlBQ2hCN0IsY0FBYzZCLFlBQVlsQjtBQUFBQSxZQUMxQnNCO0FBQUFBLFVBQ0Y7QUFBQSxRQUNGLENBQUM7QUFFRCxjQUFNcUIsYUFBYSxNQUFNQyxRQUFRQyxJQUFJN0IsaUJBQWlCO0FBQ3REL0Ysc0JBQWMwSCxVQUFVO0FBRXhCLFlBQUlBLFdBQVdyRCxTQUFTLEdBQUc7QUFDekIsY0FBSXdELGVBQWU7QUFDbkIsY0FBSWhDLHNCQUFzQjtBQUN4QixrQkFBTWlDLGFBQWFKLFdBQVdLO0FBQUFBLGNBQzVCLENBQUNDLE1BQU1BLEVBQUU1RCxpQkFBaUJ5QjtBQUFBQSxZQUM1QjtBQUNBLGdCQUFJaUMsZUFBZSxJQUFJO0FBQ3JCRCw2QkFBZUM7QUFBQUEsWUFDakI7QUFBQSxVQUNGO0FBQ0E1SCxvQ0FBMEIySCxZQUFZO0FBQ3RDLGdCQUFNSSxnQkFBZ0JQLFdBQVdHLFlBQVk7QUFDN0N4SSxtQkFBUzZJLGVBQWU7QUFBQSxZQUN0Qm5CLFdBQVdrQixjQUFjbEI7QUFBQUEsWUFDekJFLGNBQWNnQixjQUFjaEI7QUFBQUEsWUFDNUJrQixvQkFBb0JOO0FBQUFBLFlBQ3BCVCxXQUFXYSxjQUFjYjtBQUFBQSxZQUN6QkcsU0FBU1UsY0FBY1Y7QUFBQUEsWUFDdkJuQixjQUFjNkIsY0FBYzdCO0FBQUFBLFlBQzVCQyxZQUFZNEIsY0FBYzVCO0FBQUFBLFVBQzVCLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRixPQUFPO0FBQ0xyRyxzQkFBYyxFQUFFO0FBQ2hCWCxpQkFBUzZJLGVBQWU7QUFBQSxVQUN0Qm5CLFdBQVc7QUFBQSxVQUNYRSxjQUFjO0FBQUEsVUFDZGtCLG9CQUFvQkM7QUFBQUEsVUFDcEIvQixZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBUzNDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxvQ0FBb0NBLEtBQUs7QUFDdkQzRSxVQUFJMkUsTUFBTTtBQUFBLFFBQ1J2SCxTQUFTO0FBQUEsUUFDVHVKLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU0yQyx3QkFBd0IsT0FBT0MsVUFBVTtBQUM3Q3BJLDhCQUEwQm9JLEtBQUs7QUFDL0IsVUFBTUwsZ0JBQWdCbEksV0FBV3VJLEtBQUs7QUFDdEMsUUFBSUwsZUFBZTtBQUNqQjVJLGVBQVM2SSxlQUFlO0FBQUEsUUFDdEJuQixXQUFXa0IsY0FBY2xCO0FBQUFBLFFBQ3pCRSxjQUFjZ0IsY0FBY2hCO0FBQUFBLFFBQzVCa0Isb0JBQW9CRztBQUFBQSxRQUNwQmxCLFdBQVdhLGNBQWNiO0FBQUFBLFFBQ3pCRyxTQUFTVSxjQUFjVjtBQUFBQSxRQUN2Qm5CLGNBQWM2QixjQUFjN0I7QUFBQUEsUUFDNUJDLFlBQVk0QixjQUFjNUI7QUFBQUEsTUFDNUIsQ0FBQztBQUNELFlBQU1sQyxxQkFBcUI4RCxjQUFjN0QsWUFBWTtBQUFBLElBQ3ZEO0FBQUEsRUFDRjtBQUVBLFFBQU1tRSxzQkFBc0IsT0FBTzNHLFNBQVM7QUFDMUNwQyxvQkFBZ0IsSUFBSTtBQUNwQmdDLHdCQUFvQixFQUFFLEdBQUdELGtCQUFrQkUsU0FBUyxNQUFNLENBQUM7QUFDM0RYLGlCQUFhYyxLQUFLbUQsR0FBRztBQUNyQjNELG1CQUFlLElBQUk7QUFDbkJqQyx1QkFBbUIsSUFBSTtBQUV2QixVQUFNcUosVUFDSixPQUFPNUcsS0FBSzZHLGlCQUFpQixXQUFXN0csS0FBSzZHLGVBQWUsQ0FBQztBQUMvRCxVQUFNN0MsU0FBUzRDLFFBQVF6RCxPQUFPbkQsS0FBSzZHO0FBQ25DLFVBQU1DLGdCQUNKRixRQUFROUIsYUFDUjhCLFFBQVFqQyxRQUNSM0UsS0FBSytHLGtCQUNML0csS0FBS2dILFlBQ0w7QUFDRixVQUFNQyxpQkFDSkwsUUFBUWhDLGdCQUNSZ0MsUUFBUU0sVUFDUmxILEtBQUttSCxnQkFDTG5ILEtBQUtvSCxtQkFDTDtBQUNGLFVBQU1DLHNCQUNKLE9BQU9ULFlBQVksV0FBV0EsUUFBUVUsZUFBZSxRQUFRO0FBRS9ELFVBQU1DLGNBQWN2SCxLQUFLd0gsb0JBQW9CLENBQUM7QUFDOUMsVUFBTUMsWUFDSkYsWUFBWTVDLFFBQVE0QyxZQUFZekMsYUFBYTlFLEtBQUt5SCxhQUFhO0FBQ2pFLFVBQU1DLGFBQWExSCxLQUFLMEgsY0FBYztBQUN0QyxVQUFNQyxlQUNKRixjQUFjLFFBQ1ZBLFlBQ0FDLGVBQWUsUUFDYixXQUFXQSxVQUFVLEtBQ3JCO0FBRVIsVUFBTUUsc0JBQ0o1SCxNQUFNMEUsT0FBT0MsUUFBUTNFLE1BQU0wRSxPQUFPRSxlQUM5QixHQUFHNUUsS0FBSzBFLE1BQU1DLElBQUksTUFBTTNFLEtBQUswRSxNQUFNRSxZQUFZLEtBQy9DNUUsTUFBTTZFLG1CQUFtQkMsYUFDdkI5RSxNQUFNNkUsbUJBQW1CRCxlQUN6QixHQUFHNUUsS0FBSzZFLGtCQUFrQkMsU0FBUyxNQUFNOUUsS0FBSzZFLGtCQUFrQkQsWUFBWSxLQUM1RTVFLE1BQU0rRSxlQUFlQyxhQUFhaEYsTUFBTStFLGVBQWVFLGVBQ3JELEdBQUdqRixLQUFLK0UsY0FBY0MsU0FBUyxNQUFNaEYsS0FBSytFLGNBQWNFLFlBQVksS0FDcEVqRixLQUFLeUUsY0FBYztBQUU3QmhILGFBQVM2SSxlQUFlO0FBQUEsTUFDdEJPLGNBQWM3QztBQUFBQSxNQUNkK0MsZ0JBQWdCRDtBQUFBQSxNQUNoQkssY0FBY0Y7QUFBQUEsTUFDZFksWUFBWVI7QUFBQUEsTUFDWm5DLGtCQUFrQmxGLEtBQUtrRixvQkFBb0I7QUFBQSxNQUMzQ3VDLFdBQVdFO0FBQUFBLE1BQ1hHLGFBQWE5SCxLQUFLOEgsY0FBYzVMLE1BQU04RCxLQUFLOEgsV0FBVyxJQUFJO0FBQUEsTUFDMURDLGFBQWEvSCxLQUFLZ0ksZUFBZTlMLE1BQU04RCxLQUFLZ0ksY0FBYyxPQUFPLElBQUk7QUFBQSxNQUNyRXZELFlBQVltRDtBQUFBQSxNQUNaSyxhQUFhakksS0FBS2tJLFlBQVloTSxNQUFNOEQsS0FBS2tJLFNBQVMsSUFBSWhNLE1BQU07QUFBQSxNQUM1RGlKLFdBQVduRixLQUFLbUY7QUFBQUEsTUFDaEJFLGNBQWNyRixLQUFLcUY7QUFBQUEsTUFDbkI3QyxjQUFjeEMsS0FBS3dDO0FBQUFBLE1BQ25CSyxTQUFTN0MsS0FBSzZDLFNBQVNNLE9BQU9uRCxLQUFLNkMsV0FBVzdDLEtBQUs2QyxTQUFTRTtBQUFBQSxJQUM5RCxDQUFDO0FBRUQzRCx1QkFBbUJZLEtBQUttSSxVQUFVekYsV0FBVyxDQUFDO0FBRTlDLFFBQUk3RSxNQUFNNEUsV0FBVyxFQUFHLE9BQU1FLFdBQVc7QUFDekMsVUFBTW9CLHlCQUF5QkMsUUFBUWhFLEtBQUt3QyxZQUFZO0FBRXhELFFBQUl4QyxLQUFLd0MsY0FBYztBQUNyQixZQUFNRCxxQkFBcUJ2QyxLQUFLd0MsWUFBWTtBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLFFBQU00RixjQUFjLE9BQU9wSSxTQUFTO0FBQ2xDcEMsb0JBQWdCLElBQUk7QUFDcEJnQyx3QkFBb0IsRUFBRSxHQUFHRCxrQkFBa0JFLFNBQVMsTUFBTSxDQUFDO0FBQzNELFVBQU13SSxlQUFlckksS0FBS21EO0FBQzFCLFFBQUksQ0FBQ2tGLGNBQWM7QUFDakJ0RyxjQUFRRCxNQUFNLHlCQUF5QjtBQUN2Q3ZILGNBQVF1SCxNQUFNLGdEQUFnRDtBQUM5RDtBQUFBLElBQ0Y7QUFDQSxVQUFNd0csY0FBY3JHLE9BQU9zRyxTQUFTQztBQUNwQyxVQUFNQyxVQUFVLEdBQUdILFdBQVcsc0JBQXNCRCxZQUFZO0FBQ2hFcEcsV0FBT0MsS0FBS3VHLFNBQVMsUUFBUTtBQUFBLEVBQy9CO0FBRUEsUUFBTUMsdUJBQXVCQSxNQUFNO0FBQ2pDbkwsdUJBQW1CLEtBQUs7QUFDeEJFLGFBQVNrTCxZQUFZO0FBQ3JCdkssa0JBQWMsRUFBRTtBQUNoQmdCLHVCQUFtQixJQUFJO0FBQ3ZCSSxtQkFBZSxLQUFLO0FBQ3BCTixpQkFBYSxJQUFJO0FBQUEsRUFDbkI7QUFFQSxRQUFNMEosZUFBZSxPQUFPNUYsY0FBYztBQUN4QyxRQUFJO0FBQ0Y5RSxpQkFBVyxJQUFJO0FBQ2YsWUFBTTJLLFNBQVMsTUFBTXBMLFNBQVNxTCxlQUFlO0FBQzdDLFlBQU1DLGFBQWFGLE9BQU90QyxzQkFBc0JsSTtBQUNoRCxZQUFNZ0ksZ0JBQWdCbEksV0FBVzRLLFVBQVU7QUFFM0MsVUFBSSxDQUFDMUMsZUFBZTtBQUNsQmxKLFlBQUkyRSxNQUFNO0FBQUEsVUFDUnZILFNBQVM7QUFBQSxVQUNUdUosYUFBYTtBQUFBLFFBQ2YsQ0FBQztBQUNENUYsbUJBQVcsS0FBSztBQUNoQjtBQUFBLE1BQ0Y7QUFFQSxZQUFNNEosY0FBY2UsT0FBT2YsYUFBYWtCLE9BQU8sWUFBWTtBQUMzRCxZQUFNakIsY0FBY2MsT0FBT2QsYUFBYWlCLE9BQU8sT0FBTztBQUN0RCxZQUFNZixjQUFjWSxPQUFPWixhQUFhZSxPQUFPLFlBQVk7QUFFM0QsWUFBTTVGLFVBQVU7QUFBQSxRQUNkeUQsY0FBY2dDLE9BQU9oQztBQUFBQSxRQUNyQkUsZ0JBQWdCOEIsT0FBTzlCO0FBQUFBLFFBQ3ZCSSxjQUFjMEIsT0FBTzFCO0FBQUFBLFFBQ3JCVSxZQUFZZ0IsT0FBT2hCO0FBQUFBLFFBQ25CMUMsV0FBV2tCLGNBQWNsQjtBQUFBQSxRQUN6QkUsY0FBY2dCLGNBQWNoQjtBQUFBQSxRQUM1QnlDO0FBQUFBLFFBQ0FFLGNBQWNEO0FBQUFBLFFBQ2RBO0FBQUFBLFFBQ0F0RCxZQUFZb0UsT0FBT3BFO0FBQUFBLFFBQ25Cd0UsYUFBYUosT0FBT3BFO0FBQUFBLFFBQ3BCNUIsU0FBU3dELGNBQWN0RDtBQUFBQSxRQUN2QlAsY0FBYzZELGNBQWM3RDtBQUFBQSxRQUM1QmEsUUFBUUw7QUFBQUEsUUFDUmlGO0FBQUFBLFFBQ0FpQixXQUFXckwsTUFBTW9GLEtBQUssQ0FBQ2tHLE1BQU1BLEVBQUVoRyxRQUFRMEYsT0FBT2hDLFlBQVksR0FBRzFEO0FBQUFBLE1BQy9EO0FBRUEsWUFBTWhILElBQUltSCxJQUFJLHVCQUF1QnJFLFNBQVMsSUFBSW1FLE9BQU87QUFFekQsWUFBTUcsaUJBQWlCO0FBQUEsUUFDckJDLFNBQVM7QUFBQSxRQUNUQyxRQUFRO0FBQUEsUUFDUkMsUUFBUTtBQUFBLFFBQ1JDLGFBQWE7QUFBQSxRQUNiQyxRQUFRO0FBQUEsTUFDVjtBQUVBekcsVUFBSTBHLFFBQVE7QUFBQSxRQUNWdEosU0FBUztBQUFBLFFBQ1R1SixhQUNFUCxlQUFlUCxTQUFTLEtBQUsscUJBQXFCQSxTQUFTO0FBQUEsTUFDL0QsQ0FBQztBQUVEMEYsMkJBQXFCO0FBQ3JCdEcsdUJBQWlCO0FBQUEsSUFDbkIsU0FBU04sT0FBTztBQUNkQyxjQUFRRCxNQUFNLG1CQUFtQkEsS0FBSztBQUN0QyxVQUFJc0gsZUFBZTtBQUNuQixVQUFJdEgsTUFBTUosVUFBVUUsTUFBTXJILFNBQVM7QUFDakM2Tyx1QkFBZXRILE1BQU1KLFNBQVNFLEtBQUtySDtBQUFBQSxNQUNyQyxXQUFXdUgsTUFBTUosVUFBVUUsTUFBTXlILFFBQVE7QUFDdkNELHVCQUFlRSxPQUFPVCxPQUFPL0csTUFBTUosU0FBU0UsS0FBS3lILE1BQU0sRUFDcERFLEtBQUssRUFDTEMsS0FBSyxJQUFJO0FBQUEsTUFDZCxXQUFXMUgsTUFBTTJILGFBQWE7QUFDNUJMLHVCQUFldEgsTUFBTTJILFlBQ2xCckYsSUFBSSxDQUFDc0YsTUFBTSxHQUFHQSxFQUFFL0UsS0FBSzZFLEtBQUssR0FBRyxDQUFDLEtBQUtFLEVBQUVMLE9BQU9HLEtBQUssSUFBSSxDQUFDLEVBQUUsRUFDeERBLEtBQUssSUFBSTtBQUFBLE1BQ2Q7QUFDQXJNLFVBQUkyRSxNQUFNLEVBQUV2SCxTQUFTLGlCQUFpQnVKLGFBQWFzRixhQUFhLENBQUM7QUFBQSxJQUNuRSxVQUFDO0FBQ0NsTCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTXlMLG1CQUFtQixZQUFZO0FBQ25DLFVBQU1mLGFBQWEsU0FBUztBQUFBLEVBQzlCO0FBQ0EsUUFBTWdCLGtCQUFrQixZQUFZO0FBQ2xDLFVBQU1oQixhQUFhLFFBQVE7QUFBQSxFQUM3QjtBQUNBLFFBQU1pQixrQkFBa0IsWUFBWTtBQUNsQyxVQUFNakIsYUFBYSxRQUFRO0FBQUEsRUFDN0I7QUFDQSxRQUFNa0IsdUJBQXVCLFlBQVk7QUFDdkMsVUFBTWxCLGFBQWEsYUFBYTtBQUFBLEVBQ2xDO0FBQ0EsUUFBTW1CLGtCQUFrQixZQUFZO0FBQ2xDLFVBQU1uQixhQUFhLFFBQVE7QUFBQSxFQUM3QjtBQUdBLFFBQU1vQix5QkFBeUJBLENBQUNoSCxjQUFjO0FBQzVDLFVBQU1pSCxnQkFBZ0JDLG9CQUFvQkM7QUFBQUEsTUFDeEMsQ0FBQ25LLFNBQVNlLGVBQWVmLEtBQUttRCxHQUFHLEdBQUdpSCxNQUFNL0c7QUFBQUEsSUFDNUM7QUFDQSxRQUFJNEcsY0FBY3hILFdBQVcsRUFBRztBQUVoQ3BJLFVBQU1nUSxRQUFRO0FBQUEsTUFDWnhOLE9BQU87QUFBQSxNQUNQeU4sTUFBTSx1QkFBQywrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCO0FBQUEsTUFDaENDLFNBQVMsc0NBQXNDdkgsU0FBUyxTQUFTaUgsY0FBY3hILE1BQU07QUFBQSxNQUNyRitILFFBQVE7QUFBQSxNQUNSQyxZQUFZO0FBQUEsTUFDWkMsTUFBTSxZQUFZO0FBQ2hCeE0sbUJBQVcsSUFBSTtBQUNmLFlBQUk7QUFDRixnQkFBTXlNLFdBQVdWLGNBQWM3RixJQUFJLENBQUNwRSxTQUFTO0FBQzNDLGtCQUFNb0QsVUFBVTtBQUFBLGNBQ2RDLFFBQVFMO0FBQUFBLGNBQ1JSLGNBQWN4QyxLQUFLd0MsY0FBY1csT0FBT25ELEtBQUt3QztBQUFBQSxjQUM3Q0ssU0FBUzdDLEtBQUs2QyxTQUFTTSxPQUFPbkQsS0FBSzZDO0FBQUFBLFlBQ3JDO0FBQ0EsbUJBQU8xRyxJQUFJbUgsSUFBSSx1QkFBdUJ0RCxLQUFLbUQsR0FBRyxJQUFJQyxPQUFPO0FBQUEsVUFDM0QsQ0FBQztBQUNELGdCQUFNMkMsUUFBUUMsSUFBSTJFLFFBQVE7QUFDMUJ4TixjQUFJMEcsUUFBUTtBQUFBLFlBQ1Z0SixTQUFTO0FBQUEsWUFDVHVKLGFBQWEsR0FBR21HLGNBQWN4SCxNQUFNLHdCQUF3Qk8sU0FBUztBQUFBLFVBQ3ZFLENBQUM7QUFDRGhDLDRCQUFrQixDQUFDLENBQUM7QUFDcEJFLHVCQUFhLEtBQUs7QUFDbEJrQiwyQkFBaUI7QUFBQSxRQUNuQixTQUFTd0ksS0FBSztBQUNaek4sY0FBSTJFLE1BQU07QUFBQSxZQUNSdkgsU0FBUztBQUFBLFlBQ1R1SixhQUFhO0FBQUEsVUFDZixDQUFDO0FBQUEsUUFDSCxVQUFDO0FBQ0M1RixxQkFBVyxLQUFLO0FBQUEsUUFDbEI7QUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU0yTSxtQkFBbUJBLE1BQU07QUFDN0JqSyxzQkFBa0JMLGFBQWE7QUFDL0JPLG9CQUFnQkwsV0FBVztBQUFBLEVBQzdCO0FBRUEsUUFBTXFLLHFCQUFxQkEsTUFBTTtBQUMvQjVLLHNCQUFrQixLQUFLO0FBQ3ZCRSwyQkFBdUIsS0FBSztBQUM1QkUsNkJBQXlCLEtBQUs7QUFDOUJFLHFCQUFpQixJQUFJO0FBQ3JCRSxtQkFBZSxJQUFJO0FBQ25CRSxzQkFBa0IsSUFBSTtBQUN0QkUsb0JBQWdCLElBQUk7QUFBQSxFQUN0QjtBQUVBLFFBQU1pSyx3QkFBd0JBLE1BQU0zSixxQkFBcUIsSUFBSTtBQUM3RCxRQUFNNEoseUJBQXlCQSxNQUFNNUoscUJBQXFCLEtBQUs7QUFFL0QsUUFBTTZKLHFCQUFxQixZQUFZO0FBQ3JDM0osaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTTJJLGdCQUFnQkMsb0JBQW9CQztBQUFBQSxRQUN4QyxDQUFDbkssU0FBU2UsZUFBZWYsS0FBS21ELEdBQUcsR0FBR2lILE1BQU0vRztBQUFBQSxNQUM1QztBQUNBLFlBQU02SCxZQUFZLENBQUM7QUFFbkJqQixvQkFBY2tCLFFBQVEsQ0FBQ25MLFNBQVM7QUFDOUIsY0FBTTRHLFVBQ0osT0FBTzVHLEtBQUs2RyxpQkFBaUIsV0FBVzdHLEtBQUs2RyxlQUFlLENBQUM7QUFDL0QsY0FBTXVFLFdBQVcsT0FBT3BMLEtBQUs2QyxZQUFZLFdBQVc3QyxLQUFLNkMsVUFBVSxDQUFDO0FBQ3BFLGNBQU1MLGVBQ0p4QyxLQUFLd0MsY0FBY1csT0FDbkJuRCxLQUFLd0MsZ0JBQ0x4QyxLQUFLcUUsWUFBWWxCLE9BQ2pCbkQsS0FBS3FFO0FBRVA2RyxrQkFBVWxMLEtBQUttRCxHQUFHLElBQUk7QUFBQSxVQUNwQmlILE1BQU07QUFBQSxZQUNKL0csUUFBUTtBQUFBLFlBQ1IwRCxnQkFBZ0IvRyxLQUFLK0csa0JBQWtCSCxRQUFROUIsYUFBYTtBQUFBLFlBQzVEcUMsY0FBY25ILEtBQUttSCxnQkFBZ0JQLFFBQVFoQyxnQkFBZ0I7QUFBQSxZQUMzRE8sV0FBV25GLEtBQUttRixhQUFhaUcsU0FBU2hHLGNBQWM7QUFBQSxZQUNwREMsY0FBY3JGLEtBQUtxRixnQkFBZ0I7QUFBQSxZQUNuQ2dELGNBQWNySSxLQUFLbUQ7QUFBQUEsWUFDbkJYO0FBQUFBLFlBQ0FLLFNBQVN1SSxTQUFTakksT0FBT25ELEtBQUs2QztBQUFBQSxZQUM5QmdFLGNBQWNELFFBQVF6RCxPQUFPbkQsS0FBSzZHO0FBQUFBLFVBQ3BDO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUVELFlBQU0xSyxJQUFJK0gsS0FBSyx1Q0FBdUNnSCxTQUFTO0FBQy9EL04sVUFBSTBHLFFBQVE7QUFBQSxRQUNWdEosU0FBUztBQUFBLFFBQ1R1SixhQUFhO0FBQUEsTUFDZixDQUFDO0FBRUQsWUFBTXVILGdCQUFnQixFQUFFLEdBQUd0SyxlQUFlO0FBQzFDa0osb0JBQWNrQixRQUFRLENBQUNuTCxTQUFTLE9BQU9xTCxjQUFjckwsS0FBS21ELEdBQUcsQ0FBQztBQUM5RG5DLHdCQUFrQnFLLGFBQWE7QUFDL0JqSywyQkFBcUIsS0FBSztBQUFBLElBQzVCLFNBQVN3SixLQUFLO0FBQ1o3SSxjQUFRRCxNQUFNOEksR0FBRztBQUNqQnpOLFVBQUkyRSxNQUFNO0FBQUEsUUFDUnZILFNBQVM7QUFBQSxRQUNUdUosYUFBYThHLElBQUlsSixVQUFVRSxNQUFNckgsV0FBVztBQUFBLE1BQzlDLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQytHLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0ssZUFBZSxPQUFPdkksT0FBTztBQUNqQ25GLG9CQUFnQixJQUFJO0FBQ3BCZ0Msd0JBQW9CLEVBQUUsR0FBR0Qsa0JBQWtCRSxTQUFTLE1BQU0sQ0FBQztBQUMzRCxRQUFJO0FBQ0YsWUFBTTFELElBQUlvUCxPQUFPLHVCQUF1QnhJLEVBQUUsRUFBRTtBQUM1QzVGLFVBQUkwRyxRQUFRLEVBQUV0SixTQUFTLFdBQVd1SixhQUFhLHdCQUF3QixDQUFDO0FBQ3hFMUIsdUJBQWlCO0FBQUEsSUFDbkIsU0FBU04sT0FBTztBQUNkM0UsVUFBSTJFLE1BQU0sRUFBRXZILFNBQVMsU0FBU3VKLGFBQWEsb0JBQW9CLENBQUM7QUFBQSxJQUNsRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEgsZ0JBQWdCQSxDQUFDekksT0FBTztBQUM1QjFJLFVBQU1nUSxRQUFRO0FBQUEsTUFDWnhOLE9BQU87QUFBQSxNQUNQME4sU0FBUztBQUFBLE1BQ1RDLFFBQVE7QUFBQSxNQUNSaUIsUUFBUTtBQUFBLE1BQ1JoQixZQUFZO0FBQUEsTUFDWkMsT0FBTztBQUNMWSxxQkFBYXZJLEVBQUU7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNMkksY0FBY0EsQ0FBQzFMLFNBQVM7QUFDNUJwQyxvQkFBZ0IsSUFBSTtBQUNwQmdDLHdCQUFvQixFQUFFLEdBQUdELGtCQUFrQkUsU0FBUyxNQUFNLENBQUM7QUFDM0QsVUFBTStHLFVBQ0osT0FBTzVHLEtBQUs2RyxpQkFBaUIsV0FBVzdHLEtBQUs2RyxlQUFlLENBQUM7QUFDL0QsVUFBTUcsV0FBV2hILEtBQUsrRyxrQkFBa0JILFFBQVE5QixhQUFhO0FBQzdELFVBQU02RyxZQUFZM0wsS0FBS21ILGdCQUFnQlAsUUFBUWhDLGdCQUFnQjtBQUMvRCxVQUFNTyxZQUFZbkYsS0FBS21GLGFBQWFuRixLQUFLNkMsU0FBU3VDLGNBQWM7QUFDaEUsVUFBTTFDLFVBQVUxQyxLQUFLbUksVUFBVXpGLFdBQVc7QUFDMUMsVUFBTTJDLGVBQWVyRixLQUFLcUYsZ0JBQWdCO0FBQzFDLFVBQU13QyxhQUNKLE9BQU9qQixZQUFZLFdBQ2ZBLFFBQVFVLGVBQWVWLFFBQVF6RCxPQUFPLFFBQ3RDO0FBQ04sVUFBTThFLGNBQWNqSSxLQUFLa0ksWUFDckIsSUFBSTBELEtBQUs1TCxLQUFLa0ksU0FBUyxFQUNwQjJELG1CQUFtQixTQUFTO0FBQUEsTUFDM0JDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLElBQ1AsQ0FBQyxFQUNBQyxRQUFRLE9BQU8sR0FBRyxJQUNyQjtBQUNKLFVBQU1uRSxjQUFjOUgsS0FBSzhILGNBQ3JCLElBQUk4RCxLQUFLNUwsS0FBSzhILFdBQVcsRUFDdEIrRCxtQkFBbUIsU0FBUztBQUFBLE1BQzNCQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLEtBQUs7QUFBQSxJQUNQLENBQUMsRUFDQUMsUUFBUSxPQUFPLEdBQUcsSUFDckI7QUFFSixVQUFNQyxjQUFjakssT0FBT0MsS0FBSyxJQUFJLFFBQVE7QUFDNUMsVUFBTWlLLGVBQWVBLE1BQU07QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFJUC9QLEtBQUs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlGQVdvRDZMLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0VBU2JqQixRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0VBSVJhLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrRUFJVjhELFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrRUFJVHhHLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrRUFJVEUsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBS3BEM0MsV0FBVyxJQUFJLG1CQUFtQixjQUFjO0FBQUEsa0JBQ3JFQSxXQUFXLElBQUksYUFBYSxPQUFPLEtBQUswSixLQUFLQyxJQUFJM0osT0FBTyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUVBYUZvRixnQkFBZ0IsUUFBUSxJQUFJOEQsS0FBSzlELFdBQVcsRUFBRXdFLGVBQWUsV0FBVyxFQUFFUCxPQUFPLE9BQU8sQ0FBQyxJQUFJLEtBQUs7QUFBQTtBQUFBO0FBQUE7QUFBQSx5RUFJbEdqRSxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FvQnpDRCxVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWdCakRxRSxnQkFBWUssU0FBU0MsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQStCS0wsYUFBYSxDQUFDO0FBQUEsb0NBQ2RBLGFBQWEsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBVTdDO0FBQ0RELGdCQUFZSyxTQUFTRSxNQUFNO0FBQzNCUCxnQkFBWVEsTUFBTTtBQUFBLEVBQ3BCO0FBRUEsUUFBTXRLLG1CQUFtQixZQUFZO0FBQ25DLFFBQUk7QUFDRnBELHNCQUFnQixJQUFJO0FBQ3BCLFlBQU0wQyxXQUFXLE1BQU12RixJQUFJd0YsSUFBSSw2QkFBNkJoRCxRQUFRLEVBQUU7QUFDdEVHLHdCQUFrQjRDLFNBQVNFLE1BQU1BLFFBQVEsRUFBRTtBQUUzQyxZQUFNK0ssYUFBYSxDQUFDO0FBQ3BCakwsZUFBU0UsTUFBTUEsTUFBTXVKLFFBQVEsQ0FBQ25MLFNBQVM7QUFDckMsY0FBTStDLEtBQUsvQyxLQUFLbUQ7QUFDaEIsY0FBTXlELFVBQ0osT0FBTzVHLEtBQUs2RyxpQkFBaUIsV0FBVzdHLEtBQUs2RyxlQUFlLENBQUM7QUFDL0Q4RixtQkFBVzVKLEVBQUUsSUFBSTtBQUFBLFVBQ2ZxSCxNQUFNO0FBQUEsWUFDSi9HLFFBQVE7QUFBQSxZQUNSMkQsVUFBVWhILEtBQUsrRyxrQkFBa0JILFFBQVE5QjtBQUFBQSxZQUN6QzZHLFdBQVczTCxLQUFLbUgsZ0JBQWdCUCxRQUFRaEM7QUFBQUEsVUFDMUM7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQ0Q1RCx3QkFBa0IyTCxVQUFVO0FBQUEsSUFDOUIsU0FBUzdLLE9BQU87QUFDZGhELHdCQUFrQixFQUFFO0FBQUEsSUFDdEIsVUFBQztBQUNDRSxzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU00TixlQUFlQyxRQUFRLE1BQU07QUFDakMsVUFBTUMsU0FBU2pPLGVBQ1p1RixJQUFJLENBQUNwRSxTQUFTO0FBQ2IsWUFBTStNLGNBQWMvTSxNQUFNNkMsV0FBVyxDQUFDO0FBQ3RDLGFBQ0U3QyxLQUFLbUYsY0FDSixPQUFPNEgsZ0JBQWdCLFdBQVdBLFlBQVkzSCxhQUFhO0FBQUEsSUFFaEUsQ0FBQyxFQUNBK0UsT0FBTyxDQUFDNkMsT0FBT3RHLE9BQU91RyxVQUFTRCxTQUFTQyxNQUFLQyxRQUFRRixLQUFLLE1BQU10RyxLQUFLO0FBQ3hFLFdBQU9vRztBQUFBQSxFQUNULEdBQUcsQ0FBQ2pPLGNBQWMsQ0FBQztBQUVuQixRQUFNc08sZ0JBQWdCTjtBQUFBQSxJQUFRLE1BQU07QUFDbEMsYUFBT2hPLGVBQWVzTCxPQUFPLENBQUNuSyxTQUFTO0FBQ3JDLFlBQUlDLG1CQUFtQixTQUFTRCxLQUFLcUQsV0FBV3BEO0FBQzlDLGlCQUFPO0FBQ1QsWUFBSUUsd0JBQXdCLE9BQU87QUFDakMsZ0JBQU00TSxjQUFjL00sTUFBTTZDLFdBQVcsQ0FBQztBQUN0QyxnQkFBTXNDLFlBQ0puRixLQUFLbUYsY0FDSixPQUFPNEgsZ0JBQWdCLFdBQVdBLFlBQVkzSCxhQUFhO0FBQzlELGNBQUlELGNBQWNoRixvQkFBcUIsUUFBTztBQUFBLFFBQ2hEO0FBQ0EsWUFBSVEsa0JBQWtCRSxjQUFjO0FBQ2xDLGdCQUFNdU0sV0FBV3BOLEtBQUtrSSxZQUFZaE0sTUFBTThELEtBQUtrSSxTQUFTLElBQUk7QUFDMUQsY0FBSSxDQUFDa0YsU0FBVSxRQUFPO0FBQ3RCLGNBQUl6TSxrQkFBa0J5TSxTQUFTQyxTQUFTblIsTUFBTXlFLGNBQWMsR0FBRyxLQUFLO0FBQ2xFLG1CQUFPO0FBQ1QsY0FBSUUsZ0JBQWdCdU0sU0FBU0UsUUFBUXBSLE1BQU0yRSxZQUFZLEdBQUcsS0FBSztBQUM3RCxtQkFBTztBQUFBLFFBQ1g7QUFDQSxlQUFPO0FBQUEsTUFDVCxDQUFDO0FBQUEsSUFDSDtBQUFBLElBQUc7QUFBQSxNQUNEaEM7QUFBQUEsTUFDQW9CO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FRO0FBQUFBLE1BQ0FFO0FBQUFBLElBQVk7QUFBQSxFQUNiO0FBRUQsUUFBTXFKLHNCQUFzQjJDLFFBQVEsTUFBTTtBQUN4QyxRQUFJeE0sMEJBQTBCLE1BQU8sUUFBTzhNO0FBQzVDLFdBQU9BLGNBQWNoRCxPQUFPLENBQUNuSyxTQUFTO0FBQ3BDLFlBQU0wQyxVQUFVMUMsS0FBS21JLFVBQVV6RixXQUFXO0FBQzFDLFVBQUlyQywwQkFBMEIsVUFBVyxRQUFPcUMsVUFBVTtBQUMxRCxVQUFJckMsMEJBQTBCLFdBQVksUUFBT3FDLFdBQVc7QUFDNUQsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDeUssZUFBZTlNLHFCQUFxQixDQUFDO0FBRXpDLFFBQU1rTixlQUFlVixRQUFRLE1BQU07QUFDakMsVUFBTVcsZ0JBQWdCTDtBQUN0QixVQUFNTSxnQkFBZ0JELGVBQWUvSyxVQUFVO0FBQy9DLFVBQU1pTCxrQkFDSkYsZUFBZXJELE9BQU8sQ0FBQ25LLFNBQVNBLE1BQU1xRCxXQUFXLFNBQVMsR0FBR1osVUFBVTtBQUN6RSxVQUFNa0wsaUJBQ0pILGVBQWVyRCxPQUFPLENBQUNuSyxTQUFTQSxNQUFNcUQsV0FBVyxRQUFRLEdBQUdaLFVBQVU7QUFDeEUsVUFBTW1MLGlCQUNKSixlQUFlckQsT0FBTyxDQUFDbkssU0FBU0EsTUFBTXFELFdBQVcsUUFBUSxHQUFHWixVQUFVO0FBQ3hFLFVBQU1vTCxzQkFDSkwsZUFBZXJELE9BQU8sQ0FBQ25LLFNBQVNBLE1BQU1xRCxXQUFXLGFBQWEsR0FBR1osVUFDakU7QUFDRixVQUFNcUwsaUJBQ0pOLGVBQWVyRCxPQUFPLENBQUNuSyxTQUFTQSxNQUFNcUQsV0FBVyxRQUFRLEdBQUdaLFVBQVU7QUFDeEUsVUFBTXNMLGVBQ0pQLGVBQWVRO0FBQUFBLE1BQ2IsQ0FBQ0MsS0FBS2pPLFNBQVNpTyxPQUFPak8sTUFBTW1JLFVBQVV6RixXQUFXO0FBQUEsTUFDakQ7QUFBQSxJQUNGLEtBQUs7QUFFTCxVQUFNd0wsa0JBQWtCVixlQUFlUTtBQUFBQSxNQUNuQyxDQUFDQyxLQUFLak8sU0FBU2lPLE9BQU9qTyxNQUFNbUksVUFBVWdHLGVBQWVuTyxNQUFNbU8sZUFBZTtBQUFBLE1BQzFFO0FBQUEsSUFDRixLQUFLO0FBRVQsVUFBTUMsYUFBYSxDQUFDO0FBQ3BCLEtBQUNaLGlCQUFpQixJQUFJckMsUUFBUSxDQUFDbkwsU0FBUztBQUN0QyxVQUFJLENBQUNBLEtBQU07QUFDWCxZQUFNK00sY0FBYy9NLE1BQU02QyxXQUFXLENBQUM7QUFDdEMsWUFBTXNDLFlBQ0puRixNQUFNbUYsY0FDTCxPQUFPNEgsZ0JBQWdCLFdBQVdBLGFBQWEzSCxhQUFhO0FBQy9ELFVBQUksQ0FBQ0QsVUFBVztBQUVoQixVQUFJLENBQUNpSixXQUFXakosU0FBUyxHQUFHO0FBQzFCaUosbUJBQVdqSixTQUFTLElBQUk7QUFBQSxVQUN0QmtKLE9BQU87QUFBQSxVQUNQQyxTQUFTO0FBQUEsVUFDVEMsUUFBUTtBQUFBLFVBQ1JDLGFBQWE7QUFBQSxVQUNiQyxRQUFRO0FBQUEsVUFDUkMsUUFBUTtBQUFBLFVBQ1JDLG1CQUFtQjtBQUFBLFVBQ25CQyxzQkFBc0I7QUFBQSxVQUN0QkMsbUJBQW1CO0FBQUEsVUFDbkJDLG9CQUFvQjtBQUFBLFVBQ3BCQyxlQUFlO0FBQUEsVUFDZmxNLFNBQVNrSyxhQUFhNUosT0FBT25ELEtBQUs2QyxTQUFTTSxPQUFPbkQsS0FBSzZDO0FBQUFBLFFBQ3pEO0FBQUEsTUFDRjtBQUVBdUwsaUJBQVdqSixTQUFTLEVBQUVrSjtBQUN0QkQsaUJBQVdqSixTQUFTLEVBQUU0SixpQkFBaUIvTyxLQUFLbUksVUFBVXpGLFdBQVc7QUFFakUsVUFBSTFDLEtBQUtxRCxXQUFXLFVBQVcrSyxZQUFXakosU0FBUyxFQUFFbUo7QUFDckQsVUFBSXRPLEtBQUtxRCxXQUFXLFNBQVUrSyxZQUFXakosU0FBUyxFQUFFb0o7QUFDcEQsVUFBSXZPLEtBQUtxRCxXQUFXLFNBQVUrSyxZQUFXakosU0FBUyxFQUFFc0o7QUFDcEQsVUFBSXpPLEtBQUtxRCxXQUFXLGNBQWUrSyxZQUFXakosU0FBUyxFQUFFcUo7QUFDekQsVUFBSXhPLEtBQUtxRCxXQUFXLFNBQVUrSyxZQUFXakosU0FBUyxFQUFFdUo7QUFFcEQsWUFBTU0sV0FBV2hQLEtBQUs4SDtBQUN0QixVQUFJa0gsVUFBVTtBQUNaLGNBQU1DLG9CQUFvQmIsV0FBV2pKLFNBQVMsRUFBRXdKO0FBQ2hELGNBQU1PLGNBQWNoVCxNQUFNOFMsUUFBUTtBQUNsQyxZQUNFLENBQUNDLHFCQUNEQyxZQUFZN0IsU0FBU25SLE1BQU0rUyxpQkFBaUIsQ0FBQyxHQUM3QztBQUNBYixxQkFBV2pKLFNBQVMsRUFBRXdKLG9CQUFvQks7QUFDMUNaLHFCQUFXakosU0FBUyxFQUFFeUosdUJBQXVCTSxZQUFZQyxRQUFRLElBQzdERCxZQUFZbEcsT0FBTyxZQUFZLElBQy9CO0FBQUEsUUFDTjtBQUFBLE1BQ0Y7QUFFQSxVQUFJaEosS0FBS29QLGVBQWUsZ0JBQWdCO0FBQ3RDaEIsbUJBQVdqSixTQUFTLEVBQUUySjtBQUFBQSxNQUN4QjtBQUFBLElBQ0YsQ0FBQztBQUVELFVBQU1PLGVBQWU7QUFBQSxNQUNuQmYsU0FBUyxFQUFFZ0IsT0FBTyxHQUFHQyxRQUFRLEVBQUU7QUFBQSxNQUMvQkMsVUFBVSxFQUFFRixPQUFPLEVBQUU7QUFBQSxJQUN2QjtBQUVBLEtBQUM5QixpQkFBaUIsSUFBSXJDLFFBQVEsQ0FBQ25MLFNBQVM7QUFDdEMsWUFBTTBDLFVBQVUxQyxNQUFNbUksVUFBVXpGLFdBQVc7QUFDM0MsVUFBSUEsVUFBVSxHQUFHO0FBQ2YyTSxxQkFBYWYsUUFBUWdCO0FBQ3JCRCxxQkFBYWYsUUFBUWlCLFVBQVU3TTtBQUFBQSxNQUNqQyxPQUFPO0FBQ0wyTSxxQkFBYUcsU0FBU0Y7QUFBQUEsTUFDeEI7QUFBQSxJQUNGLENBQUM7QUFFRCxXQUFPO0FBQUEsTUFDTDdCLGVBQWVBLGlCQUFpQjtBQUFBLE1BQ2hDQyxpQkFBaUJBLG1CQUFtQjtBQUFBLE1BQ3BDQyxnQkFBZ0JBLGtCQUFrQjtBQUFBLE1BQ2xDQyxnQkFBZ0JBLGtCQUFrQjtBQUFBLE1BQ2xDQyxxQkFBcUJBLHVCQUF1QjtBQUFBLE1BQzVDQyxnQkFBZ0JBLGtCQUFrQjtBQUFBLE1BQ2xDQyxjQUFjQSxnQkFBZ0I7QUFBQSxNQUM3QkcsaUJBQWlCQSxtQkFBbUI7QUFBQSxNQUNyQ0UsWUFBWUEsY0FBYyxDQUFDO0FBQUEsTUFDM0JpQixjQUFjQSxnQkFBZ0I7QUFBQSxRQUM1QmYsU0FBUyxFQUFFZ0IsT0FBTyxHQUFHQyxRQUFRLEVBQUU7QUFBQSxRQUMvQkMsVUFBVSxFQUFFRixPQUFPLEVBQUU7QUFBQSxNQUN2QjtBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ25DLGFBQWEsQ0FBQztBQUVsQixRQUFNc0MsZ0JBQWdCNUMsUUFBUSxNQUFNO0FBQ2xDLFdBQU8zQyxvQkFBb0JDO0FBQUFBLE1BQ3pCLENBQUNuSyxTQUFTZSxlQUFlZixLQUFLbUQsR0FBRyxHQUFHaUgsTUFBTS9HO0FBQUFBLElBQzVDLEVBQUVaO0FBQUFBLEVBQ0osR0FBRyxDQUFDeUgscUJBQXFCbkosY0FBYyxDQUFDO0FBRXhDLFFBQU0yTyxtQkFBbUI3QyxRQUFRLE1BQU07QUFDckMsV0FBTzNDLG9CQUFvQjlGLElBQUksQ0FBQ3BFLE1BQU0wRyxVQUFVO0FBQzlDLFlBQU1pSixhQUFhM1AsTUFBTTZHLGdCQUFnQixDQUFDO0FBQzFDLFlBQU1rRyxjQUFjL00sTUFBTTZDLFdBQVcsQ0FBQztBQUN0QyxZQUFNbUUsV0FDSmhILEtBQUsrRyxtQkFDSixPQUFPNEksZUFBZSxXQUFXQSxXQUFXN0ssWUFBWTtBQUMzRCxZQUFNNkcsWUFDSjNMLEtBQUttSCxpQkFDSixPQUFPd0ksZUFBZSxXQUFXQSxXQUFXL0ssZUFBZTtBQUM5RCxZQUFNWixTQUNKLE9BQU8yTCxlQUFlLFdBQVdBLFdBQVd4TSxNQUFNd007QUFDcEQsWUFBTTlILGFBQ0osT0FBTzhILGVBQWUsV0FDbEJBLFdBQVdySSxlQUFlLFFBQzFCO0FBQ04sWUFBTW5DLFlBQ0puRixLQUFLbUYsY0FDSixPQUFPNEgsZ0JBQWdCLFdBQVdBLFlBQVkzSCxhQUFhO0FBRTlELFlBQU13SyxrQkFBa0I1UCxNQUFNNFAsbUJBQW1CO0FBQ2pELFlBQU1DLGlCQUFpQjdQLE1BQU1tSSxVQUFVekYsV0FBVztBQUVsRCxZQUFNb04sYUFBYTlQLE1BQU1tSSxVQUFVZ0csZUFBZW5PLE1BQU1tTyxlQUFlO0FBQ3ZFLFlBQU00QixnQkFBZ0IvUCxNQUFNbUksVUFBVTZILG9CQUFvQjtBQUUxRCxVQUFJQyxZQUFZO0FBQ2hCLFlBQU0xSSxjQUFjdkgsS0FBS3dILG9CQUFvQixDQUFDO0FBQzlDLFlBQU0wSSxzQkFBc0IzSSxZQUFZNUMsUUFBUTRDLFlBQVl6QztBQUM1RCxZQUFNcUwsa0JBQWtCblEsS0FBS3lIO0FBRTdCLFVBQUkwSSxpQkFBaUI7QUFDbkJGLG9CQUFZRTtBQUFBQSxNQUNkLFdBQVdELHFCQUFxQjtBQUM5QkQsb0JBQVlDO0FBQUFBLE1BQ2QsT0FBTztBQUNMRCxvQkFBWWpRLEtBQUsrRyxrQkFBa0JDLFlBQVkyRSxhQUFhO0FBQUEsTUFDOUQ7QUFFQSxZQUFNbEgsYUFDSnpFLE1BQU0wRSxPQUFPQyxRQUFRM0UsTUFBTTBFLE9BQU9FLGVBQzlCLEdBQUc1RSxLQUFLMEUsTUFBTUMsSUFBSSxNQUFNM0UsS0FBSzBFLE1BQU1FLFlBQVksS0FDL0M1RSxNQUFNNkUsbUJBQW1CQyxhQUN2QjlFLE1BQU02RSxtQkFBbUJELGVBQ3pCLEdBQUc1RSxLQUFLNkUsa0JBQWtCQyxTQUFTLE1BQU05RSxLQUFLNkUsa0JBQWtCRCxZQUFZLEtBQzVFNUUsTUFBTStFLGVBQWVDLGFBQ25CaEYsTUFBTStFLGVBQWVFLGVBQ3JCLEdBQUdqRixLQUFLK0UsY0FBY0MsU0FBUyxNQUFNaEYsS0FBSytFLGNBQWNFLFlBQVksS0FDcEU7QUFFVixZQUFNekMsZUFBZXhDLEtBQUt3QyxjQUFjVyxPQUFPbkQsS0FBS3dDO0FBQ3BELFlBQU00TixpQkFBaUJwUSxLQUFLa0Ysb0JBQW9CO0FBQ2hELFlBQU1tTCxhQUFhLENBQUMsQ0FBQ3RQLGVBQWVmLEtBQUttRCxHQUFHLEdBQUdpSCxNQUFNL0c7QUFDcEQsWUFBTWlOLGdCQUFnQnRRLE1BQU11USxVQUFVO0FBRXJDLFVBQUlDLHFCQUFxQjtBQUM3QixVQUFJQyxpQkFBaUI7QUFFckIsVUFBSXpRLEtBQUs4SCxhQUFhO0FBQ3BCMkkseUJBQWlCelEsS0FBSzhIO0FBQ3RCMEksNkJBQXFCdFUsTUFBTThELEtBQUs4SCxXQUFXLEVBQUVrQixPQUFPLFlBQVk7QUFBQSxNQUNsRTtBQUVFLGFBQU87QUFBQSxRQUNMMEgsS0FBSzFRLEtBQUttRDtBQUFBQSxRQUNWQSxLQUFLbkQsS0FBS21EO0FBQUFBLFFBQ1ZKLElBQUkyRCxRQUFRO0FBQUEsUUFDWk07QUFBQUEsUUFDQTdCO0FBQUFBLFFBQ0EwQztBQUFBQSxRQUNBVixjQUFjd0U7QUFBQUEsUUFDZGdGLGFBQWFoRjtBQUFBQSxRQUNiaUYsTUFBTTVRLEtBQUtrSSxZQUFZbEksS0FBS2tJLFVBQVV4QyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUk7QUFBQSxRQUN0REwsY0FBY3JGLEtBQUtxRixnQkFBZ0I7QUFBQSxRQUNuQ0gsa0JBQWtCa0w7QUFBQUEsUUFDbEJHLFFBQU9EO0FBQUFBLFFBQ1BFO0FBQUFBO0FBQUFBLFFBQ0YxSSxhQUFhMkk7QUFBQUEsUUFDYjFJLGFBQWEvSCxLQUFLZ0ksZUFDZDlMLE1BQU04RCxLQUFLZ0ksY0FBYyxPQUFPLEVBQUVnQixPQUFPLFFBQVEsSUFDakQ7QUFBQSxRQUNGNkgsb0JBQW9CN1EsS0FBSzZRLHNCQUFzQjtBQUFBLFFBQy9DekIsWUFBWXBQLEtBQUtvUCxjQUFjO0FBQUEsUUFDL0IwQixvQkFBb0I5USxLQUFLOFEsc0JBQXNCO0FBQUEsUUFDL0NyTTtBQUFBQSxRQUNBc00sMEJBQTBCbkIsbUJBQW1CO0FBQUEsUUFFN0NvQixzQkFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FDRXBCLG1CQUFtQixJQUNmLGlDQUNBO0FBQUEsWUFDTDtBQUFBO0FBQUEsY0FFRUEsZ0JBQWdCdEQsZUFBZSxPQUFPO0FBQUE7QUFBQTtBQUFBLFVBUDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsUUFHRjJFLHlCQUF5QnBCLGtCQUFrQjtBQUFBLFFBQzNDcUIscUJBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQ0VyQixrQkFBa0IsSUFDZCxpQ0FDQTtBQUFBLFlBQ0w7QUFBQTtBQUFBLGNBRUVBLGVBQWV2RCxlQUFlLE9BQU87QUFBQTtBQUFBO0FBQUEsVUFQMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxRQUdGNkUscUJBQXFCckIsY0FBYztBQUFBLFFBQ3JDc0IsaUJBQ0UsdUJBQUMsVUFBSyxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsVUFDekN0QixXQUFXeEQsZUFBZSxPQUFPO0FBQUEsYUFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHQTlKO0FBQUFBLFFBQ0E2TyxVQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTaEI7QUFBQUEsWUFDVCxVQUFVLENBQUNpQixNQUFNO0FBQ2Z0USxnQ0FBa0IsQ0FBQ3VRLFVBQVU7QUFBQSxnQkFDM0IsR0FBR0E7QUFBQUEsZ0JBQ0gsQ0FBQ3ZSLEtBQUttRCxHQUFHLEdBQUc7QUFBQSxrQkFDVmlILE1BQU07QUFBQSxvQkFDSi9HLFFBQVFpTyxFQUFFRSxPQUFPQztBQUFBQSxvQkFDakJ6SztBQUFBQSxvQkFDQTJFO0FBQUFBLGtCQUNGO0FBQUEsZ0JBQ0Y7QUFBQSxjQUNGLEVBQUU7QUFBQSxZQUNKO0FBQUE7QUFBQSxVQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNJO0FBQUEsUUFHTnRJLFFBQVFyRCxLQUFLcUQsVUFBVTtBQUFBLFFBQ3ZCMEQsZ0JBQWdCL0csS0FBSytHLGtCQUFrQkM7QUFBQUEsUUFDdkNILGNBQWM3QztBQUFBQSxRQUNkb0QsaUJBQWlCcEgsS0FBS21ILGdCQUFnQndFO0FBQUFBLFFBQ3RDK0YsUUFDRSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsQ0FBQ0osTUFBTTtBQUNkQSxnQkFBRUssZ0JBQWdCO0FBQ2xCLG9CQUFNQyxPQUFPTixFQUFFTyxjQUFjQyxzQkFBc0I7QUFDbkRsUyxrQ0FBb0I7QUFBQSxnQkFDbEJDLFNBQ0UsQ0FBQ0YsaUJBQWlCRSxXQUNsQkYsaUJBQWlCSyxNQUFNbUQsUUFBUW5ELEtBQUttRDtBQUFBQSxnQkFDdENyRCxHQUFHOFIsS0FBS0csUUFBUTtBQUFBLGdCQUNoQmhTLEdBQUc2UixLQUFLSSxTQUFTO0FBQUEsZ0JBQ2pCaFMsTUFDRUwsaUJBQWlCRSxXQUNqQkYsaUJBQWlCSyxNQUFNbUQsUUFBUW5ELEtBQUttRCxNQUNoQyxPQUNBbkQ7QUFBQUEsY0FDUixDQUFDO0FBQ0R3Qiw4QkFBZ0IsSUFBSTtBQUFBLFlBQ3RCO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFDVixPQUFPLEVBQUV5USxRQUFRLElBQUk7QUFBQSxZQUFFO0FBQUE7QUFBQSxVQW5CekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxNQUVKO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUMvSCxxQkFBcUJ2SyxrQkFBa0JvQixjQUFjLENBQUM7QUFFMURwSCxZQUFVLE1BQU07QUFDZCxVQUFNdVksYUFDSmhJLG9CQUFvQnpILFNBQVMsS0FDN0J5SCxvQkFBb0JpSTtBQUFBQSxNQUNsQixDQUFDblMsU0FBU2UsZUFBZWYsS0FBS21ELEdBQUcsR0FBR2lILE1BQU0vRztBQUFBQSxJQUM1QztBQUNGbkMsaUJBQWFnUixVQUFVO0FBQUEsRUFDekIsR0FBRyxDQUFDaEkscUJBQXFCbkosY0FBYyxDQUFDO0FBR3hDcEgsWUFBVSxNQUFNO0FBQ2QsVUFBTXlZLHFCQUFxQkEsQ0FBQ0MsVUFBVTtBQUVwQyxVQUNFLENBQUNBLE1BQU1iLE9BQU9jLFFBQVEsbUJBQW1CLEtBQ3pDLENBQUNELE1BQU1iLE9BQU9jLFFBQVEsZ0JBQWdCLEdBQ3RDO0FBQ0ExVSx3QkFBZ0IsSUFBSTtBQUNwQjRELHdCQUFnQixJQUFJO0FBQ3BCNUIsNEJBQW9CLEVBQUUsR0FBR0Qsa0JBQWtCRSxTQUFTLE1BQU0sQ0FBQztBQUFBLE1BQzdEO0FBQUEsSUFDRjtBQUNBME0sYUFBU2xLLGlCQUFpQixhQUFhK1Asa0JBQWtCO0FBQ3pELFdBQU8sTUFBTTdGLFNBQVNqSyxvQkFBb0IsYUFBYThQLGtCQUFrQjtBQUFBLEVBQzNFLEdBQUcsQ0FBQ3pTLGdCQUFnQixDQUFDO0FBRXJCLFFBQU00UyxVQUFVO0FBQUEsSUFDZCxFQUFFN0IsS0FBSyxNQUFNOEIsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRTlCLEtBQUssb0JBQW9COEIsUUFBUSxtQkFBbUI7QUFBQSxJQUN0RCxFQUFFOUIsS0FBSyxRQUFROEIsUUFBUSxlQUFlO0FBQUEsSUFDdEMsRUFBRTlCLEtBQUssZUFBZThCLFFBQVEsZUFBZTtBQUFBLElBQzdDLEVBQUU5QixLQUFLLFlBQVk4QixRQUFRLGtCQUFrQjtBQUFBLElBQzdDLEVBQUU5QixLQUFLLGVBQWU4QixRQUFRLGVBQWU7QUFBQSxJQUM3QyxFQUFFOUIsS0FBSyxjQUFjOEIsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRTlCLEtBQUssYUFBYThCLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUU5QixLQUFLLGdCQUFnQjhCLFFBQVEsU0FBUztBQUFBLElBQ3hDLEVBQUU5QixLQUFLLHNCQUFzQjhCLFFBQVEsZUFBZTtBQUFBLElBQ3BELEVBQUU5QixLQUFLLGNBQWM4QixRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFOUIsS0FBSyxVQUFVOEIsUUFBUSxlQUFjO0FBQUEsSUFDdkMsRUFBRTlCLEtBQUssbUJBQW1COEIsUUFBUSxjQUFjO0FBQUE7QUFBQSxJQUVoRCxFQUFFOUIsS0FBSyx1QkFBdUI4QixRQUFRLGtCQUFrQjtBQUFBLElBQ3hELEVBQUU5QixLQUFLLFlBQVk4QixRQUFRLFNBQVM7QUFBQSxJQUNwQyxFQUFFOUIsS0FBSyxVQUFVOEIsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRTlCLEtBQUssVUFBVThCLFFBQVEsVUFBVUMsT0FBTyxJQUFJO0FBQUEsRUFBQztBQUdqRCxRQUFNQyxlQUFlO0FBQUEsSUFDbkIsRUFBRWhDLEtBQUssTUFBTThCLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUU5QixLQUFLLG9CQUFvQjhCLFFBQVEsbUJBQW1CO0FBQUEsSUFDdEQsRUFBRTlCLEtBQUssUUFBUThCLFFBQVEsZUFBZTtBQUFBLElBQ3RDLEVBQUU5QixLQUFLLGVBQWU4QixRQUFRLGVBQWU7QUFBQSxJQUM3QyxFQUFFOUIsS0FBSyxZQUFZOEIsUUFBUSxrQkFBa0I7QUFBQSxJQUM3QyxFQUFFOUIsS0FBSyxlQUFlOEIsUUFBUSxlQUFlO0FBQUEsSUFDN0MsRUFBRTlCLEtBQUssY0FBYzhCLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUU5QixLQUFLLGFBQWE4QixRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFOUIsS0FBSyxnQkFBZ0I4QixRQUFRLFNBQVM7QUFBQSxJQUN4QyxFQUFFOUIsS0FBSyxzQkFBc0I4QixRQUFRLGVBQWU7QUFBQSxJQUNwRCxFQUFFOUIsS0FBSyxjQUFjOEIsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRTlCLEtBQUssVUFBVThCLFFBQVEsZUFBYztBQUFBLElBQ3RDLEVBQUU5QixLQUFLLHVCQUF1QjhCLFFBQVEsY0FBYztBQUFBLElBQ3JELEVBQUU5QixLQUFLLDRCQUE0QjhCLFFBQVEsdUJBQXVCO0FBQUEsSUFDbEUsRUFBRTlCLEtBQUssMkJBQTJCOEIsUUFBUSxrQkFBa0I7QUFBQSxJQUM1RCxFQUFFOUIsS0FBSyxVQUFVOEIsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRTlCLEtBQUssVUFBVThCLFFBQVEsVUFBVUMsT0FBTyxJQUFJO0FBQUEsRUFBQztBQUdqRDlZLFlBQVUsTUFBTTtBQUNkeUkscUJBQWlCO0FBQUEsRUFDbkIsR0FBRyxDQUFDekQsUUFBUSxDQUFDO0FBRWIsU0FDRSxtQ0FDTXZCO0FBQUFBO0FBQUFBLElBQ0osdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUNQLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsMkJBRVpIO0FBQUFBLHdCQUNDLHVCQUFDLFNBQUksV0FBVSxrR0FDYixpQ0FBQyxTQUFJLFdBQVUscURBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsb0ZBQ2IsaUNBQUMsa0JBQWUsV0FBVSxhQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQyxLQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLCtCQUE4QixvQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxjQUNoRSx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLDZDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRTtBQUFBLGlCQUZwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxtQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVN3QyxhQUFha1QsZUFBZTtBQUFBLGdCQUNyQyxVQUFVLE9BQU9sQixZQUFZO0FBQzNCLHNCQUFJO0FBQ0YsMEJBQU10VixJQUFJK0gsS0FBSyw0QkFBNEI7QUFBQSxzQkFDekN5TyxhQUFhbEI7QUFBQUEsb0JBQ2YsQ0FBQztBQUNEL1IsbUNBQWUsQ0FBQTZSLFVBQVMsRUFBRSxHQUFHQSxNQUFNb0IsYUFBYWxCLFFBQVEsRUFBRTtBQUMxRGxYLDRCQUFRc0osUUFBUSxzQkFBc0I0TixVQUFVLFlBQVksVUFBVSxFQUFFO0FBQUEsa0JBQzFFLFNBQVMzUCxPQUFPO0FBQ2R2SCw0QkFBUXVILE1BQU0sOEJBQThCO0FBQUEsa0JBQzlDO0FBQUEsZ0JBQ0Y7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQWJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWEyQjtBQUFBLGVBZjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQSxLQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsUUFJRix1QkFBQyxTQUFJLFdBQVUsMEVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsb0NBQW1DLDhCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsaUJBQWdCLHVEQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUNQRyxPQUFPQztBQUFBQSxrQkFDTDtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxnQkFDRjtBQUFBLGdCQUVGLFdBQVU7QUFBQSxnQkFDVixNQUFNLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsZ0JBQUk7QUFBQTtBQUFBLGNBWDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWNBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsU0FBU0Y7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUFvRjtBQUFBO0FBQUEsY0FKaEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLGFBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsK0RBQ1o7QUFBQSx1Q0FBQyxrQkFBZSxXQUFVLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QztBQUFBLGdCQUFHO0FBQUEsbUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsc0VBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsYUFDRS9CLG1CQUFtQixTQUNuQkUsd0JBQXdCLFNBQ3hCRSwwQkFBMEIsU0FDMUJNLGtCQUNBRSxpQkFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNpSztBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQTBDO0FBQUE7QUFBQSxjQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDBCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU8sRUFBRTJILE9BQU8sT0FBTztBQUFBLG9CQUN2QixPQUFPbFM7QUFBQUEsb0JBQ1AsVUFBVUM7QUFBQUEsb0JBQ1YsUUFBTztBQUFBLG9CQUNQLGFBQVk7QUFBQSxvQkFDWixNQUFLO0FBQUE7QUFBQSxrQkFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTWM7QUFBQSxnQkFFZDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPLEVBQUVpUyxPQUFPLE9BQU87QUFBQSxvQkFDdkIsT0FBT2hTO0FBQUFBLG9CQUNQLFVBQVVDO0FBQUFBLG9CQUNWLFFBQU87QUFBQSxvQkFDUCxhQUFZO0FBQUEsb0JBQ1osTUFBSztBQUFBO0FBQUEsa0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1jO0FBQUEsbUJBZmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPVDtBQUFBQSxrQkFDUCxVQUFVQztBQUFBQSxrQkFDVixXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUVMO0FBQUEsMkNBQUMsVUFBTyxPQUFNLE9BQU0sMEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThCO0FBQUEsb0JBQzlCLHVCQUFDLFVBQU8sT0FBTSxXQUFVLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBLG9CQUMvQix1QkFBQyxVQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQSxvQkFDN0IsdUJBQUMsVUFBTyxPQUFNLFVBQVMsd0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStCO0FBQUEsb0JBQy9CLHVCQUFDLFVBQU8sT0FBTSxlQUFjLDRCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3QztBQUFBLG9CQUN4Qyx1QkFBQyxVQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQTtBQUFBO0FBQUEsZ0JBWC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlBO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPRztBQUFBQSxrQkFDUCxVQUFVQztBQUFBQSxrQkFDVixXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUVMO0FBQUEsMkNBQUMsVUFBTyxPQUFNLE9BQU0sNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsb0JBQ2hDLHVCQUFDLFVBQU8sT0FBTSxXQUFVLCtCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1QztBQUFBLG9CQUN2Qyx1QkFBQyxVQUFPLE9BQU0sWUFBVywwQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUM7QUFBQSxvQkFDbkMsdUJBQUMsVUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZCO0FBQUE7QUFBQTtBQUFBLGdCQVQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FVQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU9IO0FBQUFBLGtCQUNQLFVBQVVDO0FBQUFBLGtCQUNWLFdBQVU7QUFBQSxrQkFDVixNQUFLO0FBQUEsa0JBQ0w7QUFBQSxrQkFDQSxjQUFjLENBQUN3UyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0MsWUFBWSxFQUFFQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxrQkFHNUQ7QUFBQSwyQ0FBQyxVQUFPLE9BQU0sT0FBTSwwQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEI7QUFBQSxvQkFDN0JuRyxhQUFheEk7QUFBQUEsc0JBQUksQ0FBQ0csVUFDakIsdUJBQUMsVUFBbUIsT0FBT0EsT0FDeEJBLG1CQURVQSxPQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUE7QUFBQSxnQkFmSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FnQkE7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw0REFBMkQsMEJBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFNBQVN0RDtBQUFBQSxrQkFDVCxVQUFVLENBQUNxUSxNQUFNO0FBQ2YsMEJBQU1HLFVBQVVILEVBQUVFLE9BQU9DO0FBQ3pCdlEsaUNBQWF1USxPQUFPO0FBQ3BCLDBCQUFNd0IsVUFBVSxFQUFFLEdBQUdsUyxlQUFlO0FBQ3BDbUosd0NBQW9CaUIsUUFBUSxDQUFDbkwsU0FBUztBQUNwQyw0QkFBTTJQLGFBQWEzUCxNQUFNNkcsZ0JBQWdCLENBQUM7QUFDMUMsNEJBQU1HLFdBQ0poSCxLQUFLK0csbUJBQ0osT0FBTzRJLGVBQWUsV0FDbkJBLFdBQVc3SyxZQUNYO0FBQ04sNEJBQU02RyxZQUNKM0wsS0FBS21ILGlCQUNKLE9BQU93SSxlQUFlLFdBQ25CQSxXQUFXL0ssZUFDWDtBQUNOcU8sOEJBQVFqVCxLQUFLbUQsR0FBRyxJQUFJO0FBQUEsd0JBQ2xCaUgsTUFBTSxFQUFFL0csUUFBUW9PLFNBQVN6SyxVQUFVMkUsVUFBVTtBQUFBLHNCQUMvQztBQUFBLG9CQUNGLENBQUM7QUFDRDNLLHNDQUFrQmlTLE9BQU87QUFBQSxrQkFDM0I7QUFBQTtBQUFBLGdCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F5QkksS0ExQk47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0QkE7QUFBQSxpQkFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQ0E7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWU7QUFBQSxnQkFDckIsU0FBU3BJO0FBQUFBLGdCQUFpQjtBQUFBO0FBQUEsY0FKNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQTlIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStIQTtBQUFBLGFBeEpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5SkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDRDQUEyQyw4QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLDZHQUE2RzVLLG1CQUFtQixXQUFXLHdDQUF3QyxFQUFFO0FBQUEsY0FDaE0sU0FBUyxNQUNQQztBQUFBQSxnQkFDRUQsbUJBQW1CLFdBQVcsUUFBUTtBQUFBLGNBQ3hDO0FBQUEsY0FHRixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwyQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0Q7QUFBQSxrQkFDaEQsdUJBQUMsT0FBRSxXQUFVLHNDQUNWc04sdUJBQWFPLGtCQUFrQixLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYixpQ0FBQyxrQkFBZSxXQUFVLDZCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBO0FBQUEsWUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBbUJBLEtBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNENBQTJDLDZCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNkRBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLE9BQUUsV0FBVSx5QkFBd0IsOEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1EO0FBQUEsZ0JBQ25ELHVCQUFDLE9BQUUsV0FBVSxzQkFDVlAsdUJBQWFFLGlCQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixNQUFLO0FBQUEsa0JBQ0wsUUFBTztBQUFBLGtCQUNQLFNBQVE7QUFBQSxrQkFFUjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxlQUFjO0FBQUEsc0JBQ2QsZ0JBQWU7QUFBQSxzQkFDZixhQUFhO0FBQUEsc0JBQ2IsR0FBRTtBQUFBO0FBQUEsb0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlxSTtBQUFBO0FBQUEsZ0JBVnZJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGlCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNCQSxLQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLDZHQUE2R3hOLG1CQUFtQixZQUFZLHdDQUF3QyxFQUFFO0FBQUEsZ0JBQ2pNLFNBQVMsTUFDUEM7QUFBQUEsa0JBQ0VELG1CQUFtQixZQUFZLFFBQVE7QUFBQSxnQkFDekM7QUFBQSxnQkFHRixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3QixnQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUQ7QUFBQSxvQkFDckQsdUJBQUMsT0FBRSxXQUFVLHNDQUNWc04sdUJBQWFHLG1CQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYixpQ0FBQyx1QkFBb0IsV0FBVSw2QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0QsS0FEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQTtBQUFBLGNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW1CQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLDRHQUE0R3pOLG1CQUFtQixXQUFXLHNDQUFzQyxFQUFFO0FBQUEsZ0JBQzdMLFNBQVMsTUFDUEM7QUFBQUEsa0JBQ0VELG1CQUFtQixXQUFXLFFBQVE7QUFBQSxnQkFDeEM7QUFBQSxnQkFHRixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0Q7QUFBQSxvQkFDcEQsdUJBQUMsT0FBRSxXQUFVLHFDQUNWc04sdUJBQWFJLGtCQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYixpQ0FBQyx1QkFBb0IsV0FBVSw0QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUQsS0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQTtBQUFBLGNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW1CQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLDBHQUEwRzFOLG1CQUFtQixXQUFXLGtDQUFrQyxFQUFFO0FBQUEsZ0JBQ3ZMLFNBQVMsTUFDUEM7QUFBQUEsa0JBQ0VELG1CQUFtQixXQUFXLFFBQVE7QUFBQSxnQkFDeEM7QUFBQSxnQkFHRixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3QixpQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0Q7QUFBQSxvQkFDdEQsdUJBQUMsT0FBRSxXQUFVLG1DQUNWc04sdUJBQWFLLGtCQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFDYixpQ0FBQyxpQkFBYyxXQUFVLDBCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQyxLQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBO0FBQUEsY0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbUJBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcsNkdBQTZHM04sbUJBQW1CLGdCQUFnQix3Q0FBd0MsRUFBRTtBQUFBLGdCQUNyTSxTQUFTLE1BQ1BDO0FBQUFBLGtCQUNFRCxtQkFBbUIsZ0JBQWdCLFFBQVE7QUFBQSxnQkFDN0M7QUFBQSxnQkFHRixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3QixvQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSxzQ0FDVnNOLHVCQUFhTSx1QkFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2IsaUNBQUMsZ0JBQWEsV0FBVSw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWUE7QUFBQTtBQUFBLGNBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXFCQTtBQUFBLGVBM0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEdBO0FBQUEsYUFoSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlIQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNENBQTJDO0FBQUE7QUFBQSxZQUMvQjtBQUFBLGVBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUNQdk47QUFBQUEsa0JBQ0VELDBCQUEwQixZQUFZLFFBQVE7QUFBQSxnQkFDaEQ7QUFBQSxnQkFFRixXQUFXLDJHQUEyR0EsMEJBQTBCLFlBQVksb0NBQW9DLEVBQUU7QUFBQSxnQkFFbE0saUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLE9BQUUsV0FBVSxxQ0FBb0MsK0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsMkNBQ1ZrTix3QkFBYzhCLGNBQWNmLFNBQVNnQixTQUFTLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLGtCQUFlLFdBQVUsMkJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlELEtBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVlBO0FBQUE7QUFBQSxjQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFxQkE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUNQaFA7QUFBQUEsa0JBQ0VELDBCQUEwQixhQUFhLFFBQVE7QUFBQSxnQkFDakQ7QUFBQSxnQkFFRixXQUFXLDJHQUEyR0EsMEJBQTBCLGFBQWEsb0NBQW9DLEVBQUU7QUFBQSxnQkFFbk0saUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLE9BQUUsV0FBVSxxQ0FBb0MsbUNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsMkNBQ1ZrTix3QkFBYzhCLGNBQWNHLFVBQVVGLFNBQVMsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2IsaUNBQUMsa0JBQWUsV0FBVSwyQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWUE7QUFBQTtBQUFBLGNBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXFCQTtBQUFBLGVBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkNBO0FBQUEsYUFqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtEQTtBQUFBLFFBRUMvQixjQUFjYSxjQUNiOUUsT0FBTzRKLEtBQUszRixhQUFhYSxjQUFjLENBQUMsQ0FBQyxFQUFFM0wsU0FBUyxLQUNsRCx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVMsTUFBTWpFLG9CQUFvQixDQUFDRCxnQkFBZ0I7QUFBQSxnQkFFcEQ7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsOEJBQTZCLHFDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsWUFBTyxXQUFVLHdEQUNmQSw2QkFDQyx1QkFBQyxjQUFXLFdBQVUsbUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDLElBRXJDLHVCQUFDLGdCQUFhLFdBQVUsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDLEtBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQTtBQUFBO0FBQUEsY0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxlQUFlRSxrQkFBa0IsU0FBUyxrQ0FBa0MsbUNBQW1DO0FBQUEsa0JBQzFILFNBQVMsTUFBTUMsaUJBQWlCLE1BQU07QUFBQSxrQkFFdEMsaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUI7QUFBQTtBQUFBLGdCQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxlQUFlRCxrQkFBa0IsU0FBUyxrQ0FBa0MsbUNBQW1DO0FBQUEsa0JBQzFILFNBQVMsTUFBTUMsaUJBQWlCLE1BQU07QUFBQSxrQkFFdEMsaUNBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0I7QUFBQTtBQUFBLGdCQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQSxlQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThCQTtBQUFBLFVBQ0NILG9CQUFvQkUsa0JBQWtCLFVBQ3JDLHVCQUFDLFNBQUksV0FBVSx1RUFDWjZLLGlCQUFPNkosUUFBUTVGLGFBQWFhLGNBQWMsQ0FBQyxDQUFDLEVBQUVoSztBQUFBQSxZQUM3QyxDQUFDLENBQUNlLFdBQVdpTyxLQUFLLE1BQ2hCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVyxtSUFBbUlqVCx3QkFBd0JnRixZQUFZLDREQUE0RCx1REFBdUQ7QUFBQSxnQkFDclMsU0FBUyxNQUNQL0U7QUFBQUEsa0JBQ0VELHdCQUF3QmdGLFlBQ3BCLFFBQ0FBO0FBQUFBLGdCQUNOO0FBQUEsZ0JBR0Y7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLGdCQUFnQmhGLHdCQUF3QmdGLFlBQVksZ0JBQWdCLDhDQUE4QztBQUFBO0FBQUEsb0JBRC9IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDa0k7QUFBQSxrQkFFbEksdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsT0FBT0E7QUFBQUEsMEJBRU5BO0FBQUFBO0FBQUFBLHdCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVcsNENBQTRDaU8sTUFBTS9FLFFBQVEsSUFBSSxrQ0FBa0MsMkJBQTJCO0FBQUEsMEJBQUc7QUFBQTtBQUFBLDRCQUVqSStFLE1BQU0vRTtBQUFBQTtBQUFBQTtBQUFBQSx3QkFIaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUlBO0FBQUEseUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFZQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVcsZUFBZStFLE1BQU05RSxVQUFVLElBQUksaUJBQWlCLFlBQVk7QUFBQSwwQkFFM0U7QUFBQSxtREFBQyxTQUFJLFdBQVUsNkJBQTRCLG9CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsNEJBQ0E7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0MsV0FBVyxxQkFBcUI4RSxNQUFNOUUsVUFBVSxJQUFJLG9CQUFvQixlQUFlO0FBQUEsZ0NBRXRGOEUsZ0JBQU05RTtBQUFBQTtBQUFBQSw4QkFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBSUE7QUFBQTtBQUFBO0FBQUEsd0JBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVdBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVyxlQUFlOEUsTUFBTTdFLFNBQVMsSUFBSSxnQkFBZ0IsWUFBWTtBQUFBLDBCQUV6RTtBQUFBLG1EQUFDLFNBQUksV0FBVSw2QkFBNEIsb0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFDQTtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxXQUFXLHFCQUFxQjZFLE1BQU03RSxTQUFTLElBQUksbUJBQW1CLGVBQWU7QUFBQSxnQ0FFcEY2RSxnQkFBTTdFO0FBQUFBO0FBQUFBLDhCQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFJQTtBQUFBO0FBQUE7QUFBQSx3QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBV0E7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFXLGVBQWU2RSxNQUFNM0UsU0FBUyxJQUFJLGNBQWMsWUFBWTtBQUFBLDBCQUV2RTtBQUFBLG1EQUFDLFNBQUksV0FBVSw2QkFBNEIscUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFDQTtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxXQUFXLHFCQUFxQjJFLE1BQU0zRSxTQUFTLElBQUksaUJBQWlCLGVBQWU7QUFBQSxnQ0FFbEYyRSxnQkFBTTNFO0FBQUFBO0FBQUFBLDhCQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFJQTtBQUFBO0FBQUE7QUFBQSx3QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBV0E7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFXLGVBQWUyRSxNQUFNMUUsU0FBUyxJQUFJLGlCQUFpQixZQUFZO0FBQUEsMEJBRTFFO0FBQUEsbURBQUMsU0FBSSxXQUFVLDZCQUE0QixvQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDRCQUNBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLFdBQVcscUJBQXFCMEUsTUFBTTFFLFNBQVMsSUFBSSxvQkFBb0IsZUFBZTtBQUFBLGdDQUVyRjBFLGdCQUFNMUU7QUFBQUE7QUFBQUEsOEJBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUlBO0FBQUE7QUFBQTtBQUFBLHdCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFXQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVcsZUFBZTBFLE1BQU01RSxjQUFjLElBQUksaUJBQWlCLFlBQVk7QUFBQSwwQkFFL0U7QUFBQSxtREFBQyxTQUFJLFdBQVUsNkJBQTRCLG9CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsNEJBQ0E7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0MsV0FBVyxxQkFBcUI0RSxNQUFNNUUsY0FBYyxJQUFJLG9CQUFvQixlQUFlO0FBQUEsZ0NBRTFGNEUsZ0JBQU01RTtBQUFBQTtBQUFBQSw4QkFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBSUE7QUFBQTtBQUFBO0FBQUEsd0JBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVdBO0FBQUEseUJBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBNkRBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHNDQUNiLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDZDQUFDLFVBQUssV0FBVSxpREFDZDtBQUFBLCtDQUFDLHVCQUFvQixXQUFVLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE4QztBQUFBLHdCQUM5Qyx1QkFBQyxVQUFLLFdBQVUsZUFBYyxrQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBS0E7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFXLDRDQUE0QzRFLE1BQU14RSx5QkFBeUIsUUFBUSw4QkFBOEIsMkJBQTJCO0FBQUEsMEJBRXRKd0UsZ0JBQU14RSx5QkFBeUIsUUFDNUJ3RSxNQUFNeEUsdUJBQ047QUFBQTtBQUFBLHdCQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNQTtBQUFBLHlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWdCQTtBQUFBLHVCQTVGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTZGQTtBQUFBO0FBQUE7QUFBQSxjQTFHS3pKO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTRHQTtBQUFBLFVBRUosS0FqSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrSEE7QUFBQSxVQUVENUcsb0JBQW9CRSxrQkFBa0IsVUFDckMsdUJBQUMsU0FBSSxXQUFVLDhEQUNiLGlDQUFDLFdBQU0sV0FBVSx1Q0FDZjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxjQUNmLGlDQUFDLFFBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsb0ZBQW1GLDBCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsc0ZBQXFGLHFCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsc0ZBQXFGLHVCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsc0ZBQXFGLHNCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsc0ZBQXFGLHNCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsc0ZBQXFGLHNCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsc0ZBQXFGLGlDQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsWUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ2Q2SyxpQkFBTzZKLFFBQVE1RixhQUFhYSxjQUFjLENBQUMsQ0FBQyxFQUFFaEs7QUFBQUEsY0FDN0MsQ0FBQyxDQUFDZSxXQUFXaU8sS0FBSyxNQUNoQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxXQUFXLEdBQUdqVCx3QkFBd0JnRixZQUFZLGVBQWUsRUFBRTtBQUFBLGtCQUNuRSxTQUFTLE1BQ1AvRTtBQUFBQSxvQkFDRUQsd0JBQXdCZ0YsWUFDcEIsUUFDQUE7QUFBQUEsa0JBQ047QUFBQSxrQkFHRjtBQUFBLDJDQUFDLFFBQUcsV0FBVSxpRUFDWEEsdUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSwyQ0FDWixpQ0FBQyxVQUFLLFdBQVUsNEZBQ2JpTyxnQkFBTS9FLFNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsMkNBQ1o7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxrRUFBa0UrRSxNQUFNOUUsVUFBVSxJQUFJLGtDQUFrQywyQkFBMkI7QUFBQSx3QkFFN0o4RSxnQkFBTTlFO0FBQUFBO0FBQUFBLHNCQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsMkNBQ1o7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxrRUFBa0U4RSxNQUFNN0UsU0FBUyxJQUFJLGdDQUFnQywyQkFBMkI7QUFBQSx3QkFFMUo2RSxnQkFBTTdFO0FBQUFBO0FBQUFBLHNCQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsMkNBQ1o7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxrRUFBa0U2RSxNQUFNM0UsU0FBUyxJQUFJLDRCQUE0QiwyQkFBMkI7QUFBQSx3QkFFdEoyRSxnQkFBTTNFO0FBQUFBO0FBQUFBLHNCQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsMkNBQ1o7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxrRUFBa0UyRSxNQUFNMUUsU0FBUyxJQUFJLGtDQUFrQywyQkFBMkI7QUFBQSx3QkFFNUowRSxnQkFBTTFFO0FBQUFBO0FBQUFBLHNCQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsMkNBQ1gwRSxnQkFBTXhFLHlCQUF5QixRQUM5Qix1QkFBQyxVQUFLLFdBQVUsc0hBQ2J3RSxnQkFBTXhFLHdCQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUEsSUFFQSx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLG1DQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBLEtBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBO0FBQUE7QUFBQSxnQkF4REt6SjtBQUFBQSxnQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMERBO0FBQUEsWUFFSixLQS9ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdFQTtBQUFBLGVBMUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkZBLEtBNUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkZBO0FBQUEsYUFuUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFQQTtBQUFBLFFBR0hzSyxnQkFBZ0IsS0FDZix1QkFBQyxTQUFJLFdBQVUsNEhBQ2IsaUNBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDhHQUNaQSwyQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsdUNBQXNDLDhCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFNLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsZ0JBQ3ZCLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsU0FBUzFFO0FBQUFBLGdCQUFzQjtBQUFBO0FBQUEsY0FMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixTQUFTLE1BQU1mLHVCQUF1QixRQUFRO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBSGxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFlO0FBQUEsZ0JBQ3JCLFNBQVMsTUFBTUEsdUJBQXVCLFFBQVE7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixTQUFTLE1BQU1BLHVCQUF1QixRQUFRO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBSGxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsU0FBUyxNQUFNQSx1QkFBdUIsU0FBUztBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUhuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLFNBQVMsTUFBTUEsdUJBQXVCLGFBQWE7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FIdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThDQTtBQUFBLGFBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3REEsS0F6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBEQTtBQUFBLFFBR0Y7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE9BQU8sRUFBRXFKLFVBQVUsVUFBVTtBQUFBLFlBRTVCdFUseUJBQ0MsdUJBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQyxJQUM5Qm1MLG9CQUFvQnpILFdBQVcsSUFDakM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXO0FBQUEsZ0JBQ1gsU0FBUztBQUFBLGdCQUNULE1BQUs7QUFBQTtBQUFBLGNBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR3FCLElBR3JCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTWlOO0FBQUFBLGdCQUNOO0FBQUEsZ0JBQ0EsWUFBWWdEO0FBQUFBLGdCQUNaLGtCQUFpQjtBQUFBLGdCQUNqQixpQkFBZ0I7QUFBQSxnQkFDaEIsaUJBQWlCO0FBQUEsa0JBQ2Y7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGdCQUFpQjtBQUFBLGdCQUVuQixtQkFBbUI7QUFBQSxrQkFDakJuRixhQUFhRSxjQUFjNkYsU0FBUztBQUFBLGtCQUNwQyxLQUFLL0YsYUFBYVEsYUFBYXpCLGVBQWUsT0FBTyxDQUFDO0FBQUEsa0JBQ3REaUIsYUFBYUcsZ0JBQWdCNEYsU0FBUztBQUFBLGtCQUN0Qy9GLGFBQWFJLGVBQWUyRixTQUFTO0FBQUEsa0JBQ3JDL0YsYUFBYUssZUFBZTBGLFNBQVM7QUFBQSxnQkFBQztBQUFBO0FBQUEsY0FsQjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW1CSTtBQUFBO0FBQUEsVUFoQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUNBO0FBQUEsUUFFQzNULGlCQUFpQkUsV0FBV0YsaUJBQWlCSyxRQUM1QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsT0FBTztBQUFBLGNBQ0x1VCxVQUFVO0FBQUEsY0FDVnRCLFFBQVE7QUFBQSxjQUNSdUIsTUFBTSxHQUFHN1QsaUJBQWlCRyxDQUFDO0FBQUEsY0FDM0IyVCxLQUFLLEdBQUc5VCxpQkFBaUJJLENBQUM7QUFBQSxZQUM1QjtBQUFBLFlBQ0EsU0FBUyxDQUFDdVIsTUFBTUEsRUFBRUssZ0JBQWdCO0FBQUEsWUFFbEM7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsQ0FBQ0wsTUFBTTtBQUNkQSx3QkFBRUssZ0JBQWdCO0FBQ2xCblE7QUFBQUEsd0JBQ0VELGlCQUFpQjVCLGlCQUFpQkssS0FBS21ELE1BQ25DLE9BQ0F4RCxpQkFBaUJLLEtBQUttRDtBQUFBQSxzQkFDNUI7QUFBQSxvQkFDRjtBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWE7QUFBQSxzQkFDYix1QkFBQyxVQUFLLDZCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW1CO0FBQUEsc0JBQ25CLHVCQUFDLFVBQUssV0FBVSxtQkFBa0IsaUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW1DO0FBQUE7QUFBQTtBQUFBLGtCQWJyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBY0E7QUFBQSxnQkFDQzVCLGlCQUFpQjVCLGlCQUFpQkssS0FBS21ELE9BQ3RDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPLEVBQUU4TyxRQUFRLElBQU07QUFBQSxvQkFFdkI7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxTQUFTLENBQUNYLE1BQU07QUFDZEEsOEJBQUVLLGdCQUFnQjtBQUNsQjdPO0FBQUFBLDhCQUNFbkQsaUJBQWlCSyxLQUFLbUQ7QUFBQUEsOEJBQ3RCO0FBQUEsNEJBQ0Y7QUFDQXZELGdEQUFvQjtBQUFBLDhCQUNsQixHQUFHRDtBQUFBQSw4QkFDSEUsU0FBUztBQUFBLDRCQUNYLENBQUM7QUFBQSwwQkFDSDtBQUFBLDBCQUNBLFdBQVU7QUFBQSwwQkFFVjtBQUFBLG1EQUFDLHVCQUFvQixXQUFVLHFCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFnRDtBQUFBLDRCQUNoRCx1QkFBQyxVQUFLLHVCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWE7QUFBQTtBQUFBO0FBQUEsd0JBZmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWdCQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFNBQVMsQ0FBQ3lSLE1BQU07QUFDZEEsOEJBQUVLLGdCQUFnQjtBQUNsQjdPO0FBQUFBLDhCQUNFbkQsaUJBQWlCSyxLQUFLbUQ7QUFBQUEsOEJBQ3RCO0FBQUEsNEJBQ0Y7QUFDQXZELGdEQUFvQjtBQUFBLDhCQUNsQixHQUFHRDtBQUFBQSw4QkFDSEUsU0FBUztBQUFBLDRCQUNYLENBQUM7QUFBQSwwQkFDSDtBQUFBLDBCQUNBLFdBQVU7QUFBQSwwQkFFVjtBQUFBLG1EQUFDLHVCQUFvQixXQUFVLG9CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUErQztBQUFBLDRCQUMvQyx1QkFBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQVk7QUFBQTtBQUFBO0FBQUEsd0JBZmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWdCQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFNBQVMsQ0FBQ3lSLE1BQU07QUFDZEEsOEJBQUVLLGdCQUFnQjtBQUNsQjdPO0FBQUFBLDhCQUNFbkQsaUJBQWlCSyxLQUFLbUQ7QUFBQUEsOEJBQ3RCO0FBQUEsNEJBQ0Y7QUFDQXZELGdEQUFvQjtBQUFBLDhCQUNsQixHQUFHRDtBQUFBQSw4QkFDSEUsU0FBUztBQUFBLDRCQUNYLENBQUM7QUFBQSwwQkFDSDtBQUFBLDBCQUNBLFdBQVU7QUFBQSwwQkFFVjtBQUFBLG1EQUFDLGtCQUFlLFdBQVUscUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQTJDO0FBQUEsNEJBQzNDLHVCQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBWTtBQUFBO0FBQUE7QUFBQSx3QkFmZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBZ0JBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsU0FBUyxDQUFDeVIsTUFBTTtBQUNkQSw4QkFBRUssZ0JBQWdCO0FBQ2xCN087QUFBQUEsOEJBQ0VuRCxpQkFBaUJLLEtBQUttRDtBQUFBQSw4QkFDdEI7QUFBQSw0QkFDRjtBQUNBdkQsZ0RBQW9CO0FBQUEsOEJBQ2xCLEdBQUdEO0FBQUFBLDhCQUNIRSxTQUFTO0FBQUEsNEJBQ1gsQ0FBQztBQUFBLDBCQUNIO0FBQUEsMEJBQ0EsV0FBVTtBQUFBLDBCQUVWO0FBQUEsbURBQUMsaUJBQWMsV0FBVSxrQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBdUM7QUFBQSw0QkFDdkMsdUJBQUMsVUFBSyxzQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFZO0FBQUE7QUFBQTtBQUFBLHdCQWZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFnQkE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxTQUFTLENBQUN5UixNQUFNO0FBQ2RBLDhCQUFFSyxnQkFBZ0I7QUFDbEI3TztBQUFBQSw4QkFDRW5ELGlCQUFpQkssS0FBS21EO0FBQUFBLDhCQUN0QjtBQUFBLDRCQUNGO0FBQ0F2RCxnREFBb0I7QUFBQSw4QkFDbEIsR0FBR0Q7QUFBQUEsOEJBQ0hFLFNBQVM7QUFBQSw0QkFDWCxDQUFDO0FBQUEsMEJBQ0g7QUFBQSwwQkFDQSxXQUFVO0FBQUEsMEJBRVY7QUFBQSxtREFBQyxnQkFBYSxXQUFVLHFCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUF5QztBQUFBLDRCQUN6Qyx1QkFBQyxVQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWtCO0FBQUE7QUFBQTtBQUFBLHdCQWZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBZ0JBO0FBQUE7QUFBQTtBQUFBLGtCQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBeUZBO0FBQUEsbUJBMUdKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNEdBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLENBQUN5UixNQUFNO0FBQ2RBLHNCQUFFSyxnQkFBZ0I7QUFDbEJoTCx3Q0FBb0JoSCxpQkFBaUJLLElBQUk7QUFDekNKLHdDQUFvQixFQUFFLEdBQUdELGtCQUFrQkUsU0FBUyxNQUFNLENBQUM7QUFBQSxrQkFDN0Q7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFhO0FBQUEsb0JBQ2IsdUJBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFVO0FBQUE7QUFBQTtBQUFBLGdCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLENBQUN5UixNQUFNO0FBQ2RBLHNCQUFFSyxnQkFBZ0I7QUFDbEJ2SixnQ0FBWXpJLGlCQUFpQkssSUFBSTtBQUNqQ0osd0NBQW9CLEVBQUUsR0FBR0Qsa0JBQWtCRSxTQUFTLE1BQU0sQ0FBQztBQUFBLGtCQUM3RDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlCO0FBQUEsb0JBQ2pCLHVCQUFDLFVBQUsscUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBVztBQUFBO0FBQUE7QUFBQSxnQkFUYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FVQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxDQUFDeVIsTUFBTTtBQUNkQSxzQkFBRUssZ0JBQWdCO0FBQ2xCakcsZ0NBQVkvTCxpQkFBaUJLLElBQUk7QUFDakNKLHdDQUFvQixFQUFFLEdBQUdELGtCQUFrQkUsU0FBUyxNQUFNLENBQUM7QUFBQSxrQkFDN0Q7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQjtBQUFBLG9CQUNoQix1QkFBQyxVQUFLLHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQVc7QUFBQTtBQUFBO0FBQUEsZ0JBVGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsQ0FBQ3lSLE1BQU07QUFDZEEsc0JBQUVLLGdCQUFnQjtBQUNsQm5HLGtDQUFjN0wsaUJBQWlCSyxLQUFLbUQsR0FBRztBQUN2Q3ZELHdDQUFvQixFQUFFLEdBQUdELGtCQUFrQkUsU0FBUyxNQUFNLENBQUM7QUFBQSxrQkFDN0Q7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFlO0FBQUEsb0JBQ2YsdUJBQUMsVUFBSyxzQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFZO0FBQUE7QUFBQTtBQUFBLGdCQVRkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUE7QUFBQTtBQUFBLFVBbEtGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW1LQTtBQUFBLFFBR0Y7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVd2QztBQUFBQSxZQUNYLFNBQVNvTDtBQUFBQSxZQUVULGlDQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSx1Q0FDYixpQ0FBQyxRQUFHLFdBQVUseUVBQXdFLGdDQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGNBQ0EsdUJBQUMsUUFBSyxNQUFNakwsVUFBVSxRQUFPLFlBQVcsV0FBVSxRQUNoRDtBQUFBLHVDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLDhDQUE2QyxrQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSwrRkFDYjtBQUFBLDJDQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssZ0JBQWUsUUFBTSxNQUNuQyxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQU0sS0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FDQztBQUFBLDZDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsZ0NBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLG9CQUFtQixXQUFVLFFBQzNDO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDO0FBQUEsMEJBQ0EsV0FBVTtBQUFBO0FBQUEsd0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUV1RCxLQUh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEseUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsMENBQXlDLGtDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxhQUFZLFdBQVUsUUFDcEM7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0M7QUFBQSwwQkFDQSxXQUFVO0FBQUE7QUFBQSx3QkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRXVELEtBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBS0E7QUFBQSx5QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FDQztBQUFBLDZDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsK0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGtCQUFpQixXQUFVLFFBQ3pDO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDO0FBQUEsMEJBQ0EsV0FBVTtBQUFBO0FBQUEsd0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUV1RCxLQUh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEseUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsMENBQXlDLDZCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxnQkFBZSxXQUFVLFFBQ3ZDO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDO0FBQUEsMEJBQ0EsV0FBVTtBQUFBO0FBQUEsd0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUV1RCxLQUh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEseUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsMENBQXlDLDJCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxjQUFhLFdBQVUsUUFDckM7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0M7QUFBQSwwQkFDQSxXQUFVO0FBQUE7QUFBQSx3QkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRXVELEtBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBS0E7QUFBQSx5QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVVBO0FBQUEsdUJBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkRBO0FBQUEsa0JBQ0NVLFdBQVdzRSxTQUFTLElBQ25CLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsc0JBQ3RCO0FBQUEsc0JBQzdCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHNCQUFDLEtBQUs7QUFBQSxzQkFBTDtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxPQUFPLENBQUMsRUFBRWlSLFVBQVUsTUFBTW5aLFNBQVMsWUFBWSxDQUFDO0FBQUEsd0JBQ2hELFdBQVU7QUFBQSx3QkFFVjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxhQUFZO0FBQUEsNEJBQ1osVUFBVWtNO0FBQUFBLDRCQUNWLE9BQU9wSTtBQUFBQSw0QkFDUCxXQUFVO0FBQUEsNEJBQ1YsTUFBSztBQUFBLDRCQUVKRixxQkFBV2lHO0FBQUFBLDhCQUFJLENBQUNHLE9BQU9tQyxVQUN0Qix1QkFBQyxVQUFzQixPQUFPQSxPQUMzQm5DO0FBQUFBLHNDQUFNWTtBQUFBQSxnQ0FBVTtBQUFBLGdDQUFXWixNQUFNYztBQUFBQSxnQ0FBYTtBQUFBLG1DQURwQ2QsTUFBTXhCLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBRUE7QUFBQSw0QkFDRDtBQUFBO0FBQUEsMEJBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVlBO0FBQUE7QUFBQSxzQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQW9CQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLDZDQUFDLFNBQ0M7QUFBQSwrQ0FBQyxXQUFNLFdBQVUsMENBQXlDLGdDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxhQUFZLFdBQVUsUUFDcEM7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0M7QUFBQSw0QkFDQSxXQUFVO0FBQUE7QUFBQSwwQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRXlFLEtBSDNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBS0E7QUFBQSwyQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FDQztBQUFBLCtDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsOEJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLFdBQVUsV0FBVSxRQUNsQztBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQztBQUFBLDRCQUNBLFdBQVU7QUFBQTtBQUFBLDBCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFFeUUsS0FIM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBLDJCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBVUE7QUFBQSxzQkFDQSx1QkFBQyxTQUNDO0FBQUEsK0NBQUMsV0FBTSxXQUFVLDBDQUF5Qyw2QkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssZ0JBQWUsV0FBVSxRQUN2QztBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQztBQUFBLDRCQUNBLFdBQVU7QUFBQTtBQUFBLDBCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFFb0YsS0FIdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBLDJCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBVUE7QUFBQSxzQkFDQSx1QkFBQyxTQUNDO0FBQUEsK0NBQUMsV0FBTSxXQUFVLDBDQUF5Qyw2QkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssZ0JBQWUsV0FBVSxRQUN2QztBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQztBQUFBLDRCQUNBLFdBQVU7QUFBQTtBQUFBLDBCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFFNEQsS0FIOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBLDJCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBVUE7QUFBQSx5QkE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkE2Q0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsMEJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGFBQVksV0FBVSxRQUNwQztBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQztBQUFBLDBCQUNBLFdBQVU7QUFBQTtBQUFBLHdCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFFNEQsS0FIOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQTtBQUFBLHlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVUE7QUFBQSx1QkFsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtRkEsSUFFQSx1QkFBQyxTQUFJLFdBQVUscURBQ2IsaUNBQUMsUUFBSyxNQUFLLFdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0IsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQXhKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBKQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLDhDQUE2QywrQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDJDQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsMENBQXlDO0FBQUE7QUFBQSx3QkFDM0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBLDJCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQyxLQUFLO0FBQUEsd0JBQUw7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsT0FBTyxDQUFDLEVBQUUyUSxVQUFVLE1BQU1uWixTQUFTLFlBQVksQ0FBQztBQUFBLDBCQUNoRCxXQUFVO0FBQUEsMEJBRVY7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsT0FBTyxFQUFFa1ksT0FBTyxPQUFPO0FBQUEsOEJBQ3ZCLFdBQVU7QUFBQSw4QkFDVixRQUFPO0FBQUE7QUFBQSw0QkFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBR3FCO0FBQUE7QUFBQSx3QkFSdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVVBO0FBQUEseUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFlQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsMENBQXlDO0FBQUE7QUFBQSx3QkFDM0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBLDJCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQyxLQUFLO0FBQUEsd0JBQUw7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsT0FBTyxDQUFDLEVBQUVpQixVQUFVLE1BQU1uWixTQUFTLFlBQVksQ0FBQztBQUFBLDBCQUNoRCxXQUFVO0FBQUEsMEJBRVY7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsT0FBTyxFQUFFa1ksT0FBTyxPQUFPO0FBQUEsOEJBQ3ZCLFdBQVU7QUFBQSw4QkFDVixRQUFPO0FBQUEsOEJBQ1AsWUFBVTtBQUFBO0FBQUEsNEJBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUlZO0FBQUE7QUFBQSx3QkFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBV0E7QUFBQSx5QkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWdCQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsMENBQXlDLDRCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxlQUFjLFdBQVUsUUFDdEM7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsT0FBTyxFQUFFQSxPQUFPLE9BQU87QUFBQSwwQkFDdkIsV0FBVTtBQUFBLDBCQUNWLFFBQU87QUFBQTtBQUFBLHdCQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFHcUIsS0FKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFNQTtBQUFBLHlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBV0E7QUFBQSx1QkE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE4Q0E7QUFBQSxxQkFsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtREE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsdUNBQXNDLG9DQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyxzQkFBc0J0VCxtQkFBbUIsSUFBSSxtQkFBbUIsY0FBYztBQUFBLHNCQUV4RkEsOEJBQW9CLE9BQ2pCLEtBQUtBLGdCQUFnQm1OLGVBQWUsT0FBTyxDQUFDLEtBQzVDO0FBQUE7QUFBQSxvQkFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxxQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLGdCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssZ0JBQWUsUUFBTSxNQUNuQyxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQU0sS0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxXQUFVLFFBQU0sTUFDOUIsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFNLEtBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLDhDQUE2Qyw2QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU07QUFBQSx3QkFDTixXQUFXM0M7QUFBQUEsd0JBQ1gsUUFBTztBQUFBLHdCQUNQLFlBQVc7QUFBQSx3QkFFWDtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxNQUFLO0FBQUEsNEJBQ0w7QUFBQSw0QkFDQSxXQUFVO0FBQUEsNEJBQ1YsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFvQjtBQUFBLDRCQUMxQixVQUFVeEwsV0FBV3NFLFdBQVc7QUFBQSw0QkFDaEMsT0FBSztBQUFBO0FBQUE7QUFBQSwwQkFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBU0E7QUFBQTtBQUFBLHNCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFnQkE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sV0FBV21IO0FBQUFBLHdCQUNYLFFBQU87QUFBQSx3QkFDUCxZQUFXO0FBQUEsd0JBRVg7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsTUFBSztBQUFBLDRCQUNMO0FBQUEsNEJBQ0EsVUFBVXpMLFdBQVdzRSxXQUFXO0FBQUEsNEJBQ2hDLFdBQVU7QUFBQSw0QkFDVixNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQW9CO0FBQUEsNEJBQzFCLE9BQUs7QUFBQTtBQUFBO0FBQUEsMEJBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVNBO0FBQUE7QUFBQSxzQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBZ0JBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLFdBQVdzSDtBQUFBQSx3QkFDWCxRQUFPO0FBQUEsd0JBQ1AsWUFBVztBQUFBLHdCQUVYO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTDtBQUFBLDRCQUNBLFVBQVU1TCxXQUFXc0UsV0FBVztBQUFBLDRCQUNoQyxXQUFVO0FBQUEsNEJBQ1YsTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFlO0FBQUEsNEJBQ3JCLE9BQUs7QUFBQTtBQUFBO0FBQUEsMEJBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVNBO0FBQUE7QUFBQSxzQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBZ0JBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLFdBQVdvSDtBQUFBQSx3QkFDWCxRQUFPO0FBQUEsd0JBQ1AsWUFBVztBQUFBLHdCQUVYO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTDtBQUFBLDRCQUNBO0FBQUEsNEJBQ0EsV0FBVTtBQUFBLDRCQUNWLE1BQU0sdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBYztBQUFBLDRCQUNwQixVQUFVMUwsV0FBV3NFLFdBQVc7QUFBQSw0QkFDaEMsT0FBSztBQUFBO0FBQUE7QUFBQSwwQkFQUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBVUE7QUFBQTtBQUFBLHNCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBaUJBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLFdBQVdxSDtBQUFBQSx3QkFDWCxRQUFPO0FBQUEsd0JBQ1AsWUFBVztBQUFBLHdCQUVYO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTDtBQUFBLDRCQUNBO0FBQUEsNEJBQ0EsV0FBVTtBQUFBLDRCQUNWLE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBYTtBQUFBLDRCQUNuQixVQUFVM0wsV0FBV3NFLFdBQVc7QUFBQSw0QkFDaEMsT0FBSztBQUFBO0FBQUE7QUFBQSw4QkFHTCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBQUc7QUFBQSw4QkFBRztBQUFBO0FBQUE7QUFBQSwwQkFWUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBWUE7QUFBQTtBQUFBLHNCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBbUJBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsU0FBU2lHO0FBQUFBLHdCQUNULFdBQVU7QUFBQSx3QkFDVixPQUFLO0FBQUE7QUFBQTtBQUFBLHNCQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLHVCQWhHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlHQTtBQUFBLHFCQXJHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXNHQTtBQUFBLG1CQTFVRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJVQTtBQUFBLGlCQWpWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtWQTtBQUFBO0FBQUEsVUF0VkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBdVZBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU3ZIO0FBQUFBLFlBQ1QsVUFBVTZKO0FBQUFBLFlBQ1YsUUFBUTtBQUFBLFlBQ1I7QUFBQSxZQUNBLE9BQU87QUFBQSxZQUVQLGlDQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw0QkFDYixpQ0FBQyxTQUFJLFdBQVUsK0JBQ2IsaUNBQUMsNkJBQTBCLFdBQVUsMkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRELEtBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUseUNBQXdDLDZCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCO0FBQUE7QUFBQSxnQkFDVztBQUFBLGdCQUMzQyx1QkFBQyxVQUFLLFdBQVUsMkJBQ2J5RTtBQUFBQTtBQUFBQSxrQkFBYztBQUFBLHFCQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQU87QUFBQSxnQkFFUCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQUc7QUFBQSxnQkFBRztBQUFBLG1CQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTekU7QUFBQUEsb0JBQ1QsV0FBVTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFIbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxTQUFTM0o7QUFBQUEsb0JBQ1QsU0FBUzRKO0FBQUFBLG9CQUNULFdBQVU7QUFBQSxvQkFBc0M7QUFBQTtBQUFBLGtCQUxsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQ0E7QUFBQTtBQUFBLFVBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQTRDQTtBQUFBLFdBbnpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb3pDQTtBQUFBLFNBdHpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdXpDQTtBQUFBLE9BMXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMnpDQTtBQUVKO0FBQUNqTyxHQTEvRVFELFlBQVU7QUFBQSxVQUdZN0MsYUFBYW1ELGlCQUV2QnpELEtBQUs4RCxPQUFPO0FBQUE7QUFBQWlXLEtBTHhCNVc7QUE0L0VULGVBQWVBO0FBQVcsSUFBQTRXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJGb3JtIiwiSW5wdXQiLCJEYXRlUGlja2VyIiwiVGltZVBpY2tlciIsIkJ1dHRvbiIsIlNlbGVjdCIsIm5vdGlmaWNhdGlvbiIsIlBvcGNvbmZpcm0iLCJTcGluIiwiTW9kYWwiLCJSYWRpbyIsIm1lc3NhZ2UiLCJTd2l0Y2giLCJFZGl0T3V0bGluZWQiLCJEZWxldGVPdXRsaW5lZCIsIkNoZWNrQ2lyY2xlT3V0bGluZWQiLCJQcmludGVyT3V0bGluZWQiLCJEb3duT3V0bGluZWQiLCJVcE91dGxpbmVkIiwiQXBwc3RvcmVPdXRsaW5lZCIsIlVub3JkZXJlZExpc3RPdXRsaW5lZCIsIlN0b3BPdXRsaW5lZCIsIlNoYXJlQWx0T3V0bGluZWQiLCJDbG9zZU91dGxpbmVkIiwiQ2xvY2tDaXJjbGVPdXRsaW5lZCIsIkRvbGxhck91dGxpbmVkIiwiU2FmZXR5T3V0bGluZWQiLCJSaXNlT3V0bGluZWQiLCJXaGF0c0FwcE91dGxpbmVkIiwiRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCIsIlRyb3BoeU91dGxpbmVkIiwiU2VhcmNoT3V0bGluZWQiLCJGaWxlVGV4dE91dGxpbmVkIiwiU2lkZWJhciIsIk5hdmJhciIsIk1vZGFsQ29tcG9uZW50IiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJkYXlqcyIsIkFQSSIsImltYWdlIiwiT3B0aW9uIiwidXNlciIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyUm9sZSIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsInRpdGxlIiwiY2FuQWNjZXNzQmlkUmVxdWVzdCIsIkJpZFJlcXVlc3QiLCJfcyIsImlzU3VwZXJBZG1pbiIsInJvbGUiLCJhcGkiLCJjb250ZXh0SG9sZGVyIiwidXNlTm90aWZpY2F0aW9uIiwiaXNFZGl0TW9kYWxPcGVuIiwic2V0SXNFZGl0TW9kYWxPcGVuIiwidXNlU3RhdGUiLCJlZGl0Rm9ybSIsInVzZUZvcm0iLCJvcGVuQWN0aW9uSWQiLCJzZXRPcGVuQWN0aW9uSWQiLCJ1c2VycyIsInNldFVzZXJzIiwibG9hZGluZ1VzZXJzIiwic2V0TG9hZGluZ1VzZXJzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJlZGl0R3JvdXBzIiwic2V0RWRpdEdyb3VwcyIsInNlbGVjdGVkRWRpdEdyb3VwSW5kZXgiLCJzZXRTZWxlY3RlZEVkaXRHcm91cEluZGV4IiwiaXNHcm91cFN0YXRzT3BlbiIsInNldElzR3JvdXBTdGF0c09wZW4iLCJncm91cFZpZXdNb2RlIiwic2V0R3JvdXBWaWV3TW9kZSIsInZpZXdUeXBlIiwic2V0Vmlld1R5cGUiLCJyYXdCaWRSZXF1ZXN0cyIsInNldFJhd0JpZFJlcXVlc3RzIiwibG9hZGluZ1RhYmxlIiwic2V0TG9hZGluZ1RhYmxlIiwiZWRpdGluZ0lkIiwic2V0RWRpdGluZ0lkIiwiY3VzdG9tZXJCYWxhbmNlIiwic2V0Q3VzdG9tZXJCYWxhbmNlIiwibG9hZGluZ0JhbGFuY2UiLCJzZXRMb2FkaW5nQmFsYW5jZSIsInNob3dCYWxhbmNlIiwic2V0U2hvd0JhbGFuY2UiLCJwZXJtaXNzaW9ucyIsInNldFBlcm1pc3Npb25zIiwiZHJvcGRvd25Qb3NpdGlvbiIsInNldERyb3Bkb3duUG9zaXRpb24iLCJ2aXNpYmxlIiwieCIsInkiLCJpdGVtIiwic2VsZWN0ZWRTdGF0dXMiLCJzZXRTZWxlY3RlZFN0YXR1cyIsInNlbGVjdGVkR3JvdXBGaWx0ZXIiLCJzZXRTZWxlY3RlZEdyb3VwRmlsdGVyIiwic2VsZWN0ZWRQYXltZW50U3RhdHVzIiwic2V0U2VsZWN0ZWRQYXltZW50U3RhdHVzIiwiaW5wdXRGcm9tRGF0ZSIsInNldElucHV0RnJvbURhdGUiLCJpbnB1dFRvRGF0ZSIsInNldElucHV0VG9EYXRlIiwiYWN0aXZlRnJvbURhdGUiLCJzZXRBY3RpdmVGcm9tRGF0ZSIsImFjdGl2ZVRvRGF0ZSIsInNldEFjdGl2ZVRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJzZWxlY3RBbGwiLCJzZXRTZWxlY3RBbGwiLCJpc1ZlcmlmeU1vZGFsT3BlbiIsInNldElzVmVyaWZ5TW9kYWxPcGVuIiwiaXNTZW5kaW5nIiwic2V0SXNTZW5kaW5nIiwib3BlblN0YXR1c0lkIiwic2V0T3BlblN0YXR1c0lkIiwiZmV0Y2hQZXJtaXNzaW9ucyIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImFjY2Vzc19wZXJtaXNzaW9ucyIsImVycm9yIiwiY29uc29sZSIsImhhbmRsZU9wZW5DcmVhdGVQYWdlIiwid2luZG93Iiwib3BlbiIsImhhbmRsZUZvY3VzIiwiZmV0Y2hCaWRSZXF1ZXN0cyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiZmV0Y2hDdXN0b21lckJhbGFuY2UiLCJlbnJvbGxtZW50SWQiLCJsZW5ndGgiLCJiYWxhbmNlIiwiZmV0Y2hVc2VycyIsImZldGNoQXVjdGlvbkNvdW50IiwiZ3JvdXBJZCIsImhhbmRsZVNpbmdsZVN0YXR1c1VwZGF0ZSIsImlkIiwibmV3U3RhdHVzIiwiZmluZCIsInIiLCJfaWQiLCJwYXlsb2FkIiwic3RhdHVzIiwicHV0Iiwic3RhdHVzTWVzc2FnZXMiLCJQZW5kaW5nIiwiQWNjZXB0IiwiUmVqZWN0IiwiTmV4dEF1Y3Rpb24iLCJQcml6ZWQiLCJzdWNjZXNzIiwiZGVzY3JpcHRpb24iLCJmZXRjaEVkaXRDdXN0b21lckRldGFpbHMiLCJ1c2VySWQiLCJzZWxlY3RlZEVucm9sbG1lbnRJZCIsInBvc3QiLCJncm91cHNEYXRhUHJvbWlzZSIsIm1hcCIsImVucm9sbG1lbnQiLCJncm91cERhdGEiLCJncm91cCIsImF1Y3Rpb25zRG9uZSIsInJlZmVycmVkQnkiLCJhZ2VudCIsIm5hbWUiLCJwaG9uZV9udW1iZXIiLCJyZWZlcnJlZF9jdXN0b21lciIsImZ1bGxfbmFtZSIsInJlZmVycmVkX2xlYWQiLCJsZWFkX25hbWUiLCJhZ2VudF9udW1iZXIiLCJiaWRfcmVxdWVzdF9jb2RlIiwiZ3JvdXBOYW1lIiwiZ3JvdXBfbmFtZSIsInRpY2tldE51bWJlciIsInRpY2tldHMiLCJ0aWNrZXRfbnVtYmVyIiwic3RhcnREYXRlIiwic3RhcnRfZGF0ZSIsInNwbGl0IiwiZW5kRGF0ZSIsImVuZF9kYXRlIiwiZnVsbEVucm9sbG1lbnQiLCJncm91cHNEYXRhIiwiUHJvbWlzZSIsImFsbCIsImRlZmF1bHRJbmRleCIsImZvdW5kSW5kZXgiLCJmaW5kSW5kZXgiLCJnIiwic2VsZWN0ZWRHcm91cCIsInNldEZpZWxkc1ZhbHVlIiwic2VsZWN0ZWRHcm91cEluZGV4IiwidW5kZWZpbmVkIiwiaGFuZGxlRWRpdEdyb3VwU2VsZWN0IiwiaW5kZXgiLCJoYW5kbGVPcGVuRWRpdE1vZGFsIiwidXNlck9iaiIsInN1YnNjcmliZXJJZCIsIm5hbWVUb0Rpc3BsYXkiLCJzdWJzY3JpYmVyTmFtZSIsInVzZXJOYW1lIiwicGhvbmVUb0Rpc3BsYXkiLCJtb2JpbGUiLCJtb2JpbGVOdW1iZXIiLCJtb2JpbGVOdW1iZXJSYXciLCJjdXN0b21lcklkVG9EaXNwbGF5IiwiY3VzdG9tZXJfaWQiLCJhZG1pbk9iamVjdCIsImFkbWluVXNlckRldGFpbHMiLCJhZG1pbk5hbWUiLCJhZG1pblBob25lIiwiYWRtaW5EaXNwbGF5IiwicmVmZXJyZWRCeUZyb21UYWJsZSIsImN1c3RvbWVySWQiLCJhdWN0aW9uRGF0ZSIsImF1Y3Rpb25UaW1lIiwiYXVjdGlvbl90aW1lIiwicmVxdWVzdERhdGUiLCJjcmVhdGVkQXQiLCJhdWN0aW9ucyIsImhhbmRsZVNoYXJlIiwiYmlkUmVxdWVzdElkIiwiZnJvbnRlbmRVcmwiLCJsb2NhdGlvbiIsIm9yaWdpbiIsImZ1bGxVcmwiLCJoYW5kbGVDbG9zZUVkaXRNb2RhbCIsInJlc2V0RmllbGRzIiwidXBkYXRlU3RhdHVzIiwidmFsdWVzIiwidmFsaWRhdGVGaWVsZHMiLCJncm91cEluZGV4IiwiZm9ybWF0IiwicmVmZXJyZWRfYnkiLCJ1cGRhdGVkQnkiLCJ1IiwiZXJyb3JNZXNzYWdlIiwiZXJyb3JzIiwiT2JqZWN0IiwiZmxhdCIsImpvaW4iLCJlcnJvckZpZWxkcyIsImYiLCJoYW5kbGVTZXRQZW5kaW5nIiwiaGFuZGxlU2V0QWNjZXB0IiwiaGFuZGxlU2V0UmVqZWN0IiwiaGFuZGxlU2V0TmV4dGF1Y3Rpb24iLCJoYW5kbGVTZXRQcml6ZWQiLCJoYW5kbGVCdWxrU3RhdHVzVXBkYXRlIiwic2VsZWN0ZWRJdGVtcyIsImZpbHRlcmVkQmlkUmVxdWVzdHMiLCJmaWx0ZXIiLCJpbmZvIiwiY29uZmlybSIsImljb24iLCJjb250ZW50Iiwib2tUZXh0IiwiY2FuY2VsVGV4dCIsIm9uT2siLCJwcm9taXNlcyIsImVyciIsImhhbmRsZURhdGVTZWFyY2giLCJoYW5kbGVDbGVhckZpbHRlcnMiLCJoYW5kbGVPcGVuVmVyaWZ5TW9kYWwiLCJoYW5kbGVDbG9zZVZlcmlmeU1vZGFsIiwiaGFuZGxlU2VuZFdoYXRzQXBwIiwicmVjZWl2ZXJzIiwiZm9yRWFjaCIsImdyb3VwT2JqIiwibmV3QWN0aXZlRGF0YSIsImhhbmRsZURlbGV0ZSIsImRlbGV0ZSIsImNvbmZpcm1EZWxldGUiLCJva1R5cGUiLCJoYW5kbGVQcmludCIsInVzZXJQaG9uZSIsIkRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ5ZWFyIiwibW9udGgiLCJkYXkiLCJyZXBsYWNlIiwicHJpbnRXaW5kb3ciLCJnZW5lcmF0ZUZvcm0iLCJNYXRoIiwiYWJzIiwidG9Mb2NhbGVTdHJpbmciLCJkb2N1bWVudCIsIndyaXRlIiwiY2xvc2UiLCJmb2N1cyIsInRlbXBBY3RpdmUiLCJ1bmlxdWVHcm91cHMiLCJ1c2VNZW1vIiwiZ3JvdXBzIiwiZ3JvdXBPYmplY3QiLCJ2YWx1ZSIsInNlbGYiLCJpbmRleE9mIiwic3RhdHNCYXNlRGF0YSIsIml0ZW1EYXRlIiwiaXNCZWZvcmUiLCJpc0FmdGVyIiwic3VtbWFyeVN0YXRzIiwiZGF0YVRvQW5hbHl6ZSIsInRvdGFsUmVxdWVzdHMiLCJwZW5kaW5nUmVxdWVzdHMiLCJhY2NlcHRSZXF1ZXN0cyIsInJlamVjdFJlcXVlc3RzIiwibmV4dGF1Y3Rpb25SZXF1ZXN0cyIsInByaXplZFJlcXVlc3RzIiwidG90YWxCYWxhbmNlIiwicmVkdWNlIiwic3VtIiwidG90YWxBbW91bnRQYWlkIiwiYW1vdW50X3BhaWQiLCJncm91cFN0YXRzIiwidG90YWwiLCJwZW5kaW5nIiwiYWNjZXB0IiwibmV4dGF1Y3Rpb24iLCJyZWplY3QiLCJwcml6ZWQiLCJuZXh0X2F1Y3Rpb25fZGF0ZSIsIm5leHRfYXVjdGlvbl9kaXNwbGF5IiwibGFzdF9hdWN0aW9uX2RhdGUiLCJiaWRkaW5nX29wZW5fY291bnQiLCJ0b3RhbF9iYWxhbmNlIiwibmV4dERhdGUiLCJjdXJyZW50U3RvcmVkRGF0ZSIsIm5leHREYXRlT2JqIiwiaXNWYWxpZCIsImJpZF9zdGF0dXMiLCJwYXltZW50U3RhdHMiLCJjb3VudCIsImFtb3VudCIsInVwVG9EYXRlIiwic2VsZWN0ZWRDb3VudCIsImZvcm1hdHRlZEJpZERhdGEiLCJ1c2VyT2JqZWN0IiwiaW5zdGFuY2VCYWxhbmNlIiwiY3VycmVudEJhbGFuY2UiLCJhbW91bnRQYWlkIiwidG90YWxUb0JlUGFpZCIsInRvdGFsX3RvX2JlX3BhaWQiLCJjcmVhdGVkQnkiLCJhZG1pbk5hbWVGcm9tTG9va3VwIiwiYWRtaW5OYW1lU3RvcmVkIiwiYmlkUmVxdWVzdENvZGUiLCJpc1NlbGVjdGVkIiwicmVxdWVzdFNvdXJjZSIsInNvdXJjZSIsImF1Y3Rpb25EYXRlRGlzcGxheSIsImF1Y3Rpb25EYXRlUmF3Iiwia2V5IiwicGhvbmVOdW1iZXIiLCJkYXRlIiwiZW5hYmxlX2JpZF9yZXF1ZXN0IiwiZGF5c191bnRpbF9hdWN0aW9uIiwiaW5zdGFuY2VCYWxhbmNlVmFsdWVfcmF3IiwiaW5zdGFuY2VCYWxhbmNlVmFsdWUiLCJjdXJyZW50QmFsYW5jZVZhbHVlX3JhdyIsImN1cnJlbnRCYWxhbmNlVmFsdWUiLCJhbW91bnRQYWlkVmFsdWVfcmF3IiwiYW1vdW50UGFpZFZhbHVlIiwiY2hlY2tCb3giLCJlIiwicHJldiIsInRhcmdldCIsImNoZWNrZWQiLCJhY3Rpb24iLCJzdG9wUHJvcGFnYXRpb24iLCJyZWN0IiwiY3VycmVudFRhcmdldCIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsInJpZ2h0IiwiYm90dG9tIiwiekluZGV4IiwiYWxsQ2hlY2tlZCIsImV2ZXJ5IiwiaGFuZGxlQ2xpY2tPdXRzaWRlIiwiZXZlbnQiLCJjbG9zZXN0IiwiY29sdW1ucyIsImhlYWRlciIsIndpZHRoIiwiZXhjZWxjb2x1bW5zIiwiYmlkX3JlcXVlc3QiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInVwZGF0ZWQiLCJrZXlzIiwiZW50cmllcyIsInN0YXRzIiwib3ZlcmZsb3ciLCJ0b1N0cmluZyIsInBvc2l0aW9uIiwibGVmdCIsInRvcCIsInJlcXVpcmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQmlkUmVxdWVzdC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIEZvcm0sXHJcbiAgSW5wdXQsXHJcbiAgRGF0ZVBpY2tlcixcclxuICBUaW1lUGlja2VyLFxyXG4gIEJ1dHRvbixcclxuICBTZWxlY3QsXHJcbiAgbm90aWZpY2F0aW9uLFxyXG4gIFBvcGNvbmZpcm0sXHJcbiAgU3BpbixcclxuICBNb2RhbCxcclxuICBSYWRpbyxcclxuICBtZXNzYWdlLFxyXG4gIFN3aXRjaCxcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQge1xyXG4gIEVkaXRPdXRsaW5lZCxcclxuICBEZWxldGVPdXRsaW5lZCxcclxuICBDaGVja0NpcmNsZU91dGxpbmVkLFxyXG4gIFByaW50ZXJPdXRsaW5lZCxcclxuICBEb3duT3V0bGluZWQsXHJcbiAgVXBPdXRsaW5lZCxcclxuICBBcHBzdG9yZU91dGxpbmVkLFxyXG4gIFVub3JkZXJlZExpc3RPdXRsaW5lZCxcclxuICBTdG9wT3V0bGluZWQsXHJcbiAgU2hhcmVBbHRPdXRsaW5lZCxcclxuICBDbG9zZU91dGxpbmVkLFxyXG4gIENsb2NrQ2lyY2xlT3V0bGluZWQsXHJcbiAgRG9sbGFyT3V0bGluZWQsXHJcbiAgU2FmZXR5T3V0bGluZWQsXHJcbiAgUmlzZU91dGxpbmVkLFxyXG4gIFdoYXRzQXBwT3V0bGluZWQsXHJcbiAgRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCxcclxuICBUcm9waHlPdXRsaW5lZCxcclxuICBTZWFyY2hPdXRsaW5lZCxcclxuICBGaWxlVGV4dE91dGxpbmVkLFxyXG59IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgTW9kYWxDb21wb25lbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBpbWFnZSBmcm9tIFwiLi4vYXNzZXRzL2ltYWdlcy9sb2dvV0IucG5nXCI7XHJcblxyXG5jb25zdCB7IE9wdGlvbiB9ID0gU2VsZWN0O1xyXG5jb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIikgfHwgXCJ7fVwiKTtcclxuY29uc3QgdXNlclJvbGUgPSB1c2VyPy5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LnRpdGxlO1xyXG5jb25zdCBjYW5BY2Nlc3NCaWRSZXF1ZXN0ID0gdXNlclJvbGUgPT09IFwiU3VwZXIgQWRtaW5pc3RyYXRvclwiIHx8IHVzZXJSb2xlID09PSBcIkJyYW5jaCBNYW5hZ2VyXCI7XHJcblxyXG5mdW5jdGlvbiBCaWRSZXF1ZXN0KCkge1xyXG5cclxuICBjb25zdCBpc1N1cGVyQWRtaW4gPSB1c2VyPy5yb2xlID09PSBcIlNVUEVSX0FETUlOXCI7XHJcbiAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcbiAgY29uc3QgW2lzRWRpdE1vZGFsT3Blbiwgc2V0SXNFZGl0TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWRpdEZvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcbiAgY29uc3QgW29wZW5BY3Rpb25JZCwgc2V0T3BlbkFjdGlvbklkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nVXNlcnMsIHNldExvYWRpbmdVc2Vyc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0R3JvdXBzLCBzZXRFZGl0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRFZGl0R3JvdXBJbmRleCwgc2V0U2VsZWN0ZWRFZGl0R3JvdXBJbmRleF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbaXNHcm91cFN0YXRzT3Blbiwgc2V0SXNHcm91cFN0YXRzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2dyb3VwVmlld01vZGUsIHNldEdyb3VwVmlld01vZGVdID0gdXNlU3RhdGUoXCJncmlkXCIpO1xyXG4gIGNvbnN0IFt2aWV3VHlwZSwgc2V0Vmlld1R5cGVdID0gdXNlU3RhdGUoXCJ1cGNvbWluZ1wiKTtcclxuICBjb25zdCBbcmF3QmlkUmVxdWVzdHMsIHNldFJhd0JpZFJlcXVlc3RzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZ1RhYmxlLCBzZXRMb2FkaW5nVGFibGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0aW5nSWQsIHNldEVkaXRpbmdJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbY3VzdG9tZXJCYWxhbmNlLCBzZXRDdXN0b21lckJhbGFuY2VdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xvYWRpbmdCYWxhbmNlLCBzZXRMb2FkaW5nQmFsYW5jZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dCYWxhbmNlLCBzZXRTaG93QmFsYW5jZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG5cclxuICBjb25zdCBbcGVybWlzc2lvbnMsIHNldFBlcm1pc3Npb25zXSA9IHVzZVN0YXRlKHt9KTtcclxuXHJcbiAgY29uc3QgW2Ryb3Bkb3duUG9zaXRpb24sIHNldERyb3Bkb3duUG9zaXRpb25dID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJsZTogZmFsc2UsXHJcbiAgICB4OiAwLFxyXG4gICAgeTogMCxcclxuICAgIGl0ZW06IG51bGwsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtzZWxlY3RlZFN0YXR1cywgc2V0U2VsZWN0ZWRTdGF0dXNdID0gdXNlU3RhdGUoXCJhbGxcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBGaWx0ZXIsIHNldFNlbGVjdGVkR3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJhbGxcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGF5bWVudFN0YXR1cywgc2V0U2VsZWN0ZWRQYXltZW50U3RhdHVzXSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xyXG4gIGNvbnN0IFtpbnB1dEZyb21EYXRlLCBzZXRJbnB1dEZyb21EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpbnB1dFRvRGF0ZSwgc2V0SW5wdXRUb0RhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2FjdGl2ZUZyb21EYXRlLCBzZXRBY3RpdmVGcm9tRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbYWN0aXZlVG9EYXRlLCBzZXRBY3RpdmVUb0RhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNWZXJpZnlNb2RhbE9wZW4sIHNldElzVmVyaWZ5TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNTZW5kaW5nLCBzZXRJc1NlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtvcGVuU3RhdHVzSWQsIHNldE9wZW5TdGF0dXNJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUGVybWlzc2lvbnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL3VzZXIvZ2V0LXBlcm1pc3Npb25zXCIpO1xyXG4gICAgICAgIHNldFBlcm1pc3Npb25zKHJlc3BvbnNlLmRhdGEuYWNjZXNzX3Blcm1pc3Npb25zIHx8IHt9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHBlcm1pc3Npb25zOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0UGVybWlzc2lvbnMoe30pO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICBpZiAoaXNTdXBlckFkbWluKSB7XHJcbiAgICAgIGZldGNoUGVybWlzc2lvbnMoKTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZU9wZW5DcmVhdGVQYWdlID0gKCkgPT4ge1xyXG4gICAgd2luZG93Lm9wZW4oXCIvYmlkLXJlcXVlc3QvY3JlYXRlXCIsIFwiX2JsYW5rXCIsIFwibm9vcGVuZXIsbm9yZWZlcnJlclwiKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgaGFuZGxlRm9jdXMgPSAoKSA9PiB7XHJcbiAgICAgIGZldGNoQmlkUmVxdWVzdHMoKTtcclxuICAgIH07XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImZvY3VzXCIsIGhhbmRsZUZvY3VzKTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiZm9jdXNcIiwgaGFuZGxlRm9jdXMpO1xyXG4gICAgfTtcclxuICB9LCBbdmlld1R5cGVdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hDdXN0b21lckJhbGFuY2UgPSBhc3luYyAoZW5yb2xsbWVudElkKSA9PiB7XHJcbiAgICBpZiAoIWVucm9sbG1lbnRJZCkgcmV0dXJuO1xyXG4gICAgc2V0TG9hZGluZ0JhbGFuY2UodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXHJcbiAgICAgICAgYC9iaWQtcmVxdWVzdC9nZXQtYmFsYW5jZS8ke2Vucm9sbG1lbnRJZH1gLFxyXG4gICAgICApO1xyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YT8uZGF0YT8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNldEN1c3RvbWVyQmFsYW5jZShyZXNwb25zZS5kYXRhLmRhdGFbMF0uYmFsYW5jZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0Q3VzdG9tZXJCYWxhbmNlKDApO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRDdXN0b21lckJhbGFuY2UoMCk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nQmFsYW5jZShmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmdVc2Vycyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEgfHwgW10pO1xyXG4gICAgICBzZXRMb2FkaW5nVXNlcnMoZmFsc2UpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0TG9hZGluZ1VzZXJzKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEF1Y3Rpb25Db3VudCA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBpZiAoIWdyb3VwSWQpIHJldHVybiAwO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KGAvYXVjdGlvbi9nZXQtZ3JvdXAtYXVjdGlvbi8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLmxlbmd0aDtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiAwO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNpbmdsZVN0YXR1c1VwZGF0ZSA9IGFzeW5jIChpZCwgbmV3U3RhdHVzKSA9PiB7XHJcbiAgICBzZXRPcGVuU3RhdHVzSWQobnVsbCk7XHJcbiAgICBzZXRPcGVuQWN0aW9uSWQobnVsbCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCBpdGVtID0gcmF3QmlkUmVxdWVzdHMuZmluZCgocikgPT4gci5faWQgPT09IGlkKTtcclxuICAgICAgaWYgKCFpdGVtKSByZXR1cm47XHJcblxyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIHN0YXR1czogbmV3U3RhdHVzLFxyXG4gICAgICAgIGVucm9sbG1lbnRJZDogaXRlbS5lbnJvbGxtZW50SWQ/Ll9pZCB8fCBpdGVtLmVucm9sbG1lbnRJZCxcclxuICAgICAgICBncm91cElkOiBpdGVtLmdyb3VwSWQ/Ll9pZCB8fCBpdGVtLmdyb3VwSWQsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhd2FpdCBBUEkucHV0KGAvYmlkLXJlcXVlc3QvdXBkYXRlLyR7aWR9YCwgcGF5bG9hZCk7XHJcblxyXG4gICAgICBjb25zdCBzdGF0dXNNZXNzYWdlcyA9IHtcclxuICAgICAgICBQZW5kaW5nOiBcIlN0YXR1cyB1cGRhdGVkIHRvIFBlbmRpbmdcIixcclxuICAgICAgICBBY2NlcHQ6IFwiQmlkIFJlcXVlc3QgYWNjZXB0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgUmVqZWN0OiBcIkJpZCBSZXF1ZXN0IHJlamVjdCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICBOZXh0QXVjdGlvbjogXCJQb3N0ZWQgdG8gTmV4dCBBdWN0aW9uIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIFByaXplZDogXCJCaWQgUmVxdWVzdCBtYXJrZWQgYXMgUHJpemVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgYXBpLnN1Y2Nlc3Moe1xyXG4gICAgICAgIG1lc3NhZ2U6IFwiU3VjY2Vzc1wiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOlxyXG4gICAgICAgICAgc3RhdHVzTWVzc2FnZXNbbmV3U3RhdHVzXSB8fCBgU3RhdHVzIHVwZGF0ZWQgdG8gJHtuZXdTdGF0dXN9YCxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBmZXRjaEJpZFJlcXVlc3RzKCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiU3RhdHVzIHVwZGF0ZSBlcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgICBhcGkuZXJyb3Ioe1xyXG4gICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gdXBkYXRlIHN0YXR1c1wiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoRWRpdEN1c3RvbWVyRGV0YWlscyA9IGFzeW5jIChcclxuICAgIHVzZXJJZCxcclxuICAgIHNlbGVjdGVkRW5yb2xsbWVudElkID0gbnVsbCxcclxuICApID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLnBvc3QoXHJcbiAgICAgICAgYC9lbnJvbGwvZ2V0LXVzZXItdGlja2V0cy1yZXBvcnQvJHt1c2VySWR9YCxcclxuICAgICAgKTtcclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBzRGF0YVByb21pc2UgPSByZXNwb25zZS5kYXRhLm1hcChhc3luYyAoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgZW5yb2xsbWVudCA9IGl0ZW0/LmVucm9sbG1lbnQ7XHJcbiAgICAgICAgICBjb25zdCBncm91cERhdGEgPSBlbnJvbGxtZW50Py5ncm91cDtcclxuICAgICAgICAgIGNvbnN0IGdyb3VwSWQgPSBncm91cERhdGE/Ll9pZDtcclxuICAgICAgICAgIGNvbnN0IGF1Y3Rpb25zRG9uZSA9IGF3YWl0IGZldGNoQXVjdGlvbkNvdW50KGdyb3VwSWQpO1xyXG4gICAgICAgICAgY29uc3QgcmVmZXJyZWRCeSA9XHJcbiAgICAgICAgICAgIGdyb3VwRGF0YT8uYWdlbnQ/Lm5hbWUgJiYgZ3JvdXBEYXRhPy5hZ2VudD8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgPyBgJHtncm91cERhdGEuYWdlbnQubmFtZX0gfCAke2dyb3VwRGF0YS5hZ2VudC5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgIDogZ3JvdXBEYXRhPy5yZWZlcnJlZF9jdXN0b21lcj8uZnVsbF9uYW1lICYmXHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwRGF0YT8ucmVmZXJyZWRfY3VzdG9tZXI/LnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgICAgPyBgJHtncm91cERhdGEucmVmZXJyZWRfY3VzdG9tZXIuZnVsbF9uYW1lfSB8ICR7Z3JvdXBEYXRhLnJlZmVycmVkX2N1c3RvbWVyLnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICA6IGdyb3VwRGF0YT8ucmVmZXJyZWRfbGVhZD8ubGVhZF9uYW1lICYmXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBEYXRhPy5yZWZlcnJlZF9sZWFkPy5hZ2VudF9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgPyBgJHtncm91cERhdGEucmVmZXJyZWRfbGVhZC5sZWFkX25hbWV9IHwgJHtncm91cERhdGEucmVmZXJyZWRfbGVhZC5hZ2VudF9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgICAgICA6IFwiTi9BXCI7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgaWQ6IGdyb3VwSWQsXHJcbiAgICAgICAgICAgIGJpZF9yZXF1ZXN0X2NvZGU6IGdyb3VwRGF0YT8uYmlkX3JlcXVlc3RfY29kZSxcclxuICAgICAgICAgICAgZ3JvdXBOYW1lOiBncm91cERhdGE/Lmdyb3VwX25hbWUgfHwgXCJObyBHcm91cCBOYW1lXCIsXHJcbiAgICAgICAgICAgIHRpY2tldE51bWJlcjpcclxuICAgICAgICAgICAgICBlbnJvbGxtZW50Py50aWNrZXRzIHx8IGVucm9sbG1lbnQ/LnRpY2tldF9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgc3RhcnREYXRlOiBncm91cERhdGE/LnN0YXJ0X2RhdGVcclxuICAgICAgICAgICAgICA/IGdyb3VwRGF0YS5zdGFydF9kYXRlLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgIDogXCJOL0FcIixcclxuICAgICAgICAgICAgZW5kRGF0ZTogZ3JvdXBEYXRhPy5lbmRfZGF0ZVxyXG4gICAgICAgICAgICAgID8gZ3JvdXBEYXRhLmVuZF9kYXRlLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgIDogXCJOL0FcIixcclxuICAgICAgICAgICAgYXVjdGlvbnNEb25lOiBhdWN0aW9uc0RvbmUsXHJcbiAgICAgICAgICAgIGZ1bGxFbnJvbGxtZW50OiBlbnJvbGxtZW50LFxyXG4gICAgICAgICAgICBlbnJvbGxtZW50SWQ6IGVucm9sbG1lbnQ/Ll9pZCxcclxuICAgICAgICAgICAgcmVmZXJyZWRCeTogcmVmZXJyZWRCeSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGdyb3Vwc0RhdGEgPSBhd2FpdCBQcm9taXNlLmFsbChncm91cHNEYXRhUHJvbWlzZSk7XHJcbiAgICAgICAgc2V0RWRpdEdyb3Vwcyhncm91cHNEYXRhKTtcclxuXHJcbiAgICAgICAgaWYgKGdyb3Vwc0RhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgbGV0IGRlZmF1bHRJbmRleCA9IDA7XHJcbiAgICAgICAgICBpZiAoc2VsZWN0ZWRFbnJvbGxtZW50SWQpIHtcclxuICAgICAgICAgICAgY29uc3QgZm91bmRJbmRleCA9IGdyb3Vwc0RhdGEuZmluZEluZGV4KFxyXG4gICAgICAgICAgICAgIChnKSA9PiBnLmVucm9sbG1lbnRJZCA9PT0gc2VsZWN0ZWRFbnJvbGxtZW50SWQsXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGlmIChmb3VuZEluZGV4ICE9PSAtMSkge1xyXG4gICAgICAgICAgICAgIGRlZmF1bHRJbmRleCA9IGZvdW5kSW5kZXg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHNldFNlbGVjdGVkRWRpdEdyb3VwSW5kZXgoZGVmYXVsdEluZGV4KTtcclxuICAgICAgICAgIGNvbnN0IHNlbGVjdGVkR3JvdXAgPSBncm91cHNEYXRhW2RlZmF1bHRJbmRleF07XHJcbiAgICAgICAgICBlZGl0Rm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbiAgICAgICAgICAgIGdyb3VwTmFtZTogc2VsZWN0ZWRHcm91cC5ncm91cE5hbWUsXHJcbiAgICAgICAgICAgIHRpY2tldE51bWJlcjogc2VsZWN0ZWRHcm91cC50aWNrZXROdW1iZXIsXHJcbiAgICAgICAgICAgIHNlbGVjdGVkR3JvdXBJbmRleDogZGVmYXVsdEluZGV4LFxyXG4gICAgICAgICAgICBzdGFydERhdGU6IHNlbGVjdGVkR3JvdXAuc3RhcnREYXRlLFxyXG4gICAgICAgICAgICBlbmREYXRlOiBzZWxlY3RlZEdyb3VwLmVuZERhdGUsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25zRG9uZTogc2VsZWN0ZWRHcm91cC5hdWN0aW9uc0RvbmUsXHJcbiAgICAgICAgICAgIHJlZmVycmVkQnk6IHNlbGVjdGVkR3JvdXAucmVmZXJyZWRCeSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRFZGl0R3JvdXBzKFtdKTtcclxuICAgICAgICBlZGl0Rm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbiAgICAgICAgICBncm91cE5hbWU6IFwiTm8gR3JvdXBzIEZvdW5kXCIsXHJcbiAgICAgICAgICB0aWNrZXROdW1iZXI6IFwiTi9BXCIsXHJcbiAgICAgICAgICBzZWxlY3RlZEdyb3VwSW5kZXg6IHVuZGVmaW5lZCxcclxuICAgICAgICAgIHJlZmVycmVkQnk6IFwiTi9BXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjdXN0b21lciBkZXRhaWxzOlwiLCBlcnJvcik7XHJcbiAgICAgIGFwaS5lcnJvcih7XHJcbiAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkZhaWxlZCB0byBmZXRjaCBjdXN0b21lciBncm91cCBkZXRhaWxzLlwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFZGl0R3JvdXBTZWxlY3QgPSBhc3luYyAoaW5kZXgpID0+IHtcclxuICAgIHNldFNlbGVjdGVkRWRpdEdyb3VwSW5kZXgoaW5kZXgpO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGVkaXRHcm91cHNbaW5kZXhdO1xyXG4gICAgaWYgKHNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgZWRpdEZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4gICAgICAgIGdyb3VwTmFtZTogc2VsZWN0ZWRHcm91cC5ncm91cE5hbWUsXHJcbiAgICAgICAgdGlja2V0TnVtYmVyOiBzZWxlY3RlZEdyb3VwLnRpY2tldE51bWJlcixcclxuICAgICAgICBzZWxlY3RlZEdyb3VwSW5kZXg6IGluZGV4LFxyXG4gICAgICAgIHN0YXJ0RGF0ZTogc2VsZWN0ZWRHcm91cC5zdGFydERhdGUsXHJcbiAgICAgICAgZW5kRGF0ZTogc2VsZWN0ZWRHcm91cC5lbmREYXRlLFxyXG4gICAgICAgIGF1Y3Rpb25zRG9uZTogc2VsZWN0ZWRHcm91cC5hdWN0aW9uc0RvbmUsXHJcbiAgICAgICAgcmVmZXJyZWRCeTogc2VsZWN0ZWRHcm91cC5yZWZlcnJlZEJ5LFxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgZmV0Y2hDdXN0b21lckJhbGFuY2Uoc2VsZWN0ZWRHcm91cC5lbnJvbGxtZW50SWQpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU9wZW5FZGl0TW9kYWwgPSBhc3luYyAoaXRlbSkgPT4ge1xyXG4gICAgc2V0T3BlbkFjdGlvbklkKG51bGwpO1xyXG4gICAgc2V0RHJvcGRvd25Qb3NpdGlvbih7IC4uLmRyb3Bkb3duUG9zaXRpb24sIHZpc2libGU6IGZhbHNlIH0pO1xyXG4gICAgc2V0RWRpdGluZ0lkKGl0ZW0uX2lkKTtcclxuICAgIHNldFNob3dCYWxhbmNlKHRydWUpO1xyXG4gICAgc2V0SXNFZGl0TW9kYWxPcGVuKHRydWUpO1xyXG5cclxuICAgIGNvbnN0IHVzZXJPYmogPVxyXG4gICAgICB0eXBlb2YgaXRlbS5zdWJzY3JpYmVySWQgPT09IFwib2JqZWN0XCIgPyBpdGVtLnN1YnNjcmliZXJJZCA6IHt9O1xyXG4gICAgY29uc3QgdXNlcklkID0gdXNlck9iai5faWQgfHwgaXRlbS5zdWJzY3JpYmVySWQ7XHJcbiAgICBjb25zdCBuYW1lVG9EaXNwbGF5ID1cclxuICAgICAgdXNlck9iai5mdWxsX25hbWUgfHxcclxuICAgICAgdXNlck9iai5uYW1lIHx8XHJcbiAgICAgIGl0ZW0uc3Vic2NyaWJlck5hbWUgfHxcclxuICAgICAgaXRlbS51c2VyTmFtZSB8fFxyXG4gICAgICBcIlwiO1xyXG4gICAgY29uc3QgcGhvbmVUb0Rpc3BsYXkgPVxyXG4gICAgICB1c2VyT2JqLnBob25lX251bWJlciB8fFxyXG4gICAgICB1c2VyT2JqLm1vYmlsZSB8fFxyXG4gICAgICBpdGVtLm1vYmlsZU51bWJlciB8fFxyXG4gICAgICBpdGVtLm1vYmlsZU51bWJlclJhdyB8fFxyXG4gICAgICBcIlwiO1xyXG4gICAgY29uc3QgY3VzdG9tZXJJZFRvRGlzcGxheSA9XHJcbiAgICAgIHR5cGVvZiB1c2VyT2JqID09PSBcIm9iamVjdFwiID8gdXNlck9iai5jdXN0b21lcl9pZCB8fCBcIk4vQVwiIDogXCJOL0FcIjtcclxuXHJcbiAgICBjb25zdCBhZG1pbk9iamVjdCA9IGl0ZW0uYWRtaW5Vc2VyRGV0YWlscyB8fCB7fTtcclxuICAgIGNvbnN0IGFkbWluTmFtZSA9XHJcbiAgICAgIGFkbWluT2JqZWN0Lm5hbWUgfHwgYWRtaW5PYmplY3QuZnVsbF9uYW1lIHx8IGl0ZW0uYWRtaW5OYW1lIHx8IFwiTi9BXCI7XHJcbiAgICBjb25zdCBhZG1pblBob25lID0gaXRlbS5hZG1pblBob25lIHx8IFwiTi9BXCI7XHJcbiAgICBjb25zdCBhZG1pbkRpc3BsYXkgPVxyXG4gICAgICBhZG1pbk5hbWUgIT09IFwiTi9BXCJcclxuICAgICAgICA/IGFkbWluTmFtZVxyXG4gICAgICAgIDogYWRtaW5QaG9uZSAhPT0gXCJOL0FcIlxyXG4gICAgICAgICAgPyBgTW9iaWxlOiAke2FkbWluUGhvbmV9YFxyXG4gICAgICAgICAgOiBcIk4vQVwiO1xyXG5cclxuICAgIGNvbnN0IHJlZmVycmVkQnlGcm9tVGFibGUgPVxyXG4gICAgICBpdGVtPy5hZ2VudD8ubmFtZSAmJiBpdGVtPy5hZ2VudD8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgPyBgJHtpdGVtLmFnZW50Lm5hbWV9IHwgJHtpdGVtLmFnZW50LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgOiBpdGVtPy5yZWZlcnJlZF9jdXN0b21lcj8uZnVsbF9uYW1lICYmXHJcbiAgICAgICAgICAgIGl0ZW0/LnJlZmVycmVkX2N1c3RvbWVyPy5waG9uZV9udW1iZXJcclxuICAgICAgICAgID8gYCR7aXRlbS5yZWZlcnJlZF9jdXN0b21lci5mdWxsX25hbWV9IHwgJHtpdGVtLnJlZmVycmVkX2N1c3RvbWVyLnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICA6IGl0ZW0/LnJlZmVycmVkX2xlYWQ/LmxlYWRfbmFtZSAmJiBpdGVtPy5yZWZlcnJlZF9sZWFkPy5hZ2VudF9udW1iZXJcclxuICAgICAgICAgICAgPyBgJHtpdGVtLnJlZmVycmVkX2xlYWQubGVhZF9uYW1lfSB8ICR7aXRlbS5yZWZlcnJlZF9sZWFkLmFnZW50X251bWJlcn1gXHJcbiAgICAgICAgICAgIDogaXRlbS5yZWZlcnJlZEJ5IHx8IFwiTi9BXCI7XHJcblxyXG4gICAgZWRpdEZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4gICAgICBzdWJzY3JpYmVySWQ6IHVzZXJJZCxcclxuICAgICAgc3Vic2NyaWJlck5hbWU6IG5hbWVUb0Rpc3BsYXksXHJcbiAgICAgIG1vYmlsZU51bWJlcjogcGhvbmVUb0Rpc3BsYXksXHJcbiAgICAgIGN1c3RvbWVySWQ6IGN1c3RvbWVySWRUb0Rpc3BsYXksXHJcbiAgICAgIGJpZF9yZXF1ZXN0X2NvZGU6IGl0ZW0uYmlkX3JlcXVlc3RfY29kZSB8fCBcIi1cIixcclxuICAgICAgYWRtaW5OYW1lOiBhZG1pbkRpc3BsYXksXHJcbiAgICAgIGF1Y3Rpb25EYXRlOiBpdGVtLmF1Y3Rpb25EYXRlID8gZGF5anMoaXRlbS5hdWN0aW9uRGF0ZSkgOiBudWxsLFxyXG4gICAgICBhdWN0aW9uVGltZTogaXRlbS5hdWN0aW9uX3RpbWUgPyBkYXlqcyhpdGVtLmF1Y3Rpb25fdGltZSwgXCJISDptbVwiKSA6IG51bGwsXHJcbiAgICAgIHJlZmVycmVkQnk6IHJlZmVycmVkQnlGcm9tVGFibGUsXHJcbiAgICAgIHJlcXVlc3REYXRlOiBpdGVtLmNyZWF0ZWRBdCA/IGRheWpzKGl0ZW0uY3JlYXRlZEF0KSA6IGRheWpzKCksXHJcbiAgICAgIGdyb3VwTmFtZTogaXRlbS5ncm91cE5hbWUsXHJcbiAgICAgIHRpY2tldE51bWJlcjogaXRlbS50aWNrZXROdW1iZXIsXHJcbiAgICAgIGVucm9sbG1lbnRJZDogaXRlbS5lbnJvbGxtZW50SWQsXHJcbiAgICAgIGdyb3VwSWQ6IGl0ZW0uZ3JvdXBJZD8uX2lkIHx8IGl0ZW0uZ3JvdXBJZCB8fCBpdGVtLmdyb3VwSWQ/LmlkLFxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0Q3VzdG9tZXJCYWxhbmNlKGl0ZW0uYXVjdGlvbnM/LmJhbGFuY2UgfHwgMCk7XHJcblxyXG4gICAgaWYgKHVzZXJzLmxlbmd0aCA9PT0gMCkgYXdhaXQgZmV0Y2hVc2VycygpO1xyXG4gICAgYXdhaXQgZmV0Y2hFZGl0Q3VzdG9tZXJEZXRhaWxzKHVzZXJJZCwgaXRlbS5lbnJvbGxtZW50SWQpO1xyXG5cclxuICAgIGlmIChpdGVtLmVucm9sbG1lbnRJZCkge1xyXG4gICAgICBhd2FpdCBmZXRjaEN1c3RvbWVyQmFsYW5jZShpdGVtLmVucm9sbG1lbnRJZCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2hhcmUgPSBhc3luYyAoaXRlbSkgPT4ge1xyXG4gICAgc2V0T3BlbkFjdGlvbklkKG51bGwpO1xyXG4gICAgc2V0RHJvcGRvd25Qb3NpdGlvbih7IC4uLmRyb3Bkb3duUG9zaXRpb24sIHZpc2libGU6IGZhbHNlIH0pO1xyXG4gICAgY29uc3QgYmlkUmVxdWVzdElkID0gaXRlbS5faWQ7XHJcbiAgICBpZiAoIWJpZFJlcXVlc3RJZCkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiTm8gYmlkIHJlcXVlc3QgSUQgZm91bmRcIik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJVbmFibGUgdG8gc2hhcmU6IFJlcXVlc3QgaW5mb3JtYXRpb24gbm90IGZvdW5kXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBjb25zdCBmcm9udGVuZFVybCA9IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW47XHJcbiAgICBjb25zdCBmdWxsVXJsID0gYCR7ZnJvbnRlbmRVcmx9L2JpZC1yZXF1ZXN0L3NoYXJlLyR7YmlkUmVxdWVzdElkfWA7XHJcbiAgICB3aW5kb3cub3BlbihmdWxsVXJsLCBcIl9ibGFua1wiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDbG9zZUVkaXRNb2RhbCA9ICgpID0+IHtcclxuICAgIHNldElzRWRpdE1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICBlZGl0Rm9ybS5yZXNldEZpZWxkcygpO1xyXG4gICAgc2V0RWRpdEdyb3VwcyhbXSk7XHJcbiAgICBzZXRDdXN0b21lckJhbGFuY2UobnVsbCk7XHJcbiAgICBzZXRTaG93QmFsYW5jZShmYWxzZSk7XHJcbiAgICBzZXRFZGl0aW5nSWQobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdXBkYXRlU3RhdHVzID0gYXN5bmMgKG5ld1N0YXR1cykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgdmFsdWVzID0gYXdhaXQgZWRpdEZvcm0udmFsaWRhdGVGaWVsZHMoKTtcclxuICAgICAgY29uc3QgZ3JvdXBJbmRleCA9IHZhbHVlcy5zZWxlY3RlZEdyb3VwSW5kZXggPz8gc2VsZWN0ZWRFZGl0R3JvdXBJbmRleDtcclxuICAgICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGVkaXRHcm91cHNbZ3JvdXBJbmRleF07XHJcblxyXG4gICAgICBpZiAoIXNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgICBhcGkuZXJyb3Ioe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiR3JvdXAgZGV0YWlscyBub3QgZm91bmQuIFBsZWFzZSBzZWxlY3QgYSB2YWxpZCBncm91cC5cIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IGF1Y3Rpb25EYXRlID0gdmFsdWVzLmF1Y3Rpb25EYXRlPy5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xyXG4gICAgICBjb25zdCBhdWN0aW9uVGltZSA9IHZhbHVlcy5hdWN0aW9uVGltZT8uZm9ybWF0KFwiSEg6bW1cIik7XHJcbiAgICAgIGNvbnN0IHJlcXVlc3REYXRlID0gdmFsdWVzLnJlcXVlc3REYXRlPy5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xyXG5cclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICBzdWJzY3JpYmVySWQ6IHZhbHVlcy5zdWJzY3JpYmVySWQsXHJcbiAgICAgICAgc3Vic2NyaWJlck5hbWU6IHZhbHVlcy5zdWJzY3JpYmVyTmFtZSxcclxuICAgICAgICBtb2JpbGVOdW1iZXI6IHZhbHVlcy5tb2JpbGVOdW1iZXIsXHJcbiAgICAgICAgY3VzdG9tZXJJZDogdmFsdWVzLmN1c3RvbWVySWQsXHJcbiAgICAgICAgZ3JvdXBOYW1lOiBzZWxlY3RlZEdyb3VwLmdyb3VwTmFtZSxcclxuICAgICAgICB0aWNrZXROdW1iZXI6IHNlbGVjdGVkR3JvdXAudGlja2V0TnVtYmVyLFxyXG4gICAgICAgIGF1Y3Rpb25EYXRlOiBhdWN0aW9uRGF0ZSxcclxuICAgICAgICBhdWN0aW9uX3RpbWU6IGF1Y3Rpb25UaW1lLFxyXG4gICAgICAgIGF1Y3Rpb25UaW1lOiBhdWN0aW9uVGltZSxcclxuICAgICAgICByZWZlcnJlZEJ5OiB2YWx1ZXMucmVmZXJyZWRCeSxcclxuICAgICAgICByZWZlcnJlZF9ieTogdmFsdWVzLnJlZmVycmVkQnksXHJcbiAgICAgICAgZ3JvdXBJZDogc2VsZWN0ZWRHcm91cC5pZCxcclxuICAgICAgICBlbnJvbGxtZW50SWQ6IHNlbGVjdGVkR3JvdXAuZW5yb2xsbWVudElkLFxyXG4gICAgICAgIHN0YXR1czogbmV3U3RhdHVzLFxyXG4gICAgICAgIHJlcXVlc3REYXRlOiByZXF1ZXN0RGF0ZSxcclxuICAgICAgICB1cGRhdGVkQnk6IHVzZXJzLmZpbmQoKHUpID0+IHUuX2lkID09PSB2YWx1ZXMuc3Vic2NyaWJlcklkKT8uX2lkLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgYXdhaXQgQVBJLnB1dChgL2JpZC1yZXF1ZXN0L3VwZGF0ZS8ke2VkaXRpbmdJZH1gLCBwYXlsb2FkKTtcclxuXHJcbiAgICAgIGNvbnN0IHN0YXR1c01lc3NhZ2VzID0ge1xyXG4gICAgICAgIFBlbmRpbmc6IFwiQmlkIFJlcXVlc3QgbW92ZWQgdG8gUGVuZGluZyBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICBBY2NlcHQ6IFwiQmlkIFJlcXVlc3QgYWNjZXB0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgUmVqZWN0OiBcIkJpZCBSZXF1ZXN0IFJlamVjdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIE5leHRBdWN0aW9uOiBcIlBvc3QgdG8gTmV4dCBBdWN0aW9uIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIFByaXplZDogXCJCaWQgUmVxdWVzdCBtYXJrZWQgYXMgUHJpemVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgYXBpLnN1Y2Nlc3Moe1xyXG4gICAgICAgIG1lc3NhZ2U6IFwiU3RhdHVzIFVwZGF0ZWRcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjpcclxuICAgICAgICAgIHN0YXR1c01lc3NhZ2VzW25ld1N0YXR1c10gfHwgYFN0YXR1cyB1cGRhdGVkIHRvICR7bmV3U3RhdHVzfWAsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgaGFuZGxlQ2xvc2VFZGl0TW9kYWwoKTtcclxuICAgICAgZmV0Y2hCaWRSZXF1ZXN0cygpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIuKdjCBVcGRhdGUgRXJyb3I6XCIsIGVycm9yKTtcclxuICAgICAgbGV0IGVycm9yTWVzc2FnZSA9IFwiRmFpbGVkIHRvIHVwZGF0ZSBzdGF0dXMuXCI7XHJcbiAgICAgIGlmIChlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSkge1xyXG4gICAgICAgIGVycm9yTWVzc2FnZSA9IGVycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZTtcclxuICAgICAgfSBlbHNlIGlmIChlcnJvci5yZXNwb25zZT8uZGF0YT8uZXJyb3JzKSB7XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlID0gT2JqZWN0LnZhbHVlcyhlcnJvci5yZXNwb25zZS5kYXRhLmVycm9ycylcclxuICAgICAgICAgIC5mbGF0KClcclxuICAgICAgICAgIC5qb2luKFwiLCBcIik7XHJcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3IuZXJyb3JGaWVsZHMpIHtcclxuICAgICAgICBlcnJvck1lc3NhZ2UgPSBlcnJvci5lcnJvckZpZWxkc1xyXG4gICAgICAgICAgLm1hcCgoZikgPT4gYCR7Zi5uYW1lLmpvaW4oXCIuXCIpfTogJHtmLmVycm9ycy5qb2luKFwiLCBcIil9YClcclxuICAgICAgICAgIC5qb2luKFwiOyBcIik7XHJcbiAgICAgIH1cclxuICAgICAgYXBpLmVycm9yKHsgbWVzc2FnZTogXCJVcGRhdGUgRmFpbGVkXCIsIGRlc2NyaXB0aW9uOiBlcnJvck1lc3NhZ2UgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZXRQZW5kaW5nID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgYXdhaXQgdXBkYXRlU3RhdHVzKFwiUGVuZGluZ1wiKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVNldEFjY2VwdCA9IGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IHVwZGF0ZVN0YXR1cyhcIkFjY2VwdFwiKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVNldFJlamVjdCA9IGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IHVwZGF0ZVN0YXR1cyhcIlJlamVjdFwiKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVNldE5leHRhdWN0aW9uID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgYXdhaXQgdXBkYXRlU3RhdHVzKFwiTmV4dEF1Y3Rpb25cIik7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVTZXRQcml6ZWQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBhd2FpdCB1cGRhdGVTdGF0dXMoXCJQcml6ZWRcIik7XHJcbiAgfTtcclxuXHJcbiAgLy8gQnVsayBTdGF0dXMgVXBkYXRlIEhhbmRsZXJcclxuICBjb25zdCBoYW5kbGVCdWxrU3RhdHVzVXBkYXRlID0gKG5ld1N0YXR1cykgPT4ge1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRJdGVtcyA9IGZpbHRlcmVkQmlkUmVxdWVzdHMuZmlsdGVyKFxyXG4gICAgICAoaXRlbSkgPT4gYWN0aXZlVXNlckRhdGFbaXRlbS5faWRdPy5pbmZvPy5zdGF0dXMsXHJcbiAgICApO1xyXG4gICAgaWYgKHNlbGVjdGVkSXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gICAgTW9kYWwuY29uZmlybSh7XHJcbiAgICAgIHRpdGxlOiBgQnVsayBVcGRhdGUgQ29uZmlybWF0aW9uYCxcclxuICAgICAgaWNvbjogPEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgLz4sXHJcbiAgICAgIGNvbnRlbnQ6IGBZb3UgYXJlIGFib3V0IHRvIHVwZGF0ZSBzdGF0dXMgdG8gXCIke25ld1N0YXR1c31cIiBmb3IgJHtzZWxlY3RlZEl0ZW1zLmxlbmd0aH0gcmVxdWVzdHMuIEFyZSB5b3Ugc3VyZT9gLFxyXG4gICAgICBva1RleHQ6IFwiWWVzLCBVcGRhdGVcIixcclxuICAgICAgY2FuY2VsVGV4dDogXCJOb1wiLFxyXG4gICAgICBvbk9rOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgcHJvbWlzZXMgPSBzZWxlY3RlZEl0ZW1zLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAgIHN0YXR1czogbmV3U3RhdHVzLFxyXG4gICAgICAgICAgICAgIGVucm9sbG1lbnRJZDogaXRlbS5lbnJvbGxtZW50SWQ/Ll9pZCB8fCBpdGVtLmVucm9sbG1lbnRJZCxcclxuICAgICAgICAgICAgICBncm91cElkOiBpdGVtLmdyb3VwSWQ/Ll9pZCB8fCBpdGVtLmdyb3VwSWQsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHJldHVybiBBUEkucHV0KGAvYmlkLXJlcXVlc3QvdXBkYXRlLyR7aXRlbS5faWR9YCwgcGF5bG9hZCk7XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKHByb21pc2VzKTtcclxuICAgICAgICAgIGFwaS5zdWNjZXNzKHtcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJTdWNjZXNzXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBgJHtzZWxlY3RlZEl0ZW1zLmxlbmd0aH0gcmVxdWVzdHMgdXBkYXRlZCB0byAke25ld1N0YXR1c31gLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSh7fSk7XHJcbiAgICAgICAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gICAgICAgICAgZmV0Y2hCaWRSZXF1ZXN0cygpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgYXBpLmVycm9yKHtcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJGYWlsZWQgdG8gdXBkYXRlIHNvbWUgcmVxdWVzdHMuXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGF0ZVNlYXJjaCA9ICgpID0+IHtcclxuICAgIHNldEFjdGl2ZUZyb21EYXRlKGlucHV0RnJvbURhdGUpO1xyXG4gICAgc2V0QWN0aXZlVG9EYXRlKGlucHV0VG9EYXRlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDbGVhckZpbHRlcnMgPSAoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFN0YXR1cyhcImFsbFwiKTtcclxuICAgIHNldFNlbGVjdGVkR3JvdXBGaWx0ZXIoXCJhbGxcIik7XHJcbiAgICBzZXRTZWxlY3RlZFBheW1lbnRTdGF0dXMoXCJhbGxcIik7XHJcbiAgICBzZXRJbnB1dEZyb21EYXRlKG51bGwpO1xyXG4gICAgc2V0SW5wdXRUb0RhdGUobnVsbCk7XHJcbiAgICBzZXRBY3RpdmVGcm9tRGF0ZShudWxsKTtcclxuICAgIHNldEFjdGl2ZVRvRGF0ZShudWxsKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPcGVuVmVyaWZ5TW9kYWwgPSAoKSA9PiBzZXRJc1ZlcmlmeU1vZGFsT3Blbih0cnVlKTtcclxuICBjb25zdCBoYW5kbGVDbG9zZVZlcmlmeU1vZGFsID0gKCkgPT4gc2V0SXNWZXJpZnlNb2RhbE9wZW4oZmFsc2UpO1xyXG5cclxuICBjb25zdCBoYW5kbGVTZW5kV2hhdHNBcHAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRJc1NlbmRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBzZWxlY3RlZEl0ZW1zID0gZmlsdGVyZWRCaWRSZXF1ZXN0cy5maWx0ZXIoXHJcbiAgICAgICAgKGl0ZW0pID0+IGFjdGl2ZVVzZXJEYXRhW2l0ZW0uX2lkXT8uaW5mbz8uc3RhdHVzLFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCByZWNlaXZlcnMgPSB7fTtcclxuXHJcbiAgICAgIHNlbGVjdGVkSXRlbXMuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHVzZXJPYmogPVxyXG4gICAgICAgICAgdHlwZW9mIGl0ZW0uc3Vic2NyaWJlcklkID09PSBcIm9iamVjdFwiID8gaXRlbS5zdWJzY3JpYmVySWQgOiB7fTtcclxuICAgICAgICBjb25zdCBncm91cE9iaiA9IHR5cGVvZiBpdGVtLmdyb3VwSWQgPT09IFwib2JqZWN0XCIgPyBpdGVtLmdyb3VwSWQgOiB7fTtcclxuICAgICAgICBjb25zdCBlbnJvbGxtZW50SWQgPVxyXG4gICAgICAgICAgaXRlbS5lbnJvbGxtZW50SWQ/Ll9pZCB8fFxyXG4gICAgICAgICAgaXRlbS5lbnJvbGxtZW50SWQgfHxcclxuICAgICAgICAgIGl0ZW0uZW5yb2xsbWVudD8uX2lkIHx8XHJcbiAgICAgICAgICBpdGVtLmVucm9sbG1lbnQ7XHJcblxyXG4gICAgICAgIHJlY2VpdmVyc1tpdGVtLl9pZF0gPSB7XHJcbiAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgIHN0YXR1czogdHJ1ZSxcclxuICAgICAgICAgICAgc3Vic2NyaWJlck5hbWU6IGl0ZW0uc3Vic2NyaWJlck5hbWUgfHwgdXNlck9iai5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgbW9iaWxlTnVtYmVyOiBpdGVtLm1vYmlsZU51bWJlciB8fCB1c2VyT2JqLnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBncm91cE5hbWU6IGl0ZW0uZ3JvdXBOYW1lIHx8IGdyb3VwT2JqLmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgdGlja2V0TnVtYmVyOiBpdGVtLnRpY2tldE51bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBiaWRSZXF1ZXN0SWQ6IGl0ZW0uX2lkLFxyXG4gICAgICAgICAgICBlbnJvbGxtZW50SWQ6IGVucm9sbG1lbnRJZCxcclxuICAgICAgICAgICAgZ3JvdXBJZDogZ3JvdXBPYmouX2lkIHx8IGl0ZW0uZ3JvdXBJZCxcclxuICAgICAgICAgICAgc3Vic2NyaWJlcklkOiB1c2VyT2JqLl9pZCB8fCBpdGVtLnN1YnNjcmliZXJJZCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBhd2FpdCBBUEkucG9zdChcIi93aGF0c2FwcC9iaWQtcmVxdWVzdC1iYWxhbmNlLWNoZWNrXCIsIHJlY2VpdmVycyk7XHJcbiAgICAgIGFwaS5zdWNjZXNzKHtcclxuICAgICAgICBtZXNzYWdlOiBcIlN1Y2Nlc3NcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogXCJXaGF0c0FwcCBtZXNzYWdlcyBpbml0aWF0ZWQgc3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IG5ld0FjdGl2ZURhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcbiAgICAgIHNlbGVjdGVkSXRlbXMuZm9yRWFjaCgoaXRlbSkgPT4gZGVsZXRlIG5ld0FjdGl2ZURhdGFbaXRlbS5faWRdKTtcclxuICAgICAgc2V0QWN0aXZlVXNlckRhdGEobmV3QWN0aXZlRGF0YSk7XHJcbiAgICAgIHNldElzVmVyaWZ5TW9kYWxPcGVuKGZhbHNlKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgIGFwaS5lcnJvcih7XHJcbiAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gc2VuZCBtZXNzYWdlcy5cIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1NlbmRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgc2V0T3BlbkFjdGlvbklkKG51bGwpO1xyXG4gICAgc2V0RHJvcGRvd25Qb3NpdGlvbih7IC4uLmRyb3Bkb3duUG9zaXRpb24sIHZpc2libGU6IGZhbHNlIH0pO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgQVBJLmRlbGV0ZShgL2JpZC1yZXF1ZXN0L2RlbGV0ZS8ke2lkfWApO1xyXG4gICAgICBhcGkuc3VjY2Vzcyh7IG1lc3NhZ2U6IFwiRGVsZXRlZFwiLCBkZXNjcmlwdGlvbjogXCJEZWxldGVkIHN1Y2Nlc3NmdWxseS5cIiB9KTtcclxuICAgICAgZmV0Y2hCaWRSZXF1ZXN0cygpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgYXBpLmVycm9yKHsgbWVzc2FnZTogXCJFcnJvclwiLCBkZXNjcmlwdGlvbjogXCJGYWlsZWQgdG8gZGVsZXRlLlwiIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbmZpcm1EZWxldGUgPSAoaWQpID0+IHtcclxuICAgIE1vZGFsLmNvbmZpcm0oe1xyXG4gICAgICB0aXRsZTogXCJBcmUgeW91IHN1cmUgZGVsZXRlIHRoaXMgYmlkIHJlcXVlc3Q/XCIsXHJcbiAgICAgIGNvbnRlbnQ6IFwiVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS5cIixcclxuICAgICAgb2tUZXh0OiBcIlllc1wiLFxyXG4gICAgICBva1R5cGU6IFwiZGFuZ2VyXCIsXHJcbiAgICAgIGNhbmNlbFRleHQ6IFwiTm9cIixcclxuICAgICAgb25PaygpIHtcclxuICAgICAgICBoYW5kbGVEZWxldGUoaWQpO1xyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUHJpbnQgPSAoaXRlbSkgPT4ge1xyXG4gICAgc2V0T3BlbkFjdGlvbklkKG51bGwpO1xyXG4gICAgc2V0RHJvcGRvd25Qb3NpdGlvbih7IC4uLmRyb3Bkb3duUG9zaXRpb24sIHZpc2libGU6IGZhbHNlIH0pO1xyXG4gICAgY29uc3QgdXNlck9iaiA9XHJcbiAgICAgIHR5cGVvZiBpdGVtLnN1YnNjcmliZXJJZCA9PT0gXCJvYmplY3RcIiA/IGl0ZW0uc3Vic2NyaWJlcklkIDoge307XHJcbiAgICBjb25zdCB1c2VyTmFtZSA9IGl0ZW0uc3Vic2NyaWJlck5hbWUgfHwgdXNlck9iai5mdWxsX25hbWUgfHwgXCJOL0FcIjtcclxuICAgIGNvbnN0IHVzZXJQaG9uZSA9IGl0ZW0ubW9iaWxlTnVtYmVyIHx8IHVzZXJPYmoucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCI7XHJcbiAgICBjb25zdCBncm91cE5hbWUgPSBpdGVtLmdyb3VwTmFtZSB8fCBpdGVtLmdyb3VwSWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIjtcclxuICAgIGNvbnN0IGJhbGFuY2UgPSBpdGVtLmF1Y3Rpb25zPy5iYWxhbmNlIHx8IDA7XHJcbiAgICBjb25zdCB0aWNrZXROdW1iZXIgPSBpdGVtLnRpY2tldE51bWJlciB8fCBcIk4vQVwiO1xyXG4gICAgY29uc3QgY3VzdG9tZXJJZCA9XHJcbiAgICAgIHR5cGVvZiB1c2VyT2JqID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgPyB1c2VyT2JqLmN1c3RvbWVyX2lkIHx8IHVzZXJPYmouX2lkIHx8IFwiTi9BXCJcclxuICAgICAgICA6IFwiTi9BXCI7XHJcbiAgICBjb25zdCByZXF1ZXN0RGF0ZSA9IGl0ZW0uY3JlYXRlZEF0XHJcbiAgICAgID8gbmV3IERhdGUoaXRlbS5jcmVhdGVkQXQpXHJcbiAgICAgICAgICAudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIiwge1xyXG4gICAgICAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgbW9udGg6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgICBkYXk6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgfSlcclxuICAgICAgICAgIC5yZXBsYWNlKC9cXC8vZywgXCItXCIpXHJcbiAgICAgIDogXCJOL0FcIjtcclxuICAgIGNvbnN0IGF1Y3Rpb25EYXRlID0gaXRlbS5hdWN0aW9uRGF0ZVxyXG4gICAgICA/IG5ldyBEYXRlKGl0ZW0uYXVjdGlvbkRhdGUpXHJcbiAgICAgICAgICAudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIiwge1xyXG4gICAgICAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgbW9udGg6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgICBkYXk6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgfSlcclxuICAgICAgICAgIC5yZXBsYWNlKC9cXC8vZywgXCItXCIpXHJcbiAgICAgIDogXCJOL0FcIjtcclxuXHJcbiAgICBjb25zdCBwcmludFdpbmRvdyA9IHdpbmRvdy5vcGVuKFwiXCIsIFwiX2JsYW5rXCIpO1xyXG4gICAgY29uc3QgZ2VuZXJhdGVGb3JtID0gKCkgPT4gYFxyXG4gICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBoLWZ1bGwgcC0zIGZvbnQtc2VyaWYgdGV4dC1bMTFweF0gdGV4dC1ibGFja1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYm9yZGVyLWItMiBib3JkZXItYmxhY2sgcGItMiBtYi0zXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPGltZyBzcmM9XCIke2ltYWdlfVwiIGFsdD1cIkxvZ29cIiBjbGFzcz1cImgtMTIgdy1hdXRvXCIgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cIlwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzcz1cInRleHQtc20gZm9udC1ib2xkIHRleHQtYmx1ZS05MDAgdXBwZXJjYXNlIGxlYWRpbmctdGlnaHQgbWwtNlwiPlZJSkFZQSBWSU5BWUFLIENISVQgRlVORFMgKFApIExURDwvaDE+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXllbGxvdy02MDAgdXBwZXJjYXNlIHRleHQtY2VudGVyIG1sLTNcIj5CaWQgUmVxdWVzdGluZyBMZXR0ZXI8L2gxPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4LWdyb3cgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInctMTAgZm9udC1zZW1pYm9sZFwiPkRhdGU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJib3JkZXItYiBib3JkZXItYmxhY2sgZmxleC1ncm93IGgtNCBwbC0xIHRleHQtYmxhY2tcIj4ke3JlcXVlc3REYXRlfTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1zcGFuLTMgZmxleCBpdGVtcy1jZW50ZXIgbWwtNDBcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInctMTAgZm9udC1zZW1pYm9sZFwiPlBsYWNlOjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYm9yZGVyLWIgYm9yZGVyLWJsYWNrIGZsZXgtZ3JvdyBoLTQgcGwtMSB0ZXh0LWJsYWNrXCI+QmFuZ2Fsb3JlPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgcHktMSBweC0xIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ3LTMyIGZvbnQtYm9sZCB0ZXh0LWJsYWNrXCI+U3Vic2NyaWJlciBOYW1lOjwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJvcmRlci1iIGJvcmRlci1ibGFjayBmbGV4LWdyb3cgaC00IHBsLTEgdGV4dC1ibGFja1wiPiR7dXNlck5hbWV9PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBweS0xIHB4LTEgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInctMzIgZm9udC1ib2xkIHRleHQtYmxhY2tcIj5TdWJzY3JpYmVyIElEOjwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJvcmRlci1iIGJvcmRlci1ibGFjayBmbGV4LWdyb3cgaC00IHBsLTEgdGV4dC1ibGFja1wiPiR7Y3VzdG9tZXJJZH08L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidy0zMiBmb250LXNlbWlib2xkXCI+TW9iaWxlIE51bWJlcjo8L3NwYW4+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJib3JkZXItYiBib3JkZXItYmxhY2sgZmxleC1ncm93IGgtNCBwbC0xIHRleHQtYmxhY2tcIj4ke3VzZXJQaG9uZX08L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidy0zMiBmb250LXNlbWlib2xkXCI+R3JvdXAgTmFtZTo8L3NwYW4+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJib3JkZXItYiBib3JkZXItYmxhY2sgZmxleC1ncm93IGgtNCBwbC0xIHRleHQtYmxhY2tcIj4ke2dyb3VwTmFtZX08L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidy0zMiBmb250LXNlbWlib2xkXCI+VGlja2V0IE5vOjwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJvcmRlci1iIGJvcmRlci1ibGFjayBmbGV4LWdyb3cgaC00IHBsLTEgdGV4dC1ibGFja1wiPiR7dGlja2V0TnVtYmVyfTwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1bMTBweF0gdGV4dC1ibGFja1wiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInctMzIgZm9udC1zZW1pYm9sZFwiPkN1cnJlbnQgU3RhdHVzOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJtbC0yXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LWJvbGQgJHtiYWxhbmNlIDw9IDAgPyBcInRleHQtZ3JlZW4tNzAwXCIgOiBcInRleHQtcmVkLTYwMFwifVwiPlxyXG4gICAgICAgICAgICAgICAgJHtiYWxhbmNlIDw9IDAgPyBcIkV4Y2VzczogXCIgOiBcIkR1ZTogXCJ94oK5ICR7TWF0aC5hYnMoYmFsYW5jZSl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJib3JkZXIgYm9yZGVyLWdyYXktNDAwIHJvdW5kZWQgcC0yIGJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvbnQtYm9sZCB0ZXh0LXhzIG1iLTEgdXBwZXJjYXNlIHRleHQteWVsbG93LTYwMCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgcGItMC41XCI+Q2hpdCBSZXF1ZXN0aW5nIERldGFpbHM8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LXNlbWlib2xkIGJsb2NrIHRleHQtWzEwcHhdXCI+SW5zdGFsbG1lbnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYm9yZGVyLWIgYm9yZGVyLWJsYWNrIGgtNCBwbC0xIHRleHQtYmxhY2tcIj48L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LXNlbWlib2xkIGJsb2NrIHRleHQtWzEwcHhdXCI+TW9udGg8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYm9yZGVyLWIgYm9yZGVyLWJsYWNrIGgtNCBwbC0xIHRleHQtYmxhY2tcIj4ke2F1Y3Rpb25EYXRlICE9PSBcIk4vQVwiID8gbmV3IERhdGUoYXVjdGlvbkRhdGUpLnRvTG9jYWxlU3RyaW5nKFwiZGVmYXVsdFwiLCB7IG1vbnRoOiBcImxvbmdcIiB9KSA6IFwiTi9BXCJ9PC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1zZW1pYm9sZCBibG9jayB0ZXh0LVsxMHB4XVwiPkRhdGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYm9yZGVyLWIgYm9yZGVyLWJsYWNrIGgtNCBwbC0xIHRleHQtYmxhY2tcIj4ke2F1Y3Rpb25EYXRlfTwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cIm10LTQgcHQtMiBib3JkZXItdCBib3JkZXItZ3JheS0zMDBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaC04IGJvcmRlci1iIGJvcmRlci1ibGFjayB3LTQ4IG1iLTFcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1ib2xkIHRleHQteHNcIj5FbXBsb3llZSBTaWduYXR1cmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtWzlweF0gaXRhbGljXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaC04IGJvcmRlci1iIGJvcmRlci1ibGFjayB3LTQ4IG1iLTFcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1ib2xkIHRleHQteHNcIj5DdXN0b21lciBTaWduYXR1cmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cIm10LTIgcHQtMiBib3JkZXItdC0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktNDAwIGJnLWdyYXktMTAwIHAtMiByb3VuZGVkIHRleHQtWzEwcHhdXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTFcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtYmxhY2tcIj5Gb3IgT2ZmaWNlIFVzZSBPbmx5PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtYmxhY2tcIj5JRDogJHtjdXN0b21lcklkfTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctd2hpdGUgcC0xIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJsb2NrIHRleHQtWzlweF0gdGV4dC1ibGFja1wiPkNoZWNrOjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaC0zXCI+PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy13aGl0ZSBwLTEgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmxvY2sgdGV4dC1bOXB4XSB0ZXh0LWJsYWNrXCI+QXV0aDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImgtM1wiPjwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIGA7XHJcblxyXG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQud3JpdGUoYFxyXG4gICAgICA8IURPQ1RZUEUgaHRtbD5cclxuICAgICAgPGh0bWw+XHJcbiAgICAgIDxoZWFkPlxyXG4gICAgICAgIDx0aXRsZT5CaWQgUmVxdWVzdCBGb3JtPC90aXRsZT5cclxuICAgICAgICA8c2NyaXB0IHNyYz1cImh0dHBzOi8vY2RuLnRhaWx3aW5kY3NzLmNvbVwiPjwvc2NyaXB0PlxyXG4gICAgICAgIDxzdHlsZT5cclxuICAgICAgICAgIEBtZWRpYSBwcmludCB7XHJcbiAgICAgICAgICAgIEBwYWdlIHsgc2l6ZTogQTQgbGFuZHNjYXBlOyBtYXJnaW46IDAuNWNtOyB9XHJcbiAgICAgICAgICAgIGJvZHkgeyAtd2Via2l0LXByaW50LWNvbG9yLWFkanVzdDogZXhhY3Q7IHByaW50LWNvbG9yLWFkanVzdDogZXhhY3Q7IG1hcmdpbjogMDsgcGFkZGluZzogMDsgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgYm9keSB7IGJhY2tncm91bmQ6ICNlNWU3ZWI7IGZvbnQtZmFtaWx5OiAnVGltZXMgTmV3IFJvbWFuJywgc2VyaWY7IH1cclxuICAgICAgICAgIC5sYW5kc2NhcGUtcGFnZSB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAyOS43Y207XHJcbiAgICAgICAgICAgIGhlaWdodDogMjBjbTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwIDAgMTBweCByZ2JhKDAsMCwwLDAuMSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAuc3BsaXQtcGFnZSB7XHJcbiAgICAgICAgICAgIGZsZXg6IDE7XHJcbiAgICAgICAgICAgIGJvcmRlci1yaWdodDogMnB4IGRhc2hlZCAjY2NjO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwLjVjbTtcclxuICAgICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5zcGxpdC1wYWdlOmxhc3QtY2hpbGQgeyBib3JkZXItcmlnaHQ6IG5vbmU7IH1cclxuICAgICAgICA8L3N0eWxlPlxyXG4gICAgICA8L2hlYWQ+XHJcbiAgICAgIDxib2R5PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYW5kc2NhcGUtcGFnZVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInNwbGl0LXBhZ2VcIj4ke2dlbmVyYXRlRm9ybSgpfTwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInNwbGl0LXBhZ2VcIj4ke2dlbmVyYXRlRm9ybSgpfTwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxzY3JpcHQ+XHJcbiAgICAgICAgICB3aW5kb3cub25sb2FkID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIHdpbmRvdy5wcmludCgpO1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkgeyB3aW5kb3cuY2xvc2UoKTsgfSwgMTAwMCk7XHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgIDwvc2NyaXB0PlxyXG4gICAgICA8L2JvZHk+XHJcbiAgICAgIDwvaHRtbD5cclxuICAgIGApO1xyXG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQuY2xvc2UoKTtcclxuICAgIHByaW50V2luZG93LmZvY3VzKCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hCaWRSZXF1ZXN0cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmdUYWJsZSh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KGAvYmlkLXJlcXVlc3QvZ2V0LWFsbD90eXBlPSR7dmlld1R5cGV9YCk7XHJcbiAgICAgIHNldFJhd0JpZFJlcXVlc3RzKHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW10pO1xyXG5cclxuICAgICAgY29uc3QgdGVtcEFjdGl2ZSA9IHt9O1xyXG4gICAgICByZXNwb25zZS5kYXRhPy5kYXRhPy5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaWQgPSBpdGVtLl9pZDtcclxuICAgICAgICBjb25zdCB1c2VyT2JqID1cclxuICAgICAgICAgIHR5cGVvZiBpdGVtLnN1YnNjcmliZXJJZCA9PT0gXCJvYmplY3RcIiA/IGl0ZW0uc3Vic2NyaWJlcklkIDoge307XHJcbiAgICAgICAgdGVtcEFjdGl2ZVtpZF0gPSB7XHJcbiAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAgICAgICAgIHVzZXJOYW1lOiBpdGVtLnN1YnNjcmliZXJOYW1lIHx8IHVzZXJPYmouZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICB1c2VyUGhvbmU6IGl0ZW0ubW9iaWxlTnVtYmVyIHx8IHVzZXJPYmoucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuICAgICAgc2V0QWN0aXZlVXNlckRhdGEodGVtcEFjdGl2ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRSYXdCaWRSZXF1ZXN0cyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nVGFibGUoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHVuaXF1ZUdyb3VwcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZ3JvdXBzID0gcmF3QmlkUmVxdWVzdHNcclxuICAgICAgLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGdyb3VwT2JqZWN0ID0gaXRlbT8uZ3JvdXBJZCB8fCB7fTtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgaXRlbS5ncm91cE5hbWUgfHxcclxuICAgICAgICAgICh0eXBlb2YgZ3JvdXBPYmplY3QgPT09IFwib2JqZWN0XCIgPyBncm91cE9iamVjdC5ncm91cF9uYW1lIDogXCJOL0FcIilcclxuICAgICAgICApO1xyXG4gICAgICB9KVxyXG4gICAgICAuZmlsdGVyKCh2YWx1ZSwgaW5kZXgsIHNlbGYpID0+IHZhbHVlICYmIHNlbGYuaW5kZXhPZih2YWx1ZSkgPT09IGluZGV4KTtcclxuICAgIHJldHVybiBncm91cHM7XHJcbiAgfSwgW3Jhd0JpZFJlcXVlc3RzXSk7XHJcblxyXG4gIGNvbnN0IHN0YXRzQmFzZURhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiByYXdCaWRSZXF1ZXN0cy5maWx0ZXIoKGl0ZW0pID0+IHtcclxuICAgICAgaWYgKHNlbGVjdGVkU3RhdHVzICE9PSBcImFsbFwiICYmIGl0ZW0uc3RhdHVzICE9PSBzZWxlY3RlZFN0YXR1cylcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIGlmIChzZWxlY3RlZEdyb3VwRmlsdGVyICE9PSBcImFsbFwiKSB7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBPYmplY3QgPSBpdGVtPy5ncm91cElkIHx8IHt9O1xyXG4gICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9XHJcbiAgICAgICAgICBpdGVtLmdyb3VwTmFtZSB8fFxyXG4gICAgICAgICAgKHR5cGVvZiBncm91cE9iamVjdCA9PT0gXCJvYmplY3RcIiA/IGdyb3VwT2JqZWN0Lmdyb3VwX25hbWUgOiBcIk4vQVwiKTtcclxuICAgICAgICBpZiAoZ3JvdXBOYW1lICE9PSBzZWxlY3RlZEdyb3VwRmlsdGVyKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGFjdGl2ZUZyb21EYXRlIHx8IGFjdGl2ZVRvRGF0ZSkge1xyXG4gICAgICAgIGNvbnN0IGl0ZW1EYXRlID0gaXRlbS5jcmVhdGVkQXQgPyBkYXlqcyhpdGVtLmNyZWF0ZWRBdCkgOiBudWxsO1xyXG4gICAgICAgIGlmICghaXRlbURhdGUpIHJldHVybiBmYWxzZTtcclxuICAgICAgICBpZiAoYWN0aXZlRnJvbURhdGUgJiYgaXRlbURhdGUuaXNCZWZvcmUoZGF5anMoYWN0aXZlRnJvbURhdGUpLCBcImRheVwiKSlcclxuICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICBpZiAoYWN0aXZlVG9EYXRlICYmIGl0ZW1EYXRlLmlzQWZ0ZXIoZGF5anMoYWN0aXZlVG9EYXRlKSwgXCJkYXlcIikpXHJcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9KTtcclxuICB9LCBbXHJcbiAgICByYXdCaWRSZXF1ZXN0cyxcclxuICAgIHNlbGVjdGVkU3RhdHVzLFxyXG4gICAgc2VsZWN0ZWRHcm91cEZpbHRlcixcclxuICAgIGFjdGl2ZUZyb21EYXRlLFxyXG4gICAgYWN0aXZlVG9EYXRlLFxyXG4gIF0pO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZEJpZFJlcXVlc3RzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRQYXltZW50U3RhdHVzID09PSBcImFsbFwiKSByZXR1cm4gc3RhdHNCYXNlRGF0YTtcclxuICAgIHJldHVybiBzdGF0c0Jhc2VEYXRhLmZpbHRlcigoaXRlbSkgPT4ge1xyXG4gICAgICBjb25zdCBiYWxhbmNlID0gaXRlbS5hdWN0aW9ucz8uYmFsYW5jZSB8fCAwO1xyXG4gICAgICBpZiAoc2VsZWN0ZWRQYXltZW50U3RhdHVzID09PSBcInBlbmRpbmdcIikgcmV0dXJuIGJhbGFuY2UgPiAwO1xyXG4gICAgICBpZiAoc2VsZWN0ZWRQYXltZW50U3RhdHVzID09PSBcInVwdG9kYXRlXCIpIHJldHVybiBiYWxhbmNlIDw9IDA7XHJcbiAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfSk7XHJcbiAgfSwgW3N0YXRzQmFzZURhdGEsIHNlbGVjdGVkUGF5bWVudFN0YXR1c10pO1xyXG5cclxuICBjb25zdCBzdW1tYXJ5U3RhdHMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGRhdGFUb0FuYWx5emUgPSBzdGF0c0Jhc2VEYXRhO1xyXG4gICAgY29uc3QgdG90YWxSZXF1ZXN0cyA9IGRhdGFUb0FuYWx5emU/Lmxlbmd0aCB8fCAwO1xyXG4gICAgY29uc3QgcGVuZGluZ1JlcXVlc3RzID1cclxuICAgICAgZGF0YVRvQW5hbHl6ZT8uZmlsdGVyKChpdGVtKSA9PiBpdGVtPy5zdGF0dXMgPT09IFwiUGVuZGluZ1wiKT8ubGVuZ3RoIHx8IDA7XHJcbiAgICBjb25zdCBhY2NlcHRSZXF1ZXN0cyA9XHJcbiAgICAgIGRhdGFUb0FuYWx5emU/LmZpbHRlcigoaXRlbSkgPT4gaXRlbT8uc3RhdHVzID09PSBcIkFjY2VwdFwiKT8ubGVuZ3RoIHx8IDA7XHJcbiAgICBjb25zdCByZWplY3RSZXF1ZXN0cyA9XHJcbiAgICAgIGRhdGFUb0FuYWx5emU/LmZpbHRlcigoaXRlbSkgPT4gaXRlbT8uc3RhdHVzID09PSBcIlJlamVjdFwiKT8ubGVuZ3RoIHx8IDA7XHJcbiAgICBjb25zdCBuZXh0YXVjdGlvblJlcXVlc3RzID1cclxuICAgICAgZGF0YVRvQW5hbHl6ZT8uZmlsdGVyKChpdGVtKSA9PiBpdGVtPy5zdGF0dXMgPT09IFwiTmV4dEF1Y3Rpb25cIik/Lmxlbmd0aCB8fFxyXG4gICAgICAwO1xyXG4gICAgY29uc3QgcHJpemVkUmVxdWVzdHMgPVxyXG4gICAgICBkYXRhVG9BbmFseXplPy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0/LnN0YXR1cyA9PT0gXCJQcml6ZWRcIik/Lmxlbmd0aCB8fCAwO1xyXG4gICAgY29uc3QgdG90YWxCYWxhbmNlID1cclxuICAgICAgZGF0YVRvQW5hbHl6ZT8ucmVkdWNlKFxyXG4gICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChpdGVtPy5hdWN0aW9ucz8uYmFsYW5jZSB8fCAwKSxcclxuICAgICAgICAwLFxyXG4gICAgICApIHx8IDA7XHJcblxyXG4gICAgICBjb25zdCB0b3RhbEFtb3VudFBhaWQgPSBkYXRhVG9BbmFseXplPy5yZWR1Y2UoXHJcbiAgICAgICAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyAoaXRlbT8uYXVjdGlvbnM/LmFtb3VudF9wYWlkIHx8IGl0ZW0/LmFtb3VudF9wYWlkIHx8IDApLFxyXG4gICAgICAgICAgMFxyXG4gICAgICAgICkgfHwgMDtcclxuXHJcbiAgICBjb25zdCBncm91cFN0YXRzID0ge307XHJcbiAgICAoZGF0YVRvQW5hbHl6ZSB8fCBbXSkuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICBpZiAoIWl0ZW0pIHJldHVybjtcclxuICAgICAgY29uc3QgZ3JvdXBPYmplY3QgPSBpdGVtPy5ncm91cElkIHx8IHt9O1xyXG4gICAgICBjb25zdCBncm91cE5hbWUgPVxyXG4gICAgICAgIGl0ZW0/Lmdyb3VwTmFtZSB8fFxyXG4gICAgICAgICh0eXBlb2YgZ3JvdXBPYmplY3QgPT09IFwib2JqZWN0XCIgPyBncm91cE9iamVjdD8uZ3JvdXBfbmFtZSA6IFwiVW5rbm93blwiKTtcclxuICAgICAgaWYgKCFncm91cE5hbWUpIHJldHVybjtcclxuXHJcbiAgICAgIGlmICghZ3JvdXBTdGF0c1tncm91cE5hbWVdKSB7XHJcbiAgICAgICAgZ3JvdXBTdGF0c1tncm91cE5hbWVdID0ge1xyXG4gICAgICAgICAgdG90YWw6IDAsXHJcbiAgICAgICAgICBwZW5kaW5nOiAwLFxyXG4gICAgICAgICAgYWNjZXB0OiAwLFxyXG4gICAgICAgICAgbmV4dGF1Y3Rpb246IDAsXHJcbiAgICAgICAgICByZWplY3Q6IDAsXHJcbiAgICAgICAgICBwcml6ZWQ6IDAsXHJcbiAgICAgICAgICBuZXh0X2F1Y3Rpb25fZGF0ZTogbnVsbCxcclxuICAgICAgICAgIG5leHRfYXVjdGlvbl9kaXNwbGF5OiBcIk4vQVwiLFxyXG4gICAgICAgICAgbGFzdF9hdWN0aW9uX2RhdGU6IG51bGwsXHJcbiAgICAgICAgICBiaWRkaW5nX29wZW5fY291bnQ6IDAsXHJcbiAgICAgICAgICB0b3RhbF9iYWxhbmNlOiAwLFxyXG4gICAgICAgICAgZ3JvdXBJZDogZ3JvdXBPYmplY3Q/Ll9pZCB8fCBpdGVtLmdyb3VwSWQ/Ll9pZCB8fCBpdGVtLmdyb3VwSWQsXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgZ3JvdXBTdGF0c1tncm91cE5hbWVdLnRvdGFsKys7XHJcbiAgICAgIGdyb3VwU3RhdHNbZ3JvdXBOYW1lXS50b3RhbF9iYWxhbmNlICs9IGl0ZW0uYXVjdGlvbnM/LmJhbGFuY2UgfHwgMDtcclxuXHJcbiAgICAgIGlmIChpdGVtLnN0YXR1cyA9PT0gXCJQZW5kaW5nXCIpIGdyb3VwU3RhdHNbZ3JvdXBOYW1lXS5wZW5kaW5nKys7XHJcbiAgICAgIGlmIChpdGVtLnN0YXR1cyA9PT0gXCJBY2NlcHRcIikgZ3JvdXBTdGF0c1tncm91cE5hbWVdLmFjY2VwdCsrO1xyXG4gICAgICBpZiAoaXRlbS5zdGF0dXMgPT09IFwiUmVqZWN0XCIpIGdyb3VwU3RhdHNbZ3JvdXBOYW1lXS5yZWplY3QrKztcclxuICAgICAgaWYgKGl0ZW0uc3RhdHVzID09PSBcIk5leHRBdWN0aW9uXCIpIGdyb3VwU3RhdHNbZ3JvdXBOYW1lXS5uZXh0YXVjdGlvbisrO1xyXG4gICAgICBpZiAoaXRlbS5zdGF0dXMgPT09IFwiUHJpemVkXCIpIGdyb3VwU3RhdHNbZ3JvdXBOYW1lXS5wcml6ZWQrKztcclxuXHJcbiAgICAgIGNvbnN0IG5leHREYXRlID0gaXRlbS5hdWN0aW9uRGF0ZTtcclxuICAgICAgaWYgKG5leHREYXRlKSB7XHJcbiAgICAgICAgY29uc3QgY3VycmVudFN0b3JlZERhdGUgPSBncm91cFN0YXRzW2dyb3VwTmFtZV0ubmV4dF9hdWN0aW9uX2RhdGU7XHJcbiAgICAgICAgY29uc3QgbmV4dERhdGVPYmogPSBkYXlqcyhuZXh0RGF0ZSk7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgIWN1cnJlbnRTdG9yZWREYXRlIHx8XHJcbiAgICAgICAgICBuZXh0RGF0ZU9iai5pc0JlZm9yZShkYXlqcyhjdXJyZW50U3RvcmVkRGF0ZSkpXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBncm91cFN0YXRzW2dyb3VwTmFtZV0ubmV4dF9hdWN0aW9uX2RhdGUgPSBuZXh0RGF0ZTtcclxuICAgICAgICAgIGdyb3VwU3RhdHNbZ3JvdXBOYW1lXS5uZXh0X2F1Y3Rpb25fZGlzcGxheSA9IG5leHREYXRlT2JqLmlzVmFsaWQoKVxyXG4gICAgICAgICAgICA/IG5leHREYXRlT2JqLmZvcm1hdChcIkRELU1NLVlZWVlcIilcclxuICAgICAgICAgICAgOiBcIk4vQVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGl0ZW0uYmlkX3N0YXR1cyA9PT0gXCJiaWRkaW5nX29wZW5cIikge1xyXG4gICAgICAgIGdyb3VwU3RhdHNbZ3JvdXBOYW1lXS5iaWRkaW5nX29wZW5fY291bnQrKztcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgcGF5bWVudFN0YXRzID0ge1xyXG4gICAgICBwZW5kaW5nOiB7IGNvdW50OiAwLCBhbW91bnQ6IDAgfSxcclxuICAgICAgdXBUb0RhdGU6IHsgY291bnQ6IDAgfSxcclxuICAgIH07XHJcblxyXG4gICAgKGRhdGFUb0FuYWx5emUgfHwgW10pLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgY29uc3QgYmFsYW5jZSA9IGl0ZW0/LmF1Y3Rpb25zPy5iYWxhbmNlIHx8IDA7XHJcbiAgICAgIGlmIChiYWxhbmNlID4gMCkge1xyXG4gICAgICAgIHBheW1lbnRTdGF0cy5wZW5kaW5nLmNvdW50Kys7XHJcbiAgICAgICAgcGF5bWVudFN0YXRzLnBlbmRpbmcuYW1vdW50ICs9IGJhbGFuY2U7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcGF5bWVudFN0YXRzLnVwVG9EYXRlLmNvdW50Kys7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsUmVxdWVzdHM6IHRvdGFsUmVxdWVzdHMgfHwgMCxcclxuICAgICAgcGVuZGluZ1JlcXVlc3RzOiBwZW5kaW5nUmVxdWVzdHMgfHwgMCxcclxuICAgICAgYWNjZXB0UmVxdWVzdHM6IGFjY2VwdFJlcXVlc3RzIHx8IDAsXHJcbiAgICAgIHJlamVjdFJlcXVlc3RzOiByZWplY3RSZXF1ZXN0cyB8fCAwLFxyXG4gICAgICBuZXh0YXVjdGlvblJlcXVlc3RzOiBuZXh0YXVjdGlvblJlcXVlc3RzIHx8IDAsXHJcbiAgICAgIHByaXplZFJlcXVlc3RzOiBwcml6ZWRSZXF1ZXN0cyB8fCAwLFxyXG4gICAgICB0b3RhbEJhbGFuY2U6IHRvdGFsQmFsYW5jZSB8fCAwLFxyXG4gICAgICAgdG90YWxBbW91bnRQYWlkOiB0b3RhbEFtb3VudFBhaWQgfHwgMCwgXHJcbiAgICAgIGdyb3VwU3RhdHM6IGdyb3VwU3RhdHMgfHwge30sXHJcbiAgICAgIHBheW1lbnRTdGF0czogcGF5bWVudFN0YXRzIHx8IHtcclxuICAgICAgICBwZW5kaW5nOiB7IGNvdW50OiAwLCBhbW91bnQ6IDAgfSxcclxuICAgICAgICB1cFRvRGF0ZTogeyBjb3VudDogMCB9LFxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9LCBbc3RhdHNCYXNlRGF0YV0pO1xyXG5cclxuICBjb25zdCBzZWxlY3RlZENvdW50ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyZWRCaWRSZXF1ZXN0cy5maWx0ZXIoXHJcbiAgICAgIChpdGVtKSA9PiBhY3RpdmVVc2VyRGF0YVtpdGVtLl9pZF0/LmluZm8/LnN0YXR1cyxcclxuICAgICkubGVuZ3RoO1xyXG4gIH0sIFtmaWx0ZXJlZEJpZFJlcXVlc3RzLCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuICBjb25zdCBmb3JtYXR0ZWRCaWREYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyZWRCaWRSZXF1ZXN0cy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgIGNvbnN0IHVzZXJPYmplY3QgPSBpdGVtPy5zdWJzY3JpYmVySWQgfHwge307XHJcbiAgICAgIGNvbnN0IGdyb3VwT2JqZWN0ID0gaXRlbT8uZ3JvdXBJZCB8fCB7fTtcclxuICAgICAgY29uc3QgdXNlck5hbWUgPVxyXG4gICAgICAgIGl0ZW0uc3Vic2NyaWJlck5hbWUgfHxcclxuICAgICAgICAodHlwZW9mIHVzZXJPYmplY3QgPT09IFwib2JqZWN0XCIgPyB1c2VyT2JqZWN0LmZ1bGxfbmFtZSA6IFwiTi9BXCIpO1xyXG4gICAgICBjb25zdCB1c2VyUGhvbmUgPVxyXG4gICAgICAgIGl0ZW0ubW9iaWxlTnVtYmVyIHx8XHJcbiAgICAgICAgKHR5cGVvZiB1c2VyT2JqZWN0ID09PSBcIm9iamVjdFwiID8gdXNlck9iamVjdC5waG9uZV9udW1iZXIgOiBcIk4vQVwiKTtcclxuICAgICAgY29uc3QgdXNlcklkID1cclxuICAgICAgICB0eXBlb2YgdXNlck9iamVjdCA9PT0gXCJvYmplY3RcIiA/IHVzZXJPYmplY3QuX2lkIDogdXNlck9iamVjdDtcclxuICAgICAgY29uc3QgY3VzdG9tZXJJZCA9XHJcbiAgICAgICAgdHlwZW9mIHVzZXJPYmplY3QgPT09IFwib2JqZWN0XCJcclxuICAgICAgICAgID8gdXNlck9iamVjdC5jdXN0b21lcl9pZCB8fCBcIk4vQVwiXHJcbiAgICAgICAgICA6IFwiTi9BXCI7XHJcbiAgICAgIGNvbnN0IGdyb3VwTmFtZSA9XHJcbiAgICAgICAgaXRlbS5ncm91cE5hbWUgfHxcclxuICAgICAgICAodHlwZW9mIGdyb3VwT2JqZWN0ID09PSBcIm9iamVjdFwiID8gZ3JvdXBPYmplY3QuZ3JvdXBfbmFtZSA6IFwiTi9BXCIpO1xyXG5cclxuICAgICAgY29uc3QgaW5zdGFuY2VCYWxhbmNlID0gaXRlbT8uaW5zdGFuY2VCYWxhbmNlIHx8IDA7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnRCYWxhbmNlID0gaXRlbT8uYXVjdGlvbnM/LmJhbGFuY2UgfHwgMDtcclxuXHJcbiAgICAgIGNvbnN0IGFtb3VudFBhaWQgPSBpdGVtPy5hdWN0aW9ucz8uYW1vdW50X3BhaWQgfHwgaXRlbT8uYW1vdW50X3BhaWQgfHwgMDtcclxuICAgICAgY29uc3QgdG90YWxUb0JlUGFpZCA9IGl0ZW0/LmF1Y3Rpb25zPy50b3RhbF90b19iZV9wYWlkIHx8IDA7XHJcblxyXG4gICAgICBsZXQgY3JlYXRlZEJ5ID0gXCJOL0FcIjtcclxuICAgICAgY29uc3QgYWRtaW5PYmplY3QgPSBpdGVtLmFkbWluVXNlckRldGFpbHMgfHwge307XHJcbiAgICAgIGNvbnN0IGFkbWluTmFtZUZyb21Mb29rdXAgPSBhZG1pbk9iamVjdC5uYW1lIHx8IGFkbWluT2JqZWN0LmZ1bGxfbmFtZTtcclxuICAgICAgY29uc3QgYWRtaW5OYW1lU3RvcmVkID0gaXRlbS5hZG1pbk5hbWU7XHJcblxyXG4gICAgICBpZiAoYWRtaW5OYW1lU3RvcmVkKSB7XHJcbiAgICAgICAgY3JlYXRlZEJ5ID0gYWRtaW5OYW1lU3RvcmVkO1xyXG4gICAgICB9IGVsc2UgaWYgKGFkbWluTmFtZUZyb21Mb29rdXApIHtcclxuICAgICAgICBjcmVhdGVkQnkgPSBhZG1pbk5hbWVGcm9tTG9va3VwO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNyZWF0ZWRCeSA9IGl0ZW0uc3Vic2NyaWJlck5hbWUgfHwgdXNlck5hbWUgfHwgdXNlclBob25lIHx8IFwiQ3VzdG9tZXJcIjtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcmVmZXJyZWRCeSA9XHJcbiAgICAgICAgaXRlbT8uYWdlbnQ/Lm5hbWUgJiYgaXRlbT8uYWdlbnQ/LnBob25lX251bWJlclxyXG4gICAgICAgICAgPyBgJHtpdGVtLmFnZW50Lm5hbWV9IHwgJHtpdGVtLmFnZW50LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICA6IGl0ZW0/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiZcclxuICAgICAgICAgICAgICBpdGVtPy5yZWZlcnJlZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgID8gYCR7aXRlbS5yZWZlcnJlZF9jdXN0b21lci5mdWxsX25hbWV9IHwgJHtpdGVtLnJlZmVycmVkX2N1c3RvbWVyLnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgIDogaXRlbT8ucmVmZXJyZWRfbGVhZD8ubGVhZF9uYW1lICYmXHJcbiAgICAgICAgICAgICAgICBpdGVtPy5yZWZlcnJlZF9sZWFkPy5hZ2VudF9udW1iZXJcclxuICAgICAgICAgICAgICA/IGAke2l0ZW0ucmVmZXJyZWRfbGVhZC5sZWFkX25hbWV9IHwgJHtpdGVtLnJlZmVycmVkX2xlYWQuYWdlbnRfbnVtYmVyfWBcclxuICAgICAgICAgICAgICA6IFwiTi9BXCI7XHJcblxyXG4gICAgICBjb25zdCBlbnJvbGxtZW50SWQgPSBpdGVtLmVucm9sbG1lbnRJZD8uX2lkIHx8IGl0ZW0uZW5yb2xsbWVudElkO1xyXG4gICAgICBjb25zdCBiaWRSZXF1ZXN0Q29kZSA9IGl0ZW0uYmlkX3JlcXVlc3RfY29kZSB8fCBcIi1cIjtcclxuICAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbaXRlbS5faWRdPy5pbmZvPy5zdGF0dXM7XHJcbiAgICAgICBjb25zdCByZXF1ZXN0U291cmNlID0gaXRlbT8uc291cmNlIHx8IFwiQ2hpdC1BZG1pblwiO1xyXG5cclxuICAgICAgICBsZXQgYXVjdGlvbkRhdGVEaXNwbGF5ID0gXCItXCI7XHJcbiAgICBsZXQgYXVjdGlvbkRhdGVSYXcgPSBudWxsO1xyXG4gICAgXHJcbiAgICBpZiAoaXRlbS5hdWN0aW9uRGF0ZSkge1xyXG4gICAgICBhdWN0aW9uRGF0ZVJhdyA9IGl0ZW0uYXVjdGlvbkRhdGU7XHJcbiAgICAgIGF1Y3Rpb25EYXRlRGlzcGxheSA9IGRheWpzKGl0ZW0uYXVjdGlvbkRhdGUpLmZvcm1hdChcIkRELU1NLVlZWVlcIik7XHJcbiAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGtleTogaXRlbS5faWQsXHJcbiAgICAgICAgX2lkOiBpdGVtLl9pZCxcclxuICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgIHVzZXJOYW1lOiB1c2VyTmFtZSxcclxuICAgICAgICBncm91cE5hbWU6IGdyb3VwTmFtZSxcclxuICAgICAgICBjdXN0b21lcklkOiBjdXN0b21lcklkLFxyXG4gICAgICAgIG1vYmlsZU51bWJlcjogdXNlclBob25lLFxyXG4gICAgICAgIHBob25lTnVtYmVyOiB1c2VyUGhvbmUsXHJcbiAgICAgICAgZGF0ZTogaXRlbS5jcmVhdGVkQXQgPyBpdGVtLmNyZWF0ZWRBdC5zcGxpdChcIlRcIilbMF0gOiBcIi1cIixcclxuICAgICAgICB0aWNrZXROdW1iZXI6IGl0ZW0udGlja2V0TnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgIGJpZF9yZXF1ZXN0X2NvZGU6IGJpZFJlcXVlc3RDb2RlLFxyXG4gICAgICAgIHNvdXJjZTpyZXF1ZXN0U291cmNlLFxyXG4gICAgICAgIGF1Y3Rpb25EYXRlRGlzcGxheTogYXVjdGlvbkRhdGVEaXNwbGF5LCAvLyBUaGlzIHdpbGwgc2hvdyB0aGUgbmV4dF9kYXRlXHJcbiAgICAgIGF1Y3Rpb25EYXRlOiBhdWN0aW9uRGF0ZVJhdyxcclxuICAgICAgYXVjdGlvblRpbWU6IGl0ZW0uYXVjdGlvbl90aW1lXHJcbiAgICAgICAgPyBkYXlqcyhpdGVtLmF1Y3Rpb25fdGltZSwgXCJISDptbVwiKS5mb3JtYXQoXCJoOm1tIEFcIilcclxuICAgICAgICA6IFwiLVwiLFxyXG4gICAgICAgIGVuYWJsZV9iaWRfcmVxdWVzdDogaXRlbS5lbmFibGVfYmlkX3JlcXVlc3QgfHwgZmFsc2UsXHJcbiAgICAgICAgYmlkX3N0YXR1czogaXRlbS5iaWRfc3RhdHVzIHx8IFwidW5rbm93blwiLFxyXG4gICAgICAgIGRheXNfdW50aWxfYXVjdGlvbjogaXRlbS5kYXlzX3VudGlsX2F1Y3Rpb24gfHwgMCxcclxuICAgICAgICByZWZlcnJlZEJ5OiByZWZlcnJlZEJ5LFxyXG4gICAgICAgIGluc3RhbmNlQmFsYW5jZVZhbHVlX3JhdzogaW5zdGFuY2VCYWxhbmNlIHx8IDAsXHJcblxyXG4gICAgICAgIGluc3RhbmNlQmFsYW5jZVZhbHVlOiAoXHJcbiAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgIGluc3RhbmNlQmFsYW5jZSA8PSAwXHJcbiAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi02MDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICA6IFwidGV4dC1yZWQtNjAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIOKCuSB7aW5zdGFuY2VCYWxhbmNlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKSxcclxuXHJcbiAgICAgICAgY3VycmVudEJhbGFuY2VWYWx1ZV9yYXc6IGN1cnJlbnRCYWxhbmNlIHx8IDAsXHJcbiAgICAgICAgY3VycmVudEJhbGFuY2VWYWx1ZTogKFxyXG4gICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgICBjdXJyZW50QmFsYW5jZSA8PSAwXHJcbiAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi02MDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICA6IFwidGV4dC1yZWQtNjAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIOKCuSB7Y3VycmVudEJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApLFxyXG5cclxuICAgICAgICBhbW91bnRQYWlkVmFsdWVfcmF3OiBhbW91bnRQYWlkIHx8IDAsXHJcbiAgICAgIGFtb3VudFBhaWRWYWx1ZTogKFxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAg4oK5IHthbW91bnRQYWlkLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApLFxyXG5cclxuICAgICAgICBlbnJvbGxtZW50SWQ6IGVucm9sbG1lbnRJZCxcclxuICAgICAgICBjaGVja0JveDogKFxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgIFtpdGVtLl9pZF06IHtcclxuICAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSxcclxuICAgICAgICBzdGF0dXM6IGl0ZW0uc3RhdHVzIHx8IFwiUGVuZGluZ1wiLFxyXG4gICAgICAgIHN1YnNjcmliZXJOYW1lOiBpdGVtLnN1YnNjcmliZXJOYW1lIHx8IHVzZXJOYW1lLFxyXG4gICAgICAgIHN1YnNjcmliZXJJZDogdXNlcklkLFxyXG4gICAgICAgIG1vYmlsZU51bWJlclJhdzogaXRlbS5tb2JpbGVOdW1iZXIgfHwgdXNlclBob25lLFxyXG4gICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB0ZXh0LWNlbnRlciBkcm9wZG93bi10cmlnZ2VyXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlY3QgPSBlLmN1cnJlbnRUYXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgICAgICAgICBzZXREcm9wZG93blBvc2l0aW9uKHtcclxuICAgICAgICAgICAgICAgICAgdmlzaWJsZTpcclxuICAgICAgICAgICAgICAgICAgICAhZHJvcGRvd25Qb3NpdGlvbi52aXNpYmxlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgZHJvcGRvd25Qb3NpdGlvbi5pdGVtPy5faWQgIT09IGl0ZW0uX2lkLFxyXG4gICAgICAgICAgICAgICAgICB4OiByZWN0LnJpZ2h0IC0gMTYwLFxyXG4gICAgICAgICAgICAgICAgICB5OiByZWN0LmJvdHRvbSArIDUsXHJcbiAgICAgICAgICAgICAgICAgIGl0ZW06XHJcbiAgICAgICAgICAgICAgICAgICAgZHJvcGRvd25Qb3NpdGlvbi52aXNpYmxlICYmXHJcbiAgICAgICAgICAgICAgICAgICAgZHJvcGRvd25Qb3NpdGlvbi5pdGVtPy5faWQgPT09IGl0ZW0uX2lkXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IG51bGxcclxuICAgICAgICAgICAgICAgICAgICAgIDogaXRlbSxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgc2V0T3BlblN0YXR1c0lkKG51bGwpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1ncmF5LTIwMCByZWxhdGl2ZVwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgekluZGV4OiAxMDAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIOKLrlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICB9LCBbZmlsdGVyZWRCaWRSZXF1ZXN0cywgZHJvcGRvd25Qb3NpdGlvbiwgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGFsbENoZWNrZWQgPVxyXG4gICAgICBmaWx0ZXJlZEJpZFJlcXVlc3RzLmxlbmd0aCA+IDAgJiZcclxuICAgICAgZmlsdGVyZWRCaWRSZXF1ZXN0cy5ldmVyeShcclxuICAgICAgICAoaXRlbSkgPT4gYWN0aXZlVXNlckRhdGFbaXRlbS5faWRdPy5pbmZvPy5zdGF0dXMsXHJcbiAgICAgICk7XHJcbiAgICBzZXRTZWxlY3RBbGwoYWxsQ2hlY2tlZCk7XHJcbiAgfSwgW2ZpbHRlcmVkQmlkUmVxdWVzdHMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4gIC8vIOKchSBGSVhFRDogQ2xpY2sgb3V0c2lkZSBoYW5kbGVyIHdpdGggcHJvcGVyIGNsYXNzIHJlZmVyZW5jZVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBoYW5kbGVDbGlja091dHNpZGUgPSAoZXZlbnQpID0+IHtcclxuICAgICAgLy8gQ2hlY2sgaWYgY2xpY2sgaXMgb3V0c2lkZSBkcm9wZG93biB0cmlnZ2VyIGFuZCBkcm9wZG93biBtZW51XHJcbiAgICAgIGlmIChcclxuICAgICAgICAhZXZlbnQudGFyZ2V0LmNsb3Nlc3QoXCIuZHJvcGRvd24tdHJpZ2dlclwiKSAmJlxyXG4gICAgICAgICFldmVudC50YXJnZXQuY2xvc2VzdChcIi5kcm9wZG93bi1tZW51XCIpXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldE9wZW5BY3Rpb25JZChudWxsKTtcclxuICAgICAgICBzZXRPcGVuU3RhdHVzSWQobnVsbCk7XHJcbiAgICAgICAgc2V0RHJvcGRvd25Qb3NpdGlvbih7IC4uLmRyb3Bkb3duUG9zaXRpb24sIHZpc2libGU6IGZhbHNlIH0pO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlZG93blwiLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZWRvd25cIiwgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcclxuICB9LCBbZHJvcGRvd25Qb3NpdGlvbl0pO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJiaWRfcmVxdWVzdF9jb2RlXCIsIGhlYWRlcjogXCJCaWQgUmVxdWVzdCBDb2RlXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlJlcXVlc3QgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uVGltZVwiLCBoZWFkZXI6IFwiUmVxdWVzdCBUaW1lXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJTdWJzY3JpYmVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVOdW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcklkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0TnVtYmVyXCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvbkRhdGVEaXNwbGF5XCIsIGhlYWRlcjogXCJBdWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRCeVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwic291cmNlXCIsIGhlYWRlcjogXCJUcmFjayBTb3VyY2VcIn0sXHJcbiAgICB7IGtleTogXCJhbW91bnRQYWlkVmFsdWVcIiwgaGVhZGVyOiBcIkFtb3VudCBQYWlkXCIgfSwgXHJcbiAgICAvLyB7IGtleTogXCJpbnN0YW5jZUJhbGFuY2VWYWx1ZVwiLCBoZWFkZXI6IFwiQmFsYW5jZSAoQXQgUmVxdWVzdClcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VycmVudEJhbGFuY2VWYWx1ZVwiLCBoZWFkZXI6IFwiQ3VycmVudCBCYWxhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcImNoZWNrQm94XCIsIGhlYWRlcjogXCJTZWxlY3RcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiwgd2lkdGg6IDE4MCB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGV4Y2VsY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYmlkX3JlcXVlc3RfY29kZVwiLCBoZWFkZXI6IFwiQmlkIFJlcXVlc3QgQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJSZXF1ZXN0IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvblRpbWVcIiwgaGVhZGVyOiBcIlJlcXVlc3QgVGltZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiU3Vic2NyaWJlciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lTnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldE51bWJlclwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25EYXRlRGlzcGxheVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkQnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcInNvdXJjZVwiLCBoZWFkZXI6IFwiVHJhY2sgU291cmNlXCJ9LFxyXG4gICAgIHsga2V5OiBcImFtb3VudFBhaWRWYWx1ZV9yYXdcIiwgaGVhZGVyOiBcIkFtb3VudCBQYWlkXCIgfSwgXHJcbiAgICB7IGtleTogXCJpbnN0YW5jZUJhbGFuY2VWYWx1ZV9yYXdcIiwgaGVhZGVyOiBcIkJhbGFuY2UgKEF0IFJlcXVlc3QpXCIgfSxcclxuICAgIHsga2V5OiBcImN1cnJlbnRCYWxhbmNlVmFsdWVfcmF3XCIsIGhlYWRlcjogXCJDdXJyZW50IEJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiwgd2lkdGg6IDE4MCB9LFxyXG4gIF07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEJpZFJlcXVlc3RzKCk7XHJcbiAgfSwgW3ZpZXdUeXBlXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuICAgICAgPE5hdmJhciAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1zY3JlZW4gbXQtMTRcIj5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHAtNCBtaW4taC1bODB2aF1cIj5cclxuICAgICAgICAgIHsvKiDinIUgU3RlcCA0OiBTdXBlciBBZG1pbiBTZXR0aW5ncyBQYW5lbCAqL31cclxuICAgICAgICAgIHtpc1N1cGVyQWRtaW4gJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1wdXJwbGUtNTAgdG8tYmx1ZS01MCByb3VuZGVkLWxnIHNoYWRvdyBwLTQgbWItNiBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBmbGV4LXdyYXAgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1wdXJwbGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1mdWxsIGgtMTAgdy0xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTYWZldHlPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlN1cGVyIEFkbWluIFNldHRpbmdzPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5Db25maWd1cmUgZmVhdHVyZSBwZXJtaXNzaW9uczwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNiBmbGV4LXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkJpZCBSZXF1ZXN0IEFjY2Vzczo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPFN3aXRjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cGVybWlzc2lvbnM/LmJpZF9yZXF1ZXN0IHx8IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2FzeW5jIChjaGVja2VkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgQVBJLnBvc3QoXCIvdXNlci91cGRhdGUtcGVybWlzc2lvbnNcIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmlkX3JlcXVlc3Q6IGNoZWNrZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQZXJtaXNzaW9ucyhwcmV2ID0+ICh7IC4uLnByZXYsIGJpZF9yZXF1ZXN0OiBjaGVja2VkIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoYEJpZCByZXF1ZXN0IGFjY2VzcyAke2NoZWNrZWQgPyAnZW5hYmxlZCcgOiAnZGlzYWJsZWQnfWApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIHBlcm1pc3Npb25zXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctcHVycGxlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBnYXAtNCBtYi04IG10LTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtZDp0ZXh0LWxlZnQgc3BhY2UteS0yIG1sLTRcIj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIEJpZCBNYW5hZ2VtZW50XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICBTdWJtaXQgYSBuZXcgYmlkIHJlcXVlc3QgZm9yIGFuIGF1Y3Rpb25cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImRlZmF1bHRcIlxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKFxyXG4gICAgICAgICAgICAgICAgICAgIFwiL3JlcG9ydHMvYmlkLXJlcXVlc3QtcmVwb3J0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJfYmxhbmtcIixcclxuICAgICAgICAgICAgICAgICAgICBcIm5vb3BlbmVyLG5vcmVmZXJyZXJcIixcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMCBweC02IHRleHQtbGcgZm9udC1zZW1pYm9sZCBiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCBzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICAgICAgaWNvbj17PEZpbGVUZXh0T3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgVmlldyBSZXBvcnRcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlT3BlbkNyZWF0ZVBhZ2V9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEwIHB4LTYgdGV4dC1sZyBmb250LXNlbWlib2xkIGJnLWJsdWUtODAwIGhvdmVyOmJnLWJsdWUtNzAwIHJvdW5kZWQtbWQgc2hhZG93LWxnXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICArIEJpZCBSZXF1ZXN0XHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8U2VhcmNoT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIFNlYXJjaCBGaWx0ZXJcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICBGaWx0ZXIgYmlkIHJlcXVlc3RzIGJ5IHN0YXR1cywgZ3JvdXAsIHBheW1lbnQsIG9yIGRhdGVcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7KHNlbGVjdGVkU3RhdHVzICE9PSBcImFsbFwiIHx8XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZEdyb3VwRmlsdGVyICE9PSBcImFsbFwiIHx8XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFBheW1lbnRTdGF0dXMgIT09IFwiYWxsXCIgfHxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZUZyb21EYXRlIHx8XHJcbiAgICAgICAgICAgICAgICBhY3RpdmVUb0RhdGUpICYmIChcclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJGaWx0ZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGJnLWJsdWUtNTAwIGhvdmVyOmJnLWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2xlYXIgQWxsIEZpbHRlcnNcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1lbmQgZ2FwLTVcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy1bMjgwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgRGF0ZSBSYW5nZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpbnB1dEZyb21EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRJbnB1dEZyb21EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIkRELU1NLVlZWVlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRnJvbSBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpbnB1dFRvRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0SW5wdXRUb0RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiREQtTU0tWVlZWVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUbyBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LVsxNTBweF1cIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBSZXF1ZXN0IFN0YXR1c1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkU3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRTdGF0dXN9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJhbGxcIj5BbGwgU3RhdHVzPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJQZW5kaW5nXCI+UGVuZGluZzwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiQWNjZXB0XCI+QWNjZXB0PC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJSZWplY3RcIj5SZWplY3RlZDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiTmV4dEF1Y3Rpb25cIj5OZXh0IEF1Y3Rpb248L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlByaXplZFwiPlByaXplZDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LVsxNTBweF1cIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBQYXltZW50IFN0YXR1c1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUGF5bWVudFN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkUGF5bWVudFN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cImFsbFwiPkFsbCBQYXltZW50czwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwicGVuZGluZ1wiPlBheW1lbnQgUGVuZGluZzwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwidXB0b2RhdGVcIj5VcCB0byBEYXRlPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJleGNlc3NcIj5FeGNlc3M8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy1bMTUwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgR3JvdXAgRmlsdGVyXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cEZpbHRlcn1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkR3JvdXBGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJhbGxcIj5BbGwgR3JvdXBzPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIHt1bmlxdWVHcm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXtncm91cH0gdmFsdWU9e2dyb3VwfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIG1pbi13LVsxMDBweF1cIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMSB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSBjdXJzb3ItcG9pbnRlciBhY2NlbnQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdEFsbH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoZWNrZWQgPSBlLnRhcmdldC5jaGVja2VkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0QWxsKGNoZWNrZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkQmlkUmVxdWVzdHMuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2VyT2JqZWN0ID0gaXRlbT8uc3Vic2NyaWJlcklkIHx8IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2VyTmFtZSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5zdWJzY3JpYmVyTmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICh0eXBlb2YgdXNlck9iamVjdCA9PT0gXCJvYmplY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB1c2VyT2JqZWN0LmZ1bGxfbmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXNlclBob25lID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLm1vYmlsZU51bWJlciB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICh0eXBlb2YgdXNlck9iamVjdCA9PT0gXCJvYmplY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB1c2VyT2JqZWN0LnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFtpdGVtLl9pZF0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaW5mbzogeyBzdGF0dXM6IGNoZWNrZWQsIHVzZXJOYW1lLCB1c2VyUGhvbmUgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEodXBkYXRlZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgaWNvbj17PFNlYXJjaE91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGF0ZVNlYXJjaH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBTZWFyY2hcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICBBdWN0aW9uIFdpbm5lclxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBwLTQgYm9yZGVyLWwtNCBib3JkZXItcHVycGxlLTUwMCBjdXJzb3ItcG9pbnRlciBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgJHtzZWxlY3RlZFN0YXR1cyA9PT0gXCJQcml6ZWRcIiA/IFwicmluZy0yIHJpbmctcHVycGxlLTUwMCBiZy1wdXJwbGUtNTBcIiA6IFwiXCJ9YH1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkU3RhdHVzKFxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkU3RhdHVzID09PSBcIlByaXplZFwiID8gXCJhbGxcIiA6IFwiUHJpemVkXCIsXHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPkJpZCBQcml6ZWQgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5U3RhdHMucHJpemVkUmVxdWVzdHMgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1wdXJwbGUtMTAwIHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUcm9waHlPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDAgdGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgQmlkIFJlcXVlc3Qnc1xyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTUgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBib3JkZXItbC00IGJvcmRlci1ibHVlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5Ub3RhbCBSZXF1ZXN0czwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5U3RhdHMudG90YWxSZXF1ZXN0c31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1ibHVlLTEwMCByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk05IDVIN2EyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJoMTBhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJoLTJNOSA1YTIgMiAwIDAwMiAyaDJhMiAyIDAgMDAyLTJNOSA1YTIgMiAwIDAxMi0yaDJhMiAyIDAgMDEyIDJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBwLTQgYm9yZGVyLWwtNCBib3JkZXIteWVsbG93LTUwMCBjdXJzb3ItcG9pbnRlciBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgJHtzZWxlY3RlZFN0YXR1cyA9PT0gXCJQZW5kaW5nXCIgPyBcInJpbmctMiByaW5nLXllbGxvdy01MDAgYmcteWVsbG93LTUwXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFN0YXR1cyhcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFN0YXR1cyA9PT0gXCJQZW5kaW5nXCIgPyBcImFsbFwiIDogXCJQZW5kaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlBlbmRpbmcgUmVxdWVzdHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQteWVsbG93LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3N1bW1hcnlTdGF0cy5wZW5kaW5nUmVxdWVzdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmcteWVsbG93LTEwMCByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2xvY2tDaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXllbGxvdy02MDAgdGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC00IGJvcmRlci1sLTQgYm9yZGVyLWdyZWVuLTUwMCBjdXJzb3ItcG9pbnRlciBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgJHtzZWxlY3RlZFN0YXR1cyA9PT0gXCJBY2NlcHRcIiA/IFwicmluZy0yIHJpbmctZ3JlZW4tNTAwIGJnLWdyZWVuLTUwXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFN0YXR1cyhcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFN0YXR1cyA9PT0gXCJBY2NlcHRcIiA/IFwiYWxsXCIgOiBcIkFjY2VwdFwiLFxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5BY2NlcHQgUmVxdWVzdHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c3VtbWFyeVN0YXRzLmFjY2VwdFJlcXVlc3RzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLWdyZWVuLTEwMCByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBwLTQgYm9yZGVyLWwtNCBib3JkZXItcmVkLTUwMCBjdXJzb3ItcG9pbnRlciBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgJHtzZWxlY3RlZFN0YXR1cyA9PT0gXCJSZWplY3RcIiA/IFwicmluZy0yIHJpbmctcmVkLTUwMCBiZy1yZWQtNTBcIiA6IFwiXCJ9YH1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkU3RhdHVzKFxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkU3RhdHVzID09PSBcIlJlamVjdFwiID8gXCJhbGxcIiA6IFwiUmVqZWN0XCIsXHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlJlamVjdGVkIFJlcXVlc3RzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5U3RhdHMucmVqZWN0UmVxdWVzdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctcmVkLTEwMCByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2xvc2VPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgdGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC00IGJvcmRlci1sLTQgYm9yZGVyLW9yYW5nZS01MDAgY3Vyc29yLXBvaW50ZXIgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsICR7c2VsZWN0ZWRTdGF0dXMgPT09IFwiTmV4dEF1Y3Rpb25cIiA/IFwicmluZy0yIHJpbmctb3JhbmdlLTUwMCBiZy1vcmFuZ2UtNTBcIiA6IFwiXCJ9YH1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkU3RhdHVzKFxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkU3RhdHVzID09PSBcIk5leHRBdWN0aW9uXCIgPyBcImFsbFwiIDogXCJOZXh0QXVjdGlvblwiLFxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFBvc3QgVG8gTmV4dCBBdWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5U3RhdHMubmV4dGF1Y3Rpb25SZXF1ZXN0c31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1vcmFuZ2UtMTAwIHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdG9wT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwIHRleHQteGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgIFBheW1lbnQgU3RhdHVzIE92ZXJ2aWV3e1wiIFwifVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTVcIj5cclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBheW1lbnRTdGF0dXMoXHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRQYXltZW50U3RhdHVzID09PSBcInBlbmRpbmdcIiA/IFwiYWxsXCIgOiBcInBlbmRpbmdcIixcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC0zIGJvcmRlci1sLTQgYm9yZGVyLXJvc2UtNTAwIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke3NlbGVjdGVkUGF5bWVudFN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgPyBcInJpbmctMiByaW5nLXJvc2UtNTAwIGJnLXJvc2UtNTBcIiA6IFwiXCJ9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IFBlbmRpbmdcclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtcm9zZS02MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c3VtbWFyeVN0YXRzPy5wYXltZW50U3RhdHM/LnBlbmRpbmc/LmNvdW50IHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctcm9zZS0xMDAgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPERvbGxhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcm9zZS02MDAgdGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQYXltZW50U3RhdHVzKFxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkUGF5bWVudFN0YXR1cyA9PT0gXCJ1cHRvZGF0ZVwiID8gXCJhbGxcIiA6IFwidXB0b2RhdGVcIixcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC0zIGJvcmRlci1sLTQgYm9yZGVyLXRlYWwtNTAwIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke3NlbGVjdGVkUGF5bWVudFN0YXR1cyA9PT0gXCJ1cHRvZGF0ZVwiID8gXCJyaW5nLTIgcmluZy10ZWFsLTUwMCBiZy10ZWFsLTUwXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVXAgVG8gRGF0ZSAmIEV4Y2Vzc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC10ZWFsLTYwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5U3RhdHM/LnBheW1lbnRTdGF0cz8udXBUb0RhdGU/LmNvdW50IHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctdGVhbC0xMDAgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNhZmV0eU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDAgdGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge3N1bW1hcnlTdGF0cz8uZ3JvdXBTdGF0cyAmJlxyXG4gICAgICAgICAgICBPYmplY3Qua2V5cyhzdW1tYXJ5U3RhdHMuZ3JvdXBTdGF0cyB8fCB7fSkubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNHcm91cFN0YXRzT3BlbighaXNHcm91cFN0YXRzT3Blbil9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIG1yLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwLXdpc2UgU3RhdGlzdGljc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwLTEgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXNHcm91cFN0YXRzT3BlbiA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFVwT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RG93bk91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctZ3JheS0xMDAgcC0xIHJvdW5kZWQtbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIgcm91bmRlZCAke2dyb3VwVmlld01vZGUgPT09IFwiZ3JpZFwiID8gXCJiZy13aGl0ZSBzaGFkb3cgdGV4dC1ibHVlLTYwMFwiIDogXCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0R3JvdXBWaWV3TW9kZShcImdyaWRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEFwcHN0b3JlT3V0bGluZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIgcm91bmRlZCAke2dyb3VwVmlld01vZGUgPT09IFwibGlzdFwiID8gXCJiZy13aGl0ZSBzaGFkb3cgdGV4dC1ibHVlLTYwMFwiIDogXCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0R3JvdXBWaWV3TW9kZShcImxpc3RcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFVub3JkZXJlZExpc3RPdXRsaW5lZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge2lzR3JvdXBTdGF0c09wZW4gJiYgZ3JvdXBWaWV3TW9kZSA9PT0gXCJncmlkXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoc3VtbWFyeVN0YXRzLmdyb3VwU3RhdHMgfHwge30pLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAgIChbZ3JvdXBOYW1lLCBzdGF0c10pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Z3JvdXBOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIGJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUgdG8tZ3JheS01MCByb3VuZGVkLXhsIGJvcmRlci0yIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBjdXJzb3ItcG9pbnRlciBvdmVyZmxvdy1oaWRkZW4gJHtzZWxlY3RlZEdyb3VwRmlsdGVyID09PSBncm91cE5hbWUgPyBcImJvcmRlci1ibHVlLTUwMCBzaGFkb3ctbGcgc2hhZG93LWJsdWUtMTAwIGJnLWJsdWUtNTAvNTBcIiA6IFwiYm9yZGVyLWdyYXktMjAwIGhvdmVyOmJvcmRlci1ibHVlLTMwMCBob3ZlcjpzaGFkb3ctbWRcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEdyb3VwRmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEdyb3VwRmlsdGVyID09PSBncm91cE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGdyb3VwTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLTEuNSB3LWZ1bGwgJHtzZWxlY3RlZEdyb3VwRmlsdGVyID09PSBncm91cE5hbWUgPyBcImJnLWJsdWUtNTAwXCIgOiBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTQwMCB0by1wdXJwbGUtNDAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0cnVuY2F0ZSBtYXgtdy1bMTQwcHhdIHByLTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtncm91cE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkICR7c3RhdHMudG90YWwgPiA1ID8gXCJiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTcwMFwiIDogXCJiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNzAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsOiB7c3RhdHMudG90YWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTUgZ2FwLTEgbXQtMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xIHJvdW5kZWQgJHtzdGF0cy5wZW5kaW5nID4gMCA/IFwiYmcteWVsbG93LTUwXCIgOiBcImJnLWdyYXktNTBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LWJvbGQgJHtzdGF0cy5wZW5kaW5nID4gMCA/IFwidGV4dC15ZWxsb3ctNjAwXCIgOiBcInRleHQtZ3JheS00MDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0cy5wZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMSByb3VuZGVkICR7c3RhdHMuYWNjZXB0ID4gMCA/IFwiYmctZ3JlZW4tNTBcIiA6IFwiYmctZ3JheS01MFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtYm9sZCAke3N0YXRzLmFjY2VwdCA+IDAgPyBcInRleHQtZ3JlZW4tNjAwXCIgOiBcInRleHQtZ3JheS00MDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0cy5hY2NlcHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xIHJvdW5kZWQgJHtzdGF0cy5yZWplY3QgPiAwID8gXCJiZy1yZWQtNTBcIiA6IFwiYmctZ3JheS01MFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlamN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LWJvbGQgJHtzdGF0cy5yZWplY3QgPiAwID8gXCJ0ZXh0LXJlZC02MDBcIiA6IFwidGV4dC1ncmF5LTQwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRzLnJlamVjdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEgcm91bmRlZCAke3N0YXRzLnByaXplZCA+IDAgPyBcImJnLXB1cnBsZS01MFwiIDogXCJiZy1ncmF5LTUwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJ6ZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1ib2xkICR7c3RhdHMucHJpemVkID4gMCA/IFwidGV4dC1wdXJwbGUtNjAwXCIgOiBcInRleHQtZ3JheS00MDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0cy5wcml6ZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xIHJvdW5kZWQgJHtzdGF0cy5uZXh0YXVjdGlvbiA+IDAgPyBcImJnLW9yYW5nZS01MFwiIDogXCJiZy1ncmF5LTUwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTmV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1ib2xkICR7c3RhdHMubmV4dGF1Y3Rpb24gPiAwID8gXCJ0ZXh0LW9yYW5nZS02MDBcIiA6IFwidGV4dC1ncmF5LTQwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRzLm5leHRhdWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDbG9ja0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTmV4dCBBdWN0aW9uIERhdGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXhzIGZvbnQtYm9sZCBweC0yIHB5LTEgcm91bmRlZC1mdWxsICR7c3RhdHMubmV4dF9hdWN0aW9uX2Rpc3BsYXkgIT09IFwiTi9BXCIgPyBcImJnLWJsdWUtMTAwIHRleHQtYmx1ZS03MDBcIiA6IFwiYmctZ3JheS0xMDAgdGV4dC1ncmF5LTUwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRzLm5leHRfYXVjdGlvbl9kaXNwbGF5ICE9PSBcIk4vQVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gc3RhdHMubmV4dF9hdWN0aW9uX2Rpc3BsYXlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk5vdCBTY2hlZHVsZWRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7aXNHcm91cFN0YXRzT3BlbiAmJiBncm91cFZpZXdNb2RlID09PSBcImxpc3RcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWNlbnRlciB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtY2VudGVyIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGVuZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWNlbnRlciB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjY2VwdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWNlbnRlciB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlamVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWNlbnRlciB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaXplZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWNlbnRlciB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5leHQgQXVjdGlvbiBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhzdW1tYXJ5U3RhdHMuZ3JvdXBTdGF0cyB8fCB7fSkubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIChbZ3JvdXBOYW1lLCBzdGF0c10pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0clxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2dyb3VwTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtzZWxlY3RlZEdyb3VwRmlsdGVyID09PSBncm91cE5hbWUgPyBcImJnLWJsdWUtNTBcIiA6IFwiXCJ9IGhvdmVyOmJnLWdyYXktNTAgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkR3JvdXBGaWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEdyb3VwRmlsdGVyID09PSBncm91cE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgaW5saW5lLWZsZXggdGV4dC1zbSBmb250LWJvbGQgbGVhZGluZy01IHRleHQtYmx1ZS03MDAgYmctYmx1ZS0xMDAgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHMudG90YWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMSBpbmxpbmUtZmxleCB0ZXh0LXNtIGZvbnQtYm9sZCBsZWFkaW5nLTUgcm91bmRlZC1mdWxsICR7c3RhdHMucGVuZGluZyA+IDAgPyBcInRleHQteWVsbG93LTcwMCBiZy15ZWxsb3ctMTAwXCIgOiBcInRleHQtZ3JheS01MDAgYmctZ3JheS0xMDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0cy5wZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEgaW5saW5lLWZsZXggdGV4dC1zbSBmb250LWJvbGQgbGVhZGluZy01IHJvdW5kZWQtZnVsbCAke3N0YXRzLmFjY2VwdCA+IDAgPyBcInRleHQtZ3JlZW4tNzAwIGJnLWdyZWVuLTEwMFwiIDogXCJ0ZXh0LWdyYXktNTAwIGJnLWdyYXktMTAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHMuYWNjZXB0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEgaW5saW5lLWZsZXggdGV4dC1zbSBmb250LWJvbGQgbGVhZGluZy01IHJvdW5kZWQtZnVsbCAke3N0YXRzLnJlamVjdCA+IDAgPyBcInRleHQtcmVkLTcwMCBiZy1yZWQtMTAwXCIgOiBcInRleHQtZ3JheS01MDAgYmctZ3JheS0xMDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0cy5yZWplY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMSBpbmxpbmUtZmxleCB0ZXh0LXNtIGZvbnQtYm9sZCBsZWFkaW5nLTUgcm91bmRlZC1mdWxsICR7c3RhdHMucHJpemVkID4gMCA/IFwidGV4dC1wdXJwbGUtNzAwIGJnLXB1cnBsZS0xMDBcIiA6IFwidGV4dC1ncmF5LTUwMCBiZy1ncmF5LTEwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRzLnByaXplZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHMubmV4dF9hdWN0aW9uX2Rpc3BsYXkgIT09IFwiTi9BXCIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgaW5saW5lLWZsZXggdGV4dC1zbSBmb250LXNlbWlib2xkIGxlYWRpbmctNSB0ZXh0LWJsdWUtNzAwIGJnLWJsdWUtNTAgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItYmx1ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRzLm5leHRfYXVjdGlvbl9kaXNwbGF5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gdXBjb21pbmcgYXVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7c2VsZWN0ZWRDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwIHRvLWluZGlnby01MCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBtYi02IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWZ1bGwgaC0xMCB3LTEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LWxnIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZENvdW50fVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICBJdGVtcyBTZWxlY3RlZFxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTMganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICBpY29uPXs8V2hhdHNBcHBPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyZWVuLTYwMCBob3ZlcjpiZy1ncmVlbi03MDAgYm9yZGVyLWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlT3BlblZlcmlmeU1vZGFsfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VuZCBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tNzAwIGJvcmRlci1ncmVlbi0yMDAgaG92ZXI6YmctZ3JlZW4tMjAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUJ1bGtTdGF0dXNVcGRhdGUoXCJBY2NlcHRcIil9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBBY2NlcHQgQWxsXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTcwMCBib3JkZXItcHVycGxlLTIwMCBob3ZlcjpiZy1wdXJwbGUtMjAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGljb249ezxUcm9waHlPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVCdWxrU3RhdHVzVXBkYXRlKFwiUHJpemVkXCIpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTWFyayBhcyBQcml6ZWRcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXJlZC0xMDAgdGV4dC1yZWQtNzAwIGJvcmRlci1yZWQtMjAwIGhvdmVyOmJnLXJlZC0yMDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQnVsa1N0YXR1c1VwZGF0ZShcIlJlamVjdFwiKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgUmVqZWN0ZWQgQWxsXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTcwMCBib3JkZXIteWVsbG93LTIwMCBob3ZlcjpiZy15ZWxsb3ctMjAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUJ1bGtTdGF0dXNVcGRhdGUoXCJQZW5kaW5nXCIpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTWFyayBQZW5kaW5nXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtMTAwIHRleHQtb3JhbmdlLTcwMCBib3JkZXItb3JhbmdlLTIwMCBob3ZlcjpiZy1vcmFuZ2UtMjAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUJ1bGtTdGF0dXNVcGRhdGUoXCJOZXh0QXVjdGlvblwiKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBvc3QgdG8gTmV4dCBhdWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBtaW4taC1bNDAwcHhdXCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgb3ZlcmZsb3c6IFwidmlzaWJsZVwiIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtsb2FkaW5nVGFibGUgPyAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuICAgICAgICAgICAgKSA6IGZpbHRlcmVkQmlkUmVxdWVzdHMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e3RydWV9XHJcbiAgICAgICAgICAgICAgICBkYXRhPVwiQmlkIFJlcXVlc3RzXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGRhdGE9e2Zvcm1hdHRlZEJpZERhdGF9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0Q29scz17ZXhjZWxjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkJpZCBSZXF1ZXN0cy5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQmlkIFJlcXVlc3RzXCJcclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIFJlcXVlc3RzXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgQmFsYW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlBlbmRpbmcgUmVxdWVzdHNcIixcclxuICAgICAgICAgICAgICAgICAgXCJBY2NlcHQgUmVxdWVzdHNcIixcclxuICAgICAgICAgICAgICAgICAgXCJSZWplY3QgUmVxdWVzdHNcIixcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgICAgICAgICAgICAgICBzdW1tYXJ5U3RhdHMudG90YWxSZXF1ZXN0cy50b1N0cmluZygpLFxyXG4gICAgICAgICAgICAgICAgICBg4oK5ICR7c3VtbWFyeVN0YXRzLnRvdGFsQmFsYW5jZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICAgICAgICAgIHN1bW1hcnlTdGF0cy5wZW5kaW5nUmVxdWVzdHMudG9TdHJpbmcoKSxcclxuICAgICAgICAgICAgICAgICAgc3VtbWFyeVN0YXRzLmFjY2VwdFJlcXVlc3RzLnRvU3RyaW5nKCksXHJcbiAgICAgICAgICAgICAgICAgIHN1bW1hcnlTdGF0cy5yZWplY3RSZXF1ZXN0cy50b1N0cmluZygpLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2Ryb3Bkb3duUG9zaXRpb24udmlzaWJsZSAmJiBkcm9wZG93blBvc2l0aW9uLml0ZW0gJiYgKFxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZHJvcGRvd24tbWVudSBiZy13aGl0ZSBib3JkZXIgcm91bmRlZC1sZyBzaGFkb3ctbGcgdy00MFwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBcImZpeGVkXCIsXHJcbiAgICAgICAgICAgICAgICB6SW5kZXg6IDk5OTksXHJcbiAgICAgICAgICAgICAgICBsZWZ0OiBgJHtkcm9wZG93blBvc2l0aW9uLnh9cHhgLFxyXG4gICAgICAgICAgICAgICAgdG9wOiBgJHtkcm9wZG93blBvc2l0aW9uLnl9cHhgLFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRPcGVuU3RhdHVzSWQoXHJcbiAgICAgICAgICAgICAgICAgICAgICBvcGVuU3RhdHVzSWQgPT09IGRyb3Bkb3duUG9zaXRpb24uaXRlbS5faWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBudWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogZHJvcGRvd25Qb3NpdGlvbi5pdGVtLl9pZCxcclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgcHgtNCBweS0yIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtcHVycGxlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxSaXNlT3V0bGluZWQgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+Q2hhbmdlIFN0YXR1czwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtYXV0byB0ZXh0LXhzXCI+4pa2PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICB7b3BlblN0YXR1c0lkID09PSBkcm9wZG93blBvc2l0aW9uLml0ZW0uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LWZ1bGwgdG9wLTAgbXItMiBiZy13aGl0ZSBib3JkZXIgcm91bmRlZC1sZyBzaGFkb3ctbGcgdy00MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgekluZGV4OiAxMDAwMCB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlU2luZ2xlU3RhdHVzVXBkYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRyb3Bkb3duUG9zaXRpb24uaXRlbS5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJQZW5kaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldERyb3Bkb3duUG9zaXRpb24oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmRyb3Bkb3duUG9zaXRpb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJsZTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHctZnVsbCBweC00IHB5LTIgaG92ZXI6YmcteWVsbG93LTUwIHRleHQteWVsbG93LTcwMCBib3JkZXItYiBib3JkZXItZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDbG9ja0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQteWVsbG93LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QZW5kaW5nPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVNpbmdsZVN0YXR1c1VwZGF0ZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkcm9wZG93blBvc2l0aW9uLml0ZW0uX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiQWNjZXB0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldERyb3Bkb3duUG9zaXRpb24oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmRyb3Bkb3duUG9zaXRpb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJsZTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHctZnVsbCBweC00IHB5LTIgaG92ZXI6YmctZ3JlZW4tNTAgdGV4dC1ncmVlbi03MDAgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BY2NlcHQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlU2luZ2xlU3RhdHVzVXBkYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRyb3Bkb3duUG9zaXRpb24uaXRlbS5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJQcml6ZWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RHJvcGRvd25Qb3NpdGlvbih7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZHJvcGRvd25Qb3NpdGlvbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aXNpYmxlOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIHB4LTQgcHktMiBob3ZlcjpiZy1wdXJwbGUtNTAgdGV4dC1wdXJwbGUtNzAwIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRyb3BoeU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Qcml6ZWQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlU2luZ2xlU3RhdHVzVXBkYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRyb3Bkb3duUG9zaXRpb24uaXRlbS5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJSZWplY3RcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RHJvcGRvd25Qb3NpdGlvbih7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZHJvcGRvd25Qb3NpdGlvbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aXNpYmxlOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIHB4LTQgcHktMiBob3ZlcjpiZy1yZWQtNTAgdGV4dC1yZWQtNzAwIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENsb3NlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlamVjdDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVTaW5nbGVTdGF0dXNVcGRhdGUoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZHJvcGRvd25Qb3NpdGlvbi5pdGVtLl9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIk5leHRBdWN0aW9uXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldERyb3Bkb3duUG9zaXRpb24oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmRyb3Bkb3duUG9zaXRpb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJsZTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHctZnVsbCBweC00IHB5LTIgaG92ZXI6Ymctb3JhbmdlLTUwIHRleHQtb3JhbmdlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFN0b3BPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+TmV4dCBBdWN0aW9uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlT3BlbkVkaXRNb2RhbChkcm9wZG93blBvc2l0aW9uLml0ZW0pO1xyXG4gICAgICAgICAgICAgICAgICBzZXREcm9wZG93blBvc2l0aW9uKHsgLi4uZHJvcGRvd25Qb3NpdGlvbiwgdmlzaWJsZTogZmFsc2UgfSk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIHB4LTQgcHktMiBob3ZlcjpiZy1ncmF5LTEwMCB0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8RWRpdE91dGxpbmVkIC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5FZGl0PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZVNoYXJlKGRyb3Bkb3duUG9zaXRpb24uaXRlbSk7XHJcbiAgICAgICAgICAgICAgICAgIHNldERyb3Bkb3duUG9zaXRpb24oeyAuLi5kcm9wZG93blBvc2l0aW9uLCB2aXNpYmxlOiBmYWxzZSB9KTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgcHgtNCBweS0yIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtb3JhbmdlLTYwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNoYXJlQWx0T3V0bGluZWQgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlNoYXJlPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZVByaW50KGRyb3Bkb3duUG9zaXRpb24uaXRlbSk7XHJcbiAgICAgICAgICAgICAgICAgIHNldERyb3Bkb3duUG9zaXRpb24oeyAuLi5kcm9wZG93blBvc2l0aW9uLCB2aXNpYmxlOiBmYWxzZSB9KTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgcHgtNCBweS0yIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8UHJpbnRlck91dGxpbmVkIC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5QcmludDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICBjb25maXJtRGVsZXRlKGRyb3Bkb3duUG9zaXRpb24uaXRlbS5faWQpO1xyXG4gICAgICAgICAgICAgICAgICBzZXREcm9wZG93blBvc2l0aW9uKHsgLi4uZHJvcGRvd25Qb3NpdGlvbiwgdmlzaWJsZTogZmFsc2UgfSk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIHB4LTQgcHktMiBob3ZlcjpiZy1ncmF5LTEwMCB0ZXh0LXJlZC02MDAgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8RGVsZXRlT3V0bGluZWQgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkRlbGV0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxNb2RhbENvbXBvbmVudFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e2lzRWRpdE1vZGFsT3Blbn1cclxuICAgICAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2VFZGl0TW9kYWx9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LTZ4bCBiZy13aGl0ZSBzaGFkb3ctaW5uZXIgZm9udC1zYW5zIHRleHQtc20gdGV4dC1ncmF5LTgwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYi0yIGJvcmRlci1ibHVlLTkwMCBwLTYgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IEJpZCBSZXF1ZXN0XHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxGb3JtIGZvcm09e2VkaXRGb3JtfSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIGNsYXNzTmFtZT1cInB4LThcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmx1ZS05MDAgbWItMyBib3JkZXItYiBwYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU3Vic2NyaWJlciBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCBiZy1ncmF5LTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cInN1YnNjcmliZXJJZFwiIGhpZGRlbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dCAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQmlkIFJlcXVlc3QgQ29kZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImJpZF9yZXF1ZXN0X2NvZGVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDcmVhdGVkIEJ5IChBZG1pbilcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJhZG1pbk5hbWVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTdWJzY3JpYmVyIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJzdWJzY3JpYmVyTmFtZVwiIGNsYXNzTmFtZT1cIm1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXItZ3JheS0zMDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE1vYmlsZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJtb2JpbGVOdW1iZXJcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBJRFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImN1c3RvbWVySWRcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICB7ZWRpdEdyb3Vwcy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBHcm91cCBmb3IgQmlkIFJlcXVlc3R7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2VsZWN0ZWRHcm91cEluZGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUmVxdWlyZWQhXCIgfV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNob29zZSB3aGljaCBncm91cC4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRWRpdEdyb3VwU2VsZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRWRpdEdyb3VwSW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZWRpdEdyb3Vwcy5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIGtleT17Z3JvdXAuaWR9IHZhbHVlPXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwTmFtZX0gKFRpY2tldDoge2dyb3VwLnRpY2tldE51bWJlcn0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgU3RhcnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwic3RhcnREYXRlXCIgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgYm9yZGVyLWJsdWUtMjAwIHRleHQtYmx1ZS05MDAgZm9udC1zZW1pYm9sZCBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgRW5kIERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImVuZERhdGVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBib3JkZXItYmx1ZS0yMDAgdGV4dC1ibHVlLTkwMCBmb250LXNlbWlib2xkIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9ucyBEb25lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJhdWN0aW9uc0RvbmVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAgYm9yZGVyLWdyZWVuLTIwMCB0ZXh0LWdyZWVuLTkwMCBmb250LWJvbGQgdGV4dC1jZW50ZXIgaC0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpY2tldCBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cInRpY2tldE51bWJlclwiIGNsYXNzTmFtZT1cIm1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXItZ3JheS0zMDAgZm9udC1zZW1pYm9sZCBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJncm91cE5hbWVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGQgaC0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTQgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTcGluIHNpemU9XCJsYXJnZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmx1ZS05MDAgbWItMyBib3JkZXItYiBwYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQXVjdGlvbiBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQXVjdGlvbiBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYXVjdGlvbkRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUmVxdWlyZWQhXCIgfV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1ncmF5LTQwMCBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtYXQ9XCJERC1NTS1ZWVlZXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUmVxdWVzdCBUaW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYXVjdGlvblRpbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUmVxdWlyZWQhXCIgfV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGltZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1ncmF5LTQwMCBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtYXQ9XCJoOm1tIEFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVzZTEySG91cnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUmVxdWVzdCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwicmVxdWVzdERhdGVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWdyYXktNDAwIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIkRELU1NLVlZWVlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctZ3JheS01MCBib3JkZXIgcm91bmRlZC1sZyBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ3VycmVudCBEdWUgQmFsYW5jZTpcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvbnQtYm9sZCB0ZXh0LTJ4bCAke2N1c3RvbWVyQmFsYW5jZSA8PSAwID8gXCJ0ZXh0LWdyZWVuLTYwMFwiIDogXCJ0ZXh0LXJlZC02MDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lckJhbGFuY2UgIT09IG51bGxcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBg4oK5ICR7Y3VzdG9tZXJCYWxhbmNlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiTG9hZGluZy4uLlwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImVucm9sbG1lbnRJZFwiIGhpZGRlbj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0IC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImdyb3VwSWRcIiBoaWRkZW4+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwIG1iLTMgYm9yZGVyLWIgcGItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFVwZGF0ZSBTdGF0dXNcclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy02IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBvcGNvbmZpcm1cclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU2V0IHRvIFBlbmRpbmc/XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17aGFuZGxlU2V0UGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRlZmF1bHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTE0IGZvbnQtYm9sZCBib3JkZXIteWVsbG93LTUwMCB0ZXh0LXllbGxvdy02MDAgaG92ZXI6YmcteWVsbG93LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PENsb2NrQ2lyY2xlT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0R3JvdXBzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGVuZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qb3Bjb25maXJtPlxyXG4gICAgICAgICAgICAgICAgICAgIDxQb3Bjb25maXJtXHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkFwcHJvdmUgUmVxdWVzdD9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25Db25maXJtPXtoYW5kbGVTZXRBY2NlcHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBva1RleHQ9XCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2FuY2VsVGV4dD1cIk5vXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2VkaXRHcm91cHMubGVuZ3RoID09PSAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTE0IGZvbnQtYm9sZCBiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwIGJvcmRlci1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8Q2hlY2tDaXJjbGVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWNjZXB0XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBvcGNvbmZpcm1cclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTWFyayBhcyBQcml6ZWQ/XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17aGFuZGxlU2V0UHJpemVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb2tUZXh0PVwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbFRleHQ9XCJOb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0R3JvdXBzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCBmb250LWJvbGQgYmctcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtNzAwIGJvcmRlci1wdXJwbGUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PFRyb3BoeU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQcml6ZWRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUG9wY29uZmlybT5cclxuICAgICAgICAgICAgICAgICAgICA8UG9wY29uZmlybVxyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZWplY3QgUmVxdWVzdD9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25Db25maXJtPXtoYW5kbGVTZXRSZWplY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICBva1RleHQ9XCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2FuY2VsVGV4dD1cIk5vXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGFuZ2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTQgZm9udC1ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PENsb3NlT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0R3JvdXBzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUmVqZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBvcGNvbmZpcm1cclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUG9zdCB0byBuZXh0IGF1Y3Rpb24/XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17aGFuZGxlU2V0TmV4dGF1Y3Rpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICBva1RleHQ9XCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2FuY2VsVGV4dD1cIk5vXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGFuZ2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTQgZm9udC1ib2xkIGJnLW9yYW5nZS02MDAgaG92ZXI6Ymctb3JhbmdlLTcwMCBib3JkZXItb3JhbmdlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxTdG9wT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0R3JvdXBzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTmV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQXVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qb3Bjb25maXJtPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsb3NlRWRpdE1vZGFsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCBmb250LXNlbWlib2xkIGJvcmRlci1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvRm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L01vZGFsQ29tcG9uZW50PlxyXG5cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICB2aXNpYmxlPXtpc1ZlcmlmeU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgb25DYW5jZWw9e2hhbmRsZUNsb3NlVmVyaWZ5TW9kYWx9XHJcbiAgICAgICAgICAgIGZvb3Rlcj17bnVsbH1cclxuICAgICAgICAgICAgY2VudGVyZWRcclxuICAgICAgICAgICAgd2lkdGg9ezUwMH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtMTAwIHJvdW5kZWQtZnVsbCBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC00eGwgdGV4dC1yZWQtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBBcmUgWW91IFN1cmU/XHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgIFlvdSBhcmUgYWJvdXQgdG8gc2VuZCBXaGF0c0FwcCBtZXNzYWdlcyB0b3tcIiBcIn1cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZENvdW50fSBjb250YWN0c1xyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgLlxyXG4gICAgICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lIG9uY2UgaW5pdGlhdGVkLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2VWZXJpZnlNb2RhbH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zMlwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgbG9hZGluZz17aXNTZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTZW5kV2hhdHNBcHB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMzIgYmctZ3JlZW4tNjAwIGhvdmVyOmJnLWdyZWVuLTcwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFllcywgU2VuZFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCaWRSZXF1ZXN0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQmlkUmVxdWVzdC5qc3gifQ==