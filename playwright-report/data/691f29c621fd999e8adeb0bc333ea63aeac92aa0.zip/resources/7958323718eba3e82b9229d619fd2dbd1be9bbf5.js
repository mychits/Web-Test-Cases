import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PaymentReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import { MdDelete } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { CiEdit } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import { BsEye } from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import UploadModal from "/src/components/modals/UploadModal.jsx";
import axios from "/node_modules/.vite/deps/axios.js?v=819e0a34";
import url from "/src/data/Url.js";
import {
  Select,
  Dropdown,
  Input,
  Tag,
  Card,
  Statistic,
  Row,
  Col,
  Empty,
  Typography,
  Divider,
  Spin
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const { Text, Title } = Typography;
import {
  ArrowUpOutlined,
  ArrowDownOutlined,
  WalletOutlined,
  GlobalOutlined,
  LinkOutlined,
  SafetyCertificateOutlined,
  BankOutlined,
  ThunderboltOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import EndlessCircularLoader from "/src/components/loaders/EndlessCircularLoader.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const PaymentReport = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableDaybook, setTableDaybook] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [receiptNo, setReceiptNo] = useState("");
  const [paymentMode, setPaymentMode] = useState("cash");
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showFilterField, setShowFilterField] = useState(false);
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const now = /* @__PURE__ */ new Date();
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const todayString = now.toISOString().split("T")[0];
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedDate, setSelectedDate] = useState(todayString);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState([]);
  const [hideAccountType, setHideAccountType] = useState("");
  const [selectedAccountType, setSelectedAccountType] = useState("");
  const [selectedCustomers, setSelectedCustomers] = useState("");
  const [payments, setPayments] = useState([]);
  const [selectedPaymentFor, setSelectedPaymentFor] = useState([]);
  const [collectionAgent, setCollectionAgent] = useState("");
  const [collectionAdmin, setCollectionAdmin] = useState("");
  const [agents, setAgents] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [totals, setTotals] = useState({ in: 0, out: 0, net: 0 });
  const [modeTotals, setModeTotals] = useState({
    cash: 0,
    online: 0,
    link: 0,
    autopay: 0
  });
  const [overviewLoading, setOverviewLoading] = useState(true);
  const [categoryLoading, setCategoryLoading] = useState(true);
  const [modeLoading, setModeLoading] = useState(true);
  const [showAllPaymentModes, setShowAllPaymentModes] = useState(false);
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    ticket: "",
    receipt_no: "",
    pay_date: "",
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    collected_by: collectionAgent,
    admin_type: collectionAdmin,
    collection_time: ""
  });
  const [categoryTotals, setCategoryTotals] = useState({
    chit: 0,
    loan: 0,
    pigme: 0,
    registration: 0
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const handleModalClose = () => setShowUploadModal(false);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const showPaymentsModes = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setShowAllPaymentModes(showPaymentsModes);
    }
  }, []);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const isModify = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setHideAccountType(isModify);
    }
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    (async () => {
      try {
        const [employees, admins2] = await Promise.all(
          [
            api.get("/employee"),
            api.get("/admin/get-sub-admins")
          ]
        );
        const emps = employees?.data?.employee.map((emp) => ({
          _id: emp._id,
          full_name: emp.name,
          phone_number: emp.phone_number,
          selected_type: "agent_type"
        }));
        setAgents(emps);
        const adms = admins2?.data?.map((ad) => ({
          _id: ad?._id,
          full_name: ad?.name,
          phone_number: ad?.phoneNumber,
          selected_type: "admin_type"
        }));
        setAdmins(adms);
      } catch (error) {
        setAdmins([]);
        setAgents([]);
      }
    })();
  }, []);
  useEffect(() => {
    const fetchReceipt = async () => {
      try {
        const response = await api.get("/payment/get-latest-receipt");
        setReceiptNo(response.data);
      } catch (error) {
        console.error("Error fetching receipt data:", error);
      }
    };
    fetchReceipt();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setFilteredUsers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    if (receiptNo) {
      setFormData((prevData) => ({
        ...prevData,
        receipt_no: receiptNo.receipt_no
      }));
    }
  }, [receiptNo]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleChangeUser = (e) => {
    const { name, value } = e.target;
    const [user_id, ticket] = value.split("-");
    setFormData((prevData) => ({
      ...prevData,
      user_id,
      ticket
    }));
  };
  const handleGroup = async (event) => {
    const groupId = event.target.value;
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      group_id: groupId
    }));
    handleGroupChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        console.error("Error fetching group data:", error);
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const groupOptions = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
  };
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  const formatPayDate = (dateString) => {
    const date = new Date(dateString);
    const options = { day: "numeric", month: "long", year: "numeric" };
    return date.toLocaleDateString("en-US", options).replace(",", "");
  };
  let paymentModes = [...selectedPaymentMode];
  if (paymentModes.includes("online") && !paymentModes.includes("cheque")) {
    paymentModes.push("cheque");
  }
  useEffect(
    () => {
      const abortController = new AbortController();
      const fetchPayments = async () => {
        try {
          setIsLoading(true);
          setOverviewLoading(true);
          setCategoryLoading(true);
          setModeLoading(true);
          const response = await api.get(`/payment/get-receipt-report`, {
            params: {
              from_date: selectedFromDate,
              to_date: selectedDate,
              groupId: selectedAuctionGroupId,
              userId: selectedCustomers,
              pay_type: paymentModes,
              account_type: selectedAccountType,
              collected_by: collectionAgent,
              admin_type: collectionAdmin,
              pay_for: selectedPaymentFor
            },
            signal: abortController.signal
          });
          console.info(response.data, "testing account type");
          if (response.data && response.data.length > 0) {
            const validPayments = response.data.filter(
              (payment) => payment.group_id !== null
            );
            setFilteredAuction(validPayments);
            const totalAmount = validPayments.reduce(
              (sum, payment) => sum + Number(payment.amount || 0),
              0
            );
            console.info(totalAmount, "check amount");
            setPayments(totalAmount);
            if (response.data) {
              let tin = 0, tout = 0;
              let cash = 0;
              let online = 0;
              let link = 0;
              let autopay = 0;
              const formattedData = validPayments.map((group, index) => {
                const amt = Number(group.amount || 0);
                if (group.type === "IN") tin += amt;
                else
                  tout += Math.abs(amt);
                return {
                  _id: group?._id,
                  id: index + 1,
                  // ✅ TYPE COLUMN ADDED
                  type: /* @__PURE__ */ jsxDEV(Tag, { color: group?.type === "IN" ? "green" : "volcano", children: group?.type ?? "Unknown" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 445,
                    columnNumber: 17
                  }, this),
                  type_raw: group?.type,
                  date: group?.pay_date,
                  group: group?.group_id?.group_name || group.pay_for,
                  name: group?.user_id?.full_name,
                  category: group?.pay_for || "Chit",
                  phone_number: group?.user_id?.phone_number,
                  receipt_no: group?.receipt_no,
                  old_receipt_no: group?.old_receipt_no,
                  ticket: group?.loan?.loan_id ?? group?.pigme?.pigme_id ?? group?.ticket,
                  amount: /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: group?.type === "IN" ? "text-green-600 font-bold" : "text-red-600 font-bold",
                      children: [
                        "₹ ",
                        Math.abs(amt).toLocaleString("en-IN")
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                      lineNumber: 465,
                      columnNumber: 17
                    },
                    this
                  ),
                  amount_raw: amt,
                  transaction_date: group?.createdAt?.split("T")?.[0],
                  mode: group?.pay_type,
                  account_type: group?.account_type,
                  collection_time: group?.collection_time,
                  collected_by: group?.collected_by?.name || group?.admin_type?.admin_name || "Super Admin",
                  action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                    Dropdown,
                    {
                      trigger: ["click"],
                      menu: {
                        items: [
                          {
                            key: "1",
                            label: /* @__PURE__ */ jsxDEV(
                              Link,
                              {
                                target: "_blank",
                                to: `/print/${group._id}`,
                                className: "text-blue-600",
                                children: "Print"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                                lineNumber: 496,
                                columnNumber: 25
                              },
                              this
                            )
                          }
                        ]
                      },
                      placement: "bottomLeft",
                      children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                        lineNumber: 509,
                        columnNumber: 23
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                      lineNumber: 489,
                      columnNumber: 21
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 488,
                    columnNumber: 17
                  }, this)
                };
              });
              let chit = 0, loan = 0, pigme = 0, registration = 0;
              response.data.forEach((item) => {
                if (item.type !== "IN") return;
                const amt = Number(item.amount || 0);
                const pf = (item.pay_for || "Chit").toLowerCase();
                if (pf.includes("loan")) loan += amt;
                else if (pf.includes("pigme")) pigme += amt;
                else if (pf.includes("reg")) registration += amt;
                else
                  chit += amt;
              });
              response.data.forEach((item) => {
                const amt = Number(item.amount || 0);
                if (item.type !== "IN") return;
                const mode = (item.pay_type || "").toLowerCase();
                if (mode === "autopay" || mode === "online/autopay" || mode.includes("autopay")) {
                  autopay += amt;
                } else if (mode === "cash") {
                  cash += amt;
                } else if (mode === "online" || mode === "cheque") {
                  online += amt;
                } else if (mode.includes("link")) {
                  link += amt;
                }
              });
              setCategoryTotals({
                chit,
                loan,
                pigme,
                registration
              });
              setTotals({ in: tin, out: tout, net: tin - tout });
              setModeTotals({
                cash,
                online,
                link,
                autopay
              });
              setTableDaybook(formattedData);
            }
          } else {
            setFilteredAuction([]);
            setTableDaybook([]);
            setPayments(0);
            setTotals({
              in: 0,
              out: 0,
              net: 0
            });
            setCategoryTotals({
              chit: 0,
              loan: 0,
              pigme: 0,
              registration: 0
            });
            setModeTotals({
              cash: 0,
              online: 0,
              link: 0,
              autopay: 0
            });
          }
        } catch (error) {
          console.error("Error fetching payment data:", error);
          console.error(error);
          setFilteredAuction([]);
          setTableDaybook([]);
          setPayments(0);
          setTotals({
            in: 0,
            out: 0,
            net: 0
          });
          setCategoryTotals({
            chit: 0,
            loan: 0,
            pigme: 0,
            registration: 0
          });
          setModeTotals({
            cash: 0,
            online: 0,
            link: 0,
            autopay: 0
          });
        } finally {
          setIsLoading(false);
          setOverviewLoading(false);
          setCategoryLoading(false);
          setModeLoading(false);
        }
      };
      fetchPayments();
      return () => {
        abortController.abort();
      };
    },
    [
      selectedAuctionGroupId,
      selectedDate,
      selectedPaymentMode,
      selectedCustomers,
      selectedFromDate,
      selectedAccountType,
      collectionAgent,
      collectionAdmin,
      selectedPaymentFor
    ]
  );
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "group", header: "Group Name" },
    { key: "name", header: "Customer Name" },
    {
      key: "type",
      header: "Type"
    },
    { key: "category", header: "Category" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "receipt_no", header: "Receipt Number" },
    { key: "old_receipt_no", header: "Old Receipt" },
    { key: "ticket", header: "Ticket" },
    { key: "amount", header: "Amount" },
    { key: "mode", header: "Payment Mode" },
    ...hideAccountType ? [{ key: "account_type", header: "Account Type" }] : [],
    { key: "collection_time", header: "Collection Time" },
    { key: "collected_by", header: "Collected By" },
    { key: "action", header: "Action" }
  ];
  const exportCols = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "group", header: "Group Name" },
    { key: "name", header: "Customer Name" },
    {
      key: "type_raw",
      header: "Type"
    },
    { key: "category", header: "Category" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "receipt_no", header: "Receipt Number" },
    { key: "old_receipt_no", header: "Old Receipt" },
    { key: "ticket", header: "Ticket" },
    { key: "amount_raw", header: "Amount" },
    { key: "mode", header: "Payment Mode" },
    ...hideAccountType ? [{ key: "account_type", header: "Account Type" }] : [],
    { key: "collection_time", header: "Collection Time" },
    { key: "collected_by", header: "Collected By" },
    { key: "action", header: "Action" }
  ];
  useEffect(() => {
    if (groupInfo && formData.bid_amount) {
      const commission = groupInfo.group_value * 5 / 100 || 0;
      const win_amount = (groupInfo.group_value || 0) - (formData.bid_amount || 0);
      const divident = (formData.bid_amount || 0) - commission;
      const divident_head = groupInfo.group_members ? divident / groupInfo.group_members : 0;
      const payable = (groupInfo.group_install || 0) - divident_head;
      setFormData((prevData) => ({
        ...prevData,
        group_id: groupInfo._id,
        commission,
        win_amount,
        divident,
        divident_head,
        payable
      }));
    }
  }, [groupInfo, formData.bid_amount]);
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" ? prevData.transaction_id : ""
    }));
  };
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/payment/get-payment-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleDeleteAuction = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/payment/delete-payment/${currentGroup._id}`);
        alert("Payment deleted successfully");
        setShowModalDelete(false);
        setCurrentGroup(null);
        window.location.reload();
      } catch (error) {
        console.error("Error deleting auction:", error);
      }
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/auction/get-auction-by-id/${groupId}`);
      setCurrentUpdateGroup(response.data);
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching auction:", error);
    }
  };
  const handleFileSubmit = async (e) => {
    e.preventDefault();
    const formDatas = new FormData();
    const fileInput = e.target.file;
    if (fileInput && fileInput.files[0]) {
      formDatas.append("file", fileInput.files[0]);
      try {
        const response = await api.post(`/payment/payment-excel`, formDatas, {
          headers: { "Content-Type": "multipart/form-data" }
        });
        if (response.status === 200) {
          alert("File uploaded successfully!");
          window.location.reload();
          setShowUploadModal(false);
        }
      } catch (error) {
        console.error("Error uploading file:", error);
        alert("Failed to upload file.");
      }
    } else {
      alert("Please select a file to upload.");
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "relative flex flex-col [height:calc(100vh-100px)] overflow-x-auto ", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 ", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
        lineNumber: 799,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
        lineNumber: 803,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent p-2", children: "Reports - Receipt" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 811,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2 ml-2", children: "Track and manage all receipt transactions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 814,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
        lineNumber: 810,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-6 mb-8 border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800 mb-6 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-5 h-5 text-indigo-600",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                  lineNumber: 827,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 821,
              columnNumber: 17
            },
            this
          ),
          "Filter Options"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 820,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Filter Option" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 840,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                onChange: handleSelectFilter,
                value: selectedLabel,
                placeholder: "Search Or Select Filter",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full h-11",
                children: groupOptions.map(
                  (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 858,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 843,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 839,
            columnNumber: 17
          }, this),
          showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "From Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 869,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedFromDate,
                  onChange: (e) => setSelectedFromDate(e.target.value),
                  className: "w-full h-11 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                  lineNumber: 872,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 868,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "To Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 880,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedDate,
                  onChange: (e) => setSelectedDate(e.target.value),
                  className: "w-full h-11 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                  lineNumber: 883,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 879,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 867,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 895,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedAuctionGroupId,
                onChange: handleGroupPayment,
                placeholder: "Search Or Select Group",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 912,
                    columnNumber: 21
                  }, this),
                  groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                      lineNumber: 914,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 898,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 894,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 923,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedCustomers,
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                placeholder: "Search Or Select Customer",
                onChange: (groupId) => setSelectedCustomers(groupId),
                className: "w-full h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 940,
                    columnNumber: 21
                  }, this),
                  filteredUsers.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group?._id, children: [
                      group?.full_name,
                      " - ",
                      group.phone_number
                    ] }, group?._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                      lineNumber: 942,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 926,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 922,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Payment Mode" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 950,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                mode: "multiple",
                value: selectedPaymentMode,
                showSearch: true,
                placeholder: "Select payment mode",
                popupMatchSelectWidth: false,
                onChange: (modes) => {
                  setSelectedPaymentMode(modes);
                },
                filterOption: (input, option) => option.label.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full",
                style: { height: "44px" },
                options: [
                  { label: "Cash", value: "cash" },
                  { label: "Online", value: "online" },
                  { label: "Online/AutoPay", value: "online/autoPay" },
                  { label: "Online/Payment Link", value: "Payment Link" },
                  { label: "Cheque", value: "cheque" }
                ]
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 954,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 949,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Payment For" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 982,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("style", { children: `
                        .custom-select .ant-select-selector {
                          min-height: 44px !important;
                          max-height: 60px !important;
                          overflow-y: auto !important;
                          display: flex;
                          align-items: center;
                        }

                        .custom-select .ant-select-selection-overflow {
                          max-height: 60px;
                          overflow-y: auto;
                        }
                      ` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 985,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                mode: "multiple",
                value: selectedPaymentFor,
                showSearch: true,
                placeholder: "Select payment for",
                popupMatchSelectWidth: false,
                onChange: (modes) => {
                  setSelectedPaymentFor(modes);
                },
                filterOption: (input, option) => option.label.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full custom-select",
                options: [
                  { label: "Chit", value: "Chit" },
                  { label: "Pigme", value: "Pigme" },
                  { label: "Loan", value: "Loan" },
                  { label: "Registration", value: "Registration" }
                ]
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1001,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 981,
            columnNumber: 17
          }, this),
          showAllPaymentModes && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Account Type" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 1029,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedAccountType,
                showSearch: true,
                placeholder: "Search Or Select Account Type",
                popupMatchSelectWidth: false,
                onChange: (groupId) => setSelectedAccountType(groupId),
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "Select Account Type" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1046,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "suspense", children: "Suspense" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1049,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "credit", children: "Credit" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1050,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "adjustment", children: "Adjustment" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1051,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "others", children: "Others" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1054,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1032,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1028,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Collection Employee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 1061,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Search Or Select Collection Agent",
                popupMatchSelectWidth: false,
                onChange: (selection) => {
                  const [id, type] = selection.split("|") || [];
                  if (type === "admin_type") {
                    setCollectionAdmin(id);
                    setCollectionAgent("");
                  } else if (type === "agent_type") {
                    setCollectionAgent(id);
                    setCollectionAdmin("");
                  } else {
                    setCollectionAdmin("");
                    setCollectionAgent("");
                  }
                },
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1089,
                    columnNumber: 21
                  }, this),
                  [...new Set(agents), ...new Set(admins)].map(
                    (dt) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: `${dt._id}|${dt.selected_type}`,
                        children: [
                          dt.selected_type === "admin_type" ? "Admin | " : "Agent | ",
                          dt.full_name,
                          " | ",
                          dt.phone_number
                        ]
                      },
                      dt?._id,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                        lineNumber: 1091,
                        columnNumber: 21
                      },
                      this
                    )
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1064,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1060,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 837,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
        lineNumber: 819,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-gray-50 rounded-2xl font-mono", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "!mb-4 text-gray-700", children: "Financial Overview" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1108,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Spin, { spinning: overviewLoading, size: "large", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [20, 20], children: [
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 12, children: /* @__PURE__ */ jsxDEV(
              Card,
              {
                className: "border border-gray-200 shadow-md rounded-lg bg-white relative overflow-hidden",
                bodyStyle: { padding: 16 },
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-center border-b border-dashed pb-2 mb-3", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-700", children: "Total Collections" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1119,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1118,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Statistic,
                    {
                      prefix: /* @__PURE__ */ jsxDEV(ArrowUpOutlined, { className: "text-emerald-500" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                        lineNumber: 1126,
                        columnNumber: 27
                      }, this),
                      value: totals.in,
                      precision: 2,
                      valueStyle: {
                        color: "#065f46",
                        fontWeight: "700",
                        fontSize: "2.0rem",
                        textAlign: "center"
                      }
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                      lineNumber: 1124,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-t border-dashed mt-3 pt-2 text-center text-[11px] italic text-gray-600", children: numberToIndianWords(Number(totals.in)) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1138,
                    columnNumber: 25
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1114,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 1113,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 12, children: /* @__PURE__ */ jsxDEV(
              Card,
              {
                className: "border border-gray-200 shadow-md rounded-lg bg-white relative overflow-hidden",
                bodyStyle: { padding: 16 },
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-center border-b border-dashed pb-2 mb-3", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-700", children: "Total PayOuts" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1149,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1148,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Statistic,
                    {
                      prefix: /* @__PURE__ */ jsxDEV(ArrowDownOutlined, { className: "text-rose-500" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                        lineNumber: 1156,
                        columnNumber: 27
                      }, this),
                      value: totals.out,
                      precision: 2,
                      valueStyle: {
                        color: "#065f46",
                        fontWeight: "700",
                        fontSize: "2.0rem",
                        textAlign: "center"
                      }
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                      lineNumber: 1154,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-t border-dashed mt-3 pt-2 text-center text-[11px] italic text-gray-600", children: numberToIndianWords(Number(totals.out)) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1168,
                    columnNumber: 25
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1144,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 1143,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1112,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1111,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 1107,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Divider, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 1177,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "!mb-4 text-gray-700", children: "Category Breakdown" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1180,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Spin, { spinning: categoryLoading, size: "large", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
            {
              title: "Chit Collections",
              val: categoryTotals.chit,
              color: "#4f46e5",
              bg: "from-indigo-50 to-white",
              icon: /* @__PURE__ */ jsxDEV(BankOutlined, { className: "text-indigo-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1191,
                columnNumber: 29
              }, this)
            },
            {
              title: "Loan Collections",
              val: categoryTotals.loan,
              color: "#f59e0b",
              bg: "from-amber-50 to-white",
              icon: /* @__PURE__ */ jsxDEV("span", { className: "text-amber-500 font-bold", children: "₹" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1199,
                columnNumber: 23
              }, this)
            },
            {
              title: "Pigme Collections",
              val: categoryTotals.pigme,
              color: "#0d9488",
              bg: "from-teal-50 to-white",
              icon: /* @__PURE__ */ jsxDEV(WalletOutlined, { className: "text-teal-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1207,
                columnNumber: 29
              }, this)
            },
            {
              title: "Registration Fees",
              val: categoryTotals.registration,
              color: "#db2777",
              bg: "from-pink-50 to-white",
              icon: /* @__PURE__ */ jsxDEV(SafetyCertificateOutlined, { className: "text-pink-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1215,
                columnNumber: 23
              }, this)
            }
          ].map(
            (item, idx) => /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, children: /* @__PURE__ */ jsxDEV(
              Card,
              {
                size: "small",
                className: `border shadow-md rounded-xl bg-gradient-to-b ${item.bg}`,
                bodyStyle: { padding: 14 },
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-center border-b border-dashed pb-2 mb-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold flex items-center justify-center gap-2", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[15px]", children: [
                    item.icon,
                    item.title
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1228,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1227,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1226,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-center text-xl font-bold",
                      style: { color: item.color },
                      children: [
                        "₹ ",
                        (item.val || 0).toLocaleString("en-IN")
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                      lineNumber: 1237,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-t border-dashed mt-2 pt-2 text-[10px] text-center italic text-gray-500", children: [
                    numberToIndianWords(item.val || 0),
                    " Only"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1245,
                    columnNumber: 27
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1220,
                columnNumber: 25
              },
              this
            ) }, idx, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 1219,
              columnNumber: 21
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1184,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1183,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 1179,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "!mb-4 text-gray-700", children: "Payment Modes" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1257,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Spin, { spinning: modeLoading, size: "large", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
            {
              title: "Cash",
              val: modeTotals.cash,
              color: "#16a34a",
              bg: "from-green-50 to-white",
              icon: /* @__PURE__ */ jsxDEV(WalletOutlined, { className: "text-green-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1268,
                columnNumber: 29
              }, this)
            },
            {
              title: "Online",
              val: modeTotals.online,
              color: "#2563eb",
              bg: "from-blue-50 to-white",
              icon: /* @__PURE__ */ jsxDEV(GlobalOutlined, { className: "text-blue-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1275,
                columnNumber: 29
              }, this)
            },
            {
              title: "Payment Link",
              val: modeTotals.link,
              color: "#7c3aed",
              bg: "from-violet-50 to-white",
              icon: /* @__PURE__ */ jsxDEV(LinkOutlined, { className: "text-violet-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1282,
                columnNumber: 29
              }, this)
            },
            {
              title: "AutoPay",
              val: modeTotals.autopay,
              color: "#7c3aed",
              icon: /* @__PURE__ */ jsxDEV(ThunderboltOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1288,
                columnNumber: 29
              }, this)
            }
          ].map(
            (mode, idx) => /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 6, children: /* @__PURE__ */ jsxDEV(
              Card,
              {
                className: `border shadow-md rounded-xl bg-gradient-to-b ${mode.bg}`,
                bodyStyle: { padding: 16 },
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-center border-b border-dashed pb-2 mb-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold flex items-center justify-center gap-2", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[15px]", children: [
                    mode.icon,
                    mode.title,
                    " Collection"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1299,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1298,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1297,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-center text-xl font-bold",
                      style: { color: mode.color },
                      children: [
                        "₹ ",
                        (mode.val || 0).toLocaleString("en-IN")
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                      lineNumber: 1307,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-t border-dashed mt-2 pt-2 text-[10px] italic text-center text-gray-500", children: [
                    numberToIndianWords(mode.val || 0),
                    " Only"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                    lineNumber: 1315,
                    columnNumber: 27
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                lineNumber: 1292,
                columnNumber: 25
              },
              this
            ) }, idx, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 1291,
              columnNumber: 21
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1261,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1260,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 1256,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
        lineNumber: 1105,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: filteredAuction && filteredAuction.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-6 border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-6", children: [
          /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-5 h-5 text-indigo-600",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
                  lineNumber: 1339,
                  columnNumber: 23
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
              lineNumber: 1333,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800", children: "Payment Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1346,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 1332,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(TableDaybook, searchText),
            columns,
            exportCols,
            printHeaderKeys: [
              "Total IN (Collections)",
              "Total OUT (Payouts)",
              "Chit Collections",
              "Loan Collections",
              "Pigme Collections",
              "Registration Fees",
              "Cash Collection",
              "Online Collection",
              "Payment Link",
              "AutoPay"
            ],
            printHeaderValues: [
              totals.in,
              totals.out,
              categoryTotals.chit,
              categoryTotals.loan,
              categoryTotals.pigme,
              categoryTotals.registration,
              modeTotals.cash,
              modeTotals.online,
              modeTotals.link,
              modeTotals.autopay
            ],
            exportedPdfName: `Receipt Report`,
            exportedFileName: `Reports Receipt.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1351,
            columnNumber: 19
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-6 pt-6 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-indigo-50 to-blue-50 px-6 py-3 rounded-xl", children: /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-gray-800", children: [
          "Total Amount:",
          " ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-indigo-600", children: [
            "₹",
            payments?.toLocaleString()
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
            lineNumber: 1387,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 1385,
          columnNumber: 23
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 1384,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 1383,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
        lineNumber: 1331,
        columnNumber: 15
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-12 text-center border border-gray-100", children: /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          failure: filteredAuction.length <= 0,
          data: "Receipt Data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
          lineNumber: 1396,
          columnNumber: 19
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
        lineNumber: 1395,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
        lineNumber: 1326,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
      lineNumber: 808,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
    lineNumber: 798,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
    lineNumber: 797,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx",
    lineNumber: 796,
    columnNumber: 5
  }, this);
};
_s(PaymentReport, "FypNd2NIQBi3rl/z4ju6RLNpvys=");
_c = PaymentReport;
export default PaymentReport;
var _c;
$RefreshReg$(_c, "PaymentReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNGJrQixTQXNhQSxVQXRhQTsyQkE1YmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLGFBQWE7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsU0FBUztBQUNoQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxNQUFNLEVBQUVDLE1BQU1DLE1BQU0sSUFBSUo7QUFFeEI7QUFBQSxFQUNFSztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRVAsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxpQkFBaUI7QUFFMUIsU0FBU0MsMkJBQTJCO0FBRXBDLE1BQU1DLGdCQUFnQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzFCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJN0MsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzhDLGNBQWNDLGVBQWUsSUFBSS9DLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNnRCxlQUFlQyxnQkFBZ0IsSUFBSWpELFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNrRCxzQkFBc0JDLHVCQUF1QixJQUFJbkQsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ29ELGlCQUFpQkMsa0JBQWtCLElBQUlyRCxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDc0Qsd0JBQXdCQyx5QkFBeUIsSUFBSXZELFNBQVMsRUFBRTtBQUN2RSxRQUFNLENBQUN3RCxlQUFlQyxnQkFBZ0IsSUFBSXpELFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUMwRCxpQkFBaUJDLGtCQUFrQixJQUFJM0QsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQzRELFdBQVdDLFlBQVksSUFBSTdELFNBQVMsQ0FBQyxDQUFDO0FBQzdDLFFBQU0sQ0FBQzhELFdBQVdDLFlBQVksSUFBSS9ELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNnRSxpQkFBaUJDLGtCQUFrQixJQUFJakUsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ2tFLGNBQWNDLGVBQWUsSUFBSW5FLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNvRSxpQkFBaUJDLGtCQUFrQixJQUFJckUsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3NFLG9CQUFvQkMscUJBQXFCLElBQUl2RSxTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDd0UsaUJBQWlCQyxrQkFBa0IsSUFBSXpFLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMwRSxXQUFXQyxZQUFZLElBQUkzRSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDNEUsYUFBYUMsY0FBYyxJQUFJN0UsU0FBUyxNQUFNO0FBQ3JELFFBQU0sQ0FBQzhFLFlBQVlDLGFBQWEsSUFBSS9FLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNnRixXQUFXQyxZQUFZLElBQUlqRixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDa0YsaUJBQWlCQyxrQkFBa0IsSUFBSW5GLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNvRixlQUFlQyxnQkFBZ0IsSUFBSXJGLFNBQVMsT0FBTztBQUUxRCxRQUFNc0YsTUFBTSxvQkFBSUMsS0FBSztBQUNyQixRQUFNQyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekNWLGtCQUFjVSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsRUFDOUI7QUFDQSxRQUFNQyxjQUFjTixJQUFJTyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbEQsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJaEcsU0FBUzRGLFdBQVc7QUFDcEUsUUFBTSxDQUFDSyxjQUFjQyxlQUFlLElBQUlsRyxTQUFTNEYsV0FBVztBQUM1RCxRQUFNLENBQUNPLHFCQUFxQkMsc0JBQXNCLElBQUlwRyxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDcUcsaUJBQWlCQyxrQkFBa0IsSUFBSXRHLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUN1RyxxQkFBcUJDLHNCQUFzQixJQUFJeEcsU0FBUyxFQUFFO0FBQ2pFLFFBQU0sQ0FBQ3lHLG1CQUFtQkMsb0JBQW9CLElBQUkxRyxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDMkcsVUFBVUMsV0FBVyxJQUFJNUcsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQzZHLG9CQUFvQkMscUJBQXFCLElBQUk5RyxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDK0csaUJBQWlCQyxrQkFBa0IsSUFBSWhILFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNpSCxpQkFBaUJDLGtCQUFrQixJQUFJbEgsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ21ILFFBQVFDLFNBQVMsSUFBSXBILFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNxSCxRQUFRQyxTQUFTLElBQUl0SCxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDdUgsUUFBUUMsU0FBUyxJQUFJeEgsU0FBUyxFQUFFeUgsSUFBSSxHQUFHQyxLQUFLLEdBQUdDLEtBQUssRUFBRSxDQUFDO0FBQzlELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJN0gsU0FBUztBQUFBLElBQzNDOEgsTUFBTTtBQUFBLElBQ05DLFFBQVE7QUFBQSxJQUNSQyxNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSW5JLFNBQVMsSUFBSTtBQUMzRCxRQUFNLENBQUNvSSxpQkFBaUJDLGtCQUFrQixJQUFJckksU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ3NJLGFBQWFDLGNBQWMsSUFBSXZJLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUN3SSxxQkFBcUJDLHNCQUFzQixJQUFJekksU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQzBJLFVBQVVDLFdBQVcsSUFBSTNJLFNBQVM7QUFBQSxJQUN2QzRJLFVBQVU7QUFBQSxJQUNWQyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLFlBQVk7QUFBQSxJQUNaQyxVQUFVO0FBQUEsSUFDVkMsUUFBUTtBQUFBLElBQ1JDLFVBQVU7QUFBQSxJQUNWQyxnQkFBZ0I7QUFBQSxJQUNoQkMsY0FBY3JDO0FBQUFBLElBQ2RzQyxZQUFZcEM7QUFBQUEsSUFDWnFDLGlCQUFpQjtBQUFBLEVBQ25CLENBQUM7QUFDRCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUl4SixTQUFTO0FBQUEsSUFDbkR5SixNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUEsRUFDaEIsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJOUosU0FBUztBQUFBLElBQzdDK0osWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTUMsbUJBQW1CQSxNQUFNekYsbUJBQW1CLEtBQUs7QUFDdkQxRSxZQUFVLE1BQU07QUFDZCxVQUFNb0ssT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1DLFVBQVVDLEtBQUtDLE1BQU1MLElBQUk7QUFFL0IsUUFDRUcsV0FDQUEsUUFBUUcsdUJBQXVCQyxvQkFBb0JDLGNBQ25EO0FBQ0EsWUFBTUMsb0JBQ0pOLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxpQkFDakQsU0FDRSxPQUNBO0FBQ05sQyw2QkFBdUJtQyxpQkFBaUI7QUFBQSxJQUMxQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBQ0w3SyxZQUFVLE1BQU07QUFDZCxVQUFNb0ssT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1DLFVBQVVDLEtBQUtDLE1BQU1MLElBQUk7QUFFL0IsUUFDRUcsV0FDQUEsUUFBUUcsdUJBQXVCQyxvQkFBb0JDLGNBQ25EO0FBQ0EsWUFBTUUsV0FDSlAsUUFBUUcsdUJBQXVCQyxvQkFBb0JDLGlCQUNqRCxTQUNFLE9BQ0E7QUFDTnJFLHlCQUFtQnVFLFFBQVE7QUFBQSxJQUM3QjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBQ0w5SyxZQUFVLE1BQU07QUFDZCxVQUFNK0ssY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU03SyxJQUFJOEssSUFBSSx3QkFBd0I7QUFDdkRuSSxrQkFBVWtJLFNBQVNFLElBQUk7QUFBQSxNQUN6QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBSixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBQ0wvSyxZQUFVLE1BQU07QUFDZCxLQUFDLFlBQVk7QUFDWCxVQUFJO0FBQ0YsY0FBTSxDQUFDcUwsV0FBVy9ELE9BQU0sSUFBSSxNQUFNZ0UsUUFBUUM7QUFBQUEsVUFBSTtBQUFBLFlBQzVDcEwsSUFBSThLLElBQUksV0FBVztBQUFBLFlBQ25COUssSUFBSThLLElBQUksdUJBQXVCO0FBQUEsVUFBQztBQUFBLFFBQ2pDO0FBQ0QsY0FBTU8sT0FBT0gsV0FBV0gsTUFBTU8sU0FBU0MsSUFBSSxDQUFDQyxTQUFTO0FBQUEsVUFDbkRDLEtBQUtELElBQUlDO0FBQUFBLFVBQ1RDLFdBQVdGLElBQUlHO0FBQUFBLFVBQ2ZDLGNBQWNKLElBQUlJO0FBQUFBLFVBQ2xCQyxlQUFlO0FBQUEsUUFDakIsRUFBRTtBQUNGM0Usa0JBQVVtRSxJQUFJO0FBQ2QsY0FBTVMsT0FBTzNFLFNBQVE0RCxNQUFNUSxJQUFJLENBQUNRLFFBQVE7QUFBQSxVQUN0Q04sS0FBS00sSUFBSU47QUFBQUEsVUFDVEMsV0FBV0ssSUFBSUo7QUFBQUEsVUFDZkMsY0FBY0csSUFBSUM7QUFBQUEsVUFDbEJILGVBQWU7QUFBQSxRQUNqQixFQUFFO0FBQ0Z6RSxrQkFBVTBFLElBQUk7QUFBQSxNQUNoQixTQUFTZCxPQUFPO0FBQ2Q1RCxrQkFBVSxFQUFFO0FBQ1pGLGtCQUFVLEVBQUU7QUFBQSxNQUNkO0FBQUEsSUFDRixHQUFHO0FBQUEsRUFDTCxHQUFHLEVBQUU7QUFDTHJILFlBQVUsTUFBTTtBQUNkLFVBQU1vTSxlQUFlLFlBQVk7QUFDL0IsVUFBSTtBQUNGLGNBQU1wQixXQUFXLE1BQU03SyxJQUFJOEssSUFBSSw2QkFBNkI7QUFDNURyRyxxQkFBYW9HLFNBQVNFLElBQUk7QUFBQSxNQUM1QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUFBLE1BQ3JEO0FBQUEsSUFDRjtBQUNBaUIsaUJBQWE7QUFBQSxFQUNmLEdBQUcsRUFBRTtBQUVMcE0sWUFBVSxNQUFNO0FBQ2QsVUFBTStLLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNN0ssSUFBSThLLElBQUksZ0JBQWdCO0FBQy9DdkgseUJBQWlCc0gsU0FBU0UsSUFBSTtBQUFBLE1BQ2hDLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FKLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFFTC9LLFlBQVUsTUFBTTtBQUNkLFFBQUkyRSxXQUFXO0FBQ2JpRSxrQkFBWSxDQUFDeUQsY0FBYztBQUFBLFFBQ3pCLEdBQUdBO0FBQUFBLFFBQ0hyRCxZQUFZckUsVUFBVXFFO0FBQUFBLE1BQ3hCLEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRixHQUFHLENBQUNyRSxTQUFTLENBQUM7QUFFZCxRQUFNMkgsZUFBZUEsQ0FBQzVHLE1BQU07QUFDMUIsVUFBTSxFQUFFb0csTUFBTWxHLE1BQU0sSUFBSUYsRUFBRUM7QUFDMUJpRCxnQkFBWSxDQUFDeUQsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ1AsSUFBSSxHQUFHbEc7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU0yRyxtQkFBbUJBLENBQUM3RyxNQUFNO0FBQzlCLFVBQU0sRUFBRW9HLE1BQU1sRyxNQUFNLElBQUlGLEVBQUVDO0FBQzFCLFVBQU0sQ0FBQ21ELFNBQVNDLE1BQU0sSUFBSW5ELE1BQU1HLE1BQU0sR0FBRztBQUN6QzZDLGdCQUFZLENBQUN5RCxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSHZEO0FBQUFBLE1BQ0FDO0FBQUFBLElBQ0YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNeUQsY0FBYyxPQUFPQyxVQUFVO0FBQ25DLFVBQU1DLFVBQVVELE1BQU05RyxPQUFPQztBQUM3QnRDLHVCQUFtQm9KLE9BQU87QUFDMUI5RCxnQkFBWSxDQUFDK0Qsa0JBQWtCO0FBQUEsTUFDN0IsR0FBR0E7QUFBQUEsTUFDSDlELFVBQVU2RDtBQUFBQSxJQUNaLEVBQUU7QUFFRkUsc0JBQWtCRixPQUFPO0FBRXpCLFFBQUlBLFNBQVM7QUFDWCxVQUFJO0FBQ0YsY0FBTTFCLFdBQVcsTUFBTTdLLElBQUk4SyxJQUFJLDBCQUEwQnlCLE9BQU8sRUFBRTtBQUNsRTVJLHFCQUFha0gsU0FBU0UsUUFBUSxDQUFDLENBQUM7QUFBQSxNQUNsQyxTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUNqRHJILHFCQUFhLENBQUMsQ0FBQztBQUFBLE1BQ2pCO0FBQUEsSUFDRixPQUFPO0FBQ0xBLG1CQUFhLENBQUMsQ0FBQztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFFBQU0rSSxlQUFlO0FBQUEsSUFDbkIsRUFBRWpILE9BQU8sU0FBU2tILE9BQU8sUUFBUTtBQUFBLElBQ2pDLEVBQUVsSCxPQUFPLGFBQWFrSCxPQUFPLFlBQVk7QUFBQSxJQUN6QyxFQUFFbEgsT0FBTyxhQUFha0gsT0FBTyxhQUFhO0FBQUEsSUFDMUMsRUFBRWxILE9BQU8sYUFBYWtILE9BQU8sYUFBYTtBQUFBLElBQzFDLEVBQUVsSCxPQUFPLFlBQVlrSCxPQUFPLFlBQVk7QUFBQSxJQUN4QyxFQUFFbEgsT0FBTyxVQUFVa0gsT0FBTyxTQUFTO0FBQUEsRUFBQztBQUd0QyxRQUFNQyxxQkFBcUIsT0FBT0wsWUFBWTtBQUU1Q2xKLDhCQUEwQmtKLE9BQU87QUFBQSxFQUNuQztBQUVBLFFBQU1NLHFCQUFxQkEsQ0FBQ3BILFVBQVU7QUFDcENOLHFCQUFpQk0sS0FBSztBQUV0QlIsdUJBQW1CLEtBQUs7QUFFeEIsVUFBTTZILFFBQVEsb0JBQUl6SCxLQUFLO0FBQ3ZCLFVBQU0wSCxhQUFhQSxDQUFDQyxTQUFTQSxLQUFLQyxtQkFBbUIsT0FBTztBQUU1RCxRQUFJeEgsVUFBVSxTQUFTO0FBQ3JCLFlBQU15SCxZQUFZSCxXQUFXRCxLQUFLO0FBQ2xDaEgsMEJBQW9Cb0gsU0FBUztBQUM3QmxILHNCQUFnQmtILFNBQVM7QUFBQSxJQUMzQixXQUFXekgsVUFBVSxhQUFhO0FBQ2hDLFlBQU0wSCxZQUFZLElBQUk5SCxLQUFLeUgsS0FBSztBQUNoQ0ssZ0JBQVVDLFFBQVFELFVBQVVFLFFBQVEsSUFBSSxDQUFDO0FBQ3pDLFlBQU1ILFlBQVlILFdBQVdJLFNBQVM7QUFDdENySCwwQkFBb0JvSCxTQUFTO0FBQzdCbEgsc0JBQWdCa0gsU0FBUztBQUFBLElBQzNCLFdBQVd6SCxVQUFVLGFBQWE7QUFDaEMsWUFBTTZILFFBQVEsSUFBSWpJLEtBQUt5SCxNQUFNUyxZQUFZLEdBQUdULE1BQU1VLFNBQVMsR0FBRyxDQUFDO0FBQy9ELFlBQU1DLE1BQU0sSUFBSXBJLEtBQUt5SCxNQUFNUyxZQUFZLEdBQUdULE1BQU1VLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakUxSCwwQkFBb0JpSCxXQUFXTyxLQUFLLENBQUM7QUFDckN0SCxzQkFBZ0IrRyxXQUFXVSxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXaEksVUFBVSxhQUFhO0FBQ2hDLFlBQU02SCxRQUFRLElBQUlqSSxLQUFLeUgsTUFBTVMsWUFBWSxHQUFHVCxNQUFNVSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ25FLFlBQU1DLE1BQU0sSUFBSXBJLEtBQUt5SCxNQUFNUyxZQUFZLEdBQUdULE1BQU1VLFNBQVMsR0FBRyxDQUFDO0FBQzdEMUgsMEJBQW9CaUgsV0FBV08sS0FBSyxDQUFDO0FBQ3JDdEgsc0JBQWdCK0csV0FBV1UsR0FBRyxDQUFDO0FBQUEsSUFDakMsV0FBV2hJLFVBQVUsWUFBWTtBQUMvQixZQUFNNkgsUUFBUSxJQUFJakksS0FBS3lILE1BQU1TLFlBQVksR0FBRyxHQUFHLENBQUM7QUFDaEQsWUFBTUUsTUFBTSxJQUFJcEksS0FBS3lILE1BQU1TLFlBQVksR0FBRyxJQUFJLEVBQUU7QUFDaER6SCwwQkFBb0JpSCxXQUFXTyxLQUFLLENBQUM7QUFDckN0SCxzQkFBZ0IrRyxXQUFXVSxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXaEksVUFBVSxVQUFVO0FBQzdCUix5QkFBbUIsSUFBSTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUNBLFFBQU15SSxnQkFBZ0JBLENBQUNDLGVBQWU7QUFDcEMsVUFBTVgsT0FBTyxJQUFJM0gsS0FBS3NJLFVBQVU7QUFDaEMsVUFBTUMsVUFBVSxFQUFFQyxLQUFLLFdBQVdDLE9BQU8sUUFBUUMsTUFBTSxVQUFVO0FBQ2pFLFdBQU9mLEtBQUtDLG1CQUFtQixTQUFTVyxPQUFPLEVBQUVJLFFBQVEsS0FBSyxFQUFFO0FBQUEsRUFDbEU7QUFFQSxNQUFJQyxlQUFlLENBQUMsR0FBR2hJLG1CQUFtQjtBQUUxQyxNQUNFZ0ksYUFBYUMsU0FBUyxRQUFRLEtBQzlCLENBQUNELGFBQWFDLFNBQVMsUUFBUSxHQUMvQjtBQUNBRCxpQkFBYUUsS0FBSyxRQUFRO0FBQUEsRUFDNUI7QUFFQXRPO0FBQUFBLElBQVUsTUFBTTtBQUNkLFlBQU11TyxrQkFBa0IsSUFBSUMsZ0JBQWdCO0FBQzVDLFlBQU1DLGdCQUFnQixZQUFZO0FBQ2hDLFlBQUk7QUFDRnZKLHVCQUFhLElBQUk7QUFDakJrRCw2QkFBbUIsSUFBSTtBQUN2QkUsNkJBQW1CLElBQUk7QUFDdkJFLHlCQUFlLElBQUk7QUFDbkIsZ0JBQU13QyxXQUFXLE1BQU03SyxJQUFJOEssSUFBSSwrQkFBK0I7QUFBQSxZQUM1RHlELFFBQVE7QUFBQSxjQUNOQyxXQUFXM0k7QUFBQUEsY0FDWDRJLFNBQVMxSTtBQUFBQSxjQUNUd0csU0FBU25KO0FBQUFBLGNBQ1RzTCxRQUFRbkk7QUFBQUEsY0FDUnlDLFVBQVVpRjtBQUFBQSxjQUNWVSxjQUFjdEk7QUFBQUEsY0FDZDZDLGNBQWNyQztBQUFBQSxjQUNkc0MsWUFBWXBDO0FBQUFBLGNBQ1o2SCxTQUFTakk7QUFBQUEsWUFDWDtBQUFBLFlBQ0FrSSxRQUFRVCxnQkFBZ0JTO0FBQUFBLFVBQzFCLENBQUM7QUFDRDVELGtCQUFRNkQsS0FBS2pFLFNBQVNFLE1BQU0sc0JBQXNCO0FBQ2xELGNBQUlGLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUtnRSxTQUFTLEdBQUc7QUFDN0Msa0JBQU1DLGdCQUFnQm5FLFNBQVNFLEtBQUtrRTtBQUFBQSxjQUNsQyxDQUFDQyxZQUFZQSxRQUFReEcsYUFBYTtBQUFBLFlBQ3BDO0FBRUFqRiwrQkFBbUJ1TCxhQUFhO0FBRWhDLGtCQUFNRyxjQUFjSCxjQUFjSTtBQUFBQSxjQUNoQyxDQUFDQyxLQUFLSCxZQUFZRyxNQUFNQyxPQUFPSixRQUFRbkcsVUFBVSxDQUFDO0FBQUEsY0FDbEQ7QUFBQSxZQUNGO0FBQ0FrQyxvQkFBUTZELEtBQUtLLGFBQWEsY0FBYztBQUN4Q3pJLHdCQUFZeUksV0FBVztBQUN2QixnQkFBSXRFLFNBQVNFLE1BQU07QUFDakIsa0JBQUl3RSxNQUFNLEdBQ1JDLE9BQU87QUFDVCxrQkFBSTVILE9BQU87QUFDWCxrQkFBSUMsU0FBUztBQUNiLGtCQUFJQyxPQUFPO0FBQ1gsa0JBQUlDLFVBQVU7QUFxRGQsb0JBQU0wSCxnQkFBZ0JULGNBQWN6RCxJQUFJLENBQUNtRSxPQUFPQyxVQUFVO0FBQ3hELHNCQUFNQyxNQUFNTixPQUFPSSxNQUFNM0csVUFBVSxDQUFDO0FBR3BDLG9CQUFJMkcsTUFBTTNGLFNBQVMsS0FBTXdGLFFBQU9LO0FBQUFBO0FBQzNCSiwwQkFBUUssS0FBS0MsSUFBSUYsR0FBRztBQUV6Qix1QkFBTztBQUFBLGtCQUNMbkUsS0FBS2lFLE9BQU9qRTtBQUFBQSxrQkFDWnNFLElBQUlKLFFBQVE7QUFBQTtBQUFBLGtCQUdaNUYsTUFDRSx1QkFBQyxPQUFJLE9BQU8yRixPQUFPM0YsU0FBUyxPQUFPLFVBQVUsV0FDMUMyRixpQkFBTzNGLFFBQVEsYUFEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVGaUcsVUFBVU4sT0FBTzNGO0FBQUFBLGtCQUVqQmlELE1BQU0wQyxPQUFPNUc7QUFBQUEsa0JBQ2I0RyxPQUFPQSxPQUFPaEgsVUFBVXVILGNBQWNQLE1BQU1kO0FBQUFBLGtCQUM1Q2pELE1BQU0rRCxPQUFPL0csU0FBUytDO0FBQUFBLGtCQUN0QndFLFVBQVVSLE9BQU9kLFdBQVc7QUFBQSxrQkFDNUJoRCxjQUFjOEQsT0FBTy9HLFNBQVNpRDtBQUFBQSxrQkFDOUIvQyxZQUFZNkcsT0FBTzdHO0FBQUFBLGtCQUNuQnNILGdCQUFnQlQsT0FBT1M7QUFBQUEsa0JBRXZCdkgsUUFDRThHLE9BQU9sRyxNQUFNNEcsV0FDYlYsT0FBT2pHLE9BQU80RyxZQUNkWCxPQUFPOUc7QUFBQUEsa0JBRVRHLFFBQ0U7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FDRTJHLE9BQU8zRixTQUFTLE9BQ1osNkJBQ0E7QUFBQSxzQkFDTDtBQUFBO0FBQUEsd0JBRUU4RixLQUFLQyxJQUFJRixHQUFHLEVBQUVVLGVBQWUsT0FBTztBQUFBO0FBQUE7QUFBQSxvQkFQekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVFBO0FBQUEsa0JBRUZDLFlBQVlYO0FBQUFBLGtCQUVaWSxrQkFBa0JkLE9BQU9lLFdBQVc3SyxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsa0JBQ2xEOEssTUFBTWhCLE9BQU8xRztBQUFBQSxrQkFDYjJGLGNBQWNlLE9BQU9mO0FBQUFBLGtCQUNyQnZGLGlCQUFpQnNHLE9BQU90RztBQUFBQSxrQkFFeEJGLGNBQ0V3RyxPQUFPeEcsY0FBY3lDLFFBQ3JCK0QsT0FBT3ZHLFlBQVl3SCxjQUNuQjtBQUFBLGtCQUVGQyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLHNCQUNqQixNQUFNO0FBQUEsd0JBQ0pDLE9BQU87QUFBQSwwQkFDTDtBQUFBLDRCQUNFQyxLQUFLO0FBQUEsNEJBQ0xuRSxPQUNFO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLFFBQU87QUFBQSxnQ0FDUCxJQUFJLFVBQVUrQyxNQUFNakUsR0FBRztBQUFBLGdDQUN2QixXQUFVO0FBQUEsZ0NBQWU7QUFBQTtBQUFBLDhCQUgzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBTUE7QUFBQSwwQkFFSjtBQUFBLHdCQUFDO0FBQUEsc0JBRUw7QUFBQSxzQkFDQSxXQUFVO0FBQUEsc0JBRVYsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStCO0FBQUE7QUFBQSxvQkFwQmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFxQkEsS0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF1QkE7QUFBQSxnQkFFSjtBQUFBLGNBQ0YsQ0FBQztBQUNELGtCQUFJbEMsT0FBTyxHQUNUQyxPQUFPLEdBQ1BDLFFBQVEsR0FDUkMsZUFBZTtBQUVqQm1CLHVCQUFTRSxLQUFLZ0csUUFBUSxDQUFDQyxTQUFTO0FBQzlCLG9CQUFJQSxLQUFLakgsU0FBUyxLQUFNO0FBRXhCLHNCQUFNNkYsTUFBTU4sT0FBTzBCLEtBQUtqSSxVQUFVLENBQUM7QUFDbkMsc0JBQU1rSSxNQUFNRCxLQUFLcEMsV0FBVyxRQUFRc0MsWUFBWTtBQUVoRCxvQkFBSUQsR0FBRy9DLFNBQVMsTUFBTSxFQUFHMUUsU0FBUW9HO0FBQUFBLHlCQUN4QnFCLEdBQUcvQyxTQUFTLE9BQU8sRUFBR3pFLFVBQVNtRztBQUFBQSx5QkFDL0JxQixHQUFHL0MsU0FBUyxLQUFLLEVBQUd4RSxpQkFBZ0JrRztBQUFBQTtBQUN4Q3JHLDBCQUFRcUc7QUFBQUEsY0FDZixDQUFDO0FBRUQvRSx1QkFBU0UsS0FBS2dHLFFBQVEsQ0FBQ0MsU0FBUztBQUM5QixzQkFBTXBCLE1BQU1OLE9BQU8wQixLQUFLakksVUFBVSxDQUFDO0FBRW5DLG9CQUFJaUksS0FBS2pILFNBQVMsS0FBTTtBQUV4QixzQkFBTTJHLFFBQVFNLEtBQUtoSSxZQUFZLElBQUlrSSxZQUFZO0FBRS9DLG9CQUFJUixTQUFTLGFBQWFBLFNBQVMsb0JBQW9CQSxLQUFLeEMsU0FBUyxTQUFTLEdBQUc7QUFDL0VuRyw2QkFBVzZIO0FBQUFBLGdCQUNiLFdBQ1NjLFNBQVMsUUFBUTtBQUN4QjlJLDBCQUFRZ0k7QUFBQUEsZ0JBQ1YsV0FDU2MsU0FBUyxZQUFZQSxTQUFTLFVBQVU7QUFDL0M3SSw0QkFBVStIO0FBQUFBLGdCQUNaLFdBQ1NjLEtBQUt4QyxTQUFTLE1BQU0sR0FBRztBQUM5QnBHLDBCQUFROEg7QUFBQUEsZ0JBQ1Y7QUFBQSxjQUNGLENBQUM7QUFPRHRHLGdDQUFrQjtBQUFBLGdCQUNoQkM7QUFBQUEsZ0JBQ0FDO0FBQUFBLGdCQUNBQztBQUFBQSxnQkFDQUM7QUFBQUEsY0FDRixDQUFDO0FBRURwQyx3QkFBVSxFQUFFQyxJQUFJZ0ksS0FBSy9ILEtBQUtnSSxNQUFNL0gsS0FBSzhILE1BQU1DLEtBQUssQ0FBQztBQUNqRDdILDRCQUFjO0FBQUEsZ0JBQ1pDO0FBQUFBLGdCQUNBQztBQUFBQSxnQkFDQUM7QUFBQUEsZ0JBQ0FDO0FBQUFBLGNBQ0YsQ0FBQztBQUVEbEYsOEJBQWdCNE0sYUFBYTtBQUFBLFlBQy9CO0FBQUEsVUFDRixPQUFPO0FBQ0xoTSwrQkFBbUIsRUFBRTtBQUNyQlosNEJBQWdCLEVBQUU7QUFDbEI2RCx3QkFBWSxDQUFDO0FBRWJZLHNCQUFVO0FBQUEsY0FDUkMsSUFBSTtBQUFBLGNBQ0pDLEtBQUs7QUFBQSxjQUNMQyxLQUFLO0FBQUEsWUFDUCxDQUFDO0FBRUQ2Qiw4QkFBa0I7QUFBQSxjQUNoQkMsTUFBTTtBQUFBLGNBQ05DLE1BQU07QUFBQSxjQUNOQyxPQUFPO0FBQUEsY0FDUEMsY0FBYztBQUFBLFlBQ2hCLENBQUM7QUFFRC9CLDBCQUFjO0FBQUEsY0FDWkMsTUFBTTtBQUFBLGNBQ05DLFFBQVE7QUFBQSxjQUNSQyxNQUFNO0FBQUEsY0FDTkMsU0FBUztBQUFBLFlBQ1gsQ0FBQztBQUFBLFVBQ0g7QUFBQSxRQUNGLFNBQVNpRCxPQUFPO0FBQ2RDLGtCQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuREMsa0JBQVFELE1BQU1BLEtBQUs7QUFFbkJ2SCw2QkFBbUIsRUFBRTtBQUNyQlosMEJBQWdCLEVBQUU7QUFDbEI2RCxzQkFBWSxDQUFDO0FBRWJZLG9CQUFVO0FBQUEsWUFDUkMsSUFBSTtBQUFBLFlBQ0pDLEtBQUs7QUFBQSxZQUNMQyxLQUFLO0FBQUEsVUFDUCxDQUFDO0FBRUQ2Qiw0QkFBa0I7QUFBQSxZQUNoQkMsTUFBTTtBQUFBLFlBQ05DLE1BQU07QUFBQSxZQUNOQyxPQUFPO0FBQUEsWUFDUEMsY0FBYztBQUFBLFVBQ2hCLENBQUM7QUFFRC9CLHdCQUFjO0FBQUEsWUFDWkMsTUFBTTtBQUFBLFlBQ05DLFFBQVE7QUFBQSxZQUNSQyxNQUFNO0FBQUEsWUFDTkMsU0FBUztBQUFBLFVBQ1gsQ0FBQztBQUFBLFFBQ0gsVUFBQztBQUNDaEQsdUJBQWEsS0FBSztBQUNsQmtELDZCQUFtQixLQUFLO0FBQ3hCRSw2QkFBbUIsS0FBSztBQUN4QkUseUJBQWUsS0FBSztBQUFBLFFBQ3RCO0FBQUEsTUFDRjtBQUVBaUcsb0JBQWM7QUFDZCxhQUFPLE1BQU07QUFDWEYsd0JBQWdCK0MsTUFBTTtBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUFBLElBQUc7QUFBQSxNQUNEL047QUFBQUEsTUFDQTJDO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FNO0FBQUFBLE1BQ0FWO0FBQUFBLE1BQ0FRO0FBQUFBLE1BQ0FRO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FKO0FBQUFBLElBQWtCO0FBQUEsRUFDbkI7QUFFRCxRQUFNeUssVUFBVTtBQUFBLElBQ2QsRUFBRU4sS0FBSyxNQUFNTyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFUCxLQUFLLFFBQVFPLFFBQVEsWUFBWTtBQUFBLElBQ25DLEVBQUVQLEtBQUssb0JBQW9CTyxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUVQLEtBQUssU0FBU08sUUFBUSxhQUFhO0FBQUEsSUFDckMsRUFBRVAsS0FBSyxRQUFRTyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDO0FBQUEsTUFDRVAsS0FBSztBQUFBLE1BQ0xPLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxFQUFFUCxLQUFLLFlBQVlPLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVQLEtBQUssZ0JBQWdCTyxRQUFRLHdCQUF3QjtBQUFBLElBQ3ZELEVBQUVQLEtBQUssY0FBY08sUUFBUSxpQkFBaUI7QUFBQSxJQUM5QyxFQUFFUCxLQUFLLGtCQUFrQk8sUUFBUSxjQUFjO0FBQUEsSUFDL0MsRUFBRVAsS0FBSyxVQUFVTyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFUCxLQUFLLFVBQVVPLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVQLEtBQUssUUFBUU8sUUFBUSxlQUFlO0FBQUEsSUFDdEMsR0FBSWxMLGtCQUNBLENBQUMsRUFBRTJLLEtBQUssZ0JBQWdCTyxRQUFRLGVBQWUsQ0FBQyxJQUNoRDtBQUFBLElBQ0osRUFBRVAsS0FBSyxtQkFBbUJPLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRVAsS0FBSyxnQkFBZ0JPLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVQLEtBQUssVUFBVU8sUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyxhQUFhO0FBQUEsSUFDakIsRUFBRVIsS0FBSyxNQUFNTyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFUCxLQUFLLFFBQVFPLFFBQVEsWUFBWTtBQUFBLElBQ25DLEVBQUVQLEtBQUssb0JBQW9CTyxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUVQLEtBQUssU0FBU08sUUFBUSxhQUFhO0FBQUEsSUFDckMsRUFBRVAsS0FBSyxRQUFRTyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDO0FBQUEsTUFDRVAsS0FBSztBQUFBLE1BQ0xPLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxFQUFFUCxLQUFLLFlBQVlPLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVQLEtBQUssZ0JBQWdCTyxRQUFRLHdCQUF3QjtBQUFBLElBQ3ZELEVBQUVQLEtBQUssY0FBY08sUUFBUSxpQkFBaUI7QUFBQSxJQUM5QyxFQUFFUCxLQUFLLGtCQUFrQk8sUUFBUSxjQUFjO0FBQUEsSUFDL0MsRUFBRVAsS0FBSyxVQUFVTyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFUCxLQUFLLGNBQWNPLFFBQVEsU0FBUztBQUFBLElBQ3RDLEVBQUVQLEtBQUssUUFBUU8sUUFBUSxlQUFlO0FBQUEsSUFDdEMsR0FBSWxMLGtCQUNBLENBQUMsRUFBRTJLLEtBQUssZ0JBQWdCTyxRQUFRLGVBQWUsQ0FBQyxJQUNoRDtBQUFBLElBQ0osRUFBRVAsS0FBSyxtQkFBbUJPLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRVAsS0FBSyxnQkFBZ0JPLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVQLEtBQUssVUFBVU8sUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQ3hSLFlBQVUsTUFBTTtBQUNkLFFBQUk2RCxhQUFhOEUsU0FBUytJLFlBQVk7QUFDcEMsWUFBTUMsYUFBYzlOLFVBQVUrTixjQUFjLElBQUssT0FBTztBQUN4RCxZQUFNQyxjQUNIaE8sVUFBVStOLGVBQWUsTUFBTWpKLFNBQVMrSSxjQUFjO0FBQ3pELFlBQU1JLFlBQVluSixTQUFTK0ksY0FBYyxLQUFLQztBQUM5QyxZQUFNSSxnQkFBZ0JsTyxVQUFVbU8sZ0JBQzVCRixXQUFXak8sVUFBVW1PLGdCQUNyQjtBQUNKLFlBQU1DLFdBQVdwTyxVQUFVcU8saUJBQWlCLEtBQUtIO0FBRWpEbkosa0JBQVksQ0FBQ3lELGNBQWM7QUFBQSxRQUN6QixHQUFHQTtBQUFBQSxRQUNIeEQsVUFBVWhGLFVBQVUrSDtBQUFBQSxRQUNwQitGO0FBQUFBLFFBQ0FFO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsQ0FBQ3BPLFdBQVc4RSxTQUFTK0ksVUFBVSxDQUFDO0FBRW5DLFFBQU1TLDBCQUEwQkEsQ0FBQ3pNLE1BQU07QUFDckMsVUFBTTBNLGVBQWUxTSxFQUFFQyxPQUFPQztBQUM5QmQsbUJBQWVzTixZQUFZO0FBQzNCeEosZ0JBQVksQ0FBQ3lELGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNIbEQsVUFBVWlKO0FBQUFBLE1BQ1ZoSixnQkFBZ0JnSixpQkFBaUIsV0FBVy9GLFNBQVNqRCxpQkFBaUI7QUFBQSxJQUN4RSxFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1pSix3QkFBd0IsT0FBTzNGLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU0xQixXQUFXLE1BQU03SyxJQUFJOEssSUFBSSw4QkFBOEJ5QixPQUFPLEVBQUU7QUFDdEV0SSxzQkFBZ0I0RyxTQUFTRSxJQUFJO0FBQzdCaEgseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTaUgsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUVBLFFBQU1tSCxzQkFBc0IsWUFBWTtBQUN0QyxRQUFJbk8sY0FBYztBQUNoQixVQUFJO0FBQ0YsY0FBTWhFLElBQUlvUyxPQUFPLDJCQUEyQnBPLGFBQWF5SCxHQUFHLEVBQUU7QUFDOUQ0RyxjQUFNLDhCQUE4QjtBQUNwQ3RPLDJCQUFtQixLQUFLO0FBQ3hCRSx3QkFBZ0IsSUFBSTtBQUNwQnFPLGVBQU9DLFNBQVNDLE9BQU87QUFBQSxNQUN6QixTQUFTeEgsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSwyQkFBMkJBLEtBQUs7QUFBQSxNQUNoRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTXlILHdCQUF3QixPQUFPbEcsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTTFCLFdBQVcsTUFBTTdLLElBQUk4SyxJQUFJLDhCQUE4QnlCLE9BQU8sRUFBRTtBQUN0RWxJLDRCQUFzQndHLFNBQVNFLElBQUk7QUFDbkM1Ryx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVM2RyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMkJBQTJCQSxLQUFLO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBRUEsUUFBTTBILG1CQUFtQixPQUFPbk4sTUFBTTtBQUNwQ0EsTUFBRW9OLGVBQWU7QUFFakIsVUFBTUMsWUFBWSxJQUFJQyxTQUFTO0FBQy9CLFVBQU1DLFlBQVl2TixFQUFFQyxPQUFPdU47QUFDM0IsUUFBSUQsYUFBYUEsVUFBVUUsTUFBTSxDQUFDLEdBQUc7QUFDbkNKLGdCQUFVSyxPQUFPLFFBQVFILFVBQVVFLE1BQU0sQ0FBQyxDQUFDO0FBRTNDLFVBQUk7QUFDRixjQUFNbkksV0FBVyxNQUFNN0ssSUFBSWtULEtBQUssMEJBQTBCTixXQUFXO0FBQUEsVUFDbkVPLFNBQVMsRUFBRSxnQkFBZ0Isc0JBQXNCO0FBQUEsUUFDbkQsQ0FBQztBQUVELFlBQUl0SSxTQUFTdUksV0FBVyxLQUFLO0FBQzNCZixnQkFBTSw2QkFBNkI7QUFDbkNDLGlCQUFPQyxTQUFTQyxPQUFPO0FBQ3ZCak8sNkJBQW1CLEtBQUs7QUFBQSxRQUMxQjtBQUFBLE1BQ0YsU0FBU3lHLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDcUgsY0FBTSx3QkFBd0I7QUFBQSxNQUNoQztBQUFBLElBQ0YsT0FBTztBQUNMQSxZQUFNLGlDQUFpQztBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUVBLFNBQ0UsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLHNFQUNiLGlDQUFDLFNBQUksV0FBVSxXQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNMUksWUFBWUk7QUFBQUEsUUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWUc7QUFBQUE7QUFBQUEsTUFIdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRytCO0FBQUEsSUFFL0IsdUJBQUMsU0FBSSxXQUFVLHVGQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUdBQW9HLGlDQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSwyQkFBMEIseURBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0VBQ1o7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsUUFBTztBQUFBLGNBQ1AsU0FBUTtBQUFBLGNBRVI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsZUFBYztBQUFBLGtCQUNkLGdCQUFlO0FBQUEsa0JBQ2YsYUFBYTtBQUFBLGtCQUNiLEdBQUU7QUFBQTtBQUFBLGdCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUk2SjtBQUFBO0FBQUEsWUFWL0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUE7QUFBQSxVQUFNO0FBQUEsYUFiUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx1RUFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQyw2QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLHVCQUF1QjtBQUFBLGdCQUN2QixVQUFVK0M7QUFBQUEsZ0JBQ1YsT0FBTzNIO0FBQUFBLGdCQUNQLGFBQVk7QUFBQSxnQkFDWixjQUFjLENBQUNtTyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUdEMsWUFBWSxFQUNaaEQsU0FBU21GLE1BQU1uQyxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUVUeEUsdUJBQWFuQjtBQUFBQSxrQkFBSSxDQUFDa0ksU0FDakIsdUJBQUMsT0FBTyxRQUFQLEVBQStCLE9BQU9BLEtBQUtoTyxPQUN6Q2dPLGVBQUs5RyxTQURZOEcsS0FBS2hPLE9BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbUJBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxVQUdDVCxtQkFDQyxtQ0FDRTtBQUFBLG1DQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDJDQUEwQyx5QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9hO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ04sTUFBTU8sb0JBQW9CUCxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsa0JBQ25ELFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUk2SjtBQUFBLGlCQVIvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsdUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPTTtBQUFBQSxrQkFDUCxVQUFVLENBQUNSLE1BQU1TLGdCQUFnQlQsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGtCQUMvQyxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJNko7QUFBQSxpQkFSL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsVUFJRix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSwyQ0FBMEMscUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSx1QkFBdUI7QUFBQSxnQkFDdkIsT0FBT3JDO0FBQUFBLGdCQUNQLFVBQVV3SjtBQUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osY0FBYyxDQUFDeUcsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVHRDLFlBQVksRUFDWmhELFNBQVNtRixNQUFNbkMsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU8sSUFBSSxtQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQSxrQkFDNUJ4TyxPQUFPNkk7QUFBQUEsb0JBQUksQ0FBQ21FLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1qRSxLQUN6Q2lFLGdCQUFNTyxjQURXUCxNQUFNakUsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW9CQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSwyQ0FBMEMsd0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSx1QkFBdUI7QUFBQSxnQkFDdkIsT0FBT2xGO0FBQUFBLGdCQUNQLGNBQWMsQ0FBQzhNLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1R0QyxZQUFZLEVBQ1poRCxTQUFTbUYsTUFBTW5DLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxhQUFZO0FBQUEsZ0JBQ1osVUFBVSxDQUFDM0UsWUFBWS9GLHFCQUFxQitGLE9BQU87QUFBQSxnQkFDbkQsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQjtBQUFBLGtCQUMxQmpKLGNBQWNpSTtBQUFBQSxvQkFBSSxDQUFDbUUsVUFDbEIsdUJBQUMsT0FBTyxRQUFQLEVBQStCLE9BQU9BLE9BQU9qRSxLQUMzQ2lFO0FBQUFBLDZCQUFPaEU7QUFBQUEsc0JBQVU7QUFBQSxzQkFBSWdFLE1BQU05RDtBQUFBQSx5QkFEVjhELE9BQU9qRSxLQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsZUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDRDQUEyQyw0QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT3hGO0FBQUFBLGdCQUNQO0FBQUEsZ0JBQ0EsYUFBWTtBQUFBLGdCQUNaLHVCQUF1QjtBQUFBLGdCQUN2QixVQUFVLENBQUN5TixVQUFVO0FBQ25CeE4seUNBQXVCd04sS0FBSztBQUFBLGdCQUM5QjtBQUFBLGdCQUNBLGNBQWMsQ0FBQ0wsT0FBT0MsV0FDcEJBLE9BQU8zRyxNQUNKNkcsU0FBUyxFQUNUdEMsWUFBWSxFQUNaaEQsU0FBU21GLE1BQU1uQyxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRXlDLFFBQVEsT0FBTztBQUFBLGdCQUN4QixTQUFTO0FBQUEsa0JBQ1AsRUFBRWhILE9BQU8sUUFBUWxILE9BQU8sT0FBTztBQUFBLGtCQUMvQixFQUFFa0gsT0FBTyxVQUFVbEgsT0FBTyxTQUFTO0FBQUEsa0JBQ25DLEVBQUVrSCxPQUFPLGtCQUFrQmxILE9BQU8saUJBQWlCO0FBQUEsa0JBQ25ELEVBQUVrSCxPQUFPLHVCQUF1QmxILE9BQU8sZUFBZTtBQUFBLGtCQUN0RCxFQUFFa0gsT0FBTyxVQUFVbEgsT0FBTyxTQUFTO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGNBdEJ4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF1Qkk7QUFBQSxlQTVCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNENBQTJDLDJCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxXQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT2tCO0FBQUFBLGdCQUNQO0FBQUEsZ0JBQ0EsYUFBWTtBQUFBLGdCQUNaLHVCQUF1QjtBQUFBLGdCQUN2QixVQUFVLENBQUMrTSxVQUFVO0FBQ25COU0sd0NBQXNCOE0sS0FBSztBQUFBLGdCQUM3QjtBQUFBLGdCQUNBLGNBQWMsQ0FBQ0wsT0FBT0MsV0FDcEJBLE9BQU8zRyxNQUNKNkcsU0FBUyxFQUNUdEMsWUFBWSxFQUNaaEQsU0FBU21GLE1BQU1uQyxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUNWLFNBQVM7QUFBQSxrQkFDUCxFQUFFdkUsT0FBTyxRQUFRbEgsT0FBTyxPQUFPO0FBQUEsa0JBQy9CLEVBQUVrSCxPQUFPLFNBQVNsSCxPQUFPLFFBQVE7QUFBQSxrQkFDakMsRUFBRWtILE9BQU8sUUFBUWxILE9BQU8sT0FBTztBQUFBLGtCQUMvQixFQUFFa0gsT0FBTyxnQkFBZ0JsSCxPQUFPLGVBQWU7QUFBQSxnQkFBQztBQUFBO0FBQUEsY0FwQnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXFCSTtBQUFBLGVBekNOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkNBO0FBQUEsVUFHQzZDLHVCQUNDLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQyw0QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPakM7QUFBQUEsZ0JBQ1A7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osdUJBQXVCO0FBQUEsZ0JBQ3ZCLFVBQVUsQ0FBQ2tHLFlBQVlqRyx1QkFBdUJpRyxPQUFPO0FBQUEsZ0JBQ3JELGNBQWMsQ0FBQzhHLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1R0QyxZQUFZLEVBQ1poRCxTQUFTbUYsTUFBTW5DLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsbUNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFlBQVcsd0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdDO0FBQUEsa0JBQ3hDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFBUyxzQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0M7QUFBQSxrQkFDcEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxjQUFhLDBCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBO0FBQUE7QUFBQSxjQXRCdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBdUJBO0FBQUEsZUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxVQUlGLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQyxtQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWix1QkFBdUI7QUFBQSxnQkFDdkIsVUFBVSxDQUFDMEMsY0FBYztBQUN2Qix3QkFBTSxDQUFDN0QsSUFBSWhHLElBQUksSUFBSTZKLFVBQVVoTyxNQUFNLEdBQUcsS0FBSztBQUMzQyxzQkFBSW1FLFNBQVMsY0FBYztBQUN6Qi9DLHVDQUFtQitJLEVBQUU7QUFDckJqSix1Q0FBbUIsRUFBRTtBQUFBLGtCQUN2QixXQUFXaUQsU0FBUyxjQUFjO0FBQ2hDakQsdUNBQW1CaUosRUFBRTtBQUNyQi9JLHVDQUFtQixFQUFFO0FBQUEsa0JBQ3ZCLE9BQU87QUFDTEEsdUNBQW1CLEVBQUU7QUFDckJGLHVDQUFtQixFQUFFO0FBQUEsa0JBQ3ZCO0FBQUEsZ0JBQ0Y7QUFBQSxnQkFDQSxjQUFjLENBQUN1TSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUdEMsWUFBWSxFQUNaaEQsU0FBU21GLE1BQU1uQyxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQjtBQUFBLGtCQUMxQixDQUFDLEdBQUcsSUFBSTJDLElBQUk1TSxNQUFNLEdBQUcsR0FBRyxJQUFJNE0sSUFBSTFNLE1BQU0sQ0FBQyxFQUFFb0U7QUFBQUEsb0JBQUksQ0FBQ3VJLE9BQzdDO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBRUMsT0FBTyxHQUFHQSxHQUFHckksR0FBRyxJQUFJcUksR0FBR2pJLGFBQWE7QUFBQSx3QkFFbkNpSTtBQUFBQSw2QkFBR2pJLGtCQUFrQixlQUNsQixhQUNBO0FBQUEsMEJBQ0hpSSxHQUFHcEk7QUFBQUEsMEJBQVU7QUFBQSwwQkFBSW9JLEdBQUdsSTtBQUFBQTtBQUFBQTtBQUFBQSxzQkFOaEJrSSxJQUFJckk7QUFBQUEsc0JBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBcENIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXFDQTtBQUFBLGVBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMENBO0FBQUEsYUF6UUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBRQTtBQUFBLFdBNVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2UkE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx3Q0FFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSx1QkFBc0Isa0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUssVUFBVXpELGlCQUFpQixNQUFLLFNBQ3BDLGlDQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQUNsQjtBQUFBLG1DQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFDZjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixXQUFXLEVBQUUrTCxTQUFTLEdBQUc7QUFBQSxnQkFFekI7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsZ0RBQ2IsaUNBQUMsT0FBRSxXQUFVLHVDQUFzQyxpQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxRQUNFLHVCQUFDLG1CQUFnQixXQUFVLHNCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QztBQUFBLHNCQUUvQyxPQUFPMU0sT0FBT0U7QUFBQUEsc0JBQ2QsV0FBVztBQUFBLHNCQUNYLFlBQVk7QUFBQSx3QkFDVnlNLE9BQU87QUFBQSx3QkFDUEMsWUFBWTtBQUFBLHdCQUNaQyxVQUFVO0FBQUEsd0JBQ1ZDLFdBQVc7QUFBQSxzQkFDYjtBQUFBO0FBQUEsb0JBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVdJO0FBQUEsa0JBR0osdUJBQUMsU0FBSSxXQUFVLGlGQUNaNVIsOEJBQW9CK00sT0FBT2pJLE9BQU9FLEVBQUUsQ0FBQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUE7QUFBQTtBQUFBLGNBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQTtBQUFBLFlBQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUNmO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFdBQVcsRUFBRXdNLFNBQVMsR0FBRztBQUFBLGdCQUV6QjtBQUFBLHlDQUFDLFNBQUksV0FBVSxnREFDYixpQ0FBQyxPQUFFLFdBQVUsdUNBQXNDLDZCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFFBQ0UsdUJBQUMscUJBQWtCLFdBQVUsbUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTRDO0FBQUEsc0JBRTlDLE9BQU8xTSxPQUFPRztBQUFBQSxzQkFDZCxXQUFXO0FBQUEsc0JBQ1gsWUFBWTtBQUFBLHdCQUNWd00sT0FBTztBQUFBLHdCQUNQQyxZQUFZO0FBQUEsd0JBQ1pDLFVBQVU7QUFBQSx3QkFDVkMsV0FBVztBQUFBLHNCQUNiO0FBQUE7QUFBQSxvQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV0k7QUFBQSxrQkFHSix1QkFBQyxTQUFJLFdBQVUsaUZBQ1o1Uiw4QkFBb0IrTSxPQUFPakksT0FBT0csR0FBRyxDQUFDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBMkJBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsZUE1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2REEsS0E5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErREE7QUFBQSxhQW5FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0VBO0FBQUEsUUFFQSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUTtBQUFBLFFBRVIsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxTQUFNLE9BQU8sR0FBRyxXQUFVLHVCQUFzQixrQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBSyxVQUFVVSxpQkFBaUIsTUFBSyxTQUNwQyxpQ0FBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FDakI7QUFBQSxZQUNDO0FBQUEsY0FDRWtNLE9BQU87QUFBQSxjQUNQQyxLQUFLaEwsZUFBZUU7QUFBQUEsY0FDcEJ5SyxPQUFPO0FBQUEsY0FDUE0sSUFBSTtBQUFBLGNBQ0pDLE1BQU0sdUJBQUMsZ0JBQWEsV0FBVSxxQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUM7QUFBQSxZQUNqRDtBQUFBLFlBQ0E7QUFBQSxjQUNFSCxPQUFPO0FBQUEsY0FDUEMsS0FBS2hMLGVBQWVHO0FBQUFBLGNBQ3BCd0ssT0FBTztBQUFBLGNBQ1BNLElBQUk7QUFBQSxjQUNKQyxNQUNFLHVCQUFDLFVBQUssV0FBVSw0QkFBMkIsaUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsWUFFaEQ7QUFBQSxZQUNBO0FBQUEsY0FDRUgsT0FBTztBQUFBLGNBQ1BDLEtBQUtoTCxlQUFlSTtBQUFBQSxjQUNwQnVLLE9BQU87QUFBQSxjQUNQTSxJQUFJO0FBQUEsY0FDSkMsTUFBTSx1QkFBQyxrQkFBZSxXQUFVLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLFlBQ2pEO0FBQUEsWUFDQTtBQUFBLGNBQ0VILE9BQU87QUFBQSxjQUNQQyxLQUFLaEwsZUFBZUs7QUFBQUEsY0FDcEJzSyxPQUFPO0FBQUEsY0FDUE0sSUFBSTtBQUFBLGNBQ0pDLE1BQ0UsdUJBQUMsNkJBQTBCLFdBQVUsbUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9EO0FBQUEsWUFFeEQ7QUFBQSxVQUFDLEVBQ0RoSjtBQUFBQSxZQUFJLENBQUN5RixNQUFNd0QsUUFDWCx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFXLGdEQUFnRHhELEtBQUtzRCxFQUFFO0FBQUEsZ0JBQ2xFLFdBQVcsRUFBRVAsU0FBUyxHQUFHO0FBQUEsZ0JBR3pCO0FBQUEseUNBQUMsU0FBSSxXQUFVLGdEQUNiLGlDQUFDLE9BQUUsV0FBVSxnRUFDWCxpQ0FBQyxVQUFLLFdBQVUsZUFDYi9DO0FBQUFBLHlCQUFLdUQ7QUFBQUEsb0JBRUx2RCxLQUFLb0Q7QUFBQUEsdUJBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBR0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLE9BQU8sRUFBRUosT0FBT2hELEtBQUtnRCxNQUFNO0FBQUEsc0JBQUU7QUFBQTtBQUFBLHlCQUV6QmhELEtBQUtxRCxPQUFPLEdBQUcvRCxlQUFlLE9BQU87QUFBQTtBQUFBO0FBQUEsb0JBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksV0FBVSxpRkFDWi9OO0FBQUFBLHdDQUFvQnlPLEtBQUtxRCxPQUFPLENBQUM7QUFBQSxvQkFBRTtBQUFBLHVCQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUE7QUFBQTtBQUFBLGNBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTRCQSxLQTdCK0JHLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUEsVUFDRCxLQWxFSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1FQSxLQXBFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFFQTtBQUFBLGFBekVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwRUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSx1QkFBc0IsNkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUssVUFBVXBNLGFBQWEsTUFBSyxTQUNoQyxpQ0FBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FDakI7QUFBQSxZQUNDO0FBQUEsY0FDRWdNLE9BQU87QUFBQSxjQUNQQyxLQUFLM00sV0FBV0U7QUFBQUEsY0FDaEJvTSxPQUFPO0FBQUEsY0FDUE0sSUFBSTtBQUFBLGNBQ0pDLE1BQU0sdUJBQUMsa0JBQWUsV0FBVSxvQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEM7QUFBQSxZQUNsRDtBQUFBLFlBQ0E7QUFBQSxjQUNFSCxPQUFPO0FBQUEsY0FDUEMsS0FBSzNNLFdBQVdHO0FBQUFBLGNBQ2hCbU0sT0FBTztBQUFBLGNBQ1BNLElBQUk7QUFBQSxjQUNKQyxNQUFNLHVCQUFDLGtCQUFlLFdBQVUsbUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUEsWUFDakQ7QUFBQSxZQUNBO0FBQUEsY0FDRUgsT0FBTztBQUFBLGNBQ1BDLEtBQUszTSxXQUFXSTtBQUFBQSxjQUNoQmtNLE9BQU87QUFBQSxjQUNQTSxJQUFJO0FBQUEsY0FDSkMsTUFBTSx1QkFBQyxnQkFBYSxXQUFVLHFCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLFlBQ2pEO0FBQUEsWUFDQTtBQUFBLGNBQ0VILE9BQU87QUFBQSxjQUNQQyxLQUFLM00sV0FBV0s7QUFBQUEsY0FDaEJpTSxPQUFPO0FBQUEsY0FDUE8sTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQjtBQUFBLFlBQzVCO0FBQUEsVUFBQyxFQUNEaEo7QUFBQUEsWUFBSSxDQUFDbUYsTUFBTThELFFBQ1gsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxHQUNmO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyxnREFBZ0Q5RCxLQUFLNEQsRUFBRTtBQUFBLGdCQUNsRSxXQUFXLEVBQUVQLFNBQVMsR0FBRztBQUFBLGdCQUd6QjtBQUFBLHlDQUFDLFNBQUksV0FBVSxnREFDYixpQ0FBQyxPQUFFLFdBQVUsZ0VBQ1gsaUNBQUMsVUFBSyxXQUFVLGVBQ2JyRDtBQUFBQSx5QkFBSzZEO0FBQUFBLG9CQUNMN0QsS0FBSzBEO0FBQUFBLG9CQUFNO0FBQUEsdUJBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBR0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLE9BQU8sRUFBRUosT0FBT3RELEtBQUtzRCxNQUFNO0FBQUEsc0JBQUU7QUFBQTtBQUFBLHlCQUV6QnRELEtBQUsyRCxPQUFPLEdBQUcvRCxlQUFlLE9BQU87QUFBQTtBQUFBO0FBQUEsb0JBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksV0FBVSxpRkFDWi9OO0FBQUFBLHdDQUFvQm1PLEtBQUsyRCxPQUFPLENBQUM7QUFBQSxvQkFBRTtBQUFBLHVCQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUE7QUFBQTtBQUFBLGNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTBCQSxLQTNCdUJHLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsVUFDRCxLQTNESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTREQSxLQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThEQTtBQUFBLGFBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtRUE7QUFBQSxXQTFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMk5BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFJWmhSLDZCQUFtQkEsZ0JBQWdCdUwsU0FBUyxLQUFLLENBQUNqSyxZQUNqRCx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsUUFBTztBQUFBLGNBQ1AsU0FBUTtBQUFBLGNBRVI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsZUFBYztBQUFBLGtCQUNkLGdCQUFlO0FBQUEsa0JBQ2YsYUFBYTtBQUFBLGtCQUNiLEdBQUU7QUFBQTtBQUFBLGdCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUkwSDtBQUFBO0FBQUEsWUFWNUg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUE7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsK0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTTNDLGFBQWFTLGNBQWNnQyxVQUFVO0FBQUEsWUFDM0M7QUFBQSxZQUNBO0FBQUEsWUFDQSxpQkFBaUI7QUFBQSxjQUNmO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsWUFBUztBQUFBLFlBRVgsbUJBQW1CO0FBQUEsY0FDakJ5QyxPQUFPRTtBQUFBQSxjQUNQRixPQUFPRztBQUFBQSxjQUNQNkIsZUFBZUU7QUFBQUEsY0FDZkYsZUFBZUc7QUFBQUEsY0FDZkgsZUFBZUk7QUFBQUEsY0FDZkosZUFBZUs7QUFBQUEsY0FDZmhDLFdBQVdFO0FBQUFBLGNBQ1hGLFdBQVdHO0FBQUFBLGNBQ1hILFdBQVdJO0FBQUFBLGNBQ1hKLFdBQVdLO0FBQUFBLFlBQU87QUFBQSxZQUVwQixpQkFBaUI7QUFBQSxZQUNqQixrQkFBa0I7QUFBQTtBQUFBLFVBN0JwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE2QjBDO0FBQUEsUUFHMUMsdUJBQUMsU0FBSSxXQUFVLHVEQUNiLGlDQUFDLFNBQUksV0FBVSxtRUFDYixpQ0FBQyxVQUFLLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxVQUNsQztBQUFBLFVBQ2QsdUJBQUMsVUFBSyxXQUFVLG1CQUFrQjtBQUFBO0FBQUEsWUFDOUJ0QixVQUFVNkosZUFBZTtBQUFBLGVBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4REEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsMEVBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxTQUFTOU0sZ0JBQWdCdUwsVUFBVTtBQUFBLFVBQ25DLE1BQUs7QUFBQTtBQUFBLFFBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3FCLEtBSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxLQTNFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkVBO0FBQUEsU0FubEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvbEJBO0FBQUEsT0E5bEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErbEJBLEtBaG1CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaW1CQSxLQWxtQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1tQkE7QUFFSjtBQUFFdE0sR0E5MENJRCxlQUFhO0FBQUFpUyxLQUFialM7QUFnMUNOLGVBQWVBO0FBQWMsSUFBQWlTO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJNZERlbGV0ZSIsIkNpRWRpdCIsIk1vZGFsIiwiQnNFeWUiLCJVcGxvYWRNb2RhbCIsImF4aW9zIiwidXJsIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJJbnB1dCIsIlRhZyIsIkNhcmQiLCJTdGF0aXN0aWMiLCJSb3ciLCJDb2wiLCJFbXB0eSIsIlR5cG9ncmFwaHkiLCJEaXZpZGVyIiwiU3BpbiIsIlRleHQiLCJUaXRsZSIsIkFycm93VXBPdXRsaW5lZCIsIkFycm93RG93bk91dGxpbmVkIiwiV2FsbGV0T3V0bGluZWQiLCJHbG9iYWxPdXRsaW5lZCIsIkxpbmtPdXRsaW5lZCIsIlNhZmV0eUNlcnRpZmljYXRlT3V0bGluZWQiLCJCYW5rT3V0bGluZWQiLCJUaHVuZGVyYm9sdE91dGxpbmVkIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJFbmRsZXNzQ2lyY3VsYXJMb2FkZXIiLCJDaXJjdWxhckxvYWRlciIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIklvTWRNb3JlIiwiTGluayIsImZpZWxkU2l6ZSIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJQYXltZW50UmVwb3J0IiwiX3MiLCJncm91cHMiLCJzZXRHcm91cHMiLCJUYWJsZURheWJvb2siLCJzZXRUYWJsZURheWJvb2siLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsInNlbGVjdGVkQXVjdGlvbkdyb3VwIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXAiLCJzZWxlY3RlZEdyb3VwSWQiLCJzZXRTZWxlY3RlZEdyb3VwSWQiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWRBdWN0aW9uIiwic2V0RmlsdGVyZWRBdWN0aW9uIiwiZ3JvdXBJbmZvIiwic2V0R3JvdXBJbmZvIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwiY3VycmVudEdyb3VwIiwic2V0Q3VycmVudEdyb3VwIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudFVwZGF0ZUdyb3VwIiwic2V0Q3VycmVudFVwZGF0ZUdyb3VwIiwic2hvd1VwbG9hZE1vZGFsIiwic2V0U2hvd1VwbG9hZE1vZGFsIiwicmVjZWlwdE5vIiwic2V0UmVjZWlwdE5vIiwicGF5bWVudE1vZGUiLCJzZXRQYXltZW50TW9kZSIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwic2VsZWN0ZWRMYWJlbCIsInNldFNlbGVjdGVkTGFiZWwiLCJub3ciLCJEYXRlIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsInZhbHVlIiwidG9kYXlTdHJpbmciLCJ0b0lTT1N0cmluZyIsInNwbGl0Iiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJzZWxlY3RlZFBheW1lbnRNb2RlIiwic2V0U2VsZWN0ZWRQYXltZW50TW9kZSIsImhpZGVBY2NvdW50VHlwZSIsInNldEhpZGVBY2NvdW50VHlwZSIsInNlbGVjdGVkQWNjb3VudFR5cGUiLCJzZXRTZWxlY3RlZEFjY291bnRUeXBlIiwic2VsZWN0ZWRDdXN0b21lcnMiLCJzZXRTZWxlY3RlZEN1c3RvbWVycyIsInBheW1lbnRzIiwic2V0UGF5bWVudHMiLCJzZWxlY3RlZFBheW1lbnRGb3IiLCJzZXRTZWxlY3RlZFBheW1lbnRGb3IiLCJjb2xsZWN0aW9uQWdlbnQiLCJzZXRDb2xsZWN0aW9uQWdlbnQiLCJjb2xsZWN0aW9uQWRtaW4iLCJzZXRDb2xsZWN0aW9uQWRtaW4iLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJhZG1pbnMiLCJzZXRBZG1pbnMiLCJ0b3RhbHMiLCJzZXRUb3RhbHMiLCJpbiIsIm91dCIsIm5ldCIsIm1vZGVUb3RhbHMiLCJzZXRNb2RlVG90YWxzIiwiY2FzaCIsIm9ubGluZSIsImxpbmsiLCJhdXRvcGF5Iiwib3ZlcnZpZXdMb2FkaW5nIiwic2V0T3ZlcnZpZXdMb2FkaW5nIiwiY2F0ZWdvcnlMb2FkaW5nIiwic2V0Q2F0ZWdvcnlMb2FkaW5nIiwibW9kZUxvYWRpbmciLCJzZXRNb2RlTG9hZGluZyIsInNob3dBbGxQYXltZW50TW9kZXMiLCJzZXRTaG93QWxsUGF5bWVudE1vZGVzIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImdyb3VwX2lkIiwidXNlcl9pZCIsInRpY2tldCIsInJlY2VpcHRfbm8iLCJwYXlfZGF0ZSIsImFtb3VudCIsInBheV90eXBlIiwidHJhbnNhY3Rpb25faWQiLCJjb2xsZWN0ZWRfYnkiLCJhZG1pbl90eXBlIiwiY29sbGVjdGlvbl90aW1lIiwiY2F0ZWdvcnlUb3RhbHMiLCJzZXRDYXRlZ29yeVRvdGFscyIsImNoaXQiLCJsb2FuIiwicGlnbWUiLCJyZWdpc3RyYXRpb24iLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiaGFuZGxlTW9kYWxDbG9zZSIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsImFjY2Vzc19wZXJtaXNzaW9ucyIsImVkaXRfcGF5bWVudCIsInNob3dQYXltZW50c01vZGVzIiwiaXNNb2RpZnkiLCJmZXRjaEdyb3VwcyIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImVtcGxveWVlcyIsIlByb21pc2UiLCJhbGwiLCJlbXBzIiwiZW1wbG95ZWUiLCJtYXAiLCJlbXAiLCJfaWQiLCJmdWxsX25hbWUiLCJuYW1lIiwicGhvbmVfbnVtYmVyIiwic2VsZWN0ZWRfdHlwZSIsImFkbXMiLCJhZCIsInBob25lTnVtYmVyIiwiZmV0Y2hSZWNlaXB0IiwicHJldkRhdGEiLCJoYW5kbGVDaGFuZ2UiLCJoYW5kbGVDaGFuZ2VVc2VyIiwiaGFuZGxlR3JvdXAiLCJldmVudCIsImdyb3VwSWQiLCJwcmV2Rm9ybURhdGEiLCJoYW5kbGVHcm91cENoYW5nZSIsImdyb3VwT3B0aW9ucyIsImxhYmVsIiwiaGFuZGxlR3JvdXBQYXltZW50IiwiaGFuZGxlU2VsZWN0RmlsdGVyIiwidG9kYXkiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImZvcm1hdHRlZCIsInllc3RlcmRheSIsInNldERhdGUiLCJnZXREYXRlIiwic3RhcnQiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZW5kIiwiZm9ybWF0UGF5RGF0ZSIsImRhdGVTdHJpbmciLCJvcHRpb25zIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwicmVwbGFjZSIsInBheW1lbnRNb2RlcyIsImluY2x1ZGVzIiwicHVzaCIsImFib3J0Q29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsImZldGNoUGF5bWVudHMiLCJwYXJhbXMiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwidXNlcklkIiwiYWNjb3VudF90eXBlIiwicGF5X2ZvciIsInNpZ25hbCIsImluZm8iLCJsZW5ndGgiLCJ2YWxpZFBheW1lbnRzIiwiZmlsdGVyIiwicGF5bWVudCIsInRvdGFsQW1vdW50IiwicmVkdWNlIiwic3VtIiwiTnVtYmVyIiwidGluIiwidG91dCIsImZvcm1hdHRlZERhdGEiLCJncm91cCIsImluZGV4IiwiYW10IiwiTWF0aCIsImFicyIsImlkIiwidHlwZV9yYXciLCJncm91cF9uYW1lIiwiY2F0ZWdvcnkiLCJvbGRfcmVjZWlwdF9ubyIsImxvYW5faWQiLCJwaWdtZV9pZCIsInRvTG9jYWxlU3RyaW5nIiwiYW1vdW50X3JhdyIsInRyYW5zYWN0aW9uX2RhdGUiLCJjcmVhdGVkQXQiLCJtb2RlIiwiYWRtaW5fbmFtZSIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwiZm9yRWFjaCIsIml0ZW0iLCJwZiIsInRvTG93ZXJDYXNlIiwiYWJvcnQiLCJjb2x1bW5zIiwiaGVhZGVyIiwiZXhwb3J0Q29scyIsImJpZF9hbW91bnQiLCJjb21taXNzaW9uIiwiZ3JvdXBfdmFsdWUiLCJ3aW5fYW1vdW50IiwiZGl2aWRlbnQiLCJkaXZpZGVudF9oZWFkIiwiZ3JvdXBfbWVtYmVycyIsInBheWFibGUiLCJncm91cF9pbnN0YWxsIiwiaGFuZGxlUGF5bWVudE1vZGVDaGFuZ2UiLCJzZWxlY3RlZE1vZGUiLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJoYW5kbGVEZWxldGVBdWN0aW9uIiwiZGVsZXRlIiwiYWxlcnQiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsInJlbG9hZCIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZUZpbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImZvcm1EYXRhcyIsIkZvcm1EYXRhIiwiZmlsZUlucHV0IiwiZmlsZSIsImZpbGVzIiwiYXBwZW5kIiwicG9zdCIsImhlYWRlcnMiLCJzdGF0dXMiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0aW1lIiwibW9kZXMiLCJoZWlnaHQiLCJzZWxlY3Rpb24iLCJTZXQiLCJkdCIsInBhZGRpbmciLCJjb2xvciIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsInRleHRBbGlnbiIsInRpdGxlIiwidmFsIiwiYmciLCJpY29uIiwiaWR4IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGF5bWVudFJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBNZERlbGV0ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBDaUVkaXQgfSBmcm9tIFwicmVhY3QtaWNvbnMvY2lcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBCc0V5ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9ic1wiO1xyXG5pbXBvcnQgVXBsb2FkTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL1VwbG9hZE1vZGFsXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHVybCBmcm9tIFwiLi4vZGF0YS9VcmxcIjtcclxuaW1wb3J0IHtcclxuICBTZWxlY3QsXHJcbiAgRHJvcGRvd24sXHJcbiAgSW5wdXQsXHJcbiAgVGFnLFxyXG4gIENhcmQsXHJcbiAgU3RhdGlzdGljLFxyXG4gIFJvdyxcclxuICBDb2wsXHJcbiAgRW1wdHksXHJcbiAgVHlwb2dyYXBoeSxcclxuICBEaXZpZGVyLFxyXG4gIFNwaW4sXHJcbn0gZnJvbSBcImFudGRcIjtcclxuY29uc3QgeyBUZXh0LCBUaXRsZSB9ID0gVHlwb2dyYXBoeTtcclxuXHJcbmltcG9ydCB7XHJcbiAgQXJyb3dVcE91dGxpbmVkLFxyXG4gIEFycm93RG93bk91dGxpbmVkLFxyXG4gIFdhbGxldE91dGxpbmVkLFxyXG4gIEdsb2JhbE91dGxpbmVkLFxyXG4gIExpbmtPdXRsaW5lZCxcclxuICBTYWZldHlDZXJ0aWZpY2F0ZU91dGxpbmVkLFxyXG4gIEJhbmtPdXRsaW5lZCxcclxuICBUaHVuZGVyYm9sdE91dGxpbmVkLFxyXG59IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5cclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBFbmRsZXNzQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9FbmRsZXNzQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcblxyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiO1xyXG5cclxuY29uc3QgUGF5bWVudFJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZURheWJvb2ssIHNldFRhYmxlRGF5Ym9va10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkQXVjdGlvbkdyb3VwLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cElkLCBzZXRTZWxlY3RlZEdyb3VwSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkQXVjdGlvbkdyb3VwSWQsIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZEF1Y3Rpb24sIHNldEZpbHRlcmVkQXVjdGlvbl0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3VwSW5mbywgc2V0R3JvdXBJbmZvXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxEZWxldGUsIHNldFNob3dNb2RhbERlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRHcm91cCwgc2V0Q3VycmVudEdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxVcGRhdGUsIHNldFNob3dNb2RhbFVwZGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVHcm91cCwgc2V0Q3VycmVudFVwZGF0ZUdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93VXBsb2FkTW9kYWwsIHNldFNob3dVcGxvYWRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlY2VpcHRObywgc2V0UmVjZWlwdE5vXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXltZW50TW9kZSwgc2V0UGF5bWVudE1vZGVdID0gdXNlU3RhdGUoXCJjYXNoXCIpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dGaWx0ZXJGaWVsZCwgc2V0U2hvd0ZpbHRlckZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIlRvZGF5XCIpO1xyXG5cclxuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IHRvZGF5U3RyaW5nID0gbm93LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEZyb21EYXRlLCBzZXRTZWxlY3RlZEZyb21EYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyaW5nKTtcclxuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUodG9kYXlTdHJpbmcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBheW1lbnRNb2RlLCBzZXRTZWxlY3RlZFBheW1lbnRNb2RlXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaGlkZUFjY291bnRUeXBlLCBzZXRIaWRlQWNjb3VudFR5cGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkQWNjb3VudFR5cGUsIHNldFNlbGVjdGVkQWNjb3VudFR5cGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkQ3VzdG9tZXJzLCBzZXRTZWxlY3RlZEN1c3RvbWVyc10gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcGF5bWVudHMsIHNldFBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYXltZW50Rm9yLCBzZXRTZWxlY3RlZFBheW1lbnRGb3JdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjb2xsZWN0aW9uQWdlbnQsIHNldENvbGxlY3Rpb25BZ2VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY29sbGVjdGlvbkFkbWluLCBzZXRDb2xsZWN0aW9uQWRtaW5dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWRtaW5zLCBzZXRBZG1pbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0b3RhbHMsIHNldFRvdGFsc10gPSB1c2VTdGF0ZSh7IGluOiAwLCBvdXQ6IDAsIG5ldDogMCB9KTtcclxuICBjb25zdCBbbW9kZVRvdGFscywgc2V0TW9kZVRvdGFsc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBjYXNoOiAwLFxyXG4gICAgb25saW5lOiAwLFxyXG4gICAgbGluazogMCxcclxuICAgIGF1dG9wYXk6IDAsXHJcbiAgfSk7XHJcbiAgY29uc3QgW292ZXJ2aWV3TG9hZGluZywgc2V0T3ZlcnZpZXdMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtjYXRlZ29yeUxvYWRpbmcsIHNldENhdGVnb3J5TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbbW9kZUxvYWRpbmcsIHNldE1vZGVMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtzaG93QWxsUGF5bWVudE1vZGVzLCBzZXRTaG93QWxsUGF5bWVudE1vZGVzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIHRpY2tldDogXCJcIixcclxuICAgIHJlY2VpcHRfbm86IFwiXCIsXHJcbiAgICBwYXlfZGF0ZTogXCJcIixcclxuICAgIGFtb3VudDogXCJcIixcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgY29sbGVjdGVkX2J5OiBjb2xsZWN0aW9uQWdlbnQsXHJcbiAgICBhZG1pbl90eXBlOiBjb2xsZWN0aW9uQWRtaW4sXHJcbiAgICBjb2xsZWN0aW9uX3RpbWU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2NhdGVnb3J5VG90YWxzLCBzZXRDYXRlZ29yeVRvdGFsc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBjaGl0OiAwLFxyXG4gICAgbG9hbjogMCxcclxuICAgIHBpZ21lOiAwLFxyXG4gICAgcmVnaXN0cmF0aW9uOiAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgaGFuZGxlTW9kYWxDbG9zZSA9ICgpID0+IHNldFNob3dVcGxvYWRNb2RhbChmYWxzZSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBjb25zdCB1c2VyT2JqID0gSlNPTi5wYXJzZSh1c2VyKTtcclxuXHJcbiAgICBpZiAoXHJcbiAgICAgIHVzZXJPYmogJiZcclxuICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50XHJcbiAgICApIHtcclxuICAgICAgY29uc3Qgc2hvd1BheW1lbnRzTW9kZXMgPVxyXG4gICAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudCA9PT1cclxuICAgICAgICAgIFwidHJ1ZVwiXHJcbiAgICAgICAgICA/IHRydWVcclxuICAgICAgICAgIDogZmFsc2U7XHJcbiAgICAgIHNldFNob3dBbGxQYXltZW50TW9kZXMoc2hvd1BheW1lbnRzTW9kZXMpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG5cclxuICAgIGlmIChcclxuICAgICAgdXNlck9iaiAmJlxyXG4gICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnRcclxuICAgICkge1xyXG4gICAgICBjb25zdCBpc01vZGlmeSA9XHJcbiAgICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50ID09PVxyXG4gICAgICAgICAgXCJ0cnVlXCJcclxuICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgc2V0SGlkZUFjY291bnRUeXBlKGlzTW9kaWZ5KTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBbZW1wbG95ZWVzLCBhZG1pbnNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgYXBpLmdldChcIi9lbXBsb3llZVwiKSxcclxuICAgICAgICAgIGFwaS5nZXQoXCIvYWRtaW4vZ2V0LXN1Yi1hZG1pbnNcIiksXHJcbiAgICAgICAgXSk7XHJcbiAgICAgICAgY29uc3QgZW1wcyA9IGVtcGxveWVlcz8uZGF0YT8uZW1wbG95ZWUubWFwKChlbXApID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGVtcC5faWQsXHJcbiAgICAgICAgICBmdWxsX25hbWU6IGVtcC5uYW1lLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBlbXAucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgc2VsZWN0ZWRfdHlwZTogXCJhZ2VudF90eXBlXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldEFnZW50cyhlbXBzKTtcclxuICAgICAgICBjb25zdCBhZG1zID0gYWRtaW5zPy5kYXRhPy5tYXAoKGFkKSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBhZD8uX2lkLFxyXG4gICAgICAgICAgZnVsbF9uYW1lOiBhZD8ubmFtZSxcclxuICAgICAgICAgIHBob25lX251bWJlcjogYWQ/LnBob25lTnVtYmVyLFxyXG4gICAgICAgICAgc2VsZWN0ZWRfdHlwZTogXCJhZG1pbl90eXBlXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldEFkbWlucyhhZG1zKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRBZG1pbnMoW10pO1xyXG4gICAgICAgIHNldEFnZW50cyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH0pKCk7XHJcbiAgfSwgW10pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFJlY2VpcHQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3BheW1lbnQvZ2V0LWxhdGVzdC1yZWNlaXB0XCIpO1xyXG4gICAgICAgIHNldFJlY2VpcHRObyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcmVjZWlwdCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFJlY2VpcHQoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChyZWNlaXB0Tm8pIHtcclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgIHJlY2VpcHRfbm86IHJlY2VpcHROby5yZWNlaXB0X25vLFxyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfSwgW3JlY2VpcHROb10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZVVzZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBjb25zdCBbdXNlcl9pZCwgdGlja2V0XSA9IHZhbHVlLnNwbGl0KFwiLVwiKTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIHVzZXJfaWQsXHJcbiAgICAgIHRpY2tldCxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cCA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgY29uc3QgZ3JvdXBJZCA9IGV2ZW50LnRhcmdldC52YWx1ZTtcclxuICAgIHNldFNlbGVjdGVkR3JvdXBJZChncm91cElkKTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2Rm9ybURhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZGb3JtRGF0YSxcclxuICAgICAgZ3JvdXBfaWQ6IGdyb3VwSWQsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgaGFuZGxlR3JvdXBDaGFuZ2UoZ3JvdXBJZCk7XHJcblxyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9ncm91cC9nZXQtYnktaWQtZ3JvdXAvJHtncm91cElkfWApO1xyXG4gICAgICAgIHNldEdyb3VwSW5mbyhyZXNwb25zZS5kYXRhIHx8IHt9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEdyb3VwSW5mbyh7fSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEdyb3VwSW5mbyh7fSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gW1xyXG4gICAgeyB2YWx1ZTogXCJUb2RheVwiLCBsYWJlbDogXCJUb2RheVwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlllc3RlcmRheVwiLCBsYWJlbDogXCJZZXN0ZXJkYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJUaGlzTW9udGhcIiwgbGFiZWw6IFwiVGhpcyBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkxhc3RNb250aFwiLCBsYWJlbDogXCJMYXN0IE1vbnRoXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc1llYXJcIiwgbGFiZWw6IFwiVGhpcyBZZWFyXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiQ3VzdG9tXCIsIGxhYmVsOiBcIkN1c3RvbVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBQYXltZW50ID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIC8vIGNvbnN0IGdyb3VwSWQgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkKGdyb3VwSWQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcbiAgICAvL2NvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2hvd0ZpbHRlckZpZWxkKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcblxyXG4gICAgaWYgKHZhbHVlID09PSBcIlRvZGF5XCIpIHtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0dGVkKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdHRlZCk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbiAgICAgIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgeWVzdGVyZGF5LnNldERhdGUoeWVzdGVyZGF5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHllc3RlcmRheSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0dGVkKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdHRlZCk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGZvcm1hdFBheURhdGUgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgY29uc3Qgb3B0aW9ucyA9IHsgZGF5OiBcIm51bWVyaWNcIiwgbW9udGg6IFwibG9uZ1wiLCB5ZWFyOiBcIm51bWVyaWNcIiB9O1xyXG4gICAgcmV0dXJuIGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tVVNcIiwgb3B0aW9ucykucmVwbGFjZShcIixcIiwgXCJcIik7XHJcbiAgfTtcclxuXHJcbiAgbGV0IHBheW1lbnRNb2RlcyA9IFsuLi5zZWxlY3RlZFBheW1lbnRNb2RlXTtcclxuXHJcbiAgaWYgKFxyXG4gICAgcGF5bWVudE1vZGVzLmluY2x1ZGVzKFwib25saW5lXCIpICYmXHJcbiAgICAhcGF5bWVudE1vZGVzLmluY2x1ZGVzKFwiY2hlcXVlXCIpXHJcbiAgKSB7XHJcbiAgICBwYXltZW50TW9kZXMucHVzaChcImNoZXF1ZVwiKTtcclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XHJcbiAgICBjb25zdCBmZXRjaFBheW1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBzZXRPdmVydmlld0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgc2V0Q2F0ZWdvcnlMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIHNldE1vZGVMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvZ2V0LXJlY2VpcHQtcmVwb3J0YCwge1xyXG4gICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgIGZyb21fZGF0ZTogc2VsZWN0ZWRGcm9tRGF0ZSxcclxuICAgICAgICAgICAgdG9fZGF0ZTogc2VsZWN0ZWREYXRlLFxyXG4gICAgICAgICAgICBncm91cElkOiBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLFxyXG4gICAgICAgICAgICB1c2VySWQ6IHNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgICAgICAgICBwYXlfdHlwZTogcGF5bWVudE1vZGVzLFxyXG4gICAgICAgICAgICBhY2NvdW50X3R5cGU6IHNlbGVjdGVkQWNjb3VudFR5cGUsXHJcbiAgICAgICAgICAgIGNvbGxlY3RlZF9ieTogY29sbGVjdGlvbkFnZW50LFxyXG4gICAgICAgICAgICBhZG1pbl90eXBlOiBjb2xsZWN0aW9uQWRtaW4sXHJcbiAgICAgICAgICAgIHBheV9mb3I6IHNlbGVjdGVkUGF5bWVudEZvcixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWwsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlLmRhdGEsIFwidGVzdGluZyBhY2NvdW50IHR5cGVcIik7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCB2YWxpZFBheW1lbnRzID0gcmVzcG9uc2UuZGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgIChwYXltZW50KSA9PiBwYXltZW50Lmdyb3VwX2lkICE9PSBudWxsLFxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24odmFsaWRQYXltZW50cyk7XHJcblxyXG4gICAgICAgICAgY29uc3QgdG90YWxBbW91bnQgPSB2YWxpZFBheW1lbnRzLnJlZHVjZShcclxuICAgICAgICAgICAgKHN1bSwgcGF5bWVudCkgPT4gc3VtICsgTnVtYmVyKHBheW1lbnQuYW1vdW50IHx8IDApLFxyXG4gICAgICAgICAgICAwLFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIGNvbnNvbGUuaW5mbyh0b3RhbEFtb3VudCwgXCJjaGVjayBhbW91bnRcIik7XHJcbiAgICAgICAgICBzZXRQYXltZW50cyh0b3RhbEFtb3VudCk7XHJcbiAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSkge1xyXG4gICAgICAgICAgICBsZXQgdGluID0gMCxcclxuICAgICAgICAgICAgICB0b3V0ID0gMDtcclxuICAgICAgICAgICAgbGV0IGNhc2ggPSAwO1xyXG4gICAgICAgICAgICBsZXQgb25saW5lID0gMDtcclxuICAgICAgICAgICAgbGV0IGxpbmsgPSAwO1xyXG4gICAgICAgICAgICBsZXQgYXV0b3BheSA9IDA7XHJcblxyXG4gICAgICAgICAgICAvLyBjb25zdCBmb3JtYXR0ZWREYXRhID0gdmFsaWRQYXltZW50cy5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgLy8gICBfaWQ6IGdyb3VwPy5faWQsXHJcbiAgICAgICAgICAgIC8vICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgLy8gICBkYXRlOiBncm91cD8ucGF5X2RhdGUsXHJcbiAgICAgICAgICAgIC8vICAgZ3JvdXA6IGdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBncm91cC5wYXlfZm9yLFxyXG4gICAgICAgICAgICAvLyAgIG5hbWU6IGdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgIC8vICAgY2F0ZWdvcnk6IGdyb3VwPy5wYXlfZm9yIHx8IFwiQ2hpdFwiLFxyXG4gICAgICAgICAgICAvLyAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgLy8gICByZWNlaXB0X25vOiBncm91cD8ucmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgLy8gICBvbGRfcmVjZWlwdF9ubzogZ3JvdXA/Lm9sZF9yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAvLyAgIHRpY2tldDogZ3JvdXA/LmxvYW5cclxuICAgICAgICAgICAgLy8gICAgID8gZ3JvdXAubG9hbj8ubG9hbl9pZFxyXG4gICAgICAgICAgICAvLyAgICAgOiBncm91cD8ucGlnbWVcclxuICAgICAgICAgICAgLy8gICAgICAgPyBncm91cC5waWdtZT8ucGlnbWVfaWRcclxuICAgICAgICAgICAgLy8gICAgICAgOiBncm91cD8udGlja2V0LFxyXG4gICAgICAgICAgICAvLyAgIGFtb3VudDogZ3JvdXA/LmFtb3VudCxcclxuICAgICAgICAgICAgLy8gICB0cmFuc2FjdGlvbl9kYXRlOiBncm91cD8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIik/LlswXSxcclxuICAgICAgICAgICAgLy8gICBtb2RlOiBncm91cD8ucGF5X3R5cGUsXHJcbiAgICAgICAgICAgIC8vICAgYWNjb3VudF90eXBlOiBncm91cD8uYWNjb3VudF90eXBlLFxyXG4gICAgICAgICAgICAvLyAgIGNvbGxlY3Rpb25fdGltZTogZ3JvdXA/LmNvbGxlY3Rpb25fdGltZSxcclxuICAgICAgICAgICAgLy8gICBjb2xsZWN0ZWRfYnk6XHJcbiAgICAgICAgICAgIC8vICAgICBncm91cD8uY29sbGVjdGVkX2J5Py5uYW1lIHx8XHJcbiAgICAgICAgICAgIC8vICAgICBncm91cD8uYWRtaW5fdHlwZT8uYWRtaW5fbmFtZSB8fFxyXG4gICAgICAgICAgICAvLyAgICAgXCJTdXBlciBBZG1pblwiLFxyXG4gICAgICAgICAgICAvLyAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAvLyAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIC8vICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAvLyAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAvLyAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgLy8gICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICAgICAgICB0bz17YC9wcmludC8ke2dyb3VwLl9pZH1gfVxyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIFwiXHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICAgIFByaW50XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgLy8gICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIC8vICAgICAgICAgfX1cclxuICAgICAgICAgICAgLy8gICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgLy8gICAgICAgPlxyXG4gICAgICAgICAgICAvLyAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAvLyAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAvLyAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIC8vICAgKSxcclxuICAgICAgICAgICAgLy8gfSkpO1xyXG4gICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gdmFsaWRQYXltZW50cy5tYXAoKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGFtdCA9IE51bWJlcihncm91cC5hbW91bnQgfHwgMCk7XHJcblxyXG4gICAgICAgICAgICAgIC8vIOKchSBUWVBFIFRPVEFMIENBTENVTEFUSU9OIChzYW1lIGFzIGRheWJvb2spXHJcbiAgICAgICAgICAgICAgaWYgKGdyb3VwLnR5cGUgPT09IFwiSU5cIikgdGluICs9IGFtdDtcclxuICAgICAgICAgICAgICBlbHNlIHRvdXQgKz0gTWF0aC5hYnMoYW10KTtcclxuXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIF9pZDogZ3JvdXA/Ll9pZCxcclxuICAgICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcblxyXG4gICAgICAgICAgICAgICAgLy8g4pyFIFRZUEUgQ09MVU1OIEFEREVEXHJcbiAgICAgICAgICAgICAgICB0eXBlOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxUYWcgY29sb3I9e2dyb3VwPy50eXBlID09PSBcIklOXCIgPyBcImdyZWVuXCIgOiBcInZvbGNhbm9cIn0+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3VwPy50eXBlID8/IFwiVW5rbm93blwifVxyXG4gICAgICAgICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICB0eXBlX3JhdzogZ3JvdXA/LnR5cGUsXHJcblxyXG4gICAgICAgICAgICAgICAgZGF0ZTogZ3JvdXA/LnBheV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXA6IGdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBncm91cC5wYXlfZm9yLFxyXG4gICAgICAgICAgICAgICAgbmFtZTogZ3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICAgIGNhdGVnb3J5OiBncm91cD8ucGF5X2ZvciB8fCBcIkNoaXRcIixcclxuICAgICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAgIHJlY2VpcHRfbm86IGdyb3VwPy5yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgICAgb2xkX3JlY2VpcHRfbm86IGdyb3VwPy5vbGRfcmVjZWlwdF9ubyxcclxuXHJcbiAgICAgICAgICAgICAgICB0aWNrZXQ6XHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwPy5sb2FuPy5sb2FuX2lkID8/XHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwPy5waWdtZT8ucGlnbWVfaWQgPz9cclxuICAgICAgICAgICAgICAgICAgZ3JvdXA/LnRpY2tldCxcclxuXHJcbiAgICAgICAgICAgICAgICBhbW91bnQ6IChcclxuICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LnR5cGUgPT09IFwiSU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi02MDAgZm9udC1ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtcmVkLTYwMCBmb250LWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuSB7TWF0aC5hYnMoYW10KS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgYW1vdW50X3JhdzogYW10LFxyXG5cclxuICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IGdyb3VwPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKT8uWzBdLFxyXG4gICAgICAgICAgICAgICAgbW9kZTogZ3JvdXA/LnBheV90eXBlLFxyXG4gICAgICAgICAgICAgICAgYWNjb3VudF90eXBlOiBncm91cD8uYWNjb3VudF90eXBlLFxyXG4gICAgICAgICAgICAgICAgY29sbGVjdGlvbl90aW1lOiBncm91cD8uY29sbGVjdGlvbl90aW1lLFxyXG5cclxuICAgICAgICAgICAgICAgIGNvbGxlY3RlZF9ieTpcclxuICAgICAgICAgICAgICAgICAgZ3JvdXA/LmNvbGxlY3RlZF9ieT8ubmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICBncm91cD8uYWRtaW5fdHlwZT8uYWRtaW5fbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICBcIlN1cGVyIEFkbWluXCIsXHJcblxyXG4gICAgICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YC9wcmludC8ke2dyb3VwLl9pZH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgbGV0IGNoaXQgPSAwLFxyXG4gICAgICAgICAgICAgIGxvYW4gPSAwLFxyXG4gICAgICAgICAgICAgIHBpZ21lID0gMCxcclxuICAgICAgICAgICAgICByZWdpc3RyYXRpb24gPSAwO1xyXG5cclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YS5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKGl0ZW0udHlwZSAhPT0gXCJJTlwiKSByZXR1cm47XHJcblxyXG4gICAgICAgICAgICAgIGNvbnN0IGFtdCA9IE51bWJlcihpdGVtLmFtb3VudCB8fCAwKTtcclxuICAgICAgICAgICAgICBjb25zdCBwZiA9IChpdGVtLnBheV9mb3IgfHwgXCJDaGl0XCIpLnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgICAgICAgICAgIGlmIChwZi5pbmNsdWRlcyhcImxvYW5cIikpIGxvYW4gKz0gYW10O1xyXG4gICAgICAgICAgICAgIGVsc2UgaWYgKHBmLmluY2x1ZGVzKFwicGlnbWVcIikpIHBpZ21lICs9IGFtdDtcclxuICAgICAgICAgICAgICBlbHNlIGlmIChwZi5pbmNsdWRlcyhcInJlZ1wiKSkgcmVnaXN0cmF0aW9uICs9IGFtdDtcclxuICAgICAgICAgICAgICBlbHNlIGNoaXQgKz0gYW10O1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGEuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGFtdCA9IE51bWJlcihpdGVtLmFtb3VudCB8fCAwKTtcclxuXHJcbiAgICAgICAgICAgICAgaWYgKGl0ZW0udHlwZSAhPT0gXCJJTlwiKSByZXR1cm47XHJcblxyXG4gICAgICAgICAgICAgIGNvbnN0IG1vZGUgPSAoaXRlbS5wYXlfdHlwZSB8fCBcIlwiKS50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgICAgICAgICAgICBpZiAobW9kZSA9PT0gXCJhdXRvcGF5XCIgfHwgbW9kZSA9PT0gXCJvbmxpbmUvYXV0b3BheVwiIHx8IG1vZGUuaW5jbHVkZXMoXCJhdXRvcGF5XCIpKSB7XHJcbiAgICAgICAgICAgICAgICBhdXRvcGF5ICs9IGFtdDtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgZWxzZSBpZiAobW9kZSA9PT0gXCJjYXNoXCIpIHtcclxuICAgICAgICAgICAgICAgIGNhc2ggKz0gYW10O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBlbHNlIGlmIChtb2RlID09PSBcIm9ubGluZVwiIHx8IG1vZGUgPT09IFwiY2hlcXVlXCIpIHtcclxuICAgICAgICAgICAgICAgIG9ubGluZSArPSBhbXQ7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGVsc2UgaWYgKG1vZGUuaW5jbHVkZXMoXCJsaW5rXCIpKSB7XHJcbiAgICAgICAgICAgICAgICBsaW5rICs9IGFtdDtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgLy8gICBpZiAobW9kZSA9PT0gXCJjYXNoXCIpIGNhc2ggKz0gYW10O1xyXG4gICAgICAgICAgICAvLyAgIGVsc2UgaWYgKG1vZGUgPT09IFwib25saW5lXCIpIG9ubGluZSArPSBhbXQ7XHJcbiAgICAgICAgICAgIC8vICAgZWxzZSBpZiAobW9kZS5pbmNsdWRlcyhcImxpbmtcIikpIGxpbmsgKz0gYW10O1xyXG4gICAgICAgICAgICAvLyB9KTtcclxuXHJcbiAgICAgICAgICAgIHNldENhdGVnb3J5VG90YWxzKHtcclxuICAgICAgICAgICAgICBjaGl0LFxyXG4gICAgICAgICAgICAgIGxvYW4sXHJcbiAgICAgICAgICAgICAgcGlnbWUsXHJcbiAgICAgICAgICAgICAgcmVnaXN0cmF0aW9uLFxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHNldFRvdGFscyh7IGluOiB0aW4sIG91dDogdG91dCwgbmV0OiB0aW4gLSB0b3V0IH0pO1xyXG4gICAgICAgICAgICBzZXRNb2RlVG90YWxzKHtcclxuICAgICAgICAgICAgICBjYXNoLFxyXG4gICAgICAgICAgICAgIG9ubGluZSxcclxuICAgICAgICAgICAgICBsaW5rLFxyXG4gICAgICAgICAgICAgIGF1dG9wYXksXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgc2V0VGFibGVEYXlib29rKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgICAgc2V0VGFibGVEYXlib29rKFtdKTtcclxuICAgICAgICAgIHNldFBheW1lbnRzKDApO1xyXG5cclxuICAgICAgICAgIHNldFRvdGFscyh7XHJcbiAgICAgICAgICAgIGluOiAwLFxyXG4gICAgICAgICAgICBvdXQ6IDAsXHJcbiAgICAgICAgICAgIG5ldDogMCxcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldENhdGVnb3J5VG90YWxzKHtcclxuICAgICAgICAgICAgY2hpdDogMCxcclxuICAgICAgICAgICAgbG9hbjogMCxcclxuICAgICAgICAgICAgcGlnbWU6IDAsXHJcbiAgICAgICAgICAgIHJlZ2lzdHJhdGlvbjogMCxcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldE1vZGVUb3RhbHMoe1xyXG4gICAgICAgICAgICBjYXNoOiAwLFxyXG4gICAgICAgICAgICBvbmxpbmU6IDAsXHJcbiAgICAgICAgICAgIGxpbms6IDAsXHJcbiAgICAgICAgICAgIGF1dG9wYXk6IDAsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG5cclxuICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIHNldFRhYmxlRGF5Ym9vayhbXSk7XHJcbiAgICAgICAgc2V0UGF5bWVudHMoMCk7XHJcblxyXG4gICAgICAgIHNldFRvdGFscyh7XHJcbiAgICAgICAgICBpbjogMCxcclxuICAgICAgICAgIG91dDogMCxcclxuICAgICAgICAgIG5ldDogMCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0Q2F0ZWdvcnlUb3RhbHMoe1xyXG4gICAgICAgICAgY2hpdDogMCxcclxuICAgICAgICAgIGxvYW46IDAsXHJcbiAgICAgICAgICBwaWdtZTogMCxcclxuICAgICAgICAgIHJlZ2lzdHJhdGlvbjogMCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0TW9kZVRvdGFscyh7XHJcbiAgICAgICAgICBjYXNoOiAwLFxyXG4gICAgICAgICAgb25saW5lOiAwLFxyXG4gICAgICAgICAgbGluazogMCxcclxuICAgICAgICAgIGF1dG9wYXk6IDAsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICBzZXRPdmVydmlld0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIHNldENhdGVnb3J5TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgc2V0TW9kZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoUGF5bWVudHMoKTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xyXG4gICAgfTtcclxuICB9LCBbXHJcbiAgICBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLFxyXG4gICAgc2VsZWN0ZWREYXRlLFxyXG4gICAgc2VsZWN0ZWRQYXltZW50TW9kZSxcclxuICAgIHNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgc2VsZWN0ZWRGcm9tRGF0ZSxcclxuICAgIHNlbGVjdGVkQWNjb3VudFR5cGUsXHJcbiAgICBjb2xsZWN0aW9uQWdlbnQsXHJcbiAgICBjb2xsZWN0aW9uQWRtaW4sXHJcbiAgICBzZWxlY3RlZFBheW1lbnRGb3IsXHJcbiAgXSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlBhaWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwidHlwZVwiLFxyXG4gICAgICBoZWFkZXI6IFwiVHlwZVwiLFxyXG4gICAgfSxcclxuICAgIHsga2V5OiBcImNhdGVnb3J5XCIsIGhlYWRlcjogXCJDYXRlZ29yeVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0X25vXCIsIGhlYWRlcjogXCJSZWNlaXB0IE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJvbGRfcmVjZWlwdF9ub1wiLCBoZWFkZXI6IFwiT2xkIFJlY2VpcHRcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwibW9kZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBNb2RlXCIgfSxcclxuICAgIC4uLihoaWRlQWNjb3VudFR5cGVcclxuICAgICAgPyBbeyBrZXk6IFwiYWNjb3VudF90eXBlXCIsIGhlYWRlcjogXCJBY2NvdW50IFR5cGVcIiB9XVxyXG4gICAgICA6IFtdKSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25fdGltZVwiLCBoZWFkZXI6IFwiQ29sbGVjdGlvbiBUaW1lXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3RlZF9ieVwiLCBoZWFkZXI6IFwiQ29sbGVjdGVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBleHBvcnRDb2xzID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJQYWlkIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cFwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcInR5cGVfcmF3XCIsXHJcbiAgICAgIGhlYWRlcjogXCJUeXBlXCIsXHJcbiAgICB9LFxyXG4gICAgeyBrZXk6IFwiY2F0ZWdvcnlcIiwgaGVhZGVyOiBcIkNhdGVnb3J5XCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcIm9sZF9yZWNlaXB0X25vXCIsIGhlYWRlcjogXCJPbGQgUmVjZWlwdFwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRfcmF3XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwibW9kZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBNb2RlXCIgfSxcclxuICAgIC4uLihoaWRlQWNjb3VudFR5cGVcclxuICAgICAgPyBbeyBrZXk6IFwiYWNjb3VudF90eXBlXCIsIGhlYWRlcjogXCJBY2NvdW50IFR5cGVcIiB9XVxyXG4gICAgICA6IFtdKSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25fdGltZVwiLCBoZWFkZXI6IFwiQ29sbGVjdGlvbiBUaW1lXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3RlZF9ieVwiLCBoZWFkZXI6IFwiQ29sbGVjdGVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGdyb3VwSW5mbyAmJiBmb3JtRGF0YS5iaWRfYW1vdW50KSB7XHJcbiAgICAgIGNvbnN0IGNvbW1pc3Npb24gPSAoZ3JvdXBJbmZvLmdyb3VwX3ZhbHVlICogNSkgLyAxMDAgfHwgMDtcclxuICAgICAgY29uc3Qgd2luX2Ftb3VudCA9XHJcbiAgICAgICAgKGdyb3VwSW5mby5ncm91cF92YWx1ZSB8fCAwKSAtIChmb3JtRGF0YS5iaWRfYW1vdW50IHx8IDApO1xyXG4gICAgICBjb25zdCBkaXZpZGVudCA9IChmb3JtRGF0YS5iaWRfYW1vdW50IHx8IDApIC0gY29tbWlzc2lvbjtcclxuICAgICAgY29uc3QgZGl2aWRlbnRfaGVhZCA9IGdyb3VwSW5mby5ncm91cF9tZW1iZXJzXHJcbiAgICAgICAgPyBkaXZpZGVudCAvIGdyb3VwSW5mby5ncm91cF9tZW1iZXJzXHJcbiAgICAgICAgOiAwO1xyXG4gICAgICBjb25zdCBwYXlhYmxlID0gKGdyb3VwSW5mby5ncm91cF9pbnN0YWxsIHx8IDApIC0gZGl2aWRlbnRfaGVhZDtcclxuXHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICBncm91cF9pZDogZ3JvdXBJbmZvLl9pZCxcclxuICAgICAgICBjb21taXNzaW9uLFxyXG4gICAgICAgIHdpbl9hbW91bnQsXHJcbiAgICAgICAgZGl2aWRlbnQsXHJcbiAgICAgICAgZGl2aWRlbnRfaGVhZCxcclxuICAgICAgICBwYXlhYmxlLFxyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfSwgW2dyb3VwSW5mbywgZm9ybURhdGEuYmlkX2Ftb3VudF0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TW9kZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZE1vZGUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldFBheW1lbnRNb2RlKHNlbGVjdGVkTW9kZSk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBwYXlfdHlwZTogc2VsZWN0ZWRNb2RlLFxyXG4gICAgICB0cmFuc2FjdGlvbl9pZDogc2VsZWN0ZWRNb2RlID09PSBcIm9ubGluZVwiID8gcHJldkRhdGEudHJhbnNhY3Rpb25faWQgOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9wYXltZW50L2dldC1wYXltZW50LWJ5LWlkLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlQXVjdGlvbiA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50R3JvdXApIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvcGF5bWVudC9kZWxldGUtcGF5bWVudC8ke2N1cnJlbnRHcm91cC5faWR9YCk7XHJcbiAgICAgICAgYWxlcnQoXCJQYXltZW50IGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgYXVjdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2F1Y3Rpb24vZ2V0LWF1Y3Rpb24tYnktaWQvJHtncm91cElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlR3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhdWN0aW9uOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRmlsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgY29uc3QgZm9ybURhdGFzID0gbmV3IEZvcm1EYXRhKCk7XHJcbiAgICBjb25zdCBmaWxlSW5wdXQgPSBlLnRhcmdldC5maWxlO1xyXG4gICAgaWYgKGZpbGVJbnB1dCAmJiBmaWxlSW5wdXQuZmlsZXNbMF0pIHtcclxuICAgICAgZm9ybURhdGFzLmFwcGVuZChcImZpbGVcIiwgZmlsZUlucHV0LmZpbGVzWzBdKTtcclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChgL3BheW1lbnQvcGF5bWVudC1leGNlbGAsIGZvcm1EYXRhcywge1xyXG4gICAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcIm11bHRpcGFydC9mb3JtLWRhdGFcIiB9LFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDApIHtcclxuICAgICAgICAgIGFsZXJ0KFwiRmlsZSB1cGxvYWRlZCBzdWNjZXNzZnVsbHkhXCIpO1xyXG4gICAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xyXG4gICAgICAgICAgc2V0U2hvd1VwbG9hZE1vZGFsKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwbG9hZGluZyBmaWxlOlwiLCBlcnJvcik7XHJcbiAgICAgICAgYWxlcnQoXCJGYWlsZWQgdG8gdXBsb2FkIGZpbGUuXCIpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgYSBmaWxlIHRvIHVwbG9hZC5cIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBmbGV4LWNvbCBbaGVpZ2h0OmNhbGMoMTAwdmgtMTAwcHgpXSBvdmVyZmxvdy14LWF1dG8gXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgXCI+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxDdXN0b21BbGVydFxyXG4gICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC04IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tc2xhdGUtNTAgdmlhLWJsdWUtNTAgdG8taW5kaWdvLTUwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgICAgICB7LyogSGVhZGVyIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWluZGlnby02MDAgdG8tYmx1ZS02MDAgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnQgcC0yXCI+XHJcbiAgICAgICAgICAgICAgICBSZXBvcnRzIC0gUmVjZWlwdFxyXG4gICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtdC0yIG1sLTJcIj5cclxuICAgICAgICAgICAgICAgIFRyYWNrIGFuZCBtYW5hZ2UgYWxsIHJlY2VpcHQgdHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgey8qIEZpbHRlcnMgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgcC02IG1iLTggYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi02IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1pbmRpZ28tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNMyA0YTEgMSAwIDAxMS0xaDE2YTEgMSAwIDAxMSAxdjIuNTg2YTEgMSAwIDAxLS4yOTMuNzA3bC02LjQxNCA2LjQxNGExIDEgMCAwMC0uMjkzLjcwN1YxN2wtNCA0di02LjU4NmExIDEgMCAwMC0uMjkzLS43MDdMMy4yOTMgNy4yOTNBMSAxIDAgMDEzIDYuNTg2VjR6XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgRmlsdGVyIE9wdGlvbnNcclxuICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTQgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBGaWx0ZXIgT3B0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEZpbHRlciBPcHRpb25cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTZWxlY3RGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IEZpbHRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKHRpbWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dGltZS52YWx1ZX0gdmFsdWU9e3RpbWUudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dGltZS5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ3VzdG9tIERhdGUgUmFuZ2UgKi99XHJcbiAgICAgICAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBGcm9tIERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRGcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMiBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbCBvdXRsaW5lLW5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUbyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tYWxsIG91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEdyb3VwIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQXVjdGlvbkdyb3VwSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBPciBTZWxlY3QgR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPXtcIlwifT5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEN1c3RvbWVyc31cclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBPciBTZWxlY3QgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZ3JvdXBJZCkgPT4gc2V0U2VsZWN0ZWRDdXN0b21lcnMoZ3JvdXBJZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkVXNlcnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cD8uX2lkfSB2YWx1ZT17Z3JvdXA/Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cD8uZnVsbF9uYW1lfSAtIHtncm91cC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFBheW1lbnRNb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBwYXltZW50IG1vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhtb2RlcykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQYXltZW50TW9kZShtb2Rlcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogXCI0NHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkNhc2hcIiwgdmFsdWU6IFwiY2FzaFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIk9ubGluZVwiLCB2YWx1ZTogXCJvbmxpbmVcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJPbmxpbmUvQXV0b1BheVwiLCB2YWx1ZTogXCJvbmxpbmUvYXV0b1BheVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIk9ubGluZS9QYXltZW50IExpbmtcIiwgdmFsdWU6IFwiUGF5bWVudCBMaW5rXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiQ2hlcXVlXCIsIHZhbHVlOiBcImNoZXF1ZVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBGb3JcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHN0eWxlPlxyXG4gICAgICAgICAgICAgICAgICAgIHtgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5jdXN0b20tc2VsZWN0IC5hbnQtc2VsZWN0LXNlbGVjdG9yIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW4taGVpZ2h0OiA0NHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4LWhlaWdodDogNjBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG92ZXJmbG93LXk6IGF1dG8gIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5jdXN0b20tc2VsZWN0IC5hbnQtc2VsZWN0LXNlbGVjdGlvbi1vdmVyZmxvdyB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4LWhlaWdodDogNjBweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvdmVyZmxvdy15OiBhdXRvO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBgfVxyXG4gICAgICAgICAgICAgICAgICA8L3N0eWxlPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgbW9kZT1cIm11bHRpcGxlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRQYXltZW50Rm9yfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBwYXltZW50IGZvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KG1vZGVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBheW1lbnRGb3IobW9kZXMpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5sYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGN1c3RvbS1zZWxlY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiQ2hpdFwiLCB2YWx1ZTogXCJDaGl0XCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiUGlnbWVcIiwgdmFsdWU6IFwiUGlnbWVcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJMb2FuXCIsIHZhbHVlOiBcIkxvYW5cIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJSZWdpc3RyYXRpb25cIiwgdmFsdWU6IFwiUmVnaXN0cmF0aW9uXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEFjY291bnQgVHlwZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICB7c2hvd0FsbFBheW1lbnRNb2RlcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQWNjb3VudCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBY2NvdW50VHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIE9yIFNlbGVjdCBBY2NvdW50IFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZ3JvdXBJZCkgPT4gc2V0U2VsZWN0ZWRBY2NvdW50VHlwZShncm91cElkKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWNjb3VudCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cInN1c3BlbnNlXCI+U3VzcGVuc2U8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImNyZWRpdFwiPkNyZWRpdDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiYWRqdXN0bWVudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBZGp1c3RtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIm90aGVyc1wiPk90aGVyczwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBDb2xsZWN0aW9uIEVtcGxveWVlIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBDb2xsZWN0aW9uIEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IENvbGxlY3Rpb24gQWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhzZWxlY3Rpb24pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IFtpZCwgdHlwZV0gPSBzZWxlY3Rpb24uc3BsaXQoXCJ8XCIpIHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGUgPT09IFwiYWRtaW5fdHlwZVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENvbGxlY3Rpb25BZG1pbihpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENvbGxlY3Rpb25BZ2VudChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJhZ2VudF90eXBlXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29sbGVjdGlvbkFnZW50KGlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29sbGVjdGlvbkFkbWluKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29sbGVjdGlvbkFkbWluKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRDb2xsZWN0aW9uQWdlbnQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7Wy4uLm5ldyBTZXQoYWdlbnRzKSwgLi4ubmV3IFNldChhZG1pbnMpXS5tYXAoKGR0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2R0Py5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHtkdC5faWR9fCR7ZHQuc2VsZWN0ZWRfdHlwZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZHQuc2VsZWN0ZWRfdHlwZSA9PT0gXCJhZG1pbl90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiQWRtaW4gfCBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJBZ2VudCB8IFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZHQuZnVsbF9uYW1lfSB8IHtkdC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBiZy1ncmF5LTUwIHJvdW5kZWQtMnhsIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgIHsvKiBTRUNUSU9OOiBPdmVydmlldyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gY2xhc3NOYW1lPVwiIW1iLTQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBGaW5hbmNpYWwgT3ZlcnZpZXdcclxuICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8U3BpbiBzcGlubmluZz17b3ZlcnZpZXdMb2FkaW5nfSBzaXplPVwibGFyZ2VcIj5cclxuICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1syMCwgMjBdfT5cclxuICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gbWQ9ezEyfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0yMDAgc2hhZG93LW1kIHJvdW5kZWQtbGcgYmctd2hpdGUgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9keVN0eWxlPXt7IHBhZGRpbmc6IDE2IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgYm9yZGVyLWIgYm9yZGVyLWRhc2hlZCBwYi0yIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgQ29sbGVjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QXJyb3dVcE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dG90YWxzLmlufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjMDY1ZjQ2XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjcwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMi4wcmVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWRhc2hlZCBtdC0zIHB0LTIgdGV4dC1jZW50ZXIgdGV4dC1bMTFweF0gaXRhbGljIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhOdW1iZXIodG90YWxzLmluKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhcmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBzaGFkb3ctbWQgcm91bmRlZC1sZyBiZy13aGl0ZSByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBib2R5U3R5bGU9e3sgcGFkZGluZzogMTYgfX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBib3JkZXItYiBib3JkZXItZGFzaGVkIHBiLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBQYXlPdXRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwcmVmaXg9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFycm93RG93bk91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dG90YWxzLm91dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwcmVjaXNpb249ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzA2NWY0NlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogXCI3MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjIuMHJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dEFsaWduOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1kYXNoZWQgbXQtMyBwdC0yIHRleHQtY2VudGVyIHRleHQtWzExcHhdIGl0YWxpYyB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoTnVtYmVyKHRvdGFscy5vdXQpKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgPC9TcGluPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8RGl2aWRlciAvPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gY2xhc3NOYW1lPVwiIW1iLTQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBDYXRlZ29yeSBCcmVha2Rvd25cclxuICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8U3BpbiBzcGlubmluZz17Y2F0ZWdvcnlMb2FkaW5nfSBzaXplPVwibGFyZ2VcIj5cclxuICAgICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfT5cclxuICAgICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJDaGl0IENvbGxlY3Rpb25zXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbDogY2F0ZWdvcnlUb3RhbHMuY2hpdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzRmNDZlNVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBiZzogXCJmcm9tLWluZGlnby01MCB0by13aGl0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8QmFua091dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTUwMFwiIC8+LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiTG9hbiBDb2xsZWN0aW9uc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWw6IGNhdGVnb3J5VG90YWxzLmxvYW4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiNmNTllMGJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmc6IFwiZnJvbS1hbWJlci01MCB0by13aGl0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hbWJlci01MDAgZm9udC1ib2xkXCI+4oK5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiUGlnbWUgQ29sbGVjdGlvbnNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsOiBjYXRlZ29yeVRvdGFscy5waWdtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzBkOTQ4OFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBiZzogXCJmcm9tLXRlYWwtNTAgdG8td2hpdGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPFdhbGxldE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtdGVhbC01MDBcIiAvPixcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlJlZ2lzdHJhdGlvbiBGZWVzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbDogY2F0ZWdvcnlUb3RhbHMucmVnaXN0cmF0aW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjZGIyNzc3XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJnOiBcImZyb20tcGluay01MCB0by13aGl0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNhZmV0eUNlcnRpZmljYXRlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1waW5rLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF0ubWFwKChpdGVtLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs2fSBrZXk9e2lkeH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bib3JkZXIgc2hhZG93LW1kIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tYiAke2l0ZW0uYmd9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBib2R5U3R5bGU9e3sgcGFkZGluZzogMTQgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBib3JkZXItYiBib3JkZXItZGFzaGVkIHBiLTIgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uaWNvbn1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFtb3VudCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXhsIGZvbnQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogaXRlbS5jb2xvciB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7KGl0ZW0udmFsIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBXb3JkcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1kYXNoZWQgbXQtMiBwdC0yIHRleHQtWzEwcHhdIHRleHQtY2VudGVyIGl0YWxpYyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhpdGVtLnZhbCB8fCAwKX0gT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICA8L1NwaW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBTRUNUSU9OOiBQYXltZW50IE1vZGVzID09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPFRpdGxlIGxldmVsPXs0fSBjbGFzc05hbWU9XCIhbWItNCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZXNcclxuICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8U3BpbiBzcGlubmluZz17bW9kZUxvYWRpbmd9IHNpemU9XCJsYXJnZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19PlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIkNhc2hcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsOiBtb2RlVG90YWxzLmNhc2gsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMxNmEzNGFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmc6IFwiZnJvbS1ncmVlbi01MCB0by13aGl0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8V2FsbGV0T3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi01MDBcIiAvPixcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIk9ubGluZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWw6IG1vZGVUb3RhbHMub25saW5lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjMjU2M2ViXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJnOiBcImZyb20tYmx1ZS01MCB0by13aGl0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8R2xvYmFsT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiIC8+LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiUGF5bWVudCBMaW5rXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbDogbW9kZVRvdGFscy5saW5rLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjN2MzYWVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJnOiBcImZyb20tdmlvbGV0LTUwIHRvLXdoaXRlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxMaW5rT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNTAwXCIgLz4sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJBdXRvUGF5XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbDogbW9kZVRvdGFscy5hdXRvcGF5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjN2MzYWVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxUaHVuZGVyYm9sdE91dGxpbmVkIC8+LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBdLm1hcCgobW9kZSwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gbWQ9ezZ9IGtleT17aWR4fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bib3JkZXIgc2hhZG93LW1kIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tYiAke21vZGUuYmd9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBib2R5U3R5bGU9e3sgcGFkZGluZzogMTYgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBib3JkZXItYiBib3JkZXItZGFzaGVkIHBiLTIgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge21vZGUuaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bW9kZS50aXRsZX0gQ29sbGVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBbW91bnQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC14bCBmb250LWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IG1vZGUuY29sb3IgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrkgeyhtb2RlLnZhbCB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogV29yZHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItZGFzaGVkIG10LTIgcHQtMiB0ZXh0LVsxMHB4XSBpdGFsaWMgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMobW9kZS52YWwgfHwgMCl9IE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgPC9TcGluPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgey8qIFRvdGFsIEFtb3VudCBDYXJkICovfVxyXG5cclxuICAgICAgICAgICAgICB7LyogRGF0YSBUYWJsZSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIHtmaWx0ZXJlZEF1Y3Rpb24gJiYgZmlsdGVyZWRBdWN0aW9uLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1pbmRpZ28tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOSAxMmg2bS02IDRoNm0yIDVIN2EyIDIgMCAwMS0yLTJWNWEyIDIgMCAwMTItMmg1LjU4NmExIDEgMCAwMS43MDcuMjkzbDUuNDE0IDUuNDE0YTEgMSAwIDAxLjI5My43MDdWMTlhMiAyIDAgMDEtMiAyelwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlRGF5Ym9vaywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRDb2xzPXtleHBvcnRDb2xzfVxyXG4gICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgXCJUb3RhbCBJTiAoQ29sbGVjdGlvbnMpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIE9VVCAoUGF5b3V0cylcIixcclxuICAgICAgICAgICAgICAgICAgICAgIFwiQ2hpdCBDb2xsZWN0aW9uc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJMb2FuIENvbGxlY3Rpb25zXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlBpZ21lIENvbGxlY3Rpb25zXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlJlZ2lzdHJhdGlvbiBGZWVzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkNhc2ggQ29sbGVjdGlvblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJPbmxpbmUgQ29sbGVjdGlvblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJQYXltZW50IExpbmtcIixcclxuICAgICAgICAgICAgICAgICAgICAgIFwiQXV0b1BheVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgIHRvdGFscy5pbixcclxuICAgICAgICAgICAgICAgICAgICAgIHRvdGFscy5vdXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjYXRlZ29yeVRvdGFscy5jaGl0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2F0ZWdvcnlUb3RhbHMubG9hbixcclxuICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5VG90YWxzLnBpZ21lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2F0ZWdvcnlUb3RhbHMucmVnaXN0cmF0aW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbW9kZVRvdGFscy5jYXNoLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbW9kZVRvdGFscy5vbmxpbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgICBtb2RlVG90YWxzLmxpbmssXHJcbiAgICAgICAgICAgICAgICAgICAgICBtb2RlVG90YWxzLmF1dG9wYXksXHJcbiAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BSZWNlaXB0IFJlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YFJlcG9ydHMgUmVjZWlwdC5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LTYgcHQtNiBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1pbmRpZ28tNTAgdG8tYmx1ZS01MCBweC02IHB5LTMgcm91bmRlZC14bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBBbW91bnQ6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7cGF5bWVudHM/LnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgcC0xMiB0ZXh0LWNlbnRlciBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e2ZpbHRlcmVkQXVjdGlvbi5sZW5ndGggPD0gMH1cclxuICAgICAgICAgICAgICAgICAgICBkYXRhPVwiUmVjZWlwdCBEYXRhXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBheW1lbnRSZXBvcnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9QYXltZW50UmVwb3J0LmpzeCJ9